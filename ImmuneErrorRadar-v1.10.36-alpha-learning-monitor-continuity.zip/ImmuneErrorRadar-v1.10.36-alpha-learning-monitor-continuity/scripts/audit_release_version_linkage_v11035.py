#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.35 release file: {rel}')
    return p.read_text(errors='replace')

checks = {
    'app/build.gradle.kts': ['versionCode = 97', 'versionName = "1.10.35-alpha-lead-closure-learning-rules"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.35-alpha-lead-closure-learning-rules', 'UsefulLearningReportPolicy'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.10.35-alpha-lead-closure-learning-rules"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 97', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.35"',
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 97', 'VERSION_NAME: String = "1.10.35-alpha-lead-closure-learning-rules"',
        'ENGINE_VERSION: String = "v1.10.35-alpha-lead-closure-learning-rules"', 'LEARNING_SCHEMA_VERSION: String = "1.10.35"',
        'lead-closure handoff', 'metadata closure', 'unknown-route classifier',
    ],
    'scripts/run_static_checks_fast.sh': ['audit_v11035_lead_closure_handoff.py', 'audit_release_version_linkage_v11035.py'],
    'scripts/run_static_checks_full.sh': ['audit_v11035_lead_closure_handoff.py', 'audit_release_version_linkage_v11035.py'],
    'scripts/run_static_checks.sh': ['1.10.35-alpha-lead-closure-learning-rules'],
    'docs/CHANGELOG_v1.10.35.md': ['1.10.35-alpha-lead-closure-learning-rules', 'versionCode=97'],
}
for rel, tokens in checks.items():
    text = read(rel)
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing release linkage token: {token}')
print('v1.10.35 release version linkage audit: PASS')
