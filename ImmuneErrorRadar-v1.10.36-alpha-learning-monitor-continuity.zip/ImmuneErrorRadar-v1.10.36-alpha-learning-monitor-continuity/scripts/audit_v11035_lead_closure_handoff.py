#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.35 file: {rel}')
    return p.read_text(errors='replace')

checks = {
    'app/src/main/java/com/immunesignal/app/LeadClosureHandoffV11035.kt': [
        'LeadClosureHandoffPolicy', 'LeadClosureHandoffReport', 'MetadataClosureReport',
        'UnknownRouteClassificationReport', 'LEAD_OBJECT_SECONDARY_LOOKUP',
        'MINIMUM_METADATA_CLOSURE', 'ARCHIVE_OR_COOLDOWN_WITH_EXPLICIT_REASON',
        'latent_virus_reactivation_route', 'ROUTE_PRIOR_ONLY_NOT_EVIDENCE',
        'lead_closure_handoff_not_biological_proof', 'EBV', 'HHV-6', 'CMV',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': [
        'leadClosureHandoffReport', 'metadataClosureReport', 'unknownRouteClassificationReport',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'leadClosureHandoffReport', 'metadataClosureReport', 'unknownRouteClassificationReport',
        'leadClosureHandoffToJson', 'metadataClosureToJson', 'unknownRouteClassificationToJson',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'LeadClosureHandoffPolicy.shouldForceLeadClosure', 'extractSeedTextsFromRecentReports',
        'leadClosureHandoffRequestedV11035', 'DATASET_FORAGING_LEAD_OBJECT_SECONDARY_LOOKUP',
        'DATASET_FORAGING_MINIMUM_METADATA_CLOSURE', 'v1.10.35 lead closure handoff',
        'v1.10.35 metadata closure', 'v1.10.35 unknown-route classifier',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingPathLinkageGuard.kt': [
        'MINIMUM_METADATA_CLOSURE', 'LEAD_OBJECT_SECONDARY_LOOKUP', 'matureProbeConsumedByLeadPath',
    ],
    'app/src/main/java/com/immunesignal/app/UsefulLearningReportV11034.kt': [
        'lead_closure_handoff_pinned', 'metadata_closure_fields_tracked',
        'route_prior_classified', 'latent_virus_route_prior_saved', 'Saved rules:',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'LearningRulesUiSummary.renderCompact', 'LearningRulesUiSummary.renderMini',
        'Lead closure handoff v1.10.35', 'Metadata closure v1.10.35', 'Unknown-route classifier v1.10.35',
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Lead closure handoff v1.10.35', 'Metadata closure v1.10.35', 'Unknown-route classifier v1.10.35',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'LeadClosureHandoffPolicy', 'MetadataClosureAgent', 'UnknownRouteClassifier', 'LearningRulesUiSummary',
    ],
    'app/src/test/java/com/immunesignal/app/LeadClosureHandoffV11035Test.kt': [
        'LeadClosureHandoffV11035Test', 'priorWeakLeadForcesClosureHandoff',
        'metadataClosureTracksExactMissingFields', 'ebvIsSavedAsLatentVirusRoutePriorOnlyNotProof',
        'pathLinkageAcceptsWeakAccessionMetadataClosureAsLeadPath',
    ],
    'docs/LEAD_CLOSURE_HANDOFF_v1.10.35.md': [
        'Lead Closure Handoff', 'Metadata Closure Agent', 'Unknown Route Classifier',
        'latent_virus_reactivation_route', 'ROUTE_PRIOR_ONLY_NOT_EVIDENCE',
    ],
    'docs/CHANGELOG_v1.10.35.md': [
        '1.10.35-alpha-lead-closure-learning-rules', 'versionCode=97',
        'LeadClosureHandoffPolicy', 'MetadataClosureAgent', 'UnknownRouteClassifier',
    ],
}
for rel, tokens in checks.items():
    text = read(rel)
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.35 token: {token}')
print('v1.10.35 lead closure handoff audit: PASS')
