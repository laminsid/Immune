package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.10.36: user-facing learning audit monitor.
 *
 * This layer is intentionally report-only. It turns the evidence/lead handoff,
 * metadata closure, and route-prior reports into a compact inspection card so the
 * UI shows what was actually learned, which rules were pinned, what is still
 * missing, and what would invalidate the saved prior. It never upgrades biology.
 */
data class LearningRulesAuditCard(
    val monitorState: String,
    val learnedDetails: List<String>,
    val pinnedRules: List<String>,
    val savedPriors: List<String>,
    val stillMissing: List<String>,
    val invalidators: List<String>,
    val nextAuditAction: String,
    val claimLimit: String = LearningRulesUiSummary.CLAIM_LIMIT
)

object LearningRulesUiSummary {
    const val CLAIM_LIMIT: String = "learning_rules_ui_monitor_not_biological_proof"

    fun buildCard(forager: JSONObject): LearningRulesAuditCard {
        val handoff = forager.optJSONObject("leadClosureHandoffReport") ?: JSONObject()
        val metadata = forager.optJSONObject("metadataClosureReport") ?: JSONObject()
        val route = forager.optJSONObject("unknownRouteClassificationReport") ?: JSONObject()
        val progress = forager.optJSONObject("researchProgressWithoutEvidenceReport") ?: JSONObject()
        val leadQueue = forager.optJSONObject("leadInspectionQueueReport") ?: JSONObject()
        val learningValue = forager.optJSONObject("learningValueScoreReport") ?: JSONObject()

        val learned = mutableListOf<String>()
        val categories = jsonArrayToList(progress.optJSONArray("successCategories")) + jsonArrayToList(learningValue.optJSONArray("usefulOutcomes"))
        val friendlyCategories = categories.mapNotNull { friendlyCategory(it) }.distinct()
        if (friendlyCategories.isNotEmpty()) {
            learned += "saved progress: ${friendlyCategories.take(4).joinToString(", ")}"
        }
        if (handoff.optBoolean("active", false)) {
            learned += "carried weak lead(s): ${handoff.optInt("carriedLeadCount", 0)}"
        }
        if (metadata.optBoolean("active", false)) {
            val closed = jsonArrayToList(metadata.optJSONArray("closedFields"))
            val missing = jsonArrayToList(metadata.optJSONArray("missingFields"))
            learned += "metadata checked: closed ${closed.size}, missing ${missing.size}"
        }
        if (route.optBoolean("active", false)) {
            learned += "route prior saved: ${friendlyRoute(route.optString("selectedRoute", "none"))} (${route.optInt("confidence", 0)}/100, not proof)"
        }
        if (leadQueue.optBoolean("active", false)) {
            learned += "lead queue open: ${leadQueue.optInt("openItems", 0)} item(s)"
        }

        val pinned = (
            jsonArrayToList(handoff.optJSONArray("pinnedLearningRules")) +
                listOf(
                    "Do not upgrade without an EvidenceObject.",
                    "Do not let a weak/off-route lead disappear before secondary lookup or explicit archive.",
                    "Close minimum metadata before contradiction search.",
                    "A route prior is routing memory only, not biological evidence."
                )
            ).map { cleanRule(it) }.filter { it.isNotBlank() }.distinct().take(6)

        val savedPriors = routePriors(route).ifEmpty {
            val selected = route.optString("selectedRoute", "none")
            if (selected.isNotBlank() && selected != "none") listOf("${friendlyRoute(selected)} — route prior only") else emptyList()
        }

        val missing = (
            jsonArrayToList(metadata.optJSONArray("missingFields")) +
                firstLeadMissing(leadQueue) +
                jsonArrayToList(handoff.optJSONArray("missingFields"))
            ).map { friendlyField(it) }.filter { it.isNotBlank() }.distinct().take(8)

        val invalidators = buildInvalidators(route.optString("selectedRoute", "none"), missing)
        val next = firstNonBlank(
            handoff.optString("forcedNextAction"),
            metadata.optString("nextAction"),
            leadQueue.optString("nextAction"),
            route.optString("nextAction"),
            forager.optString("nextAction"),
            "Run secondary lookup or metadata closure before any broad search."
        )

        val state = when {
            metadata.optString("state").contains("READY_FOR_CONTRADICTION", true) -> "METADATA_READY_CONTRADICTION_NEXT"
            handoff.optBoolean("active", false) && missing.isNotEmpty() -> "LEAD_RULES_PINNED_METADATA_OPEN"
            route.optBoolean("active", false) -> "ROUTE_PRIOR_SAVED_NO_PROOF"
            learned.isNotEmpty() -> "LEARNING_PROGRESS_MONITORED"
            else -> "NO_LEARNING_MONITOR_SIGNAL"
        }

        return LearningRulesAuditCard(
            monitorState = state,
            learnedDetails = learned.ifEmpty { listOf("No new audit-level learning was saved in this cycle.") },
            pinnedRules = pinned,
            savedPriors = savedPriors,
            stillMissing = missing.ifEmpty { listOf("none listed") },
            invalidators = invalidators,
            nextAuditAction = cleanAction(next)
        )
    }

    fun renderCompact(forager: JSONObject): String {
        val card = buildCard(forager)
        return buildString {
            append("Learning audit monitor\n")
            append("• State: ").append(card.monitorState).append("\n")
            append("• Learned now: ").append(card.learnedDetails.take(3).joinToString("; ")).append("\n")
            append("• Rules kept: ").append(card.pinnedRules.take(3).joinToString("; ")).append("\n")
            if (card.savedPriors.isNotEmpty()) {
                append("• Saved priors: ").append(card.savedPriors.take(3).joinToString("; ")).append("\n")
            }
            append("• Still missing: ").append(card.stillMissing.take(5).joinToString(", ")).append("\n")
            append("• Invalidate if: ").append(card.invalidators.take(2).joinToString("; ")).append("\n")
            append("• Next audit: ").append(card.nextAuditAction)
        }
    }

    fun renderMini(forager: JSONObject): String {
        val card = buildCard(forager)
        return buildString {
            append("• Learning monitor: ").append(card.monitorState).append("\n")
            append("• Learned: ").append(card.learnedDetails.take(2).joinToString("; ")).append("\n")
            append("• Rule kept: ").append(card.pinnedRules.firstOrNull().orEmpty().ifBlank { "No upgrade without EvidenceObject." }).append("\n")
            append("• Missing: ").append(card.stillMissing.take(4).joinToString(", ")).append("\n")
            append("• Invalidate: ").append(card.invalidators.firstOrNull().orEmpty().ifBlank { "if metadata stays unresolved" })
        }
    }

    private fun routePriors(route: JSONObject): List<String> {
        val priors = route.optJSONArray("routePriors") ?: JSONArray()
        val out = mutableListOf<String>()
        for (i in 0 until priors.length().coerceAtMost(4)) {
            val item = priors.optJSONObject(i) ?: continue
            val id = item.optString("routeId", "none")
            if (id.isBlank() || id == "none") continue
            out += "${friendlyRoute(id)} — ${item.optInt("confidence", 0)}/100"
        }
        return out
    }

    private fun firstLeadMissing(leadQueue: JSONObject): List<String> {
        val items = leadQueue.optJSONArray("items") ?: return emptyList()
        return jsonArrayToList(items.optJSONObject(0)?.optJSONArray("missing"))
    }

    private fun buildInvalidators(selectedRoute: String, missing: List<String>): List<String> {
        val out = mutableListOf<String>()
        if (missing.any { it.contains("control", true) || it.contains("comparator", true) }) {
            out += "control/comparator remains absent after closure"
        }
        if (missing.any { it.contains("outcome", true) }) {
            out += "outcome labels remain absent"
        }
        if (missing.any { it.contains("accession", true) || it.contains("data availability", true) }) {
            out += "no explicit accession or data-availability text is found"
        }
        if (selectedRoute.contains("latent_virus", true)) {
            out += "EBV/HHV-6/CMV terms do not appear in accession-level metadata"
        }
        out += "a better route explains the same lead with fewer assumptions"
        return out.distinct().take(4)
    }

    private fun friendlyCategory(value: String): String? = when (value.trim().lowercase()) {
        "topic_stored" -> "topic saved"
        "dataset_first_attempted" -> "dataset-first search attempted"
        "weak_lead_preserved" -> "weak lead preserved"
        "gap_queue_created" -> "evidence gap queue created"
        "query_strategy_changed" -> "query strategy changed"
        "dataset_catalog_strategy_prepared", "post_pubmed_strategy_prepared" -> "dataset-catalog strategy prepared"
        "failure_pattern_learned" -> "failure pattern learned"
        "lead_closure_handoff_pinned" -> "lead-closure rule pinned"
        "metadata_closure_fields_tracked" -> "metadata fields tracked"
        "route_prior_classified" -> "route prior classified"
        "latent_virus_route_prior_saved" -> "latent-virus route saved as prior"
        else -> null
    }

    private fun friendlyRoute(value: String): String = when (value.trim()) {
        "type2_allergy_mast_cell_route" -> "Type-2 allergy / mast-cell route"
        "autoimmune_flare_route" -> "autoimmune flare route"
        "interferon_antiviral_route" -> "interferon / antiviral route"
        "latent_virus_reactivation_route" -> "latent-virus reactivation route"
        "drug_perturbation_route" -> "drug perturbation route"
        "stress_immune_psychoneuro_route" -> "stress-immune route"
        "barrier_tissue_route" -> "barrier tissue route"
        "rna_transcriptomic_state_route" -> "RNA/transcriptomic state route"
        else -> value.replace('_', ' ').ifBlank { "unknown route" }
    }

    private fun friendlyField(value: String): String = when (value.trim().lowercase()) {
        "accession" -> "accession"
        "human_or_patient_data" -> "human/patient data"
        "sample_size" -> "sample size"
        "condition_labels" -> "condition labels"
        "outcome_labels" -> "outcome labels"
        "control_or_comparator", "comparator_control" -> "control/comparator"
        "time_order" -> "time order"
        "tissue_or_cell_context" -> "tissue/cell context"
        "license_access" -> "license/access"
        "data_availability_text" -> "data availability text"
        else -> value.replace('_', ' ')
    }

    private fun cleanRule(value: String): String = value
        .replace("EvidenceObject", "EvidenceObject")
        .replace('_', ' ')
        .trim()
        .take(180)

    private fun cleanAction(value: String): String = value
        .replace("LEAD_OBJECT_SECONDARY_LOOKUP", "secondary lead lookup")
        .replace("MINIMUM_METADATA_CLOSURE", "minimum metadata closure")
        .replace("BROAD_PUBMED_SEARCH", "broad PubMed search")
        .replace('_', ' ')
        .trim()
        .take(220)

    private fun jsonArrayToList(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        val out = mutableListOf<String>()
        for (i in 0 until array.length()) {
            val value = array.opt(i)
            if (value is String && value.isNotBlank()) out += value
        }
        return out
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""
}
