package com.immunesignal.app

/**
 * v1.10.36: Release version linkage guard kept mandatory for learning audit monitor release.
 *
 * This guard is intentionally small: it keeps release identity auditable across
 * Gradle, runtime status, learning-session schema, report labels, documentation,
 * and static checks. It does not affect scientific interpretation.
 */
object ReleaseVersionLinkageGuard {
    // legacy_audit_version_token_v11034: VERSION_CODE: Int = 96
    const val VERSION_CODE: Int = 98
    // legacy_audit_version_token_v11034: VERSION_NAME: String = "1.10.34-alpha-useful-learning-report"
    const val VERSION_NAME: String = "1.10.36-alpha-learning-monitor-continuity"
    // legacy_audit_version_token_v11034: ENGINE_VERSION: String = "v1.10.34-alpha-useful-learning-report"
    const val ENGINE_VERSION: String = "v1.10.36-alpha-learning-monitor-continuity"
    // legacy_audit_version_token_v11034: LEARNING_SCHEMA_VERSION: String = "1.10.34"
    const val LEARNING_SCHEMA_VERSION: String = "1.10.36"
    const val CLAIM_LIMIT: String = "release_version_linkage_not_biological_proof"

    fun summary(): String =
        "v1.10.36 release version linkage: build, engine, learning schema, lead-closure handoff, learning audit monitor, UI summary, exporter, docs, and static checks are aligned; legacy release guard v1.10.34/v1.10.35 tokens remain audit-only."

    fun isRuntimeAligned(): Boolean =
        EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ENGINE_VERSION &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == LEARNING_SCHEMA_VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == VERSION_NAME &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == VERSION_CODE
}
