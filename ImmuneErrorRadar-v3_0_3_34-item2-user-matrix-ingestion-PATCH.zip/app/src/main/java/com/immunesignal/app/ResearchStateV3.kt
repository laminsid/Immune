package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

data class ResearchInputV3(
    val topic: String,
    val primaryHypothesisId: String = "H1_PRIMARY",
    val budget: ResearchBudgetV3 = ResearchBudgetV3(),
    val explicitMatrixRows: List<ExpressionSampleRowV30329> = emptyList(),
    // v3.0.3.34 — item 2: user-supplied matrix ingestion.
    // Non-blank provenance + declared case/control group labels are what let a
    // pasted/uploaded sample-level matrix reach CERTIFIED_USER_SUPPLIED_WITH_PROVENANCE.
    val explicitMatrixProvenance: String = "",
    val explicitCaseLabels: List<String> = emptyList(),
    val explicitControlLabels: List<String> = emptyList()
)

data class ResearchBudgetV3(
    val maxNetworkCalls: Int = 14,
    val maxEmptyQueries: Int = 6,
    val maxRepeatedSourceFamily: Int = 2,
    val minimumEvidenceQuality: QualityTierV3 = QualityTierV3.B,
    val minimumIndependentAccessions: Int = 2,
    val requireContradictionAttempt: Boolean = true,
    val minNetworkCallsForReport: Int = 4,
    val minExecutedEvidenceObjectivesForReport: Int = 4,
    val maxObjectives: Int = 8,
    val sourceQueryReserve: Int = 3,
    val datasetQueryReserve: Int = 3,
    val contradictionQueryReserve: Int = 3,
    val provenanceQueryReserve: Int = 2,
    val retryEmptyNetworkErrorOnce: Boolean = true
) {
    fun hasCapacity(usage: BudgetUsageV3, executedObjectives: Int): Boolean =
        executedObjectives < maxObjectives &&
            usage.networkCalls < maxNetworkCalls &&
            usage.emptyQueries <= maxEmptyQueries

    fun roleFor(objective: ResearchObjectiveV3): EvidenceRoleV3 = when (objective) {
        is ResearchObjectiveV3.FindSourceEvidence -> EvidenceRoleV3.SOURCE
        is ResearchObjectiveV3.FindDatasetEvidence -> EvidenceRoleV3.DATASET
        is ResearchObjectiveV3.FindProvenance -> EvidenceRoleV3.PROVENANCE
        is ResearchObjectiveV3.FindContradiction -> EvidenceRoleV3.CONTRADICTION
        is ResearchObjectiveV3.RankHypotheses -> EvidenceRoleV3.HYPOTHESIS_RANKING
        is ResearchObjectiveV3.ContinueHypothesisProof -> EvidenceRoleV3.MECHANISM
        is ResearchObjectiveV3.CompileReport -> EvidenceRoleV3.CONTEXT
    }

    fun queryReserveForRole(role: EvidenceRoleV3): Int = when (role) {
        EvidenceRoleV3.SOURCE -> sourceQueryReserve
        EvidenceRoleV3.DATASET -> datasetQueryReserve
        EvidenceRoleV3.CONTRADICTION, EvidenceRoleV3.FALSIFIER -> contradictionQueryReserve
        EvidenceRoleV3.PROVENANCE -> provenanceQueryReserve
        EvidenceRoleV3.MECHANISM -> 2
        else -> 0
    }.coerceAtLeast(0)

    fun contradictionPending(snapshot: EvidenceLedgerSnapshotV3): Boolean = requireContradictionAttempt &&
        !snapshot.objectiveExecuted("contradiction:")

    fun canStartObjective(
        objective: ResearchObjectiveV3,
        usage: BudgetUsageV3,
        executedObjectives: Int,
        snapshot: EvidenceLedgerSnapshotV3
    ): Boolean {
        if (executedObjectives >= maxObjectives) return false
        if (objective is ResearchObjectiveV3.RankHypotheses || objective is ResearchObjectiveV3.CompileReport) return true
        if (usage.networkCalls >= maxNetworkCalls) return false
        val role = roleFor(objective)
        val remaining = maxNetworkCalls - usage.networkCalls
        val contradictionStillPending = contradictionPending(snapshot)

        // Provenance is useful, but it must not consume the reserve needed for the
        // mandatory falsification objective. This is the core v3.0.3.10 budget fix.
        if (contradictionStillPending && role == EvidenceRoleV3.PROVENANCE) {
            return remaining > contradictionQueryReserve
        }

        // Empty-query exhaustion must not prevent mandatory source/dataset/contradiction
        // attempts. It can only stop optional enrichers.
        if (usage.emptyQueries > maxEmptyQueries && role == EvidenceRoleV3.PROVENANCE) return false
        return remaining > 0
    }

    fun allowedNetworkCallsForObjective(
        role: EvidenceRoleV3,
        usage: BudgetUsageV3,
        snapshot: EvidenceLedgerSnapshotV3
    ): Int {
        val remaining = (maxNetworkCalls - usage.networkCalls).coerceAtLeast(0)
        if (remaining == 0) return 0
        val base = queryReserveForRole(role).coerceAtLeast(1)
        val contradictionStillPending = contradictionPending(snapshot)
        if (contradictionStillPending && role !in setOf(EvidenceRoleV3.CONTRADICTION, EvidenceRoleV3.FALSIFIER)) {
            val protectedRemaining = (remaining - contradictionQueryReserve).coerceAtLeast(0)
            if (role == EvidenceRoleV3.PROVENANCE) return 0
            return minOf(base, protectedRemaining.coerceAtLeast(1))
        }
        return minOf(base, remaining)
    }
}

data class BudgetUsageV3(
    val networkCalls: Int = 0,
    val emptyQueries: Int = 0,
    val sourceFamilyCounts: Map<String, Int> = emptyMap()
) {
    operator fun plus(other: BudgetUsageV3): BudgetUsageV3 {
        val families = sourceFamilyCounts.toMutableMap()
        other.sourceFamilyCounts.forEach { (family, count) -> families[family] = (families[family] ?: 0) + count }
        return BudgetUsageV3(
            networkCalls = networkCalls + other.networkCalls,
            emptyQueries = emptyQueries + other.emptyQueries,
            sourceFamilyCounts = families.toMap()
        )
    }

    fun toJson(): JSONObject = JSONObject()
        .put("networkCalls", networkCalls)
        .put("emptyQueries", emptyQueries)
        .put("sourceFamilyCounts", JSONObject(sourceFamilyCounts))
}

enum class ResearchRunStatusV3 {
    READY,
    RUNNING,
    CHECKPOINT_READY,
    CHECKPOINT_FINAL_QUALITY_BLOCKED,
    REPORT_READY,
    STOPPED,
    FAILED_SAFE
}

data class ResearchStateV3(
    val input: ResearchInputV3,
    val status: ResearchRunStatusV3,
    val ledgerSnapshot: EvidenceLedgerSnapshotV3,
    val budgetUsage: BudgetUsageV3 = BudgetUsageV3(),
    val openGates: List<String> = emptyList()
) {
    val executedObjectiveCount: Int get() = ledgerSnapshot.objectiveOutcomes.size

    fun reduce(outcome: ResearchObjectiveOutcomeV3, newSnapshot: EvidenceLedgerSnapshotV3): ResearchStateV3 = copy(
        status = ResearchRunStatusV3.RUNNING,
        ledgerSnapshot = newSnapshot,
        budgetUsage = budgetUsage + outcome.budgetDelta
    )

    fun withClosure(snapshot: ResearchClosureSnapshotV3): ResearchStateV3 = copy(
        status = if (snapshot.canCloseReport) ResearchRunStatusV3.REPORT_READY else ResearchRunStatusV3.CHECKPOINT_READY,
        openGates = snapshot.openGates
    )

    fun toJson(): JSONObject = JSONObject()
        .put("topic", input.topic)
        .put("explicitMatrixRowCount", input.explicitMatrixRows.size)
        .put("explicitMatrixProvenancePresent", input.explicitMatrixProvenance.isNotBlank())
        .put("explicitDeclaredCaseLabelCount", input.explicitCaseLabels.size)
        .put("explicitDeclaredControlLabelCount", input.explicitControlLabels.size)
        .put("status", status.name)
        .put("budgetUsage", budgetUsage.toJson())
        .put("openGates", JSONArray(openGates))
        .put("ledger", ledgerSnapshot.toJson())

    companion object {
        fun initial(input: ResearchInputV3, snapshot: EvidenceLedgerSnapshotV3 = EvidenceLedgerV3().snapshot()): ResearchStateV3 =
            ResearchStateV3(input = input, status = ResearchRunStatusV3.READY, ledgerSnapshot = snapshot)
    }
}
