package com.immunesignal.app

import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.34 — item 2: user-supplied matrix ingestion.
 *
 * Shortest path from the (already-wired) review-only scaffold to the first
 * CERTIFIED_USER_SUPPLIED_WITH_PROVENANCE run, WITHOUT building full GEO ETL.
 *
 * The user pastes / uploads a small processed-expression matrix as CSV or TSV and
 * declares which group values are "case" and which are "control". This object turns
 * that text into sample-level [ExpressionSampleRowV30329] plus a provenance receipt.
 * When the receipt is present and the matrix groups cleanly (>= 2 case and >= 2 control
 * rows with >= 1 shared marker), the downstream matrix-fuel gate marks the run
 * CERTIFIED_USER_SUPPLIED_WITH_PROVENANCE and the DGE result becomes a real
 * (single-dataset, research-only) mechanism signal rather than a hidden pipeline value.
 *
 * Expected text format (header required; comma or tab delimited):
 *   sample_id,group,MARKER1,MARKER2,...
 *   s1,active_ra,5.0,5.2,...
 *   c1,healthy_control,3.2,3.1,...
 *
 * Boundary: research-only. A certified single user-supplied dataset is a research
 * signal that still requires independent replication and exact-axis falsifier review.
 * It is never proof, diagnosis, treatment, dosing, or patient action.
 */
data class UserSuppliedMatrixV30333(
    val rows: List<ExpressionSampleRowV30329>,
    val caseLabels: List<String>,
    val controlLabels: List<String>,
    val markers: List<String>,
    val caseRowCount: Int,
    val controlRowCount: Int,
    val provenanceReceipt: String,
    val certifiable: Boolean,
    val warnings: List<String>,
    val boundary: String = UserSuppliedMatrixIngestorV30333.BOUNDARY
) {
    /** Builds a ready-to-run input. Provenance is only attached when [certifiable]. */
    fun toResearchInput(topic: String, budget: ResearchBudgetV3 = ResearchBudgetV3()): ResearchInputV3 = ResearchInputV3(
        topic = topic,
        budget = budget,
        explicitMatrixRows = rows,
        explicitMatrixProvenance = if (certifiable) provenanceReceipt else "",
        explicitCaseLabels = caseLabels,
        explicitControlLabels = controlLabels
    )

    fun toJson(): JSONObject = JSONObject()
        .put("schema", "user_supplied_matrix_v30334")
        .put("requiredToken", UserSuppliedMatrixIngestorV30333.REQUIRED_TOKEN)
        .put("rowCount", rows.size)
        .put("caseRowCount", caseRowCount)
        .put("controlRowCount", controlRowCount)
        .put("markerCount", markers.size)
        .put("caseLabels", JSONArray(caseLabels))
        .put("controlLabels", JSONArray(controlLabels))
        .put("certifiable", certifiable)
        .put("provenanceReceipt", provenanceReceipt)
        .put("warnings", JSONArray(warnings))
        .put("boundary", boundary)
}

object UserSuppliedMatrixIngestorV30333 {
    const val REQUIRED_TOKEN: String = "V30334_USER_SUPPLIED_MATRIX_INGESTOR_CSV_TO_CERTIFIED_DGE_FUEL"
    const val BOUNDARY: String =
        "User-supplied matrix ingestion is research-only. A certified single dataset is a research " +
        "signal requiring independent replication and exact-axis falsifier review; it is never proof, " +
        "diagnosis, treatment, dosing, or patient action."

    /**
     * @param sourceLabel human-readable provenance (e.g. "GEO GSE89408 processed TPM, downloaded 2026-06-04").
     *        A blank label keeps the matrix review-only (no certification), even if it parses cleanly.
     */
    fun ingest(
        text: String,
        declaredCaseGroups: List<String>,
        declaredControlGroups: List<String>,
        sourceLabel: String = ""
    ): UserSuppliedMatrixV30333 {
        val warnings = mutableListOf<String>()
        val lines = text.split('\n', '\r')
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("#") }
        if (lines.size < 2) {
            warnings += "need_header_plus_at_least_one_data_row"
            return empty(warnings)
        }
        val delimiter = if (lines.first().contains('\t')) '\t' else ','
        val header = lines.first().split(delimiter).map { it.trim() }
        if (header.size < 3) {
            warnings += "header_needs_sample_id_group_and_at_least_one_marker_column"
            return empty(warnings)
        }
        val markers = header.drop(2).map { it.trim().uppercase() }.filter { it.isNotBlank() }.distinct()
        if (markers.isEmpty()) {
            warnings += "no_marker_columns_detected"
            return empty(warnings)
        }

        val caseSet = declaredCaseGroups.map { normalize(it) }.filter { it.isNotBlank() }.toSet()
        val controlSet = declaredControlGroups.map { normalize(it) }.filter { it.isNotBlank() }.toSet()
        if (caseSet.isEmpty() || controlSet.isEmpty()) {
            warnings += "declare_case_and_control_group_values_for_certification"
        }
        if (caseSet.intersect(controlSet).isNotEmpty()) {
            warnings += "case_and_control_group_labels_overlap"
        }

        val rows = mutableListOf<ExpressionSampleRowV30329>()
        var skipped = 0
        for (line in lines.drop(1)) {
            val cols = line.split(delimiter).map { it.trim() }
            if (cols.size < 3) { skipped++; continue }
            val sampleId = cols[0]
            val group = normalize(cols[1])
            if (sampleId.isBlank() || group.isBlank()) { skipped++; continue }
            val values = LinkedHashMap<String, Double>()
            markers.forEachIndexed { i, marker ->
                val raw = cols.getOrNull(i + 2)?.replace(",", "")?.trim()
                val v = raw?.toDoubleOrNull()
                if (v != null && v.isFinite()) values[marker] = v
            }
            if (values.isEmpty()) { skipped++; continue }
            rows += ExpressionSampleRowV30329(sampleId, group, values)
        }
        if (skipped > 0) warnings += "skipped_${skipped}_unparseable_or_empty_rows"
        if (rows.isEmpty()) {
            warnings += "no_parseable_sample_rows"
            return empty(warnings)
        }

        val caseRowCount = rows.count { it.group in caseSet }
        val controlRowCount = rows.count { it.group in controlSet }
        if (caseRowCount < 2) warnings += "need_at_least_2_case_rows_for_dge"
        if (controlRowCount < 2) warnings += "need_at_least_2_control_rows_for_dge"

        val groupsReady = caseSet.isNotEmpty() && controlSet.isNotEmpty() && caseRowCount >= 2 && controlRowCount >= 2
        val provenancePresent = sourceLabel.isNotBlank()
        if (!provenancePresent) warnings += "no_source_label_matrix_stays_review_only_until_provenance_is_supplied"

        val certifiable = groupsReady && provenancePresent
        val receipt = if (certifiable) buildReceipt(rows, markers, caseRowCount, controlRowCount, sourceLabel) else ""

        return UserSuppliedMatrixV30333(
            rows = rows,
            caseLabels = caseSet.toList(),
            controlLabels = controlSet.toList(),
            markers = markers,
            caseRowCount = caseRowCount,
            controlRowCount = controlRowCount,
            provenanceReceipt = receipt,
            certifiable = certifiable,
            warnings = warnings.distinct()
        )
    }

    private fun buildReceipt(
        rows: List<ExpressionSampleRowV30329>,
        markers: List<String>,
        caseRowCount: Int,
        controlRowCount: Int,
        sourceLabel: String
    ): String {
        val canonical = buildString {
            append(sourceLabel.trim()).append('\n')
            rows.sortedBy { it.sampleId }.forEach { r ->
                append(r.sampleId).append('|').append(r.group).append('|')
                append(r.values.toSortedMap().entries.joinToString(",") { "${it.key}=${it.value}" })
                append('\n')
            }
        }
        val hash = sha256(canonical).take(16)
        return "user_csv|sha256=$hash|rows=${rows.size}|case=$caseRowCount|control=$controlRowCount|markers=${markers.size}|src=${sourceLabel.trim().take(120)}"
    }

    private fun sha256(input: String): String =
        MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun normalize(label: String): String =
        label.trim().lowercase().replace(Regex("[\\s\\-/]+"), "_").replace(Regex("[^a-z0-9_]"), "")

    private fun empty(warnings: List<String>): UserSuppliedMatrixV30333 = UserSuppliedMatrixV30333(
        rows = emptyList(),
        caseLabels = emptyList(),
        controlLabels = emptyList(),
        markers = emptyList(),
        caseRowCount = 0,
        controlRowCount = 0,
        provenanceReceipt = "",
        certifiable = false,
        warnings = warnings.distinct()
    )
}
