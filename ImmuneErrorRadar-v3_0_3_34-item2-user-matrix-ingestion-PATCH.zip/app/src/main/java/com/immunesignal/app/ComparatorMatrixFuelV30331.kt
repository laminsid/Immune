package com.immunesignal.app

/**
 * v3.0.3.31 — resolves comparator axes to real group labels and feeds the signal
 * executor with explicit, sample-level rows from user input, capsules, or local lite rows.
 */
object ComparatorGroupResolverV30331 {
    const val REQUIRED_TOKEN: String = "V30331_COMPARATOR_GROUP_RESOLVER_REAL_LABELS_NOT_ACCESSION_GROUPS"

    fun resolve(
        topic: String,
        variable: ComparatorVariableV30329?,
        metadataProbe: ResearchMetadataProbeIngestionReportV3,
        datasetModuleScore: ResearchDatasetModuleScoreCardV3
    ): ComparatorGroupResolutionV30330 {
        val accession = variable?.accession?.takeIf { it != "none" }
            ?: datasetModuleScore.dataset.takeIf { it != "none" }
            ?: metadataProbe.targets.firstOrNull()?.accession
            ?: "none"
        val legacy = ComparatorGroupResolverV30330.resolve(variable, metadataProbe, datasetModuleScore)
        val (liteCase, liteControl) = ProcessedExpressionRowsLiteV30331.groupLabelsFor(accession, topic)
        val caseLabels = (liteCase + legacy.caseLabels + variable?.caseGroupLabels.orEmpty())
            .map { ComparatorGroupResolverV30330.normalizeLabel(it) }
            .filter { it.isNotBlank() && it != accession.lowercase() }
            .distinct()
        val controlLabels = (liteControl + legacy.controlLabels + variable?.controlGroupLabels.orEmpty())
            .map { ComparatorGroupResolverV30330.normalizeLabel(it) }
            .filter { it.isNotBlank() && it != accession.lowercase() }
            .distinct()
        return if (caseLabels.isNotEmpty() && controlLabels.isNotEmpty()) {
            ComparatorGroupResolutionV30330(
                state = "COMPARATOR_GROUP_VALUES_RESOLVED_V30331_REAL_LABELS",
                accession = accession,
                caseLabels = caseLabels,
                controlLabels = controlLabels,
                unresolvedAxis = variable?.caseControlAxis ?: legacy.unresolvedAxis,
                source = "v30331_lite_rows_metadata_capsule_and_comparator_extractor"
            )
        } else {
            legacy
        }
    }
}

object MatrixFuelProviderV30331 {
    const val REQUIRED_TOKEN: String = "V30331_MATRIX_FUEL_PROVIDER_LITE_ROWS_AND_REAL_GROUPS"

    fun collect(
        state: ResearchStateV3,
        metadataProbe: ResearchMetadataProbeIngestionReportV3,
        datasetModuleScore: ResearchDatasetModuleScoreCardV3,
        comparatorVariables: ComparatorVariableExtractionReportV30329
    ): Pair<List<ExpressionSampleRowV30329>, MatrixFuelSnapshotV30330> {
        val best = comparatorVariables.variables.maxByOrNull { it.confidence }
        val baseGroupResolution = ComparatorGroupResolverV30331.resolve(state.input.topic, best, metadataProbe, datasetModuleScore)
        // v3.0.3.34 — item 2: user-declared case/control labels take authority over inferred
        // labels so a pasted/uploaded sample-level matrix can group and run real DGE.
        val userCaseLabels = state.input.explicitCaseLabels.map { ComparatorGroupResolverV30330.normalizeLabel(it) }.filter { it.isNotBlank() }
        val userControlLabels = state.input.explicitControlLabels.map { ComparatorGroupResolverV30330.normalizeLabel(it) }.filter { it.isNotBlank() }
        val groupResolution = if (userCaseLabels.isNotEmpty() && userControlLabels.isNotEmpty()) {
            baseGroupResolution.copy(
                state = "COMPARATOR_GROUP_VALUES_RESOLVED_V30334_USER_DECLARED",
                caseLabels = (userCaseLabels + baseGroupResolution.caseLabels).distinct(),
                controlLabels = (userControlLabels + baseGroupResolution.controlLabels).distinct(),
                source = baseGroupResolution.source + "+v30334_user_declared_case_control_labels"
            )
        } else baseGroupResolution
        val dataset = groupResolution.accession.takeIf { it != "none" } ?: datasetModuleScore.dataset
        val (etlRows, etlWarnings) = RealGeoEtlConnectorV30333.collect(state, dataset)
        val explicitRows = state.input.explicitMatrixRows.filter { it.sampleId.isNotBlank() && it.values.isNotEmpty() }
        // Real provenance flag (replaces the fragile source.contains("provenance") substring test,
        // which previously also matched the literal "no_provenance" and over-certified user rows).
        val hasUserProvenance = explicitRows.isNotEmpty() && state.input.explicitMatrixProvenance.isNotBlank()
        val capsuleRows = GTIMLocalProcessedCapsuleStoreV21316.getCapsuleByAccession(dataset)?.expressionRows.orEmpty()
            .map { it.toExpressionSampleRow() }
        val liteRows = if (etlRows.isEmpty() && explicitRows.isEmpty() && capsuleRows.isEmpty()) ProcessedExpressionRowsLiteV30331.rowsFor(dataset, state.input.topic) else emptyList()
        val rows = (etlRows + explicitRows + capsuleRows + liteRows).distinctBy { it.sampleId + "|" + it.group }
        val normalizedRows = rows.map { row -> row.copy(group = ComparatorGroupResolverV30330.normalizeLabel(row.group)) }
        val availableGroups = normalizedRows.map { it.group }.distinct()
        val expandedCaseLabels = ComparatorSynonymMapV30332.expandCaseLabels(state.input.topic, dataset, groupResolution.caseLabels, availableGroups)
        val expandedControlLabels = ComparatorSynonymMapV30332.expandControlLabels(state.input.topic, dataset, groupResolution.controlLabels, availableGroups)
        val effectiveGroupResolution = groupResolution.copy(
            caseLabels = expandedCaseLabels,
            controlLabels = expandedControlLabels,
            state = if (expandedCaseLabels.isNotEmpty() && expandedControlLabels.isNotEmpty()) "COMPARATOR_GROUP_VALUES_RESOLVED_V30332_SYNONYM_EXPANDED" else groupResolution.state,
            source = groupResolution.source + "+v30332_comparator_synonym_map"
        )
        val caseCount = normalizedRows.count { row -> effectiveGroupResolution.caseLabels.any { row.group == it || row.group.contains(it) || it.contains(row.group) } }
        val controlCount = normalizedRows.count { row -> effectiveGroupResolution.controlLabels.any { row.group == it || row.group.contains(it) || it.contains(row.group) } }
        val warnings = mutableListOf<String>()
        warnings += etlWarnings
        if (etlRows.isEmpty() && explicitRows.isEmpty() && capsuleRows.isEmpty() && liteRows.isEmpty()) warnings += "no_explicit_sample_level_expression_rows_available"
        if (liteRows.isNotEmpty()) warnings += "v30331_lite_processed_rows_review_fuel_not_certified_full_geo_etl"
        if (liteRows.isNotEmpty()) warnings += "v30333_lite_scaffold_rows_pipeline_validation_only_not_biology"
        if (explicitRows.isNotEmpty() && etlRows.isEmpty() && !hasUserProvenance) warnings += "v30333_explicit_rows_review_only_until_provenance_hash_is_modelled"
        if (hasUserProvenance && etlRows.isEmpty()) warnings += "v30334_user_supplied_matrix_certified_single_dataset_replicate_before_generalization"
        if (capsuleRows.isNotEmpty() && etlRows.isEmpty()) warnings += "v30333_capsule_rows_review_only_not_full_geo_etl_certified"
        if (!effectiveGroupResolution.ready) warnings += "comparator_axis_not_mapped_to_real_group_values"
        if (effectiveGroupResolution.caseLabels.any { it.equals(dataset, true) } || effectiveGroupResolution.controlLabels.any { it.equals(dataset, true) }) warnings += "accession_must_not_be_used_as_group_label"
        if (caseCount < 2 || controlCount < 2) warnings += "insufficient_case_or_control_rows_for_dge"
        val stateName = when {
            normalizedRows.isNotEmpty() && caseCount >= 2 && controlCount >= 2 && groupResolution.ready -> "MATRIX_FUEL_READY_FOR_RAW_DGE_V30331"
            normalizedRows.isNotEmpty() -> "MATRIX_ROWS_PRESENT_BUT_GROUPING_BLOCKED"
            else -> "MATRIX_FUEL_MISSING_PREVIEW_ONLY"
        }
        val source = when {
            etlRows.isNotEmpty() -> "geo_etl_certified_matrix_rows_v30333"
            hasUserProvenance -> "user_supplied_matrix_rows_with_provenance_receipt_certified_v30334"
            explicitRows.isNotEmpty() -> "user_supplied_matrix_rows_review_only_no_receipt_v30334"
            capsuleRows.isNotEmpty() -> "processed_capsule_explicit_matrix_rows_review_only"
            liteRows.isNotEmpty() -> "local_lite_processed_expression_rows_v30331_review_fuel"
            else -> "none"
        }
        val certificationLevel = when {
            etlRows.isNotEmpty() -> "CERTIFIED_GEO_ETL"
            hasUserProvenance -> "CERTIFIED_USER_SUPPLIED_WITH_PROVENANCE"
            liteRows.isNotEmpty() -> "LITE_SCAFFOLD_REVIEW_ONLY"
            capsuleRows.isNotEmpty() -> "LOCAL_CAPSULE_REVIEW_ONLY"
            explicitRows.isNotEmpty() -> "USER_SUPPLIED_ROWS_NO_PROVENANCE_REVIEW_ONLY"
            normalizedRows.isNotEmpty() -> "UNKNOWN_ROWS_REVIEW_ONLY"
            else -> "NO_MATRIX_ROWS"
        }
        val analysisMode = when {
            normalizedRows.isNotEmpty() && caseCount >= 2 && controlCount >= 2 && certificationLevel in setOf("CERTIFIED_GEO_ETL", "CERTIFIED_USER_SUPPLIED_WITH_PROVENANCE") -> "CERTIFIED_DGE"
            normalizedRows.isNotEmpty() && caseCount >= 2 && controlCount >= 2 -> "LITE_REVIEW_DGE"
            normalizedRows.isNotEmpty() -> "ROWS_PRESENT_GROUPING_OR_MARKER_BLOCKED"
            else -> "NO_MATRIX_PREVIEW"
        }
        val scientificInterpretability = when (analysisMode) {
            "CERTIFIED_DGE" -> "MODERATE_CERTIFIED_SINGLE_DATASET"
            "LITE_REVIEW_DGE" -> if (liteRows.isNotEmpty()) "NONE_PIPELINE_ONLY" else "LOW_REVIEW_ONLY"
            else -> "NONE_PIPELINE_ONLY"
        }
        val fuelOrigin = when {
            etlRows.isNotEmpty() -> "CERTIFIED_GEO_ETL"
            hasUserProvenance -> "CERTIFIED_USER_SUPPLIED_WITH_PROVENANCE"
            liteRows.isNotEmpty() -> "LITE_SCAFFOLD"
            capsuleRows.isNotEmpty() -> "LOCAL_CAPSULE_REVIEW_ONLY"
            explicitRows.isNotEmpty() -> "USER_SUPPLIED_ROWS_NO_PROVENANCE_REVIEW_ONLY"
            else -> "NO_MATRIX_ROWS"
        }
        return normalizedRows to MatrixFuelSnapshotV30330(
            state = stateName,
            accession = dataset,
            rowCount = normalizedRows.size,
            caseRowCount = caseCount,
            controlRowCount = controlCount,
            source = source,
            groupResolution = effectiveGroupResolution,
            warnings = warnings.distinct(),
            certificationLevel = certificationLevel,
            analysisMode = analysisMode,
            scientificInterpretability = scientificInterpretability,
            fuelOrigin = fuelOrigin
        )
    }
}
