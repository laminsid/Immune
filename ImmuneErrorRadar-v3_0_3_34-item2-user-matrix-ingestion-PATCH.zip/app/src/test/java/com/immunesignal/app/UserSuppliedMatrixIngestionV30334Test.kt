package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UserSuppliedMatrixIngestionV30334Test {

    private val raCsv = """
        sample_id,group,TNF,IL6,IL17A,CD68
        ra1,active_ra,5.0,5.2,4.8,4.7
        ra2,active_ra,5.1,5.0,4.7,4.8
        ra3,active_ra,4.9,5.1,4.6,4.6
        c1,healthy_control,3.2,3.1,2.7,3.0
        c2,healthy_control,3.1,3.2,2.8,3.1
        c3,healthy_control,3.0,3.0,2.6,2.9
    """.trimIndent()

    @Test
    fun parsesRowsGroupsAndMarkers() {
        val m = UserSuppliedMatrixIngestorV30333.ingest(
            text = raCsv,
            declaredCaseGroups = listOf("active_ra"),
            declaredControlGroups = listOf("healthy_control"),
            sourceLabel = "user RA synovium processed matrix, 2026-06-04"
        )
        assertEquals(6, m.rows.size)
        assertEquals(3, m.caseRowCount)
        assertEquals(3, m.controlRowCount)
        assertTrue(m.markers.contains("TNF"))
    }

    @Test
    fun withSourceLabelMatrixIsCertifiableAndProducesProvenanceReceipt() {
        val m = UserSuppliedMatrixIngestorV30333.ingest(
            raCsv, listOf("active_ra"), listOf("healthy_control"),
            sourceLabel = "user RA synovium processed matrix, 2026-06-04"
        )
        assertTrue(m.certifiable)
        assertTrue(m.provenanceReceipt.startsWith("user_csv|sha256="))
        val input = m.toResearchInput("rheumatoid arthritis synovial inflammation")
        assertTrue(input.explicitMatrixProvenance.isNotBlank())
        assertEquals(6, input.explicitMatrixRows.size)
        assertTrue(input.explicitCaseLabels.contains("active_ra"))
    }

    @Test
    fun withoutSourceLabelStaysReviewOnlyNoProvenance() {
        val m = UserSuppliedMatrixIngestorV30333.ingest(
            raCsv, listOf("active_ra"), listOf("healthy_control"), sourceLabel = ""
        )
        assertFalse(m.certifiable)
        assertEquals("", m.provenanceReceipt)
        assertEquals("", m.toResearchInput("ra").explicitMatrixProvenance)
    }

    @Test
    fun certifiedUserMatrixDrivesMatrixFuelToCertifiedDiscovery() {
        val m = UserSuppliedMatrixIngestorV30333.ingest(
            raCsv, listOf("active_ra"), listOf("healthy_control"),
            sourceLabel = "user RA synovium processed matrix, 2026-06-04"
        )
        val input = m.toResearchInput("rheumatoid arthritis synovial inflammation tnf il6 il17")
        val state = ResearchStateV3.initial(input)
        val metadata = ResearchMetadataProbeIngestionV3.evaluate(state)
        val datasetScore = ResearchDatasetModuleScoreV3.evaluate(state, metadata)
        val comparator = ComparatorVariableExtractorV30329.evaluate(state, metadata)
        val (rows, fuel) = MatrixFuelProviderV30331.collect(state, metadata, datasetScore, comparator)
        assertTrue(rows.isNotEmpty())
        assertTrue(fuel.caseRowCount >= 2)
        assertTrue(fuel.controlRowCount >= 2)
        assertEquals("CERTIFIED_USER_SUPPLIED_WITH_PROVENANCE", fuel.certificationLevel)
        assertTrue(fuel.certifiedForDiscovery)
        // The reality guard must agree (no scaffold/no-provenance false-match).
        val reality = SyntheticScaffoldDataGuardV30333.assess(fuel)
        assertEquals("CERTIFIED_DGE", reality.analysisMode)
        assertTrue(reality.biologicallyInterpretable)
    }

    @Test
    fun reviewOnlyUserRowsDoNotFalseCertify() {
        val m = UserSuppliedMatrixIngestorV30333.ingest(
            raCsv, listOf("active_ra"), listOf("healthy_control"), sourceLabel = ""
        )
        val input = m.toResearchInput("rheumatoid arthritis synovial inflammation tnf il6 il17")
        val state = ResearchStateV3.initial(input)
        val metadata = ResearchMetadataProbeIngestionV3.evaluate(state)
        val datasetScore = ResearchDatasetModuleScoreV3.evaluate(state, metadata)
        val comparator = ComparatorVariableExtractorV30329.evaluate(state, metadata)
        val (_, fuel) = MatrixFuelProviderV30331.collect(state, metadata, datasetScore, comparator)
        assertFalse(fuel.certifiedForDiscovery)
        assertFalse(fuel.certificationLevel == "CERTIFIED_USER_SUPPLIED_WITH_PROVENANCE")
    }
}
