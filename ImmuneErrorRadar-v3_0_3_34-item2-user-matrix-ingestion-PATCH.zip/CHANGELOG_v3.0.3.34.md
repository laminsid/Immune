# ImmuneErrorRadar v3.0.3.34 — User-Supplied Matrix Ingestion (Item 2)

## Purpose
Shortest path to the first `certified=true` DGE run **without** building full GEO ETL:
let the user paste/upload a small processed-expression matrix (CSV/TSV) and declare
case/control groups. With a provenance label, the run reaches
`CERTIFIED_USER_SUPPLIED_WITH_PROVENANCE` and the effect/CI/p become a real
(single-dataset, research-only) mechanism signal instead of a hidden pipeline value.

## Added
- `UserSuppliedMatrixIngestorV30333` — parses CSV/TSV (`sample_id,group,MARKER...`) into
  `ExpressionSampleRowV30329`, validates (>=2 case + >=2 control rows, >=1 marker),
  computes a SHA-256 provenance receipt, and builds a ready `ResearchInputV3` via
  `toResearchInput(topic)`.
- `UserSuppliedMatrixIngestionV30334Test` — proves certified path, review-only-without-
  provenance path, and that the matrix-fuel gate + reality guard agree.

## Changed
- `ResearchInputV3` — new fields: `explicitMatrixProvenance`, `explicitCaseLabels`,
  `explicitControlLabels` (all default-empty; existing callers unaffected).
- `MatrixFuelProviderV30331` — (1) user-declared case/control labels now take authority in
  group resolution so an arbitrary uploaded matrix groups correctly; (2) certification is
  driven by a real `hasUserProvenance` flag.
- Bug fix: removed the fragile `source.contains("provenance")` test that also matched the
  literal `"no_provenance"` and would have **over-certified** user rows lacking a receipt.
  No-receipt source string no longer contains the word "provenance"; the reality guard
  (`SyntheticScaffoldDataGuardV30333`) now agrees with the fuel gate.

## Not changed
- Clinical/treatment/diagnosis claims remain blocked. Lite scaffold rows remain review-only.
- A certified single user dataset still requires replication + exact-axis falsifier before
  any discovery claim; score cap and falsifier gates are unchanged.

## How to use (engine entry point)
```kotlin
val matrix = UserSuppliedMatrixIngestorV30333.ingest(
    text = csvText,
    declaredCaseGroups = listOf("active_ra"),
    declaredControlGroups = listOf("healthy_control"),
    sourceLabel = "GEO GSE89408 processed matrix, downloaded 2026-06-04"
)
val input = matrix.toResearchInput("rheumatoid arthritis synovial inflammation")
// run the engine with `input` as usual
```
UI wiring (a file-picker / paste box that feeds `ingest(...)`) is the remaining surface step.
