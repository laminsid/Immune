#!/usr/bin/env python3
from pathlib import Path

ROOT = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/AccessionAcquisitionHardening.kt': [
        'FOUND_ACCESSION', 'FOUND_WEAK_ACCESSION_NEEDS_METADATA', 'NO_ACCESSION_ARCHIVE_ROUTE',
        'compactReportRecommended', 'accession_acquisition_not_biological_proof', 'routeFamiliesForNoAccession'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetAccessionResolver.kt': [
        'v1.10.15: expanded accession grammar', 'PRJEB', 'SRX', 'SAMN', 'E-GEOD', 'FOUND_WEAK_ACCESSION_NEEDS_METADATA'
    ],
    'app/src/main/java/com/immunesignal/app/DirectDatasetSourceRouter.kt': [
        'v1.10.15: accession acquisition lock', 'AccessionAcquisitionHardening.routeFamiliesForNoAccession'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': [
        'accessionAcquisitionReport', 'AccessionAcquisitionReport.empty()'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'accessionAcquisitionReport', 'accessionAcquisitionToJson', 'explicitAccessions', 'compactReportRecommended'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'AccessionAcquisitionHardening.evaluate', 'DATASET_FORAGING_FOUND_ACCESSION', 'DATASET_FORAGING_WEAK_ACCESSION_NEEDS_METADATA'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchReportV3Builder.kt': [
        'accessionAcquisition', 'Dataset accession found', 'No accession — archive or reframe route'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'accession acquisition & steering-aware forge v1.10.16', 'Accession acquisition v1.10.16'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Dataset handle:', 'Accession acquisition:', 'accession_acquisition_not_biological_proof'
    ],
    'app/src/test/java/com/immunesignal/app/AccessionAcquisitionHardeningV11015Test.kt': [
        'extractsExpandedAccessionFamiliesWithoutBiologicalUpgrade', 'reportsFoundAccessionBeforeHypothesisUpgrade', 'unresolvedLeadStaysWeakAndCompact', 'repeatedNoAccessionCanArchiveRoute'
    ],
    'app/build.gradle.kts': ['1.10.16-alpha-extended-thinking-budget'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.16-alpha-extended-thinking-budget', 'AccessionAcquisitionHardening'],
}
missing = []
for rel, needles in checks.items():
    text = (ROOT / rel).read_text(encoding='utf-8')
    for needle in needles:
        if needle not in text:
            missing.append(f'{rel}: {needle}')
if missing:
    raise SystemExit('v1.10.16 accession acquisition audit failed:\n' + '\n'.join(missing))
print('v1.10.16 accession acquisition hardening audit: PASS')
