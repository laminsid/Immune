package com.immunesignal.app

/**
 * Runtime module registry v1.10.2.
 *
 * This replaces the old raw string-only module inventory with lightweight typed
 * entries. It is intentionally minimal: readiness is explicit and auditable,
 * while module history stays in Git/docs instead of in class names.
 */
interface RuntimeModule {
    val id: String
    val category: String
    fun isReady(): Boolean
}

data class StaticRuntimeModule(
    override val id: String,
    override val category: String,
    private val ready: Boolean = true
) : RuntimeModule {
    override fun isReady(): Boolean = ready
}

object RuntimeModuleRegistry {
    private val modules: List<RuntimeModule> = listOf(
        StaticRuntimeModule("SmartReportIntegrityLock", "integrity"),
        StaticRuntimeModule("ScopeDisciplineLock", "integrity"),
        StaticRuntimeModule("AutonomousStagnationEngine", "planning"),
        StaticRuntimeModule("EvidenceLearningOS", "learning"),
        StaticRuntimeModule("DatasetAccessionResolver", "dataset"),
        StaticRuntimeModule("AccessionAcquisitionHardening", "dataset"),
        StaticRuntimeModule("LaneCooldown", "planning"),
        StaticRuntimeModule("ExecutionWiringGuard", "integrity"),
        StaticRuntimeModule("RuntimeDatasetHuntFailover", "planning"),
        StaticRuntimeModule("DirectDatasetSourceRouter", "dataset"),
        StaticRuntimeModule("DatasetFirstForager", "dataset"),
        StaticRuntimeModule("PersistentFailureMemory", "learning"),
        StaticRuntimeModule("HypothesisDecomposer", "reasoning"),
        StaticRuntimeModule("MultiPassEvidenceLoop", "evidence"),
        StaticRuntimeModule("DatasetParser", "dataset"),
        StaticRuntimeModule("OutcomeLabelDetector", "evidence"),
        StaticRuntimeModule("ControlGroupDetector", "evidence"),
        StaticRuntimeModule("ContrastiveEvidenceGate", "evidence"),
        StaticRuntimeModule("CumulativeEvidenceScorer", "scoring"),
        StaticRuntimeModule("EvidenceHypergraphLite", "reasoning"),
        StaticRuntimeModule("ResearchRouteAudit", "integrity"),
        StaticRuntimeModule("ActionableNextEvidence", "planning"),
        StaticRuntimeModule("RouteFitGate", "evidence"),
        StaticRuntimeModule("ScoreSeparation", "scoring"),
        StaticRuntimeModule("FailurePatternLedger", "learning"),
        StaticRuntimeModule("QueryFeedbackPlanner", "planning"),
        StaticRuntimeModule("DatasetTriageEngine", "dataset"),
        StaticRuntimeModule("MLDatasetTriageEngine", "triage"),
        StaticRuntimeModule("FailurePredictionModel", "triage"),
        StaticRuntimeModule("RouteEmbeddingScorer", "triage"),
        StaticRuntimeModule("EvidenceFreshnessScorer", "scoring"),
        StaticRuntimeModule("FoundationKnowledgeLayer", "knowledge"),
        StaticRuntimeModule("AxisRankingEngine", "scoring"),
        StaticRuntimeModule("FoundationConflictResolver", "knowledge"),
        StaticRuntimeModule("FoundationKnowledgeAccuracyLedger", "learning"),
        StaticRuntimeModule("FoundationPatchSuggestionLedger", "learning"),
        StaticRuntimeModule("LearningSessionManager", "learning"),
        StaticRuntimeModule("PhaseExecutor", "execution"),
        StaticRuntimeModule("ProgressTracker", "execution"),
        StaticRuntimeModule("QuestionEvolver", "planning"),
        StaticRuntimeModule("SessionMetrics", "learning"),
        StaticRuntimeModule("RuntimeFeatureFlags", "runtime"),
        StaticRuntimeModule("LearningSessionIntegrityGuard", "integrity"),
        StaticRuntimeModule("SessionHistoryPersistence", "storage"),
        StaticRuntimeModule("LearningSessionOutcomeBridge", "learning"),
        StaticRuntimeModule("SessionHandoff", "execution"),
        StaticRuntimeModule("CandidateActionResolver", "planning"),
        StaticRuntimeModule("MinimumMetadataParser", "dataset"),
        StaticRuntimeModule("AutoContinuationTrigger", "planning"),
        StaticRuntimeModule("ReportConsistencyGuard", "integrity"),
        StaticRuntimeModule("SpecializedReasoningEngine", "reasoning"),
        StaticRuntimeModule("HypothesisFalsificationPressure", "reasoning"),
        StaticRuntimeModule("NextDecisiveTestSelector", "planning"),
        StaticRuntimeModule("GeneralModelFailureGuard", "integrity"),
        StaticRuntimeModule("CumulativeKnowledgeMapEngine", "reasoning"),
        StaticRuntimeModule("EpistemicBeliefEngine", "reasoning"),
        StaticRuntimeModule("CognitivePathIntegrationEngine", "reasoning"),
        StaticRuntimeModule("CognitiveNextCycleBridge", "planning"),
        StaticRuntimeModule("CognitiveLoopSingleUseGuard", "integrity"),
        StaticRuntimeModule("QueryInflationGuard", "integrity"),
        StaticRuntimeModule("CognitiveLoopCalibrationEngine", "learning"),
        StaticRuntimeModule("DirectiveLifecycleEngine", "learning"),
        StaticRuntimeModule("EvidenceGainQueryRanker", "planning"),
        StaticRuntimeModule("BeliefFalsificationContractEngine", "reasoning"),
        StaticRuntimeModule("MemoryConsolidationEngine", "learning"),
        StaticRuntimeModule("CausalReadinessGate", "integrity"),
        StaticRuntimeModule("ReflectionLessonEngine", "learning"),
        StaticRuntimeModule("MiniPeerReviewGate", "integrity"),
        StaticRuntimeModule("ReportSimplificationLayer", "ui"),
        StaticRuntimeModule("WeightedDiscoveryIntelligence", "reasoning"),
        StaticRuntimeModule("ScientificKnowledgeIndexEngine", "knowledge"),
        StaticRuntimeModule("MechanismHypothesisEngine", "reasoning"),
        StaticRuntimeModule("DeepDiscoveryReasoner", "reasoning"),
        StaticRuntimeModule("ScientificDiscoveryDecisionEngine", "planning"),
        StaticRuntimeModule("CounterfactualDiscoveryStressTest", "integrity"),
        StaticRuntimeModule("PolicyEnforcedDiscoveryControl", "integrity"),
        StaticRuntimeModule("OutcomeVerificationDiscoveryMemory", "learning"),
        StaticRuntimeModule("HypothesisLineageDiscoveryGraph", "reasoning"),
        StaticRuntimeModule("LatentDiscoveryGapMiner", "planning"),
        StaticRuntimeModule("ExecutableDiscoveryProbePlan", "planning"),
        StaticRuntimeModule("ProbeOutcomeLearningLedger", "learning"),
        StaticRuntimeModule("MetaStrategyGovernor", "planning"),
        StaticRuntimeModule("DiscoveryQualityGate", "integrity"),
        StaticRuntimeModule("ExecutableQualityRunbook", "execution"),
        StaticRuntimeModule("EvidenceClosureEngine", "evidence"),
        StaticRuntimeModule("PostSearchThinkingEngine", "reasoning"),
        StaticRuntimeModule("ThinkingContinuityEngine", "reasoning"),
        StaticRuntimeModule("AutonomousThoughtPulseEngine", "reasoning"),
        StaticRuntimeModule("HypothesisGraphCognition", "reasoning"),
        StaticRuntimeModule("CognitiveMomentumEngine", "learning"),
        StaticRuntimeModule("LinkedCognitionSpineEngine", "orchestration"),
        StaticRuntimeModule("RuntimeHardeningV1101", "runtime"),
        StaticRuntimeModule("RuntimeHardeningV1102", "runtime"),
        StaticRuntimeModule("NcbiClientOkHttp", "network"),
        StaticRuntimeModule("NcbiRateLimiter", "network"),
        StaticRuntimeModule("SecureNcbiCredentialStore", "security"),
        StaticRuntimeModule("AxisMatcherWordBoundary", "evidence"),
        StaticRuntimeModule("CognitionPathOrchestrator", "orchestration"),
        StaticRuntimeModule("ProgressAuditGate", "integrity"),
        StaticRuntimeModule("OfflineThoughtLedger", "storage"),
        StaticRuntimeModule("OfflineHypothesisLinker", "reasoning"),
        StaticRuntimeModule("ResearchCyclePhaseAuditEngine", "integrity"),
        StaticRuntimeModule("ResearchKnowledgeStoreFileOps", "storage"),
        StaticRuntimeModule("ResearchCyclePhaseSpine", "orchestration"),
        StaticRuntimeModule("ResearchCyclePlanStage", "orchestration"),
        StaticRuntimeModule("ResearchCycleSearchStage", "execution"),
        StaticRuntimeModule("ResearchCyclePathMaintenanceGuard", "integrity"),
        StaticRuntimeModule("DatasetHuntSearchUnlockPolicy", "orchestration"),
        StaticRuntimeModule("ExtendedThinkingBudgetPolicy", "reasoning")
    )

    val activeModuleIds: List<String> = modules.filter { it.isReady() }.map { it.id }
    val readinessSummary: String = "ready=${activeModuleIds.size}/${modules.size}"
}
