package com.immunesignal.app

import java.util.Locale

/** v1.4.0: compiles narrow dataset-source queries from testable shards. */
object DatasetQueryCompiler {
    private val fallbackEvidenceQueries = listOf(
        "GSE GEO human immune response outcome severity recovery longitudinal control metadata accession",
        "PRJNA PRJEB SRP SRA human RNA-seq immune response recovery severity comparator BioProject metadata",
        "GEO GDS ArrayExpress E-MTAB ImmPort SDY allergy asthma viral autoimmune transcriptomic outcome response nonresponse control"
    )

    private val geoAccessionQueries = listOf(
        "GSE human immune response outcome severity recovery longitudinal control phenotype labels",
        "GDS GSE human allergy asthma viral autoimmune transcriptomic outcome response control metadata",
        "GEO DataSets human patient cohort immune response severity recovery time course accession"
    )

    private val sraAccessionQueries = listOf(
        "PRJNA PRJEB human RNA-seq immune response outcome severity recovery longitudinal metadata",
        "SRP SRR SRX SRA human single-cell immune response comparator control recovery severity",
        "BioProject BioSample SAMN human transcriptomic immune cohort phenotype outcome longitudinal"
    )

    private val immPortSdyQueries = listOf(
        "ImmPort SDY human immune response outcome severity recovery longitudinal control",
        "SDY ImmPort human allergy asthma viral autoimmune immune response phenotype outcome",
        "ImmPort study accession human cytokine transcriptomic response nonresponse severity endpoint"
    )

    private val pubmedAccessionMiningQueries = listOf(
        "GSE OR SDY OR PRJNA OR PRJEB OR SRP OR E-MTAB human immune response outcome severity recovery longitudinal",
        "public dataset accession human RNA-seq immune response GSE PRJNA SRP outcome comparator",
        "supplementary dataset GSE SDY PRJNA E-MTAB immune cohort response nonresponse control"
    )

    private val pubmedContradictionQueries = listOf(
        "human immune transcriptomic outcome severity recovery nonresponse heterogeneity no association negative control",
        "immune response longitudinal control comparator failed replication nonresponse severity recovery"
    )

    fun compile(shards: List<TestableHypothesisShard>, memory: PersistentFailureMemorySnapshot): List<ResearchQuery> {
        val killedFamilies = memory.records
            .filter { it.cooldownCyclesRemaining > 0 }
            .map { it.sourceFamily.lowercase(Locale.US) }
            .toSet()
        val out = mutableListOf<ResearchQuery>()
        for (shard in shards) {
            val seeds = shard.querySeeds.take(2)
            for ((idx, seed) in seeds.withIndex()) {
                out += ResearchQuery(
                    id = "q_v142_${shard.shardId.lowercase(Locale.US)}_$idx",
                    label = "v1.4.2 dataset shard: ${shard.label}",
                    query = seed,
                    reason = "Hypothesis decomposition: ${shard.evidenceQuestion}"
                )
            }
        }
        val filtered = if (killedFamilies.contains("broad_pubmed_mapping")) {
            out.filterNot { it.query.lowercase(Locale.US).contains("broad") }
        } else {
            out
        }
        val distinct = filtered.distinctBy { it.id }
        return distinct.ifEmpty { fallbackQueries(memory) }
    }


    /**
     * v1.10.8 maintenance8: source-aware query compilation.
     *
     * Generic PubMed-shaped strings are weak when sent to Entrez GDS/SRA. This
     * method keeps the old compile() contract intact, but gives the Dataset
     * Forager route-specific queries so an active forager cannot become a
     * shallow "same query everywhere" loop.
     */
    /**
     * v1.10.15: zero-query recovery guard.
     *
     * This is used only when a prior acquisition lock produced an empty plan or
     * an offline archive/reframe marker before any network query executed. It is
     * intentionally PubMed-shaped because the normal post-forager search stage
     * can only execute ResearchQuery batches through the PubMed path; direct
     * GEO/SRA routes remain owned by runDatasetFirstForaging.
     */
    fun zeroQueryAccessionRecoveryQueries(memory: PersistentFailureMemorySnapshot): List<ResearchQuery> {
        val forced = memory.records
            .asSequence()
            .map { it.forcedNextSource }
            .firstOrNull { it.isNotBlank() }
            .orEmpty()
        val query = "GSE OR GEO OR SDY OR ImmPort OR PRJNA OR PRJEB OR PRJDB OR SRP OR SRR OR SRX OR SRS OR E-MTAB human RNA-seq single-cell immune response outcome severity recovery longitudinal control comparator dataset accession"
        return listOf(
            ResearchQuery(
                id = "q_v11015_zero_query_accession_recovery_pubmed",
                label = "v1.10.15 zero-query accession recovery",
                query = query,
                reason = "Recovery guard: the dataset forager was active but no network query left PLAN/SEARCH. Execute one bounded accession-mining query before archive/reframe. Forced source hint: ${forced.ifBlank { "none" }}."
            )
        )
    }

    fun compileForRoute(
        route: DirectDatasetSourceRouter.SourceRoute,
        shards: List<TestableHypothesisShard>,
        memory: PersistentFailureMemorySnapshot
    ): List<ResearchQuery> {
        val base = compile(shards, memory)
        val sourceSeeds = when {
            route.ncbiDb == "gds" -> geoAccessionQueries
            route.ncbiDb == "sra" -> sraAccessionQueries
            route.sourceFamily.contains("IMM_PORT", ignoreCase = true) || route.sourceFamily.contains("SDY", ignoreCase = true) -> immPortSdyQueries
            route.sourceFamily.contains("ACCESSION_MINING", ignoreCase = true) -> pubmedAccessionMiningQueries
            route.sourceFamily.contains("CONTRADICTION", ignoreCase = true) -> pubmedContradictionQueries
            route.sourceFamily.contains("CONTROL", ignoreCase = true) -> pubmedContradictionQueries.map { "$it matched control baseline comparator" }
            else -> fallbackEvidenceQueries
        }
        val sourceQueries = sourceSeeds.mapIndexed { idx, query ->
            ResearchQuery(
                id = "q_v142_${route.sourceFamily.lowercase(Locale.US)}_source_${idx}",
                label = "v1.4.2 source-aware ${route.sourceFamily} query ${idx + 1}",
                query = query,
                reason = "Source-aware dataset accession query for ${route.sourceFamily}; avoids reusing a generic PubMed query against ${route.ncbiDb}."
            )
        }
        val shardQueries = base.take(3).mapIndexed { idx, q ->
            val routeTerms = when {
                route.ncbiDb == "gds" -> "GSE OR GDS OR GEO phenotype labels outcome severity recovery"
                route.ncbiDb == "sra" -> "PRJNA OR PRJEB OR SRP OR SRR OR SRX OR BioSample RNA-seq single-cell phenotype outcome"
                route.sourceFamily.contains("IMM_PORT", ignoreCase = true) || route.sourceFamily.contains("SDY", ignoreCase = true) -> "ImmPort OR SDY phenotype outcome response nonresponse severity"
                route.sourceFamily.contains("ACCESSION_MINING", ignoreCase = true) -> "GSE OR SDY OR PRJNA OR PRJEB OR SRP OR E-MTAB dataset accession outcome labels"
                route.sourceFamily.contains("CONTROL", ignoreCase = true) -> "negative control matched control comparator baseline"
                route.sourceFamily.contains("CONTRADICTION", ignoreCase = true) -> "nonresponse heterogeneity no association failed replication"
                else -> "dataset accession metadata outcome labels"
            }
            q.copy(
                id = "q_v142_${route.sourceFamily.lowercase(Locale.US)}_shard_${idx}_${q.id.takeLast(12)}",
                label = "v1.4.2 source-aware ${route.sourceFamily}: ${q.label}",
                query = "(${q.query}) $routeTerms",
                reason = "${q.reason} Source-aware route terms: $routeTerms."
            )
        }
        return (sourceQueries + shardQueries).distinctBy { it.id }.take(6)
    }

    private fun fallbackQueries(memory: PersistentFailureMemorySnapshot): List<ResearchQuery> {
        val memoryHint = memory.records
            .asSequence()
            .map { it.forcedNextSource }
            .firstOrNull { it.contains("GEO", ignoreCase = true) || it.contains("SRA", ignoreCase = true) || it.contains("DATASET", ignoreCase = true) }
            .orEmpty()
        return fallbackEvidenceQueries.mapIndexed { idx, query ->
            ResearchQuery(
                id = "q_v142_fallback_dataset_accession_$idx",
                label = "v1.4.2 fallback dataset accession hunt ${idx + 1}",
                query = query,
                reason = "Fallback guard: DATASET_HUNT must always emit at least one accession-oriented evidence query. Memory hint: ${memoryHint.ifBlank { "none" }}."
            )
        }
    }
}
