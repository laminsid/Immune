package com.immunesignal.app

/** v2.9.0 — Smart comparator auto-alignment v1.
 *
 * Rule-first, evidence-snippet-only alignment. This deliberately avoids treating an
 * LLM or heuristic label as final truth; it only prepares reviewable case/control
 * suggestions for the ETL readiness path.
 */
data class GTIMSmartComparatorAlignmentReportV2900(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val caseCount: Int,
    val controlCount: Int,
    val line: String,
    val boundaryLine: String
)

object GTIMSmartComparatorAutoAlignmentV2900 {
    const val VERSION: String = "2.9.0-smart-comparator-auto-alignment"

    fun build(actual: GTIMActualEtlExecutionReportV2800): GTIMSmartComparatorAlignmentReportV2900 {
        if (actual.targetId.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true)) {
            return emit(actual.targetId, "COMPARATOR_ALIGNMENT_BLOCKED_NO_TOPIC_TARGET", 0, 0, "Smart comparator alignment: version=$VERSION | state=COMPARATOR_ALIGNMENT_BLOCKED_NO_TOPIC_TARGET | target=${actual.targetId} | suggestions=0")
        }
        val suggestions = actual.caseControlLabelSuggestions.suggestions
        val caseCount = suggestions.count { isCase(it.suggestedLabel) }
        val controlCount = suggestions.count { isControl(it.suggestedLabel) }
        val state = when {
            actual.sampleMetadataExtraction.rows.isEmpty() -> "COMPARATOR_ALIGNMENT_PENDING_METADATA_ROWS"
            caseCount > 0 && controlCount > 0 -> "COMPARATOR_ALIGNMENT_READY_REVIEW_ONLY"
            suggestions.isNotEmpty() -> "COMPARATOR_ALIGNMENT_PARTIAL_REVIEW_REQUIRED"
            else -> "COMPARATOR_ALIGNMENT_NOT_INFERRED"
        }
        val preview = suggestions.take(4).joinToString(";") { s -> "${s.sampleId}:${s.suggestedLabel}@${s.confidence} source_field=${s.sourceField} evidence_snippet=${s.evidenceSnippet.take(50)}" }.ifBlank { "none" }
        val line = "Smart comparator alignment: version=$VERSION | state=$state | target=${actual.targetId} | case=$caseCount | control=$controlCount | preview=$preview | evidence_snippet_required=true | llm_label_not_final_truth=true"
        return emit(actual.targetId, state, caseCount, controlCount, line)
    }

    private fun isCase(label: String): Boolean = label.contains("case") || label.contains("disease") || label.contains("severe") || label == "treated" || label == "responder" || label == "non_responder"
    private fun isControl(label: String): Boolean = label.contains("control") || label == "baseline" || label == "untreated"

    private fun emit(target: String, state: String, caseCount: Int, controlCount: Int, line: String) =
        GTIMSmartComparatorAlignmentReportV2900(
            active = true,
            targetId = target,
            state = state,
            caseCount = caseCount,
            controlCount = controlCount,
            line = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Comparator alignment boundary: rule/LLM-style labels are review-only suggestions and require source_field plus evidence_snippet; never final truth."
        )
}
