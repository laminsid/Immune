package com.immunesignal.app

import org.json.JSONObject

object GTIMMetadataFirstObservedEvidenceBridgeV2950 {
    const val VERSION: String = "2.9.9-public-expression-request-plan-cache-export-bridge"
    const val CLAIM_LIMIT: String = "metadata_first_bridge_not_dge_ready_not_biological_proof"
    const val LOCAL_FULL_MATRIX_LIMIT_BYTES: Long = 100L * 1024L * 1024L

    fun build(
        contract: GTIMRunDecisionContractV2740,
        fileDiscovery: GTIMRepositoryFileDiscoveryReportV2800,
        report: JSONObject? = null
    ): GTIMMetadataFirstObservedEvidenceBridgeReportV2950 {
        val soft = GTIMGeoSoftMetadataProbeV2950.build(contract, fileDiscovery, report)
        val mapping = GTIMGseToSrpMapperV2950.build(fileDiscovery.targetId, soft, report)
        val external = GTIMExternalProcessedAvailabilityCheckV2950.build(fileDiscovery.targetId, mapping, report)
        val device = GTIMDeviceFilePolicyV2950.build(fileDiscovery.targetId, soft, GTIMSupplementaryFileDiscoveryV2802.observedFiles(report))
        val capsule = GTIMExternalEvidenceCapsuleImporterV2980.build(fileDiscovery.targetId, report)
        val publicSources = GTIMPublicExpressionSourceRegistryV2980.build(fileDiscovery.targetId, soft, mapping, external, capsule, report)
        val requestPlan = GTIMPublicExpressionRequestPlannerV2990.build(fileDiscovery.targetId, publicSources, mapping, capsule)
        val learningCache = GTIMLearningCacheV2980.build(contract, fileDiscovery.targetId, soft, mapping, publicSources, capsule)
        val learningCacheExport = GTIMLearningCacheExportV2990.build(learningCache, requestPlan, capsule)
        val state = when {
            fileDiscovery.state == "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET" -> "METADATA_FIRST_BRIDGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"
            soft.state == "GEO_SOFT_METADATA_PARSED_REVIEW_ONLY" && mapping.state == "SRP_MAPPING_FOUND" -> "METADATA_FIRST_BRIDGE_SOFT_AND_SRP_READY_REVIEW_ONLY"
            soft.state == "GEO_SOFT_METADATA_PARSED_REVIEW_ONLY" -> "METADATA_FIRST_BRIDGE_SOFT_READY_MAPPING_PENDING"
            mapping.state == "SRP_MAPPING_FOUND" -> "METADATA_FIRST_BRIDGE_SRP_READY_SOFT_PENDING"
            else -> "METADATA_FIRST_BRIDGE_METADATA_PROBE_REQUIRED"
        }
        val line = "Metadata-first bridge: version=$VERSION | state=$state | target=${fileDiscovery.targetId} | soft=${soft.state} | gse_srp=${mapping.state} | external=${external.state} | public_sources=${publicSources.state} | request_plan=${requestPlan.state} | capsule=${capsule.state} | learning_cache=${learningCache.state} | cache_export=${learningCacheExport.state} | device=${device.state} | no_dge_ready_from_metadata=true"
        return GTIMMetadataFirstObservedEvidenceBridgeReportV2950(
            active = true,
            targetId = fileDiscovery.targetId,
            state = state,
            softProbe = soft,
            gseToSrpMapping = mapping,
            externalAvailability = external,
            deviceFilePolicy = device,
            publicExpressionSources = publicSources,
            externalEvidenceCapsule = capsule,
            learningCache = learningCache,
            publicExpressionRequestPlan = requestPlan,
            learningCacheExport = learningCacheExport,
            line = normalize(line),
            boundaryLine = "Metadata-first bridge boundary: closes lookup/metadata/capsule planning only; public connectors and capsules do not download large matrices, do not create internal DGE_READY, and do not produce treatment or clinical-management claims; v2.9.9 request plans are explicit review-only intents, not automatic network execution."
        )
    }

    internal fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
