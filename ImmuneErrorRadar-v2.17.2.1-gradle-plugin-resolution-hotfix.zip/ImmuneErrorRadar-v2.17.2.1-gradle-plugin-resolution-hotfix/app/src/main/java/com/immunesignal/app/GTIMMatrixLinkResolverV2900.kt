package com.immunesignal.app

/** v2.9.0 — Matrix link resolver.
 *
 * Builds a deterministic, review-only repository link plan from the selected target and
 * the observed ETL evidence already present in the report. It never claims that a file
 * exists unless observed file evidence is present.
 */
data class GTIMMatrixLinkResolutionReportV2900(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val candidateLinks: List<String>,
    val observedMatrixFileTypes: List<String>,
    val line: String,
    val boundaryLine: String
)

object GTIMMatrixLinkResolverV2900 {
    const val VERSION: String = "2.9.0-matrix-link-resolver"

    fun build(card: GTIMMatrixAuditCardReportV2745, actual: GTIMActualEtlExecutionReportV2800): GTIMMatrixLinkResolutionReportV2900 {
        val target = card.targetId
        if (target.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true) || target.equals("NO_ACCESSION_ID_CAPTURED", true)) {
            return emit(
                target = target,
                state = "MATRIX_LINK_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET",
                links = emptyList(),
                observed = emptyList(),
                line = "Matrix link resolver: version=$VERSION | state=MATRIX_LINK_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | target=$target | next=select topic-compatible accession before file discovery"
            )
        }
        val observedTypes = actual.matrixFileClassifier.matrixFileTypes.filter { type ->
            type.contains("MATRIX") || type == "COUNT_TABLE" || type == "EXPRESSION_TABLE" || type == "ANNDATA_H5AD" || type == "HDF5_MATRIX" || type == "R_OBJECT_MATRIX"
        }.distinct()
        val links = candidateLinks(target, card.repository)
        val state = when {
            observedTypes.isNotEmpty() -> "MATRIX_LINK_OBSERVED_REVIEW_ONLY"
            links.isNotEmpty() -> "MATRIX_LINK_RESOLUTION_REQUIRED"
            else -> "MATRIX_LINK_REPOSITORY_UNKNOWN_REVIEW_REQUIRED"
        }
        val next = when (state) {
            "MATRIX_LINK_OBSERVED_REVIEW_ONLY" -> "observed matrix-like file classified; proceed to metadata/sample-id linkage review"
            "MATRIX_LINK_RESOLUTION_REQUIRED" -> "probe candidate supplementary links and record observed file evidence before matrix parsing"
            else -> "surface repository and accession family before file discovery"
        }
        val line = "Matrix link resolver: version=$VERSION | state=$state | target=$target | candidate_links=${links.take(2).ifEmpty { listOf("none") }.joinToString(",")} | observed_matrix_types=${observedTypes.ifEmpty { listOf("none") }.joinToString(",")} | next=$next"
        return emit(target, state, links, observedTypes, line)
    }

    private fun candidateLinks(target: String, repository: String): List<String> {
        val upper = target.uppercase()
        return when {
            upper.startsWith("GSE") -> {
                val n = upper.removePrefix("GSE")
                val prefix = if (n.length > 3) "GSE${n.dropLast(3)}nnn" else "GSEnnn"
                listOf(
                    "https://ftp.ncbi.nlm.nih.gov/geo/series/$prefix/$upper/suppl/",
                    "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=$upper"
                )
            }
            upper.startsWith("SRP") || upper.startsWith("SRR") || upper.startsWith("PRJNA") -> listOf("SRA/ENA lookup required for $upper")
            upper.startsWith("E-MTAB") -> listOf("ArrayExpress lookup required for $upper")
            repository.equals("GEO", true) -> listOf("GEO supplementary lookup required for $upper")
            else -> emptyList()
        }
    }

    private fun emit(target: String, state: String, links: List<String>, observed: List<String>, line: String) =
        GTIMMatrixLinkResolutionReportV2900(
            active = true,
            targetId = target,
            state = state,
            candidateLinks = links,
            observedMatrixFileTypes = observed,
            line = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Matrix link boundary: candidate URLs are not observed files; matrix parsing requires observed file evidence with file name/source/size/checksum/parser hint."
        )
}
