package com.immunesignal.app

import java.util.Locale

object GTIMDeviceFilePolicyV2950 {
    const val VERSION: String = "2.9.8-device-file-size-guard"

    fun build(targetId: String, soft: GTIMSoftMetadataProbeReportV2950, observed: List<GTIMObservedRepositoryFileV2802>): GTIMDeviceFilePolicyReportV2950 {
        if (soft.state.contains("BLOCKED_NO_TOPIC", true) || targetId.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true)) {
            return emit(targetId, "DEVICE_FILE_POLICY_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", emptyList(), emptyList(), emptyList())
        }
        val files = (observed + soft.supplementaryFiles).distinctBy { it.fileName.lowercase(Locale.US) + "|" + it.sourceUrl.lowercase(Locale.US) }
        if (files.isEmpty()) return emit(targetId, "DEVICE_FILE_POLICY_WAITING_FOR_OBSERVED_FILES", emptyList(), emptyList(), emptyList())
        val tooLarge = files.filter { isTooLargeOrHeavy(it) }.map { it.fileName }.distinct()
        val unknown = files.filter { it.sizeBytes <= 0L && isHeavyByName(it.fileName, it.parserHint) }.map { it.fileName }.distinct()
        val safe = files.filter { it.fileName !in tooLarge && it.fileName !in unknown }.map { it.fileName }.distinct()
        val state = when {
            tooLarge.isNotEmpty() || unknown.isNotEmpty() -> "OBSERVED_FILE_TOO_LARGE_FOR_DEVICE"
            safe.isNotEmpty() -> "DEVICE_SAFE_METADATA_OR_SMALL_TABLE_REVIEW_ONLY"
            else -> "DEVICE_FILE_POLICY_REVIEW_REQUIRED"
        }
        return emit(targetId, state, tooLarge, safe, unknown)
    }

    private fun isTooLargeOrHeavy(file: GTIMObservedRepositoryFileV2802): Boolean =
        file.sizeBytes > GTIMMetadataFirstObservedEvidenceBridgeV2950.LOCAL_FULL_MATRIX_LIMIT_BYTES ||
            isHeavyByName(file.fileName, file.parserHint) && file.sizeBytes > 0L

    private fun isHeavyByName(name: String, hint: String): Boolean {
        val text = "$name $hint".lowercase(Locale.US)
        return text.contains(".h5") || text.contains(".h5ad") || text.contains(".rds") || text.contains(".rdata") ||
            text.contains(".bam") || text.contains("fastq") || text.contains("raw.tar") || text.endsWith(".tar") || text.endsWith(".tar.gz")
    }

    private fun emit(target: String, state: String, tooLarge: List<String>, safe: List<String>, unknown: List<String>): GTIMDeviceFilePolicyReportV2950 {
        val line = "Device file policy: version=$VERSION | state=$state | target=$target | too_large=${tooLarge.take(5).joinToString(",").ifBlank { "none" }} | safe=${safe.take(5).joinToString(",").ifBlank { "none" }} | unknown_size_heavy=${unknown.take(5).joinToString(",").ifBlank { "none" }} | local_full_matrix_limit_bytes=${GTIMMetadataFirstObservedEvidenceBridgeV2950.LOCAL_FULL_MATRIX_LIMIT_BYTES} | no_large_matrix_download_on_device=true"
        return GTIMDeviceFilePolicyReportV2950(
            active = true,
            targetId = target,
            state = state,
            tooLargeFiles = tooLarge,
            safeFiles = safe,
            unknownSizeFiles = unknown,
            localFullMatrixLimitBytes = GTIMMetadataFirstObservedEvidenceBridgeV2950.LOCAL_FULL_MATRIX_LIMIT_BYTES,
            line = GTIMMetadataFirstObservedEvidenceBridgeV2950.normalize(line),
            boundaryLine = "Device file policy boundary: Android may keep metadata/link evidence locally; large matrices, raw archives, BAM/FASTQ/H5/RDS containers route to precomputed or remote review paths."
        )
    }
}
