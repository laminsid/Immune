package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.5 — Immune module signal engine.
 * Produces bounded module-signal candidates from selected capsules. It intentionally
 * labels signals as candidate/test-ready unless actual DGE values are present.
 */
object GTIMImmuneModuleSignalEngineV2135 {
    const val VERSION: String = "2.13.5-immune-module-signal-engine"
    const val CLAIM_LIMIT: String = "module_signal_candidate_not_validated_dge"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val capsuleStore = report.optJSONObject("processedCapsuleStoreV2135") ?: GTIMProcessedCapsuleStoreV2135.toJson(report)
        val capsule = capsuleStore.optJSONObject("selectedCapsule") ?: JSONObject()
        val modules = GTIMProcessedCapsuleStoreV2135.jsonStrings(capsule.optJSONArray("moduleIds"))
        val signals = JSONArray()
        modules.forEach { module ->
            signals.put(JSONObject()
                .put("moduleId", module)
                .put("direction", "to_test_not_observed")
                .put("signalState", if (capsule.optInt("readiness", 0) >= 8) "DATASET_CAPSULE_READY_FOR_COMPUTATIONAL_TEST" else "PARTIAL_CAPSULE_NEEDS_REVIEW")
                .put("effectSize", "unknown_until_DGE_or_module_score")
                .put("fdr", "unknown_until_DGE_or_module_score")
                .put("specificity", specificityFor(active, module))
                .put("boundary", CLAIM_LIMIT))
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (signals.length() > 0) "MODULE_SIGNAL_CANDIDATES_READY" else "MODULE_SIGNAL_NEEDS_CAPSULE")
            .put("activeDomain", active)
            .put("canonicalTarget", capsuleStore.optString("canonicalTarget"))
            .put("moduleSignals", signals)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val signals = obj.optJSONArray("moduleSignals") ?: JSONArray()
        val names = (0 until signals.length()).mapNotNull { signals.optJSONObject(it)?.optString("moduleId") }.take(5)
        return listOf(
            "Immune module signal engine",
            "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; signals=${signals.length()}.",
            "Candidate modules: ${names.joinToString(", ").ifBlank { "none" }}",
            "Boundary: modules are test-ready candidates until DGE/module scores, FDR/effect size, replication, and contradiction checks exist."
        )
    }

    private fun specificityFor(domain: String, module: String): String = when {
        domain.contains("allergy") && (module.contains("type2") || module.contains("mast") || module.contains("barrier")) -> "domain_specific"
        domain.contains("filovirus") && (module.contains("interferon") || module.contains("endothelial") || module.contains("coagulation")) -> "domain_specific"
        domain.contains("viral") && (module.contains("interferon") || module.contains("il6") || module.contains("recovery")) -> "domain_relevant"
        domain.contains("depression") && (module.contains("kynurenine") || module.contains("microglia") || module.contains("il6")) -> "domain_specific"
        else -> "broad_or_background"
    }
}
