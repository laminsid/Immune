package com.immunesignal.app

import org.json.JSONObject

/** v2.13.5 — Discovery Claim Ladder C0-C5.
 * Strict clinical proof remains blocked, but C1/C2 candidate language is allowed so the
 * app can move beyond route-only research reports.
 */
object GTIMDiscoveryClaimLadderV2135 {
    const val VERSION: String = "2.13.5-discovery-claim-ladder-c0-c5"
    const val CLAIM_LIMIT: String = "discovery_candidate_allowed_scientific_proof_blocked"

    fun level(report: JSONObject): String {
        val capsule = report.optJSONObject("processedCapsuleStoreV2135")?.optJSONObject("selectedCapsule") ?: JSONObject()
        val exec = report.optJSONObject("discoveryExecutionEnginesV2135") ?: JSONObject()
        val moduleSignals = report.optJSONObject("immuneModuleSignalEngineV2135")?.optJSONArray("moduleSignals")
        val readiness = capsule.optInt("readiness", 0)
        val comparatorClosed = exec.optString("comparatorGate") == "COMPARATOR_GATE_CLOSED"
        val provenanceClosed = exec.optString("provenanceGate") == "PROVENANCE_GATE_CLOSED"
        val hasModules = (moduleSignals?.length() ?: 0) > 0
        return when {
            readiness >= 9 && comparatorClosed && provenanceClosed && hasModules -> "C1_DATASET_BACKED_DISCOVERY_CANDIDATE"
            readiness >= 7 && hasModules -> "C1_PARTIAL_DATASET_BACKED_DISCOVERY_CANDIDATE"
            hasModules -> "C0_MODULE_ROUTE_CANDIDATE"
            else -> "C0_ROUTE_ONLY"
        }
    }

    fun toJson(report: JSONObject): JSONObject {
        val lvl = level(report)
        return JSONObject()
            .put("version", VERSION)
            .put("state", "DISCOVERY_CLAIM_LADDER_READY")
            .put("discoveryLevel", lvl)
            .put("relaxedCandidatePolicy", "C1 may be called a discovery candidate when capsule/comparator/provenance/module gates are visible; C2+ requires computational replication; C3+ requires cross-dataset robustness.")
            .put("clinicalClaimAllowed", false)
            .put("scientificDiscoveryProofAllowed", lvl.startsWith("C3") || lvl.startsWith("C4") || lvl.startsWith("C5"))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Discovery claim ladder",
        "State: ${obj.optString("state", "UNKNOWN")}; level=${obj.optString("discoveryLevel", "C0_ROUTE_ONLY")}; clinical_claim_allowed=${obj.optBoolean("clinicalClaimAllowed", false)}.",
        "Policy: ${obj.optString("relaxedCandidatePolicy", "C1 candidate language allowed; proof blocked")}",
        "Boundary: discovery candidate ≠ validated discovery, treatment, diagnosis, or efficacy."
    )
}
