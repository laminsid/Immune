package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

// v2.12.3 — Same-topic deepening bridge.
// Repeated presses on Immune Search with the same topic must continue the investigation,
// not restart the same shallow pass. This bridge reads recent saved reports, detects the
// same topic, increases search depth, carries forward candidate handles/gaps, and keeps
// the output research-only. It never upgrades evidence, runs DGE, or creates clinical claims.
data class GTIMDeepeningRunLimitsV2123(
    val maxSearchMillis: Long,
    val maxLearningMillis: Long,
    val maxQueries: Int,
    val maxResultsPerQuery: Int,
    val fetchAbstracts: Boolean,
    val enableSelectiveAbstracts: Boolean,
    val maxAbstractsPerCycle: Int
)

data class GTIMSameTopicDeepeningPlanV2123(
    val version: String,
    val active: Boolean,
    val state: String,
    val originalTopic: String,
    val runTopic: String,
    val previousMatchingRuns: Int,
    val deepeningDepth: Int,
    val deepeningQuery: String,
    val passLabel: String,
    val whatChangesThisRun: List<String>,
    val carryForwardTargets: List<String>,
    val carryForwardGaps: List<String>,
    val runLimits: GTIMDeepeningRunLimitsV2123,
    val claimLimit: String
)

object GTIMSameTopicDeepeningBridgeV2123 {
    const val VERSION: String = "2.12.3-same-topic-deepening-bridge"
    const val CLAIM_LIMIT: String = "same_topic_deepening_research_only_no_evidence_upgrade_no_clinical_claim"
    const val REQUIRED_UI_TOKEN: String = "uiDeepenText"

    fun build(rawTopic: String, resolvedTopic: String, recentReportLines: List<String>): GTIMSameTopicDeepeningPlanV2123 {
        val original = firstNonBlank(rawTopic.trim(), resolvedTopic.trim(), "immune research topic").take(280)
        val normalizedOriginal = normalize(original)
        val recentReports = recentReportLines.mapNotNull { parseReport(it) }
        val matches = recentReports.filter { report ->
            val candidates = topicCandidates(report)
            candidates.any { candidate -> sameTopic(normalizedOriginal, normalize(candidate)) }
        }
        val previousMatchingRuns = matches.size
        val deepeningDepth = (previousMatchingRuns + 1).coerceIn(1, 6)
        val active = previousMatchingRuns > 0
        val targets = matches.flatMap { report -> handleCandidates(report) }.distinct().take(6)
        val gaps = matches.flatMap { report -> gapCandidates(report) }.distinct().take(8)
        val passLabel = passLabel(deepeningDepth)
        val changes = changesForDepth(deepeningDepth, targets, gaps)
        val runTopic = if (active) deepenQuery(original, deepeningDepth, targets, gaps) else original
        val limits = limitsForDepth(deepeningDepth)
        return GTIMSameTopicDeepeningPlanV2123(
            version = VERSION,
            active = active,
            state = if (active) "SAME_TOPIC_DEEPENING_ACTIVE" else "FIRST_PASS_OR_NO_PRIOR_MATCH",
            originalTopic = original,
            runTopic = runTopic,
            previousMatchingRuns = previousMatchingRuns,
            deepeningDepth = deepeningDepth,
            deepeningQuery = runTopic,
            passLabel = passLabel,
            whatChangesThisRun = changes,
            carryForwardTargets = targets,
            carryForwardGaps = gaps,
            runLimits = limits,
            claimLimit = CLAIM_LIMIT
        )
    }

    fun topicForRun(plan: GTIMSameTopicDeepeningPlanV2123): String = plan.runTopic.ifBlank { plan.originalTopic }

    fun uiDeepenText(plan: GTIMSameTopicDeepeningPlanV2123): String {
        return if (plan.active) {
            buildString {
                append("Deepening mode: same topic detected — pass #").append(plan.deepeningDepth).append("\n")
                append("Focus: ").append(plan.passLabel).append("\n")
                append("This run will not restart from zero. It carries forward: ")
                    .append(plan.carryForwardTargets.joinToString(", ").ifBlank { "prior gaps and route memory" }).append("\n")
                append("Depth plan: ").append(plan.whatChangesThisRun.take(3).joinToString(" | ")).append("\n")
                append("Boundary: deeper search only; no evidence upgrade, diagnosis, treatment, or gene/pathway claim without gates.")
            }
        } else {
            "Deepening mode: first pass for this topic. Repeat Immune Search with the same topic to deepen instead of restarting."
        }
    }

    fun publicLines(report: JSONObject): List<String> {
        val plan = report.optJSONObject("sameTopicDeepeningV2123") ?: return emptyList()
        if (!plan.optBoolean("active", false)) return emptyList()
        val changes = jsonArray(plan.optJSONArray("whatChangesThisRun")).take(4)
        val targets = jsonArray(plan.optJSONArray("carryForwardTargets")).take(4)
        return listOf(
            "Same-topic deepening",
            "Deepening state: ${plan.optString("state", "SAME_TOPIC_DEEPENING_ACTIVE")} — pass #${plan.optInt("deepeningDepth", 2)} (${plan.optString("passLabel", "deeper evidence pass")}).",
            "Not restarted: previous matching runs=${plan.optInt("previousMatchingRuns", 1)}; carried targets=${targets.joinToString(", ").ifBlank { "none yet" }}.",
            "This pass deepens: ${changes.joinToString(" | ").ifBlank { "metadata, comparator, matrix, external evidence, contradiction check" }}.",
            "Deepening boundary: ${plan.optString("claimLimit", CLAIM_LIMIT)}."
        )
    }

    fun toJson(plan: GTIMSameTopicDeepeningPlanV2123): JSONObject = JSONObject()
        .put("version", plan.version)
        .put("active", plan.active)
        .put("state", plan.state)
        .put("originalTopic", plan.originalTopic)
        .put("runTopic", plan.runTopic)
        .put("previousMatchingRuns", plan.previousMatchingRuns)
        .put("deepeningDepth", plan.deepeningDepth)
        .put("deepeningQuery", plan.deepeningQuery)
        .put("passLabel", plan.passLabel)
        .put("whatChangesThisRun", JSONArray(plan.whatChangesThisRun))
        .put("carryForwardTargets", JSONArray(plan.carryForwardTargets))
        .put("carryForwardGaps", JSONArray(plan.carryForwardGaps))
        .put("runLimits", JSONObject()
            .put("maxSearchMillis", plan.runLimits.maxSearchMillis)
            .put("maxLearningMillis", plan.runLimits.maxLearningMillis)
            .put("maxQueries", plan.runLimits.maxQueries)
            .put("maxResultsPerQuery", plan.runLimits.maxResultsPerQuery)
            .put("fetchAbstracts", plan.runLimits.fetchAbstracts)
            .put("enableSelectiveAbstracts", plan.runLimits.enableSelectiveAbstracts)
            .put("maxAbstractsPerCycle", plan.runLimits.maxAbstractsPerCycle))
        .put("claimLimit", plan.claimLimit)
        .put("uiToken", REQUIRED_UI_TOKEN)

    private fun limitsForDepth(depth: Int): GTIMDeepeningRunLimitsV2123 {
        val safeDepth = depth.coerceIn(1, 6)
        return GTIMDeepeningRunLimitsV2123(
            maxSearchMillis = RuntimeFeatureFlags.DEFAULT_SEARCH_TIME_LIMIT_MILLIS + (safeDepth - 1) * 4L * 60L * 1000L,
            maxLearningMillis = RuntimeFeatureFlags.DEFAULT_RESEARCH_LEARNING_TIME_LIMIT_MILLIS,
            maxQueries = min(20, 8 + (safeDepth - 1) * 3),
            maxResultsPerQuery = min(60, 25 + (safeDepth - 1) * 7),
            fetchAbstracts = safeDepth >= 2,
            enableSelectiveAbstracts = true,
            maxAbstractsPerCycle = min(14, 5 + (safeDepth - 1) * 2)
        )
    }

    private fun deepenQuery(topic: String, depth: Int, targets: List<String>, gaps: List<String>): String {
        val focusTerms = when (depth.coerceIn(2, 6)) {
            2 -> listOf("data availability", "GEO", "SRA", "supplementary files", "sample table", "comparator labels")
            3 -> listOf("raw count matrix", "sample ID linkage", "case control", "metadata", "processed expression")
            4 -> listOf("gene list", "pathway module", "functional repair", "microbiome", "barrier", "metabolic", "immune tolerance")
            5 -> listOf("contradiction check", "wrong tissue", "wrong species", "independent cohort", "falsification")
            else -> listOf("study dossier", "validation ladder", "biosafety boundary", "source to sample provenance")
        }
        val targetTerms = targets.take(3)
        val gapTerms = gaps.take(3).map { it.replace('_', ' ') }
        return (listOf(topic) + targetTerms + focusTerms + gapTerms)
            .joinToString(" ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(420)
    }

    private fun changesForDepth(depth: Int, targets: List<String>, gaps: List<String>): List<String> {
        val base = when (depth.coerceIn(1, 6)) {
            1 -> listOf("initial topic routing", "first accession/handle hunt", "safe external lookup setup")
            2 -> listOf("continue same topic", "inspect prior candidate handles", "force data-availability and supplementary-file search")
            3 -> listOf("deepen matrix/sample/comparator linkage", "expand processed-expression source checks", "carry forward unresolved gaps")
            4 -> listOf("connect mechanism to functional repair dossier", "seek gene/pathway evidence capsules", "keep claims review-only")
            5 -> listOf("run contradiction and falsification pressure", "look for independent cohort support", "kill weak routes faster")
            else -> listOf("compose study-grade validation ladder", "separate novelty from known background", "prepare next evidence capsule")
        }
        val withTargets = if (targets.isNotEmpty()) base + "carry forward targets: ${targets.take(3).joinToString(", ")}" else base
        return if (gaps.isNotEmpty()) withTargets + "re-test gaps: ${gaps.take(3).joinToString(", ")}" else withTargets
    }

    private fun passLabel(depth: Int): String = when (depth.coerceIn(1, 6)) {
        1 -> "initial route and handle discovery"
        2 -> "target/file/metadata deepening"
        3 -> "matrix-comparator-sample linkage deepening"
        4 -> "mechanism and functional repair deepening"
        5 -> "contradiction and independent support deepening"
        else -> "study dossier and validation ladder deepening"
    }

    private fun topicCandidates(report: JSONObject): List<String> {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val auto = report.optJSONObject("autonomousDiscoveryMode") ?: JSONObject()
        return listOf(
            topic.optString("rawInput"),
            topic.optString("normalizedTopic"),
            auto.optString("selectedTopic"),
            report.optString("researchTopic"),
            report.optString("topic")
        ).filter { it.isNotBlank() }
    }

    private fun handleCandidates(report: JSONObject): List<String> {
        val out = mutableListOf<String>()
        val consistency = report.optJSONObject("reportConsistencyGateV2121") ?: JSONObject()
        out += consistency.optString("acceptedTarget")
        out += consistency.optString("candidateLookupHandle")
        val external = report.optJSONObject("externalRouterV211310") ?: JSONObject()
        out += external.optString("targetId")
        val relaxed = report.optJSONObject("relaxedResearchLeadBridgeV2122") ?: JSONObject()
        out += relaxed.optString("acceptedTarget")
        out += relaxed.optString("candidateLookupHandle")
        val text = report.toString()
        Regex("GSE\\d{3,}|PRJNA\\d+|SRP\\d+|SRR\\d+|SDY\\d+|E-MTAB-\\d+", RegexOption.IGNORE_CASE)
            .findAll(text).forEach { out += it.value.uppercase(Locale.US) }
        return out.map { it.trim() }
            .filter { it.isNotBlank() && !it.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true) && !it.equals("BLOCKED", true) }
            .distinct()
    }

    private fun gapCandidates(report: JSONObject): List<String> {
        val out = mutableListOf<String>()
        val relaxed = report.optJSONObject("relaxedResearchLeadBridgeV2122") ?: JSONObject()
        out += relaxed.optString("relaxedNextAction")
        val functional = report.optJSONObject("functionalRepairDossierV2120") ?: JSONObject()
        out += jsonArray(functional.optJSONArray("missingEvidence"))
        val study = report.optJSONObject("studyGradeFunctionalSolutionV2121") ?: JSONObject()
        out += jsonArray(study.optJSONArray("falsificationTriggers"))
        val consistency = report.optJSONObject("reportConsistencyGateV2121") ?: JSONObject()
        out += consistency.optString("targetState")
        return out.map { it.replace(Regex("\\s+"), " ").trim().take(120) }
            .filter { it.isNotBlank() }
            .distinct()
    }

    private fun sameTopic(a: String, b: String): Boolean {
        if (a.isBlank() || b.isBlank()) return false
        if (a == b) return true
        if (a.length >= 8 && b.contains(a)) return true
        if (b.length >= 8 && a.contains(b)) return true
        val at = tokenSet(a)
        val bt = tokenSet(b)
        if (at.isEmpty() || bt.isEmpty()) return false
        val overlap = at.intersect(bt).size
        val denominator = max(1, min(at.size, bt.size))
        return overlap.toDouble() / denominator.toDouble() >= 0.62
    }

    private fun normalize(value: String): String = value.lowercase(Locale.US)
        .replace(Regex("[^a-z0-9+ -]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun tokenSet(value: String): Set<String> = normalize(value)
        .split(' ')
        .map { it.trim() }
        .filter { it.length >= 3 && it !in setOf("and", "the", "for", "with", "data", "dataset", "human") }
        .toSet()

    private fun parseReport(line: String): JSONObject? = try { JSONObject(line) } catch (_: Throwable) { null }
    private fun jsonArray(arr: JSONArray?): List<String> = if (arr == null) emptyList() else (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}
