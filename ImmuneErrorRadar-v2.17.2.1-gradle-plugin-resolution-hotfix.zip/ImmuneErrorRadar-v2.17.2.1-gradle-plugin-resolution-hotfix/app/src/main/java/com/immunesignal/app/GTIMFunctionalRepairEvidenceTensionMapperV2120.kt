package com.immunesignal.app

// v2.12.0 — Separates support, uncertainty, contradiction, and kill criteria.
object GTIMFunctionalRepairEvidenceTensionMapperV2120 {
    const val VERSION: String = "2.12.0-functional-repair-evidence-tension-mapper"

    fun map(
        model: GTIMFunctionalDysfunctionModelV2120,
        functions: List<GTIMFunctionalRepairFunctionV2120>,
        target: String,
        evidenceText: String
    ): GTIMEvidenceTensionMapV2120 {
        val support = mutableListOf<String>()
        if (target.isNotBlank() && target != "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" && target != "BLOCKED") {
            support += "candidate accession or lookup handle exists: $target"
        }
        support += model.causalSketch.take(4).map { "mechanism node under review: $it" }
        support += functions.take(2).map { "repair function route available: ${it.repairFunction}" }
        if (evidenceText.contains("METADATA_AUDIT_READY", true)) support += "metadata/comparator audit advanced but not decisive"
        if (evidenceText.contains("External Router", true) || evidenceText.contains("EXTERNAL_ROUTER", true)) support += "external lookup routes can gather missing file/provenance evidence"

        val weakness = mutableListOf(
            "no reviewed internal DGE output yet",
            "no observed gene/pathway signal can be claimed yet",
            "microbial or biological tool candidate is function-level hypothesis only"
        )
        if (evidenceText.contains("NO_TOPIC_COMPATIBLE", true)) weakness += "topic-compatible target has not been accepted"
        if (evidenceText.contains("FILE_MISSING", true) || evidenceText.contains("OBSERVED_FILE_EVIDENCE", true)) weakness += "raw/count matrix or file evidence is still missing"

        val ambiguity = listOf(
            "disease labels may share symptoms without sharing root dysfunction",
            "tissue, species, treatment status, and sampling time can flip interpretation",
            "microbiome association can be passenger signal rather than causal repair function",
            "external sources may identify handles without proving source-to-sample linkage"
        )
        val kill = listOf(
            "target is wrong tissue/species or does not match the research topic",
            "no matrix/provenance can be recovered after external lookup",
            "comparator labels cannot separate case/control or relevant subgroups",
            "candidate repair marker does not move in the predicted direction",
            "negative-control route explains the signal better than the proposed dysfunction",
            "biosafety risk dominates plausible research value"
        )
        val novelty = noveltyFor(model, functions, evidenceText)
        val line = "Functional repair evidence tension: version=$VERSION | novelty=$novelty | support=${support.distinct().take(8).joinToString(";").oneLine()} | weaknesses=${weakness.distinct().joinToString(";").oneLine()} | ambiguity=${ambiguity.joinToString(";").oneLine()} | kill=${kill.joinToString(";").oneLine()}"
        return GTIMEvidenceTensionMapV2120(support.distinct().take(8), weakness.distinct().take(8), ambiguity, kill, novelty, line)
    }

    private fun noveltyFor(model: GTIMFunctionalDysfunctionModelV2120, functions: List<GTIMFunctionalRepairFunctionV2120>, evidenceText: String): String = when {
        functions.any { it.evidenceLevel.contains("L0") } -> "NOVELTY_OPEN_HIGH_UNVALIDATED"
        model.modelId.contains("exposure", true) -> "NOVELTY_MEDIUM_HIGH_BIOSAFETY_HEAVY"
        model.modelId.contains("microbiome", true) && evidenceText.contains("depression", true) -> "NOVELTY_MEDIUM_KNOWN_PARTS_NEW_SUBGROUP_TEST"
        model.modelId.contains("interferon", true) -> "NOVELTY_MEDIUM_CONTEXT_AND_DURABILITY_REFRAMING"
        else -> "NOVELTY_MEDIUM_FUNCTIONAL_REPAIR_REFRAMING"
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
