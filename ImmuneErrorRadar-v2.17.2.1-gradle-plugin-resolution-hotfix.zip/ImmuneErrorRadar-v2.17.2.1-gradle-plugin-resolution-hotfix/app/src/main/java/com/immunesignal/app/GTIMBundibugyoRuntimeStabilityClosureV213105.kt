package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.13.10.5 — Bundibugyo/filovirus hard routing + runtime report stability closure.
 *
 * This layer is intentionally narrow. It does not add a new scientific claim engine.
 * It makes Ebola Bundibugyo/BDBV impossible to satisfy with a generic COVID/post-viral
 * capsule, and it records a runtime-safe transition contract for the fragile gap between
 * search completion and report rendering/export.
 */
object GTIMBundibugyoRuntimeStabilityClosureV213105 {
    const val VERSION: String = "2.13.10.5-bundibugyo-runtime-stability-closure"
    const val CLAIM_LIMIT: String = "bundibugyo_route_and_runtime_stability_only_no_evidence_upgrade"

    fun isBundibugyoQuestion(report: JSONObject): Boolean = normalizedText(report).let { text ->
        listOf("bundibugyo", "bdbv", "ebola bundibugyo", "bundibugyo ebolavirus", "bundibugyo virus").any { text.contains(it) }
    }

    fun isFilovirusQuestion(report: JSONObject): Boolean = normalizedText(report).let { text ->
        isBundibugyoQuestion(report) || listOf("ebola", "filovirus", "ebolavirus", "viral hemorrhagic fever", "hemorrhagic fever").any { text.contains(it) }
    }

    fun forcedActiveDomain(report: JSONObject): String = when {
        isFilovirusQuestion(report) -> "filovirus_viral_host_response"
        else -> GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
    }

    fun forcedSubtype(report: JSONObject): String = when {
        isBundibugyoQuestion(report) -> "viral_filovirus_bundibugyo"
        isFilovirusQuestion(report) -> "viral_filovirus"
        else -> GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report)
    }

    fun targetAllowedForSubtype(handle: String, subtype: String): Boolean {
        if (handle.isBlank()) return true
        val h = handle.uppercase(Locale.US)
        return when (subtype) {
            "viral_filovirus_bundibugyo" -> isBundibugyoCompatibleTarget(h)
            "viral_filovirus" -> isFilovirusCompatibleTarget(h)
            else -> true
        }
    }

    fun canonicalTarget(report: JSONObject): String {
        val subtype = forcedSubtype(report)
        val candidates = collectCandidateHandles(report)
        if (subtype == "viral_filovirus_bundibugyo") {
            // No Bundibugyo-specific cleaned capsule is currently shipped. Prefer exact
            // BDBV-compatible future seeds if later added; otherwise leave canonical empty.
            return candidates.firstOrNull { isBundibugyoCompatibleTarget(it) }.orEmpty()
        }
        if (subtype == "viral_filovirus") {
            return candidates.firstOrNull { it == "GSE45291" }
                ?: candidates.firstOrNull { isFilovirusCompatibleTarget(it) && it != "GSE166552" }
                ?: ""
        }
        return GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
    }

    fun toJson(report: JSONObject, stage: String = "REPORT_ASSEMBLY"): JSONObject {
        val subtype = forcedSubtype(report)
        val activeDomain = forcedActiveDomain(report)
        val canonical = canonicalTarget(report)
        val blocked = collectCandidateHandles(report).filter { !targetAllowedForSubtype(it, subtype) }
        val state = when {
            subtype == "viral_filovirus_bundibugyo" && canonical.isBlank() -> "BUNDIBUGYO_TOPIC_LEVEL_ROUTE_NEEDS_BDBV_COMPATIBLE_TARGET"
            subtype.startsWith("viral_filovirus") && canonical.isBlank() -> "FILOVIRUS_TOPIC_LEVEL_ROUTE_NEEDS_COMPATIBLE_TARGET"
            blocked.isNotEmpty() -> "FILOVIRUS_ROUTE_READY_WITH_GENERIC_TARGETS_BLOCKED"
            else -> "BUNDIBUGYO_RUNTIME_STABILITY_READY"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("activeDomain", activeDomain)
            .put("subtype", subtype)
            .put("canonicalTarget", canonical)
            .put("blockedGenericTargets", JSONArray(blocked))
            .put("bundibugyoHardGate", isBundibugyoQuestion(report))
            .put("filovirusHardGate", isFilovirusQuestion(report))
            .put("blankSearchSafe", true)
            .put("reportTransitionSafe", true)
            .put("safeStage", stage)
            .put("runtimePolicy", "search_completion_to_report_render_is_safe: no previous query replay, no generic COVID fallback for Bundibugyo/filovirus, report-render exceptions downgrade to saved debug output")
            .put("strictness", "relaxed_for_C0_C1_topic_level_discovery_route_strict_for_BDBV_COVID_target_mismatch_and_clinical_claims")
            .put("routeLinkage", "legacy rails -> subtype hard gate -> active-domain guard -> canonical guard -> matrix shortcut -> final release/test locks")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Bundibugyo / filovirus runtime-stability closure",
        "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; subtype=${obj.optString("subtype", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; blocked_generic_targets=${obj.optJSONArray("blockedGenericTargets")?.length() ?: 0}.",
        "Runtime policy: ${obj.optString("runtimePolicy", "safe report transition")}",
        "Strictness: ${obj.optString("strictness", "C0/C1 relaxed; clinical/proof claims strict")}",
        "Boundary: route hardening and runtime stability only; no diagnosis, treatment, dosing, vaccine, efficacy, or validated discovery claim."
    )

    fun moduleFailure(stage: String, key: String, throwable: Throwable): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", "MODULE_RENDER_FAILURE_CAPTURED_NON_FATAL")
        .put("stage", stage)
        .put("module", key)
        .put("errorType", throwable::class.java.simpleName)
        .put("errorMessage", throwable.message.orEmpty().take(220))
        .put("reportTransitionSafe", true)
        .put("claimLimit", CLAIM_LIMIT)

    private fun isBundibugyoCompatibleTarget(handle: String): Boolean = when (handle.uppercase(Locale.US)) {
        // Placeholder for future cleaned BDBV capsules; none are currently bundled.
        "GSE_BDBV", "BDBV_COMPATIBLE_CAPSULE" -> true
        else -> false
    }

    private fun isFilovirusCompatibleTarget(handle: String): Boolean = when (handle.uppercase(Locale.US)) {
        "GSE45291" -> true
        else -> false
    }

    private fun collectCandidateHandles(report: JSONObject): List<String> {
        val out = linkedSetOf<String>()
        fun add(value: String) {
            val v = value.trim().uppercase(Locale.US)
            if (Regex("^(GSE\\d{3,8}|BDBV[_A-Z0-9-]*)\$").matches(v)) out.add(v)
        }
        fun addArray(array: JSONArray?) {
            if (array == null) return
            for (i in 0 until array.length()) {
                when (val item = array.opt(i)) {
                    is String -> add(item)
                    is JSONObject -> add(listOf(item.optString("handle"), item.optString("target"), item.optString("accession"), item.optString("id")).firstOrNull { it.isNotBlank() }.orEmpty())
                }
            }
        }
        listOf(
            "candidateHandleLedgerV21215", "terminalDiscoveryContinuationV21212", "injectedMetadataSeedPackV21216",
            "futureEvidenceLiteCorpusV2130", "verifiedMetadataClosurePackV2132", "finalDataClosureExecutionV2132",
            "matrixShortcutResolverV2124", "finalReleaseLockV21219"
        ).forEach { key ->
            val obj = report.optJSONObject(key) ?: return@forEach
            add(obj.optString("selectedReviewTarget"))
            add(obj.optString("selectedClosedTarget"))
            add(obj.optString("canonicalTarget"))
            add(obj.optString("handle"))
            addArray(obj.optJSONArray("candidateHandles"))
            addArray(obj.optJSONArray("allCandidateHandles"))
            addArray(obj.optJSONArray("handles"))
        }
        Regex("\\b(GSE\\d{3,8})\\b", RegexOption.IGNORE_CASE).findAll(report.toString()).forEach { add(it.value) }
        return out.toList()
    }

    private fun normalizedText(report: JSONObject): String {
        val curated = report.optJSONObject("curatedMetadataSeedLibraryV21211") ?: JSONObject()
        val search = report.optJSONObject("searchStabilityClosureV21217") ?: JSONObject()
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val focus = report.optJSONObject("studyFocusNormalizerV21282") ?: JSONObject()
        val selector = report.optJSONObject("domainSpecificHypothesisSelectorV2129") ?: JSONObject()
        val run = report.optJSONObject("runDecisionContractV2740") ?: report.optJSONObject("gtimRunDecisionContractV2740") ?: JSONObject()
        return listOf(
            topic.optString("rawInput"), topic.optString("normalizedTopic"),
            run.optString("primaryPhenotype"), run.optString("routeKey"),
            report.optString("researchTopic"), report.optString("normalizedTopic"), report.optString("topic"),
            focus.optString("studyFocus"), focus.optString("title"),
            selector.optString("studyFocus"), selector.optString("domainKey"), selector.optString("topResearchHypothesis"),
            ledger.optString("topicSubtype"), ledger.optString("domainKey"),
            curated.optString("selectedTopicFamily"), curated.optString("topicText"),
            search.optString("topicSubtype"), search.optString("domainKey")
        ).filter { it.isNotBlank() }.joinToString(" ").lowercase(Locale.US)
    }
}
