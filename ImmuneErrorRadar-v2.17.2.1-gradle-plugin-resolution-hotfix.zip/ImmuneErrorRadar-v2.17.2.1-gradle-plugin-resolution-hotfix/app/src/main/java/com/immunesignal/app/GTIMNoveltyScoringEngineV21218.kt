package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** v2.12.18 — novelty score separates known science from GTIM-added bridge. */
object GTIMNoveltyScoringEngineV21218 {
    const val VERSION: String = "2.12.18-novelty-scoring-engine"
    const val CLAIM_LIMIT: String = "novelty_score_is_hypothesis_routing_not_scientific_priority_claim"

    fun toJson(report: JSONObject): JSONObject {
        val text = report.toString().lowercase(Locale.US)
        val domain = report.optJSONObject("candidateHandleLedgerV21215")?.optString("domainKey") ?: report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainKey") ?: "unknown"
        val knownness = when {
            text.contains("kynurenine") && text.contains("depression") -> 4
            text.contains("covid") && (text.contains("interferon") || text.contains("il-6")) -> 3
            text.contains("allergy") && text.contains("type-2") -> 3
            text.contains("ebola") || text.contains("filovirus") -> 3
            else -> 5
        }
        val bridgeBonus = listOf("exposure", "metabolite", "microbiome", "neuroimmune", "endothelial", "sample provenance", "contradiction").count { text.contains(it) }.coerceAtMost(4)
        val dataPathBonus = if (report.optJSONObject("evidenceCapsuleBuilderV21218")?.optString("state")?.contains("CAPSULE") == true) 1 else 0
        val novelty = (knownness + bridgeBonus + dataPathBonus).coerceAtMost(10)
        val state = when {
            novelty >= 9 -> "HIGH_NOVELTY_TESTABLE_BRIDGE"
            novelty >= 7 -> "MODERATE_HIGH_NOVELTY_UNDERTESTED_BRIDGE"
            novelty >= 5 -> "MODERATE_NOVELTY_KNOWN_PARTS_NEW_ROUTING"
            else -> "LOW_NOVELTY_KNOWN_RELATION_REPACKAGED"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("domainKey", domain)
            .put("noveltyScore", novelty)
            .put("knownScience", knownScience(text))
            .put("gtimAdded", "Structured route: target/readout/dataset/provenance/capsule/contradiction/minimum-study gates in one dossier.")
            .put("untestedGap", mechanismGap(text))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Novelty scoring engine",
        "State: ${obj.optString("state", "UNKNOWN")}; novelty_score=${obj.optInt("noveltyScore", 0)}/10; domain=${obj.optString("domainKey", "unknown")}",
        "Known science: ${obj.optString("knownScience", "known components may exist")}",
        "GTIM added: ${obj.optString("gtimAdded", "structured evidence-routing dossier")}",
        "Untested gap: ${obj.optString("untestedGap", "requires direct dataset/capsule validation")}",
        "Boundary: novelty score is not a priority, therapeutic, patent, or discovery-proof claim."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "MODERATE_NOVELTY_KNOWN_PARTS_NEW_ROUTING", "HIGH_NOVELTY_TESTABLE_BRIDGE", CLAIM_LIMIT))

    private fun knownScience(text: String): String = when {
        text.contains("kynurenine") && text.contains("depression") -> "Depression-kynurenine/IDO1/KMO/neuroimmune components are already known; subgroup dataset routing is the possible value."
        text.contains("covid") -> "COVID/post-viral interferon and cytokine routes are already studied; severity/recovery capsule mapping is the possible value."
        text.contains("allergy") -> "Type-2/allergy/barrier biology is established; dataset-specific threshold testing is the possible value."
        text.contains("ebola") || text.contains("filovirus") -> "Filovirus host-response/cytokine/endothelial injury biology is studied; target-specific capsule routing is the possible value."
        else -> "Knownness unclear; treat novelty as provisional until literature and contradiction checks close."
    }

    private fun mechanismGap(text: String): String = when {
        text.contains("kynurenine") -> "Missing direct human subgroup capsule linking IDO1/KMO, kynurenine/tryptophan readouts, inflammatory tone, and depression comparator labels."
        text.contains("covid") -> "Missing verified sample-level severity/recovery comparator capsule connecting interferon timing and IL-6/TNF modules."
        text.contains("allergy") -> "Missing topic-fit capsule tying IgE/eosinophil/mast/epithelial readouts to comparator labels and barrier route."
        else -> "Missing direct dataset anchor with comparator labels, sample provenance, and contradiction-resistant readouts."
    }
}
