package com.immunesignal.app

import org.json.JSONObject

/** Onco-microbiome response-modifier lens; never a treatment predictor by itself. */
object GTIMOncoMicrobiomeImmunotherapyLensV21319 {
    const val VERSION: String = "2.13.19-onco-microbiome-immunotherapy-lens"
    const val CLAIM_LIMIT: String = "onco_microbiome_response_modifier_not_validated_treatment_predictor"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val applicable = active.contains("cancer") || report.optString("topic", "").lowercase().contains("checkpoint")
        return JSONObject()
            .put("version", VERSION)
            .put("state", "ONCO_MICROBIOME_IMMUNOTHERAPY_LENS_READY")
            .put("applicable", applicable)
            .put("checkpoint_inhibitor_response_modifier_hypothesis", applicable)
            .put("validated_predictor_claim_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }
}
