package com.immunesignal.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.12.11 — Curated metadata seed library.
 *
 * Small offline lookup accelerator for common GTIM runs. This layer prevents repeated
 * GEO/SOFT internet waste by checking a compact, topic-aware asset first. If no internal
 * seed fits, external handles already discovered by the old router are preserved as
 * pending curated seed candidates for later review. It never upgrades evidence.
 */
object GTIMCuratedMetadataSeedLibraryV21211 {
    const val VERSION: String = "2.12.11-curated-metadata-seed-library"
    const val ASSET_NAME: String = "gtim_curated_metadata_seed_library_v2.12.11.json"
    const val CLAIM_LIMIT: String = "curated_metadata_seed_lookup_only_no_evidence_upgrade"

    fun toJson(context: Context, report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val library = loadLibrary(context)
        val seeds = library.optJSONArray("seeds") ?: JSONArray()
        val topicText = topicText(report, technicalLines)
        val domainKey = GTIMDomainSpecificHypothesisSelectorV2129.build(report, technicalLines).domainKey
        val rawMatches = selectMatches(topicText, seeds)
        val matches = domainCompatibleMatches(rawMatches, domainKey)
        val demoted = domainMismatchedMatches(rawMatches, domainKey)
        val localHandles = (0 until seeds.length())
            .mapNotNull { seeds.optJSONObject(it)?.optString("handle")?.uppercase(Locale.US)?.takeIf { h -> h.isNotBlank() } }
            .toSet()
        val externalHandles = extractDatasetHandles(report.toString() + " " + technicalLines.joinToString(" "))
            .filterNot { it in localHandles }
            .take(6)
        val pending = if (matches.length() == 0) pendingSeedCandidates(externalHandles, topicText) else JSONArray()
        val best = matches.optJSONObject(0) ?: JSONObject()
        val state = when {
            matches.length() > 0 -> "LOCAL_CURATED_SEED_MATCH"
            demoted.length() > 0 -> "LOCAL_CURATED_SEED_DOMAIN_MISMATCH_DEMOTED_EXTERNAL_LOOKUP_REQUIRED"
            pending.length() > 0 -> "EXTERNAL_HANDLE_CAPTURED_PENDING_CURATED_REVIEW"
            else -> "NO_LOCAL_SEED_EXTERNAL_LOOKUP_REQUIRED"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("asset", ASSET_NAME)
            .put("state", state)
            .put("domainKey", domainKey)
            .put("topicText", topicText.take(500))
            .put("localSeedMatches", matches)
            .put("domainMismatchedSeedMatches", demoted)
            .put("selectedHandle", best.optString("handle"))
            .put("selectedTopicFamily", best.optString("topic_family"))
            .put("metadataReadiness", best.optString("readiness", if (pending.length() > 0) "pending_curated_review" else "external_lookup_required"))
            .put("candidateHandles", JSONArray(extractDatasetHandles(report.toString() + " " + technicalLines.joinToString(" ")).take(12)))
            .put("candidateHandleCount", extractDatasetHandles(report.toString() + " " + technicalLines.joinToString(" ")).size)
            .put("verifiedCapsuleSourceCount", GTIMReportConsistencyGateV2121.build(report, technicalLines).verifiedMatrixFiles)
            .put("pendingCuratedSeedCandidates", pending)
            .put("externalFallbackPolicy", "if_no_local_seed_then_external_lookup_then_store_new_important_handle_as_pending_curated_seed")
            .put("seedDomainConsistencyPolicy", "selectedSeed.topicFamily must match domainSpecificRoute; mismatches are demoted to cross-domain background/contradiction only")
            .put("usage", "readiness_accelerator_only_not_dataset_acceptance")
            .put("nextAction", nextAction(state, best, pending))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(seedJson: JSONObject): List<String> {
        val matches = seedJson.optJSONArray("localSeedMatches") ?: JSONArray()
        val pending = seedJson.optJSONArray("pendingCuratedSeedCandidates") ?: JSONArray()
        val selected = seedJson.optString("selectedHandle").ifBlank { "none" }
        val family = seedJson.optString("selectedTopicFamily").ifBlank { "none" }
        val state = seedJson.optString("state", "UNKNOWN")
        val count = seedJson.optInt("candidateHandleCount", 0)
        val demotedCount = seedJson.optJSONArray("domainMismatchedSeedMatches")?.length() ?: 0
        return listOf(
            "Curated metadata seed library",
            "State: $state; selected seed=$selected; topic family=$family; local matches=${matches.length()}; candidate handles=$count; verified_capsule_source_count=${seedJson.optInt("verifiedCapsuleSourceCount", 0)}; demoted_cross_domain_seeds=$demotedCount.",
            "Use: offline metadata readiness accelerator with domain consistency; mismatched seeds are background/contradiction only, not selected targets.",
            "Next: ${seedJson.optString("nextAction", "run external lookup and store only important handles as pending curated seeds").takeClean(260)}",
            "Boundary: curated seeds and pending seeds do not prove mechanism, gene/pathway signal, diagnosis, treatment, or efficacy."
        ) + if (pending.length() > 0) listOf("Pending seed candidates stored for review: ${jsonHandles(pending).joinToString(", ").ifBlank { "none" }}") else emptyList()
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        ASSET_NAME,
        "LOCAL_CURATED_SEED_MATCH",
        "EXTERNAL_HANDLE_CAPTURED_PENDING_CURATED_REVIEW",
        "if_no_local_seed_then_external_lookup_then_store_new_important_handle_as_pending_curated_seed",
        "selectedSeed.topicFamily must match domainSpecificRoute",
        "LOCAL_CURATED_SEED_DOMAIN_MISMATCH_DEMOTED_EXTERNAL_LOOKUP_REQUIRED",
        CLAIM_LIMIT
    ))

    private fun loadLibrary(context: Context): JSONObject = try {
        context.assets.open(ASSET_NAME).bufferedReader(Charsets.UTF_8).use { JSONObject(it.readText()) }
    } catch (_: Exception) {
        JSONObject().put("version", VERSION).put("seeds", JSONArray())
    }

    private fun selectMatches(topicText: String, seeds: JSONArray): JSONArray {
        val normalized = topicText.lowercase(Locale.US)
        val scored = mutableListOf<Pair<Int, JSONObject>>()
        for (i in 0 until seeds.length()) {
            val seed = seeds.optJSONObject(i) ?: continue
            val terms = jsonStrings(seed.optJSONArray("matched_topics")) + jsonStrings(seed.optJSONArray("route_keywords")) + seed.optString("topic_family")
            val score = terms.distinctBy { it.lowercase(Locale.US) }.count { term ->
                term.isNotBlank() && normalized.contains(term.lowercase(Locale.US))
            }
            val handleScore = if (seed.optString("handle").isNotBlank() && normalized.contains(seed.optString("handle").lowercase(Locale.US))) 5 else 0
            val total = score + handleScore
            if (total > 0) scored += total to seed.put("matchScore", total)
        }
        val out = JSONArray()
        scored.sortedByDescending { it.first }.take(4).forEach { out.put(it.second) }
        return out
    }


    private fun domainCompatibleMatches(rawMatches: JSONArray, domainKey: String): JSONArray {
        val out = JSONArray()
        for (i in 0 until rawMatches.length()) {
            val seed = rawMatches.optJSONObject(i) ?: continue
            if (familyMatches(domainKey, seed.optString("topic_family"))) out.put(seed)
        }
        return out
    }

    private fun domainMismatchedMatches(rawMatches: JSONArray, domainKey: String): JSONArray {
        val out = JSONArray()
        for (i in 0 until rawMatches.length()) {
            val seed = rawMatches.optJSONObject(i) ?: continue
            if (!familyMatches(domainKey, seed.optString("topic_family"))) {
                out.put(JSONObject()
                    .put("handle", seed.optString("handle"))
                    .put("topic_family", seed.optString("topic_family"))
                    .put("matchScore", seed.optInt("matchScore", 0))
                    .put("demotionReason", "selectedSeed.topicFamily does not match domainSpecificRoute"))
            }
        }
        return out
    }

    private fun familyMatches(domainKey: String, family: String): Boolean {
        val d = domainKey.lowercase(Locale.US)
        val f = family.lowercase(Locale.US)
        return when {
            d.contains("depression_kynurenine") -> f.contains("depression_kynurenine")
            d.contains("viral_interferon") -> f.contains("viral") || f.contains("filovirus") || f.contains("hantavirus")
            d.contains("allergy_type2") -> f.contains("allergy_type2")
            d.contains("metabolic") -> f.contains("metabolic")
            d.contains("environmental") -> f.contains("environmental") || f.contains("xenobiotic")
            else -> true
        }
    }

    private fun pendingSeedCandidates(handles: List<String>, topicText: String): JSONArray {
        val out = JSONArray()
        handles.take(6).forEach { handle ->
            out.put(
                JSONObject()
                    .put("handle", handle)
                    .put("handle_type", handleType(handle))
                    .put("topic_family_guess", GTIMStudyFocusNormalizerV21282.build(topicText).domain)
                    .put("metadata_readiness", "pending_curated_review")
                    .put("store_policy", "store_if_topic_fit_or_comparator_or_matrix_hint_is_confirmed")
                    .put("claim_limit", "pending_seed_only_no_evidence_upgrade")
            )
        }
        return out
    }

    private fun nextAction(state: String, best: JSONObject, pending: JSONArray): String = when (state) {
        "LOCAL_CURATED_SEED_MATCH" -> "Use ${best.optString("handle")} as a lookup seed only; verify topic-fit, comparator labels, tissue/species, sample linkage, and matrix/capsule availability before any DGE or pathway claim."
        "EXTERNAL_HANDLE_CAPTURED_PENDING_CURATED_REVIEW" -> "Review captured external handle(s), keep only important topic-fit handles in the local pending seed ledger, then require SOFT/comparator/matrix confirmation."
        else -> "Run external GEO/SRA/Europe PMC/OpenAlex lookup; store only important new handles as pending curated seeds after topic-fit and metadata readiness checks."
    }

    private fun topicText(report: JSONObject, technicalLines: List<String>): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val contract = report.optJSONObject("runDecisionContractV2740") ?: report.optJSONObject("gtimRunDecisionContractV2740") ?: JSONObject()
        val focus = report.optJSONObject("studyFocusNormalizerV21282") ?: JSONObject()
        val card = report.optJSONObject("studyResultCardV2126") ?: JSONObject()
        return listOf(
            topic.optString("normalizedTopic"),
            topic.optString("rawInput"),
            contract.optString("primaryPhenotype"),
            contract.optString("routeKey"),
            focus.optString("title"),
            card.optString("topic"),
            technicalLines.firstOrNull { it.startsWith("Research topic:") }?.removePrefix("Research topic:")?.trim().orEmpty()
        ).filter { it.isNotBlank() }.joinToString(" ").ifBlank { report.optString("topic", "immune research question") }
    }

    private fun extractDatasetHandles(text: String): List<String> = Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|SRR\\d+|PRJNA\\d+|PRJEB\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+)\\b", RegexOption.IGNORE_CASE)
        .findAll(text)
        .map { it.value.uppercase(Locale.US) }
        .distinct()
        .toList()

    private fun handleType(handle: String): String = when {
        handle.startsWith("GSE", true) -> "GSE"
        handle.startsWith("SRP", true) -> "SRP"
        handle.startsWith("SRR", true) -> "SRR"
        handle.startsWith("PRJNA", true) -> "PRJNA"
        handle.startsWith("PRJEB", true) -> "PRJEB"
        handle.startsWith("SDY", true) -> "SDY"
        handle.startsWith("E-MTAB", true) -> "E-MTAB"
        else -> "DATASET_HANDLE"
    }

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx ->
        array.optString(idx).takeIf { it.isNotBlank() }
    }

    private fun jsonHandles(array: JSONArray): List<String> = (0 until array.length()).mapNotNull { idx ->
        array.optJSONObject(idx)?.optString("handle")?.takeIf { it.isNotBlank() }
    }

    private fun String.takeClean(max: Int): String {
        val clean = replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= max) clean else clean.take(max).trimEnd()
    }
}
