package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** NETosis / extracellular trap immunity research lens. */
object GTIMNETosisExtracellularImmunityEngineV21319 {
    const val VERSION: String = "2.13.19-netosis-extracellular-immunity-engine"
    const val STATE_READY: String = "NETOSIS_EXTRACELLULAR_IMMUNITY_LENS_READY"
    const val CLAIM_LIMIT: String = "NET_signal_not_diagnosis_not_patient_action"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("NETosis_role", "extracellular_DNA_trap_damage_or_defense_axis")
        .put("candidate_markers", JSONArray(listOf("cell_free_DNA", "citrullinated_histone_H3", "MPO_DNA_complex", "neutrophil_elastase")))
        .put("diagnosis_claim_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
