package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.12.18 — scorecard for practical value, novelty, and application readiness. */
object GTIMTenTenResearchScorecardV21218 {
    const val VERSION: String = "2.12.18-ten-ten-research-scorecard"
    const val CLAIM_LIMIT: String = "scorecard_guides_readiness_not_scientific_truth"

    fun toJson(report: JSONObject): JSONObject {
        val capsule = report.optJSONObject("evidenceCapsuleBuilderV21218") ?: JSONObject()
        val novelty = report.optJSONObject("noveltyScoringEngineV21218") ?: JSONObject()
        val feasibility = report.optJSONObject("studyFeasibilityScoreV21218") ?: JSONObject()
        val contradiction = report.optJSONObject("contradictionSearchEngineV21218") ?: JSONObject()
        val protocol = report.optJSONObject("minimumViableStudyProtocolV21218") ?: JSONObject()
        val practical = (capsule.optInt("capsuleScore", 0) + if (contradiction.optInt("unresolvedConflictCount", 3) <= 2) 1 else 0).coerceAtMost(10)
        val originality = novelty.optInt("noveltyScore", 0).coerceAtMost(10)
        val applied = (feasibility.optInt("feasibilityScore", 0) + if (protocol.optString("state").contains("READY")) 1 else 0).coerceAtMost(10)
        val gaps = JSONArray()
        if (practical < 10) gaps.put("Close comparator, sample-provenance, matrix/capsule, and contradiction gates to reach practical value 10/10.")
        if (originality < 10) gaps.put("Add direct evidence of under-tested cross-domain relationship and novelty gap to reach originality 10/10.")
        if (applied < 10) gaps.put("Close feasibility, data availability, and minimum-study execution details to reach applied study 10/10.")
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (practical == 10 && originality == 10 && applied == 10) "TEN_TEN_RESEARCH_READY" else "TEN_TEN_PATHWAY_READY_GAPS_VISIBLE")
            .put("practicalResearchValue", practical)
            .put("scientificOriginality", originality)
            .put("appliedStudyReadiness", applied)
            .put("remainingGaps", gaps)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "10/10 research scorecard",
        "State: ${obj.optString("state", "UNKNOWN")}; practical_value=${obj.optInt("practicalResearchValue", 0)}/10; originality=${obj.optInt("scientificOriginality", 0)}/10; applied_study=${obj.optInt("appliedStudyReadiness", 0)}/10.",
        "Rule: the app may target 10/10, but scores stay capped until real capsule, novelty, contradiction, and minimum-study gates close.",
        "Remaining gaps are shown instead of inflated scores.",
        "Boundary: scorecard is a readiness dashboard, not proof of discovery, clinical validity, or publishability."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "TEN_TEN_PATHWAY_READY_GAPS_VISIBLE", "TEN_TEN_RESEARCH_READY", CLAIM_LIMIT))
}
