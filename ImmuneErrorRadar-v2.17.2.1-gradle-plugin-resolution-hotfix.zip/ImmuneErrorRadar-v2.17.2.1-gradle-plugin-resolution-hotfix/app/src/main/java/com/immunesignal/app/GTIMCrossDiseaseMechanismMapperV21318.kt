package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Maps one immune mechanism across diseases without upgrading it to proof. */
object GTIMCrossDiseaseMechanismMapperV21318 {
    const val VERSION: String = "2.13.18-cross-disease-mechanism-mapper"
    const val CLAIM_LIMIT: String = "cross_disease_mapping_is_hypothesis_bridge_not_causal_proof"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val states = GTIMImmunePolarityClassifierV21317.classify(active)
        val connected = connectedDomains(active, states)
        val shared = sharedMechanismAxis(active, states)
        return JSONObject()
            .put("version", VERSION)
            .put("active_domain", active)
            .put("immune_decision_states", JSONArray(states))
            .put("shared_mechanism_axis", shared)
            .put("connected_disease_domains", JSONArray(connected))
            .put("cross_disease_level", if (connected.size >= 3) "M1_CROSS_DISEASE_MECHANISM_CANDIDATE" else "M0_LOCAL_MECHANISM_ONLY")
            .put("required_evidence", JSONArray(listOf("same-axis capsule signal", "domain-specific comparator", "contradiction check", "no clinical proof claim")))
            .put("falsifier", "downgrade if the same mechanism does not appear across compatible disease capsules or reverses direction under contradiction review")
            .put("claim_limit", CLAIM_LIMIT)
    }

    private fun sharedMechanismAxis(active: String, states: List<String>): String = when {
        states.any { it.contains("tolerance_failure") } -> "FOXP3/Treg peripheral tolerance failure versus generic inflammation"
        states.any { it.contains("trained") } || active == "immune_age_longevity" -> "trained innate immunity / HSPC epigenetic memory / immune age drift"
        states.any { it.contains("exhaustion") } -> "chronic activation plus exhaustion or pathogen-persistence conflict"
        states.any { it.contains("tumor") } -> "tolerance excess / tumor immune escape / checkpoint context"
        states.any { it.contains("repair") } -> "tissue repair or resolution failure across inflammatory states"
        else -> "open immune reprogramming axis"
    }

    private fun connectedDomains(active: String, states: List<String>): List<String> {
        val base = linkedSetOf(active)
        when {
            active == "immune_age_longevity" -> base += listOf("inflammation_resolution", "metabolic_inflammation", "oncology_tumor_microenvironment", "hiv_aids_immune_activation", "viral_interferon_cytokine")
            states.any { it.contains("tolerance_failure") } -> base += listOf("rheumatoid_autoimmune_synovial_inflammation", "allergy_type2_barrier", "metabolic_inflammation")
            states.any { it.contains("trained") } -> base += listOf("inflammation_resolution", "viral_interferon_cytokine", "filovirus_viral_host_response", "metabolic_inflammation")
            states.any { it.contains("exhaustion") } -> base += listOf("hiv_aids_immune_activation", "oncology_tumor_microenvironment", "viral_interferon_cytokine")
            states.any { it.contains("tumor") } -> base += listOf("oncology_tumor_microenvironment", "hiv_aids_immune_activation", "rheumatoid_autoimmune_synovial_inflammation")
            else -> base += listOf("inflammation_resolution", "metabolic_inflammation")
        }
        return base.filter { it.isNotBlank() }.toList()
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Cross-disease mechanism mapper",
            "Shared mechanism axis: ${obj.optString("shared_mechanism_axis")}",
            "Connected diseases/domains: ${obj.optJSONArray("connected_disease_domains") ?: JSONArray()}",
            "Cross-disease level: ${obj.optString("cross_disease_level")}",
            "Cross-disease falsifier: ${obj.optString("falsifier")}",
            "Boundary: ${obj.optString("claim_limit")}."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "shared_mechanism_axis",
        "connected_disease_domains",
        "M1_CROSS_DISEASE_MECHANISM_CANDIDATE",
        CLAIM_LIMIT
    ))
}
