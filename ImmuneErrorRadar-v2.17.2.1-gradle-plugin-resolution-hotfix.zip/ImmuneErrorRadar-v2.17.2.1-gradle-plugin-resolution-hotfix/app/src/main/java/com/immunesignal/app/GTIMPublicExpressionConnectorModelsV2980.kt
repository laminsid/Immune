package com.immunesignal.app

/**
 * v2.9.8 — Public expression connector and external capsule models.
 *
 * These models keep the app lightweight. Public sources and imported capsules are
 * treated as route/capsule evidence, not as internal DGE execution. Heavy matrices
 * remain outside the Android runtime.
 */
data class GTIMPublicExpressionSourceRouteV2980(
    val sourceId: String,
    val state: String,
    val queryHandle: String,
    val outputKind: String,
    val reason: String,
    val line: String
)

data class GTIMPublicExpressionSourceRegistryReportV2980(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val routes: List<GTIMPublicExpressionSourceRouteV2980>,
    val preferredRoute: String,
    val line: String,
    val boundaryLine: String
)

data class GTIMExternalEvidenceCapsuleGeneV2980(
    val gene: String,
    val direction: String,
    val log2fc: Double?,
    val padj: Double?,
    val rank: Int,
    val axis: String
)

data class GTIMExternalEvidenceCapsulePathwayV2980(
    val pathway: String,
    val direction: String,
    val score: Double?,
    val supportGenes: List<String>
)

data class GTIMExternalEvidenceCapsuleImportReportV2980(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val datasetId: String,
    val contrastId: String,
    val source: String,
    val topGenes: List<GTIMExternalEvidenceCapsuleGeneV2980>,
    val pathways: List<GTIMExternalEvidenceCapsulePathwayV2980>,
    val provenanceHashes: List<String>,
    val claimLimit: String,
    val blockers: List<String>,
    val line: String,
    val boundaryLine: String
)

data class GTIMLearningCacheRecordV2980(
    val queryKey: String,
    val targetId: String,
    val routeState: String,
    val acceptedForReuse: Boolean,
    val rejectionOrLimit: String,
    val storedFields: List<String>
)

data class GTIMLearningCacheReportV2980(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val record: GTIMLearningCacheRecordV2980,
    val line: String,
    val boundaryLine: String
)
