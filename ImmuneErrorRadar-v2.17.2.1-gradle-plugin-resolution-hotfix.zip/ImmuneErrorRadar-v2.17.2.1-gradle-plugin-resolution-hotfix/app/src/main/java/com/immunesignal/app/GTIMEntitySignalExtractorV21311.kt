package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

object GTIMEntitySignalExtractorV21311 {
    fun contextText(report: JSONObject): String {
        val parts = mutableListOf<String>()
        listOf("researchTopic", "normalizedTopic", "topic", "query", "rawInput", "lastUserQuery").forEach { key ->
            val v = report.optString(key)
            if (v.isNotBlank()) parts += v
        }
        val objectKeys = listOf(
            "topicCapture", "studyFocusNormalizerV21282", "domainSpecificHypothesisSelectorV2129",
            "candidateHandleLedgerV21215", "curatedMetadataSeedLibraryV21211", "searchStabilityClosureV21217",
            "runDecisionContractV2740", "gtimRunDecisionContractV2740", "futureEvidenceLiteCorpusV2130",
            "expandedDiseaseFutureCorpusV2131", "verifiedMetadataClosurePackV2132", "finalDataClosureExecutionV2132"
        )
        objectKeys.forEach { key ->
            val obj = report.optJSONObject(key) ?: return@forEach
            obj.keys().forEach { k ->
                when (val value = obj.opt(k)) {
                    is String -> if (value.length < 1200) parts += value
                    is JSONArray -> parts += value.toString()
                }
            }
        }
        return parts.joinToString(" ").lowercase(Locale.US)
    }

    fun entities(report: JSONObject): List<String> {
        val text = contextText(report)
        val out = linkedSetOf<String>()
        fun addIf(token: String, vararg patterns: String) {
            if (patterns.any { text.contains(it.lowercase(Locale.US)) }) out.add(token)
        }
        addIf("BDBV", "bundibugyo", "bdbv", "bundibugyo ebolavirus", "bundibugyo virus", "ebola bundibugyo")
        addIf("EBOLA", "ebola", "ebolavirus", "viral hemorrhagic fever", "hemorrhagic fever")
        addIf("FILOVIRUS", "filovirus", "filoviridae", "ebolavirus", "marburg")
        addIf("COVID", "covid", "sars-cov-2", "post-covid", "long covid", "recurrent covid")
        addIf("VIRAL_HOST_RESPONSE", "interferon", "ifn", "cytokine", "host-response", "host response", "il-6", "tnf")
        addIf("KYNURENINE", "kynurenine", "ido1", "kmo", "tryptophan", "quinolinic", "kynurenic")
        addIf("DEPRESSION", "depression", "mdd", "major depression", "mood")
        addIf("ALLERGY_TYPE2", "allergy", "ige", "eosinophil", "mast cell", "il-4", "il-5", "il-13", "type-2", "type 2")
        addIf("CANCER_TME", "cancer", "tumor", "tumour", "pd-1", "pd-l1", "ctla4", "tme")
        addIf("METABOLIC_INFLAMMATION", "metabolic", "diabetes", "obesity", "insulin", "metaflammation")
        return out.toList()
    }

    fun handles(report: JSONObject): List<String> {
        val out = linkedSetOf<String>()
        fun add(value: String) {
            val v = value.trim().uppercase(Locale.US)
            if (Regex("^(GSE\\d{3,8}|PMID:\\d+|BDBV[_A-Z0-9-]*)$").matches(v)) out.add(v)
        }
        fun addArray(array: JSONArray?) {
            if (array == null) return
            for (i in 0 until array.length()) {
                when (val item = array.opt(i)) {
                    is String -> add(item)
                    is JSONObject -> listOf("handle", "target", "accession", "id", "selectedClosedTarget", "selectedReviewTarget", "canonicalTarget").forEach { add(item.optString(it)) }
                }
            }
        }
        val keys = listOf(
            "candidateHandleLedgerV21215", "terminalDiscoveryContinuationV21212", "injectedMetadataSeedPackV21216",
            "futureEvidenceLiteCorpusV2130", "verifiedMetadataClosurePackV2132", "finalDataClosureExecutionV2132",
            "matrixShortcutResolverV2124", "activeDomainConsistencyGuardV2134", "canonicalFinalSurfaceGuardV2135",
            "bundibugyoRuntimeStabilityClosureV213105", "finalBundibugyoSearchRuntimeClosureV213106"
        )
        keys.forEach { key ->
            val obj = report.optJSONObject(key) ?: return@forEach
            listOf("selectedReviewTarget", "selectedClosedTarget", "canonicalTarget", "canonicalFinalTarget", "handle", "target").forEach { add(obj.optString(it)) }
            listOf("candidateHandles", "allCandidateHandles", "handles", "blockedGenericTargets", "blockedCovidTargets").forEach { addArray(obj.optJSONArray(it)) }
        }
        Regex("\\b(GSE\\d{3,8}|PMID:\\d+|BDBV[_A-Z0-9-]*)\\b", RegexOption.IGNORE_CASE).findAll(report.toString()).forEach { add(it.value) }
        return out.toList()
    }
}
