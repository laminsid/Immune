package com.immunesignal.app

// v2.11.1 — Microbial Reversal Engine models.
// These models keep radical microbial/function-reversal ideas structured, bounded,
// and connected to root-cause, data harmonization, and dossier reporting.

data class GTIMMicrobialDamageMechanismV2111(
    val mechanismId: String,
    val damageClass: String,
    val harmfulMechanism: String,
    val topicLink: String,
    val confidenceState: String,
    val line: String
)

data class GTIMMicrobialCounterFunctionV2111(
    val functionId: String,
    val mechanismId: String,
    val counterFunctionClass: String,
    val reversalLogic: String,
    val requiredEvidence: List<String>,
    val falsificationTests: List<String>,
    val safetyBoundary: String,
    val line: String
)

data class GTIMMicrobialReversalCandidateV2111(
    val candidateId: String,
    val candidateClass: String,
    val sourceFunctionId: String,
    val hypotheticalRole: String,
    val evidenceRank: String,
    val missingEvidence: List<String>,
    val biosafetyRisks: List<String>,
    val claimLimit: String,
    val line: String
)

data class GTIMMicrobialReversalStudyPlanV2111(
    val planId: String,
    val candidateId: String,
    val hypothesis: String,
    val minimumEvidencePackage: List<String>,
    val expectedBiomarkers: List<String>,
    val decisiveTests: List<String>,
    val killCriteria: List<String>,
    val line: String
)

data class GTIMMicrobialReversalReportV2111(
    val active: Boolean,
    val version: String,
    val state: String,
    val philosophy: String,
    val damageMechanisms: List<GTIMMicrobialDamageMechanismV2111>,
    val counterFunctions: List<GTIMMicrobialCounterFunctionV2111>,
    val candidateRoutes: List<GTIMMicrobialReversalCandidateV2111>,
    val studyPlans: List<GTIMMicrobialReversalStudyPlanV2111>,
    val evidenceLadder: List<String>,
    val integrationState: String,
    val boundaryLine: String,
    val line: String
) {
    companion object {
        fun empty(): GTIMMicrobialReversalReportV2111 = GTIMMicrobialReversalReportV2111(
            active = false,
            version = GTIMMicrobialReversalEngineV2111.VERSION,
            state = "MICROBIAL_REVERSAL_NOT_EVALUATED",
            philosophy = GTIMMicrobialReversalEngineV2111.PHILOSOPHY,
            damageMechanisms = emptyList(),
            counterFunctions = emptyList(),
            candidateRoutes = emptyList(),
            studyPlans = emptyList(),
            evidenceLadder = GTIMMicrobialReversalEvidenceLadderV2111.LADDER,
            integrationState = "NOT_EVALUATED",
            boundaryLine = GTIMMicrobialReversalEngineV2111.BOUNDARY,
            line = "Microbial reversal engine: not evaluated."
        )
    }
}
