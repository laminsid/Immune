package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BiomarkerInput(
    val crpMgL: Double?,
    val esrMmH: Double?,
    val totalIgeIuMl: Double?,
    val eosinophilsCellsUl: Double?,
    val il6PgMl: Double?,
    val tnfAlphaPgMl: Double?,
    val il10PgMl: Double?,
    val ferritinNgMl: Double?,
    val histamine: Double?
)

data class SymptomInput(
    val allergyLike: Boolean,
    val jointInflammatoryLike: Boolean,
    val breathingDanger: Boolean,
    val confusionOrFainting: Boolean,
    val rapidSwelling: Boolean
)

data class CauseContextInput(
    val stressToday0To10: Int?,
    val stressLast7Days0To10: Int?,
    val sleepQuality0To10: Int?,
    val majorEmotionalEvent: Boolean,
    val panicOrRapidBreathing: Boolean,
    val pollenDustExposure: Boolean,
    val coldAirExposure: Boolean,
    val smokeFragranceExposure: Boolean,
    val moldOrPetsExposure: Boolean,
    val recentInfectionLike: Boolean,
    val longSittingHours: Int?,
    val heavyLifting: Boolean,
    val suddenTwist: Boolean,
    val backOrDiscPain: Boolean,
    val radiatingLegPain: Boolean,
    val numbnessOrWeakness: Boolean,
    val painWorseWithStress: Boolean,
    val notes: String?
)



data class AgingAutonomicInput(
    val infectionRecoverySlow0To10: Int?,
    val frequentInfections: Boolean,
    val fatigueAfterStress0To10: Int?,
    val exerciseRecovery0To10: Int?,
    val slowWoundHealing: Boolean,
    val allergyIntensity0To10: Int?,
    val foodSensitivityEpisode: Boolean,
    val seasonalPattern: Boolean,
    val allergyAfterStress: Boolean,
    val allergyAfterPoorSleep: Boolean,
    val systolicBpMmHg: Int?,
    val diastolicBpMmHg: Int?,
    val restingPulseBpm: Int?,
    val dizzinessOnStanding: Boolean,
    val faintnessDuringAllergy: Boolean,
    val flushingOrWarmth: Boolean,
    val coldHandsFeet: Boolean
)



data class GutNutritionHormoneInput(
    val refluxHeartburn0To10: Int?,
    val bloatingDyspepsia0To10: Int?,
    val suspectedLowAcidPattern: Boolean,
    val ppiOrAntacidUse: Boolean,
    val knownGastritisOrHpylori: Boolean,
    val mealTimingIrregular: Boolean,
    val dietDiversity0To10: Int?,
    val proteinIntakeEstimateG: Double?,
    val bodyWeightKg: Double?,
    val muscleMassLossOrLow: Boolean,
    val strengthTraining: Boolean,
    val appetiteLow: Boolean,
    val testosteroneNgDl: Double?,
    val lowLibidoOrLowMorningDrive: Boolean,
    val lowMorningEnergy: Boolean,
    val notes: String?
)


data class CaseInput(
    val id: String,
    val createdAtMillis: Long,
    val label: String,
    val age: Int?,
    val temperatureC: Double?,
    val biomarkers: BiomarkerInput,
    val symptoms: SymptomInput,
    val causeContext: CauseContextInput,
    val agingAutonomic: AgingAutonomicInput,
    val gutNutritionHormone: GutNutritionHormoneInput
)

data class ImmuneStateVector(
    val type2AllergicAxis: Int,
    val mastCellAxis: Int,
    val eosinophilAxis: Int,
    val tnfIl6InflammatoryAxis: Int,
    val hyperInflammatoryAxis: Int,
    val regulatoryBrakeWeakness: Int,
    val systemicDamageSignal: Int,
    val psychoneuroimmuneStressAxis: Int,
    val mechanicalLoadAxis: Int,
    val neuroMuscularGuardingAxis: Int,
    val immunosenescenceAxis: Int,
    val inflammagingAxis: Int,
    val immuneResponsivenessAxis: Int,
    val sympatheticPressureUpAxis: Int,
    val histaminePressureDownAxis: Int,
    val bloodPressureInstabilityAxis: Int,
    val gastricAcidDysregulationAxis: Int,
    val gutBarrierMicrobiomeAxis: Int,
    val nutritionProteinAxis: Int,
    val muscleMassReserveAxis: Int,
    val testosteroneImmuneModulationAxis: Int,
    val dominantCompartment: String
)

data class CauseEvidenceLedger(
    val temporalEvidence: String,
    val biologicalPlausibility: String,
    val repeatability: String,
    val caution: String
)

data class CausalOriginMap(
    val dominantDriver: String,
    val allergenExposure: Int,
    val psychologicalStress: Int,
    val sleepRecoveryDebt: Int,
    val infectionTrigger: Int,
    val mechanicalLoad: Int,
    val neuroMuscularGuarding: Int,
    val mixedUncertain: Int,
    val interpretation: String,
    val ledger: CauseEvidenceLedger
)



data class AgingAutonomicMap(
    val immunosenescenceAxis: Int,
    val inflammagingAxis: Int,
    val immuneResponsivenessAxis: Int,
    val allergyReactivityIndex: Int,
    val agingLoadIndex: Int,
    val resilienceIndex: Int,
    val sympatheticPressureUp: Int,
    val histaminePressureDown: Int,
    val bloodPressureInstability: Int,
    val dominantPattern: String,
    val researchInterpretation: String,
    val competingHypotheses: List<String>
)


data class GutNutritionHormoneMap(
    val gastricAcidDysregulationAxis: Int,
    val gutBarrierMicrobiomeAxis: Int,
    val nutritionProteinAxis: Int,
    val muscleMassReserveAxis: Int,
    val testosteroneImmuneModulationAxis: Int,
    val metabolicStressAxis: Int,
    val dominantPattern: String,
    val researchInterpretation: String,
    val competingHypotheses: List<String>
)

data class SignalResult(
    val severity: String,
    val classifierLabel: String,
    val pattern: String,
    val signalStrengthPercent: Int,
    val signalStrengthLabel: String,
    val dataQualityPercent: Int,
    val evidenceCompleteness: String,
    val immuneStateVector: ImmuneStateVector,
    val causalOriginMap: CausalOriginMap,
    val agingAutonomicMap: AgingAutonomicMap,
    val gutNutritionHormoneMap: GutNutritionHormoneMap,
    val evidence: List<String>,
    val causeEvidence: List<String>,
    val researchHypotheses: List<String>,
    val discussionPrompts: List<String>,
    val safeActions: List<String>,
    val notProven: List<String>
)

data class CaseRecord(
    val input: CaseInput,
    val result: SignalResult
)

object JsonCodec {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    fun caseToJson(record: CaseRecord): JSONObject {
        val input = record.input
        val b = input.biomarkers
        val s = input.symptoms
        val c = input.causeContext
        val vector = record.result.immuneStateVector
        val cause = record.result.causalOriginMap
        val aging = record.result.agingAutonomicMap
        val gut = record.result.gutNutritionHormoneMap
        val ledger = cause.ledger
        return JSONObject()
            .put("schemaVersion", 7)
            .put("productMode", "Immu DZ Research Mode")
            .put("id", input.id)
            .put("createdAtMillis", input.createdAtMillis)
            .put("createdAtText", dateFormat.format(Date(input.createdAtMillis)))
            .put("label", input.label)
            .put("age", input.age)
            .put("temperatureC", input.temperatureC)
            .put("biomarkers", JSONObject()
                .put("crpMgL", b.crpMgL)
                .put("esrMmH", b.esrMmH)
                .put("totalIgeIuMl", b.totalIgeIuMl)
                .put("eosinophilsCellsUl", b.eosinophilsCellsUl)
                .put("il6PgMl", b.il6PgMl)
                .put("tnfAlphaPgMl", b.tnfAlphaPgMl)
                .put("il10PgMl", b.il10PgMl)
                .put("ferritinNgMl", b.ferritinNgMl)
                .put("histamine", b.histamine))
            .put("symptoms", JSONObject()
                .put("allergyLike", s.allergyLike)
                .put("jointInflammatoryLike", s.jointInflammatoryLike)
                .put("breathingDanger", s.breathingDanger)
                .put("confusionOrFainting", s.confusionOrFainting)
                .put("rapidSwelling", s.rapidSwelling))
            .put("causeContext", JSONObject()
                .put("stressToday0To10", c.stressToday0To10)
                .put("stressLast7Days0To10", c.stressLast7Days0To10)
                .put("sleepQuality0To10", c.sleepQuality0To10)
                .put("majorEmotionalEvent", c.majorEmotionalEvent)
                .put("panicOrRapidBreathing", c.panicOrRapidBreathing)
                .put("pollenDustExposure", c.pollenDustExposure)
                .put("coldAirExposure", c.coldAirExposure)
                .put("smokeFragranceExposure", c.smokeFragranceExposure)
                .put("moldOrPetsExposure", c.moldOrPetsExposure)
                .put("recentInfectionLike", c.recentInfectionLike)
                .put("longSittingHours", c.longSittingHours)
                .put("heavyLifting", c.heavyLifting)
                .put("suddenTwist", c.suddenTwist)
                .put("backOrDiscPain", c.backOrDiscPain)
                .put("radiatingLegPain", c.radiatingLegPain)
                .put("numbnessOrWeakness", c.numbnessOrWeakness)
                .put("painWorseWithStress", c.painWorseWithStress)
                .put("notes", c.notes))
            .put("agingAutonomic", JSONObject()
                .put("infectionRecoverySlow0To10", input.agingAutonomic.infectionRecoverySlow0To10)
                .put("frequentInfections", input.agingAutonomic.frequentInfections)
                .put("fatigueAfterStress0To10", input.agingAutonomic.fatigueAfterStress0To10)
                .put("exerciseRecovery0To10", input.agingAutonomic.exerciseRecovery0To10)
                .put("slowWoundHealing", input.agingAutonomic.slowWoundHealing)
                .put("allergyIntensity0To10", input.agingAutonomic.allergyIntensity0To10)
                .put("foodSensitivityEpisode", input.agingAutonomic.foodSensitivityEpisode)
                .put("seasonalPattern", input.agingAutonomic.seasonalPattern)
                .put("allergyAfterStress", input.agingAutonomic.allergyAfterStress)
                .put("allergyAfterPoorSleep", input.agingAutonomic.allergyAfterPoorSleep)
                .put("systolicBpMmHg", input.agingAutonomic.systolicBpMmHg)
                .put("diastolicBpMmHg", input.agingAutonomic.diastolicBpMmHg)
                .put("restingPulseBpm", input.agingAutonomic.restingPulseBpm)
                .put("dizzinessOnStanding", input.agingAutonomic.dizzinessOnStanding)
                .put("faintnessDuringAllergy", input.agingAutonomic.faintnessDuringAllergy)
                .put("flushingOrWarmth", input.agingAutonomic.flushingOrWarmth)
                .put("coldHandsFeet", input.agingAutonomic.coldHandsFeet))
            .put("gutNutritionHormone", JSONObject()
                .put("refluxHeartburn0To10", input.gutNutritionHormone.refluxHeartburn0To10)
                .put("bloatingDyspepsia0To10", input.gutNutritionHormone.bloatingDyspepsia0To10)
                .put("suspectedLowAcidPattern", input.gutNutritionHormone.suspectedLowAcidPattern)
                .put("ppiOrAntacidUse", input.gutNutritionHormone.ppiOrAntacidUse)
                .put("knownGastritisOrHpylori", input.gutNutritionHormone.knownGastritisOrHpylori)
                .put("mealTimingIrregular", input.gutNutritionHormone.mealTimingIrregular)
                .put("dietDiversity0To10", input.gutNutritionHormone.dietDiversity0To10)
                .put("proteinIntakeEstimateG", input.gutNutritionHormone.proteinIntakeEstimateG)
                .put("bodyWeightKg", input.gutNutritionHormone.bodyWeightKg)
                .put("muscleMassLossOrLow", input.gutNutritionHormone.muscleMassLossOrLow)
                .put("strengthTraining", input.gutNutritionHormone.strengthTraining)
                .put("appetiteLow", input.gutNutritionHormone.appetiteLow)
                .put("testosteroneNgDl", input.gutNutritionHormone.testosteroneNgDl)
                .put("lowLibidoOrLowMorningDrive", input.gutNutritionHormone.lowLibidoOrLowMorningDrive)
                .put("lowMorningEnergy", input.gutNutritionHormone.lowMorningEnergy)
                .put("notes", input.gutNutritionHormone.notes))
            .put("result", JSONObject()
                .put("severity", record.result.severity)
                .put("classifierLabel", record.result.classifierLabel)
                .put("pattern", record.result.pattern)
                .put("signalStrengthPercent", record.result.signalStrengthPercent)
                .put("signalStrengthLabel", record.result.signalStrengthLabel)
                .put("dataQualityPercent", record.result.dataQualityPercent)
                .put("evidenceCompleteness", record.result.evidenceCompleteness)
                .put("immuneStateVector", JSONObject()
                    .put("type2AllergicAxis", vector.type2AllergicAxis)
                    .put("mastCellAxis", vector.mastCellAxis)
                    .put("eosinophilAxis", vector.eosinophilAxis)
                    .put("tnfIl6InflammatoryAxis", vector.tnfIl6InflammatoryAxis)
                    .put("hyperInflammatoryAxis", vector.hyperInflammatoryAxis)
                    .put("regulatoryBrakeWeakness", vector.regulatoryBrakeWeakness)
                    .put("systemicDamageSignal", vector.systemicDamageSignal)
                    .put("psychoneuroimmuneStressAxis", vector.psychoneuroimmuneStressAxis)
                    .put("mechanicalLoadAxis", vector.mechanicalLoadAxis)
                    .put("neuroMuscularGuardingAxis", vector.neuroMuscularGuardingAxis)
                    .put("immunosenescenceAxis", vector.immunosenescenceAxis)
                    .put("inflammagingAxis", vector.inflammagingAxis)
                    .put("immuneResponsivenessAxis", vector.immuneResponsivenessAxis)
                    .put("sympatheticPressureUpAxis", vector.sympatheticPressureUpAxis)
                    .put("histaminePressureDownAxis", vector.histaminePressureDownAxis)
                    .put("bloodPressureInstabilityAxis", vector.bloodPressureInstabilityAxis)
                    .put("gastricAcidDysregulationAxis", vector.gastricAcidDysregulationAxis)
                    .put("gutBarrierMicrobiomeAxis", vector.gutBarrierMicrobiomeAxis)
                    .put("nutritionProteinAxis", vector.nutritionProteinAxis)
                    .put("muscleMassReserveAxis", vector.muscleMassReserveAxis)
                    .put("testosteroneImmuneModulationAxis", vector.testosteroneImmuneModulationAxis)
                    .put("dominantCompartment", vector.dominantCompartment))
                .put("causalOriginMap", JSONObject()
                    .put("dominantDriver", cause.dominantDriver)
                    .put("allergenExposure", cause.allergenExposure)
                    .put("psychologicalStress", cause.psychologicalStress)
                    .put("sleepRecoveryDebt", cause.sleepRecoveryDebt)
                    .put("infectionTrigger", cause.infectionTrigger)
                    .put("mechanicalLoad", cause.mechanicalLoad)
                    .put("neuroMuscularGuarding", cause.neuroMuscularGuarding)
                    .put("mixedUncertain", cause.mixedUncertain)
                    .put("interpretation", cause.interpretation)
                    .put("ledger", JSONObject()
                        .put("temporalEvidence", ledger.temporalEvidence)
                        .put("biologicalPlausibility", ledger.biologicalPlausibility)
                        .put("repeatability", ledger.repeatability)
                        .put("caution", ledger.caution)))
                .put("agingAutonomicMap", JSONObject()
                    .put("immunosenescenceAxis", aging.immunosenescenceAxis)
                    .put("inflammagingAxis", aging.inflammagingAxis)
                    .put("immuneResponsivenessAxis", aging.immuneResponsivenessAxis)
                    .put("allergyReactivityIndex", aging.allergyReactivityIndex)
                    .put("agingLoadIndex", aging.agingLoadIndex)
                    .put("resilienceIndex", aging.resilienceIndex)
                    .put("sympatheticPressureUp", aging.sympatheticPressureUp)
                    .put("histaminePressureDown", aging.histaminePressureDown)
                    .put("bloodPressureInstability", aging.bloodPressureInstability)
                    .put("dominantPattern", aging.dominantPattern)
                    .put("researchInterpretation", aging.researchInterpretation)
                    .put("competingHypotheses", JSONArray(aging.competingHypotheses)))
                .put("gutNutritionHormoneMap", JSONObject()
                    .put("gastricAcidDysregulationAxis", gut.gastricAcidDysregulationAxis)
                    .put("gutBarrierMicrobiomeAxis", gut.gutBarrierMicrobiomeAxis)
                    .put("nutritionProteinAxis", gut.nutritionProteinAxis)
                    .put("muscleMassReserveAxis", gut.muscleMassReserveAxis)
                    .put("testosteroneImmuneModulationAxis", gut.testosteroneImmuneModulationAxis)
                    .put("metabolicStressAxis", gut.metabolicStressAxis)
                    .put("dominantPattern", gut.dominantPattern)
                    .put("researchInterpretation", gut.researchInterpretation)
                    .put("competingHypotheses", JSONArray(gut.competingHypotheses)))
                .put("evidence", JSONArray(record.result.evidence))
                .put("causeEvidence", JSONArray(record.result.causeEvidence))
                .put("researchHypotheses", JSONArray(record.result.researchHypotheses))
                .put("discussionPrompts", JSONArray(record.result.discussionPrompts))
                .put("safeActions", JSONArray(record.result.safeActions))
                .put("notProven", JSONArray(record.result.notProven)))
    }
}
