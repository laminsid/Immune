package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.7 — Signal Surprise + Immune Phase + Specificity engines.
 * These engines do not claim discovery. They search for non-obvious, falsifiable
 * discovery-candidate angles from the already-linked canonical target/capsule/module rails.
 */
object GTIMSignalSurpriseEngineV2137 {
    const val VERSION: String = "2.13.7-signal-surprise-engine"
    const val CLAIM_LIMIT: String = "signal_surprise_is_hypothesis_generation_not_biological_proof"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val canonical = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val moduleJson = report.optJSONObject("immuneModuleSignalEngineV2135") ?: GTIMImmuneModuleSignalEngineV2135.toJson(report)
        val signals = moduleJson.optJSONArray("moduleSignals") ?: JSONArray()
        val patterns = JSONArray()
        if (signals.length() == 0) {
            patterns.put(pattern("missing_module_signal", "no_module_signal_yet", "ask for capsule or run DGE/module scoring before discovery upgrade"))
        } else {
            val modules = jsonStringsFromObjects(signals, "moduleId")
            patterns.put(pattern("expected_signal_present_but_unscored", modules.take(3).joinToString("+"), "convert candidate modules into module_score/direction/effect_size/FDR"))
            if (modules.any { it.contains("il6") || it.contains("tnf") || it.contains("interferon") }) {
                patterns.put(pattern("broad_inflammation_specificity_risk", "shared_cytokine_module", "test whether signal is tissue/timing/subgroup-specific rather than generic inflammation"))
            }
            if (domain.contains("depression") && modules.any { it.contains("kynurenine") }) {
                patterns.put(pattern("non_obvious_subgroup_angle", "brain_region_sex_inflammatory_state", "mutate hypothesis toward brain-region/sex/inflammatory-subgroup split"))
            }
            if (domain.contains("allergy") && modules.any { it.contains("type2") || it.contains("mast") }) {
                patterns.put(pattern("threshold_instability_angle", "type2_threshold_vs_microbiome_alone", "test whether type-2 threshold explains severity better than generic barrier/microbiome"))
            }
            if (domain.contains("viral")) {
                patterns.put(pattern("immune_timing_angle", "early_IFN_vs_late_IL6_TNF", "test phase timing rather than static cytokine presence"))
            }
        }
        val state = if (patterns.length() > 0 && canonical.isNotBlank()) "SIGNAL_SURPRISE_READY" else "SIGNAL_SURPRISE_NEEDS_CANONICAL_TARGET_OR_MODULES"
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("activeDomain", domain)
            .put("canonicalTarget", canonical)
            .put("surprisePatterns", patterns)
            .put("innovationUse", "feed_hypothesis_mutation_and_competition_arena")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val patterns = obj.optJSONArray("surprisePatterns") ?: JSONArray()
        return listOf(
            "Signal Surprise Engine",
            "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; surprises=${patterns.length()}.",
            "Top surprise: ${patterns.optJSONObject(0)?.optString("pattern", "none") ?: "none"} → ${patterns.optJSONObject(0)?.optString("nextTest", "none") ?: "none"}",
            "Boundary: surprise patterns generate hypotheses; they do not prove mechanism or clinical value."
        )
    }

    private fun pattern(kind: String, signal: String, next: String): JSONObject = JSONObject()
        .put("pattern", kind)
        .put("signal", signal)
        .put("nextTest", next)
        .put("status", "candidate_to_test")

    private fun jsonStringsFromObjects(array: JSONArray, key: String): List<String> =
        (0 until array.length()).mapNotNull { array.optJSONObject(it)?.optString(key)?.takeIf { s -> s.isNotBlank() } }
}

object GTIMCellTissueSpecificityEngineV2137 {
    const val VERSION: String = "2.13.7-cell-tissue-specificity-engine"
    const val CLAIM_LIMIT: String = "cell_tissue_specificity_is_discovery_triage_not_proof"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val canonical = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val capsule = report.optJSONObject("processedCapsuleStoreV2135")?.optJSONObject("selectedCapsule") ?: JSONObject()
        val specificityAxes = when {
            domain.contains("depression") -> listOf("brain_region", "sex_strata", "microglia_neuroimmune", "blood_vs_brain_proxy")
            domain.contains("allergy") -> listOf("airway_vs_blood", "HDM_allergy_status", "Th_Treg_subset", "mast_eosinophil_epithelial_axis")
            domain.contains("filovirus") -> listOf("PBMC_vs_tissue", "severity_survival", "endothelial_coagulation", "acute_timing")
            domain.contains("viral") -> listOf("PBMC_blood", "acute_vs_recovery", "severity_vs_persistence", "IFN_timing")
            domain.contains("metabolic") -> listOf("adipose_vs_blood", "insulin_resistance", "beta_cell_stress", "low_grade_inflammation")
            else -> listOf("tissue_context", "cell_type_context", "phenotype_subgroup")
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (canonical.isNotBlank()) "CELL_TISSUE_SPECIFICITY_TRIAGE_READY" else "CELL_TISSUE_SPECIFICITY_NEEDS_TARGET")
            .put("activeDomain", domain)
            .put("canonicalTarget", canonical)
            .put("capsuleTissueState", capsule.optString("tissueState", "unknown"))
            .put("specificityAxes", JSONArray(specificityAxes))
            .put("killCondition", "downgrade_if_signal_is_not_specific_to_tissue_cell_or_subgroup_axis")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val axes = jsonStrings(obj.optJSONArray("specificityAxes")).take(5).joinToString(", ")
        return listOf(
            "Cell / Tissue Specificity Engine",
            "State: ${obj.optString("state", "UNKNOWN")}; target=${obj.optString("canonicalTarget", "none")}; axes=$axes.",
            "Kill condition: ${obj.optString("killCondition", "specificity failure downgrades claim")}",
            "Boundary: specificity improves hypothesis quality; it is not DGE or causality proof."
        )
    }

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { array.optString(it).takeIf { s -> s.isNotBlank() } }
}

object GTIMImmunePhaseEngineV2137 {
    const val VERSION: String = "2.13.7-immune-phase-engine"
    const val CLAIM_LIMIT: String = "immune_phase_model_is_testable_hypothesis_not_mechanism_proof"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val phases = when {
            domain.contains("viral") || domain.contains("filovirus") -> listOf("early_trigger", "interferon_timing", "cytokine_amplification", "tissue_or_endothelial_injury", "recovery_persistence_or_survival")
            domain.contains("allergy") -> listOf("allergen_exposure", "epithelial_alarmin_signal", "type2_amplification", "mast_eosinophil_effector", "tolerance_or_relapse_threshold")
            domain.contains("depression") -> listOf("inflammatory_trigger", "IDO1_KMO_kynurenine_shift", "neuroimmune_stress", "neurotransmission_readout", "subgroup_persistence")
            domain.contains("metabolic") -> listOf("metabolic_stress", "immune_energy_mismatch", "low_grade_cytokine_tone", "tissue_metabolic_readout", "chronic_persistence")
            else -> listOf("trigger", "amplification", "tissue_readout", "phenotype", "persistence")
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "IMMUNE_PHASE_MODEL_READY")
            .put("activeDomain", domain)
            .put("phaseModel", JSONArray(phases))
            .put("nonObviousQuestion", nonObviousQuestion(domain))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Immune Phase Engine",
        "State: ${obj.optString("state", "UNKNOWN")}; phases=${jsonStrings(obj.optJSONArray("phaseModel")).joinToString(" → ")}.",
        "Non-obvious question: ${obj.optString("nonObviousQuestion", "none")}",
        "Boundary: phase model guides discovery tests; it is not a proven disease mechanism."
    )

    private fun nonObviousQuestion(domain: String): String = when {
        domain.contains("viral") || domain.contains("filovirus") -> "Does immune timing explain outcome better than static cytokine abundance?"
        domain.contains("allergy") -> "Does threshold instability explain subgroup severity better than microbiome/barrier signal alone?"
        domain.contains("depression") -> "Is kynurenine biology restricted to a sex/brain-region/inflammatory subgroup rather than all depression?"
        domain.contains("metabolic") -> "Is immune-energy mismatch a subgroup signal rather than generic metabolic inflammation?"
        else -> "Which phase turns a broad immune signal into a subgroup-specific phenotype?"
    }

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { array.optString(it).takeIf { s -> s.isNotBlank() } }
}
