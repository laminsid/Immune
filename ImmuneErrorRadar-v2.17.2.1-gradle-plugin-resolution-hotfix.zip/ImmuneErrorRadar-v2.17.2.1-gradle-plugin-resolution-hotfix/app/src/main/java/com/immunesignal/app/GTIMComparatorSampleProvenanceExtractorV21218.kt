package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.18 — Comparator + sample provenance extractor.
 *
 * Converts injected metadata and background probe results into one review-only
 * provenance card. This layer improves study-readiness; it never upgrades evidence.
 */
object GTIMComparatorSampleProvenanceExtractorV21218 {
    const val VERSION: String = "2.12.18-comparator-sample-provenance-extractor"
    const val CLAIM_LIMIT: String = "provenance_readiness_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: GTIMCandidateHandleLedgerV21215.toJson(report)
        val selected = ledger.optString("selectedReviewTarget")
        val probe = report.optJSONObject("metadataProbeBackgroundWorkersV21215") ?: JSONObject()
        val injected = report.optJSONObject("injectedMetadataSeedPackV21216") ?: JSONObject()
        val executed = probe.optJSONArray("executedSteps") ?: JSONArray()
        val queued = probe.optJSONArray("queuedSteps") ?: JSONArray()
        val blocked = probe.optJSONArray("blockedSteps") ?: JSONArray()
        val probeResults = probe.optJSONArray("probeResults") ?: JSONArray()
        val selectedProbe = selectedProbeResult(probeResults, selected)
        val text = listOf(report.toString().take(6000), selectedProbe.toString(), injected.toString()).joinToString(" ").lowercase()
        val comparatorState = when {
            selectedProbe.optString("comparatorLabelsStatus").contains("found", true) -> "COMPARATOR_LABELS_FOUND_REVIEW_REQUIRED"
            text.contains("severity") || text.contains("case/control") || text.contains("control") || text.contains("comparator") -> "COMPARATOR_LABELS_HINTED_NEEDS_REVIEW"
            else -> "COMPARATOR_LABELS_NOT_CLOSED"
        }
        val provenanceState = when {
            selectedProbe.optString("sampleProvenanceStatus").contains("found", true) -> "SAMPLE_PROVENANCE_FOUND_REVIEW_REQUIRED"
            text.contains("sample") && (text.contains("source") || text.contains("provenance") || text.contains("srp") || text.contains("sra")) -> "SAMPLE_PROVENANCE_HINTED_NEEDS_REVIEW"
            else -> "SAMPLE_PROVENANCE_NOT_CLOSED"
        }
        val tissueSpeciesState = when {
            selectedProbe.optString("tissueSpeciesStatus").contains("found", true) -> "TISSUE_SPECIES_FOUND_REVIEW_REQUIRED"
            text.contains("human") || text.contains("pbmc") || text.contains("blood") || text.contains("brain") || text.contains("tissue") -> "TISSUE_SPECIES_HINTED_NEEDS_REVIEW"
            else -> "TISSUE_SPECIES_NOT_CLOSED"
        }
        val matrixState = when {
            selectedProbe.optString("matrixOrCapsuleHint").contains("available", true) -> "MATRIX_OR_CAPSULE_HINT_AVAILABLE_REVIEW_REQUIRED"
            selectedProbe.optString("matrixOrCapsuleHint").contains("possible", true) || text.contains("grein") || text.contains("refine.bio") || text.contains("recount3") -> "PROCESSED_CAPSULE_POSSIBLE_NOT_VERIFIED"
            else -> "MATRIX_OR_CAPSULE_NOT_CLOSED"
        }
        val closedCount = listOf(comparatorState, provenanceState, tissueSpeciesState, matrixState).count { it.contains("FOUND") || it.contains("AVAILABLE") }
        val readiness = when {
            closedCount >= 4 -> "PROVENANCE_REVIEW_READY"
            closedCount >= 2 || executed.length() > 0 -> "PROVENANCE_PARTIAL_REVIEW_READY"
            selected.isNotBlank() -> "PROVENANCE_SEED_ONLY"
            else -> "NO_SELECTED_REVIEW_TARGET"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", readiness)
            .put("selectedReviewTarget", selected)
            .put("executedStepCount", executed.length())
            .put("queuedStepCount", queued.length())
            .put("blockedStepCount", blocked.length())
            .put("comparatorLabelsState", comparatorState)
            .put("sampleProvenanceState", provenanceState)
            .put("tissueSpeciesState", tissueSpeciesState)
            .put("matrixOrCapsuleState", matrixState)
            .put("readyGateCount", closedCount)
            .put("minimumFields", JSONArray(listOf("sample_groups", "case_control_or_severity_labels", "tissue_species", "sample_to_source_provenance", "matrix_or_processed_capsule_hint")))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Comparator + sample provenance extractor",
        "State: ${obj.optString("state", "UNKNOWN")}; selected_review_target=${obj.optString("selectedReviewTarget", "none")}; ready_gates=${obj.optInt("readyGateCount", 0)}/4.",
        "Comparator: ${obj.optString("comparatorLabelsState", "unknown")}; sample provenance: ${obj.optString("sampleProvenanceState", "unknown")}; tissue/species: ${obj.optString("tissueSpeciesState", "unknown")}; matrix/capsule: ${obj.optString("matrixOrCapsuleState", "unknown")}",
        "Execution: executed_steps=${obj.optInt("executedStepCount", 0)}; queued_steps=${obj.optInt("queuedStepCount", 0)}; blocked_steps=${obj.optInt("blockedStepCount", 0)}.",
        "Boundary: provenance readiness supports study design only; it does not prove mechanism, DGE, diagnosis, treatment, or efficacy."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "PROVENANCE_PARTIAL_REVIEW_READY", "COMPARATOR_LABELS_NOT_CLOSED", CLAIM_LIMIT))

    private fun selectedProbeResult(arr: JSONArray, selected: String): JSONObject {
        if (selected.isBlank()) return JSONObject()
        for (idx in 0 until arr.length()) {
            val item = arr.optJSONObject(idx) ?: continue
            if (item.optString("handle").equals(selected, ignoreCase = true)) return item
        }
        return JSONObject()
    }
}
