package com.immunesignal.app

import org.json.JSONObject

/**
 * v2.14.2 — Hard lock that makes the professional phased orchestrator the default
 * mobile research route. The old monolithic ResearchAutopilot → reportToJson →
 * REPORT_JSON_ENCODING branch remains only as an explicitly disabled legacy fallback
 * for source compatibility, tests, and forensic comparison. It must not run during
 * normal Android foreground research.
 */
object GTIMProfessionalOrchestratorHardLockV2142 {
    const val VERSION: String = "2.14.2-professional-orchestrator-hard-lock"
    const val REQUIRED_TOKEN: String = "V2142_PROFESSIONAL_ORCHESTRATOR_DEFAULT_NO_MONOLITHIC_JSON_ENCODING"
    const val DEFAULT_ROUTE: String = "GTIMProfessionalResearchOrchestratorV2140"
    const val LEGACY_ROUTE: String = "ResearchAutopilot_reportToJson_REPORT_JSON_ENCODING"

    fun shouldUseProfessionalOrchestrator(
        professionalEnabled: Boolean,
        allowLegacyMonolithicFallback: Boolean
    ): Boolean = professionalEnabled || !allowLegacyMonolithicFallback

    fun toJson(
        professionalEnabled: Boolean,
        allowLegacyMonolithicFallback: Boolean
    ): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("requiredToken", REQUIRED_TOKEN)
        .put("defaultRoute", DEFAULT_ROUTE)
        .put("legacyRoute", LEGACY_ROUTE)
        .put("professionalEnabled", professionalEnabled)
        .put("allowLegacyMonolithicFallback", allowLegacyMonolithicFallback)
        .put("legacyRouteReachableByDefault", false)
        .put("sixMinuteCheckpointMeaning", "visible compact checkpoint and compatibility contract, not a waiting strategy")
        .put("tenMinuteCeilingMeaning", "emergency safety ceiling only; normal mobile output is produced by staged checkpoints")
        .put("claim", "The app produces compact staged dossiers first and deepens by repeat passes, not by blocking the foreground screen for one huge JSON report.")

    fun userLine(): String =
        "Professional orchestrator hard lock: default route=$DEFAULT_ROUTE; legacy monolithic JSON route is disabled for normal mobile runs."
}
