package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.13 — Negative evidence memory.
 *
 * Records failed/weak evidence conditions as reusable learning so the app does not keep
 * repeating the same wrong matrix, topic, tissue, comparator, or microbiome fallback.
 */
object GTIMNegativeEvidenceMemoryV21213 {
    const val VERSION: String = "2.12.13-negative-evidence-memory"
    const val CLAIM_LIMIT: String = "negative_evidence_memory_learning_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val consistency = report.optJSONObject("reportConsistencyGateV2121") ?: JSONObject()
        val text = report.toString()
        val items = JSONArray()
        if (!consistency.optBoolean("topicCompatibleTargetSelected", false)) {
            items.put(item("topic_fit_not_closed", "Candidate handle or route was not accepted as a topic-compatible internal target.", "block_evidence_upgrade"))
        }
        if (consistency.optInt("verifiedMatrixFiles", 0) <= 0) {
            items.put(item("matrix_or_capsule_not_verified", "No verified matrix, processed-expression capsule, or observed file evidence is closed.", "keep_as_review_task"))
        }
        if (!text.contains("comparator", true) || text.contains("comparator labels missing", true)) {
            items.put(item("comparator_labels_unresolved", "Comparator labels are missing or not independently verified.", "require_metadata_probe"))
        }
        if (text.contains("microbiome", true) && text.contains("kynurenine", true) && !text.contains("IDO1", true) && !text.contains("KMO", true)) {
            items.put(item("microbiome_fallback_risk", "Kynurenine run risks falling back to microbiome/barrier without IDO1/KMO target mapping.", "diversify_target_lexicon"))
        }
        if (text.contains("wrong tissue", true) || text.contains("wrong species", true)) {
            items.put(item("tissue_species_mismatch", "Tissue/species mismatch appears in falsification or validation text.", "downgrade_to_background"))
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (items.length() > 0) "NEGATIVE_EVIDENCE_MEMORY_ACTIVE" else "NO_NEGATIVE_EVIDENCE_ITEM")
            .put("negativeEvidenceItems", items)
            .put("learningPolicy", "store_failed_routes_and_missing_gates_to_prevent_repeated_false_leads")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val items = obj.optJSONArray("negativeEvidenceItems") ?: JSONArray()
        val first = items.optJSONObject(0)?.optString("reason") ?: "none"
        return listOf(
            "Negative evidence memory",
            "State: ${obj.optString("state", "UNKNOWN")}; items=${items.length()}; first blocker=${first.takeClean(220)}",
            "Use: store failed/missing gates so the app does not repeat weak dataset, comparator, tissue/species, or generic microbiome fallback errors.",
            "Boundary: negative evidence memory guides routing; it does not prove the opposite biology."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "NEGATIVE_EVIDENCE_MEMORY_ACTIVE",
        "topic_fit_not_closed",
        "matrix_or_capsule_not_verified",
        "comparator_labels_unresolved",
        "microbiome_fallback_risk",
        CLAIM_LIMIT
    ))

    private fun item(code: String, reason: String, action: String): JSONObject = JSONObject()
        .put("code", code)
        .put("reason", reason)
        .put("nextRoutingAction", action)
        .put("memoryStatus", "store_as_routing_warning_not_biological_proof")
        .put("claimLimit", "negative_memory_only_no_evidence_upgrade")

    private fun String.takeClean(max: Int): String {
        val clean = replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= max) clean else clean.take(max).trimEnd()
    }
}
