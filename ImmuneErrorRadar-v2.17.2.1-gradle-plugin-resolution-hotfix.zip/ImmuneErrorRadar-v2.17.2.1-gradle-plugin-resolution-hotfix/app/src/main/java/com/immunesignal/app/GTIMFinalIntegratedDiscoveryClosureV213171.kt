package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.17.1 — Final integrated immune-decision closure.
 *
 * This closure is deliberately small. It does not create another research tree; it
 * verifies that the final visible decision is assembled from the new connected layers:
 * local processed capsules, hypothesis-first discovery, immune decision/paradigm
 * capsules, digital immunomics lens, and the active decision surface. Legacy rails remain
 * appendix/export compatibility only.
 */
object GTIMFinalIntegratedDiscoveryClosureV213171 {
    const val VERSION: String = "2.13.17.1-final-integrated-immune-decision-closure"
    const val STATE_READY: String = "FINAL_INTEGRATED_IMMUNE_DECISION_CLOSURE_READY"
    const val CLAIM_LIMIT: String = "integrated_research_preview_not_validated_science_not_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val hypothesis = report.optJSONObject("hypothesisFirstDiscoveryEngineV21315")
            ?: GTIMHypothesisFirstDiscoveryEngineV21315.toJson(report)
        val capsule = report.optJSONObject("localProcessedCapsuleLayerV21316")
            ?: hypothesis.optJSONObject("localProcessedCapsuleLayerV21316")
            ?: GTIMCapsuleSurfaceCardV21316.toJson(report)
        val paradigm = report.optJSONObject("paradigmCandidateEngineV21317")
            ?: GTIMParadigmCandidateEngineV21317.toJson(report)
        val digital = paradigm.optJSONObject("digital_immunomics_lens")
            ?: GTIMDigitalImmunomicsLensV21317.toJson(report)
        val assumption = GTIMAssumptionBreakerEngineV21318.toJson(report)
        val crossDisease = GTIMCrossDiseaseMechanismMapperV21318.toJson(report)
        val modality = GTIMTherapeuticModalityLensV21318.toJson(report)
        val binding = GTIMProteinInteractionBindingHypothesisV21318.toJson(report)
        val microbiome = GTIMMicrobiomeRoleSurfaceCardV21319.toJson(report)
        val cellDeath = GTIMCellDeathSurfaceCardV21319.toJson(report)
        val active = hypothesis.optString("activeDomain").ifBlank {
            GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        }
        val capsuleState = hypothesis.optString("matrixState", capsule.optString("matrix_state", "CAPSULE_MISSING_ACQUISITION_TASK_CREATED"))
        val capsuleAvailable = capsuleState.contains("LOCAL", ignoreCase = true) || capsule.optJSONObject("capsule") != null
        val conceptSelected = paradigm.optString("concept_id", "none_selected") != "none_selected"
        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("active_domain", active)
            .put("primary_result", hypothesis.optString("primaryResult", "C0_ROUTE_HYPOTHESIS"))
            .put("capsule_state", capsuleState)
            .put("local_capsule_available", capsuleAvailable)
            .put("concept_capsule_selected", conceptSelected)
            .put("paradigm_level", paradigm.optString("paradigm_level", "P0_OPEN_PARADIGM_SEARCH"))
            .put("immune_decision_states", paradigm.optJSONArray("immune_decision_states") ?: JSONArray())
            .put("digital_immunomics_applicable", digital.optBoolean("applicable", false))
            .put("assumption_breaker", assumption)
            .put("cross_disease_mechanism_mapper", crossDisease)
            .put("therapeutic_modality_lens", modality)
            .put("protein_interaction_binding_hypothesis", binding)
            .put("microbiome_role_card", microbiome)
            .put("cell_death_netosis_panoptosis_card", cellDeath)
            .put("sandbox_preview_policy", "C0_C1_C2_C3_ALLOWED_EVEN_WITHOUT_RAW_MATRIX_OR_REPLICATION")
            .put("execution_policy", "missing_matrix_replication_module_scores_are_execution_tasks_only")
            .put("clinical_policy", "patient_action_dosing_clinical_implementation_validated_proof_blocked")
            .put("legacy_policy", "legacy_rails_appendix_export_audit_compatibility_only")
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Final integrated immune-decision closure",
            "State: ${obj.optString("state")}; active_domain=${obj.optString("active_domain")}; primary_result=${obj.optString("primary_result")}",
            "Capsule state: ${obj.optString("capsule_state")}; local_capsule_available=${obj.optBoolean("local_capsule_available")}; concept_capsule_selected=${obj.optBoolean("concept_capsule_selected")}",
            "Paradigm level: ${obj.optString("paradigm_level")}; immune_decision_states=${obj.optJSONArray("immune_decision_states") ?: JSONArray()}",
            "Digital immunomics lens: applicable=${obj.optBoolean("digital_immunomics_applicable")}; use as design/hypothesis lens only, not efficacy proof.",
            "Assumption/cross-disease closure: ${obj.optJSONObject("assumption_breaker")?.optString("old_assumption_challenged") ?: "open"}; ${obj.optJSONObject("cross_disease_mechanism_mapper")?.optString("shared_mechanism_axis") ?: "open"}.",
            "Modality/binding closure: modalities=${obj.optJSONObject("therapeutic_modality_lens")?.optJSONArray("modalities") ?: JSONArray()}; target_antigen=${obj.optJSONObject("protein_interaction_binding_hypothesis")?.optString("target_antigen") ?: "open"}.",
            "Microbiome/NETosis closure: microbiome_role=${obj.optJSONObject("microbiome_role_card")?.optString("microbiome_role") ?: "open"}; cell_death_state=${obj.optJSONObject("cell_death_netosis_panoptosis_card")?.optString("state") ?: "open"}.",
            "Sandbox policy: ${obj.optString("sandbox_preview_policy")}",
            "Execution policy: ${obj.optString("execution_policy")}",
            "Legacy policy: ${obj.optString("legacy_policy")}",
            "Boundary: ${obj.optString("clinical_policy")}; ${obj.optString("claim_limit")}."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        STATE_READY,
        "C0_C1_C2_C3_ALLOWED_EVEN_WITHOUT_RAW_MATRIX_OR_REPLICATION",
        "missing_matrix_replication_module_scores_are_execution_tasks_only",
        "legacy_rails_appendix_export_audit_compatibility_only",
        CLAIM_LIMIT,
        "GTIMAssumptionBreakerEngineV21318",
        "GTIMCrossDiseaseMechanismMapperV21318",
        "GTIMTherapeuticModalityLensV21318",
        "GTIMProteinInteractionBindingHypothesisV21318",
        "immune_age_longevity",
        "GTIMGutMicrobiomeImmuneOrganEngineV21319",
        "GTIMMicrobiomeRoleSurfaceCardV21319",
        "GTIMNETosisExtracellularImmunityEngineV21319",
        "GTIMPANoptosisCellDeathEngineV21319",
        "GTIMCellDeathSurfaceCardV21319"
    ))
}
