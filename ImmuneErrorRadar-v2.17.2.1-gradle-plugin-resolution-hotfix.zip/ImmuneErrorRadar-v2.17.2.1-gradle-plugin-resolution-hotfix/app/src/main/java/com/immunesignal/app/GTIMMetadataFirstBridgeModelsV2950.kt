package com.immunesignal.app

/**
 * v2.9.9 — Modular metadata-first observed evidence bridge.
 *
 * This is the single connective layer between the active target gate and the heavier
 * ETL/DGE stack. It is intentionally metadata-first: it can parse/plan GEO SOFT,
 * map GSE→SRP/SRA, check whether an external/precomputed route may exist, classify
 * supplementary links, and enforce device-size routing. It does not download large
 * matrices, parse expression values, run DGE, or create treatment/clinical claims.
 */
data class GTIMSoftMetadataProbeReportV2950(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val softUrl: String,
    val sampleRows: List<GTIMSampleMetadataRowV2802>,
    val supplementaryFiles: List<GTIMObservedRepositoryFileV2802>,
    val sraAccessions: List<String>,
    val bioProjectAccessions: List<String>,
    val line: String,
    val boundaryLine: String
)

data class GTIMGseToSrpMappingReportV2950(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val srpAccessions: List<String>,
    val sraRunAccessions: List<String>,
    val bioProjectAccessions: List<String>,
    val eutilsSearchUrl: String,
    val line: String,
    val boundaryLine: String
)

data class GTIMExternalAvailabilityReportV2950(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val checkedRoutes: List<String>,
    val availableRoutes: List<String>,
    val blocker: String,
    val line: String,
    val boundaryLine: String
)

data class GTIMDeviceFilePolicyReportV2950(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val tooLargeFiles: List<String>,
    val safeFiles: List<String>,
    val unknownSizeFiles: List<String>,
    val localFullMatrixLimitBytes: Long,
    val line: String,
    val boundaryLine: String
)

data class GTIMMetadataFirstObservedEvidenceBridgeReportV2950(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val softProbe: GTIMSoftMetadataProbeReportV2950,
    val gseToSrpMapping: GTIMGseToSrpMappingReportV2950,
    val externalAvailability: GTIMExternalAvailabilityReportV2950,
    val deviceFilePolicy: GTIMDeviceFilePolicyReportV2950,
    val publicExpressionSources: GTIMPublicExpressionSourceRegistryReportV2980? = null,
    val externalEvidenceCapsule: GTIMExternalEvidenceCapsuleImportReportV2980? = null,
    val learningCache: GTIMLearningCacheReportV2980? = null,
    val publicExpressionRequestPlan: GTIMPublicExpressionRequestPlanReportV2990? = null,
    val learningCacheExport: GTIMLearningCacheExportReportV2990? = null,
    val line: String,
    val boundaryLine: String
)
