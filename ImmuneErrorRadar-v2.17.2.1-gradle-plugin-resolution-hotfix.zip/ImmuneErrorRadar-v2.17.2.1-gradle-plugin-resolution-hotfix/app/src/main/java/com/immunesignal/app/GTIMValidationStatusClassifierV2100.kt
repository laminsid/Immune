package com.immunesignal.app

// legacy_v2100_audit_marker: 2.10.0-medical-research-dossier

/** v2.10.0 — validation status and evidence grade classifier. */
object GTIMValidationStatusClassifierV2100 {
    const val VERSION: String = "2.10.0-validation-status-classifier"

    fun grade(
        established: List<GTIMEstablishedEvidenceCardV2100>,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        routes: List<GTIMTherapeuticRouteCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): String = when {
        discovery.any { it.validationStatus.contains("REGULATORY", ignoreCase = true) } -> "RESEARCH_DOSSIER_WITH_EXPLORATORY_UNVALIDATED_FINDINGS"
        dgeVerdict.verdict == "DGE_READY_REVIEW_ONLY_NOT_RUN" -> "RESEARCH_DOSSIER_ETL_READY_NO_CLINICAL_CLAIM"
        established.any { it.evidenceLevel.startsWith("A") } && routes.any { it.validationStatus.contains("ESTABLISHED", true) } -> "ESTABLISHED_SCIENCE_PLUS_RESEARCH_ROUTE_MAP"
        discovery.any { it.evidenceState.contains("CAPSULE", true) || it.sourceLayer.contains("capsule", true) } -> "RESEARCH_DOSSIER_WITH_EXTERNAL_CAPSULE_REVIEW"
        else -> "RESEARCH_DOSSIER_HYPOTHESIS_AND_METADATA_ONLY"
    }

    fun state(discovery: List<GTIMDiscoveryFindingCardV2100>, routes: List<GTIMTherapeuticRouteCardV2100>): String = when {
        routes.isEmpty() -> "MEDICAL_RESEARCH_DOSSIER_NO_ROUTE"
        discovery.any { it.validationStatus.contains("NOT_VALIDATED", true) } -> "MEDICAL_RESEARCH_DOSSIER_ESTABLISHED_PLUS_GTIM_EXPLORATORY"
        discovery.isNotEmpty() -> "MEDICAL_RESEARCH_DOSSIER_REVIEW_ONLY"
        else -> "MEDICAL_RESEARCH_DOSSIER_ESTABLISHED_BASELINE_ONLY"
    }
}
