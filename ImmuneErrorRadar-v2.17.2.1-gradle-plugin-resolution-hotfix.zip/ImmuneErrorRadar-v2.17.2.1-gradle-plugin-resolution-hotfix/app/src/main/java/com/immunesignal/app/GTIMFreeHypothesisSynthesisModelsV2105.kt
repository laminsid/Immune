package com.immunesignal.app

// v2.10.5 — Free hypothesis synthesis models.
// This layer is the GTIM core: established science is used as the foundation,
// not the ceiling. The app may connect immune/genetic mechanisms into novel
// research hypotheses while preserving anti-hallucination and clinical-action locks.

data class GTIMFreeHypothesisSynthesisCardV2105(
    val cardId: String,
    val state: String,
    val routeClass: String,
    val hypothesis: String,
    val mechanismBasis: String,
    val crossDomainAnalogy: String,
    val supportBasis: List<String>,
    val missingEvidence: List<String>,
    val falsificationTests: List<String>,
    val explorationRank: String,
    val boundary: String,
    val line: String
)

data class GTIMFreeHypothesisSynthesisReportV2105(
    val active: Boolean,
    val version: String,
    val state: String,
    val synthesisMode: String,
    val foundationUse: String,
    val cards: List<GTIMFreeHypothesisSynthesisCardV2105>,
    val antiHallucinationLocks: List<String>,
    val boundaryLine: String,
    val line: String
) {
    companion object {
        fun empty(): GTIMFreeHypothesisSynthesisReportV2105 = GTIMFreeHypothesisSynthesisReportV2105(
            active = false,
            version = GTIMFreeHypothesisSynthesisEngineV2105.VERSION,
            state = "FREE_HYPOTHESIS_SYNTHESIS_NOT_EVALUATED",
            synthesisMode = "not_evaluated",
            foundationUse = "not_evaluated",
            cards = emptyList(),
            antiHallucinationLocks = GTIMFreeHypothesisSynthesisEngineV2105.ANTI_HALLUCINATION_LOCKS,
            boundaryLine = GTIMFreeHypothesisSynthesisEngineV2105.BOUNDARY,
            line = "Free hypothesis synthesis: not evaluated."
        )
    }
}
