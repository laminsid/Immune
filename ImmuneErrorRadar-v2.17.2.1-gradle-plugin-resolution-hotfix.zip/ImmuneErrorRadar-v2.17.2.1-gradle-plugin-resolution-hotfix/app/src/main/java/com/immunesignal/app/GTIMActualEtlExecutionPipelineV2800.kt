package com.immunesignal.app

import org.json.JSONObject

/** v2.8.0 — Actual ETL execution pipeline surface: file discovery → matrix preview → metadata cleaning → linkage → review-only DGE → signals.
 * compatibility token: 2.8.2-concrete-etl-readiness
 */
data class GTIMActualEtlExecutionReportV2800(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val fileDiscovery: GTIMRepositoryFileDiscoveryReportV2800,
    val matrixReader: GTIMMatrixReaderPreviewReportV2800,
    val metadataCleaner: GTIMMetadataCleanerReportV2800,
    val sampleLinkage: GTIMSampleIdLinkageReportV2800,
    val dge: GTIMReviewOnlyDgeReportV2800,
    val genePathway: GTIMGenePathwaySignalReportV2800,
    val observedFileEvidence: GTIMObservedFileEvidenceReportV2801,
    val supplementaryFileDiscovery: GTIMSupplementaryFileDiscoveryReportV2802,
    val matrixFileClassifier: GTIMMatrixFileClassificationReportV2802,
    val sampleMetadataExtraction: GTIMSampleMetadataExtractionReportV2802,
    val caseControlLabelSuggestions: GTIMCaseControlLabelSuggestionReportV2802,
    val sampleIdLinkageVerification: GTIMSampleIdLinkageVerificationReportV2802,
    val dgeReadinessVerdict: GTIMDgeReadinessVerdictReportV2802,
    val metadataFirstBridge: GTIMMetadataFirstObservedEvidenceBridgeReportV2950? = null,
    val medicalResearchDossier: GTIMMedicalResearchDossierReportV2100? = null,
    val finalLine: String,
    val boundaryLine: String
)

object GTIMActualEtlExecutionPipelineV2800 {
    // legacy_v2101_audit_marker: 2.10.1-actual-etl-medical-study-structure-dossier-pipeline
    const val VERSION: String = "2.10.8-actual-etl-root-cause-eco-immune-dossier-pipeline"
    const val V2800_AUDIT_TOKEN: String = "2.8.0-actual-etl-execution-pipeline"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        matrixAuditCard: GTIMMatrixAuditCardReportV2745,
        etlBridge: GTIMMatrixEtlMetadataBridgeReportV2780,
        finalEtl: GTIMFinalEtlExecutionUnifierReportV2782,
        therapeutic: GTIMTherapeuticReverseTranslationReportV2790,
        report: JSONObject? = null
    ): GTIMActualEtlExecutionReportV2800 {
        val file = GTIMRepositoryFileDiscoveryV2800.build(matrixAuditCard, etlBridge, finalEtl)
        val metadataFirstBridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(contract, file, report)
        val observedFileEvidence = GTIMObservedFileEvidenceContractV2801.build(file, report)
        val matrix = GTIMMatrixReaderPreviewV2800.build(file, observedFileEvidence)
        val metadata = GTIMMetadataCleanerV2800.build(matrixAuditCard, etlBridge, matrix)
        val linkage = GTIMSampleIdLinkageEngineV2800.build(matrix, metadata)
        val dge = GTIMReviewOnlyDgePipelineV2800.build(file, matrix, metadata, linkage)
        val signal = GTIMGenePathwaySignalExtractorV2800.build(contract, dge, therapeutic)
        val supplementary = GTIMSupplementaryFileDiscoveryV2802.build(file, report, metadataFirstBridge.softProbe)
        val matrixClassifier = GTIMMatrixFileClassifierV2802.build(supplementary)
        val sampleMetadata = GTIMSampleMetadataExtractorV2802.build(file.targetId, report, metadata, metadataFirstBridge.softProbe)
        val caseControl = GTIMCaseControlLabelSuggesterV2802.build(sampleMetadata)
        val sampleIdVerification = GTIMSampleIdLinkageVerifierV2802.build(file.targetId, report, matrixClassifier, sampleMetadata)
        val dgeVerdict = GTIMDgeReadinessVerdictV2802.build(
            targetId = file.targetId,
            matrixClassifier = matrixClassifier,
            metadata = sampleMetadata,
            labels = caseControl,
            linkage = sampleIdVerification,
            observedFileEvidence = observedFileEvidence,
            deviceFilePolicy = metadataFirstBridge.deviceFilePolicy
        )
        val medicalResearchDossier = GTIMMedicalResearchDossierBuilderV2100.build(
            contract = contract,
            targetId = file.targetId,
            metadataBridge = metadataFirstBridge,
            dgeVerdict = dgeVerdict
        )
        val state = when {
            file.state == "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET" -> "ACTUAL_ETL_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"
            dgeVerdict.verdict == "DGE_READY_REVIEW_ONLY_NOT_RUN" -> "ACTUAL_ETL_READY_FOR_REVIEW_ONLY_DGE_RUN"
            dge.state == "DGE_READY_REVIEW_ONLY_PENDING_RUN" -> "ACTUAL_ETL_READY_FOR_REVIEW_ONLY_DGE_RUN"
            matrix.state == "MATRIX_READER_WAITING_FOR_OBSERVED_FILE_EVIDENCE" -> "ACTUAL_ETL_WAITING_FOR_OBSERVED_FILE_EVIDENCE"
            matrix.state == "MATRIX_READER_WAITING_FOR_DOWNLOAD" -> "ACTUAL_ETL_WAITING_FOR_FILE_DOWNLOAD"
            metadata.state == "METADATA_EXTRACTION_REQUIRED" -> "ACTUAL_ETL_WAITING_FOR_METADATA_CLEANING"
            linkage.state != "SAMPLE_LINKAGE_READY_FOR_REVIEW_ONLY_JOIN" -> "ACTUAL_ETL_WAITING_FOR_SAMPLE_ID_LINKAGE"
            else -> "ACTUAL_ETL_REVIEW_REQUIRED"
        }
        val finalLine = "Actual ETL execution: audit_token=$V2800_AUDIT_TOKEN | version=${GTIMUnifiedReleaseSurfaceV2804.ACTUAL_ETL_SPINE} | state=$state | target=${file.targetId} | download=${file.state} | matrix=${matrix.state} | metadata=${metadata.state} | sample_linkage=${linkage.state} | dge=${dge.state} | gene_pathway=${signal.state} | observed_file_evidence=${observedFileEvidence.state} | dge_readiness_verdict=${dgeVerdict.verdict}"
            .replace(Regex("\\s+"), " ").trim()
        return GTIMActualEtlExecutionReportV2800(
            active = true,
            targetId = file.targetId,
            state = state,
            fileDiscovery = file,
            matrixReader = matrix,
            metadataCleaner = metadata,
            sampleLinkage = linkage,
            dge = dge,
            genePathway = signal,
            observedFileEvidence = observedFileEvidence,
            supplementaryFileDiscovery = supplementary,
            matrixFileClassifier = matrixClassifier,
            sampleMetadataExtraction = sampleMetadata,
            caseControlLabelSuggestions = caseControl,
            sampleIdLinkageVerification = sampleIdVerification,
            dgeReadinessVerdict = dgeVerdict,
            metadataFirstBridge = metadataFirstBridge,
            medicalResearchDossier = medicalResearchDossier,
            finalLine = finalLine,
            boundaryLine = "Actual ETL boundary: public file discovery/download request and review-only execution gates; planned file signatures are not observed files; no fabricated matrix, no unreviewed DGE, no clinical or treatment claim."
        )
    }
}
