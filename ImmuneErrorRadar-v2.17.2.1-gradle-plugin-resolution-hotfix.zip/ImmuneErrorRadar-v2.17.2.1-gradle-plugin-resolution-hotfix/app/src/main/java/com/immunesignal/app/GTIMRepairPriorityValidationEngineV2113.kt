package com.immunesignal.app

// v2.11.3 — Ranks repair-function routes and forces biomarker/falsification plans.
object GTIMRepairPriorityValidationEngineV2113 {
    const val VERSION: String = "2.11.3-repair-priority-biomarker-validation"
    const val BOUNDARY: String = "priority_ranking_is_research_triage_not_medical_recommendation_not_treatment"

    fun rank(
        candidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
        restorationRoutes: List<GTIMEcosystemRestorationRouteV2108>,
        microbialReversal: GTIMMicrobialReversalReportV2111?,
        ecologicalRestoration: GTIMEcologicalRestorationReportV2112?,
        symptomOverlap: GTIMSymptomOverlapReportV2112?
    ): GTIMRepairPriorityValidationReportV2113 {
        val routes = mutableListOf<GTIMRepairPriorityRouteV2113>()
        restorationRoutes.take(4).forEachIndexed { index, route ->
            routes += priority(
                index = routes.size,
                routeClass = route.routeClass,
                source = route.routeId,
                impact = impactRank(route.routeClass),
                testability = if (route.requiredEvidence.any { it.contains("marker", true) || it.contains("metadata", true) }) "TESTABILITY_MEDIUM_HIGH" else "TESTABILITY_MEDIUM",
                risk = riskRank(route.routeClass),
                biomarker = routeBiomarkers(route.routeClass) + route.requiredEvidence.take(2),
                falsify = listOf("route-specific biomarkers do not move", "alternative dysfunction explains signal", "effect remains symptom-only without mechanism shift"),
                dataPack = listOf("topic-compatible dataset or evidence capsule", "mechanism marker", "context/comparator", "negative-control route"),
                upgrade = "upgrade only from repair route to stronger research signal when biomarker + context + falsification resistance align"
            )
        }
        microbialReversal?.candidateRoutes?.take(3)?.forEach { candidate ->
            routes += priority(
                index = routes.size,
                routeClass = "microbial_counter_function_priority",
                source = candidate.candidateId,
                impact = "IMPACT_HIGH_IF_COUNTER_FUNCTION_MATCHES_COLLAPSE",
                testability = if (candidate.evidenceRank.startsWith("L4") || candidate.evidenceRank.startsWith("L5")) "TESTABILITY_MEDIUM_HIGH" else "TESTABILITY_MEDIUM_LOW_TO_MEDIUM",
                risk = if (candidate.candidateClass.contains("engineered", true)) "RISK_HIGH_LONG_HORIZON" else "RISK_MEDIUM_REQUIRES_BIOSAFETY",
                biomarker = candidate.missingEvidence.take(3) + listOf("counter-function assay or proxy", "safety/no-inflammatory-worsening readout"),
                falsify = candidate.biosafetyRisks.take(2) + listOf("counter-function absent", "no restoration marker despite candidate signal"),
                dataPack = listOf("damage mechanism", "candidate function", "evidence rank", "biosafety review", "kill criteria"),
                upgrade = "do not upgrade by analogy; require counter-function evidence and recovery marker"
            )
        }
        symptomOverlap?.restorativeFunctionRoutes?.take(3)?.forEach { route ->
            routes += priority(
                index = routes.size,
                routeClass = route.routeClass,
                source = route.routeId,
                impact = "IMPACT_MEDIUM_HIGH_IF_SHARED_ROOT_MECHANISM_CONFIRMED",
                testability = "TESTABILITY_MEDIUM_HIGH_WITH_DISCRIMINATING_EVIDENCE",
                risk = "RISK_MEDIUM_DIAGNOSTIC_CONFUSION_IF_SYMPTOM_ONLY",
                biomarker = route.requiredEvidence + listOf("discriminating evidence against competing dysfunctions"),
                falsify = listOf("same symptoms better explained by another dysfunction", "repair function not measurable", "no shared-root mechanism remains"),
                dataPack = listOf("symptom cluster", "dysfunction nodes", "discriminating biomarkers", "repair-function route"),
                upgrade = "upgrade only after symptoms are separated from disease identity and dysfunction route is measured"
            )
        }
        val unique = routes.distinctBy { it.priorityId }.take(8)
        val biomarkers = (unique.flatMap { it.biomarkerPlan } + ecologicalRestoration?.restorationSequences.orEmpty().flatMap { it.recoveryMarkers }).distinct().take(12)
        val falsify = (unique.flatMap { it.falsificationPlan } + ecologicalRestoration?.restorationSequences.orEmpty().flatMap { it.failureSignals }).distinct().take(12)
        val state = when {
            unique.any { it.priorityState.contains("EARLY_PRIORITY", true) } -> "REPAIR_PRIORITY_EARLY_RESEARCH_ROUTES_READY"
            unique.isNotEmpty() -> "REPAIR_PRIORITY_RESEARCH_TRIAGE_READY"
            else -> "REPAIR_PRIORITY_OPEN_NO_ROUTE"
        }
        val line = "Repair priority validation: version=$VERSION | state=$state | routes=${unique.size} | biomarkers=${biomarkers.joinToString(";").oneLine()} | falsification=${falsify.joinToString(";").oneLine()} | boundary=$BOUNDARY"
        return GTIMRepairPriorityValidationReportV2113(true, VERSION, state, unique, biomarkers, falsify, BOUNDARY, line)
    }

    private fun priority(index: Int, routeClass: String, source: String, impact: String, testability: String, risk: String, biomarker: List<String>, falsify: List<String>, dataPack: List<String>, upgrade: String): GTIMRepairPriorityRouteV2113 {
        val state = when {
            impact.contains("HIGH") && testability.contains("HIGH") && !risk.contains("HIGH") -> "EARLY_PRIORITY_RESEARCH_ROUTE"
            risk.contains("HIGH") -> "LONG_HORIZON_PRIORITY_REQUIRES_SAFETY_PROOF"
            else -> "CONDITIONAL_PRIORITY_RESEARCH_ROUTE"
        }
        val id = "REPAIR_PRIORITY_${index + 1}_${source}".replace(Regex("[^A-Za-z0-9_]+"), "_").take(110)
        val line = "Repair priority route: version=$VERSION | id=$id | source=$source | class=$routeClass | impact=$impact | testability=$testability | risk=$risk | state=$state | biomarkers=${biomarker.distinct().joinToString(";").oneLine()} | falsify=${falsify.distinct().joinToString(";").oneLine()} | data_pack=${dataPack.distinct().joinToString(";").oneLine()} | upgrade_rule=${upgrade.oneLine()} | boundary=$BOUNDARY"
        return GTIMRepairPriorityRouteV2113(id, routeClass, source, impact, testability, risk, state, biomarker.distinct().take(8), falsify.distinct().take(8), dataPack.distinct().take(6), upgrade, line)
    }

    private fun impactRank(routeClass: String): String = when {
        routeClass.contains("barrier", true) -> "IMPACT_HIGH_SHARED_ENTRY_SURFACE"
        routeClass.contains("microbial", true) -> "IMPACT_HIGH_IF_FUNCTION_LOSS_CONFIRMED"
        routeClass.contains("metabolic", true) -> "IMPACT_MEDIUM_HIGH_SYSTEMIC_CONTEXT"
        routeClass.contains("immune", true) -> "IMPACT_HIGH_IF_IMMUNE_DECISION_ERROR_CONFIRMED"
        else -> "IMPACT_MEDIUM_OPEN_ROOT_CAUSE"
    }

    private fun riskRank(routeClass: String): String = when {
        routeClass.contains("microbial_reversal", true) -> "RISK_MEDIUM_REQUIRES_BIOSAFETY"
        routeClass.contains("adaptive", true) -> "RISK_MEDIUM_ENDPOINT_MISMATCH"
        else -> "RISK_LOW_MEDIUM_RESEARCH_ONLY"
    }

    private fun routeBiomarkers(routeClass: String): List<String> = when {
        routeClass.contains("barrier", true) -> listOf("barrier/permeability marker", "mucosal cytokine tone", "microbiome-metabolite bridge")
        routeClass.contains("microbial", true) -> listOf("microbial functional profile", "metabolite direction", "inflammatory baseline")
        routeClass.contains("metabolic", true) -> listOf("glucose/insulin/lipid context", "immune-energy marker", "mitochondrial or lactate proxy")
        routeClass.contains("immune", true) -> listOf("cytokine panel", "tolerance marker", "durability/waning marker")
        else -> listOf("mechanism biomarker", "context-specific comparator", "negative-control signal")
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
