package com.immunesignal.app

// legacy_v2100_audit_marker: 2.10.0-medical-research-dossier

/**
 * v2.10.1 — Medical Research Dossier models.
 *
 * These models elevate the final export from a short app brief to a research-grade
 * medical evidence dossier. They separate established science from GTIM exploration,
 * keep all therapeutic routes as research hypotheses, and require an explicit
 * validation-status statement for anything the app discovers or imports.
 */
data class GTIMEstablishedEvidenceCardV2100(
    val cardId: String,
    val topicArea: String,
    val statement: String,
    val evidenceLevel: String,
    val evidenceKind: String,
    val applicabilityLimit: String,
    val line: String
)

data class GTIMDiscoveryFindingCardV2100(
    val findingId: String,
    val sourceLayer: String,
    val finding: String,
    val evidenceState: String,
    val validationStatus: String,
    val requiredNextEvidence: String,
    val line: String
)

data class GTIMMechanismAxisCardV2100(
    val axisId: String,
    val mechanismChain: String,
    val supportState: String,
    val requiredEvidence: List<String>,
    val line: String
)

data class GTIMTherapeuticRouteCardV2100(
    val routeId: String,
    val routeClass: String,
    val biologicalRationale: String,
    val requiredBiomarkersOrEvidence: List<String>,
    val evidenceLevel: String,
    val validationStatus: String,
    val forbiddenClaims: List<String>,
    val line: String
)

data class GTIMValidationLimitCardV2100(
    val limitId: String,
    val statement: String,
    val severity: String,
    val line: String
)

data class GTIMMedicalResearchDossierReportV2100(
    val active: Boolean,
    val version: String,
    val state: String,
    val targetId: String,
    val researchQuestion: String,
    val establishedEvidence: List<GTIMEstablishedEvidenceCardV2100>,
    val discoveryFindings: List<GTIMDiscoveryFindingCardV2100>,
    val mechanismMap: List<GTIMMechanismAxisCardV2100>,
    val therapeuticRoutes: List<GTIMTherapeuticRouteCardV2100>,
    val validationLimits: List<GTIMValidationLimitCardV2100>,
    val researchProtocol: GTIMResearchProtocolCardV2101?,
    val searchStrategy: GTIMSearchStrategyCardV2101?,
    val evidenceTable: List<GTIMEvidenceTableRowV2101>,
    val authorityValidationStatements: List<GTIMAuthorityValidationStatementV2101>,
    val immunotherapyHypothesisCards: List<GTIMTherapeuticHypothesisCardV2102>,
    val clinicalTrialsRequestPlans: List<GTIMClinicalTrialsRequestPlanV2102>,
    val authorityEvidenceRequestPlans: List<GTIMAuthorityEvidenceRequestPlanV2103>,
    val knowledgeAssetContract: GTIMKnowledgeAssetContractReportV2103?,
    val immunotherapyKnowledgeLine: String,
    val evidenceDossierGrade: String,
    val conciseLines: List<String>,
    val boundaryLine: String,
    val explorationPosture: GTIMExplorationPostureReportV2104? = null,
    val freeHypothesisSynthesis: GTIMFreeHypothesisSynthesisReportV2105? = null,
    val hypothesisLearningLedger: GTIMHypothesisLearningLedgerReportV2106? = null,
    val ecoImmuneRootCause: GTIMEcoImmuneRootCauseReportV2108? = null,
    val dataHarmonization: GTIMDataHarmonizationReportV2110? = null,
    val ciHardeningGuard: GTIMCiHardeningGuardReportV2109? = null
) {
    companion object {
        fun empty(targetId: String = "UNKNOWN"): GTIMMedicalResearchDossierReportV2100 = GTIMMedicalResearchDossierReportV2100(
            active = false,
            version = GTIMMedicalResearchDossierBuilderV2100.VERSION,
            state = "MEDICAL_RESEARCH_DOSSIER_NOT_EVALUATED",
            targetId = targetId,
            researchQuestion = "No dossier context available.",
            establishedEvidence = emptyList(),
            discoveryFindings = emptyList(),
            mechanismMap = emptyList(),
            therapeuticRoutes = emptyList(),
            validationLimits = GTIMMedicalResearchDossierBuilderV2100.defaultValidationLimits(),
            researchProtocol = null,
            searchStrategy = null,
            evidenceTable = emptyList(),
            authorityValidationStatements = emptyList(),
            immunotherapyHypothesisCards = emptyList(),
            clinicalTrialsRequestPlans = emptyList(),
            authorityEvidenceRequestPlans = emptyList(),
            knowledgeAssetContract = null,
            immunotherapyKnowledgeLine = "Immunotherapy knowledge base: not evaluated.",
            evidenceDossierGrade = "NOT_EVALUATED",
            conciseLines = emptyList(),
            boundaryLine = GTIMMedicalResearchDossierBuilderV2100.BOUNDARY,
            explorationPosture = null,
            freeHypothesisSynthesis = GTIMFreeHypothesisSynthesisReportV2105.empty(),
            hypothesisLearningLedger = GTIMHypothesisLearningLedgerReportV2106.empty(),
            ecoImmuneRootCause = GTIMEcoImmuneRootCauseReportV2108.empty(),
            dataHarmonization = GTIMDataHarmonizationReportV2110.empty(),
            ciHardeningGuard = GTIMCiHardeningGuardReportV2109.empty()
        )
    }
}
