package com.immunesignal.app

// v2.10.4 — Relaxed authority evidence request planning.
// Authority checks are expansion hints for later validation, not blockers for research hypothesis generation.
data class GTIMAuthorityEvidenceRequestPlanV2103(
    val planId: String,
    val mechanismId: String,
    val state: String,
    val sourceType: String,
    val queryTerm: String,
    val requestTarget: String,
    val rankPurpose: String,
    val noHttpExecution: Boolean,
    val line: String
)

object GTIMAuthorityEvidenceRequestPlannerV2103 {
    const val VERSION: String = "2.10.4-relaxed-authority-evidence-expansion-planner"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        cards: List<GTIMTherapeuticHypothesisCardV2102>
    ): List<GTIMAuthorityEvidenceRequestPlanV2103> {
        val anchor = contract.primaryAnchor.routeId.toSearchTerm().ifBlank { "immune genetic therapeutic mechanism" }
        return cards.take(5).flatMapIndexed { index, card ->
            val term = listOf(anchor, card.routeClass, card.requiredBiomarkers.take(3).joinToString(" "))
                .joinToString(" ")
                .toSearchTerm()
                .ifBlank { "immune therapy ${card.mechanismId}" }
            val rankPurpose = when {
                card.evidenceRank.contains("A", ignoreCase = true) -> "rank_A_candidate_can_be_explored_but_requires_source_before_claim"
                card.evidenceRank.contains("B", ignoreCase = true) -> "rank_B_candidate_explore_phase3_or_strong_clinical_context"
                card.evidenceRank.contains("C", ignoreCase = true) -> "rank_C_candidate_explore_early_clinical_or_case_series_context"
                card.evidenceRank.contains("X", ignoreCase = true) -> "rank_X_safety_contradiction_review_priority"
                else -> "exploratory_rank_can_surface_with_literature_dataset_or_capsule_followup"
            }
            listOf(
                plan(index, card, "FDA_OR_AUTHORITY_LABEL", term, "Drugs@FDA / regulator label search", rankPurpose),
                plan(index, card, "GUIDELINE_OR_PROFESSIONAL_BODY", term, "guideline or professional society source search", rankPurpose),
                plan(index, card, "PUBMED_SYSTEMATIC_OR_CLINICAL_EVIDENCE", term, "PubMed / systematic review / trial publication search", rankPurpose)
            )
        }
    }

    private fun plan(
        index: Int,
        card: GTIMTherapeuticHypothesisCardV2102,
        sourceType: String,
        term: String,
        target: String,
        purpose: String
    ): GTIMAuthorityEvidenceRequestPlanV2103 {
        val id = "AUTH_PLAN_${index + 1}_${card.mechanismId}_${sourceType}"
        val state = when {
            card.mechanismId == "open_mechanism_exploration" -> "EVIDENCE_EXPANSION_OPEN_EXPLORATION_HINT"
            card.validationStatus.contains("RANK_A_CANDIDATE", ignoreCase = true) -> "EVIDENCE_EXPANSION_HINT_FOR_RANK_A_CANDIDATE"
            card.evidenceRank.contains("X", ignoreCase = true) -> "SAFETY_REVIEW_HINT_FOR_UNSAFE_OR_ESCAPE_CLAIM"
            else -> "EVIDENCE_EXPANSION_HINT_READY_NO_HTTP_EXECUTION"
        }
        val line = "Authority evidence expansion hint: version=$VERSION | id=$id | state=$state | source_type=$sourceType | query_term=${term.oneLine()} | target=$target | purpose=$purpose | no_http_execution=true | not_a_discovery_blocker=true | candidate_rank_allowed_if_labeled_unverified=true"
        return GTIMAuthorityEvidenceRequestPlanV2103(
            planId = id,
            mechanismId = card.mechanismId,
            state = state,
            sourceType = sourceType,
            queryTerm = term,
            requestTarget = target,
            rankPurpose = purpose,
            noHttpExecution = true,
            line = line
        )
    }

    private fun String.toSearchTerm(): String = replace(Regex("[^A-Za-z0-9 _/+.-]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
