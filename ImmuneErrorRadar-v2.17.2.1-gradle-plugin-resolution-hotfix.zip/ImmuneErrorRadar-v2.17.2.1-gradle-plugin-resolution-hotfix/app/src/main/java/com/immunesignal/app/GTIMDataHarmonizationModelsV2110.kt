package com.immunesignal.app

// v2.11.0 — Lightweight data-harmonization models.
// Purpose: keep heterogeneous public data useful for solution discovery while
// preventing weak cross-domain links from being promoted to causal conclusions.

data class GTIMSourceCapsuleV2110(
    val capsuleId: String,
    val sourceFamily: String,
    val evidenceKind: String,
    val contextFields: List<String>,
    val alignmentUse: String,
    val qualityState: String,
    val line: String
)

data class GTIMResearchObjectV2110(
    val objectId: String,
    val topic: String,
    val phenotypeOrDisease: String,
    val mechanismBridge: String,
    val tissueOrContext: String,
    val exposureOrSourceContext: String,
    val claimLimit: String,
    val line: String
)

data class GTIMEvidenceAlignmentV2110(
    val alignmentLevel: String,
    val score: Int,
    val mechanismBridgeFound: Boolean,
    val heterogeneousSources: List<String>,
    val confidenceUse: String,
    val line: String
)

data class GTIMSpuriousCorrelationAssessmentV2110(
    val riskLevel: String,
    val policy: String,
    val downgradeReason: String,
    val allowedOutputState: String,
    val requiredUpgradeEvidence: List<String>,
    val line: String
)

data class GTIMHeterogeneousSolutionRouteV2110(
    val routeId: String,
    val routeClass: String,
    val routeLogic: String,
    val supportedBy: List<String>,
    val missingBridgeEvidence: List<String>,
    val outputState: String,
    val line: String
)

data class GTIMDataHarmonizationReportV2110(
    val active: Boolean,
    val version: String,
    val state: String,
    val policy: String,
    val sourceCapsules: List<GTIMSourceCapsuleV2110>,
    val researchObject: GTIMResearchObjectV2110?,
    val evidenceAlignment: GTIMEvidenceAlignmentV2110?,
    val spuriousCorrelationAssessment: GTIMSpuriousCorrelationAssessmentV2110?,
    val solutionRoutes: List<GTIMHeterogeneousSolutionRouteV2110>,
    val line: String,
    val boundaryLine: String
) {
    companion object {
        fun empty(): GTIMDataHarmonizationReportV2110 = GTIMDataHarmonizationReportV2110(
            active = false,
            version = GTIMDataHarmonizationGuardV2110.VERSION,
            state = "DATA_HARMONIZATION_NOT_EVALUATED",
            policy = GTIMDataHarmonizationGuardV2110.POLICY,
            sourceCapsules = emptyList(),
            researchObject = null,
            evidenceAlignment = null,
            spuriousCorrelationAssessment = null,
            solutionRoutes = emptyList(),
            line = "Data harmonization: not evaluated.",
            boundaryLine = GTIMDataHarmonizationGuardV2110.BOUNDARY
        )
    }
}
