package com.immunesignal.app

/** v2.8.0 — Metadata cleaner/normalizer. Produces evidence-backed label suggestions only. */
data class GTIMMetadataCleanerReportV2800(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val normalizedFields: List<String>,
    val labelSuggestionPolicy: String,
    val metadataCleanerLine: String,
    val boundaryLine: String
)

object GTIMMetadataCleanerV2800 {
    const val VERSION: String = "2.8.0-metadata-cleaner"
    val REQUIRED_FIELDS: List<String> = listOf(
        "sample_id", "title", "source_name", "characteristics", "disease", "tissue",
        "cell_type", "treatment", "severity", "timepoint", "case_control", "response_label"
    )

    fun build(
        matrixAuditCard: GTIMMatrixAuditCardReportV2745,
        etlBridge: GTIMMatrixEtlMetadataBridgeReportV2780,
        matrixReader: GTIMMatrixReaderPreviewReportV2800
    ): GTIMMetadataCleanerReportV2800 {
        if (matrixReader.state.contains("BLOCKED_NO_TOPIC", true)) {
            return report(matrixAuditCard.targetId, "METADATA_CLEANER_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", emptyList(), "NO_LABEL_SUGGESTION", "Metadata cleaner: version=$VERSION | state=METADATA_CLEANER_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | target=${matrixAuditCard.targetId} | normalized_fields=none | evidence_snippet_required=true")
        }
        val hasMetadataCandidate = etlBridge.metadataNormalizationState.contains("CANDIDATE", true) ||
            matrixAuditCard.metadataTraitState != "ACCESSION_HANDLE_ONLY" ||
            matrixAuditCard.verifiedMetadataSlots.isNotEmpty()
        val state = if (hasMetadataCandidate) "METADATA_NORMALIZATION_REVIEW_READY" else "METADATA_EXTRACTION_REQUIRED"
        val fields = (matrixAuditCard.verifiedMetadataSlots + REQUIRED_FIELDS).distinct().take(12)
        val policy = "suggestion_only_confidence_source_field_evidence_snippet_required"
        val line = "Metadata cleaner: version=$VERSION | state=$state | target=${matrixAuditCard.targetId} | normalized_fields=${fields.joinToString(",")} | label_policy=$policy | llm_label_final_truth=false"
        return report(matrixAuditCard.targetId, state, fields, policy, line)
    }

    private fun report(target: String, state: String, fields: List<String>, policy: String, line: String): GTIMMetadataCleanerReportV2800 =
        GTIMMetadataCleanerReportV2800(
            active = true,
            targetId = target,
            state = state,
            normalizedFields = fields,
            labelSuggestionPolicy = policy,
            metadataCleanerLine = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Metadata cleaner boundary: label suggestions are review-only and require source_field plus evidence_snippet; no LLM label is final truth."
        )
}
