package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.13 — Hypothesis variants and discriminator tests.
 *
 * Forces 2–4 competing research hypotheses instead of a single scenario, then attaches
 * a discriminator test and falsification trigger to each variant.
 */
object GTIMHypothesisVariantDiscriminatorV21213 {
    const val VERSION: String = "2.12.13-hypothesis-variants-discriminator"
    const val CLAIM_LIMIT: String = "hypothesis_variants_research_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val domain = domain(report)
        val targetCard = report.optJSONObject("targetValidationCardV21213") ?: GTIMTargetValidationCardV21213.toJson(report)
        val handles = jsonStrings(targetCard.optJSONArray("datasetAnchors"))
        val variants = variants(domain, handles.firstOrNull())
        return JSONObject()
            .put("version", VERSION)
            .put("state", "COMPETING_HYPOTHESES_REQUIRED")
            .put("domainKey", domain)
            .put("variants", variants)
            .put("bestNextDiscriminator", bestNextDiscriminator(domain, handles.firstOrNull()))
            .put("promotionRule", "one hypothesis may advance only after metadata/comparator/sample/capsule and contradiction checks")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val variants = obj.optJSONArray("variants") ?: JSONArray()
        val first = variants.optJSONObject(0)?.optString("hypothesis") ?: "no hypothesis generated"
        return listOf(
            "Hypothesis variants + discriminator",
            "State: ${obj.optString("state", "UNKNOWN")}; variants=${variants.length()}; top variant=${first.takeClean(220)}",
            "Best next discriminator: ${obj.optString("bestNextDiscriminator", "metadata + comparator + capsule + contradiction check").takeClean(260)}",
            "Boundary: variants are research hypotheses, not medical or mechanistic proof."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "COMPETING_HYPOTHESES_REQUIRED",
        "bestNextDiscriminator",
        "one hypothesis may advance only after metadata/comparator/sample/capsule",
        CLAIM_LIMIT
    ))

    private fun variants(domain: String, handle: String?): JSONArray {
        val h = handle?.let { " using $it" }.orEmpty()
        val list = when (domain) {
            "depression_kynurenine_neuroimmune" -> listOf(
                item("H1_IDO1_inflammatory_shift", "IDO1-driven inflammatory tryptophan→kynurenine shift may define a depression subgroup$h.", "kynurenine/tryptophan ratio + IDO1 + IL-6/TNF separates depression/control or high-inflammation groups", "no comparator separation or no IDO1/kynurenine signal under topic-compatible sample labels"),
                item("H2_KMO_neurotoxic_branch", "KMO-side kynurenine branch imbalance may better explain neuroimmune stress than generic inflammation$h.", "KMO/kynurenine branch readouts outperform generic cytokine markers", "KMO branch absent, wrong tissue/species, or no independent support"),
                item("H3_neurotransmission_bridge", "Cytokine tone may affect neurotransmission/glutamate/NMDA context without requiring microbiome causality$h.", "neuroimmune + neurotransmission/module signal appears before microbiome/barrier claim", "signal only appears in unrelated gut/barrier contexts or is contradicted")
            )
            "viral_interferon_cytokine" -> listOf(
                item("H1_interferon_timing", "Viral severity/recovery may be driven by interferon timing rather than generic barrier dysfunction$h.", "early/late IFN module separates severity, recovery, or persistence labels", "IFN timing cannot separate comparator groups"),
                item("H2_cytokine_amplification", "IL-6/TNF amplification may track severity or inflammatory persistence$h.", "IL-6/TNF module plus sample timing tracks severity/recovery", "cytokine module absent or only non-specific inflammation"),
                item("H3_tissue_injury_host_response", "Endothelial/tissue injury host-response may dominate over mucosal/barrier context$h.", "tissue injury/endothelial module improves route fit", "wrong tissue/species or no injury module support")
            )
            "allergy_type2_barrier" -> listOf(
                item("H1_type2_threshold", "Type-2 inflammatory threshold instability may be the core route$h.", "IL-4/IL-13, IgE, eosinophil/mast markers separate groups", "type-2 markers absent or comparator labels unusable"),
                item("H2_epithelial_barrier", "Epithelial barrier dysfunction may be a measurable repair-function route$h.", "epithelial/barrier marker set separates phenotype groups", "barrier signal absent or non-specific"),
                item("H3_tolerance_context", "Tolerance instability may explain subgroup response better than general microbiome support$h.", "tolerance/readout markers improve topic-fit", "no tolerance marker or no sample provenance")
            )
            else -> listOf(
                item("H1_domain_specific_route", "A domain-specific route may exist but needs a dataset anchor$h.", "metadata + comparator + capsule signal supports the route", "no topic-compatible seed or comparator labels"),
                item("H2_alternative_route", "An alternative mechanism may outperform the first retrieved template$h.", "diversified target lexicon finds a better target/readout", "only generic template remains after expansion")
            )
        }
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        return arr
    }

    private fun item(id: String, hypothesis: String, discriminator: String, falsifier: String): JSONObject = JSONObject()
        .put("id", id)
        .put("hypothesis", hypothesis)
        .put("discriminatorTest", discriminator)
        .put("falsificationTrigger", falsifier)
        .put("claimLimit", "hypothesis_only_no_evidence_upgrade")

    private fun bestNextDiscriminator(domain: String, handle: String?): String {
        val h = handle ?: "the strongest candidate seed"
        return when (domain) {
            "depression_kynurenine_neuroimmune" -> "For $h: compare IDO1, KMO, kynurenine/tryptophan, IL-6/TNF, and neuroimmune/transmission modules with depression/control labels."
            "viral_interferon_cytokine" -> "For $h: compare interferon timing, IL-6/TNF, tissue injury modules, and severity/recovery labels before any repair hypothesis."
            "allergy_type2_barrier" -> "For $h: compare IgE/eosinophil/mast, IL-4/IL-13, epithelial barrier, and phenotype labels."
            else -> "For $h: require metadata, comparator labels, sample linkage, capsule/matrix hint, and contradiction check."
        }
    }

    private fun domain(report: JSONObject): String = report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainKey")
        ?: report.optJSONObject("terminalDiscoveryContinuationV21212")?.optString("domainKey")
        ?: GTIMStudyFocusNormalizerV21282.build(report.toString()).domain

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx -> array.optString(idx).takeIf { it.isNotBlank() } }

    private fun String.takeClean(max: Int): String {
        val clean = replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= max) clean else clean.take(max).trimEnd()
    }
}
