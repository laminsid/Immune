package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.14 — Professional report surface sanity guard.
 *
 * Final report polish layer. It does not replace the route engines; it verifies that the
 * first decision surface is coherent: study focus matches the route, allergy/type-2 is not
 * leaked into viral reports, candidate handles are separated from verified capsules, and
 * the report stays research-only.
 */
object GTIMReportProfessionalSurfaceSanityV21214 {
    const val VERSION: String = "2.12.14-professional-report-surface-sanity"
    const val CLAIM_LIMIT: String = "surface_sanity_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val domain = domain(report)
        val routeText = routeText(report)
        val abstractText = abstractText(report)
        val candidateHandles = handles(report.toString())
        val verifiedCapsuleCount = verifiedCapsuleCount(report)
        val contamination = contaminationReason(domain, abstractText, routeText)
        val requiredBlocks = requiredBlocks(report)
        val missing = JSONArray(requiredBlocks.filter { !report.has(it) })
        val ready = contamination.isBlank() && missing.length() == 0
        return JSONObject()
            .put("version", VERSION)
            .put("surfaceState", if (ready) "PROFESSIONAL_FIRST_SURFACE_READY" else "PROFESSIONAL_SURFACE_NEEDS_REVIEW")
            .put("domainKey", domain.ifBlank { "unknown" })
            .put("routeText", routeText.takeClean(320))
            .put("abstractRouteContamination", contamination.ifBlank { "none_detected" })
            .put("candidate_handles", candidateHandles)
            .put("verified_capsule_source_count", verifiedCapsuleCount)
            .put("candidateVsVerifiedCapsuleSeparated", true)
            .put("requiredFirstSurfaceBlocks", JSONArray(requiredBlocks))
            .put("missingFirstSurfaceBlocks", missing)
            .put("firstSurfaceContract", "abstract_result_repair_seed_continuation_target_variants_strictness_closure_before_technical_trace")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val candidates = jsonStrings(obj.optJSONArray("candidate_handles")).take(4).joinToString(", ").ifBlank { "none" }
        return listOf(
            "Professional report surface sanity",
            "State: ${obj.optString("surfaceState", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}; contamination=${obj.optString("abstractRouteContamination", "unknown")}",
            "Candidate handles: $candidates; verified_capsule_source_count=${obj.optInt("verified_capsule_source_count", 0)}; separated=${obj.optBoolean("candidateVsVerifiedCapsuleSeparated", true)}.",
            "Contract: first page shows study focus, result, repair function, seed/continuation plan, target/readout, variants, strictness, and closure before technical trace."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "PROFESSIONAL_FIRST_SURFACE_READY",
        "candidate_handles",
        "verified_capsule_source_count",
        "candidateVsVerifiedCapsuleSeparated",
        "abstract_result_repair_seed_continuation_target_variants_strictness_closure_before_technical_trace",
        CLAIM_LIMIT
    ))

    private fun requiredBlocks(report: JSONObject): List<String> = listOf(
        "finalResearchValueBoosterV212101",
        "curatedMetadataSeedLibraryV21211",
        "terminalDiscoveryContinuationV21212",
        "publishedResearchUtilityScoreV21213",
        "targetValidationCardV21213",
        "hypothesisVariantDiscriminatorV21213",
        "pharmaGradeStrictnessGateV21213"
    )

    private fun domain(report: JSONObject): String = report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainKey").orEmpty()
        .ifBlank { report.optJSONObject("targetValidationCardV21213")?.optString("domainKey").orEmpty() }
        .ifBlank { GTIMStudyFocusNormalizerV21282.build(report.toString()).domain }

    private fun routeText(report: JSONObject): String = listOf(
        report.optJSONObject("studyFocusNormalizerV21282")?.optString("route").orEmpty(),
        report.optJSONObject("studyResultCardV2126")?.optString("studyFocus").orEmpty(),
        report.optJSONObject("terminalDiscoveryContinuationV21212")?.optString("routeText").orEmpty(),
        report.optJSONObject("reportConsistencyGateV2121")?.optString("researchRoute").orEmpty()
    ).filter { it.isNotBlank() }.joinToString(" | ").ifBlank { report.toString().takeClean(600) }

    private fun abstractText(report: JSONObject): String = listOf(
        report.optJSONObject("finalGlobalStudyDossierV2127")?.optString("studyFrame").orEmpty(),
        report.optJSONObject("finalGlobalStudyDossierV2127")?.optString("studyFocus").orEmpty(),
        report.optJSONObject("studyFocusNormalizerV21282")?.optString("studyFocus").orEmpty(),
        report.optJSONObject("studyResultCardV2126")?.optString("studyFocus").orEmpty()
    ).filter { it.isNotBlank() }.joinToString(" | ")

    private fun contaminationReason(domain: String, abstractText: String, routeText: String): String {
        val combined = "$abstractText | $routeText"
        val looksViral = domain.contains("viral", true) || combined.contains("COVID", true) || combined.contains("Ebola", true) || combined.contains("filovirus", true) || combined.contains("interferon", true)
        val allergyLeak = abstractText.contains("allergy/type-2", true) || abstractText.contains("allergy_type2", true)
        return when {
            looksViral && allergyLeak -> "viral_report_contains_allergy_type2_surface_leak"
            domain.contains("depression_kynurenine", true) && abstractText.contains("allergy/type-2", true) -> "depression_kynurenine_report_contains_allergy_type2_surface_leak"
            else -> ""
        }
    }

    private fun verifiedCapsuleCount(report: JSONObject): Int {
        val consistency = report.optJSONObject("reportConsistencyGateV2121") ?: JSONObject()
        val matrixCount = consistency.optInt("verifiedMatrixFiles", 0).coerceAtLeast(0)
        val capsuleCount = report.optJSONObject("finalResearchValueBoosterV212101")
            ?.optJSONObject("matrixCapsulePlan")
            ?.optInt("verified_capsule_source_count", -1) ?: -1
        return if (capsuleCount >= 0) capsuleCount else matrixCount
    }

    private fun handles(text: String): JSONArray {
        val out = JSONArray()
        Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|SRR\\d+|PRJNA\\d+|PRJEB\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+|PMID:?\\d+|10\\.\\d{4,9}/[^\\s\\\"']+)\\b", RegexOption.IGNORE_CASE)
            .findAll(text)
            .map { it.value.uppercase() }
            .distinct()
            .take(12)
            .forEach { out.put(it) }
        return out
    }

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx -> array.optString(idx).takeIf { it.isNotBlank() } }

    private fun String.takeClean(max: Int): String {
        val clean = replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= max) clean else clean.take(max).trimEnd()
    }
}
