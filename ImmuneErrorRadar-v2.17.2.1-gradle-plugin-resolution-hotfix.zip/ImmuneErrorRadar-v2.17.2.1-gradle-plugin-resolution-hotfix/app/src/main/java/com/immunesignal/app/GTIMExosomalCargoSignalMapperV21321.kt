package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Maps exosomal cargo classes into safe hypothesis axes. */
object GTIMExosomalCargoSignalMapperV21321 {
    const val VERSION: String = "2.13.21-exosomal-cargo-signal-mapper"
    const val STATE_READY: String = "EXOSOMAL_CARGO_SIGNAL_MAPPER_READY"
    const val CLAIM_LIMIT: String = "cargo_mapping_is_hypothesis_context_not_validated_transfer_or_biomarker_claim"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("cargo_axes", JSONArray(listOf("RNA_cargo", "protein_cargo", "lipid_cargo", "surface_targeting_signature", "immune_suppression_or_activation_cargo")))
        .put("candidate_questions", JSONArray(listOf(
            "Does exosomal cargo transmit immune suppression or training across tissue compartments?",
            "Does tumor-derived vesicle cargo precondition immune niches before visible spread?",
            "Does inflammatory vesicle cargo explain systemic coordination better than cytokines alone?"
        )))
        .put("validated_transfer_claim_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
