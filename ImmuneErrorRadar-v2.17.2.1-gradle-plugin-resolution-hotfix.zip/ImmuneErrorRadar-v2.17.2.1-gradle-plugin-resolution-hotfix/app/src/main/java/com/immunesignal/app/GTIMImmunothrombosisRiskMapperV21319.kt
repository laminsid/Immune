package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Immunothrombosis/thromboinflammation risk hypothesis mapper. */
object GTIMImmunothrombosisRiskMapperV21319 {
    const val VERSION: String = "2.13.19-immunothrombosis-risk-mapper"
    const val CLAIM_LIMIT: String = "immunothrombosis_risk_hypothesis_not_clinical_prediction"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val contexts = mutableListOf<String>()
        if (active.contains("hantavirus") || active.contains("covid") || active.contains("filovirus")) contexts += "viral_lung_or_vascular_injury"
        if (report.optString("topic", "").lowercase().contains("sepsis")) contexts += "sepsis_organ_failure"
        if (active.contains("cancer")) contexts += "tumor_NET_shield_metastasis"
        if (contexts.isEmpty()) contexts += "open_thromboinflammation_context"
        return JSONObject()
            .put("version", VERSION)
            .put("state", "IMMUNOTHROMBOSIS_RISK_MAPPING_READY")
            .put("contexts", JSONArray(contexts))
            .put("clinical_prediction_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }
}
