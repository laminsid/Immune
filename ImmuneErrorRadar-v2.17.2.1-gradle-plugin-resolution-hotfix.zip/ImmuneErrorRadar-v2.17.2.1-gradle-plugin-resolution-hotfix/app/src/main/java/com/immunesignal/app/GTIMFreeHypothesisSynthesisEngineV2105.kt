package com.immunesignal.app

// v2.10.5 — Free, grounded hypothesis synthesis engine.
// Purpose: let GTIM connect dots beyond already-approved or already-documented uses,
// without turning speculative research routes into medical advice.
object GTIMFreeHypothesisSynthesisEngineV2105 {
    const val VERSION: String = "2.10.5-free-hypothesis-synthesis"
    const val BOUNDARY: String = "free_research_hypothesis_synthesis_not_clinical_claim_no_dosing_no_treatment_selection_no_medication_stop_no_efficacy_claim"

    val ANTI_HALLUCINATION_LOCKS: List<String> = listOf(
        "no_hypothesis_without_mechanism_basis",
        "no_mechanism_claim_without_foundation_or_analogy",
        "no_therapeutic_route_without_biomarker_or_pathway_prompt",
        "must_state_missing_evidence",
        "must_state_falsification_tests",
        "authority_evidence_is_weight_not_discovery_blocker",
        "clinical_action_claims_remain_locked"
    )

    fun build(
        contract: GTIMRunDecisionContractV2740,
        establishedEvidence: List<GTIMEstablishedEvidenceCardV2100>,
        discoveryFindings: List<GTIMDiscoveryFindingCardV2100>,
        mechanismMap: List<GTIMMechanismAxisCardV2100>,
        therapeuticRoutes: List<GTIMTherapeuticRouteCardV2100>,
        immunotherapyCards: List<GTIMTherapeuticHypothesisCardV2102>,
        explorationPosture: GTIMExplorationPostureReportV2104,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802,
        latentAxisFilterOverride: GTIMLatentAxisFilterReportV2107? = null,
        ecoImmuneRootCause: GTIMEcoImmuneRootCauseReportV2108? = null
    ): GTIMFreeHypothesisSynthesisReportV2105 {
        val latentAxisFilter = latentAxisFilterOverride ?: GTIMLatentAxisFilterV2107.build(
            contract = contract,
            establishedEvidence = establishedEvidence,
            discoveryFindings = discoveryFindings,
            mechanismMap = mechanismMap,
            therapeuticRoutes = therapeuticRoutes,
            immunotherapyCards = immunotherapyCards,
            dgeVerdict = dgeVerdict
        )
        val cardsFromImmunotherapy = immunotherapyCards
            .sortedByDescending { card -> latentAxisFilter.routeAffinity(card.routeClass + " " + card.mechanismId) }
            .take(6)
            .mapIndexed { index, card ->
                cardFromImmunotherapy(index, contract, card, establishedEvidence, discoveryFindings, mechanismMap, dgeVerdict, latentAxisFilter, ecoImmuneRootCause)
            }
        val fallbackCards = if (cardsFromImmunotherapy.isEmpty()) {
            therapeuticRoutes
                .sortedByDescending { route -> latentAxisFilter.routeAffinity(route.routeClass + " " + route.biologicalRationale) }
                .take(3)
                .mapIndexed { index, route ->
                    cardFromRoute(index, contract, route, establishedEvidence, discoveryFindings, mechanismMap, dgeVerdict, latentAxisFilter, ecoImmuneRootCause)
                }
        } else emptyList()
        val cards = (cardsFromImmunotherapy + fallbackCards).ifEmpty {
            listOf(genericOpenCard(contract, establishedEvidence, discoveryFindings, mechanismMap, dgeVerdict, latentAxisFilter, ecoImmuneRootCause))
        }
        val state = when {
            cards.any { it.explorationRank.contains("NOVEL", ignoreCase = true) } -> "FREE_SYNTHESIS_NOVEL_HYPOTHESES_AVAILABLE_RESEARCH_ONLY"
            cards.any { it.explorationRank.contains("ESTABLISHED_FOUNDATION", ignoreCase = true) } -> "FREE_SYNTHESIS_ESTABLISHED_FOUNDATION_WITH_EXTENSION"
            else -> "FREE_SYNTHESIS_OPEN_RESEARCH_ROUTES_AVAILABLE"
        }
        val synthesisMode = "connect_established_immune_genetic_mechanisms_to_new_research_hypotheses_without_requiring_prior_authority_approval"
        val foundationUse = "traditional_evidence_builds_foundation_and_rank_weight_but_does_not_cap_exploration"
        val line = "Free hypothesis synthesis: version=$VERSION | state=$state | mode=$synthesisMode | foundation_use=$foundationUse | cards=${cards.size} | posture=${explorationPosture.state} | locks=${ANTI_HALLUCINATION_LOCKS.joinToString(",")} | boundary=$BOUNDARY"
        return GTIMFreeHypothesisSynthesisReportV2105(
            active = true,
            version = VERSION,
            state = state,
            synthesisMode = synthesisMode,
            foundationUse = foundationUse,
            cards = cards,
            antiHallucinationLocks = ANTI_HALLUCINATION_LOCKS,
            boundaryLine = BOUNDARY,
            line = line
        )
    }

    private fun cardFromImmunotherapy(
        index: Int,
        contract: GTIMRunDecisionContractV2740,
        card: GTIMTherapeuticHypothesisCardV2102,
        established: List<GTIMEstablishedEvidenceCardV2100>,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        mechanisms: List<GTIMMechanismAxisCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        ecoImmuneRootCause: GTIMEcoImmuneRootCauseReportV2108?
    ): GTIMFreeHypothesisSynthesisCardV2105 {
        val basis = mechanismBasis(card.routeClass, mechanisms)
        val analogy = analogyFor(card.mechanismId, card.routeClass)
        val latentMissing = latentAxisFilter.promptsFor(card.routeClass + " " + card.mechanismId)
        val rootMissing = rootCauseMissing(ecoImmuneRootCause)
        val missing = (rootMissing + card.requiredBiomarkers + card.resistancePatterns.take(2) + latentMissing + discoveryMissing(discovery) + dgeMissing(dgeVerdict)).distinct().take(8)
        val support = supportBasis(card.evidenceRank, established, discovery, mechanisms)
        val falsifiers = (falsificationFor(card.mechanismId, missing, dgeVerdict) + latentAxisFilter.falsifiersFor(card.routeClass + " " + card.mechanismId) + rootCauseFalsifiers(ecoImmuneRootCause)).distinct().take(7)
        val rank = explorationRank(card.evidenceRank, card.validationStatus, dgeVerdict)
        val hypothesis = "If ${card.routeClass} shares an immune/genetic mechanism with ${contract.primaryAnchor.routeId}, GTIM can explore it as a research hypothesis even before direct authority validation, provided biomarkers, comparator evidence, and falsification tests remain explicit."
        val state = if (card.mechanismId == "open_mechanism_exploration") "OPEN_FREE_SYNTHESIS_RESEARCH_ONLY" else "GROUNDED_FREE_SYNTHESIS_RESEARCH_ONLY"
        val line = "Free hypothesis card: version=$VERSION | id=FHS_${index + 1}_${card.mechanismId} | authority_is_weight_not_blocker=true | no_clinical_action=true | state=$state | route=${card.routeClass} | exploration_rank=$rank | hypothesis=${hypothesis.oneLine()} | mechanism_basis=${basis.oneLine()} | analogy=${analogy.oneLine()} | support=${support.joinToString(";").oneLine()} | missing=${missing.joinToString(";").oneLine()} | falsify=${falsifiers.joinToString(";").oneLine()}"
        return GTIMFreeHypothesisSynthesisCardV2105(
            cardId = "FHS_${index + 1}_${card.mechanismId}",
            state = state,
            routeClass = card.routeClass,
            hypothesis = hypothesis,
            mechanismBasis = basis,
            crossDomainAnalogy = analogy,
            supportBasis = support,
            missingEvidence = missing,
            falsificationTests = falsifiers,
            explorationRank = rank,
            boundary = BOUNDARY,
            line = line
        )
    }

    private fun cardFromRoute(
        index: Int,
        contract: GTIMRunDecisionContractV2740,
        route: GTIMTherapeuticRouteCardV2100,
        established: List<GTIMEstablishedEvidenceCardV2100>,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        mechanisms: List<GTIMMechanismAxisCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        ecoImmuneRootCause: GTIMEcoImmuneRootCauseReportV2108?
    ): GTIMFreeHypothesisSynthesisCardV2105 {
        val basis = mechanismBasis(route.routeClass, mechanisms)
        val rootMissing = rootCauseMissing(ecoImmuneRootCause)
        val missing = (rootMissing + route.requiredBiomarkersOrEvidence + latentAxisFilter.promptsFor(route.routeClass + " " + route.biologicalRationale) + discoveryMissing(discovery) + dgeMissing(dgeVerdict)).distinct().take(8)
        val support = supportBasis(route.evidenceLevel, established, discovery, mechanisms)
        val falsifiers = (listOf(
            "no matching biomarker/pathway in topic-compatible metadata",
            "no comparator-backed signal after evidence capsule or DGE review",
            "route contradicts established safety or mechanism evidence"
        ) + latentAxisFilter.falsifiersFor(route.routeClass + " " + route.biologicalRationale) + rootCauseFalsifiers(ecoImmuneRootCause)).distinct().take(7)
        val hypothesis = "GTIM may translate ${route.routeClass} from a known immune/genetic pattern into an explorable hypothesis for ${contract.primaryAnchor.routeId}, without requiring that this exact use was already documented."
        val rank = if (route.evidenceLevel.contains("E", true) || route.validationStatus.contains("DISCOVERY", true)) "NOVEL_E_MECHANISM_ONLY_ALLOWED" else "NOVEL_CONTEXT_EXTENSION_ALLOWED"
        val line = "Free hypothesis card: version=$VERSION | id=FHS_ROUTE_${index + 1}_${route.routeId} | authority_is_weight_not_blocker=true | no_clinical_action=true | state=ROUTE_BASED_FREE_SYNTHESIS_RESEARCH_ONLY | route=${route.routeClass} | exploration_rank=$rank | hypothesis=${hypothesis.oneLine()} | mechanism_basis=${basis.oneLine()} | support=${support.joinToString(";").oneLine()} | missing=${missing.joinToString(";").oneLine()} | falsify=${falsifiers.joinToString(";").oneLine()}"
        return GTIMFreeHypothesisSynthesisCardV2105(
            cardId = "FHS_ROUTE_${index + 1}_${route.routeId}",
            state = "ROUTE_BASED_FREE_SYNTHESIS_RESEARCH_ONLY",
            routeClass = route.routeClass,
            hypothesis = hypothesis,
            mechanismBasis = basis,
            crossDomainAnalogy = "route translated from mechanism map and established/dataset foundation, not from direct treatment claim",
            supportBasis = support,
            missingEvidence = missing,
            falsificationTests = falsifiers,
            explorationRank = rank,
            boundary = BOUNDARY,
            line = line
        )
    }

    private fun genericOpenCard(
        contract: GTIMRunDecisionContractV2740,
        established: List<GTIMEstablishedEvidenceCardV2100>,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        mechanisms: List<GTIMMechanismAxisCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        ecoImmuneRootCause: GTIMEcoImmuneRootCauseReportV2108?
    ): GTIMFreeHypothesisSynthesisCardV2105 {
        val rootMissing = rootCauseMissing(ecoImmuneRootCause)
        val missing = (rootMissing + mechanisms.flatMap { it.requiredEvidence } + latentAxisFilter.missingEvidencePrompts + discoveryMissing(discovery) + dgeMissing(dgeVerdict)).distinct().take(8)
        val support = supportBasis("D_TO_E_EXPLORATORY", established, discovery, mechanisms)
        val hypothesis = "For ${contract.primaryAnchor.routeId}, GTIM can freely search for immune/genetic analogies across mechanisms, but every idea remains a falsifiable research lead until evidence is imported or generated."
        val line = "Free hypothesis card: version=$VERSION | id=FHS_OPEN_GENERAL | authority_is_weight_not_blocker=true | no_clinical_action=true | state=OPEN_GENERAL_FREE_SYNTHESIS_RESEARCH_ONLY | route=open immune/genetic hypothesis route | exploration_rank=NOVEL_OPEN_E_MECHANISM_ONLY_ALLOWED | hypothesis=${hypothesis.oneLine()} | support=${support.joinToString(";").oneLine()} | missing=${missing.joinToString(";").oneLine()} | falsify=no mechanism match; no biomarker; no comparator; contradiction or safety red flag"
        return GTIMFreeHypothesisSynthesisCardV2105(
            cardId = "FHS_OPEN_GENERAL",
            state = "OPEN_GENERAL_FREE_SYNTHESIS_RESEARCH_ONLY",
            routeClass = "open immune/genetic hypothesis route",
            hypothesis = hypothesis,
            mechanismBasis = mechanisms.firstOrNull()?.mechanismChain ?: "mechanism basis required before any upgrade",
            crossDomainAnalogy = "open analogy mining across immune mechanisms",
            supportBasis = support,
            missingEvidence = missing,
            falsificationTests = (listOf("no mechanism match", "no biomarker/pathway prompt", "no comparator", "contradiction or safety red flag") + latentAxisFilter.falsificationPrompts + rootCauseFalsifiers(ecoImmuneRootCause)).distinct().take(7),
            explorationRank = "NOVEL_OPEN_E_MECHANISM_ONLY_ALLOWED",
            boundary = BOUNDARY,
            line = line
        )
    }

    private fun supportBasis(
        rank: String,
        established: List<GTIMEstablishedEvidenceCardV2100>,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        mechanisms: List<GTIMMechanismAxisCardV2100>
    ): List<String> {
        val establishedLine = established.firstOrNull()?.statement ?: "established science layer available as foundation"
        val discoveryLine = discovery.firstOrNull()?.finding ?: "GTIM discovery layer can supply metadata/capsule/request-plan evidence"
        val mechanismLine = mechanisms.firstOrNull()?.mechanismChain ?: "mechanism map required"
        return listOf(
            "rank_context=$rank",
            "foundation=${establishedLine.oneLine()}",
            "discovery=${discoveryLine.oneLine()}",
            "mechanism=${mechanismLine.oneLine()}"
        )
    }

    private fun mechanismBasis(routeClass: String, mechanisms: List<GTIMMechanismAxisCardV2100>): String {
        val direct = mechanisms.firstOrNull { axis ->
            val text = (axis.axisId + " " + axis.mechanismChain).lowercase()
            routeClass.lowercase().split(Regex("[^a-z0-9]+"))
                .filter { it.length >= 4 }
                .any { token -> text.contains(token) }
        } ?: mechanisms.firstOrNull()
        return direct?.mechanismChain ?: "mechanism basis must be established from ontology, dataset, capsule, or literature before upgrade"
    }

    private fun analogyFor(mechanismId: String, routeClass: String): String = when (mechanismId) {
        "checkpoint_release" -> "known checkpoint success patterns can inspire exploration only when immune visibility, biomarker, and escape context are checked"
        "cellular_redirection" -> "cellular redirection success in one immune target can suggest analogies where antigen, HLA, or cell-compartment dominance exists"
        "cytokine_modulation" -> "cytokine-axis therapies can inspire cross-disease hypotheses when the same inflammatory axis and phenotype are present"
        "b_cell_reset" -> "B-cell reset evidence can inspire autoimmune hypotheses where autoantibody or B-cell dominance is observed"
        "ige_mast_cell_modulation" -> "IgE/mast-cell modulation can be translated only to IgE-mediated or mediator-backed allergy contexts"
        "passive_antiviral_antibody" -> "antibody neutralization patterns can inspire epidemic countermeasure hypotheses only with target conservation and escape checks"
        "innate_interferon_sting" -> "innate activation can connect DNA damage, infection, and immune visibility but timing/toxicity can falsify the route"
        "microbiome_barrier_modulation" -> "microbiome/barrier mechanisms can connect diet, metabolites, mucosa, and immune tone without becoming diet advice"
        "dna_repair_cell_cycle_apoptosis" -> "DNA repair and cell-cycle stress can connect tumor vulnerability with immune visibility as a testable combination idea"
        else -> "open cross-mechanism analogy from $routeClass; use as research lead only"
    }


    private fun rootCauseMissing(rootCause: GTIMEcoImmuneRootCauseReportV2108?): List<String> {
        if (rootCause == null || rootCause.candidates.isEmpty()) return emptyList()
        val anchor = listOf(
            "upstream eco-immune dysfunction evidence missing: microbiome/metabolic/barrier context unresolved",
            "root-cause transferability evidence required before upgrade: population_context and exposure ecology",
            "barrier or mucosal evidence required when microbiome/allergy/gut signals appear",
            "metabolic immune-state evidence required before route prioritization"
        )
        val candidateSpecific = rootCause.candidates.flatMap { candidate ->
            listOf(
                candidate.upstreamDysfunction,
                candidate.causalChain,
                candidate.restorationNeed
            ) + candidate.missingEvidence
        }
        return (anchor + candidateSpecific)
            .map { it.oneLine() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(6)
    }

    private fun rootCauseFalsifiers(rootCause: GTIMEcoImmuneRootCauseReportV2108?): List<String> =
        rootCause?.falsificationPlans?.flatMap { it.decisiveTests + it.weakeningSignals + it.invalidationRule }?.distinct()?.take(5) ?: emptyList()

    private fun discoveryMissing(discovery: List<GTIMDiscoveryFindingCardV2100>): List<String> = discovery
        .flatMap { listOf(it.requiredNextEvidence, it.validationStatus) }
        .filter { it.isNotBlank() }
        .take(4)

    private fun dgeMissing(dge: GTIMDgeReadinessVerdictReportV2802): List<String> = when {
        dge.verdict.contains("READY", ignoreCase = true) -> listOf("independent validation beyond review-only DGE")
        dge.blockers.isNotEmpty() -> dge.blockers.take(4)
        else -> listOf("DGE/capsule/provenance evidence")
    }

    private fun falsificationFor(mechanismId: String, missing: List<String>, dge: GTIMDgeReadinessVerdictReportV2802): List<String> {
        val base = mutableListOf<String>()
        base += when (mechanismId) {
            "passive_antiviral_antibody" -> "current variant/strain lacks neutralization or target conservation"
            "checkpoint_release" -> "topic lacks immune-visibility biomarker or shows immune-excluded/non-responder pattern"
            "b_cell_reset" -> "no B-cell/autoantibody dominance or relapse/safety signal dominates"
            "microbiome_barrier_modulation" -> "no barrier/metabolite/microbiome link after metadata or capsule review"
            else -> "mechanism/pathway not present in topic-compatible evidence"
        }
        base += if (dge.verdict.contains("READY", ignoreCase = true)) "DGE/capsule signal contradicts route direction" else "missing observed expression/capsule evidence remains unresolved"
        base += missing.take(2).map { "missing_evidence_not_resolved: $it" }
        return base.distinct().take(5)
    }

    private fun explorationRank(rank: String, validation: String, dge: GTIMDgeReadinessVerdictReportV2802): String = when {
        rank.contains("X", true) -> "X_SAFETY_OR_ESCAPE_REVIEW_ONLY_DO_NOT_PROMOTE"
        validation.contains("OPEN", true) -> "NOVEL_OPEN_E_MECHANISM_ONLY_ALLOWED"
        rank.contains("A_CANDIDATE", true) -> "ESTABLISHED_FOUNDATION_WITH_NOVEL_EXTENSION_ALLOWED"
        rank.contains("B", true) || rank.contains("C", true) -> "NOVEL_EXTENSION_WITH_CLINICAL_ANALOGY_ALLOWED"
        dge.verdict.contains("READY", true) -> "NOVEL_DATASET_BACKED_REVIEW_ONLY_ALLOWED"
        else -> "NOVEL_E_MECHANISM_ONLY_ALLOWED"
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
