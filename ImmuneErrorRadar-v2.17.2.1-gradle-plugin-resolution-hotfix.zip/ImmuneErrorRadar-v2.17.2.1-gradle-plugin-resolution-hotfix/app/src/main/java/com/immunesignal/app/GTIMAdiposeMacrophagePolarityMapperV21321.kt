package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Adipose tissue macrophage M1/M2 polarity mapping lens. */
object GTIMAdiposeMacrophagePolarityMapperV21321 {
    const val VERSION: String = "2.13.21-adipose-macrophage-polarity-mapper"
    const val STATE_READY: String = "ADIPOSE_MACROPHAGE_POLARITY_MAPPER_READY"
    const val CLAIM_LIMIT: String = "ATM_polarity_mapping_is_research_hypothesis_not_metabolic_diagnosis"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("polarity_axes", JSONArray(listOf("M2_repair_insulin_sensitivity_context", "M1_inflammatory_ATM_shift", "oxidative_stress_adipocyte_stress_axis", "chronic_low_grade_inflammation")))
        .put("diagnosis_claim_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
