package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.0 — Final closure for the future evidence lite corpus layer. */
object GTIMFutureLiteCorpusClosureV2130 {
    const val VERSION: String = "2.13.0-final-future-lite-corpus-closure"
    const val CLAIM_LIMIT: String = "future_corpus_closure_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val corpus = report.optJSONObject("futureEvidenceLiteCorpusV2130") ?: JSONObject()
        val composer = report.optJSONObject("futureHypothesisComposerV2130") ?: JSONObject()
        val gap = report.optJSONObject("mechanismGapAmplifierV2130") ?: JSONObject()
        val graph = report.optJSONObject("futureCorpusEvidenceGraphBridgeV2130") ?: JSONObject()
        val mismatch = composer.optString("state").contains("DOMAIN_MISMATCH") || graph.optString("state").contains("DOMAIN_MISMATCH")
        val ready = !mismatch && corpus.optString("state").contains("READY") && composer.optString("state").contains("READY") && graph.optString("state").contains("READY")
        val route = JSONArray(listOf(
            "future_lite_corpus",
            "future_hypothesis_composer",
            "mechanism_gap_amplifier",
            "future_corpus_graph_bridge",
            "evidence_capsule",
            "contradiction_engine",
            "minimum_viable_study_protocol",
            "red_team"
        ))
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (ready) "FUTURE_LITE_CORPUS_CLOSURE_READY" else if (mismatch) "FUTURE_LITE_CORPUS_BACKGROUND_ONLY_DOMAIN_MISMATCH" else "FUTURE_LITE_CORPUS_CLOSURE_PARTIAL")
            .put("domainKey", GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report))
            .put("selectedFutureCorpusDomain", corpus.optString("domainKey"))
            .put("hypothesisVariants", composer.optJSONArray("variants")?.length() ?: 0)
            .put("decisiveMissingExperiment", gap.optString("decisiveMissingExperiment"))
            .put("routeLinkage", route)
            .put("oldNewRoutesLinked", true)
            .put("futureAccelerationWithoutApi", true)
            .put("claimPromotionAllowed", false)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final future-lite corpus closure",
        "State: ${obj.optString("state", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}; variants=${obj.optInt("hypothesisVariants", 0)}; future_acceleration_without_api=${obj.optBoolean("futureAccelerationWithoutApi", false)}.",
        "Decisive missing experiment: ${obj.optString("decisiveMissingExperiment", "not selected")}",
        "Route linkage: future corpus → hypothesis composer → mechanism gap → evidence graph → capsule/contradiction/study protocol/red-team.",
        "Boundary: this brings future-facing priors into the report now, but does not claim to surpass validated science until evidence gates close."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FUTURE_LITE_CORPUS_CLOSURE_READY", CLAIM_LIMIT))
}
