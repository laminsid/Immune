package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Immune-cell metabolic switch hypothesis mapper. */
object GTIMMetabolicImmuneSwitchMapperV21321 {
    const val VERSION: String = "2.13.21-metabolic-immune-switch-mapper"
    const val STATE_READY: String = "METABOLIC_IMMUNE_SWITCH_MAPPER_READY"
    const val CLAIM_LIMIT: String = "metabolic_switch_lens_not_diet_drug_or_cancer_treatment_claim"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("switch_axes", JSONArray(listOf("glycolysis_vs_oxidative_phosphorylation", "fatty_acid_oxidation", "lactate_TME_constraint", "nutrient_competition", "immune_exhaustion_energy_stress")))
        .put("drug_target_proof_allowed", false)
        .put("diet_protocol_allowed", false)
        .put("treatment_claim_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
