package com.immunesignal.app

/**
 * v2.7.8.1 — Matrix ETL Evidence Packet.
 *
 * This layer sits after the Matrix ETL bridge. It does not download files and does not
 * run DGE. Its job is to make the next execution step precise enough for a researcher
 * or a later ETL worker: repository file signatures to probe, metadata fields to parse,
 * comparator evidence requirements, and sample-id linkage checks. It keeps sentinel
 * targets such as NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED blocked before file probing.
 */
data class GTIMMatrixEtlEvidencePacketReportV2781(
    val active: Boolean,
    val targetId: String,
    val packetState: String,
    val fileProbeState: String,
    val candidateFileTypes: List<String>,
    val metadataFields: List<String>,
    val comparatorLabels: List<String>,
    val sampleLinkageChecks: List<String>,
    val summaryLine: String,
    val fileProbeLine: String,
    val metadataEvidenceLine: String,
    val boundaryLine: String
)

object GTIMMatrixEtlEvidencePacketV2781 {
    const val VERSION: String = "2.7.8.1-matrix-etl-evidence-packet"

    private val FILE_SIGNATURES = listOf(
        "matrix.mtx",
        "barcodes.tsv",
        "features.tsv",
        "genes.tsv",
        "h5",
        "h5ad",
        "rds",
        "csv_count_matrix",
        "tsv_expression_matrix",
        "series_matrix",
        "supplementary_files"
    )

    private val METADATA_FIELDS = listOf(
        "title",
        "source_name",
        "characteristics",
        "disease",
        "tissue",
        "cell_type",
        "treatment",
        "severity",
        "timepoint",
        "platform",
        "organism"
    )

    private val COMPARATOR_LABELS = listOf(
        "case",
        "healthy_control",
        "recovered_control",
        "treated",
        "untreated",
        "responder",
        "non_responder",
        "baseline",
        "follow_up",
        "severity_group"
    )

    private val LINKAGE_CHECKS = listOf(
        "metadata_row_ids",
        "matrix_column_ids",
        "cell_barcodes",
        "gsm_sample_ids",
        "column_metadata_join",
        "duplicate_sample_guard"
    )

    fun build(etl: GTIMMatrixEtlMetadataBridgeReportV2780): GTIMMatrixEtlEvidencePacketReportV2781 {
        val hasTopicTarget = GTIMAccessionIdValidityGuardV2753.isFullAccession(etl.targetId)
        val blocked = !hasTopicTarget || etl.dgeReadinessVerdict == "DGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"

        if (blocked) {
            val summary = "Matrix ETL evidence packet: version=$VERSION | state=BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | target=${etl.targetId} | file_probe=BLOCKED_BEFORE_TARGET_SELECTION | metadata_evidence=BLOCKED_BEFORE_TARGET_SELECTION | comparator_evidence=BLOCKED_BEFORE_TARGET_SELECTION | sample_linkage=BLOCKED_BEFORE_TARGET_SELECTION"
            return GTIMMatrixEtlEvidencePacketReportV2781(
                active = true,
                targetId = etl.targetId,
                packetState = "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET",
                fileProbeState = "BLOCKED_BEFORE_TARGET_SELECTION",
                candidateFileTypes = emptyList(),
                metadataFields = emptyList(),
                comparatorLabels = emptyList(),
                sampleLinkageChecks = emptyList(),
                summaryLine = summary,
                fileProbeLine = "ETL file probe: state=BLOCKED_BEFORE_TARGET_SELECTION | candidate_files=none | reason=select topic-compatible accession before repository file probing",
                metadataEvidenceLine = "ETL metadata evidence: state=BLOCKED_BEFORE_TARGET_SELECTION | required_fields=none | label_rule=no comparator labels before target selection",
                boundaryLine = boundary()
            )
        }

        val fileProbe = when (etl.fileDiscoveryState) {
            "FILE_CANDIDATE_DISCOVERED_REVIEW_ONLY" -> "REPOSITORY_FILE_SIGNATURE_CANDIDATE_REVIEW"
            "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET" -> "BLOCKED_BEFORE_TARGET_SELECTION"
            else -> "REPOSITORY_FILE_SIGNATURE_PROBE_REQUIRED"
        }
        val packetState = when {
            etl.dgeReadinessVerdict == "DGE_READY_REVIEW_ONLY" -> "ETL_EVIDENCE_PACKET_READY_FOR_REVIEW_ONLY_DGE"
            etl.dgeReadinessVerdict.contains("COMPARATOR", ignoreCase = true) -> "ETL_EVIDENCE_PACKET_COMPARATOR_EVIDENCE_REQUIRED"
            etl.dgeReadinessVerdict.contains("METADATA", ignoreCase = true) -> "ETL_EVIDENCE_PACKET_METADATA_EVIDENCE_REQUIRED"
            etl.dgeReadinessVerdict.contains("SAMPLE_ID", ignoreCase = true) || etl.dgeReadinessVerdict.contains("LINKAGE", ignoreCase = true) -> "ETL_EVIDENCE_PACKET_SAMPLE_LINKAGE_REQUIRED"
            else -> "ETL_EVIDENCE_PACKET_FILE_PROBE_REQUIRED"
        }

        val summary = "Matrix ETL evidence packet: version=$VERSION | state=$packetState | target=${etl.targetId} | file_probe=$fileProbe | metadata_evidence=FIELD_SNIPPETS_REQUIRED | comparator_evidence=LABEL_SUGGESTION_WITH_CONFIDENCE_REQUIRED | sample_linkage=SAMPLE_ID_JOIN_REQUIRED"
            .replace(Regex("\\s+"), " ")
            .trim()
        val fileLine = "ETL file probe: state=$fileProbe | candidate_files=${FILE_SIGNATURES.joinToString(",")} | repository_scope=GEO/SRA/ArrayExpress/BioProject/ImmPort | no_download_claim_until_file_seen=true"
            .replace(Regex("\\s+"), " ")
            .trim()
        val metadataLine = "ETL metadata evidence: required_fields=${METADATA_FIELDS.joinToString(",")} | comparator_labels=${COMPARATOR_LABELS.joinToString(",")} | output=suggestion+confidence+source_field+evidence_snippet | sample_linkage_checks=${LINKAGE_CHECKS.joinToString(",")}"
            .replace(Regex("\\s+"), " ")
            .trim()

        return GTIMMatrixEtlEvidencePacketReportV2781(
            active = true,
            targetId = etl.targetId,
            packetState = packetState,
            fileProbeState = fileProbe,
            candidateFileTypes = FILE_SIGNATURES,
            metadataFields = METADATA_FIELDS,
            comparatorLabels = COMPARATOR_LABELS,
            sampleLinkageChecks = LINKAGE_CHECKS,
            summaryLine = summary,
            fileProbeLine = fileLine,
            metadataEvidenceLine = metadataLine,
            boundaryLine = boundary()
        )
    }

    private fun boundary(): String = "Matrix ETL evidence boundary: readiness packet only; no file was downloaded, no DGE was run, no biological proof or clinical claim."
}
