package com.immunesignal.app

// v2.10.2 — ClinicalTrials.gov request planner.
// It creates transparent exploration request plans only; it does not execute HTTP and does not authorize clinical action.
object GTIMClinicalTrialsRequestPlannerV2102 {
    const val VERSION: String = "2.10.4-relaxed-clinicaltrials-exploration-plan"
    const val BASE_URL: String = "https://clinicaltrials.gov/api/v2/studies"

    fun build(contract: GTIMRunDecisionContractV2740, matches: List<GTIMImmunotherapyKnowledgeMatchV2102>): List<GTIMClinicalTrialsRequestPlanV2102> {
        val anchor = contract.primaryAnchor.routeId.replace(Regex("[^A-Za-z0-9 _/-]+"), " ").replace(Regex("\\s+"), " ").trim()
        return matches.take(5).mapIndexed { index, match ->
            val terms = (listOf(anchor, match.entry.mechanismClass) + match.entry.targets.take(3) + match.matchedTerms.take(3))
                .joinToString(" ")
                .replace(Regex("\\s+"), " ")
                .trim()
                .ifBlank { "immune therapy mechanism" }
            val filters = listOf("filter.phase=PHASE2,PHASE3,PHASE4", "filter.overallStatus=COMPLETED,RECRUITING,ACTIVE_NOT_RECRUITING")
            val query = "$BASE_URL?query.term=${terms.replace(" ", "+")}&${filters.joinToString("&")}" 
            val state = if (match.matchState.contains("MATCHED") || match.entry.id == "open_mechanism_exploration") "EXPLORATION_REQUEST_PLAN_READY_NO_HTTP_EXECUTION" else "EXPLORATION_REQUEST_PLAN_NEAR_MATCH_ALLOWED"
            val line = "ClinicalTrials request plan: version=$VERSION | id=CTGOV_PLAN_${index + 1}_${match.entry.id} | state=$state | query_term=${terms.oneLine()} | use=explore_rank_B_or_C_candidate_context_not_clinical_authorization | no_http_execution=true"
            GTIMClinicalTrialsRequestPlanV2102(
                planId = "CTGOV_PLAN_${index + 1}_${match.entry.id}",
                state = state,
                queryTerm = query,
                filters = filters,
                evidenceRankUse = "trial_registry_context_for_hypothesis_expansion_not_clinical_authorization",
                noHttpExecution = true,
                line = line
            )
        }
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
