package com.immunesignal.app

/**
 * v2.9.1 — final compact production closure.
 *
 * Display-only release closure for the researcher-facing brief. It keeps the public
 * surface short and decision-first while legacy compatibility markers remain in source
 * comments/constants for CI audits. It does not alter target selection, ETL/DGE gates,
 * comparator alignment, treatment safety, or Claim Guard behavior.
 */
object GTIMFinalCompactReleaseClosureV2910 {
    const val VERSION: String = "v2.9.1-final-compact-production-closure"
    const val SURFACE_MODE: String = "compact_decision_first"
    const val TECHNICAL_HISTORY_POLICY: String = "hidden_from_first_ui_surface"

    fun topLine(): String =
        "Release closure: version=$VERSION | surface=$SURFACE_MODE | technical_history=$TECHNICAL_HISTORY_POLICY | decision_order=target→files→metadata→comparator→sample_linkage→DGE"
}
