package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Compact first-surface card for immune-decision and paradigm candidates. */
object GTIMParadigmSurfaceCardV21317 {
    const val VERSION: String = "2.13.17-paradigm-surface-card"

    fun renderLines(report: JSONObject): List<String> {
        val card = GTIMParadigmCandidateEngineV21317.toJson(report)
        val states = card.optJSONArray("immune_decision_states")?.toStringList()?.joinToString(", ").orEmpty().ifBlank { "open_immune_reprogramming_axis" }
        val modalities = card.optJSONArray("modality_lens")?.toStringList()?.joinToString(", ").orEmpty().ifBlank { "open_modality_lens" }
        val digital = card.optJSONObject("digital_immunomics_lens")
        val digitalTasks = digital?.optJSONArray("digital_immunomics_tasks")?.toStringList()?.joinToString(", ").orEmpty().ifBlank { "open_digital_immunomics_mapping" }
        val assumption = GTIMAssumptionBreakerEngineV21318.toJson(report)
        val cross = GTIMCrossDiseaseMechanismMapperV21318.toJson(report)
        val modality = GTIMTherapeuticModalityLensV21318.toJson(report)
        val binding = GTIMProteinInteractionBindingHypothesisV21318.toJson(report)
        return listOf(
            "Paradigm candidate card",
            "Immune decision state: $states",
            "Paradigm level: ${card.optString("paradigm_level")}; concept=${card.optString("concept_id")}",
            "Old assumption challenged: ${assumption.optString("old_assumption_challenged", card.optString("old_assumption_challenged"))}",
            "Candidate mechanism: ${card.optString("candidate_mechanism")}",
            "Cross-disease mechanism: ${cross.optString("shared_mechanism_axis")}; connected=${cross.optJSONArray("connected_disease_domains") ?: JSONArray()}",
            "Therapeutic/modality lens: ${modality.optJSONArray("modalities") ?: JSONArray()}; validated_treatment_claim=BLOCKED.",
            "Protein interaction/binding lens: target_antigen=${binding.optString("target_antigen")}; epitope=${binding.optString("epitope")}; validated_binding_or_efficacy_claim=BLOCKED.",
            "AI immunomics/design lens: $digitalTasks; sandbox_design_preview=ALLOWED; validated_binding_or_efficacy_claim=BLOCKED.",
            "Paradigm falsifier: ${card.optString("falsifier")}",
            "Boundary: concept, modality, protein-interaction, and digital-immunomics cards are research previews only; no treatment, dosing, clinical implementation, validated binding proof, efficacy, or confirmed discovery."
        )
    }

    fun toJson(report: JSONObject): JSONObject = GTIMParadigmCandidateEngineV21317.toJson(report)
        .put("surface_version", VERSION)

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "Paradigm candidate card",
        "trained_innate_immunity_core",
        "peripheral_immune_tolerance_core",
        "digital_immunomics_antibody_design",
        "sandbox_design_preview=ALLOWED",
        "validated_binding_or_efficacy_claim=BLOCKED",
        "Assumption breaker engine",
        "Cross-disease mechanism mapper",
        "Protein interaction / binding hypothesis",
        "Therapeutic modality lens"
    ))
}
