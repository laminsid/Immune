package com.immunesignal.app

/**
 * v2.8.4 — final linked release surface.
 *
 * This is a display/contract-coherence helper only. It does not change routing,
 * ETL decisions, DGE readiness, treatment reasoning, or Claim Guard behavior.
 * It exists to keep the release identity unified after the v2.8.x ETL execution
 * pipeline split.
 */
object GTIMUnifiedReleaseSurfaceV2804 {
    const val VERSION: String = "2.9.0-target-recall-matrix-link-compact-brief"
    const val RELEASE_CHAIN: String = "v2.7.7.7-topic-compatible-dge-target-gate + v2.7.8.2-final-etl-execution-unification + v2.7.9.1-therapeutic-protocol-safety-guard + v2.8.3-actual-etl-final-run-contract + v2.8.4-final-linked-release-unification + v2.8.5-legacy-surface-token-compatibility + v2.8.9-report-surface-compression-etl-priority-view + v2.9.0-target-recall-matrix-link-compact-brief"
    const val ACTUAL_ETL_SPINE: String = "v2.8.0-actual-etl-execution-pipeline + v2.8.1-observed-file-evidence-contract + v2.8.2-concrete-etl-readiness + v2.8.3-actual-etl-final-run-contract"
    const val SAFETY_LOCKS: String = "background_seed_not_dge_target; target_recall_review_only; matrix_link_requires_observed_file; comparator_alignment_requires_evidence_snippet; observed_file_evidence_required; sample_metadata_and_linkage_required; dge_review_only_not_run; no_treatment_or_clinical_claim"

    fun summaryLine(actualEtlState: String): String = normalize(
        "Unified release: version=$VERSION | chain=$RELEASE_CHAIN | actual_etl_spine=$ACTUAL_ETL_SPINE | actual_etl_state=$actualEtlState | locks=$SAFETY_LOCKS"
    )

    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
