package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.12.18 — pre-output scientific red-team reviewer. */
object GTIMScientificRedTeamReviewerV21218 {
    const val VERSION: String = "2.12.18-scientific-red-team-reviewer"
    const val CLAIM_LIMIT: String = "red_team_review_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val warnings = JSONArray()
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val capsule = report.optJSONObject("evidenceCapsuleBuilderV21218") ?: JSONObject()
        val novelty = report.optJSONObject("noveltyScoringEngineV21218") ?: JSONObject()
        val utility = report.optJSONObject("publishedResearchUtilityScoreV21213") ?: JSONObject()
        val text = report.toString()
        if (ledger.optString("selectedReviewTarget").isBlank()) warnings.put("No selected review target; report must remain route-only.")
        if (capsule.optInt("capsuleScore", 0) < 6) warnings.put("Capsule score below partial review threshold; do not present as study-ready.")
        if (utility.optInt("score", 0) > 6 && capsule.optInt("capsuleScore", 0) < 8) warnings.put("Utility score may be too high for capsule readiness; cap should apply.")
        if (novelty.optInt("noveltyScore", 0) >= 9 && text.contains("known components", true)) warnings.put("High novelty conflicts with known-components language; keep novelty provisional.")
        if (text.contains("proof", true) && !text.contains("not proof", true)) warnings.put("Potential proof wording detected; enforce claim boundary.")
        val state = if (warnings.length() == 0) "RED_TEAM_PASS_CLAIM_SAFE" else "RED_TEAM_WARNINGS_PRESENT_CLAIM_BLOCKED"
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("warningCount", warnings.length())
            .put("warnings", warnings)
            .put("decision", if (warnings.length() == 0) "publish_research_route_with_boundaries" else "publish_with_downgraded_claim_language_and_missing_gate_visibility")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Scientific red-team reviewer",
        "State: ${obj.optString("state", "UNKNOWN")}; warnings=${obj.optInt("warningCount", 0)}; decision=${obj.optString("decision", "review_required")}",
        "Checks: overclaim language, score inflation, selected-target gaps, capsule weakness, novelty inflation, and domain/seed mismatch.",
        "Output rule: warnings lower confidence/claim language; they do not hide missing evidence.",
        "Boundary: red-team review improves report safety but cannot validate biology."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "RED_TEAM_PASS_CLAIM_SAFE", "RED_TEAM_WARNINGS_PRESENT_CLAIM_BLOCKED", CLAIM_LIMIT))
}
