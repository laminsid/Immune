package com.immunesignal.app

// v2.11.2 — Converts dysfunction nodes into repair-function routes.
object GTIMRestorativeFunctionSearchV2112 {
    const val VERSION: String = "2.11.2-restorative-function-search"
    private const val CLAIM_LIMIT = "repair_function_route_is_research_hypothesis_not_treatment"

    fun search(nodes: List<GTIMDysfunctionHypothesisNodeV2112>): List<GTIMRestorativeFunctionRouteV2112> = nodes.mapIndexed { index, node ->
        val (routeClass, logic, required) = when (node.nodeId) {
            "IMMUNE_DECISION_ERROR" -> Triple("immune_recalibration_route", "Search for functions that restore immune decision thresholds rather than suppressing all immune activity.", listOf("cytokine/tolerance marker", "subgroup context", "no broad suppression claim"))
            "BARRIER_FAILURE_NODE" -> Triple("barrier_restoration_route", "Search for functions that restore entry-surface integrity, mucus, epithelial tone, or local tolerance.", listOf("barrier marker", "local tissue context", "microbiome/metabolite bridge"))
            "MICROBIAL_ECOLOGY_NODE" -> Triple("microbial_metabolite_restoration_route", "Search for missing microbial function or metabolite conversion that could stabilize the system.", listOf("function-level microbiome evidence", "metabolite direction", "diet/antibiotic context"))
            "EXPOSOME_PRESSURE_NODE" -> Triple("exposome_resilience_route", "Search for exposure reduction, binding, biotransformation, or resilience functions without claiming detox treatment.", listOf("exposure measurement", "safe byproduct profile", "burden or oxidative marker"))
            "IMMUNOMETABOLIC_STRESS_NODE" -> Triple("immunometabolic_resilience_route", "Search for energy-context functions that support immune-cell decisions and tissue repair.", listOf("metabolic marker", "immune-energy bridge", "comparator group"))
            else -> Triple("open_repair_function_route", "Search for the missing or failed function before selecting a disease label or intervention family.", listOf("dysfunction definition", "mechanism marker", "falsification plan"))
        }
        val id = "REPAIR_FUNCTION_${index + 1}_${node.nodeId}".take(96)
        val line = "Restorative function route: version=$VERSION | id=$id | node=${node.nodeId} | class=$routeClass | logic=${logic.oneLine()} | required=${required.joinToString(";").oneLine()} | claim_limit=$CLAIM_LIMIT"
        GTIMRestorativeFunctionRouteV2112(id, node.nodeId, routeClass, logic, required, CLAIM_LIMIT, line)
    }.distinctBy { it.routeId }.take(7)

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
