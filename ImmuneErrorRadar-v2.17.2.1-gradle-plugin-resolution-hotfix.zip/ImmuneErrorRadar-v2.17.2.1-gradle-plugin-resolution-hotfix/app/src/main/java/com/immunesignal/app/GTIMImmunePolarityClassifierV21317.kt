package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Classifies the immune decision state behind the active disease/domain route. */
object GTIMImmunePolarityClassifierV21317 {
    const val VERSION: String = "2.13.17-immune-decision-polarity"

    fun classify(activeDomain: String): List<String> = when (activeDomain) {
        "allergy_type2_barrier" -> listOf("tolerance_failure", "type2_skew", "barrier_repair_failure")
        "rheumatoid_autoimmune_synovial_inflammation" -> listOf("tolerance_failure", "activation_dominant", "tissue_repair_failure")
        "oncology_tumor_microenvironment" -> listOf("tolerance_excess", "tumor_immune_escape", "tissue_resident_immunity")
        "hiv_aids_immune_activation" -> listOf("chronic_activation", "exhaustion", "pathogen_persistence")
        "viral_interferon_cytokine" -> listOf("activation_dominant", "trained_immunity_memory", "tissue_resident_immunity")
        "filovirus_viral_host_response" -> listOf("activation_damage_dominant", "repair_resolution_candidate", "vascular_injury")
        "viral_hantavirus_host_response" -> listOf("activation_damage_dominant", "endothelial_leak", "repair_resolution_candidate")
        "metabolic_inflammation" -> listOf("metabolic_inflammation", "trained_immunity_memory", "repair_resolution_failure")
        "inflammation_resolution" -> listOf("failed_resolution", "trained_immunity_memory", "chronic_activation")
        "immune_age_longevity" -> listOf("immune_age_drift", "inflammaging", "trained_immunity_memory", "repair_resolution_failure", "tolerance_balance")
        else -> listOf("open_immune_reprogramming_axis")
    }

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val states = classify(active)
        return JSONObject()
            .put("version", VERSION)
            .put("active_domain", active)
            .put("immune_decision_states", JSONArray(states))
            .put("claim_limit", "immune_polarity_is_hypothesis_lens_not_diagnosis_or_treatment")
    }
}
