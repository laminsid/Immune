package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.8 — final surface repair + supersession guards.
 * These guards are deliberately separate from innovation engines. They keep legacy
 * rails visible for compatibility, but stop old handles from masquerading as the
 * active discovery target after canonical routing has selected a better target.
 */
object GTIMLegacyCandidateSupersessionGuardV2138 {
    const val VERSION: String = "2.13.8-legacy-candidate-supersession-guard"
    const val CLAIM_LIMIT: String = "legacy_candidate_supersession_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val canonical = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val handles = linkedSetOf<String>()
        collectHandle(report.optJSONObject("candidateHandleLedgerV21215")?.optJSONArray("candidateHandles"), handles)
        collectHandle(report.optJSONObject("terminalDiscoveryContinuationV21212")?.optJSONArray("candidateHandles"), handles)
        collectHandle(report.optJSONObject("futureEvidenceLiteCorpusV2130")?.optJSONArray("candidateHandles"), handles)
        listOf(
            report.optJSONObject("candidateHandleLedgerV21215")?.optString("selectedReviewTarget").orEmpty(),
            report.optJSONObject("targetValidationCardV21213")?.optString("selectedReviewTarget").orEmpty(),
            report.optJSONObject("matrixShortcutResolverV2124")?.optString("handle").orEmpty(),
            report.optJSONObject("finalReleaseLockV21219")?.optString("selectedReviewTarget").orEmpty(),
            report.optJSONObject("finalTestReadinessV2133")?.optString("selectedReviewTarget").orEmpty()
        ).filter { it.isNotBlank() }.forEach { handles.add(it) }

        val superseded = JSONArray()
        val activeHandles = JSONArray()
        handles.filter { it.isNotBlank() }.forEach { handle ->
            if (canonical.isNotBlank() && handle != canonical) {
                superseded.put(JSONObject()
                    .put("handle", handle)
                    .put("status", "superseded_by_canonical_target")
                    .put("canonicalTarget", canonical)
                    .put("renderPolicy", "legacy_lookup_only_not_active_target"))
            } else if (handle == canonical && canonical.isNotBlank()) {
                activeHandles.put(handle)
            }
        }
        val activeLegacyCount = if (canonical.isBlank()) 0 else activeHandles.length()
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (canonical.isNotBlank()) "LEGACY_CANDIDATES_SUPERSEDED_OR_CANONICAL" else "LEGACY_CANDIDATE_SUPERSESSION_NEEDS_CANONICAL_TARGET")
            .put("activeDomain", active)
            .put("canonicalTarget", canonical)
            .put("supersededCandidates", superseded)
            .put("activeLegacyCandidateCount", activeLegacyCount)
            .put("policy", "legacy handles remain visible only as superseded lookup history; canonical target controls final action")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Legacy candidate supersession guard",
        "State: ${obj.optString("state", "UNKNOWN")}; canonical_target=${obj.optString("canonicalTarget", "none")}; superseded=${obj.optJSONArray("supersededCandidates")?.length() ?: 0}; active_legacy=${obj.optInt("activeLegacyCandidateCount", 0)}.",
        "Policy: ${obj.optString("policy", "legacy handles are lookup history only")}",
        "Boundary: supersession cleans final rendering; it does not validate biology."
    )

    private fun collectHandle(array: JSONArray?, out: MutableSet<String>) {
        if (array == null) return
        for (i in 0 until array.length()) {
            val item = array.opt(i)
            when (item) {
                is String -> if (item.isNotBlank()) out.add(item)
                is JSONObject -> item.optString("handle").takeIf { it.isNotBlank() }?.let { out.add(it) }
            }
        }
    }
}

object GTIMStaleSurfaceZeroExportGuardV2138 {
    const val VERSION: String = "2.13.8-stale-surface-zero-export-guard"
    const val CLAIM_LIMIT: String = "stale_surface_guard_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val canonical = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val supersession = report.optJSONObject("legacyCandidateSupersessionGuardV2138")
            ?: GTIMLegacyCandidateSupersessionGuardV2138.toJson(report)
        val findings = JSONArray()
        val matrix = report.optJSONObject("matrixShortcutResolverV2124") ?: JSONObject()
        val matrixHandle = matrix.optString("handle")
        if (canonical.isBlank()) {
            findings.put("canonical_target_missing_export_background_only")
        } else if (matrixHandle.isNotBlank() && matrixHandle != canonical) {
            findings.put("matrix_handle_superseded:$matrixHandle->$canonical")
        }
        val unresolvedActiveLegacy = supersession.optInt("activeLegacyCandidateCount", 0) > 1
        if (unresolvedActiveLegacy) findings.put("multiple_active_legacy_candidates")
        val blocking = (0 until findings.length()).map { findings.optString(it) }
            .filterNot { it.contains("superseded") || it.contains("background_only") }
        val exportState = if (blocking.isEmpty()) "STALE_SURFACE_ZERO_EXPORT_READY" else "STALE_SURFACE_EXPORT_REVIEW_REQUIRED"
        return JSONObject()
            .put("version", VERSION)
            .put("state", exportState)
            .put("activeDomain", active)
            .put("canonicalTarget", canonical)
            .put("staleSurfaceItems", 0)
            .put("nonBlockingFindings", findings)
            .put("blockingFindings", JSONArray(blocking))
            .put("exportPolicy", if (canonical.isBlank()) "no_dataset_next_action_until_topic_compatible_target_exists" else "canonical_target_only_final_action")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Stale surface zero export guard",
        "State: ${obj.optString("state", "UNKNOWN")}; canonical_target=${obj.optString("canonicalTarget", "none")}; stale_surface_items=${obj.optInt("staleSurfaceItems", -1)}; blocking=${obj.optJSONArray("blockingFindings")?.length() ?: 0}.",
        "Export policy: ${obj.optString("exportPolicy", "canonical target only")}",
        "Boundary: export guard cleans stale report actions; it does not upgrade evidence."
    )
}
