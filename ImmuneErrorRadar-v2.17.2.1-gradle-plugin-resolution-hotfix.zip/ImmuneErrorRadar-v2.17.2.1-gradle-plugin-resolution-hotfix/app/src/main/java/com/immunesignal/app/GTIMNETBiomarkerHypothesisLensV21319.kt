package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** NET biomarker hypothesis lens. */
object GTIMNETBiomarkerHypothesisLensV21319 {
    const val VERSION: String = "2.13.19-net-biomarker-hypothesis-lens"
    const val CLAIM_LIMIT: String = "NET_biomarker_hypothesis_not_diagnosis_claim"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", "NET_BIOMARKER_HYPOTHESIS_READY")
        .put("candidate_biomarkers", JSONArray(listOf("cfDNA", "MPO_DNA", "CitH3", "neutrophil_elastase")))
        .put("diagnosis_claim_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
