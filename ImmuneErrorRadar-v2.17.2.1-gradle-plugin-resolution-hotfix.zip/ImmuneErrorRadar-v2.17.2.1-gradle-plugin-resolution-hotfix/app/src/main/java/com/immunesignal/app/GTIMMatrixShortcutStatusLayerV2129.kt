package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.9 — Matrix shortcut status layer.
 *
 * Public processed-expression sources are not treated as internal proof, but the report
 * must still tell the researcher what each shortcut can contribute now. This layer turns
 * links into review-only status capsules: queued, inspectable, expected extraction, and
 * decision impact.
 */
object GTIMMatrixShortcutStatusLayerV2129 {
    const val VERSION: String = "2.12.9-matrix-shortcut-status-layer"
    const val CLAIM_LIMIT: String = "review_only_status_capsule_not_network_result_not_dge_ready"

    data class StatusItem(
        val source: String,
        val status: String,
        val expectedExtraction: String,
        val decisionImpact: String,
        val proofBoundary: String
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): List<StatusItem> {
        val items = mutableListOf<StatusItem>()
        val matrixJson = report.optJSONObject("matrixShortcutResolverV2124")
        if (matrixJson != null) {
            val routes = matrixJson.optJSONArray("routes") ?: JSONArray()
            for (i in 0 until routes.length()) {
                val route = routes.optJSONObject(i) ?: continue
                val source = route.optString("source").ifBlank { "processed-expression shortcut" }
                val extracts = jsonStrings(route.optJSONArray("extracts")).take(3).joinToString(", ").ifBlank { "availability, labels, provenance" }
                val decision = route.optString("decisionImpact").ifBlank { "Use as lookup task only; reviewer must confirm before evidence upgrade." }
                items += StatusItem(source, statusFor(source), extracts, decision, CLAIM_LIMIT)
            }
        } else {
            val matrix = GTIMMatrixShortcutResolverV2124.build(report, technicalLines)
            matrix.routes.forEach { route ->
                val extracts = route.extracts.take(3).joinToString(", ").ifBlank { "availability, labels, provenance" }
                items += StatusItem(route.source, statusFor(route.source), extracts, route.decisionImpact, CLAIM_LIMIT)
            }
        }
        return items.ifEmpty {
            listOf(StatusItem(
                "Matrix Shortcut Resolver",
                "QUEUED_TOPIC_LEVEL_SHORTCUT_REVIEW",
                "processed expression availability, comparator labels, source-to-sample provenance",
                "Convert matrix missing into a review-only evidence-capsule task, not proof.",
                CLAIM_LIMIT
            ))
        }
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val items = build(report, technicalLines)
        val lines = mutableListOf<String>()
        lines += "Matrix shortcut status layer"
        lines += "Status capsule: processed-expression shortcuts are actionable review tasks, not internal DGE or gene/pathway proof."
        items.take(4).forEachIndexed { idx, item ->
            lines += "${idx + 1}. ${item.source}: ${item.status}; extract=${item.expectedExtraction}; impact=${item.decisionImpact.takeClean(180)}"
        }
        lines += "Shortcut proof boundary: $CLAIM_LIMIT"
        return lines
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val arr = JSONArray()
        build(report, technicalLines).forEach { item ->
            arr.put(JSONObject()
                .put("source", item.source)
                .put("status", item.status)
                .put("expectedExtraction", item.expectedExtraction)
                .put("decisionImpact", item.decisionImpact)
                .put("proofBoundary", item.proofBoundary))
        }
        return JSONObject()
            .put("version", VERSION)
            .put("status", "MATRIX_SHORTCUT_STATUS_READY")
            .put("routeStatuses", arr)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "Matrix shortcut status layer",
        "MATRIX_SHORTCUT_STATUS_READY",
        "QUEUED_PROCESSED_EXPRESSION_REVIEW",
        "QUEUED_COMPARATOR_LABEL_REVIEW",
        CLAIM_LIMIT
    ))

    private fun statusFor(source: String): String = when {
        source.contains("GREIN", true) || source.contains("refine", true) || source.contains("recount", true) -> "QUEUED_PROCESSED_EXPRESSION_REVIEW"
        source.contains("Expression Atlas", true) || source.contains("ArrayExpress", true) -> "QUEUED_EXTERNAL_EXPERIMENT_LOOKUP"
        source.contains("GEO2R", true) || source.contains("sample table", true) -> "QUEUED_COMPARATOR_LABEL_REVIEW"
        else -> "QUEUED_SHORTCUT_REVIEW"
    }

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx ->
        array.optString(idx).takeIf { it.isNotBlank() }
    }

    private fun String.takeClean(max: Int): String {
        val clean = replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= max) clean else clean.take(max).trimEnd()
    }
}
