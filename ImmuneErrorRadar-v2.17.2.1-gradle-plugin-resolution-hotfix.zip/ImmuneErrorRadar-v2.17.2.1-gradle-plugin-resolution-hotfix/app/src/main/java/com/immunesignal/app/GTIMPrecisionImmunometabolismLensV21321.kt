package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Precision immunometabolism research modality lens. */
object GTIMPrecisionImmunometabolismLensV21321 {
    const val VERSION: String = "2.13.21-precision-immunometabolism-lens"
    const val STATE_READY: String = "PRECISION_IMMUNOMETABOLISM_LENS_READY"
    const val CLAIM_LIMIT: String = "precision_immunometabolism_is_research_modality_not_nutrition_or_treatment_protocol"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("modalities", JSONArray(listOf("metabolic_biomarker_panel", "adipokine_inflammation_axis", "TME_metabolic_reprogramming_lens", "digital_nutrition_research_hypothesis")))
        .put("nutrition_protocol_allowed", false)
        .put("medical_treatment_claim_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
