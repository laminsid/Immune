package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Compact first-surface card for exosome systemic immunity and immunometabolism. */
object GTIMExosomeImmunometabolismSurfaceCardV21321 {
    const val VERSION: String = "2.13.21-exosome-immunometabolism-surface-card"
    const val STATE_READY: String = "EXOSOME_IMMUNOMETABOLISM_SURFACE_CARD_READY"
    const val CLAIM_LIMIT: String = "exosome_and_immunometabolism_cards_are_research_lenses_not_diagnosis_or_treatment_claims"

    fun toJson(report: JSONObject): JSONObject {
        val exosome = GTIMExosomeSystemicImmunityEngineV21321.toJson(report)
        val cargo = GTIMExosomalCargoSignalMapperV21321.toJson(report)
        val biopsy = GTIMExosomeLiquidBiopsyLensV21321.toJson(report)
        val delivery = GTIMExosomeDeliveryModalityLensV21321.toJson(report)
        val adipose = GTIMImmunometabolismAdiposeEngineV21321.toJson(report)
        val atm = GTIMAdiposeMacrophagePolarityMapperV21321.toJson(report)
        val metabolicSwitch = GTIMMetabolicImmuneSwitchMapperV21321.toJson(report)
        val precision = GTIMPrecisionImmunometabolismLensV21321.toJson(report)
        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("exosome_role", exosome.optString("exosome_role"))
            .put("exosomal_cargo_axes", cargo.optJSONArray("cargo_axes") ?: JSONArray())
            .put("liquid_biopsy_lens", biopsy)
            .put("exosome_delivery_lens", delivery)
            .put("immunometabolism_role", adipose.optString("immunometabolism_role"))
            .put("adipose_macrophage_axes", atm.optJSONArray("polarity_axes") ?: JSONArray())
            .put("metabolic_switch_axes", metabolicSwitch.optJSONArray("switch_axes") ?: JSONArray())
            .put("precision_immunometabolism_lens", precision)
            .put("c2_c3_sandbox_preview_allowed", true)
            .put("diagnosis_claim_allowed", false)
            .put("treatment_claim_allowed", false)
            .put("diet_protocol_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Exosome / immunometabolism role card",
            "Exosome role: ${obj.optString("exosome_role")}; cargo_axes=${obj.optJSONArray("exosomal_cargo_axes") ?: JSONArray()}.",
            "Liquid biopsy / delivery lens: diagnosis=BLOCKED; cell_free_therapy=BLOCKED; BBB_safety_claim=BLOCKED.",
            "Immunometabolism role: ${obj.optString("immunometabolism_role")}; adipose_axes=${obj.optJSONArray("adipose_macrophage_axes") ?: JSONArray()}.",
            "Metabolic immune switch: ${obj.optJSONArray("metabolic_switch_axes") ?: JSONArray()}; diet_protocol=BLOCKED; treatment_claim=BLOCKED.",
            "Boundary: exosome signal != liquid-biopsy diagnosis; EV delivery lens != therapy; adipose immunometabolism signal != weight-loss/metabolic treatment claim."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        STATE_READY,
        "Exosome / immunometabolism role card",
        "exosome signal != liquid-biopsy diagnosis",
        "EV delivery lens != therapy",
        "adipose immunometabolism signal != weight-loss/metabolic treatment claim",
        CLAIM_LIMIT
    ))
}
