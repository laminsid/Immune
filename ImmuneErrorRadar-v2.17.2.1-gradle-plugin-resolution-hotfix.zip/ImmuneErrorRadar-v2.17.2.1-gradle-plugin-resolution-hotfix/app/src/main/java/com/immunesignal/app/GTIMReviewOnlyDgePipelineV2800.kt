package com.immunesignal.app

/** v2.8.0 — Review-only DGE gate/runner surface. Never fabricates DGE output. */
data class GTIMReviewOnlyDgeReportV2800(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val methodCandidates: List<String>,
    val blockers: List<String>,
    val dgeLine: String,
    val boundaryLine: String
)

object GTIMReviewOnlyDgePipelineV2800 {
    const val VERSION: String = "2.8.0-review-only-dge-pipeline"
    private val METHODS = listOf("DESeq2", "edgeR", "limma-voom", "scanpy-rank_genes_groups", "Seurat-FindMarkers")

    fun build(
        fileDiscovery: GTIMRepositoryFileDiscoveryReportV2800,
        matrixReader: GTIMMatrixReaderPreviewReportV2800,
        metadataCleaner: GTIMMetadataCleanerReportV2800,
        linkage: GTIMSampleIdLinkageReportV2800
    ): GTIMReviewOnlyDgeReportV2800 {
        val blockers = mutableListOf<String>()
        if (fileDiscovery.state == "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET") blockers += "NO_TOPIC_COMPATIBLE_TARGET"
        if (matrixReader.state == "MATRIX_READER_WAITING_FOR_OBSERVED_FILE_EVIDENCE") blockers += "OBSERVED_MATRIX_FILE_EVIDENCE_REQUIRED"
        if (matrixReader.state == "MATRIX_READER_WAITING_FOR_DOWNLOAD") blockers += "MATRIX_FILE_NOT_DOWNLOADED"
        if (matrixReader.state.contains("BLOCKED", true)) blockers += "MATRIX_READER_BLOCKED"
        if (metadataCleaner.state != "METADATA_NORMALIZATION_REVIEW_READY") blockers += "METADATA_NOT_NORMALIZED"
        if (linkage.state != "SAMPLE_LINKAGE_READY_FOR_REVIEW_ONLY_JOIN") blockers += "SAMPLE_ID_LINKAGE_NOT_CONFIRMED"

        val state = if (blockers.isEmpty()) "DGE_READY_REVIEW_ONLY_PENDING_RUN" else "DGE_NOT_RUN_REVIEW_ONLY_BLOCKED"
        val line = "Review-only DGE: version=$VERSION | state=$state | target=${fileDiscovery.targetId} | methods=${METHODS.joinToString(",")} | blockers=${blockers.joinToString(",").ifBlank { "none" }} | no_clinical_or_treatment_claim=true"
        return GTIMReviewOnlyDgeReportV2800(
            active = true,
            targetId = fileDiscovery.targetId,
            state = state,
            methodCandidates = METHODS,
            blockers = blockers,
            dgeLine = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "DGE boundary: review-only statistical execution gate; no causality, diagnosis, treatment, dosing, or efficacy claim."
        )
    }
}
