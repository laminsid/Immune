package com.immunesignal.app

// v2.10.2 — Data-first immunotherapy knowledge extension.
// The authoritative mechanism examples live in app/src/main/assets/immunotherapy_mechanism_ontology_v1.json.
// Kotlin mirrors the schema only so the dossier can render safely when assets are not injected at runtime.

data class GTIMImmunotherapyMechanismEntryV2102(
    val id: String,
    val mechanismClass: String,
    val targets: List<String>,
    val biomarkersRequired: List<String>,
    val diseaseContextHints: List<String>,
    val evidenceRank: String,
    val authoritySources: List<String>,
    val resistancePatterns: List<String>,
    val targetConservation: String,
    val escapeRisk: String,
    val safetyFlags: List<String>,
    val claimLimits: List<String>,
    val openExplorationTerms: List<String>
)

data class GTIMImmunotherapyKnowledgeMatchV2102(
    val entry: GTIMImmunotherapyMechanismEntryV2102,
    val matchState: String,
    val matchedTerms: List<String>,
    val missingProof: List<String>,
    val line: String
)

data class GTIMTherapeuticHypothesisCardV2102(
    val cardId: String,
    val mechanismId: String,
    val routeClass: String,
    val evidenceRank: String,
    val evidenceRankReason: String,
    val requiredBiomarkers: List<String>,
    val authoritySources: List<String>,
    val targetConservation: String,
    val escapeRisk: String,
    val resistancePatterns: List<String>,
    val safetyFlags: List<String>,
    val validationStatus: String,
    val clinicalTrialsRequestPlan: String,
    val line: String
)

data class GTIMClinicalTrialsRequestPlanV2102(
    val planId: String,
    val state: String,
    val queryTerm: String,
    val filters: List<String>,
    val evidenceRankUse: String,
    val noHttpExecution: Boolean,
    val line: String
)
