package com.immunesignal.app

// v2.10.7 — Hidden latent-axis scoring filter.
// This is an internal reasoning/routing filter only. It must not render as a dossier
// section or UI surface. It quietly biases hypothesis synthesis toward biological
// cross-axis checks while preserving open exploration and research-only boundaries.
data class GTIMLatentAxisScoreV2107(
    val axisId: String,
    val role: String,
    val score: Int,
    val matchedSignals: List<String>,
    val influenceTokens: List<String>,
    val missingEvidencePrompts: List<String>,
    val falsificationPrompts: List<String>
)

data class GTIMLatentAxisFilterReportV2107(
    val active: Boolean,
    val version: String,
    val state: String,
    val hidden: Boolean,
    val scores: List<GTIMLatentAxisScoreV2107>,
    val routeInfluenceTokens: List<String>,
    val missingEvidencePrompts: List<String>,
    val falsificationPrompts: List<String>,
    val policy: String
) {
    fun routeAffinity(routeText: String): Int {
        val text = routeText.lowercase()
        return scores.sumOf { score ->
            val tokenHit = score.influenceTokens.count { token -> text.contains(token.lowercase()) }
            val axisHit = if (text.contains(score.axisId.removeSuffix("_axis").replace('_', ' '))) 1 else 0
            (tokenHit + axisHit) * score.score
        }
    }

    fun promptsFor(routeText: String): List<String> {
        val text = routeText.lowercase()
        val matched = scores.filter { axis ->
            axis.influenceTokens.any { token -> text.contains(token.lowercase()) } ||
                text.contains(axis.axisId.removeSuffix("_axis").replace('_', ' '))
        }
        return matched.flatMap { it.missingEvidencePrompts }.ifEmpty { missingEvidencePrompts }.distinct().take(4)
    }

    fun falsifiersFor(routeText: String): List<String> {
        val text = routeText.lowercase()
        val matched = scores.filter { axis ->
            axis.influenceTokens.any { token -> text.contains(token.lowercase()) } ||
                text.contains(axis.axisId.removeSuffix("_axis").replace('_', ' '))
        }
        return matched.flatMap { it.falsificationPrompts }.ifEmpty { falsificationPrompts }.distinct().take(4)
    }

    companion object {
        fun empty(): GTIMLatentAxisFilterReportV2107 = GTIMLatentAxisFilterReportV2107(
            active = false,
            version = GTIMLatentAxisFilterV2107.VERSION,
            state = "LATENT_AXIS_FILTER_NOT_EVALUATED",
            hidden = true,
            scores = emptyList(),
            routeInfluenceTokens = emptyList(),
            missingEvidencePrompts = emptyList(),
            falsificationPrompts = emptyList(),
            policy = GTIMLatentAxisFilterV2107.POLICY
        )
    }
}

object GTIMLatentAxisFilterV2107 {
    const val VERSION: String = "2.10.7-latent-axis-filter"
    const val POLICY: String = "internal_hidden_filter_only_not_report_section_not_user_visible_not_disease_whitelist"

    private data class AxisTemplate(
        val axisId: String,
        val role: String,
        val baseScore: Int,
        val keywords: List<String>,
        val influenceTokens: List<String>,
        val missingEvidencePrompts: List<String>,
        val falsificationPrompts: List<String>
    )

    private val templates = listOf(
        AxisTemplate(
            axisId = "microbiome_axis",
            role = "mandatory_internal_pass",
            baseScore = 35,
            keywords = listOf("microbiome", "gut", "dysbiosis", "barrier", "mucosal", "butyrate", "scfa", "fiber", "bacteria"),
            influenceTokens = listOf("microbiome", "gut", "barrier", "mucosal", "butyrate", "scfa", "treg", "dysbiosis"),
            missingEvidencePrompts = listOf("microbiome/metabolite evidence", "barrier or mucosal marker", "human or capsule signal for microbial route"),
            falsificationPrompts = listOf("no microbiome or metabolite shift in topic-compatible evidence", "barrier/mucosal markers contradict the route")
        ),
        AxisTemplate(
            axisId = "metabolic_axis",
            role = "mandatory_internal_pass",
            baseScore = 35,
            keywords = listOf("metabolic", "glucose", "insulin", "lactate", "energy", "mitochondria", "fatty", "lipid", "glycolysis", "oxidative"),
            influenceTokens = listOf("metabolic", "glucose", "insulin", "lactate", "mitochondrial", "energy", "glycolysis", "lipid"),
            missingEvidencePrompts = listOf("metabolic-state evidence", "glucose/insulin or energy pathway marker", "immune-metabolic context"),
            falsificationPrompts = listOf("metabolic markers do not align with the proposed immune route", "energy or insulin pathway signal is absent")
        ),
        AxisTemplate(
            axisId = "immune_interaction_axis",
            role = "mandatory_bridge",
            baseScore = 40,
            keywords = listOf("immune", "cytokine", "t cell", "b cell", "mast", "ige", "interferon", "macrophage", "microglia", "inflammation"),
            influenceTokens = listOf("immune", "cytokine", "interferon", "t-cell", "b-cell", "mast", "ige", "macrophage", "microglia"),
            missingEvidencePrompts = listOf("immune-cell or cytokine marker", "pathway-level immune evidence", "comparative immune phenotype"),
            falsificationPrompts = listOf("immune marker is absent or opposite direction", "phenotype is not immune-mediated after comparator review")
        ),
        AxisTemplate(
            axisId = "genetic_dna_axis",
            role = "latent_context_pass",
            baseScore = 12,
            keywords = listOf("gene", "genetic", "dna", "mutation", "mmr", "msi", "tmb", "repair", "apoe", "chromosome"),
            influenceTokens = listOf("genetic", "dna", "repair", "mmr", "msi", "mutation", "apoe", "tmb"),
            missingEvidencePrompts = listOf("genetic or DNA-repair evidence", "variant/biomarker context", "gene-pathway support"),
            falsificationPrompts = listOf("required genetic marker absent", "DNA-repair or mutation context does not match")
        ),
        AxisTemplate(
            axisId = "protein_proteostasis_axis",
            role = "latent_context_pass",
            baseScore = 12,
            keywords = listOf("protein", "amyloid", "tau", "misfold", "proteostasis", "apoptosis", "cell cycle", "autophagy"),
            influenceTokens = listOf("protein", "amyloid", "tau", "misfolding", "proteostasis", "apoptosis", "autophagy", "cell-cycle"),
            missingEvidencePrompts = listOf("protein-clearance or proteostasis marker", "apoptosis/cell-cycle evidence", "disease-relevant protein signal"),
            falsificationPrompts = listOf("protein/proteostasis signal absent", "apoptosis/cell-cycle route contradicts observed biology")
        ),
        AxisTemplate(
            axisId = "barrier_inflammation_axis",
            role = "latent_context_pass",
            baseScore = 14,
            keywords = listOf("barrier", "permeability", "epithelial", "mucosa", "inflammation", "il-6", "tnf", "nfkb", "crp"),
            influenceTokens = listOf("barrier", "permeability", "epithelial", "inflammation", "il-6", "tnf", "nfkb", "crp"),
            missingEvidencePrompts = listOf("barrier/permeability evidence", "inflammatory mediator evidence", "tissue injury marker"),
            falsificationPrompts = listOf("barrier markers are normal", "inflammatory mediators do not support the route")
        ),
        AxisTemplate(
            axisId = "environment_diet_toxin_axis",
            role = "latent_context_pass",
            baseScore = 8,
            keywords = listOf("diet", "food", "toxin", "smoking", "drug", "medicine", "ppi", "fiber", "lectin", "environment"),
            influenceTokens = listOf("diet", "food", "toxin", "smoking", "ppi", "fiber", "lectin", "environment"),
            missingEvidencePrompts = listOf("exposure definition", "dose/time context", "risk-benefit and safety context"),
            falsificationPrompts = listOf("exposure not present or not biologically plausible", "public-health safety evidence contradicts the claim")
        )
    )

    fun build(
        contract: GTIMRunDecisionContractV2740,
        establishedEvidence: List<GTIMEstablishedEvidenceCardV2100>,
        discoveryFindings: List<GTIMDiscoveryFindingCardV2100>,
        mechanismMap: List<GTIMMechanismAxisCardV2100>,
        therapeuticRoutes: List<GTIMTherapeuticRouteCardV2100>,
        immunotherapyCards: List<GTIMTherapeuticHypothesisCardV2102>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMLatentAxisFilterReportV2107 {
        val corpus = listOf(
            contract.rawQuery,
            contract.normalizedQuery,
            contract.primaryAnchor.routeId,
            contract.diseaseFamily.name,
            contract.secondaryDomains.joinToString(" ") { it.name },
            contract.discoveryBridges.joinToString(" ") { it.routeId },
            contract.exploratoryRoutes.joinToString(" "),
            contract.allowedRoutes.joinToString(" "),
            contract.bridgeRationale,
            contract.reason,
            establishedEvidence.joinToString(" ") { it.statement + " " + it.topicArea },
            discoveryFindings.joinToString(" ") { it.finding + " " + it.requiredNextEvidence },
            mechanismMap.joinToString(" ") { it.axisId + " " + it.mechanismChain },
            therapeuticRoutes.joinToString(" ") { it.routeClass + " " + it.biologicalRationale },
            immunotherapyCards.joinToString(" ") { it.routeClass + " " + it.mechanismId + " " + it.requiredBiomarkers.joinToString(" ") },
            dgeVerdict.verdict + " " + dgeVerdict.blockers.joinToString(" ")
        ).joinToString(" ").lowercase()

        val scored = templates.map { template ->
            val matches = template.keywords.filter { keyword -> corpus.contains(keyword.lowercase()) }.distinct()
            val score = (template.baseScore + matches.size * 12).coerceAtMost(100)
            GTIMLatentAxisScoreV2107(
                axisId = template.axisId,
                role = template.role,
                score = score,
                matchedSignals = matches,
                influenceTokens = template.influenceTokens,
                missingEvidencePrompts = template.missingEvidencePrompts,
                falsificationPrompts = template.falsificationPrompts
            )
        }.sortedWith(compareByDescending<GTIMLatentAxisScoreV2107> { it.role.contains("mandatory") || it.role.contains("bridge") }.thenByDescending { it.score })

        val activeAxes = scored.filter { it.role.contains("mandatory") || it.role.contains("bridge") || it.score >= 30 }.take(7)
        val state = when {
            activeAxes.any { it.axisId == "microbiome_axis" } && activeAxes.any { it.axisId == "metabolic_axis" } -> "LATENT_AXIS_FILTER_READY_INTERNAL_PRIORITY_PASS"
            activeAxes.isNotEmpty() -> "LATENT_AXIS_FILTER_READY_INTERNAL_OPEN_PASS"
            else -> "LATENT_AXIS_FILTER_OPEN_NO_STRONG_AXIS"
        }
        return GTIMLatentAxisFilterReportV2107(
            active = true,
            version = VERSION,
            state = state,
            hidden = true,
            scores = activeAxes,
            routeInfluenceTokens = activeAxes.flatMap { it.influenceTokens }.distinct().take(40),
            missingEvidencePrompts = activeAxes.flatMap { it.missingEvidencePrompts }.distinct().take(12),
            falsificationPrompts = activeAxes.flatMap { it.falsificationPrompts }.distinct().take(12),
            policy = POLICY
        )
    }
}
