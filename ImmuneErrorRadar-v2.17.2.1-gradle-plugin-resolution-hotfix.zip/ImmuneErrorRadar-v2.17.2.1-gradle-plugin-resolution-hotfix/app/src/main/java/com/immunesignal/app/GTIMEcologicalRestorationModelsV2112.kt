package com.immunesignal.app

// v2.11.2 — Ecological Restoration Model models.
// Converts the pond-restoration analogy into a bounded research structure:
// collapse pattern -> missing stabilizing function -> restoration sequence -> recovery marker.

data class GTIMEcologicalCollapseSignalV2112(
    val signalId: String,
    val collapseType: String,
    val observedPattern: String,
    val likelyDrivers: List<String>,
    val missingStabilizingFunction: String,
    val claimLimit: String,
    val line: String
)

data class GTIMRestorationSequenceV2112(
    val sequenceId: String,
    val collapseSignalId: String,
    val firstRepairFunction: String,
    val secondOrderEffect: String,
    val recoveryMarkers: List<String>,
    val failureSignals: List<String>,
    val microbialRole: String,
    val confidenceState: String,
    val line: String
)

data class GTIMEcologicalRestorationReportV2112(
    val active: Boolean,
    val version: String,
    val state: String,
    val principle: String,
    val collapseSignals: List<GTIMEcologicalCollapseSignalV2112>,
    val restorationSequences: List<GTIMRestorationSequenceV2112>,
    val analogyGuard: List<String>,
    val integrationState: String,
    val boundaryLine: String,
    val line: String
) {
    companion object {
        fun empty(): GTIMEcologicalRestorationReportV2112 = GTIMEcologicalRestorationReportV2112(
            active = false,
            version = GTIMEcologicalRestorationModelV2112.VERSION,
            state = "ECOLOGICAL_RESTORATION_NOT_EVALUATED",
            principle = GTIMEcologicalRestorationModelV2112.PRINCIPLE,
            collapseSignals = emptyList(),
            restorationSequences = emptyList(),
            analogyGuard = GTIMEcologicalRestorationModelV2112.ANALOGY_GUARD,
            integrationState = "NOT_EVALUATED",
            boundaryLine = GTIMEcologicalRestorationModelV2112.BOUNDARY,
            line = "Ecological restoration model: not evaluated."
        )
    }
}
