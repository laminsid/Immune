package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.14.3 — manual agent control panel.
 *
 * The user-facing research runtime is not a wall-clock countdown. The app exposes
 * four explicit controls — Start, Pause, Continue, Stop — and each phase writes a
 * small checkpoint. Hidden safety budgets may remain for compatibility/audits, but
 * they are not the product strategy and are not shown as a countdown.
 */
object GTIMAgenticControlPanelV2143 {
    const val VERSION: String = "2.14.3-agentic-manual-controls-no-visible-duration"
    const val REQUIRED_TOKEN: String = "V2143_START_PAUSE_CONTINUE_STOP_NO_VISIBLE_COUNTDOWN"
    const val CLAIM_LIMIT: String = "controls_manage_research_workflow_not_evidence_strength"
    const val FAST_PASS_TARGET_MILLIS: Long = 2_000L

    val controls: List<String> = listOf("Start", "Pause", "Continue", "Stop")

    fun toJson(state: String, lastCheckpoint: String, topic: String): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("requiredToken", REQUIRED_TOKEN)
        .put("state", state)
        .put("topic", topic.take(180))
        .put("controls", JSONArray(controls))
        .put("lastCheckpoint", lastCheckpoint)
        .put("visibleDurationPolicy", "no_user_facing_countdown")
        .put("hiddenSafetyPolicy", "compatibility_only_not_strategy")
        .put("fastPassTargetMillis", FAST_PASS_TARGET_MILLIS)
        .put("defaultRoute", GTIMProfessionalOrchestratorHardLockV2142.DEFAULT_ROUTE)
        .put("legacyMonolithicRouteDefault", false)
        .put("claimLimit", CLAIM_LIMIT)

    fun uiBlock(state: String, checkpoint: String): String = buildString {
        append("Agent controls: Start / Pause / Continue / Stop\n")
        append("State: ").append(state).append("\n")
        append("Checkpoint: ").append(checkpoint.ifBlank { "ready" }).append("\n")
        append("Timing model: no visible countdown; progress is stage/checkpoint based.\n")
        append("Fast compact pass target: <=2s per local agent dossier when network proof execution is deferred.\n")
        append("Boundary: workflow control only; not proof, diagnosis, treatment, dosing, or clinical advice.")
    }
}
