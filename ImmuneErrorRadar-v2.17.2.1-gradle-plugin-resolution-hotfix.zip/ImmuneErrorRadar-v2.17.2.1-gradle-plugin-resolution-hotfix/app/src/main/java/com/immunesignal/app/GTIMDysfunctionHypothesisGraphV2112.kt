package com.immunesignal.app

// v2.11.2 — Builds dysfunction nodes from shared symptoms and root-cause signals.
object GTIMDysfunctionHypothesisGraphV2112 {
    const val VERSION: String = "2.11.2-dysfunction-hypothesis-graph"

    fun build(
        corpus: String,
        candidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
        ecologicalRestoration: GTIMEcologicalRestorationReportV2112
    ): List<GTIMDysfunctionHypothesisNodeV2112> {
        val text = (corpus + " " + candidates.joinToString(" ") { it.upstreamDysfunction + " " + it.causalChain } + " " + ecologicalRestoration.line).lowercase()
        val nodes = mutableListOf<GTIMDysfunctionHypothesisNodeV2112>()
        if (hasAny(text, listOf("fatigue", "fever", "pain", "brain fog", "joint", "rash", "inflammation", "symptom", "weakness", "gut"))) {
            nodes += node("OVERLAP_NON_SPECIFIC_SIGNAL", "symptom_overlap_not_disease_identity", "Shared symptoms can emerge from immune, infectious, metabolic, microbiome, environmental, or neuroimmune families.", "build competing dysfunction map before disease naming")
        }
        if (hasAny(text, listOf("inflammation", "cytokine", "autoimmune", "allergy", "mast", "ige", "th17", "treg")) || ecologicalRestoration.collapseSignals.any { it.signalId == "IMMUNE_OVERACTIVATION" }) {
            nodes += node("IMMUNE_DECISION_ERROR", "immune_overactivation_or_tolerance_loss", "The symptom cluster may reflect a decision error in immune threshold rather than one disease label.", "immune recalibration and tolerance-restoration route")
        }
        if (hasAny(text, listOf("barrier", "mucosal", "gut", "skin", "lung", "permeability")) || ecologicalRestoration.collapseSignals.any { it.signalId == "BARRIER_FAILURE" }) {
            nodes += node("BARRIER_FAILURE_NODE", "barrier_or_mucosal_failure", "Entry-surface or barrier failure can explain overlapping gut, skin, respiratory, and inflammatory symptoms.", "barrier repair and local ecological restoration")
        }
        if (hasAny(text, listOf("microbiome", "bacteria", "dysbiosis", "scfa", "butyrate", "metabolite"))) {
            nodes += node("MICROBIAL_ECOLOGY_NODE", "microbial_ecology_or_metabolite_imbalance", "Different diseases may share loss of microbial function or wrong metabolite direction.", "microbial/metabolite function restoration")
        }
        if (hasAny(text, listOf("toxin", "plastic", "pfas", "pollution", "water", "food", "exposome", "bpa", "phthalate"))) {
            nodes += node("EXPOSOME_PRESSURE_NODE", "external_pressure_or_toxin_context", "Exposure pressure can create disease-like symptom overlap through barrier, endocrine-immune, metabolic, or inflammatory routes.", "exposure measurement, buffering, or resilience function")
        }
        if (hasAny(text, listOf("metabolic", "insulin", "glucose", "mitochond", "energy", "lactate", "lipid"))) {
            nodes += node("IMMUNOMETABOLIC_STRESS_NODE", "immunometabolic_or_energy_stress", "Immune and tissue repair may fail when metabolic/mitochondrial context is unfavorable.", "metabolic resilience and immune-energy support")
        }
        if (nodes.isEmpty()) {
            nodes += node("OPEN_DYSFUNCTION_NODE", "open_root_dysfunction", "Symptoms or topic terms are insufficiently specific; keep the system in open dysfunction mapping mode.", "discriminating evidence before repair-route ranking")
        }
        return nodes.distinctBy { it.nodeId }.take(7)
    }

    private fun node(id: String, klass: String, rationale: String, need: String): GTIMDysfunctionHypothesisNodeV2112 {
        val line = "Dysfunction hypothesis node: version=$VERSION | id=$id | class=$klass | rationale=${rationale.oneLine()} | repair_need=${need.oneLine()}"
        return GTIMDysfunctionHypothesisNodeV2112(id, klass, rationale, need, line)
    }

    private fun hasAny(text: String, tokens: List<String>): Boolean = tokens.any { text.contains(it.lowercase()) }
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
