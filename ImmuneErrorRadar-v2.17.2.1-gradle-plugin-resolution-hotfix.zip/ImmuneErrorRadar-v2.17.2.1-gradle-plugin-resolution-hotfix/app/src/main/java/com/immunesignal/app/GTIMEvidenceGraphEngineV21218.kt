package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.12.18 — lightweight evidence graph. */
object GTIMEvidenceGraphEngineV21218 {
    const val VERSION: String = "2.12.18-evidence-graph-engine"
    const val CLAIM_LIMIT: String = "evidence_graph_routing_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val target = report.optJSONObject("targetValidationCardV21213") ?: JSONObject()
        val contradiction = report.optJSONObject("contradictionSearchEngineV21218") ?: JSONObject()
        val domain = ledger.optString("domainKey", "current_topic")
        val selected = ledger.optString("selectedReviewTarget", "unselected_dataset")
        val nodes = JSONArray()
            .put(node("domain", domain))
            .put(node("dataset", selected))
            .put(node("status", "review_target_not_evidence"))
        val targets = target.optJSONArray("targets") ?: JSONArray()
        for (idx in 0 until targets.length().coerceAtMost(4)) nodes.put(node("target", targets.optString(idx)))
        val readouts = target.optJSONArray("readouts") ?: JSONArray()
        for (idx in 0 until readouts.length().coerceAtMost(4)) nodes.put(node("readout", readouts.optString(idx)))
        val edges = JSONArray()
            .put(edge(domain, selected, "has_review_target", "unverified"))
            .put(edge(selected, "review_target_not_evidence", "claim_limited_by", "hard_gate"))
        if (contradiction.optInt("unresolvedConflictCount", 0) > 0) edges.put(edge(selected, "contradiction_check", "blocked_by", "unresolved"))
        return JSONObject()
            .put("version", VERSION)
            .put("state", "EVIDENCE_GRAPH_READY")
            .put("nodeCount", nodes.length())
            .put("edgeCount", edges.length())
            .put("nodes", nodes)
            .put("edges", edges)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Evidence graph engine",
        "State: ${obj.optString("state", "UNKNOWN")}; nodes=${obj.optInt("nodeCount", 0)}; edges=${obj.optInt("edgeCount", 0)}.",
        "Graph rule: disease/route, target, readout, dataset, contradiction, and claim-limit nodes are linked explicitly.",
        "Use: supports learning memory and red-team review by making support/weakness edges visible.",
        "Boundary: graph links are routing edges, not proof of causality or treatment effect."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "EVIDENCE_GRAPH_READY", "claim_limited_by", CLAIM_LIMIT))

    private fun node(type: String, id: String): JSONObject = JSONObject().put("type", type).put("id", id.ifBlank { "unknown" })
    private fun edge(from: String, to: String, relation: String, strength: String): JSONObject = JSONObject().put("from", from.ifBlank { "unknown" }).put("to", to.ifBlank { "unknown" }).put("relation", relation).put("strength", strength)
}
