package com.immunesignal.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local, tiny concept-capsule registry for cross-disease immune decision states. */
object GTIMConceptCapsuleStoreV21317 {
    const val VERSION: String = "2.13.17-concept-capsule-store"
    const val ASSET_INDEX_PATH: String = "concept_capsules/index.json"

    private val capsules: List<GTIMConceptCapsuleV21317> by lazy {
        listOf(
            concept(
                "trained_innate_immunity_core",
                "Trained innate immunity / HSPC memory",
                "trained_immunity_memory",
                "innate immunity is short-lived and has no memory",
                "exposure history may reprogram myeloid/HSPC states and change later inflammatory or antiviral responses",
                listOf("inflammation_resolution", "viral_interferon_cytokine", "filovirus_viral_host_response", "metabolic_inflammation", "oncology_tumor_microenvironment"),
                listOf("NLRP3", "IL1B", "TNF", "IL6", "SPI1", "CEBPA", "ISG15"),
                listOf("innate_training", "vaccine_or_adjuvant_direction", "diagnostic_biomarker"),
                "downgrade if trained/myeloid signatures do not persist across exposure state or do not outperform ordinary cytokine snapshots"
            ),
            concept(
                "hspc_epigenetic_memory",
                "HSPC epigenetic immune memory",
                "epigenetic_reprogramming",
                "bone marrow only emits naive immune cells after exposure",
                "hematopoietic progenitor state may store inflammatory history through chromatin/metabolic rewiring",
                listOf("inflammation_resolution", "hiv_aids_immune_activation", "metabolic_inflammation", "rheumatoid_autoimmune_synovial_inflammation"),
                listOf("ATAC_PROXY", "H3K4ME3_PROXY", "SPI1", "CEBPA", "IRF8", "RUNX1"),
                listOf("epigenetic_biomarker", "immune_age_assay", "mechanism_discovery"),
                "downgrade if progenitor/myeloid lineage signals are absent or explained by cell-composition artifact"
            ),
            concept(
                "peripheral_immune_tolerance_core",
                "Peripheral immune tolerance",
                "tolerance_failure_or_excess",
                "autoimmune disease is only generalized inflammation requiring broad suppression",
                "FOXP3/Treg localization and suppressive-state balance may define whether tissue attack stops or persists",
                listOf("rheumatoid_autoimmune_synovial_inflammation", "allergy_type2_barrier", "metabolic_inflammation", "oncology_tumor_microenvironment"),
                listOf("FOXP3", "IL2RA", "CTLA4", "IKZF2", "IL10", "TGFB1"),
                listOf("cell_therapy", "CAR_Treg", "biologic", "diagnostic_biomarker"),
                "downgrade if effector/Treg ratio, tissue-homing, or suppressive markers do not separate disease activity or tissue context"
            ),
            concept(
                "foxp3_treg_master_program",
                "FOXP3/Treg master program",
                "treg_engineering_tolerance",
                "Tregs are fixed, scarce, and too non-specific to guide targeted repair hypotheses",
                "FOXP3/Treg program can be treated as a programmable tissue-tolerance and repair axis in research previews",
                listOf("rheumatoid_autoimmune_synovial_inflammation", "allergy_type2_barrier", "oncology_tumor_microenvironment"),
                listOf("FOXP3", "IL2RA", "CTLA4", "CCR7", "CCR4", "IKZF2"),
                listOf("CAR_Treg", "cell_therapy", "gene_engineering", "tissue_specific_tolerance"),
                "downgrade if Treg markers are generic, not tissue-localized, or invert toward tumor immune escape rather than repair"
            ),
            concept(
                "neuro_immune_axis",
                "Neuro-immune axis",
                "neuroimmune_reprogramming",
                "the nervous system is isolated from peripheral immune decision states",
                "peripheral inflammation, cytokines, microglia-like programs, and vagal/neuroendocrine signals may co-shape mood, pain, recovery, and chronic disease state",
                listOf("inflammation_resolution", "hiv_aids_immune_activation", "metabolic_inflammation", "viral_interferon_cytokine"),
                listOf("IL6", "TNF", "CXCL10", "IDO1", "KMO", "BDNF", "CX3CR1"),
                listOf("diagnostic_biomarker", "neuroimmune_modulation", "mechanism_discovery"),
                "downgrade if immune signals do not link to neuroimmune readouts, timing, or phenotype labels"
            ),
            concept(
                "microbiome_immune_metabolite_axis",
                "Microbiome–immune metabolite axis",
                "microbiome_metabolite_reprogramming",
                "microbiome effects are only descriptive correlations",
                "microbial metabolites may shift tolerance, barrier, trained immunity, and neuroimmune tone through testable immune modules",
                listOf("allergy_type2_barrier", "metabolic_inflammation", "inflammation_resolution", "rheumatoid_autoimmune_synovial_inflammation"),
                listOf("AHR", "IDO1", "IL10", "TGFB1", "IL22", "MUC2", "TJP1"),
                listOf("microbiome_modulation", "metabolite_biomarker", "barrier_repair"),
                "downgrade if metabolite/barrier signals do not separate comparator groups or are not linked to immune module shifts"
            ),
            concept(
                "tissue_resident_immunity",
                "Tissue-resident immunity",
                "tissue_local_immune_memory",
                "blood antibody or blood cytokine levels are enough to describe protective immunity",
                "resident tissue immune states may explain protection, persistence, allergy, tumor control, or tissue damage better than blood-only markers",
                listOf("allergy_type2_barrier", "oncology_tumor_microenvironment", "viral_hantavirus_host_response", "filovirus_viral_host_response"),
                listOf("ITGAE", "CXCR6", "CCR7", "GZMB", "IL7R", "CD69"),
                listOf("diagnostic_biomarker", "vaccine_evaluation", "tissue_specific_immunity"),
                "downgrade if tissue-resident markers do not add predictive value beyond blood/static cytokine readouts"
            ),
            concept(
                "digital_immunomics_antibody_design",
                "AI-driven immunomics and de novo antibody design",
                "digital_immunomics_design",
                "immune drug discovery must rely primarily on long wet-lab screening before rational design can start",
                "antigen/receptor/epitope mapping and protein-language priors can generate digital binding hypotheses before wet-lab validation",
                listOf("oncology_tumor_microenvironment", "viral_interferon_cytokine", "filovirus_viral_host_response", "hiv_aids_immune_activation", "viral_hantavirus_host_response"),
                listOf("ANTIGEN", "EPITOPE", "TCR_BCR", "HLA", "BINDING_INTERFACE", "ESCAPE_MUTATION"),
                listOf("antibody", "de_novo_design", "protein_structure_prediction", "escape_mutation_analysis"),
                "downgrade if no antigen/epitope/receptor target is defined, or if design claims are presented as efficacy without wet-lab validation"
            ),
            concept(
                "immune_age_inflammaging",
                "Immune age / inflammaging / longevity resilience",
                "immune_age_longevity_reprogramming",
                "longevity is explained by calendar age alone rather than immune-state resilience",
                "aging trajectories may reflect inflammaging, trained innate memory, metabolic stress, tolerance balance, and repair-resolution capacity",
                listOf("immune_age_longevity", "inflammation_resolution", "metabolic_inflammation", "oncology_tumor_microenvironment", "hiv_aids_immune_activation"),
                listOf("IL6", "TNF", "NLRP3", "CDKN2A", "FOXP3", "SIRT1", "MTOR", "ISG15"),
                listOf("diagnostic_biomarker", "immune_age_assay", "microbiome_modulation", "innate_training", "mechanism_discovery"),
                "downgrade if immune-age markers do not separate resilience, frailty, recovery, or inflammaging phenotypes better than calendar age alone"
            ),
            concept(
                "protein_language_model_design",
                "Protein language model / binding design preview",
                "protein_language_digital_design",
                "immune interaction design cannot start without exhaustive wet-lab screening",
                "protein language and structure priors can nominate antigen, epitope, receptor, binding, and escape hypotheses before validation",
                listOf("oncology_tumor_microenvironment", "viral_interferon_cytokine", "filovirus_viral_host_response", "viral_hantavirus_host_response", "hiv_aids_immune_activation"),
                listOf("ANTIGEN", "EPITOPE", "RECEPTOR", "BINDING_INTERFACE", "ESCAPE_MUTATION", "STRUCTURE_PRIOR"),
                listOf("digital_antibody_design", "protein_structure_prediction", "antibody", "diagnostic_biomarker"),
                "downgrade if binding, antigen, epitope, or escape hypotheses are shown as validated efficacy instead of design-preview tasks"
            )
        )
    }

    fun allConcepts(): List<GTIMConceptCapsuleV21317> = capsules

    fun conceptsForDomain(domain: String): List<GTIMConceptCapsuleV21317> {
        val normalized = domain.trim()
        if (normalized.isBlank()) return emptyList()
        return capsules.filter { concept ->
            concept.diseaseDomains.any { it == normalized || normalized.contains(it, ignoreCase = true) || it.contains(normalized, ignoreCase = true) }
        }
    }

    fun bestConceptForDomain(domain: String): GTIMConceptCapsuleV21317? = conceptsForDomain(domain).firstOrNull()

    fun tryLoadAssetConcept(context: Context, assetPath: String): GTIMConceptCapsuleV21317? = try {
        val raw = context.assets.open(assetPath).bufferedReader().use { it.readText() }
        GTIMConceptCapsuleV21317.fromJson(JSONObject(raw))
    } catch (_: Exception) {
        null
    }

    fun toIndexJson(): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("claim_limit", GTIMConceptCapsuleV21317.CLAIM_LIMIT)
        .put("concepts", JSONArray(capsules.map { concept ->
            JSONObject()
                .put("concept_id", concept.conceptId)
                .put("axis", concept.axis)
                .put("asset", "concept_capsules/${concept.conceptId}.json")
        }))

    private fun concept(
        conceptId: String,
        title: String,
        axis: String,
        oldAssumption: String,
        mechanism: String,
        domains: List<String>,
        markers: List<String>,
        modalities: List<String>,
        falsifier: String
    ): GTIMConceptCapsuleV21317 = GTIMConceptCapsuleV21317(
        conceptId = conceptId,
        title = title,
        axis = axis,
        oldAssumptionChallenged = oldAssumption,
        candidateMechanism = mechanism,
        diseaseDomains = domains,
        moduleMarkers = markers,
        modalityLens = modalities,
        falsifier = falsifier
    )
}
