package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.17 — Lightweight concept capsule schema.
 *
 * Concept capsules sit above disease capsules. They encode cross-disease immune-state
 * ideas such as trained immunity, FOXP3/Treg tolerance, neuro-immune signaling, and
 * digital immunomics. They are not proof, treatment advice, dosing guidance, or wet-lab
 * protocols; they are bounded hypothesis lenses for sandbox discovery previews.
 */
data class GTIMConceptCapsuleV21317(
    val conceptId: String,
    val title: String,
    val axis: String,
    val oldAssumptionChallenged: String,
    val candidateMechanism: String,
    val diseaseDomains: List<String>,
    val moduleMarkers: List<String>,
    val modalityLens: List<String>,
    val falsifier: String,
    val claimLimit: String = CLAIM_LIMIT
) {
    fun toJson(): JSONObject = JSONObject()
        .put("concept_id", conceptId)
        .put("title", title)
        .put("axis", axis)
        .put("old_assumption_challenged", oldAssumptionChallenged)
        .put("candidate_mechanism", candidateMechanism)
        .put("disease_domains", JSONArray(diseaseDomains))
        .put("module_markers", JSONArray(moduleMarkers))
        .put("modality_lens", JSONArray(modalityLens))
        .put("falsifier", falsifier)
        .put("claim_limit", claimLimit)

    companion object {
        const val CLAIM_LIMIT: String = "concept_capsule_for_paradigm_hypothesis_not_validated_science_or_clinical_claim"

        fun fromJson(json: JSONObject): GTIMConceptCapsuleV21317 = GTIMConceptCapsuleV21317(
            conceptId = json.optString("concept_id", "unknown_concept"),
            title = json.optString("title", "unknown concept"),
            axis = json.optString("axis", "open_immune_reprogramming_axis"),
            oldAssumptionChallenged = json.optString("old_assumption_challenged", "old assumption not specified"),
            candidateMechanism = json.optString("candidate_mechanism", "candidate mechanism not specified"),
            diseaseDomains = json.optJSONArray("disease_domains").toStringList(),
            moduleMarkers = json.optJSONArray("module_markers").toStringList(),
            modalityLens = json.optJSONArray("modality_lens").toStringList(),
            falsifier = json.optString("falsifier", "downgrade if cross-disease mechanism fails domain-specific evidence checks"),
            claimLimit = json.optString("claim_limit", CLAIM_LIMIT)
        )
    }
}
