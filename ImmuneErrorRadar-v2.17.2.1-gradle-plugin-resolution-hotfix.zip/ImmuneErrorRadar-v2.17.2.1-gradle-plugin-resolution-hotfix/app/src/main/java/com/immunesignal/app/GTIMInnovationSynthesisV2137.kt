package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.7 — Innovation synthesis layer.
 * This layer moves beyond clean reporting by generating non-obvious, falsifiable
 * discovery-candidate hypotheses, competing explanations, replication paths, novelty
 * classes, and a first-page synthesis card. It remains research-only.
 */
object GTIMHypothesisMutationEngineV2137 {
    const val VERSION: String = "2.13.7-hypothesis-mutation-engine"
    const val CLAIM_LIMIT: String = "hypothesis_mutation_generates_testable_claims_not_proof"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val target = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val surprise = report.optJSONObject("signalSurpriseEngineV2137") ?: GTIMSignalSurpriseEngineV2137.toJson(report)
        val mutations = JSONArray(mutationsFor(domain, target))
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (mutations.length() > 0) "HYPOTHESIS_MUTATIONS_READY" else "HYPOTHESIS_MUTATIONS_NEED_ROUTE")
            .put("activeDomain", domain)
            .put("canonicalTarget", target)
            .put("inputSurprises", surprise.optJSONArray("surprisePatterns") ?: JSONArray())
            .put("mutatedHypotheses", mutations)
            .put("selectionRule", "prefer_non_obvious_subgroup_tissue_timing_or_comparator_claim_over_known_pathway_restatement")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val first = obj.optJSONArray("mutatedHypotheses")?.optJSONObject(0) ?: JSONObject()
        return listOf(
            "Hypothesis Mutation Engine",
            "State: ${obj.optString("state", "UNKNOWN")}; mutations=${obj.optJSONArray("mutatedHypotheses")?.length() ?: 0}; target=${obj.optString("canonicalTarget", "none")}",
            "Best mutation: ${first.optString("claim", "none")}",
            "Boundary: mutated hypotheses require module scoring, negative controls, and replication before discovery upgrade."
        )
    }

    private fun mutationsFor(domain: String, target: String): List<JSONObject> {
        val t = target.ifBlank { "selected_or_pending_capsule" }
        val triples = when {
            domain.contains("depression") -> listOf(
                Triple("subgroup_specific_kynurenine", "In $t, IDO1/KMO-kynurenine may stratify only inflammatory depression subgroups by brain-region/sex context.", "non_inflammatory_depression_or_wrong_brain_region"),
                Triple("artifact_competitor", "The kynurenine signal may reflect tissue/cell-composition artifact rather than depression mechanism.", "cell_composition_control"),
                Triple("cross_module_bridge", "IL-6/TNF tone may be the upstream selector that decides when kynurenine biology becomes phenotype-relevant.", "remove_inflammatory_strata")
            )
            domain.contains("allergy") -> listOf(
                Triple("threshold_instability", "In $t, type-2 threshold instability may separate allergic severity better than microbiome/barrier signal alone.", "type2_markers_do_not_separate_groups"),
                Triple("tolerance_axis", "HDM/tolerance group structure may reveal a Treg/Th imbalance that precedes effector mast/eosinophil modules.", "Treg_Th_axis_absent"),
                Triple("barrier_competitor", "Barrier signal may be secondary unless IgE/eosinophil/IL-4/IL-13 readouts move with it.", "barrier_only_without_type2_readout")
            )
            domain.contains("filovirus") -> listOf(
                Triple("timing_vs_static_cytokines", "Filovirus outcome may depend on interferon/endothelial timing rather than static cytokine intensity.", "no_timing_or_survival_comparator"),
                Triple("coagulation_interface", "Endothelial/coagulation module may be the discriminator between generic viral inflammation and hemorrhagic phenotype.", "coagulation_module_absent"),
                Triple("generic_viral_competitor", "The observed IFN/IL-6/TNF route may be generic viral response unless filovirus-specific comparator survives.", "replicates_only_in_COVID_like_data")
            )
            domain.contains("viral") -> listOf(
                Triple("phase_timing", "Post-viral persistence may be explained by IFN timing followed by late IL-6/TNF amplification, not baseline inflammation.", "acute_only_samples_without_recovery_labels"),
                Triple("tissue_injury_bridge", "Endothelial/tissue injury markers may explain persistence only when paired with recovery-state labels.", "injury_markers_do_not_track_recovery"),
                Triple("countermeasure_context", "Known antiviral/immunomodulator priors can triangulate host-response biology without implying treatment use.", "drug_seed_matches_without_module_signal")
            )
            domain.contains("metabolic") -> listOf(
                Triple("immune_energy_mismatch", "Metabolic inflammation may contain an immune-energy mismatch subgroup distinct from generic insulin resistance.", "no_metabolic_topic_capsule"),
                Triple("postbiotic_context", "Metabolite/postbiotic context may only matter when insulin/glucose and cytokine readouts move together.", "metabolite_readout_absent"),
                Triple("generic_inflammation_competitor", "IL-6/TNF signal may be nonspecific unless linked to metabolic comparator labels.", "cytokine_signal_not_metabolic_specific")
            )
            else -> listOf(
                Triple("open_subgroup_bridge", "A non-obvious subgroup bridge may exist if capsule/comparator/provenance gates close.", "no_topic_fit_capsule")
            )
        }
        return triples.mapIndexed { index, tri -> JSONObject().put("rank", index + 1).put("id", tri.first).put("claim", tri.second).put("killCondition", tri.third).put("status", "testable_mutation") }
    }
}

object GTIMMechanismCompetitionArenaV2137 {
    const val VERSION: String = "2.13.7-mechanism-competition-arena"
    const val CLAIM_LIMIT: String = "mechanism_competition_is_scoring_not_truth"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val hasTarget = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report).isNotBlank()
        val hasSignals = (report.optJSONObject("immuneModuleSignalEngineV2135")?.optJSONArray("moduleSignals")?.length() ?: 0) > 0
        val entries = listOf(
            competitor("H1_pathway_specific", if (hasSignals) 55 else 25, "domain module separates phenotype", "needs DGE/module score and replication"),
            competitor("H2_generic_inflammation", 45, "shared cytokine modules are common across diseases", "negative controls may demote it"),
            competitor("H3_batch_or_cell_composition_artifact", if (hasTarget) 35 else 60, "metadata/cell/tissue imbalance can mimic signal", "confounder guard required")
        )
        return JSONObject()
            .put("version", VERSION)
            .put("state", "MECHANISM_COMPETITION_READY")
            .put("activeDomain", domain)
            .put("competitors", JSONArray(entries))
            .put("winnerPolicy", "no_winner_until_module_score_replication_negative_control_and_confounder_review")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val comps = obj.optJSONArray("competitors") ?: JSONArray()
        val first = comps.optJSONObject(0) ?: JSONObject()
        return listOf(
            "Mechanism Competition Arena",
            "State: ${obj.optString("state", "UNKNOWN")}; competitors=${comps.length()}; top_candidate=${first.optString("id", "none")}; score=${first.optInt("score", 0)}.",
            "Winner policy: ${obj.optString("winnerPolicy", "no winner until replication")}",
            "Boundary: competition ranks explanations; it does not validate biology."
        )
    }

    private fun competitor(id: String, score: Int, support: String, risk: String): JSONObject = JSONObject()
        .put("id", id).put("score", score).put("support", support).put("risk", risk)
}

object GTIMC2AutoReplicationEngineV2137 {
    const val VERSION: String = "2.13.7-c2-auto-replication-triage"
    const val CLAIM_LIMIT: String = "replication_triage_is_not_executed_replication"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val canonical = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val candidates = replicationCandidates(domain, canonical)
        val state = when {
            canonical.isBlank() -> "C2_REPLICATION_NEEDS_CANONICAL_TARGET"
            candidates.isEmpty() -> "C2_REPLICATION_NEEDS_SECOND_DATASET"
            else -> "C2_REPLICATION_CANDIDATES_READY"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("activeDomain", domain)
            .put("primaryTarget", canonical)
            .put("replicationCandidates", JSONArray(candidates))
            .put("c2UpgradeRule", "same_module_same_direction_or_specific_phase_pattern_in_second_same_domain_dataset")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "C2 Auto-Replication Engine",
        "State: ${obj.optString("state", "UNKNOWN")}; primary=${obj.optString("primaryTarget", "none")}; candidates=${obj.optJSONArray("replicationCandidates")?.length() ?: 0}.",
        "C2 upgrade rule: ${obj.optString("c2UpgradeRule", "replication required")}",
        "Boundary: this selects replication candidates; it has not executed replication."
    )

    private fun replicationCandidates(domain: String, canonical: String): List<JSONObject> {
        val ids = when {
            domain.contains("depression") -> listOf("GSE72056", "GSE49454")
            domain.contains("allergy") -> listOf("GSE250594")
            domain.contains("filovirus") -> listOf("GSE131907")
            domain.contains("viral") -> listOf("GSE152202", "GSE152418", "GSE157103")
            domain.contains("metabolic") -> listOf("metabolic_topic_fit_dataset_required")
            else -> emptyList()
        }.filter { it != canonical && it.isNotBlank() }
        return ids.map { JSONObject().put("handle", it).put("status", if (it.contains("required")) "needs_external_discovery" else "candidate_review_only").put("requiredCheck", "same_module_direction_specificity_and_contradiction_review") }
    }
}

object GTIMCrossDiseaseImmuneConvergenceEngineV2137 {
    const val VERSION: String = "2.13.7-cross-disease-immune-convergence"
    const val CLAIM_LIMIT: String = "cross_disease_convergence_is_pattern_mining_not_mechanism_proof"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val modules = report.optJSONObject("immuneModuleSignalEngineV2135")?.optJSONArray("moduleSignals") ?: JSONArray()
        val moduleIds = (0 until modules.length()).mapNotNull { modules.optJSONObject(it)?.optString("moduleId")?.takeIf { s -> s.isNotBlank() } }
        val shared = moduleIds.filter { it.contains("il6") || it.contains("tnf") || it.contains("interferon") || it.contains("barrier") }
        val verdict = if (shared.isEmpty()) "no_broad_shared_module_detected" else "shared_module_requires_specificity_test"
        return JSONObject()
            .put("version", VERSION)
            .put("state", "CROSS_DISEASE_CONVERGENCE_READY")
            .put("activeDomain", domain)
            .put("sharedModules", JSONArray(shared))
            .put("verdict", verdict)
            .put("innovationUse", "separate_reusable_immune_pattern_from_noisy_generic_inflammation")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Cross-Disease Immune Convergence Engine",
        "State: ${obj.optString("state", "UNKNOWN")}; shared_modules=${obj.optJSONArray("sharedModules")?.length() ?: 0}; verdict=${obj.optString("verdict", "unknown")}",
        "Innovation use: ${obj.optString("innovationUse", "specificity testing")}",
        "Boundary: convergence suggests reusable patterns; it is not disease mechanism proof."
    )
}

object GTIMDrugVaccineMechanismTriangulationV2137 {
    const val VERSION: String = "2.13.7-drug-vaccine-mechanism-triangulation"
    const val CLAIM_LIMIT: String = "countermeasure_triangulation_is_mechanism_prior_not_advice"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val counter = report.optJSONObject("countermeasureSeedDatabaseV2135") ?: GTIMCountermeasureSeedDatabaseV2135.toJson(report)
        val matched = counter.optJSONArray("matchedSeeds") ?: JSONArray()
        val questions = JSONArray()
        if (matched.length() > 0 && domain.contains("viral")) {
            questions.put("Do antiviral/vaccine/immunomodulator priors explain host-response module timing without implying treatment use?")
            questions.put("Which module is intervention-adjacent: viral replication context, IFN timing, IL-6/JAK tone, or antibody-response context?")
        } else {
            questions.put("No same-domain countermeasure prior; keep drugs/vaccines as background only.")
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (matched.length() > 0) "MECHANISM_TRIANGULATION_PRIORS_READY" else "MECHANISM_TRIANGULATION_BACKGROUND_ONLY")
            .put("activeDomain", domain)
            .put("matchedCountermeasureSeeds", matched.length())
            .put("triangulationQuestions", questions)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Drug/Vaccine Mechanism Triangulation",
        "State: ${obj.optString("state", "UNKNOWN")}; matched_seeds=${obj.optInt("matchedCountermeasureSeeds", 0)}.",
        "Top question: ${obj.optJSONArray("triangulationQuestions")?.optString(0) ?: "none"}",
        "Boundary: mechanism priors only; no treatment, dosing, vaccine, efficacy, or clinical advice."
    )
}

object GTIMDiscoveryNoveltyMinerV2137 {
    const val VERSION: String = "2.13.7-discovery-novelty-miner"
    const val CLAIM_LIMIT: String = "novelty_mining_requires_literature_and_replication_before_claim"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val mutation = report.optJSONObject("hypothesisMutationEngineV2137") ?: GTIMHypothesisMutationEngineV2137.toJson(report)
        val className = when {
            domain.contains("depression") -> "known_pathway_new_subgroup_tissue_context_candidate"
            domain.contains("allergy") -> "known_type2_axis_new_comparator_threshold_candidate"
            domain.contains("filovirus") -> "known_viral_host_response_new_phase_or_endothelial_bridge_candidate"
            domain.contains("viral") -> "known_postviral_axis_new_timing_recovery_bridge_candidate"
            domain.contains("metabolic") -> "open_cross_domain_metabolic_immune_energy_candidate"
            else -> "open_contextual_bridge_candidate"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "DISCOVERY_NOVELTY_MINER_READY")
            .put("activeDomain", domain)
            .put("noveltyClass", className)
            .put("nonObviousnessBasis", mutation.optJSONArray("mutatedHypotheses")?.optJSONObject(0)?.optString("id", "not_available") ?: "not_available")
            .put("downgradeIf", "literature_already_reports_same_dataset_same_comparator_same_module_claim")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Discovery Novelty Miner",
        "State: ${obj.optString("state", "UNKNOWN")}; novelty=${obj.optString("noveltyClass", "unknown")}; basis=${obj.optString("nonObviousnessBasis", "unknown")}",
        "Downgrade if: ${obj.optString("downgradeIf", "known claim")}",
        "Boundary: novelty class is provisional until literature + replication checks run."
    )
}

object GTIMDiscoverySynthesisCardV2137 {
    const val VERSION: String = "2.13.7-discovery-synthesis-card"
    const val CLAIM_LIMIT: String = "innovation_synthesis_card_is_discovery_candidate_not_validated_discovery"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val target = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val mutation = report.optJSONObject("hypothesisMutationEngineV2137") ?: GTIMHypothesisMutationEngineV2137.toJson(report)
        val arena = report.optJSONObject("mechanismCompetitionArenaV2137") ?: GTIMMechanismCompetitionArenaV2137.toJson(report)
        val replication = report.optJSONObject("c2AutoReplicationEngineV2137") ?: GTIMC2AutoReplicationEngineV2137.toJson(report)
        val novelty = report.optJSONObject("discoveryNoveltyMinerV2137") ?: GTIMDiscoveryNoveltyMinerV2137.toJson(report)
        val best = mutation.optJSONArray("mutatedHypotheses")?.optJSONObject(0) ?: JSONObject()
        val level = when {
            target.isBlank() -> "C0_INNOVATION_ROUTE_ONLY"
            replication.optString("state") == "C2_REPLICATION_CANDIDATES_READY" -> "C1_PLUS_REPLICATION_READY_INNOVATION_CANDIDATE"
            else -> "C1_INNOVATION_CANDIDATE"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "DISCOVERY_SYNTHESIS_CARD_READY")
            .put("activeDomain", domain)
            .put("canonicalTarget", target.ifBlank { "not_selected" })
            .put("newClaimCandidate", best.optString("claim", "no mutated discovery candidate"))
            .put("whyItMayBeNew", novelty.optString("noveltyClass", "unknown"))
            .put("nonObviousSignal", best.optString("id", "none"))
            .put("competingExplanations", arena.optJSONArray("competitors") ?: JSONArray())
            .put("replicationStatus", replication.optString("state", "replication_not_closed"))
            .put("killCondition", best.optString("killCondition", "no kill condition"))
            .put("upgradePath", "C2 requires executing same module on second same-domain dataset; C3 requires cross-dataset robustness and contradiction resistance")
            .put("innovationLevel", level)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Discovery Synthesis Card",
        "New claim candidate: ${obj.optString("newClaimCandidate", "none")}",
        "Innovation level: ${obj.optString("innovationLevel", "C0")}; target=${obj.optString("canonicalTarget", "not_selected")}; why_new=${obj.optString("whyItMayBeNew", "unknown")}",
        "Replication: ${obj.optString("replicationStatus", "not closed")}; kill_condition=${obj.optString("killCondition", "not defined")}",
        "Upgrade path: ${obj.optString("upgradePath", "C2/C3 needs replication")}",
        "Boundary: synthesis card proposes a non-obvious Discovery Candidate; it is not validated discovery or medical advice."
    )
}

object GTIMFinalInnovationDiscoveryClosureV2137 {
    const val VERSION: String = "2.13.7-final-innovation-discovery-synthesis"
    const val CLAIM_LIMIT: String = "final_innovation_closure_candidate_only_no_validated_scientific_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val synthesis = report.optJSONObject("discoverySynthesisCardV2137") ?: GTIMDiscoverySynthesisCardV2137.toJson(report)
        val closure = report.optJSONObject("finalDiscoveryExecutionClosureV2136") ?: GTIMFinalDiscoveryExecutionClosureV2136.toJson(report)
        val level = synthesis.optString("innovationLevel", "C0")
        val oldNewLinked = closure.optBoolean("oldNewRoutesLinked", true)
        val state = if (level.startsWith("C1") && oldNewLinked) "FINAL_INNOVATION_DISCOVERY_SYNTHESIS_READY" else "FINAL_INNOVATION_DISCOVERY_SYNTHESIS_REVIEW_NOTES"
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("activeDomain", synthesis.optString("activeDomain"))
            .put("canonicalTarget", synthesis.optString("canonicalTarget"))
            .put("innovationLevel", level)
            .put("routeLinkage", "legacy research rails -> canonical target -> surprise/mutation/competition -> replication triage -> novelty miner -> synthesis card -> final locks")
            .put("strictnessPolicy", "relaxed_for_C0_C1_innovation_candidate_strict_for_C2_claim_upgrade_and_all_clinical_claims")
            .put("claimPromotionAllowed", true)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final Innovation Discovery Closure",
        "State: ${obj.optString("state", "UNKNOWN")}; innovation_level=${obj.optString("innovationLevel", "C0")}; target=${obj.optString("canonicalTarget", "not_selected")}",
        "Route linkage: ${obj.optString("routeLinkage", "old and new routes linked")}",
        "Strictness: ${obj.optString("strictnessPolicy", "C0/C1 relaxed; C2+ strict")}",
        "Boundary: final output can propose non-obvious Discovery Candidates; validated science still requires execution, replication, contradiction resistance, and external review."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FINAL_INNOVATION_DISCOVERY_SYNTHESIS_READY", "Hypothesis Mutation Engine", "Signal Surprise Engine", CLAIM_LIMIT))
}
