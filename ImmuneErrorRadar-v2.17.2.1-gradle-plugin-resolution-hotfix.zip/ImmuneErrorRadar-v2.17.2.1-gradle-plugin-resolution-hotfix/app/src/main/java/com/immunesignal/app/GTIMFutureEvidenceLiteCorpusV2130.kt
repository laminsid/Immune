package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.13.0 — Future Evidence Lite Corpus.
 *
 * A compact offline corpus that acts as a cleaned prior database for future-facing
 * hypothesis generation. It does not claim novelty, mechanism, clinical utility, or proof.
 */
object GTIMFutureEvidenceLiteCorpusV2130 {
    const val VERSION: String = "2.13.0-future-evidence-lite-corpus"
    const val ASSET_NAME: String = "gtim_future_evidence_lite_corpus_v2.13.0.json"
    const val CLAIM_LIMIT: String = "future_lite_corpus_prior_not_biological_proof"

    fun toJson(report: JSONObject): JSONObject {
        val domain = domainKey(report)
        // v2.13.6: do not match future-corpus entries from report.toString().
        // The report body already contains legacy/future text from other domains; using it
        // reintroduced depression/kynurenine priors inside allergy/filovirus reports.
        // ActiveDomain is the only selector allowed here.
        val matches = matchingEntries(domain)
        val best = matches.optJSONObject(0) ?: fallbackEntry(domain)
        val activeSubtype = GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report)
        val candidateHandles = mergeHandles(
            jsonStrings(best.optJSONArray("candidateHandles")),
            jsonStrings(report.optJSONObject("candidateHandleLedgerV21215")?.optJSONArray("allCandidateHandles")),
            extractHandles(report.toString())
        ).filter { GTIMActiveDomainConsistencyGuardV2134.handleFitsActiveDomain(it, domain, activeSubtype) }
        return JSONObject()
            .put("version", VERSION)
            .put("asset", ASSET_NAME)
            .put("state", if (matches.length() > 0) "FUTURE_LITE_CORPUS_MATCH_READY" else "FUTURE_LITE_CORPUS_FALLBACK_READY")
            .put("domainKey", domain)
            .put("matchedEntries", matches.length())
            .put("selectedDomain", best.optString("domain", domain))
            .put("primaryTargets", best.optJSONArray("primaryTargets") ?: JSONArray())
            .put("readouts", best.optJSONArray("readouts") ?: JSONArray())
            .put("crossDomainBridges", best.optJSONArray("crossDomainBridges") ?: JSONArray())
            .put("missingExperiments", best.optJSONArray("missingExperiments") ?: JSONArray())
            .put("highValueHypotheses", best.optJSONArray("highValueHypotheses") ?: JSONArray())
            .put("negativeControls", best.optJSONArray("negativeControls") ?: JSONArray())
            .put("candidateHandles", JSONArray(candidateHandles))
            .put("domainSelectionPolicy", "active_domain_exact_match_only_no_report_text_alias_scan")
            .put("futureCorpusCompatible", best.optString("domain", domain) == domain)
            .put("useOrder", JSONArray(listOf("future_lite_corpus", "curated_seed", "injected_metadata", "background_workers", "evidence_capsule", "contradiction_engine")))
            .put("futureAcceleration", "offline priors let GTIM propose testable underexplored bridges before waiting for APIs")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val domain = obj.optString("domainKey", "unknown")
        val selected = obj.optString("selectedDomain", domain)
        val compatible = obj.optBoolean("futureCorpusCompatible", selected == domain) && selected == domain
        if (!compatible) {
            return listOf(
                "Future Evidence Lite Corpus",
                "State: FUTURE_LITE_CORPUS_BACKGROUND_ONLY_DOMAIN_MISMATCH; domain=$domain; selected_domain=$selected; candidate_handles=background-only.",
                "Targets: suppressed because selected future corpus does not match active domain.",
                "Readouts: suppressed because selected future corpus does not match active domain.",
                "Use: background/contradiction prior only; no future hypothesis, targets, or readouts are rendered."
            )
        }
        return listOf(
            "Future Evidence Lite Corpus",
            "State: ${obj.optString("state", "UNKNOWN")}; domain=$domain; selected_domain=$selected; candidate_handles=${jsonStrings(obj.optJSONArray("candidateHandles")).take(5).joinToString(", ").ifBlank { "none" }}.",
            "Targets: ${jsonStrings(obj.optJSONArray("primaryTargets")).take(5).joinToString(", ").ifBlank { "not selected" }}.",
            "Readouts: ${jsonStrings(obj.optJSONArray("readouts")).take(5).joinToString(", ").ifBlank { "not selected" }}.",
            "Use: lightweight injected future-facing prior database; it accelerates hypothesis generation but never upgrades evidence."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, ASSET_NAME, "FUTURE_LITE_CORPUS_MATCH_READY", "active_domain_exact_match_only_no_report_text_alias_scan", CLAIM_LIMIT, "IDO1", "KMO", "interferon", "IL-4/IL-13"))

    internal fun domainKey(report: JSONObject): String = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)

    private fun matchingEntries(domain: String): JSONArray {
        val out = JSONArray()
        entries().forEach { e ->
            val d = e.optString("domain")
            if (d == domain) out.put(JSONObject(e.toString()))
        }
        return out
    }

    private fun fallbackEntry(domain: String): JSONObject = JSONObject()
        .put("domain", domain)
        .put("primaryTargets", JSONArray(listOf("immune mediator module", "tissue-context module", "exposure/context module")))
        .put("readouts", JSONArray(listOf("comparator labels", "sample provenance", "inflammatory module", "matrix/capsule availability")))
        .put("crossDomainBridges", JSONArray(listOf("exposure/context -> immune mediator -> tissue module -> phenotype subgroup")))
        .put("missingExperiments", JSONArray(listOf("direct topic-fit capsule with comparator and sample provenance")))
        .put("highValueHypotheses", JSONArray(listOf("under-tested subgroup relation may exist if comparator and capsule gates close")))
        .put("negativeControls", JSONArray(listOf("wrong tissue/species", "missing comparator", "confounded association")))
        .put("candidateHandles", JSONArray())

    private fun entries(): List<JSONObject> = listOf(
        entry("depression_kynurenine_neuroimmune", listOf("depression", "mood", "kynurenine", "tryptophan", "neuroimmune"), listOf("IDO1", "KMO", "TDO2", "ACMSD", "microglia-neuroimmune module"), listOf("kynurenine/tryptophan ratio", "quinolinic acid", "kynurenic acid", "IL-6/TNF tone", "glutamate/NMDA readout"), listOf("GSE102556"), listOf("inflammation -> IDO1 activation -> kynurenine shift -> neurotransmission stress", "circadian/metabolic stress -> tryptophan partitioning -> depression subgroup"), listOf("human cohort with depression/control labels plus IDO1/KMO/kynurenine readouts", "sample-level transcriptome/metabolomics capsule with inflammatory subgroup labels"), listOf("IDO1-driven kynurenine shift defines an inflammatory depression subgroup", "KMO branch imbalance separates neurotoxic versus regulatory kynurenine phenotypes"), listOf("non-inflammatory depression subgroup", "microbiome-only explanation without metabolite readout")),
        entry("viral_interferon_cytokine", listOf("covid", "post-viral", "viral", "interferon", "il-6", "tnf"), listOf("IFN-I timing module", "IFN-lambda mucosal module", "IL-6/TNF amplification module", "endothelial/tissue injury module"), listOf("ISG timing", "IL-6/TNF", "severity/recovery labels", "endothelial injury markers"), listOf("GSE166552", "GSE152202", "GSE152418", "GSE157103"), listOf("early interferon timing -> later cytokine amplification -> recovery persistence", "endothelial injury + immune timing -> severity subgroup"), listOf("longitudinal sample timing with severity/recovery comparator labels", "processed capsule linking IFN timing with IL-6/TNF and endothelial modules"), listOf("viral severity/recovery may be driven by interferon timing rather than generic barrier dysfunction", "endothelial-inflammation interface explains a high-risk recovery subgroup"), listOf("acute-only samples without recovery labels", "filovirus handles used as COVID targets without subtype match")),
        entry("filovirus_viral_host_response", listOf("ebola", "filovirus", "viral hemorrhagic"), listOf("filovirus host-response module", "interferon antagonism/timing module", "cytokine storm module", "endothelial/coagulation injury module"), listOf("IFN module timing", "IL-6/TNF", "coagulation/endothelial injury markers", "survival/severity labels"), listOf("GSE45291"), listOf("filovirus immune timing -> endothelial/coagulation injury -> severe outcome"), listOf("sample-level severity/survival comparator capsule"), listOf("filovirus outcome may be stratified by immune timing plus vascular injury module rather than cytokine level alone"), listOf("COVID/post-viral handles used as filovirus primary targets without subtype confirmation")),
        entry("allergy_type2_barrier", listOf("allergy", "type-2", "ige", "eosinophil", "mast", "asthma", "eczema"), listOf("IL-4/IL-13 type-2 axis", "IgE/mast/eosinophil module", "epithelial barrier module", "tolerance-threshold module", "alarmin axis TSLP/IL-33/IL-25"), listOf("IgE", "eosinophil/mast markers", "IL-4/IL-5/IL-13", "epithelial/barrier markers"), listOf("GSE146170", "GSE250594"), listOf("barrier/tolerance threshold -> type-2 amplification -> allergic phenotype", "alarmin epithelial signals -> IgE/eosinophil/mast cascade"), listOf("topic-fit capsule with allergy/type-2 comparator labels", "epithelial/readout capsule separated from generic microbiome claim"), listOf("type-2 threshold instability may explain allergic subgroup severity better than microbiome signal alone"), listOf("barrier-only claim without IgE/eosinophil/type-2 readout")),
        entry("neuroinflammation_alzheimer", listOf("alzheimer", "neuroinflammation", "microglia", "complement", "inflammasome"), listOf("microglia activation module", "C1q/C3 complement-synapse module", "NLRP3 inflammasome", "TREM2/APOE context", "BBB/endothelial neuroimmune interface"), listOf("microglial markers", "C1q/C3", "IL-1beta/TNF", "synaptic injury module", "BBB/endothelial markers"), emptyList(), listOf("microglia/complement -> synaptic injury -> cognitive phenotype", "BBB/endothelial stress -> neuroimmune activation -> progression subgroup"), listOf("human tissue/blood separation with microglia/complement readouts"), listOf("microglia-complement-synapse triad may define a progression subgroup distinct from generic inflammation"), listOf("blood-only inflammatory signal claimed as brain mechanism without tissue bridge")),
        entry("exposome_immune_metabolic_bridge", listOf("microplastic", "pesticide", "pollution", "xenobiotic", "metabolic"), listOf("xenobiotic-response module", "oxidative/mitochondrial stress module", "barrier-immune module", "metabolic-inflammatory module"), listOf("AhR/Nrf2 stress signals", "CRP/IL-6/TNF", "mitochondrial fatigue readouts", "barrier markers"), emptyList(), listOf("environmental exposure -> barrier/metabolic stress -> immune mediator -> phenotype subgroup", "xenobiotic response -> oxidative stress -> cytokine tone -> fatigue/mood/metabolic phenotype"), listOf("exposure-labeled cohort with immune/metabolic readouts"), listOf("exposure-linked immune-metabolic signature may explain subgroups currently classified by symptoms only"), listOf("unmeasured exposure proxy treated as causal exposure"))
    )

    private fun entry(domain: String, aliases: List<String>, targets: List<String>, readouts: List<String>, handles: List<String>, bridges: List<String>, gaps: List<String>, hypotheses: List<String>, negatives: List<String>): JSONObject = JSONObject()
        .put("domain", domain)
        .put("domainAliases", JSONArray(aliases))
        .put("primaryTargets", JSONArray(targets))
        .put("readouts", JSONArray(readouts))
        .put("candidateHandles", JSONArray(handles))
        .put("crossDomainBridges", JSONArray(bridges))
        .put("missingExperiments", JSONArray(gaps))
        .put("highValueHypotheses", JSONArray(hypotheses))
        .put("negativeControls", JSONArray(negatives))

    private fun extractHandles(text: String): List<String> = Regex("\\b(GSE\\d+|SRP\\d+|PRJNA\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+|PMID:\\d+)\\b", RegexOption.IGNORE_CASE)
        .findAll(text).map { it.value.uppercase(Locale.US) }.distinct().toList()

    private fun mergeHandles(vararg lists: List<String>): List<String> = lists.flatMap { it }.map { it.uppercase(Locale.US) }.distinct().take(12)

    internal fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx -> array.optString(idx).takeIf { it.isNotBlank() } }
}
