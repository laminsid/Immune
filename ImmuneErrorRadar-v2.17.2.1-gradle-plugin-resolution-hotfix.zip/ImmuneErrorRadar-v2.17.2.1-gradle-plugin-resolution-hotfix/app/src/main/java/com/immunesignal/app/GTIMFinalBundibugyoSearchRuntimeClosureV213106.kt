package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.13.10.6 — final Bundibugyo/BDBV + search-to-report crash closure.
 *
 * This is a narrow post-v2.13.10.5 hardening layer. It does not introduce new biology.
 * It prevents Bundibugyo/BDBV and filovirus prompts from being satisfied by generic
 * COVID/post-viral capsules, forces matrix shortcut recomputation through the canonical
 * guard, and records a UI transition policy so report-generation failures degrade into a
 * saved/exportable report instead of closing the app.
 */
object GTIMFinalBundibugyoSearchRuntimeClosureV213106 {
    const val VERSION: String = "2.13.10.6-final-bundibugyo-search-runtime-closure"
    const val ENGINE_VERSION: String = "v2.13.10.6-final-bundibugyo-search-runtime-closure"
    const val CLAIM_LIMIT: String = "final_bundibugyo_search_runtime_closure_only_no_evidence_upgrade"

    fun isBundibugyo(report: JSONObject): Boolean = contextText(report).let { text ->
        containsAny(text, "bundibugyo", "bdbv", "bundibugyo ebolavirus", "bundibugyo virus", "ebola bundibugyo")
    }

    fun isFilovirus(report: JSONObject): Boolean = contextText(report).let { text ->
        isBundibugyo(report) || containsAny(text, "filovirus", "ebolavirus", "ebola", "viral hemorrhagic fever", "hemorrhagic fever", "viral_filovirus")
    }

    fun effectiveActiveDomain(report: JSONObject): String {
        val inferred = GTIMRouteConfidenceGateV21311.infer(report)
        return when {
            inferred.locked -> inferred.lockedRoute
            isFilovirus(report) -> "filovirus_viral_host_response"
            else -> GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        }
    }

    fun effectiveSubtype(report: JSONObject): String {
        val inferred = GTIMRouteConfidenceGateV21311.infer(report)
        return when {
            inferred.locked -> inferred.lockedSubtype
            isBundibugyo(report) -> "viral_filovirus_bundibugyo"
            isFilovirus(report) -> "viral_filovirus"
            else -> GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report)
        }
    }

    fun isCovidGenericTarget(handle: String): Boolean = handle.uppercase(Locale.US) in setOf(
        "GSE166552", "GSE152202", "GSE152418", "GSE157103"
    )

    fun isFilovirusCanonicalTarget(handle: String): Boolean = handle.uppercase(Locale.US) in setOf(
        "GSE45291"
    )

    fun isBundibugyoCanonicalTarget(handle: String): Boolean = handle.uppercase(Locale.US) in setOf(
        "GSE_BDBV", "BDBV_COMPATIBLE_CAPSULE", "BDBV_HOST_RESPONSE_CAPSULE"
    )

    fun finalCanonicalTarget(report: JSONObject): String {
        val evidenceFirst = GTIMCanonicalTargetAfterRouteLockV21311.canonicalTarget(report)
        val inferred = GTIMRouteConfidenceGateV21311.infer(report)
        if (inferred.locked) return evidenceFirst
        val subtype = effectiveSubtype(report)
        val candidates = collectHandles(report)
        return when (subtype) {
            "viral_filovirus_bundibugyo" -> candidates.firstOrNull { isBundibugyoCanonicalTarget(it) }.orEmpty()
            "viral_filovirus" -> candidates.firstOrNull { isFilovirusCanonicalTarget(it) }.orEmpty()
            else -> GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        }
    }

    fun targetAllowed(handle: String, subtype: String = ""): Boolean {
        if (handle.isBlank()) return true
        val s = subtype.ifBlank { "nonviral_or_unspecified" }
        return when (s) {
            "viral_filovirus_bundibugyo" -> isBundibugyoCanonicalTarget(handle)
            "viral_filovirus" -> isFilovirusCanonicalTarget(handle)
            else -> true
        }
    }

    fun toJson(report: JSONObject, stage: String = "FINAL_SEARCH_RUNTIME_CLOSURE"): JSONObject {
        val subtype = effectiveSubtype(report)
        val active = effectiveActiveDomain(report)
        val canonical = finalCanonicalTarget(report)
        val handles = collectHandles(report)
        val blocked = handles.filter { !targetAllowed(it, subtype) }
        val covidBlocked = blocked.filter { isCovidGenericTarget(it) }
        val matrix = report.optJSONObject("matrixShortcutResolverV2124") ?: JSONObject()
        val matrixHandle = matrix.optString("handle")
        val matrixSafe = canonical.isNotBlank() || matrixHandle.isBlank() || targetAllowed(matrixHandle, subtype)
        val state = when {
            subtype == "viral_filovirus_bundibugyo" && canonical.isBlank() -> "FINAL_BDBV_TOPIC_ROUTE_READY_NEEDS_BDBV_CAPSULE"
            subtype == "viral_filovirus" && canonical.isBlank() -> "FINAL_FILOVIRUS_TOPIC_ROUTE_READY_NEEDS_FILOVIRUS_CAPSULE"
            subtype.startsWith("viral_filovirus") && covidBlocked.isNotEmpty() -> "FINAL_FILOVIRUS_ROUTE_READY_GENERIC_COVID_TARGETS_BLOCKED"
            !matrixSafe -> "FINAL_SEARCH_RUNTIME_REVIEW_MATRIX_HANDLE_NOT_CANONICAL"
            else -> "FINAL_BUNDIBUGYO_SEARCH_RUNTIME_READY"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("engineVersion", ENGINE_VERSION)
            .put("state", state)
            .put("activeDomain", active)
            .put("activeSubtype", subtype)
            .put("canonicalTarget", canonical)
            .put("bundibugyoDetected", isBundibugyo(report))
            .put("filovirusDetected", isFilovirus(report))
            .put("blockedGenericTargets", JSONArray(blocked))
            .put("blockedCovidTargets", JSONArray(covidBlocked))
            .put("matrixShortcutHandle", matrixHandle)
            .put("matrixShortcutSafe", matrixSafe)
            .put("blankSearchSafe", true)
            .put("reportTransitionSafe", true)
            .put("safeStage", stage)
            .put("runtimePolicy", "blank search clears checkpoint and never replays old topic; search-to-report rendering is saved/exportable-first; preview failures degrade to compact safe text")
            .put("routePolicy", "Bundibugyo/BDBV cannot use COVID/post-viral capsules; filovirus cannot use generic viral COVID capsules; if no compatible capsule exists, canonical_target remains empty")
            .put("strictness", "C0/C1/C2/C3 experimental preview relaxed; subtype mismatch remains strict; patient action/dosing/clinical implementation not allowed")
            .put("routeLinkage", "legacy rails -> evidence-first route discovery -> BDBV/filovirus subtype gate -> active-domain guard -> canonical target guard -> recomputed matrix shortcut -> final release/test locks")
            .put("claimPromotionAllowed", true)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final Bundibugyo/BDBV search-runtime closure",
        "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; subtype=${obj.optString("activeSubtype", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; blocked_covid_targets=${obj.optJSONArray("blockedCovidTargets")?.length() ?: 0}.",
        "Route policy: ${obj.optString("routePolicy", "subtype-specific canonical targets only")}",
        "Runtime policy: ${obj.optString("runtimePolicy", "saved/exportable-first report transition")}",
        "Matrix shortcut: handle=${obj.optString("matrixShortcutHandle", "")}; safe=${obj.optBoolean("matrixShortcutSafe", false)}.",
        "Strictness: ${obj.optString("strictness", "C0/C1 relaxed; validated/actionable claims guarded")}",
        "Boundary: final route/runtime hardening only; experimental preview labels are allowed for testing, but no patient action, dosing, clinical implementation, or validated proof."
    )

    fun compactRuntimeFallback(stage: String, throwable: Throwable): String =
        "Report saved safely. Preview was reduced at $stage to prevent the app from closing. Export PDF or Copy Report remains available. Error=${throwable::class.java.simpleName}."

    private fun collectHandles(report: JSONObject): List<String> {
        val out = linkedSetOf<String>()
        fun add(value: String) {
            val v = value.trim().uppercase(Locale.US)
            if (Regex("^(GSE\\d{3,8}|BDBV[_A-Z0-9-]*)$").matches(v)) out.add(v)
        }
        fun addArray(array: JSONArray?) {
            if (array == null) return
            for (i in 0 until array.length()) {
                when (val item = array.opt(i)) {
                    is String -> add(item)
                    is JSONObject -> listOf("handle", "target", "accession", "id", "selectedClosedTarget", "selectedReviewTarget").forEach { add(item.optString(it)) }
                }
            }
        }
        val keys = listOf(
            "candidateHandleLedgerV21215", "terminalDiscoveryContinuationV21212", "injectedMetadataSeedPackV21216",
            "futureEvidenceLiteCorpusV2130", "verifiedMetadataClosurePackV2132", "finalDataClosureExecutionV2132",
            "matrixShortcutResolverV2124", "finalReleaseLockV21219", "activeDomainConsistencyGuardV2134",
            "canonicalFinalSurfaceGuardV2135", "finalUnifiedDiscoveryReadinessClosureV21310"
        )
        keys.forEach { key ->
            val obj = report.optJSONObject(key) ?: return@forEach
            listOf("selectedReviewTarget", "selectedClosedTarget", "canonicalTarget", "canonicalFinalTarget", "handle", "target").forEach { add(obj.optString(it)) }
            listOf("candidateHandles", "allCandidateHandles", "handles", "blockedGenericTargets").forEach { addArray(obj.optJSONArray(it)) }
        }
        Regex("\\b(GSE\\d{3,8}|BDBV[_A-Z0-9-]*)\\b", RegexOption.IGNORE_CASE).findAll(report.toString()).forEach { add(it.value) }
        return out.toList()
    }

    private fun contextText(report: JSONObject): String {
        val keys = listOf(
            "topicCapture", "studyFocusNormalizerV21282", "domainSpecificHypothesisSelectorV2129",
            "candidateHandleLedgerV21215", "curatedMetadataSeedLibraryV21211", "searchStabilityClosureV21217",
            "runDecisionContractV2740", "gtimRunDecisionContractV2740"
        )
        val parts = mutableListOf<String>()
        parts += listOf(report.optString("researchTopic"), report.optString("normalizedTopic"), report.optString("topic"))
        keys.forEach { key ->
            val obj = report.optJSONObject(key) ?: return@forEach
            obj.keys().forEach { k ->
                val v = obj.opt(k)
                if (v is String && v.length < 800) parts += v
            }
        }
        return parts.joinToString(" ").lowercase(Locale.US)
    }

    private fun containsAny(text: String, vararg terms: String): Boolean = terms.any { text.contains(it) }
}
