package com.immunesignal.app

/** v2.10.1 — evidence table builder for medical-study-like dossier output. */
object GTIMEvidenceTableBuilderV2101 {
    const val VERSION: String = "2.10.1-evidence-table-builder"

    fun build(
        protocol: GTIMResearchProtocolCardV2101,
        established: List<GTIMEstablishedEvidenceCardV2100>,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        routes: List<GTIMTherapeuticRouteCardV2100>
    ): List<GTIMEvidenceTableRowV2101> {
        val rows = mutableListOf<GTIMEvidenceTableRowV2101>()
        established.take(4).forEachIndexed { index, card ->
            rows += row(
                id = "EVIDENCE_ESTABLISHED_${index + 1}_${card.cardId}",
                claim = card.statement,
                source = card.evidenceKind,
                design = designFor(card.evidenceLevel),
                population = protocol.populationOrProblem,
                intervention = card.topicArea,
                comparator = protocol.comparator,
                outcome = card.applicabilityLimit,
                certainty = card.evidenceLevel,
                validation = "ESTABLISHED_SCIENCE_BASELINE_NOT_APP_DISCOVERY",
                limitation = card.applicabilityLimit
            )
        }
        discovery.take(4).forEachIndexed { index, card ->
            rows += row(
                id = "EVIDENCE_GTIM_DISCOVERY_${index + 1}_${card.findingId}",
                claim = card.finding,
                source = card.sourceLayer,
                design = "repository_metadata_or_execution_state",
                population = protocol.populationOrProblem,
                intervention = "GTIM exploration layer",
                comparator = "not confirmed unless source_field and evidence_snippet are present",
                outcome = card.requiredNextEvidence,
                certainty = "D_TO_E_EXPLORATORY_OR_EXECUTION_STATE",
                validation = card.validationStatus,
                limitation = "GTIM discovery is not established science and is not authority-validated by the app."
            )
        }
        routes.take(5).forEachIndexed { index, route ->
            rows += row(
                id = "EVIDENCE_ROUTE_${index + 1}_${route.routeId}",
                claim = route.biologicalRationale,
                source = "therapeutic_route_hypothesis",
                design = "mechanism_to_translation_route_review",
                population = protocol.populationOrProblem,
                intervention = route.routeClass,
                comparator = protocol.comparator,
                outcome = route.requiredBiomarkersOrEvidence.joinToString(", "),
                certainty = route.evidenceLevel,
                validation = route.validationStatus,
                limitation = "Research-only route; ${route.forbiddenClaims.joinToString(", ")}."
            )
        }
        return rows.distinctBy { it.rowId }.take(14)
    }

    private fun designFor(level: String): String = when {
        level.startsWith("A") -> "guideline_or_high_certainty_clinical_evidence_context"
        level.startsWith("B") -> "clinical_or_review_evidence_context"
        level.startsWith("C") -> "mechanistic_or_early_clinical_context"
        level.startsWith("D") -> "dataset_or_exploratory_context"
        level.contains("SAFETY") -> "safety_boundary_or_claim_guard"
        else -> "method_or_context_baseline"
    }

    private fun row(
        id: String,
        claim: String,
        source: String,
        design: String,
        population: String,
        intervention: String,
        comparator: String,
        outcome: String,
        certainty: String,
        validation: String,
        limitation: String
    ): GTIMEvidenceTableRowV2101 {
        val line = "Evidence table: id=$id | source=$source | design=$design | certainty=$certainty | validation=$validation | claim=${claim.oneLine()} | comparator=${comparator.oneLine()} | outcome=${outcome.oneLine()} | limitation=${limitation.oneLine()}"
        return GTIMEvidenceTableRowV2101(
            rowId = id,
            claimOrRoute = claim.oneLine(),
            sourceClass = source,
            studyDesign = design,
            populationContext = population.oneLine(),
            interventionOrExposure = intervention.oneLine(),
            comparator = comparator.oneLine(),
            outcomeOrReadout = outcome.oneLine(),
            certainty = certainty,
            validationStatus = validation,
            limitation = limitation.oneLine(),
            line = line
        )
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
