package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.14 — final evidence-first route discovery unified closure.
 *
 * This is the last defensive layer after v2.13.10.2. It does not create biological proof.
 * It closes final-surface drift, subtype-specific canonical-target mistakes, empty-query
 * replay risk, and stale legacy active-target wording before export/readiness surfaces.
 */
object GTIMFinalRouteSearchHardeningClosureV213103 {
    // legacy_v21314_active_compat: VERSION: String = "2.13.14-final-generalized-route-coherence-unified"
    const val VERSION: String = "2.13.15-final-hypothesis-first-discovery-unified"
    const val ENGINE_VERSION: String = "v2.13.15-final-hypothesis-first-discovery-unified"
    const val CLAIM_LIMIT: String = "route_search_hardening_only_no_evidence_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val activeDomain = GTIMFinalBundibugyoSearchRuntimeClosureV213106.effectiveActiveDomain(report)
        val subtype = GTIMFinalBundibugyoSearchRuntimeClosureV213106.effectiveSubtype(report)
        val canonicalTarget = GTIMFinalBundibugyoSearchRuntimeClosureV213106.finalCanonicalTarget(report)
        val bundibugyoClosure = GTIMFinalBundibugyoSearchRuntimeClosureV213106.toJson(report, "FINAL_ROUTE_SEARCH_HARDENING")
        val canonicalGuard = report.optJSONObject("canonicalFinalSurfaceGuardV2135") ?: JSONObject()
        val staleGuard = report.optJSONObject("staleSurfaceZeroExportGuardV2138") ?: JSONObject()
        val matrix = GTIMMatrixShortcutResolverV2124.toJson(report)
        val unified = report.optJSONObject("finalUnifiedDiscoveryReadinessClosureV21310") ?: JSONObject()
        val blankSearchPolicy = JSONArray(listOf(
            "blank_query_never_replays_previous_topic",
            "blank_query_clears_checkpoint_before_return",
            "blank_query_does_not_start_background_search",
            "blank_query_returns_safe_prompt_message"
        ))
        val filovirusCanonicalAllowed = !subtype.startsWith("viral_filovirus") || canonicalTarget.isBlank() ||
            GTIMFinalBundibugyoSearchRuntimeClosureV213106.targetAllowed(canonicalTarget, subtype)
        val emptyCanonicalSafe = canonicalTarget.isNotBlank() || matrix.optString("handle").isBlank()
        val staleItems = staleGuard.optInt("staleSurfaceItems", 0)
        val versionAligned = EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ENGINE_VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == 192 &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == "2.13.15" &&
            ReleaseVersionLinkageGuard.VERSION_NAME == VERSION &&
            ReleaseVersionLinkageGuard.ENGINE_VERSION == ENGINE_VERSION &&
            unified.optBoolean("versionAligned", false)
        val hardeningBlockers = JSONArray()
        if (!versionAligned) hardeningBlockers.put("version_identity_drift")
        if (!filovirusCanonicalAllowed) hardeningBlockers.put("filovirus_or_bundibugyo_subtype_canonical_target_not_allowed")
        if (subtype == "viral_filovirus_bundibugyo" && canonicalTarget.isNotBlank()) hardeningBlockers.put("bundibugyo_requires_bdbv_specific_target_or_empty_canonical")
        if (!emptyCanonicalSafe) hardeningBlockers.put("empty_canonical_target_still_has_matrix_handle")
        if (staleItems > 0) hardeningBlockers.put("stale_legacy_surface_items_present")
        val state = if (hardeningBlockers.length() == 0) {
            "FINAL_ROUTE_SEARCH_HARDENING_READY"
        } else {
            "FINAL_ROUTE_SEARCH_HARDENING_REVIEW_REQUIRED"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("engineVersion", ENGINE_VERSION)
            .put("state", state)
            .put("activeDomain", activeDomain)
            .put("activeSubtype", subtype)
            .put("canonicalTarget", canonicalTarget)
            .put("filovirusCanonicalAllowed", filovirusCanonicalAllowed)
            .put("emptyCanonicalSafe", emptyCanonicalSafe)
            .put("staleSurfaceItems", staleItems)
            .put("blankSearchPolicy", blankSearchPolicy)
            .put("bundibugyoRuntimeStabilityClosure", bundibugyoClosure)
            .put("reportTransitionSafe", true)
            .put("legacySurfacePolicy", "legacy candidates remain visible only as historical_lookup_only / superseded_by_canonical_target / not_active_target")
            .put("versionAligned", versionAligned)
            .put("hardeningBlockers", hardeningBlockers)
            .put("canonicalGuardState", canonicalGuard.optString("state", "missing"))
            .put("matrixShortcutHandle", matrix.optString("handle"))
            .put("routeLinkage", "blank-search guard -> active subtype guard -> canonical target guard -> legacy supersession -> stale-zero export -> final unified readiness")
            .put("claimPromotionAllowed", true)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        if (obj.optString("activeDomain") == "filovirus_viral_host_response") "Final Bundibugyo/BDBV search-runtime closure" else "Final route/search-runtime hardening closure",
        "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; subtype=${obj.optString("activeSubtype", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; version_aligned=${obj.optBoolean("versionAligned", false)}.",
        "Hardening: active_domain_route_safe=${obj.optBoolean("filovirusCanonicalAllowed", false)}; empty_canonical_safe=${obj.optBoolean("emptyCanonicalSafe", false)}; stale_surface_items=${obj.optInt("staleSurfaceItems", -1)}; blockers=${obj.optJSONArray("hardeningBlockers")?.length() ?: 0}.",
        "Blank-search policy: blank query never replays the previous topic, clears checkpoints, does not start background search, and returns a safe prompt message.",
        "Legacy surface policy: ${obj.optString("legacySurfacePolicy", "legacy candidates are compatibility-only")}",
        "Route linkage: ${obj.optString("routeLinkage", "legacy_and_new_routes_linked")}",
        "Boundary: this hardening layer changes routing/export safety only; it does not validate biology, diagnosis, treatment, dosing, vaccine advice, or efficacy."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        ENGINE_VERSION,
        "FINAL_ROUTE_SEARCH_HARDENING_READY",
        "blank_query_never_replays_previous_topic",
        "filovirus_subtype_canonical_target_not_allowed",
        "filovirus_or_bundibugyo_subtype_canonical_target_not_allowed",
        "bundibugyo_requires_bdbv_specific_target_or_empty_canonical",
        "search_completion_to_report_render_is_safe",
        "historical_lookup_only",
        CLAIM_LIMIT
    ))
}
