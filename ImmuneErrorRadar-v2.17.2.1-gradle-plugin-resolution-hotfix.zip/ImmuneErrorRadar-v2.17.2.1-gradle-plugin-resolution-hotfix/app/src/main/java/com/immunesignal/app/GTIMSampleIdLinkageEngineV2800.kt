package com.immunesignal.app

/** v2.8.0 — Sample ID linkage engine. Blocks DGE until matrix columns/barcodes match metadata rows. */
data class GTIMSampleIdLinkageReportV2800(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val requiredKeys: List<String>,
    val sampleLinkageLine: String,
    val boundaryLine: String
)

object GTIMSampleIdLinkageEngineV2800 {
    const val VERSION: String = "2.8.0-sample-id-linkage-engine"
    private val KEYS = listOf("GSM_sample_id", "matrix_column_id", "cell_barcode", "metadata_row_id", "run_accession", "batch_id")

    fun build(
        matrixReader: GTIMMatrixReaderPreviewReportV2800,
        metadataCleaner: GTIMMetadataCleanerReportV2800
    ): GTIMSampleIdLinkageReportV2800 {
        val state = when {
            matrixReader.state.contains("BLOCKED_NO_TOPIC", true) -> "SAMPLE_LINKAGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"
            matrixReader.state == "MATRIX_READER_WAITING_FOR_OBSERVED_FILE_EVIDENCE" -> "SAMPLE_LINKAGE_PENDING_OBSERVED_MATRIX_FILE_EVIDENCE"
            matrixReader.state == "MATRIX_READER_WAITING_FOR_DOWNLOAD" -> "SAMPLE_LINKAGE_PENDING_MATRIX_DOWNLOAD"
            metadataCleaner.state == "METADATA_EXTRACTION_REQUIRED" -> "SAMPLE_LINKAGE_PENDING_METADATA_EXTRACTION"
            matrixReader.state == "MATRIX_READER_SCHEMA_CANDIDATE_REVIEW_ONLY" && metadataCleaner.state == "METADATA_NORMALIZATION_REVIEW_READY" -> "SAMPLE_LINKAGE_READY_FOR_REVIEW_ONLY_JOIN"
            else -> "SAMPLE_LINKAGE_REVIEW_REQUIRED"
        }
        val line = "Sample ID linkage: version=$VERSION | state=$state | target=${matrixReader.targetId} | required_keys=${KEYS.joinToString(",")} | block_dge_until_observed_matrix_columns_match_metadata_rows=true"
        return GTIMSampleIdLinkageReportV2800(
            active = true,
            targetId = matrixReader.targetId,
            state = state,
            requiredKeys = KEYS,
            sampleLinkageLine = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Sample linkage boundary: no DGE until sample IDs/barcodes are joined and reviewed."
        )
    }
}
