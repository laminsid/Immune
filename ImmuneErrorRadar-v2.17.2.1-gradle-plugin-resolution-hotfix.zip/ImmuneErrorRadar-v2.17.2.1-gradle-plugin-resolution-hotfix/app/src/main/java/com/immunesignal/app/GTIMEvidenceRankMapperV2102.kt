package com.immunesignal.app

// v2.10.2 — Evidence Rank A-X mapper.
// Rank A may be surfaced as a candidate context from the knowledge base, but clinical action still requires external confirmation.
// ClinicalTrials.gov request plans support exploration and evidence expansion, not treatment authorization.
object GTIMEvidenceRankMapperV2102 {
    const val VERSION: String = "2.10.4-relaxed-evidence-rank-a-x"

    fun map(match: GTIMImmunotherapyKnowledgeMatchV2102, hasExternalCapsule: Boolean, hasDgeReady: Boolean): Pair<String, String> {
        val raw = match.entry.evidenceRank.uppercase()
        val reason = when {
            raw.startsWith("A") && match.matchedTerms.size >= 2 -> "A-candidate can be surfaced for research when the mechanism and biomarker context match; keep it unverified until an external source is imported."
            raw.contains("X") -> "Rank can fall to X when current-variant escape, contradicted evidence, or unsafe public-health claim is documented."
            hasDgeReady -> "DGE-ready review can support dataset-level evidence but still does not prove clinical efficacy."
            hasExternalCapsule -> "External capsule may support a research summary if provenance, contrast, and claim limits are valid."
            match.matchState.contains("NEAR_MATCH") -> "Near-match is allowed as a weak research lead; missing biomarkers/sources become next-evidence prompts, not discovery blockers."
            else -> "Mechanism ontology match can produce an exploratory therapeutic route; external authority/trial/systematic evidence is needed only before clinical-strength claims."
        }
        val rank = when {
            raw.startsWith("A") && match.matchedTerms.size >= 2 -> "A_CANDIDATE_CONTEXT_DEPENDENT"
            raw.contains("A_TO_X") -> "A_TO_X_VARIANT_DEPENDENT"
            raw.contains("A_TO_D") -> "A_TO_D_CONTEXT_DEPENDENT"
            raw.contains("B_TO_C") -> "B_TO_C_EMERGING"
            raw.contains("B_TO_E") -> "B_TO_E_CONTEXT_DEPENDENT"
            raw.contains("C_TO_E") -> "C_TO_E_CONTEXT_DEPENDENT"
            raw.contains("D_TO_E") -> "D_TO_E_EXPLORATORY"
            else -> raw
        }
        return rank to reason
    }
}
