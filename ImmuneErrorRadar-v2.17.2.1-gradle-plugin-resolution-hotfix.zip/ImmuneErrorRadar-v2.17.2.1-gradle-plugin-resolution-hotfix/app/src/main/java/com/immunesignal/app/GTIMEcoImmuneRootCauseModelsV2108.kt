package com.immunesignal.app

// v2.10.8 — Root-cause eco-immune research models.
// This layer changes the internal research direction from symptom/product endpoints
// toward upstream dysfunction: microbiome, metabolism, immune interaction, endocrine,
// barrier, neuroimmune, genetic/protein, context/ecology, and restoration routes.

data class GTIMEcoImmuneRootCauseCandidateV2108(
    val candidateId: String,
    val state: String,
    val upstreamDysfunction: String,
    val causalChain: String,
    val restorationNeed: String,
    val supportingSignals: List<String>,
    val missingEvidence: List<String>,
    val falsificationTests: List<String>,
    val contextModifiers: List<String>,
    val priority: String,
    val line: String
)

data class GTIMEcosystemRestorationRouteV2108(
    val routeId: String,
    val routeClass: String,
    val restorationLogic: String,
    val researchLevers: List<String>,
    val requiredEvidence: List<String>,
    val safetyBoundary: String,
    val line: String
)

data class GTIMRootCauseFalsificationPlanV2108(
    val planId: String,
    val candidateId: String,
    val decisiveTests: List<String>,
    val weakeningSignals: List<String>,
    val invalidationRule: String,
    val line: String
)

data class GTIMEcoImmuneRootCauseReportV2108(
    val active: Boolean,
    val version: String,
    val state: String,
    val philosophy: String,
    val rootCauseGraphState: String,
    val candidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
    val restorationRoutes: List<GTIMEcosystemRestorationRouteV2108>,
    val falsificationPlans: List<GTIMRootCauseFalsificationPlanV2108>,
    val endpointFailureChecks: List<String>,
    val contextEcologyModifiers: List<String>,
    val boundaryLine: String,
    val line: String,
    val microbialReversal: GTIMMicrobialReversalReportV2111? = null,
    val ecologicalRestoration: GTIMEcologicalRestorationReportV2112? = null,
    val symptomOverlap: GTIMSymptomOverlapReportV2112? = null,
    val repairPriorityValidation: GTIMRepairPriorityValidationReportV2113? = null
) {
    companion object {
        fun empty(): GTIMEcoImmuneRootCauseReportV2108 = GTIMEcoImmuneRootCauseReportV2108(
            active = false,
            version = GTIMEcoImmuneRootCauseEngineV2108.VERSION,
            state = "ECO_IMMUNE_ROOT_CAUSE_NOT_EVALUATED",
            philosophy = GTIMEcoImmuneRootCauseEngineV2108.PHILOSOPHY,
            rootCauseGraphState = "NOT_EVALUATED",
            candidates = emptyList(),
            restorationRoutes = emptyList(),
            falsificationPlans = emptyList(),
            endpointFailureChecks = emptyList(),
            contextEcologyModifiers = emptyList(),
            boundaryLine = GTIMEcoImmuneRootCauseEngineV2108.BOUNDARY,
            line = "Eco-immune root-cause engine: not evaluated.",
            microbialReversal = GTIMMicrobialReversalReportV2111.empty(),
            ecologicalRestoration = GTIMEcologicalRestorationReportV2112.empty(),
            symptomOverlap = GTIMSymptomOverlapReportV2112.empty(),
            repairPriorityValidation = GTIMRepairPriorityValidationReportV2113.empty()
        )
    }
}
