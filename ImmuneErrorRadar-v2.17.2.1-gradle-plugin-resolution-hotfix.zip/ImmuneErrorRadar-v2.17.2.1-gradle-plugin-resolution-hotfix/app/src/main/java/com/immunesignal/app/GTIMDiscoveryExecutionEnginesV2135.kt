package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.5 — Discovery support engines: comparator, replication, negative control,
 * confounder, novelty, contradiction execution, and mechanism assembly.
 */
object GTIMDiscoveryExecutionEnginesV2135 {
    const val VERSION: String = "2.13.5-discovery-execution-engines"
    const val CLAIM_LIMIT: String = "discovery_execution_triage_not_validated_scientific_discovery"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val capsuleStore = report.optJSONObject("processedCapsuleStoreV2135") ?: GTIMProcessedCapsuleStoreV2135.toJson(report)
        val capsule = capsuleStore.optJSONObject("selectedCapsule") ?: JSONObject()
        val readiness = capsule.optInt("readiness", 0)
        val comparator = capsule.optString("comparatorState", "missing")
        val provenance = capsule.optString("provenanceState", "missing")
        val modules = GTIMProcessedCapsuleStoreV2135.jsonStrings(capsule.optJSONArray("moduleIds"))
        val replication = when {
            active.contains("viral") && !active.contains("filovirus") && readiness >= 8 -> "replication_candidate_available_same_domain_required"
            active.contains("depression") && readiness >= 8 -> "replication_required_second_depression_or_inflammatory_subgroup_dataset"
            active.contains("allergy") && readiness >= 8 -> "replication_required_second_allergy_type2_dataset"
            else -> "replication_not_closed"
        }
        val negativeControls = JSONArray(listOf(
            "wrong_tissue_or_species_control",
            "unrelated_inflammatory_condition_control",
            "batch_platform_control",
            "broad_cytokine_non_specificity_control"
        ))
        val confounders = JSONArray(listOf(
            "age_sex_balance", "tissue_mixing", "treatment_status", "acute_vs_chronic_timing", "cell_composition_bias"
        ))
        val novelty = when {
            active.contains("depression") -> "known_pathway_under_tested_subgroup_or_dataset_bridge"
            active.contains("allergy") -> "known_type2_route_new_comparator_capsule_bridge"
            active.contains("filovirus") -> "filovirus_host_response_candidate_needs_comparator_closure"
            active.contains("viral") -> "known_postviral_host_response_possible_capsule_mapping_value"
            else -> "open_mechanism_bridge"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "DISCOVERY_EXECUTION_TRIAGE_READY")
            .put("activeDomain", active)
            .put("comparatorGate", if (comparator == "closed") "COMPARATOR_GATE_CLOSED" else "COMPARATOR_GATE_PARTIAL_OR_MISSING")
            .put("provenanceGate", if (provenance == "closed") "PROVENANCE_GATE_CLOSED" else "PROVENANCE_GATE_PARTIAL_OR_MISSING")
            .put("replicationStatus", replication)
            .put("negativeControls", negativeControls)
            .put("confoundersToCheck", confounders)
            .put("noveltyClass", novelty)
            .put("contradictionExecution", "run_same_modules_against_negative_or_contradiction_dataset_before_upgrade")
            .put("mechanismAssembly", mechanismFor(active, modules))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Discovery execution engines",
        "State: ${obj.optString("state", "UNKNOWN")}; comparator=${obj.optString("comparatorGate", "unknown")}; provenance=${obj.optString("provenanceGate", "unknown")}; replication=${obj.optString("replicationStatus", "unknown")}",
        "Novelty class: ${obj.optString("noveltyClass", "unknown")}",
        "Contradiction execution: ${obj.optString("contradictionExecution", "not defined")}",
        "Boundary: execution triage can nominate discovery candidates, not validated medical/scientific truth."
    )

    private fun mechanismFor(domain: String, modules: List<String>): String = when {
        domain.contains("allergy") -> "allergen/tissue context -> type-2 threshold instability -> ${modules.take(3).joinToString(" + ")} -> phenotype comparator"
        domain.contains("filovirus") -> "filovirus trigger -> interferon timing/endothelial injury/coagulation interface -> severity or survival comparator"
        domain.contains("viral") -> "viral trigger -> interferon timing + IL-6/TNF amplification -> recovery/severity/persistence comparator"
        domain.contains("depression") -> "inflammatory tone -> IDO1/KMO/kynurenine module -> neuroimmune neurotransmission stress -> depression subgroup comparator"
        else -> "context -> immune mediator module -> tissue readout -> phenotype comparator"
    }
}
