package com.immunesignal.app

import org.json.JSONObject

object GTIMPublicExpressionSourceRegistryV2980 {
    const val VERSION: String = "2.9.8-public-expression-source-registry"

    fun build(
        targetId: String,
        soft: GTIMSoftMetadataProbeReportV2950,
        mapping: GTIMGseToSrpMappingReportV2950,
        external: GTIMExternalAvailabilityReportV2950,
        capsule: GTIMExternalEvidenceCapsuleImportReportV2980? = null,
        report: JSONObject? = null
    ): GTIMPublicExpressionSourceRegistryReportV2980 {
        val target = GTIMAccessionIdValidityGuardV2753.canonical(targetId)
        if (soft.state.contains("BLOCKED_NO_TOPIC", true) || target.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true)) {
            return emit(target, "PUBLIC_SOURCES_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", emptyList(), "none")
        }
        val availability = availabilityObject(report)
        val routes = listOf(
            greinRoute(target, soft, availability),
            refineBioRoute(target, soft, mapping, availability),
            recount3Route(target, mapping, external, availability),
            enrichrRoute(target, capsule, availability),
            sigComRoute(target, capsule, availability)
        )
        val available = routes.filter { it.state.endsWith("AVAILABLE_REVIEW_ONLY") }
        val candidates = routes.filter { it.state.contains("CANDIDATE") || it.state.endsWith("AVAILABLE_REVIEW_ONLY") }
        val state = when {
            available.isNotEmpty() -> "PUBLIC_EXPRESSION_ROUTE_AVAILABLE_REVIEW_ONLY"
            candidates.isNotEmpty() -> "PUBLIC_EXPRESSION_ROUTES_CANDIDATE"
            soft.state.contains("PROBE_REQUIRED", true) -> "PUBLIC_EXPRESSION_ROUTES_REQUIRE_METADATA_FIRST"
            else -> "PUBLIC_EXPRESSION_ROUTES_REVIEW_REQUIRED"
        }
        val preferred = available.firstOrNull()?.sourceId ?: candidates.firstOrNull()?.sourceId ?: "none"
        return emit(target, state, routes, preferred)
    }

    private fun greinRoute(target: String, soft: GTIMSoftMetadataProbeReportV2950, availability: JSONObject): GTIMPublicExpressionSourceRouteV2980 {
        val state = when {
            availability.optBoolean("greinAvailable", false) -> "GREIN_ROUTE_AVAILABLE_REVIEW_ONLY"
            target.startsWith("GSE", true) && soft.state.contains("GEO_SOFT_METADATA", true) -> "GREIN_ROUTE_CANDIDATE"
            target.startsWith("GSE", true) -> "GREIN_ROUTE_REQUIRES_SOFT_METADATA"
            else -> "GREIN_ROUTE_NOT_APPLICABLE"
        }
        val handle = if (target.startsWith("GSE", true)) target else "not_applicable"
        return route("GREIN", state, handle, "processed_expression_or_signature", "GEO accession based public processed RNA-seq candidate")
    }

    private fun refineBioRoute(target: String, soft: GTIMSoftMetadataProbeReportV2950, mapping: GTIMGseToSrpMappingReportV2950, availability: JSONObject): GTIMPublicExpressionSourceRouteV2980 {
        val hasHandle = target.startsWith("GSE", true) || mapping.srpAccessions.isNotEmpty() || soft.bioProjectAccessions.isNotEmpty()
        val handle = listOf(target, mapping.srpAccessions.firstOrNull().orEmpty(), soft.bioProjectAccessions.firstOrNull().orEmpty()).firstOrNull { it.isNotBlank() } ?: "not_available"
        val state = when {
            availability.optBoolean("refineBioAvailable", false) -> "REFINEBIO_ROUTE_AVAILABLE_REVIEW_ONLY"
            hasHandle -> "REFINEBIO_ROUTE_CANDIDATE"
            else -> "REFINEBIO_ROUTE_REQUIRES_GEO_SRA_OR_BIOPROJECT_HANDLE"
        }
        return route("refine.bio", state, handle, "standardized_expression_matrix_or_metadata", "public processed expression dataset candidate")
    }

    private fun recount3Route(target: String, mapping: GTIMGseToSrpMappingReportV2950, external: GTIMExternalAvailabilityReportV2950, availability: JSONObject): GTIMPublicExpressionSourceRouteV2980 {
        val srp = mapping.srpAccessions.firstOrNull().orEmpty()
        val state = when {
            availability.optBoolean("recount3Available", false) || external.availableRoutes.any { it.equals("recount3", true) } -> "RECOUNT3_ROUTE_AVAILABLE_REVIEW_ONLY"
            srp.isNotBlank() -> "RECOUNT3_ROUTE_CANDIDATE"
            target.startsWith("GSE", true) -> "RECOUNT3_ROUTE_REQUIRES_GSE_TO_SRP_MAPPING"
            else -> "RECOUNT3_ROUTE_NOT_APPLICABLE"
        }
        return route("recount3", state, srp.ifBlank { target }, "processed_bulk_rnaseq_expression", "SRP/SRA mapped external expression route; never equals internal DGE_READY")
    }

    private fun enrichrRoute(target: String, capsule: GTIMExternalEvidenceCapsuleImportReportV2980?, availability: JSONObject): GTIMPublicExpressionSourceRouteV2980 {
        val hasGenes = capsule?.topGenes?.isNotEmpty() == true
        val state = when {
            availability.optBoolean("enrichrAvailable", false) || hasGenes -> "ENRICHR_ROUTE_AVAILABLE_REVIEW_ONLY"
            else -> "ENRICHR_ROUTE_REQUIRES_TOP_GENE_LIST"
        }
        return route("Enrichr", state, target, "gene_set_enrichment_from_capsule_genes", "pathway interpretation only after top-gene capsule exists")
    }

    private fun sigComRoute(target: String, capsule: GTIMExternalEvidenceCapsuleImportReportV2980?, availability: JSONObject): GTIMPublicExpressionSourceRouteV2980 {
        val upDown = capsule?.topGenes?.any { it.direction.equals("up", true) } == true && capsule.topGenes.any { it.direction.equals("down", true) }
        val state = when {
            availability.optBoolean("sigComAvailable", false) || upDown -> "SIGCOM_LINCS_ROUTE_AVAILABLE_REVIEW_ONLY"
            else -> "SIGCOM_LINCS_ROUTE_REQUIRES_UP_DOWN_SIGNATURE"
        }
        return route("SigComLINCS", state, target, "signature_similarity_or_reverse_translation", "similarity route; no treatment efficacy claim")
    }

    private fun route(source: String, state: String, handle: String, output: String, reason: String): GTIMPublicExpressionSourceRouteV2980 {
        val line = "Public expression source: version=$VERSION | source=$source | state=$state | handle=$handle | output=$output | reason=$reason | no_internal_dge_ready=true"
        return GTIMPublicExpressionSourceRouteV2980(source, state, handle, output, reason, normalize(line))
    }

    private fun emit(target: String, state: String, routes: List<GTIMPublicExpressionSourceRouteV2980>, preferred: String): GTIMPublicExpressionSourceRegistryReportV2980 {
        val summary = routes.joinToString(",") { "${it.sourceId}:${it.state}" }.ifBlank { "none" }
        val line = "Public expression registry: version=$VERSION | state=$state | target=$target | preferred=$preferred | routes=$summary | external_sources_are_route_candidates_not_claims=true"
        return GTIMPublicExpressionSourceRegistryReportV2980(
            active = true,
            targetId = target,
            state = state,
            routes = routes,
            preferredRoute = preferred,
            line = normalize(line),
            boundaryLine = "Public expression boundary: GREIN/refine.bio/recount3/Enrichr/SigCom are public route/capsule sources; availability never creates internal DGE_READY, treatment advice, dosing, clinical management, or efficacy claims."
        )
    }

    private fun availabilityObject(report: JSONObject?): JSONObject = report?.optJSONObject("publicExpressionAvailability")
        ?: report?.optJSONObject("externalProcessedAvailability")
        ?: JSONObject()

    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
