package com.immunesignal.app

// v2.11.2 — Selects evidence that distinguishes overlapping dysfunction hypotheses.
object GTIMDiscriminatingEvidencePlannerV2112 {
    const val VERSION: String = "2.11.2-discriminating-evidence-planner"

    fun plan(nodes: List<GTIMDysfunctionHypothesisNodeV2112>): List<GTIMDiscriminatingEvidencePlanV2112> = nodes.mapIndexed { index, node ->
        val evidence = when (node.nodeId) {
            "IMMUNE_DECISION_ERROR" -> listOf("cytokine direction", "autoantibody/allergy marker where relevant", "Treg/Th/mast-cell context", "time-direction after exposure or infection")
            "BARRIER_FAILURE_NODE" -> listOf("mucosal or permeability marker", "local tissue context", "microbiome-metabolite bridge", "negative-control non-barrier comparator")
            "MICROBIAL_ECOLOGY_NODE" -> listOf("microbial functional profile", "metabolite panel", "strain/function not name-only", "diet/antibiotic context")
            "EXPOSOME_PRESSURE_NODE" -> listOf("measured exposure or credible capsule", "burden or oxidative marker", "barrier/metabolic bridge", "source-time alignment")
            "IMMUNOMETABOLIC_STRESS_NODE" -> listOf("glucose/insulin/lipid/mitochondrial proxy", "immune-cell metabolic phenotype", "lactate/hypoxia context", "subgroup comparator")
            else -> listOf("mechanism biomarker", "context history", "comparative disease family", "falsification test")
        }
        val against = nodes.filter { it.nodeId != node.nodeId }.map { it.dysfunctionClass }.take(4)
        val id = "DISCRIMINATE_${index + 1}_${node.nodeId}".take(96)
        val line = "Discriminating evidence plan: version=$VERSION | id=$id | node=${node.nodeId} | evidence=${evidence.joinToString(";").oneLine()} | distinguishes_from=${against.joinToString(";").oneLine()}"
        GTIMDiscriminatingEvidencePlanV2112(id, node.nodeId, evidence, against, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
