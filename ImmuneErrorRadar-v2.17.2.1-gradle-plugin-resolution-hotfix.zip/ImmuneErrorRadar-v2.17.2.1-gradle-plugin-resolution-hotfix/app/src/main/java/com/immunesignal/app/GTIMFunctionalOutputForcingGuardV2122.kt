package com.immunesignal.app

import org.json.JSONObject

// v2.12.2 — Functional Output Forcing Guard.
// Guarantees that the PDF/text export cannot regress to a generic Medical Research
// Dossier only. The old report remains available technically, but the user-facing surface
// must show relaxed research value + functional repair + study-grade solution first.
object GTIMFunctionalOutputForcingGuardV2122 {
    const val VERSION: String = "2.12.2-functional-output-forcing-guard"
    const val REQUIRED_BLOCKS: String = "Research value produced|Functional repair study dossier|Study-grade solution hypothesis|Validation ladder"

    fun forcedValueLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val technical = if (technicalLines.isNotEmpty()) technicalLines else GlobalResearchGradeBriefV11061.renderLines(report)
        val out = mutableListOf<String>()
        out += GTIMRelaxedResearchLeadBridgeV2122.publicLines(report, technical)
        out += ""
        out += GTIMFunctionalRepairDossierEngineV2120.publicLines(report, technical)
        out += ""
        out += GTIMStudyGradeFunctionalSolutionEngineV2121.publicLines(report, technical)
        return out
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        return JSONObject()
            .put("version", VERSION)
            .put("requiredBlocks", REQUIRED_BLOCKS)
            .put("relaxedResearchLead", GTIMRelaxedResearchLeadBridgeV2122.toJson(report, technicalLines))
            .put("claimLimit", "display_forcing_only_no_evidence_upgrade")
    }
}
