package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.12.18 — maps selected dataset/handle to study use. */
object GTIMDatasetToStudyMapperV21218 {
    const val VERSION: String = "2.12.18-dataset-to-study-mapper"
    const val CLAIM_LIMIT: String = "dataset_mapping_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val capsule = report.optJSONObject("evidenceCapsuleBuilderV21218") ?: JSONObject()
        val contradiction = report.optJSONObject("contradictionSearchEngineV21218") ?: JSONObject()
        val selected = capsule.optString("selectedReviewTarget", report.optJSONObject("candidateHandleLedgerV21215")?.optString("selectedReviewTarget") ?: "")
        val score = capsule.optInt("capsuleScore", 0)
        val conflicts = contradiction.optInt("unresolvedConflictCount", 0)
        val use = when {
            score >= 9 && conflicts == 0 -> "VALIDATION_CANDIDATE_AFTER_EXTERNAL_REVIEW"
            score >= 6 && conflicts <= 2 -> "DISCOVERY_AND_PARTIAL_VALIDATION_CANDIDATE"
            score >= 3 -> "DISCOVERY_ONLY_CANDIDATE"
            else -> "BACKGROUND_LOOKUP_ONLY"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "DATASET_TO_STUDY_MAPPING_READY")
            .put("selectedReviewTarget", selected)
            .put("recommendedUse", use)
            .put("capsuleScore", score)
            .put("unresolvedConflictCount", conflicts)
            .put("why", "Use is capped by capsule completeness and contradiction state; no dataset is promoted without comparator, provenance, matrix/capsule, and external review.")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Dataset-to-study mapper",
        "State: ${obj.optString("state", "UNKNOWN")}; selected_review_target=${obj.optString("selectedReviewTarget", "none")}; recommended_use=${obj.optString("recommendedUse", "unknown")}",
        "Capsule score=${obj.optInt("capsuleScore", 0)}/10; unresolved_conflicts=${obj.optInt("unresolvedConflictCount", 0)}.",
        "Decision rule: discovery-only until comparator, sample provenance, capsule/matrix, and contradiction gates close.",
        "Boundary: mapping is a study-planning label, not a claim that the dataset proves biology."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "DATASET_TO_STUDY_MAPPING_READY", "DISCOVERY_ONLY_CANDIDATE", CLAIM_LIMIT))
}
