package com.immunesignal.app

import org.json.JSONObject

data class GTIMCapsuleRoutingResultV21316(
    val matrixState: GTIMMatrixStateV21316,
    val externalReviewRequired: Boolean,
    val sandboxPreviewAllowed: Boolean,
    val previewStrength: String,
    val executableCapsule: GTIMProcessedCapsuleV21316?,
    val acquisitionTask: String,
    val claimLimit: String = GTIMProcessedCapsuleV21316.CLAIM_LIMIT
) {
    fun toJson(): JSONObject = JSONObject()
        .put("matrix_state", matrixState.name)
        .put("external_review_required", externalReviewRequired)
        .put("sandbox_preview_allowed", sandboxPreviewAllowed)
        .put("preview_strength", previewStrength)
        .put("acquisition_task", acquisitionTask)
        .put("claim_limit", claimLimit)
        .put("capsule", executableCapsule?.toJson() ?: JSONObject.NULL)
}

/** Routes a report to a local processed capsule when possible. */
object GTIMCapsuleInjectionRouterV21316 {
    const val VERSION: String = "2.13.16-capsule-injection-router"

    fun route(report: JSONObject): GTIMCapsuleRoutingResultV21316 {
        val activeDomain = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val activeSubtype = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeSubtype(report)
        val canonical = GTIMFinalSurfaceDomainCoherenceGuardV21313.canonicalTarget(report)
        val accessionCapsule = if (canonical.isNotBlank()) GTIMLocalProcessedCapsuleStoreV21316.getCapsuleByAccession(canonical) else null
        val compatibleAccessionCapsule = accessionCapsule?.takeIf { it.domain == activeDomain }
        val domainCapsule = compatibleAccessionCapsule ?: GTIMLocalProcessedCapsuleStoreV21316.getBestCapsuleForDomain(activeDomain)
            ?.takeUnless { requiresSubtypeSpecificCapsule(activeDomain, activeSubtype, canonical) }

        return when {
            compatibleAccessionCapsule != null -> GTIMCapsuleRoutingResultV21316(
                matrixState = GTIMMatrixStateV21316.LOCAL_PROCESSED_CAPSULE_AVAILABLE,
                externalReviewRequired = false,
                sandboxPreviewAllowed = true,
                previewStrength = "C1_PLUS_CAPSULE_BACKED_SANDBOX_PREVIEW",
                executableCapsule = compatibleAccessionCapsule,
                acquisitionTask = "local_processed_capsule_available_for_${compatibleAccessionCapsule.accession}"
            )
            domainCapsule != null -> GTIMCapsuleRoutingResultV21316(
                matrixState = GTIMMatrixStateV21316.LOCAL_DOMAIN_CAPSULE_AVAILABLE,
                externalReviewRequired = true,
                sandboxPreviewAllowed = true,
                previewStrength = "C1_DOMAIN_CAPSULE_SANDBOX_PREVIEW",
                executableCapsule = domainCapsule,
                acquisitionTask = "domain_capsule_available; acquire_or_verify_topic_specific_dataset_anchor"
            )
            else -> GTIMCapsuleRoutingResultV21316(
                matrixState = GTIMMatrixStateV21316.CAPSULE_MISSING_ACQUISITION_TASK_CREATED,
                externalReviewRequired = true,
                sandboxPreviewAllowed = true,
                previewStrength = "C0_ROUTE_SANDBOX_PREVIEW_CAPSULE_MISSING",
                executableCapsule = null,
                acquisitionTask = "create_lightweight_processed_capsule_for_${activeDomain.ifBlank { "active_domain" }}"
            )
        }
    }

    private fun requiresSubtypeSpecificCapsule(activeDomain: String, activeSubtype: String, canonical: String): Boolean {
        if (canonical.isNotBlank()) return false
        val subtype = activeSubtype.lowercase()
        return activeDomain == "filovirus_viral_host_response" && (
            subtype.contains("bundibugyo") || subtype.contains("bdbv")
        )
    }

    fun routeJson(report: JSONObject): JSONObject = route(report).toJson().put("version", VERSION)
}
