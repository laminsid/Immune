package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Switchable immunity lens: optogenetic / logic-gated immune-cell control as research direction only. */
object GTIMSwitchableImmunityLensV21320 {
    const val VERSION: String = "2.13.20-switchable-immunity-lens"
    const val STATE_READY: String = "SWITCHABLE_IMMUNITY_RESEARCH_LENS_READY"
    const val CLAIM_LIMIT: String = "switchable_immunity_design_not_clinical_safety_proof"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("switch_axes", JSONArray(listOf("optogenetic_control", "logic_gated_CAR_control", "drug_inducible_switch", "external_signal_controlled_activity")))
        .put("safety_boundary", "switchable design hypothesis only; no 100_percent_safety claim")
        .put("clinical_safety_proof_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
