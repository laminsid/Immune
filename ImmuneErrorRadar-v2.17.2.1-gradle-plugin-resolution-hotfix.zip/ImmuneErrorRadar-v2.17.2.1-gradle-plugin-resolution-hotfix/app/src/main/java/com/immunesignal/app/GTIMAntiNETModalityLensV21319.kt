package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** DNase / anti-NET modality research lens, not a treatment recommendation. */
object GTIMAntiNETModalityLensV21319 {
    const val VERSION: String = "2.13.19-anti-net-modality-lens"
    const val CLAIM_LIMIT: String = "anti_NET_modality_lens_not_treatment_recommendation"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", "ANTI_NET_MODALITY_LENS_READY")
        .put("modalities", JSONArray(listOf("DNase_or_anti_NET_strategy", "biomarker_research", "thromboinflammation_modulation_lens")))
        .put("treatment_recommendation_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
