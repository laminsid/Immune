package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.13.1 — Expanded Disease Future Corpus.
 *
 * A lightweight offline disease-expansion layer for cancer, diabetes, cardiovascular/
 * hypertension, rheumatoid/autoimmune, and kidney metabolic-immune routes. It only
 * proposes research priors, mechanisms, gaps, and minimal study routes; it never upgrades
 * evidence or makes clinical claims.
 */
object GTIMExpandedDiseaseFutureCorpusV2131 {
    const val VERSION: String = "2.13.1-expanded-disease-future-corpus"
    const val ASSET_NAME: String = "gtim_expanded_disease_future_corpus_v2.13.1.json"
    const val CLAIM_LIMIT: String = "expanded_disease_future_corpus_prior_not_biological_proof"

    fun toJson(report: JSONObject): JSONObject {
        val text = activeTopicText(report)
        val domain = domainKey(text, report)
        val matches = matchingEntries(domain, text)
        val best = matches.optJSONObject(0) ?: fallbackEntry(domain)
        val corpus = report.optJSONObject("futureEvidenceLiteCorpusV2130") ?: JSONObject()
        val handles = mergeStrings(
            jsonStrings(best.optJSONArray("candidateHandles")),
            jsonStrings(corpus.optJSONArray("candidateHandles")),
            jsonStrings(report.optJSONObject("candidateHandleLedgerV21215")?.optJSONArray("allCandidateHandles"))
        ).filter { GTIMActiveDomainConsistencyGuardV2134.handleFitsActiveDomain(it, GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report), GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report)) }
        return JSONObject()
            .put("version", VERSION)
            .put("asset", ASSET_NAME)
            .put("state", if (matches.length() > 0) "EXPANDED_DISEASE_CORPUS_MATCH_READY" else "EXPANDED_DISEASE_CORPUS_FALLBACK_READY")
            .put("domainKey", domain)
            .put("matchedEntries", matches.length())
            .put("selectedDomain", best.optString("domain", domain))
            .put("primaryTargets", best.optJSONArray("primaryTargets") ?: JSONArray())
            .put("readouts", best.optJSONArray("readouts") ?: JSONArray())
            .put("crossDomainBridges", best.optJSONArray("crossDomainBridges") ?: JSONArray())
            .put("missingExperiments", best.optJSONArray("missingExperiments") ?: JSONArray())
            .put("highValueHypotheses", best.optJSONArray("highValueHypotheses") ?: JSONArray())
            .put("negativeControls", best.optJSONArray("negativeControls") ?: JSONArray())
            .put("candidateHandles", JSONArray(handles))
            .put("studyRouting", JSONArray(listOf("target_readout_split", "human_animal_invitro_separation", "comparator_provenance_gate", "contradiction_search", "minimum_viable_study")))
            .put("coverage", JSONArray(listOf("cancer", "diabetes", "hypertension_cardiovascular", "rheumatoid_autoimmune", "kidney_metabolic_immune")))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Expanded disease future corpus",
        "State: ${obj.optString("state", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}; selected_domain=${obj.optString("selectedDomain", "unknown")}; matched_entries=${obj.optInt("matchedEntries", 0)}.",
        "Expanded targets: ${jsonStrings(obj.optJSONArray("primaryTargets")).take(5).joinToString(", ").ifBlank { "not selected" }}.",
        "Expanded readouts: ${jsonStrings(obj.optJSONArray("readouts")).take(5).joinToString(", ").ifBlank { "not selected" }}.",
        "Use: extends the offline corpus to cancer, diabetes, cardiovascular/hypertension, rheumatoid/autoimmune, and kidney routes; no evidence upgrade."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, ASSET_NAME, "EXPANDED_DISEASE_CORPUS_MATCH_READY", "cancer", "diabetes", "hypertension", "rheumatoid", CLAIM_LIMIT))

    internal fun domainKey(text: String, report: JSONObject): String {
        val active = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        return when {
            active.contains("oncology") || active.contains("tumor") || active.contains("cancer") -> "cancer_immune_tumor_microenvironment"
            text.contains("cancer") || text.contains("tumor") || text.contains("oncology") || text.contains("carcinoma") || text.contains("melanoma") -> "cancer_immune_tumor_microenvironment"
            text.contains("diabetes") || text.contains("insulin") || text.contains("hba1c") || text.contains("glucose") || text.contains("metabolic syndrome") -> "diabetes_metabolic_inflammation"
            text.contains("hypertension") || text.contains("blood pressure") || text.contains("cardiovascular") || text.contains("heart failure") || text.contains("atherosclerosis") -> "cardiometabolic_hypertension_heart_inflammation"
            text.contains("rheumatoid") || text.contains("rheumatism") || text.contains("arthritis") || text.contains("synovial") || text.contains("autoimmune") -> "rheumatoid_autoimmune_synovial_inflammation"
            text.contains("kidney") || text.contains("ckd") || text.contains("renal") || text.contains("albuminuria") || text.contains("nephropathy") -> "chronic_kidney_metabolic_immune_axis"
            else -> "expanded_background_only_${active}"
        }
    }

    private fun activeTopicText(report: JSONObject): String = listOf(
        report.optJSONObject("topicCapture")?.optString("rawInput").orEmpty(),
        report.optJSONObject("topicCapture")?.optString("normalizedTopic").orEmpty(),
        report.optString("researchTopic"),
        report.optJSONObject("studyFocusNormalizerV21282")?.optString("studyFocus").orEmpty(),
        report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("studyFocus").orEmpty()
    ).joinToString(" ").lowercase(Locale.US)

    private fun matchingEntries(domain: String, text: String): JSONArray {
        val out = JSONArray()
        entries().forEach { e ->
            val d = e.optString("domain")
            val aliases = jsonStrings(e.optJSONArray("domainAliases"))
            if (d == domain || aliases.any { text.contains(it.lowercase(Locale.US)) }) out.put(JSONObject(e.toString()))
        }
        return out
    }

    private fun fallbackEntry(domain: String): JSONObject = JSONObject()
        .put("domain", domain)
        .put("primaryTargets", JSONArray(listOf("immune mediator module", "tissue-injury module", "metabolic/vascular context module")))
        .put("readouts", JSONArray(listOf("comparator labels", "sample provenance", "inflammatory module", "matrix/capsule availability")))
        .put("crossDomainBridges", JSONArray(listOf("disease context -> immune mediator -> tissue module -> phenotype subgroup")))
        .put("missingExperiments", JSONArray(listOf("topic-specific human capsule with comparator/sample provenance")))
        .put("highValueHypotheses", JSONArray(listOf("under-tested disease subgroup may exist if comparator and capsule gates close")))
        .put("negativeControls", JSONArray(listOf("wrong tissue/species", "missing comparator", "confounded association")))
        .put("candidateHandles", JSONArray())

    private fun entries(): List<JSONObject> = listOf(
        entry("cancer_immune_tumor_microenvironment", listOf("cancer", "tumor", "oncology", "carcinoma", "melanoma"), listOf("tumor immune microenvironment", "PD-1/PD-L1 checkpoint axis", "CTLA4/T-cell exhaustion module", "TGF-beta immune exclusion module", "myeloid/MDSC-TAM suppressive module", "neoantigen presentation/MHC module"), listOf("CD8/Treg ratio", "PD-L1/immune checkpoint expression", "IFN-gamma cytotoxic module", "TAM/MDSC markers", "MHC antigen-presentation score", "TGF-beta/stromal exclusion markers"), listOf("PMID:31930990"), listOf("tumor antigen presentation -> T-cell exhaustion -> immune escape phenotype", "myeloid suppressive niche -> checkpoint resistance -> relapse/progression subgroup", "metabolic hypoxia/lactate stress -> T-cell dysfunction -> cold tumor state"), listOf("paired tumor+immune sample capsule with responder/non-responder labels", "dataset separating immune-hot versus immune-cold tumors with treatment/exposure metadata", "contradiction check for checkpoint-high but nonresponsive subgroups"), listOf("immune-cold tumors may be driven more by myeloid/TGF-beta exclusion than by PD-L1 alone", "hypoxia-lactate immune suppression may define a resistance subgroup across solid tumors", "MHC/antigen-presentation loss may break apparent checkpoint-readiness despite high inflammatory signals"), listOf("bulk tumor inflammation without cell-type separation", "checkpoint marker without response labels", "cell-line-only evidence used as patient tumor mechanism")),
        entry("diabetes_metabolic_inflammation", listOf("diabetes", "type 2 diabetes", "t2d", "insulin resistance", "hba1c", "glucose"), listOf("insulin resistance inflammatory axis", "adipose macrophage module", "beta-cell stress/inflammation module", "IL-1beta/NLRP3 metabolic inflammation", "mitochondrial oxidative stress module", "gut-liver-adipose immune crosstalk"), listOf("HbA1c/glucose", "insulin/HOMA-IR", "CRP/IL-6/TNF", "IL-1beta/NLRP3", "adipokines/leptin/adiponectin", "mitochondrial stress markers"), emptyList(), listOf("nutrient excess -> adipose macrophage inflammation -> insulin resistance", "beta-cell stress -> IL-1beta/NLRP3 -> glycemic deterioration subgroup", "gut-liver-adipose signaling -> systemic inflammatory tone -> metabolic phenotype"), listOf("human cohort linking glycemic labels, inflammatory markers, tissue/source metadata, and transcriptome/metabolomics capsule", "subgroup study separating obesity-driven inflammation from beta-cell stress-driven diabetes"), listOf("T2D subgroups may separate into adipose-macrophage inflammatory versus beta-cell stress inflammatory phenotypes", "mitochondrial stress plus IL-1beta/NLRP3 may predict a high-inflammatory glycemic subgroup", "gut-liver-adipose immune crosstalk may explain metabolic inflammation beyond glucose level alone"), listOf("glucose-only dataset without inflammatory labels", "animal-only beta-cell model promoted as human systemic diabetes evidence", "obesity confounding not separated from glycemic phenotype")),
        entry("cardiometabolic_hypertension_heart_inflammation", listOf("hypertension", "blood pressure", "heart", "cardiovascular", "atherosclerosis"), listOf("endothelial dysfunction module", "RAAS-immune activation axis", "vascular smooth muscle inflammation", "NLRP3/IL-1beta vascular module", "oxidative stress/NO bioavailability module", "cardiac fibrosis remodeling module"), listOf("blood pressure phenotype", "CRP/IL-6/TNF", "endothelial markers", "NO/oxidative stress markers", "fibrosis markers", "vascular stiffness/progression labels"), emptyList(), listOf("RAAS activation -> endothelial immune stress -> hypertension phenotype", "vascular inflammation -> stiffness/remodeling -> cardiovascular risk subgroup", "metabolic inflammation -> endothelial dysfunction -> heart/pressure phenotype"), listOf("cohort with BP phenotype, medication context, endothelial/immune readouts, and sample provenance", "study separating vascular inflammation from obesity/diabetes confounding"), listOf("a high-inflammatory endothelial subgroup may explain resistant hypertension beyond sodium/RAAS alone", "NLRP3/IL-1beta vascular activation may define a pressure-remodeling risk subgroup", "metabolic-vascular immune bridge may unify diabetes and hypertension in a shared endothelial phenotype"), listOf("BP-only association without immune/endothelial readouts", "heart failure samples used for primary hypertension without phenotype bridge", "medication confounding not modeled")),
        entry("rheumatoid_autoimmune_synovial_inflammation", listOf("rheumatoid", "arthritis", "rheumatism", "autoimmune", "synovial"), listOf("TNF/IL-6 synovial inflammation module", "Th17/IL-17 axis", "JAK/STAT cytokine signaling", "B-cell/autoantibody module", "synovial fibroblast activation module", "macrophage pannus module"), listOf("TNF/IL-6", "IL-17/Th17 markers", "CRP/ESR", "RF/anti-CCP", "synovial fibroblast markers", "treatment response labels"), emptyList(), listOf("autoantibody context -> synovial macrophage/fibroblast activation -> joint damage phenotype", "Th17/TNF/IL-6 cytokine loop -> flare persistence -> treatment-response subgroup", "gut/oral mucosal trigger -> systemic autoimmunity -> synovial inflammation"), listOf("synovial or blood cohort with treatment response labels and cytokine/cell-type capsule", "contradiction check for TNF-high versus IL-6/JAK-dominant subgroups"), listOf("RA may split into TNF/macrophage-dominant versus IL-6/JAK/fibroblast-dominant inflammatory subgroups", "mucosal-autoimmune bridge may explain a subset of synovial inflammation but requires antibody and tissue context", "Th17/TNF/IL-6 balance may predict treatment-response mismatch"), listOf("generic inflammation without RA comparator labels", "osteoarthritis mixed with autoimmune arthritis without separation", "mucosal microbiome claim without autoantibody/synovial readout")),
        entry("chronic_kidney_metabolic_immune_axis", listOf("kidney", "ckd", "renal", "albuminuria", "nephropathy"), listOf("renal endothelial inflammation module", "fibrosis/TGF-beta module", "complement activation axis", "metabolic-uremic inflammatory tone", "podocyte/tubular stress module"), listOf("eGFR/albuminuria", "CRP/IL-6/TNF", "TGF-beta/fibrosis markers", "complement markers", "tubular injury markers"), emptyList(), listOf("metabolic inflammation -> renal endothelial/tubular stress -> CKD progression subgroup", "complement/fibrosis activation -> albuminuria progression -> cardiovascular-kidney bridge"), listOf("kidney phenotype cohort with eGFR/albuminuria plus immune/fibrosis capsule", "separation of diabetes-driven nephropathy from primary inflammatory renal disease"), listOf("immune-fibrotic CKD subgroup may be distinguishable before eGFR decline using complement/TGF-beta/tubular injury readouts", "cardio-renal inflammatory bridge may explain high-risk hypertension+CKD subgroup"), listOf("renal function-only dataset without tissue/source context", "diabetes confounding not separated", "animal fibrosis model promoted as human CKD evidence"))
    )

    private fun entry(domain: String, aliases: List<String>, targets: List<String>, readouts: List<String>, handles: List<String>, bridges: List<String>, gaps: List<String>, hypotheses: List<String>, negatives: List<String>): JSONObject = JSONObject()
        .put("domain", domain)
        .put("domainAliases", JSONArray(aliases))
        .put("primaryTargets", JSONArray(targets))
        .put("readouts", JSONArray(readouts))
        .put("candidateHandles", JSONArray(handles))
        .put("crossDomainBridges", JSONArray(bridges))
        .put("missingExperiments", JSONArray(gaps))
        .put("highValueHypotheses", JSONArray(hypotheses))
        .put("negativeControls", JSONArray(negatives))

    internal fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx -> array.optString(idx).takeIf { it.isNotBlank() } }
    private fun mergeStrings(vararg lists: List<String>): List<String> = lists.flatMap { it }.map { it.uppercase(Locale.US) }.distinct().take(16)
}
