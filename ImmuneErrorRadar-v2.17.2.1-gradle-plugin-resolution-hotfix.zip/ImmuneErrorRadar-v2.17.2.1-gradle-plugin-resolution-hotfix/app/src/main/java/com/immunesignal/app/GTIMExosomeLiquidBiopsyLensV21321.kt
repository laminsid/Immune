package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Liquid-biopsy and extracellular vesicle diagnostic hypothesis lens. */
object GTIMExosomeLiquidBiopsyLensV21321 {
    const val VERSION: String = "2.13.21-exosome-liquid-biopsy-lens"
    const val STATE_READY: String = "EXOSOME_LIQUID_BIOPSY_LENS_READY"
    const val CLAIM_LIMIT: String = "liquid_biopsy_marker_hypothesis_not_diagnosis_or_screening_recommendation"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("biomarker_axes", JSONArray(listOf("tumor_EV_signature", "immune_EV_signature", "thromboinflammatory_EV_signature", "autoimmune_EV_signature")))
        .put("diagnosis_claim_allowed", false)
        .put("screening_recommendation_allowed", false)
        .put("clinical_triage_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
