package com.immunesignal.app

// v2.11.1 — Maps harm mechanisms to reversible microbial functions.
object GTIMMicrobialCounterFunctionMapperV2111 {
    const val VERSION: String = "2.11.1-microbial-counter-function-mapper"
    const val SAFETY_BOUNDARY: String = "counter_functions_are_research_hypotheses_not_live_microbe_use_not_wet_lab_protocols"

    fun map(mechanisms: List<GTIMMicrobialDamageMechanismV2111>): List<GTIMMicrobialCounterFunctionV2111> {
        val functions = mutableListOf<GTIMMicrobialCounterFunctionV2111>()
        mechanisms.forEach { mechanism ->
            when (mechanism.mechanismId) {
                "pathogen_or_dysbiosis_dominance" -> {
                    functions += function(
                        mechanism,
                        "competitive_displacement_and_niche_reoccupation",
                        "ecological_counter_dominance",
                        "Search for functions that outcompete the harmful organism, restore missing niche occupancy, reduce toxin expression, or weaken biofilm before direct killing is considered.",
                        listOf("pathogen identity or dysbiosis pattern", "niche/context match", "biofilm or toxin marker", "negative-control commensal comparison"),
                        listOf("dominant organism absent in topic-compatible data", "counter-function increases inflammation or pathogen fitness", "biofilm/toxin marker does not change")
                    )
                    functions += function(
                        mechanism,
                        "phage_or_precision_weakening",
                        "precision_pathogen_weakening",
                        "Use phage-like or antagonist logic only as a precision research route for weakening a defined harmful bacterium, not as broad antimicrobial advice.",
                        listOf("defined target bacterium", "host-range evidence", "resistance-escape review", "polymicrobial-context review"),
                        listOf("target organism not confirmed", "polymicrobial ecology dominates", "resistance escape appears faster than benefit")
                    )
                }
                "toxin_or_exposome_burden" -> functions += function(
                    mechanism,
                    "microbial_toxin_sink_or_biotransformation",
                    "toxin_binding_degradation_or_bioavailability_reduction",
                    "Search for natural or designed microbial functions that bind, sequester, transform, or reduce bioavailability of toxins/particles without claiming detox treatment.",
                    listOf("measured toxin or particle context", "binding/biotransformation assay", "safe byproduct profile", "excretion or reduced-burden marker"),
                    listOf("no binding or transformation observed", "harmful metabolite byproduct", "no burden reduction despite exposure match")
                )
                "barrier_ecology_failure" -> functions += function(
                    mechanism,
                    "barrier_restoration_and_mucus_support",
                    "barrier_ecology_restoration",
                    "Search for microbial/metabolite functions that support mucus, epithelial integrity, tight junction context, and local tolerance.",
                    listOf("barrier marker", "mucosal or tissue context", "metabolite profile", "local immune readout"),
                    listOf("barrier markers stay damaged", "metabolite direction contradicts restoration", "local inflammation increases")
                )
                "immune_decision_error" -> functions += function(
                    mechanism,
                    "immune_tolerance_retraining",
                    "immune_decision_recalibration",
                    "Search for functions that change immune decision thresholds, tolerance, Treg/Th balance, mast-cell thresholds, or cytokine durability.",
                    listOf("immune phenotype", "tolerance or cytokine marker", "microbial/metabolite bridge", "subgroup/context stratification"),
                    listOf("no immune phenotype bridge", "suppression replaces recalibration", "tolerance marker worsens")
                )
                "neuroimmune_tissue_damage_loop" -> functions += function(
                    mechanism,
                    "peripheral_neuroimmune_signal_dampening",
                    "neuroimmune_loop_interruption",
                    "Search for microbial/metabolite or barrier functions that reduce peripheral inflammatory input into neuroimmune/tissue-damage loops.",
                    listOf("neuroimmune marker", "peripheral inflammatory marker", "barrier/metabolite bridge", "longitudinal directionality"),
                    listOf("neuroimmune marker independent from peripheral route", "barrier/metabolite route absent", "candidate signal is only symptom correlation")
                )
                "metabolic_conversion_gap" -> functions += function(
                    mechanism,
                    "missing_metabolite_or_conversion_restoration",
                    "host_microbe_metabolite_rebalancing",
                    "Search for missing or maladaptive microbial conversions such as SCFA, bile-acid, lactate, lipid, or energy-context functions.",
                    listOf("metabolite panel", "host immune-energy marker", "microbial function annotation", "comparator group"),
                    listOf("metabolite gap absent", "conversion exists but immune phenotype unchanged", "diet/context fully explains signal")
                )
                else -> functions += function(
                    mechanism,
                    "open_counter_function_discovery",
                    "open_microbial_reversal_search",
                    "Search function-first: what biological function would need to be reversed, restored, neutralized, or buffered if this damage mechanism is real?",
                    listOf("mechanism definition", "minimum contextual evidence", "counter-function candidate", "falsification test"),
                    listOf("no coherent damage mechanism", "no measurable counter-function", "no safety boundary can be defined")
                )
            }
        }

        val needsEngineeredSensor = mechanisms.any { it.damageClass.contains("toxin", true) || it.damageClass.contains("open", true) || it.damageClass.contains("neuroimmune", true) }
        if (needsEngineeredSensor) {
            val anchor = mechanisms.first()
            functions += function(
                anchor,
                "engineered_living_sensor_actor_research_route",
                "synthetic_biology_long_horizon",
                "Long-horizon route: a bounded living sensor/actor could theoretically detect a disease microenvironment and execute a local counter-function, but only as a design-study hypothesis with containment requirements.",
                listOf("sensor input definition", "actuator output definition", "biocontainment concept", "off-switch/fail-safe evidence", "no horizontal-transfer risk review"),
                listOf("signal is not specific", "actuator output is systemically risky", "containment or clearance cannot be demonstrated")
            )
        }
        return functions.distinctBy { it.functionId }.take(10)
    }

    private fun function(
        mechanism: GTIMMicrobialDamageMechanismV2111,
        id: String,
        klass: String,
        logic: String,
        required: List<String>,
        falsify: List<String>
    ): GTIMMicrobialCounterFunctionV2111 {
        val line = "Microbial counter-function: version=$VERSION | id=$id | mechanism=${mechanism.mechanismId} | class=$klass | reversal_logic=${logic.oneLine()} | required=${required.joinToString(";").oneLine()} | falsify=${falsify.joinToString(";").oneLine()} | boundary=$SAFETY_BOUNDARY"
        return GTIMMicrobialCounterFunctionV2111(id, mechanism.mechanismId, klass, logic, required, falsify, SAFETY_BOUNDARY, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
