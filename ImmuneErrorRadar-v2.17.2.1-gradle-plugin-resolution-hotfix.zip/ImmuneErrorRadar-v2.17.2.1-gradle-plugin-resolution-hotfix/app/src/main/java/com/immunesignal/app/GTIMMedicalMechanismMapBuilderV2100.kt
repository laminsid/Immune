package com.immunesignal.app

// legacy_v2100_audit_marker: 2.10.0-medical-research-dossier

/** v2.10.0 — Immune/genetic mechanism map builder. */
object GTIMMedicalMechanismMapBuilderV2100 {
    const val VERSION: String = "2.10.0-medical-mechanism-map-builder"

    fun build(contract: GTIMRunDecisionContractV2740): List<GTIMMechanismAxisCardV2100> {
        val anchor = contract.primaryAnchor.routeId.lowercase()
        val axes = when {
            anchor.contains("cancer") -> listOf(
                axis("MECH_ONCO_DNA_REPAIR", "DNA repair/MMR/MSI/TMB context -> mutation/neoantigen burden -> immune visibility hypothesis", "BIOMARKER_REQUIRED", listOf("MSI-H/dMMR/TMB/MMR", "tumor type", "clinical context", "independent source")),
                axis("MECH_ONCO_TME_ESCAPE", "tumor microenvironment -> antigen presentation/checkpoint/exclusion -> immune escape or response route", "CONTEXT_REQUIRED", listOf("immune infiltrate", "PD-1/PD-L1/CTLA-4 context", "antigen presentation markers", "comparator")),
                axis("MECH_ONCO_CELL_CYCLE_APOPTOSIS", "DNA damage + cell-cycle arrest + mitotic stress -> apoptosis/failed division -> possible immune-visibility interaction", "HYPOTHESIS_ONLY_UNTIL_TESTED", listOf("model system", "cell-cycle marker", "apoptosis marker", "immune-readout", "safety context"))
            )
            anchor.contains("ibd") || anchor.contains("mucosal") || anchor.contains("microbiome") -> listOf(
                axis("MECH_GUT_BARRIER", "diet/microbiome exposure -> barrier function -> mucosal cytokines -> immune activation or tolerance", "PLAUSIBLE_REQUIRES_HUMAN_CONTEXT", listOf("diet/exposure definition", "microbiome data", "barrier marker", "case/control metadata")),
                axis("MECH_SCFA_BUTYRATE", "fiber fermentation -> SCFA/butyrate -> epithelial energy/barrier modulation -> inflammatory tone", "PLAUSIBLE_REQUIRES_DIRECT_EVIDENCE", listOf("fiber intake", "SCFA/butyrate measure", "inflammation marker", "outcome"))
            )
            anchor.contains("covid") || anchor.contains("viral") || anchor.contains("ebola") || anchor.contains("hantavirus") -> listOf(
                axis("MECH_VIRAL_INNATE", "virus/host interaction -> interferon and innate immune response -> cytokine/tissue injury balance", "HOST_RESPONSE_CONTEXT_REQUIRED", listOf("pathogen identity", "sample tissue", "timepoint", "case/control", "biosafety boundary")),
                axis("MECH_VIRAL_ESCAPE", "viral immune evasion or dysregulated host response -> persistent inflammation or tissue damage route", "HYPOTHESIS_ONLY_UNTIL_DATASET_VALIDATED", listOf("variant/strain", "host-response data", "time course", "contradiction search"))
            )
            anchor.contains("diabetes") || anchor.contains("metabolic") || anchor.contains("insulin") -> listOf(
                axis("MECH_METABOLIC_INFLAMMATION", "metabolic stress -> adipose/liver/gut immune activation -> insulin-resistance inflammatory route", "PLAUSIBLE_REQUIRES_COHORT_CONTEXT", listOf("phenotype", "tissue", "metabolic markers", "comparator", "medication context")),
                axis("MECH_GUT_METABOLIC", "gut microbiome/barrier -> endotoxin or metabolite signaling -> metabolic inflammation hypothesis", "EXPLORATORY", listOf("microbiome/metabolite data", "diet context", "case/control", "time order"))
            )
            else -> listOf(
                axis("MECH_GENERAL_IMMUNE_GENETIC", "topic anchor -> immune/genetic pathway -> comparator-backed evidence -> translational hypothesis", "DISCOVERY_ONLY", listOf("topic-compatible target", "metadata", "comparator", "dataset or literature evidence"))
            )
        }
        return axes.take(6)
    }

    private fun axis(id: String, chain: String, support: String, required: List<String>): GTIMMechanismAxisCardV2100 {
        val line = "Mechanism map: id=$id | support=$support | chain=${chain.oneLine()} | required=${required.joinToString(", ")}"
        return GTIMMechanismAxisCardV2100(id, chain, support, required, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
