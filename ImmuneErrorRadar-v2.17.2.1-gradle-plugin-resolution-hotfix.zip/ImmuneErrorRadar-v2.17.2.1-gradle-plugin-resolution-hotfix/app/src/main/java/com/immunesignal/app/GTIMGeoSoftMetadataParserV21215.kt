package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.12.15 — Small SOFT metadata parser for background probes. */
object GTIMGeoSoftMetadataParserV21215 {
    const val VERSION: String = "2.12.15-geo-soft-metadata-parser"
    const val CLAIM_LIMIT: String = "soft_metadata_parse_readiness_only_no_evidence_upgrade"

    fun parse(handle: String, softText: String): JSONObject {
        val clean = softText.take(500_000)
        val sampleIds = regexValues(clean, "(?m)^!Sample_geo_accession\\s*=\\s*(GSM\\d+)").take(24)
        val titles = regexValues(clean, "(?m)^!Sample_title\\s*=\\s*(.+)").take(12)
        val sources = regexValues(clean, "(?m)^!Sample_source_name_ch1\\s*=\\s*(.+)").take(12)
        val organisms = regexValues(clean, "(?m)^!Sample_organism_ch1\\s*=\\s*(.+)").take(8)
        val characteristics = regexValues(clean, "(?m)^!Sample_characteristics_ch1\\s*=\\s*(.+)").take(24)
        val platforms = regexValues(clean, "(?m)^!Sample_platform_id\\s*=\\s*(GPL\\d+)").take(8)
        val comparatorTerms = listOf("control", "case", "healthy", "patient", "disease", "severity", "severe", "mild", "recovered", "treated", "untreated")
        val comparatorFound = (titles + sources + characteristics).any { line -> comparatorTerms.any { line.contains(it, true) } }
        val tissueFound = sources.isNotEmpty() || characteristics.any { it.contains("tissue", true) || it.contains("blood", true) || it.contains("PBMC", true) || it.contains("brain", true) }
        val provenanceFound = sampleIds.isNotEmpty() && (sources.isNotEmpty() || titles.isNotEmpty())
        val matrixHint = when {
            clean.contains("!series_matrix_table_begin", true) -> "series_matrix_table_observed"
            clean.contains("supplementary_file", true) || clean.contains("!Series_supplementary_file", true) -> "supplementary_file_hint_observed"
            sampleIds.isNotEmpty() -> "soft_sample_metadata_observed_processed_capsule_still_required"
            else -> "no_matrix_or_capsule_hint_observed"
        }
        val readiness = when {
            comparatorFound && tissueFound && provenanceFound -> "METADATA_READY_FOR_REVIEW_ONLY_CAPSULE_CHECK"
            sampleIds.isNotEmpty() -> "METADATA_PARTIAL_SAMPLE_LIST_FOUND"
            else -> "METADATA_NOT_INFORMATIVE"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("handle", handle)
            .put("softProbeState", readiness)
            .put("sampleCount", sampleIds.size)
            .put("sampleAccessionsPreview", JSONArray(sampleIds))
            .put("sampleTitlesPreview", JSONArray(titles))
            .put("sourceNamesPreview", JSONArray(sources))
            .put("organisms", JSONArray(organisms.distinct()))
            .put("characteristicsPreview", JSONArray(characteristics))
            .put("platforms", JSONArray(platforms.distinct()))
            .put("comparatorLabelsStatus", if (comparatorFound) "found_or_inferred_from_sample_labels" else "missing_or_not_observed")
            .put("tissueSpeciesStatus", if (tissueFound || organisms.isNotEmpty()) "found_or_partially_observed" else "missing_or_not_observed")
            .put("sampleProvenanceStatus", if (provenanceFound) "found_sample_to_source_preview" else "missing_or_not_observed")
            .put("matrixOrCapsuleHint", matrixHint)
            .put("claimLimit", CLAIM_LIMIT)
    }

    private fun regexValues(text: String, pattern: String): List<String> = Regex(pattern, RegexOption.IGNORE_CASE)
        .findAll(text)
        .map { it.groupValues.getOrNull(1).orEmpty().trim() }
        .filter { it.isNotBlank() }
        .distinct()
        .toList()
}
