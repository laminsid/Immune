// legacy_v2137_audit_marker: ACTIVE_ENGINE_VERSION = "v2.13.7-final-innovation-discovery-synthesis-unified"
// legacy_v2100_audit_token: v2.10.0-medical-research-dossier-button-only-ui
// legacy_audit_version_token_v1110: ACTIVE_ENGINE_VERSION = "v1.11.0-alpha-research-grade-mechanism-dossier"
// legacy_audit_version_token_v11055: ACTIVE_ENGINE_VERSION = "v1.10.55-alpha-ci-fast-gate-route-surface-unification"
// legacy_audit_version_token_v11051: ACTIVE_ENGINE_VERSION = "v1.10.51-alpha-route-reconciliation-evidence-candidate-activation"
// legacy_audit_version_token_v11052: ACTIVE_ENGINE_VERSION = "v1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox"
// legacy_audit_version_token_v11053: ACTIVE_ENGINE_VERSION = "v1.10.53-alpha-ci-route-linkage-hardening"
// legacy_audit_version_token_v11054: ACTIVE_ENGINE_VERSION = "v1.10.54-alpha-github-ci-runtime-surface-hardening"
package com.immunesignal.app

// legacy_audit_token_v11048: ACTIVE_ENGINE_VERSION = "v1.10.48-alpha-relaxed-progression-context-alignment"

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.4.5: learning memory, ML-safe triage, query feedback, freshness weighting, route-fit gate, and score separation.
 *
 * Earlier versions could write a correct pivot in the report without proving
 * that the next run actually executed the forced evidence path. This object is
 * intentionally small and explicit: it records which engine is active, which
 * modules are on, which research state was forced, which queries were actually
 * executed, and whether the execution lock passed.
 */
data class ActiveResearchEngineStatus(
    val engineVersion: String,
    val activeModules: List<String>,
    val researchState: String,
    val appliedPivotType: String,
    val effectiveMaxQueries: Int,
    val effectiveResultsPerQuery: Int,
    val runtimeFailoverApplied: Boolean,
    val forcedQueries: List<String>,
    val executedQueryIds: List<String>
)

data class ExecutionLockReport(
    val status: String,
    val failures: List<String>,
    val enforcedActions: List<String>
)

object EngineRuntimeStatus {
    // legacy_audit_version_token_v195: v1.9.5-alpha-ui-guarded-maintenance
    // legacy_audit_version_token_v11024: v1.10.24-alpha-abstract-accession-harvest
    // legacy_audit_version_token_v11027: v1.10.27-alpha-dataset-path-linkage-guard
    // legacy_audit_version_token_v11029: v1.10.29-alpha-learning-domain-path-linkage
    // legacy_audit_version_token_v11034: v1.10.34-alpha-useful-learning-report
    // legacy_audit_version_token_v11041: v1.10.41-alpha-biomedical-research-ontology
    // legacy_audit_version_token_v11042: v1.10.42-alpha-biomedical-concept-bridge
    // active_module_token_v11043: ModernMedicalTechnologyIntelligence
    // active_module_token_v11044: ViralCountermeasureIntelligence + BiomedicalKnowledgeGraphLinker
    // legacy_audit_version_token_v11043: ACTIVE_ENGINE_VERSION = "v1.10.43-alpha-modern-medtech-modular-index"
    // legacy_audit_version_token_v11044: ACTIVE_ENGINE_VERSION = "v1.10.44-alpha-viral-countermeasure-knowledge-graph"
    // active_compile_scope_guard_v11045: BiomedicalResearchOntology compile-scope linkage guard
    // legacy_audit_version_token_v11045: ACTIVE_ENGINE_VERSION = "v1.10.45-alpha-compile-scope-linkage-guard"
    // active_longevity_biological_systems_graph_v11046: LongevityBiologicalSystemsGraph + HealthAdviceClaimGuard
    // legacy_audit_version_token_v11046: ACTIVE_ENGINE_VERSION = "v1.10.46-alpha-longevity-biological-systems-graph"
    // legacy_audit_version_token_v11047: ACTIVE_ENGINE_VERSION = "v1.10.47-alpha-topic-fit-metadata-parse-ui-clarity"
    // active_relaxed_progression_context_alignment_v11048: Relaxed progression for metadata/context lookup; no claim relaxation
    // active_topic_route_correction_evidence_object_candidate_v11049: Topic route correction + comparator hunt + EvidenceObjectCandidate
    // legacy_audit_version_token_v11049: ACTIVE_ENGINE_VERSION = "v1.10.49-alpha-topic-route-correction-evidence-object-candidate"
    // active_environmental_psychophysiological_exposome_lane_v11050: Environmental/psychophysiological exposure routing + exposome guard
    // legacy_audit_version_token_v11050: ACTIVE_ENGINE_VERSION = "v1.10.50-alpha-environmental-psychophysiological-exposome-lane"
    // legacy_audit_version_token_v263: ACTIVE_ENGINE_VERSION = "v2.7.3-final-proof-benchmark-learning-locked"
    // legacy_v2101_audit_marker: ACTIVE_ENGINE_VERSION = "v2.10.1-medical-study-structure-dossier-button-only-ui"
    // legacy_v2104_audit_marker: ACTIVE_ENGINE_VERSION = "v2.10.4-relaxed-exploration-dossier-button-only-ui"
    // legacy_v2105_audit_marker: ACTIVE_ENGINE_VERSION = "v2.10.5-free-hypothesis-synthesis-dossier-button-only-ui"
    // legacy_v2106_audit_marker: ACTIVE_ENGINE_VERSION = "v2.10.6-hypothesis-learning-ledger-dossier-button-only-ui"
    // legacy_v2107_audit_marker: ACTIVE_ENGINE_VERSION = "v2.10.7-latent-axis-filter-dossier-button-only-ui"
    // legacy_v2108_audit_marker: ACTIVE_ENGINE_VERSION = "v2.10.8-root-cause-eco-immune-engine-button-only-ui"
    // legacy_v2109_audit_marker: ACTIVE_ENGINE_VERSION = "v2.10.9-ci-hardening-root-cause-integration-button-only-ui"
    // legacy_v2110_audit_marker: ACTIVE_ENGINE_VERSION = "v2.11.0-data-harmonization-soft-guard-root-cause-button-only-ui"
    // legacy_v21212_audit_marker: ACTIVE_ENGINE_VERSION = "v2.12.12-final-terminal-discovery-continuation-unified"
    // legacy_v21213_audit_marker: ACTIVE_ENGINE_VERSION = "v2.12.13-final-pharma-grade-strict-discovery-unified"
    // legacy_v21214_audit_marker: ACTIVE_ENGINE_VERSION = "v2.12.14-final-professional-research-release-unified"
    // legacy_v21215_audit_marker: ACTIVE_ENGINE_VERSION = "v2.12.15-final-background-metadata-consistency-unified"
    // legacy_v2131_compat_marker: versionName = "2.12.16-final-injected-metadata-execution-unified"
// legacy_v2131_compat_marker: versionName = "2.12.17-final-search-stability-resume-unified"
// legacy_v2131_compat_marker: versionName = "2.12.18-final-ten-ten-research-engine-unified"
// legacy_v2131_compat_marker: versionName = "2.12.19-final-release-lock-validated"
    // legacy_v2130_audit_marker: ACTIVE_ENGINE_VERSION = "v2.13.0-final-future-evidence-lite-corpus-unified"
        // legacy_v21219_audit_marker: ACTIVE_ENGINE_VERSION = "v2.12.19-final-release-lock-validated"
    // legacy_v2131_audit_marker: ACTIVE_ENGINE_VERSION = "v2.13.1-final-expanded-disease-corpus-unified"
    // legacy_v2132_audit_marker: ACTIVE_ENGINE_VERSION = "v2.13.2-final-verified-data-closure-unified"
    // legacy_v2133_final_unified_marker: ACTIVE_ENGINE_VERSION = "v2.13.3-final-test-ready-data-closure-unified"
    const val ACTIVE_ENGINE_VERSION = "v2.13.15-final-hypothesis-first-discovery-unified"

    val ACTIVE_MODULES = RuntimeModuleRegistry.activeModuleIds

    private val legacyActiveModules = listOf(
        "SmartReportIntegrityLock",
        "ScopeDisciplineLock",
        "AutonomousStagnationEngine",
        "EvidenceLearningOS",
        "DatasetAccessionResolver",
        "AccessionAcquisitionHardening",
        "ExtendedThinkingBudgetPolicy",
        "ExtendedAcquisitionSweepPolicy",
        "AutonomousExplorationSandboxPolicy",
        "SourcePriorityArbitrationPolicy",
        "DomainExpertiseMemoryPolicy",
        "AccessionMiningIntensityPolicy",
        "AccessionTextHarvestPolicy",
        "DataAvailabilityAccessionQueryPolicy",
        "MatureDomainEvidenceProbePolicy",
        "DatasetForagingPathLinkageGuard",
        "DatasetPassCoverageLinkageGuard",
        "LearningDomainPathLinkageGuard",
        "ReleaseVersionLinkageGuard",
        "EvidenceLeadAndManualSeedPolicy",
        "EvidenceLeadPathLinkageGuard",
        "LeadObjectLedger",
        "MatureDomainFocusModePolicy",
        "DomainSpecificKillCriteriaGuard",
        "KnowledgeGapQueue",
        "StrongRouteFingerprintGuard",
        "LeanAgentRuntimePolicy",
        "UsefulLearningReportPolicy",
        "TopicMemoryLedger",
        "LeadInspectionQueue",
        "ThreeLayerUsefulReport",
        "LearningRulesUiSummary",
        "LearningRulesAuditMonitor",
        "EBVLeadVerificationPolicy",
        "ImmuneEvidencePriorMatrix",
        "EvidencePriorSelector",
        "NoRandomContextInjectionGuard",
        "DrugAndNaturalCompoundClaimGuard",
        "IntegratedPathLinkageGuard",
        "FinalPathReleaseGate",
        "FinalReleaseStabilityGuard",
        "BiomedicalResearchOntology",
        "DiagnosticPhenotypeVocabulary",
        "BiomedicalConceptBridge",
        "ReleaseContinuityAuditGuard",
        "LaneCooldown",
        "ExecutionWiringGuard",
        "RuntimeDatasetHuntFailover",
        "DirectDatasetSourceRouter",
        "DatasetFirstForager",
        "PersistentFailureMemory",
        "HypothesisDecomposer",
        "MultiPassEvidenceLoop",
        "DatasetParser",
        "OutcomeLabelDetector",
        "ControlGroupDetector",
        "ContrastiveEvidenceGate",
        "CumulativeEvidenceScorer",
        "EvidenceHypergraphLite",
        "ResearchRouteAudit",
        "ActionableNextEvidence",
        "RouteFitGate",
        "ScoreSeparation",
        "FailurePatternLedger",
        "QueryFeedbackPlanner",
        "DatasetTriageEngine",
        "MLDatasetTriageEngine",
        "FailurePredictionModel",
        "RouteEmbeddingScorer",
        "EvidenceFreshnessScorer",
        "FoundationKnowledgeLayer",
        "AxisRankingEngine",
        "FoundationConflictResolver",
        "FoundationKnowledgeAccuracyLedger",
        "FoundationPatchSuggestionLedger",
        "LearningSessionManager",
        "PhaseExecutor",
        "ProgressTracker",
        "QuestionEvolver",
        "SessionMetrics",
        "RuntimeFeatureFlags",
        "LearningSessionIntegrityGuard",
        "SessionHistoryPersistence",
        "LearningSessionOutcomeBridge",
        "SessionHandoff",
        "CandidateActionResolver",
        "MinimumMetadataParser",
        "AutoContinuationTrigger",
        "ReportConsistencyGuard",
        "SpecializedReasoningEngine",
        "HypothesisFalsificationPressure",
        "NextDecisiveTestSelector",
        "GeneralModelFailureGuard",
        "CumulativeKnowledgeMapEngine",
        "KnowledgeMapReport",
        "EpistemicBeliefEngine",
        "EpistemicBeliefReport",
        "BeliefTransitionSummary",
        "BeliefAbandonmentQuestion",
        "UnusedWeakBeliefPruner",
        "MutableBeliefRevision",
        "MapGapTracker",
        "MapCarryForward",
        "EvidenceGapMatrix",
        "HypothesisTournament",
        "ReasoningAuditProtocol",
        "NextCycleProtocol",
        "CognitivePathIntegrationEngine",
        "CognitivePathIntegrationReport",
        "CognitiveNextCycleBridge",
        "CognitiveNextCycleDirective",
        "CognitiveLoopSingleUseGuard",
        "QueryInflationGuard",
        "CognitiveLoopCalibrationEngine",
        "DirectiveOutcomeCalibration",
        "IntegratedNextAction",
        "DirectiveLifecycleEngine",
        "DirectiveLifecycleReport",
        "EvidenceGainQueryRanker",
        "BeliefFalsificationContractEngine",
        "BeliefFalsificationContractReport",
        "MemoryConsolidationEngine",
        "CausalReadinessGate",
        "ReflectionLessonEngine",
        "MiniPeerReviewGate",
        "ReportSimplificationLayer",
        "ActionableCognitiveControlV171",
        "DirectiveControlContextEnricher",
        "WeightedDiscoveryIntelligenceV182",
        "ScientificKnowledgeIndexEngine",
        "ScientificTermIndexV181",
        "KnowledgeRoutedDiscoveryControlV181",
        "MechanismHypothesisEngine",
        "MechanismTournamentEngine",
        "DecisiveExperimentPlanner",
        "NoveltyAndNonObviousnessScorer",
        "DeepContradictionMiner",
        "CrossAxisBridgeReasoner",
        "DeepThinkSessionEngine",
        "DeepDiscoveryReasonerV180",
        "ScientificDiscoveryWeightEngine",
        "ScientificDiscoveryDecisionEngineV183",
        "ScientificDiscoveryDecisionMemoryV183",
        "ScientificDiscoveryStressTestEngineV184",
        "CounterfactualDiscoveryStressTestV184",
        "ScientificDiscoveryExecutionPolicyEngineV185",
        "PolicyEnforcedDiscoveryControlV185",
        "ScientificDiscoveryOutcomeVerifierEngineV186",
        "OutcomeVerificationDiscoveryMemoryV186",
        "ScientificDiscoveryLineageEngineV187",
        "HypothesisLineageDiscoveryGraphV187",
        "ScientificDiscoveryGapMinerEngineV188",
        "LatentDiscoveryGapMinerV188",
        "ScientificDiscoveryProbePlannerEngineV189",
        "ExecutableDiscoveryProbePlanV189",
        "ScientificDiscoveryProbeOutcomeLedgerEngineV190",
        "ProbeOutcomeLearningLedgerV190",
        "ScientificDiscoveryMetaStrategyGovernorEngineV191",
        "MetaStrategyGovernorV191",
        "ScientificDiscoveryQualityGateEngineV192",
        "DiscoveryQualityGateV192",
        "ExecutableQualityRunbookV193",
        "EvidenceClosureEngine",
        "AccessionClosureCard",
        "PostSearchThinkingEngine",
        "ThinkingContinuityEngine",
        "AutonomousThoughtPulseEngine",
        "HypothesisGraphCognitionV198",
        "CognitiveMomentumEngineV199",
        "LinkedCognitionSpineEngineV200",
        "RuntimeHardeningV1101",
        "RuntimeHardeningV1102",
        "NcbiClientOkHttp",
        "NcbiRateLimiter",
        "SecureNcbiCredentialStore",
        "AxisMatcherWordBoundary",
        "CognitionPathOrchestrator",
        "ProgressAuditGate",
        "OfflineThoughtLedger",
        "OfflineHypothesisLinker",
        "TopicFitMetadataParseUiClarityV11047",
        "RelaxedProgressionContextAlignmentV11048",
        "TopicFitDominanceGate",
        "LearningDiscoverySeparationCard",
        "TopicRouteCorrectionV11049",
        "ComparatorHuntModeV11049",
        "EvidenceObjectCandidateV11049",
        "EnvironmentalPsychophysiologicalExposomeLaneV11050",
        "ExposomeToLabMapperV11050",
        "RouteReconciliationEvidenceCandidateV11051",
        "OpenExplorationMedicalIndexV11052",
        "DiagnosticReasoningSandboxV11052",
        "DynamicRouteNodeOpenerV11052",
        "SugarSaltMetabolicElectrolyteLaneV11052",
        "MedicalTermSummaryIndexV11052",
        "RouteLinkageHardeningV11053",
        "GithubCiRuntimeSurfaceHardeningV11054",
        "CiFastGateRouteSurfaceUnificationV11055",
        "MetadataClosureStrategyMatrixV11057",
        "MinimumMetadataProbeV11056",
        "StrategyMatrixQueryStreamsV11056",
        "MetadataClosureStrategyMatrixV11058",
        "HyperDriveHardDataExtractionV11058",
        "MultiDimensionalAccessionSearchStreamV11058",
        "GithubCiRouteAuditUnificationV11060",
        "SourceMetadataEnrichmentV1113",
        "AccessionValidationGateV1113",
        "MatrixReadinessScoreV1113",
        "AccessionValidationComparatorExtractionV1114",
        "ComparatorExtractionCardV1114",
        "EvidenceObjectCreationGateV1114"
    )

    fun stateFor(appliedPivot: PivotDecision, stagnationActive: Boolean): String {
        val pivotText = (appliedPivot.pivotType + " " + appliedPivot.nextIntent + " " + appliedPivot.nextQuerySeed).lowercase()
        return when {
            pivotText.contains("dataset") || pivotText.contains("accession") -> "DATASET_HUNT"
            pivotText.contains("contradiction") || pivotText.contains("negative control") -> "CONTRADICTION_HUNT"
            stagnationActive -> "STAGNATION_RECOVERY"
            appliedPivot.pivotType != "NO_PIVOT" -> "FORCED_EVIDENCE_PATH"
            else -> "RESEARCH_NORMAL"
        }
    }

    fun enforceQueryBudget(
        baseLimits: ResearchRunLimits,
        appliedPivot: PivotDecision,
        stagnationPlan: AutonomousStagnationEngine.StagnationPlan
    ): Pair<Int, Int> {
        val forced = appliedPivot.pivotType != "NO_PIVOT" || stagnationPlan.active
        val maxQueries = maxOf(baseLimits.maxQueries, stagnationPlan.effectiveMaxQueries, if (forced) 6 else baseLimits.maxQueries)
        val retMax = maxOf(baseLimits.maxResultsPerQuery, stagnationPlan.effectiveResultsPerQuery, if (forced) 20 else baseLimits.maxResultsPerQuery)
        return maxQueries to retMax
    }

    fun hardStagnationTriggered(newFindingsCount: Int, repeatedSkipped: Int, datasetCandidateCount: Int): Boolean {
        return newFindingsCount <= 0 && repeatedSkipped >= 10 && datasetCandidateCount <= 0
    }

    fun runtimeFailoverPivot(repeatedSkipped: Int): PivotDecision {
        return ScopeDisciplineLock.sanitizePivot(
            PivotDecision(
                pivotType = "RUNTIME_STAGNATION_DATASET_HUNT",
                reason = "Hard stagnation triggered during this run: no fresh useful sources, repeated skipped=$repeatedSkipped, and no dataset candidate. Execute dataset/accession hunt now instead of only writing a future pivot.",
                nextIntent = "runtime_dataset_hunt",
                nextQuerySeed = "GSE OR GEO OR SDY OR ImmPort OR PRJNA OR SRP RNA-seq single-cell immune response outcome severity longitudinal negative control",
                priority = 99
            )
        )
    }

    fun buildExecutionLock(
        runtimeStatus: ActiveResearchEngineStatus,
        learningOsReport: LearningOsReport,
        hardStagnationObserved: Boolean,
        datasetForagingReport: DatasetForagingReport = DatasetForagingReport.empty()
    ): ExecutionLockReport {
        val failures = mutableListOf<String>()
        val enforced = mutableListOf<String>()

        if (runtimeStatus.engineVersion != ACTIVE_ENGINE_VERSION) {
            failures += "Active engine version mismatch."
        }
        if (runtimeStatus.activeModules.toSet().containsAll(ACTIVE_MODULES).not()) {
            failures += "Not all dataset-first execution modules are active."
        }

        if (runtimeStatus.appliedPivotType != "NO_PIVOT") {
            if (runtimeStatus.forcedQueries.isEmpty()) failures += "Forced pivot exists but no forced queries were generated."
            if (runtimeStatus.executedQueryIds.none { it.startsWith("q_pivot_") || it.startsWith("q_antistag_") || it.startsWith("q_runtime_") || it.startsWith("q_v140_") || it.startsWith("q_v142_") || it.startsWith("q_v196_") || it.startsWith("q_v197_") || it.startsWith("q_v199_") || it.startsWith("q_v200_") || it.startsWith("q_v201_") || it.startsWith("q_v11015_") || it.startsWith("q_v11018_") || it.startsWith("q_v11025_") }) {
                failures += "Forced pivot exists but no forced query id was executed."
            }
            enforced += "Forced evidence path executed for ${runtimeStatus.appliedPivotType}."
        }

        if (datasetForagingReport.active) {
            enforced += "Dataset-first forager executed: ${datasetForagingReport.sourceFamiliesAttempted.joinToString(", ")}."
            if (datasetForagingReport.sourceFamiliesAttempted.isEmpty()) failures += "Dataset-first forager was active but no source family was attempted."
            if (datasetForagingReport.passes.isEmpty()) failures += "Dataset-first forager was active but no acquisition pass was recorded."
        }

        if (runtimeStatus.researchState == "DATASET_HUNT" && !datasetForagingReport.active) {
            failures += "Research state is DATASET_HUNT but dataset-first forager did not run."
        }

        if (hardStagnationObserved) {
            val causes = learningOsReport.incident.rootCauses
            if (causes.isEmpty()) failures += "Hard stagnation observed but no root cause was recorded."
            if (learningOsReport.preventiveGates.isEmpty()) failures += "Hard stagnation observed but no preventive gate was created."
            if (learningOsReport.regressionVectors.isEmpty()) failures += "Hard stagnation observed but no regression vector was created."
            if (learningOsReport.laneCooldowns.isEmpty()) failures += "Hard stagnation observed but no lane cooldown was created."
            enforced += "Hard stagnation converted to incident, gate, regression vector, and cooldown."
        }

        if (runtimeStatus.runtimeFailoverApplied) {
            enforced += "Runtime dataset hunt failover executed inside the same cycle."
        }

        return ExecutionLockReport(
            status = if (failures.isEmpty()) "PASS" else "FAIL",
            failures = failures,
            enforcedActions = enforced.ifEmpty { listOf("Normal research cycle; no forced execution needed.") }
        )
    }

    fun runtimeStatusToJson(item: ActiveResearchEngineStatus): JSONObject = JSONObject()
        .put("engineVersion", item.engineVersion)
        .put("activeModules", JSONArray(item.activeModules))
        .put("researchState", item.researchState)
        .put("appliedPivotType", item.appliedPivotType)
        .put("effectiveMaxQueries", item.effectiveMaxQueries)
        .put("effectiveResultsPerQuery", item.effectiveResultsPerQuery)
        .put("runtimeFailoverApplied", item.runtimeFailoverApplied)
        .put("forcedQueries", JSONArray(item.forcedQueries))
        .put("executedQueryIds", JSONArray(item.executedQueryIds))

    fun executionLockToJson(item: ExecutionLockReport): JSONObject = JSONObject()
        .put("status", item.status)
        .put("failures", JSONArray(item.failures))
        .put("enforcedActions", JSONArray(item.enforcedActions))
}
