package com.immunesignal.app

import java.util.Locale

/**
 * v2.9.4 — Single-token disease intent stabilization.
 *
 * A one-word disease query such as "Ebola" or "Diabetes" is a valid research
 * intent even when pathway/comparator/assay are missing. This resolver fills the
 * intent shell only. It never upgrades evidence, never closes ETL/DGE gates, and
 * never creates treatment, dosing, efficacy, diagnosis, or clinical-management claims.
 */
data class GTIMSingleTokenDiseaseIntentExpansionV2940(
    val active: Boolean,
    val state: String,
    val disease: List<String>,
    val trigger: List<String>,
    val pathway: List<String>,
    val cell: List<String>,
    val assay: List<String>,
    val comparator: List<String>,
    val claimLimit: String = GTIMSingleTokenDiseaseIntentResolverV2940.CLAIM_LIMIT
)

object GTIMSingleTokenDiseaseIntentResolverV2940 {
    const val VERSION: String = "2.9.4-single-token-disease-intent-stabilization"
    const val CLAIM_LIMIT: String = "single_token_intent_only_not_evidence_not_dge_ready"

    fun expand(text: String): GTIMSingleTokenDiseaseIntentExpansionV2940 {
        val normalized = normalize(text)
        if (normalized.isBlank()) return empty("NO_TEXT")
        return when {
            matchesAny(normalized, "ebola", "evd", "ebolavirus", "filovirus") -> GTIMSingleTokenDiseaseIntentExpansionV2940(
                active = true,
                state = "SINGLE_TOKEN_DISEASE_INTENT_RESOLVED",
                disease = listOf("Ebola virus disease / viral hemorrhagic fever frame"),
                trigger = listOf("Ebola virus / filovirus exposure"),
                pathway = listOf("interferon timing", "cytokine storm", "endothelial injury", "coagulation/platelet axis"),
                cell = listOf("blood", "PBMC", "monocytes", "endothelium"),
                assay = listOf("RNA-seq", "single-cell RNA-seq", "cytokine profiling"),
                comparator = listOf("Ebola cases vs controls/recovered comparators")
            )
            matchesAny(normalized, "hanta", "hantavirus", "hfrs", "hcps") -> GTIMSingleTokenDiseaseIntentExpansionV2940(
                active = true,
                state = "SINGLE_TOKEN_DISEASE_INTENT_RESOLVED",
                disease = listOf("Hantavirus disease / hemorrhagic fever renal-pulmonary syndrome frame"),
                trigger = listOf("hantavirus / rodent-borne viral exposure"),
                pathway = listOf("endothelial injury", "capillary leak", "interferon", "cytokine signaling"),
                cell = listOf("blood", "PBMC", "endothelium", "kidney/lung context"),
                assay = listOf("RNA-seq", "serology/cytokine profiling", "single-cell RNA-seq"),
                comparator = listOf("hantavirus cases vs healthy/recovered controls")
            )
            matchesAny(normalized, "covid", "sars cov 2", "sars-cov-2", "pasc", "long covid") -> GTIMSingleTokenDiseaseIntentExpansionV2940(
                active = true,
                state = "SINGLE_TOKEN_DISEASE_INTENT_RESOLVED",
                disease = listOf("COVID", "Long COVID / PASC"),
                trigger = listOf("SARS-CoV-2"),
                pathway = listOf("interferon", "IL-6", "TNF", "cytokine", "post-viral inflammation"),
                cell = listOf("PBMC", "blood", "airway epithelial tissue"),
                assay = listOf("RNA-seq", "cytokine profiling", "single-cell RNA-seq"),
                comparator = listOf("COVID cases vs healthy/recovered controls")
            )
            matchesAny(normalized, "diabetes", "diabetic", "t2d", "type 2 diabetes", "type2 diabetes") -> GTIMSingleTokenDiseaseIntentExpansionV2940(
                active = true,
                state = "SINGLE_TOKEN_DISEASE_INTENT_RESOLVED",
                disease = listOf("Diabetes / metabolic-inflammatory phenotype"),
                trigger = listOf("glucose/insulin metabolic stress"),
                pathway = listOf("insulin resistance", "metabolic inflammation", "IL-6", "TNF", "adipose inflammation"),
                cell = listOf("blood", "PBMC", "adipose tissue", "pancreatic/islet context"),
                assay = listOf("RNA-seq", "metabolomics", "cytokine profiling"),
                comparator = listOf("diabetes cases vs non-diabetic controls")
            )
            matchesAny(normalized, "hiv", "aids") -> GTIMSingleTokenDiseaseIntentExpansionV2940(
                active = true,
                state = "SINGLE_TOKEN_DISEASE_INTENT_RESOLVED",
                disease = listOf("HIV/AIDS"),
                trigger = listOf("HIV retroviral infection"),
                pathway = listOf("CD4 depletion", "immune activation", "T-cell exhaustion", "interferon"),
                cell = listOf("CD4 T cells", "CD8 T cells", "PBMC", "blood"),
                assay = listOf("RNA-seq", "flow cytometry", "single-cell RNA-seq"),
                comparator = listOf("HIV cases vs controls or treatment-status comparators")
            )
            matchesAny(normalized, "arthritis", "rheumatoid arthritis", "ra") -> GTIMSingleTokenDiseaseIntentExpansionV2940(
                active = true,
                state = "SINGLE_TOKEN_DISEASE_INTENT_RESOLVED",
                disease = listOf("Rheumatoid arthritis / synovial autoimmune inflammation"),
                trigger = listOf("autoimmune synovial inflammation"),
                pathway = listOf("TNF", "IL-6", "B-cell autoantibody", "citrullination"),
                cell = listOf("synovial tissue", "PBMC", "T cells", "B cells", "macrophage"),
                assay = listOf("RNA-seq", "single-cell RNA-seq", "cytokine profiling"),
                comparator = listOf("arthritis cases vs healthy/non-inflammatory controls")
            )
            else -> empty("NO_SINGLE_TOKEN_DISEASE_MATCH")
        }
    }

    private fun empty(state: String): GTIMSingleTokenDiseaseIntentExpansionV2940 =
        GTIMSingleTokenDiseaseIntentExpansionV2940(
            active = false,
            state = state,
            disease = emptyList(),
            trigger = emptyList(),
            pathway = emptyList(),
            cell = emptyList(),
            assay = emptyList(),
            comparator = emptyList()
        )

    private fun normalize(value: String): String = value.lowercase(Locale.US)
        .replace('→', ' ')
        .replace('_', ' ')
        .replace('-', ' ')
        .replace(Regex("[^a-z0-9/\\s]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun matchesAny(text: String, vararg needles: String): Boolean = needles.any { raw ->
        val needle = normalize(raw)
        if (needle.isBlank()) false else Regex("(?<![a-z0-9])${Regex.escape(needle)}(?![a-z0-9])").containsMatchIn(text)
    }
}
