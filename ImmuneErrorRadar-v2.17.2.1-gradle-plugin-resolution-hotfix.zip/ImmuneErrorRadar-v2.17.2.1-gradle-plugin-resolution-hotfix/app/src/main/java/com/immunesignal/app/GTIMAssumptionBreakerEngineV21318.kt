package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.18 — Assumption breaker.
 *
 * Finds when the active immune hypothesis challenges an older biological assumption.
 * This is a research-paradigm preview only. It does not validate a mechanism, drug,
 * antibody, treatment, dosing, or clinical implementation.
 */
object GTIMAssumptionBreakerEngineV21318 {
    const val VERSION: String = "2.13.18-assumption-breaker-engine"
    const val CLAIM_LIMIT: String = "assumption_breaker_generates_paradigm_hypotheses_not_validated_science_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val rawTopic = listOf(
            report.optString("topic"),
            report.optString("researchTopic"),
            report.optString("normalizedTopic"),
            report.optJSONObject("topicCapture")?.optString("rawInput").orEmpty(),
            report.optJSONObject("topicCapture")?.optString("normalizedTopic").orEmpty()
        ).joinToString(" ").lowercase()
        val paradigm = GTIMParadigmCandidateEngineV21317.toJson(report)
        val conceptId = paradigm.optString("concept_id", "none_selected")
        val challenge = when {
            // FOXP3/Treg/tolerance intent must win over broad HSPC/trained-immunity
            // concept ordering. Otherwise rheumatoid/Treg prompts can be mislabeled as
            // generic epigenetic memory and fail the tolerance paradigm contract.
            rawTopic.contains("foxp3") || rawTopic.contains("treg") || rawTopic.contains("tolerance") ||
                active == "rheumatoid_autoimmune_synovial_inflammation" || active == "allergy_type2_barrier" ->
                "old_assumption_autoimmunity_requires_global_immunosuppression"
            conceptId.contains("trained", ignoreCase = true) || conceptId.contains("hspc", ignoreCase = true) ->
                "old_assumption_innate_immunity_has_no_memory"
            conceptId.contains("treg", ignoreCase = true) || conceptId.contains("tolerance", ignoreCase = true) ->
                "old_assumption_autoimmunity_requires_global_immunosuppression"
            conceptId.contains("neuro", ignoreCase = true) ->
                "old_assumption_brain_immunity_is_separate_from_peripheral_immune_state"
            conceptId.contains("microbiome", ignoreCase = true) ->
                "old_assumption_microbiome_is_background_context_not_immune_programming_axis"
            conceptId.contains("digital", ignoreCase = true) || conceptId.contains("antibody", ignoreCase = true) ->
                "old_assumption_antibody_discovery_requires_only_wetlab_screening"
            active == "immune_age_longevity" ->
                "old_assumption_longevity_is_calendar_age_not_immune_state_reprogramming"
            active == "oncology_tumor_microenvironment" ->
                "old_assumption_more_immunity_is_always_better_in_cancer"
            else -> "old_assumption_not_selected"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("active_domain", active)
            .put("concept_id", conceptId)
            .put("old_assumption_challenged", challenge)
            .put("new_paradigm_candidate", paradigm.optString("candidate_mechanism", "open immune reprogramming mechanism"))
            .put("assumption_breaker_level", if (challenge == "old_assumption_not_selected") "A0_OPEN_ASSUMPTION_SCAN" else "A1_ASSUMPTION_CHALLENGE_CANDIDATE")
            .put("falsifier", "downgrade if the proposed mechanism does not outperform ordinary disease-route markers or fails cross-domain contradiction checks")
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Assumption breaker engine",
            "Assumption level: ${obj.optString("assumption_breaker_level")}; old_assumption_challenged=${obj.optString("old_assumption_challenged")}",
            "New paradigm candidate: ${obj.optString("new_paradigm_candidate")}",
            "Assumption falsifier: ${obj.optString("falsifier")}",
            "Boundary: ${obj.optString("claim_limit")}."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "old_assumption_challenged",
        "old_assumption_innate_immunity_has_no_memory",
        "old_assumption_autoimmunity_requires_global_immunosuppression",
        "old_assumption_antibody_discovery_requires_only_wetlab_screening",
        CLAIM_LIMIT
    ))
}
