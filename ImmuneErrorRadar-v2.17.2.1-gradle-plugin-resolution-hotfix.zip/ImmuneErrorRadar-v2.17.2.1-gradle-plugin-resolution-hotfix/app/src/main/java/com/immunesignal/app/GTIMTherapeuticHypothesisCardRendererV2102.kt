package com.immunesignal.app

// v2.10.2 — Therapeutic hypothesis card renderer extension.
// Extends the existing medical dossier; it is deliberately permissive for research-route discovery while locking clinical action claims.
object GTIMTherapeuticHypothesisCardRendererV2102 {
    const val VERSION: String = "2.10.4-relaxed-therapeutic-hypothesis-card-renderer"
    private const val VALIDATION_LIMIT = "GTIM_THERAPEUTIC_IDEA_OPEN_RESEARCH_HYPOTHESIS_NOT_CLINICAL_ACTION"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        routes: List<GTIMTherapeuticRouteCardV2100>,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): Pair<List<GTIMTherapeuticHypothesisCardV2102>, List<GTIMClinicalTrialsRequestPlanV2102>> {
        val routeLines = routes.map { it.line } + discovery.map { it.line }
        val matches = GTIMImmunotherapyKnowledgeBaseV2102.match(contract, routeLines)
        val plans = GTIMClinicalTrialsRequestPlannerV2102.build(contract, matches)
        val hasCapsule = discovery.any { it.sourceLayer.contains("capsule", true) || it.finding.contains("capsule", true) }
        val hasDge = dgeVerdict.verdict == "DGE_READY_REVIEW_ONLY_NOT_RUN"
        val cards = matches.mapIndexed { index, match ->
            val (rank, rankReason) = GTIMEvidenceRankMapperV2102.map(match, hasExternalCapsule = hasCapsule, hasDgeReady = hasDge)
            val plan = plans.getOrNull(index)
            val validation = when {
                rank.contains("A_CANDIDATE") -> "RANK_A_CANDIDATE_OPEN_FOR_RESEARCH_VALIDATION"
                rank.contains("X") -> "ESCAPE_OR_UNSAFE_CLAIM_REVIEW_PRIORITY"
                match.entry.id == "open_mechanism_exploration" -> "OPEN_EXPLORATION_ALLOWED_UNVERIFIED"
                else -> VALIDATION_LIMIT
            }
            val line = "Therapeutic hypothesis card: version=$VERSION | id=THC_${index + 1}_${match.entry.id} | route=${match.entry.mechanismClass} | rank=$rank | required_biomarkers=${match.entry.biomarkersRequired.joinToString(", ")} | evidence_sources_to_check=${match.entry.authoritySources.joinToString(", ")} | target_conservation=${match.entry.targetConservation} | escape_risk=${match.entry.escapeRisk} | safety=${match.entry.safetyFlags.joinToString(", ")} | validation=$validation | discovery_relaxed=true | no_dosing_no_clinical_management_no_efficacy_claim=true"
            GTIMTherapeuticHypothesisCardV2102(
                cardId = "THC_${index + 1}_${match.entry.id}",
                mechanismId = match.entry.id,
                routeClass = match.entry.mechanismClass,
                evidenceRank = rank,
                evidenceRankReason = rankReason,
                requiredBiomarkers = match.entry.biomarkersRequired,
                authoritySources = match.entry.authoritySources,
                targetConservation = match.entry.targetConservation,
                escapeRisk = match.entry.escapeRisk,
                resistancePatterns = match.entry.resistancePatterns,
                safetyFlags = match.entry.safetyFlags,
                validationStatus = validation,
                clinicalTrialsRequestPlan = plan?.queryTerm ?: "NO_REQUEST_PLAN_AVAILABLE",
                line = line
            )
        }
        return cards to plans
    }
}
