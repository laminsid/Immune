package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.2 — Dataset-to-study readiness closure. */
object GTIMDataClosureStudyReadinessV2132 {
    const val VERSION: String = "2.13.2-data-closure-study-readiness"
    const val CLAIM_LIMIT: String = "study_protocol_readiness_not_clinical_or_biological_proof"

    fun toJson(report: JSONObject): JSONObject {
        val closure = report.optJSONObject("verifiedMetadataClosurePackV2132") ?: GTIMVerifiedMetadataClosurePackV2132.toJson(report)
        val capsule = report.optJSONObject("closedEvidenceCapsuleV2132") ?: GTIMClosedEvidenceCapsuleV2132.toJson(report)
        val sampleGroups = closure.optJSONArray("sampleGroups") ?: JSONArray()
        val mve = closure.optString("nextExperiment").ifBlank { report.optJSONObject("minimumViableStudyProtocolV21218")?.optString("minimumViableExperiment") ?: "Define one comparator-ready dataset and one falsification readout." }
        val humanAnimal = closure.optString("humanAnimalInVitroSeparation", "unknown")
        val feasibility = when {
            capsule.optInt("capsuleScore", 0) >= 9 -> 9
            capsule.optInt("capsuleScore", 0) >= 7 -> 8
            capsule.optInt("capsuleScore", 0) >= 5 -> 6
            else -> 4
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (sampleGroups.length() > 0) "STUDY_PROTOCOL_DATA_READY_FOR_REVIEW" else "STUDY_PROTOCOL_NEEDS_DATASET")
            .put("studyProtocol", JSONObject()
                .put("question", "Does the selected dataset support the proposed biological route under explicit comparator and provenance gates?")
                .put("populationOrModel", humanAnimal)
                .put("comparators", sampleGroups)
                .put("primaryReadout", "route-specific target/module readout defined by target validation card")
                .put("secondaryReadouts", JSONArray(listOf("inflammatory module", "tissue/species stratification", "contradiction/negative-control route")))
                .put("minimumViableExperiment", mve)
                .put("falsificationRule", "Demote hypothesis if comparator separation, sample provenance, or route-specific module signal fails review."))
            .put("feasibilityScore", feasibility)
            .put("datasetToStudyMapping", if (capsule.optInt("capsuleScore", 0) >= 7) "review_ready_discovery_or_validation_candidate" else "discovery_only_until_capsule_closes")
            .put("humanAnimalInVitroSeparation", humanAnimal)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val protocol = obj.optJSONObject("studyProtocol") ?: JSONObject()
        return listOf(
            "Data-closure study readiness",
            "State: ${obj.optString("state", "UNKNOWN")}; feasibility=${obj.optInt("feasibilityScore", 0)}/10; dataset_mapping=${obj.optString("datasetToStudyMapping", "unknown")}",
            "Population/model separation: ${obj.optString("humanAnimalInVitroSeparation", "unknown")}",
            "Minimum viable experiment: ${protocol.optString("minimumViableExperiment", "not available")}",
            "Falsification: ${protocol.optString("falsificationRule", "not available")}",
            "Boundary: protocol readiness is not medical advice, diagnosis, treatment, dosing, or efficacy evidence."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "STUDY_PROTOCOL_DATA_READY_FOR_REVIEW", "minimumViableExperiment", "humanAnimalInVitroSeparation", CLAIM_LIMIT))
}
