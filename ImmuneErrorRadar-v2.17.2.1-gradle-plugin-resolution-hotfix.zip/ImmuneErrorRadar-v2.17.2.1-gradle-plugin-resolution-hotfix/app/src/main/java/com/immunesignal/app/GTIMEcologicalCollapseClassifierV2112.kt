package com.immunesignal.app

// v2.11.2 — Classifies the internal equivalent of the "black pond" state.
object GTIMEcologicalCollapseClassifierV2112 {
    const val VERSION: String = "2.11.2-ecological-collapse-classifier"
    private const val CLAIM_LIMIT: String = "restoration_analogy_not_medical_or_causal_proof"

    fun classify(
        contract: GTIMRunDecisionContractV2740,
        corpus: String,
        candidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
        microbialReversal: GTIMMicrobialReversalReportV2111?
    ): List<GTIMEcologicalCollapseSignalV2112> {
        val text = (corpus + " " + candidates.joinToString(" ") { it.upstreamDysfunction + " " + it.causalChain + " " + it.restorationNeed } + " " + microbialReversal?.line.orEmpty()).lowercase()
        val signals = mutableListOf<GTIMEcologicalCollapseSignalV2112>()
        if (hasAny(text, listOf("dysbiosis", "microbiome", "bacteria", "microbial", "lost function", "ecological"))) {
            signals += signal(
                id = "LOW_DIVERSITY_OR_FUNCTION_LOSS",
                type = "low_diversity_or_missing_microbiome_function",
                pattern = "Symptoms or topic context may represent loss of stabilizing microbial/metabolite functions rather than a single-agent defect.",
                drivers = listOf("antibiotic or diet pressure", "lost functional guild", "pathogen niche dominance", "metabolite depletion"),
                missing = "microbial/metabolite stabilizing function that supports barrier, tolerance, or immune tone",
                topic = contract.primaryAnchor.routeId
            )
        }
        if (hasAny(text, listOf("barrier", "mucosal", "gut", "skin", "lung", "permeability", "mucus", "epithelial"))) {
            signals += signal(
                id = "BARRIER_FAILURE",
                type = "barrier_or_entry_surface_collapse",
                pattern = "The topic may behave like a boundary failure where exposure, antigens, microbes, or inflammatory cues cross compartments too easily.",
                drivers = listOf("mucus/tight-junction stress", "local immune threshold loss", "exposure pressure", "microbial-metabolite imbalance"),
                missing = "barrier repair and local tolerance function",
                topic = contract.primaryAnchor.routeId
            )
        }
        if (hasAny(text, listOf("inflammation", "cytokine", "autoimmune", "allergy", "asthma", "mast", "th17", "treg", "immune over"))) {
            signals += signal(
                id = "IMMUNE_OVERACTIVATION",
                type = "persistent_immune_overactivation_or_tolerance_loss",
                pattern = "Shared symptoms may reflect immune decision error or chronic inflammatory loop rather than a unique disease identity.",
                drivers = listOf("persistent antigen/exposure cue", "tolerance loss", "cytokine durability", "trained-immune mismatch"),
                missing = "immune recalibration function with explicit tolerance and cytokine biomarkers",
                topic = contract.primaryAnchor.routeId
            )
        }
        if (hasAny(text, listOf("toxin", "pfas", "plastic", "microplastic", "pollution", "bpa", "phthalate", "heavy metal", "exposome", "water", "food"))) {
            signals += signal(
                id = "TOXIN_OR_EXPOSOME_PRESSURE",
                type = "external_pressure_or_toxin_burden",
                pattern = "The collapse pattern may be driven by continuous exposure pressure that distorts barrier, microbiome, metabolism, or immune tone.",
                drivers = listOf("particle/chemical exposure", "oxidative stress", "endocrine-immune interaction", "microbiome perturbation"),
                missing = "exposure buffering, binding, biotransformation, or resilience function",
                topic = contract.primaryAnchor.routeId
            )
        }
        if (signals.isEmpty()) {
            signals += signal(
                id = "OPEN_ECOLOGICAL_COLLAPSE_SCAN",
                type = "open_system_imbalance",
                pattern = "No specific collapse driver is dominant; keep the topic as an open restoration-oriented dysfunction scan.",
                drivers = listOf("unknown root dysfunction", "overlapping symptom family", "insufficient context"),
                missing = "discriminating evidence before selecting a repair function",
                topic = contract.primaryAnchor.routeId
            )
        }
        return signals.distinctBy { it.signalId }.take(6)
    }

    private fun signal(id: String, type: String, pattern: String, drivers: List<String>, missing: String, topic: String): GTIMEcologicalCollapseSignalV2112 {
        val line = "Ecological collapse signal: version=$VERSION | id=$id | type=$type | topic=$topic | pattern=${pattern.oneLine()} | drivers=${drivers.joinToString(";").oneLine()} | missing_function=${missing.oneLine()} | claim_limit=$CLAIM_LIMIT"
        return GTIMEcologicalCollapseSignalV2112(id, type, pattern, drivers, missing, CLAIM_LIMIT, line)
    }

    private fun hasAny(text: String, tokens: List<String>): Boolean = tokens.any { text.contains(it.lowercase()) }
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
