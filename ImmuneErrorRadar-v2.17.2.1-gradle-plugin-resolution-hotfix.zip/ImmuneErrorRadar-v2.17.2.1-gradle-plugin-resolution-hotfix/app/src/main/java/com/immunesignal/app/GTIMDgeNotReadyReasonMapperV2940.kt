package com.immunesignal.app

/**
 * v2.9.4 — Human-readable DGE_NOT_READY reason mapping.
 *
 * This is display/report-only. It does not relax DGE gates and does not run DGE.
 */
object GTIMDgeNotReadyReasonMapperV2940 {
    const val VERSION: String = "2.9.4-dge-not-ready-reason-mapper"

    fun label(actual: GTIMActualEtlExecutionReportV2800, finalRun: GTIMActualEtlFinalRunReportV2803): String = when {
        finalRun.state == "FINAL_ETL_STOP_NO_TOPIC_COMPATIBLE_TARGET" || actual.targetId.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", ignoreCase = true) ->
            "DGE_NOT_READY_NO_TOPIC_COMPATIBLE_TARGET"
        finalRun.state == "FINAL_ETL_STOP_OBSERVED_FILE_EVIDENCE_REQUIRED" ->
            "DGE_NOT_READY_TARGET_FOUND_FILE_MISSING"
        finalRun.state == "FINAL_ETL_STOP_MATRIX_FILE_NOT_CLASSIFIED" ->
            "DGE_NOT_READY_MATRIX_LINK_UNRESOLVED"
        finalRun.state == "FINAL_ETL_STOP_SAMPLE_METADATA_NOT_EXTRACTED" ->
            "DGE_NOT_READY_METADATA_ROWS_PENDING"
        finalRun.state == "FINAL_ETL_STOP_CASE_CONTROL_EVIDENCE_REQUIRED" ->
            "DGE_NOT_READY_COMPARATOR_LABELS_AMBIGUOUS"
        finalRun.state == "FINAL_ETL_STOP_SAMPLE_ID_LINKAGE_NOT_CONFIRMED" ->
            "DGE_NOT_READY_SAMPLE_LINKAGE_MISSING"
        finalRun.state == "FINAL_ETL_READY_REVIEW_ONLY_DGE_NOT_RUN" ->
            "DGE_READY_REVIEW_ONLY_NOT_RUN"
        else -> actual.dgeReadinessVerdict.verdict.ifBlank { "DGE_NOT_READY_UNCLASSIFIED" }
    }

    fun nextEvidence(label: String, targetId: String): String = when (label) {
        "DGE_NOT_READY_NO_TOPIC_COMPATIBLE_TARGET" -> "select a topic-compatible accession target before ETL probing"
        "DGE_NOT_READY_TARGET_FOUND_FILE_MISSING" -> "locate/download observed supplementary raw/count matrix file for $targetId"
        "DGE_NOT_READY_MATRIX_LINK_UNRESOLVED" -> "classify observed matrix file type and parser plan for $targetId"
        "DGE_NOT_READY_METADATA_ROWS_PENDING" -> "extract sample metadata rows with source_field and evidence_snippet"
        "DGE_NOT_READY_COMPARATOR_LABELS_AMBIGUOUS" -> "normalize case/control labels with evidence snippets"
        "DGE_NOT_READY_SAMPLE_LINKAGE_MISSING" -> "match metadata sample IDs to matrix columns/barcodes"
        "DGE_READY_REVIEW_ONLY_NOT_RUN" -> "queue review-only DGE without gene/pathway claims until output exists"
        else -> "continue ETL gate closure before DGE"
    }

    fun line(actual: GTIMActualEtlExecutionReportV2800, finalRun: GTIMActualEtlFinalRunReportV2803): String {
        val label = label(actual, finalRun)
        return "DGE readiness reason: version=$VERSION | label=$label | next=${nextEvidence(label, actual.targetId)} | no_gene_pathway_without_dge=true"
    }
}
