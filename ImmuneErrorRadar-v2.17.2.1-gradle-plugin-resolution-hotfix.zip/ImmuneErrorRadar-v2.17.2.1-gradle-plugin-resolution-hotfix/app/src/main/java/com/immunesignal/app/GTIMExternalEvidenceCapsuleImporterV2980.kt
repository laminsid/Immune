package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

object GTIMExternalEvidenceCapsuleImporterV2980 {
    const val VERSION: String = "2.9.8-external-evidence-capsule-importer"

    fun build(targetId: String, report: JSONObject? = null): GTIMExternalEvidenceCapsuleImportReportV2980 {
        val target = GTIMAccessionIdValidityGuardV2753.canonical(targetId)
        val capsule = report?.optJSONObject("externalEvidenceCapsule")
            ?: report?.optJSONObject("gtimExternalEvidenceCapsule")
        if (capsule == null) {
            return emit(target, "CAPSULE_NOT_SUPPLIED", "", "", "none", emptyList(), emptyList(), emptyList(), "", listOf("capsule_missing"))
        }
        val dataset = firstNonBlank(capsule.optString("dataset_id"), capsule.optString("datasetId"), capsule.optString("gse"), target)
        val contrast = firstNonBlank(capsule.optString("contrast_id"), capsule.optString("contrastId"))
        val source = firstNonBlank(capsule.optString("source"), capsule.optString("generatedBy"), "external_capsule")
        val claimLimit = firstNonBlank(capsule.optString("claim_limit"), capsule.optString("claimLimit"))
        val hashes = stringList(capsule.optJSONArray("provenance_hashes") ?: capsule.optJSONArray("source_hashes") ?: capsule.optJSONArray("hashes"))
        val genes = genes(capsule)
        val pathways = pathways(capsule)
        val blockers = mutableListOf<String>()
        if (dataset.isBlank()) blockers += "dataset_id_missing"
        if (contrast.isBlank()) blockers += "contrast_id_missing"
        if (claimLimit.isBlank()) blockers += "claim_limit_missing"
        if (hashes.isEmpty()) blockers += "provenance_hash_missing"
        if (genes.isEmpty() && pathways.isEmpty()) blockers += "summary_payload_missing"
        val state = when {
            blockers.isNotEmpty() -> "CAPSULE_REJECTED_${blockers.first().uppercase(Locale.US)}"
            genes.isNotEmpty() -> "CAPSULE_EXTERNAL_DGE_SUMMARY_AVAILABLE"
            pathways.isNotEmpty() -> "CAPSULE_PATHWAY_SUMMARY_AVAILABLE"
            else -> "CAPSULE_METADATA_ONLY"
        }
        return emit(target, state, dataset, contrast, source, genes, pathways, hashes, claimLimit, blockers)
    }

    private fun genes(capsule: JSONObject): List<GTIMExternalEvidenceCapsuleGeneV2980> {
        val arrays = listOfNotNull(
            capsule.optJSONArray("top_genes"),
            capsule.optJSONArray("topGenes"),
            capsule.optJSONArray("immune_focus"),
            capsule.optJSONArray("immuneFocus")
        )
        val out = mutableListOf<GTIMExternalEvidenceCapsuleGeneV2980>()
        for (array in arrays) {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val gene = firstNonBlank(obj.optString("gene"), obj.optString("symbol"), obj.optString("name")).uppercase(Locale.US)
                if (gene.isBlank()) continue
                out += GTIMExternalEvidenceCapsuleGeneV2980(
                    gene = gene,
                    direction = firstNonBlank(obj.optString("direction"), obj.optString("dir"), obj.optString("regulation"), "unknown"),
                    log2fc = nullableDouble(obj, "log2fc", "log2FC", "log2_fold_change"),
                    padj = nullableDouble(obj, "padj", "adj_p", "fdr"),
                    rank = obj.optInt("rank", out.size + 1),
                    axis = firstNonBlank(obj.optString("axis"), obj.optString("pathway"), "unspecified")
                )
            }
        }
        return out.distinctBy { it.gene + "|" + it.direction.lowercase(Locale.US) }.take(250)
    }

    private fun pathways(capsule: JSONObject): List<GTIMExternalEvidenceCapsulePathwayV2980> {
        val arrays = listOfNotNull(capsule.optJSONArray("pathways"), capsule.optJSONArray("pathway_capsules"), capsule.optJSONArray("pathwayCapsules"))
        val out = mutableListOf<GTIMExternalEvidenceCapsulePathwayV2980>()
        for (array in arrays) {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val name = firstNonBlank(obj.optString("pathway"), obj.optString("name"))
                if (name.isBlank()) continue
                out += GTIMExternalEvidenceCapsulePathwayV2980(
                    pathway = name,
                    direction = firstNonBlank(obj.optString("direction"), "unknown"),
                    score = nullableDouble(obj, "score", "nes", "combined_score"),
                    supportGenes = stringList(obj.optJSONArray("support_genes") ?: obj.optJSONArray("supportGenes"))
                )
            }
        }
        return out.distinctBy { it.pathway.lowercase(Locale.US) }.take(100)
    }

    private fun emit(
        target: String,
        state: String,
        dataset: String,
        contrast: String,
        source: String,
        genes: List<GTIMExternalEvidenceCapsuleGeneV2980>,
        pathways: List<GTIMExternalEvidenceCapsulePathwayV2980>,
        hashes: List<String>,
        claimLimit: String,
        blockers: List<String>
    ): GTIMExternalEvidenceCapsuleImportReportV2980 {
        val line = "External evidence capsule: version=$VERSION | state=$state | target=$target | dataset=${dataset.ifBlank { "none" }} | contrast=${contrast.ifBlank { "none" }} | genes=${genes.size} | pathways=${pathways.size} | hashes=${hashes.size} | blockers=${blockers.ifEmpty { listOf("none") }.joinToString(",")} | external_summary_not_internal_dge_ready=true"
        return GTIMExternalEvidenceCapsuleImportReportV2980(
            active = true,
            targetId = target,
            state = state,
            datasetId = dataset,
            contrastId = contrast,
            source = source,
            topGenes = genes,
            pathways = pathways,
            provenanceHashes = hashes,
            claimLimit = claimLimit,
            blockers = blockers,
            line = normalize(line),
            boundaryLine = "External capsule boundary: imported summaries are research evidence capsules only; they do not prove clinical diagnosis, treatment response, dosing, efficacy, or internal DGE execution."
        )
    }

    private fun stringList(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        val out = mutableListOf<String>()
        for (i in 0 until array.length()) {
            val value = array.optString(i).trim()
            if (value.isNotBlank()) out += value
        }
        return out.distinct()
    }

    private fun nullableDouble(obj: JSONObject, vararg keys: String): Double? {
        for (key in keys) {
            if (obj.has(key)) return obj.optDouble(key)
        }
        return null
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""
    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
