package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Inflammatory reflex mapper for vagus/immune feedback hypotheses. */
object GTIMInflammatoryReflexMapperV21320 {
    const val VERSION: String = "2.13.20-inflammatory-reflex-mapper"
    const val STATE_READY: String = "INFLAMMATORY_REFLEX_MAPPING_READY"
    const val CLAIM_LIMIT: String = "inflammatory_reflex_mapping_not_universal_anti_inflammatory_treatment"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("reflex_axes", JSONArray(listOf("vagus_splenic_axis", "cholinergic_anti_inflammatory_pathway", "cytokine_feedback_loop", "autonomic_immune_balance")))
        .put("candidate_tests", JSONArray(listOf("map_inflammatory_burst_timing", "separate_neuroimmune_signal_from_drug_effect", "check_closed_loop_feedback_need")))
        .put("treatment_claim_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
