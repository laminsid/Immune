package com.immunesignal.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.5.6: Learning Session Manager
 *
 * Controls advanced learning in discrete, user-triggered sessions of up to 15
 * minutes. Sessions are pausable, resumable, checkpointed, and protected by an
 * integrity guard. These sessions are research-review bookkeeping only: they do
 * not diagnose, treat, prove biology, or change core evidence gates.
 */

enum class SessionStatus {
    NOT_STARTED,
    IN_PROGRESS,
    PAUSED,
    COMPLETED,
    FAILED
}

enum class SessionType {
    FRESH_ANALYSIS,
    INCREMENTAL,
    RESUMED
}

enum class PhaseStatus {
    PENDING,
    IN_PROGRESS,
    PAUSED,
    COMPLETED,
    FAILED
}

data class LearningSession(
    val sessionId: String,
    val sessionType: SessionType,
    val startedAt: Long,
    val status: SessionStatus,
    val timeLimit: Long,
    val phases: List<PhaseState>,
    val checkpoint: SessionCheckpoint,
    val claimLimits: Map<String, String>,
    val accumulatedTimeUsed: Long = 0L,
    val resumeCount: Int = 0,
    val historyTag: String? = null
) {
    fun timeUsed(): Long {
        val activeDelta = if (status == SessionStatus.IN_PROGRESS) {
            (System.currentTimeMillis() - startedAt).coerceAtLeast(0L)
        } else 0L
        return (accumulatedTimeUsed + activeDelta).coerceAtLeast(0L)
    }

    fun timeRemaining(): Long = (timeLimit - timeUsed()).coerceAtLeast(0L)

    fun overallProgress(): Int {
        if (phases.isEmpty()) return 0
        return (phases.sumOf { it.progress } / phases.size).coerceIn(0, 100)
    }

    fun canContinue(): Boolean = timeRemaining() > 0 && status != SessionStatus.COMPLETED
}

data class PhaseState(
    val phaseName: String,
    val status: PhaseStatus,
    val progress: Int,
    val startedAt: Long? = null,
    val completedAt: Long? = null,
    val processedItems: Int = 0,
    val totalItems: Int = 0,
    val partialResults: JSONObject? = null,
    val nextItemIndex: Int = 0,
    val error: String? = null
) {
    fun timeUsed(): Long {
        val start = startedAt ?: return 0L
        val end = completedAt ?: System.currentTimeMillis()
        return (end - start).coerceAtLeast(0L)
    }
}

data class SessionCheckpoint(
    val lastPhaseCompleted: String?,
    val lastDataProcessed: String?,
    val pendingPhases: List<String>,
    val canResume: Boolean,
    val savedAt: Long
)

data class LearningSessionReport(
    val sessionId: String,
    val sessionType: SessionType,
    val status: SessionStatus,
    val progress: Int,
    val timeUsed: Long,
    val timeLimit: Long,
    val phases: List<PhaseReport>,
    val insights: LearningInsights,
    val claimLimits: Map<String, String>,
    val nextAction: String,
    val handoff: LearningSessionHandoff = LearningSessionHandoff.empty(sessionId)
) {
    fun timeRemaining(): Long = (timeLimit - timeUsed).coerceAtLeast(0L)

    fun estimatedCompletion(): String {
        val msRemaining = timeRemaining()
        val seconds = (msRemaining / 1000) % 60
        val minutes = (msRemaining / (1000 * 60)) % 60
        return "${minutes.toInt()}m ${seconds.toInt()}s"
    }
}

data class PhaseReport(
    val phaseName: String,
    val status: PhaseStatus,
    val progress: Int,
    val timeUsed: Long,
    val findings: JSONObject?
)

data class LearningInsights(
    val failurePatternClusters: List<JSONObject> = emptyList(),
    val hypothesisInteractions: List<JSONObject> = emptyList(),
    val proposedRoutes: List<JSONObject> = emptyList(),
    val blindSpots: List<JSONObject> = emptyList(),
    val questions: List<String> = emptyList()
)

/** Local-only session bookkeeping metrics. Not evidence or biological proof. */
data class SessionMetrics(
    val sessionId: String,
    val timeUsed: Long,
    val timeLimit: Long,
    val timePerPhase: Map<String, Long>,
    val progressPerPhase: Map<String, Int>,
    val totalItems: Int,
    val itemsProcessed: Int,
    val itemsRemaining: Int,
    val datasetsAnalyzed: Int,
    val hypothesesCompared: Int,
    val newInsightsFound: Int,
    val checkpointsCreated: Int,
    val resumeCount: Int,
    val errorCount: Int,
    val deltaFromPrevious: Map<String, Int>,
    val claimLimit: String = "session_metrics_not_biological_proof"
)

class LearningSessionManager(private val context: Context) {
    private val fileName = "immune_learning_session_checkpoint_v150.json"
    private val historyFileName = "immune_learning_session_history_v154.json"
    private var currentSession: LearningSession? = null

    fun startSession(
        sessionType: SessionType = SessionType.INCREMENTAL,
        timeLimit: Long = RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS
    ): LearningSession {
        val existing = loadCheckpoint()
        val session = if (existing != null && sessionType == SessionType.RESUMED && existing.checkpoint.canResume) {
            resumeFromCheckpoint(existing)
        } else {
            createNewSession(sessionType, timeLimit)
        }
        currentSession = session
        return session
    }

    private fun createNewSession(sessionType: SessionType, timeLimit: Long): LearningSession {
        val phases = LearningSessionIntegrityGuard.expectedPhaseNames.map { name ->
            PhaseState(
                phaseName = name,
                status = PhaseStatus.PENDING,
                progress = 0,
                totalItems = 1
            )
        }
        return LearningSession(
            sessionId = "session_${System.currentTimeMillis()}_${(Math.random() * 10000).toInt()}",
            sessionType = sessionType,
            startedAt = System.currentTimeMillis(),
            status = SessionStatus.IN_PROGRESS,
            timeLimit = timeLimit.takeIf { it > 0 } ?: RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS,
            phases = phases,
            checkpoint = SessionCheckpoint(
                lastPhaseCompleted = null,
                lastDataProcessed = null,
                pendingPhases = phases.map { it.phaseName },
                canResume = false,
                savedAt = System.currentTimeMillis()
            ),
            claimLimits = defaultClaimLimits(),
            accumulatedTimeUsed = 0L,
            resumeCount = 0,
            historyTag = "created"
        )
    }

    private fun resumeFromCheckpoint(checkpoint: LearningSession): LearningSession {
        return checkpoint.copy(
            status = SessionStatus.IN_PROGRESS,
            sessionType = SessionType.RESUMED,
            startedAt = System.currentTimeMillis(),
            resumeCount = checkpoint.resumeCount + 1,
            historyTag = "resumed_from_checkpoint"
        )
    }

    fun updatePhaseProgress(
        phaseName: String,
        progress: Int,
        processedItems: Int = 0,
        totalItems: Int = 0,
        partialResults: JSONObject? = null,
        error: String? = null
    ) {
        val session = currentSession ?: return
        val updatedPhases = session.phases.map { phase ->
            if (phase.phaseName == phaseName) {
                phase.copy(
                    status = if (error == null) PhaseStatus.IN_PROGRESS else PhaseStatus.FAILED,
                    progress = progress.coerceIn(0, 100),
                    startedAt = phase.startedAt ?: System.currentTimeMillis(),
                    processedItems = processedItems,
                    totalItems = totalItems,
                    partialResults = partialResults ?: phase.partialResults,
                    error = error
                )
            } else phase
        }
        currentSession = session.copy(phases = updatedPhases)
    }

    fun completePhase(phaseName: String, results: JSONObject) {
        val session = currentSession ?: return
        val now = System.currentTimeMillis()
        val updatedPhases = session.phases.map { phase ->
            if (phase.phaseName == phaseName) {
                phase.copy(
                    status = PhaseStatus.COMPLETED,
                    progress = 100,
                    startedAt = phase.startedAt ?: now,
                    completedAt = now,
                    processedItems = phase.totalItems.coerceAtLeast(phase.processedItems).coerceAtLeast(1),
                    totalItems = phase.totalItems.coerceAtLeast(1),
                    partialResults = results,
                    error = null
                )
            } else phase
        }
        val pending = updatedPhases.filter { it.status != PhaseStatus.COMPLETED }.map { it.phaseName }
        currentSession = session.copy(
            phases = updatedPhases,
            checkpoint = session.checkpoint.copy(
                lastPhaseCompleted = phaseName,
                pendingPhases = pending,
                canResume = pending.isNotEmpty(),
                savedAt = now
            ),
            historyTag = "phase_completed:$phaseName"
        )
        saveCheckpoint(currentSession!!)
    }

    fun pauseSession() {
        val session = currentSession ?: return
        currentSession = session.copy(
            status = SessionStatus.PAUSED,
            accumulatedTimeUsed = session.timeUsed(),
            startedAt = System.currentTimeMillis(),
            historyTag = "paused"
        )
        saveCheckpoint(currentSession!!)
    }

    fun resumeSession() {
        val session = currentSession ?: loadCheckpoint() ?: return
        currentSession = LearningSessionIntegrityGuard.normalize(session).copy(
            status = SessionStatus.IN_PROGRESS,
            startedAt = System.currentTimeMillis(),
            resumeCount = session.resumeCount + 1,
            historyTag = "resumed"
        )
    }

    fun skipCurrentOrNextPhase(reason: String = "user_skipped_phase"): LearningSession? {
        val session = currentSession ?: loadCheckpoint() ?: return null
        val target = session.phases.firstOrNull { it.status == PhaseStatus.IN_PROGRESS }
            ?: session.phases.firstOrNull { it.status == PhaseStatus.PAUSED }
            ?: session.phases.firstOrNull { it.status == PhaseStatus.PENDING }
            ?: return session
        val now = System.currentTimeMillis()
        val skippedResult = JSONObject().apply {
            put("skipped", true)
            put("reason", reason)
            put("phaseName", target.phaseName)
            put("claimLimit", "phase_skipped_no_inference")
            put("savedAt", now)
        }
        val updatedPhases = session.phases.map { phase ->
            if (phase.phaseName == target.phaseName) {
                phase.copy(
                    status = PhaseStatus.COMPLETED,
                    progress = 100,
                    startedAt = phase.startedAt ?: now,
                    completedAt = now,
                    partialResults = skippedResult,
                    error = null
                )
            } else phase
        }
        val pending = updatedPhases.filter { it.status != PhaseStatus.COMPLETED }.map { it.phaseName }
        currentSession = session.copy(
            status = SessionStatus.PAUSED,
            accumulatedTimeUsed = session.timeUsed(),
            startedAt = now,
            phases = updatedPhases,
            checkpoint = session.checkpoint.copy(
                lastPhaseCompleted = target.phaseName,
                pendingPhases = pending,
                canResume = pending.isNotEmpty(),
                savedAt = now
            ),
            historyTag = "phase_skipped:${target.phaseName}"
        )
        saveCheckpoint(currentSession!!)
        return currentSession
    }

    fun markNewSearchBoundary(reason: String = "new_search_started"): LearningSession? {
        val session = currentSession ?: loadCheckpoint() ?: return null
        val now = System.currentTimeMillis()
        val boundary = JSONObject().apply {
            put("event", "NEW_SEARCH_BOUNDARY")
            put("reason", reason)
            put("timestamp", now)
            put("claimLimit", "session_boundary_not_evidence")
        }
        currentSession = session.copy(
            status = if (session.status == SessionStatus.COMPLETED) session.status else SessionStatus.PAUSED,
            accumulatedTimeUsed = session.timeUsed(),
            startedAt = now,
            checkpoint = session.checkpoint.copy(
                canResume = session.status != SessionStatus.COMPLETED,
                savedAt = now,
                lastDataProcessed = reason
            ),
            phases = session.phases.mapIndexed { index, phase ->
                if (index == 0 && phase.partialResults == null && phase.status == PhaseStatus.PENDING) {
                    phase.copy(partialResults = boundary)
                } else phase
            },
            historyTag = "new_search_boundary:$reason"
        )
        saveCheckpoint(currentSession!!)
        return currentSession
    }

    fun getSessionMetrics(): SessionMetrics? {
        val session = currentSession ?: loadCheckpoint() ?: return null
        return buildSessionMetrics(session)
    }

    private fun buildSessionMetrics(session: LearningSession): SessionMetrics {
        val phaseTimes = session.phases.associate { it.phaseName to it.timeUsed() }
        val phaseProgress = session.phases.associate { it.phaseName to it.progress }
        val totalItems = session.phases.sumOf { it.totalItems.coerceAtLeast(0) }
        val processedItems = session.phases.sumOf { it.processedItems.coerceAtLeast(0) }
        val errorCount = session.phases.count { it.status == PhaseStatus.FAILED || it.error != null }
        val insights = session.phases.count { phase ->
            val obj = phase.partialResults
            obj != null && !obj.optBoolean("skipped", false) && obj.length() > 0
        }
        val completedCheckpoints = session.phases.count { it.status == PhaseStatus.COMPLETED }
        return SessionMetrics(
            sessionId = session.sessionId,
            timeUsed = session.timeUsed(),
            timeLimit = session.timeLimit,
            timePerPhase = phaseTimes,
            progressPerPhase = phaseProgress,
            totalItems = totalItems,
            itemsProcessed = processedItems,
            itemsRemaining = (totalItems - processedItems).coerceAtLeast(0),
            datasetsAnalyzed = session.phases.firstOrNull { it.phaseName == "FAILURE_ANALYSIS" }?.processedItems ?: 0,
            hypothesesCompared = session.phases.firstOrNull { it.phaseName == "INTERACTION_DETECTION" }?.processedItems ?: 0,
            newInsightsFound = insights,
            checkpointsCreated = completedCheckpoints,
            resumeCount = session.resumeCount,
            errorCount = errorCount,
            deltaFromPrevious = mapOf(
                "newClusters" to (session.phases.firstOrNull { it.phaseName == "FAILURE_ANALYSIS" }?.partialResults?.optJSONArray("clusters")?.length() ?: 0),
                "newInteractions" to (session.phases.firstOrNull { it.phaseName == "INTERACTION_DETECTION" }?.partialResults?.optJSONArray("interactions")?.length() ?: 0),
                "changedPriorities" to (session.phases.firstOrNull { it.phaseName == "ROUTE_DISCOVERY" }?.partialResults?.optJSONArray("proposedRoutes")?.length() ?: 0),
                "confirmedInsights" to insights,
                "contradictedInsights" to (session.phases.firstOrNull { it.phaseName == "BLIND_SPOT_FINDING" }?.partialResults?.optJSONArray("blindSpots")?.length() ?: 0)
            )
        )
    }

    fun completeSession(insights: LearningInsights) {
        val session = currentSession ?: return
        val now = System.currentTimeMillis()
        currentSession = session.copy(
            status = SessionStatus.COMPLETED,
            accumulatedTimeUsed = session.timeUsed(),
            startedAt = now,
            checkpoint = session.checkpoint.copy(
                pendingPhases = emptyList(),
                canResume = false,
                savedAt = now
            ),
            historyTag = "completed"
        )
        saveCheckpoint(currentSession!!)
    }

    fun getCurrentSession(): LearningSession? = currentSession

    fun getSessionReport(): LearningSessionReport? {
        val session = currentSession ?: loadCheckpoint() ?: return null
        val insights = buildInsightsFromPhases(session)
        return LearningSessionReport(
            sessionId = session.sessionId,
            sessionType = session.sessionType,
            status = session.status,
            progress = session.overallProgress(),
            timeUsed = session.timeUsed(),
            timeLimit = session.timeLimit,
            phases = session.phases.map { phase ->
                PhaseReport(
                    phaseName = phase.phaseName,
                    status = phase.status,
                    progress = phase.progress,
                    timeUsed = phase.timeUsed(),
                    findings = phase.partialResults
                )
            },
            insights = insights,
            claimLimits = session.claimLimits,
            nextAction = determineNextAction(session),
            handoff = LearningSessionOutcomeBridge.buildHandoff(session, insights)
        )
    }


    private fun buildInsightsFromPhases(session: LearningSession): LearningInsights {
        fun objectsFor(phaseName: String, arrayName: String): List<JSONObject> {
            val array = session.phases
                .firstOrNull { it.phaseName == phaseName }
                ?.partialResults
                ?.optJSONArray(arrayName) ?: return emptyList()
            val out = mutableListOf<JSONObject>()
            repeat(array.length()) { idx -> array.optJSONObject(idx)?.let { out.add(it) } }
            return out
        }
        val questions = mutableListOf<String>()
        session.phases.forEach { phase ->
            phase.partialResults?.optJSONArray("questions")?.let { arr ->
                repeat(arr.length()) { idx ->
                    val q = arr.optString(idx, "").trim()
                    if (q.isNotBlank()) questions += q
                }
            }
        }
        return LearningInsights(
            failurePatternClusters = objectsFor("FAILURE_ANALYSIS", "clusters"),
            hypothesisInteractions = objectsFor("INTERACTION_DETECTION", "interactions"),
            proposedRoutes = objectsFor("ROUTE_DISCOVERY", "proposedRoutes"),
            blindSpots = objectsFor("BLIND_SPOT_FINDING", "blindSpots"),
            questions = questions.distinct().take(12)
        )
    }

    private fun determineNextAction(session: LearningSession): String {
        return when {
            session.status == SessionStatus.COMPLETED -> "Learning session completed. Review insights and next research directions."
            session.status == SessionStatus.PAUSED -> "Session paused. Press Continue to resume learning."
            !session.canContinue() -> "Time limit reached. Save checkpoint and start a new session if needed."
            else -> "Learning in progress..."
        }
    }

    private fun saveCheckpoint(session: LearningSession) {
        val normalized = LearningSessionIntegrityGuard.normalize(session)
        val json = JSONObject().apply {
            put("sessionId", normalized.sessionId)
            put("sessionType", normalized.sessionType.name)
            put("startedAt", normalized.startedAt)
            put("status", normalized.status.name)
            put("timeLimit", normalized.timeLimit)
            put("timeUsed", normalized.timeUsed())
            put("accumulatedTimeUsed", normalized.timeUsed())
            put("resumeCount", normalized.resumeCount)
            put("historyTag", normalized.historyTag ?: "checkpoint")
            put("schemaVersion", RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION)
            put("claimLimit", RuntimeFeatureFlags.CHECKPOINT_CLAIM_LIMIT)
            put("integrity", LearningSessionIntegrityGuard.validationReport(normalized))

            val phasesArray = JSONArray()
            normalized.phases.forEach { phase ->
                phasesArray.put(JSONObject().apply {
                    put("phaseName", phase.phaseName)
                    put("status", phase.status.name)
                    put("progress", phase.progress)
                    put("processedItems", phase.processedItems)
                    put("totalItems", phase.totalItems)
                    put("nextItemIndex", phase.nextItemIndex)
                    phase.startedAt?.let { put("startedAt", it) }
                    phase.completedAt?.let { put("completedAt", it) }
                    phase.error?.let { put("error", it) }
                    phase.partialResults?.let { put("partialResults", it) }
                })
            }
            put("phases", phasesArray)

            put("checkpoint", JSONObject().apply {
                put("lastPhaseCompleted", normalized.checkpoint.lastPhaseCompleted)
                put("lastDataProcessed", normalized.checkpoint.lastDataProcessed)
                put("pendingPhases", JSONArray(normalized.checkpoint.pendingPhases))
                put("canResume", normalized.checkpoint.canResume)
                put("savedAt", normalized.checkpoint.savedAt)
            })

            buildSessionMetrics(normalized).let { metrics ->
                put("metrics", JSONObject().apply {
                    put("claimLimit", metrics.claimLimit)
                    put("timeUsed", metrics.timeUsed)
                    put("timeLimit", metrics.timeLimit)
                    put("overallProgress", normalized.overallProgress())
                    put("checkpointsCreated", metrics.checkpointsCreated)
                    put("resumeCount", metrics.resumeCount)
                    put("errorCount", metrics.errorCount)
                    put("itemsProcessed", metrics.itemsProcessed)
                    put("itemsRemaining", metrics.itemsRemaining)
                    put("datasetsAnalyzed", metrics.datasetsAnalyzed)
                    put("hypothesesCompared", metrics.hypothesesCompared)
                    put("newInsightsFound", metrics.newInsightsFound)
                    put("deltaFromPrevious", JSONObject(metrics.deltaFromPrevious))
                })
            }
            val handoff = LearningSessionOutcomeBridge.buildHandoff(normalized, buildInsightsFromPhases(normalized))
            put("sessionHandoff", handoff.toJson())
        }
        try {
            context.openFileOutput(fileName, Context.MODE_PRIVATE).use { fos ->
                fos.write(json.toString().toByteArray())
            }
        } catch (e: Exception) {
            android.util.Log.w("LearningSession", "saveCheckpoint failed (non-fatal): ${e.message}")
        }
        try { saveHistorySnapshot(normalized, json) } catch (e: Exception) {
            android.util.Log.w("LearningSession", "saveHistorySnapshot failed (non-fatal): ${e.message}")
        }
    }

    private fun loadCheckpoint(): LearningSession? {
        return runCatching {
            val text = context.openFileInput(fileName).bufferedReader().use { it.readText() }
            val json = JSONObject(text)
            val phases = mutableListOf<PhaseState>()
            val phasesArray = json.optJSONArray("phases") ?: JSONArray()
            repeat(phasesArray.length()) { idx ->
                val phaseJson = phasesArray.optJSONObject(idx) ?: return@repeat
                phases += PhaseState(
                    phaseName = phaseJson.optString("phaseName", ""),
                    status = parsePhaseStatus(phaseJson.optString("status", "PENDING")),
                    progress = phaseJson.optInt("progress", 0).coerceIn(0, 100),
                    startedAt = phaseJson.optLong("startedAt", 0L).takeIf { it > 0L },
                    completedAt = phaseJson.optLong("completedAt", 0L).takeIf { it > 0L },
                    processedItems = phaseJson.optInt("processedItems", 0),
                    totalItems = phaseJson.optInt("totalItems", 0),
                    partialResults = phaseJson.optJSONObject("partialResults"),
                    nextItemIndex = phaseJson.optInt("nextItemIndex", 0),
                    error = phaseJson.optString("error", "").ifBlank { null }
                )
            }

            val checkpointJson = json.optJSONObject("checkpoint") ?: JSONObject()
            val pending = mutableListOf<String>()
            val pendingArray = checkpointJson.optJSONArray("pendingPhases") ?: JSONArray()
            repeat(pendingArray.length()) { idx -> pending += pendingArray.optString(idx, "") }

            LearningSessionIntegrityGuard.normalize(
                LearningSession(
                    sessionId = json.optString("sessionId", "session_${System.currentTimeMillis()}"),
                    sessionType = parseSessionType(json.optString("sessionType", "INCREMENTAL")),
                    startedAt = json.optLong("startedAt", System.currentTimeMillis()),
                    status = parseSessionStatus(json.optString("status", "PAUSED")),
                    timeLimit = json.optLong("timeLimit", RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS),
                    phases = phases,
                    checkpoint = SessionCheckpoint(
                        lastPhaseCompleted = checkpointJson.optString("lastPhaseCompleted", "").ifBlank { null },
                        lastDataProcessed = checkpointJson.optString("lastDataProcessed", "").ifBlank { null },
                        pendingPhases = pending.filter { it.isNotBlank() },
                        canResume = checkpointJson.optBoolean("canResume", false),
                        savedAt = checkpointJson.optLong("savedAt", 0L)
                    ),
                    claimLimits = defaultClaimLimits(),
                    accumulatedTimeUsed = json.optLong("accumulatedTimeUsed", json.optLong("timeUsed", 0L)),
                    resumeCount = json.optInt("resumeCount", 0),
                    historyTag = json.optString("historyTag", "checkpoint")
                )
            )
        }.getOrNull()
    }

    private fun saveHistorySnapshot(session: LearningSession, checkpointJson: JSONObject) {
        runCatching {
            val existing = runCatching {
                val text = context.openFileInput(historyFileName).bufferedReader().use { it.readText() }
                JSONObject(text).optJSONArray("sessions") ?: JSONArray()
            }.getOrDefault(JSONArray())
            val sessions = JSONArray()
            val startIndex = (existing.length() - RuntimeFeatureFlags.MAX_LEARNING_SESSION_HISTORY + 1).coerceAtLeast(0)
            for (i in startIndex until existing.length()) {
                sessions.put(existing.optJSONObject(i) ?: continue)
            }
            sessions.put(JSONObject().apply {
                put("sessionId", session.sessionId)
                put("status", session.status.name)
                put("sessionType", session.sessionType.name)
                put("progress", session.overallProgress())
                put("timeUsed", session.timeUsed())
                put("timeLimit", session.timeLimit)
                put("resumeCount", session.resumeCount)
                put("historyTag", session.historyTag ?: "checkpoint")
                put("lastPhaseCompleted", session.checkpoint.lastPhaseCompleted)
                put("lastDataProcessed", session.checkpoint.lastDataProcessed)
                put("savedAt", System.currentTimeMillis())
                put("claimLimit", "session_history_not_biological_proof")
                put("integrity", LearningSessionIntegrityGuard.validationReport(session))
                put("checkpointSchema", checkpointJson.optString("schemaVersion", "unknown"))
            })
            context.openFileOutput(historyFileName, Context.MODE_PRIVATE).use { fos ->
                fos.write(JSONObject().apply {
                    put("schemaVersion", RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION)
                    put("claimLimit", "session_history_not_biological_proof")
                    put("sessions", sessions)
                }.toString().toByteArray())
            }
        }
    }

    fun getSessionHistorySummary(limit: Int = 5): String {
        return runCatching {
            val text = context.openFileInput(historyFileName).bufferedReader().use { it.readText() }
            val sessions = JSONObject(text).optJSONArray("sessions") ?: JSONArray()
            if (sessions.length() == 0) return@runCatching "No prior session history."
            val lines = mutableListOf<String>()
            val from = (sessions.length() - limit).coerceAtLeast(0)
            for (i in from until sessions.length()) {
                val obj = sessions.optJSONObject(i) ?: continue
                lines += "${obj.optString("sessionId")}: ${obj.optString("status")} ${obj.optInt("progress")}% (${obj.optString("historyTag", "checkpoint")})"
            }
            lines.joinToString("\n")
        }.getOrDefault("No prior session history.")
    }

    fun getCheckpointIntegrityReport(): JSONObject? {
        val session = currentSession ?: loadCheckpoint() ?: return null
        return LearningSessionIntegrityGuard.validationReport(session)
    }

    fun clearCheckpoint() {
        context.deleteFile(fileName)
        currentSession = null
        // History is retained as a local audit trail; it contains bookkeeping only.
    }

    private fun defaultClaimLimits(): Map<String, String> = mapOf(
        "failures" to "memory_only_not_biological_proof",
        "interactions" to "pattern_hypothesis_not_discovery",
        "routes" to "proposed_not_validated",
        "blindSpots" to "research_guidance_not_proof"
    )

    private fun parseSessionType(raw: String): SessionType = runCatching { SessionType.valueOf(raw) }.getOrDefault(SessionType.INCREMENTAL)
    private fun parseSessionStatus(raw: String): SessionStatus = runCatching { SessionStatus.valueOf(raw) }.getOrDefault(SessionStatus.PAUSED)
    private fun parsePhaseStatus(raw: String): PhaseStatus = runCatching { PhaseStatus.valueOf(raw) }.getOrDefault(PhaseStatus.PENDING)
}
