package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.18.1 — final requirements coverage and output-contract closure.
 *
 * This is a small acceptance layer, not another discovery engine. It verifies that the
 * final release surface stays hypothesis-first, capsule-backed, paradigm-aware, and
 * preview-relaxed while keeping proof/clinical/action claims blocked. It also checks the
 * presence of the priority disease capsules and concept/digital-immunomics capsules that
 * define the current research scope.
 */
object GTIMFinalRequirementsCoverageClosureV213181 {
    const val VERSION: String = "2.13.18.1-final-requirements-coverage-and-output-contract"
    const val STATE_READY: String = "FINAL_REQUIREMENTS_COVERAGE_CLOSURE_READY"
    const val CLAIM_LIMIT: String = "requirements_coverage_closure_acceptance_layer_not_scientific_or_clinical_proof"

    private val requiredDiseaseCapsules = listOf(
        "inflammation_resolution_core",
        "rheumatoid_synovial_core",
        "allergy_gse146170",
        "cancer_tme_core",
        "filovirus_gse45291",
        "hiv_immune_activation_core",
        "covid_gse152202",
        "diabetes_inflammation_core",
        "hantavirus_endothelial_core",
        "longevity_immune_age_core"
    )

    private val requiredConceptCapsules = listOf(
        "trained_innate_immunity_core",
        "hspc_epigenetic_memory",
        "peripheral_immune_tolerance_core",
        "foxp3_treg_master_program",
        "car_treg_or_tissue_specific_tolerance_repair",
        "neuro_immune_axis",
        "microbiome_immune_metabolite_axis",
        "tissue_resident_immunity",
        "immune_age_inflammaging",
        "digital_immunomics_antibody_design",
        "protein_language_model_design",
        "gut_microbiome_endocrine_immune_organ",
        "netosis_extracellular_trap_core",
        "panoptosis_panoptosome_core",
        "immunothrombosis_thromboinflammation"
    )

    private val requiredSurfaceOrder = listOf(
        "Primary hypothesis",
        "Immune decision state",
        "Capsule state",
        "Concept/paradigm candidate",
        "Microbiome role",
        "Cell-death / NETosis role",
        "Best execution route",
        "Falsifier",
        "Claim boundary"
    )

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val capsule = report.optJSONObject("localProcessedCapsuleLayerV21316")
            ?: GTIMCapsuleSurfaceCardV21316.toJson(report)
        val paradigm = report.optJSONObject("paradigmCandidateEngineV21317")
            ?: GTIMParadigmCandidateEngineV21317.toJson(report)
        val integrated = report.optJSONObject("finalIntegratedDiscoveryClosureV213171")
            ?: GTIMFinalIntegratedDiscoveryClosureV213171.toJson(report)
        val matrixState = capsule.optString("matrix_state", integrated.optString("capsule_state", "CAPSULE_MISSING_ACQUISITION_TASK_CREATED"))
        val capsuleAvailable = matrixState.contains("LOCAL_PROCESSED_CAPSULE_AVAILABLE", ignoreCase = true) ||
            integrated.optBoolean("local_capsule_available", false)
        val capsuleOutcome = if (capsuleAvailable) {
            "LOCAL_PROCESSED_CAPSULE_AVAILABLE_HYPOTHESIS_STRENGTH_HIGHER"
        } else {
            "CAPSULE_MISSING_C0_C1_HYPOTHESIS_AND_ACQUISITION_TASK_CREATED"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("active_domain", active)
            .put("priority_disease_capsules", JSONArray(requiredDiseaseCapsules))
            .put("concept_capsules", JSONArray(requiredConceptCapsules))
            .put("output_contract_order", JSONArray(requiredSurfaceOrder))
            .put("capsule_outcome", capsuleOutcome)
            .put("c2_c3_sandbox_preview_allowed", true)
            .put("hypothesis_output_allowed", true)
            .put("validated_proof_allowed", false)
            .put("treatment_dosing_clinical_action_allowed", false)
            .put("legacy_surface_owner_allowed", false)
            .put("paradigm_candidate_present", paradigm.optString("paradigm_level", "P0_OPEN_PARADIGM_SEARCH").isNotBlank())
            .put("digital_immunomics_present", integrated.optBoolean("digital_immunomics_applicable", false) || paradigm.has("digital_immunomics_lens"))
            .put("microbiome_role_card_present", integrated.has("microbiome_role_card"))
            .put("cell_death_netosis_panoptosis_present", integrated.has("cell_death_netosis_panoptosis_card"))
            .put("proof_boundary", "mechanism_direction_is_not_therapeutic_suggestion_and_not_validated_treatment")
            .put("legacy_policy", "legacy_rails_json_export_appendix_audit_compatibility_only")
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Final requirements coverage closure",
            "State: ${obj.optString("state")}; active_domain=${obj.optString("active_domain")}; version=${obj.optString("version")}",
            "Coverage: priority disease capsules include chronic inflammation, rheumatoid, allergy, cancer, Ebola/filovirus, HIV/AIDS, COVID, diabetes, hantavirus, and longevity/immune-age.",
            "Coverage: concept capsules include trained innate immunity, HSPC memory, peripheral tolerance, FOXP3/Treg, CAR-Treg/tissue tolerance, neuro-immune, microbiome-immune-metabolite, tissue-resident immunity, immune age/inflammaging, digital immunomics, de novo antibody design, protein language models, gut microbiome endocrine-immune organ, NETosis, PANoptosis, and immunothrombosis.",
            "Coverage: microbiome_capsules/ and cell_death_capsules/ are indexed, lightweight, and used as research lenses only.",
            "Capsule outcome: ${obj.optString("capsule_outcome")}",
            "Final output contract: Primary hypothesis → Immune decision state → Capsule state → Concept/paradigm candidate → Microbiome role → Cell-death / NETosis role → Best execution route → Falsifier → Claim boundary.",
            "Preview policy: C0/C1/C2/C3 sandbox preview allowed; hypothesis output allowed=${obj.optBoolean("hypothesis_output_allowed")}; validated_proof_allowed=${obj.optBoolean("validated_proof_allowed")}; treatment/dosing/clinical action allowed=${obj.optBoolean("treatment_dosing_clinical_action_allowed")}",
            "Legacy policy: ${obj.optString("legacy_policy")}; legacy_surface_owner_allowed=${obj.optBoolean("legacy_surface_owner_allowed")}",
            "Claim boundary: ${obj.optString("proof_boundary")}; ${obj.optString("claim_limit")}"
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        STATE_READY,
        "inflammation_resolution_core",
        "rheumatoid_synovial_core",
        "allergy_gse146170",
        "cancer_tme_core",
        "filovirus_gse45291",
        "hiv_immune_activation_core",
        "covid_gse152202",
        "diabetes_inflammation_core",
        "hantavirus_endothelial_core",
        "longevity_immune_age_core",
        "trained_innate_immunity_core",
        "hspc_epigenetic_memory",
        "peripheral_immune_tolerance_core",
        "foxp3_treg_master_program",
        "digital_immunomics_antibody_design",
        "protein_language_model_design",
        "Primary hypothesis",
        "Immune decision state",
        "Capsule state",
        "Concept/paradigm candidate",
        "Microbiome role",
        "Cell-death / NETosis role",
        "Best execution route",
        "Falsifier",
        "Claim boundary",
        "LOCAL_PROCESSED_CAPSULE_AVAILABLE_HYPOTHESIS_STRENGTH_HIGHER",
        "CAPSULE_MISSING_C0_C1_HYPOTHESIS_AND_ACQUISITION_TASK_CREATED",
        "microbiome_capsules/index.json",
        "cell_death_capsules/index.json",
        "legacy_rails_json_export_appendix_audit_compatibility_only",
        CLAIM_LIMIT
    ))
}
