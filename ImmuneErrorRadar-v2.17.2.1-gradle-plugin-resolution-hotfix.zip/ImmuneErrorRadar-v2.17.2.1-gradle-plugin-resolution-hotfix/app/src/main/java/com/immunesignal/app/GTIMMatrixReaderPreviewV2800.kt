package com.immunesignal.app

/** v2.8.0 — Matrix reader preview. Parses readiness from discovered/downloaded file signals without fabricating matrix content. */
data class GTIMMatrixReaderPreviewReportV2800(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val matrixFormatCandidates: List<String>,
    val schemaState: String,
    val matrixReaderLine: String,
    val boundaryLine: String
)

object GTIMMatrixReaderPreviewV2800 {
    const val VERSION: String = "2.8.0-matrix-reader-preview"

    fun build(fileDiscovery: GTIMRepositoryFileDiscoveryReportV2800): GTIMMatrixReaderPreviewReportV2800 =
        build(fileDiscovery, GTIMObservedFileEvidenceContractV2801.build(fileDiscovery))

    fun build(
        fileDiscovery: GTIMRepositoryFileDiscoveryReportV2800,
        observedFileEvidence: GTIMObservedFileEvidenceReportV2801
    ): GTIMMatrixReaderPreviewReportV2800 {
        if (fileDiscovery.state == "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET") {
            return report(
                target = fileDiscovery.targetId,
                state = "MATRIX_READER_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET",
                formats = emptyList(),
                schema = "NO_MATRIX_SCHEMA_TARGET",
                line = "Matrix reader preview: version=$VERSION | state=MATRIX_READER_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | target=${fileDiscovery.targetId} | formats=none | schema=blocked_before_file_discovery"
            )
        }
        val formats = fileDiscovery.candidateFileTypes.filter { candidate ->
            candidate.contains("mtx", true) || candidate.contains("h5", true) || candidate.contains("rds", true) || candidate.contains("csv", true) || candidate.contains("tsv", true) || candidate.contains("series_matrix", true)
        }.distinct()
        val hasObservedMatrixFile = observedFileEvidence.observedFileCount > 0 && observedFileEvidence.observedFileTypes.any { observed ->
            observed.contains("mtx", true) || observed.contains("matrix", true) || observed.contains("h5", true) || observed.contains("h5ad", true) ||
                observed.contains("rds", true) || observed.contains("csv", true) || observed.contains("tsv", true) ||
                observed.contains("series_matrix", true) || observed.contains("count_table", true) || observed.contains("expression_table", true) ||
                observed.contains("anndata", true) || observed.contains("hdf5", true)
        }
        val state = when {
            hasObservedMatrixFile -> "MATRIX_READER_SCHEMA_CANDIDATE_REVIEW_ONLY"
            observedFileEvidence.state == "OBSERVED_FILE_EVIDENCE_REQUIRED" -> "MATRIX_READER_WAITING_FOR_OBSERVED_FILE_EVIDENCE"
            else -> "MATRIX_READER_WAITING_FOR_DOWNLOAD"
        }
        val schema = if (state == "MATRIX_READER_SCHEMA_CANDIDATE_REVIEW_ONLY") {
            "ROW_GENE_BY_COLUMN_SAMPLE_SCHEMA_CANDIDATE"
        } else {
            "SCHEMA_PENDING_OBSERVED_FILE_EVIDENCE"
        }
        val line = "Matrix reader preview: version=$VERSION | state=$state | target=${fileDiscovery.targetId} | formats=${formats.joinToString(",")} | schema=$schema | required_checks=observed_file_evidence,gene_rows,sample_columns,non_empty_counts,format_parser,checksum | candidate_signatures_are_not_matrix_evidence=true"
        return report(fileDiscovery.targetId, state, formats, schema, line)
    }

    private fun report(target: String, state: String, formats: List<String>, schema: String, line: String): GTIMMatrixReaderPreviewReportV2800 =
        GTIMMatrixReaderPreviewReportV2800(
            active = true,
            targetId = target,
            state = state,
            matrixFormatCandidates = formats,
            schemaState = schema,
            matrixReaderLine = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Matrix reader boundary: schema/readiness preview only; candidate signatures and recovery-query terms are not matrix evidence; no matrix values are interpreted until an observed file is parsed."
        )
}
