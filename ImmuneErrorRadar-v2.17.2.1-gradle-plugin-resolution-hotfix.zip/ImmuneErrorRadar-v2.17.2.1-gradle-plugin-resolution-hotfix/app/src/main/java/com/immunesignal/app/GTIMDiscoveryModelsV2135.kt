package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.5 — Shared Discovery Candidate data model.
 * This model deliberately separates discovery-candidate language from scientific proof.
 */
data class GTIMDatasetSignalV2135(
    val datasetId: String,
    val domain: String,
    val moduleId: String,
    val direction: String,
    val signalState: String,
    val comparatorState: String,
    val provenanceState: String,
    val boundary: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("datasetId", datasetId)
        .put("domain", domain)
        .put("moduleId", moduleId)
        .put("direction", direction)
        .put("signalState", signalState)
        .put("comparatorState", comparatorState)
        .put("provenanceState", provenanceState)
        .put("boundary", boundary)
}

data class GTIMDiscoveryCandidateV2135(
    val domain: String,
    val canonicalTarget: String,
    val claimCandidate: String,
    val signalType: String,
    val datasetSignals: List<GTIMDatasetSignalV2135>,
    val replicationStatus: String,
    val negativeControlStatus: String,
    val confounderStatus: String,
    val noveltyClass: String,
    val discoveryLevel: String,
    val falsifiers: List<String>,
    val claimBoundary: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("domain", domain)
        .put("canonicalTarget", canonicalTarget)
        .put("claimCandidate", claimCandidate)
        .put("signalType", signalType)
        .put("datasetSignals", JSONArray(datasetSignals.map { it.toJson() }))
        .put("replicationStatus", replicationStatus)
        .put("negativeControlStatus", negativeControlStatus)
        .put("confounderStatus", confounderStatus)
        .put("noveltyClass", noveltyClass)
        .put("discoveryLevel", discoveryLevel)
        .put("falsifiers", JSONArray(falsifiers))
        .put("claimBoundary", claimBoundary)
}
