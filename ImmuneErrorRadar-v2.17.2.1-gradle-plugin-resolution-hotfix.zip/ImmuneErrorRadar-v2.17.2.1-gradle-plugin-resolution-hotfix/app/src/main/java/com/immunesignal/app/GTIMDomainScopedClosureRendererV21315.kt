package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.13.15 — Domain-scoped closure renderer.
 *
 * Legacy closures stay linked for GitHub/export, but first-surface rendering is scoped:
 * global-core closures can render everywhere; pathogen/domain-specific closures render
 * only when they match the active domain. This prevents Bundibugyo/BDBV blocks from
 * appearing in allergy reports, or allergy blocks from becoming viral results.
 */
object GTIMDomainScopedClosureRendererV21315 {
    const val VERSION: String = "2.13.15-final-hypothesis-first-discovery-unified"
    const val CLAIM_LIMIT: String = "domain_scoped_rendering_only_no_evidence_upgrade"

    fun normalizedSubtype(activeDomain: String, rawSubtype: String): String {
        val raw = rawSubtype.trim().lowercase(Locale.US)
        return when (activeDomain) {
            "allergy_type2_barrier" -> "allergy_type2_or_barrier_microbiome"
            "depression_kynurenine_neuroimmune" -> "neuroimmune_kynurenine"
            "filovirus_viral_host_response" -> if (raw.contains("bundibugyo") || raw.contains("bdbv")) "viral_filovirus_bundibugyo" else "viral_filovirus"
            else -> raw.ifBlank { "unspecified_or_domain_native" }
        }
    }

    fun closureDomain(closureKey: String): String = when (closureKey) {
        "finalBundibugyoSearchRuntimeClosureV213106",
        "bundibugyoRuntimeStabilityClosureV213105" -> "filovirus_viral_host_response"
        "finalRouteSearchHardeningClosureV213103" -> "global_core"
        "experimentalClaimRelaxationV21312" -> "global_core"
        "finalUnifiedDiscoveryReadinessClosureV21310" -> "global_core"
        "finalReleaseLockV21219" -> "global_core"
        "hypothesisFirstDiscoveryEngineV21315" -> "global_core"
        else -> "global_core"
    }

    fun canRenderFirstSurface(closureKey: String, activeDomain: String): Boolean {
        val domain = closureDomain(closureKey)
        return domain == "global_core" || GTIMGeneralizedRouteCoherenceGuardV21314.domainCompatible(activeDomain, domain)
    }

    fun renderOrAppendixNote(closureKey: String, activeDomain: String, lines: List<String>): List<String> =
        if (canRenderFirstSurface(closureKey, activeDomain)) lines else listOf(
            "Compatibility appendix only: $closureKey is scoped to ${closureDomain(closureKey)} and is hidden from first surface for active_domain=$activeDomain."
        )

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val rawSubtype = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeSubtype(report)
        val subtype = normalizedSubtype(active, rawSubtype)
        return JSONObject()
            .put("version", VERSION)
            .put("activeDomain", active)
            .put("activeSubtype", subtype)
            .put("closurePolicy", "global_core_everywhere_domain_specific_only_when_matching_active_domain")
            .put("firstSurfaceHiddenClosures", hiddenClosures(active))
            .put("hypothesisOutputAllowed", true)
            .put("claimPromotionAllowed", false)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Domain-scoped closure renderer",
        "State: DOMAIN_SCOPED_CLOSURE_RENDERING_READY; active_domain=${obj.optString("activeDomain", "unknown")}; subtype=${obj.optString("activeSubtype", "unknown")}",
        "Policy: ${obj.optString("closurePolicy", "global core everywhere; domain-specific closures scoped")}",
        "Hidden first-surface closures: ${obj.optJSONArray("firstSurfaceHiddenClosures")?.length() ?: 0}",
        "Boundary: rendering scope only; no evidence upgrade or clinical claim."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "DOMAIN_SCOPED_CLOSURE_RENDERING_READY",
        "global_core_everywhere_domain_specific_only_when_matching_active_domain",
        "Compatibility appendix only",
        CLAIM_LIMIT
    ))

    private fun hiddenClosures(activeDomain: String): JSONArray {
        val keys = listOf("finalBundibugyoSearchRuntimeClosureV213106", "bundibugyoRuntimeStabilityClosureV213105")
        return JSONArray(keys.filterNot { canRenderFirstSurface(it, activeDomain) })
    }
}
