package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.14 — final version unification guard.
 *
 * This is an identity/runtime guard only. It closes the patch-chain problem where older
 * rails still asked for v2.13.10/v2.13.12 identities after the generalized route
 * coherence algorithm became the active release. Legacy modules stay linked, but only as
 * compatibility modules; the active identity is single-source and auditable.
 */
object GTIMFinalVersionUnificationGuardV21314 {
    // legacy_v21314_active_compat: VERSION_NAME: String = "2.13.14-final-generalized-route-coherence-unified"
    // legacy_v21314_active_compat: VERSION_CODE: Int = 191
    // legacy_v21314_active_compat: ENGINE_VERSION: String = "v2.13.14-final-generalized-route-coherence-unified"
    // legacy_v21314_active_compat: SCHEMA_VERSION: String = "2.13.14"
    const val VERSION_NAME: String = "2.13.15-final-hypothesis-first-discovery-unified"
    const val ENGINE_VERSION: String = "v2.13.15-final-hypothesis-first-discovery-unified"
    const val VERSION_CODE: Int = 192
    const val SCHEMA_VERSION: String = "2.13.15"
    const val CLAIM_LIMIT: String = "final_version_unification_only_no_evidence_or_clinical_claim"

    fun toJson(report: JSONObject = JSONObject()): JSONObject {
        val runtimeAligned = RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == VERSION_NAME &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == VERSION_CODE &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == SCHEMA_VERSION &&
            EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ENGINE_VERSION &&
            ReleaseVersionLinkageGuard.VERSION_NAME == VERSION_NAME &&
            ReleaseVersionLinkageGuard.VERSION_CODE == VERSION_CODE &&
            ReleaseVersionLinkageGuard.ENGINE_VERSION == ENGINE_VERSION &&
            ReleaseVersionLinkageGuard.LEARNING_SCHEMA_VERSION == SCHEMA_VERSION

        val finalSurfaceAligned = GTIMFinalSurfaceDomainCoherenceGuardV21313.VERSION == VERSION_NAME &&
            GTIMGeneralizedRouteCoherenceGuardV21314.VERSION == VERSION_NAME &&
            GTIMMobileSafeFirstSurfaceV21313.VERSION == VERSION_NAME &&
            GTIMHypothesisFirstDiscoveryEngineV21315.VERSION == VERSION_NAME &&
            GTIMDomainScopedClosureRendererV21315.VERSION == VERSION_NAME

        val activeDomain = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val canonicalTarget = GTIMFinalSurfaceDomainCoherenceGuardV21313.canonicalTarget(report)
        val blockers = JSONArray()
        if (!runtimeAligned) blockers.put("runtime_or_linkage_identity_drift")
        if (!finalSurfaceAligned) blockers.put("final_surface_patch_identity_drift")
        if (!RuntimeFeatureFlags.ENABLE_GENERALIZED_ROUTE_COHERENCE_V21314) blockers.put("generalized_route_coherence_disabled")
        if (!RuntimeFeatureFlags.ENABLE_FINAL_SURFACE_DOMAIN_COHERENCE_V21313) blockers.put("final_surface_domain_coherence_disabled")
        if (!RuntimeFeatureFlags.ENABLE_HYPOTHESIS_FIRST_DISCOVERY_V21315) blockers.put("hypothesis_first_discovery_disabled")
        if (!RuntimeFeatureFlags.ENABLE_DOMAIN_SCOPED_CLOSURE_RENDERING_V21315) blockers.put("domain_scoped_closure_rendering_disabled")

        return JSONObject()
            .put("versionName", VERSION_NAME)
            .put("engineVersion", ENGINE_VERSION)
            .put("versionCode", VERSION_CODE)
            .put("schemaVersion", SCHEMA_VERSION)
            .put("state", if (blockers.length() == 0) "FINAL_VERSION_UNIFICATION_READY" else "FINAL_VERSION_UNIFICATION_REVIEW_REQUIRED")
            .put("runtimeAligned", runtimeAligned)
            .put("finalSurfaceAligned", finalSurfaceAligned)
            .put("activeDomain", activeDomain)
            .put("canonicalTarget", canonicalTarget)
            .put("legacyRailsMode", "compatibility_only")
            .put("legacyVersionRequestsClosed", true)
            .put("activeIdentitySource", "RuntimeFeatureFlags + EngineRuntimeStatus + ReleaseVersionLinkageGuard")
            .put("finalAlgorithm", "ActiveDomain -> HypothesisFirst -> CanonicalTarget -> EvidenceUpgradeGates -> FirstSurface; mismatched blocks become appendix/history/contradiction")
            .put("mobileBudget", "compact_on_device_hypothesis_first_surface; full_json_export_retained")
            .put("blockers", blockers)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final version-unification guard",
        "State: ${obj.optString("state", "UNKNOWN")}; version=${obj.optString("versionName", VERSION_NAME)}; code=${obj.optInt("versionCode", VERSION_CODE)}; schema=${obj.optString("schemaVersion", SCHEMA_VERSION)}.",
        "Runtime aligned: ${obj.optBoolean("runtimeAligned", false)}; final_surface_aligned=${obj.optBoolean("finalSurfaceAligned", false)}; legacy_rails=${obj.optString("legacyRailsMode", "compatibility_only")}; old_version_requests_closed=${obj.optBoolean("legacyVersionRequestsClosed", false)}.",
        "Final algorithm: ${obj.optString("finalAlgorithm", "ActiveDomain -> HypothesisFirst -> CanonicalTarget -> EvidenceUpgradeGates -> FirstSurface")}",
        "Runtime budget: ${obj.optString("mobileBudget", "compact_on_device_first_surface")}",
        "Boundary: release identity and hypothesis-first rendering orchestration only; no mechanism, diagnosis, treatment, dosing, vaccine, efficacy, or validated discovery claim."
    )
}
