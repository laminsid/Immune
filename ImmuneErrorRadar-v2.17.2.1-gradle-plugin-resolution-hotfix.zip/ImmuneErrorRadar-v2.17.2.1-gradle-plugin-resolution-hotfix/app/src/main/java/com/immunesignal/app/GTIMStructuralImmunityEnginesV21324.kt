package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Structural immunity lens: non-immune cells as active immune-code participants. */
object GTIMStructuralImmunityNonImmuneCellEngineV21324 {
    const val VERSION: String = "2.13.24-structural-immunity-non-immune-cell-engine"
    const val STATE_READY: String = "STRUCTURAL_IMMUNITY_NON_IMMUNE_CELL_ENGINE_READY"
    const val CLAIM_LIMIT: String = "structural_immunity_is_research_lens_not_tissue_therapy_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val topic = report.optString("topic", report.optJSONObject("topicCapture")?.optString("normalizedTopic", "") ?: "")
        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("topic_hint", topic.take(240))
            .put("core_shift", "structural cells are modeled as active local immune-code participants, not passive barriers only")
            .put("cell_families", JSONArray(listOf("epithelial_cells", "endothelial_cells", "fibroblasts", "keratinocytes", "stromal_cells", "barrier_tissue_cells")))
            .put("mechanism_axes", JSONArray(listOf("danger_sensing", "local_cytokine_chemokine_output", "epigenetic_tissue_memory", "barrier_remodeling", "fibrosis_programming", "immune_cell_recruitment_instruction")))
            .put("disease_contexts", JSONArray(listOf("eczema_psoriasis", "asthma_lung_barrier_injury", "Crohn_intestinal_barrier", "pulmonary_fibrosis", "liver_cardiac_fibrosis", "wound_repair_aging_tissue")))
            .put("best_falsifier", "Downgrade if single-cell/spatial data show immune-cell-only signal with no structural-cell transcriptional or epigenetic state separation.")
            .put("claim_limit", CLAIM_LIMIT)
}
}

/** Maps tissue-local memory concepts without upgrading them to therapeutic proof. */
object GTIMBarrierTissueMemoryMapperV21324 {
    const val VERSION: String = "2.13.24-barrier-tissue-memory-mapper"
    const val STATE_READY: String = "BARRIER_TISSUE_MEMORY_MAPPER_READY"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("memory_model", "barrier and stromal cells may retain local molecular/epigenetic state after repeated stress, infection, or inflammation")
        .put("readouts", JSONArray(listOf("single_cell_RNA_seq", "single_cell_ATAC_seq", "spatial_transcriptomics", "fibroblast_activation_modules", "epithelial_interferon_or_alarm_modules", "endothelial_activation_markers")))
        .put("recurrence_hypothesis", "local structural-cell memory may help explain same-site relapse patterns without assuming systemic immune proof")
        .put("falsifier", "No local structural-cell state persistence after accounting for infiltrating immune-cell composition and tissue damage severity.")
}

/** Separates fibroblast/endothelial/epithelial immune-code hypotheses. */
object GTIMStructuralCellImmuneCodeMapperV21324 {
    const val VERSION: String = "2.13.24-structural-cell-immune-code-mapper"
    const val STATE_READY: String = "STRUCTURAL_CELL_IMMUNE_CODE_MAPPER_READY"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("fibroblast_axis", JSONArray(listOf("matrix_remodeling", "fibrosis_program", "chemokine_scaffold", "tissue_stiffness_feedback")))
        .put("endothelial_axis", JSONArray(listOf("vascular_activation", "leukocyte_trafficking_gate", "coagulation_inflammation_interface", "barrier_leak_signal")))
        .put("epithelial_axis", JSONArray(listOf("barrier_alarm", "antimicrobial_and_interferon_programs", "mucosal_tolerance_instruction", "repair_vs_scar_decision")))
        .put("strategic_research_value", "turns many chronic inflammatory or fibrotic conditions into tissue-state engineering hypotheses, not only immune-cell suppression hypotheses")
        .put("blocked_claims", JSONArray(listOf("tissue_targeted_therapy_proof", "fibrosis_reversal_claim", "bioengineered_organ_acceptance_claim", "clinical_implementation_claim")))
}

/** Compact first-surface card for structural immunity and non-immune cell immunological code. */
object GTIMStructuralImmunitySurfaceCardV21324 {
    const val VERSION: String = "2.13.24-structural-immunity-surface-card"
    const val STATE_READY: String = "STRUCTURAL_IMMUNITY_SURFACE_CARD_READY"
    const val CLAIM_LIMIT: String = "structural_immunity_card_research_only_no_tissue_therapy_or_fibrosis_reversal_claim"

    fun toJson(report: JSONObject): JSONObject {
        val core = GTIMStructuralImmunityNonImmuneCellEngineV21324.toJson(report)
        val memory = GTIMBarrierTissueMemoryMapperV21324.toJson(report)
        val code = GTIMStructuralCellImmuneCodeMapperV21324.toJson(report)
        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("core_shift", core.optString("core_shift"))
            .put("cell_families", core.optJSONArray("cell_families") ?: JSONArray())
            .put("mechanism_axes", core.optJSONArray("mechanism_axes") ?: JSONArray())
            .put("tissue_memory_model", memory.optString("memory_model"))
            .put("single_cell_spatial_readouts", memory.optJSONArray("readouts") ?: JSONArray())
            .put("fibroblast_axis", code.optJSONArray("fibroblast_axis") ?: JSONArray())
            .put("endothelial_axis", code.optJSONArray("endothelial_axis") ?: JSONArray())
            .put("epithelial_axis", code.optJSONArray("epithelial_axis") ?: JSONArray())
            .put("sandbox_preview_allowed", true)
            .put("tissue_therapy_claim_allowed", false)
            .put("fibrosis_reversal_claim_allowed", false)
            .put("bioengineered_organ_acceptance_claim_allowed", false)
            .put("clinical_implementation_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Structural immunity / non-immune cell immune-code card",
            "Old assumption challenged: structural cells are not passive barriers only; epithelial/endothelial/fibroblast/stromal cells are modeled as active local immune-code participants.",
            "Structural-cell axes: cell_families=${obj.optJSONArray("cell_families") ?: JSONArray()}; mechanisms=${obj.optJSONArray("mechanism_axes") ?: JSONArray()}.",
            "Tissue memory lens: ${obj.optString("tissue_memory_model")}; readouts=${obj.optJSONArray("single_cell_spatial_readouts") ?: JSONArray()}.",
            "Fibroblast/endothelial/epithelial code: fibroblast=${obj.optJSONArray("fibroblast_axis") ?: JSONArray()}; endothelial=${obj.optJSONArray("endothelial_axis") ?: JSONArray()}; epithelial=${obj.optJSONArray("epithelial_axis") ?: JSONArray()}.",
            "Boundary: structural immunity signal != tissue-targeted therapy proof; fibrosis/tissue repair lens != reversal claim; bioengineered-organ immune-code lens != transplant acceptance or clinical implementation claim."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        STATE_READY,
        "Structural immunity / non-immune cell immune-code card",
        "epithelial_cells",
        "endothelial_cells",
        "fibroblasts",
        "epigenetic_tissue_memory",
        "single_cell_spatial_readouts",
        "fibrosis_programming",
        "tissue-targeted therapy proof",
        "bioengineered-organ immune-code lens",
        CLAIM_LIMIT
    ))
}

/** Final linkage closure for v2.13.24 structural immunity layer. */
object GTIMFinalStructuralImmunityClosureV21324 {
    const val VERSION: String = "2.13.24-final-structural-immunity-non-immune-cell-code-layer"
    const val STATE_READY: String = "FINAL_STRUCTURAL_IMMUNITY_CLOSURE_READY"
    const val CLAIM_LIMIT: String = "structural_immunity_layer_research_only_no_therapy_fibrosis_reversal_or_clinical_implementation"

    fun toJson(report: JSONObject): JSONObject {
        val card = GTIMStructuralImmunitySurfaceCardV21324.toJson(report)
        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("surface_card_present", card.optString("state") == GTIMStructuralImmunitySurfaceCardV21324.STATE_READY)
            .put("non_immune_cell_engine", GTIMStructuralImmunityNonImmuneCellEngineV21324.STATE_READY)
            .put("barrier_tissue_memory_mapper", GTIMBarrierTissueMemoryMapperV21324.STATE_READY)
            .put("structural_cell_immune_code_mapper", GTIMStructuralCellImmuneCodeMapperV21324.STATE_READY)
            .put("legacy_linkage_policy", "old_rails_remain_appendix_export_audit_only_new_structural_immunity_layer_attaches_to_final_active_surface")
            .put("sandbox_preview_allowed", true)
            .put("tissue_therapy_claim_allowed", false)
            .put("fibrosis_reversal_claim_allowed", false)
            .put("bioengineered_organ_acceptance_claim_allowed", false)
            .put("clinical_implementation_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Final structural immunity + non-immune cell code closure",
            "State: ${obj.optString("state")}; version=${obj.optString("version")}; surface_card_present=${obj.optBoolean("surface_card_present")}",
            "Closure: non_immune_cell_engine=${obj.optString("non_immune_cell_engine")}; tissue_memory=${obj.optString("barrier_tissue_memory_mapper")}; structural_cell_code=${obj.optString("structural_cell_immune_code_mapper")}",
            "Preview policy: sandbox_preview_allowed=${obj.optBoolean("sandbox_preview_allowed")}; tissue_therapy_claim_allowed=${obj.optBoolean("tissue_therapy_claim_allowed")}; fibrosis_reversal_claim_allowed=${obj.optBoolean("fibrosis_reversal_claim_allowed")}; clinical_implementation_allowed=${obj.optBoolean("clinical_implementation_allowed")}",
            "Boundary: no tissue-targeted therapy proof, no fibrosis reversal claim, no bioengineered-organ acceptance claim, no clinical implementation; ${obj.optString("claim_limit")}."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        STATE_READY,
        "GTIMStructuralImmunityNonImmuneCellEngineV21324",
        "GTIMBarrierTissueMemoryMapperV21324",
        "GTIMStructuralCellImmuneCodeMapperV21324",
        "GTIMStructuralImmunitySurfaceCardV21324",
        "FINAL_STRUCTURAL_IMMUNITY_CLOSURE_READY",
        "no tissue-targeted therapy proof",
        "no fibrosis reversal claim",
        "no bioengineered-organ acceptance claim",
        CLAIM_LIMIT
    ))
}
