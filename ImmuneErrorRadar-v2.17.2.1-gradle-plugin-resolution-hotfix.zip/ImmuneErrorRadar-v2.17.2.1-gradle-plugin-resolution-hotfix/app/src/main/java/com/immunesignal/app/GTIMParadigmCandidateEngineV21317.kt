package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Builds a cross-disease paradigm candidate from active domain + concept capsules. */
object GTIMParadigmCandidateEngineV21317 {
    const val VERSION: String = "2.13.17-paradigm-candidate-engine"
    const val CLAIM_LIMIT: String = "paradigm_candidate_for_sandbox_research_not_validated_science_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val concepts = GTIMConceptCapsuleStoreV21317.conceptsForDomain(active)
        val best = concepts.firstOrNull()
        val polarity = GTIMImmunePolarityClassifierV21317.classify(active)
        val digital = GTIMDigitalImmunomicsLensV21317.toJson(report)
        val diseaseCapsule = GTIMCapsuleInjectionRouterV21316.route(report).executableCapsule
        return JSONObject()
            .put("version", VERSION)
            .put("active_domain", active)
            .put("immune_decision_states", JSONArray(polarity))
            .put("paradigm_level", if (best != null) "P1_CONCEPTUAL_PARADIGM_CANDIDATE" else "P0_OPEN_PARADIGM_SEARCH")
            .put("concept_id", best?.conceptId ?: "none_selected")
            .put("concept_title", best?.title ?: "open immune reprogramming concept search")
            .put("old_assumption_challenged", best?.oldAssumptionChallenged ?: "not_selected")
            .put("candidate_mechanism", best?.candidateMechanism ?: "active domain needs concept capsule selection")
            .put("connected_disease_domains", JSONArray(best?.diseaseDomains ?: emptyList<String>()))
            .put("concept_markers", JSONArray(best?.moduleMarkers ?: emptyList<String>()))
            .put("modality_lens", JSONArray(best?.modalityLens ?: emptyList<String>()))
            .put("disease_capsule", diseaseCapsule?.toJson() ?: JSONObject.NULL)
            .put("digital_immunomics_lens", digital)
            .put("falsifier", best?.falsifier ?: "downgrade if cross-disease mechanism fails domain-specific capsule or comparator checks")
            .put("claim_limit", CLAIM_LIMIT)
    }
}
