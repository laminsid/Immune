package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.17 — Search stability + unified selected-target closure.
 *
 * Final report-side closure for the fixes after v2.12.16: one selected-review-target
 * source, viral subtype safety, legacy-counter alignment, and resumable network/search
 * interruption behavior. This is a control surface only; it never promotes evidence.
 */
object GTIMSearchStabilityClosureV21217 {
    const val VERSION: String = "2.12.17-search-stability-selected-target-unification"
    const val CLAIM_LIMIT: String = "stability_closure_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val terminal = report.optJSONObject("terminalDiscoveryContinuationV21212") ?: JSONObject()
        val target = report.optJSONObject("targetValidationCardV21213") ?: JSONObject()
        val probe = report.optJSONObject("metadataProbeBackgroundWorkersV21215") ?: JSONObject()
        val selected = ledger.optString("selectedReviewTarget")
        val terminalSelected = terminal.optString("selectedReviewTarget")
        val targetSelected = target.optString("selectedReviewTarget")
        val aligned = selected.isNotBlank() && listOf(terminalSelected, targetSelected).all { it.isBlank() || it == selected }
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (aligned) "SEARCH_STABILITY_CLOSURE_READY" else "SEARCH_STABILITY_ALIGNMENT_WARNING")
            .put("selectedReviewTarget", selected)
            .put("targetAlignment", aligned)
            .put("domainKey", ledger.optString("domainKey"))
            .put("topicSubtype", ledger.optString("topicSubtype"))
            .put("candidateHandleCount", ledger.optInt("candidateHandleCount", 0))
            .put("verifiedCapsuleSourceCount", ledger.optInt("verifiedCapsuleSourceCount", 0))
            .put("backgroundWorkerState", probe.optString("state", "not_attached"))
            .put("executedSteps", probe.optJSONArray("executedSteps") ?: JSONArray())
            .put("queuedSteps", probe.optJSONArray("queuedSteps") ?: JSONArray())
            .put("runCheckpointGuard", ResearchRunCheckpointV21217.VERSION)
            .put("contract", "ledger_selected_review_target_drives_terminal_target_card_matrix_and_legacy_counter_surfaces; network interruptions produce resume state instead of silent first-page reset")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Search stability closure",
        "State: ${obj.optString("state", "UNKNOWN")}; selected_review_target=${obj.optString("selectedReviewTarget", "none")}; target_alignment=${obj.optBoolean("targetAlignment", false)}; subtype=${obj.optString("topicSubtype", "unknown")}",
        "Counters: candidate_handles=${obj.optInt("candidateHandleCount", 0)}; verified_capsule_source_count=${obj.optInt("verifiedCapsuleSourceCount", 0)}; background_worker_state=${obj.optString("backgroundWorkerState", "not_attached")}",
        "Resume guard: ${obj.optString("runCheckpointGuard", ResearchRunCheckpointV21217.VERSION)}; brief network loss is queued/resumable, not treated as biological failure.",
        "Boundary: search stability and resume guards do not upgrade evidence or claims."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "SEARCH_STABILITY_CLOSURE_READY",
        "ledger_selected_review_target_drives_terminal_target_card_matrix_and_legacy_counter_surfaces",
        "network interruptions produce resume state instead of silent first-page reset",
        ResearchRunCheckpointV21217.VERSION,
        CLAIM_LIMIT
    ))
}
