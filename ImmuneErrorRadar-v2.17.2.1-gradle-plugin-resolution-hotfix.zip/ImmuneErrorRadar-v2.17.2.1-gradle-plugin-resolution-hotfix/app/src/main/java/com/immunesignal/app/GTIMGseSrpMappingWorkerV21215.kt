package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.12.15 — GSE→SRP/SRA/PRJ mapping extractor from fetched metadata text. */
object GTIMGseSrpMappingWorkerV21215 {
    const val VERSION: String = "2.12.15-gse-srp-mapping-worker"
    const val CLAIM_LIMIT: String = "gse_srp_mapping_readiness_only_no_evidence_upgrade"

    fun parse(handle: String, text: String): JSONObject {
        val mappings = Regex("\\b(SRP\\d+|SRA\\d+|SRR\\d+|SRX\\d+|PRJNA\\d+|PRJEB\\d+)\\b", RegexOption.IGNORE_CASE)
            .findAll(text.take(500_000))
            .map { it.value.uppercase() }
            .distinct()
            .take(24)
            .toList()
        return JSONObject()
            .put("version", VERSION)
            .put("handle", handle)
            .put("mappingState", if (mappings.isNotEmpty()) "GSE_TO_SRP_OR_SRA_MAPPING_OBSERVED" else "NO_SRP_MAPPING_OBSERVED_IN_SOFT")
            .put("mappingHandles", JSONArray(mappings))
            .put("claimLimit", CLAIM_LIMIT)
    }
}
