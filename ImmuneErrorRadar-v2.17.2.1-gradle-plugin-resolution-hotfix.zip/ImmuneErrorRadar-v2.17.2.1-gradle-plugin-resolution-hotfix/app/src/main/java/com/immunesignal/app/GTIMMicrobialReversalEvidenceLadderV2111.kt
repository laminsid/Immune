package com.immunesignal.app

// v2.11.1 — Evidence ladder for radical microbial reversal hypotheses.
object GTIMMicrobialReversalEvidenceLadderV2111 {
    const val VERSION: String = "2.11.1-microbial-reversal-evidence-ladder"
    val LADDER: List<String> = listOf(
        "L0_PURE_HYPOTHESIS_NO_BIOLOGICAL_EVIDENCE",
        "L1_MECHANISM_ANALOGY_ONLY",
        "L2_IN_VITRO_OR_BINDING_FUNCTION_SIGNAL",
        "L3_ANIMAL_OR_ORGANOID_DIRECTIONAL_SIGNAL",
        "L4_HUMAN_ASSOCIATION_OR_METADATA_CONTEXT",
        "L5_HUMAN_INTERVENTIONAL_SIGNAL_UNREPLICATED",
        "L6_REPLICATED_CONTROLLED_EVIDENCE",
        "L7_NARROW_CLINICAL_PROOF_FOR_SPECIFIC_USE"
    )

    fun rank(
        function: GTIMMicrobialCounterFunctionV2111,
        corpus: String,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): String {
        val text = corpus.lowercase()
        return when {
            text.contains("clinical") || text.contains("trial") || text.contains("human intervention") -> "L5_HUMAN_INTERVENTIONAL_SIGNAL_UNREPLICATED"
            text.contains("human") || text.contains("cohort") || text.contains("metadata") || text.contains("sample") -> "L4_HUMAN_ASSOCIATION_OR_METADATA_CONTEXT"
            text.contains("mouse") || text.contains("animal") || text.contains("organoid") -> "L3_ANIMAL_OR_ORGANOID_DIRECTIONAL_SIGNAL"
            text.contains("in vitro") || text.contains("assay") || text.contains("binding") -> "L2_IN_VITRO_OR_BINDING_FUNCTION_SIGNAL"
            function.counterFunctionClass.contains("synthetic", true) -> "L1_MECHANISM_ANALOGY_ONLY"
            dgeVerdict.verdict.contains("READY", true) -> "L4_HUMAN_ASSOCIATION_OR_METADATA_CONTEXT"
            else -> "L1_MECHANISM_ANALOGY_ONLY"
        }
    }

    fun allowedClaim(rank: String): String = when {
        rank.startsWith("L7") || rank.startsWith("L6") -> "specific_evidence_review_possible_but_still_not_personal_medical_advice"
        rank.startsWith("L5") || rank.startsWith("L4") -> "research_route_with_human_context_no_clinical_claim"
        rank.startsWith("L3") || rank.startsWith("L2") -> "preclinical_or_functional_signal_only"
        else -> "hypothesis_or_mechanism_analogy_only"
    }
}
