package com.immunesignal.app

/** v2.10.1 — transparent search strategy builder for research-grade dossier output. */
object GTIMSearchStrategyBuilderV2101 {
    const val VERSION: String = "2.10.1-search-strategy-builder"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        protocol: GTIMResearchProtocolCardV2101,
        metadataBridge: GTIMMetadataFirstObservedEvidenceBridgeReportV2950?
    ): GTIMSearchStrategyCardV2101 {
        val anchor = contract.primaryAnchor.routeId.oneLine()
        val target = metadataBridge?.targetId ?: "NO_TARGET"
        val srp = metadataBridge?.gseToSrpMapping?.srpAccessions?.firstOrNull() ?: "SRP_UNKNOWN"
        val databases = listOf(
            "PubMed",
            "Cochrane/clinical guidelines when available",
            "ClinicalTrials.gov for interventional route status",
            "GEO SOFT metadata",
            "SRA via GSE-to-SRP mapping",
            "GREIN/refine.bio/recount3 availability when topic-compatible",
            "Enrichr/SigCom only after validated gene list or capsule"
        )
        val queries = listOf(
            "(${anchor}) AND (immune OR immunology OR cytokine OR biomarker OR pathway)",
            "(${anchor}) AND (systematic review OR guideline OR clinical trial OR cohort)",
            "(${anchor}) AND (${protocol.interventionOrExposure}) AND (${protocol.comparator})",
            "GEO target=${target} SOFT sample metadata characteristics_ch1 supplementary_file",
            "SRA mapping target=${target} srp=${srp}",
            "external expression availability: GREIN refine.bio recount3 for target=${target}"
        ).map { it.oneLine() }
        val trace = listOf(
            "database_name",
            "query_string",
            "timestamp_or_version",
            "inclusion_exclusion_reason",
            "study_design",
            "population_context",
            "comparator_definition",
            "source_field_and_evidence_snippet",
            "validation_status"
        )
        val traceStatus = if (metadataBridge == null || target == "NO_TARGET") {
            "SEARCH_TRACE_PLANNED_TARGET_REQUIRED"
        } else {
            "SEARCH_TRACE_READY_REVIEW_ONLY_NO_AUTOMATIC_CLAIM"
        }
        val line = "Search strategy: version=$VERSION | state=$traceStatus | databases=${databases.joinToString(", ")} | primary_query=${queries.first()} | trace_fields=${trace.joinToString(", ")}"
        return GTIMSearchStrategyCardV2101(
            strategyId = "SEARCH_STRATEGY_V2101",
            databases = databases,
            queryStrings = queries,
            requiredTraceFields = trace,
            traceStatus = traceStatus,
            line = line
        )
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
