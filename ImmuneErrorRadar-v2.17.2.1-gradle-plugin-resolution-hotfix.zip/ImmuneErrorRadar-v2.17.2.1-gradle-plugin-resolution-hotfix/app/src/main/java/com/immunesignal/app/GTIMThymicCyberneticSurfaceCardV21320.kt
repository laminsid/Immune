package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Compact first-surface card for thymic rejuvenation and cybernetic immunology lenses. */
object GTIMThymicCyberneticSurfaceCardV21320 {
    const val VERSION: String = "2.13.20-thymic-cybernetic-surface-card"
    const val STATE_READY: String = "THYMIC_CYBERNETIC_SURFACE_CARD_READY"
    const val CLAIM_LIMIT: String = "thymic_and_cybernetic_cards_are_research_lenses_not_rejuvenation_or_device_claims"

    fun toJson(report: JSONObject): JSONObject {
        val thymic = GTIMThymicRejuvenationEngineV21320.toJson(report)
        val immuneAge = GTIMImmuneAgeReversalHypothesisEngineV21320.toJson(report)
        val repertoire = GTIMNaiveTCellRepertoireMapperV21320.toJson(report)
        val bio = GTIMBioelectronicImmuneModulationEngineV21320.toJson(report)
        val reflex = GTIMInflammatoryReflexMapperV21320.toJson(report)
        val switchable = GTIMSwitchableImmunityLensV21320.toJson(report)
        val closedLoop = GTIMClosedLoopImmuneControlMapperV21320.toJson(report)
        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("thymic_state_hypothesis", thymic.optString("thymic_role"))
            .put("immune_age_hypothesis", immuneAge.optString("hypothesis"))
            .put("naive_tcell_repertoire_axes", repertoire.optJSONArray("repertoire_axes") ?: JSONArray())
            .put("bioelectronic_control_role", bio.optString("bioelectronic_role"))
            .put("inflammatory_reflex_axes", reflex.optJSONArray("reflex_axes") ?: JSONArray())
            .put("switchable_immunity_axes", switchable.optJSONArray("switch_axes") ?: JSONArray())
            .put("closed_loop_components", closedLoop.optJSONArray("loop_components") ?: JSONArray())
            .put("sandbox_preview_allowed", true)
            .put("rejuvenation_proof_allowed", false)
            .put("device_recommendation_allowed", false)
            .put("patient_action_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Thymic rejuvenation / cybernetic immunology card",
            "Thymic/immune-age role: ${obj.optString("thymic_state_hypothesis")}; naive_T_cell_axes=${obj.optJSONArray("naive_tcell_repertoire_axes") ?: JSONArray()}.",
            "Immune-age hypothesis: ${obj.optString("immune_age_hypothesis")}",
            "Bioelectronic role: ${obj.optString("bioelectronic_control_role")}; inflammatory_reflex=${obj.optJSONArray("inflammatory_reflex_axes") ?: JSONArray()}.",
            "Switchable/closed-loop lens: switches=${obj.optJSONArray("switchable_immunity_axes") ?: JSONArray()}; loop=${obj.optJSONArray("closed_loop_components") ?: JSONArray()}.",
            "Boundary: thymic rejuvenation is not age-reversal proof; bioelectronic/switchable immunity is not a device recommendation, dosing, patient action, clinical implementation, or 100% safety claim."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        STATE_READY,
        "thymic_rejuvenation",
        "FOXN1_thymic_epithelial_program",
        "IL7_KGF_thymic_support",
        "naive_T_cell_output",
        "vagus_nerve_stimulation",
        "inflammatory_reflex",
        "optogenetic_switchable_immunity",
        "closed_loop_neuroimmune_control",
        "electroceutical_immunology_lens",
        "not age-reversal proof",
        "not a device recommendation",
        CLAIM_LIMIT
    ))
}
