package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

object GTIMRouteConfidenceGateV21311 {
    private const val LOCK_SCORE = 0.55
    private const val LOCK_GAP = 0.08

    fun infer(report: JSONObject): GTIMResearchIntentObjectV21311 {
        val text = GTIMEntitySignalExtractorV21311.contextText(report)
        val entities = GTIMEntitySignalExtractorV21311.entities(report)
        val handles = GTIMEntitySignalExtractorV21311.handles(report)
        val ranked = GTIMRouteCandidateRankerV21311.rank(GTIMEvidenceFirstRouteCollectorV21311.collect(entities, handles))
        val top = ranked.first()
        val second = ranked.drop(1).firstOrNull()
        val gap = if (second == null) top.score else top.score - second.score
        val locked = top.score >= LOCK_SCORE && gap >= LOCK_GAP && top.route != "unknown_topic_evidence_discovery"
        val route = if (locked) top.route else "topic_level_route_needs_evidence"
        val subtype = if (locked) top.subtype else "unknown_or_insufficient_context"
        return GTIMResearchIntentObjectV21311(
            rawText = text.take(1600),
            entities = entities,
            handles = handles,
            candidateRoutes = ranked,
            lockedRoute = route,
            lockedSubtype = subtype,
            locked = locked,
            confidence = top.score,
            explanation = GTIMRouteCandidateRankerV21311.explanation(ranked)
        )
    }

    fun toJson(report: JSONObject): JSONObject {
        val intent = infer(report)
        val routes = JSONArray()
        intent.candidateRoutes.forEach { c ->
            routes.put(JSONObject()
                .put("route", c.route)
                .put("subtype", c.subtype)
                .put("score", c.score)
                .put("semanticScore", c.semanticScore)
                .put("evidenceScore", c.evidenceScore)
                .put("datasetScore", c.datasetScore)
                .put("reasons", JSONArray(c.reasons)))
        }
        return JSONObject()
            .put("version", GTIMResearchIntentObjectContractV21311.VERSION)
            .put("state", if (intent.locked) "EVIDENCE_FIRST_ROUTE_LOCKED" else "TOPIC_LEVEL_ROUTE_NEEDS_EVIDENCE")
            .put("locked", intent.locked)
            .put("lockedRoute", intent.lockedRoute)
            .put("lockedSubtype", intent.lockedSubtype)
            .put("confidence", intent.confidence)
            .put("entities", JSONArray(intent.entities))
            .put("handles", JSONArray(intent.handles))
            .put("candidateRoutes", routes)
            .put("explanation", intent.explanation)
            .put("policy", "semantic route fit outranks capsule readiness; dataset selection occurs only after route lock; unknown topics never reuse previous route/checkpoint")
            .put("strictness", "C0/C1/C2/C3 and medical/therapeutic/vaccine/efficacy preview labels relaxed for sandbox testing; patient action, dosing, and clinical implementation not allowed")
            .put("claimLimit", GTIMResearchIntentObjectContractV21311.CLAIM_LIMIT)
    }
}
