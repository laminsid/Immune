package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.13.26 — crash-safe mobile interim dossier.
 *
 * This layer exists because device testing showed that a long foreground pass can
 * survive search/progress but still fail later during REPORT_JSON_ENCODING or a
 * huge UI/export render. The fix is to produce a compact, useful, research-only
 * dossier before the heavy final JSON stage and close the mobile pass cleanly.
 */
object GTIMCrashSafeInterimDossierV21326 {
    const val VERSION: String = "2.13.26-crash-safe-interim-dossier"
    const val CLAIM_LIMIT: String = "compact_interim_research_only_no_diagnosis_no_treatment_no_dosing_no_evidence_upgrade"
    const val MAX_UI_CHARS: Int = 12_000
    const val STARTUP_SAFE_JSON_CHARS: Int = 180_000

    fun augment(
        report: JSONObject,
        snapshot: ResearchTopicCaptureSnapshotV2740,
        budget: GTIMMobileSearchBudgetV21322,
        sameTopicPlan: GTIMSameTopicDeepeningPlanV2123,
        status: String,
        stopReason: String,
        lastSafeStage: String,
        elapsedMillis: Long
    ): JSONObject {
        val topic = snapshot.normalizedTopic.ifBlank { snapshot.rawInput }.ifBlank { "captured research topic" }
        val local = localDossier(topic, status, stopReason, lastSafeStage, elapsedMillis, budget)
        report.put("crashSafeInterimDossierV21326", local)
        report.put("agenticProgressPlanV21324", GTIMAgenticProgressPlanV21324.toJson(budget, elapsedMillis, lastSafeStage))
        report.put("reportV3", compactReportV3(topic, local))
        report.put("finalMobileSafeClosureV21326", JSONObject()
            .put("version", VERSION)
            .put("status", status)
            .put("stopReason", stopReason)
            .put("lastSafeStage", lastSafeStage)
            .put("elapsedMillis", elapsedMillis)
            .put("hardCloseMillis", budget.hardTimeoutMillis)
            .put("sameTopicDepth", sameTopicPlan.deepeningDepth)
            .put("why", "mobile_foreground_pass_closed_before_heavy_json_encoding_or_oversized_report_render")
            .put("nextAction", "Run the same topic again to deepen from saved state, or narrow the question to one mechanism/source family.")
            .put("claimLimit", CLAIM_LIMIT)
        )
        return report
    }

    fun launchRecoveryReport(
        snapshot: ResearchTopicCaptureSnapshotV2740,
        budget: GTIMMobileSearchBudgetV21322,
        sameTopicPlan: GTIMSameTopicDeepeningPlanV2123
    ): JSONObject {
        val now = System.currentTimeMillis()
        val base = JSONObject()
            .put("schemaVersion", 21326)
            .put("productMode", "Immu DZ Autonomous Global Immune Researcher")
            .put("id", "mobile_launch_recovery_${now}")
            .put("createdAtMillis", now)
            .put("completedAtMillis", now)
            .put("topicCapture", RuntimeCrashSafetyAndTopicGuardV2740.toJson(snapshot))
            .put("sameTopicDeepeningV2123", GTIMSameTopicDeepeningBridgeV2123.toJson(sameTopicPlan))
            .put("mobileRuntimeBudgetV21322", GTIMMobileSearchRuntimeBudgetV21322.toJson(
                budget = budget,
                elapsedMillis = 0L,
                status = "LAUNCH_RECOVERY_DRAFT",
                lastSafeStage = "TOPIC_CAPTURED"
            ))
            .put("queries", JSONArray())
            .put("findings", JSONArray())
        return augment(
            report = base,
            snapshot = snapshot,
            budget = budget,
            sameTopicPlan = sameTopicPlan,
            status = "LAUNCH_RECOVERY_DRAFT",
            stopReason = "topic_captured_before_long_research_started",
            lastSafeStage = "TOPIC_CAPTURED",
            elapsedMillis = 0L
        )
    }

    fun renderUserCard(report: JSONObject): String {
        val dossier = report.optJSONObject("crashSafeInterimDossierV21326") ?: return ""
        return renderDossierCard(dossier)
    }

    fun renderDossierCard(dossier: JSONObject): String {
        val lines = mutableListOf<String>()
        lines += "Crash-safe research dossier"
        lines += "Topic: ${dossier.optString("topic", "captured topic")}".take(220)
        lines += "Status: ${dossier.optString("status", "compact_interim")}" 
        lines += "Why this report exists: ${dossier.optString("whyThisReportExists", "The mobile pass was converted to a compact dossier before heavy final rendering.")}"
        lines += ""
        lines += "Decision-first brief"
        lines += "• ${dossier.optString("decisionBrief", "A compact research-only dossier is saved; queued checks are not evidence.")}"
        lines += ""
        lines += "Working hypotheses"
        appendArray(lines, dossier.optJSONArray("workingHypotheses"), 6)
        lines += ""
        lines += "Mechanism routes to inspect next"
        appendArray(lines, dossier.optJSONArray("mechanismRoutes"), 8)
        lines += ""
        lines += "Useful local scientific memory"
        appendArray(lines, dossier.optJSONArray("localKnowledgeUsed"), 8)
        lines += ""
        lines += "Executed vs queued"
        appendArray(lines, dossier.optJSONArray("executedChecks"), 6)
        lines += "Queued:"
        appendArray(lines, dossier.optJSONArray("queuedChecks"), 8)
        lines += ""
        lines += "Next safe run"
        lines += "• ${dossier.optString("nextSafeRun", "Run the same topic again to deepen, or narrow the prompt.")}"
        lines += ""
        lines += "Boundary"
        lines += "• ${dossier.optString("claimLimit", CLAIM_LIMIT)}"
        return lines.joinToString("\n").take(MAX_UI_CHARS)
    }

    fun safeStartupCardFromRawLine(raw: String): String {
        return buildString {
            append("Previous large report found — safe startup mode\n")
            append("The previous saved report is too large to parse on screen startup (${raw.length} chars).\n")
            append("The app will not reopen it automatically to avoid another freeze.\n")
            append("Start a new narrowed run, or use Copy/Export only after a compact report is visible.\n")
            append("Boundary: startup recovery only; no scientific claim is upgraded.")
        }
    }

    private fun localDossier(
        topic: String,
        status: String,
        stopReason: String,
        lastSafeStage: String,
        elapsedMillis: Long,
        budget: GTIMMobileSearchBudgetV21322
    ): JSONObject {
        val t = topic.lowercase(Locale.US)
        val isAllergy = listOf("allergy", "allergic", "ige", "eczema", "asthma", "rhinitis", "mast", "eosinophil").any { it in t }
        val isViral = listOf("covid", "ebola", "virus", "viral", "hiv", "filovirus", "hantavirus").any { it in t }
        val isCancer = listOf("cancer", "tumor", "tumour", "oncology", "metastasis").any { it in t }
        val route = when {
            isAllergy -> "barrier-tissue / type-2 immunity / epithelial-stromal memory route"
            isViral -> "innate antiviral / tissue-resident immunity / interferon-barrier route"
            isCancer -> "tumor microenvironment / stromal-immune suppression / NET-microbiome route"
            else -> "cross-disease immune mechanism discovery route"
        }
        val hypotheses = when {
            isAllergy -> listOf(
                "Allergy should not be mapped only to circulating immune cells; epithelial, fibroblast, endothelial and barrier tissue programs may act as active immune-code participants.",
                "Repeated exposure can be modeled as local tissue memory: epigenetic barrier-state changes may help explain site-specific recurrence without claiming proof.",
                "Microbiome-metabolite-barrier signals should be kept as a parallel explanatory axis, not a replacement for IgE/type-2 mechanisms.",
                "NETosis/PANoptosis are review lenses for tissue damage and inflammatory amplification, not automatic allergy proof."
            )
            isViral -> listOf(
                "Viral route should separate systemic immune response from tissue-resident structural immunity in lung, endothelium, epithelium, and fibroblast niches.",
                "Interferon timing, trained innate immunity, immunothrombosis/NETosis and barrier repair should be modeled as distinct hypotheses.",
                "Dataset work must distinguish candidate handles from verified expression/provenance evidence."
            )
            isCancer -> listOf(
                "Cancer route should inspect tumor-stromal immune code: fibroblast/endothelial programs, tissue-resident immunity, microbiome and NET shield hypotheses.",
                "Therapeutic modality lenses remain research-only; no efficacy, treatment, dosing or clinical action claim is allowed.",
                "Spatial/single-cell evidence is preferred before upgrading any microenvironment hypothesis."
            )
            else -> listOf(
                "Use an evidence-first route: symptom/topic is a non-specific signal, not a disease proof.",
                "Prioritize shared root mechanisms across barrier, microbiome, tissue-resident immunity, immunometabolism and cell-death axes.",
                "Keep C0/C1/C2/C3 as sandbox states; queued checks do not become evidence."
            )
        }
        val mechanisms = listOf(
            "Structural Immunity / Non-Immune Cell Immunological Code: epithelial, endothelial, fibroblast and stromal cells as active immune participants.",
            "Barrier tissue memory: local epigenetic state, recurrence in the same tissue niche, and maladaptive repair/fibrosis hypotheses.",
            "Microbiome as endocrine-immune organ: microbial metabolites, gut-axis mapping, barrier tone and immune tolerance.",
            "NETosis/PANoptosis and inflammatory cell-death/extracellular immunity: damage amplification and thromboinflammatory review lens.",
            "Trained innate immunity / HSPC epigenetic memory: durable innate-state changes as a hypothesis layer.",
            "FOXP3/Treg and tissue-specific tolerance: tolerance failure/repair as a discriminating route.",
            "Digital immunomics / protein-language-model lens: only for hypothesis generation and target-prioritization, not proof."
        )
        val localKnowledge = listOf(
            "Disease capsules + concept capsules are used as local memory before external lookup.",
            "Structural immunity report integrated as a research-only lens, not as a clinical conclusion.",
            "Final surface must separate confirmed evidence, plausible mechanisms, weak leads, speculative bridges and missing evidence.",
            "Progress percent is runtime progress, not evidence strength.",
            "Candidate handles, metadata seeds and queued checks are not evidence until source/sample/provenance gates close."
        )
        return JSONObject()
            .put("version", VERSION)
            .put("topic", topic.take(180))
            .put("status", status)
            .put("stopReason", stopReason)
            .put("lastSafeStage", lastSafeStage)
            .put("elapsedMillis", elapsedMillis)
            .put("hardCloseMillis", budget.hardTimeoutMillis)
            .put("whyThisReportExists", "The app reached a mobile-safe closure point before heavy final JSON/report rendering. This prevents the REPORT_JSON_ENCODING freeze observed on device.")
            .put("decisionBrief", "Use this compact dossier as the visible output for this pass; deepen through another saved pass instead of one long Android foreground loop.")
            .put("selectedRoute", route)
            .put("workingHypotheses", JSONArray(hypotheses))
            .put("mechanismRoutes", JSONArray(mechanisms))
            .put("localKnowledgeUsed", JSONArray(localKnowledge))
            .put("executedChecks", GTIMAgenticProgressPlanV21324.executedChecksFor(lastSafeStage, elapsedMillis, budget))
            .put("queuedChecks", GTIMAgenticProgressPlanV21324.queuedChecksFor(lastSafeStage, elapsedMillis, budget))
            .put("nextSafeRun", "Repeat the same topic to deepen from local memory, or narrow to one axis such as epithelial barrier memory, microbiome metabolites, NETosis/PANoptosis, Treg tolerance, or single-cell dataset evidence.")
            .put("claimLimit", CLAIM_LIMIT)
    }

    private fun compactReportV3(topic: String, dossier: JSONObject): JSONObject = JSONObject()
        .put("cycleResult", "Compact crash-safe interim dossier created for $topic")
        .put("newUsefulLead", dossier.optString("selectedRoute", "research route selected"))
        .put("hypothesisChanged", "A bounded research route was selected; no evidence grade was upgraded.")
        .put("whyItMatters", "The user receives a useful report before Android can freeze during final JSON encoding or oversized UI rendering.")
        .put("nextAutonomousMove", dossier.optString("nextSafeRun"))
        .put("doNotBelieveYet", "No diagnosis, treatment, dosing, efficacy, biomarker proof, causal proof, or clinical action was established.")
        .put("technicalPointer", "v2.13.26 crash-safe compact report before heavy final closure.")
        .put("hypothesis", dossier.optJSONArray("workingHypotheses")?.optString(0).orEmpty())
        .put("supportingEvidence", "Local concept memory only unless verified sources are present in exported evidence sections.")
        .put("counterEvidenceOrContradiction", "Contradiction search remains queued unless the final evidence pass completed.")
        .put("whatWeDoNotBelieveYet", CLAIM_LIMIT)
        .put("integrityStatus", "COMPACT_INTERIM_NO_EVIDENCE_UPGRADE")

    private fun appendArray(lines: MutableList<String>, arr: JSONArray?, limit: Int) {
        if (arr == null || arr.length() == 0) {
            lines += "• None captured in this compact pass."
            return
        }
        for (i in 0 until minOf(arr.length(), limit)) {
            val text = arr.optString(i).trim()
            if (text.isNotBlank()) lines += "• ${text.take(360)}"
        }
    }
}
