package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.12.18 — practical feasibility score. */
object GTIMStudyFeasibilityScoreV21218 {
    const val VERSION: String = "2.12.18-study-feasibility-score"
    const val CLAIM_LIMIT: String = "feasibility_score_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val provenance = report.optJSONObject("comparatorSampleProvenanceExtractorV21218") ?: JSONObject()
        val capsule = report.optJSONObject("evidenceCapsuleBuilderV21218") ?: JSONObject()
        val mapper = report.optJSONObject("datasetToStudyMapperV21218") ?: JSONObject()
        val components = JSONObject()
            .put("dataAvailability", if (capsule.optString("selectedReviewTarget").isNotBlank()) 2 else 0)
            .put("metadataReadiness", provenance.optInt("readyGateCount", 0).coerceAtMost(4))
            .put("capsuleReadiness", (capsule.optInt("capsuleScore", 0) / 2).coerceAtMost(4))
            .put("contradictionBurden", if ((report.optJSONObject("contradictionSearchEngineV21218")?.optInt("unresolvedConflictCount", 3) ?: 3) <= 2) 1 else 0)
            .put("studyUse", if (mapper.optString("recommendedUse").contains("DISCOVERY")) 1 else 0)
        val total = (components.optInt("dataAvailability") + components.optInt("metadataReadiness") + components.optInt("capsuleReadiness") + components.optInt("contradictionBurden") + components.optInt("studyUse")).coerceAtMost(10)
        val state = when {
            total >= 9 -> "HIGH_FEASIBILITY_STUDY_ROUTE"
            total >= 6 -> "MODERATE_FEASIBILITY_STUDY_ROUTE"
            total >= 3 -> "LOW_MODERATE_FEASIBILITY_NEEDS_DATA"
            else -> "LOW_FEASIBILITY_LOOKUP_ONLY"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("feasibilityScore", total)
            .put("components", components)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Study feasibility score",
        "State: ${obj.optString("state", "UNKNOWN")}; feasibility_score=${obj.optInt("feasibilityScore", 0)}/10.",
        "Drivers: data availability, metadata readiness, capsule readiness, contradiction burden, and study-use label.",
        "Interpretation: high feasibility means the route is easier to study, not that the mechanism is true.",
        "Boundary: feasibility score does not create clinical or therapeutic claims."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "MODERATE_FEASIBILITY_STUDY_ROUTE", "HIGH_FEASIBILITY_STUDY_ROUTE", CLAIM_LIMIT))
}
