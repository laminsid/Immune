package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Research modality classifier. It is not a treatment recommendation. */
object GTIMTherapeuticModalityLensV21318 {
    const val VERSION: String = "2.13.18-therapeutic-modality-lens"
    const val CLAIM_LIMIT: String = "therapeutic_modality_lens_is_research_direction_not_treatment_recommendation"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val modalities = modalitiesFor(active)
        return JSONObject()
            .put("version", VERSION)
            .put("active_domain", active)
            .put("modalities", JSONArray(modalities))
            .put("research_direction_only", true)
            .put("validated_treatment_claim_allowed", false)
            .put("dosing_or_patient_action_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun modalitiesFor(activeDomain: String): List<String> = when (activeDomain) {
        "rheumatoid_autoimmune_synovial_inflammation", "allergy_type2_barrier" -> listOf("biologic", "cell_therapy", "CAR_Treg", "diagnostic_biomarker")
        "oncology_tumor_microenvironment" -> listOf("antibody", "cell_therapy", "biologic", "digital_antibody_design", "diagnostic_biomarker")
        "viral_interferon_cytokine", "filovirus_viral_host_response", "viral_hantavirus_host_response" -> listOf("antibody", "vaccine_or_innate_training", "digital_antibody_design", "diagnostic_biomarker")
        "hiv_aids_immune_activation" -> listOf("antibody", "small_molecule", "diagnostic_biomarker", "immune_exhaustion_modulation_lens")
        "metabolic_inflammation", "immune_age_longevity", "inflammation_resolution" -> listOf("small_molecule", "microbiome_modulation", "diagnostic_biomarker", "vaccine_or_innate_training")
        else -> listOf("diagnostic_biomarker", "research_modality_to_be_selected")
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Therapeutic modality lens",
            "Research modalities: ${obj.optJSONArray("modalities") ?: JSONArray()}",
            "Modality policy: research_direction_only=${obj.optBoolean("research_direction_only")}; validated_treatment_claim_allowed=${obj.optBoolean("validated_treatment_claim_allowed")}; dosing_or_patient_action_allowed=${obj.optBoolean("dosing_or_patient_action_allowed")}",
            "Boundary: ${obj.optString("claim_limit")}."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "small_molecule",
        "biologic",
        "cell_therapy",
        "CAR_Treg",
        "antibody",
        "vaccine_or_innate_training",
        "microbiome_modulation",
        "diagnostic_biomarker",
        "digital_antibody_design",
        CLAIM_LIMIT
    ))
}
