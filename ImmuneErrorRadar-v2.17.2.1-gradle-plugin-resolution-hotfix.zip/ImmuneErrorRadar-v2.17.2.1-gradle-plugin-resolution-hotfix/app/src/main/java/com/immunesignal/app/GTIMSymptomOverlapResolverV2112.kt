package com.immunesignal.app

// v2.11.2 — Resolves shared symptoms into competing dysfunction hypotheses.
object GTIMSymptomOverlapResolverV2112 {
    const val VERSION: String = "2.11.2-symptom-overlap-resolver"
    const val PRINCIPLE: String = "symptoms_are_overlap_signals_not_disease_identity_map_dysfunction_before_naming_disease"
    const val BOUNDARY: String = "symptom_overlap_outputs_are_research_triage_not_diagnosis_not_patient_advice"

    fun resolve(
        contract: GTIMRunDecisionContractV2740,
        corpus: String,
        candidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
        ecologicalRestoration: GTIMEcologicalRestorationReportV2112
    ): GTIMSymptomOverlapReportV2112 {
        val clusters = buildClusters(contract, corpus)
        val nodes = GTIMDysfunctionHypothesisGraphV2112.build(corpus, candidates, ecologicalRestoration)
        val evidence = GTIMDiscriminatingEvidencePlannerV2112.plan(nodes)
        val shared = GTIMSharedRootMechanismMapperV2112.map(nodes)
        val routes = GTIMRestorativeFunctionSearchV2112.search(nodes)
        val state = when {
            nodes.size >= 3 -> "SYMPTOM_OVERLAP_MULTI_DYSFUNCTION_MAP_READY"
            nodes.any { it.nodeId == "OPEN_DYSFUNCTION_NODE" } -> "SYMPTOM_OVERLAP_OPEN_DYSFUNCTION_SCAN"
            else -> "SYMPTOM_OVERLAP_DYSFUNCTION_MAP_READY"
        }
        val line = "Symptom overlap resolver: version=$VERSION | state=$state | principle=$PRINCIPLE | clusters=${clusters.size} | dysfunction_nodes=${nodes.size} | discriminating_evidence=${evidence.size} | repair_routes=${routes.size} | boundary=$BOUNDARY"
        return GTIMSymptomOverlapReportV2112(true, VERSION, state, PRINCIPLE, clusters, nodes, evidence, shared, routes, BOUNDARY, line)
    }

    private fun buildClusters(contract: GTIMRunDecisionContractV2740, corpus: String): List<GTIMSymptomOverlapClusterV2112> {
        val text = (contract.rawQuery + " " + contract.normalizedQuery + " " + corpus).lowercase()
        val symptoms = listOf("fatigue", "fever", "pain", "joint", "rash", "brain fog", "weakness", "gut", "diarrhea", "inflammation", "cough", "skin", "nerve").filter { text.contains(it) }
            .ifEmpty { listOf("non_specific_or_topic_derived_signals") }
        val families = mutableListOf("immune_inflammatory", "infectious_or_post_infectious", "metabolic_or_mitochondrial", "microbiome_barrier", "exposome_environmental")
        if (text.contains("neuro") || text.contains("brain") || text.contains("nerve")) families += "neuroimmune"
        val line = "Symptom overlap cluster: version=$VERSION | id=SYMPTOM_CLUSTER_PRIMARY | symptoms=${symptoms.joinToString(";").oneLine()} | families=${families.distinct().joinToString(";").oneLine()} | claim_limit=symptoms_do_not_identify_disease"
        return listOf(GTIMSymptomOverlapClusterV2112("SYMPTOM_CLUSTER_PRIMARY", symptoms, families.distinct(), "symptoms_do_not_identify_disease", line))
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
