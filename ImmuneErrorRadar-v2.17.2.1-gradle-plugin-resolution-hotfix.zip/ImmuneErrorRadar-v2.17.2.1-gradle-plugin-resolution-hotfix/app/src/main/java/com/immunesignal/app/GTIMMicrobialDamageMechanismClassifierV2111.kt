package com.immunesignal.app

// v2.11.1 — Classifies harm mechanisms for microbial counter-function discovery.
object GTIMMicrobialDamageMechanismClassifierV2111 {
    const val VERSION: String = "2.11.1-microbial-damage-mechanism-classifier"

    fun classify(
        contract: GTIMRunDecisionContractV2740,
        corpus: String,
        rootCandidates: List<GTIMEcoImmuneRootCauseCandidateV2108>
    ): List<GTIMMicrobialDamageMechanismV2111> {
        val mechanisms = mutableListOf<GTIMMicrobialDamageMechanismV2111>()
        val joinedRoots = rootCandidates.joinToString(" ") { it.upstreamDysfunction + " " + it.causalChain + " " + it.restorationNeed }.lowercase()
        val text = (corpus + " " + joinedRoots).lowercase()

        if (hasAny(text, listOf("pathogen", "bacteria", "c difficile", "infection", "biofilm", "staphyl", "salmonella", "h pylori", "dysbiosis"))) {
            mechanisms += mechanism(
                id = "pathogen_or_dysbiosis_dominance",
                damageClass = "microbial_dominance_or_biofilm_damage",
                harmful = "pathogen/dysbiosis dominance may occupy an ecological niche, produce toxins, protect itself through biofilm, or keep immune activation persistent",
                topic = contract.primaryAnchor.routeId,
                confidence = "MECHANISM_PLAUSIBLE_RESEARCH_ONLY"
            )
        }
        if (hasAny(text, listOf("toxin", "pfas", "plastic", "microplastic", "nanoplastic", "pollution", "heavy metal", "bpa", "phthalate", "exposome"))) {
            mechanisms += mechanism(
                id = "toxin_or_exposome_burden",
                damageClass = "external_or_internal_toxin_pressure",
                harmful = "chemical, particle, or microbial toxin pressure may alter barrier integrity, immune tone, oxidative stress, or microbial ecology",
                topic = contract.primaryAnchor.routeId,
                confidence = "EXPOSOME_ROUTE_PLAUSIBLE_REQUIRES_MEASUREMENT"
            )
        }
        if (hasAny(text, listOf("barrier", "mucosal", "permeability", "gut", "skin", "lung", "mucus", "epithelial", "tight junction"))) {
            mechanisms += mechanism(
                id = "barrier_ecology_failure",
                damageClass = "barrier_and_entry_surface_failure",
                harmful = "barrier or mucosal failure may let exposure, antigens, microbes, or inflammatory signals persist beyond the intended compartment",
                topic = contract.primaryAnchor.routeId,
                confidence = "BARRIER_ROUTE_PLAUSIBLE_RESEARCH_ONLY"
            )
        }
        if (hasAny(text, listOf("autoimmune", "allergy", "asthma", "ige", "mast", "cytokine", "th17", "treg", "tolerance", "inflammation", "immune over"))) {
            mechanisms += mechanism(
                id = "immune_decision_error",
                damageClass = "maladaptive_immune_decision_or_tolerance_loss",
                harmful = "immune decision error may convert protective response into chronic inflammation, allergy, autoimmunity, or tissue-damaging cytokine loops",
                topic = contract.primaryAnchor.routeId,
                confidence = "IMMUNE_RETRAINING_ROUTE_PLAUSIBLE_RESEARCH_ONLY"
            )
        }
        if (hasAny(text, listOf("neuro", "brain", "microglia", "alzheimer", "paralysis", "blind", "retina", "nerve", "demyelin", "tau", "amyloid"))) {
            mechanisms += mechanism(
                id = "neuroimmune_tissue_damage_loop",
                damageClass = "neuroimmune_or_tissue_decline_loop",
                harmful = "peripheral inflammation, microbial metabolites, barrier stress, or immune miscalibration may contribute to neuroimmune or tissue-decline loops",
                topic = contract.primaryAnchor.routeId,
                confidence = "LONG_HORIZON_HYPOTHESIS_REQUIRES_STRONG_FALSIFICATION"
            )
        }
        if (hasAny(text, listOf("metabolic", "metabolism", "insulin", "glucose", "mitochond", "scfa", "butyrate", "bile", "lactate", "lipid"))) {
            mechanisms += mechanism(
                id = "metabolic_conversion_gap",
                damageClass = "missing_or_wrong_metabolite_conversion",
                harmful = "missing microbial or host-microbial conversion may shift immune energy, metabolite signaling, bile-acid tone, or repair capacity",
                topic = contract.primaryAnchor.routeId,
                confidence = "METABOLITE_ROUTE_PLAUSIBLE_RESEARCH_ONLY"
            )
        }

        if (mechanisms.isEmpty()) {
            mechanisms += mechanism(
                id = "open_microbiome_counter_mechanism_scan",
                damageClass = "open_damage_mechanism",
                harmful = "topic has no dominant microbial damage mechanism yet; keep function-first microbial reversal as an exploratory root-cause scan",
                topic = contract.primaryAnchor.routeId,
                confidence = "OPEN_SCAN_WEAK_BUT_USEFUL"
            )
        }
        return mechanisms.distinctBy { it.mechanismId }.take(7)
    }

    private fun mechanism(id: String, damageClass: String, harmful: String, topic: String, confidence: String): GTIMMicrobialDamageMechanismV2111 {
        val line = "Microbial damage mechanism: version=$VERSION | id=$id | class=$damageClass | confidence=$confidence | topic=$topic | harmful_mechanism=${harmful.oneLine()}"
        return GTIMMicrobialDamageMechanismV2111(id, damageClass, harmful, topic, confidence, line)
    }

    private fun hasAny(text: String, tokens: List<String>): Boolean = tokens.any { text.contains(it.lowercase()) }
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
