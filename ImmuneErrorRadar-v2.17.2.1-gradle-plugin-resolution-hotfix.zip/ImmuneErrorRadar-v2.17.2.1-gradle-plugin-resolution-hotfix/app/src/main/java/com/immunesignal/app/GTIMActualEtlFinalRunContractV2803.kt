package com.immunesignal.app

/**
 * v2.8.3 — Final actual ETL execution closure.
 *
 * This is the last review-only decision surface after concrete ETL readiness:
 * observed repository files, matrix classification, sample metadata, case/control
 * suggestions and sample-ID linkage must all close before a DGE run is merely
 * allowed to be queued. It never fabricates DGE values and never emits clinical
 * or treatment claims.
 */
data class GTIMActualEtlFinalRunReportV2803(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val dgeQueueState: String,
    val firstBlockingGate: String,
    val closedGates: List<String>,
    val openGates: List<String>,
    val summaryLine: String,
    val executionOrderLine: String,
    val stopRuleLine: String,
    val boundaryLine: String
)

object GTIMActualEtlFinalRunContractV2803 {
    const val VERSION: String = "2.8.3-actual-etl-final-run-contract"

    private val GATE_ORDER = listOf(
        "P0_TOPIC_COMPATIBLE_TARGET",
        "P1_OBSERVED_FILE_EVIDENCE",
        "P2_MATRIX_FILE_CLASSIFICATION",
        "P3_SAMPLE_METADATA_EXTRACTION",
        "P4_CASE_CONTROL_EVIDENCE",
        "P5_SAMPLE_ID_LINKAGE",
        "P6_REVIEW_ONLY_DGE_QUEUE"
    )

    fun build(actual: GTIMActualEtlExecutionReportV2800): GTIMActualEtlFinalRunReportV2803 {
        val open = mutableListOf<String>()
        val closed = mutableListOf<String>()

        fun gate(name: String, ok: Boolean) {
            if (ok) closed += name else open += name
        }

        val topicTargetOk = actual.fileDiscovery.state != "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET" &&
            !actual.targetId.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", ignoreCase = true)
        val observedFileOk = actual.observedFileEvidence.state == "OBSERVED_FILE_EVIDENCE_COMPLETE_REVIEW_ONLY"
        val matrixClassifiedOk = actual.matrixFileClassifier.state == "MATRIX_FILE_CLASSIFIED_REVIEW_ONLY"
        val metadataOk = actual.sampleMetadataExtraction.state == "SAMPLE_METADATA_EXTRACTED_REVIEW_ONLY"
        val labelsOk = actual.caseControlLabelSuggestions.state == "CASE_CONTROL_LABELS_SUGGESTED_WITH_EVIDENCE"
        val linkageOk = actual.sampleIdLinkageVerification.state == "SAMPLE_ID_LINKAGE_CONFIRMED_REVIEW_ONLY"
        val verdictOk = actual.dgeReadinessVerdict.verdict == "DGE_READY_REVIEW_ONLY_NOT_RUN"

        gate("P0_TOPIC_COMPATIBLE_TARGET", topicTargetOk)
        gate("P1_OBSERVED_FILE_EVIDENCE", observedFileOk)
        gate("P2_MATRIX_FILE_CLASSIFICATION", matrixClassifiedOk)
        gate("P3_SAMPLE_METADATA_EXTRACTION", metadataOk)
        gate("P4_CASE_CONTROL_EVIDENCE", labelsOk)
        gate("P5_SAMPLE_ID_LINKAGE", linkageOk)
        gate("P6_REVIEW_ONLY_DGE_QUEUE", verdictOk)

        val firstBlock = open.firstOrNull() ?: "NONE"
        val state = when {
            !topicTargetOk -> "FINAL_ETL_STOP_NO_TOPIC_COMPATIBLE_TARGET"
            !observedFileOk -> "FINAL_ETL_STOP_OBSERVED_FILE_EVIDENCE_REQUIRED"
            !matrixClassifiedOk -> "FINAL_ETL_STOP_MATRIX_FILE_NOT_CLASSIFIED"
            !metadataOk -> "FINAL_ETL_STOP_SAMPLE_METADATA_NOT_EXTRACTED"
            !labelsOk -> "FINAL_ETL_STOP_CASE_CONTROL_EVIDENCE_REQUIRED"
            !linkageOk -> "FINAL_ETL_STOP_SAMPLE_ID_LINKAGE_NOT_CONFIRMED"
            verdictOk -> "FINAL_ETL_READY_REVIEW_ONLY_DGE_NOT_RUN"
            else -> "FINAL_ETL_STOP_REVIEW_ONLY_DGE_QUEUE_NOT_READY"
        }
        val dgeQueue = if (state == "FINAL_ETL_READY_REVIEW_ONLY_DGE_NOT_RUN") {
            "QUEUE_REVIEW_ONLY_DGE_ALLOWED_NOT_EXECUTED"
        } else {
            "QUEUE_REVIEW_ONLY_DGE_BLOCKED"
        }

        val summary = "Actual ETL final run contract: version=$VERSION | state=$state | target=${actual.targetId} | dge_queue=$dgeQueue | first_blocking_gate=$firstBlock | closed_gates=${closed.joinToString(",")} | open_gates=${open.ifEmpty { listOf("none") }.joinToString(",")}"
        val order = "Actual ETL final order: ${GATE_ORDER.joinToString(" -> ")} | current_stop=$firstBlock | review_only=true"
        val stop = "Actual ETL final stop rules: no_topic_target_blocks_files=true | observed_files_required=true | matrix_classification_required=true | metadata_and_evidence_snippets_required=true | sample_id_linkage_required=true | no_dge_values_produced=true | no_gene_pathway_claim_without_dge_output=true"
        val boundary = "Actual ETL final boundary: readiness verdict only; DGE may be queued for human review after all gates close, but this layer does not compute expression values, pathways, treatment efficacy, dosing, diagnosis, or patient-care instructions."

        return GTIMActualEtlFinalRunReportV2803(
            active = true,
            targetId = actual.targetId,
            state = state,
            dgeQueueState = dgeQueue,
            firstBlockingGate = firstBlock,
            closedGates = closed,
            openGates = open,
            summaryLine = normalize(summary),
            executionOrderLine = normalize(order),
            stopRuleLine = normalize(stop),
            boundaryLine = normalize(boundary)
        )
    }

    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
