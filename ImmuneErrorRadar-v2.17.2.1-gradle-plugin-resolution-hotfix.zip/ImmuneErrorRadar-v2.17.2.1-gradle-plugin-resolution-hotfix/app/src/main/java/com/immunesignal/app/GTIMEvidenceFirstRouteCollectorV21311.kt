package com.immunesignal.app

object GTIMEvidenceFirstRouteCollectorV21311 {
    fun collect(entities: List<String>, handles: List<String>): List<GTIMRouteCandidateV21311> {
        val e = entities.toSet()
        val h = handles.map { it.uppercase() }.toSet()
        val candidates = mutableListOf<GTIMRouteCandidateV21311>()
        fun add(route: String, subtype: String, semantic: Double, evidence: Double, dataset: Double, reasons: List<String>) {
            // Semantic fit dominates dataset availability. A strong wrong capsule may help a route,
            // but it cannot beat a weaker correct pathogen/domain route.
            val score = (semantic * 0.62) + (evidence * 0.25) + (dataset * 0.13)
            candidates += GTIMRouteCandidateV21311(route, subtype, score.coerceIn(0.0, 1.0), semantic, evidence, dataset, reasons)
        }
        val bdbv = "BDBV" in e
        val filovirus = "FILOVIRUS" in e || "EBOLA" in e || bdbv
        val covid = "COVID" in e
        val viral = "VIRAL_HOST_RESPONSE" in e || filovirus || covid
        val depression = "DEPRESSION" in e || "KYNURENINE" in e
        val allergy = "ALLERGY_TYPE2" in e
        val cancer = "CANCER_TME" in e
        val metabolic = "METABOLIC_INFLAMMATION" in e

        if (bdbv) add(
            "filovirus_viral_host_response", "viral_filovirus_bundibugyo",
            0.98, 0.82, if (h.any { it.startsWith("BDBV") }) 0.65 else 0.10,
            listOf("Bundibugyo/BDBV entity matched", "pathogen-specific route outranks generic viral capsules")
        )
        if (filovirus && !bdbv) add(
            "filovirus_viral_host_response", "viral_filovirus",
            0.92, 0.78, if ("GSE45291" in h) 0.75 else 0.20,
            listOf("Ebola/filovirus entity matched", "filovirus-compatible datasets only")
        )
        if (covid) add(
            "viral_interferon_cytokine", "viral_covid_postviral",
            0.88, 0.72, if ("GSE166552" in h) 0.90 else 0.35,
            listOf("COVID/post-viral entity matched", "COVID capsule may be used only after route lock")
        )
        if (viral) add(
            "viral_interferon_cytokine", if (covid) "viral_covid_postviral" else "viral_generic_host_response",
            if (filovirus && !covid) 0.50 else 0.72,
            0.64,
            if (h.intersect(setOf("GSE166552", "GSE152202", "GSE152418", "GSE157103")).isNotEmpty()) 0.80 else 0.25,
            listOf("generic viral/IFN-cytokine context", "generic route cannot override pathogen-specific fit")
        )
        if (depression) add(
            "depression_kynurenine_neuroimmune", "nonviral_or_unspecified",
            if ("KYNURENINE" in e) 0.92 else 0.72,
            0.74,
            if ("GSE102556" in h) 0.90 else 0.25,
            listOf("depression/kynurenine entity matched", "IDO1/KMO route considered before microbiome fallback")
        )
        if (allergy) add(
            "allergy_type2_barrier", "nonviral_or_unspecified",
            0.88, 0.70, if ("GSE146170" in h) 0.88 else 0.25,
            listOf("type-2/allergy entity matched", "barrier/microbiome only where supported")
        )
        if (cancer) add(
            "cancer_immune_tumor_microenvironment", "nonviral_or_unspecified",
            0.86, 0.68, if ("GSE131907" in h) 0.35 else 0.20,
            listOf("cancer/TME entity matched", "expanded disease corpus cannot hijack unrelated topics")
        )
        if (metabolic) add(
            "metabolic_inflammation", "nonviral_or_unspecified",
            0.82, 0.62, 0.20,
            listOf("metabolic inflammation entity matched", "requires compatible dataset before canonical target")
        )
        if (candidates.isEmpty()) add(
            "unknown_topic_evidence_discovery", "unknown_or_insufficient_context",
            0.30, 0.25, 0.0,
            listOf("no confident route entities found", "keep topic-level route and do not reuse previous target")
        )
        return candidates.sortedByDescending { it.score }
    }
}
