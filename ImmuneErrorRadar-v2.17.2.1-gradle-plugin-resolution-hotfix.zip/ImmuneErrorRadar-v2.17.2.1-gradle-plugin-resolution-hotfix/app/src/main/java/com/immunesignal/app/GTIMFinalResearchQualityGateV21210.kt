package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * Compatibility wrapper for v2.12.10.
 *
 * The old "quality gate" name is retained only so older audits and JSON consumers do not
 * break. It delegates to the non-blocking v2.12.10.1 value booster. Do not use this layer
 * as a blocking gate.
 */
object GTIMFinalResearchQualityGateV21210 {
    const val VERSION: String = "2.12.10-compat-wrapper-non-blocking-value-booster"
    const val CLAIM_LIMIT: String = "value_booster_only_no_evidence_upgrade_no_blocking"

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> =
        GTIMFinalResearchValueBoosterV212101.publicLines(report, technicalLines)

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject =
        GTIMFinalResearchValueBoosterV212101.toJson(report, technicalLines)
            .put("compatibilityKey", "finalResearchQualityGateV21210")
            .put("compatibilityMode", "delegates_to_non_blocking_value_booster")

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "GTIMFinalResearchValueBoosterV212101",
        "delegates_to_non_blocking_value_booster",
        CLAIM_LIMIT
    ))
}
