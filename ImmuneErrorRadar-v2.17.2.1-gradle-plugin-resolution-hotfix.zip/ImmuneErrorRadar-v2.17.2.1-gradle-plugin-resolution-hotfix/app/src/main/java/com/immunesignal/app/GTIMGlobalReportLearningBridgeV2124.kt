package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.12.4 — Global report learning and cross-run linkage.
 *
 * Same-topic deepening is not enough. This bridge reads prior reports and turns them
 * into cross-run memory: repeated mechanisms, blockers, handles, and functional repair
 * routes. It remains research-only and never treats recurrence as proof.
 */
object GTIMGlobalReportLearningBridgeV2124 {
    const val VERSION: String = "2.12.4-global-report-learning-cross-run-linkage"
    const val CLAIM_LIMIT: String = "cross_report_learning_not_biological_proof"

    data class GlobalLearningReportV2124(
        val active: Boolean,
        val reportsUsed: Int,
        val repeatedMechanisms: List<String>,
        val repeatedBlockers: List<String>,
        val crossDiseaseBridges: List<String>,
        val carriedHandles: List<String>,
        val nextResearchMove: String,
        val boundary: String
    )

    fun build(current: JSONObject, previousReports: List<JSONObject>): GlobalLearningReportV2124 {
        val reports = (listOf(current) + previousReports).take(60)
        val texts = reports.map { it.toString() }
        val mechanisms = mechanismCounts(texts).filter { it.value >= 2 }.keys.toList().take(8)
        val blockers = blockerCounts(texts).filter { it.value >= 2 }.keys.toList().take(8)
        val handles = texts.flatMap { extractHandles(it) }.distinct().take(12)
        val bridges = buildBridges(texts, mechanisms).take(8)
        val next = when {
            blockers.any { it.contains("matrix", true) } -> "Repeated blocker is matrix/file evidence. Run Matrix Shortcut Resolver first, then use external evidence capsule review before another raw-matrix hunt."
            mechanisms.any { it.contains("microbiome", true) } -> "Repeated mechanism is microbiome/barrier/inflammatory tone. Build cross-condition validation ladder before narrowing to one disease."
            handles.isNotEmpty() -> "Carry forward accession handles and test whether they are topic-compatible, matrix-accessible, and comparator-labeled."
            else -> "Accumulate at least two comparable reports, then link mechanisms, blockers, targets, and repair functions."
        }
        return GlobalLearningReportV2124(
            active = reports.size >= 1,
            reportsUsed = reports.size,
            repeatedMechanisms = mechanisms,
            repeatedBlockers = blockers,
            crossDiseaseBridges = bridges,
            carriedHandles = handles,
            nextResearchMove = next,
            boundary = CLAIM_LIMIT
        )
    }

    fun publicLines(report: JSONObject): List<String> {
        val obj = report.optJSONObject("globalReportLearningV2124") ?: return emptyList()
        val mechanisms = jsonArray(obj.optJSONArray("repeatedMechanisms")).take(6)
        val blockers = jsonArray(obj.optJSONArray("repeatedBlockers")).take(6)
        val bridges = jsonArray(obj.optJSONArray("crossDiseaseBridges")).take(5)
        val handles = jsonArray(obj.optJSONArray("carriedHandles")).take(6)
        return listOf(
            "Global report learning",
            "Learning state: reports_used=${obj.optInt("reportsUsed", 1)}; cross-run memory links prior reports, routes, blockers, and functional repair hypotheses.",
            "Repeated mechanisms: ${mechanisms.joinToString(", ").ifBlank { "not enough recurrence yet" }}.",
            "Repeated blockers: ${blockers.joinToString(", ").ifBlank { "not enough recurrence yet" }}.",
            "Cross-report bridges: ${bridges.joinToString(" | ").ifBlank { "no strong cross-disease bridge yet" }}.",
            "Carried handles: ${handles.joinToString(", ").ifBlank { "none yet" }}.",
            "Next global move: ${obj.optString("nextResearchMove", "continue evidence-capsule learning")}",
            "Learning boundary: ${obj.optString("claimLimit", CLAIM_LIMIT)}. Recurrence across reports is a research signal, not proof."
        )
    }

    fun toJson(current: JSONObject, previousReports: List<JSONObject>): JSONObject {
        val g = build(current, previousReports)
        return JSONObject()
            .put("version", VERSION)
            .put("active", g.active)
            .put("reportsUsed", g.reportsUsed)
            .put("repeatedMechanisms", JSONArray(g.repeatedMechanisms))
            .put("repeatedBlockers", JSONArray(g.repeatedBlockers))
            .put("crossDiseaseBridges", JSONArray(g.crossDiseaseBridges))
            .put("carriedHandles", JSONArray(g.carriedHandles))
            .put("nextResearchMove", g.nextResearchMove)
            .put("claimLimit", g.boundary)
    }

    private fun mechanismCounts(texts: List<String>): Map<String, Int> {
        val dictionary = listOf(
            "IL-6/TNF inflammatory tone" to listOf("il-6", "tnf"),
            "interferon/cytokine timing" to listOf("interferon", "cytokine"),
            "microbiome/barrier dysfunction" to listOf("microbiome", "barrier", "gut"),
            "tryptophan/kynurenine neuroimmune route" to listOf("tryptophan", "kynurenine"),
            "IgE/mast-cell/eosinophil type-2 axis" to listOf("ige", "mast", "eosinophil"),
            "metabolic inflammation" to listOf("metabolic", "diabetes", "insulin"),
            "endothelial injury / vascular immune stress" to listOf("endothelial", "vascular"),
            "functional repair / biological tool route" to listOf("functional repair", "biological tool", "microbial")
        )
        return dictionary.associate { (label, terms) -> label to texts.count { text -> terms.any { text.contains(it, true) } } }
    }

    private fun blockerCounts(texts: List<String>): Map<String, Int> {
        val dictionary = listOf(
            "matrix/file evidence missing" to listOf("matrix", "file evidence", "raw/count"),
            "comparator labels missing" to listOf("comparator"),
            "sample-ID linkage missing" to listOf("sample-id", "sample id", "source-to-sample"),
            "topic-compatible target not accepted" to listOf("no topic-compatible", "target: blocked"),
            "DGE review not run" to listOf("dge_not_ready", "dge not run", "DGE_BLOCKED"),
            "contradiction check incomplete" to listOf("contradiction")
        )
        return dictionary.associate { (label, terms) -> label to texts.count { text -> terms.any { text.contains(it, true) } } }
    }

    private fun buildBridges(texts: List<String>, mechanisms: List<String>): List<String> {
        val joined = texts.joinToString(" ").lowercase(Locale.US)
        val bridges = mutableListOf<String>()
        if (joined.contains("covid") && joined.contains("ebola")) bridges += "viral host-response bridge: interferon/cytokine timing across COVID/Ebola-style routes"
        if (joined.contains("allergy") && (joined.contains("microbiome") || joined.contains("gut"))) bridges += "barrier/microbiome bridge: allergy route may share epithelial-barrier and immune-tolerance repair functions"
        if (joined.contains("depression") && (joined.contains("microbiome") || joined.contains("kynurenine"))) bridges += "neuroimmune bridge: microbiome/metabolite route may connect depression, inflammation, and cytokine tone"
        if (mechanisms.any { it.contains("IL-6", true) } && mechanisms.any { it.contains("microbiome", true) }) bridges += "shared repair hypothesis: barrier/metabolite restoration may reduce inflammatory amplification across conditions"
        if (bridges.isEmpty() && mechanisms.isNotEmpty()) bridges += "emerging mechanism recurrence: ${mechanisms.take(3).joinToString(" + ")}"
        return bridges.distinct()
    }

    private fun extractHandles(text: String): List<String> = Regex("\\b(GSE\\d{3,}|PRJNA\\d+|SRP\\d+|SRR\\d+|SDY\\d+|E-MTAB-\\d+)\\b", RegexOption.IGNORE_CASE)
        .findAll(text).map { it.value.uppercase(Locale.US) }.toList()

    private fun jsonArray(arr: JSONArray?): List<String> = if (arr == null) emptyList() else (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { v -> v.isNotBlank() } }
}
