package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.5 — Discovery Candidate assembler.
 * Consolidates canonical target, capsule, module signals, countermeasure context,
 * novelty/replication/negative-control checks, and claim ladder into a single object.
 */
object GTIMDiscoveryCandidateAssemblerV2135 {
    const val VERSION: String = "2.13.5-discovery-candidate-assembler"
    const val CLAIM_LIMIT: String = "discovery_candidate_not_validated_scientific_claim"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val canonical = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val moduleJson = report.optJSONObject("immuneModuleSignalEngineV2135") ?: GTIMImmuneModuleSignalEngineV2135.toJson(report)
        val exec = report.optJSONObject("discoveryExecutionEnginesV2135") ?: GTIMDiscoveryExecutionEnginesV2135.toJson(report)
        val ladder = report.optJSONObject("discoveryClaimLadderV2135") ?: GTIMDiscoveryClaimLadderV2135.toJson(report)
        val counter = report.optJSONObject("countermeasureSeedDatabaseV2135") ?: GTIMCountermeasureSeedDatabaseV2135.toJson(report)
        val signals = moduleJson.optJSONArray("moduleSignals") ?: JSONArray()
        val datasetSignals = mutableListOf<GTIMDatasetSignalV2135>()
        for (i in 0 until signals.length()) {
            val s = signals.optJSONObject(i) ?: continue
            datasetSignals += GTIMDatasetSignalV2135(
                datasetId = canonical.ifBlank { "not_selected" },
                domain = active,
                moduleId = s.optString("moduleId", "unknown_module"),
                direction = s.optString("direction", "to_test_not_observed"),
                signalState = s.optString("signalState", "candidate"),
                comparatorState = exec.optString("comparatorGate", "unknown"),
                provenanceState = exec.optString("provenanceGate", "unknown"),
                boundary = GTIMImmuneModuleSignalEngineV2135.CLAIM_LIMIT
            )
        }
        val candidate = GTIMDiscoveryCandidateV2135(
            domain = active,
            canonicalTarget = canonical.ifBlank { "not_selected" },
            claimCandidate = claimFor(active, canonical, datasetSignals.map { it.moduleId }),
            signalType = "immune_module_signal_candidate",
            datasetSignals = datasetSignals,
            replicationStatus = exec.optString("replicationStatus", "replication_not_closed"),
            negativeControlStatus = "negative_controls_required_before_C2_or_higher",
            confounderStatus = "confounder_guard_required_before_C2_or_higher",
            noveltyClass = exec.optString("noveltyClass", "unknown"),
            discoveryLevel = ladder.optString("discoveryLevel", "C0_ROUTE_ONLY"),
            falsifiers = listOf(
                "module signal fails comparator separation",
                "sample provenance cannot be verified",
                "signal is batch/platform/cell-composition artifact",
                "replication dataset reverses or loses the signal",
                "literature search shows the claim is already established without novelty"
            ),
            claimBoundary = CLAIM_LIMIT
        )
        return JSONObject()
            .put("version", VERSION)
            .put("state", "DISCOVERY_CANDIDATE_OBJECT_READY")
            .put("candidate", candidate.toJson())
            .put("countermeasureContext", counter.optJSONArray("matchedSeeds") ?: JSONArray())
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val c = obj.optJSONObject("candidate") ?: JSONObject()
        val signals = c.optJSONArray("datasetSignals") ?: JSONArray()
        return listOf(
            "Discovery Candidate Card",
            "Candidate claim: ${c.optString("claimCandidate", "no discovery candidate assembled")}",
            "Discovery level: ${c.optString("discoveryLevel", "C0_ROUTE_ONLY")}; canonical_target=${c.optString("canonicalTarget", "none")}; signals=${signals.length()}.",
            "Replication: ${c.optString("replicationStatus", "not closed")}; novelty=${c.optString("noveltyClass", "unknown")}; negative_control=${c.optString("negativeControlStatus", "required")}",
            "Why it may fail: ${jsonStrings(c.optJSONArray("falsifiers")).take(3).joinToString("; ")}",
            "Boundary: candidate language only; no diagnosis, treatment, dosing, vaccine advice, efficacy, or validated discovery claim."
        )
    }

    private fun claimFor(domain: String, target: String, modules: List<String>): String = when {
        domain.contains("allergy") -> "Allergy/type-2 candidate: ${target.ifBlank { "selected capsule" }} may support testing whether ${modules.take(3).joinToString(" + ")} stratifies type-2 threshold instability."
        domain.contains("filovirus") -> "Filovirus candidate: ${target.ifBlank { "selected capsule" }} may support testing whether interferon/endothelial/coagulation modules stratify severe host-response states."
        domain.contains("viral") -> "Post-viral candidate: ${target.ifBlank { "selected capsule" }} may support testing whether interferon timing and IL-6/TNF modules stratify severity, recovery, or persistence."
        domain.contains("depression") -> "Depression/kynurenine candidate: ${target.ifBlank { "selected capsule" }} may support testing whether IDO1/KMO-kynurenine and inflammatory modules define a subgroup."
        else -> "Open immune candidate: ${target.ifBlank { "selected capsule" }} may support testing a domain-specific module against comparator labels."
    }

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { array.optString(it).takeIf { s -> s.isNotBlank() } }
}
