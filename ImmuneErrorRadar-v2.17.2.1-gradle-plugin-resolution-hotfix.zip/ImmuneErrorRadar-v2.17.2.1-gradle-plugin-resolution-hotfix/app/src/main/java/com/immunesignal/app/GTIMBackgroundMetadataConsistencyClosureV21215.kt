package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.12.15 — Final consistency closure for counters, domain seeds, and metadata probes. */
object GTIMBackgroundMetadataConsistencyClosureV21215 {
    const val VERSION: String = "2.12.15-background-metadata-consistency-closure"
    const val RELEASE_NAME: String = "2.12.15-final-background-metadata-consistency-unified"
    const val CLAIM_LIMIT: String = "background_metadata_consistency_closure_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: GTIMCandidateHandleLedgerV21215.toJson(report)
        val probe = report.optJSONObject("metadataProbeBackgroundWorkersV21215") ?: JSONObject()
        val demotedCount = ledger.optJSONArray("demotedCrossDomainSeeds")?.length() ?: 0
        val executedCount = probe.optJSONArray("executedSteps")?.length() ?: 0
        val ready = ledger.optBoolean("topicCompatibleTargetSelected", false) || ledger.optInt("candidateHandleCount", 0) > 0 || executedCount > 0
        return JSONObject()
            .put("version", VERSION)
            .put("release", RELEASE_NAME)
            .put("state", if (ready) "BACKGROUND_METADATA_CONSISTENCY_READY" else "BACKGROUND_METADATA_CONSISTENCY_NEEDS_MORE_INPUT")
            .put("candidateCountersUnified", true)
            .put("seedDomainConsistencyGate", if (demotedCount > 0) "CROSS_DOMAIN_SEEDS_DEMOTED" else "NO_CROSS_DOMAIN_SEED_LEAK")
            .put("backgroundWorkers", probe.optString("state", "NOT_ATTACHED"))
            .put("executedVsQueuedSeparated", true)
            .put("utilityScoreHardCapsRequired", true)
            .put("oldRoutesStillLinked", "ETL_DGE_external_router_matrix_shortcut_curated_seed_terminal_continuation")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Background metadata consistency closure",
        "State: ${obj.optString("state", "UNKNOWN")}; release=${obj.optString("release", RELEASE_NAME)}.",
        "Gates: counters_unified=${obj.optBoolean("candidateCountersUnified", false)}; seed_domain=${obj.optString("seedDomainConsistencyGate", "unknown")}; workers=${obj.optString("backgroundWorkers", "unknown")}; executed_vs_queued_separated=${obj.optBoolean("executedVsQueuedSeparated", false)}.",
        "Route linkage: ${obj.optString("oldRoutesStillLinked")}; evidence promotion remains blocked by hard gates."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        RELEASE_NAME,
        "BACKGROUND_METADATA_CONSISTENCY_READY",
        "CROSS_DOMAIN_SEEDS_DEMOTED",
        "executedVsQueuedSeparated",
        "ETL_DGE_external_router_matrix_shortcut_curated_seed_terminal_continuation",
        CLAIM_LIMIT
    ))
}
