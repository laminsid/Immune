package com.immunesignal.app

/**
 * v2.7.8.2 — Final ETL Execution Unification.
 *
 * This is the final surface unifier for the v2.7.7/v2.7.8 execution line. It does not
 * add a new biomedical route and does not run downloads, DGE, treatment selection, or
 * clinical reasoning. It merges the already-linked DGE bridge, Matrix ETL bridge,
 * ETL evidence packet, Treatment bridge, and Final execution readiness into one
 * deterministic production-readiness decision.
 */
data class GTIMFinalEtlExecutionUnifierReportV2782(
    val active: Boolean,
    val state: String,
    val targetId: String,
    val finalDecision: String,
    val readinessLine: String,
    val executionOrderLine: String,
    val stopRulesLine: String,
    val boundaryLine: String
) {
    companion object {
        fun empty(): GTIMFinalEtlExecutionUnifierReportV2782 = GTIMFinalEtlExecutionUnifierReportV2782(
            active = false,
            state = "NOT_EVALUATED",
            targetId = "NO_TARGET",
            finalDecision = "NO_FINAL_ETL_DECISION",
            readinessLine = "Unified final readiness: not evaluated.",
            executionOrderLine = "Unified execution order: not evaluated.",
            stopRulesLine = "Unified stop rules: not evaluated.",
            boundaryLine = "Unified boundary: research execution readiness only; no biological or clinical claim."
        )
    }
}

object GTIMFinalEtlExecutionUnifierV2782 {
    const val VERSION: String = "2.7.8.2-final-etl-execution-unification"
    const val CLAIM_LIMIT: String = "etl_execution_readiness_only_no_dge_result_no_clinical_or_treatment_claim"

    fun build(
        matrixAuditCard: GTIMMatrixAuditCardReportV2745,
        etlBridge: GTIMMatrixEtlMetadataBridgeReportV2780,
        evidencePacket: GTIMMatrixEtlEvidencePacketReportV2781,
        treatmentKnowledge: GTIMTreatmentKnowledgeReportV2772,
        treatmentExecution: GTIMTreatmentExecutionBridgeReportV2773,
        finalExecution: GTIMFinalExecutionReadinessReportV2774
    ): GTIMFinalEtlExecutionUnifierReportV2782 {
        if (!matrixAuditCard.active || !etlBridge.active || !evidencePacket.active) {
            return GTIMFinalEtlExecutionUnifierReportV2782.empty()
        }

        val target = firstNonBlank(etlBridge.targetId, matrixAuditCard.targetId, finalExecution.targetId, "NO_TARGET")
        val hasConcreteTarget = GTIMAccessionIdValidityGuardV2753.isFullAccession(target) &&
            etlBridge.dgeReadinessVerdict != "DGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET" &&
            evidencePacket.packetState != "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"
        val treatmentContext = treatmentKnowledge.active || treatmentExecution.active
        val verdict = etlBridge.dgeReadinessVerdict.ifBlank { "DGE_READINESS_NOT_EVALUATED" }

        val state = when {
            !hasConcreteTarget -> "FINAL_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"
            verdict == "DGE_READY_REVIEW_ONLY" -> "FINAL_ETL_READY_FOR_REVIEW_ONLY_DGE"
            verdict.contains("MATRIX_FILE", ignoreCase = true) || verdict.contains("FILE_DISCOVERY", ignoreCase = true) -> "FINAL_FILE_DISCOVERY_REQUIRED"
            verdict.contains("METADATA", ignoreCase = true) -> "FINAL_METADATA_NORMALIZATION_REQUIRED"
            verdict.contains("COMPARATOR", ignoreCase = true) -> "FINAL_COMPARATOR_EVIDENCE_REQUIRED"
            verdict.contains("SAMPLE_ID", ignoreCase = true) || verdict.contains("LINKAGE", ignoreCase = true) -> "FINAL_SAMPLE_ID_LINKAGE_REQUIRED"
            else -> "FINAL_ETL_REVIEW_REQUIRED"
        }

        val finalDecision = when (state) {
            "FINAL_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET" -> "SELECT_TOPIC_COMPATIBLE_ACCESSION_BEFORE_ETL_OR_DGE"
            "FINAL_FILE_DISCOVERY_REQUIRED" -> "RUN_REPOSITORY_FILE_DISCOVERY_FIRST"
            "FINAL_METADATA_NORMALIZATION_REQUIRED" -> "PARSE_SAMPLE_METADATA_WITH_EVIDENCE_SNIPPETS"
            "FINAL_COMPARATOR_EVIDENCE_REQUIRED" -> "NORMALIZE_COMPARATOR_LABELS_WITH_CONFIDENCE_AND_SOURCE_FIELD"
            "FINAL_SAMPLE_ID_LINKAGE_REQUIRED" -> "VERIFY_SAMPLE_IDS_AGAINST_MATRIX_COLUMNS_BEFORE_DGE"
            "FINAL_ETL_READY_FOR_REVIEW_ONLY_DGE" -> "RUN_REVIEW_ONLY_DGE_AFTER_BATCH_AND_CONTRADICTION_CHECKS"
            else -> "KEEP_AS_RESEARCH_LEAD_AND_CLOSE_ETL_GATES"
        }

        val readiness = normalizeLine(
            "Unified final readiness: version=$VERSION | state=$state | target=$target | final_decision=$finalDecision | etl_verdict=$verdict | file_probe=${evidencePacket.fileProbeState} | metadata=${etlBridge.metadataNormalizationState} | comparator=${etlBridge.comparatorNormalizationState} | sample_linkage=${etlBridge.sampleIdLinkageState} | treatment_context=$treatmentContext | claim=$CLAIM_LIMIT"
        )
        val order = normalizeLine(
            "Unified execution order: P0 target gate -> P1 file discovery -> P2 metadata normalization -> P3 comparator evidence -> P4 sample-id linkage -> P5 review-only DGE | next=${nextActionFor(finalDecision, target, etlBridge, evidencePacket)}"
        )
        val stops = normalizeLine(
            "Unified stop rules: stop_before_file_probe_if_no_topic_target=${!hasConcreteTarget} | stop_before_dge_if_matrix_metadata_comparator_or_linkage_unclosed=${verdict != "DGE_READY_REVIEW_ONLY"} | no_download_claim_until_file_seen=true | no_llm_label_as_final_truth=true | no_treatment_advice=true"
        )
        val boundary = "Unified boundary: production-readiness routing only; no file was downloaded, no DGE was run, no biological proof, no diagnosis, no treatment advice, no dosing, no efficacy claim."

        return GTIMFinalEtlExecutionUnifierReportV2782(
            active = true,
            state = state,
            targetId = target,
            finalDecision = finalDecision,
            readinessLine = readiness,
            executionOrderLine = order,
            stopRulesLine = stops,
            boundaryLine = boundary
        )
    }

    fun compactLine(report: GTIMFinalEtlExecutionUnifierReportV2782): String = report.readinessLine

    private fun nextActionFor(
        finalDecision: String,
        target: String,
        etlBridge: GTIMMatrixEtlMetadataBridgeReportV2780,
        evidencePacket: GTIMMatrixEtlEvidencePacketReportV2781
    ): String {
        return when (finalDecision) {
            "SELECT_TOPIC_COMPATIBLE_ACCESSION_BEFORE_ETL_OR_DGE" ->
                "select a concrete topic-compatible accession; block repository file probing for sentinel/background-only targets"
            "RUN_REPOSITORY_FILE_DISCOVERY_FIRST" ->
                "$target probe ${evidencePacket.candidateFileTypes.take(5).joinToString(",").ifBlank { "matrix.mtx,h5,rds,csv/tsv" }}; do not claim matrix exists until observed"
            "PARSE_SAMPLE_METADATA_WITH_EVIDENCE_SNIPPETS" ->
                "$target parse ${evidencePacket.metadataFields.take(6).joinToString(",")} and retain source_field plus evidence_snippet"
            "NORMALIZE_COMPARATOR_LABELS_WITH_CONFIDENCE_AND_SOURCE_FIELD" ->
                "$target classify comparator labels only as suggestions with confidence and evidence snippets"
            "VERIFY_SAMPLE_IDS_AGAINST_MATRIX_COLUMNS_BEFORE_DGE" ->
                "$target verify ${evidencePacket.sampleLinkageChecks.take(4).joinToString(",")} before any DGE call"
            "RUN_REVIEW_ONLY_DGE_AFTER_BATCH_AND_CONTRADICTION_CHECKS" ->
                "$target ${etlBridge.nextStep}; keep output review-only"
            else ->
                "$target keep as research lead; close ETL gates in order before DGE"
        }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""

    private fun normalizeLine(value: String): String = value
        .replace(Regex("\\s+"), " ")
        .trim()
}
