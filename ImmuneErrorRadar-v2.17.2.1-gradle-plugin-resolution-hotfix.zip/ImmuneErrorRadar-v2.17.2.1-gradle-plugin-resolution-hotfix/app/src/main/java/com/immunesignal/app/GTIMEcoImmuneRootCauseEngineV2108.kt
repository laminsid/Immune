package com.immunesignal.app

// v2.10.8 — Eco-immune root-cause engine.
// Core direction: do not stop at symptom pathway or product endpoint; search for the
// upstream dysfunction and restoration route while keeping all outputs research-only.
object GTIMEcoImmuneRootCauseEngineV2108 {
    const val VERSION: String = "2.10.8-root-cause-eco-immune-engine"
    const val PHILOSOPHY: String = "traditional_evidence_is_foundation_not_ceiling_search_upstream_dysfunction_before_symptom_suppression"
    const val BOUNDARY: String = "root_cause_research_hypotheses_only_not_diagnosis_not_treatment_not_clinical_advice"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        establishedEvidence: List<GTIMEstablishedEvidenceCardV2100>,
        discoveryFindings: List<GTIMDiscoveryFindingCardV2100>,
        mechanismMap: List<GTIMMechanismAxisCardV2100>,
        therapeuticRoutes: List<GTIMTherapeuticRouteCardV2100>,
        immunotherapyCards: List<GTIMTherapeuticHypothesisCardV2102>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMEcoImmuneRootCauseReportV2108 {
        val corpus = corpus(contract, establishedEvidence, discoveryFindings, mechanismMap, therapeuticRoutes, immunotherapyCards, dgeVerdict)
        val candidates = buildCandidates(contract, corpus, latentAxisFilter, discoveryFindings, mechanismMap, dgeVerdict)
        val microbialReversal = GTIMMicrobialReversalEngineV2111.build(
            contract = contract,
            corpus = corpus,
            rootCandidates = candidates,
            dgeVerdict = dgeVerdict
        )
        val ecologicalRestoration = GTIMEcologicalRestorationModelV2112.build(
            contract = contract,
            corpus = corpus,
            candidates = candidates,
            microbialReversal = microbialReversal
        )
        val symptomOverlap = GTIMSymptomOverlapResolverV2112.resolve(
            contract = contract,
            corpus = corpus,
            candidates = candidates,
            ecologicalRestoration = ecologicalRestoration
        )
        val routes = GTIMEcosystemRestorationRouteGeneratorV2108.build(candidates, microbialReversal, ecologicalRestoration)
        val repairPriority = GTIMRepairPriorityValidationEngineV2113.rank(
            candidates = candidates,
            restorationRoutes = routes,
            microbialReversal = microbialReversal,
            ecologicalRestoration = ecologicalRestoration,
            symptomOverlap = symptomOverlap
        )
        val falsificationPlans = GTIMRootCauseFalsificationPlannerV2108.build(candidates)
        val endpointChecks = endpointFailureChecks(corpus)
        val context = contextEcologyModifiers(corpus)
        val state = when {
            candidates.any { it.priority.contains("HIGH", true) } -> "ECO_IMMUNE_ROOT_CAUSE_HIGH_VALUE_RESEARCH_ROUTES"
            candidates.isNotEmpty() -> "ECO_IMMUNE_ROOT_CAUSE_OPEN_RESEARCH_ROUTES"
            else -> "ECO_IMMUNE_ROOT_CAUSE_OPEN_SCAN_NO_STRONG_ROUTE"
        }
        val graphState = "ROOT_CAUSE_GRAPH_READY|candidates=${candidates.size}|restoration_routes=${routes.size}|falsification_plans=${falsificationPlans.size}|context_modifiers=${context.size}|microbial_reversal=${microbialReversal.candidateRoutes.size}|ecological_restoration=${ecologicalRestoration.restorationSequences.size}|symptom_overlap=${symptomOverlap.dysfunctionHypotheses.size}|repair_priority=${repairPriority.priorityRoutes.size}"
        val line = "Eco-immune root-cause engine: version=$VERSION | state=$state | philosophy=$PHILOSOPHY | graph=$graphState | microbial_reversal=${microbialReversal.state}:${microbialReversal.candidateRoutes.size} | ecological_restoration=${ecologicalRestoration.state}:${ecologicalRestoration.restorationSequences.size} | symptom_overlap=${symptomOverlap.state}:${symptomOverlap.dysfunctionHypotheses.size} | repair_priority=${repairPriority.state}:${repairPriority.priorityRoutes.size} | endpoint_checks=${endpointChecks.joinToString(";").oneLine()} | context=${context.joinToString(";").oneLine()} | boundary=$BOUNDARY"
        return GTIMEcoImmuneRootCauseReportV2108(
            active = true,
            version = VERSION,
            state = state,
            philosophy = PHILOSOPHY,
            rootCauseGraphState = graphState,
            candidates = candidates,
            restorationRoutes = routes,
            falsificationPlans = falsificationPlans,
            endpointFailureChecks = endpointChecks,
            contextEcologyModifiers = context,
            boundaryLine = BOUNDARY,
            line = line,
            microbialReversal = microbialReversal,
            ecologicalRestoration = ecologicalRestoration,
            symptomOverlap = symptomOverlap,
            repairPriorityValidation = repairPriority
        )
    }

    private fun buildCandidates(
        contract: GTIMRunDecisionContractV2740,
        corpus: String,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        discoveryFindings: List<GTIMDiscoveryFindingCardV2100>,
        mechanismMap: List<GTIMMechanismAxisCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): List<GTIMEcoImmuneRootCauseCandidateV2108> {
        val candidates = mutableListOf<GTIMEcoImmuneRootCauseCandidateV2108>()
        candidates += ecologicalCandidate(contract, latentAxisFilter, discoveryFindings, dgeVerdict)
        candidates += immunometabolicCandidate(contract, latentAxisFilter, discoveryFindings, dgeVerdict)
        if (containsAny(corpus, listOf("allergy", "asthma", "rhinitis", "skin", "gut", "ibd", "colitis", "virus", "covid", "mucosal", "barrier"))) {
            candidates += mucosalBarrierCandidate(contract, latentAxisFilter, discoveryFindings, dgeVerdict)
        }
        if (containsAny(corpus, listOf("covid", "variant", "vaccine", "viral", "virus", "antibody", "mucosal", "waning"))) {
            candidates += immuneInterventionFailureCandidate(contract, latentAxisFilter, discoveryFindings, dgeVerdict)
        }
        if (containsAny(corpus, listOf("alzheimer", "amyloid", "tau", "apoe", "microglia", "neuro", "protein", "misfold"))) {
            candidates += neuroimmuneProteostasisCandidate(contract, latentAxisFilter, discoveryFindings, mechanismMap, dgeVerdict)
        }
        if (candidates.isEmpty()) candidates += openRootCauseCandidate(contract, latentAxisFilter, discoveryFindings, dgeVerdict)
        return candidates.distinctBy { it.candidateId }.take(6)
    }

    private fun ecologicalCandidate(
        contract: GTIMRunDecisionContractV2740,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMEcoImmuneRootCauseCandidateV2108 = candidate(
        id = "ecological_function_loss",
        dysfunction = "possible loss of protective microbial, metabolite, barrier, or tolerance function",
        chain = "microbiome/metabolites -> epithelial or mucosal barrier -> immune tolerance threshold -> inflammatory or tissue phenotype in ${contract.primaryAnchor.routeId}",
        restoration = "restore missing ecosystem function instead of only suppressing downstream symptoms",
        latentAxisFilter = latentAxisFilter,
        discovery = discovery,
        dgeVerdict = dgeVerdict,
        context = listOf("diet/ecology transferability must be tested", "lost function matters more than bacterial name"),
        priority = "ROOT_CAUSE_PRIORITY_HIGH_IF_MICROBIOME_METABOLITE_BARRIER_SIGNAL_PRESENT"
    )

    private fun immunometabolicCandidate(
        contract: GTIMRunDecisionContractV2740,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMEcoImmuneRootCauseCandidateV2108 = candidate(
        id = "immunometabolic_mismatch",
        dysfunction = "possible metabolic-energy mismatch that changes immune tone, inflammatory durability, or tissue repair capacity",
        chain = "glucose/insulin/lipid/mitochondrial state -> immune-cell metabolism -> cytokine or repair phenotype -> research topic expression",
        restoration = "test metabolic resilience and immune-energy correction as research routes before assuming a single drug target",
        latentAxisFilter = latentAxisFilter,
        discovery = discovery,
        dgeVerdict = dgeVerdict,
        context = listOf("population diet and lifestyle can alter transferability", "endpoint must distinguish symptom relief from immune resilience"),
        priority = "ROOT_CAUSE_PRIORITY_MEDIUM_HIGH_FOR_ANY_IMMUNE_TOPIC"
    )

    private fun mucosalBarrierCandidate(
        contract: GTIMRunDecisionContractV2740,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMEcoImmuneRootCauseCandidateV2108 = candidate(
        id = "barrier_mucosal_tolerance_failure",
        dysfunction = "possible failure at the barrier or mucosal-tolerance interface",
        chain = "entry surface or gut barrier -> local immune training/tolerance -> mast-cell, IgE, cytokine, or host-response threshold",
        restoration = "evaluate barrier repair, mucosal immunity, and tolerance rebuilding as research routes",
        latentAxisFilter = latentAxisFilter,
        discovery = discovery,
        dgeVerdict = dgeVerdict,
        context = listOf("local ecology and exposure history can change mucosal thresholds", "do not equate systemic evidence with mucosal protection"),
        priority = "ROOT_CAUSE_PRIORITY_HIGH_FOR_BARRIER_OR_RESPIRATORY_GUT_TOPICS"
    )

    private fun immuneInterventionFailureCandidate(
        contract: GTIMRunDecisionContractV2740,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMEcoImmuneRootCauseCandidateV2108 = candidate(
        id = "immune_intervention_failure_case",
        dysfunction = "possible endpoint mismatch, variant escape, waning durability, or host-context failure in immune intervention logic",
        chain = "product target -> variant pressure and mucosal entry -> systemic versus local immunity -> host microbiome/metabolic context -> real-world failure case",
        restoration = "seek broad immune readiness routes: conserved targets, mucosal defense, trained immunity balance, and context-specific resilience",
        latentAxisFilter = latentAxisFilter,
        discovery = discovery,
        dgeVerdict = dgeVerdict,
        context = listOf("authority approval is not the same as durable variant-era protection for every subgroup", "failure cases are research signals, not proof of general failure"),
        priority = "ROOT_CAUSE_PRIORITY_HIGH_FOR_EPIDEMIC_OR_VARIANT_TOPICS"
    )

    private fun neuroimmuneProteostasisCandidate(
        contract: GTIMRunDecisionContractV2740,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        mechanisms: List<GTIMMechanismAxisCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMEcoImmuneRootCauseCandidateV2108 {
        val extraMissing = mechanisms.flatMap { it.requiredEvidence }.filter { it.contains("protein", true) || it.contains("immune", true) }.take(2)
        val base = candidate(
            id = "neuroimmune_proteostasis_context",
            dysfunction = "possible interaction between protein clearance, neuroimmune activation, microbiome-metabolite tone, and metabolic stress",
            chain = "protein/proteostasis stress -> microglia or neuroimmune tone -> metabolic and microbial context -> tissue resilience or decline",
            restoration = "test whether restoring immune-metabolic and ecological context could improve protein-clearance environment",
            latentAxisFilter = latentAxisFilter,
            discovery = discovery,
            dgeVerdict = dgeVerdict,
            context = listOf("family/population risk is context for research only", "neurodegeneration hypotheses require long-horizon validation"),
            priority = "ROOT_CAUSE_PRIORITY_MEDIUM_HIGH_FOR_NEUROIMMUNE_TOPICS"
        )
        return base.copy(
            missingEvidence = (base.missingEvidence + extraMissing).distinct().take(8),
            line = base.line + " | proteostasis_context=true"
        )
    }

    private fun openRootCauseCandidate(
        contract: GTIMRunDecisionContractV2740,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMEcoImmuneRootCauseCandidateV2108 = candidate(
        id = "open_root_cause_scan",
        dysfunction = "unknown upstream dysfunction requiring open eco-immune scan",
        chain = "research input -> latent microbiome/metabolic/immune/barrier/genetic axes -> candidate mechanism -> missing proof",
        restoration = "do not stop at symptom pathway; search for reversible lost function or maladaptive immune-context loop",
        latentAxisFilter = latentAxisFilter,
        discovery = discovery,
        dgeVerdict = dgeVerdict,
        context = listOf("open-topic scan not restricted by disease whitelist", "context/ecology transferability must be reviewed"),
        priority = "ROOT_CAUSE_PRIORITY_OPEN_EXPLORATION"
    )

    private fun candidate(
        id: String,
        dysfunction: String,
        chain: String,
        restoration: String,
        latentAxisFilter: GTIMLatentAxisFilterReportV2107,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802,
        context: List<String>,
        priority: String
    ): GTIMEcoImmuneRootCauseCandidateV2108 {
        val support = (latentAxisFilter.scores.take(4).flatMap { axis -> axis.matchedSignals.map { "${axis.axisId}:$it" } } + discovery.take(2).map { it.findingId + ":" + it.evidenceState }).filter { it.isNotBlank() }.ifEmpty { listOf("latent axis scan keeps microbiome/metabolism/immune interaction under review") }
        val missing = (latentAxisFilter.missingEvidencePrompts + discovery.take(2).map { it.requiredNextEvidence } + dgeVerdict.blockers.map { "DGE blocker: $it" }).distinct().take(8)
        val falsify = (latentAxisFilter.falsificationPrompts + "topic-compatible dataset contradicts upstream chain" + "restoration lever does not map to missing function").distinct().take(8)
        val state = "ROOT_CAUSE_CANDIDATE_RESEARCH_ONLY"
        val line = "Root-cause candidate: version=$VERSION | id=$id | state=$state | priority=$priority | dysfunction=${dysfunction.oneLine()} | chain=${chain.oneLine()} | restoration_need=${restoration.oneLine()} | support=${support.joinToString(";").oneLine()} | missing=${missing.joinToString(";").oneLine()} | falsify=${falsify.joinToString(";").oneLine()} | context=${context.joinToString(";").oneLine()} | boundary=$BOUNDARY"
        return GTIMEcoImmuneRootCauseCandidateV2108(
            candidateId = id,
            state = state,
            upstreamDysfunction = dysfunction,
            causalChain = chain,
            restorationNeed = restoration,
            supportingSignals = support,
            missingEvidence = missing,
            falsificationTests = falsify,
            contextModifiers = context,
            priority = priority,
            line = line
        )
    }

    private fun endpointFailureChecks(corpus: String): List<String> {
        val checks = mutableListOf(
            "separate symptom relief from root restoration",
            "separate approved endpoint from individual or subgroup failure",
            "check durability, waning, and endpoint mismatch before ranking success"
        )
        if (containsAny(corpus, listOf("covid", "variant", "vaccine", "viral", "antibody"))) {
            checks += listOf("variant escape and conserved-target review", "mucosal versus systemic protection gap")
        }
        return checks.distinct()
    }

    private fun contextEcologyModifiers(corpus: String): List<String> {
        val base = mutableListOf(
            "geography_diet_lifestyle_and_exposure_can_modify_transferability",
            "population_context_is_research_modifier_not_deterministic_identity_claim"
        )
        if (containsAny(corpus, listOf("diet", "food", "fiber", "meat", "north africa", "africa", "america", "industrial"))) base += "dietary_ecology_modifier"
        if (containsAny(corpus, listOf("antibiotic", "ppi", "medicine", "drug"))) base += "medication_exposure_microbiome_modifier"
        if (containsAny(corpus, listOf("sun", "vitamin", "sleep", "stress"))) base += "lifestyle_resilience_modifier"
        return base.distinct()
    }

    private fun corpus(
        contract: GTIMRunDecisionContractV2740,
        establishedEvidence: List<GTIMEstablishedEvidenceCardV2100>,
        discoveryFindings: List<GTIMDiscoveryFindingCardV2100>,
        mechanismMap: List<GTIMMechanismAxisCardV2100>,
        therapeuticRoutes: List<GTIMTherapeuticRouteCardV2100>,
        immunotherapyCards: List<GTIMTherapeuticHypothesisCardV2102>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): String = listOf(
        contract.rawQuery,
        contract.normalizedQuery,
        contract.primaryAnchor.routeId,
        contract.diseaseFamily.name,
        contract.secondaryDomains.joinToString(" ") { it.name },
        contract.discoveryBridges.joinToString(" ") { it.routeId },
        contract.exploratoryRoutes.joinToString(" "),
        establishedEvidence.joinToString(" ") { it.statement + " " + it.topicArea },
        discoveryFindings.joinToString(" ") { it.finding + " " + it.requiredNextEvidence },
        mechanismMap.joinToString(" ") { it.axisId + " " + it.mechanismChain },
        therapeuticRoutes.joinToString(" ") { it.routeClass + " " + it.biologicalRationale },
        immunotherapyCards.joinToString(" ") { it.routeClass + " " + it.mechanismId + " " + it.requiredBiomarkers.joinToString(" ") },
        dgeVerdict.verdict + " " + dgeVerdict.blockers.joinToString(" ")
    ).joinToString(" ").lowercase()

    private fun containsAny(text: String, tokens: List<String>): Boolean = tokens.any { text.contains(it.lowercase()) }
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
