package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.12.18 — local contradiction and falsification engine. */
object GTIMContradictionSearchEngineV21218 {
    const val VERSION: String = "2.12.18-contradiction-search-engine"
    const val CLAIM_LIMIT: String = "contradiction_routing_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val capsule = report.optJSONObject("evidenceCapsuleBuilderV21218") ?: JSONObject()
        val negative = report.optJSONObject("negativeEvidenceMemoryV21213") ?: JSONObject()
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val contradictions = JSONArray()
        if (!capsule.optBoolean("comparatorClosed", false)) contradictions.put("Comparator labels are missing or only hinted; case/control or severity separation may fail.")
        if (!capsule.optBoolean("sampleProvenanceClosed", false)) contradictions.put("Sample-to-source provenance is not closed; handle may not support sample-level inference.")
        if (!capsule.optBoolean("matrixOrCapsuleClosed", false)) contradictions.put("Processed capsule/raw matrix is not verified; pathway or gene signal cannot be tested yet.")
        val negativeItemCount = maxOf(negative.optInt("items", 0), negative.optJSONArray("items")?.length() ?: 0)
        if (negativeItemCount > 0) contradictions.put("Negative evidence memory contains unresolved blockers from earlier runs.")
        if (ledger.optInt("demotedCrossDomainSeedCount", 0) > 0) contradictions.put("Some candidate seeds were demoted as cross-domain or cross-subtype background only.")
        val support = JSONArray()
        if (ledger.optString("selectedReviewTarget").isNotBlank()) support.put("Selected review target exists: ${ledger.optString("selectedReviewTarget")}")
        if (capsule.optInt("capsuleScore", 0) >= 6) support.put("Partial capsule score suggests a follow-up route, not proof.")
        val state = when {
            contradictions.length() == 0 && support.length() > 0 -> "NO_LOCAL_CONTRADICTION_FOUND_REVIEW_REQUIRED"
            contradictions.length() <= 2 -> "CONTRADICTIONS_PRESENT_BUT_ROUTABLE"
            else -> "CONTRADICTION_RISK_HIGH_CLAIM_BLOCKED"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("supportingSignals", support)
            .put("contradictingSignals", contradictions)
            .put("unresolvedConflictCount", contradictions.length())
            .put("bestFalsificationTest", bestFalsificationTest(report, capsule))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Contradiction search engine",
        "State: ${obj.optString("state", "UNKNOWN")}; unresolved_conflicts=${obj.optInt("unresolvedConflictCount", 0)}.",
        "Best falsification test: ${obj.optString("bestFalsificationTest", "verify comparator/sample/capsule gates before claim upgrade")}",
        "Contradiction rule: a hypothesis that survives only missing-data checks is still a route, not proof.",
        "Boundary: contradiction routing does not prove or disprove disease mechanisms; it prioritizes what must be tested next."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "CONTRADICTIONS_PRESENT_BUT_ROUTABLE", "CONTRADICTION_RISK_HIGH_CLAIM_BLOCKED", CLAIM_LIMIT))

    private fun bestFalsificationTest(report: JSONObject, capsule: JSONObject): String {
        val selected = capsule.optString("selectedReviewTarget", report.optJSONObject("candidateHandleLedgerV21215")?.optString("selectedReviewTarget") ?: "selected handle")
        return "For $selected, verify comparator labels, sample provenance, and processed capsule; then test whether the nominated target/readout separates phenotype groups and survives a negative/contradiction dataset."
    }
}
