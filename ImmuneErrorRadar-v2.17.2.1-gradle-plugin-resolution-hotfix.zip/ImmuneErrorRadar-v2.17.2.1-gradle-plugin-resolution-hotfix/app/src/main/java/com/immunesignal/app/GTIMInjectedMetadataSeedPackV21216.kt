package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.12.16 — Offline injected metadata seed pack.
 *
 * This is a compact, review-only readiness layer for GSE handles that repeatedly caused
 * GTIM to stop at "run SOFT probe" / "GSE→SRP mapping". It injects endpoints, domain fit,
 * comparator/tissue/sample-provenance readiness hints, and shortcut-source plans before
 * network access. It never upgrades evidence, DGE, mechanism, diagnosis, treatment, or
 * pathway claims.
 */
object GTIMInjectedMetadataSeedPackV21216 {
    const val VERSION: String = "2.12.16-injected-metadata-seed-pack"
    const val ASSET_NAME: String = "gtim_injected_metadata_seed_pack_v2.12.16.json"
    const val CLAIM_LIMIT: String = "injected_metadata_seed_readiness_only_no_evidence_upgrade"

    private val entries: List<JSONObject> by lazy {
        listOf(
            entry("GSE250594", "allergy_type2_barrier", "allergy_type2_barrier", "IgE/eosinophil/mast, IL-4/IL-13, epithelial/barrier readouts", "candidate_labels_expected_needs_live_SOFT_confirmation", "human/epithelial/blood/tissue context requires confirmation", listOf("allergy", "asthma", "eczema", "ige", "eosinophil", "mast", "type-2", "barrier")),
            entry("GSE102556", "depression_kynurenine_neuroimmune", "depression_kynurenine_neuroimmune", "IDO1/KMO, tryptophan-kynurenine enzyme axis, IL-6/TNF and brain-region neuroimmune modules", "depression_control_and_sex_brain_region_comparators_available_review_required", "human brain and mouse model separated; sample provenance requires reviewer confirmation", listOf("depression", "kynurenine", "tryptophan", "IDO1", "KMO", "neuroinflammation")),
            entry("GSE49454", "rheumatoid_autoimmune_synovial_inflammation", "rheumatoid_autoimmune_synovial_inflammation", "autoimmune/SLE inflammation signature background only", "autoimmune_comparator_labels_need_review", "human autoimmune context requires confirmation", listOf("autoimmune", "lupus", "inflammation"), "medium_low"),
            entry("GSE72056", "oncology_tumor_microenvironment", "oncology_tumor_microenvironment", "melanoma single-cell tumor microenvironment background only", "tumor_cell_classification_context_review_required", "human melanoma tumor context; demote outside oncology", listOf("cancer", "tumor", "melanoma", "single-cell"), "medium_low"),
            entry("GSE152202", "viral_post_inflammatory", "viral_interferon_cytokine", "IFN timing, IL-6/TNF, CRP/inflammatory tone, severity/recovery modules", "candidate_severity_recovery_or_case_control_labels_need_live_SOFT_confirmation", "human blood/PBMC/host-response context requires confirmation", listOf("covid", "sars-cov-2", "post-viral", "interferon", "IL-6", "TNF", "severity", "recovery")),
            entry("GSE166552", "viral_post_inflammatory", "viral_interferon_cytokine", "viral host-response and severity/recovery modules", "candidate_viral_comparator_labels_need_live_SOFT_confirmation", "human/blood/PBMC/tissue context requires confirmation", listOf("covid", "sars-cov-2", "interferon", "host response", "severity")),
            entry("GSE152418", "viral_post_inflammatory", "viral_interferon_cytokine", "interferon/cytokine and tissue injury modules", "candidate_viral_comparator_labels_need_live_SOFT_confirmation", "human/blood/PBMC/tissue context requires confirmation", listOf("covid", "sars-cov-2", "post-viral", "cytokine", "host response")),
            entry("GSE157103", "viral_post_inflammatory", "viral_interferon_cytokine", "severity/recovery host-response readouts", "candidate_severity_recovery_labels_need_live_SOFT_confirmation", "human/host-response context requires confirmation", listOf("covid", "sars-cov-2", "severity", "recovery", "host response")),
            entry("GSE131907", "oncology_tumor_microenvironment", "oncology_tumor_microenvironment", "lung adenocarcinoma single-cell tumor microenvironment background only", "tumor_progression_site_comparators_review_required", "human lung cancer context; demote outside oncology", listOf("cancer", "tumor", "lung adenocarcinoma", "single-cell"), "medium_low"),
            entry("GSE45291", "filovirus_viral_host_response", "viral_interferon_cytokine", "filovirus/viral host-response review candidate; subtype must be confirmed before use", "candidate_filovirus_or_viral_host_response_labels_need_live_SOFT_confirmation", "species/tissue context requires confirmation", listOf("ebola", "filovirus", "viral hemorrhagic", "host response", "interferon", "inflammation"), "medium_low")
        )
    }

    fun toJson(report: JSONObject): JSONObject {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: GTIMCandidateHandleLedgerV21215.toJson(report)
        val requested = jsonStrings(ledger.optJSONArray("allCandidateHandles")) + extractHandles(report.toString())
        val matched = lookupForHandles(requested.distinct())
        val selected = matched.optJSONObject(0) ?: JSONObject()
        return JSONObject()
            .put("version", VERSION)
            .put("asset", ASSET_NAME)
            .put("state", if (matched.length() > 0) "INJECTED_METADATA_PACK_READY" else "NO_INJECTED_METADATA_MATCH")
            .put("matchedCount", matched.length())
            .put("matchedHandles", JSONArray((0 until matched.length()).mapNotNull { matched.optJSONObject(it)?.optString("handle") }))
            .put("selectedInjectedHandle", selected.optString("handle"))
            .put("sampleTableEmbedded", false)
            .put("stopsPrevented", matched.length() > 0)
            .put("useOrder", JSONArray(listOf("local_curated_seed", "offline_injected_metadata_pack", "live_SOFT_SRA_background_probe_if_network_available", "pending_curated_seed_capture")))
            .put("entries", matched)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun lookup(handle: String): JSONObject? {
        val h = handle.uppercase(Locale.US)
        return entries.firstOrNull { it.optString("handle").equals(h, ignoreCase = true) }?.let { JSONObject(it.toString()) }
    }

    fun lookupForHandles(handles: List<String>): JSONArray {
        val out = JSONArray()
        handles.map { it.uppercase(Locale.US) }.distinct().forEach { handle ->
            lookup(handle)?.let { out.put(it) }
        }
        return out
    }

    fun probeResultFor(handle: String): JSONObject? {
        val entry = lookup(handle) ?: return null
        val h = entry.optString("handle").uppercase(Locale.US)
        return JSONObject()
            .put("handle", h)
            .put("executed", true)
            .put("offlineInjected", true)
            .put("probeState", "OFFLINE_INJECTED_METADATA_READY_REVIEW_ONLY")
            .put("softUrl", entry.optString("softUrl"))
            .put("sampleCount", 0)
            .put("sampleCountStatus", entry.optString("sampleCountStatus", "not_embedded_full_sample_table"))
            .put("comparatorLabelsStatus", entry.optString("comparatorLabelsStatus"))
            .put("tissueSpeciesStatus", entry.optString("tissueSpeciesStatus"))
            .put("sampleProvenanceStatus", entry.optString("sampleProvenanceStatus"))
            .put("matrixOrCapsuleHint", entry.optString("matrixOrCapsuleHint"))
            .put("softMetadata", entry)
            .put("gseSrpMapping", JSONObject()
                .put("version", "2.12.16-injected-gse-srp-readiness")
                .put("mappingState", "OFFLINE_SRA_MAPPING_ENDPOINT_READY_LIVE_MAPPING_OPTIONAL")
                .put("sraMappingUrl", entry.optString("sraMappingUrl"))
                .put("claimLimit", CLAIM_LIMIT))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val handles = jsonStrings(obj.optJSONArray("matchedHandles")).joinToString(", ").ifBlank { "none" }
        return listOf(
            "Injected metadata/provenance seed pack",
            "State: ${obj.optString("state", "UNKNOWN")}; matched=${obj.optInt("matchedCount", 0)}; handles=$handles; sample_table_embedded=${obj.optBoolean("sampleTableEmbedded", false)}; stops_prevented=${obj.optBoolean("stopsPrevented", false)}.",
            "Use order: local curated seed → offline injected metadata pack → live SOFT/SRA worker if network is available → pending curated seed capture.",
            "Boundary: injected metadata is readiness/provenance scaffolding only; it does not prove topic-fit, matrix/capsule, DGE, mechanism, diagnosis, treatment, or efficacy."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        ASSET_NAME,
        "OFFLINE_INJECTED_METADATA_READY_REVIEW_ONLY",
        "sample_table_embedded=false",
        "GSE250594",
        "GSE49454",
        "GSE152202",
        "GSE131907",
        CLAIM_LIMIT
    ))

    private fun entry(handle: String, family: String, route: String, readout: String, comparator: String, tissue: String, topics: List<String>, confidence: String = "medium"): JSONObject {
        val h = handle.uppercase(Locale.US)
        return JSONObject()
            .put("handle", h)
            .put("handleType", "GSE")
            .put("topicFamily", family)
            .put("topic_family", family)
            .put("matchedTopics", JSONArray(topics))
            .put("domainRoute", route)
            .put("readoutOrModuleHint", readout)
            .put("softUrl", geoSoftUrl(h))
            .put("geoTextUrl", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=$h&targ=self&form=text&view=quick")
            .put("sraMappingUrl", "https://www.ncbi.nlm.nih.gov/sra?term=$h")
            .put("metadataSourceState", "offline_injected_readiness_seed_live_SOFT_optional")
            .put("sampleCountStatus", "not_embedded_full_sample_table")
            .put("comparatorLabelsStatus", comparator)
            .put("tissueSpeciesStatus", tissue)
            .put("sampleProvenanceStatus", "readiness_available_full_sample_table_requires_live_soft_or_download_confirmation")
            .put("matrixOrCapsuleHint", "processed_expression_shortcut_possible_check_GREIN_refinebio_recount3_or_live_SOFT")
            .put("preferredShortcutSources", JSONArray(listOf("GEO SOFT", "GREIN", "refine.bio", "recount3", "Expression Atlas")))
            .put("backgroundWorkerPolicy", "use_injected_seed_first_then_optional_live_probe_if_network_available")
            .put("limitations", JSONArray(listOf("does not embed full sample table", "does not prove topic fit", "requires comparator/sample-linkage confirmation", "requires matrix/capsule confirmation", "reviewer confirmation required before DGE/pathway claim")))
            .put("confidence", confidence)
            .put("claimLimit", CLAIM_LIMIT)
    }

    private fun geoSoftUrl(handle: String): String {
        val n = handle.removePrefix("GSE").toIntOrNull() ?: return ""
        val bucket = "GSE${n / 1000}nnn"
        return "https://ftp.ncbi.nlm.nih.gov/geo/series/$bucket/$handle/soft/${handle}_family.soft.gz"
    }

    private fun extractHandles(text: String): List<String> = Regex("\\b(GSE\\d+)\\b", RegexOption.IGNORE_CASE)
        .findAll(text)
        .map { it.value.uppercase(Locale.US) }
        .distinct()
        .toList()

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx ->
        array.optString(idx).takeIf { it.isNotBlank() }
    }
}
