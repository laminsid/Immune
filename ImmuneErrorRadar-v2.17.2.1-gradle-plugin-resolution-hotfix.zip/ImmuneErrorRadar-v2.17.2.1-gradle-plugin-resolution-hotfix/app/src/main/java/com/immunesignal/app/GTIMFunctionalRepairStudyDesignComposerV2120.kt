package com.immunesignal.app

// v2.12.0 — Composes a paper-like validation plan without clinical or lab instructions.
object GTIMFunctionalRepairStudyDesignComposerV2120 {
    const val VERSION: String = "2.12.0-functional-repair-study-design-composer"

    fun compose(
        topic: String,
        target: String,
        model: GTIMFunctionalDysfunctionModelV2120,
        functions: List<GTIMFunctionalRepairFunctionV2120>,
        tension: GTIMEvidenceTensionMapV2120
    ): GTIMFunctionalStudyDesignV2120 {
        val primary = functions.firstOrNull()
        val question = "Can ${model.primaryDysfunction} be reframed as a testable functional repair problem for ${topic.ifBlank { "the current topic" }} using ${primary?.biologicalToolClass ?: "a function-first biological route"}?"
        val dataset = listOf(
            "select or feed a topic-compatible accession/handle before ETL",
            "verify supplementary raw/count matrix or processed expression availability",
            "extract sample table, tissue/species, disease/control or subgroup comparator labels",
            "map source-to-sample provenance and reject mismatched context",
            "run review-only DGE only after matrix, comparator, and sample-ID linkage close",
            "compare proposed dysfunction markers against a negative-control route"
        )
        val lab = listOf(
            "define a competent-lab assay for the nominated repair function",
            "measure host-response, barrier, metabolite, cytokine, or tolerance markers relevant to the model",
            "include context-matched negative controls and safety readouts",
            "for microbial or biological candidates, require biosafety, containment, and identity verification before any interpretation",
            "do not translate into human use without external ethical, regulatory, and clinical validation"
        )
        val readouts = (functions.flatMap { it.missingEvidence } + model.causalSketch.map { "directional marker for $it" }).distinct().take(8)
        val upgrade = listOf(
            "D to C: target-compatible accession plus observed file/provenance evidence",
            "C to B: comparator labels, sample linkage, and reviewed expression or external evidence capsule",
            "B to A-like research signal: repeated independent support plus contradiction resistance",
            "never upgrade to medical, treatment, or efficacy claim inside this app"
        )
        val line = "Functional repair study design: version=$VERSION | question=${question.oneLine()} | dataset_plan=${dataset.joinToString(";").oneLine()} | lab_plan=${lab.joinToString(";").oneLine()} | readouts=${readouts.joinToString(";").oneLine()} | upgrade=${upgrade.joinToString(";").oneLine()}"
        return GTIMFunctionalStudyDesignV2120(question, dataset, lab, readouts, upgrade, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
