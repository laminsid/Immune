package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.25 — foreground long-run dossier closure.
 *
 * The Android screen must not behave like an endless scientific worker. The new
 * contract guarantees a visible interim dossier after six minutes, permits a
 * deeper 10-minute foreground pass, and then forces a saved partial/final surface.
 * This is a runtime/report-visibility contract only; it does not upgrade evidence.
 */
object GTIMForegroundLongRunDossierClosureV21325 {
    const val VERSION: String = "2.13.25-foreground-long-run-dossier-closure"
    const val CLAIM_LIMIT: String = "long_run_progress_report_only_no_evidence_upgrade_no_clinical_action"

    fun toJson(report: JSONObject, stillRunning: Boolean): JSONObject {
        val budget = report.optJSONObject("mobileRuntimeBudgetV21322") ?: JSONObject()
        val progress = report.optJSONObject("agenticProgressPlanV21324") ?: JSONObject()
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (stillRunning) "INTERIM_VISIBLE_SEARCH_CONTINUES" else "PASS_CLOSED_WITH_VISIBLE_DOSSIER")
            .put("sixMinuteInterimReport", true)
            .put("tenMinuteHardCeiling", true)
            .put("firstVisibleReportMillis", budget.optLong("firstVisibleReportMillis", 6L * 60L * 1000L))
            .put("hardTimeoutMillis", budget.optLong("hardTimeoutMillis", 10L * 60L * 1000L))
            .put("currentStatus", budget.optString("status", if (stillRunning) "INTERIM_SIX_MINUTE_REPORT_STILL_RUNNING" else "VISIBLE_DOSSIER_READY"))
            .put("phase", progress.optString("phase", "REPORT_OUTPUT"))
            .put("percent", progress.optInt("percent", 0))
            .put("visibleSurfaceGuarantee", "A report card is shown at the six-minute checkpoint and again on hard close/final completion.")
            .put("copyExportGuarantee", "Copy and Export are enabled once any interim, partial, or final dossier exists.")
            .put("pipeline", JSONArray(listOf(
                "Reading question",
                "Collecting local scientific memory",
                "Searching and collecting data",
                "Filtering and cleaning evidence handles",
                "Thinking and hypothesis synthesis",
                "Linking mechanisms and routes",
                "Writing report"
            )))
            .put("notEvidence", JSONArray(listOf(
                "runtime progress percentage",
                "queued checks",
                "interim dossier",
                "candidate handles without source closure"
            )))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun renderLines(obj: JSONObject): List<String> {
        val closure = obj.optJSONObject("foregroundLongRunDossierClosureV21325") ?: toJson(obj, stillRunning = false)
        return listOf(
            "Foreground long-run dossier: ${closure.optString("state", "VISIBLE_DOSSIER_READY")}",
            "First visible report: ${closure.optLong("firstVisibleReportMillis", 360000L) / 1000L}s; hard ceiling: ${closure.optLong("hardTimeoutMillis", 600000L) / 1000L}s.",
            "Guarantee: ${closure.optString("visibleSurfaceGuarantee", "A visible dossier surface is produced.")}",
            "Boundary: ${closure.optString("claimLimit", CLAIM_LIMIT)}"
        )
    }
}
