package com.immunesignal.app

import org.json.JSONObject

/**
 * v2.14.4 — loop breaker UI state machine.
 *
 * This layer separates the professional staged agent from old compatibility
 * artifacts. The start screen is a clean idle state, blank input is a true no-op,
 * report buttons are disabled until a real dossier exists, and previous reports
 * are not replayed into the main surface automatically.
 */
object GTIMLoopBreakerUiStateV2144 {
    const val VERSION: String = "2.14.4-loop-breaker-ui-state-machine"
    const val REQUIRED_TOKEN: String = "V2144_CLEAN_IDLE_NO_BLANK_REPORT_NO_OLD_REPLAY"
    const val CLAIM_LIMIT: String = "ui_state_machine_controls_workflow_not_evidence_strength"
    const val FAST_COMPACT_PASS_TARGET: String = "two-second compact local pass target; proof seeking deepens through repeat passes"

    fun idleCard(previousReportAvailable: Boolean): String = buildString {
        append("Ready — enter one topic or question.\n")
        append("Start creates a new staged agent pass. Pause/Continue/Stop only apply after Start.\n")
        append("No old topic is replayed automatically. ")
        append(if (previousReportAvailable) "A previous dossier exists in storage, but it is not shown until Copy/Export is requested." else "No previous dossier is opened on the main screen.")
    }

    fun blankInputCard(): String =
        "No run started. Enter a topic first. Blank Start clears interrupted checkpoints and never replays an old question."

    fun controlsCard(state: String, reportAvailable: Boolean): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("requiredToken", REQUIRED_TOKEN)
        .put("state", state)
        .put("reportAvailable", reportAvailable)
        .put("copyExportEnabled", reportAvailable)
        .put("blankInputShowsReport", false)
        .put("oldTopicReplay", false)
        .put("fastCompactPassTarget", FAST_COMPACT_PASS_TARGET)
        .put("defaultRoute", GTIMProfessionalOrchestratorHardLockV2142.DEFAULT_ROUTE)
        .put("legacyMonolithicRouteDefault", false)
        .put("claimLimit", CLAIM_LIMIT)
}
