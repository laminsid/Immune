package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** PANoptosis / panoptosome research lens. */
object GTIMPANoptosisCellDeathEngineV21319 {
    const val VERSION: String = "2.13.19-panoptosis-cell-death-engine"
    const val STATE_READY: String = "PANOPTOSIS_CELL_DEATH_LENS_READY"
    const val CLAIM_LIMIT: String = "PANoptosis_lens_not_drug_target_proof"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("PANoptosis_role", "coordinated_programmed_inflammatory_cell_death")
        .put("cell_death_modes", JSONArray(listOf("pyroptosis", "apoptosis", "necroptosis")))
        .put("drug_target_proof_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
