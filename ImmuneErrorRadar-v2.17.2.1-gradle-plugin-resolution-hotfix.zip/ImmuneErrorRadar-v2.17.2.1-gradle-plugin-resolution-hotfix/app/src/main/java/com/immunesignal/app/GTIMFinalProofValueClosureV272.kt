package com.immunesignal.app

/** v2.7.3 closure guard: verifies that the proof/value benchmark patch is connected. */
data class GTIMFinalProofValueClosureReportV272(
    val active: Boolean,
    val versionUnified: Boolean,
    val paperUnderstandingLinked: Boolean,
    val promisingRouteLinked: Boolean,
    val proofOfValueLinked: Boolean,
    val topicRouteLinked: Boolean,
    val learningLoopLinked: Boolean,
    val closureState: String,
    val nextAction: String,
    val claimLimit: String = GTIMFinalProofValueClosureV272.CLAIM_LIMIT
)

object GTIMFinalProofValueClosureV272 {
    const val VERSION: String = "2.7.3-final-proof-benchmark-learning-locked"
    const val CLAIM_LIMIT: String = "proof_of_value_closure_not_biological_proof"

    fun verify(question: String): GTIMFinalProofValueClosureReportV272 {
        val versionUnified = ReleaseVersionLinkageGuard.VERSION_NAME.isNotBlank() &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME.isNotBlank() &&
            EngineRuntimeStatus.ACTIVE_ENGINE_VERSION.isNotBlank() &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION.isNotBlank() &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE > 0 &&
            ReleaseVersionLinkageGuard.VERSION_CODE > 0
        val topic = GTIMTopicSpecificRouteBuilderV270.build(question)
        val learningLinked = RuntimeFeatureFlags.ENABLE_LEARNING_LOOP_ACTIVATION_V262 &&
            LearningLoopActivationV262.CLAIM_LIMIT.contains("not_biological_proof")
        val ok = versionUnified &&
            RuntimeFeatureFlags.ENABLE_PAPER_UNDERSTANDING_LITE_V272 &&
            RuntimeFeatureFlags.ENABLE_PROMISING_ROUTE_STATE_V272 &&
            RuntimeFeatureFlags.ENABLE_PROOF_OF_VALUE_MODE_V272 &&
            RuntimeFeatureFlags.ENABLE_BENCHMARK_VALUE_HARNESS_V273 &&
            topic.active && learningLinked
        return GTIMFinalProofValueClosureReportV272(
            active = ok,
            versionUnified = versionUnified,
            paperUnderstandingLinked = RuntimeFeatureFlags.ENABLE_PAPER_UNDERSTANDING_LITE_V272,
            promisingRouteLinked = RuntimeFeatureFlags.ENABLE_PROMISING_ROUTE_STATE_V272,
            proofOfValueLinked = RuntimeFeatureFlags.ENABLE_PROOF_OF_VALUE_MODE_V272,
            topicRouteLinked = topic.active,
            learningLoopLinked = learningLinked,
            closureState = if (ok) "PROOF_OF_VALUE_ROUTE_LEARNING_CYCLE_CLOSED" else "PROOF_OF_VALUE_ROUTE_LEARNING_CYCLE_INCOMPLETE",
            nextAction = if (ok) "Run GitHub Gradle test/build, then benchmark the five fixed questions before adding features." else "Repair version, paper-understanding, route-state, proof-of-value, topic-route, or learning-loop linkage."
        )
    }
}
