package com.immunesignal.app

/**
 * v2.7.9.1 — isolated therapeutic protocol surface.
 *
 * Splits therapeutic reverse-translation rendering out of GTIMBriefExecutionSurfaceV2790
 * so therapeutic lanes can evolve without expanding the global brief renderer. This class
 * is display-only and preserves the compatibility tokens expected by older tests/audits.
 */
object GTIMTherapeuticProtocolSurfaceV2791 {
    const val VERSION: String = "2.7.9.1-therapeutic-protocol-surface-split"

    fun buildLines(
        report: GTIMTherapeuticReverseTranslationReportV2790,
        safety: GTIMTherapeuticProtocolSafetyReportV2791,
        maxLine: Int = 460
    ): List<String> {
        if (!report.active) return emptyList()
        val lines = mutableListOf<String>()
        lines += clip(GTIMTherapeuticReverseTranslationRouterV2790.compactLine(report), maxLine)
        lines += clip(safety.etlDependencyLine, maxLine)
        lines += clip(report.interventionLine, 400)
        lines += clip(report.evidenceGateLine, 400)
        lines += clip(report.resistanceFailureLine, 400)
        lines += clip(report.datasetRequirementLine, maxLine)
        lines += clip(report.etlRoutingLine, 440)
        lines += clip(safety.claimLockLine, 420)
        lines += clip(safety.stopRulesLine, 420)
        lines += clip(report.boundaryLine, 360)
        return lines
    }

    private fun clip(value: String, max: Int): String {
        val oneLine = value.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1).trimEnd() + "…"
    }
}
