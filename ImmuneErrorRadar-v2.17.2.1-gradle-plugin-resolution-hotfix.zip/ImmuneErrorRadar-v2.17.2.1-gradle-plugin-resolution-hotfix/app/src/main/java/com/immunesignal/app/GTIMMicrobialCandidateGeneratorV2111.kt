package com.immunesignal.app

// v2.11.1 — Generates candidate classes from counter-functions without naming a DIY organism or protocol.
object GTIMMicrobialCandidateGeneratorV2111 {
    const val VERSION: String = "2.11.1-microbial-candidate-generator"
    const val CLAIM_LIMIT: String = "research_candidate_not_treatment_not_dosing_not_wet_lab_or_engineering_protocol"

    fun generate(
        functions: List<GTIMMicrobialCounterFunctionV2111>,
        corpus: String,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): List<GTIMMicrobialReversalCandidateV2111> {
        val routes = mutableListOf<GTIMMicrobialReversalCandidateV2111>()
        functions.forEach { function ->
            val routeClass = routeClassFor(function)
            val role = roleFor(function, routeClass)
            val rank = GTIMMicrobialReversalEvidenceLadderV2111.rank(function, corpus, dgeVerdict)
            val missing = (function.requiredEvidence + missingFor(routeClass, rank) + dgeVerdict.blockers.map { "DGE blocker: $it" }).distinct().take(8)
            val risks = risksFor(routeClass)
            routes += candidate(function, routeClass, role, rank, missing, risks)
        }
        return routes.distinctBy { it.candidateId }.take(8)
    }

    private fun routeClassFor(function: GTIMMicrobialCounterFunctionV2111): String = when {
        function.functionId.contains("phage", true) -> "bacteriophage_or_antagonist_precision_route"
        function.functionId.contains("toxin", true) -> "microbial_toxin_sink_or_biotransformation_route"
        function.functionId.contains("barrier", true) -> "natural_commensal_or_postbiotic_barrier_route"
        function.functionId.contains("tolerance", true) -> "immune_tolerance_retraining_consortium_or_metabolite_route"
        function.functionId.contains("metabolite", true) -> "metabolite_restoration_or_postbiotic_route"
        function.functionId.contains("engineered", true) -> "engineered_living_sensor_actor_theoretical_route"
        function.functionId.contains("competitive", true) -> "defined_consortium_competitive_displacement_route"
        else -> "open_function_first_microbial_reversal_route"
    }

    private fun roleFor(function: GTIMMicrobialCounterFunctionV2111, routeClass: String): String = when (routeClass) {
        "bacteriophage_or_antagonist_precision_route" -> "weaken a defined harmful bacterium or biofilm while leaving broader ecology as the main restoration target"
        "microbial_toxin_sink_or_biotransformation_route" -> "bind, sequester, transform, or reduce bioavailability of toxic pressure as a research function"
        "natural_commensal_or_postbiotic_barrier_route" -> "restore barrier-support function through commensal, metabolite, or postbiotic logic"
        "immune_tolerance_retraining_consortium_or_metabolite_route" -> "shift immune decision thresholds toward tolerance/recalibration rather than broad suppression"
        "metabolite_restoration_or_postbiotic_route" -> "restore a missing conversion/metabolite signal that may change immune energy or repair context"
        "engineered_living_sensor_actor_theoretical_route" -> "long-horizon design-study concept: sense disease microenvironment and execute bounded local counter-function under containment"
        "defined_consortium_competitive_displacement_route" -> "reoccupy ecological niche and reduce harmful dominance by restoring missing ecosystem function"
        else -> "discover the minimal microbial function that would reverse the nominated damage mechanism"
    }

    private fun missingFor(routeClass: String, rank: String): List<String> = listOf(
        "rank=$rank requires explicit upgrade evidence before belief increase",
        "same-context comparator or negative-control route",
        "mechanism biomarker and directionality check",
        "alternative-explanation review"
    ) + when (routeClass) {
        "engineered_living_sensor_actor_theoretical_route" -> listOf("containment/off-switch evidence", "no horizontal gene-transfer route", "clearance/reversibility test")
        "microbial_toxin_sink_or_biotransformation_route" -> listOf("binding/degradation assay", "safe byproduct analysis", "burden/excretion marker")
        "bacteriophage_or_antagonist_precision_route" -> listOf("target-host-range evidence", "resistance escape review", "polymicrobial-failure test")
        else -> listOf("function-level evidence beyond species-name association")
    }

    private fun risksFor(routeClass: String): List<String> = when (routeClass) {
        "engineered_living_sensor_actor_theoretical_route" -> listOf("containment failure", "horizontal gene transfer", "signal misfire", "uncontrolled colonization", "ecological escape")
        "bacteriophage_or_antagonist_precision_route" -> listOf("resistance escape", "niche replacement by worse organism", "biofilm persistence", "inflammatory debris")
        "microbial_toxin_sink_or_biotransformation_route" -> listOf("harmful byproduct", "false detox claim", "no excretion route", "context-specific binding failure")
        "immune_tolerance_retraining_consortium_or_metabolite_route" -> listOf("immune over-suppression", "wrong subgroup", "flare of inflammatory pathway", "tolerance marker ambiguity")
        else -> listOf("dysbiosis", "uncontrolled colonization", "inflammation", "correlation mistaken for causation")
    }

    private fun candidate(
        function: GTIMMicrobialCounterFunctionV2111,
        routeClass: String,
        role: String,
        rank: String,
        missing: List<String>,
        risks: List<String>
    ): GTIMMicrobialReversalCandidateV2111 {
        val id = "MRC_${function.functionId.uppercase()}".replace(Regex("[^A-Z0-9_]+"), "_").take(92)
        val allowed = GTIMMicrobialReversalEvidenceLadderV2111.allowedClaim(rank)
        val line = "Microbial reversal candidate: version=$VERSION | id=$id | class=$routeClass | source_function=${function.functionId} | evidence_rank=$rank | allowed_claim=$allowed | role=${role.oneLine()} | missing=${missing.joinToString(";").oneLine()} | biosafety=${risks.joinToString(";").oneLine()} | claim_limit=$CLAIM_LIMIT"
        return GTIMMicrobialReversalCandidateV2111(id, routeClass, function.functionId, role, rank, missing, risks, CLAIM_LIMIT, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
