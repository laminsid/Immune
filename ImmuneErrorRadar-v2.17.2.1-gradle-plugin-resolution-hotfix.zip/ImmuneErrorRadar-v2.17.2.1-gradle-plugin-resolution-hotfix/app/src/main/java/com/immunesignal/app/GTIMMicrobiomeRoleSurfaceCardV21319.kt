package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Compact first-surface microbiome role card. */
object GTIMMicrobiomeRoleSurfaceCardV21319 {
    const val VERSION: String = "2.13.19-microbiome-role-surface-card"

    fun toJson(report: JSONObject): JSONObject {
        val organ = GTIMGutMicrobiomeImmuneOrganEngineV21319.toJson(report)
        val metabolite = GTIMMicrobialMetaboliteSignalMapperV21319.toJson(report)
        val axis = GTIMGutAxisMapperV21319.toJson(report)
        val onco = GTIMOncoMicrobiomeImmunotherapyLensV21319.toJson(report)
        val lbp = GTIMLiveBiotherapeuticProductLensV21319.toJson(report)
        return JSONObject()
            .put("version", VERSION)
            .put("state", "MICROBIOME_ROLE_CARD_READY")
            .put("microbiome_role", organ.optString("microbiome_role"))
            .put("metabolite_axes", metabolite.optJSONArray("mapped_axes") ?: JSONArray())
            .put("gut_axes", axis.optJSONArray("gut_axes") ?: JSONArray())
            .put("onco_microbiome_lens", onco)
            .put("live_biotherapeutic_product_lens", lbp)
            .put("claim_boundary", "microbiome signal != microbiome cause; microbiome intervention lens != treatment recommendation")
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Microbiome role card",
            "Microbiome role: ${obj.optString("microbiome_role")}; metabolite_axes=${obj.optJSONArray("metabolite_axes") ?: JSONArray()}; gut_axes=${obj.optJSONArray("gut_axes") ?: JSONArray()}.",
            "Onco-microbiome lens: applicable=${obj.optJSONObject("onco_microbiome_lens")?.optBoolean("applicable") ?: false}; response modifier only, not validated predictor.",
            "LBP lens: ${obj.optJSONObject("live_biotherapeutic_product_lens")?.optJSONArray("modalities") ?: JSONArray()}; not prescription or treatment recommendation.",
            "Boundary: ${obj.optString("claim_boundary")}"
        )
    }
}
