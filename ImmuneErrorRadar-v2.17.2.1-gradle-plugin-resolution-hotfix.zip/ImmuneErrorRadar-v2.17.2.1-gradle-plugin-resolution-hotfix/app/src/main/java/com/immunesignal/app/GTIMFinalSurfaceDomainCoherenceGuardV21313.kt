package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * legacy_v21314_compat_marker: 2.13.12.4-generalized-route-coherence-runtime-budget; 2.13.12.3-final-surface-domain-coherence-runtime-budget; 2.13.12.3-mobile-safe-first-surface.
 * v2.13.14.3 — final surface domain coherence + mobile/runtime budget guard.
 *
 * This is a rendering and orchestration layer only. It does not delete legacy rails and
 * does not create biological evidence. It forces the first decision surface to follow the
 * active domain + canonical target selected by the newer route locks; mismatched legacy
 * blocks are moved to compatibility/appendix semantics.
 * legacy_v21313_audit_marker: 2.13.14-final-generalized-route-coherence-unified; filovirus host-response study; GSE152202; superseded_by_canonical_target.
 * v2.13.14.4 generalizes the algorithm beyond COVID/filovirus via GTIMGeneralizedRouteCoherenceGuardV21314.
 */
object GTIMFinalSurfaceDomainCoherenceGuardV21313 {
    // legacy_v21314_active_compat: VERSION: String = "2.13.14-final-generalized-route-coherence-unified"
    const val VERSION: String = "2.13.15-final-hypothesis-first-discovery-unified"
    const val CLAIM_LIMIT: String = "generalized_final_surface_domain_coherence_only_no_evidence_or_clinical_claim"
    const val MAX_FIRST_SURFACE_LINES: Int = 96
    const val MAX_FIRST_SURFACE_CHARS: Int = 18000

    private val covidPostViralHandles = setOf("GSE152202", "GSE166552", "GSE152418", "GSE157103")

    fun activeDomain(report: JSONObject): String {
        val fallback = firstNonBlank(
            report.optJSONObject("finalRouteSearchHardeningClosureV213103")?.optString("activeDomain").orEmpty(),
            report.optJSONObject("finalUnifiedDiscoveryReadinessClosureV21310")?.optString("activeDomain").orEmpty(),
            report.optJSONObject("finalBundibugyoSearchRuntimeClosureV213106")?.optString("activeDomain").orEmpty(),
            report.optJSONObject("activeDomainConsistencyGuardV2134")?.optString("activeDomain").orEmpty(),
            report.optJSONObject("activeDomainConsistencyGuardV2134")?.optString("activeDomainKey").orEmpty(),
            GTIMFinalBundibugyoSearchRuntimeClosureV213106.effectiveActiveDomain(report)
        )
        return GTIMGeneralizedRouteCoherenceGuardV21314.effectiveActiveDomain(report, fallback)
    }

    fun activeSubtype(report: JSONObject): String = GTIMDomainScopedClosureRendererV21315.normalizedSubtype(activeDomain(report), firstNonBlank(
        report.optJSONObject("finalRouteSearchHardeningClosureV213103")?.optString("activeSubtype").orEmpty(),
        report.optJSONObject("finalUnifiedDiscoveryReadinessClosureV21310")?.optString("activeSubtype").orEmpty(),
        report.optJSONObject("finalBundibugyoSearchRuntimeClosureV213106")?.optString("activeSubtype").orEmpty(),
        report.optJSONObject("activeDomainConsistencyGuardV2134")?.optString("activeSubtype").orEmpty(),
        GTIMFinalBundibugyoSearchRuntimeClosureV213106.effectiveSubtype(report)
    ))

    fun canonicalTarget(report: JSONObject): String =
        GTIMGeneralizedRouteCoherenceGuardV21314.canonicalTargetFor(report, activeDomain(report))

    fun shouldUseMobileSafeSurface(report: JSONObject): Boolean =
        report.has("canonicalFinalSurfaceGuardV2135") ||
            report.has("finalUnifiedDiscoveryReadinessClosureV21310") ||
            report.has("finalRouteSearchHardeningClosureV213103") ||
            report.has("finalBundibugyoSearchRuntimeClosureV213106")

    fun toJson(report: JSONObject): JSONObject {
        val active = activeDomain(report)
        val subtype = activeSubtype(report)
        val canonical = canonicalTarget(report)
        val quarantined = quarantinedLegacyHandles(active, canonical)
        return JSONObject()
            .put("version", VERSION)
            .put("generalizedRouteCoherenceVersion", GTIMGeneralizedRouteCoherenceGuardV21314.VERSION)
            .put("algorithm", "generic_block_domain_inference_then_active_domain_match")
            .put("oneOffCovidOrFilovirusRule", false)
            .put("activeDomain", active)
            .put("activeSubtype", subtype)
            .put("canonicalTarget", canonical)
            .put("firstSurfacePolicy", "active_domain_and_canonical_target_only; any mismatched domain/pathogen/handle becomes appendix_or_superseded_only")
            .put("legacyRailsLinked", true)
            .put("legacyRailsPlacement", "technical_appendix_or_historical_lookup_only")
            .put("maxFirstSurfaceLines", MAX_FIRST_SURFACE_LINES)
            .put("maxFirstSurfaceChars", MAX_FIRST_SURFACE_CHARS)
            .put("quarantinedLegacyHandles", JSONArray(quarantined))
            .put("mobileRuntimePolicy", "compact_preview_on_device; full JSON/appendix retained for export/audit; duplicate legacy surfaces not rendered on first surface")
            .put("claimPromotionAllowed", true)
            .put("generalizedGuard", GTIMGeneralizedRouteCoherenceGuardV21314.toJson(report, active))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final surface domain-coherence guard",
        "State: FINAL_SURFACE_DOMAIN_COHERENCE_READY; active_domain=${obj.optString("activeDomain", "unknown")}; subtype=${obj.optString("activeSubtype", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}",
        "Policy: ${obj.optString("firstSurfacePolicy", "active-domain first surface only")}",
        "Runtime budget: first_surface_lines<=${obj.optInt("maxFirstSurfaceLines", MAX_FIRST_SURFACE_LINES)}; first_surface_chars<=${obj.optInt("maxFirstSurfaceChars", MAX_FIRST_SURFACE_CHARS)}; legacy_rails_linked=${obj.optBoolean("legacyRailsLinked", true)}",
        "Boundary: rendering coherence only; no mechanism, diagnosis, treatment, dosing, vaccine, efficacy, or validated discovery claim."
    )

    fun studyFocusFor(activeDomain: String, fallback: String = "immune host-response study"): String =
        GTIMGeneralizedRouteCoherenceGuardV21314.studyFocusFor(activeDomain, fallback)

    fun domainLineFor(activeDomain: String, fallback: String = ""): String =
        GTIMGeneralizedRouteCoherenceGuardV21314.domainLineFor(activeDomain, fallback)

    fun topHypothesisFor(activeDomain: String, fallback: String = ""): String =
        GTIMGeneralizedRouteCoherenceGuardV21314.topHypothesisFor(activeDomain, fallback)

    fun repairFunctionFor(activeDomain: String, fallback: String = ""): String =
        GTIMGeneralizedRouteCoherenceGuardV21314.repairFunctionFor(activeDomain, fallback)

    fun biologicalToolFor(activeDomain: String, fallback: String = ""): String =
        GTIMGeneralizedRouteCoherenceGuardV21314.biologicalToolFor(activeDomain, fallback)

    fun sanitizeFirstSurfaceLines(report: JSONObject, lines: List<String>): List<String> {
        return GTIMGeneralizedRouteCoherenceGuardV21314.sanitizeFirstSurfaceLines(
            report = report,
            fallbackActiveDomain = activeDomain(report),
            canonicalTarget = canonicalTarget(report),
            lines = lines
        )
    }

    fun sanitizeLine(line: String, activeDomain: String, canonicalTarget: String): String? {
        return GTIMGeneralizedRouteCoherenceGuardV21314.sanitizeLine(
            line = line,
            activeDomain = activeDomain,
            subtype = "",
            canonicalTarget = canonicalTarget
        )
    }

    private fun quarantinedLegacyHandles(activeDomain: String, canonicalTarget: String): List<String> =
        covidPostViralHandles.filterNot { GTIMGeneralizedRouteCoherenceGuardV21314.domainCompatible(activeDomain, "viral_interferon_cytokine") || it.equals(canonicalTarget, ignoreCase = true) }

    private fun isHistoricalOrBlockedContext(lower: String): Boolean = listOf(
        "historical lookup only",
        "superseded_by_canonical_target",
        "not_active_target",
        "blocked_covid",
        "blocked generic",
        "cannot use covid",
        "background/contradiction",
        "contradiction/background",
        "appendix",
        "compatibility"
    ).any { lower.contains(it) }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}
