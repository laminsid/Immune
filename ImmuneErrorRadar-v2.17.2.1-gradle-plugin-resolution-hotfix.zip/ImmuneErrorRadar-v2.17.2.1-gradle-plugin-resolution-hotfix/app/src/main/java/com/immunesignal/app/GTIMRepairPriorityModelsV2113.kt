package com.immunesignal.app

// v2.11.3 — Repair priority and biomarker/falsification validation models.

data class GTIMRepairPriorityRouteV2113(
    val priorityId: String,
    val routeClass: String,
    val sourceRouteId: String,
    val impactRank: String,
    val testabilityRank: String,
    val riskRank: String,
    val priorityState: String,
    val biomarkerPlan: List<String>,
    val falsificationPlan: List<String>,
    val minimalDataPack: List<String>,
    val upgradeRule: String,
    val line: String
)

data class GTIMRepairPriorityValidationReportV2113(
    val active: Boolean,
    val version: String,
    val state: String,
    val priorityRoutes: List<GTIMRepairPriorityRouteV2113>,
    val globalBiomarkerPlan: List<String>,
    val globalFalsificationPlan: List<String>,
    val boundaryLine: String,
    val line: String
) {
    companion object {
        fun empty(): GTIMRepairPriorityValidationReportV2113 = GTIMRepairPriorityValidationReportV2113(
            active = false,
            version = GTIMRepairPriorityValidationEngineV2113.VERSION,
            state = "REPAIR_PRIORITY_NOT_EVALUATED",
            priorityRoutes = emptyList(),
            globalBiomarkerPlan = emptyList(),
            globalFalsificationPlan = emptyList(),
            boundaryLine = GTIMRepairPriorityValidationEngineV2113.BOUNDARY,
            line = "Repair priority validation: not evaluated."
        )
    }
}
