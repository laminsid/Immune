package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.15 — Hypothesis-first discovery engine.
 *
 * This is the central decision repair for GTIM: hypothesis generation is no longer
 * blocked by evidence-upgrade gates. A clear active domain is enough to emit a bounded
 * C0 route hypothesis. A compatible canonical target upgrades the output to C1/C1+
 * research-candidate status. C2/C3 sandbox preview is allowed even when module scores,
 * comparator/sample provenance, replication, negative controls, or contradiction review
 * are missing. Those gaps are execution tasks, not preview blockers. Only patient action,
 * dosing, clinical implementation, or validated proof claims remain blocked.
 */
object GTIMHypothesisFirstDiscoveryEngineV21315 {
    const val VERSION: String = "2.13.15-final-hypothesis-first-discovery-unified"
    const val ENGINE_VERSION: String = "v2.13.15-final-hypothesis-first-discovery-unified"
    const val CLAIM_LIMIT: String = "hypothesis_first_c2c3_preview_relaxed_validated_proof_clinical_claims_blocked"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val subtype = GTIMDomainScopedClosureRendererV21315.normalizedSubtype(active, GTIMFinalSurfaceDomainCoherenceGuardV21313.activeSubtype(report))
        val canonical = GTIMFinalSurfaceDomainCoherenceGuardV21313.canonicalTarget(report)
        val hypothesis = GTIMGeneralizedRouteCoherenceGuardV21314.topHypothesisFor(active)
        val repair = GTIMGeneralizedRouteCoherenceGuardV21314.repairFunctionFor(active)
        val tool = GTIMGeneralizedRouteCoherenceGuardV21314.biologicalToolFor(active)
        val focus = GTIMGeneralizedRouteCoherenceGuardV21314.studyFocusFor(active)
        val synthesis = report.optJSONObject("discoverySynthesisCardV2137") ?: JSONObject()
        val c2 = report.optJSONObject("finalC2InnovationReadinessClosureV2139") ?: JSONObject()
        val matrix = report.optJSONObject("matrixShortcutResolverV2124") ?: JSONObject()
        val capsule = report.optJSONObject("evidenceCapsuleBuilderV21218") ?: JSONObject()
        val comparator = report.optJSONObject("comparatorSampleProvenanceExtractorV21218") ?: JSONObject()
        val contradiction = report.optJSONObject("contradictionSearchEngineV21218") ?: JSONObject()
        val replication = report.optJSONObject("executableReplicationMatrixV2139") ?: JSONObject()

        val hypothesisBlockers = JSONArray()
        if (active.isBlank() || active == "open_mechanism_first" || active == "topic_level_route_needs_evidence") hypothesisBlockers.put("active_domain_not_locked")

        val executionTasks = JSONArray()
        if (canonical.isBlank()) executionTasks.put("canonical_target_missing")
        if (!looksClosed(comparator, "comparator") && !containsReady(comparator.optString("comparatorStatus"))) executionTasks.put("comparator_labels_not_closed")
        if (!looksClosed(comparator, "sample") && !containsReady(comparator.optString("sampleProvenanceStatus"))) executionTasks.put("sample_provenance_not_closed")
        if (!containsReady(matrix.optString("state")) && !containsReady(capsule.optString("state"))) executionTasks.put("processed_capsule_or_matrix_not_closed")
        if (!hasModuleScores(report)) executionTasks.put("module_score_direction_effect_size_fdr_missing")
        if (!containsReady(replication.optString("state")) || replication.optInt("replicationCandidates", 0) <= 0) executionTasks.put("replication_not_executed")
        if (!containsClosedOrReady(contradiction.optString("state")) && !containsClosedOrReady(contradiction.optString("contradictionRule"))) executionTasks.put("contradiction_resistance_not_closed")
        executionTasks.put("negative_control_required_before_C2_or_higher")

        val clinicalClaimBlockers = JSONArray(listOf(
            "patient_action_blocked",
            "dosing_protocol_blocked",
            "clinical_implementation_blocked",
            "validated_proof_claim_blocked"
        ))

        val level = when {
            canonical.isBlank() -> "C0_ROUTE_HYPOTHESIS"
            synthesis.optString("innovationLevel").contains("C1_PLUS", ignoreCase = true) ||
                c2.optString("allowed").contains("C1_READY", ignoreCase = true) -> "C1_PLUS_REPLICATION_READY_CANDIDATE"
            else -> "C1_DISCOVERY_CANDIDATE"
        }
        val state = when (level) {
            "C0_ROUTE_HYPOTHESIS" -> "HYPOTHESIS_FIRST_C0_READY_TARGET_REQUIRED"
            "C1_PLUS_REPLICATION_READY_CANDIDATE" -> "HYPOTHESIS_FIRST_C1_PLUS_READY_C2_C3_PREVIEW_ALLOWED_EXECUTION_TASKS_OPEN"
            else -> "HYPOTHESIS_FIRST_C1_READY_C2_C3_PREVIEW_ALLOWED_EXECUTION_TASKS_OPEN"
        }
        val searchQuery = if (canonical.isBlank()) bestQueryFor(active, subtype) else canonical
        val targetLabel = canonical.ifBlank { "not_selected" }

        val result = JSONObject()
            .put("version", VERSION)
            .put("engineVersion", ENGINE_VERSION)
            .put("state", state)
            .put("activeDomain", active)
            .put("activeSubtype", subtype)
            .put("canonicalTarget", canonical)
            .put("studyFocus", focus)
            .put("primaryResult", level)
            .put("primaryHypothesis", hypothesis)
            .put("mechanismAxis", repair)
            .put("candidateToolClass", tool)
            .put("whyPlausible", whyPlausible(active, targetLabel, repair))
            .put("bestSearchQuery", searchQuery)
            .put("requiredDatasetProfile", requiredDatasetProfile(active))
            .put("falsifier", falsifier(active))
            .put("hypothesisBlockers", hypothesisBlockers)
            .put("executionTasks", executionTasks)
            .put("clinicalClaimBlockers", clinicalClaimBlockers)
            .put("hypothesisAllowed", hypothesisBlockers.length() == 0)
            .put("c2PreviewAllowed", true).put("c3PreviewAllowed", true).put("validatedProofAllowed", false)
            .put("clinicalClaimAllowed", false)
            .put("strictnessPolicy", "hypothesis_generation_relaxed; C2_C3_preview_relaxed_even_without_matrix_or_replication; validated_proof_and_clinical_patient_claims_blocked")
            .put("runtimePolicy", "compact_first_surface; details_and_legacy_rails_to_appendix_export")
            .put("claimLimit", CLAIM_LIMIT)
        return GTIMCapsuleBackedHypothesisBridgeV21316.enrich(report, result)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Primary hypothesis result",
        "Result: ${obj.optString("primaryResult", "C0_ROUTE_HYPOTHESIS")}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none").ifBlank { "none" }}",
        "Hypothesis: ${obj.optString("primaryHypothesis", "route-specific hypothesis not generated")}",
        "Mechanism axis: ${obj.optString("mechanismAxis", "route-specific mechanism axis not generated")}",
        "Why plausible: ${obj.optString("whyPlausible", "active-domain priors support a bounded research hypothesis")}",
        "Best search/execution target: ${obj.optString("bestSearchQuery", "topic-compatible dataset/capsule search")}",
        "Local processed capsule: ${obj.optString("matrixState", "CAPSULE_MISSING_ACQUISITION_TASK_CREATED")}; preview_strength=${obj.optString("capsulePreviewStrength", "C0_ROUTE_SANDBOX_PREVIEW_CAPSULE_MISSING")}",
        "Execution tasks: hypothesis_blockers=${obj.optJSONArray("hypothesisBlockers")?.length() ?: 0}; open_execution_tasks=${obj.optJSONArray("executionTasks")?.length() ?: 0}; clinical_claim_blockers=${obj.optJSONArray("clinicalClaimBlockers")?.length() ?: 0}.",
        "Falsifier: ${obj.optString("falsifier", "downgrade if comparator/module/replication/contradiction checks fail")}",
        "Boundary: C0/C1/C2/C3 sandbox preview is allowed even without matrix or replication; missing matrix/replication are execution tasks only; no patient action, dosing, clinical implementation, or validated proof."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "HYPOTHESIS_FIRST_C0_READY_TARGET_REQUIRED",
        "C1_PLUS_REPLICATION_READY_CANDIDATE",
        "hypothesis_generation_relaxed; C2_C3_preview_relaxed_even_without_matrix_or_replication; validated_proof_and_clinical_patient_claims_blocked",
        "hypothesisBlockers",
        "executionTasks",
        "clinicalClaimBlockers",
        CLAIM_LIMIT,
        "LOCAL_PROCESSED_CAPSULE_AVAILABLE",
        "capsuleBackedPreviewAllowed"
    ))

    private fun hasModuleScores(report: JSONObject): Boolean {
        val placeholder = report.optJSONObject("moduleScorePlaceholderEngineV2138") ?: JSONObject()
        val rows = placeholder.optJSONArray("moduleRows") ?: placeholder.optJSONArray("modules")
        return rows != null && rows.length() > 0 && placeholder.optString("state").contains("READY", ignoreCase = true) &&
            !placeholder.optString("c2Blocker").contains("missing", ignoreCase = true)
    }

    private fun containsReady(value: String): Boolean = value.contains("READY", ignoreCase = true) || value.contains("PARTIAL", ignoreCase = true)
    private fun containsClosedOrReady(value: String): Boolean = value.contains("CLOSED", ignoreCase = true) || value.contains("READY", ignoreCase = true) || value.contains("RESIST", ignoreCase = true)
    private fun looksClosed(obj: JSONObject, key: String): Boolean = obj.toString().contains(key, ignoreCase = true) && obj.toString().contains("true", ignoreCase = true)

    private fun whyPlausible(active: String, target: String, repair: String): String = when {
        target != "not_selected" -> "active domain is locked and canonical target $target is available for review; $repair"
        active.startsWith("viral_") || active.contains("filovirus") -> "pathogen-specific host-response priors support a route hypothesis, but a compatible accession/capsule is still required."
        active == "allergy_type2_barrier" -> "type-2/barrier priors support a testable threshold-instability hypothesis; target/capsule quality controls evidence upgrade."
        else -> "active-domain priors support a bounded route hypothesis; evidence gates decide upgrade only."
    }

    private fun bestQueryFor(active: String, subtype: String): String = when (active) {
        "filovirus_viral_host_response" -> if (subtype.contains("bundibugyo", true)) "Bundibugyo Ebola BDBV host response severity survival expression dataset" else "filovirus Ebola host response severity survival expression dataset"
        "viral_hantavirus_host_response" -> "hantavirus host response endothelial vascular severity expression dataset"
        "viral_dengue_host_response" -> "dengue severity vascular leak host response expression dataset"
        "viral_zika_host_response" -> "Zika host response interferon tissue tropism expression dataset"
        "viral_influenza_host_response" -> "influenza severity epithelial interferon cytokine expression dataset"
        "viral_interferon_cytokine" -> "COVID post-viral interferon cytokine severity recovery expression dataset"
        "allergy_type2_barrier" -> "allergy type-2 IgE mast eosinophil epithelial barrier expression dataset"
        "depression_kynurenine_neuroimmune" -> "depression kynurenine IDO1 KMO neuroimmune expression dataset"
        else -> "$active immune host response comparator expression dataset"
    }

    private fun requiredDatasetProfile(active: String): String = when (active) {
        "allergy_type2_barrier" -> "allergy/type-2 cohort with comparator labels, epithelial/barrier and IgE/mast/eosinophil/type-2 cytokine readouts, and processed matrix/capsule."
        "filovirus_viral_host_response" -> "filovirus/BDBV-compatible cohort with severity or survival labels, sample provenance, and interferon/endothelial/coagulation module readouts."
        else -> "topic-compatible cohort with comparator labels, sample provenance, processed capsule/matrix, module scoring, negative control, and contradiction dataset."
    }

    private fun falsifier(active: String): String = when (active) {
        "allergy_type2_barrier" -> "downgrade if type-2/barrier markers do not separate comparator groups or fail replication/negative-control checks."
        "filovirus_viral_host_response" -> "downgrade if interferon/endothelial/coagulation timing does not separate severity/survival labels or is explained by batch/cell-composition artifacts."
        else -> "downgrade if the nominated module fails comparator separation, provenance review, negative control, replication, or contradiction checks."
    }
}
