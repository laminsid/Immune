package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** v2.12.18 — minimum viable study protocol draft. Research-only, no clinical protocol. */
object GTIMMinimumViableStudyProtocolV21218 {
    const val VERSION: String = "2.12.18-minimum-viable-study-protocol"
    const val CLAIM_LIMIT: String = "research_protocol_draft_only_not_clinical_trial_or_medical_advice"

    fun toJson(report: JSONObject): JSONObject {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val target = report.optJSONObject("targetValidationCardV21213") ?: JSONObject()
        val novelty = report.optJSONObject("noveltyScoringEngineV21218") ?: JSONObject()
        val selected = ledger.optString("selectedReviewTarget", "topic-compatible dataset")
        val domain = ledger.optString("domainKey", "current_topic")
        val text = report.toString().lowercase(Locale.US)
        val readouts = target.optJSONArray("readouts") ?: JSONArray(readoutFallback(text))
        val protocol = JSONObject()
            .put("studyQuestion", studyQuestion(domain, text))
            .put("population", population(text))
            .put("comparator", comparator(text))
            .put("sampleType", sampleType(text))
            .put("primaryReadouts", readouts)
            .put("datasetNeeded", selected)
            .put("primaryEndpoint", "group separation or severity/recovery association in predefined target/readout module")
            .put("secondaryEndpoint", "contradiction resistance across at least one independent dataset or literature/capsule route")
            .put("falsificationRule", "Reject or downgrade if comparator labels, sample provenance, or target/readout separation cannot be verified.")
            .put("minimumViableExperiment", minimumExperiment(domain, selected))
        return JSONObject()
            .put("version", VERSION)
            .put("state", "MINIMUM_VIABLE_STUDY_PROTOCOL_READY")
            .put("selectedReviewTarget", selected)
            .put("domainKey", domain)
            .put("noveltyState", novelty.optString("state", "not_scored"))
            .put("protocol", protocol)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val p = obj.optJSONObject("protocol") ?: JSONObject()
        return listOf(
            "Minimum viable study protocol",
            "State: ${obj.optString("state", "UNKNOWN")}; selected_review_target=${obj.optString("selectedReviewTarget", "none")}; domain=${obj.optString("domainKey", "unknown")}",
            "Study question: ${p.optString("studyQuestion", "test whether the route separates defined biological/phenotype groups")}",
            "Population/comparator/sample: ${p.optString("population", "topic cohort")} / ${p.optString("comparator", "matched controls or severity groups")} / ${p.optString("sampleType", "topic-relevant sample")}",
            "Minimum viable experiment: ${p.optString("minimumViableExperiment", "verify comparator + sample provenance + readout module in one dataset")}",
            "Falsification rule: ${p.optString("falsificationRule", "downgrade if hard gates fail")}",
            "Boundary: protocol is a research planning draft, not a clinical trial protocol, medical advice, or treatment recommendation."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "MINIMUM_VIABLE_STUDY_PROTOCOL_READY", "minimumViableExperiment", CLAIM_LIMIT))

    private fun studyQuestion(domain: String, text: String): String = when {
        domain.contains("depression") || text.contains("kynurenine") -> "Do IDO1/KMO and tryptophan-kynurenine readouts stratify depression or high-inflammatory subgroups?"
        domain.contains("viral") || text.contains("covid") || text.contains("ebola") -> "Do interferon timing and IL-6/TNF/host-response modules track severity, recovery, or persistence?"
        domain.contains("allergy") || text.contains("type-2") -> "Do IgE/eosinophil/mast/epithelial barrier readouts separate type-2/allergy phenotypes?"
        else -> "Does the nominated target/readout module separate the topic phenotype from comparator groups?"
    }

    private fun population(text: String): String = when {
        text.contains("depression") -> "human depression/control or inflammatory-subgroup cohort"
        text.contains("covid") -> "human COVID/post-viral cohort with recovery/severity labels"
        text.contains("ebola") || text.contains("filovirus") -> "filovirus/viral hemorrhagic fever host-response cohort"
        text.contains("allergy") -> "human allergy/type-2 phenotype cohort"
        else -> "topic-relevant human-first cohort where available"
    }

    private fun comparator(text: String): String = when {
        text.contains("severity") || text.contains("recovery") -> "severity/recovery groups plus controls if available"
        text.contains("depression") -> "depression vs control, or high-inflammation vs low-inflammation subgroup"
        text.contains("allergy") -> "allergy/type-2 phenotype vs non-allergic/control groups"
        else -> "case/control or exposure/severity groups"
    }

    private fun sampleType(text: String): String = when {
        text.contains("brain") -> "brain tissue if ethically/publicly available; blood/PBMC as translational proxy"
        text.contains("pbmc") || text.contains("blood") -> "blood/PBMC"
        text.contains("barrier") || text.contains("epithelial") -> "epithelial/barrier tissue or blood proxy with phenotype labels"
        else -> "topic-relevant tissue with sample-level metadata"
    }

    private fun readoutFallback(text: String): List<String> = when {
        text.contains("kynurenine") -> listOf("IDO1", "KMO", "kynurenine/tryptophan ratio", "IL-6/TNF tone")
        text.contains("viral") || text.contains("interferon") -> listOf("IFN module timing", "IL-6/TNF", "CRP/inflammatory tone", "severity/recovery labels")
        text.contains("allergy") -> listOf("IgE", "eosinophil/mast markers", "IL-4/IL-13", "epithelial barrier markers")
        else -> listOf("target expression/module", "immune mediator", "phenotype label")
    }

    private fun minimumExperiment(domain: String, selected: String): String = "Use $selected as the first review target: confirm topic-fit, comparator labels, sample provenance, and processed capsule; then test the domain module ($domain) against phenotype labels and one contradiction route."
}
