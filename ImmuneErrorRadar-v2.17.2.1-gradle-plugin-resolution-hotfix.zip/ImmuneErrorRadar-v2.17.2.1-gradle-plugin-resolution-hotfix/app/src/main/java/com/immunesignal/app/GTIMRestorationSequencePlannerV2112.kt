package com.immunesignal.app

// v2.11.2 — Plans a research-only restoration sequence for each collapse signal.
object GTIMRestorationSequencePlannerV2112 {
    const val VERSION: String = "2.11.2-restoration-sequence-planner"

    fun plan(
        collapseSignals: List<GTIMEcologicalCollapseSignalV2112>,
        microbialReversal: GTIMMicrobialReversalReportV2111?
    ): List<GTIMRestorationSequenceV2112> {
        val microbialBridge = microbialReversal?.candidateRoutes?.firstOrNull()
        return collapseSignals.mapIndexed { index, signal ->
            val seq = when (signal.signalId) {
                "LOW_DIVERSITY_OR_FUNCTION_LOSS" -> sequence(
                    index,
                    signal,
                    first = "restore missing microbial/metabolite function before naming a disease-specific route",
                    second = "barrier tone, immune tolerance, and inflammatory baseline may become measurable recovery proxies",
                    markers = listOf("microbial functional diversity", "SCFA/metabolite direction", "barrier marker", "inflammatory marker"),
                    failures = listOf("no functional shift", "inflammation rises", "metabolite direction contradicts repair"),
                    microbialRole = microbialBridge?.hypotheticalRole ?: "natural or defined microbial function as ecosystem stabilizer"
                )
                "BARRIER_FAILURE" -> sequence(
                    index,
                    signal,
                    first = "test barrier-support and mucosal-tolerance restoration as the first repair function",
                    second = "lower antigen/exposure leakage could reduce chronic immune activation",
                    markers = listOf("permeability or mucosal marker", "mucus/epithelial integrity proxy", "local cytokine tone", "microbial metabolite bridge"),
                    failures = listOf("barrier markers unchanged", "local inflammation increases", "effect appears only symptomatic"),
                    microbialRole = "microbial/metabolite support for mucus, epithelial integrity, and local immune tolerance"
                )
                "IMMUNE_OVERACTIVATION" -> sequence(
                    index,
                    signal,
                    first = "separate immune recalibration from broad suppression and require discriminating biomarkers",
                    second = "tolerance markers and cytokine durability may reveal whether the loop is actually being repaired",
                    markers = listOf("cytokine panel", "Treg/Th balance", "mast-cell or IgE context where relevant", "longitudinal symptom-independent marker"),
                    failures = listOf("suppression without recalibration", "autoimmune/allergic marker worsens", "no time-direction evidence"),
                    microbialRole = "microbial/postbiotic route only if it maps to immune decision thresholds"
                )
                "TOXIN_OR_EXPOSOME_PRESSURE" -> sequence(
                    index,
                    signal,
                    first = "measure or contextualize exposure pressure before claiming restoration",
                    second = "reduced burden, improved barrier response, or lower inflammatory pressure would be recovery proxies",
                    markers = listOf("exposure/burden marker", "oxidative stress marker", "barrier marker", "excretion or reduced-bioavailability proxy"),
                    failures = listOf("no exposure match", "harmful byproduct", "no burden reduction", "effect depends on uncontrolled context"),
                    microbialRole = microbialBridge?.hypotheticalRole ?: "microbial toxin-sink or biotransformation hypothesis with safety guard"
                )
                else -> sequence(
                    index,
                    signal,
                    first = "identify the missing stabilizing function before selecting a candidate intervention family",
                    second = "the first useful result is a better dysfunction map, not a medical claim",
                    markers = listOf("mechanism biomarker", "context-specific comparator", "time-direction evidence", "negative-control route"),
                    failures = listOf("no coherent mechanism", "candidate route lacks measurement", "alternative explanation dominates"),
                    microbialRole = "open microbial/metabolic/exposome repair route until evidence distinguishes the dysfunction"
                )
            }
            seq
        }.take(6)
    }

    private fun sequence(index: Int, signal: GTIMEcologicalCollapseSignalV2112, first: String, second: String, markers: List<String>, failures: List<String>, microbialRole: String): GTIMRestorationSequenceV2112 {
        val id = "RESTORATION_SEQUENCE_${index + 1}_${signal.signalId}".take(96)
        val confidence = if (signal.signalId.startsWith("OPEN")) "WEAK_OPEN_RESTORATION_ROUTE" else "PLAUSIBLE_RESTORATION_ROUTE_NEEDS_CAUSAL_TEST"
        val line = "Restoration sequence: version=$VERSION | id=$id | collapse=${signal.signalId} | first_repair=${first.oneLine()} | second_order=${second.oneLine()} | recovery_markers=${markers.joinToString(";").oneLine()} | failure_signals=${failures.joinToString(";").oneLine()} | microbial_role=${microbialRole.oneLine()} | confidence=$confidence"
        return GTIMRestorationSequenceV2112(id, signal.signalId, first, second, markers, failures, microbialRole, confidence, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
