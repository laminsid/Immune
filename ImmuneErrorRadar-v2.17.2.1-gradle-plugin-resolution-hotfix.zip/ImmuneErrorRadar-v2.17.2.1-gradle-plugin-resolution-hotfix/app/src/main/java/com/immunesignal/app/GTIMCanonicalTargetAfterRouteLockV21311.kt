package com.immunesignal.app

import org.json.JSONObject
import java.util.Locale

object GTIMCanonicalTargetAfterRouteLockV21311 {
    fun canonicalTarget(report: JSONObject): String {
        val intent = GTIMRouteConfidenceGateV21311.infer(report)
        if (!intent.locked) return ""
        val handles = intent.handles.map { it.uppercase(Locale.US) }
        fun first(vararg allowed: String): String = allowed.firstOrNull { it.uppercase(Locale.US) in handles }.orEmpty()
        return when (intent.lockedSubtype) {
            "viral_filovirus_bundibugyo" -> first("BDBV_COMPATIBLE_CAPSULE", "BDBV_HOST_RESPONSE_CAPSULE", "GSE_BDBV")
            "viral_filovirus" -> first("GSE45291")
            "viral_covid_postviral" -> first("GSE166552", "GSE152202", "GSE152418", "GSE157103")
            else -> when (intent.lockedRoute) {
                "depression_kynurenine_neuroimmune" -> first("GSE102556")
                "allergy_type2_barrier" -> first("GSE146170")
                "cancer_immune_tumor_microenvironment" -> first("GSE131907")
                else -> ""
            }
        }
    }

    fun toJson(report: JSONObject): JSONObject {
        val intent = GTIMRouteConfidenceGateV21311.infer(report)
        val target = canonicalTarget(report)
        return JSONObject()
            .put("version", GTIMResearchIntentObjectContractV21311.VERSION)
            .put("state", if (target.isBlank()) "CANONICAL_TARGET_EMPTY_UNTIL_COMPATIBLE_DATASET" else "CANONICAL_TARGET_SELECTED_AFTER_ROUTE_LOCK")
            .put("lockedRoute", intent.lockedRoute)
            .put("lockedSubtype", intent.lockedSubtype)
            .put("canonicalTarget", target)
            .put("selectionPolicy", "route lock first, compatible dataset second; strong wrong capsule is blocked")
            .put("claimLimit", GTIMResearchIntentObjectContractV21311.CLAIM_LIMIT)
    }
}
