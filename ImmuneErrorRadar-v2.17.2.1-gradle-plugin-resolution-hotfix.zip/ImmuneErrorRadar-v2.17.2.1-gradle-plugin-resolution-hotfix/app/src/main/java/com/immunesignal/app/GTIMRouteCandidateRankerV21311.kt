package com.immunesignal.app

object GTIMRouteCandidateRankerV21311 {
    fun rank(candidates: List<GTIMRouteCandidateV21311>): List<GTIMRouteCandidateV21311> =
        candidates.sortedWith(compareByDescending<GTIMRouteCandidateV21311> { it.score }.thenByDescending { it.semanticScore })

    fun explanation(ranked: List<GTIMRouteCandidateV21311>): String {
        val top = ranked.firstOrNull() ?: return "no route candidates"
        val second = ranked.drop(1).firstOrNull()
        val gap = if (second == null) top.score else top.score - second.score
        return "selected=${top.route}/${top.subtype}; score=${"%.2f".format(top.score)}; semantic=${"%.2f".format(top.semanticScore)}; dataset=${"%.2f".format(top.datasetScore)}; gap=${"%.2f".format(gap)}; reasons=${top.reasons.joinToString(" | ")}"
    }
}
