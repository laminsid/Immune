package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.12.16 — Final injected metadata execution closure. */
object GTIMInjectedMetadataFinalClosureV21216 {
    const val VERSION: String = "2.12.16-injected-metadata-final-closure"
    const val RELEASE_NAME: String = "2.12.16-final-injected-metadata-execution-unified"
    const val CLAIM_LIMIT: String = "final_injected_metadata_execution_closure_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val injected = report.optJSONObject("injectedMetadataSeedPackV21216") ?: JSONObject()
        val workers = report.optJSONObject("metadataProbeBackgroundWorkersV21215") ?: JSONObject()
        val matched = injected.optInt("matchedCount", 0)
        val executed = workers.optJSONArray("executedSteps")?.length() ?: 0
        val injectedUsed = workers.optJSONArray("probeResults")?.let { arr ->
            (0 until arr.length()).any { idx -> arr.optJSONObject(idx)?.optBoolean("offlineInjected", false) == true }
        } ?: false
        return JSONObject()
            .put("version", VERSION)
            .put("release", RELEASE_NAME)
            .put("state", if (matched > 0 && executed > 0) "FINAL_INJECTED_METADATA_EXECUTION_READY" else "FINAL_INJECTED_METADATA_EXECUTION_NEEDS_MORE_HANDLES")
            .put("offlineInjectedPackPresent", matched > 0)
            .put("backgroundWorkersExecuted", executed > 0)
            .put("offlineInjectedResultsUsed", injectedUsed)
            .put("manualSoftProbeNoLongerDefault", matched > 0 || executed > 0)
            .put("routeLinkage", "curated_seed_injected_metadata_background_worker_external_router_matrix_shortcut_etl_dge_terminal_continuation")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final injected metadata execution closure",
        "State: ${obj.optString("state", "UNKNOWN")}; release=${obj.optString("release", RELEASE_NAME)}; offline_pack=${obj.optBoolean("offlineInjectedPackPresent", false)}; workers_executed=${obj.optBoolean("backgroundWorkersExecuted", false)}; injected_results_used=${obj.optBoolean("offlineInjectedResultsUsed", false)}.",
        "Contract: SOFT/GSE→SRP steps are no longer manual-only; injected readiness is used first, then live background probes may improve it when network is available.",
        "Route linkage: ${obj.optString("routeLinkage")}; evidence promotion remains blocked until topic-fit, comparator, sample-linkage, matrix/capsule, DGE, and contradiction gates close."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        RELEASE_NAME,
        "FINAL_INJECTED_METADATA_EXECUTION_READY",
        "manualSoftProbeNoLongerDefault",
        "curated_seed_injected_metadata_background_worker_external_router_matrix_shortcut_etl_dge_terminal_continuation",
        CLAIM_LIMIT
    ))
}
