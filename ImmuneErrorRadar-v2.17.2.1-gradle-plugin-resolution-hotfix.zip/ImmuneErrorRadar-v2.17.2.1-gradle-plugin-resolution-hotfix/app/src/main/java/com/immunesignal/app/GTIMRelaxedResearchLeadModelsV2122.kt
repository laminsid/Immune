package com.immunesignal.app

// v2.12.2 — relaxed research value bridge models.
// This is a capture-and-study layer, not an evidence upgrade layer.
data class GTIMRelaxedResearchLeadV2122(
    val version: String,
    val state: String,
    val valueProduced: String,
    val acceptedTarget: String,
    val candidateLookupHandle: String,
    val routeBridge: String,
    val functionalBridge: String,
    val externalBridge: String,
    val relaxedNextAction: String,
    val claimLimit: String
)
