package com.immunesignal.app

// v2.11.2 — Ecological Restoration Model.
// The pond example becomes an analogy guard and a research lens, not medical proof.
object GTIMEcologicalRestorationModelV2112 {
    const val VERSION: String = "2.11.2-ecological-restoration-model"
    const val PRINCIPLE: String = "symptoms_or_damage_may_reflect_system_collapse_restore_conditions_not_just_remove_one_agent"
    const val BOUNDARY: String = "pond_to_host_restoration_is_research_analogy_not_diagnosis_not_treatment_not_causal_proof"
    val ANALOGY_GUARD: List<String> = listOf(
        "RESTORATION_ANALOGY_NOT_PROOF",
        "RECOVERY_PROXY_NOT_CAUSAL_EVIDENCE",
        "MICROBIAL_PRESENCE_NOT_REPAIR_PROOF",
        "BIOMARKER_AND_FALSIFICATION_REQUIRED"
    )

    fun build(
        contract: GTIMRunDecisionContractV2740,
        corpus: String,
        candidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
        microbialReversal: GTIMMicrobialReversalReportV2111?
    ): GTIMEcologicalRestorationReportV2112 {
        val signals = GTIMEcologicalCollapseClassifierV2112.classify(contract, corpus, candidates, microbialReversal)
        val sequences = GTIMRestorationSequencePlannerV2112.plan(signals, microbialReversal)
        val state = when {
            signals.any { it.signalId == "BARRIER_FAILURE" || it.signalId == "IMMUNE_OVERACTIVATION" } -> "ECOLOGICAL_RESTORATION_ROUTE_FOUND"
            signals.any { it.signalId == "LOW_DIVERSITY_OR_FUNCTION_LOSS" || it.signalId == "TOXIN_OR_EXPOSOME_PRESSURE" } -> "SYSTEM_REBALANCE_HYPOTHESIS"
            else -> "ECOLOGICAL_RESTORATION_OPEN_SCAN"
        }
        val integration = "CONNECTED_TO_ROOT_CAUSE_MRE_AND_DOSSIER|collapse=${signals.size}|sequences=${sequences.size}|mre=${microbialReversal?.candidateRoutes?.size ?: 0}"
        val line = "Ecological restoration model: version=$VERSION | state=$state | principle=$PRINCIPLE | integration=$integration | analogy_guard=${ANALOGY_GUARD.joinToString(";").oneLine()} | boundary=$BOUNDARY"
        return GTIMEcologicalRestorationReportV2112(true, VERSION, state, PRINCIPLE, signals, sequences, ANALOGY_GUARD, integration, BOUNDARY, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
