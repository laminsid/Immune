package com.immunesignal.app

// v2.11.1 — Microbial Reversal Engine.
// Integrated over Eco-Immune Root Cause and Data Harmonization. It does not run wet-lab
// procedures, does not recommend live organisms, and does not upgrade speculative routes
// into medical claims. It only builds root-cause, counter-function research dossiers.
object GTIMMicrobialReversalEngineV2111 {
    const val VERSION: String = "2.11.1-microbial-reversal-engine"
    const val PHILOSOPHY: String = "for_each_damage_mechanism_search_a_counter_function_that_can_reverse_restore_neutralize_or_buffer_the_root_cause"
    const val BOUNDARY: String = "hypothetical_root_cause_research_only_not_treatment_not_diagnosis_not_dosing_not_wet_lab_engineering_protocol"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        corpus: String,
        rootCandidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMMicrobialReversalReportV2111 {
        val mechanisms = GTIMMicrobialDamageMechanismClassifierV2111.classify(contract, corpus, rootCandidates)
        val functions = GTIMMicrobialCounterFunctionMapperV2111.map(mechanisms)
        val candidates = GTIMMicrobialCandidateGeneratorV2111.generate(functions, corpus, dgeVerdict)
        val plans = GTIMMicrobialReversalStudyDesignerV2111.design(contract, mechanisms, candidates)
        val state = when {
            candidates.any { it.candidateClass.contains("engineered", true) } -> "MICROBIAL_REVERSAL_LONG_HORIZON_AND_NATURAL_ROUTES_AVAILABLE"
            candidates.any { it.evidenceRank.startsWith("L4") || it.evidenceRank.startsWith("L5") } -> "MICROBIAL_REVERSAL_HUMAN_CONTEXT_RESEARCH_ROUTES_AVAILABLE"
            candidates.isNotEmpty() -> "MICROBIAL_REVERSAL_COUNTER_FUNCTION_ROUTES_AVAILABLE"
            else -> "MICROBIAL_REVERSAL_OPEN_SCAN_NO_ROUTE"
        }
        val integration = "CONNECTED_TO_ROOT_CAUSE_AND_DATA_HARMONIZATION|damage=${mechanisms.size}|counter_functions=${functions.size}|candidates=${candidates.size}|study_plans=${plans.size}"
        val line = "Microbial reversal engine: version=$VERSION | state=$state | philosophy=$PHILOSOPHY | integration=$integration | ladder=${GTIMMicrobialReversalEvidenceLadderV2111.LADDER.joinToString(",").oneLine()} | boundary=$BOUNDARY"
        return GTIMMicrobialReversalReportV2111(
            active = true,
            version = VERSION,
            state = state,
            philosophy = PHILOSOPHY,
            damageMechanisms = mechanisms,
            counterFunctions = functions,
            candidateRoutes = candidates,
            studyPlans = plans,
            evidenceLadder = GTIMMicrobialReversalEvidenceLadderV2111.LADDER,
            integrationState = integration,
            boundaryLine = BOUNDARY,
            line = line
        )
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
