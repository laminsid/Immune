package com.immunesignal.app

/** v2.8.0 — Gene/pathway signal extractor surface. Requires DGE output before claiming gene signals. */
data class GTIMGenePathwaySignalReportV2800(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val pathwayContext: List<String>,
    val genePathwayLine: String,
    val boundaryLine: String
)

object GTIMGenePathwaySignalExtractorV2800 {
    const val VERSION: String = "2.8.0-gene-pathway-signal-extractor"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        dge: GTIMReviewOnlyDgeReportV2800,
        therapeutic: GTIMTherapeuticReverseTranslationReportV2790
    ): GTIMGenePathwaySignalReportV2800 {
        val routeContext = contextFor(contract, therapeutic)
        val state = when (dge.state) {
            "DGE_READY_REVIEW_ONLY_PENDING_RUN" -> "GENE_PATHWAY_EXTRACTION_WAITING_FOR_DGE_RESULT"
            else -> "GENE_PATHWAY_EXTRACTION_BLOCKED_DGE_NOT_RUN"
        }
        val line = "Gene/pathway signal extractor: version=$VERSION | state=$state | target=${dge.targetId} | pathway_context=${routeContext.joinToString(",")} | requires_ranked_gene_table=true | no_gene_signal_claim_without_dge=true"
        return GTIMGenePathwaySignalReportV2800(
            active = true,
            targetId = dge.targetId,
            state = state,
            pathwayContext = routeContext,
            genePathwayLine = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Gene/pathway boundary: pathway context is a requirement map until DGE output exists; no gene/pathway result is claimed from routing text."
        )
    }

    private fun contextFor(contract: GTIMRunDecisionContractV2740, therapeutic: GTIMTherapeuticReverseTranslationReportV2790): List<String> {
        val text = listOf(contract.rawQuery, contract.primaryAnchor.routeId, therapeutic.axisLine, therapeutic.datasetRequirementLine).joinToString(" ").lowercase()
        val out = mutableListOf<String>()
        if (text.contains("ebola") || text.contains("hemorrhagic")) out += listOf("interferon_response", "endothelial_leak", "coagulation_inflammation", "survivor_vs_fatal")
        if (text.contains("hanta") || text.contains("andes")) out += listOf("pulmonary_vascular_leak", "endothelial_barrier", "severity_signature")
        if (text.contains("diabetes") || text.contains("metabolic")) out += listOf("metabolic_inflammation", "insulin_resistance", "beta_cell_stress", "incretin_axis")
        if (text.contains("cancer") || text.contains("tumor") || text.contains("pd-1")) out += listOf("t_cell_exhaustion", "myeloid_suppression", "antigen_presentation", "responder_nonresponder")
        if (text.contains("covid") || text.contains("sars")) out += listOf("interferon", "il6_tnf", "endothelial_cytokine_axis")
        if (out.isEmpty()) out += listOf("topic_specific_pathway_context_required")
        return out.distinct().take(8)
    }
}
