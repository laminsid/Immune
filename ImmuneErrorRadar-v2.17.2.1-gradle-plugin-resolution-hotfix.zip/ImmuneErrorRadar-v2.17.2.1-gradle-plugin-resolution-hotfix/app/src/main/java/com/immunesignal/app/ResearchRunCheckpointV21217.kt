package com.immunesignal.app

import android.content.Context
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/**
 * v2.12.17 — Research run checkpoint + network-resume guard.
 *
 * Keeps a small local checkpoint while a report is running. If the Activity is destroyed,
 * Android recreates the screen, or internet disappears briefly, the app does not silently
 * fall back to the first page with no context. It preserves the topic/stage and asks the
 * researcher to resume when connectivity returns. It does not keep raw biomedical claims
 * alive and does not upgrade evidence.
 */
object ResearchRunCheckpointV21217 {
    const val VERSION: String = "2.12.17-run-checkpoint-network-resume-guard"
    private const val PREFS = "immune_run_checkpoint_v21217"
    private const val KEY = "checkpoint"

    fun begin(context: Context, topic: String, stage: String = "CYCLE_LAUNCHED") {
        val now = System.currentTimeMillis()
        write(context, JSONObject()
            .put("version", VERSION)
            .put("status", "RUNNING")
            .put("topic", topic)
            .put("stage", stage)
            .put("startedAtMillis", now)
            .put("updatedAtMillis", now)
            .put("resumeSuggested", false)
            .put("claimLimit", "checkpoint_only_no_evidence_upgrade"))
    }

    fun updateStage(context: Context, stage: String) {
        val obj = read(context) ?: return
        if (obj.optString("status") == "COMPLETED") return
        obj.put("stage", stage)
            .put("updatedAtMillis", System.currentTimeMillis())
        write(context, obj)
    }

    fun markInterrupted(context: Context, stage: String, reason: String, throwable: Throwable? = null) {
        val obj = read(context) ?: JSONObject()
        obj.put("version", VERSION)
            .put("status", "INTERRUPTED")
            .put("stage", stage)
            .put("reason", reason)
            .put("errorType", throwable?.javaClass?.simpleName.orEmpty())
            .put("errorMessage", throwable?.message?.take(220).orEmpty())
            .put("networkTransient", throwable?.let { isTransientNetwork(it) } ?: reason.contains("network", true))
            .put("resumeSuggested", true)
            .put("updatedAtMillis", System.currentTimeMillis())
            .put("claimLimit", "checkpoint_only_no_evidence_upgrade")
        write(context, obj)
    }

    fun markCompleted(context: Context) {
        val obj = read(context) ?: JSONObject()
        obj.put("version", VERSION)
            .put("status", "COMPLETED")
            .put("resumeSuggested", false)
            .put("updatedAtMillis", System.currentTimeMillis())
        write(context, obj)
    }

    fun read(context: Context): JSONObject? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return null
        return runCatching { JSONObject(raw) }.getOrNull()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    fun isTransientNetwork(t: Throwable): Boolean {
        var current: Throwable? = t
        while (current != null) {
            if (current is UnknownHostException || current is SocketTimeoutException || current is IOException) return true
            val msg = current.message.orEmpty().lowercase()
            if (msg.contains("timeout") || msg.contains("unable to resolve") || msg.contains("failed to connect") || msg.contains("network") || msg.contains("canceled")) return true
            current = current.cause
        }
        return false
    }

    fun resumeBanner(obj: JSONObject): String {
        val topic = obj.optString("topic", "previous topic")
        val stage = obj.optString("stage", "unknown stage")
        val reason = obj.optString("reason", "interrupted before completion")
        return "Search can be resumed.\n\nTopic: $topic\nLast safe stage: $stage\nReason: $reason\n\nIf internet was interrupted, reconnect and press Immune Search again. Injected metadata and saved seeds will be reused; no claim upgrade is made from the checkpoint."
    }

    private fun write(context: Context, obj: JSONObject) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, obj.toString()).apply()
    }
}
