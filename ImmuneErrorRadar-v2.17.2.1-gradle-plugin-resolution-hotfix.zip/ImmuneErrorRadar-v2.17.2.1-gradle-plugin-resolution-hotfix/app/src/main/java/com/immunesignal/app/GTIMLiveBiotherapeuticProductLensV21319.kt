package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Live biotherapeutic product modality lens, not a prescribing/treatment layer. */
object GTIMLiveBiotherapeuticProductLensV21319 {
    const val VERSION: String = "2.13.19-live-biotherapeutic-product-lens"
    const val CLAIM_LIMIT: String = "LBP_lens_not_prescription_not_treatment_recommendation"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", "LIVE_BIOTHERAPEUTIC_PRODUCT_LENS_READY")
        .put("modalities", JSONArray(listOf("live_biotherapeutic_product", "microbiome_modulation", "diagnostic_biomarker_research")))
        .put("treatment_recommendation_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
