package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Final linkage closure for v2.13.21 exosome + immunometabolism layer. */
object GTIMFinalExosomeImmunometabolismClosureV21321 {
    const val VERSION: String = "2.13.21-final-exosome-immunometabolism-systemic-signaling-layer"
    const val STATE_READY: String = "FINAL_EXOSOME_IMMUNOMETABOLISM_CLOSURE_READY"
    const val CLAIM_LIMIT: String = "exosome_immunometabolism_layer_research_only_no_diagnosis_treatment_or_diet_protocol"

    fun toJson(report: JSONObject): JSONObject {
        val card = GTIMExosomeImmunometabolismSurfaceCardV21321.toJson(report)
        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("surface_card_present", card.optString("state") == GTIMExosomeImmunometabolismSurfaceCardV21321.STATE_READY)
            .put("exosome_systemic_immunity_layer", GTIMExosomeSystemicImmunityEngineV21321.STATE_READY)
            .put("exosomal_cargo_mapper", GTIMExosomalCargoSignalMapperV21321.STATE_READY)
            .put("liquid_biopsy_lens", GTIMExosomeLiquidBiopsyLensV21321.STATE_READY)
            .put("exosome_delivery_lens", GTIMExosomeDeliveryModalityLensV21321.STATE_READY)
            .put("immunometabolism_adipose_layer", GTIMImmunometabolismAdiposeEngineV21321.STATE_READY)
            .put("adipose_macrophage_mapper", GTIMAdiposeMacrophagePolarityMapperV21321.STATE_READY)
            .put("metabolic_switch_mapper", GTIMMetabolicImmuneSwitchMapperV21321.STATE_READY)
            .put("precision_immunometabolism_lens", GTIMPrecisionImmunometabolismLensV21321.STATE_READY)
            .put("legacy_linkage_policy", "old_rails_remain_appendix_export_audit_only_new_layers_attach_to_final_active_surface")
            .put("sandbox_preview_allowed", true)
            .put("liquid_biopsy_diagnosis_allowed", false)
            .put("exosome_therapy_claim_allowed", false)
            .put("metabolic_treatment_claim_allowed", false)
            .put("diet_protocol_allowed", false)
            .put("clinical_implementation_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Final exosome + immunometabolism closure",
            "State: ${obj.optString("state")}; version=${obj.optString("version")}; surface_card_present=${obj.optBoolean("surface_card_present")}",
            "Exosome closure: ${obj.optString("exosome_systemic_immunity_layer")}; cargo=${obj.optString("exosomal_cargo_mapper")}; liquid_biopsy=${obj.optString("liquid_biopsy_lens")}; delivery=${obj.optString("exosome_delivery_lens")}",
            "Immunometabolism closure: ${obj.optString("immunometabolism_adipose_layer")}; ATM=${obj.optString("adipose_macrophage_mapper")}; switch=${obj.optString("metabolic_switch_mapper")}; precision=${obj.optString("precision_immunometabolism_lens")}",
            "Preview policy: sandbox_preview_allowed=${obj.optBoolean("sandbox_preview_allowed")}; liquid_biopsy_diagnosis_allowed=${obj.optBoolean("liquid_biopsy_diagnosis_allowed")}; exosome_therapy_claim_allowed=${obj.optBoolean("exosome_therapy_claim_allowed")}; metabolic_treatment_claim_allowed=${obj.optBoolean("metabolic_treatment_claim_allowed")}; diet_protocol_allowed=${obj.optBoolean("diet_protocol_allowed")}",
            "Boundary: exosome cargo is not diagnosis; exosome delivery is not therapy; immunometabolism signal is not diet/drug protocol; ${obj.optString("claim_limit")}")
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        STATE_READY,
        "GTIMExosomeSystemicImmunityEngineV21321",
        "GTIMExosomalCargoSignalMapperV21321",
        "GTIMExosomeLiquidBiopsyLensV21321",
        "GTIMExosomeDeliveryModalityLensV21321",
        "GTIMImmunometabolismAdiposeEngineV21321",
        "GTIMAdiposeMacrophagePolarityMapperV21321",
        "GTIMMetabolicImmuneSwitchMapperV21321",
        "GTIMPrecisionImmunometabolismLensV21321",
        "exosome cargo is not diagnosis",
        "immunometabolism signal is not diet/drug protocol",
        CLAIM_LIMIT
    ))
}
