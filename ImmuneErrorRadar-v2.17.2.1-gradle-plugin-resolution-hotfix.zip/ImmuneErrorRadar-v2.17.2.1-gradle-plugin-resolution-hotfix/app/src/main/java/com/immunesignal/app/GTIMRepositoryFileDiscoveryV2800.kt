package com.immunesignal.app

/**
 * v2.8.0 — Public repository file discovery and download request planner.
 *
 * This layer prepares a user-started public repository download/file-discovery request.
 * It does not claim that a file was downloaded unless a concrete observed file signal is
 * passed from a future downloader. It preserves the v2.7.8.2 target gate: sentinel or
 * background-only handles cannot start ETL/DGE probing.
 */
data class GTIMRepositoryFileDiscoveryReportV2800(
    val active: Boolean,
    val targetId: String,
    val repository: String,
    val state: String,
    val candidateFileTypes: List<String>,
    val repositoryLookupUrls: List<String>,
    val downloadMode: String,
    val fileDiscoveryLine: String,
    val downloadRequestLine: String,
    val boundaryLine: String
)

object GTIMRepositoryFileDiscoveryV2800 {
    const val VERSION: String = "2.8.0-public-repository-file-discovery"
    val MATRIX_FILE_SIGNATURES: List<String> = listOf(
        "matrix.mtx", "barcodes.tsv", "features.tsv", "raw_counts.tsv", "counts.csv",
        "expression_matrix.tsv", "series_matrix.txt", "h5", "h5ad", "rds"
    )

    fun build(
        matrixAuditCard: GTIMMatrixAuditCardReportV2745,
        etlBridge: GTIMMatrixEtlMetadataBridgeReportV2780,
        finalEtl: GTIMFinalEtlExecutionUnifierReportV2782
    ): GTIMRepositoryFileDiscoveryReportV2800 {
        val target = firstNonBlank(finalEtl.targetId, etlBridge.targetId, matrixAuditCard.targetId)
        val concreteTarget = GTIMAccessionIdValidityGuardV2753.isFullAccession(target) &&
            !target.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", ignoreCase = true) &&
            finalEtl.state != "FINAL_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET" &&
            etlBridge.dgeReadinessVerdict != "DGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"
        val repository = repositoryFor(target, matrixAuditCard.repository)

        if (!concreteTarget) {
            val line = "Repository file discovery: version=$VERSION | state=BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | target=$target | repository=${repository.ifBlank { "not selected" }} | candidate_files=none | download_mode=blocked_before_target_gate"
            return GTIMRepositoryFileDiscoveryReportV2800(
                active = true,
                targetId = target,
                repository = repository,
                state = "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET",
                candidateFileTypes = emptyList(),
                repositoryLookupUrls = emptyList(),
                downloadMode = "BLOCKED_BEFORE_TOPIC_TARGET_GATE",
                fileDiscoveryLine = normalize(line),
                downloadRequestLine = "Repository download request: blocked; select a topic-compatible accession before file probing or matrix download.",
                boundaryLine = boundary()
            )
        }

        val urls = lookupUrls(target, repository)
        val state = when {
            etlBridge.fileDiscoveryState.contains("DISCOVERED", ignoreCase = true) -> "FILE_DISCOVERY_CANDIDATE_REVIEW_ONLY"
            else -> "FILE_DISCOVERY_REQUEST_READY"
        }
        val line = "Repository file discovery: version=$VERSION | state=$state | target=$target | repository=$repository | candidate_files=${MATRIX_FILE_SIGNATURES.take(8).joinToString(",")} | download_mode=user_started_public_repository_only | no_download_claim_until_file_seen=true"
        val request = "Repository download request: target=$target | lookup_urls=${urls.take(3).joinToString(",")} | fetch_candidate_files=${MATRIX_FILE_SIGNATURES.take(6).joinToString(",")} | checksum_and_size_required=true | review_only=true"
        return GTIMRepositoryFileDiscoveryReportV2800(
            active = true,
            targetId = target,
            repository = repository,
            state = state,
            candidateFileTypes = MATRIX_FILE_SIGNATURES,
            repositoryLookupUrls = urls,
            downloadMode = "USER_STARTED_PUBLIC_REPOSITORY_ONLY",
            fileDiscoveryLine = normalize(line),
            downloadRequestLine = normalize(request),
            boundaryLine = boundary()
        )
    }

    private fun lookupUrls(target: String, repository: String): List<String> {
        val upper = target.uppercase()
        return when {
            upper.startsWith("GSE") -> {
                val bucket = geoSeriesBucket(upper)
                listOf(
                    "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=$upper",
                    "https://ftp.ncbi.nlm.nih.gov/geo/series/$bucket/$upper/suppl/"
                )
            }
            upper.startsWith("SRP") || upper.startsWith("SRR") -> listOf(
                "https://www.ncbi.nlm.nih.gov/sra/?term=$upper",
                "https://trace.ncbi.nlm.nih.gov/Traces/?view=run_browser&acc=$upper"
            )
            upper.startsWith("PRJNA") -> listOf(
                "https://www.ncbi.nlm.nih.gov/bioproject/$upper",
                "https://www.ncbi.nlm.nih.gov/sra/?term=$upper"
            )
            upper.startsWith("E-MTAB") -> listOf("https://www.ebi.ac.uk/biostudies/arrayexpress/studies/$upper")
            upper.startsWith("SDY") -> listOf("https://www.immport.org/shared/study/$upper")
            else -> listOf("$repository:$upper")
        }
    }

    private fun geoSeriesBucket(gse: String): String {
        val digits = gse.dropWhile { !it.isDigit() }
        return if (digits.length <= 3) "${gse.take(3)}nnn" else "GSE${digits.dropLast(3)}nnn"
    }

    private fun repositoryFor(target: String, fallback: String): String = when {
        target.startsWith("GSE", true) || target.startsWith("GSM", true) -> "GEO"
        target.startsWith("SRP", true) || target.startsWith("SRR", true) -> "SRA"
        target.startsWith("PRJNA", true) -> "BioProject"
        target.startsWith("E-MTAB", true) -> "ArrayExpress"
        target.startsWith("SDY", true) -> "ImmPort"
        fallback.isNotBlank() -> fallback
        else -> "repository not surfaced"
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: "NO_TARGET"
    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
    private fun boundary(): String = "Repository file discovery boundary: public repository lookup/download request only; no file is claimed downloaded until observed with size/checksum; no DGE or biological claim."
}
