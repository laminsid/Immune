package com.immunesignal.app

/** Builds the dataset requirement surface for v2.7.9.0 therapeutic routing. */
object GTIMTherapeuticDatasetRequirementGeneratorV2790 {
    const val VERSION: String = "2.7.9.0-therapeutic-dataset-requirement-generator"

    fun requirementLine(
        lane: GTIMTherapeuticAxisDefinitionV2790,
        etl: GTIMFinalEtlExecutionUnifierReportV2782,
        matrixAuditCard: GTIMMatrixAuditCardReportV2745
    ): String {
        val target = matrixAuditCard.targetId.ifBlank { etl.targetId }
        val targetState = if (GTIMAccessionIdValidityGuardV2753.isFullAccession(target)) {
            "target=$target"
        } else {
            "target_required_before_etl=true"
        }
        return normalize(
            "Therapeutic dataset requirement: lane=${lane.laneId} | $targetState | comparators=${lane.requiredComparators.take(4).joinToString(",")} | assays=${lane.requiredAssays.take(4).joinToString(",")} | metadata=${lane.requiredMetadataFields.take(6).joinToString(",")} | etl_decision=${etl.finalDecision} | output=dataset_requirement_not_treatment_claim"
        )
    }

    fun etlRoutingLine(
        lane: GTIMTherapeuticAxisDefinitionV2790,
        etl: GTIMFinalEtlExecutionUnifierReportV2782
    ): String {
        val next = when (etl.finalDecision) {
            "SELECT_TOPIC_COMPATIBLE_ACCESSION_BEFORE_ETL_OR_DGE" -> "select topic-compatible accession before therapeutic file probe"
            "RUN_REPOSITORY_FILE_DISCOVERY_FIRST" -> "run file discovery for therapeutic-response matrix candidates"
            "PARSE_SAMPLE_METADATA_WITH_EVIDENCE_SNIPPETS" -> "parse intervention/outcome metadata with evidence snippets"
            "NORMALIZE_COMPARATOR_LABELS_WITH_CONFIDENCE_AND_SOURCE_FIELD" -> "normalize therapeutic comparator labels with source fields"
            "VERIFY_SAMPLE_IDS_AGAINST_MATRIX_COLUMNS_BEFORE_DGE" -> "verify sample IDs before review-only DGE"
            "RUN_REVIEW_ONLY_DGE_AFTER_BATCH_AND_CONTRADICTION_CHECKS" -> "run bounded review-only DGE; keep therapeutic interpretation gated"
            else -> "keep as structured therapeutic research protocol; close ETL gates in order"
        }
        return normalize("Therapeutic ETL routing: lane=${lane.laneId} | final_etl_state=${etl.state} | next=$next | no_DGE_ready_from_therapeutic_reasoning=true")
    }

    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
