package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * Connects local processed capsules to the hypothesis-first engine without promoting
 * validated proof or clinical claims.
 */
object GTIMCapsuleBackedHypothesisBridgeV21316 {
    const val VERSION: String = "2.13.16-capsule-backed-hypothesis-bridge"
    const val CLAIM_LIMIT: String = "capsule_backed_preview_not_validated_proof_no_clinical_claim"

    fun enrich(report: JSONObject, hypothesis: JSONObject): JSONObject {
        val route = GTIMCapsuleInjectionRouterV21316.route(report)
        val capsule = route.executableCapsule
        val executionTasks = hypothesis.optJSONArray("executionTasks") ?: JSONArray()
        val normalizedTasks = JSONArray()
        for (i in 0 until executionTasks.length()) {
            val task = executionTasks.optString(i)
            if (route.executableCapsule != null && task == "processed_capsule_or_matrix_not_closed") {
                normalizedTasks.put("local_processed_capsule_available_not_validated_proof")
            } else {
                normalizedTasks.put(task)
            }
        }
        if (route.executableCapsule == null) normalizedTasks.put("local_processed_capsule_acquisition_task_created")

        hypothesis
            .put("localProcessedCapsuleLayerV21316", route.toJson().put("version", VERSION))
            .put("matrixState", route.matrixState.name)
            .put("capsulePreviewStrength", route.previewStrength)
            .put("capsuleBackedPreviewAllowed", route.sandboxPreviewAllowed)
            .put("executionTasks", normalizedTasks)
            .put("claimLimit", CLAIM_LIMIT)

        if (capsule != null) {
            val moduleNames = capsule.modules.map { it.name }
            hypothesis
                .put("primaryResult", upgradePrimaryResult(hypothesis.optString("primaryResult"), route.previewStrength))
                .put("bestSearchQuery", capsule.accession)
                .put("bestExecutionTarget", capsule.accession)
                .put("requiredDatasetProfile", "local processed capsule available for ${capsule.domain}; external review remains optional for validation and required for proof.")
                .put("capsuleModules", JSONArray(moduleNames))
                .put("whyPlausible", "local processed capsule ${capsule.accession} is available for ${capsule.domain}; module panels=${moduleNames.joinToString(", ")}; capsule is executable research substrate, not proof.")
        }
        return hypothesis
    }

    fun toJson(report: JSONObject): JSONObject = routeAndSummarize(report)

    fun publicLines(obj: JSONObject): List<String> {
        val route = obj.optJSONObject("localProcessedCapsuleLayerV21316") ?: obj
        val capsule = route.optJSONObject("capsule")
        val state = route.optString("matrix_state", "CAPSULE_MISSING_ACQUISITION_TASK_CREATED")
        val accession = capsule?.optString("accession")?.takeIf { it.isNotBlank() } ?: "none"
        val modules = capsule?.optJSONArray("modules")?.let { modules ->
            (0 until modules.length()).mapNotNull { modules.optJSONObject(it)?.optString("name") }.joinToString(", ")
        }.orEmpty().ifBlank { "none_yet" }
        return listOf(
            "Local processed capsule layer",
            "Matrix state: $state; capsule=$accession; sandbox_preview_allowed=${route.optBoolean("sandbox_preview_allowed", true)}.",
            "Preview strength: ${route.optString("preview_strength", "C0_ROUTE_SANDBOX_PREVIEW_CAPSULE_MISSING")}",
            "Executable modules: $modules",
            "Acquisition task: ${route.optString("acquisition_task", "create_lightweight_processed_capsule")}",
            "Boundary: local capsule is executable research substrate only; not validated proof, diagnosis, treatment, dosing, clinical implementation, or efficacy."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "LOCAL_PROCESSED_CAPSULE_AVAILABLE",
        "LOCAL_DOMAIN_CAPSULE_AVAILABLE",
        "CAPSULE_MISSING_ACQUISITION_TASK_CREATED",
        "C1_PLUS_CAPSULE_BACKED_SANDBOX_PREVIEW",
        CLAIM_LIMIT
    ))

    private fun routeAndSummarize(report: JSONObject): JSONObject = GTIMCapsuleInjectionRouterV21316.routeJson(report)

    private fun upgradePrimaryResult(current: String, strength: String): String = when {
        strength.contains("C1_PLUS", ignoreCase = true) -> "C1_PLUS_CAPSULE_BACKED_DISCOVERY_PREVIEW"
        strength.contains("C1_DOMAIN", ignoreCase = true) -> "C1_DOMAIN_CAPSULE_DISCOVERY_PREVIEW"
        current.isNotBlank() -> current
        else -> "C0_ROUTE_HYPOTHESIS"
    }
}
