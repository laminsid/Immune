package com.immunesignal.app

import java.util.Locale

/**
 * v2.9.6 — Weighted anchor compatibility review.
 *
 * This is a lightweight, deterministic guard that turns the keyword floor into
 * a scored review signal without becoming a DGE or evidence-upgrade gate. It is used to
 * prevent sticky/fallback targets and mismatched SOFT metadata from being promoted, while
 * keeping borderline targets in NEAR_MATCH_TOPIC_COMPATIBLE_REVIEW.
 */
data class GTIMWeightedAnchorCompatibilityReportV2960(
    val active: Boolean,
    val anchorRouteId: String,
    val state: String,
    val score: Int,
    val primaryHits: List<String>,
    val synonymHits: List<String>,
    val assayTissueHits: List<String>,
    val comparatorHits: List<String>,
    val negativeHits: List<String>,
    val line: String,
    val boundaryLine: String
) {
    val topicCompatible: Boolean get() = state == GTIMWeightedAnchorCompatibilityV2960.PASS_STATE
    val nearMatch: Boolean get() = state == GTIMWeightedAnchorCompatibilityV2960.NEAR_STATE
}

object GTIMWeightedAnchorCompatibilityV2960 {
    const val VERSION: String = "2.9.8-weighted-anchor-compatibility-review"
    const val PASS_STATE: String = "WEIGHTED_ANCHOR_TOPIC_COMPATIBLE"
    const val NEAR_STATE: String = GTIMTargetQueryConsistencyGateV2940.NEAR_MATCH_STATE
    const val NO_MATCH_STATE: String = "WEIGHTED_ANCHOR_NO_TOPIC_COMPATIBLE"
    const val CLAIM_LIMIT: String = "weighted_anchor_review_not_evidence_not_dge_ready"

    fun evaluateText(text: String, contract: GTIMRunDecisionContractV2740): GTIMWeightedAnchorCompatibilityReportV2960 {
        val profile = profileFor(contract.primaryAnchor)
        val normalized = normalize(text)
        val primary = hitTerms(normalized, profile.primary)
        val synonyms = hitTerms(normalized, profile.synonyms).filterNot { it in primary }
        val assayTissue = hitTerms(normalized, profile.assayTissue)
        val comparator = hitTerms(normalized, profile.comparator)
        val negative = hitTerms(normalized, profile.negative)
        val score = (primary.size.coerceAtMost(1) * 3) +
            (synonyms.size.coerceAtMost(2)) +
            (assayTissue.size.coerceAtMost(1)) +
            (comparator.size.coerceAtMost(1) * 2) -
            (negative.size.coerceAtMost(1) * 3)
        val state = when {
            score >= 4 -> PASS_STATE
            score in 2..3 -> NEAR_STATE
            else -> NO_MATCH_STATE
        }
        val line = "Weighted anchor compatibility: version=$VERSION | anchor=${contract.primaryAnchor.routeId} | state=$state | score=$score | primary=${primary.joinToString(",").ifBlank { "none" }} | synonyms=${synonyms.joinToString(",").ifBlank { "none" }} | assay_tissue=${assayTissue.joinToString(",").ifBlank { "none" }} | comparator=${comparator.joinToString(",").ifBlank { "none" }} | negative=${negative.joinToString(",").ifBlank { "none" }} | claim_limit=$CLAIM_LIMIT"
        return GTIMWeightedAnchorCompatibilityReportV2960(
            active = true,
            anchorRouteId = contract.primaryAnchor.routeId,
            state = state,
            score = score,
            primaryHits = primary,
            synonymHits = synonyms,
            assayTissueHits = assayTissue,
            comparatorHits = comparator,
            negativeHits = negative,
            line = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Weighted anchor boundary: compatibility scoring only; it cannot create observed files, comparator confirmation, DGE readiness, gene/pathway signal, treatment advice, efficacy, dosing, or clinical-management claims."
        )
    }

    private data class Profile(
        val primary: List<String>,
        val synonyms: List<String> = emptyList(),
        val assayTissue: List<String> = emptyList(),
        val comparator: List<String> = listOf("case", "control", "healthy", "patient", "disease state"),
        val negative: List<String> = emptyList()
    )

    private fun profileFor(anchor: GTIMPrimaryAnchorV2740): Profile = when (anchor) {
        GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> Profile(
            primary = listOf("covid", "sars cov 2"),
            synonyms = listOf("pasc", "long covid", "coronavirus"),
            assayTissue = listOf("pbmc", "blood", "airway", "interferon", "il 6", "tnf"),
            negative = listOf("diabetes", "ebola", "hantavirus", "allergy", "depression")
        )
        GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> Profile(
            primary = listOf("ebola", "evd"),
            synonyms = listOf("filovirus", "viral hemorrhagic", "hemorrhagic fever"),
            assayTissue = listOf("blood", "pbmc", "monocyte", "interferon", "cytokine"),
            negative = listOf("diabetes", "depression", "allergy", "sars cov 2", "covid")
        )
        GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> Profile(
            primary = listOf("hanta", "hantavirus"),
            synonyms = listOf("hfrs", "hcps", "hemorrhagic fever with renal syndrome"),
            assayTissue = listOf("renal", "pulmonary", "blood", "endothelial", "cytokine"),
            negative = listOf("diabetes", "depression", "allergy", "covid")
        )
        GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> Profile(
            primary = listOf("depression", "microbiome", "gut"),
            synonyms = listOf("tryptophan", "kynurenine", "mood", "neuroimmune"),
            assayTissue = listOf("stool", "fecal", "gut mucosa", "il 6", "tnf"),
            negative = listOf("diabetes", "ebola", "covid", "hantavirus", "allergy")
        )
        GTIMPrimaryAnchorV2740.DEPRESSION_NEUROIMMUNE -> Profile(
            primary = listOf("depression", "mood"),
            synonyms = listOf("neuroimmune", "major depressive", "mdd"),
            assayTissue = listOf("blood", "pbmc", "il 6", "tnf", "crp"),
            negative = listOf("diabetes", "ebola", "covid", "allergy")
        )
        GTIMPrimaryAnchorV2740.DIABETES_METABOLIC_INFLAMMATION,
        GTIMPrimaryAnchorV2740.T2D_INSULIN_RESISTANCE_INFLAMMATION -> Profile(
            primary = listOf("diabetes", "diabetic", "type 2 diabetes", "t2d"),
            synonyms = listOf("insulin resistance", "glucose", "hba1c", "metabolic"),
            assayTissue = listOf("blood", "pbmc", "adipose", "pancreas", "islet", "inflammation"),
            negative = listOf("depression", "ebola", "covid", "hantavirus", "allergy")
        )
        GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> Profile(
            primary = listOf("allergy", "allergic", "ige"),
            synonyms = listOf("type 2", "eosinophil", "mast cell", "atopy"),
            assayTissue = listOf("blood", "airway", "skin", "il 4", "il 5", "il 13"),
            negative = listOf("diabetes", "depression", "ebola", "covid")
        )
        GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION -> Profile(
            primary = listOf("hiv", "aids"),
            synonyms = listOf("retroviral", "viral load", "cd4"),
            assayTissue = listOf("blood", "pbmc", "t cell", "cd4"),
            negative = listOf("diabetes", "depression", "ebola", "covid")
        )
        GTIMPrimaryAnchorV2740.RA_SYNOVIAL_AUTOIMMUNE -> Profile(
            primary = listOf("rheumatoid", "arthritis", "ra"),
            synonyms = listOf("synovial", "citrullination", "autoimmune"),
            assayTissue = listOf("synovium", "blood", "tnf", "il 6"),
            negative = listOf("diabetes", "depression", "ebola", "covid")
        )
        GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY -> Profile(primary = emptyList(), comparator = emptyList())
        else -> {
            val routeTerms = anchor.routeId.replace('_', ' ').split(' ').filter { it.length >= 4 }
            Profile(primary = routeTerms.take(3), synonyms = routeTerms.drop(3).take(4), assayTissue = emptyList(), negative = emptyList())
        }
    }

    private fun hitTerms(normalizedText: String, terms: List<String>): List<String> = terms
        .map { normalize(it) }
        .filter { it.isNotBlank() && containsTerm(normalizedText, it) }
        .distinct()

    internal fun normalize(value: String): String = value.lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun containsTerm(text: String, term: String): Boolean =
        Regex("(?<![a-z0-9])${Regex.escape(term)}(?![a-z0-9])").containsMatchIn(text)
}
