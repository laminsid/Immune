package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.2 — Final data closure execution scorecard. */
object GTIMFinalDataClosureExecutionV2132 {
    const val VERSION: String = "2.13.2-final-data-closure-execution"
    const val CLAIM_LIMIT: String = "data_closure_can_raise_readiness_not_scientific_or_clinical_claims"

    fun toJson(report: JSONObject): JSONObject {
        val metadata = report.optJSONObject("verifiedMetadataClosurePackV2132") ?: GTIMVerifiedMetadataClosurePackV2132.toJson(report)
        val capsule = report.optJSONObject("closedEvidenceCapsuleV2132") ?: GTIMClosedEvidenceCapsuleV2132.toJson(report)
        val study = report.optJSONObject("dataClosureStudyReadinessV2132") ?: GTIMDataClosureStudyReadinessV2132.toJson(report)
        val contradiction = report.optJSONObject("contradictionSearchEngineV21218") ?: JSONObject()
        val gates = listOf(
            "metadata" to (metadata.optString("state") == "VERIFIED_METADATA_CLOSURE_READY"),
            "capsule" to (capsule.optInt("capsuleScore", 0) >= 7),
            "comparator" to metadata.optBoolean("comparatorClosed", false),
            "sample_provenance" to metadata.optBoolean("sampleProvenanceClosed", false),
            "contradiction_check" to contradiction.optString("state", "").isNotBlank(),
            "next_experiment" to metadata.optString("nextExperiment").isNotBlank(),
            "study_protocol" to (study.optString("state") == "STUDY_PROTOCOL_DATA_READY_FOR_REVIEW"),
            "human_animal_invitro_separation" to metadata.optString("humanAnimalInVitroSeparation").isNotBlank()
        )
        val closed = gates.count { it.second }
        val score = ((closed * 10.0) / gates.size).toInt().coerceIn(0, 10)
        val state = when {
            score >= 9 -> "DATA_CLOSURE_10_READY_FOR_REVIEW"
            score >= 7 -> "DATA_CLOSURE_STRONG_BUT_NOT_10"
            else -> "DATA_CLOSURE_PARTIAL"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("readinessScore", score)
            .put("closedGateCount", closed)
            .put("totalGateCount", gates.size)
            .put("gates", JSONArray(gates.map { JSONObject().put("name", it.first).put("closed", it.second) }))
            .put("selectedClosedTarget", metadata.optString("selectedClosedTarget"))
            .put("evidencePromotionAllowed", false)
            .put("routeLinkage", "old_external_router_matrix_shortcut_etl_dge + new_verified_metadata_capsule_study_protocol_contradiction_graph")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final data-closure execution",
        "State: ${obj.optString("state", "UNKNOWN")}; readiness_score=${obj.optInt("readinessScore", 0)}/10; gates=${obj.optInt("closedGateCount", 0)}/${obj.optInt("totalGateCount", 0)}; selected_closed_target=${obj.optString("selectedClosedTarget", "none")}",
        "Route linkage: ${obj.optString("routeLinkage", "not declared")}",
        "Evidence promotion allowed: ${obj.optBoolean("evidencePromotionAllowed", false)} — hard claim gates remain locked until external review/DGE/replication.",
        "Boundary: this closes data-readiness gates, not scientific truth, medical diagnosis, treatment, dosing, or efficacy."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "DATA_CLOSURE_10_READY_FOR_REVIEW", "old_external_router_matrix_shortcut_etl_dge", CLAIM_LIMIT))
}
