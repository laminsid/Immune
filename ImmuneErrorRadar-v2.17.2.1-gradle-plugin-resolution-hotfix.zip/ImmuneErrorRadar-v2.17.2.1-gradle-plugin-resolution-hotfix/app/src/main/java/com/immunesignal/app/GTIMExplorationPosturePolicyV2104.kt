package com.immunesignal.app

// v2.10.4 — Relaxed exploration posture.
// This patch intentionally separates discovery freedom from final clinical-safety locks.
// It prevents authority-planning layers from becoming hard blockers for hypothesis generation.

data class GTIMExplorationPostureReportV2104(
    val state: String,
    val discoveryMode: String,
    val authorityUse: String,
    val rankPolicy: String,
    val safetyBoundary: String,
    val line: String
)

object GTIMExplorationPosturePolicyV2104 {
    const val VERSION: String = "2.10.4-relaxed-exploration-posture"

    fun build(
        immunotherapyCards: List<GTIMTherapeuticHypothesisCardV2102>,
        clinicalTrialPlans: List<GTIMClinicalTrialsRequestPlanV2102>,
        authorityPlans: List<GTIMAuthorityEvidenceRequestPlanV2103>
    ): GTIMExplorationPostureReportV2104 {
        val hasOpen = immunotherapyCards.any { it.mechanismId == "open_mechanism_exploration" }
        val hasCandidate = immunotherapyCards.isNotEmpty() || clinicalTrialPlans.isNotEmpty() || authorityPlans.isNotEmpty()
        val state = when {
            hasOpen -> "OPEN_EXPLORATION_RELAXED_RESEARCH_ONLY"
            hasCandidate -> "CANDIDATE_ROUTE_EXPLORATION_RELAXED"
            else -> "EXPLORATION_AVAILABLE_NO_ROUTE_SELECTED_YET"
        }
        val discoveryMode = "allow_hypothesis_generation_from_mechanism_metadata_capsule_request_plan_and_partial_evidence"
        val authorityUse = "authority_sources_are_validation_targets_not_discovery_blockers"
        val rankPolicy = "evidence_rank_can_be_candidate_A_to_X_but_must_remain_unverified_until_source_imported"
        val safetyBoundary = "only_clinical_action_locked_no_dosing_no_medication_stop_no_patient_specific_recommendation_no_efficacy_claim"
        val line = "Exploration posture: version=$VERSION | state=$state | discovery_mode=$discoveryMode | authority_use=$authorityUse | rank_policy=$rankPolicy | safety_boundary=$safetyBoundary | hard_blockers=clinical_action_only"
        return GTIMExplorationPostureReportV2104(
            state = state,
            discoveryMode = discoveryMode,
            authorityUse = authorityUse,
            rankPolicy = rankPolicy,
            safetyBoundary = safetyBoundary,
            line = line
        )
    }
}
