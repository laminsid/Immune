package com.immunesignal.app

// audit_guard_phrase: no administration; no evidence upgrade

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

// v2.12.1 — Study-grade functional solution synthesis.
// This is not a treatment engine. It converts the root-dysfunction dossier into a
// paper-like contribution frame: what new hypothesis is worth studying, which biological
// function might solve it, and what would validate or kill it.
object GTIMStudyGradeFunctionalSolutionEngineV2121 {
    const val VERSION: String = "2.12.1-study-grade-functional-solution-synthesis"
    const val BOUNDARY: String = "research_only_hypothesis_no_diagnosis_no_treatment_no_administration_no_engineering_protocol_no_environmental_release"

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): GTIMStudyGradeSolutionV2121 {
        val lines = if (technicalLines.isNotEmpty()) technicalLines else GlobalResearchGradeBriefV11061.renderLines(report)
        val topic = topic(report, lines)
        val text = (topic + " " + lines.joinToString(" ") + " " + report.toString()).lowercase(Locale.US).take(12000)
        val consistency = GTIMReportConsistencyGateV2121.build(report, lines)
        val functional = GTIMFunctionalRepairDossierEngineV2120.build(report, lines)
        val model = functional.dysfunctionModel
        val primaryRepair = functional.repairFunctions.firstOrNull()
        val phenotype = phenotypeLabel(text, topic)
        val contribution = "A testable root-cause study frame for $phenotype: connect non-specific symptoms or disease labels to a shared dysfunction model, then test whether repairing the missing biological function changes measurable immune/metabolic/barrier readouts."
        val rootCause = model.primaryDysfunction.ifBlank { "unresolved root dysfunction requiring comparator datasets and mechanism falsification" }
        val repairHypothesis = primaryRepair?.repairFunction ?: repairFunctionFallback(text)
        val toolRationale = primaryRepair?.let { "Investigate ${it.biologicalToolClass} for ${it.repairFunction}; mechanism=${it.plausibleMechanism}" }
            ?: microbialToolFallback(text)
        val bridge = bridgeSignals(text, model.crossDiseaseBridge)
        val validation = validationLadder(consistency, text)
        val kill = killCriteria(consistency, text)
        val novelty = noveltyFrame(text, consistency)
        val state = when {
            consistency.topicCompatibleTargetSelected && consistency.verifiedMatrixFiles > 0 -> "STUDY_SOLUTION_READY_FOR_REVIEW_ONLY_ANALYTIC_TEST"
            consistency.topicCompatibleTargetSelected -> "STUDY_SOLUTION_DATASET_TARGET_FOUND_MATRIX_PENDING"
            consistency.candidateLookupHandle.isNotBlank() -> "STUDY_SOLUTION_CANDIDATE_HANDLE_REQUIRES_TOPIC_FIT"
            else -> "STUDY_SOLUTION_TOPIC_ONLY_NEEDS_DATASET_ANCHOR"
        }
        val line = "Study-grade functional solution: version=$VERSION | state=$state | contribution=root_cause_functional_repair_frame | root=${rootCause.oneLine()} | repair=${repairHypothesis.oneLine()} | novelty=${novelty.oneLine()} | boundary=$BOUNDARY"
        return GTIMStudyGradeSolutionV2121(VERSION, state, contribution, rootCause, repairHypothesis, toolRationale, bridge, validation, kill, novelty, BOUNDARY, line.oneLine())
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val s = build(report, technicalLines)
        return listOf(
            "Study-grade solution hypothesis",
            "Proposed contribution: ${s.proposedContribution}",
            "Root-cause candidate: ${s.rootCauseClaimCandidate}",
            "Functional repair hypothesis: ${s.functionalSolutionHypothesis}",
            "Microbial/biological tool rationale: ${s.microbialOrBiologicalToolRationale}",
            "Cross-condition bridge: ${s.crossConditionBridge.take(4).joinToString("; ")}",
            "Validation ladder: ${s.validationLadder.take(5).joinToString("; ")}",
            "What would falsify it: ${s.falsificationTriggers.take(5).joinToString("; ")}",
            "Novelty frame: ${s.noveltyFrame}",
            "Boundary: research-only; no diagnosis, treatment, administration route, organism-engineering steps, environmental release, or efficacy claim."
        ).map { it.oneLine() }
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val s = build(report, technicalLines)
        return JSONObject()
            .put("version", s.version)
            .put("state", s.state)
            .put("proposedContribution", s.proposedContribution)
            .put("rootCauseClaimCandidate", s.rootCauseClaimCandidate)
            .put("functionalSolutionHypothesis", s.functionalSolutionHypothesis)
            .put("microbialOrBiologicalToolRationale", s.microbialOrBiologicalToolRationale)
            .put("crossConditionBridge", JSONArray(s.crossConditionBridge))
            .put("validationLadder", JSONArray(s.validationLadder))
            .put("falsificationTriggers", JSONArray(s.falsificationTriggers))
            .put("noveltyFrame", s.noveltyFrame)
            .put("boundary", s.boundary)
            .put("line", s.line)
    }

    private fun topic(report: JSONObject, lines: List<String>): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        return firstNonBlank(
            topic.optString("normalizedTopic"),
            topic.optString("rawInput"),
            lineAfter(lines, "Research topic:"),
            lineAfter(lines, "What the app understood:")
        )
    }

    private fun phenotypeLabel(text: String, topic: String): String {
        val primary = topic.lowercase(Locale.US)
        return when {
            has(primary, "pfas", "bpa", "phthalate", "microplastic", "plastic", "exposure") || has(text, "pfas", "bpa", "phthalate", "microplastic") -> "environmental exposure-barrier stress"
            has(primary, "depression", "kynurenine", "tryptophan", "neuroimmune") || has(text, "depression", "kynurenine", "tryptophan") -> "gut-neuroimmune mood/inflammation axis"
            has(primary, "allerg", "ige", "mast", "eosinophil") || has(text, "allerg", "ige", "mast") -> "allergy/type-2 immune activation"
            has(primary, "covid", "sars", "corona", "hanta", "ebola", "filovirus", "interferon") || has(text, "covid", "sars", "ebola", "interferon") -> "viral interferon-cytokine response"
            has(primary, "diabetes", "metabolic", "insulin", "glucose") || has(text, "diabetes", "metabolic") -> "metabolic immune inflammation"
            else -> topic.ifBlank { "immune dysfunction question" }
        }
    }

    private fun repairFunctionFallback(text: String): String = when {
        has(text, "pfas", "bpa", "phthalate", "microplastic", "plastic", "exposure") -> "study barrier-protective and particle-interaction functions under controlled biosafety conditions"
        has(text, "depression", "kynurenine", "tryptophan") -> "rebalance microbiome-metabolite-neuroimmune signaling and inflammatory tone"
        has(text, "allerg", "ige", "mast", "eosinophil") -> "restore barrier integrity and immune tolerance while reducing type-2 inflammatory amplification"
        has(text, "covid", "sars", "corona", "hanta", "ebola", "filovirus", "interferon") -> "test timing and balance of interferon/cytokine response rather than a single-product endpoint"
        has(text, "diabetes", "metabolic") -> "reduce metabolic inflammatory amplification and improve immune-metabolic resilience markers"
        else -> "identify the missing repair function before selecting any biological tool candidate"
    }

    private fun microbialToolFallback(text: String): String = when {
        has(text, "pfas", "bpa", "phthalate", "microplastic", "plastic", "exposure") -> "screen microbial or postbiotic functions for binding/sequestration/barrier-protection as controlled research hypotheses only"
        has(text, "depression", "kynurenine", "tryptophan") -> "screen metabolite-modulating microbiome functions linked to tryptophan/kynurenine and cytokine readouts"
        has(text, "allerg", "ige", "mast", "eosinophil") -> "screen commensal/postbiotic barrier-support and immune-tolerance functions, not strains for use"
        else -> "map biological tool classes by function first: metabolite production, barrier support, immune tolerance, or exposure interaction"
    }

    private fun bridgeSignals(text: String, existing: List<String>): List<String> {
        val out = mutableListOf<String>()
        out += existing.take(4)
        if (text.contains("microbiome") || text.contains("gut")) out += "microbiome and barrier context may connect multiple immune phenotypes"
        if (text.contains("il-6") || text.contains("tnf") || text.contains("crp")) out += "low-grade cytokine tone may be a shared amplification layer"
        if (text.contains("metabolic") || text.contains("diabetes")) out += "metabolic stress may shift immune response thresholds"
        if (text.contains("allerg") || text.contains("ige")) out += "type-2 skewing can be tested against barrier and tolerance markers"
        if (text.contains("depression") || text.contains("kynurenine")) out += "tryptophan-kynurenine imbalance can bridge microbial, immune, and neuroactive pathways"
        return out.distinct().ifEmpty { listOf("cross-disease bridge remains open until comparator datasets and contradiction checks are observed") }
    }

    private fun validationLadder(c: GTIMReportConsistencyGateV2121.TargetConsistency, text: String): List<String> {
        val out = mutableListOf<String>()
        out += if (c.topicCompatibleTargetSelected) "use accepted target ${c.acceptedTarget} as the first dataset anchor" else "select or feed a topic-compatible dataset anchor before analytic claims"
        out += "verify observed raw/count matrix or processed expression capsule"
        out += "extract comparator labels, tissue/species, sample table, and source-to-sample provenance"
        out += "test candidate pathway/module only after reviewed DGE or external gene-list provenance"
        if (text.contains("microbiome") || text.contains("bacteria") || text.contains("gut")) out += "add microbiome/metabolite readouts or literature-linked dataset support before microbial-tool ranking"
        out += "separate association, mechanism, and repair-function evidence into different grades"
        return out
    }

    private fun killCriteria(c: GTIMReportConsistencyGateV2121.TargetConsistency, text: String): List<String> {
        val out = mutableListOf<String>()
        out += "wrong tissue/species or route not matching the question"
        out += "no reproducible accession or no observed matrix/capsule"
        out += "comparator labels cannot separate case/control, severity, exposure, or phenotype groups"
        out += "gene/pathway/module signal disappears under independent dataset or contradiction check"
        if (text.contains("microbiome") || text.contains("bacteria")) out += "microbial function has no measurable metabolite, barrier, immune, or safety readout"
        if (!c.topicCompatibleTargetSelected) out += "candidate lookup handle fails topic-fit validation"
        return out.distinct()
    }

    private fun noveltyFrame(text: String, c: GTIMReportConsistencyGateV2121.TargetConsistency): String = when {
        text.contains("microplastic") || text.contains("bioremediation") -> "high-speculation/high-upside: exposure-repair function needs strict biosafety and independent validation"
        text.contains("microbiome") && (text.contains("depression") || text.contains("allerg")) -> "medium novelty: known components exist, but subgroup-specific repair-function testing may be the research gap"
        c.topicCompatibleTargetSelected -> "incremental-to-moderate novelty: candidate dataset can test whether the proposed repair function maps to observable immune modules"
        else -> "conceptual novelty only until a topic-compatible dataset anchor is selected"
    }

    private fun has(text: String, vararg needles: String): Boolean = needles.any { text.contains(it, true) }
    private fun lineAfter(lines: List<String>, prefix: String): String = lines.firstOrNull { it.startsWith(prefix) }?.removePrefix(prefix)?.trim().orEmpty()
    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
