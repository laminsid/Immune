package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.5 — Lightweight processed capsule store.
 * This is not a hidden DGE database. It stores cleaned study-readiness capsules and
 * module-test templates so the engine can move from route planning toward Discovery
 * Candidate triage without pretending to have run wet-lab validation.
 */
object GTIMProcessedCapsuleStoreV2135 {
    const val VERSION: String = "2.13.5-lightweight-processed-capsule-store"
    const val CLAIM_LIMIT: String = "processed_capsule_store_readiness_not_expression_proof"

    private data class Capsule(
        val dataset: String,
        val domain: String,
        val comparatorState: String,
        val provenanceState: String,
        val tissueState: String,
        val matrixState: String,
        val moduleIds: List<String>,
        val readiness: Int
    )

    private val capsules = listOf(
        Capsule("GSE102556", "depression_kynurenine_neuroimmune", "closed", "closed", "closed", "route_available_review_required", listOf("ido1_kmo_kynurenine", "il6_tnf_tone", "microglia_neuroimmune"), 10),
        Capsule("GSE146170", "allergy_type2_barrier", "closed", "closed", "closed", "route_available_review_required", listOf("type2_il4_il5_il13", "mast_eosinophil_ige", "epithelial_barrier"), 10),
        Capsule("GSE45291", "filovirus_viral_host_response", "partial", "partial", "partial", "route_available_review_required", listOf("interferon_timing", "endothelial_injury", "coagulation_inflammation"), 6),
        Capsule("GSE166552", "viral_interferon_cytokine", "closed", "partial", "closed", "route_available_review_required", listOf("interferon_timing", "il6_tnf_tone", "recovery_severity"), 8)
    )

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val canonical = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val selected = capsules.firstOrNull { it.dataset.equals(canonical, ignoreCase = true) }
            ?: capsules.firstOrNull { GTIMActiveDomainConsistencyGuardV2134.domainCompatible(active, it.domain) }
        val compatible = capsules.filter { GTIMActiveDomainConsistencyGuardV2134.domainCompatible(active, it.domain) }
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (selected != null) "LIGHTWEIGHT_CAPSULE_SELECTED" else "LIGHTWEIGHT_CAPSULE_BACKGROUND_ONLY")
            .put("activeDomain", active)
            .put("canonicalTarget", canonical)
            .put("selectedCapsule", selected?.toJson() ?: JSONObject())
            .put("compatibleCapsuleCount", compatible.size)
            .put("compatibleCapsules", JSONArray(compatible.map { it.toJson() }))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val capsule = obj.optJSONObject("selectedCapsule") ?: JSONObject()
        return listOf(
            "Lightweight processed capsule store",
            "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; compatible_capsules=${obj.optInt("compatibleCapsuleCount", 0)}.",
            "Selected capsule: ${capsule.optString("dataset", "none")}; readiness=${capsule.optInt("readiness", 0)}/10; modules=${jsonStrings(capsule.optJSONArray("moduleIds")).joinToString(", ").ifBlank { "none" }}.",
            "Boundary: capsule store enables discovery-candidate triage, not DGE/gene/pathway proof."
        )
    }

    private fun Capsule.toJson(): JSONObject = JSONObject()
        .put("dataset", dataset)
        .put("domain", domain)
        .put("comparatorState", comparatorState)
        .put("provenanceState", provenanceState)
        .put("tissueState", tissueState)
        .put("matrixState", matrixState)
        .put("moduleIds", JSONArray(moduleIds))
        .put("readiness", readiness)

    fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { array.optString(it).takeIf { s -> s.isNotBlank() } }
}
