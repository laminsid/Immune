package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.18 — Evidence capsule builder.
 *
 * Builds a single reviewer-facing capsule from the selected review target, comparator
 * readiness, injected metadata, and matrix shortcut state. Capsule != proof.
 */
object GTIMEvidenceCapsuleBuilderV21218 {
    const val VERSION: String = "2.12.18-evidence-capsule-builder"
    const val CLAIM_LIMIT: String = "capsule_readiness_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: GTIMCandidateHandleLedgerV21215.toJson(report)
        val provenance = report.optJSONObject("comparatorSampleProvenanceExtractorV21218") ?: GTIMComparatorSampleProvenanceExtractorV21218.toJson(report)
        val selected = ledger.optString("selectedReviewTarget")
        val domain = ledger.optString("domainKey")
        val comparatorOk = provenance.optString("comparatorLabelsState").contains("FOUND")
        val sampleOk = provenance.optString("sampleProvenanceState").contains("FOUND")
        val tissueOk = provenance.optString("tissueSpeciesState").contains("FOUND")
        val matrixOk = provenance.optString("matrixOrCapsuleState").contains("AVAILABLE")
        val topicTarget = ledger.optBoolean("topicCompatibleTargetSelected", false)
        val capsuleScore = listOf(
            if (selected.isNotBlank()) 2 else 0,
            if (domain.isNotBlank()) 1 else 0,
            if (comparatorOk) 2 else 0,
            if (sampleOk) 2 else 0,
            if (tissueOk) 1 else 0,
            if (matrixOk) 2 else 0
        ).sum().coerceAtMost(10)
        val state = when {
            capsuleScore >= 9 && topicTarget -> "EVIDENCE_CAPSULE_REVIEW_READY"
            capsuleScore >= 6 -> "PARTIAL_EVIDENCE_CAPSULE_BUILT"
            selected.isNotBlank() -> "SEED_CAPSULE_BUILT_NEEDS_METADATA"
            else -> "NO_CAPSULE_TARGET"
        }
        val upgradeAllowed = state == "EVIDENCE_CAPSULE_REVIEW_READY" && topicTarget
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("selectedReviewTarget", selected)
            .put("domainKey", domain)
            .put("capsuleScore", capsuleScore)
            .put("topicCompatibleTargetSelected", topicTarget)
            .put("comparatorClosed", comparatorOk)
            .put("sampleProvenanceClosed", sampleOk)
            .put("tissueSpeciesClosed", tissueOk)
            .put("matrixOrCapsuleClosed", matrixOk)
            .put("upgradeAllowed", upgradeAllowed)
            .put("capsuleFields", JSONArray(listOf("handle", "topic_fit", "comparator_labels", "tissue_species", "sample_provenance", "matrix_or_capsule", "contradictions", "upgrade_decision")))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Evidence capsule builder",
        "State: ${obj.optString("state", "UNKNOWN")}; selected_review_target=${obj.optString("selectedReviewTarget", "none")}; capsule_score=${obj.optInt("capsuleScore", 0)}/10; upgrade_allowed=${obj.optBoolean("upgradeAllowed", false)}.",
        "Closed gates: comparator=${obj.optBoolean("comparatorClosed", false)}; sample_provenance=${obj.optBoolean("sampleProvenanceClosed", false)}; tissue_species=${obj.optBoolean("tissueSpeciesClosed", false)}; matrix_or_capsule=${obj.optBoolean("matrixOrCapsuleClosed", false)}.",
        "Use: one compact capsule for reviewer/lab follow-up; weak or missing fields remain visible instead of hidden.",
        "Boundary: capsule readiness is not biological proof and cannot create diagnosis, treatment, dosing, or efficacy claims."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "PARTIAL_EVIDENCE_CAPSULE_BUILT", "EVIDENCE_CAPSULE_REVIEW_READY", CLAIM_LIMIT))
}
