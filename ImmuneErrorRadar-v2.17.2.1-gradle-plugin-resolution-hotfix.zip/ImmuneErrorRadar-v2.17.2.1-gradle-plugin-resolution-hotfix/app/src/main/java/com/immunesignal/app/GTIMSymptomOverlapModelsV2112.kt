package com.immunesignal.app

// v2.11.2 — Symptom Overlap Resolver models.
// Symptoms are non-specific overlap signals, not direct disease identity.

data class GTIMSymptomOverlapClusterV2112(
    val clusterId: String,
    val symptomSignals: List<String>,
    val overlappingFamilies: List<String>,
    val claimLimit: String,
    val line: String
)

data class GTIMDysfunctionHypothesisNodeV2112(
    val nodeId: String,
    val dysfunctionClass: String,
    val rationale: String,
    val repairFunctionNeed: String,
    val line: String
)

data class GTIMDiscriminatingEvidencePlanV2112(
    val planId: String,
    val hypothesisNodeId: String,
    val evidenceNeeded: List<String>,
    val discriminatesAgainst: List<String>,
    val line: String
)

data class GTIMRestorativeFunctionRouteV2112(
    val routeId: String,
    val dysfunctionNodeId: String,
    val routeClass: String,
    val restorativeLogic: String,
    val requiredEvidence: List<String>,
    val claimLimit: String,
    val line: String
)

data class GTIMSymptomOverlapReportV2112(
    val active: Boolean,
    val version: String,
    val state: String,
    val principle: String,
    val clusters: List<GTIMSymptomOverlapClusterV2112>,
    val dysfunctionHypotheses: List<GTIMDysfunctionHypothesisNodeV2112>,
    val discriminatingEvidence: List<GTIMDiscriminatingEvidencePlanV2112>,
    val sharedRootMechanisms: List<String>,
    val restorativeFunctionRoutes: List<GTIMRestorativeFunctionRouteV2112>,
    val boundaryLine: String,
    val line: String
) {
    companion object {
        fun empty(): GTIMSymptomOverlapReportV2112 = GTIMSymptomOverlapReportV2112(
            active = false,
            version = GTIMSymptomOverlapResolverV2112.VERSION,
            state = "SYMPTOM_OVERLAP_NOT_EVALUATED",
            principle = GTIMSymptomOverlapResolverV2112.PRINCIPLE,
            clusters = emptyList(),
            dysfunctionHypotheses = emptyList(),
            discriminatingEvidence = emptyList(),
            sharedRootMechanisms = emptyList(),
            restorativeFunctionRoutes = emptyList(),
            boundaryLine = GTIMSymptomOverlapResolverV2112.BOUNDARY,
            line = "Symptom overlap resolver: not evaluated."
        )
    }
}
