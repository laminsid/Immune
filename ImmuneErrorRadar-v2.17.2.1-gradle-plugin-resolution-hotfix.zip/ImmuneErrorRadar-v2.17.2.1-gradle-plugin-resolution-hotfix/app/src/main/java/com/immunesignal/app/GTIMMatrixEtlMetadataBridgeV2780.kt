package com.immunesignal.app

/**
 * v2.7.8.0 — Matrix ETL & Metadata Normalization Bridge.
 *
 * This is a readiness bridge, not a downloader and not a DGE runner. It converts the
 * matrix-audit/DGE bridge surface into a production-oriented ETL checklist:
 * topic-compatible target, file discovery, sample metadata parsing, comparator
 * normalization, sample-id linkage, and final DGE readiness verdict. It preserves the
 * existing claim guard by never treating a dictionary term, recovery query, or planning
 * phrase as biological proof.
 */
data class GTIMMatrixEtlMetadataBridgeReportV2780(
    val active: Boolean,
    val targetId: String,
    val etlState: String,
    val readinessScore: Int,
    val fileDiscoveryState: String,
    val metadataNormalizationState: String,
    val comparatorNormalizationState: String,
    val sampleIdLinkageState: String,
    val dgeReadinessVerdict: String,
    val nextStep: String,
    val gates: List<String>,
    val summaryLine: String,
    val metadataLine: String,
    val boundaryLine: String
)

object GTIMMatrixEtlMetadataBridgeV2780 {
    const val VERSION: String = "2.7.8.0-matrix-etl-metadata-normalization-bridge"

    fun build(card: GTIMMatrixAuditCardReportV2745): GTIMMatrixEtlMetadataBridgeReportV2780 {
        val target = card.targetId
        val hasTarget = GTIMAccessionIdValidityGuardV2753.isFullAccession(target)

        if (!hasTarget) {
            val gates = listOf(
                "TOPIC_COMPATIBLE_TARGET_REQUIRED:: select a concrete GSE/SRP/PRJNA/E-MTAB/SDY accession that matches the active run contract.",
                "ETL_BLOCKED_BEFORE_FILE_DISCOVERY:: do not request raw/count matrix for sentinel or background-only handles."
            )
            val summary = "Matrix ETL bridge: version=$VERSION | state=NO_TOPIC_COMPATIBLE_ETL_TARGET | target=$target | readiness=20/100 | file_discovery=BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | metadata=NO_METADATA_TARGET | comparator=COMPARATOR_NOT_READY | sample_linkage=NO_SAMPLE_LINKAGE_TARGET | verdict=DGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"
            return GTIMMatrixEtlMetadataBridgeReportV2780(
                active = true,
                targetId = target,
                etlState = "NO_TOPIC_COMPATIBLE_ETL_TARGET",
                readinessScore = 20,
                fileDiscoveryState = "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET",
                metadataNormalizationState = "NO_METADATA_TARGET",
                comparatorNormalizationState = "COMPARATOR_NOT_READY",
                sampleIdLinkageState = "NO_SAMPLE_LINKAGE_TARGET",
                dgeReadinessVerdict = "DGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET",
                nextStep = "Select a topic-compatible accession first; only then run repository file discovery and metadata normalization.",
                gates = gates,
                summaryLine = summary,
                metadataLine = "Metadata normalization: state=BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | suggestions=none | evidence_snippet_required=true",
                boundaryLine = boundary()
            )
        }

        val observed = normalize(listOf(
            card.summaryLine,
            card.datasetObjectSummary,
            card.dgeExecutionBridgeLine,
            card.dgeExecutionNextLine,
            card.matrixState,
            card.matrixReadinessState,
            card.evidenceUpgradeState,
            card.blockingGaps.joinToString(" "),
            card.verifiedMetadataSlots.joinToString(" ")
        ).joinToString(" "))

        val hardFileCandidate = containsAny(observed,
            "matrix file candidate found review only",
            "matrix link found",
            "matrix link unverified",
            "dge ready",
            "sample id linkage candidate review only"
        ) && !containsAny(observed,
            "matrix download required",
            "not directly verified",
            "needs download",
            "lookup required",
            "soft matrix candidate needs download"
        )
        val fileDiscoveryState = when {
            hardFileCandidate -> "FILE_CANDIDATE_DISCOVERED_REVIEW_ONLY"
            containsAny(observed, "soft matrix", "matrix download required", "supplementary", "data availability", "series matrix") -> "FILE_DISCOVERY_REQUIRED"
            else -> "FILE_DISCOVERY_REQUIRED"
        }

        val metadataCandidate = card.metadataTraitState != "ACCESSION_HANDLE_ONLY" ||
            containsAny(observed, "metadata table", "metadata table found", "sample metadata table candidate", "sample traits", "characteristics", "phenotype")
        val metadataState = when {
            metadataCandidate -> "METADATA_NORMALIZATION_CANDIDATE_REVIEW_ONLY"
            else -> "METADATA_EXTRACTION_REQUIRED"
        }

        val comparatorMapped = containsAny(observed, "comparator labels mapped review only", "comparator mapped or partial", "comparator mapped") &&
            !containsAny(observed, "ambiguous comparator", "need standardization", "missing or ambiguous")
        val comparatorSoft = !comparatorMapped && containsAny(observed,
            "soft comparator", "comparator review lead", "comparator labels need standardization", "patient/cohort contrast", "case/control", "healthy", "severity", "treated", "untreated"
        )
        val comparatorState = when {
            comparatorMapped -> "COMPARATOR_NORMALIZED_REVIEW_ONLY"
            comparatorSoft || metadataCandidate -> "COMPARATOR_NORMALIZATION_REQUIRED"
            else -> "COMPARATOR_EXTRACTION_REQUIRED"
        }

        val sampleLinkageState = when {
            containsAny(observed, "sample id linkage candidate review only", "sample id linkage confirmed") -> "SAMPLE_ID_LINKAGE_CANDIDATE_REVIEW_ONLY"
            hardFileCandidate -> "SAMPLE_ID_LINKAGE_REQUIRED"
            else -> "SAMPLE_ID_LINKAGE_PENDING_FILE_DISCOVERY"
        }

        val verdict = when {
            !hardFileCandidate -> "DGE_BLOCKED_MATRIX_FILE_DISCOVERY_REQUIRED"
            !metadataCandidate -> "DGE_BLOCKED_METADATA_MISSING"
            comparatorState != "COMPARATOR_NORMALIZED_REVIEW_ONLY" -> "DGE_BLOCKED_COMPARATOR_AMBIGUOUS"
            sampleLinkageState != "SAMPLE_ID_LINKAGE_CANDIDATE_REVIEW_ONLY" -> "DGE_BLOCKED_SAMPLE_ID_LINKAGE_PENDING"
            else -> "DGE_READY_REVIEW_ONLY"
        }
        val etlState = when (verdict) {
            "DGE_READY_REVIEW_ONLY" -> "ETL_READY_FOR_REVIEW_ONLY_DGE"
            "DGE_BLOCKED_MATRIX_FILE_DISCOVERY_REQUIRED" -> "ETL_FILE_DISCOVERY_REQUIRED"
            "DGE_BLOCKED_METADATA_MISSING" -> "ETL_METADATA_EXTRACTION_REQUIRED"
            "DGE_BLOCKED_COMPARATOR_AMBIGUOUS" -> "ETL_COMPARATOR_NORMALIZATION_REQUIRED"
            "DGE_BLOCKED_SAMPLE_ID_LINKAGE_PENDING" -> "ETL_SAMPLE_ID_LINKAGE_REQUIRED"
            else -> "ETL_REVIEW_REQUIRED"
        }
        val score = when (verdict) {
            "DGE_READY_REVIEW_ONLY" -> 88
            "DGE_BLOCKED_SAMPLE_ID_LINKAGE_PENDING" -> 78
            "DGE_BLOCKED_COMPARATOR_AMBIGUOUS" -> 68
            "DGE_BLOCKED_METADATA_MISSING" -> 56
            "DGE_BLOCKED_MATRIX_FILE_DISCOVERY_REQUIRED" -> 48
            else -> 30
        }.coerceAtMost(maxOf(card.dgeReadinessScore + 10, 35)).coerceIn(0, 90)

        val gates = mutableListOf<String>()
        if (!hardFileCandidate) gates += "FILE_DISCOVERY_REQUIRED:: locate GEO/SRA/ArrayExpress supplementary raw counts, matrix.mtx, h5, rds, csv/tsv expression matrix, or series matrix."
        if (!metadataCandidate) gates += "METADATA_EXTRACTION_REQUIRED:: parse sample title, source_name, characteristics, disease, tissue, cell type, treatment, severity, and timepoint."
        if (comparatorState != "COMPARATOR_NORMALIZED_REVIEW_ONLY") gates += "COMPARATOR_NORMALIZATION_REQUIRED:: suggest case/control, healthy/recovered, severity, treated/untreated, responder/non-responder, baseline/follow-up labels with evidence snippets."
        if (sampleLinkageState != "SAMPLE_ID_LINKAGE_CANDIDATE_REVIEW_ONLY") gates += "SAMPLE_ID_LINKAGE_REQUIRED:: verify matrix columns/cell barcodes match metadata rows before DGE."
        if (gates.isEmpty()) gates += "REVIEW_ONLY_DGE_READY:: run DGE only with contradiction and batch/comparator checks."

        val next = when (verdict) {
            "DGE_BLOCKED_MATRIX_FILE_DISCOVERY_REQUIRED" -> "$target: run repository file discovery for raw/count matrix, h5, mtx/rds, csv/tsv or series matrix before DGE."
            "DGE_BLOCKED_METADATA_MISSING" -> "$target: parse sample metadata fields and extract evidence snippets before comparator mapping."
            "DGE_BLOCKED_COMPARATOR_AMBIGUOUS" -> "$target: normalize comparator labels with evidence snippets; do not let LLM labels become final truth."
            "DGE_BLOCKED_SAMPLE_ID_LINKAGE_PENDING" -> "$target: match sample IDs/barcodes between matrix columns and metadata rows."
            else -> "$target: ETL gates are review-ready; run bounded DGE only after batch/comparator contradiction checks."
        }

        val summary = "Matrix ETL bridge: version=$VERSION | state=$etlState | target=$target | readiness=$score/100 | file_discovery=$fileDiscoveryState | metadata=$metadataState | comparator=$comparatorState | sample_linkage=$sampleLinkageState | verdict=$verdict"
            .replace(Regex("\\s+"), " ")
            .trim()
        val metadataLine = "Metadata normalization: state=$metadataState | suggestions=case/control/severity/treatment/timepoint require confidence + source_field + evidence_snippet | comparator=$comparatorState | sample_linkage=$sampleLinkageState"
            .replace(Regex("\\s+"), " ")
            .trim()

        return GTIMMatrixEtlMetadataBridgeReportV2780(
            active = true,
            targetId = target,
            etlState = etlState,
            readinessScore = score,
            fileDiscoveryState = fileDiscoveryState,
            metadataNormalizationState = metadataState,
            comparatorNormalizationState = comparatorState,
            sampleIdLinkageState = sampleLinkageState,
            dgeReadinessVerdict = verdict,
            nextStep = next,
            gates = gates.distinct().take(6),
            summaryLine = summary,
            metadataLine = metadataLine,
            boundaryLine = boundary()
        )
    }

    fun nextLine(report: GTIMMatrixEtlMetadataBridgeReportV2780): String {
        val firstGate = report.gates.firstOrNull()?.substringBefore("::") ?: "REVIEW_ONLY_DGE_READY"
        return "Matrix ETL next: boundary=review-only | $firstGate | ${report.nextStep} | gates=${report.gates.take(3).joinToString("; ")}"
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun boundary(): String = "Matrix ETL boundary: dataset-readiness routing only; no biological proof, no clinical claim, no treatment advice, no DGE result."

    private fun normalize(value: String): String = value.lowercase()
        .replace('_', ' ')
        .replace('-', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun containsAny(text: String, vararg needles: String): Boolean = needles.any { text.contains(it, ignoreCase = true) }
}
