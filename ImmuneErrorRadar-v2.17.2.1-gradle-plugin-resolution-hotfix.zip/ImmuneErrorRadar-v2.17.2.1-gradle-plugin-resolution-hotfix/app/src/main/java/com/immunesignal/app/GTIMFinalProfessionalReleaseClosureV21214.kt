package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.14 — Final professional release closure.
 *
 * Last-mile release layer: it ties the old rails and the v2.12.11–v2.12.13 rails into one
 * final professional research dossier contract. It is deliberately not a biological proof
 * engine; it declares release readiness, route linkage, and the claim boundary.
 */
object GTIMFinalProfessionalReleaseClosureV21214 {
    const val VERSION: String = "2.12.14-final-professional-release-closure"
    const val RELEASE_NAME: String = "2.12.14-final-professional-research-release-unified"
    const val CLAIM_LIMIT: String = "final_release_closure_research_only_no_evidence_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val surface = report.optJSONObject("reportProfessionalSurfaceSanityV21214") ?: GTIMReportProfessionalSurfaceSanityV21214.toJson(report)
        val strict = report.optJSONObject("pharmaGradeStrictnessGateV21213") ?: JSONObject()
        val continuation = report.optJSONObject("terminalDiscoveryContinuationV21212") ?: JSONObject()
        val missing = missingRouteBlocks(report)
        val ready = missing.length() == 0 &&
            !surface.optString("abstractRouteContamination").contains("leak", true) &&
            strict.optBoolean("discoveryMayContinue", true) &&
            !strict.optBoolean("claimPromotionAllowed", false)
        return JSONObject()
            .put("version", VERSION)
            .put("releaseName", RELEASE_NAME)
            .put("closureState", if (ready) "FINAL_PROFESSIONAL_RESEARCH_RELEASE_READY" else "FINAL_RELEASE_NEEDS_REVIEW")
            .put("routeLinkageState", if (missing.length() == 0) "OLD_AND_NEW_ROUTES_LINKED" else "ROUTE_LINKAGE_GAP")
            .put("missingRouteBlocks", missing)
            .put("firstSurfaceState", surface.optString("surfaceState", "UNKNOWN"))
            .put("strictnessState", strict.optString("state", "STRICT_PROMOTION_BLOCKED_DISCOVERY_CONTINUES"))
            .put("continuationState", continuation.optString("state", "DISCOVERY_CONTINUES_UNTIL_TERMINAL_REVIEW_PLAN"))
            .put("discoveryContinuationRequired", true)
            .put("evidencePromotionAllowed", false)
            .put("claimPromotionAllowed", false)
            .put("professionalContract", professionalContract())
            .put("githubSafety", "static_audits_json_xml_kotlin_string_workflow_release_hygiene_zip_integrity_required")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        return listOf(
            "Final professional release closure",
            "State: ${obj.optString("closureState", "UNKNOWN")}; route_linkage=${obj.optString("routeLinkageState", "UNKNOWN")}; release=${obj.optString("releaseName", RELEASE_NAME)}.",
            "Contract: ${obj.optString("professionalContract", professionalContract()).takeClean(360)}",
            "Boundary: discovery continues; evidence/claim promotion remains blocked until external review and hard gates close."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        RELEASE_NAME,
        "FINAL_PROFESSIONAL_RESEARCH_RELEASE_READY",
        "OLD_AND_NEW_ROUTES_LINKED",
        "discoveryContinuationRequired",
        "evidencePromotionAllowed",
        "static_audits_json_xml_kotlin_string_workflow_release_hygiene_zip_integrity_required",
        CLAIM_LIMIT
    ))

    private fun requiredRouteBlocks(): List<String> = listOf(
        "studyFocusNormalizerV21282",
        "externalRouterV211310",
        "matrixShortcutResolverV2124",
        "matrixShortcutStatusLayerV2129",
        "functionalRepairDossierV2120",
        "studyGradeFunctionalSolutionV2121",
        "domainSpecificHypothesisSelectorV2129",
        "relaxedResearchLeadBridgeV2122",
        "globalReportLearningV2124",
        "unifiedRouteReleaseContractV2125",
        "studyResultCardV2126",
        "finalWorldStudyDossierV2128",
        "finalResearchValueBoosterV212101",
        "curatedMetadataSeedLibraryV21211",
        "terminalDiscoveryContinuationV21212",
        "targetValidationCardV21213",
        "hypothesisVariantDiscriminatorV21213",
        "pharmaGradeStrictnessGateV21213",
        "reportProfessionalSurfaceSanityV21214"
    )

    private fun missingRouteBlocks(report: JSONObject): JSONArray = JSONArray(requiredRouteBlocks().filter { !report.has(it) })

    private fun professionalContract(): String = "final dossier must show study focus, research result, repair function, curated/internal seed state, external continuation, target/readout card, hypothesis variants, negative evidence, strictness gate, and claim boundary; technical trace remains appendix-only."

    private fun String.takeClean(max: Int): String {
        val clean = replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= max) clean else clean.take(max).trimEnd()
    }
}
