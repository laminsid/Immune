package com.immunesignal.app

// v2.12.0 — Functional Repair Dossier models.
// This layer turns a safe research route into a paper-like study dossier: root dysfunction,
// repair function, biological tool candidate, evidence tension, and validation plan. It is
// deliberately split from ETL/DGE so value can be produced without pretending that DGE ran.

data class GTIMFunctionalDysfunctionModelV2120(
    val modelId: String,
    val primaryDysfunction: String,
    val causalSketch: List<String>,
    val crossDiseaseBridge: List<String>,
    val contextModifiers: List<String>,
    val line: String
)

data class GTIMFunctionalRepairFunctionV2120(
    val functionId: String,
    val repairFunction: String,
    val biologicalToolClass: String,
    val plausibleMechanism: String,
    val evidenceLevel: String,
    val missingEvidence: List<String>,
    val biosafetyBoundaries: List<String>,
    val line: String
)

data class GTIMEvidenceTensionMapV2120(
    val supportSignals: List<String>,
    val contradictionsOrWeaknesses: List<String>,
    val ambiguityDrivers: List<String>,
    val killCriteria: List<String>,
    val noveltyState: String,
    val line: String
)

data class GTIMFunctionalStudyDesignV2120(
    val studyQuestion: String,
    val datasetValidationPlan: List<String>,
    val labValidationPlan: List<String>,
    val decisiveReadouts: List<String>,
    val upgradeRules: List<String>,
    val line: String
)

data class GTIMFunctionalRepairDossierV2120(
    val active: Boolean,
    val version: String,
    val state: String,
    val valueClaim: String,
    val dysfunctionModel: GTIMFunctionalDysfunctionModelV2120,
    val repairFunctions: List<GTIMFunctionalRepairFunctionV2120>,
    val evidenceTension: GTIMEvidenceTensionMapV2120,
    val studyDesign: GTIMFunctionalStudyDesignV2120,
    val boundaryLine: String,
    val line: String
)
