package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.5 — Unified route/release contract.
 *
 * This is not a new discovery engine. It is the single linkage contract that keeps the
 * old safety/ETL/DGE rails and the new value rails connected in one GitHub-safe release
 * surface. It prevents the app from drifting into disconnected code islands after many
 * patch layers.
 */
object GTIMUnifiedRouteReleaseContractV2125 {
    const val VERSION: String = "2.12.5-unified-route-release-contract"
    const val ACTIVE_SURFACE: String = "Immu DZ unified research-value dossier"
    const val CLAIM_LIMIT: String = "unified_contract_links_routes_without_evidence_upgrade"

    private val oldRails = listOf(
        "topic_isolation_v2741",
        "topic_run_isolation_v2742",
        "downstream_contamination_closure_v2745_v2746",
        "accession_to_matrix_resolver_v2761",
        "dge_execution_bridge_v2770_v2771",
        "final_etl_execution_unifier_v2782",
        "actual_etl_pipeline_v2800_v2803",
        "target_recall_matrix_link_v2900_v2910"
    )

    private val newRails = listOf(
        "external_router_v211310",
        "functional_repair_dossier_v2120",
        "study_grade_solution_v2121",
        "relaxed_research_lead_bridge_v2122",
        "same_topic_deepening_v2123",
        "global_report_learning_v2124",
        "matrix_shortcut_resolver_v2124",
        "study_result_card_v2126"
    )

    private val routeChain = listOf(
        "topic_capture",
        "topic_gate",
        "target_or_candidate_lookup_handle",
        "external_router",
        "matrix_shortcut_resolver",
        "functional_repair_dossier",
        "study_grade_solution_hypothesis",
        "global_report_learning",
        "same_topic_deepening",
        "study_result_card",
        "export_pdf_or_copy_report"
    )

    fun toJson(report: JSONObject): JSONObject {
        val state = buildState(report)
        return JSONObject()
            .put("version", VERSION)
            .put("activeSurface", ACTIVE_SURFACE)
            .put("routeChain", JSONArray(routeChain))
            .put("legacyRailsRetained", JSONArray(oldRails))
            .put("newRailsConnected", JSONArray(newRails))
            .put("connectedJsonFields", JSONArray(state.connectedJsonFields))
            .put("missingJsonFields", JSONArray(state.missingJsonFields))
            .put("githubSafety", state.githubSafety)
            .put("uiPolicy", "old live report views hidden, not deleted; export and copy remain available")
            .put("strictnessPolicy", "P0/P1 creates research-lead/value dossier instead of empty blocked-only output; DGE/gene/clinical claims remain gated")
            .put("matrixPolicy", "raw matrix missing routes into review-only processed-expression shortcut sources without marking DGE_READY")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(report: JSONObject): List<String> {
        val obj = report.optJSONObject("unifiedRouteReleaseContractV2125") ?: toJson(report)
        val missing = jsonArray(obj.optJSONArray("missingJsonFields"))
        return listOf(
            "Unified route contract",
            "Active release surface: ${obj.optString("activeSurface", ACTIVE_SURFACE)} | version=${obj.optString("version", VERSION)}",
            "Route chain: topic → target/candidate → external router → matrix shortcut → functional repair → study solution → global learning → study-result card → export.",
            "Old rails retained: ETL/DGE/topic-isolation safety remains active; old code paths are linked, not deleted.",
            "New value rails connected: functional repair, study-grade solution, relaxed lead capture, same-topic deepening, global learning, matrix shortcut resolver, and study-result card.",
            "Compatibility state: missing_fields=${missing.joinToString(", ").ifBlank { "none" }}; github_safety=${obj.optString("githubSafety", "static-and-runtime-linkage-guarded")}",
            "Unified boundary: ${obj.optString("claimLimit", CLAIM_LIMIT)}. Research value may be produced without claiming biological proof."
        )
    }

    fun technicalLines(report: JSONObject): List<String> {
        val obj = report.optJSONObject("unifiedRouteReleaseContractV2125") ?: toJson(report)
        return listOf(
            "Unified route/release contract: version=${obj.optString("version", VERSION)} | surface=${obj.optString("activeSurface", ACTIVE_SURFACE)} | claim_limit=${obj.optString("claimLimit", CLAIM_LIMIT)}",
            "Unified route chain: ${jsonArray(obj.optJSONArray("routeChain")).joinToString(" -> ")}",
            "Unified legacy rails retained: ${jsonArray(obj.optJSONArray("legacyRailsRetained")).joinToString(" + ")}",
            "Unified new rails connected: ${jsonArray(obj.optJSONArray("newRailsConnected")).joinToString(" + ")}",
            "Unified connected fields: ${jsonArray(obj.optJSONArray("connectedJsonFields")).joinToString(", ")}",
            "Unified missing fields: ${jsonArray(obj.optJSONArray("missingJsonFields")).joinToString(", ").ifBlank { "none" }}"
        )
    }

    private data class State(
        val connectedJsonFields: List<String>,
        val missingJsonFields: List<String>,
        val githubSafety: String
    )

    private fun buildState(report: JSONObject): State {
        val expected = listOf(
            "reportConsistencyGateV2121",
            "externalRouterV211310",
            "matrixShortcutResolverV2124",
            "functionalRepairDossierV2120",
            "studyGradeFunctionalSolutionV2121",
            "relaxedResearchLeadBridgeV2122",
            "functionalOutputForcingGuardV2122",
            "sameTopicDeepeningV2123",
            "globalReportLearningV2124",
            "studyResultCardV2126"
        )
        val connected = expected.filter { report.has(it) }
        val missing = expected.filterNot { report.has(it) }
        val safety = when {
            missing.isEmpty() -> "all_value_and_safety_rails_present"
            connected.size >= 6 -> "partial_runtime_fields_present_static_linkage_retained"
            else -> "static_contract_ready_runtime_fields_will_fill_after_search"
        }
        return State(connected, missing, safety)
    }

    private fun jsonArray(arr: JSONArray?): List<String> = if (arr == null) emptyList() else (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { v -> v.isNotBlank() } }
}
