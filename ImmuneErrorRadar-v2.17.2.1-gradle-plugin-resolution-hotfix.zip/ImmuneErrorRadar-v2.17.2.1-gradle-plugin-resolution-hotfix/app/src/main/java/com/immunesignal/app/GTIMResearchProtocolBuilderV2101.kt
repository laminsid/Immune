package com.immunesignal.app

/** v2.10.1 — PICO/PECO research protocol builder. */
object GTIMResearchProtocolBuilderV2101 {
    const val VERSION: String = "2.10.1-research-protocol-builder"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        established: List<GTIMEstablishedEvidenceCardV2100>,
        routes: List<GTIMTherapeuticRouteCardV2100>
    ): GTIMResearchProtocolCardV2101 {
        val anchor = contract.primaryAnchor.routeId.oneLine()
        val lower = anchor.lowercase()
        val framework = when {
            lower.contains("diet") || lower.contains("microbiome") || lower.contains("exposure") -> "PECO_REVIEW_FRAMEWORK"
            lower.contains("cancer") || lower.contains("therapy") || lower.contains("treatment") -> "PICO_TRANSLATIONAL_REVIEW_FRAMEWORK"
            else -> "PICO_PECO_HYBRID_RESEARCH_FRAMEWORK"
        }
        val population = when {
            lower.contains("cancer") -> "Patients/samples with the cancer phenotype or tumor context explicitly supported by metadata."
            lower.contains("covid") || lower.contains("viral") || lower.contains("ebola") || lower.contains("hantavirus") -> "Human or model samples with explicit pathogen, tissue, and timepoint metadata."
            lower.contains("diabetes") || lower.contains("metabolic") -> "Cohorts/samples with explicit metabolic phenotype and medication/context metadata."
            lower.contains("microbiome") || lower.contains("gut") || lower.contains("ibd") -> "Gut/mucosal disease or exposure cohorts with explicit diet/microbiome/barrier context."
            else -> "Topic-compatible cohorts/samples with explicit phenotype, tissue, comparator and source metadata."
        }
        val intervention = routes.firstOrNull()?.routeClass ?: established.firstOrNull()?.topicArea ?: "immune/genetic mechanism or exposure route"
        val comparator = "Matched control, baseline, responder/non-responder, exposed/unexposed, or case/control group with evidence_snippet and source_field."
        val outcomes = listOf(
            "clinical or phenotype outcome if externally reported",
            "immune/genetic mechanism readout",
            "validated biomarker or pathway evidence",
            "dataset-level expression/pathway signal only when DGE or external capsule is validated",
            "safety and claim-limit status"
        )
        val inclusion = listOf(
            "human, clinical, guideline, systematic review, curated repository metadata, or validated external evidence capsule",
            "explicit disease/topic anchor and comparator",
            "source_field plus evidence_snippet for sample labels",
            "method, thresholds, provenance and validation status for any external capsule"
        )
        val exclusion = listOf(
            "personal stories or promotional claims without verifiable source",
            "metadata-only route promoted as biological proof",
            "LLM label treated as final truth",
            "treatment, dosing, medication-stopping, efficacy, or patient-specific advice"
        )
        val question = "For topic=${anchor}, what does established science support, what did GTIM explore, and which immune/genetic therapeutic-route hypotheses remain untested or not authority-validated?"
        val line = "Research protocol: version=$VERSION | framework=$framework | question=${question.oneLine()} | population=${population.oneLine()} | intervention_or_exposure=${intervention.oneLine()} | comparator=${comparator.oneLine()} | outcomes=${outcomes.joinToString("; ")}"
        return GTIMResearchProtocolCardV2101(
            protocolId = "PROTOCOL_PICO_PECO_V2101",
            framework = framework,
            researchQuestion = question,
            populationOrProblem = population,
            interventionOrExposure = intervention,
            comparator = comparator,
            outcomes = outcomes,
            inclusionCriteria = inclusion,
            exclusionCriteria = exclusion,
            line = line
        )
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
