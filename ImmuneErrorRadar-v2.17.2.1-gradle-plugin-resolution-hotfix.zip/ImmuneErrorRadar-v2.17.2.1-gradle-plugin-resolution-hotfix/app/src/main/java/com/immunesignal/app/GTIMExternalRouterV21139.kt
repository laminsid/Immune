package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

/**
 * v2.11.3.9 — External Router surface.
 *
 * This layer breaks the old all-or-nothing block by surfacing safe public lookup routes
 * when internal ETL/DGE cannot run. It never downloads a matrix, never executes DGE,
 * never upgrades evidence, and never creates clinical or treatment claims.
 */
object GTIMExternalRouterV21139 {
    const val VERSION: String = "2.11.3.10-external-router-evidence-capsule"
    const val CLAIM_LIMIT: String = "external_router_lookup_only_not_dge_ready_not_clinical_claim"

    data class ExternalRoute(
        val source: String,
        val purpose: String,
        val queryOrHandle: String,
        val url: String,
        val safety: String,
        val extractionChecklist: List<String> = emptyList()
    )

    data class ExternalRouterReport(
        val active: Boolean,
        val state: String,
        val targetId: String,
        val query: String,
        val routes: List<ExternalRoute>,
        val line: String,
        val boundaryLine: String
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): ExternalRouterReport {
        val consistency = GTIMReportConsistencyGateV2121.build(report, technicalLines)
        val acceptedTarget = consistency.acceptedTarget
        val candidateLookupHandle = consistency.candidateLookupHandle
        val target = firstNonBlank(
            acceptedTarget,
            candidateLookupHandle,
            extractTargetFromJson(report)
        ).let { if (looksLikeTarget(it)) it else "" }
        val query = firstNonBlank(
            topicFromReport(report),
            extractQueryFromLines(technicalLines),
            target.takeIf { !it.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true) }.orEmpty(),
            "immune response dataset matrix comparator accession"
        )
        val hasAcceptedTarget = acceptedTarget.isNotBlank()
        val hasLookupHandle = target.isNotBlank() && looksLikeTarget(target)
        val routeKey = if (hasLookupHandle) target else query
        val routes = mutableListOf<ExternalRoute>()
        routes += route(
            source = "NCBI GEO",
            purpose = if (hasLookupHandle && target.startsWith("GSE", true)) "Open dataset record and supplementary file list" else "Search GEO for topic-compatible dataset accessions",
            queryOrHandle = routeKey,
            url = if (hasLookupHandle && target.startsWith("GSE", true)) "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=${enc(target)}" else "https://www.ncbi.nlm.nih.gov/gds/?term=${enc(query)}",
            safety = "metadata_and_file_listing_only",
            extractionChecklist = listOf("supplementary file names", "raw/count matrix availability", "sample table", "platform/species/tissue")
        )
        routes += route(
            source = "NCBI SRA",
            purpose = "Map GEO/BioProject/SRP/SRR run metadata before any matrix claim",
            queryOrHandle = routeKey,
            url = "https://www.ncbi.nlm.nih.gov/sra/?term=${enc(routeKey)}",
            safety = "run_metadata_only_no_expression_claim",
            extractionChecklist = listOf("SRP/SRR links", "library strategy", "sample identifiers", "run-to-sample mapping")
        )
        routes += route(
            source = "Europe PMC",
            purpose = "Find data-availability text, accession mentions, DOI/PMCID links",
            queryOrHandle = query,
            url = "https://europepmc.org/search?query=${enc(query + " data availability GEO SRA RNA-seq")}",
            safety = "literature_metadata_only",
            extractionChecklist = listOf("data availability statement", "GEO/SRA/ArrayExpress handles", "cohort/comparator wording", "paper-methods clue")
        )
        routes += route(
            source = "OpenAlex",
            purpose = "Cross-index works, DOI, open-access metadata, cited dataset clues",
            queryOrHandle = query,
            url = "https://openalex.org/works?search=${enc(query + " dataset accession")}",
            safety = "cross_index_lookup_only",
            extractionChecklist = listOf("DOI", "open-access landing page", "related works", "dataset/accession clues")
        )
        routes += route(
            source = "GREIN / refine.bio / recount3",
            purpose = "Check whether public processed expression summaries may exist",
            queryOrHandle = routeKey,
            url = if (hasLookupHandle) "external-processed-expression-check:${routeKey}" else "external-processed-expression-check:${enc(query)}",
            safety = "availability_or_processed_summary_only_never_internal_dge_ready",
            extractionChecklist = listOf("processed expression availability", "normalization notes", "comparator labels", "exportable summary only")
        )
        routes += route(
            source = "Enrichr / Reactome / SigComLINCS",
            purpose = "Use only after a reviewed top-gene list or external evidence capsule exists",
            queryOrHandle = "requires_reviewed_gene_list_or_capsule",
            url = "external-gene-list-router:waiting_for_reviewed_gene_list",
            safety = "pathway_interpretation_only_no_treatment_claim",
            extractionChecklist = listOf("pathway labels", "enrichment caveats", "gene-list provenance", "contradiction prompts")
        )
        val state = when {
            hasAcceptedTarget -> "EXTERNAL_ROUTER_READY_FOR_ACCEPTED_TARGET_LOOKUP"
            hasLookupHandle -> "EXTERNAL_ROUTER_READY_FOR_CANDIDATE_HANDLE_LOOKUP"
            else -> "EXTERNAL_ROUTER_READY_FOR_TOPIC_SEARCH"
        }
        val line = "External Router: version=$VERSION | state=$state | acceptedTarget=${acceptedTarget.ifBlank { "NONE" }} | candidateLookupHandle=${candidateLookupHandle.ifBlank { "NONE" }} | routes=${routes.joinToString(",") { it.source }} | claim_limit=$CLAIM_LIMIT"
        return ExternalRouterReport(
            active = true,
            state = state,
            targetId = target,
            query = query,
            routes = routes,
            line = normalize(line),
            boundaryLine = "External Router boundary: routes are lookup/request plans only; they may make the report useful for a researcher, but they do not create internal DGE readiness, gene/pathway proof, clinical advice, dosing, efficacy, or treatment claims."
        )
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val router = build(report, technicalLines)
        val targetOrQuery = if (router.targetId.isBlank()) router.query else router.targetId
        val firstRoutes = router.routes.take(5)
        val lines = mutableListOf<String>()
        lines += "External Router: ${router.state} — safe lookup routes are available without upgrading evidence."
        lines += when {
            router.state.contains("CANDIDATE_HANDLE") -> "Candidate lookup handle: ${targetOrQuery.take(180)} — not accepted as an internal ETL/DGE target yet."
            router.targetId.isBlank() -> "Lookup query: ${targetOrQuery.take(180)}"
            else -> "Lookup handle: ${targetOrQuery.take(180)}"
        }
        lines += "What this adds: external sources can identify accession links, matrix files, sample labels, and gene-list evidence capsules; they do not make the internal result proven."
        firstRoutes.forEachIndexed { index, route ->
            val checklist = route.extractionChecklist.take(3).joinToString(", ").ifBlank { route.purpose }
            lines += "${index + 1}. ${route.source}: ${route.purpose}; extract: $checklist; link: ${route.url.take(180)}"
        }
        lines += "External boundary: lookup-only; no internal DGE_READY, no gene/pathway proof, no clinical or treatment claim."
        return lines
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val router = build(report, technicalLines)
        val routes = JSONArray()
        router.routes.forEach { route ->
            routes.put(JSONObject()
                .put("source", route.source)
                .put("purpose", route.purpose)
                .put("queryOrHandle", route.queryOrHandle)
                .put("url", route.url)
                .put("safety", route.safety)
                .put("extract", JSONArray(route.extractionChecklist)))
        }
        return JSONObject()
            .put("version", VERSION)
            .put("claimLimit", CLAIM_LIMIT)
            .put("active", router.active)
            .put("state", router.state)
            .put("targetId", router.targetId)
            .put("query", router.query)
            .put("line", router.line)
            .put("boundaryLine", router.boundaryLine)
            .put("routes", routes)
    }

    fun technicalLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val router = build(report, technicalLines)
        return listOf(router.line, router.boundaryLine) + router.routes.map {
            "External route: source=${it.source} | purpose=${it.purpose} | handle=${it.queryOrHandle} | url=${it.url} | safety=${it.safety} | extract=${it.extractionChecklist.joinToString(",")}"
        }
    }

    private fun route(source: String, purpose: String, queryOrHandle: String, url: String, safety: String, extractionChecklist: List<String> = emptyList()): ExternalRoute =
        ExternalRoute(source, normalize(purpose), normalize(queryOrHandle), url, safety, extractionChecklist.map { normalize(it) })

    private fun topicFromReport(report: JSONObject): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossierReport")
            ?: report.optJSONObject("mechanismDiscoveryDossier")
            ?: JSONObject()
        val v3 = report.optJSONObject("reportV3") ?: report.optJSONObject("v3Report") ?: JSONObject()
        return firstNonBlank(
            topic.optString("normalizedTopic"),
            topic.optString("rawInput"),
            mechanism.optString("researchQuestion"),
            mechanism.optString("bestResearchLeadSummary"),
            v3.optString("hypothesis")
        )
    }

    private fun extractTargetFromJson(report: JSONObject): String {
        val direct = listOf("targetId", "target", "selectedTarget", "gse")
            .asSequence()
            .map { report.optString(it) }
            .firstOrNull { looksLikeTarget(it) }
            .orEmpty()
        if (direct.isNotBlank()) return direct
        val nestedKeys = listOf("actualEtlExecution", "gtimActualEtl", "metadataFirstBridge", "externalProcessedAvailability")
        for (key in nestedKeys) {
            val obj = report.optJSONObject(key) ?: continue
            val value = listOf("targetId", "target", "dataset_id", "datasetId").map { obj.optString(it) }.firstOrNull { looksLikeTarget(it) }
            if (!value.isNullOrBlank()) return value
        }
        return ""
    }

    private fun extractTargetFromLines(lines: List<String>): String {
        val joined = lines.joinToString(" ")
        val targetPattern = Regex("target=([A-Za-z0-9_.:-]+)")
        val target = targetPattern.findAll(joined).map { it.groupValues[1] }.firstOrNull { looksLikeTarget(it) }.orEmpty()
        if (target.isNotBlank()) return target
        return Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|PRJNA\\d+|SDY\\d+)\\b", RegexOption.IGNORE_CASE)
            .find(joined)?.value.orEmpty().uppercase(Locale.US)
    }

    private fun extractQueryFromLines(lines: List<String>): String {
        val prefixes = listOf("What the app understood:", "Research question:", "Best query to run:", "User query captured:")
        for (line in lines) {
            for (prefix in prefixes) {
                if (line.startsWith(prefix)) return line.removePrefix(prefix).trim().take(220)
            }
        }
        return ""
    }

    private fun looksLikeTarget(value: String): Boolean {
        val v = value.trim().uppercase(Locale.US)
        if (v.isBlank() || v == "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" || v == "NO_TOPIC_COMPAT" || v == "BLOCKED" || v == "UNKNOWN" || v.startsWith("PMID")) return false
        return Regex("^(GSE|GDS|GSM|SRP|SRR|SRS|SRX|PRJNA|PRJEB|SDY|E-MTAB)[A-Z0-9_.-]*\\d+$", RegexOption.IGNORE_CASE).containsMatchIn(v)
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")
    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""
}
