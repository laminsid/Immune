package com.immunesignal.app

/**
 * v2.10.1 — Medical-study structure models for the final dossier.
 *
 * These cards do not turn the app output into a clinical trial. They make every
 * dossier look like a reviewable medical-study file: question, PICO/PECO,
 * search strategy, evidence table, and explicit not-yet-validated statements.
 */
data class GTIMResearchProtocolCardV2101(
    val protocolId: String,
    val framework: String,
    val researchQuestion: String,
    val populationOrProblem: String,
    val interventionOrExposure: String,
    val comparator: String,
    val outcomes: List<String>,
    val inclusionCriteria: List<String>,
    val exclusionCriteria: List<String>,
    val line: String
)

data class GTIMSearchStrategyCardV2101(
    val strategyId: String,
    val databases: List<String>,
    val queryStrings: List<String>,
    val requiredTraceFields: List<String>,
    val traceStatus: String,
    val line: String
)

data class GTIMEvidenceTableRowV2101(
    val rowId: String,
    val claimOrRoute: String,
    val sourceClass: String,
    val studyDesign: String,
    val populationContext: String,
    val interventionOrExposure: String,
    val comparator: String,
    val outcomeOrReadout: String,
    val certainty: String,
    val validationStatus: String,
    val limitation: String,
    val line: String
)

data class GTIMAuthorityValidationStatementV2101(
    val statementId: String,
    val discoveryOrRouteId: String,
    val validationStatus: String,
    val requiredValidation: List<String>,
    val notYetValidatedStatement: String,
    val line: String
)
