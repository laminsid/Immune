package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

// v2.12.0 — Functional Repair Dossier Engine.
// This is the product-value layer: it turns routing/gates into a root-cause study dossier
// with biological-tool hypotheses, without breaking DGE/ETL safety locks.
object GTIMFunctionalRepairDossierEngineV2120 {
    const val VERSION: String = "2.12.0-functional-repair-dossier-engine"
    const val BOUNDARY: String = "research_only_functional_repair_hypothesis_no_diagnosis_no_treatment_no_administration_route_no_engineering_protocol"

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): GTIMFunctionalRepairDossierV2120 {
        val technical = if (technicalLines.isNotEmpty()) technicalLines else GlobalResearchGradeBriefV11061.renderLines(report)
        val topic = topic(report, technical)
        val target = target(technical)
        val evidenceText = (technical.joinToString(" ") + " " + report.toString()).take(6000)
        val route = firstLineAfterPrefix(technical, "Strongest exploratory route:").ifBlank { firstLineAfterPrefix(technical, "Research route:") }
        val model = GTIMFunctionalRepairDysfunctionModelBuilderV2120.build(topic, route, target, evidenceText)
        val functions = GTIMFunctionalRepairCandidateToolEngineV2120.build(model, topic, target)
        val tension = GTIMFunctionalRepairEvidenceTensionMapperV2120.map(model, functions, target, evidenceText)
        val study = GTIMFunctionalRepairStudyDesignComposerV2120.compose(topic, target, model, functions, tension)
        val state = when {
            functions.any { it.evidenceLevel.contains("L0") } -> "FUNCTIONAL_REPAIR_OPEN_STUDY_DOSSIER"
            target.isBlank() || target == "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" || target == "BLOCKED" -> "FUNCTIONAL_REPAIR_TARGET_NEEDED_STUDY_DOSSIER"
            else -> "FUNCTIONAL_REPAIR_CANDIDATE_STUDY_DOSSIER_READY"
        }
        val value = "added_value=root dysfunction model + repair function + biological tool candidate + evidence tension + validation plan"
        val line = "Functional repair dossier: version=$VERSION | state=$state | $value | model=${model.modelId} | candidates=${functions.size} | novelty=${tension.noveltyState} | boundary=$BOUNDARY"
        return GTIMFunctionalRepairDossierV2120(true, VERSION, state, value, model, functions, tension, study, BOUNDARY, line)
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val d = build(report, technicalLines)
        val primary = d.repairFunctions.firstOrNull()
        val secondary = d.repairFunctions.drop(1).firstOrNull()
        val lines = mutableListOf<String>()
        lines += "Functional repair study dossier"
        lines += "Added value: ${d.valueClaim}"
        lines += "Root dysfunction model: ${d.dysfunctionModel.primaryDysfunction}"
        lines += "Cross-disease bridge: ${d.dysfunctionModel.crossDiseaseBridge.joinToString("; ").take(260)}"
        if (primary != null) {
            lines += "Candidate repair function: ${primary.repairFunction}"
            lines += "Candidate biological tool class: ${primary.biologicalToolClass}"
            lines += "Why it could matter: ${primary.plausibleMechanism}"
            lines += "Evidence level: ${primary.evidenceLevel} — unvalidated research route only"
        }
        if (secondary != null) {
            lines += "Alternative repair route: ${secondary.repairFunction} (${secondary.biologicalToolClass})"
        }
        lines += "Evidence tension: supports=${d.evidenceTension.supportSignals.take(3).joinToString("; ").ifBlank { "no decisive support yet" }}"
        lines += "Weaknesses: ${d.evidenceTension.contradictionsOrWeaknesses.take(4).joinToString("; ")}" 
        lines += "What would kill it: ${d.evidenceTension.killCriteria.take(4).joinToString("; ")}" 
        lines += "Dataset validation plan: ${d.studyDesign.datasetValidationPlan.take(4).joinToString("; ")}" 
        lines += "Lab validation plan: ${d.studyDesign.labValidationPlan.take(3).joinToString("; ")}" 
        lines += "Upgrade rule: ${d.studyDesign.upgradeRules.joinToString("; ")}" 
        lines += "Boundary: research-only; no diagnosis, no treatment, no administration route, no wet-lab or organism-engineering protocol."
        return lines.map { it.oneLine() }
    }

    fun toJson(report: JSONObject): JSONObject {
        val d = build(report)
        return JSONObject()
            .put("version", d.version)
            .put("state", d.state)
            .put("valueClaim", d.valueClaim)
            .put("boundary", d.boundaryLine)
            .put("dysfunctionModel", JSONObject()
                .put("modelId", d.dysfunctionModel.modelId)
                .put("primaryDysfunction", d.dysfunctionModel.primaryDysfunction)
                .put("causalSketch", JSONArray(d.dysfunctionModel.causalSketch))
                .put("crossDiseaseBridge", JSONArray(d.dysfunctionModel.crossDiseaseBridge))
                .put("contextModifiers", JSONArray(d.dysfunctionModel.contextModifiers)))
            .put("repairFunctions", JSONArray(d.repairFunctions.map { f -> JSONObject()
                .put("functionId", f.functionId)
                .put("repairFunction", f.repairFunction)
                .put("biologicalToolClass", f.biologicalToolClass)
                .put("plausibleMechanism", f.plausibleMechanism)
                .put("evidenceLevel", f.evidenceLevel)
                .put("missingEvidence", JSONArray(f.missingEvidence))
                .put("biosafetyBoundaries", JSONArray(f.biosafetyBoundaries))
            }))
            .put("evidenceTension", JSONObject()
                .put("supportSignals", JSONArray(d.evidenceTension.supportSignals))
                .put("weaknesses", JSONArray(d.evidenceTension.contradictionsOrWeaknesses))
                .put("ambiguityDrivers", JSONArray(d.evidenceTension.ambiguityDrivers))
                .put("killCriteria", JSONArray(d.evidenceTension.killCriteria))
                .put("noveltyState", d.evidenceTension.noveltyState))
            .put("studyDesign", JSONObject()
                .put("studyQuestion", d.studyDesign.studyQuestion)
                .put("datasetValidationPlan", JSONArray(d.studyDesign.datasetValidationPlan))
                .put("labValidationPlan", JSONArray(d.studyDesign.labValidationPlan))
                .put("decisiveReadouts", JSONArray(d.studyDesign.decisiveReadouts))
                .put("upgradeRules", JSONArray(d.studyDesign.upgradeRules)))
    }

    private fun topic(report: JSONObject, lines: List<String>): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        return firstNonBlank(
            topic.optString("normalizedTopic"),
            topic.optString("rawInput"),
            firstLineAfterPrefix(lines, "What the app understood:"),
            report.optJSONObject("mechanismDiscoveryDossierReport")?.optString("researchQuestion") ?: ""
        )
    }

    private fun target(lines: List<String>): String {
        val joined = lines.joinToString(" ")
        return Regex("target=([A-Za-z0-9_.:-]+)").findAll(joined).map { it.groupValues[1] }
            .firstOrNull { it.isNotBlank() && it != "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" }
            ?: if (joined.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED")) "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" else ""
    }

    private fun firstLineAfterPrefix(lines: List<String>, prefix: String): String =
        lines.firstOrNull { it.startsWith(prefix) }?.removePrefix(prefix)?.trim().orEmpty()

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
