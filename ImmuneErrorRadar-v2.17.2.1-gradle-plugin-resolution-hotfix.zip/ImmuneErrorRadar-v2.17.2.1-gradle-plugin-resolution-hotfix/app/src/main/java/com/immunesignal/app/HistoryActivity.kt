package com.immunesignal.app

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import org.json.JSONObject

class HistoryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        findViewById<TextView>(R.id.historyText).apply {
            text = ""
            visibility = View.GONE
        }
        findViewById<Button>(R.id.closeButton).setOnClickListener { finish() }
    }

    private fun renderHistory(): String {
        val records = LocalCaseStore(this).readLatest(40)
        if (records.isEmpty()) return "No local cases yet."
        return records.mapIndexed { index, json ->
            val r = JSONObject(json)
            val result = r.getJSONObject("result")
            val signal = result.optInt("signalStrengthPercent", 0)
            val signalLabel = result.optString("signalStrengthLabel", "prototype signal")
            "#${index + 1} ${r.optString("createdAtText")}\n" +
                "${r.optString("label")}\n" +
                "${result.optString("severity")} — ${result.optString("pattern")}\n" +
                "Classifier: ${result.optString("classifierLabel", "legacy_record")}\n" +
                "Signal: $signalLabel ($signal%) • Data quality: ${result.optInt("dataQualityPercent")}%"
        }.joinToString("\n\n")
    }
}
