package com.immunesignal.app

import org.json.JSONObject
import java.util.Locale

object GTIMGseToSrpMapperV2950 {
    const val VERSION: String = "2.9.8-gse-to-srp-mapping-public-source-ready"

    fun build(targetId: String, soft: GTIMSoftMetadataProbeReportV2950, report: JSONObject? = null): GTIMGseToSrpMappingReportV2950 {
        val target = GTIMAccessionIdValidityGuardV2753.canonical(targetId)
        val eutils = if (target.startsWith("GSE", true)) "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=sra&term=$target%5BGEO%20Accession%5D&retmode=json" else "not_applicable"
        if (soft.state.contains("BLOCKED_NO_TOPIC", true) || target.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true)) {
            return emit(target, "SRP_MAPPING_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", emptyList(), emptyList(), emptyList(), eutils)
        }
        val text = report?.toString().orEmpty()
        val srp = (soft.sraAccessions.filter { it.startsWith("SRP") } + extract(text, Regex("\\bSRP\\d+\\b", RegexOption.IGNORE_CASE))).distinct()
        val runs = (soft.sraAccessions.filter { it.startsWith("SRR") } + extract(text, Regex("\\bSRR\\d+\\b", RegexOption.IGNORE_CASE))).distinct()
        val bio = (soft.bioProjectAccessions + extract(text, Regex("\\bPRJNA\\d+\\b", RegexOption.IGNORE_CASE))).distinct()
        val state = when {
            srp.size == 1 -> "SRP_MAPPING_FOUND"
            srp.size > 1 -> "SRP_MAPPING_AMBIGUOUS"
            target.startsWith("GSE", true) -> "SRP_MAPPING_LOOKUP_REQUIRED"
            else -> "SRP_MAPPING_NOT_APPLICABLE"
        }
        return emit(target, state, srp, runs, bio, eutils)
    }

    private fun emit(target: String, state: String, srp: List<String>, runs: List<String>, bio: List<String>, eutils: String): GTIMGseToSrpMappingReportV2950 {
        val line = "GSE→SRP mapping: version=$VERSION | state=$state | target=$target | srp=${srp.take(5).joinToString(",").ifBlank { "none" }} | sra_runs=${runs.take(5).joinToString(",").ifBlank { "none" }} | bioproject=${bio.take(5).joinToString(",").ifBlank { "none" }} | eutils_url=$eutils"
        return GTIMGseToSrpMappingReportV2950(
            active = true,
            targetId = target,
            state = state,
            srpAccessions = srp,
            sraRunAccessions = runs,
            bioProjectAccessions = bio,
            eutilsSearchUrl = eutils,
            line = GTIMMetadataFirstObservedEvidenceBridgeV2950.normalize(line),
            boundaryLine = "GSE→SRP boundary: mapping only; an SRP/SRA handle does not mean recount3 coverage, comparator validity, DGE readiness, or biological proof."
        )
    }

    private fun extract(text: String, regex: Regex): List<String> = regex.findAll(text).map { it.value.uppercase(Locale.US) }.toList()
}
