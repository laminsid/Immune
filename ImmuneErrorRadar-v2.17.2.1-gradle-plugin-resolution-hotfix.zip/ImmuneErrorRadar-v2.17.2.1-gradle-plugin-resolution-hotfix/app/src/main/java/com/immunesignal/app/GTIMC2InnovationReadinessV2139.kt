package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.9 — C2 innovation readiness layer.
 * This layer keeps C0/C1 permissive, but makes the next innovation step concrete:
 * executable replication matrix, evidence-lift gates, anomaly/surprise agenda, and
 * a final C2-readiness closure. It never claims validated biology or clinical value.
 */
object GTIMExecutableReplicationMatrixV2139 {
    const val VERSION: String = "2.13.9-executable-replication-matrix"
    const val CLAIM_LIMIT: String = "replication_matrix_is_execution_design_not_replicated_result"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val target = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val score = report.optJSONObject("moduleScorePlaceholderEngineV2138") ?: GTIMModuleScorePlaceholderEngineV2138.toJson(report)
        val repl = report.optJSONObject("c2AutoReplicationEngineV2137") ?: GTIMC2AutoReplicationEngineV2137.toJson(report)
        val moduleRows = score.optJSONArray("moduleScoreRows") ?: JSONArray()
        val replicationCandidates = repl.optJSONArray("replicationCandidates") ?: JSONArray()
        val executionRows = JSONArray()
        for (i in 0 until moduleRows.length()) {
            val row = moduleRows.optJSONObject(i) ?: continue
            val moduleId = row.optString("moduleId", "module_$i")
            executionRows.put(JSONObject()
                .put("moduleId", moduleId)
                .put("primaryTarget", target.ifBlank { "topic_compatible_target_required" })
                .put("primaryExecution", "compute_module_score_direction_effect_size_FDR")
                .put("replicationExecution", if (replicationCandidates.length() > 0) "run_same_module_on_second_same_domain_dataset" else "find_second_same_domain_dataset_first")
                .put("negativeControlExecution", negativeControl(domain))
                .put("contradictionExecution", contradiction(domain))
                .put("promotionRequirement", "same_direction_plus_effect_size_visible_plus_FDR_or_equivalent_quality_plus_negative_control_resistance"))
        }
        val state = when {
            target.isBlank() -> "REPLICATION_MATRIX_NEEDS_CANONICAL_TARGET"
            executionRows.length() == 0 -> "REPLICATION_MATRIX_NEEDS_MODULE_ROWS"
            replicationCandidates.length() == 0 -> "REPLICATION_MATRIX_C1_READY_NEEDS_REPLICATION_DATASET"
            else -> "REPLICATION_MATRIX_READY_FOR_C2_EXECUTION"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("activeDomain", domain)
            .put("canonicalTarget", target)
            .put("replicationCandidates", replicationCandidates)
            .put("executionRows", executionRows)
            .put("c2PromotionBlocked", true)
            .put("experimentalC2PreviewAllowed", true)
            .put("proofPromotionBlocked", true)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Executable replication matrix",
        "State: ${obj.optString("state", "UNKNOWN")}; target=${obj.optString("canonicalTarget", "none")}; modules=${obj.optJSONArray("executionRows")?.length() ?: 0}; replication_candidates=${obj.optJSONArray("replicationCandidates")?.length() ?: 0}.",
        "C2 requirement: same module direction + visible effect size/FDR quality + negative-control resistance + contradiction review.",
        "Boundary: replication matrix is an execution design, not a replicated result."
    )

    private fun negativeControl(domain: String): String = when {
        domain.contains("depression") -> "test_non_inflammatory_depression_or_wrong_brain_region"
        domain.contains("allergy") -> "test_barrier_only_context_without_type2_IgE_eosinophil_readout"
        domain.contains("filovirus") -> "test_non_filovirus_viral_dataset_or_survival_label_absent_context"
        domain.contains("viral") -> "test_acute_only_dataset_without_recovery_persistence_labels"
        domain.contains("metabolic") -> "test_generic_inflammation_without_glucose_insulin_context"
        else -> "test_wrong_tissue_or_unrelated_comparator"
    }

    private fun contradiction(domain: String): String = when {
        domain.contains("depression") -> "run_same_modules_against_dataset_expected_to_show_generic_inflammation_without_kynurenine_specificity"
        domain.contains("allergy") -> "run_same_modules_against_non_type2_or_non_allergic_inflammation_context"
        domain.contains("filovirus") -> "run_same_modules_against_non_filovirus_viral_host_response_context"
        domain.contains("viral") -> "run_same_modules_against_recovered_or_mild_only_dataset"
        domain.contains("metabolic") -> "run_same_modules_against_non_metabolic_inflammatory_dataset"
        else -> "run_same_modules_against_domain_mismatch_dataset"
    }
}

object GTIMEvidenceLiftGateV2139 {
    const val VERSION: String = "2.13.9-evidence-lift-gate"
    const val CLAIM_LIMIT: String = "evidence_lift_gate_controls_labels_not_scientific_truth"

    fun toJson(report: JSONObject): JSONObject {
        val ladder = report.optJSONObject("discoveryClaimLadderV2135") ?: JSONObject()
        val matrix = report.optJSONObject("executableReplicationMatrixV2139") ?: GTIMExecutableReplicationMatrixV2139.toJson(report)
        val score = report.optJSONObject("moduleScorePlaceholderEngineV2138") ?: JSONObject()
        val target = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val moduleRows = score.optJSONArray("moduleScoreRows")?.length() ?: 0
        val replicationRows = matrix.optJSONArray("replicationCandidates")?.length() ?: 0
        val blockers = JSONArray()
        if (target.isBlank()) blockers.put("canonical_target_missing")
        if (moduleRows == 0) blockers.put("module_scores_not_executed") else blockers.put("module_scores_are_placeholders_not_results")
        if (replicationRows == 0) blockers.put("replication_dataset_missing") else blockers.put("replication_not_executed")
        blockers.put("negative_control_not_executed")
        blockers.put("contradiction_execution_not_executed")
        val current = ladder.optString("level").ifBlank { report.optJSONObject("discoverySynthesisCardV2137")?.optString("innovationLevel") ?: "C0_ROUTE_ONLY" }
        val next = when {
            target.isBlank() -> "C0_ROUTE_ONLY"
            current.contains("C1") -> "C1_READY_FOR_C2_EXECUTION"
            moduleRows > 0 -> "C1_DISCOVERY_CANDIDATE_ALLOWED"
            else -> "C0_ROUTE_ONLY"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "EVIDENCE_LIFT_GATE_READY")
            .put("currentLevel", current)
            .put("allowedOutputLevel", next)
            .put("c2Blocked", false)
            .put("c2Blockers", blockers)
            .put("relaxedStrictness", "C0_C1_C2_C3_experimental_hypothesis_generation_allowed_even_when_replication_is_missing")
            .put("hardBoundary", "C2_C3_medical_therapeutic_vaccine_efficacy_preview_allowed_in_experimental_mode_not_patient_action")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Evidence lift gate",
        "State: ${obj.optString("state", "UNKNOWN")}; allowed=${obj.optString("allowedOutputLevel", "C0")}; C2_preview_allowed=${!obj.optBoolean("c2Blocked", false)}; blockers=${obj.optJSONArray("c2Blockers")?.length() ?: 0}.",
        "Relaxed strictness: ${obj.optString("relaxedStrictness", "C0/C1 allowed")}",
        "Boundary: C2/C3 and medical/therapeutic/vaccine/efficacy language may be emitted as experimental sandbox preview only; no patient action, dosing, clinical implementation, or validated proof."
    )
}

object GTIMAnomalyToInnovationBacklogV2139 {
    const val VERSION: String = "2.13.9-anomaly-to-innovation-backlog"
    const val CLAIM_LIMIT: String = "innovation_backlog_is_prioritized_research_work_not_discovery_proof"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val surprise = report.optJSONObject("signalSurpriseEngineV2137") ?: GTIMSignalSurpriseEngineV2137.toJson(report)
        val competition = report.optJSONObject("mechanismCompetitionArenaV2137") ?: GTIMMechanismCompetitionArenaV2137.toJson(report)
        val matrix = report.optJSONObject("executableReplicationMatrixV2139") ?: GTIMExecutableReplicationMatrixV2139.toJson(report)
        val items = JSONArray()
        items.put(JSONObject()
            .put("priority", "P0")
            .put("work", "execute_primary_module_scores")
            .put("why", "turn module candidates into direction/effect/FDR-bearing signals"))
        items.put(JSONObject()
            .put("priority", "P1")
            .put("work", "test_surprise_or_missing_expected_signal")
            .put("why", surprise.optString("surpriseType", "surprise_or_absence_can_generate_non_obvious_claim")))
        items.put(JSONObject()
            .put("priority", "P2")
            .put("work", "make_competing_mechanisms_fight")
            .put("why", competition.optString("topRisk", "artifact_vs_specific_mechanism_must_be_resolved")))
        items.put(JSONObject()
            .put("priority", "P3")
            .put("work", "run_replication_matrix")
            .put("why", matrix.optString("state", "replication_required")))
        val state = if ((matrix.optJSONArray("executionRows")?.length() ?: 0) > 0) "INNOVATION_BACKLOG_EXECUTABLE" else "INNOVATION_BACKLOG_NEEDS_TARGET_OR_MODULES"
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("activeDomain", domain)
            .put("backlog", items)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Anomaly → Innovation backlog",
        "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; items=${obj.optJSONArray("backlog")?.length() ?: 0}.",
        "Top work: ${obj.optJSONArray("backlog")?.optJSONObject(0)?.optString("work") ?: "none"}",
        "Boundary: backlog prioritizes discovery work; it is not proof."
    )
}

object GTIMFinalC2InnovationReadinessClosureV2139 {
    const val VERSION: String = "2.13.9-final-c2-innovation-readiness"
    const val CLAIM_LIMIT: String = "final_c2_readiness_candidate_only_no_validated_scientific_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val target = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val stale = report.optJSONObject("staleSurfaceZeroExportGuardV2138") ?: GTIMStaleSurfaceZeroExportGuardV2138.toJson(report)
        val matrix = report.optJSONObject("executableReplicationMatrixV2139") ?: GTIMExecutableReplicationMatrixV2139.toJson(report)
        val lift = report.optJSONObject("evidenceLiftGateV2139") ?: GTIMEvidenceLiftGateV2139.toJson(report)
        val backlog = report.optJSONObject("anomalyToInnovationBacklogV2139") ?: GTIMAnomalyToInnovationBacklogV2139.toJson(report)
        val hasTarget = target.isNotBlank()
        val hasRows = (matrix.optJSONArray("executionRows")?.length() ?: 0) > 0
        val staleClean = stale.optInt("staleSurfaceItems", 0) == 0 || stale.optString("state").contains("READY")
        val state = when {
            hasTarget && hasRows && staleClean -> "FINAL_C2_INNOVATION_READINESS_READY_C2_BLOCKED_UNTIL_EXECUTION"
            hasTarget && hasRows -> "FINAL_C2_INNOVATION_READINESS_REVIEW_SURFACE"
            hasTarget -> "FINAL_C2_INNOVATION_READINESS_NEEDS_MODULE_ROWS"
            else -> "FINAL_C2_INNOVATION_READINESS_NEEDS_CANONICAL_TARGET"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("canonicalTarget", target)
            .put("allowedOutputLevel", lift.optString("allowedOutputLevel"))
            .put("replicationMatrixState", matrix.optString("state"))
            .put("innovationBacklogState", backlog.optString("state"))
            .put("staleSurfaceItems", stale.optInt("staleSurfaceItems", 0))
            .put("strictnessPolicy", "C0_C1_C2_C3_and_medical_therapeutic_vaccine_efficacy_preview_relaxed_for_testing")
            .put("routeLinkage", "legacy rails -> canonical final surface -> v2.13.7 innovation synthesis -> v2.13.8 execution bridge -> v2.13.9 executable replication matrix + evidence lift gate + innovation backlog -> final locks")
            .put("claimPromotionAllowed", true)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final C2 innovation-readiness closure",
        "State: ${obj.optString("state", "UNKNOWN")}; target=${obj.optString("canonicalTarget", "none")}; allowed=${obj.optString("allowedOutputLevel", "C0")}; stale=${obj.optInt("staleSurfaceItems", -1)}.",
        "Replication matrix: ${obj.optString("replicationMatrixState", "unknown")}; backlog=${obj.optString("innovationBacklogState", "unknown")}",
        "Strictness: ${obj.optString("strictnessPolicy", "C1 relaxed; C2+ strict")}",
        "Boundary: this prepares C2 execution; it does not validate scientific, clinical, treatment, dosing, vaccine, or efficacy claims."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FINAL_C2_INNOVATION_READINESS_READY_C2_BLOCKED_UNTIL_EXECUTION", "EVIDENCE_LIFT_GATE_READY", "REPLICATION_MATRIX_READY_FOR_C2_EXECUTION", CLAIM_LIMIT))
}
