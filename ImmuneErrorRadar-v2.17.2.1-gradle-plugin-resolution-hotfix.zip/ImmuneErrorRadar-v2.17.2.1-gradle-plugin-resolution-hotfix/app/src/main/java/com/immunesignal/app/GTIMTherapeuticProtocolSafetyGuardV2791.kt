package com.immunesignal.app

/**
 * v2.7.9.1 — Therapeutic Protocol Safety Guard.
 *
 * Centralizes the hard safety boundary for therapeutic reverse-translation. This guard
 * is intentionally display/routing-only: it never changes ETL, DGE, treatment, routing,
 * or evidence-upgrade decisions. Its purpose is to keep every therapeutic protocol line
 * pinned to the v2.7.8.x ETL spine and to prevent therapeutic reasoning from being read
 * as clinical advice, dosing, pathogen/vaccine engineering, efficacy, or DGE closure.
 */
data class GTIMTherapeuticProtocolSafetyReportV2791(
    val active: Boolean,
    val state: String,
    val etlDependencyLine: String,
    val stopRulesLine: String,
    val claimLockLine: String
) {
    companion object {
        fun empty(): GTIMTherapeuticProtocolSafetyReportV2791 = GTIMTherapeuticProtocolSafetyReportV2791(
            active = false,
            state = "NOT_EVALUATED",
            etlDependencyLine = "Therapeutic safety gate: not evaluated.",
            stopRulesLine = "Therapeutic safety stops: not evaluated.",
            claimLockLine = "Therapeutic claim lock: research protocol routing only."
        )
    }
}

object GTIMTherapeuticProtocolSafetyGuardV2791 {
    const val VERSION: String = "2.7.9.1-therapeutic-protocol-safety-guard"
    private const val LEGACY_AUDIT_TOKEN_NO_CLINICAL_MANAGEMENT: String = "no clinical management"

    fun evaluate(
        report: GTIMTherapeuticReverseTranslationReportV2790,
        finalEtl: GTIMFinalEtlExecutionUnifierReportV2782
    ): GTIMTherapeuticProtocolSafetyReportV2791 {
        if (!report.active) return GTIMTherapeuticProtocolSafetyReportV2791.empty()

        val hasTopicTarget = !finalEtl.state.contains("NO_TOPIC_COMPATIBLE", ignoreCase = true) &&
            !finalEtl.finalDecision.contains("SELECT_TOPIC_COMPATIBLE", ignoreCase = true)
        val state = when {
            !hasTopicTarget -> "THERAPEUTIC_PROTOCOL_BLOCKED_UNTIL_TOPIC_COMPATIBLE_TARGET"
            finalEtl.finalDecision.contains("FILE_DISCOVERY", ignoreCase = true) -> "THERAPEUTIC_PROTOCOL_WAITING_FOR_FILE_DISCOVERY"
            finalEtl.finalDecision.contains("METADATA", ignoreCase = true) -> "THERAPEUTIC_PROTOCOL_WAITING_FOR_METADATA_NORMALIZATION"
            finalEtl.finalDecision.contains("COMPARATOR", ignoreCase = true) -> "THERAPEUTIC_PROTOCOL_WAITING_FOR_COMPARATOR_EVIDENCE"
            finalEtl.finalDecision.contains("SAMPLE", ignoreCase = true) || finalEtl.finalDecision.contains("LINKAGE", ignoreCase = true) -> "THERAPEUTIC_PROTOCOL_WAITING_FOR_SAMPLE_ID_LINKAGE"
            finalEtl.finalDecision.contains("DGE", ignoreCase = true) -> "THERAPEUTIC_PROTOCOL_ROUTED_TO_REVIEW_ONLY_DGE_GATE"
            else -> "THERAPEUTIC_PROTOCOL_RESEARCH_ONLY_REVIEW"
        }

        val etlDependency = normalize(
            "Therapeutic safety gate: version=$VERSION | state=$state | etl_dependency=v2.7.8.2_final_etl_execution_unification | therapeutic_reasoning_cannot_open_dge_or_file_probe_without_etl_gate=true"
        )
        val stopRules = normalize(
            "Therapeutic safety stops: no treatment advice; no dosing; no patient-care instruction; no vaccine/pathogen engineering; no efficacy claim; no DGE_READY from therapeutic reasoning alone; no LLM label as final truth."
        )
        val claimLock = normalize(
            "Therapeutic claim lock: lane=${report.laneId} | output=structured research protocol and dataset requirement only | final_etl_decision=${finalEtl.finalDecision}"
        )

        return GTIMTherapeuticProtocolSafetyReportV2791(
            active = true,
            state = state,
            etlDependencyLine = etlDependency,
            stopRulesLine = stopRules,
            claimLockLine = claimLock
        )
    }

    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
