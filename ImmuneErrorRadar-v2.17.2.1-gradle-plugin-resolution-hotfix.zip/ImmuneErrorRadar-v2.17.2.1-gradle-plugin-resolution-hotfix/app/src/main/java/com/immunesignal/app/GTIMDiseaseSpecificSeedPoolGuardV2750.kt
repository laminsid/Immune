package com.immunesignal.app

/**
 * v2.7.5.0 — Disease-specific active seed pool guard.
 *
 * Retrieval can keep broad/background handles internally, but the visible active
 * queue and matrix-audit fallback handles must be compatible with the active
 * contract. Incompatible handles are not deleted; they are just not displayed as
 * active evidence/lookup handles for this run.
 */
data class GTIMSeedPoolGuardReportV2750(
    val activeHandles: List<String>,
    val rejectedBackgroundHandles: List<String>,
    val summaryLine: String
)

object GTIMDiseaseSpecificSeedPoolGuardV2750 {
    const val VERSION: String = "2.7.5.0-disease-specific-seed-pool-guard+2.9.0-target-recall-aware"

    private val knownTopicSeedHints: Map<String, String> = mapOf(
        // v2.11.3.3: GSE117882 is a broad gut/metabolic-neuroimmune public-data lead used in
        // diabetes/metabolic soft-learning tests. Keep it as a soft route only; it still cannot
        // upgrade evidence without ETL/DGE gates.
        "GSE117882" to "diabetes_metabolic_immune_axis",
        "GSE250594" to "allergy_type2_ige_mast_eosinophil",
        "GSE152202" to "covid_interferon_cytokine_bridge",
        "GSE166552" to "covid_interferon_cytokine_bridge",
        "GSE152418" to "covid_interferon_cytokine_bridge",
        "GSE157103" to "covid_interferon_cytokine_bridge",
        "GSE93798" to "ebola_hemorrhagic_viral_host_response",
        "GSE72056" to "ebola_hemorrhagic_viral_host_response",
        "GSE131907" to "ebola_hemorrhagic_viral_host_response",
        "GSE25628" to "ebola_hemorrhagic_viral_host_response"
    )

    fun filterActiveHandles(handles: List<String>, contract: GTIMRunDecisionContractV2740): GTIMSeedPoolGuardReportV2750 {
        val canonicalHandles = handles.mapNotNull { canonicalHandle(it) }.distinct()
        val active = mutableListOf<String>()
        val rejected = mutableListOf<String>()
        canonicalHandles.forEach { handle ->
            val hintedRoute = knownTopicSeedHints[handle]
            val allowed = when {
                hintedRoute != null -> isTopicRouteCompatible(hintedRoute, contract)
                handle.startsWith("PMID:", true) || handle.all { it.isDigit() } -> false
                contract.runMode == GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION && contract.primaryAnchor == GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY -> true
                else -> false
            }
            if (allowed) active += handle else rejected += handle
        }
        val summary = "Seed pool guard: active=${active.size} | rejected_background=${rejected.size} | anchor=${contract.primaryAnchor.routeId}"
        return GTIMSeedPoolGuardReportV2750(active.take(12), rejected.take(12), summary)
    }

    fun isTopicRouteCompatible(routeId: String, contract: GTIMRunDecisionContractV2740): Boolean {
        val canonical = GTIMCanonicalRouteIdentityV2748.canonicalize(routeId)
        return canonical == contract.primaryAnchor.routeId ||
            canonical in contract.discoveryBridges.map { it.routeId }.toSet() ||
            canonical in contract.exploratoryRoutes
    }

    private fun canonicalHandle(raw: String): String? {
        val text = raw.trim()
        if (text.isBlank()) return null
        val regex = Regex("(?i)\\b(GSE\\d+|GDS\\d+|PRJNA\\d+|SRP\\d+|SRR\\d+|E-MTAB-\\d+|SDY\\d+|PMID:\\d+|\\d{7,9}|DOI:[A-Za-z0-9./_:-]+)\\b")
        val match = regex.find(text)?.value ?: return null
        return if (match.all { it.isDigit() }) "PMID:$match" else match.trim().takeWhile { ch -> ch.isLetterOrDigit() || ch == ':' || ch == '-' || ch == '_' || ch == '.' }
    }
}
