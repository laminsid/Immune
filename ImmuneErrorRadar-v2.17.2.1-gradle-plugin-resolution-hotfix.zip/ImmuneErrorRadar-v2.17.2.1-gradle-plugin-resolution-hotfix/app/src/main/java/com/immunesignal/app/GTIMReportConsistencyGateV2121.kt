package com.immunesignal.app

// audit_guard_phrase: no administration; no evidence upgrade

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

// v2.12.1 — Report Consistency Gate.
// Separates an accepted topic-compatible target from a candidate lookup handle so the
// public report never says Target is accepted when ETL/DGE gates explicitly blocked it.
object GTIMReportConsistencyGateV2121 {
    const val VERSION: String = "2.12.1-report-consistency-target-handle-gate"
    const val CLAIM_LIMIT: String = "display_consistency_only_no_evidence_upgrade"

    data class TargetConsistency(
        val acceptedTarget: String,
        val candidateLookupHandle: String,
        val targetState: String,
        val candidateAccessionsFound: Int,
        val topicCompatibleTargetSelected: Boolean,
        val verifiedMatrixFiles: Int,
        val line: String
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): TargetConsistency {
        val joined = (technicalLines.joinToString(" ") + " " + report.toString()).take(12000)
        val candidates = extractCandidates(joined)
        val noTopicCompatibleTarget = joined.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true) ||
            joined.contains("DGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", true) ||
            joined.contains("FINAL_ETL_STOP_NO_TOPIC_COMPATIBLE_TARGET", true) ||
            joined.contains("P0_TOPIC_COMPATIBLE_TARGET", true)
        val observedFileStop = joined.contains("OBSERVED_FILE_EVIDENCE", true) || joined.contains("TARGET_FOUND_FILE_MISSING", true)
        val accepted = if (!noTopicCompatibleTarget) candidates.firstOrNull().orEmpty() else ""
        val candidate = candidates.firstOrNull().orEmpty()
        val verifiedMatrixFiles = countVerifiedMatrixSignals(joined)
        val state = when {
            accepted.isNotBlank() && observedFileStop -> "TARGET_ACCEPTED_FILE_EVIDENCE_MISSING"
            accepted.isNotBlank() -> "TARGET_ACCEPTED_TOPIC_COMPATIBLE"
            candidate.isNotBlank() -> "CANDIDATE_LOOKUP_HANDLE_NOT_ACCEPTED_AS_TARGET"
            else -> "NO_TARGET_OR_LOOKUP_HANDLE_YET"
        }
        val line = "Report consistency gate: version=$VERSION | state=$state | acceptedTarget=${accepted.ifBlank { "NONE" }} | candidateLookupHandle=${candidate.ifBlank { "NONE" }} | candidateHandles=${candidates.joinToString(",").ifBlank { "NONE" }} | candidateAccessionsFound=${candidates.size} | topicCompatibleTargetSelected=${accepted.isNotBlank()} | verifiedCapsuleSourceCount=$verifiedMatrixFiles | verifiedMatrixFiles=$verifiedMatrixFiles | claim_limit=$CLAIM_LIMIT"
        return TargetConsistency(accepted, candidate, state, candidates.size, accepted.isNotBlank(), verifiedMatrixFiles, line)
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val c = build(report, technicalLines)
        val ledger = report.optJSONObject("candidateHandleLedgerV21215")
        val selected = ledger?.optString("selectedReviewTarget").orEmpty().ifBlank { c.candidateLookupHandle }
        val candidateCount = ledger?.optInt("candidateHandleCount", c.candidateAccessionsFound) ?: c.candidateAccessionsFound
        val verifiedCount = ledger?.optInt("verifiedCapsuleSourceCount", c.verifiedMatrixFiles) ?: c.verifiedMatrixFiles
        val lines = mutableListOf<String>()
        lines += when {
            c.topicCompatibleTargetSelected -> "Target: ${c.acceptedTarget} — accepted as topic-compatible for the current route."
            selected.isNotBlank() -> "External review target selected — not evidence yet: candidate lookup handle $selected needs topic-fit, comparator, sample-linkage, and matrix/capsule validation."
            else -> "Target: not selected yet — discover or feed a topic-compatible accession before ETL/DGE."
        }
        if (!c.topicCompatibleTargetSelected && selected.isNotBlank()) {
            lines += "Candidate lookup handle: $selected — useful for External Router search only, not an internal DGE target."
        }
        lines += "Evidence counters: candidate_handles=$candidateCount; verified_capsule_source_count=$verifiedCount; topicCompatibleTargetSelected=${c.topicCompatibleTargetSelected}."
        lines += "Display boundary: candidate handles help lookup; they do not upgrade evidence or prove a gene/pathway signal."
        return lines
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val c = build(report, technicalLines)
        return JSONObject()
            .put("version", VERSION)
            .put("claimLimit", CLAIM_LIMIT)
            .put("state", c.targetState)
            .put("acceptedTarget", c.acceptedTarget)
            .put("candidateLookupHandle", c.candidateLookupHandle)
            .put("candidateHandles", JSONArray(if (c.candidateLookupHandle.isNotBlank()) listOf(c.candidateLookupHandle) else emptyList<String>()))
            .put("candidateAccessionsFound", c.candidateAccessionsFound)
            .put("candidateHandleCount", c.candidateAccessionsFound)
            .put("topicCompatibleTargetSelected", c.topicCompatibleTargetSelected)
            .put("verifiedMatrixFiles", c.verifiedMatrixFiles)
            .put("verifiedCapsuleSourceCount", c.verifiedMatrixFiles)
            .put("externalReviewTargetStatus", if (c.candidateLookupHandle.isNotBlank() && !c.topicCompatibleTargetSelected) "External review target selected — not evidence yet" else c.targetState)
            .put("line", c.line)
    }

    private fun extractCandidates(text: String): List<String> {
        val values = mutableListOf<String>()
        Regex("target=([A-Za-z0-9_.:-]+)").findAll(text).forEach { match ->
            val value = match.groupValues[1]
            if (looksLikeDatasetHandle(value)) values += value
        }
        Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|SRR\\d+|PRJNA\\d+|PRJEB\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+)\\b", RegexOption.IGNORE_CASE)
            .findAll(text).forEach { values += it.value }
        return values.map { it.trim().uppercase(Locale.US) }
            .filter { looksLikeDatasetHandle(it) }
            .distinct()
    }

    private fun looksLikeDatasetHandle(value: String): Boolean {
        val v = value.trim().uppercase(Locale.US)
        if (v.isBlank()) return false
        if (v in invalidHandleTokens) return false
        if (v.startsWith("PMID")) return false
        return Regex("^(GSE|GDS|GSM|SRP|SRR|SRS|SRX|PRJNA|PRJEB|SDY|E-MTAB)[A-Z0-9_.-]*\\d+$", RegexOption.IGNORE_CASE).matches(v)
    }

    private val invalidHandleTokens: Set<String> = setOf(
        "NO_TOPIC_COMPAT",
        "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED",
        "BLOCKED",
        "UNKNOWN",
        "NONE",
        "NULL",
        "TARGET",
        "NO_TARGET"
    )

    private fun countVerifiedMatrixSignals(text: String): Int {
        val lower = text.lowercase(Locale.US)
        if (lower.contains("matrix_not_verified") || lower.contains("file_missing") || lower.contains("matrix_unresolved")) return 0
        return listOf("matrix file verified", "observed matrix", "raw/count matrix verified", "dge_ready").count { lower.contains(it) }
    }
}
