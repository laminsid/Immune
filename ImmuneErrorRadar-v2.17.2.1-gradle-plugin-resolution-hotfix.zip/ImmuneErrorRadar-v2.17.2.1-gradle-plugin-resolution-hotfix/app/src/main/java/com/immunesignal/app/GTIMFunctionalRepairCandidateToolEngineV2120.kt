package com.immunesignal.app

// v2.12.0 — Maps dysfunction models to function-first biological tool candidates.
// It never names a use protocol and never upgrades a candidate to therapy.
object GTIMFunctionalRepairCandidateToolEngineV2120 {
    const val VERSION: String = "2.12.0-functional-repair-candidate-tool-engine"
    const val CLAIM_LIMIT: String = "research_candidate_only_no_administration_route_no_clinical_use_no_engineering_protocol"

    fun build(model: GTIMFunctionalDysfunctionModelV2120, topic: String, target: String): List<GTIMFunctionalRepairFunctionV2120> {
        val routes = mutableListOf<GTIMFunctionalRepairFunctionV2120>()
        when (model.modelId) {
            "barrier_type2_tolerance_failure_model" -> {
                routes += function("barrier_support_commensal_or_postbiotic", "restore epithelial/barrier support and reduce type-2 threshold instability", "natural_commensal_or_postbiotic_barrier_route", "barrier-support microbial metabolites or postbiotic signals may reduce inflammatory amplification", "L2_PLAUSIBLE_FUNCTION_ROUTE_UNVALIDATED")
                routes += function("immune_tolerance_metabolite_route", "recalibrate immune tolerance thresholds without broad suppression", "metabolite_producing_or_consortium_tolerance_route", "short-chain-fatty-acid/tolerance-associated functions may be screened as mechanism candidates", "L2_PLAUSIBLE_FUNCTION_ROUTE_UNVALIDATED")
            }
            "microbiome_metabolite_neuroimmune_model" -> {
                routes += function("tryptophan_kynurenine_modulation_route", "restore metabolite balance around tryptophan/kynurenine and inflammatory tone", "metabolite_modulating_microbiome_function_route", "microbial functions may influence metabolite availability and cytokine context", "L2_PLAUSIBLE_FUNCTION_ROUTE_UNVALIDATED")
                routes += function("anti_inflammatory_barrier_metabolite_route", "reduce low-grade inflammatory amplification through barrier/metabolite context", "postbiotic_or_commensal_context_route", "candidate functions are screened for host-response direction, not species-name association", "L2_PLAUSIBLE_FUNCTION_ROUTE_UNVALIDATED")
            }
            "interferon_timing_cytokine_amplification_model" -> {
                routes += function("mucosal_resilience_support_route", "support mucosal resilience and reduce amplification context after viral trigger", "barrier_mucosal_microbiome_context_route", "local microbial/barrier context may modify cytokine thresholds and recovery context", "L1_SPECULATIVE_TO_L2_CONTEXT_ROUTE")
                routes += function("cytokine_resolution_context_route", "identify ecological or metabolite context associated with inflammatory resolution", "metabolite_or_postbiotic_resolution_route", "route requires human cohort evidence and cannot imply antiviral efficacy", "L1_SPECULATIVE_TO_L2_CONTEXT_ROUTE")
            }
            "metabolic_inflammation_energy_context_model" -> {
                routes += function("immune_energy_metabolite_route", "restore immune-energy context and reduce low-grade inflammatory loop", "metabolite_restoration_or_postbiotic_route", "microbial metabolite function may be studied as a context modifier of immune-energy state", "L2_PLAUSIBLE_FUNCTION_ROUTE_UNVALIDATED")
                routes += function("barrier_endotoxin_pressure_route", "test whether barrier/endotoxin pressure sustains metabolic inflammation", "barrier_support_commensal_or_postbiotic_route", "candidate function requires endotoxin/barrier markers and metabolic comparator", "L2_PLAUSIBLE_FUNCTION_ROUTE_UNVALIDATED")
            }
            "exposure_barrier_bioremediation_model" -> {
                routes += function("particle_binding_or_sequestration_screen", "screen microbial or postbiotic functions for binding/sequestration of exposure pressure", "bioremediation_or_binding_function_research_route", "function could be researched for binding, transformation, or reduced bioavailability under containment", "L1_SPECULATIVE_BIOSAFETY_HEAVY")
                routes += function("barrier_protection_under_exposure_route", "buffer barrier and inflammatory response under environmental exposure", "barrier_support_ecological_resilience_route", "route focuses on host barrier markers, not detox claims", "L1_SPECULATIVE_BIOSAFETY_HEAVY")
            }
            "immune_tolerance_error_model" -> {
                routes += function("tolerance_retraining_context_route", "restore immune tolerance/resolution signaling as a research function", "immune_tolerance_consortium_or_metabolite_route", "candidate function must move tolerance markers without worsening inflammation", "L1_SPECULATIVE_TO_L2_CONTEXT_ROUTE")
            }
            else -> {
                routes += function("open_counter_function_scan", "identify the missing biological function before selecting any candidate tool", "open_function_first_microbiome_or_postbiotic_route", "no organism/tool should be nominated until dysfunction markers are discriminated", "L0_OPEN_HYPOTHESIS")
            }
        }
        return routes.distinctBy { it.functionId }.take(4)
    }

    private fun function(id: String, repair: String, toolClass: String, mechanism: String, rank: String): GTIMFunctionalRepairFunctionV2120 {
        val missing = listOf(
            "topic-compatible dataset or external evidence capsule",
            "same-context comparator and negative-control route",
            "function-level evidence beyond species-name association",
            "biomarker directionality and source-to-sample provenance",
            "independent contradiction check"
        )
        val boundaries = listOf(
            "no DIY use",
            "no administration route",
            "no wet-lab or organism-engineering instructions",
            "biosafety and containment review required before translational interpretation",
            "not a diagnosis, treatment, efficacy, or patient prediction claim"
        )
        val line = "Functional repair candidate: version=$VERSION | id=$id | repair_function=${repair.oneLine()} | tool_class=$toolClass | plausible_mechanism=${mechanism.oneLine()} | evidence_level=$rank | missing=${missing.joinToString(";").oneLine()} | biosafety=${boundaries.joinToString(";").oneLine()} | claim_limit=$CLAIM_LIMIT"
        return GTIMFunctionalRepairFunctionV2120(id, repair, toolClass, mechanism, rank, missing, boundaries, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
