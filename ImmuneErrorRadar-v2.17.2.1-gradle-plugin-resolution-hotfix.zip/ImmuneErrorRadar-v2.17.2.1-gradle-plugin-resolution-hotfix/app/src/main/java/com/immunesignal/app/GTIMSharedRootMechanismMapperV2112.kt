package com.immunesignal.app

// v2.11.2 — Finds shared root mechanisms across disease families that share symptoms.
object GTIMSharedRootMechanismMapperV2112 {
    const val VERSION: String = "2.11.2-shared-root-mechanism-mapper"

    fun map(nodes: List<GTIMDysfunctionHypothesisNodeV2112>): List<String> {
        val mechanisms = mutableListOf<String>()
        if (nodes.any { it.nodeId == "IMMUNE_DECISION_ERROR" } && nodes.any { it.nodeId == "BARRIER_FAILURE_NODE" }) mechanisms += "shared_root=barrier_failure_can_feed_immune_overactivation"
        if (nodes.any { it.nodeId == "MICROBIAL_ECOLOGY_NODE" } && nodes.any { it.nodeId == "IMMUNE_DECISION_ERROR" }) mechanisms += "shared_root=microbial_metabolite_shift_can_change_immune_thresholds"
        if (nodes.any { it.nodeId == "EXPOSOME_PRESSURE_NODE" } && nodes.any { it.nodeId == "BARRIER_FAILURE_NODE" }) mechanisms += "shared_root=exposome_pressure_can_damage_barrier_and_amplify_inflammation"
        if (nodes.any { it.nodeId == "IMMUNOMETABOLIC_STRESS_NODE" } && nodes.any { it.nodeId == "IMMUNE_DECISION_ERROR" }) mechanisms += "shared_root=immune_energy_context_can_shape_cytokine_durability"
        if (mechanisms.isEmpty()) mechanisms += "shared_root=open_overlap_requires_discriminating_biomarkers_before_disease_naming"
        return mechanisms.distinct().take(6).map { "Shared root mechanism: version=$VERSION | $it | claim_limit=hypothesis_not_diagnosis" }
    }
}
