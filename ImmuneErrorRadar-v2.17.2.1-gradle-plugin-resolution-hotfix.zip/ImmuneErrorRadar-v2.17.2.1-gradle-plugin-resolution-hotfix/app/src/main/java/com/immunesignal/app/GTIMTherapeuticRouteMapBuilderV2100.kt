package com.immunesignal.app

// legacy_v2100_audit_marker: 2.10.0-medical-research-dossier

/** v2.10.0 — Research-only therapeutic route map. */
object GTIMTherapeuticRouteMapBuilderV2100 {
    const val VERSION: String = "2.10.0-therapeutic-route-map-builder"
    private val forbidden = listOf("no dosing", "no clinical management", "no patient-specific recommendation", "no efficacy claim", "no medication stopping advice")

    fun build(contract: GTIMRunDecisionContractV2740, mechanismMap: List<GTIMMechanismAxisCardV2100>): List<GTIMTherapeuticRouteCardV2100> {
        val anchor = (contract.primaryAnchor.routeId + " " + contract.rawQuery).lowercase()
        val routes = when {
            anchor.contains("cancer") -> cancerRoutes()
            anchor.contains("ibd") || anchor.contains("microbiome") || anchor.contains("mucosal") -> gutRoutes()
            anchor.contains("viral") || anchor.contains("covid") || anchor.contains("ebola") || anchor.contains("hantavirus") -> viralRoutes()
            anchor.contains("autoimmune") || anchor.contains("ra") || anchor.contains("sle") || anchor.contains("psoriasis") -> autoimmuneRoutes()
            anchor.contains("diabetes") || anchor.contains("metabolic") -> metabolicRoutes()
            else -> genericRoutes(mechanismMap)
        }
        return routes.take(8)
    }

    private fun cancerRoutes(): List<GTIMTherapeuticRouteCardV2100> = listOf(
        route("ROUTE_ONCO_CHECKPOINT", "immune checkpoint route", "Immune escape/checkpoint context may be relevant when validated tumor biomarkers and clinical context support it.", listOf("MSI-H/dMMR/TMB/MMR", "PD-1/PD-L1/CTLA-4 context", "tumor type", "clinical evidence source"), "A_TO_D_DEPENDS_ON_BIOMARKER_AND_CONTEXT", "ESTABLISHED_FOR_SELECTED_CONTEXTS_NOT_APP_VALIDATED"),
        route("ROUTE_ONCO_DNA_REPAIR", "DNA repair vulnerability route", "DNA damage/MMR/repair stress can define therapeutic vulnerability hypotheses but requires independent validation.", listOf("MMR/DNA repair biomarker", "tumor model", "response endpoint", "toxicity/safety context"), "B_TO_D_CONTEXT_DEPENDENT", "HYPOTHESIS_UNLESS_SOURCE_VALIDATED"),
        route("ROUTE_ONCO_CELL_CYCLE_APOPTOSIS", "cell-cycle/apoptosis route", "Cell-cycle blockade, mitotic stress and apoptosis induction can form a combination hypothesis; GTIM cannot infer efficacy.", listOf("cell-cycle marker", "apoptosis marker", "immune readout", "tested combination evidence"), "C_TO_E", "NOT_YET_TESTED_BY_GTIM_OR_AUTHORITY")
    )

    private fun gutRoutes(): List<GTIMTherapeuticRouteCardV2100> = listOf(
        route("ROUTE_GUT_DIET_MICROBIOME", "diet/microbiome modulation route", "Dietary or microbiome interventions may be explored only as disease-specific, time-bounded research routes with outcome evidence.", listOf("diet definition", "diagnosis/phenotype", "microbiome or inflammatory marker", "outcome", "nutrition-risk review"), "B_TO_D_CONTEXT_DEPENDENT", "RESEARCH_ROUTE_NOT_DIET_ADVICE"),
        route("ROUTE_GUT_CYTOKINE_BARRIER", "mucosal cytokine/barrier route", "Barrier and cytokine pathways can guide research hypotheses for gut inflammation.", listOf("tissue/sample", "cytokine/barrier marker", "case/control", "clinical endpoint"), "C_TO_D", "MECHANISTIC_HYPOTHESIS_ONLY")
    )

    private fun viralRoutes(): List<GTIMTherapeuticRouteCardV2100> = listOf(
        route("ROUTE_VIRAL_HOST_RESPONSE", "host-response route", "Interferon/cytokine host-response maps can guide research questions about immune response and tissue injury.", listOf("pathogen", "strain/timepoint", "sample tissue", "case/control", "countermeasure evidence"), "C_TO_D", "RESEARCH_ONLY_NOT_COUNTERMEASURE_ADVICE"),
        route("ROUTE_VIRAL_COUNTERMEASURE_REVIEW", "countermeasure evidence route", "Vaccines/antivirals/immune countermeasures require external clinical or public-health evidence; GTIM only routes the question.", listOf("countermeasure name", "endpoint", "trial/guideline source", "safety context"), "A_TO_E_DEPENDS_ON_SOURCE", "NO_EFFICACY_OR_PUBLIC_HEALTH_CLAIM")
    )

    private fun autoimmuneRoutes(): List<GTIMTherapeuticRouteCardV2100> = listOf(
        route("ROUTE_AUTOIMMUNE_CYTOKINE", "cytokine/immune-modulator route", "Cytokine and immune-cell axes can define class-level research routes when comparator and disease context are explicit.", listOf("disease phenotype", "cytokine/cell marker", "therapy class or target", "responder/non-responder metadata"), "B_TO_D_CONTEXT_DEPENDENT", "NO_TREATMENT_SELECTION"),
        route("ROUTE_AUTOIMMUNE_TOLERANCE", "immune tolerance/antigen route", "Tolerance and antigen-presentation hypotheses require strong disease-specific evidence.", listOf("antigen or autoantibody", "HLA/immune context", "tissue", "clinical endpoint"), "C_TO_E", "HYPOTHESIS_ONLY")
    )

    private fun metabolicRoutes(): List<GTIMTherapeuticRouteCardV2100> = listOf(
        route("ROUTE_METABOLIC_INFLAMMATION", "metabolic inflammation route", "Inflammatory and gut/metabolic routes may generate research hypotheses but cannot replace standard metabolic care.", listOf("phenotype", "metabolic marker", "inflammatory marker", "diet/medication context"), "C_TO_D", "NO_MEDICATION_OR_DIET_MANAGEMENT_ADVICE")
    )

    private fun genericRoutes(mechanismMap: List<GTIMMechanismAxisCardV2100>): List<GTIMTherapeuticRouteCardV2100> = listOf(
        route("ROUTE_GENERIC_THERAPEUTIC_HYPOTHESIS", "research-only therapeutic hypothesis route", "Mechanism axes may be translated into therapy-class hypotheses only after evidence source, comparator and validation status are explicit.", mechanismMap.flatMap { it.requiredEvidence }.distinct().take(6).ifEmpty { listOf("mechanism axis", "comparator", "evidence source") }, "D_TO_E", "DISCOVERY_ONLY_NOT_VALIDATED")
    )

    private fun route(id: String, cls: String, rationale: String, required: List<String>, level: String, status: String): GTIMTherapeuticRouteCardV2100 {
        val line = "Therapeutic route map: id=$id | class=$cls | evidence=$level | validation=$status | required=${required.joinToString(", ")} | limit=research-only; ${forbidden.joinToString(", ")}"
        return GTIMTherapeuticRouteCardV2100(id, cls, rationale, required, level, status, forbidden, line)
    }
}
