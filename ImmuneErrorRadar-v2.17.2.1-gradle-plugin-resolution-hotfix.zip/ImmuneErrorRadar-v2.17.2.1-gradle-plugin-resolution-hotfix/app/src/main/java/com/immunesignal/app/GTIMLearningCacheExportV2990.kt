package com.immunesignal.app

/**
 * v2.9.9 — Learning cache export contract.
 *
 * This prepares a small, local-first operational memory payload for later reuse.
 * It does not persist raw matrices, does not assert medical truth, and does not
 * convert external capsule summaries into internal DGE execution.
 */
data class GTIMLearningCacheExportReportV2990(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val cacheKey: String,
    val schemaVersion: String,
    val tables: List<String>,
    val reusable: Boolean,
    val blockers: List<String>,
    val line: String,
    val boundaryLine: String
)

object GTIMLearningCacheExportV2990 {
    const val VERSION: String = "2.9.9-learning-cache-export-contract"
    const val SCHEMA_VERSION: String = "gtim_learning_cache_v1"

    fun build(
        cache: GTIMLearningCacheReportV2980,
        requestPlan: GTIMPublicExpressionRequestPlanReportV2990,
        capsule: GTIMExternalEvidenceCapsuleImportReportV2980
    ): GTIMLearningCacheExportReportV2990 {
        val target = GTIMAccessionIdValidityGuardV2753.canonical(cache.targetId)
        val blockers = mutableListOf<String>()
        if (cache.state == "LEARNING_CACHE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET") blockers += "topic_compatible_target_required"
        if (cache.record.storedFields.isEmpty()) blockers += "no_cacheable_fields"
        if (requestPlan.state == "REQUEST_PLAN_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET") blockers += "request_plan_blocked"
        if (capsule.state.startsWith("CAPSULE_REJECTED")) blockers += "capsule_rejected_${capsule.blockers.firstOrNull().orEmpty()}"
        val tables = buildList {
            if (cache.record.storedFields.contains("soft_sample_rows")) add("gtim_soft_sample_rows")
            if (cache.record.storedFields.contains("soft_supplementary_refs")) add("gtim_soft_supplementary_refs")
            if (cache.record.storedFields.contains("gse_srp_mapping")) add("gtim_gse_srp_mapping")
            if (cache.record.storedFields.contains("public_expression_preferred_route")) add("gtim_public_expression_routes")
            if (capsule.topGenes.isNotEmpty()) add("gtim_capsule_top_genes")
            if (capsule.pathways.isNotEmpty()) add("gtim_capsule_pathways")
        }.distinct()
        val reusable = blockers.isEmpty() && cache.record.acceptedForReuse && tables.isNotEmpty()
        val state = when {
            blockers.contains("topic_compatible_target_required") -> "LEARNING_CACHE_EXPORT_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"
            blockers.isNotEmpty() && tables.isEmpty() -> "LEARNING_CACHE_EXPORT_BLOCKED_${blockers.first().uppercase()}"
            reusable -> "LEARNING_CACHE_EXPORT_READY_REVIEW_ONLY"
            tables.isNotEmpty() -> "LEARNING_CACHE_EXPORT_REVIEW_ONLY_LIMITED"
            else -> "LEARNING_CACHE_EXPORT_NOTHING_TO_WRITE"
        }
        val line = "Learning cache export: version=$VERSION | state=$state | target=$target | cache_key=${cache.record.queryKey} | schema=$SCHEMA_VERSION | reusable=$reusable | tables=${tables.ifEmpty { listOf("none") }.joinToString(",")} | blockers=${blockers.ifEmpty { listOf("none") }.joinToString(",")} | local_operational_memory_only=true"
        return GTIMLearningCacheExportReportV2990(
            active = true,
            targetId = target,
            state = state,
            cacheKey = cache.record.queryKey,
            schemaVersion = SCHEMA_VERSION,
            tables = tables,
            reusable = reusable,
            blockers = blockers,
            line = normalize(line),
            boundaryLine = "Learning cache export boundary: writes only small operational route/capsule memory; no raw matrices, no private clinical data, no medical truth assertion, and no internal DGE execution claim."
        )
    }

    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
