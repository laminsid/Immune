package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.19.2 — Final microbiome + NETosis/PANoptosis immune-damage closure.
 *
 * This is an acceptance and linkage layer. It does not create a new science tree.
 * It verifies that the gut-microbiome endocrine-immune organ layer and the
 * NETosis/PANoptosis extracellular immune-damage layer are connected to the final
 * active decision surface, while preserving the sandbox-preview policy and blocking
 * proof, diagnosis, treatment, dosing, patient action, and clinical implementation.
 */
object GTIMFinalMicrobiomeCellDeathDamageClosureV213192 {
    const val VERSION: String = "2.13.19.2-final-microbiome-cell-death-damage-closure"
    const val STATE_READY: String = "FINAL_MICROBIOME_CELL_DEATH_DAMAGE_CLOSURE_READY"
    const val CLAIM_LIMIT: String = "microbiome_cell_death_damage_closure_research_lens_not_diagnosis_not_treatment"

    fun toJson(report: JSONObject): JSONObject {
        val microbiome = report.optJSONObject("microbiomeRoleSurfaceCardV21319")
            ?: GTIMMicrobiomeRoleSurfaceCardV21319.toJson(report)
        val cellDeath = report.optJSONObject("cellDeathSurfaceCardV21319")
            ?: GTIMCellDeathSurfaceCardV21319.toJson(report)
        val integrated = report.optJSONObject("finalIntegratedDiscoveryClosureV213171")
            ?: GTIMFinalIntegratedDiscoveryClosureV213171.toJson(report)
        val requirements = report.optJSONObject("finalRequirementsCoverageClosureV213181")
            ?: GTIMFinalRequirementsCoverageClosureV213181.toJson(report)

        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("microbiome_role_card_present", microbiome.optString("state") == "MICROBIOME_ROLE_CARD_READY")
            .put("cell_death_netosis_panoptosis_card_present", cellDeath.optString("state") == "CELL_DEATH_NETOSIS_PANOPTOSIS_CARD_READY")
            .put("gut_microbiome_endocrine_immune_organ_layer", GTIMGutMicrobiomeImmuneOrganEngineV21319.STATE_READY)
            .put("microbial_metabolite_mapping", JSONArray(listOf("SCFA_axis", "tryptophan_indole_AhR_axis", "bile_acid_axis", "LPS_PRR_axis")))
            .put("gut_axis_mapping", JSONArray(listOf("gut_lung", "gut_skin", "gut_brain", "gut_tumor", "gut_metabolic", "gut_autoimmune")))
            .put("netosis_layer", GTIMNETosisExtracellularImmunityEngineV21319.STATE_READY)
            .put("panoptosis_layer", GTIMPANoptosisCellDeathEngineV21319.STATE_READY)
            .put("damage_axis", JSONArray(listOf("immunothrombosis", "thromboinflammation", "organ_failure_risk_hypothesis", "viral_lung_injury", "tumor_NET_shield", "metastasis_or_ICI_resistance_hypothesis")))
            .put("surface_integration", "ActiveDomain_to_Capsule_to_HypothesisFirst_to_ImmuneDecision_to_MicrobiomeRole_to_CellDeathNETosisRole_to_ParadigmCandidate_to_DigitalImmunomics_to_CompactSurface")
            .put("sandbox_preview_policy", integrated.optString("sandbox_preview_policy", "C0_C1_C2_C3_ALLOWED_EVEN_WITHOUT_RAW_MATRIX_OR_REPLICATION"))
            .put("legacy_policy", requirements.optString("legacy_policy", "legacy_rails_json_export_appendix_audit_compatibility_only"))
            .put("microbiome_claim_boundary", "microbiome signal != microbiome cause; microbiome intervention lens != treatment recommendation")
            .put("netosis_claim_boundary", "NET signal != diagnosis; NET biomarker hypothesis != clinical prediction")
            .put("panoptosis_claim_boundary", "PANoptosis lens != drug target proof")
            .put("anti_net_claim_boundary", "DNase/anti-NET modality lens != treatment recommendation")
            .put("validated_proof_allowed", false)
            .put("diagnosis_allowed", false)
            .put("treatment_allowed", false)
            .put("dosing_allowed", false)
            .put("patient_action_allowed", false)
            .put("clinical_implementation_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Final microbiome + cell-death immune-damage closure",
            "State: ${obj.optString("state")}; version=${obj.optString("version")}",
            "Microbiome closure: role_card_present=${obj.optBoolean("microbiome_role_card_present")}; layer=${obj.optString("gut_microbiome_endocrine_immune_organ_layer")}; metabolite_axes=${obj.optJSONArray("microbial_metabolite_mapping") ?: JSONArray()}.",
            "Gut-axis closure: axes=${obj.optJSONArray("gut_axis_mapping") ?: JSONArray()}; LBP/onco-microbiome remain research lenses only.",
            "Cell-death closure: role_card_present=${obj.optBoolean("cell_death_netosis_panoptosis_card_present")}; NETosis=${obj.optString("netosis_layer")}; PANoptosis=${obj.optString("panoptosis_layer")}; damage_axis=${obj.optJSONArray("damage_axis") ?: JSONArray()}.",
            "Surface integration: ${obj.optString("surface_integration")}",
            "Preview policy: ${obj.optString("sandbox_preview_policy")}",
            "Legacy policy: ${obj.optString("legacy_policy")}",
            "Claim boundaries: ${obj.optString("microbiome_claim_boundary")}; ${obj.optString("netosis_claim_boundary")}; ${obj.optString("panoptosis_claim_boundary")}; ${obj.optString("anti_net_claim_boundary")}",
            "Clinical boundary: proof=${obj.optBoolean("validated_proof_allowed")}; diagnosis=${obj.optBoolean("diagnosis_allowed")}; treatment=${obj.optBoolean("treatment_allowed")}; dosing=${obj.optBoolean("dosing_allowed")}; patient_action=${obj.optBoolean("patient_action_allowed")}; clinical_implementation=${obj.optBoolean("clinical_implementation_allowed")}; ${obj.optString("claim_limit")}"
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        STATE_READY,
        "GTIMGutMicrobiomeImmuneOrganEngineV21319",
        "GTIMMicrobialMetaboliteSignalMapperV21319",
        "GTIMGutAxisMapperV21319",
        "GTIMOncoMicrobiomeImmunotherapyLensV21319",
        "GTIMLiveBiotherapeuticProductLensV21319",
        "GTIMNETosisExtracellularImmunityEngineV21319",
        "GTIMPANoptosisCellDeathEngineV21319",
        "GTIMImmunothrombosisRiskMapperV21319",
        "GTIMNETBiomarkerHypothesisLensV21319",
        "GTIMAntiNETModalityLensV21319",
        "SCFA_axis",
        "tryptophan_indole_AhR_axis",
        "bile_acid_axis",
        "organ_failure_risk_hypothesis",
        "tumor_NET_shield",
        "microbiome signal != microbiome cause",
        "NET signal != diagnosis",
        "PANoptosis lens != drug target proof",
        "DNase/anti-NET modality lens != treatment recommendation",
        CLAIM_LIMIT
    ))
}
