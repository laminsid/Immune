package com.immunesignal.app

/**
 * v2.9.9 — Public expression request plan.
 *
 * This is a planning layer only. It turns public connector routes from v2.9.8 into
 * explicit, reviewable request intents for an external worker/manual tool. It does
 * not execute HTTP, download matrices, store credentials, or upgrade evidence to
 * internal DGE readiness.
 */
data class GTIMPublicExpressionRequestV2990(
    val sourceId: String,
    val state: String,
    val method: String,
    val endpointKind: String,
    val queryHandle: String,
    val expectedOutput: String,
    val safetyLimit: String,
    val line: String
)

data class GTIMPublicExpressionRequestPlanReportV2990(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val requests: List<GTIMPublicExpressionRequestV2990>,
    val preferredRequestSource: String,
    val line: String,
    val boundaryLine: String
)

object GTIMPublicExpressionRequestPlannerV2990 {
    const val VERSION: String = "2.9.9-public-expression-request-plan"

    fun build(
        targetId: String,
        publicSources: GTIMPublicExpressionSourceRegistryReportV2980,
        mapping: GTIMGseToSrpMappingReportV2950,
        capsule: GTIMExternalEvidenceCapsuleImportReportV2980
    ): GTIMPublicExpressionRequestPlanReportV2990 {
        val target = GTIMAccessionIdValidityGuardV2753.canonical(targetId)
        if (publicSources.state == "PUBLIC_SOURCES_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET" ||
            target.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", ignoreCase = true)
        ) {
            return emit(target, "REQUEST_PLAN_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", emptyList(), "none")
        }
        val requests = publicSources.routes.mapNotNull { route -> requestFor(route, target, mapping, capsule) }
        val ready = requests.filter { it.state == "REQUEST_INTENT_READY_REVIEW_ONLY" }
        val state = when {
            ready.isNotEmpty() -> "REQUEST_PLAN_READY_REVIEW_ONLY"
            requests.isNotEmpty() -> "REQUEST_PLAN_CANDIDATES_REQUIRE_METADATA_OR_CAPSULE"
            else -> "REQUEST_PLAN_NOTHING_TO_REQUEST"
        }
        val preferred = ready.firstOrNull()?.sourceId ?: requests.firstOrNull()?.sourceId ?: "none"
        return emit(target, state, requests, preferred)
    }

    private fun requestFor(
        route: GTIMPublicExpressionSourceRouteV2980,
        target: String,
        mapping: GTIMGseToSrpMappingReportV2950,
        capsule: GTIMExternalEvidenceCapsuleImportReportV2980
    ): GTIMPublicExpressionRequestV2990? {
        val source = route.sourceId
        val state = if (route.state.endsWith("AVAILABLE_REVIEW_ONLY") || route.state.contains("CANDIDATE")) {
            "REQUEST_INTENT_READY_REVIEW_ONLY"
        } else if (route.state.contains("REQUIRES")) {
            "REQUEST_INTENT_WAITING_FOR_PREREQUISITE"
        } else {
            return null
        }
        val srp = mapping.srpAccessions.firstOrNull().orEmpty()
        val upDown = capsule.topGenes.any { it.direction.equals("up", true) } && capsule.topGenes.any { it.direction.equals("down", true) }
        val endpoint = when (source.lowercase()) {
            "grein" -> "GREIN_DATASET_OR_SIGNATURE_LOOKUP_BY_GSE"
            "refine.bio" -> "REFINEBIO_SEARCH_BY_GEO_SRA_OR_BIOPROJECT"
            "recount3" -> "RECOUNT3_PROJECT_LOOKUP_BY_SRP"
            "enrichr" -> "ENRICHR_GENE_SET_ENRICHMENT_FROM_TOP_GENES"
            "sigcomlincs" -> "SIGCOM_LINCS_SIGNATURE_SIMILARITY_FROM_UP_DOWN_GENES"
            else -> "PUBLIC_SOURCE_LOOKUP"
        }
        val handle = when (source.lowercase()) {
            "recount3" -> srp.ifBlank { route.queryHandle }
            "enrichr", "sigcomlincs" -> if (upDown || capsule.topGenes.isNotEmpty()) "capsule:${capsule.datasetId}:${capsule.contrastId}" else route.queryHandle
            else -> route.queryHandle.ifBlank { target }
        }
        val expected = when (source.lowercase()) {
            "enrichr" -> "pathway_enrichment_summary"
            "sigcomlincs" -> "signature_similarity_or_reverse_translation_summary"
            "recount3" -> "processed_expression_availability_metadata"
            else -> route.outputKind
        }
        val safety = when (source.lowercase()) {
            "enrichr", "sigcomlincs" -> "gene_list_only_no_raw_matrix_no_treatment_claim"
            "recount3" -> "availability_or_processed_expression_only_no_internal_dge_ready"
            else -> "metadata_or_processed_summary_only_no_large_matrix_download"
        }
        return request(source, state, "GET_OR_EXTERNAL_WORKER", endpoint, handle, expected, safety)
    }

    private fun request(
        source: String,
        state: String,
        method: String,
        endpoint: String,
        handle: String,
        expected: String,
        safety: String
    ): GTIMPublicExpressionRequestV2990 {
        val line = "Public expression request: version=$VERSION | source=$source | state=$state | method=$method | endpoint=$endpoint | handle=$handle | expected=$expected | safety=$safety | request_plan_only_no_http_execution=true"
        return GTIMPublicExpressionRequestV2990(source, state, method, endpoint, handle, expected, safety, normalize(line))
    }

    private fun emit(target: String, state: String, requests: List<GTIMPublicExpressionRequestV2990>, preferred: String): GTIMPublicExpressionRequestPlanReportV2990 {
        val summary = requests.joinToString(",") { "${it.sourceId}:${it.state}" }.ifBlank { "none" }
        val line = "Public expression request plan: version=$VERSION | state=$state | target=$target | preferred=$preferred | requests=$summary | no_network_execution_inside_planner=true"
        return GTIMPublicExpressionRequestPlanReportV2990(
            active = true,
            targetId = target,
            state = state,
            requests = requests,
            preferredRequestSource = preferred,
            line = normalize(line),
            boundaryLine = "Request plan boundary: creates reviewable connector request intents only; no HTTP execution, no raw matrix download, no credential storage, no internal DGE_READY, and no clinical or treatment claim."
        )
    }

    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
