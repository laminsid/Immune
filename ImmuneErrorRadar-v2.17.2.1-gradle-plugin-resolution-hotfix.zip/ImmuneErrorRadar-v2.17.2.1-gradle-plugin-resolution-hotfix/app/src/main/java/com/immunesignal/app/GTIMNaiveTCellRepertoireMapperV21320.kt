package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Maps thymic-output hypotheses onto naive T-cell and repertoire-readiness tasks. */
object GTIMNaiveTCellRepertoireMapperV21320 {
    const val VERSION: String = "2.13.20-naive-tcell-repertoire-mapper"
    const val STATE_READY: String = "NAIVE_TCELL_REPERTOIRE_MAPPING_READY"
    const val CLAIM_LIMIT: String = "repertoire_mapping_is_research_readiness_not_immune_rejuvenation_proof"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("repertoire_axes", JSONArray(listOf("naive_CD4_CD8_balance", "recent_thymic_emigrants", "TCR_diversity", "clonal_expansion_pressure", "senescent_T_cell_load")))
        .put("execution_tasks", JSONArray(listOf("find_TCR_or_flow_capsule", "map_naive_memory_effector_groups", "compare_repertoire_diversity", "stress_test_against_inflammaging_only_explanation")))
        .put("proof_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
