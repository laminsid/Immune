package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Exosome-mediated systemic immunity research lens. */
object GTIMExosomeSystemicImmunityEngineV21321 {
    const val VERSION: String = "2.13.21-exosome-systemic-immunity-engine"
    const val STATE_READY: String = "EXOSOME_SYSTEMIC_IMMUNITY_LENS_READY"
    const val CLAIM_LIMIT: String = "exosome_signal_not_liquid_biopsy_diagnosis_not_cell_free_therapy_claim"

    fun toJson(report: JSONObject): JSONObject {
        val topic = report.optString("topic", "").lowercase()
        val roles = mutableListOf("intercellular_RNA_protein_cargo_signal", "immune_memory_or_training_transfer_hypothesis")
        if (topic.contains("cancer") || topic.contains("tumor") || topic.contains("metastasis")) roles.add("tumor_exosome_immune_evasion_hypothesis")
        if (topic.contains("brain") || topic.contains("neuro")) roles.add("blood_brain_barrier_delivery_research_lens")
        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("exosome_role", "systemic_nano_cargo_immune_communication_lens")
            .put("candidate_cargo", JSONArray(listOf("miRNA", "mRNA", "lncRNA", "proteins", "lipids", "surface_addressing_markers")))
            .put("research_roles", JSONArray(roles))
            .put("liquid_biopsy_diagnosis_claim_allowed", false)
            .put("cell_free_therapy_claim_allowed", false)
            .put("blood_brain_delivery_safety_claim_allowed", false)
            .put("clinical_implementation_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        STATE_READY,
        "systemic_nano_cargo_immune_communication_lens",
        "tumor_exosome_immune_evasion_hypothesis",
        "liquid_biopsy_diagnosis_claim_allowed",
        "cell_free_therapy_claim_allowed",
        "blood_brain_delivery_safety_claim_allowed",
        CLAIM_LIMIT
    ))
}
