package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Classifies inflammatory cell-death damage axes as research hypotheses. */
object GTIMCellDeathDamageAxisClassifierV21319 {
    const val VERSION: String = "2.13.19-cell-death-damage-axis-classifier"
    const val CLAIM_LIMIT: String = "cell_death_damage_axis_not_mechanism_proof"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", "CELL_DEATH_DAMAGE_AXIS_CLASSIFIER_READY")
        .put("damage_axes", JSONArray(listOf("NETosis", "PANoptosis", "thromboinflammation", "tissue_repair_failure")))
        .put("mechanism_proof_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
