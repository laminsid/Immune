package com.immunesignal.app

/**
 * Legacy audit token retained: no clinical management.
 * v2.7.9.0 — Therapeutic Reverse-Translation Router.
 *
 * Converts disease/outbreak/treatment context into a structured research protocol and
 * dataset requirement. It is intentionally upstream of ETL/DGE execution and downstream
 * of topic isolation. It never recommends treatment, dosing, pathogen engineering,
 * vaccine construction, clinical management, or efficacy.
 */
data class GTIMTherapeuticReverseTranslationReportV2790(
    val active: Boolean,
    val state: String,
    val laneId: String,
    val axisLine: String,
    val interventionLine: String,
    val evidenceGateLine: String,
    val resistanceFailureLine: String,
    val datasetRequirementLine: String,
    val etlRoutingLine: String,
    val boundaryLine: String
) {
    companion object {
        fun empty(): GTIMTherapeuticReverseTranslationReportV2790 = GTIMTherapeuticReverseTranslationReportV2790(
            active = false,
            state = "NOT_EVALUATED",
            laneId = "NO_THERAPEUTIC_LANE",
            axisLine = "Therapeutic reverse translation: not evaluated.",
            interventionLine = "Therapeutic intervention classes: not evaluated.",
            evidenceGateLine = "Therapeutic evidence gate: not evaluated.",
            resistanceFailureLine = "Therapeutic resistance/failure map: not evaluated.",
            datasetRequirementLine = "Therapeutic dataset requirement: not evaluated.",
            etlRoutingLine = "Therapeutic ETL routing: not evaluated.",
            boundaryLine = "Therapeutic reverse-translation boundary: research protocol routing only; no treatment advice."
        )
    }
}

object GTIMTherapeuticReverseTranslationRouterV2790 {
    const val VERSION: String = "2.7.9.0-therapeutic-reverse-translation-router"
    const val CLAIM_LIMIT: String = "therapeutic_research_protocol_only_no_treatment_advice_no_dosing_no_pathogen_engineering_no_efficacy_claim"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        treatmentKnowledge: GTIMTreatmentKnowledgeReportV2772,
        treatmentExecution: GTIMTreatmentExecutionBridgeReportV2773,
        finalEtl: GTIMFinalEtlExecutionUnifierReportV2782,
        matrixAuditCard: GTIMMatrixAuditCardReportV2745
    ): GTIMTherapeuticReverseTranslationReportV2790 {
        if (!matrixAuditCard.active || !finalEtl.active) return GTIMTherapeuticReverseTranslationReportV2790.empty()

        val lane = GTIMTherapeuticAxisCatalogV2790.select(
            contract = contract,
            extraText = listOf(
                treatmentKnowledge.matchedLanes.joinToString(" "),
                treatmentKnowledge.matchedSignals.joinToString(" "),
                treatmentExecution.translationalQuestionLine,
                matrixAuditCard.researchValueLine
            ).joinToString(" ")
        )
        val therapeuticContextActive = isTherapeuticContext(contract, treatmentKnowledge, treatmentExecution, lane)
        if (!therapeuticContextActive) return GTIMTherapeuticReverseTranslationReportV2790.empty()

        val hasConcreteTarget = GTIMAccessionIdValidityGuardV2753.isFullAccession(matrixAuditCard.targetId)
        val state = when {
            !hasConcreteTarget -> "THERAPEUTIC_PROTOCOL_NEEDS_TOPIC_COMPATIBLE_DATASET"
            finalEtl.state.contains("FILE_DISCOVERY", ignoreCase = true) -> "THERAPEUTIC_PROTOCOL_NEEDS_FILE_DISCOVERY"
            finalEtl.state.contains("METADATA", ignoreCase = true) -> "THERAPEUTIC_PROTOCOL_NEEDS_METADATA_NORMALIZATION"
            finalEtl.state.contains("COMPARATOR", ignoreCase = true) -> "THERAPEUTIC_PROTOCOL_NEEDS_COMPARATOR_EVIDENCE"
            finalEtl.state.contains("SAMPLE_ID", ignoreCase = true) || finalEtl.state.contains("LINKAGE", ignoreCase = true) -> "THERAPEUTIC_PROTOCOL_NEEDS_SAMPLE_ID_LINKAGE"
            finalEtl.state.contains("READY", ignoreCase = true) -> "THERAPEUTIC_PROTOCOL_READY_FOR_REVIEW_ONLY_ANALYSIS"
            else -> "THERAPEUTIC_PROTOCOL_REVIEW_REQUIRED"
        }

        val axis = normalize("Therapeutic reverse translation: version=$VERSION | state=$state | lane=${lane.laneId} | axis=${lane.therapeuticAxis} | claim=$CLAIM_LIMIT")
        val interventions = normalize("Therapeutic intervention classes: ${lane.interventionClasses.joinToString(", ")} | classification_only=true | no_recommendation=true")
        val evidenceGate = normalize("Therapeutic evidence gate: require human/animal/in-vitro/dataset/trial context, comparator, endpoint, contradiction, and safety boundary before any interpretation | etl_state=${finalEtl.state}")
        val resistance = normalize("Therapeutic resistance/failure map: ${lane.resistanceFailureModes.joinToString(", ")} | do_not_infer_response_or_resistance_from_pathway_words_alone=true")
        val requirement = GTIMTherapeuticDatasetRequirementGeneratorV2790.requirementLine(lane, finalEtl, matrixAuditCard)
        val etlRouting = GTIMTherapeuticDatasetRequirementGeneratorV2790.etlRoutingLine(lane, finalEtl)
        val boundary = "Therapeutic reverse-translation boundary: structured research protocol only; no treatment advice, no dosing, no patient-care instruction, no vaccine/pathogen engineering, no efficacy claim, no DGE_READY from therapeutic reasoning alone."

        return GTIMTherapeuticReverseTranslationReportV2790(
            active = true,
            state = state,
            laneId = lane.laneId,
            axisLine = axis,
            interventionLine = interventions,
            evidenceGateLine = evidenceGate,
            resistanceFailureLine = resistance,
            datasetRequirementLine = requirement,
            etlRoutingLine = etlRouting,
            boundaryLine = boundary
        )
    }

    fun compactLine(report: GTIMTherapeuticReverseTranslationReportV2790): String = if (report.active) report.axisLine else report.axisLine

    private fun isTherapeuticContext(
        contract: GTIMRunDecisionContractV2740,
        treatmentKnowledge: GTIMTreatmentKnowledgeReportV2772,
        treatmentExecution: GTIMTreatmentExecutionBridgeReportV2773,
        lane: GTIMTherapeuticAxisDefinitionV2790
    ): Boolean {
        if (treatmentKnowledge.active || treatmentExecution.active) return true
        if (lane.laneId != "GENERAL_THERAPEUTIC_REVERSE_TRANSLATION") return true
        val q = (contract.rawQuery + " " + contract.normalizedQuery).lowercase()
        return listOf("drug", "treatment", "therapy", "vaccine", "trial", "resistance", "response", "non-responder", "cancer", "diabetes", "ebola", "hanta").any { q.contains(it) }
    }

    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}
