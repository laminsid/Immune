package com.immunesignal.app

/**
 * v2.9.0 — Target-gate recall guard.
 *
 * This helper documents and centralizes the safe recall relaxation used for emerging
 * or relationship-heavy topics such as Hanta and gut-microbiome/depression. It does
 * not promote a background handle into evidence. It only permits a selected accession
 * to enter review-only ETL triage when the active contract already carries the topic
 * identity and all downstream ETL/DGE gates remain closed until files/metadata/linkage
 * are observed.
 */
object GTIMTargetGateRecallV2900 {
    const val VERSION: String = "2.9.0-target-gate-recall-fix"
    const val REVIEW_STATE: String = "NEAR_MATCH_TOPIC_COMPATIBLE_REVIEW"

    fun minimumAcceptScore(contract: GTIMRunDecisionContractV2740, currentMinimum: Int): Int {
        return when (contract.primaryAnchor) {
            GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL,
            GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> currentMinimum.coerceAtMost(45)
            else -> currentMinimum
        }
    }

    fun recallReason(contract: GTIMRunDecisionContractV2740, score: Int): String =
        "$REVIEW_STATE for ${contract.primaryAnchor.routeId}; score=$score; ETL/DGE remains blocked until observed file evidence, metadata evidence, comparator labels, and sample-ID linkage pass."

    fun surfaceLine(targetId: String, state: String): String =
        "Target recall gate: version=$VERSION | target=$targetId | state=$state | background_seed_not_evidence=true | no_dge_without_etl=true"
}
