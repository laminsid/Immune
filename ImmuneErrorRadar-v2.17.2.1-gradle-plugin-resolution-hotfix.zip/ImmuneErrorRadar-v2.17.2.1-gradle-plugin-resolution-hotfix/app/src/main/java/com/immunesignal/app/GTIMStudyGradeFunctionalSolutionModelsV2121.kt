package com.immunesignal.app

// v2.12.1 models for paper-like value synthesis without turning hypotheses into claims.
data class GTIMStudyGradeSolutionV2121(
    val version: String,
    val state: String,
    val proposedContribution: String,
    val rootCauseClaimCandidate: String,
    val functionalSolutionHypothesis: String,
    val microbialOrBiologicalToolRationale: String,
    val crossConditionBridge: List<String>,
    val validationLadder: List<String>,
    val falsificationTriggers: List<String>,
    val noveltyFrame: String,
    val boundary: String,
    val line: String
)
