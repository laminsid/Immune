package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

object GTIMRouteLearningMemoryV21311 {
    fun toJson(report: JSONObject): JSONObject {
        val intent = GTIMRouteConfidenceGateV21311.infer(report)
        val target = GTIMCanonicalTargetAfterRouteLockV21311.canonicalTarget(report)
        val blocked = JSONArray()
        intent.handles.forEach { handle ->
            val h = handle.uppercase()
            val wrong = when (intent.lockedSubtype) {
                "viral_filovirus_bundibugyo", "viral_filovirus" -> h in setOf("GSE166552", "GSE152202", "GSE152418", "GSE157103")
                "viral_covid_postviral" -> h == "GSE45291"
                "nonviral_or_unspecified" -> intent.lockedRoute == "depression_kynurenine_neuroimmune" && h in setOf("GSE166552", "GSE131907", "GSE250594", "GSE72056")
                else -> false
            }
            if (wrong) blocked.put(h)
        }
        return JSONObject()
            .put("version", GTIMResearchIntentObjectContractV21311.VERSION)
            .put("state", "ROUTE_LEARNING_MEMORY_READY")
            .put("lockedRoute", intent.lockedRoute)
            .put("lockedSubtype", intent.lockedSubtype)
            .put("canonicalTarget", target)
            .put("blockedWrongCapsuleHandles", blocked)
            .put("learningRule", "future runs should prefer route evidence over reused accessions; blocked handles may reappear only as background/contradiction, not active targets")
            .put("claimLimit", GTIMResearchIntentObjectContractV21311.CLAIM_LIMIT)
    }
}
