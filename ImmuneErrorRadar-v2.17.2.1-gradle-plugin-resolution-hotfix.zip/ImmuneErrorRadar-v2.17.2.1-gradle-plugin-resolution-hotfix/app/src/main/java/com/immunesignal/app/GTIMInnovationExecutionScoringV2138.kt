package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.8 — execution bridge: module score placeholders + C1→C2 pathway.
 * This is innovation infrastructure, not proof. It tells the app exactly what must be
 * executed next to turn a C1 discovery candidate into a computationally replicated C2.
 */
object GTIMModuleScorePlaceholderEngineV2138 {
    const val VERSION: String = "2.13.8-module-score-placeholder-engine"
    const val CLAIM_LIMIT: String = "module_score_placeholders_are_not_dge_results"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val target = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val modules = report.optJSONObject("immuneModuleSignalEngineV2135")?.optJSONArray("moduleSignals") ?: JSONArray()
        val rows = JSONArray()
        for (i in 0 until modules.length()) {
            val module = modules.optJSONObject(i) ?: continue
            val id = module.optString("moduleId", module.optString("id", "module_$i"))
            rows.put(JSONObject()
                .put("moduleId", id)
                .put("direction", "unknown_pending_matrix_or_capsule_scoring")
                .put("moduleScoreStatus", "PENDING_EXECUTION")
                .put("effectSizeStatus", "PENDING_EFFECT_SIZE")
                .put("fdrStatus", "PENDING_FDR")
                .put("replicationStatus", "PENDING_SECOND_DATASET")
                .put("upgradeImpact", "blocks_C2_until_executed"))
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (target.isNotBlank() && rows.length() > 0) "MODULE_SCORE_PLACEHOLDERS_READY" else "MODULE_SCORE_PLACEHOLDERS_NEED_TARGET_OR_MODULES")
            .put("activeDomain", domain)
            .put("canonicalTarget", target)
            .put("moduleScoreRows", rows)
            .put("c2Blocker", "module_score_direction_effect_size_and_FDR_missing")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Module score placeholder engine",
        "State: ${obj.optString("state", "UNKNOWN")}; target=${obj.optString("canonicalTarget", "none")}; modules=${obj.optJSONArray("moduleScoreRows")?.length() ?: 0}.",
        "C2 blocker: ${obj.optString("c2Blocker", "module score missing")}",
        "Boundary: placeholders define execution work; they are not DGE, FDR, effect size, or proof."
    )
}

object GTIMC1ToC2UpgradePathwayV2138 {
    const val VERSION: String = "2.13.8-c1-to-c2-upgrade-pathway"
    const val CLAIM_LIMIT: String = "c1_to_c2_pathway_is_execution_plan_not_replicated_result"

    fun toJson(report: JSONObject): JSONObject {
        val target = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val score = report.optJSONObject("moduleScorePlaceholderEngineV2138") ?: GTIMModuleScorePlaceholderEngineV2138.toJson(report)
        val repl = report.optJSONObject("c2AutoReplicationEngineV2137") ?: GTIMC2AutoReplicationEngineV2137.toJson(report)
        val candidates = repl.optJSONArray("replicationCandidates") ?: JSONArray()
        val blockers = JSONArray()
        if (target.isBlank()) blockers.put("canonical_target_missing")
        if ((score.optJSONArray("moduleScoreRows")?.length() ?: 0) == 0) blockers.put("module_score_rows_missing")
        if (candidates.length() == 0) blockers.put("replication_dataset_missing")
        blockers.put("negative_control_not_executed")
        blockers.put("contradiction_execution_not_executed")
        val state = if (blockers.length() <= 2 && target.isNotBlank()) "C1_TO_C2_UPGRADE_PATHWAY_READY" else "C1_TO_C2_UPGRADE_PATHWAY_NEEDS_EXECUTION"
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("primaryTarget", target)
            .put("replicationCandidates", candidates)
            .put("upgradeBlockers", blockers)
            .put("nextExecutionOrder", JSONArray(listOf("score_primary_modules", "score_replication_modules", "run_negative_control", "run_contradiction_dataset", "compare_direction_effect_size_FDR")))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "C1 → C2 upgrade pathway",
        "State: ${obj.optString("state", "UNKNOWN")}; primary=${obj.optString("primaryTarget", "none")}; replication_candidates=${obj.optJSONArray("replicationCandidates")?.length() ?: 0}; blockers=${obj.optJSONArray("upgradeBlockers")?.length() ?: 0}.",
        "Next execution: ${jsonStrings(obj.optJSONArray("nextExecutionOrder")).joinToString(" → ")}",
        "Boundary: C2/C3 preview may be shown in sandbox; validation still requires module scores, replication, negative control, and contradiction checks."
    )

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { array.optString(it).takeIf { s -> s.isNotBlank() } }
}
