package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.0/v2.13.5 — Compose future-facing hypotheses from the offline lite corpus.
 * v2.13.5 adds the future-corpus mismatch lock: if the future corpus does not match
 * ActiveDomain, no target/readout/hypothesis text is rendered into the final report.
 */
object GTIMFutureHypothesisComposerV2130 {
    const val VERSION: String = "2.13.0-future-hypothesis-composer"
    const val CLAIM_LIMIT: String = "future_hypotheses_are_testable_leads_not_discoveries"

    fun toJson(report: JSONObject): JSONObject {
        val corpus = report.optJSONObject("futureEvidenceLiteCorpusV2130") ?: GTIMFutureEvidenceLiteCorpusV2130.toJson(report)
        val activeDomain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val corpusDomain = corpus.optString("domainKey")
        val matchesActive = GTIMActiveDomainConsistencyGuardV2134.domainCompatible(activeDomain, corpusDomain, GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report))
        if (!matchesActive) {
            return JSONObject()
                .put("version", VERSION)
                .put("state", "FUTURE_HYPOTHESIS_BACKGROUND_ONLY_DOMAIN_MISMATCH")
                .put("domainKey", activeDomain)
                .put("selectedFutureCorpusDomain", corpusDomain)
                .put("variants", JSONArray())
                .put("bestVariant", JSONObject())
                .put("renderPolicy", "background_contradiction_only_no_hypothesis_targets_readouts")
                .put("claimLimit", CLAIM_LIMIT)
        }
        val selectedTarget = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val hypotheses = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("highValueHypotheses"))
        val bridges = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("crossDomainBridges"))
        val readouts = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("readouts"))
        val variants = JSONArray()
        val seeds = if (hypotheses.isNotEmpty()) hypotheses else listOf("under-tested immune bridge may define a measurable subgroup")
        seeds.take(4).forEachIndexed { index, h ->
            variants.put(JSONObject()
                .put("id", "FH${index + 1}")
                .put("hypothesis", h)
                .put("bridge", bridges.getOrNull(index % bridges.size.coerceAtLeast(1)) ?: "context -> immune mediator -> tissue module -> phenotype")
                .put("minimumReadouts", JSONArray(readouts.take(4)))
                .put("selectedReviewTarget", selectedTarget.ifBlank { "not_selected_yet" })
                .put("falsifier", "fails if comparator labels, tissue context, sample provenance, or contradiction check do not support the bridge"))
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "FUTURE_HYPOTHESIS_VARIANTS_READY")
            .put("domainKey", activeDomain)
            .put("variants", variants)
            .put("bestVariant", variants.optJSONObject(0) ?: JSONObject())
            .put("renderPolicy", "domain_specific_future_blocks_allowed")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        if (obj.optString("state") == "FUTURE_HYPOTHESIS_BACKGROUND_ONLY_DOMAIN_MISMATCH") {
            return listOf(
                "Future hypothesis composer",
                "State: ${obj.optString("state", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}; selected_future_domain=${obj.optString("selectedFutureCorpusDomain", "unknown")}; variants=0.",
                "Render policy: background/contradiction prior only; cross-domain future hypothesis, targets, and readouts are suppressed.",
                "Boundary: mismatch suppression prevents stale future-corpus contamination."
            )
        }
        val best = obj.optJSONObject("bestVariant") ?: JSONObject()
        return listOf(
            "Future hypothesis composer",
            "State: ${obj.optString("state", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}; variants=${obj.optJSONArray("variants")?.length() ?: 0}.",
            "Top future-facing hypothesis: ${best.optString("hypothesis", "no hypothesis composed")}",
            "Bridge: ${best.optString("bridge", "no bridge selected")}",
            "Boundary: these are testable leads, not discoveries, mechanisms, treatments, or clinical predictions."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FUTURE_HYPOTHESIS_VARIANTS_READY", "FUTURE_HYPOTHESIS_BACKGROUND_ONLY_DOMAIN_MISMATCH", CLAIM_LIMIT))
}
