package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Compact first-surface card for NETosis/PANoptosis/cell-death damage hypotheses. */
object GTIMCellDeathSurfaceCardV21319 {
    const val VERSION: String = "2.13.19-cell-death-netosis-panoptosis-surface-card"

    fun toJson(report: JSONObject): JSONObject {
        val net = GTIMNETosisExtracellularImmunityEngineV21319.toJson(report)
        val pan = GTIMPANoptosisCellDeathEngineV21319.toJson(report)
        val thrombo = GTIMImmunothrombosisRiskMapperV21319.toJson(report)
        val damage = GTIMCellDeathDamageAxisClassifierV21319.toJson(report)
        val biomarker = GTIMNETBiomarkerHypothesisLensV21319.toJson(report)
        val antiNet = GTIMAntiNETModalityLensV21319.toJson(report)
        return JSONObject()
            .put("version", VERSION)
            .put("state", "CELL_DEATH_NETOSIS_PANOPTOSIS_CARD_READY")
            .put("netosis", net)
            .put("panoptosis", pan)
            .put("immunothrombosis", thrombo)
            .put("damage_axis", damage)
            .put("NET_biomarker_hypothesis", biomarker)
            .put("anti_NET_modality_lens", antiNet)
            .put("claim_boundary", "NET signal != diagnosis; PANoptosis lens != drug target proof; anti-NET modality lens != treatment recommendation")
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        return listOf(
            "Cell-death / NETosis role card",
            "NETosis role: ${obj.optJSONObject("netosis")?.optString("NETosis_role")}; biomarkers=${obj.optJSONObject("NET_biomarker_hypothesis")?.optJSONArray("candidate_biomarkers") ?: JSONArray()}.",
            "PANoptosis role: ${obj.optJSONObject("panoptosis")?.optString("PANoptosis_role")}; modes=${obj.optJSONObject("panoptosis")?.optJSONArray("cell_death_modes") ?: JSONArray()}.",
            "Immunothrombosis/thromboinflammation: ${obj.optJSONObject("immunothrombosis")?.optJSONArray("contexts") ?: JSONArray()}; clinical prediction=BLOCKED.",
            "Anti-NET modality lens: ${obj.optJSONObject("anti_NET_modality_lens")?.optJSONArray("modalities") ?: JSONArray()}; treatment recommendation=BLOCKED.",
            "Boundary: ${obj.optString("claim_boundary")}"
        )
    }
}
