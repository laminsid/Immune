package com.immunesignal.app

// v2.10.8 — Restoration route generator.
// Produces research routes that ask what function may need restoration, not which
// symptom should be suppressed. Routes are not interventions, prescriptions, or claims.
object GTIMEcosystemRestorationRouteGeneratorV2108 {
    const val VERSION: String = "2.10.8-ecosystem-restoration-route-generator"
    const val BOUNDARY: String = "restoration_routes_are_research_hypotheses_not_treatment_protocols"

    fun build(
        candidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
        microbialReversal: GTIMMicrobialReversalReportV2111? = null,
        ecologicalRestoration: GTIMEcologicalRestorationReportV2112? = null
    ): List<GTIMEcosystemRestorationRouteV2108> {
        val baseRoutes = candidates.take(5).mapIndexed { index, candidate ->
            val id = "RESTORE_${index + 1}_${candidate.candidateId}"
            val routeClass = when {
                candidate.upstreamDysfunction.contains("microbial", true) || candidate.upstreamDysfunction.contains("ecological", true) -> "microbiome_metabolite_function_restoration"
                candidate.upstreamDysfunction.contains("metabolic", true) || candidate.upstreamDysfunction.contains("energy", true) -> "immunometabolic_resilience_restoration"
                candidate.upstreamDysfunction.contains("mucosal", true) || candidate.upstreamDysfunction.contains("barrier", true) -> "barrier_mucosal_tolerance_restoration"
                candidate.upstreamDysfunction.contains("variant", true) || candidate.upstreamDysfunction.contains("immune readiness", true) -> "adaptive_immune_readiness_restoration"
                else -> "open_ecosystem_restoration_route"
            }
            val levers = researchLevers(routeClass)
            val required = (candidate.missingEvidence + "context-specific validation before any clinical interpretation").distinct().take(7)
            val logic = when (routeClass) {
                "microbiome_metabolite_function_restoration" -> "Search for lost protective microbial/metabolite functions that may restore barrier tone, immune tolerance, and inflammatory balance."
                "immunometabolic_resilience_restoration" -> "Search for metabolic flexibility and immune-energy constraints that may explain poor immune adaptation or excessive inflammation."
                "barrier_mucosal_tolerance_restoration" -> "Search for failure at the entry/barrier interface where microbes, metabolites, epithelium, and immune training interact."
                "adaptive_immune_readiness_restoration" -> "Search for durable immune readiness across variant pressure, mucosal entry, trained innate tone, and conserved target response."
                else -> "Search for upstream system functions that may need rebuilding rather than downstream symptom suppression."
            }
            val line = "Eco restoration route: version=$VERSION | id=$id | class=$routeClass | logic=${logic.oneLine()} | levers=${levers.joinToString(";").oneLine()} | required=${required.joinToString(";").oneLine()} | boundary=$BOUNDARY"
            GTIMEcosystemRestorationRouteV2108(
                routeId = id,
                routeClass = routeClass,
                restorationLogic = logic,
                researchLevers = levers,
                requiredEvidence = required,
                safetyBoundary = BOUNDARY,
                line = line
            )
        }
        val microbialRoutes = microbialReversal?.candidateRoutes?.take(2)?.mapIndexed { index, candidate ->
            val id = "RESTORE_MRE_${index + 1}_${candidate.candidateId}".take(96)
            val logic = "Microbial reversal bridge: use ${candidate.candidateClass} as a research-only counter-function route for ${candidate.hypotheticalRole}."
            val levers = listOf(
                "counter-function=${candidate.sourceFunctionId}",
                "candidate_class=${candidate.candidateClass}",
                "evidence_rank=${candidate.evidenceRank}",
                "claim_limit=${candidate.claimLimit}"
            )
            val required = (candidate.missingEvidence + "microbial reversal study plan before any belief upgrade").distinct().take(7)
            val line = "Eco restoration route: version=$VERSION | id=$id | class=microbial_reversal_counter_function_bridge | logic=${logic.oneLine()} | levers=${levers.joinToString(";").oneLine()} | required=${required.joinToString(";").oneLine()} | boundary=$BOUNDARY"
            GTIMEcosystemRestorationRouteV2108(
                routeId = id,
                routeClass = "microbial_reversal_counter_function_bridge",
                restorationLogic = logic,
                researchLevers = levers,
                requiredEvidence = required,
                safetyBoundary = BOUNDARY,
                line = line
            )
        }.orEmpty()
        val ecologicalRoutes = ecologicalRestoration?.restorationSequences?.take(2)?.mapIndexed { index, sequence ->
            val id = "RESTORE_ECO_${index + 1}_${sequence.collapseSignalId}".take(96)
            val logic = "Ecological restoration bridge: ${sequence.firstRepairFunction} before treating symptoms as disease identity."
            val levers = listOf(
                "collapse=${sequence.collapseSignalId}",
                "microbial_role=${sequence.microbialRole}",
                "confidence=${sequence.confidenceState}"
            )
            val required = (sequence.recoveryMarkers + sequence.failureSignals.take(2) + "causal restoration test before evidence upgrade").distinct().take(7)
            val line = "Eco restoration route: version=$VERSION | id=$id | class=ecological_restoration_sequence_bridge | logic=${logic.oneLine()} | levers=${levers.joinToString(";").oneLine()} | required=${required.joinToString(";").oneLine()} | boundary=$BOUNDARY"
            GTIMEcosystemRestorationRouteV2108(
                routeId = id,
                routeClass = "ecological_restoration_sequence_bridge",
                restorationLogic = logic,
                researchLevers = levers,
                requiredEvidence = required,
                safetyBoundary = BOUNDARY,
                line = line
            )
        }.orEmpty()
        return (baseRoutes + microbialRoutes + ecologicalRoutes).distinctBy { it.routeId }.take(9)
    }

    private fun researchLevers(routeClass: String): List<String> = when (routeClass) {
        "microbiome_metabolite_function_restoration" -> listOf(
            "defined microbial function or consortium candidate",
            "prebiotic/postbiotic/metabolite route such as SCFA or butyrate context",
            "diet-mediated ecological restoration as research variable",
            "donor-derived route only under screened regulated research conditions"
        )
        "immunometabolic_resilience_restoration" -> listOf(
            "glucose-insulin and mitochondrial energy context",
            "immune-cell metabolic phenotype",
            "lactate/hypoxia/lipid metabolism route",
            "population/diet/ecology modifier"
        )
        "barrier_mucosal_tolerance_restoration" -> listOf(
            "mucosal immunity and epithelial barrier markers",
            "Treg/Th2/Th17 balance or mast-cell threshold",
            "barrier permeability and inflammatory mediator review",
            "microbiome-metabolite-barrier linkage"
        )
        "adaptive_immune_readiness_restoration" -> listOf(
            "conserved epitope or broad T-cell route",
            "mucosal entry-point immunity",
            "trained innate immunity balance",
            "variant escape and waning durability analysis"
        )
        else -> listOf(
            "upstream dysfunction mapping",
            "missing function restoration",
            "cross-domain analogy review",
            "falsification-first evidence plan"
        )
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
