package com.immunesignal.app

import org.json.JSONObject

/**
 * v2.8.1 — Observed file evidence contract.
 *
 * Separates planned repository/file signatures from files that were actually observed
 * after a public repository lookup/download step. A future downloader may populate
 * concrete file evidence, but this contract keeps v2.8.0 honest today: candidate
 * signatures such as matrix.mtx/h5/rds are not evidence that a matrix exists.
 */
data class GTIMObservedFileEvidenceReportV2801(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val observedFileCount: Int,
    val observedFileTypes: List<String>,
    val requiredEvidenceFields: List<String>,
    val observedFileLine: String,
    val boundaryLine: String
)

object GTIMObservedFileEvidenceContractV2801 {
    const val VERSION: String = "2.8.1-observed-file-evidence-contract"
    private val REQUIRED_EVIDENCE_FIELDS = listOf(
        "file_name", "source_url", "size_bytes", "checksum_or_etag", "download_timestamp", "parser_hint"
    )

    fun build(fileDiscovery: GTIMRepositoryFileDiscoveryReportV2800): GTIMObservedFileEvidenceReportV2801 = build(fileDiscovery, null)

    fun build(fileDiscovery: GTIMRepositoryFileDiscoveryReportV2800, reportJson: JSONObject?): GTIMObservedFileEvidenceReportV2801 {
        if (fileDiscovery.state == "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET") {
            return report(
                target = fileDiscovery.targetId,
                state = "OBSERVED_FILE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET",
                observedTypes = emptyList(),
                count = 0,
                line = "Observed file evidence: version=$VERSION | state=OBSERVED_FILE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | target=${fileDiscovery.targetId} | observed_files=0 | observed_types=none | required_evidence=${REQUIRED_EVIDENCE_FIELDS.joinToString(",")}"
            )
        }

        val observed = GTIMSupplementaryFileDiscoveryV2802.observedFiles(reportJson)
        if (observed.isNotEmpty()) {
            val types = observed.map { GTIMSupplementaryFileDiscoveryV2802.classifyFileType(it.fileName, it.parserHint) }.distinct()
            val completeEvidence = observed.all { it.fileName.isNotBlank() && it.sourceUrl.isNotBlank() && it.sizeBytes > 0L && it.checksumOrEtag.isNotBlank() && it.parserHint.isNotBlank() }
            val state = if (completeEvidence) "OBSERVED_FILE_EVIDENCE_COMPLETE_REVIEW_ONLY" else "OBSERVED_FILE_EVIDENCE_PARTIAL_REVIEW_REQUIRED"
            return report(
                target = fileDiscovery.targetId,
                state = state,
                observedTypes = types,
                count = observed.size,
                line = "Observed file evidence: version=$VERSION | state=$state | target=${fileDiscovery.targetId} | observed_files=${observed.size} | observed_types=${types.joinToString(",")} | required_evidence=${REQUIRED_EVIDENCE_FIELDS.joinToString(",")}"
            )
        }

        // Repository signatures and lookup URLs are execution plans only. File evidence must
        // be observed before matrix parsing can advance.
        return report(
            target = fileDiscovery.targetId,
            state = "OBSERVED_FILE_EVIDENCE_REQUIRED",
            observedTypes = emptyList(),
            count = 0,
            line = "Observed file evidence: version=$VERSION | state=OBSERVED_FILE_EVIDENCE_REQUIRED | target=${fileDiscovery.targetId} | observed_files=0 | observed_types=none | candidate_signatures_are_not_observed_files=true | required_evidence=${REQUIRED_EVIDENCE_FIELDS.joinToString(",")}"
        )
    }

    private fun report(
        target: String,
        state: String,
        observedTypes: List<String>,
        count: Int,
        line: String
    ): GTIMObservedFileEvidenceReportV2801 = GTIMObservedFileEvidenceReportV2801(
        active = true,
        targetId = target,
        state = state,
        observedFileCount = count,
        observedFileTypes = observedTypes,
        requiredEvidenceFields = REQUIRED_EVIDENCE_FIELDS,
        observedFileLine = line.replace(Regex("\\s+"), " ").trim(),
        boundaryLine = "Observed file evidence boundary: planned file signatures, lookup URLs, and recovery queries are not downloaded files; matrix parsing requires observed file_name, source_url, size/checksum, and parser hint."
    )
}
