package com.immunesignal.app

// v2.11.1 — Produces a professional hypothetical study route for each microbial reversal candidate.
object GTIMMicrobialReversalStudyDesignerV2111 {
    const val VERSION: String = "2.11.1-microbial-reversal-study-designer"

    fun design(
        contract: GTIMRunDecisionContractV2740,
        mechanisms: List<GTIMMicrobialDamageMechanismV2111>,
        candidates: List<GTIMMicrobialReversalCandidateV2111>
    ): List<GTIMMicrobialReversalStudyPlanV2111> {
        val primaryMechanism = mechanisms.firstOrNull()
        return candidates.take(5).mapIndexed { index, candidate ->
            val hypothesis = "For ${contract.primaryAnchor.routeId}, a ${candidate.candidateClass} may reverse or buffer ${primaryMechanism?.damageClass ?: "an upstream damage mechanism"} by ${candidate.hypotheticalRole}; this is a root-cause research hypothesis, not a clinical claim."
            val minimumEvidence = minimumEvidence(candidate)
            val biomarkers = biomarkersFor(candidate, primaryMechanism)
            val decisive = decisiveTests(candidate)
            val kills = killCriteria(candidate, primaryMechanism)
            val id = "MRE_STUDY_${index + 1}_${candidate.candidateId}".take(98)
            val line = "Microbial reversal study plan: version=$VERSION | id=$id | candidate=${candidate.candidateId} | hypothesis=${hypothesis.oneLine()} | minimum_evidence=${minimumEvidence.joinToString(";").oneLine()} | biomarkers=${biomarkers.joinToString(";").oneLine()} | decisive_tests=${decisive.joinToString(";").oneLine()} | kill_criteria=${kills.joinToString(";").oneLine()}"
            GTIMMicrobialReversalStudyPlanV2111(id, candidate.candidateId, hypothesis, minimumEvidence, biomarkers, decisive, kills, line)
        }
    }

    private fun minimumEvidence(candidate: GTIMMicrobialReversalCandidateV2111): List<String> = (listOf(
        "mechanism-specific literature or dataset capsule",
        "same-topic comparator group or negative control",
        "function-level evidence not species-name association",
        "explicit safety and alternative-explanation review"
    ) + candidate.missingEvidence.take(3)).distinct().take(8)

    private fun biomarkersFor(candidate: GTIMMicrobialReversalCandidateV2111, mechanism: GTIMMicrobialDamageMechanismV2111?): List<String> {
        val base = mutableListOf("microbial function marker", "host-response marker", "context/provenance marker")
        when {
            candidate.candidateClass.contains("toxin", true) -> base += listOf("toxin/particle burden", "binding or byproduct marker", "excretion/reduced-bioavailability signal")
            candidate.candidateClass.contains("barrier", true) -> base += listOf("barrier integrity marker", "mucus/tight-junction context", "local cytokine profile")
            candidate.candidateClass.contains("tolerance", true) -> base += listOf("Treg/Th balance", "mast-cell or cytokine threshold", "flare/suppression safety marker")
            candidate.candidateClass.contains("phage", true) -> base += listOf("target bacterium load", "biofilm/toxin marker", "resistance escape marker")
            candidate.candidateClass.contains("engineered", true) -> base += listOf("sensor specificity", "actuator output", "containment/clearance marker")
        }
        if (mechanism?.damageClass?.contains("neuro", true) == true) base += listOf("peripheral inflammatory marker", "neuroimmune proxy", "longitudinal directionality")
        return base.distinct().take(8)
    }

    private fun decisiveTests(candidate: GTIMMicrobialReversalCandidateV2111): List<String> = listOf(
        "show counter-function changes the nominated mechanism marker in a controlled context",
        "show effect direction survives negative-control and context-matched comparator",
        "show no conversion into treatment/dosing/clinical-management claim",
        "show biosafety risk can be bounded before any translational interpretation"
    ) + when {
        candidate.candidateClass.contains("engineered", true) -> listOf("demonstrate containment/off-switch in model only")
        candidate.candidateClass.contains("toxin", true) -> listOf("demonstrate no harmful byproduct and measurable burden reduction")
        candidate.candidateClass.contains("phage", true) -> listOf("demonstrate target specificity and resistance-escape monitoring")
        else -> listOf("demonstrate function-level change beyond microbiome association")
    }

    private fun killCriteria(candidate: GTIMMicrobialReversalCandidateV2111, mechanism: GTIMMicrobialDamageMechanismV2111?): List<String> = (listOf(
        "candidate worsens inflammation or barrier damage",
        "effect disappears under topic-compatible comparator",
        "mechanism marker does not move despite claimed function",
        "biosafety risk dominates plausible benefit"
    ) + candidate.biosafetyRisks.take(3) + listOf("damage mechanism not confirmed: ${mechanism?.mechanismId ?: "open"}")).distinct().take(8)

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
