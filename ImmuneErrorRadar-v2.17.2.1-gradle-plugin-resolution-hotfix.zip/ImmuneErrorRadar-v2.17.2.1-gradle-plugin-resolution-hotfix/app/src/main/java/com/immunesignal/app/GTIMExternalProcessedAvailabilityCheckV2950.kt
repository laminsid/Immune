package com.immunesignal.app

import org.json.JSONObject

object GTIMExternalProcessedAvailabilityCheckV2950 {
    const val VERSION: String = "2.9.8-external-processed-availability-check"

    fun build(targetId: String, mapping: GTIMGseToSrpMappingReportV2950, report: JSONObject? = null): GTIMExternalAvailabilityReportV2950 {
        val checked = listOf("recount3", "GEO2R", "processed_supplementary_tables")
        if (mapping.state.contains("BLOCKED_NO_TOPIC", true)) {
            return emit(targetId, "EXTERNAL_ROUTE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", checked, emptyList(), "topic_compatible_target_required")
        }
        if (mapping.srpAccessions.isEmpty()) {
            return emit(targetId, "EXTERNAL_ROUTE_REQUIRES_SRP_MAPPING", checked, emptyList(), "srp_mapping_missing")
        }
        val root = report ?: JSONObject()
        val external = root.optJSONObject("externalProcessedAvailability") ?: root.optJSONObject("externalDgeAvailability") ?: JSONObject()
        val available = mutableListOf<String>()
        if (external.optBoolean("recount3Available", false) || root.optBoolean("recount3Available", false)) available += "recount3"
        if (external.optBoolean("geo2rCompatible", false) || root.optBoolean("geo2rCompatible", false)) available += "GEO2R"
        if (external.optBoolean("processedTableAvailable", false) || root.optBoolean("processedTableAvailable", false)) available += "processed_supplementary_tables"
        val state = when {
            available.isNotEmpty() -> "EXTERNAL_PROCESSED_EXPRESSION_AVAILABLE"
            else -> "EXTERNAL_AVAILABILITY_CHECK_REQUIRED"
        }
        return emit(targetId, state, checked, available.distinct(), if (available.isEmpty()) "availability_not_verified" else "none")
    }

    private fun emit(target: String, state: String, checked: List<String>, available: List<String>, blocker: String): GTIMExternalAvailabilityReportV2950 {
        val line = "External processed availability: version=$VERSION | state=$state | target=$target | checked=${checked.joinToString(",")} | available=${available.ifEmpty { listOf("none") }.joinToString(",")} | blocker=$blocker | never_equals_dge_ready=true"
        return GTIMExternalAvailabilityReportV2950(
            active = true,
            targetId = target,
            state = state,
            checkedRoutes = checked,
            availableRoutes = available,
            blocker = blocker,
            line = GTIMMetadataFirstObservedEvidenceBridgeV2950.normalize(line),
            boundaryLine = "External availability boundary: processed expression availability is only a route candidate; contrast/sample mapping and reviewed output are still required before DGE claims."
        )
    }
}
