package com.immunesignal.app

import org.json.JSONObject

object GTIMUnknownTopicSafeFallbackV21311 {
    fun toJson(report: JSONObject): JSONObject {
        val intent = GTIMRouteConfidenceGateV21311.infer(report)
        return JSONObject()
            .put("version", GTIMResearchIntentObjectContractV21311.VERSION)
            .put("state", if (intent.locked) "FALLBACK_NOT_USED_ROUTE_LOCKED" else "UNKNOWN_TOPIC_SAFE_FALLBACK_READY")
            .put("locked", intent.locked)
            .put("route", intent.lockedRoute)
            .put("canonicalTarget", if (intent.locked) GTIMCanonicalTargetAfterRouteLockV21311.canonicalTarget(report) else "")
            .put("runtimePolicy", "do not reuse previous question, checkpoint, route, or matrix handle when the current prompt has insufficient route evidence")
            .put("nextAction", if (intent.locked) "continue with route-compatible canonical selection" else "search/feed topic-compatible accession or capsule before report target selection")
            .put("claimLimit", GTIMResearchIntentObjectContractV21311.CLAIM_LIMIT)
    }
}
