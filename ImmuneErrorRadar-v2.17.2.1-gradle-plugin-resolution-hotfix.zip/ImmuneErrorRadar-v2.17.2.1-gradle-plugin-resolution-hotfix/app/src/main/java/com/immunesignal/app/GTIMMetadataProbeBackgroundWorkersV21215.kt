package com.immunesignal.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * v2.12.15 — Background metadata probe workers.
 *
 * Executes bounded, report-triggered background microtasks for GSE handles: SOFT/listing
 * metadata probe and GSE→SRP/SRA mapping extraction. This turns repeated manual next-action
 * SOFT probe guidance into an in-app background attempt. Network failure keeps
 * the task queued; success writes review-only metadata into the technical appendix. No
 * result upgrades evidence or claims.
 */
object GTIMMetadataProbeBackgroundWorkersV21215 {
    const val VERSION: String = "2.12.16-background-metadata-probe-workers-with-injected-pack"
    const val CLAIM_LIMIT: String = "background_metadata_probe_readiness_only_no_evidence_upgrade"
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .callTimeout(10, TimeUnit.SECONDS)
            .build()
    }

    suspend fun run(report: JSONObject, maxHandles: Int = 3): JSONObject = withContext(Dispatchers.IO) {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: GTIMCandidateHandleLedgerV21215.toJson(report)
        val handles = jsonStrings(ledger.optJSONArray("allCandidateHandles"))
            .filter { it.startsWith("GSE", true) }
            .distinct()
            .take(maxHandles)
        val results = if (handles.isEmpty()) emptyList() else supervisorScope {
            handles.map { handle -> async { probeOne(handle) } }.awaitAll()
        }
        val executed = JSONArray()
        val queued = JSONArray()
        val blocked = JSONArray()
        if (handles.isEmpty()) blocked.put("no_gse_handle_available_for_background_soft_probe")
        results.forEach { result ->
            if (result.optBoolean("executed", false)) {
                executed.put("${result.optString("handle")}:soft_metadata_probe")
                executed.put("${result.optString("handle")}:gse_srp_mapping")
            } else {
                queued.put("${result.optString("handle")}:retry_soft_metadata_probe_when_network_available")
            }
        }
        JSONObject()
            .put("version", VERSION)
            .put("state", state(results, handles))
            .put("mode", "report_triggered_async_background_workers_bounded_review_only")
            .put("handlesAttempted", JSONArray(handles))
            .put("executedSteps", executed)
            .put("queuedSteps", queued)
            .put("blockedSteps", blocked)
            .put("probeResults", JSONArray(results))
            .put("workerContract", "SOFT/listing metadata and GSE→SRP mapping are attempted automatically during report generation; failures remain queued not manual-only")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val attempted = jsonStrings(obj.optJSONArray("handlesAttempted")).joinToString(", ").ifBlank { "none" }
        return listOf(
            "Background metadata workers",
            "State: ${obj.optString("state", "UNKNOWN")}; attempted=$attempted; mode=${obj.optString("mode", "bounded_review_only")}; injected_results=${injectedCount(obj)}",
            "Executed steps: ${jsonStrings(obj.optJSONArray("executedSteps")).take(6).joinToString(", ").ifBlank { "none" }}.",
            "Queued/blocked: queued=${obj.optJSONArray("queuedSteps")?.length() ?: 0}; blocked=${obj.optJSONArray("blockedSteps")?.length() ?: 0}; claim_limit=${obj.optString("claimLimit", CLAIM_LIMIT)}.",
            "Boundary: metadata/SRP probes prepare appendix-ready sample provenance; they do not prove mechanism, DGE, gene/pathway signal, diagnosis, treatment, or efficacy."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "report_triggered_async_background_workers_bounded_review_only",
        "executedSteps",
        "queuedSteps",
        "SOFT/listing metadata and GSE→SRP mapping are attempted automatically",
        "QUEUED_NETWORK_OR_REMOTE_METADATA_UNAVAILABLE_RESUME_WHEN_ONLINE",
        "offline injected metadata pack",
        "OFFLINE_INJECTED_METADATA_READY_REVIEW_ONLY",
        CLAIM_LIMIT
    ))

    private suspend fun probeOne(handle: String): JSONObject {
        GTIMInjectedMetadataSeedPackV21216.probeResultFor(handle)?.let { return it }
        val url = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=${handle.uppercase(Locale.US)}&targ=self&form=text&view=quick"
        val fetched = fetchWithResume(url)
        if (fetched.isNullOrBlank()) {
            return JSONObject()
                .put("handle", handle.uppercase(Locale.US))
                .put("executed", false)
                .put("probeState", "QUEUED_NETWORK_OR_REMOTE_METADATA_UNAVAILABLE_RESUME_WHEN_ONLINE")
                .put("resumeSuggested", true)
                .put("softUrl", url)
                .put("claimLimit", CLAIM_LIMIT)
        }
        val parsed = GTIMGeoSoftMetadataParserV21215.parse(handle.uppercase(Locale.US), fetched)
        val mapping = GTIMGseSrpMappingWorkerV21215.parse(handle.uppercase(Locale.US), fetched)
        return JSONObject()
            .put("handle", handle.uppercase(Locale.US))
            .put("executed", true)
            .put("probeState", parsed.optString("softProbeState"))
            .put("softUrl", url)
            .put("sampleCount", parsed.optInt("sampleCount", 0))
            .put("comparatorLabelsStatus", parsed.optString("comparatorLabelsStatus"))
            .put("tissueSpeciesStatus", parsed.optString("tissueSpeciesStatus"))
            .put("sampleProvenanceStatus", parsed.optString("sampleProvenanceStatus"))
            .put("matrixOrCapsuleHint", parsed.optString("matrixOrCapsuleHint"))
            .put("softMetadata", parsed)
            .put("gseSrpMapping", mapping)
            .put("claimLimit", CLAIM_LIMIT)
    }

    private fun state(results: List<JSONObject>, handles: List<String>): String = when {
        handles.isEmpty() -> "NO_HANDLE_FOR_BACKGROUND_METADATA_PROBE"
        results.any { it.optBoolean("executed", false) } -> "BACKGROUND_METADATA_PROBE_RESULTS_READY"
        else -> "BACKGROUND_METADATA_PROBE_QUEUED_OR_NETWORK_BLOCKED"
    }

    private fun injectedCount(obj: JSONObject): Int {
        val arr = obj.optJSONArray("probeResults") ?: return 0
        return (0 until arr.length()).count { idx -> arr.optJSONObject(idx)?.optBoolean("offlineInjected", false) == true }
    }

    private suspend fun fetchWithResume(url: String, attempts: Int = 3): String? {
        var backoff = 800L
        repeat(attempts.coerceAtLeast(1)) { attempt ->
            val fetched = withTimeoutOrNull(15_000L) { fetch(url) }
            if (!fetched.isNullOrBlank()) return fetched
            if (attempt < attempts - 1) delay(backoff)
            backoff = (backoff * 2).coerceAtMost(3_500L)
        }
        return null
    }

    private fun fetch(url: String): String? = runCatching {
        val request = Request.Builder()
            .url(url)
            .get()
            .header("User-Agent", "ImmuneErrorRadar/${EngineRuntimeStatus.ACTIVE_ENGINE_VERSION} (MetadataProbe; no-tracking)")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) null else response.body?.string()
        }
    }.getOrNull()

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx ->
        array.optString(idx).takeIf { it.isNotBlank() }
    }
}
