package com.immunesignal.app

// v2.10.8 — Root-cause falsification planner.
// Every upstream/restoration hypothesis must say how it could fail.
object GTIMRootCauseFalsificationPlannerV2108 {
    const val VERSION: String = "2.10.8-root-cause-falsification-planner"

    fun build(candidates: List<GTIMEcoImmuneRootCauseCandidateV2108>): List<GTIMRootCauseFalsificationPlanV2108> {
        return candidates.take(5).mapIndexed { index, candidate ->
            val tests = (candidate.falsificationTests + decisiveTestsFor(candidate)).distinct().take(7)
            val weakening = weakeningSignalsFor(candidate).distinct().take(6)
            val invalidation = "Invalidate or downgrade if topic-compatible evidence fails to show the proposed upstream dysfunction, restoration lever, or immune/metabolic bridge after metadata/capsule/dataset review."
            val planId = "RCF_${index + 1}_${candidate.candidateId}"
            val line = "Root-cause falsification plan: version=$VERSION | id=$planId | candidate=${candidate.candidateId} | tests=${tests.joinToString(";").oneLine()} | weakening=${weakening.joinToString(";").oneLine()} | invalidation=${invalidation.oneLine()}"
            GTIMRootCauseFalsificationPlanV2108(
                planId = planId,
                candidateId = candidate.candidateId,
                decisiveTests = tests,
                weakeningSignals = weakening,
                invalidationRule = invalidation,
                line = line
            )
        }
    }

    private fun decisiveTestsFor(candidate: GTIMEcoImmuneRootCauseCandidateV2108): List<String> = listOf(
        "topic-compatible metadata or capsule confirms relevant comparator group",
        "public expression/metabolite/microbiome source supports the proposed bridge",
        "mechanism remains plausible after population/diet/ecology context adjustment",
        "alternative symptom-level explanation does not fully account for the signal"
    ) + when {
        candidate.candidateId.contains("variant", true) || candidate.candidateId.contains("immune_readiness", true) -> listOf(
            "variant-escape review shows target conservation or broad-response plausibility",
            "mucosal or trained-immunity evidence is relevant to the entry route"
        )
        candidate.candidateId.contains("ecological", true) || candidate.candidateId.contains("microbial", true) -> listOf(
            "microbiome/metabolite deficit is observed or strongly supported",
            "restoration lever maps to a lost function, not only a taxon name"
        )
        else -> emptyList()
    }

    private fun weakeningSignalsFor(candidate: GTIMEcoImmuneRootCauseCandidateV2108): List<String> = listOf(
        "no topic-compatible upstream signal after repeated source review",
        "only symptom suppression evidence exists with no root-chain support",
        "context/ecology modifier contradicts transferability of the analogy"
    ) + candidate.missingEvidence.take(3).map { "missing persists: $it" }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
