package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.13 — Published research utility score.
 *
 * Scores how reusable a paper/GSE/DOI/PMID/GEO handle is for GTIM evidence routing. This
 * is not biological evidence; it decides whether published material is useful as a seed.
 */
object GTIMPublishedResearchUtilityScoreV21213 {
    const val VERSION: String = "2.12.13-published-research-utility-score"
    const val CLAIM_LIMIT: String = "published_research_utility_seed_score_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val text = report.toString()
        val handles = handles(text)
        val topicFit = if (hasDomainRoute(report)) 2 else 1
        val humanSample = if (text.contains("human", true) || text.contains("PBMC", true) || text.contains("blood", true)) 2 else 0
        val comparator = if (text.contains("comparator", true) || text.contains("case/control", true) || text.contains("control", true) || text.contains("severity", true)) 2 else 0
        val dataAvailability = if (handles.length() > 0) 1 else 0
        val matrix = if (text.contains("matrix", true) || text.contains("processed-expression", true) || text.contains("capsule", true)) 1 else 0
        val sampleProvenance = if (text.contains("sample-to-source", true) || text.contains("sample linkage", true) || text.contains("provenance", true)) 1 else 0
        val contradiction = if (text.contains("contradiction", true) || text.contains("falsif", true)) 1 else 0
        val uncappedScore = (topicFit + humanSample + comparator + dataAvailability + matrix + sampleProvenance + contradiction).coerceAtMost(10)
        val consistency = GTIMReportConsistencyGateV2121.build(report, GlobalResearchGradeBriefV11061.renderLines(report))
        val cap = hardCap(report, consistency)
        val score = uncappedScore.coerceAtMost(cap.first)
        return JSONObject()
            .put("version", VERSION)
            .put("state", state(score, handles.length()))
            .put("score", score)
            .put("uncappedScore", uncappedScore)
            .put("maxScore", 10)
            .put("hardCapApplied", cap.first < 10)
            .put("hardCapReasons", JSONArray(cap.second))
            .put("components", JSONObject()
                .put("topicFit", topicFit)
                .put("humanSampleRelevance", humanSample)
                .put("comparatorLabels", comparator)
                .put("dataHandleAvailability", dataAvailability)
                .put("matrixOrCapsuleHint", matrix)
                .put("sampleProvenance", sampleProvenance)
                .put("contradictionResistance", contradiction))
            .put("candidateHandles", handles)
            .put("decision", decision(score))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        return listOf(
            "Published research utility score",
            "Score: ${obj.optInt("score", 0)}/${obj.optInt("maxScore", 10)}; uncapped=${obj.optInt("uncappedScore", obj.optInt("score", 0))}; hard_cap_applied=${obj.optBoolean("hardCapApplied", false)}; state=${obj.optString("state", "UNKNOWN")}; decision=${obj.optString("decision", "background literature only")}",
            "Use: scores reuse value of GSE/PMID/DOI/literature as a seed; it does not upgrade biological evidence.",
            "Boundary: published ≠ validated for this topic until topic-fit, comparator, sample linkage, capsule/matrix, and contradiction gates close."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "Published research utility score",
        "topicFit",
        "humanSampleRelevance",
        "comparatorLabels",
        "background_literature_only",
        "hardCapApplied",
        "verified_capsule_source_count=0_max_score_6",
        CLAIM_LIMIT
    ))


    private fun hardCap(report: JSONObject, consistency: GTIMReportConsistencyGateV2121.TargetConsistency): Pair<Int, List<String>> {
        var cap = 10
        val reasons = mutableListOf<String>()
        fun apply(value: Int, reason: String) {
            if (cap > value) cap = value
            reasons += reason
        }
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val verifiedCapsules = ledger.optInt("verifiedCapsuleSourceCount", consistency.verifiedMatrixFiles)
        if (verifiedCapsules <= 0) apply(6, "verified_capsule_source_count=0_max_score_6")
        if (!consistency.topicCompatibleTargetSelected) apply(7, "topicCompatibleTargetSelected=false_max_score_7")
        val probe = report.optJSONObject("metadataProbeBackgroundWorkersV21215") ?: JSONObject()
        val probeResults = probe.optJSONArray("probeResults") ?: JSONArray()
        val comparatorFound = (0 until probeResults.length()).any { idx ->
            probeResults.optJSONObject(idx)?.optString("comparatorLabelsStatus").orEmpty().contains("found", true)
        }
        val provenanceFound = (0 until probeResults.length()).any { idx ->
            probeResults.optJSONObject(idx)?.optString("sampleProvenanceStatus").orEmpty().contains("found", true)
        }
        if (probeResults.length() == 0 || !comparatorFound) apply(6, "comparator_labels_missing_or_not_executed_max_score_6")
        if (probeResults.length() == 0 || !provenanceFound) apply(6, "sample_linkage_missing_or_not_executed_max_score_6")
        return cap to reasons.distinct()
    }

    private fun hasDomainRoute(report: JSONObject): Boolean = report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainKey").orEmpty().isNotBlank()
        || report.toString().contains("domain_specific_route", true)

    private fun state(score: Int, handleCount: Int): String = when {
        score >= 8 -> "HIGH_UTILITY_SEED_REVIEW_TARGET_NOT_EVIDENCE"
        score >= 6 -> "MODERATE_UTILITY_SEED_NEEDS_METADATA_CLOSURE"
        score >= 4 && handleCount > 0 -> "WEAK_UTILITY_HANDLE_NEEDS_REVIEW"
        else -> "BACKGROUND_LITERATURE_ONLY"
    }

    private fun decision(score: Int): String = when {
        score >= 8 -> "promote_to_review_target_if_claim_guards_pass"
        score >= 6 -> "keep_as_metadata_seed_candidate"
        score >= 4 -> "hold_for_manual_review_only"
        else -> "background_literature_only"
    }

    private fun handles(text: String): JSONArray {
        val out = JSONArray()
        Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|SRR\\d+|PRJNA\\d+|PRJEB\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+|PMID:?\\d+|10\\.\\d{4,9}/[^\\s\\\"']+)\\b", RegexOption.IGNORE_CASE)
            .findAll(text).map { it.value.uppercase() }.distinct().take(12).forEach { out.put(it) }
        return out
    }
}
