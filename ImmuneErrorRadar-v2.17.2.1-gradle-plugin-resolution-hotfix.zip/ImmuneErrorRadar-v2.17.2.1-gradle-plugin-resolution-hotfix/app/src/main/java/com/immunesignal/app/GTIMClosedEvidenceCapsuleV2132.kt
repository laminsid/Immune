package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.2 — Closed evidence capsule from verified metadata closure. */
object GTIMClosedEvidenceCapsuleV2132 {
    const val VERSION: String = "2.13.2-closed-evidence-capsule"
    const val CLAIM_LIMIT: String = "closed_capsule_study_readiness_not_dge_or_mechanism_proof"

    fun toJson(report: JSONObject): JSONObject {
        val closure = report.optJSONObject("verifiedMetadataClosurePackV2132") ?: GTIMVerifiedMetadataClosurePackV2132.toJson(report)
        val selected = closure.optString("selectedClosedTarget")
        val comparator = closure.optBoolean("comparatorClosed", false)
        val sample = closure.optBoolean("sampleProvenanceClosed", false)
        val tissue = closure.optBoolean("tissueSpeciesClosed", false)
        val matrix = closure.optBoolean("matrixOrCapsuleRoutable", false)
        val contradiction = (report.optJSONObject("contradictionSearchEngineV21218")?.optString("state") ?: "").ifBlank { "CONTRADICTION_REVIEW_REQUIRED" }
        val score = listOf(if (selected.isNotBlank()) 2 else 0, if (comparator) 2 else 0, if (sample) 2 else 0, if (tissue) 1 else 0, if (matrix) 2 else 0, 1).sum().coerceAtMost(10)
        val state = when {
            score >= 9 -> "CLOSED_STUDY_READINESS_CAPSULE_REVIEW_READY"
            score >= 7 -> "MOSTLY_CLOSED_CAPSULE_REQUIRES_REVIEW"
            score >= 5 -> "PARTIAL_CLOSED_CAPSULE"
            else -> "CAPSULE_NOT_CLOSED"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("selectedClosedTarget", selected)
            .put("capsuleScore", score)
            .put("metadataClosed", selected.isNotBlank())
            .put("comparatorClosed", comparator)
            .put("sampleProvenanceClosed", sample)
            .put("tissueSpeciesClosed", tissue)
            .put("matrixOrCapsuleRoutable", matrix)
            .put("contradictionState", contradiction)
            .put("upgradeAllowed", false)
            .put("fields", JSONArray(listOf("handle", "domain", "sample_groups", "comparator", "sample_provenance", "human_animal_invitro_separation", "matrix_or_capsule_route", "contradiction", "next_experiment")))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Closed evidence capsule",
        "State: ${obj.optString("state", "UNKNOWN")}; selected=${obj.optString("selectedClosedTarget", "none")}; capsule_score=${obj.optInt("capsuleScore", 0)}/10; upgrade_allowed=${obj.optBoolean("upgradeAllowed", false)}.",
        "Closed gates: metadata=${obj.optBoolean("metadataClosed", false)}; comparator=${obj.optBoolean("comparatorClosed", false)}; sample_provenance=${obj.optBoolean("sampleProvenanceClosed", false)}; tissue/species=${obj.optBoolean("tissueSpeciesClosed", false)}; matrix/capsule_route=${obj.optBoolean("matrixOrCapsuleRoutable", false)}.",
        "Contradiction: ${obj.optString("contradictionState", "CONTRADICTION_REVIEW_REQUIRED")}",
        "Boundary: this is a study-readiness capsule. It still cannot prove DGE, mechanism, diagnosis, treatment, dosing, or efficacy."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "CLOSED_STUDY_READINESS_CAPSULE_REVIEW_READY", "sampleProvenanceClosed", CLAIM_LIMIT))
}
