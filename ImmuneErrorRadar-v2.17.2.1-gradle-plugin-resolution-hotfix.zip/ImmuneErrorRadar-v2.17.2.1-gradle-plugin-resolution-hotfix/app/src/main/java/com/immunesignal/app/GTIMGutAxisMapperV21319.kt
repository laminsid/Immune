package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Classifies gut-organ axis hypotheses without turning them into causes or treatments. */
object GTIMGutAxisMapperV21319 {
    const val VERSION: String = "2.13.19-gut-axis-mapper"
    const val CLAIM_LIMIT: String = "gut_axis_hypothesis_not_causal_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val axes = mutableListOf<String>()
        if (active.contains("covid") || active.contains("hantavirus") || active.contains("filovirus")) axes += "gut_lung"
        if (active.contains("allergy")) axes += listOf("gut_skin", "gut_lung")
        if (active.contains("cancer")) axes += "gut_tumor"
        if (active.contains("diabetes") || active.contains("immune_age")) axes += "gut_metabolic"
        if (axes.isEmpty()) axes += "gut_immune_general"
        return JSONObject()
            .put("version", VERSION)
            .put("state", "GUT_AXIS_MAPPING_READY")
            .put("gut_axes", JSONArray(axes))
            .put("claim_limit", CLAIM_LIMIT)
    }
}
