package com.immunesignal.app

/** v2.10.1 — mandatory not-yet-validated statement guard. */
object GTIMAuthorityValidationStatementGuardV2101 {
    const val VERSION: String = "2.10.1-authority-validation-statement-guard"
    const val GLOBAL_NOT_YET_VALIDATED: String = "Any GTIM-generated or imported exploratory idea is not tested, approved, or validated by competent clinical/regulatory/professional authorities unless an explicit external validated source says so."

    fun build(
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        routes: List<GTIMTherapeuticRouteCardV2100>
    ): List<GTIMAuthorityValidationStatementV2101> {
        val statements = mutableListOf<GTIMAuthorityValidationStatementV2101>()
        discovery.forEach { finding ->
            statements += statement(
                id = "AUTH_DISCOVERY_${finding.findingId}",
                objectId = finding.findingId,
                validation = finding.validationStatus,
                required = listOf("independent source verification", "method/provenance review", "authority or peer review where applicable", "contradiction search"),
                text = "$GLOBAL_NOT_YET_VALIDATED Discovery=${finding.findingId}; next=${finding.requiredNextEvidence}."
            )
        }
        routes.forEach { route ->
            statements += statement(
                id = "AUTH_ROUTE_${route.routeId}",
                objectId = route.routeId,
                validation = route.validationStatus,
                required = route.requiredBiomarkersOrEvidence + listOf("clinical or preclinical validation appropriate to route", "safety review", "no patient-specific translation"),
                text = "$GLOBAL_NOT_YET_VALIDATED Route=${route.routeId}; forbidden=${route.forbiddenClaims.joinToString(", ")}."
            )
        }
        if (statements.isEmpty()) {
            statements += statement(
                id = "AUTH_NO_DISCOVERY_ROUTE",
                objectId = "NO_DISCOVERY_OR_ROUTE",
                validation = "NOT_EVALUATED",
                required = listOf("run dossier builder with target-compatible evidence"),
                text = GLOBAL_NOT_YET_VALIDATED
            )
        }
        return statements.distinctBy { it.statementId }.take(12)
    }

    private fun statement(
        id: String,
        objectId: String,
        validation: String,
        required: List<String>,
        text: String
    ): GTIMAuthorityValidationStatementV2101 {
        val line = "Authority validation: id=$id | object=$objectId | validation=$validation | required=${required.distinct().joinToString(", ")} | statement=${text.oneLine()}"
        return GTIMAuthorityValidationStatementV2101(
            statementId = id,
            discoveryOrRouteId = objectId,
            validationStatus = validation,
            requiredValidation = required.distinct(),
            notYetValidatedStatement = text.oneLine(),
            line = line
        )
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
