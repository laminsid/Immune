package com.immunesignal.app

/**
 * v2.7.9.0 — Therapeutic Reverse-Translation Axis Catalog.
 *
 * Safe, research-only disease-to-therapeutic-axis mapping. It does not encode
 * treatment protocols, dose choices, vaccine design instructions, pathogen engineering,
 * or efficacy claims. The catalog only converts a disease/outbreak context into the
 * data requirements needed to test a therapeutic hypothesis through the existing
 * v2.7.8 ETL/DGE readiness spine.
 */
data class GTIMTherapeuticAxisDefinitionV2790(
    val laneId: String,
    val displayName: String,
    val triggers: List<String>,
    val diseaseFamilies: Set<GTIMDiseaseFamilyV2740>,
    val anchors: Set<GTIMPrimaryAnchorV2740>,
    val therapeuticAxis: String,
    val interventionClasses: List<String>,
    val resistanceFailureModes: List<String>,
    val requiredComparators: List<String>,
    val requiredAssays: List<String>,
    val requiredMetadataFields: List<String>,
    val claimLimit: String
)

object GTIMTherapeuticAxisCatalogV2790 {
    const val VERSION: String = "2.7.9.0-therapeutic-axis-catalog"

    val lanes: List<GTIMTherapeuticAxisDefinitionV2790> = listOf(
        GTIMTherapeuticAxisDefinitionV2790(
            laneId = "EBOLA_HOST_RESPONSE_REVERSE_TRANSLATION",
            displayName = "Ebola/Bundibugyo host-response therapeutic routing",
            triggers = listOf("ebola", "bundibugyo", "hemorrhagic", "haemorrhagic", "viral hemorrhagic fever", "evd"),
            diseaseFamilies = setOf(GTIMDiseaseFamilyV2740.HEMORRHAGIC_VIRAL, GTIMDiseaseFamilyV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE),
            anchors = setOf(GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL),
            therapeuticAxis = "host-response/endothelial-coagulation axis; survivor-vs-fatal and early-vs-late immune injury signatures",
            interventionClasses = listOf("antiviral/countermeasure evidence review", "monoclonal-antibody evidence review", "vaccine-gap countermeasure review", "supportive-care-linked immune marker review"),
            resistanceFailureModes = listOf("strain/lineage evidence gap", "antibody escape or coverage gap", "endothelial leakage persistence", "coagulation-inflammatory injury", "survivor/fatal comparator missing"),
            requiredComparators = listOf("survivor_vs_fatal", "mild_or_recovered_vs_severe", "early_vs_late_infection", "exposed_or_control_vs_case"),
            requiredAssays = listOf("RNA-seq", "single-cell RNA-seq", "proteomics", "cytokine panel", "PBMC/blood host-response"),
            requiredMetadataFields = listOf("virus_strain", "day_post_symptom_or_sampling_time", "outcome", "viral_load_or_case_status", "coagulation_or_endothelial_marker", "treatment_or_countermeasure_exposure"),
            claimLimit = "research_route_only_no_countermeasure_or_treatment_claim"
        ),
        GTIMTherapeuticAxisDefinitionV2790(
            laneId = "HANTA_ENDOTHELIAL_LEAK_REVERSE_TRANSLATION",
            displayName = "Hanta/Andes endothelial-leak therapeutic routing",
            triggers = listOf("hanta", "hantavirus", "andes", "pulmonary syndrome", "vascular leak", "endothelial barrier"),
            diseaseFamilies = setOf(GTIMDiseaseFamilyV2740.VECTOR_BORNE_OR_ZOONOTIC, GTIMDiseaseFamilyV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE),
            anchors = setOf(GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL),
            therapeuticAxis = "pulmonary vascular leak/endothelial barrier injury axis; mild-vs-severe or survivor-vs-fatal host-response signatures",
            interventionClasses = listOf("antiviral/countermeasure evidence review", "endothelial-barrier injury marker review", "supportive-care-linked immune marker review", "neutralizing antibody evidence review"),
            resistanceFailureModes = listOf("severity-label gap", "vascular leakage signal not separated from generic inflammation", "small-outbreak sample scarcity", "supportive-care confounding"),
            requiredComparators = listOf("mild_vs_severe", "survivor_vs_fatal", "acute_vs_recovered", "case_vs_control"),
            requiredAssays = listOf("RNA-seq", "single-cell RNA-seq", "cytokine panel", "endothelial injury markers", "blood/PBMC host-response"),
            requiredMetadataFields = listOf("virus_or_lineage", "severity", "pulmonary_status", "outcome", "sampling_time", "supportive_care_context"),
            claimLimit = "research_route_only_no_antiviral_or_supportive_care_claim"
        ),
        GTIMTherapeuticAxisDefinitionV2790(
            laneId = "DIABETES_METABOLIC_IMMUNE_REVERSE_TRANSLATION",
            displayName = "Diabetes metabolic-immune therapeutic routing",
            triggers = listOf("diabetes", "t1d", "t2d", "insulin", "beta cell", "beta-cell", "glp-1", "incretin", "metabolic inflammation", "insulin resistance"),
            diseaseFamilies = setOf(GTIMDiseaseFamilyV2740.METABOLIC_INFLAMMATION, GTIMDiseaseFamilyV2740.BETA_CELL_AUTOIMMUNE, GTIMDiseaseFamilyV2740.OBESITY_METABOLIC_INFLAMMATION),
            anchors = setOf(GTIMPrimaryAnchorV2740.DIABETES_METABOLIC_INFLAMMATION, GTIMPrimaryAnchorV2740.T2D_INSULIN_RESISTANCE_INFLAMMATION, GTIMPrimaryAnchorV2740.T1D_AUTOIMMUNE_BETA_CELL, GTIMPrimaryAnchorV2740.OBESITY_METABOLIC_INFLAMMATION),
            therapeuticAxis = "metabolic inflammation/beta-cell stress/insulin-resistance/incretin-microbiome axis; response-vs-non-response dataset requirements",
            interventionClasses = listOf("metabolic drug class review", "incretin/GLP-1 axis evidence review", "beta-cell preservation evidence review", "microbiome-metabolic inflammation review"),
            resistanceFailureModes = listOf("insulin resistance persistence", "beta-cell loss", "non-responder phenotype", "weight/metabolic confounding", "microbiome response heterogeneity"),
            requiredComparators = listOf("diabetes_vs_healthy_control", "treated_vs_untreated", "responder_vs_non_responder", "baseline_vs_followup", "insulin_resistant_vs_sensitive"),
            requiredAssays = listOf("bulk RNA-seq", "single-cell RNA-seq", "islet/adipose/blood expression", "metabolomics", "microbiome + immune marker dataset"),
            requiredMetadataFields = listOf("diabetes_type", "treatment_exposure", "HbA1c_or_glucose_marker", "BMI_or_weight_context", "insulin_status", "timepoint", "responder_label"),
            claimLimit = "research_route_only_no_diabetes_treatment_or_injection_replacement_claim"
        ),
        GTIMTherapeuticAxisDefinitionV2790(
            laneId = "CANCER_IMMUNOTHERAPY_RESPONSE_REVERSE_TRANSLATION",
            displayName = "Cancer immunotherapy response/resistance routing",
            triggers = listOf("cancer", "tumor", "tumour", "oncology", "immunotherapy", "pd-1", "pd-l1", "ctla-4", "car-t", "t cell exhaustion", "non-responder", "checkpoint"),
            diseaseFamilies = setOf(GTIMDiseaseFamilyV2740.CANCER_IMMUNE),
            anchors = setOf(GTIMPrimaryAnchorV2740.CANCER_IMMUNE),
            therapeuticAxis = "tumor microenvironment/immunotherapy response-resistance axis; responder-vs-non-responder evidence requirements",
            interventionClasses = listOf("immune-checkpoint response review", "CAR-T/TIL response review", "tumor microenvironment evidence review", "immune-related adverse-event marker review"),
            resistanceFailureModes = listOf("T-cell exhaustion", "myeloid suppression", "antigen presentation loss", "cold tumor state", "immune-related adverse event confounding", "non-responder label missing"),
            requiredComparators = listOf("responder_vs_non_responder", "treated_vs_untreated", "baseline_vs_on_treatment", "hot_vs_cold_tumor", "irAE_vs_no_irAE"),
            requiredAssays = listOf("single-cell RNA-seq", "spatial transcriptomics", "bulk RNA-seq", "TCR-seq", "tumor microenvironment profiling"),
            requiredMetadataFields = listOf("cancer_type", "therapy_class", "response_label", "timepoint", "tumor_site", "immune_cell_annotation", "adverse_event_context"),
            claimLimit = "research_route_only_no_cancer_cure_or_therapy_claim"
        ),
        GTIMTherapeuticAxisDefinitionV2790(
            laneId = "GENERAL_THERAPEUTIC_REVERSE_TRANSLATION",
            displayName = "General therapeutic reverse-translation routing",
            triggers = listOf("drug", "therapy", "treatment", "vaccine", "trial", "resistance", "response", "non-responder", "antibody", "intervention"),
            diseaseFamilies = emptySet(),
            anchors = emptySet(),
            therapeuticAxis = "disease mechanism -> intervention class -> response/resistance evidence -> dataset requirements",
            interventionClasses = listOf("drug class evidence review", "clinical trial evidence review", "vaccine/countermeasure review", "response-resistance marker review"),
            resistanceFailureModes = listOf("non-responder phenotype", "adverse immune activation", "confounding comparator", "missing intervention metadata"),
            requiredComparators = listOf("case_vs_control", "treated_vs_untreated", "responder_vs_non_responder", "baseline_vs_followup"),
            requiredAssays = listOf("RNA-seq", "single-cell RNA-seq", "proteomics", "clinical metadata table"),
            requiredMetadataFields = listOf("intervention", "comparator", "outcome", "timepoint", "tissue", "safety_context"),
            claimLimit = "research_route_only_no_treatment_advice"
        )
    )

    fun select(contract: GTIMRunDecisionContractV2740, extraText: String = ""): GTIMTherapeuticAxisDefinitionV2790 {
        val context = normalize(listOf(
            contract.rawQuery,
            contract.normalizedQuery,
            contract.primaryAnchor.routeId,
            contract.diseaseFamily.name,
            contract.secondaryDomains.joinToString(" ") { it.name },
            contract.discoveryBridges.joinToString(" ") { it.routeId },
            extraText
        ).joinToString(" "))

        return lanes.firstOrNull { lane -> contract.primaryAnchor in lane.anchors } ?: lanes.firstOrNull { lane -> contract.diseaseFamily in lane.diseaseFamilies } ?: lanes.firstOrNull { lane -> lane.triggers.any { context.contains(normalize(it)) } } ?: lanes.last()
    }

    private fun normalize(value: String): String = value.lowercase()
        .replace('_', ' ')
        .replace('-', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()
}
