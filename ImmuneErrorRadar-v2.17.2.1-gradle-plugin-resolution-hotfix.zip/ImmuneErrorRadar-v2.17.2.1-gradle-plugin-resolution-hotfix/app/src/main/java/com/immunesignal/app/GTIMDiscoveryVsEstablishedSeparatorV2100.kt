package com.immunesignal.app

// legacy_v2100_audit_marker: 2.10.0-medical-research-dossier

/** v2.10.0 — Discovery vs established separator.
 * Converts ETL/metadata/capsule status into explicit GTIM discovery cards. These
 * cards never override established science and never become clinical claims.
 */
object GTIMDiscoveryVsEstablishedSeparatorV2100 {
    const val VERSION: String = "2.10.0-discovery-established-separator"

    fun build(
        targetId: String,
        metadataBridge: GTIMMetadataFirstObservedEvidenceBridgeReportV2950?,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): List<GTIMDiscoveryFindingCardV2100> {
        val cards = mutableListOf<GTIMDiscoveryFindingCardV2100>()
        if (metadataBridge == null) {
            cards += card("DISCOVERY_NO_BRIDGE", "metadata_bridge", "GTIM did not receive the metadata-first bridge context.", "NO_DISCOVERY_CONTEXT", "NOT_VALIDATED", "Run target gate and metadata-first bridge before dossier export.")
            return cards
        }
        cards += card(
            id = "DISCOVERY_TARGET_ETL_STATE",
            source = "actual_etl",
            finding = "GTIM selected target=$targetId and DGE state=${dgeVerdict.verdict}; this is an execution-readiness state, not a biological result.",
            evidence = dgeVerdict.verdict,
            validation = "REVIEW_ONLY_EXECUTION_STATE",
            next = "Close observed file, metadata, comparator and sample-linkage gates before any gene/pathway statement."
        )
        cards += card(
            id = "DISCOVERY_METADATA_FIRST_STATE",
            source = "metadata_first_bridge",
            finding = "SOFT=${metadataBridge.softProbe.state}, GSE→SRP=${metadataBridge.gseToSrpMapping.state}, external=${metadataBridge.externalAvailability.state}, public_routes=${metadataBridge.publicExpressionSources?.state ?: "NOT_EVALUATED"}.",
            evidence = metadataBridge.state,
            validation = "DISCOVERY_METADATA_OR_ROUTE_ONLY",
            next = "Use source fields, snippets, SRP mapping and request plan to create reviewable evidence capsules."
        )
        metadataBridge.externalEvidenceCapsule?.let { capsule ->
            val payload = "capsule=${capsule.state}, genes=${capsule.topGenes.size}, pathways=${capsule.pathways.size}, provenance=${capsule.provenanceHashes.size}"
            cards += card(
                id = "DISCOVERY_EXTERNAL_CAPSULE_STATE",
                source = "external_evidence_capsule",
                finding = payload,
                evidence = capsule.state,
                validation = "GTIM_DISCOVERY_NOT_VALIDATED_BY_REGULATORY_OR_CLINICAL_AUTHORITY",
                next = "Verify contrast, method, provenance hashes and independent validation before using this as scientific evidence."
            )
        }
        metadataBridge.publicExpressionRequestPlan?.let { plan ->
            cards += card(
                id = "DISCOVERY_PUBLIC_REQUEST_PLAN",
                source = "public_expression_request_plan",
                finding = "Public-expression request plan state=${plan.state}; candidates=${plan.requests.size}; no automatic HTTP execution.",
                evidence = plan.state,
                validation = "REQUEST_PLAN_ONLY_NOT_DATA_RESULT",
                next = "Execute externally or through approved connector, then import a validated evidence capsule."
            )
        }
        metadataBridge.learningCacheExport?.let { cache ->
            cards += card(
                id = "DISCOVERY_LEARNING_CACHE_EXPORT",
                source = "learning_cache_export",
                finding = "Learning cache export=${cache.state}; fields=${cache.tables.joinToString(", ")}; operational memory only.",
                evidence = cache.state,
                validation = "OPERATIONAL_MEMORY_NOT_MEDICAL_TRUTH",
                next = "Reuse only as route memory; never as established medical evidence."
            )
        }
        return cards.distinctBy { it.findingId }.take(8)
    }

    private fun card(id: String, source: String, finding: String, evidence: String, validation: String, next: String): GTIMDiscoveryFindingCardV2100 {
        val line = "GTIM discovery: id=$id | source=$source | evidence_state=$evidence | validation=$validation | finding=${finding.oneLine()} | next=${next.oneLine()}"
        return GTIMDiscoveryFindingCardV2100(id, source, finding, evidence, validation, next, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
