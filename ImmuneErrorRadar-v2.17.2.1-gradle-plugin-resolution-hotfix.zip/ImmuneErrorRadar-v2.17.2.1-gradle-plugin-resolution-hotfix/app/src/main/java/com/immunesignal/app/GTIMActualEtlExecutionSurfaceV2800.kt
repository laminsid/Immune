package com.immunesignal.app

/** v2.8.0 rendering surface
 * compatibility token: ObservedFileEvidenceContractV2801 for the split actual ETL execution modules. */
object GTIMActualEtlExecutionSurfaceV2800 {
    const val VERSION: String = "2.8.0-actual-etl-execution-surface"

    fun buildLines(report: GTIMActualEtlExecutionReportV2800, maxLine: Int = 420): List<String> {
        if (!report.active) return emptyList()
        val finalRun = GTIMActualEtlFinalRunContractV2803.build(report)
        return listOf(
            GTIMUnifiedReleaseSurfaceV2804.summaryLine(report.state),
            report.finalLine,
            finalRun.summaryLine,
            finalRun.executionOrderLine,
            finalRun.stopRuleLine,
            report.fileDiscovery.fileDiscoveryLine,
            report.fileDiscovery.downloadRequestLine,
            report.observedFileEvidence.observedFileLine,
            report.supplementaryFileDiscovery.line,
            report.matrixFileClassifier.line,
            report.matrixReader.matrixReaderLine,
            report.metadataCleaner.metadataCleanerLine,
            report.sampleMetadataExtraction.line,
            report.caseControlLabelSuggestions.line,
            report.sampleLinkage.sampleLinkageLine,
            report.sampleIdLinkageVerification.line,
            report.dge.dgeLine,
            report.dgeReadinessVerdict.line,
            report.genePathway.genePathwayLine,
            finalRun.boundaryLine,
            report.boundaryLine
        ).map { clip(it, maxLine) }
    }

    private fun clip(value: String, max: Int): String {
        val oneLine = value.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1).trimEnd() + "…"
    }
}
