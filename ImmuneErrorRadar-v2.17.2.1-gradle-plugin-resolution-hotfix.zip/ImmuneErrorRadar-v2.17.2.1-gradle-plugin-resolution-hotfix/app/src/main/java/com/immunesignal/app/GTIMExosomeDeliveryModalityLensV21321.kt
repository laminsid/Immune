package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Exosome delivery/cell-free modality research lens. */
object GTIMExosomeDeliveryModalityLensV21321 {
    const val VERSION: String = "2.13.21-exosome-delivery-modality-lens"
    const val STATE_READY: String = "EXOSOME_DELIVERY_MODALITY_LENS_READY"
    const val CLAIM_LIMIT: String = "exosome_delivery_is_modality_lens_not_therapy_or_BBB_safety_claim"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("modalities", JSONArray(listOf("cell_free_EV_therapy_research", "engineered_exosome_delivery", "BBB_delivery_hypothesis", "immune_cargo_reprogramming_lens")))
        .put("therapy_claim_allowed", false)
        .put("BBB_safety_claim_allowed", false)
        .put("patient_action_allowed", false)
        .put("claim_limit", CLAIM_LIMIT)
}
