package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Compact first-surface card for local processed capsules. */
object GTIMCapsuleSurfaceCardV21316 {
    const val VERSION: String = "2.13.16-capsule-surface-card"

    fun renderLines(report: JSONObject): List<String> {
        val route = GTIMCapsuleInjectionRouterV21316.route(report)
        val capsule = route.executableCapsule
        val target = capsule?.accession ?: "not_selected"
        val modules = capsule?.modules?.joinToString(", ") { it.name }.orEmpty().ifBlank { "capsule acquisition required" }
        return listOf(
            "Local processed capsule card",
            "State: ${route.matrixState.name}; target=$target; preview=${route.previewStrength}.",
            "Injected priority disease family: ${capsule?.diseaseFamily ?: "none_yet"}; domain=${capsule?.domain ?: GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)}.",
            "Immediate modules: $modules",
            "C2/C3 sandbox preview: ALLOWED; missing capsule/matrix/replication are execution or acquisition tasks only.",
            "Claim limit: processed capsule supports hypothesis generation only; no validated proof, clinical action, treatment, dosing, vaccine, or efficacy claim."
        )
    }

    fun toJson(report: JSONObject): JSONObject = GTIMCapsuleInjectionRouterV21316.routeJson(report)
        .put("surface_version", VERSION)
        .put("priority_diseases", JSONArray(listOf("inflammation", "rheumatism", "allergy", "cancer", "ebola", "hiv_aids", "covid", "diabetes", "hantavirus")))

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "Local processed capsule card",
        "C2/C3 sandbox preview: ALLOWED",
        "inflammation",
        "rheumatism",
        "allergy",
        "cancer",
        "ebola",
        "hiv_aids",
        "covid",
        "diabetes",
        "hantavirus"
    ))
}
