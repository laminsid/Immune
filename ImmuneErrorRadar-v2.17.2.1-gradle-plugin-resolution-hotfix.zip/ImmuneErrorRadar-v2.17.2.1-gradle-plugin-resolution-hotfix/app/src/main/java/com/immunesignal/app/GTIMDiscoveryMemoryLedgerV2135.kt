package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.5 — Discovery memory ledger.
 * Stores what the engine tried, why it is only a candidate, and what would upgrade/kill it.
 */
object GTIMDiscoveryMemoryLedgerV2135 {
    const val VERSION: String = "2.13.5-discovery-memory-ledger"
    const val CLAIM_LIMIT: String = "memory_ledger_learning_not_biological_proof"

    fun toJson(report: JSONObject): JSONObject {
        val candidate = report.optJSONObject("discoveryCandidateAssemblerV2135")?.optJSONObject("candidate") ?: JSONObject()
        val entry = JSONObject()
            .put("domain", candidate.optString("domain"))
            .put("canonicalTarget", candidate.optString("canonicalTarget"))
            .put("claimCandidate", candidate.optString("claimCandidate"))
            .put("discoveryLevel", candidate.optString("discoveryLevel"))
            .put("failedOrOpenGates", JSONArray(listOf("DGE_or_module_score", "replication", "negative_control", "confounder_guard", "external_review")))
            .put("reusePolicy", "reuse only as same-domain candidate; never as proof")
        return JSONObject()
            .put("version", VERSION)
            .put("state", "DISCOVERY_MEMORY_LEDGER_READY")
            .put("entries", JSONArray(listOf(entry)))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val entries = obj.optJSONArray("entries") ?: JSONArray()
        val first = entries.optJSONObject(0) ?: JSONObject()
        return listOf(
            "Discovery memory ledger",
            "State: ${obj.optString("state", "UNKNOWN")}; entries=${entries.length()}; last_level=${first.optString("discoveryLevel", "none")}; target=${first.optString("canonicalTarget", "none")}",
            "Reuse policy: ${first.optString("reusePolicy", "same-domain candidate only")}",
            "Boundary: ledger prevents repeated weak claims; it does not validate biology."
        )
    }
}
