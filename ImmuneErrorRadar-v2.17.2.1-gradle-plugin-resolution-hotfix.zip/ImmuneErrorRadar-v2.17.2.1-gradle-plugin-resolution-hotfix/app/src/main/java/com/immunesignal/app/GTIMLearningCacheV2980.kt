package com.immunesignal.app

import java.util.Locale

object GTIMLearningCacheV2980 {
    const val VERSION: String = "2.9.8-learning-cache-route-memory"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        targetId: String,
        soft: GTIMSoftMetadataProbeReportV2950,
        mapping: GTIMGseToSrpMappingReportV2950,
        publicSources: GTIMPublicExpressionSourceRegistryReportV2980,
        capsule: GTIMExternalEvidenceCapsuleImportReportV2980
    ): GTIMLearningCacheReportV2980 {
        val target = GTIMAccessionIdValidityGuardV2753.canonical(targetId)
        val blocked = soft.state.contains("BLOCKED_NO_TOPIC", true) || target.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true)
        val reusable = !blocked && (
            publicSources.state == "PUBLIC_EXPRESSION_ROUTE_AVAILABLE_REVIEW_ONLY" ||
                capsule.state == "CAPSULE_EXTERNAL_DGE_SUMMARY_AVAILABLE" ||
                capsule.state == "CAPSULE_PATHWAY_SUMMARY_AVAILABLE" ||
                soft.state == "GEO_SOFT_METADATA_PARSED_REVIEW_ONLY"
            )
        val fields = mutableListOf<String>()
        if (soft.sampleRows.isNotEmpty()) fields += "soft_sample_rows"
        if (soft.supplementaryFiles.isNotEmpty()) fields += "soft_supplementary_refs"
        if (mapping.srpAccessions.isNotEmpty()) fields += "gse_srp_mapping"
        if (publicSources.preferredRoute != "none") fields += "public_expression_preferred_route"
        if (capsule.topGenes.isNotEmpty()) fields += "capsule_top_genes"
        if (capsule.pathways.isNotEmpty()) fields += "capsule_pathways"
        val state = when {
            blocked -> "LEARNING_CACHE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"
            reusable -> "LEARNING_CACHE_RECORD_READY_FOR_LOCAL_REUSE"
            fields.isNotEmpty() -> "LEARNING_CACHE_RECORD_REVIEW_ONLY"
            else -> "LEARNING_CACHE_NOTHING_TO_STORE"
        }
        val limit = when {
            blocked -> "topic_compatible_target_required"
            capsule.blockers.isNotEmpty() -> capsule.blockers.joinToString(",")
            publicSources.state.contains("REQUIRE", true) -> "public_source_route_requires_metadata_or_mapping"
            else -> "claim_limited_route_memory_only"
        }
        val record = GTIMLearningCacheRecordV2980(
            queryKey = queryKey(contract),
            targetId = target,
            routeState = state,
            acceptedForReuse = reusable,
            rejectionOrLimit = limit,
            storedFields = fields.distinct()
        )
        val line = "Learning cache: version=$VERSION | state=$state | target=$target | query_key=${record.queryKey} | reusable=$reusable | stored=${record.storedFields.ifEmpty { listOf("none") }.joinToString(",")} | limit=$limit | cache_is_operational_memory_not_medical_truth=true"
        return GTIMLearningCacheReportV2980(
            active = true,
            targetId = target,
            state = state,
            record = record,
            line = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Learning cache boundary: stores route outcomes, mappings, source availability, and capsule summaries for later reuse; it does not store raw matrices or assert medical truth."
        )
    }

    private fun queryKey(contract: GTIMRunDecisionContractV2740): String {
        val text = (listOf(
            contract.rawQuery,
            contract.normalizedQuery,
            contract.primaryAnchor.name,
            contract.diseaseFamily.name
        ) + contract.secondaryDomains.map { it.name })
            .joinToString(" ")
            .lowercase(Locale.US)
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
        return if (text.isBlank()) "blank_autonomous" else text.split(Regex("\\s+")).take(10).joinToString("_")
    }
}
