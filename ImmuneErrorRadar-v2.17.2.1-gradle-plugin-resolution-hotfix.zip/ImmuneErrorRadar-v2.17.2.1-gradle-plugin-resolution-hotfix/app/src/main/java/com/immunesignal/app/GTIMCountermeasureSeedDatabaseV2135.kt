package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** v2.13.5 — Clean lightweight local countermeasure seed database.
 * Drugs/vaccines are lookup priors only. They help compare immune-route hypotheses with
 * known intervention classes; they never create treatment advice, dosing, efficacy, or
 * clinical recommendations.
 */
object GTIMCountermeasureSeedDatabaseV2135 {
    const val VERSION: String = "2.13.5-clean-countermeasure-seed-database"
    const val CLAIM_LIMIT: String = "countermeasure_seed_lookup_only_not_medical_advice"

    private data class Seed(
        val id: String,
        val name: String,
        val category: String,
        val condition: String,
        val targetOrMechanism: String,
        val evidenceUse: String,
        val routeDomains: List<String>,
        val boundary: String
    )

    private val seeds = listOf(
        Seed("covid_tx_paxlovid", "Paxlovid / nirmatrelvir-ritonavir", "antiviral_drug", "COVID-19", "SARS-CoV-2 protease antiviral class", "known-countermeasure context for viral replication vs host-response separation", listOf("viral_interferon_cytokine"), "no treatment recommendation"),
        Seed("covid_tx_veklury", "Veklury / remdesivir", "antiviral_drug", "COVID-19", "viral RNA polymerase antiviral class", "known-countermeasure context for antiviral vs immune-persistence hypotheses", listOf("viral_interferon_cytokine", "filovirus_viral_host_response"), "no treatment recommendation"),
        Seed("covid_tx_lagevrio", "Lagevrio / molnupiravir", "antiviral_drug", "COVID-19", "viral mutagenesis antiviral class", "known-countermeasure context only", listOf("viral_interferon_cytokine"), "authorization/label status must be checked externally"),
        Seed("covid_immune_tocilizumab", "Actemra / tocilizumab", "immune_modulator", "COVID-19 inflammatory disease context", "IL-6 receptor blockade", "immune-module comparator for IL-6 route hypotheses", listOf("viral_interferon_cytokine"), "not a recommendation"),
        Seed("covid_immune_baricitinib", "Olumiant / baricitinib", "immune_modulator", "COVID-19 inflammatory disease context", "JAK pathway modulation", "immune-module comparator for cytokine amplification hypotheses", listOf("viral_interferon_cytokine"), "not a recommendation"),
        Seed("covid_vax_comirnaty", "Comirnaty", "vaccine", "COVID-19", "mRNA spike antigen vaccine class", "vaccine-response context for immune memory / variant-adaptation hypotheses", listOf("viral_interferon_cytokine"), "not vaccine advice"),
        Seed("covid_vax_spikevax", "Spikevax", "vaccine", "COVID-19", "mRNA spike antigen vaccine class", "vaccine-response context for immune memory / variant-adaptation hypotheses", listOf("viral_interferon_cytokine"), "not vaccine advice"),
        Seed("covid_vax_nuvaxovid", "Nuvaxovid", "vaccine", "COVID-19", "protein-based vaccine class", "contrast class for vaccine-platform hypotheses", listOf("viral_interferon_cytokine"), "not vaccine advice"),
        Seed("ebola_vax_ervebo", "ERVEBO", "vaccine", "Zaire ebolavirus disease", "rVSV-vectored Zaire Ebola glycoprotein vaccine class", "known Zaire ebolavirus vaccine context for filovirus specificity checks", listOf("filovirus_viral_host_response"), "Zaire-specific; not Bundibugyo proof"),
        Seed("ebola_tx_inmazeb", "Inmazeb / atoltivimab-maftivimab-odesivimab", "monoclonal_antibody_drug", "Zaire ebolavirus infection", "antibody cocktail targeting Ebola virus glycoprotein", "known Zaire ebolavirus treatment context for antibody/entry hypotheses", listOf("filovirus_viral_host_response"), "Zaire-specific; no treatment advice"),
        Seed("ebola_tx_ebanga", "Ebanga / ansuvimab", "monoclonal_antibody_drug", "Zaire ebolavirus infection", "monoclonal antibody blocking viral entry", "known Zaire ebolavirus treatment context for entry/antibody hypotheses", listOf("filovirus_viral_host_response"), "Zaire-specific; no treatment advice")
    )

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val matched = seeds.filter { seed -> seed.routeDomains.any { GTIMActiveDomainConsistencyGuardV2134.domainCompatible(active, it) } }
        val arr = JSONArray()
        matched.forEach { seed -> arr.put(seed.toJson()) }
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (matched.isNotEmpty()) "COUNTERMEASURE_SEED_MATCH_READY" else "COUNTERMEASURE_SEED_BACKGROUND_READY")
            .put("activeDomain", active)
            .put("matchedSeedCount", matched.size)
            .put("matchedSeeds", arr)
            .put("databaseUse", "lightweight cleaned drug/vaccine prior database for route comparison only")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val seeds = obj.optJSONArray("matchedSeeds") ?: JSONArray()
        val names = (0 until seeds.length()).mapNotNull { seeds.optJSONObject(it)?.optString("name")?.takeIf { name -> name.isNotBlank() } }.take(5)
        return listOf(
            "Clean countermeasure seed database",
            "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; matched=${obj.optInt("matchedSeedCount", 0)}.",
            "Seed classes: ${names.joinToString(", ").ifBlank { "background only" }}",
            "Use: drugs/vaccines are mechanism-context priors only; they do not create treatment, dosing, vaccine, efficacy, or clinical advice."
        )
    }

    private fun Seed.toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("category", category)
        .put("condition", condition)
        .put("targetOrMechanism", targetOrMechanism)
        .put("evidenceUse", evidenceUse)
        .put("routeDomains", JSONArray(routeDomains))
        .put("boundary", boundary)

    fun seedNamesForDomain(domain: String): List<String> = seeds.filter { seed -> seed.routeDomains.any { GTIMActiveDomainConsistencyGuardV2134.domainCompatible(domain.lowercase(Locale.US), it) } }.map { it.name }
}
