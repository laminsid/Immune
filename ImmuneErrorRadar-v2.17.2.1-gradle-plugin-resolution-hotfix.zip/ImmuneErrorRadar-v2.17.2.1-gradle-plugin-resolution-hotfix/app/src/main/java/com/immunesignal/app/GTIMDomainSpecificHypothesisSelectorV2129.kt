package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.12.9 — Domain-specific hypothesis selector.
 *
 * This layer prevents broad template bias in the final study dossier. It selects the
 * root-dysfunction and functional-repair hypothesis from the user's actual study domain
 * before global-learning/fallback text can dominate the result. It still produces only
 * research value: no clinical, treatment, DGE, gene/pathway, wet-lab, or organism-use claim.
 */
object GTIMDomainSpecificHypothesisSelectorV2129 {
    const val VERSION: String = "2.12.9-domain-specific-hypothesis-selector"
    const val CLAIM_LIMIT: String = "domain_specific_research_hypothesis_only_no_evidence_upgrade"
    const val DIVERSIFIED_LEXICON_VERSION: String = "2.12.11-diversify-target-lexicon"

    data class Selection(
        val domainKey: String,
        val studyFocus: String,
        val rootDysfunction: String,
        val repairFunction: String,
        val biologicalToolClass: String,
        val mechanismRationale: String,
        val noveltyFrame: String,
        val topResearchHypothesis: String,
        val nextBestActionHint: String,
        val falsificationTriggers: List<String>,
        val prioritySource: String,
        val claimLimit: String = CLAIM_LIMIT
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): Selection {
        val primary = primaryText(report, technicalLines)
        val corpus = (primary + " " + report.toString().take(16000) + " " + technicalLines.joinToString(" ")).lowercase(Locale.US)
        val primaryLower = primary.lowercase(Locale.US)
        val domain = when {
            has(primaryLower, "pfas", "bpa", "phthalate", "microplastic", "plastic", "xenobiotic", "endocrine disrupt", "pollution", "particle", "toxin") -> "environmental_exposure_xenobiotic"
            has(primaryLower, "depress", "kynuren", "tryptophan", "neuroimmune", "mood") -> "depression_kynurenine_neuroimmune"
            has(primaryLower, "bundibugyo", "bdbv", "ebola", "filovirus", "marburg") -> "filovirus_viral_host_response"
            has(primaryLower, "hanta", "hantavirus", "hantaan", "sin nombre", "puumala", "andes virus") -> "viral_hantavirus_host_response"
            has(primaryLower, "dengue", "denv") -> "viral_dengue_host_response"
            has(primaryLower, "zika", "zikv") -> "viral_zika_host_response"
            has(primaryLower, "influenza", "flu", "h1n1", "h3n2", "avian influenza") -> "viral_influenza_host_response"
            has(primaryLower, "covid", "sars", "corona", "post-covid", "long covid") -> "viral_interferon_cytokine"
            has(primaryLower, "viral", "virus", "interferon") -> "viral_generic_host_response"
            has(primaryLower, "allerg", "ige", "mast", "eosinophil", "type-2", "type 2", "asthma", "eczema") -> "allergy_type2_barrier"
            has(primaryLower, "diabet", "insulin", "glucose", "metabolic", "obesity", "lps", "endotoxin") -> "metabolic_inflammation"
            has(corpus, "pfas", "bpa", "phthalate", "microplastic", "xenobiotic") -> "environmental_exposure_xenobiotic"
            has(corpus, "depress", "kynuren", "tryptophan", "neuroimmune") -> "depression_kynurenine_neuroimmune"
            has(corpus, "bundibugyo", "bdbv", "ebola", "filovirus", "marburg") -> "filovirus_viral_host_response"
            has(corpus, "hanta", "hantavirus", "hantaan", "sin nombre", "puumala", "andes virus") -> "viral_hantavirus_host_response"
            has(corpus, "dengue", "denv") -> "viral_dengue_host_response"
            has(corpus, "zika", "zikv") -> "viral_zika_host_response"
            has(corpus, "influenza", "flu", "h1n1", "h3n2", "avian influenza") -> "viral_influenza_host_response"
            has(corpus, "covid", "sars", "corona", "post-covid", "long covid") -> "viral_interferon_cytokine"
            has(corpus, "viral", "virus", "interferon") -> "viral_generic_host_response"
            has(corpus, "allerg", "ige", "mast", "eosinophil", "type-2", "type 2") -> "allergy_type2_barrier"
            has(corpus, "diabet", "insulin", "glucose", "metabolic") -> "metabolic_inflammation"
            else -> "open_mechanism_first"
        }
        return byDomain(domain, primaryLower, corpus)
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val s = build(report, technicalLines)
        return JSONObject()
            .put("version", VERSION)
            .put("domainKey", s.domainKey)
            .put("studyFocus", s.studyFocus)
            .put("rootDysfunction", s.rootDysfunction)
            .put("repairFunction", s.repairFunction)
            .put("biologicalToolClass", s.biologicalToolClass)
            .put("mechanismRationale", s.mechanismRationale)
            .put("noveltyFrame", s.noveltyFrame)
            .put("topResearchHypothesis", s.topResearchHypothesis)
            .put("nextBestActionHint", s.nextBestActionHint)
            .put("falsificationTriggers", JSONArray(s.falsificationTriggers))
            .put("prioritySource", s.prioritySource)
            .put("claimLimit", s.claimLimit)
    }

    fun publicLine(report: JSONObject, technicalLines: List<String> = emptyList()): String {
        val s = build(report, technicalLines)
        return "Domain-specific hypothesis lock: ${s.domainKey} → ${s.biologicalToolClass}; repair=${s.repairFunction}; claim_limit=${s.claimLimit}"
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "environmental_exposure_xenobiotic",
        "depression_kynurenine_neuroimmune",
        "viral_interferon_cytokine",
        "filovirus_viral_host_response",
        "viral_hantavirus_host_response",
        "viral_dengue_host_response",
        "viral_zika_host_response",
        "viral_influenza_host_response",
        "viral_generic_host_response",
        "allergy_type2_barrier",
        "metabolic_inflammation",
        "bioremediation_or_binding_function_research_route",
        "metabolite_modulating_microbiome_function_route",
        "barrier_mucosal_microbiome_context_route",
        "kynurenine_enzyme_neuroimmune_route",
        "interferon_cytokine_host_response_route",
        "microbiome route = candidate only, not default",
        DIVERSIFIED_LEXICON_VERSION,
        CLAIM_LIMIT
    ))

    private fun byDomain(domain: String, primaryLower: String, corpus: String): Selection = when (domain) {
        "environmental_exposure_xenobiotic" -> Selection(
            domain,
            "environmental-exposure immune/barrier study",
            "xenobiotic or particle pressure may interact with endocrine signaling, barrier stress, and inflammatory amplification",
            "screen microbial, postbiotic, or material-adjacent biological functions for binding, sequestration, transformation-context, or barrier-resilience support under containment",
            "bioremediation_or_binding_function_research_route",
            "PFAS/BPA/phthalate/microplastic routes must prioritize exposure pressure, endocrine/xenobiotic stress, barrier resilience, and biosafety-heavy evidence over allergy-style type-2 fallback",
            "high-speculation/high-upside: exposure-repair function needs strict biosafety, containment, and independent validation",
            "environmental exposure pressure may create a barrier/endocrine/immune stress state → test whether biosafety-bounded binding/sequestration or barrier-resilience functions reduce measurable exposure-linked inflammatory readouts",
            "Run topic-level external search plus Matrix Shortcut Resolver; prioritize datasets with exposure annotation, tissue/species, comparator labels, endocrine/immune readouts, and processed-expression capsule availability.",
            listOf("no exposure-compatible dataset anchor", "no comparator separating exposed vs control", "no barrier/endocrine/immune readout", "binding/sequestration function has no measurable safe assay route", "candidate route fails biosafety boundary"),
            "primary_query_exposure_terms"
        )
        "depression_kynurenine_neuroimmune" -> {
            val microbiomePositive = has(primaryLower, "microbiome", "gut", "barrier", "microbial", "postbiotic") ||
                (has(corpus, "microbiome", "gut", "barrier", "microbial", "postbiotic") && has(primaryLower, "microbiome", "gut", "barrier"))
            if (microbiomePositive) Selection(
                domain,
                "depression kynurenine-neuroimmune enzyme study with microbiome branch",
                "tryptophan/kynurenine stress may involve IDO1/KMO balance, neuroimmune signaling, and a separately testable microbiome-metabolite branch",
                "prioritize IDO1/KMO and tryptophan-kynurenine readouts; keep microbiome modulation only as a positive-signal branch",
                "kynurenine_enzyme_neuroimmune_route_with_microbiome_branch",
                "Diversify the Target Lexicon: microbiome is allowed only because the topic contains positive microbiome/gut/barrier signals; it is not the default route.",
                "medium novelty: value comes from separating enzyme/neurotransmission signals from generic gut-barrier hypotheses",
                "depression with kynurenine signals may reflect IDO1/KMO-linked tryptophan metabolism and neuroimmune signaling → test whether enzyme/metabolite and neuroinflammatory readouts stratify depression subgroups before any microbiome repair claim",
                "Prioritize IDO1, KMO, tryptophan/kynurenine metabolite ratios, neuroimmune or microglial inflammatory context, then inspect microbiome only if comparator metadata supports it.",
                listOf("no depression/control or subgroup comparator", "IDO1/KMO or tryptophan-kynurenine readouts absent", "neuroimmune/neurotransmission context absent", "microbiome branch lacks positive metadata signal", "independent contradiction check breaks the route"),
                "primary_query_depression_kynurenine_diversified_terms"
            ) else Selection(
                domain,
                "depression kynurenine-neuroimmune enzyme study",
                "tryptophan/kynurenine imbalance may involve IDO1/KMO regulation, microglial-inflammatory tone, glutamate/NMDA context, and mood-linked neuroimmune signaling",
                "map IDO1/KMO and tryptophan-kynurenine readouts before nominating any microbiome or barrier-support repair route",
                "kynurenine_enzyme_neuroimmune_route",
                "Diversify the Target Lexicon: depression+kynurenine must focus on IDO1, KMO, tryptophan metabolism, neuroimmune signaling, and neurotransmission instead of falling back to generic gut-barrier support.",
                "medium novelty: useful if enzyme/metabolite/neuroimmune subgroup signals are separated from generic inflammation",
                "depression with kynurenine pathway signals may reflect IDO1/KMO-linked tryptophan metabolism and neuroimmune neurotransmission stress → test enzyme/metabolite signatures and inflammatory tone before any microbiome hypothesis",
                "Search for depression/control or high-inflammation subgroup cohorts with IDO1/KMO, tryptophan/kynurenine, metabolomics/transcriptomics, neuroimmune or neurotransmission readouts, and processed-expression/capsule availability.",
                listOf("no depression/control or subgroup comparator", "IDO1/KMO or tryptophan-kynurenine readouts absent", "neuroimmune/neurotransmission context absent", "only generic microbiome/barrier text appears", "independent contradiction check breaks the route"),
                "primary_query_depression_kynurenine_diversified_terms"
            )
        }
        "filovirus_viral_host_response" -> pathogenSelection(
            domain,
            "filovirus host-response study",
            "filovirus outcome may depend on interferon timing, endothelial/coagulation injury, cytokine amplification, and severity/survival modules",
            "filovirus_host_response_module_route",
            "Verify filovirus/Ebola/Bundibugyo topic-fit, comparator labels, sample provenance, and capsule/module signals before any C2 upgrade.",
            "filovirus immune timing plus endothelial/coagulation injury may stratify severe host-response states",
            "primary_query_filovirus_terms"
        )
        "viral_hantavirus_host_response" -> pathogenSelection(
            domain,
            "hantavirus host-response study",
            "hantavirus severity may depend on interferon timing, vascular/endothelial injury, and immune-amplification modules",
            "hantavirus_host_response_module_route",
            "Verify hantavirus topic-fit, vascular/endothelial injury context, comparator labels, sample provenance, and capsule/module signals before any C2 upgrade.",
            "hantavirus immune timing plus vascular injury may stratify severe host-response states",
            "primary_query_hantavirus_terms"
        )
        "viral_dengue_host_response" -> pathogenSelection(
            domain,
            "dengue host-response study",
            "dengue severity may depend on interferon timing, vascular-leak/endothelial injury, platelet/coagulation context, and cytokine amplification",
            "dengue_host_response_module_route",
            "Verify dengue topic-fit, severity/comparator labels, vascular-leak/endothelial readouts, sample provenance, and capsule/module signals before any C2 upgrade.",
            "dengue vascular-leak plus immune timing modules may explain severe host-response states",
            "primary_query_dengue_terms"
        )
        "viral_zika_host_response" -> pathogenSelection(
            domain,
            "Zika host-response study",
            "Zika host-response may depend on interferon timing, tissue tropism, neurodevelopmental context, and immune amplification",
            "zika_host_response_module_route",
            "Verify Zika topic-fit, tissue/tropism context, comparator labels, sample provenance, and capsule/module signals before any C2 upgrade.",
            "Zika tissue tropism plus interferon timing may stratify host-response states",
            "primary_query_zika_terms"
        )
        "viral_influenza_host_response" -> pathogenSelection(
            domain,
            "influenza host-response study",
            "influenza severity may depend on interferon timing, epithelial injury, cytokine amplification, and recovery-state modules",
            "influenza_host_response_module_route",
            "Verify influenza topic-fit, infected/control or severity labels, epithelial/airway context, sample provenance, and capsule/module signals before any C2 upgrade.",
            "influenza epithelial injury plus immune timing may stratify recovery/severity states",
            "primary_query_influenza_terms"
        )
        "viral_generic_host_response" -> pathogenSelection(
            domain,
            "pathogen-specific viral host-response study",
            "the viral topic requires pathogen/subtype locking before borrowing COVID, filovirus, or generic interferon templates",
            "pathogen_specific_viral_host_response_route",
            "First lock the pathogen/subtype, then verify topic-compatible handles, comparator labels, sample provenance, and capsule/module signals before any C2 upgrade.",
            "unknown or under-specified viral topics should remain pathogen-specific route candidates until a compatible dataset anchor is selected",
            "primary_query_generic_viral_terms"
        )
        "viral_interferon_cytokine" -> Selection(
            domain,
            "viral interferon-cytokine host-response study",
            "viral severity or persistence may reflect interferon timing mismatch, IL-6/TNF cytokine amplification, endothelial injury, and tissue-specific host-response stress",
            "map interferon timing, cytokine amplification, endothelial/tissue injury, and recovery-state markers before nominating barrier or microbiome repair context",
            "interferon_cytokine_host_response_route",
            "viral host-response routes must stay pathogen/host-response first; barrier or microbiome context is a secondary branch only when positive metadata supports it",
            "conceptual novelty depends on finding compatible severity/recovery/control cohorts and independent host-response support",
            "viral trigger may dysregulate interferon timing and IL-6/TNF amplification → test whether host-response, endothelial/tissue injury, and recovery-state signatures track severity or persistence",
            "Prioritize severe/mild/control or infected/recovered comparator labels, host-response tissue/sample metadata, interferon/cytokine modules, matrix or processed-expression capsule, and contradiction check.",
            listOf("wrong pathogen/tissue/sample context", "no severity or infected/control comparator", "interferon/cytokine module absent", "endothelial/tissue host-response context unsupported", "independent viral dataset does not reproduce the route"),
            "primary_query_viral_terms"
        )
        "allergy_type2_barrier" -> Selection(
            domain,
            "allergy/type-2 microbiome-barrier study",
            "barrier and immune-tolerance dysfunction may amplify IgE/mast-cell/eosinophil type-2 inflammation beyond a single allergen-only explanation",
            "restore epithelial/barrier support and reduce type-2 threshold instability",
            "natural_commensal_or_postbiotic_barrier_route",
            "allergy/type-2 routes should prioritize barrier integrity, tolerance thresholds, IgE/mast/eosinophil readouts, and metabolite/postbiotic context",
            "medium novelty: known components exist, but subgroup-specific repair-function testing may be the research gap",
            "barrier/tolerance dysfunction may lower type-2 inflammatory thresholds → test whether barrier-support microbial/postbiotic functions change IgE, mast-cell/eosinophil, epithelial, or type-2 cytokine readouts",
            "Prioritize allergy/asthma/eczema cohorts with case/control labels, epithelial/barrier markers, IgE/mast/eosinophil/type-2 readouts, and processed-expression capsule availability.",
            listOf("no allergy/type-2 comparator", "no barrier or epithelial marker", "IgE/mast/eosinophil/type-2 axis absent", "microbial function is not measurable", "repair marker does not move in predicted direction"),
            "primary_query_allergy_type2_terms"
        )
        "metabolic_inflammation" -> Selection(
            domain,
            "metabolic inflammation immune-energy study",
            "immune-energy mismatch, gut barrier pressure, and low-grade inflammatory loops may sustain metabolic dysfunction",
            "restore immune-energy metabolite context and reduce low-grade inflammatory amplification",
            "metabolite_restoration_or_postbiotic_route",
            "metabolic routes should prioritize insulin/glucose context, IL-6/TNF or CRP tone, barrier/endotoxin markers, and comparator metadata",
            "medium novelty: high value if subgroup-specific inflammatory-metabolic repair functions are separated from generic metabolic association",
            "metabolic stress may create immune-energy mismatch and barrier-linked inflammatory amplification → test whether metabolite/postbiotic context tracks insulin-glucose and inflammatory readouts",
            "Prioritize metabolic disease/control or high/low inflammation subgroups with blood/transcriptome, metabolite, barrier/endotoxin, and processed-expression capsule evidence.",
            listOf("no metabolic comparator", "no inflammatory/metabolic readouts", "barrier/endotoxin signal absent", "no processed/raw matrix or capsule", "signal fails independent dataset"),
            "primary_query_metabolic_terms"
        )
        else -> Selection(
            domain,
            "open immune root-dysfunction study",
            "upstream eco-immune dysfunction remains unresolved and requires mechanism-first exploration",
            "identify the missing biological function before selecting any candidate tool",
            "open_function_first_route",
            "open topics must not nominate microbiome/postbiotic or any strong tool before tissue/sample/comparator and mechanism signals are discriminated",
            "conceptual only until a topic-compatible dataset anchor is selected",
            "an unresolved immune phenotype may reflect an upstream dysfunction → test only after dataset anchor, comparator labels, and mechanism readouts are available",
            "Run topic-level external search, select a compatible accession/capsule, then rank repair functions only after route-specific evidence appears.",
            listOf("no dataset anchor", "no comparator", "no mechanism readout", "wrong tissue/species", "no independent support"),
            "open_mechanism_first_fallback"
        )
    }

    private fun pathogenSelection(
        domain: String,
        studyFocus: String,
        rootDysfunction: String,
        toolClass: String,
        nextHint: String,
        hypothesis: String,
        prioritySource: String
    ): Selection = Selection(
        domain,
        studyFocus,
        rootDysfunction,
        "lock pathogen/subtype first, then score immune timing, tissue injury, comparator separation, sample provenance, capsule/module evidence, and contradiction resistance",
        toolClass,
        "Generalized viral routing: pathogen/subtype-specific evidence outranks broad COVID/interferon templates and legacy dataset handles.",
        "conceptual novelty only until compatible dataset/capsule, comparator labels, sample provenance, module scoring, and contradiction checks close",
        hypothesis,
        nextHint,
        listOf("wrong pathogen/subtype", "no compatible dataset anchor", "no infected/control or severity comparator", "no sample provenance", "module signal fails negative/contradiction check"),
        prioritySource
    )

    private fun primaryText(report: JSONObject, technicalLines: List<String>): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val focus = report.optJSONObject("studyFocusNormalizerV21282") ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossierReport") ?: report.optJSONObject("mechanismDiscoveryDossier") ?: JSONObject()
        return firstNonBlank(
            topic.optString("normalizedTopic"),
            topic.optString("rawInput"),
            focus.optString("title"),
            mechanism.optString("researchQuestion"),
            technicalLines.firstOrNull { it.startsWith("Research topic:") }?.removePrefix("Research topic:")?.trim().orEmpty(),
            "immune research question"
        )
    }

    private fun has(text: String, vararg needles: String): Boolean = needles.any { text.contains(it, true) }
    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}
