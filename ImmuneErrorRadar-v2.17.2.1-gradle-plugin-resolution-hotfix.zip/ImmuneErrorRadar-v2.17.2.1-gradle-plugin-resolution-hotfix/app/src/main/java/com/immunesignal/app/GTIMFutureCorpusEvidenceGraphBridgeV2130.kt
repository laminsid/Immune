package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.0 — Bridges the future lite corpus into the existing evidence graph. */
object GTIMFutureCorpusEvidenceGraphBridgeV2130 {
    const val VERSION: String = "2.13.0-future-corpus-evidence-graph-bridge"
    const val CLAIM_LIMIT: String = "graph_bridge_is_prior_structure_not_evidence"

    fun toJson(report: JSONObject): JSONObject {
        val corpus = report.optJSONObject("futureEvidenceLiteCorpusV2130") ?: GTIMFutureEvidenceLiteCorpusV2130.toJson(report)
        val active = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val domain = corpus.optString("domainKey")
        val matchesActive = GTIMActiveDomainConsistencyGuardV2134.domainCompatible(active, domain, GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report))
        val targets = if (matchesActive) GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("primaryTargets")) else emptyList()
        val readouts = if (matchesActive) GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("readouts")) else emptyList()
        val handles = if (matchesActive) GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("candidateHandles")) else emptyList()
        val edges = JSONArray()
        if (!matchesActive) edges.put(JSONObject().put("from", domain).put("to", active).put("edge", "background_contradiction_prior_only"))
        targets.take(4).forEach { t -> edges.put(JSONObject().put("from", active).put("to", t).put("edge", "prior_target_candidate")) }
        readouts.take(4).forEach { r -> edges.put(JSONObject().put("from", "target_module").put("to", r).put("edge", "measurable_readout_candidate")) }
        handles.take(4).forEach { h -> edges.put(JSONObject().put("from", h).put("to", active).put("edge", "dataset_lookup_seed_review_only")) }
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (matchesActive) "FUTURE_CORPUS_GRAPH_BRIDGE_READY" else "FUTURE_CORPUS_GRAPH_BACKGROUND_ONLY_DOMAIN_MISMATCH")
            .put("domainKey", active)
            .put("selectedFutureCorpusDomain", domain)
            .put("nodeCount", 1 + targets.take(4).size + readouts.take(4).size + handles.take(4).size)
            .put("edges", edges)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Future corpus evidence-graph bridge",
        "State: ${obj.optString("state", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}; nodes=${obj.optInt("nodeCount", 0)}; edges=${obj.optJSONArray("edges")?.length() ?: 0}.",
        "Use: connects future corpus priors into the existing evidence graph so reports reason over targets/readouts/handles instead of loose text.",
        "Boundary: graph edges are priors and routing aids, not biological proof."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FUTURE_CORPUS_GRAPH_BRIDGE_READY", CLAIM_LIMIT))
}
