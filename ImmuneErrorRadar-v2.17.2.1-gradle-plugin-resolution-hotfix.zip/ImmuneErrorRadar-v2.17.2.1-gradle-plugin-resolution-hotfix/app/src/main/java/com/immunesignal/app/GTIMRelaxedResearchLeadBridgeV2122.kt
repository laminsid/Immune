package com.immunesignal.app

import org.json.JSONObject

// v2.12.2 — Relaxed Research Lead Bridge.
// Purpose: stop the two-week loop where P0/P1 gates produce no useful value. When DGE/ETL
// cannot close, the engine still emits a study-grade research lead that connects route,
// external lookup, functional repair, and validation plan. It never upgrades evidence.
object GTIMRelaxedResearchLeadBridgeV2122 {
    const val VERSION: String = "2.12.2-relaxed-research-lead-bridge"
    const val CLAIM_LIMIT: String = "research_lead_capture_only_no_evidence_upgrade_no_diagnosis_no_treatment"

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): GTIMRelaxedResearchLeadV2122 {
        val lines = if (technicalLines.isNotEmpty()) technicalLines else GlobalResearchGradeBriefV11061.renderLines(report)
        val consistency = GTIMReportConsistencyGateV2121.build(report, lines)
        val functional = GTIMFunctionalRepairDossierEngineV2120.build(report, lines)
        val study = GTIMStudyGradeFunctionalSolutionEngineV2121.build(report, lines)
        val status = when {
            consistency.topicCompatibleTargetSelected -> "SOFT_STUDY_LEAD_WITH_ACCEPTED_TARGET"
            consistency.candidateLookupHandle.isNotBlank() -> "SOFT_STUDY_LEAD_WITH_CANDIDATE_HANDLE"
            else -> "SOFT_STUDY_LEAD_TOPIC_SEARCH_ONLY"
        }
        val targetText = if (consistency.topicCompatibleTargetSelected) {
            "accepted target ${consistency.acceptedTarget}"
        } else if (consistency.candidateLookupHandle.isNotBlank()) {
            "candidate handle ${consistency.candidateLookupHandle} for lookup only"
        } else {
            "no target yet; topic-search route remains usable"
        }
        val route = firstNonBlank(
            lineAfter(lines, "Strongest exploratory route:"),
            lineAfter(lines, "Research route:"),
            study.crossConditionBridge.firstOrNull().orEmpty(),
            "topic route retained for hypothesis and external lookup"
        )
        val primaryRepair = functional.repairFunctions.firstOrNull()
        val repair = primaryRepair?.let { "${it.repairFunction} via ${it.biologicalToolClass}" }
            ?: study.functionalSolutionHypothesis.ifBlank { "repair-function hypothesis pending topic-specific validation" }
        val external = if (consistency.topicCompatibleTargetSelected || consistency.candidateLookupHandle.isNotBlank()) {
            "External Router should inspect GEO/SRA/Europe PMC/OpenAlex for matrix, metadata, comparator labels, and source-to-sample provenance."
        } else {
            "External Router should run topic-level GEO/SRA/Europe PMC/OpenAlex searches before target selection."
        }
        val next = when {
            consistency.topicCompatibleTargetSelected -> "Treat ${consistency.acceptedTarget} as a research anchor; verify files, metadata, comparators, and sample linkage before any DGE."
            consistency.candidateLookupHandle.isNotBlank() -> "Inspect ${consistency.candidateLookupHandle} externally; accept it only if topic-fit, matrix/file evidence, and comparator labels match the question."
            else -> "Run topic-search lookup; capture the first accession with matching tissue/species/phenotype/comparator and keep the repair hypothesis as study-only."
        }
        val value = "usable study lead produced despite open gates: route + functional repair hypothesis + external evidence task + falsification plan"
        return GTIMRelaxedResearchLeadV2122(
            version = VERSION,
            state = status,
            valueProduced = value,
            acceptedTarget = consistency.acceptedTarget,
            candidateLookupHandle = consistency.candidateLookupHandle,
            routeBridge = "Route bridge: $route | $targetText",
            functionalBridge = "Functional bridge: $repair",
            externalBridge = external,
            relaxedNextAction = next,
            claimLimit = CLAIM_LIMIT
        )
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val lead = build(report, technicalLines)
        return listOf(
            "Research value produced",
            "Relaxed research state: ${lead.state} — useful study lead captured even when ETL/DGE gates remain open.",
            "Value: ${lead.valueProduced}",
            lead.routeBridge,
            lead.functionalBridge,
            "External evidence task: ${lead.externalBridge}",
            "Next best action: ${lead.relaxedNextAction}",
            "Claim limit: ${lead.claimLimit}."
        ).map { it.oneLine() }
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val lead = build(report, technicalLines)
        return JSONObject()
            .put("version", lead.version)
            .put("state", lead.state)
            .put("valueProduced", lead.valueProduced)
            .put("acceptedTarget", lead.acceptedTarget)
            .put("candidateLookupHandle", lead.candidateLookupHandle)
            .put("routeBridge", lead.routeBridge)
            .put("functionalBridge", lead.functionalBridge)
            .put("externalBridge", lead.externalBridge)
            .put("relaxedNextAction", lead.relaxedNextAction)
            .put("claimLimit", lead.claimLimit)
    }

    private fun lineAfter(lines: List<String>, prefix: String): String =
        lines.firstOrNull { it.startsWith(prefix) }?.removePrefix(prefix)?.trim().orEmpty()

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
