package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** Immunometabolism and adipose tissue immune policing research lens. */
object GTIMImmunometabolismAdiposeEngineV21321 {
    const val VERSION: String = "2.13.21-immunometabolism-adipose-engine"
    const val STATE_READY: String = "IMMUNOMETABOLISM_ADIPOSE_IMMUNE_POLICING_LENS_READY"
    const val CLAIM_LIMIT: String = "adipose_immunometabolism_signal_not_weight_loss_or_metabolic_treatment_claim"

    fun toJson(report: JSONObject): JSONObject {
        val topic = report.optString("topic", "").lowercase()
        val contexts = mutableListOf("low_grade_chronic_inflammation", "insulin_resistance_inflammation_axis", "macrophage_polarization_M1_M2")
        if (topic.contains("cancer") || topic.contains("tumor")) contexts.add("tumor_energy_and_TME_metabolic_constraint")
        if (topic.contains("diabetes") || topic.contains("metabolic") || topic.contains("obesity")) contexts.add("adipose_tissue_macrophage_ATM_axis")
        return JSONObject()
            .put("version", VERSION)
            .put("state", STATE_READY)
            .put("immunometabolism_role", "adipose_tissue_as_active_immune_endocrine_metabolic_organ_lens")
            .put("contexts", JSONArray(contexts))
            .put("candidate_markers", JSONArray(listOf("TNF", "IL6", "IL1B", "ADIPOQ", "LEP", "CCL2", "M1_M2_macrophage_balance")))
            .put("weight_loss_claim_allowed", false)
            .put("metabolic_treatment_claim_allowed", false)
            .put("diet_protocol_allowed", false)
            .put("claim_limit", CLAIM_LIMIT)
    }
}
