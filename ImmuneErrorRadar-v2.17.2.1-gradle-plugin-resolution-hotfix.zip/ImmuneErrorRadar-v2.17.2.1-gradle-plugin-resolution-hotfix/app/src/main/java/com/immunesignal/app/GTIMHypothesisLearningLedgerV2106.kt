package com.immunesignal.app

// v2.10.6 — Hypothesis learning ledger.
// Purpose: convert free GTIM hypotheses into reusable learning objects and next-proof tasks
// without closing exploration or pretending that a hypothesis is a validated treatment.
data class GTIMHypothesisLearningLedgerEntryV2106(
    val entryId: String,
    val sourceCardId: String,
    val routeClass: String,
    val hypothesis: String,
    val learningStatus: String,
    val nextProofTasks: List<String>,
    val reinforcementSignals: List<String>,
    val weakeningSignals: List<String>,
    val falsificationPriority: String,
    val reusableLearningKey: String,
    val line: String
)

data class GTIMHypothesisLearningLedgerReportV2106(
    val active: Boolean,
    val version: String,
    val state: String,
    val entries: List<GTIMHypothesisLearningLedgerEntryV2106>,
    val exportPolicy: String,
    val learningBoundary: String,
    val line: String
) {
    companion object {
        fun empty(): GTIMHypothesisLearningLedgerReportV2106 = GTIMHypothesisLearningLedgerReportV2106(
            active = false,
            version = GTIMHypothesisLearningLedgerV2106.VERSION,
            state = "HYPOTHESIS_LEDGER_NOT_EVALUATED",
            entries = emptyList(),
            exportPolicy = GTIMHypothesisLearningLedgerV2106.EXPORT_POLICY,
            learningBoundary = GTIMHypothesisLearningLedgerV2106.BOUNDARY,
            line = "Hypothesis learning ledger: not evaluated"
        )
    }
}

object GTIMHypothesisLearningLedgerV2106 {
    const val VERSION: String = "2.10.6-hypothesis-learning-ledger"
    const val EXPORT_POLICY: String = "local_operational_learning_only_no_raw_matrix_no_patient_claim_no_medical_truth"
    const val BOUNDARY: String = "learn_from_hypotheses_as_research_routes_not_treatment_claims"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        metadataBridge: GTIMMetadataFirstObservedEvidenceBridgeReportV2950?,
        freeHypothesisSynthesis: GTIMFreeHypothesisSynthesisReportV2105,
        clinicalTrialPlans: List<GTIMClinicalTrialsRequestPlanV2102>,
        authorityEvidencePlans: List<GTIMAuthorityEvidenceRequestPlanV2103>,
        discoveryFindings: List<GTIMDiscoveryFindingCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMHypothesisLearningLedgerReportV2106 {
        val entries = freeHypothesisSynthesis.cards.take(8).mapIndexed { index, card ->
            entry(index, contract, metadataBridge, card, clinicalTrialPlans, authorityEvidencePlans, discoveryFindings, dgeVerdict)
        }
        val state = when {
            entries.isEmpty() -> "HYPOTHESIS_LEDGER_EMPTY_OPEN_EXPLORATION_ALLOWED"
            entries.any { it.learningStatus.contains("NOVEL", ignoreCase = true) } -> "HYPOTHESIS_LEDGER_READY_NOVEL_RESEARCH_ROUTES"
            else -> "HYPOTHESIS_LEDGER_READY_FOUNDATION_EXTENSION_ROUTES"
        }
        val line = "Hypothesis learning ledger: version=$VERSION | state=$state | entries=${entries.size} | export_policy=$EXPORT_POLICY | authority_is_weight_not_blocker=true | learning_boundary=$BOUNDARY"
        return GTIMHypothesisLearningLedgerReportV2106(
            active = true,
            version = VERSION,
            state = state,
            entries = entries,
            exportPolicy = EXPORT_POLICY,
            learningBoundary = BOUNDARY,
            line = line
        )
    }

    private fun entry(
        index: Int,
        contract: GTIMRunDecisionContractV2740,
        metadataBridge: GTIMMetadataFirstObservedEvidenceBridgeReportV2950?,
        card: GTIMFreeHypothesisSynthesisCardV2105,
        clinicalTrialPlans: List<GTIMClinicalTrialsRequestPlanV2102>,
        authorityEvidencePlans: List<GTIMAuthorityEvidenceRequestPlanV2103>,
        discoveryFindings: List<GTIMDiscoveryFindingCardV2100>,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMHypothesisLearningLedgerEntryV2106 {
        val routeKey = card.routeClass.toKey()
        val topicKey = contract.primaryAnchor.routeId.toKey()
        val srpHint = metadataBridge?.gseToSrpMapping?.state.orEmpty().ifBlank { "SRP_MAPPING_UNKNOWN" }
        val nextProofTasks = buildList {
            add("confirm topic-compatible dataset or manual seed for ${contract.primaryAnchor.routeId}")
            addAll(card.missingEvidence.take(4))
            if (metadataBridge == null) add("run metadata-first SOFT probe before DGE or gene/pathway claims")
            if (!dgeVerdict.verdict.contains("READY", ignoreCase = true)) add("close observed-file or external-capsule evidence before calling gene/pathway signal")
            if (clinicalTrialPlans.isNotEmpty()) add("review ClinicalTrials request plan as context, not authorization")
            if (authorityEvidencePlans.isNotEmpty()) add("review authority/guideline/PubMed hints as weighting sources, not discovery blockers")
        }.map { it.oneLine() }.distinct().take(8)
        val reinforcementSignals = listOf(
            "same mechanism recurs across established evidence or therapeutic card",
            "metadata/capsule/DGE later supports biomarker or pathway prompt",
            "independent source supports clinical or preclinical pattern",
            "learning cache observes repeated route success for similar mechanism class"
        )
        val weakeningSignals = buildList {
            add("topic-compatible metadata lacks the required biomarker/pathway")
            add("comparator-backed capsule or DGE contradicts the mechanism")
            add("safety/escape/resistance pattern dominates plausible benefit")
            addAll(card.falsificationTests.take(3))
        }.map { it.oneLine() }.distinct().take(7)
        val status = when {
            card.explorationRank.contains("NOVEL", true) || card.state.contains("OPEN", true) -> "NOVEL_RESEARCH_LEAD_UNVALIDATED_LEARNABLE"
            card.explorationRank.contains("FOUNDATION", true) -> "FOUNDATION_EXTENSION_LEAD_UNVALIDATED_LEARNABLE"
            else -> "RESEARCH_ROUTE_LEAD_UNVALIDATED_LEARNABLE"
        }
        val priority = when {
            card.falsificationTests.any { it.contains("safety", true) || it.contains("contradict", true) } -> "HIGH_FALSIFICATION_PRIORITY"
            card.missingEvidence.size >= 5 -> "MEDIUM_HIGH_FALSIFICATION_PRIORITY"
            else -> "STANDARD_FALSIFICATION_PRIORITY"
        }
        val key = listOf(topicKey, routeKey, srpHint.toKey()).joinToString("::")
        val line = "Hypothesis learning entry: version=$VERSION | id=HLE_${index + 1}_${card.cardId} | not_medical_truth=true | status=$status | route=${card.routeClass.oneLine()} | reusable_key=$key | next_proof=${nextProofTasks.joinToString(";").oneLine()} | reinforce=${reinforcementSignals.joinToString(";").oneLine()} | weaken=${weakeningSignals.joinToString(";").oneLine()} | falsification_priority=$priority"
        return GTIMHypothesisLearningLedgerEntryV2106(
            entryId = "HLE_${index + 1}_${card.cardId}",
            sourceCardId = card.cardId,
            routeClass = card.routeClass,
            hypothesis = card.hypothesis,
            learningStatus = status,
            nextProofTasks = nextProofTasks,
            reinforcementSignals = reinforcementSignals,
            weakeningSignals = weakeningSignals,
            falsificationPriority = priority,
            reusableLearningKey = key,
            line = line
        )
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
    private fun String.toKey(): String = lowercase()
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .ifBlank { "unknown" }
}
