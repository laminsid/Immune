package com.immunesignal.app

/**
 * v2.7.4.5 — Discovery Ledger
 *
 * Separates hypothesis routing from matrix audit. Biological bridges remain allowed,
 * especially in autonomous discovery, but every visible route must be labeled and
 * every prior/template outside the active contract is downgraded or rejected.
 */
data class GTIMDiscoveryLedgerEntryV2745(
    val routeId: String,
    val label: GTIMEvidenceLabelV2740,
    val visible: Boolean,
    val reason: String
)

data class GTIMDiscoveryLedgerReportV2745(
    val active: Boolean,
    val entries: List<GTIMDiscoveryLedgerEntryV2745>,
    val rejectedTemplates: List<String>,
    val summaryLine: String,
    val topLine: String
)

object GTIMDiscoveryLedgerV2745 {
    const val VERSION: String = "2.7.4.5-discovery-ledger"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        candidateTexts: List<String> = emptyList()
    ): GTIMDiscoveryLedgerReportV2745 {
        val entries = contract.discoveryBridges.map { bridge ->
            val label = contract.classifyBridge(bridge.routeId)
            GTIMDiscoveryLedgerEntryV2745(
                routeId = bridge.routeId,
                label = label,
                visible = contract.canUseRoute(bridge.routeId),
                reason = reasonFor(label, contract)
            )
        }
        val rejected = candidateTexts
            .filter { it.isNotBlank() && !GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(it, contract) }
            .map { sanitizeTemplate(it) }
            .distinct()
            .take(5)
        val counts = entries.groupingBy { it.label }.eachCount()
        val summary = "Discovery ledger: plausible=${counts[GTIMEvidenceLabelV2740.PLAUSIBLE_MECHANISM] ?: 0} | weak=${counts[GTIMEvidenceLabelV2740.WEAK_LEAD] ?: 0} | speculative=${counts[GTIMEvidenceLabelV2740.SPECULATIVE_BRIDGE] ?: 0} | rejected=${rejected.size}"
        val top = entries.firstOrNull { it.visible }?.let {
            "Discovery ledger top: route=${it.routeId} | label=${it.label} | ${it.reason}"
        } ?: "Discovery ledger top: no visible route passed the active contract."
        return GTIMDiscoveryLedgerReportV2745(
            active = true,
            entries = entries,
            rejectedTemplates = rejected,
            summaryLine = summary,
            topLine = top
        )
    }

    fun safeFindingLine(
        rawFinding: String,
        contract: GTIMRunDecisionContractV2740,
        matrixAudit: GTIMMatrixAuditCardReportV2745
    ): String {
        val finding = rawFinding.trim()
        if (finding.isBlank()) {
            return "What it found: ${matrixAudit.summaryLine}; no biological hypothesis was promoted."
        }
        if (!GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(finding, contract) || looksLikePriorTemplate(finding, contract)) {
            return "What it found: prior/template finding suppressed as outside active contract; ${matrixAudit.summaryLine}."
        }
        val label = contract.classifyBridge(contract.primaryAnchor.routeId)
        return "What it found: ${finding.replace(Regex("\\s+"), " ")} | discovery_label=$label | matrix_audit_separate=true"
    }

    private fun looksLikePriorTemplate(text: String, contract: GTIMRunDecisionContractV2740): Boolean {
        val t = text.lowercase()
        val latentVirusTemplate = (t.contains("ebv") || t.contains("hhv-6") || t.contains("hhv6")) &&
            (t.contains("sle") || t.contains("ms") || t.contains("me-cfs") || t.contains("me/cfs"))
        if (!latentVirusTemplate) return false
        return contract.primaryAnchor !in setOf(
            GTIMPrimaryAnchorV2740.SLE_SYSTEMIC_AUTOIMMUNE,
            GTIMPrimaryAnchorV2740.MS_NEUROIMMUNE_DEMYELINATION,
            GTIMPrimaryAnchorV2740.AUTOIMMUNE_INFLAMMATORY
        )
    }

    private fun sanitizeTemplate(text: String): String {
        return text.replace(Regex("\\s+"), " ").trim().take(160)
    }

    private fun reasonFor(label: GTIMEvidenceLabelV2740, contract: GTIMRunDecisionContractV2740): String = when (label) {
        GTIMEvidenceLabelV2740.CONFIRMED_EVIDENCE -> "direct evidence allowed only because matrix/accession gates are ready; still not a clinical claim."
        GTIMEvidenceLabelV2740.PLAUSIBLE_MECHANISM -> "anchor-compatible mechanism; not causality."
        GTIMEvidenceLabelV2740.WEAK_LEAD -> "exploratory route linked to the protected anchor; needs dataset confirmation."
        GTIMEvidenceLabelV2740.SPECULATIVE_BRIDGE -> "autonomous cross-domain bridge; provenance and confidence labels required."
        GTIMEvidenceLabelV2740.REJECTED_CONFLATION -> "rejected because it changes or contaminates the active anchor ${contract.primaryAnchor.routeId}."
        GTIMEvidenceLabelV2740.NEEDS_DATASET_CONFIRMATION -> "requires accession/comparator/matrix closure before evidence upgrade."
    }
}
