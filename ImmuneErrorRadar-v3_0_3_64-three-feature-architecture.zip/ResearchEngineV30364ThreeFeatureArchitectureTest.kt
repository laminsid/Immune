package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30364ThreeFeatureArchitectureTest {

    // ─── Feature 1: Hypothesis Stress-Test ───────────────────────────────────

    @Test
    fun featureOneSetsKilledWhenProbeAuditFails() {
        val input = HypothesisStressTestInputV1(
            hypothesisText = "ADAR axis predicts PFS in neuroblastoma beyond MYCN",
            axisGenes = listOf("ADAR", "IFIH1", "DDX58", "TMEM173"),
            disease = "neuroblastoma",
            knownDriver = "MYCN_amplification",
            discoveryCohort = "GSE85047",
            replicationCohort = "TARGET-NBL",
            fullProbeManifest = emptyMap() // no manifest → probe audit blocked
        )
        val statValidity = FirstHypothesisStatisticalValidityReportV30358.inactive(input.hypothesisText)
        val result = HypothesisStressTestRouterV1.evaluate(input, statValidity)

        // Without a probe manifest the audit cannot pass → verdict must be KILLED or EXPLORATORY
        assertTrue(
            result.verdict == HypothesisVerdictV1.KILLED ||
            result.verdict == HypothesisVerdictV1.EXPLORATORY
        )
        assertTrue(result.falsifier.isNotBlank())
        assertEquals(ResearchEngineFeatureModeV1.HYPOTHESIS_STRESS_TEST.name, result.featureMode)
        assertTrue(result.nextStep.isNotBlank())
        assertTrue(result.boundary.isNotBlank())
    }

    @Test
    fun featureOneKilledVerdictBlocksBridgeToFeatureTwo() {
        val input = HypothesisStressTestInputV1(
            hypothesisText = "hypoxia/stroma proxy predicts PFS",
            axisGenes = listOf("HIF1A", "VEGFA"),
            disease = "neuroblastoma",
            knownDriver = "MYCN_amplification",
            discoveryCohort = "GSE85047"
        )
        val statValidity = FirstHypothesisStatisticalValidityReportV30358.inactive(input.hypothesisText)
        val result = HypothesisStressTestRouterV1.evaluate(input, statValidity)

        if (result.verdict == HypothesisVerdictV1.KILLED) {
            assertTrue(result.bridgeToFeature2.contains("BLOCKED"))
        }
    }

    @Test
    fun featureOneRouterTokenIsPresent() {
        assertTrue(HypothesisStressTestRouterV1.REQUIRED_TOKEN.isNotBlank())
        assertEquals("V30364_HYPOTHESIS_STRESS_TEST_ROUTER_V1", HypothesisStressTestRouterV1.REQUIRED_TOKEN)
        assertEquals("HYPOTHESIS_STRESS_TEST", HypothesisStressTestRouterV1.FEATURE_MODE)
    }

    // ─── Feature 2: Cross-Disease Axis Consistency ───────────────────────────

    @Test
    fun featureTwoVerdictIsUniversalWhenTwoDiseasesHaveConsistentDirection() {
        // Two surviving results with same direction → UNIVERSAL_AXIS_CANDIDATE
        val axisGenes = listOf("ADAR", "IFIH1")
        val targets = CrossDiseaseAxisConsistencyTrackerV1.PRESET_NB_CROSS_DISEASE_TARGETS.take(2)
        val report = CrossDiseaseAxisConsistencyTrackerV1.evaluate("ADAR innate sensing", axisGenes, targets)

        // With no external matrices the tracker will return EXTERNAL_MATRIX_REQUIRED
        // for non-NB targets → survivingDiseaseCount reflects actual available results
        assertNotNull(report.verdict)
        assertTrue(report.totalTestedCount == 2)
        assertTrue(report.claudeApiSuggestionSlot.isNotBlank())
        assertTrue(report.boundary.contains("MIN_DISEASES_FOR_UNIVERSAL").not() || report.boundary.isNotBlank())
    }

    @Test
    fun featureTwoInsufficientTargetsReturnsCorrectVerdict() {
        val report = CrossDiseaseAxisConsistencyTrackerV1.evaluate(
            "ADAR",
            listOf("ADAR"),
            listOf(CrossDiseaseAxisConsistencyTrackerV1.PRESET_NB_CROSS_DISEASE_TARGETS.first())
        )
        assertEquals(CrossDiseaseAxisConsistencyTrackerV1.VERDICT_INSUFFICIENT, report.verdict)
        assertFalse(report.universalCandidate)
    }

    @Test
    fun featureTwoDirectionInconsistencyDemotesToSpecific() {
        val conflicting = listOf(
            DiseaseAxisResultV1("NB", "GSE85047", "MYCN", survived = true, direction = "PROTECTIVE", hr = 0.7, adjustedP = 0.03, confounderAdjusted = true, state = "PASS"),
            DiseaseAxisResultV1("Melanoma", "GSE65185", "TMB", survived = true, direction = "RISK", hr = 1.5, adjustedP = 0.04, confounderAdjusted = true, state = "PASS")
        )
        val directions = conflicting.map { it.direction }.distinct()
        assertFalse("direction should be inconsistent", directions.size == 1)
    }

    @Test
    fun featureTwoTrackerTokenIsPresent() {
        assertEquals("V30364_CROSS_DISEASE_AXIS_CONSISTENCY_TRACKER_V1", CrossDiseaseAxisConsistencyTrackerV1.REQUIRED_TOKEN)
        assertEquals("CROSS_DISEASE_AXIS_SEARCH", CrossDiseaseAxisConsistencyTrackerV1.FEATURE_MODE)
        assertEquals(2, CrossDiseaseAxisConsistencyTrackerV1.MIN_DISEASES_FOR_UNIVERSAL)
    }

    // ─── Feature 3: General Search Scope ─────────────────────────────────────

    @Test
    fun featureThreeScopeFilterEnrichesTopicBeforePipeline() {
        val filter = GeneralSearchScopeFilterV1.PRESET_PEDIATRIC_ONCOLOGY
        val enriched = GeneralSearchScopeV1.applyScope("neuroblastoma mycn immune", filter)
        assertTrue(enriched.contains("oncology") || enriched.contains("pediatric") || enriched.contains("pfs"))
        assertTrue(enriched.length > "neuroblastoma mycn immune".length)
    }

    @Test
    fun featureThreeScopeFilterValidationRejectsInvalidAgeGroup() {
        val invalid = GeneralSearchScopeFilterV1(ageGroup = "INFANT")
        val validation = invalid.validate()
        assertFalse(validation.valid)
        assertTrue(validation.errors.isNotEmpty())
        assertTrue(validation.validationState.startsWith("SCOPE_INVALID"))
    }

    @Test
    fun featureThreeScopeFilterNullDoesNotChangeQuery() {
        val topic = "neuroblastoma mycn"
        val result = GeneralSearchScopeV1.applyScope(topic, null)
        assertEquals(topic, result)
    }

    @Test
    fun featureThreeBridgeToStressTestIsGeneratedForHypothesisCandidate() {
        val bridge = GeneralSearchScopeV1.bridgeToStressTest(
            hypothesisText = "ADAR axis predicts PFS beyond MYCN",
            axisGenes = listOf("ADAR", "IFIH1"),
            disease = "neuroblastoma",
            knownDriver = "MYCN_amplification"
        )
        assertEquals(ResearchEngineFeatureModeV1.BRIDGE_GENERAL_TO_STRESS_TEST, bridge.getString("bridgeType"))
        assertEquals("LOAD_INTO_FEATURE_1_HYPOTHESIS_STRESS_TEST", bridge.getString("action"))
        assertTrue(bridge.getString("note").contains("rerun"))
    }

    // ─── Feature routing enum ─────────────────────────────────────────────────

    @Test
    fun featureModeFromStringRoutesCorrectly() {
        assertEquals(ResearchEngineFeatureModeV1.HYPOTHESIS_STRESS_TEST, ResearchEngineFeatureModeV1.fromString("KILL"))
        assertEquals(ResearchEngineFeatureModeV1.CROSS_DISEASE_AXIS_SEARCH, ResearchEngineFeatureModeV1.fromString("cross"))
        assertEquals(ResearchEngineFeatureModeV1.GENERAL_DISEASE_RESEARCH, ResearchEngineFeatureModeV1.fromString("unknown"))
        assertEquals(ResearchEngineFeatureModeV1.GENERAL_DISEASE_RESEARCH, ResearchEngineFeatureModeV1.fromString(""))
    }

    @Test
    fun featureModeTransitionBridgesAreDefined() {
        assertTrue(ResearchEngineFeatureModeV1.BRIDGE_GENERAL_TO_STRESS_TEST.isNotBlank())
        assertTrue(ResearchEngineFeatureModeV1.BRIDGE_STRESS_TEST_TO_CROSS_DISEASE.isNotBlank())
    }
}
