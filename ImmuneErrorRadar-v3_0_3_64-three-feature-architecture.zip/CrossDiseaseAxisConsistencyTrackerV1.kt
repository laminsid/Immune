package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.64 — Feature 2: Cross-Disease Axis Consistency Tracker.
 *
 * Tests the same biological axis across multiple diseases, each with its own
 * dominant known-driver adjustment. Returns UNIVERSAL_AXIS_CANDIDATE if the axis
 * survives driver adjustment with consistent direction in ≥2 independent cohorts.
 *
 * Direction consistency rule:
 *   - All surviving results must share the same direction (PROTECTIVE or RISK).
 *   - A direction flip in any disease demotes the axis to DISEASE_SPECIFIC_SIGNAL.
 *   - UNKNOWN direction from an untested cohort does not count as a survivor.
 *
 * Current data availability:
 *   - Neuroblastoma / GSE85047: full pipeline available (probe audit + Cox).
 *   - All other diseases: EXTERNAL_MATRIX_REQUIRED — matrix must be injected.
 *
 * Claude API integration point (before disease list is finalized):
 *   - Disease candidate pointer: which diseases have public GEO cohorts with the
 *     right expression platform and survival metadata for this axis?
 *   - Claude must not populate disease results; only suggest targets.
 *
 * Publication threshold: UNIVERSAL_AXIS_CANDIDATE requires ≥2 surviving diseases
 * with consistent direction, each adjusted for its own dominant driver.
 */

data class DiseaseAxisTargetV1(
    val disease: String,
    val cohort: String,
    val platform: String,
    val knownDriver: String,
    val outcome: String,   // PFS, OS, RESPONSE
    val fullProbeManifest: Map<String, List<String>> = emptyMap()
)

data class DiseaseAxisResultV1(
    val disease: String,
    val cohort: String,
    val knownDriver: String,
    val survived: Boolean,
    val direction: String,      // PROTECTIVE / RISK / UNKNOWN
    val hr: Double?,
    val adjustedP: Double?,
    val confounderAdjusted: Boolean,
    val state: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("disease", disease)
        .put("cohort", cohort)
        .put("knownDriver", knownDriver)
        .put("survived", survived)
        .put("direction", direction)
        .put("hr", hr ?: JSONObject.NULL)
        .put("adjustedP", adjustedP ?: JSONObject.NULL)
        .put("confounderAdjusted", confounderAdjusted)
        .put("state", state)
}

data class CrossDiseaseConsistencyReportV1(
    val axisName: String,
    val axisGenes: List<String>,
    val results: List<DiseaseAxisResultV1>,
    val verdict: String,
    val consistentDirection: Boolean,
    val survivingDiseaseCount: Int,
    val totalTestedCount: Int,
    val universalCandidate: Boolean,
    val claudeApiSuggestionSlot: String,
    val boundary: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("schema", "cross_disease_consistency_report_v1")
        .put("requiredToken", CrossDiseaseAxisConsistencyTrackerV1.REQUIRED_TOKEN)
        .put("featureMode", CrossDiseaseAxisConsistencyTrackerV1.FEATURE_MODE)
        .put("axisName", axisName)
        .put("axisGenes", JSONArray(axisGenes))
        .put("results", JSONArray(results.map { it.toJson() }))
        .put("verdict", verdict)
        .put("consistentDirection", consistentDirection)
        .put("survivingDiseaseCount", survivingDiseaseCount)
        .put("totalTestedCount", totalTestedCount)
        .put("universalCandidate", universalCandidate)
        .put("claudeApiSuggestionSlot", claudeApiSuggestionSlot)
        .put("boundary", boundary)
}

object CrossDiseaseAxisConsistencyTrackerV1 {
    const val REQUIRED_TOKEN: String = "V30364_CROSS_DISEASE_AXIS_CONSISTENCY_TRACKER_V1"
    const val FEATURE_MODE: String = "CROSS_DISEASE_AXIS_SEARCH"
    const val MIN_DISEASES_FOR_UNIVERSAL: Int = 2

    // Verdict labels
    const val VERDICT_UNIVERSAL: String = "UNIVERSAL_AXIS_CANDIDATE"
    const val VERDICT_DISEASE_SPECIFIC: String = "DISEASE_SPECIFIC_SIGNAL"
    const val VERDICT_DIRECTION_INCONSISTENT: String = "DIRECTION_INCONSISTENT_ACROSS_DISEASES"
    const val VERDICT_NO_SIGNAL: String = "NO_SURVIVING_SIGNAL_ANY_DISEASE"
    const val VERDICT_INSUFFICIENT: String = "INSUFFICIENT_REPLICATION_TARGETS"

    fun evaluate(
        axisName: String,
        axisGenes: List<String>,
        diseaseTargets: List<DiseaseAxisTargetV1>
    ): CrossDiseaseConsistencyReportV1 {
        if (diseaseTargets.size < MIN_DISEASES_FOR_UNIVERSAL) {
            return insufficientTargets(axisName, axisGenes, diseaseTargets)
        }

        val results = diseaseTargets.map { target -> evaluateOneDisease(axisGenes, target) }
        val survivors = results.filter { it.survived }
        val knownDirections = survivors.map { it.direction }.filter { it != "UNKNOWN" }.distinct()
        val consistentDirection = knownDirections.size == 1
        val universalCandidate = survivors.size >= MIN_DISEASES_FOR_UNIVERSAL && consistentDirection

        val verdict: String = when {
            survivors.isEmpty() -> VERDICT_NO_SIGNAL
            !consistentDirection && survivors.size >= MIN_DISEASES_FOR_UNIVERSAL -> VERDICT_DIRECTION_INCONSISTENT
            universalCandidate -> VERDICT_UNIVERSAL
            survivors.size == 1 -> VERDICT_DISEASE_SPECIFIC
            else -> VERDICT_DISEASE_SPECIFIC
        }

        return CrossDiseaseConsistencyReportV1(
            axisName = axisName,
            axisGenes = axisGenes,
            results = results,
            verdict = verdict,
            consistentDirection = consistentDirection,
            survivingDiseaseCount = survivors.size,
            totalTestedCount = diseaseTargets.size,
            universalCandidate = universalCandidate,
            claudeApiSuggestionSlot = "CLAUDE_API_MAY_SUGGEST_ADDITIONAL_DISEASE_COHORT_TARGETS_HERE_REVIEW_ONLY",
            boundary = "UNIVERSAL_AXIS_CANDIDATE requires ≥$MIN_DISEASES_FOR_UNIVERSAL diseases surviving " +
                "their own known-driver adjustment with consistent direction. " +
                "EXTERNAL_MATRIX_REQUIRED states are not survivors. " +
                "highImpactAllowed=false until ≥2 independent human cohorts pass full Cox+replication pipeline."
        )
    }

    private fun evaluateOneDisease(
        axisGenes: List<String>,
        target: DiseaseAxisTargetV1
    ): DiseaseAxisResultV1 {
        val isNeuroblastoma = target.cohort.contains("GSE85047", ignoreCase = true) ||
            target.disease.contains("neuroblastoma", ignoreCase = true)

        return if (isNeuroblastoma) {
            evaluateNeuroblastoma(axisGenes, target)
        } else {
            externalMatrixRequired(target)
        }
    }

    private fun evaluateNeuroblastoma(
        axisGenes: List<String>,
        target: DiseaseAxisTargetV1
    ): DiseaseAxisResultV1 {
        val probeAudit = GPL5175ProbeAuditV30359.evaluate(target.fullProbeManifest)
        val axisPass = probeAudit.axisAudits.any { it.axisAuditPassed }
        return DiseaseAxisResultV1(
            disease = target.disease,
            cohort = target.cohort,
            knownDriver = target.knownDriver,
            survived = axisPass,
            direction = if (axisPass) "PENDING_MYCN_ADJUSTED_COX" else "UNKNOWN",
            hr = null,
            adjustedP = null,
            confounderAdjusted = false,
            state = if (axisPass)
                "NB_PROBE_AUDIT_PASSED_MYCN_ADJUSTED_COX_REQUIRED"
            else
                "NB_PROBE_AUDIT_BLOCKED_ATTACH_GPL5175_MANIFEST"
        )
    }

    private fun externalMatrixRequired(target: DiseaseAxisTargetV1): DiseaseAxisResultV1 {
        val diseaseKey = target.disease.uppercase().replace(" ", "_").replace("-", "_")
        return DiseaseAxisResultV1(
            disease = target.disease,
            cohort = target.cohort,
            knownDriver = target.knownDriver,
            survived = false,
            direction = "UNKNOWN",
            hr = null,
            adjustedP = null,
            confounderAdjusted = false,
            state = "EXTERNAL_MATRIX_REQUIRED_FOR_${diseaseKey}_INJECT_EXPRESSION_SURVIVAL_MATRIX_FIRST"
        )
    }

    private fun insufficientTargets(
        axisName: String,
        axisGenes: List<String>,
        targets: List<DiseaseAxisTargetV1>
    ): CrossDiseaseConsistencyReportV1 = CrossDiseaseConsistencyReportV1(
        axisName = axisName,
        axisGenes = axisGenes,
        results = emptyList(),
        verdict = VERDICT_INSUFFICIENT,
        consistentDirection = false,
        survivingDiseaseCount = 0,
        totalTestedCount = targets.size,
        universalCandidate = false,
        claudeApiSuggestionSlot = "CLAUDE_API_CAN_SUGGEST_DISEASE_COHORTS_TO_REACH_MIN_$MIN_DISEASES_FOR_UNIVERSAL",
        boundary = "At least $MIN_DISEASES_FOR_UNIVERSAL disease targets required for cross-disease consistency check."
    )

    /**
     * Pre-built disease target presets for common neuroblastoma cross-disease scenarios.
     * All non-NB targets require external matrix injection before they can produce results.
     */
    val PRESET_NB_CROSS_DISEASE_TARGETS: List<DiseaseAxisTargetV1> = listOf(
        DiseaseAxisTargetV1("Neuroblastoma", "GSE85047", "GPL5175", "MYCN_amplification", "PFS"),
        DiseaseAxisTargetV1("Melanoma_ICI", "GSE65185", "GPL570", "TMB", "RESPONSE"),
        DiseaseAxisTargetV1("Lung_NSCLC", "GSE19188", "GPL570", "KRAS_EGFR_mutation", "OS"),
        DiseaseAxisTargetV1("AML", "TCGA-LAML", "HiSeq", "FLT3_mutation", "OS"),
        DiseaseAxisTargetV1("Rhabdomyosarcoma", "GSE66533", "GPL570", "PAX_FOXO_fusion", "EFS")
    )
}
