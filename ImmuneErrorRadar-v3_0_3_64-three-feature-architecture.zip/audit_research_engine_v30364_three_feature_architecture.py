#!/usr/bin/env python3
"""
audit_research_engine_v30364_three_feature_architecture.py

Static audit for v3.0.3.64 — three-feature architecture.
Verifies that all four new files are present and contain required tokens,
and that RuntimeModuleRegistry, ReleaseIdentity, and build.gradle are updated.
"""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
missing = []

def read(path):
    p = ROOT / path
    if not p.exists():
        missing.append(f'missing file: {path}')
        return ''
    return p.read_text(errors='replace')

# --- ResearchEngineFeatureModeV1 ---
mode = read('app/src/main/java/com/immunesignal/app/ResearchEngineFeatureModeV1.kt')
for token in [
    'V30364_THREE_FEATURE_ARCHITECTURE',
    'HYPOTHESIS_STRESS_TEST',
    'CROSS_DISEASE_AXIS_SEARCH',
    'GENERAL_DISEASE_RESEARCH',
    'BRIDGE_GENERAL_TO_STRESS_TEST',
    'BRIDGE_STRESS_TEST_TO_CROSS_DISEASE',
    'ResearchEngineFeatureModeV1',
]:
    if token not in mode:
        missing.append(f'ResearchEngineFeatureModeV1.kt missing {token}')

# --- HypothesisStressTestRouterV1 (Feature 1) ---
stress = read('app/src/main/java/com/immunesignal/app/HypothesisStressTestRouterV1.kt')
for token in [
    'V30364_HYPOTHESIS_STRESS_TEST_ROUTER_V1',
    'HypothesisStressTestInputV1',
    'HypothesisStressTestResultV1',
    'HypothesisStressTestRouterV1',
    'HypothesisVerdictV1',
    'KILLED',
    'SURVIVING',
    'EXPLORATORY',
    'probeAuditPassed',
    'knownDriver',
    'bridgeToFeature2',
    'BRIDGE_STRESS_TEST_TO_CROSS_DISEASE',
    'fullProbeManifest',
    'GPL5175ProbeAuditV30359.evaluate',
    'HypothesisCriticAndGeneratorV3.evaluate',
    'MAX_SHADOW_SUBGROUP_ATTEMPTS',
]:
    if token not in stress:
        missing.append(f'HypothesisStressTestRouterV1.kt missing {token}')

# --- CrossDiseaseAxisConsistencyTrackerV1 (Feature 2) ---
cross = read('app/src/main/java/com/immunesignal/app/CrossDiseaseAxisConsistencyTrackerV1.kt')
for token in [
    'V30364_CROSS_DISEASE_AXIS_CONSISTENCY_TRACKER_V1',
    'DiseaseAxisTargetV1',
    'DiseaseAxisResultV1',
    'CrossDiseaseConsistencyReportV1',
    'CrossDiseaseAxisConsistencyTrackerV1',
    'UNIVERSAL_AXIS_CANDIDATE',
    'DISEASE_SPECIFIC_SIGNAL',
    'DIRECTION_INCONSISTENT_ACROSS_DISEASES',
    'NO_SURVIVING_SIGNAL_ANY_DISEASE',
    'INSUFFICIENT_REPLICATION_TARGETS',
    'MIN_DISEASES_FOR_UNIVERSAL',
    'EXTERNAL_MATRIX_REQUIRED',
    'consistentDirection',
    'universalCandidate',
    'claudeApiSuggestionSlot',
    'PRESET_NB_CROSS_DISEASE_TARGETS',
]:
    if token not in cross:
        missing.append(f'CrossDiseaseAxisConsistencyTrackerV1.kt missing {token}')

# --- GeneralSearchScopeFilterV1 (Feature 3) ---
scope = read('app/src/main/java/com/immunesignal/app/GeneralSearchScopeFilterV1.kt')
for token in [
    'V30364_GENERAL_SEARCH_SCOPE_FILTER_V1',
    'GeneralSearchScopeFilterV1',
    'GeneralSearchScopeV1',
    'toQueryEnrichment',
    'applyScope',
    'bridgeToStressTest',
    'BRIDGE_GENERAL_TO_STRESS_TEST',
    'PRESET_PEDIATRIC_ONCOLOGY',
    'PRESET_AUTOIMMUNE',
    'PRESET_ICI_RESPONSE',
    'validate',
    'SCOPE_VALID',
]:
    if token not in scope:
        missing.append(f'GeneralSearchScopeFilterV1.kt missing {token}')

# --- RuntimeModuleRegistry ---
registry = read('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt')
for token in [
    'ResearchEngineFeatureModeV1',
    'HypothesisStressTestRouterV1',
    'CrossDiseaseAxisConsistencyTrackerV1',
    'GeneralSearchScopeV1',
    'GPL5175ProbeManifestAttachmentV30363',
]:
    if token not in registry:
        missing.append(f'RuntimeModuleRegistry.kt missing {token}')

# --- ReleaseIdentity ---
identity = read('app/src/main/java/com/immunesignal/app/ResearchEngineV3ReleaseIdentity.kt')
for token in [
    '3.0.3.64-three-feature-architecture',
    'V30364_THREE_FEATURE_ARCHITECTURE',
    'VERSION_CODE: Int = 281',
]:
    if token not in identity:
        missing.append(f'ResearchEngineV3ReleaseIdentity.kt missing {token}')

# --- build.gradle.kts ---
build = read('app/build.gradle.kts')
for token in [
    'versionCode = 281',
    'versionName = "3.0.3.64-three-feature-architecture"',
]:
    if token not in build:
        missing.append(f'app/build.gradle.kts missing {token}')

# --- Test file ---
test = read('app/src/test/java/com/immunesignal/app/ResearchEngineV30364ThreeFeatureArchitectureTest.kt')
for token in [
    'featureOneSetsKilledWhenProbeAuditFails',
    'featureTwoVerdictIsUniversalWhenTwoDiseasesHaveConsistentDirection',
    'featureThreeScopeFilterEnrichesTopicBeforePipeline',
    'featureThreeBridgeToStressTestIsGeneratedForHypothesisCandidate',
]:
    if token not in test:
        missing.append(f'ResearchEngineV30364ThreeFeatureArchitectureTest.kt missing {token}')

# --- run_static_checks_fast.sh ---
runner = read('scripts/run_static_checks_fast.sh')
if 'audit_research_engine_v30364_three_feature_architecture.py' not in runner:
    missing.append('run_static_checks_fast.sh missing v30364 audit entry')

if missing:
    raise AssertionError(
        'v30364 three-feature architecture audit failed:\n' + '\n'.join(missing)
    )
print('audit_research_engine_v30364_three_feature_architecture: PASS')
