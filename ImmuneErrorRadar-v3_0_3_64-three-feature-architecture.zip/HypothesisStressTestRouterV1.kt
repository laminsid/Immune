package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.64 — Feature 1: Hypothesis Stress-Test.
 *
 * Entry point for users who already have a hypothesis and want to validate or kill it.
 * Bypasses hypothesis generation; routes directly to probe audit → statistical validity
 * → confounder-safe subgroup search → binary verdict.
 *
 * The verdict is one of three states:
 *   KILLED      — signal does not survive known-driver adjustment or probe audit fails.
 *   SURVIVING   — signal survives FDR + known-driver Cox; external replication required.
 *   EXPLORATORY — probe audit passes but no statistical verdict yet; Cox run required.
 *
 * Claude API integration point (pre-flight only, before Cox):
 *   - Augmented falsifier: confounders not in the current adjustment list.
 *   - Literature collision check: has this axis been tested in this disease?
 * Claude must not override the statistical verdict.
 */

enum class HypothesisVerdictV1 { KILLED, SURVIVING, EXPLORATORY }

data class HypothesisStressTestInputV1(
    val hypothesisText: String,
    val axisGenes: List<String>,
    val disease: String,
    val knownDriver: String,
    val discoveryCohort: String,
    val replicationCohort: String? = null,
    val fullProbeManifest: Map<String, List<String>> = emptyMap()
)

data class HypothesisStressTestResultV1(
    val verdict: HypothesisVerdictV1,
    val verdictReason: String,
    val falsifier: String,
    val literatureCollisionRisk: String,
    val statisticalSummary: String,
    val probeAuditPassed: Boolean,
    val nextStep: String,
    val featureMode: String = ResearchEngineFeatureModeV1.HYPOTHESIS_STRESS_TEST.name,
    val bridgeToFeature2: String,
    val boundary: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("schema", "hypothesis_stress_test_result_v1")
        .put("requiredToken", HypothesisStressTestRouterV1.REQUIRED_TOKEN)
        .put("featureMode", featureMode)
        .put("verdict", verdict.name)
        .put("verdictReason", verdictReason)
        .put("falsifier", falsifier)
        .put("literatureCollisionRisk", literatureCollisionRisk)
        .put("statisticalSummary", statisticalSummary)
        .put("probeAuditPassed", probeAuditPassed)
        .put("nextStep", nextStep)
        .put("bridgeToFeature2", bridgeToFeature2)
        .put("boundary", boundary)
}

object HypothesisStressTestRouterV1 {
    const val REQUIRED_TOKEN: String = "V30364_HYPOTHESIS_STRESS_TEST_ROUTER_V1"
    const val FEATURE_MODE: String = "HYPOTHESIS_STRESS_TEST"

    fun evaluate(
        input: HypothesisStressTestInputV1,
        statisticalValidity: FirstHypothesisStatisticalValidityReportV30358
    ): HypothesisStressTestResultV1 {
        // Step 1: Probe audit — can the axis genes be measured?
        val probeAudit = GPL5175ProbeAuditV30359.evaluate(input.fullProbeManifest)
        val probeAuditPassed = probeAudit.axisAudits.any { it.axisAuditPassed }

        // Step 2: Metadata preflight
        val metadata = GSE85047MetadataPreflightV30359.evaluate()

        // Step 3: Hypothesis critic — falsifier-first, literature collision
        val critic = HypothesisCriticAndGeneratorV3.evaluate(
            input.hypothesisText, probeAudit, metadata, statisticalValidity
        )

        // Step 4: Verdict from statistical validity state
        val shadowState = statisticalValidity.mycnShadowState.trim()
        val verdict: HypothesisVerdictV1 = when {
            !probeAuditPassed ->
                HypothesisVerdictV1.KILLED
            statisticalValidity.active && shadowState.startsWith("SIGNAL_DOES_NOT") ->
                HypothesisVerdictV1.KILLED
            statisticalValidity.active && shadowState.startsWith("SIGNAL_SURVIVES") ->
                HypothesisVerdictV1.SURVIVING
            else ->
                HypothesisVerdictV1.EXPLORATORY
        }

        val verdictReason: String = when (verdict) {
            HypothesisVerdictV1.KILLED -> when {
                !probeAuditPassed ->
                    "Probe audit failed: no verified GPL5175 probes with sufficient dynamic range for the axis genes. Attach full GPL5175 manifest to proceed."
                else ->
                    "${input.knownDriver} shadow: axis loses independent signal after known-driver adjustment (p=non-significant post-Cox). ${critic.falsifier}"
            }
            HypothesisVerdictV1.SURVIVING ->
                "Signal survives ${input.knownDriver} adjustment. External replication in ${input.replicationCohort ?: "TARGET-NBL or GSE49710"} required for publication-grade claim. highImpactAllowed=false until replication passes."
            HypothesisVerdictV1.EXPLORATORY ->
                "Probe audit passed; no prior ${input.knownDriver}-adjusted Cox result. Run ConfounderSafeSubgroupHypothesisSearchV30359 on this axis to obtain statistical verdict."
        }

        val nextStep: String = when (verdict) {
            HypothesisVerdictV1.KILLED ->
                "Review shadow exit guidance: try MYCN-non-amplified subgroup, different confounder definition, or archive axis after MAX_SHADOW_SUBGROUP_ATTEMPTS=${ConfounderSafeSubgroupHypothesisSearchV30359.MAX_SHADOW_SUBGROUP_ATTEMPTS}."
            HypothesisVerdictV1.SURVIVING ->
                "Attach replication matrix for ${input.replicationCohort ?: "TARGET-NBL"} and rerun same-axis Cox after ${input.knownDriver} adjustment. If direction holds → load axis into Feature 2 Cross-Disease search."
            HypothesisVerdictV1.EXPLORATORY ->
                "Attach full GPL5175 manifest via GPL5175ProbeManifestAttachmentV30363, then run Feature 1 again or pass axis to ConfounderSafeSubgroupHypothesisSearchV30359."
        }

        val bridgeToFeature2: String = when (verdict) {
            HypothesisVerdictV1.SURVIVING ->
                "${ResearchEngineFeatureModeV1.BRIDGE_STRESS_TEST_TO_CROSS_DISEASE}: load axisGenes=${input.axisGenes} into CrossDiseaseAxisConsistencyTrackerV1 for pan-disease consistency check."
            else -> "BRIDGE_BLOCKED_UNTIL_SURVIVING_VERDICT"
        }

        return HypothesisStressTestResultV1(
            verdict = verdict,
            verdictReason = verdictReason,
            falsifier = critic.falsifier,
            literatureCollisionRisk = critic.literatureCollisionRisk,
            statisticalSummary = if (statisticalValidity.active)
                "fdrState=${statisticalValidity.fdrState}; mycnShadow=${statisticalValidity.mycnShadowState}"
            else "STATISTICAL_VALIDITY_NOT_YET_RUN_PASS_TO_CONFOUNDER_SAFE_V30359",
            probeAuditPassed = probeAuditPassed,
            nextStep = nextStep,
            bridgeToFeature2 = bridgeToFeature2,
            boundary = "Feature 1 verdict is binary and gate-enforced. It is not a publication result. " +
                "SURVIVING requires external replication. KILLED may be re-entered with a different subgroup. " +
                "Claude API may enrich the falsifier before Cox but must not override the verdict."
        )
    }
}
