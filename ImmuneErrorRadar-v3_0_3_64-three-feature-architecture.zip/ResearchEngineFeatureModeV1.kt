package com.immunesignal.app

/**
 * v3.0.3.64 — Three-feature architecture routing.
 *
 * Feature 1 — HYPOTHESIS_STRESS_TEST:
 *   User provides a structured hypothesis. Engine bypasses generation and goes
 *   straight to probe audit → FDR → MYCN-adjusted Cox → verdict.
 *
 * Feature 2 — CROSS_DISEASE_AXIS_SEARCH:
 *   User provides an axis + list of disease-cohort pairs. Engine tests the same
 *   axis in parallel across diseases, each with its own known-driver adjustment.
 *   Returns UNIVERSAL_AXIS_CANDIDATE if direction is consistent across ≥2 diseases.
 *
 * Feature 3 — GENERAL_DISEASE_RESEARCH:
 *   Free-text topic → full ResearchEngineV3 pipeline (existing flow).
 *   Optional GeneralSearchScopeFilterV1 narrows retrieval before generation.
 *
 * All three features share the same backbone:
 *   GPL5175ProbeAuditV30359 → HypothesisCriticAndGeneratorV3
 *   → FirstHypothesisStatisticalValidityGateV30358
 *   → ConfounderSafeSubgroupHypothesisSearchV30359
 *   → ConditionalModernMechanismModulePackV30360
 *
 * Principle: "Claude proposes; engine disposes."
 * Claude API is a pre-flight intelligence layer (falsifier + collision + disease pointer).
 * It must not override probe audit, metadata preflight, or statistical gates.
 */
enum class ResearchEngineFeatureModeV1 {
    HYPOTHESIS_STRESS_TEST,    // Feature 1 — user supplies hypothesis
    CROSS_DISEASE_AXIS_SEARCH, // Feature 2 — user supplies axis + disease list
    GENERAL_DISEASE_RESEARCH;  // Feature 3 — user supplies free-text topic (default)

    companion object {
        const val REQUIRED_TOKEN: String = "V30364_THREE_FEATURE_ARCHITECTURE"

        fun fromString(value: String): ResearchEngineFeatureModeV1 = when (value.uppercase().trim()) {
            "HYPOTHESIS_STRESS_TEST", "KILL", "STRESS_TEST", "FEATURE_1" -> HYPOTHESIS_STRESS_TEST
            "CROSS_DISEASE_AXIS_SEARCH", "CROSS_DISEASE", "CROSS", "FEATURE_2" -> CROSS_DISEASE_AXIS_SEARCH
            else -> GENERAL_DISEASE_RESEARCH
        }

        /** Transition rule: Feature 3 output can bridge to Feature 1. */
        const val BRIDGE_GENERAL_TO_STRESS_TEST: String =
            "FEATURE_3_OUTPUT_CAN_LOAD_HYPOTHESIS_INTO_FEATURE_1_STRESS_TEST"

        /** Transition rule: Feature 1 SURVIVING output can bridge to Feature 2. */
        const val BRIDGE_STRESS_TEST_TO_CROSS_DISEASE: String =
            "FEATURE_1_SURVIVING_AXIS_CAN_LOAD_INTO_FEATURE_2_CROSS_DISEASE"
    }
}
