package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.64 — Feature 3: General Disease Research Scope Filter.
 *
 * Wraps the existing ResearchEngineV3 full pipeline with an optional pre-filter
 * that narrows retrieval before hypothesis generation. Reduces the CHECKPOINT_DATASET_GAP
 * failure rate observed in broad generic queries (cancer TME, RA synovium) by
 * constraining the accession search to disease area, age group, and outcome type.
 *
 * The scope filter does NOT change engine logic — it enriches the query string
 * before topic normalization, so all existing gates (probe audit, MYCN adjustment,
 * FDR, contradiction search) apply unchanged.
 *
 * Bridge to Feature 1:
 *   When Feature 3 generates a hypothesis candidate, the output carries a
 *   BRIDGE_TO_STRESS_TEST field. The UI can load the hypothesis directly into
 *   Feature 1 (HypothesisStressTestRouterV1) for a kill-or-survive verdict.
 *
 * Claude API integration point:
 *   After the report is generated, Claude may produce a narrative summary and
 *   suggest "should this hypothesis be stress-tested in Feature 1?"
 *   Claude must not override the report's closure state.
 */

data class GeneralSearchScopeFilterV1(
    val diseaseArea: String? = null,     // "oncology", "autoimmune", "metabolic", "infectious"
    val ageGroup: String? = null,         // "PEDIATRIC", "ADULT", "AGE_NOT_SPECIFIED"
    val outcomeType: String? = null,      // "PFS", "OS", "RESPONSE", "ACTIVITY_SCORE"
    val organism: String = "HUMAN"
) {
    fun validate(): GeneralSearchScopeValidationV1 {
        val errors = mutableListOf<String>()
        if (ageGroup != null && ageGroup !in VALID_AGE_GROUPS) {
            errors += "INVALID_AGE_GROUP '$ageGroup': use one of $VALID_AGE_GROUPS"
        }
        if (organism !in VALID_ORGANISMS) {
            errors += "INVALID_ORGANISM '$organism': use one of $VALID_ORGANISMS"
        }
        if (outcomeType != null && outcomeType !in VALID_OUTCOMES) {
            errors += "INVALID_OUTCOME_TYPE '$outcomeType': use one of $VALID_OUTCOMES"
        }
        return GeneralSearchScopeValidationV1(
            valid = errors.isEmpty(),
            errors = errors
        )
    }

    fun toQueryEnrichment(): String {
        val parts = mutableListOf<String>()
        diseaseArea?.let { parts.add(it) }
        ageGroup?.takeIf { it != "AGE_NOT_SPECIFIED" }?.let { parts.add(it.lowercase()) }
        outcomeType?.let { parts.add(it.lowercase()) }
        if (organism != "HUMAN") parts.add(organism.lowercase())
        return parts.joinToString(" ")
    }

    fun toJson(): JSONObject = JSONObject()
        .put("diseaseArea", diseaseArea ?: JSONObject.NULL)
        .put("ageGroup", ageGroup ?: JSONObject.NULL)
        .put("outcomeType", outcomeType ?: JSONObject.NULL)
        .put("organism", organism)
        .put("queryEnrichment", toQueryEnrichment())
        .put("validationState", validate().validationState)

    companion object {
        val VALID_AGE_GROUPS = listOf("PEDIATRIC", "ADULT", "AGE_NOT_SPECIFIED")
        val VALID_ORGANISMS = listOf("HUMAN", "MOUSE", "UNKNOWN")
        val VALID_OUTCOMES = listOf("PFS", "OS", "RESPONSE", "ACTIVITY_SCORE", "EFS", "DFS")

        /** Preset for pediatric oncology queries — most specific, lowest noise. */
        val PRESET_PEDIATRIC_ONCOLOGY: GeneralSearchScopeFilterV1 = GeneralSearchScopeFilterV1(
            diseaseArea = "oncology",
            ageGroup = "PEDIATRIC",
            outcomeType = "PFS",
            organism = "HUMAN"
        )

        /** Preset for autoimmune/RA queries — addresses the CHECKPOINT_DATASET_GAP pattern. */
        val PRESET_AUTOIMMUNE: GeneralSearchScopeFilterV1 = GeneralSearchScopeFilterV1(
            diseaseArea = "autoimmune",
            ageGroup = "ADULT",
            outcomeType = "ACTIVITY_SCORE",
            organism = "HUMAN"
        )

        /** Preset for ICI response queries — bridges to Feature 2 cross-disease pathway. */
        val PRESET_ICI_RESPONSE: GeneralSearchScopeFilterV1 = GeneralSearchScopeFilterV1(
            diseaseArea = "oncology immunotherapy",
            ageGroup = "ADULT",
            outcomeType = "RESPONSE",
            organism = "HUMAN"
        )
    }
}

data class GeneralSearchScopeValidationV1(
    val valid: Boolean,
    val errors: List<String>
) {
    val validationState: String get() = if (valid) "SCOPE_VALID" else "SCOPE_INVALID_${errors.size}_ERRORS"
}

object GeneralSearchScopeV1 {
    const val REQUIRED_TOKEN: String = "V30364_GENERAL_SEARCH_SCOPE_FILTER_V1"
    const val FEATURE_MODE: String = "GENERAL_DISEASE_RESEARCH"

    /**
     * Enriches a raw topic string with scope filter terms before passing to
     * the ResearchEngineV3 topic normalizer.
     */
    fun applyScope(topic: String, filter: GeneralSearchScopeFilterV1?): String {
        if (filter == null) return topic
        val validation = filter.validate()
        if (!validation.valid) return topic // invalid filter silently ignored; engine uses raw topic
        val enrichment = filter.toQueryEnrichment()
        return if (enrichment.isBlank()) topic else "$topic $enrichment".trim()
    }

    /**
     * Generates a bridge-to-Feature-1 suggestion based on Feature 3 output.
     * Called after report compilation; output is display metadata, not an engine gate.
     */
    fun bridgeToStressTest(
        hypothesisText: String,
        axisGenes: List<String>,
        disease: String,
        knownDriver: String
    ): JSONObject = JSONObject()
        .put("bridgeType", ResearchEngineFeatureModeV1.BRIDGE_GENERAL_TO_STRESS_TEST)
        .put("action", "LOAD_INTO_FEATURE_1_HYPOTHESIS_STRESS_TEST")
        .put("hypothesisText", hypothesisText)
        .put("axisGenes", JSONArray(axisGenes))
        .put("disease", disease)
        .put("knownDriver", knownDriver)
        .put("note", "Bridge is a UI affordance; Feature 1 will rerun probe audit and statistical gates from scratch.")
}
