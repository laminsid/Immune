package com.immunesignal.app

/**
 * General microbiome bridge metadata for v2.7.3 patch-line.
 *
 * This is deliberately broad: it supports routes where microbiome signals connect to molecules,
 * immune mediators and phenotypes without asserting that one bacterium, one toxin or one disease
 * is causal. The executable routing lives in GTIMTopicSpecificRouteBuilderV270 profiles; this
 * object gives audits/tests a stable runtime identity and safety contract.
 */
object GTIMGeneralMicrobiomeImmuneBridgeV2732 {
    const val VERSION: String = "2.7.3.2-final-general-microbiome-bridge-routes"
    const val RELEASE_COMPAT_VERSION: String = "2.7.3-final-proof-benchmark-learning-locked"
    const val CLAIM_LIMIT: String = "route_learning_only_not_evidence_not_diagnosis_not_treatment_not_exposure_attribution"

    val routeIds: List<String> = listOf(
        "microbiome_molecule_immune_phenotype_bridge_route",
        "microbiome_environment_drug_food_immune_modulation_route"
    )

    val requiredBridgeGates: List<String> = listOf(
        "microbe_or_community_feature",
        "molecule_metabolite_barrier_hormone_or_cytokine_mediator",
        "immune_mediator_or_host_response",
        "phenotype_or_outcome_label",
        "case_control_or_exposure_comparator",
        "microbiome_metabolomics_or_host_response_accession",
        "contradiction_or_negative_control_search"
    )

    fun isMicrobiomeBridgeTopic(text: String): Boolean {
        val normalized = text.lowercase()
        return listOf(
            "microbiome", "microbiota", "gut bacteria", "gut-brain", "dysbiosis", "metabolite",
            "tryptophan", "kynurenine", "scfa", "bile acid", "lps", "intestinal permeability",
            "antibiotic", "pesticide", "heavy metal", "microplastic", "plasticizer", "resistome"
        ).any { normalized.contains(it) }
    }

    fun safetyLine(): String =
        "Microbiome bridge routes are lookup/learning routes only: require mediator + comparator + accession + contradiction gates; no causality, diagnosis, treatment or exposure attribution."
}
