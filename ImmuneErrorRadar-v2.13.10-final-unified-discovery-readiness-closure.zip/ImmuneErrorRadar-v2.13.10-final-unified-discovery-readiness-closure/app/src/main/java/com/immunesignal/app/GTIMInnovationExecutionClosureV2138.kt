package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.8 — innovation execution closure.
 * Converts v2.13.7 synthesis into a ranked, non-obvious, executable discovery-candidate
 * portfolio and keeps C2 claims blocked until actual scoring/replication exists.
 */
object GTIMNonObviousExperimentDesignerV2138 {
    const val VERSION: String = "2.13.8-non-obvious-experiment-designer"
    const val CLAIM_LIMIT: String = "experiment_design_is_computational_research_plan_not_wet_lab_or_clinical_protocol"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val target = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report).ifBlank { "topic_compatible_target_required" }
        val phase = report.optJSONObject("immunePhaseEngineV2137") ?: GTIMImmunePhaseEngineV2137.toJson(report)
        val mutation = report.optJSONObject("hypothesisMutationEngineV2137") ?: GTIMHypothesisMutationEngineV2137.toJson(report)
        val topMutation = mutation.optJSONArray("mutatedHypotheses")?.optJSONObject(0) ?: JSONObject()
        val design = JSONObject()
            .put("primaryQuestion", topMutation.optString("claim", "find a non-obvious same-domain subgroup claim"))
            .put("primaryTarget", target)
            .put("phaseAxis", phase.optString("nonObviousQuestion", "phase/tissue/subgroup axis"))
            .put("requiredComparators", JSONArray(comparatorsFor(domain)))
            .put("negativeControl", negativeControlFor(domain))
            .put("killCondition", topMutation.optString("killCondition", "module does not separate comparator groups"))
            .put("executionBoundary", "computational_dataset_review_only_no_wet_lab_protocol")
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (target != "topic_compatible_target_required") "NON_OBVIOUS_EXPERIMENT_DESIGN_READY" else "NON_OBVIOUS_EXPERIMENT_DESIGN_NEEDS_TARGET")
            .put("activeDomain", domain)
            .put("design", design)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val design = obj.optJSONObject("design") ?: JSONObject()
        return listOf(
            "Non-obvious experiment designer",
            "State: ${obj.optString("state", "UNKNOWN")}; target=${design.optString("primaryTarget", "none")}",
            "Primary question: ${design.optString("primaryQuestion", "none")}",
            "Kill condition: ${design.optString("killCondition", "none")}",
            "Boundary: design is computational research planning only; no wet-lab, dosing, or clinical protocol is emitted."
        )
    }

    private fun comparatorsFor(domain: String): List<String> = when {
        domain.contains("depression") -> listOf("MDD_vs_control", "inflammatory_subgroup_vs_non_inflammatory", "brain_region_or_sex_strata")
        domain.contains("allergy") -> listOf("allergic_vs_non_allergic", "HDM_status", "asthma_status", "treated_vs_untreated_if_available")
        domain.contains("filovirus") -> listOf("survivor_vs_fatal", "severity_strata", "early_vs_late_sampling")
        domain.contains("viral") -> listOf("acute_vs_recovery", "severity_vs_control", "persistent_vs_recovered")
        domain.contains("metabolic") -> listOf("insulin_resistant_vs_control", "high_vs_low_inflammation", "tissue_or_adiposity_strata")
        else -> listOf("case_vs_control", "high_vs_low_signal")
    }

    private fun negativeControlFor(domain: String): String = when {
        domain.contains("depression") -> "non_inflammatory_depression_or_unrelated_brain_region"
        domain.contains("allergy") -> "barrier_only_signal_without_type2_IgE_eosinophil_readout"
        domain.contains("filovirus") -> "generic_viral_dataset_without_filovirus_or_survival_context"
        domain.contains("viral") -> "acute_only_dataset_without_recovery_or_persistence_labels"
        domain.contains("metabolic") -> "generic_IL6_TNF_signal_without_metabolic_comparator"
        else -> "wrong_tissue_or_unrelated_comparator"
    }
}

object GTIMInnovationPortfolioRankerV2138 {
    const val VERSION: String = "2.13.8-innovation-portfolio-ranker"
    const val CLAIM_LIMIT: String = "portfolio_rank_is_prioritization_not_discovery_proof"

    fun toJson(report: JSONObject): JSONObject {
        val synthesis = report.optJSONObject("discoverySynthesisCardV2137") ?: GTIMDiscoverySynthesisCardV2137.toJson(report)
        val upgrade = report.optJSONObject("c1ToC2UpgradePathwayV2138") ?: GTIMC1ToC2UpgradePathwayV2138.toJson(report)
        val design = report.optJSONObject("nonObviousExperimentDesignerV2138") ?: GTIMNonObviousExperimentDesignerV2138.toJson(report)
        val hasTarget = synthesis.optString("canonicalTarget").isNotBlank() && synthesis.optString("canonicalTarget") != "not_selected"
        val hasReplication = (upgrade.optJSONArray("replicationCandidates")?.length() ?: 0) > 0
        val score = (if (hasTarget) 35 else 0) + (if (hasReplication) 25 else 0) + 20 + if (synthesis.optString("innovationLevel").startsWith("C1")) 20 else 5
        val rank = when {
            score >= 80 -> "PRIORITY_A_EXECUTE_FOR_C2"
            score >= 55 -> "PRIORITY_B_KEEP_AS_C1_AND_FIND_REPLICATION"
            else -> "PRIORITY_C_ROUTE_ONLY_NEEDS_TARGET"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "INNOVATION_PORTFOLIO_RANK_READY")
            .put("rank", rank)
            .put("score", score)
            .put("claimCandidate", synthesis.optString("newClaimCandidate", "open claim candidate"))
            .put("primaryExecution", design.optJSONObject("design")?.optString("primaryQuestion", "score modules then replicate") ?: "score modules then replicate")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Innovation portfolio ranker",
        "State: ${obj.optString("state", "UNKNOWN")}; rank=${obj.optString("rank", "UNKNOWN")}; score=${obj.optInt("score", 0)}.",
        "Candidate: ${obj.optString("claimCandidate", "none")}",
        "Primary execution: ${obj.optString("primaryExecution", "score modules then replicate")}",
        "Boundary: portfolio rank prioritizes work; it is not scientific proof."
    )
}

object GTIMFinalInnovationExecutionClosureV2138 {
    const val VERSION: String = "2.13.8-final-innovation-execution-bridge"
    const val CLAIM_LIMIT: String = "final_innovation_execution_bridge_candidate_only_no_validated_scientific_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val target = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val export = report.optJSONObject("staleSurfaceZeroExportGuardV2138") ?: GTIMStaleSurfaceZeroExportGuardV2138.toJson(report)
        val score = report.optJSONObject("moduleScorePlaceholderEngineV2138") ?: GTIMModuleScorePlaceholderEngineV2138.toJson(report)
        val upgrade = report.optJSONObject("c1ToC2UpgradePathwayV2138") ?: GTIMC1ToC2UpgradePathwayV2138.toJson(report)
        val rank = report.optJSONObject("innovationPortfolioRankerV2138") ?: GTIMInnovationPortfolioRankerV2138.toJson(report)
        val c2Ready = upgrade.optString("state") == "C1_TO_C2_UPGRADE_PATHWAY_READY"
        val exportReady = export.optString("state") == "STALE_SURFACE_ZERO_EXPORT_READY"
        val hasScoreRows = (score.optJSONArray("moduleScoreRows")?.length() ?: 0) > 0
        val state = when {
            target.isBlank() -> "FINAL_INNOVATION_EXECUTION_NEEDS_CANONICAL_TARGET"
            exportReady && hasScoreRows && c2Ready -> "FINAL_INNOVATION_EXECUTION_BRIDGE_READY"
            exportReady && hasScoreRows -> "FINAL_INNOVATION_EXECUTION_C1_READY_C2_BLOCKED"
            else -> "FINAL_INNOVATION_EXECUTION_REVIEW_NOTES"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("canonicalTarget", target)
            .put("staleSurfaceItems", export.optInt("staleSurfaceItems", 0))
            .put("moduleScoreRows", score.optJSONArray("moduleScoreRows")?.length() ?: 0)
            .put("c2UpgradeState", upgrade.optString("state"))
            .put("portfolioRank", rank.optString("rank"))
            .put("strictnessPolicy", "relaxed_for_non_obvious_C1_generation_strict_for_C2_C3_validated_claims_and_all_clinical_claims")
            .put("routeLinkage", "legacy rails -> canonical target -> v2.13.7 synthesis -> v2.13.8 score placeholders -> C1-to-C2 bridge -> portfolio rank -> final locks")
            .put("claimPromotionAllowed", false)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final innovation-execution bridge",
        "State: ${obj.optString("state", "UNKNOWN")}; target=${obj.optString("canonicalTarget", "none")}; stale_surface_items=${obj.optInt("staleSurfaceItems", -1)}; module_rows=${obj.optInt("moduleScoreRows", 0)}.",
        "C2 state: ${obj.optString("c2UpgradeState", "unknown")}; portfolio=${obj.optString("portfolioRank", "unknown")}",
        "Strictness: ${obj.optString("strictnessPolicy", "C1 relaxed; C2+ strict")}",
        "Boundary: this is an innovation-execution bridge; no validated scientific, clinical, treatment, dosing, vaccine, or efficacy claim is made."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FINAL_INNOVATION_EXECUTION_BRIDGE_READY", "STALE_SURFACE_ZERO_EXPORT_READY", "module_score_placeholders_are_not_dge_results", CLAIM_LIMIT))
}
