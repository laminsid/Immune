package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.6 — Final study-result card and report compression layer.
 *
 * Purpose: make the first PDF/UI surface read like a world-class research dossier:
 * result first, value first, evidence limits clear, technical rails moved to appendix.
 * This layer deliberately relaxes blocked-only output into research-lead output while
 * preserving all hard claim locks: no diagnosis, no treatment, no administration, no
 * gene/pathway proof without reviewed evidence.
 */
object GTIMStudyResultCardV2126 {
    const val VERSION: String = "2.12.6-final-study-result-card-report-compression"
    const val CLAIM_LIMIT: String = "study_result_card_research_value_only_no_evidence_upgrade"

    data class Card(
        val status: String,
        val topic: String,
        val topResearchHypothesis: String,
        val functionalRepairCandidate: String,
        val biologicalToolClass: String,
        val evidenceGrade: String,
        val whyNotProven: String,
        val nextBestAction: String,
        val validationLadder: List<String>,
        val falsificationTriggers: List<String>,
        val matrixShortcutAction: String,
        val crossReportLearning: String,
        val reportShape: String,
        val boundary: String
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): Card {
        val technical = if (technicalLines.isNotEmpty()) technicalLines else GlobalResearchGradeBriefV11061.renderLines(report)
        val consistency = GTIMReportConsistencyGateV2121.build(report, technical)
        val candidateLedger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val selectedReviewTarget = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report).ifBlank { candidateLedger.optString("selectedReviewTarget").ifBlank { consistency.candidateLookupHandle } }
        val candidateHandleCount = candidateLedger.optInt("candidateHandleCount", consistency.candidateAccessionsFound)
        val functional = report.optJSONObject("functionalRepairDossierV2120")
            ?: GTIMFunctionalRepairDossierEngineV2120.toJson(report)
        val study = report.optJSONObject("studyGradeFunctionalSolutionV2121")
            ?: GTIMStudyGradeFunctionalSolutionEngineV2121.toJson(report, technical)
        val relaxed = report.optJSONObject("relaxedResearchLeadBridgeV2122")
            ?: GTIMRelaxedResearchLeadBridgeV2122.toJson(report, technical)
        val matrix = report.optJSONObject("matrixShortcutResolverV2124")
            ?: GTIMMatrixShortcutResolverV2124.toJson(report, technical)
        val global = report.optJSONObject("globalReportLearningV2124") ?: JSONObject()
        val selector = report.optJSONObject("domainSpecificHypothesisSelectorV2129")
            ?: GTIMDomainSpecificHypothesisSelectorV2129.toJson(report, technical)

        val dysfunction = functional.optJSONObject("dysfunctionModel") ?: JSONObject()
        val firstRepair = functional.optJSONArray("repairFunctions")?.optJSONObject(0) ?: JSONObject()
        val evidenceTension = functional.optJSONObject("evidenceTension") ?: JSONObject()
        val studyDesign = functional.optJSONObject("studyDesign") ?: JSONObject()

        val rawTopic = topic(report, technical)
        val focus = GTIMStudyFocusNormalizerV21282.build(rawTopic, relaxed.optString("routeBridge"), technical.joinToString(" "))
        val topic = selector.optString("studyFocus").ifBlank { focus.title }
        val root = firstNonBlank(
            selector.optString("rootDysfunction"),
            study.optString("rootCauseClaimCandidate"),
            dysfunction.optString("primaryDysfunction"),
            relaxed.optString("functionalBridge"),
            "root dysfunction still open; use this run as mechanism-first research lead"
        )
        val repair = firstNonBlank(
            selector.optString("repairFunction"),
            study.optString("functionalSolutionHypothesis"),
            firstRepair.optString("repairFunction"),
            relaxed.optString("functionalBridge"),
            "identify the missing biological repair function before nominating tools"
        )
        val tool = firstNonBlank(
            selector.optString("biologicalToolClass"),
            firstRepair.optString("biologicalToolClass"),
            extractToolClass(study.optString("microbialOrBiologicalToolRationale")),
            "function_first_biological_tool_candidate"
        )
        val hypothesis = selector.optString("topResearchHypothesis").ifBlank {
            "${root.oneLine()} → test whether ${repair.oneLine()} changes measurable immune/metabolic/barrier readouts."
        }
        val status = when {
            consistency.topicCompatibleTargetSelected && consistency.verifiedMatrixFiles > 0 -> "Study candidate ready for review-only analysis"
            consistency.topicCompatibleTargetSelected -> "Dataset lead accepted — matrix/capsule review required"
            selectedReviewTarget.isNotBlank() || candidateHandleCount > 0 -> "External review target selected — not evidence yet"
            else -> "Topic-level study lead — target discovery required"
        }
        val grade = when {
            consistency.topicCompatibleTargetSelected && consistency.verifiedMatrixFiles > 0 -> "C — review-only evidence capsule possible; not biological proof"
            consistency.topicCompatibleTargetSelected || selectedReviewTarget.isNotBlank() || candidateHandleCount > 0 -> "D+ — actionable research lead; useful for dataset follow-up"
            else -> "D — useful study route; needs dataset anchor"
        }
        val whyNot = when {
            consistency.verifiedMatrixFiles <= 0 -> "matrix/capsule evidence, comparator labels, sample-ID linkage, and reviewed expression output are not all closed"
            !consistency.topicCompatibleTargetSelected -> "topic-compatible target is not accepted yet"
            else -> "review-only evidence still requires contradiction checks and independent support"
        }
        val next = nextBestAction(consistency, matrix, topic, selector, selectedReviewTarget)
        val validation = listOf(
            firstNonBlank(jsonStrings(study.optJSONArray("validationLadder")).getOrNull(0).orEmpty(), "select or feed a topic-compatible dataset anchor"),
            "verify processed-expression capsule or raw/count matrix availability",
            "extract comparator labels, tissue/species, sample table, and source-to-sample provenance",
            "test pathway/module only after reviewed DGE or external gene-list provenance",
            "grade repair-function evidence separately from association evidence"
        ).distinct().take(5)
        val falsifiers = (jsonStrings(study.optJSONArray("falsificationTriggers")) + jsonStrings(evidenceTension.optJSONArray("killCriteria"))).distinct().ifEmpty {
            listOf("wrong tissue/species", "no reproducible accession or capsule", "weak comparator", "gene/pathway signal disappears under independent check")
        }.take(5)
        val matrixAction = firstNonBlank(
            matrix.optString("nextAction"),
            "run processed-expression shortcuts: GREIN, refine.bio, recount3, Expression Atlas, GEO2R/sample table"
        )
        val globalLearning = compactGlobalLearning(global)
        return Card(
            status = status,
            topic = topic,
            topResearchHypothesis = hypothesis,
            functionalRepairCandidate = repair,
            biologicalToolClass = tool,
            evidenceGrade = grade,
            whyNotProven = whyNot,
            nextBestAction = next,
            validationLadder = validation,
            falsificationTriggers = falsifiers,
            matrixShortcutAction = matrixAction,
            crossReportLearning = globalLearning,
            reportShape = "first_page_result_card_then_dossier_then_evidence_tasks; technical_contract_in_appendix",
            boundary = CLAIM_LIMIT
        )
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val c = build(report, technicalLines)
        return listOf(
            "Study Result Card",
            "Study focus: ${c.topic}",
            "Domain lock: ${domainLine(report, technicalLines)}",
            "Status: ${c.status}",
            "Top research hypothesis: ${c.topResearchHypothesis.takeClean(260)}",
            "Best functional repair candidate: ${c.functionalRepairCandidate.takeClean(240)}",
            "Candidate biological tool class: ${c.biologicalToolClass.takeClean(180)}",
            "Evidence grade: ${c.evidenceGrade}",
            "Why not proven yet: ${c.whyNotProven.takeClean(240)}",
            "Next best action: ${c.nextBestAction.takeClean(260)}",
            "Cross-report learning: ${c.crossReportLearning.takeClean(260)}",
            "Boundary: research-only; no diagnosis, treatment, administration route, organism-engineering steps, environmental release, or efficacy claim."
        )
    }

    fun compactDossierLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val c = build(report, technicalLines)
        return listOf(
            "Functional Study Dossier",
            "Validation ladder: ${c.validationLadder.joinToString("; ").takeClean(420)}",
            "What would falsify it: ${c.falsificationTriggers.joinToString("; ").takeClean(420)}",
            "Matrix/capsule route: ${c.matrixShortcutAction.takeClean(360)}",
            "Report policy: ${c.reportShape}; strictness relaxed for research value only, not for evidence upgrades."
        )
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val c = build(report, technicalLines)
        return JSONObject()
            .put("version", VERSION)
            .put("status", c.status)
            .put("topic", c.topic)
            .put("domainSpecificHypothesisSelector", GTIMDomainSpecificHypothesisSelectorV2129.toJson(report, technicalLines))
            .put("topResearchHypothesis", c.topResearchHypothesis)
            .put("functionalRepairCandidate", c.functionalRepairCandidate)
            .put("biologicalToolClass", c.biologicalToolClass)
            .put("evidenceGrade", c.evidenceGrade)
            .put("whyNotProven", c.whyNotProven)
            .put("nextBestAction", c.nextBestAction)
            .put("validationLadder", JSONArray(c.validationLadder))
            .put("falsificationTriggers", JSONArray(c.falsificationTriggers))
            .put("matrixShortcutAction", c.matrixShortcutAction)
            .put("crossReportLearning", c.crossReportLearning)
            .put("reportShape", c.reportShape)
            .put("claimLimit", c.boundary)
    }

    private fun nextBestAction(consistency: GTIMReportConsistencyGateV2121.TargetConsistency, matrix: JSONObject, topic: String, selector: JSONObject, selectedReviewTarget: String): String = when {
        consistency.topicCompatibleTargetSelected -> "Use Matrix Shortcut Resolver on ${consistency.acceptedTarget}: confirm processed/raw expression availability, comparator labels, source-to-sample provenance, and domain-specific fit (${selector.optString("domainKey")}) before any review-only DGE."
        selectedReviewTarget.isNotBlank() -> "Inspect $selectedReviewTarget as the canonical target; accept only if topic-fit, tissue/species, comparator labels, sample provenance, and matrix/capsule evidence match the ${selector.optString("studyFocus").ifBlank { topic }} question."
        selector.optString("nextBestActionHint").isNotBlank() -> selector.optString("nextBestActionHint")
        matrix.optString("query").isNotBlank() -> "Run topic-level external search and matrix shortcut for '${topic.ifBlank { matrix.optString("query") }}' before another raw-matrix hunt; treat results as review-only evidence capsule tasks."
        else -> "Run topic-level GEO/SRA/Europe PMC/OpenAlex search for ${topic.ifBlank { "the current research question" }} and capture the first compatible accession/capsule."
    }

    private fun domainLine(report: JSONObject, technicalLines: List<String>): String =
        GTIMDomainSpecificHypothesisSelectorV2129.publicLine(report, technicalLines)

    private fun compactGlobalLearning(global: JSONObject): String {
        val repeated = jsonStrings(global.optJSONArray("repeatedMechanisms")).take(4)
        val blockers = jsonStrings(global.optJSONArray("repeatedBlockers")).take(3)
        val bridges = jsonStrings(global.optJSONArray("crossReportBridges")).take(2)
        return when {
            repeated.isNotEmpty() -> "repeated mechanisms=${repeated.joinToString(", ")}; blockers=${blockers.joinToString(", ").ifBlank { "matrix/comparator/sample linkage" }}"
            bridges.isNotEmpty() -> bridges.joinToString(" | ")
            else -> "global learning active; repeated matrix/capsule and comparator blockers should be resolved before more raw search"
        }
    }

    private fun topic(report: JSONObject, lines: List<String>): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        return firstNonBlank(
            topic.optString("normalizedTopic"),
            topic.optString("rawInput"),
            lineAfter(lines, "Research topic:"),
            lineAfter(lines, "What the app understood:"),
            "unspecified immune research topic"
        )
    }

    private fun extractToolClass(rationale: String): String = Regex("Investigate\\s+([A-Za-z0-9_/-]+)").find(rationale)?.groupValues?.getOrNull(1).orEmpty()
    private fun lineAfter(lines: List<String>, prefix: String): String = lines.firstOrNull { it.startsWith(prefix) }?.removePrefix(prefix)?.trim().orEmpty()
    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { array.optString(it).takeIf { v -> v.isNotBlank() } }
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
    private fun String.takeClean(max: Int): String {
        val clean = oneLine()
        return if (clean.length <= max) clean else clean.take(max).trimEnd()
    }
}
