package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

/**
 * v2.12.4 — Matrix shortcut resolver.
 *
 * The old path stopped repeatedly at "raw/count matrix missing". This layer adds a
 * review-only shortcut path through public processed-expression resources and compact
 * database checks. It never marks DGE_READY, never runs internal DGE, and never treats a
 * processed-expression hit as biological proof. It only creates actionable lookup tasks
 * that can carry the research run past a dead P1 stop.
 */
object GTIMMatrixShortcutResolverV2124 {
    const val VERSION: String = "2.12.4-matrix-shortcut-resolver"
    const val CLAIM_LIMIT: String = "processed_expression_shortcut_lookup_only_not_internal_dge_ready"

    data class MatrixShortcutRouteV2124(
        val source: String,
        val routeType: String,
        val queryOrHandle: String,
        val url: String,
        val extracts: List<String>,
        val decisionImpact: String,
        val safety: String
    )

    data class MatrixShortcutReportV2124(
        val active: Boolean,
        val state: String,
        val handle: String,
        val query: String,
        val routes: List<MatrixShortcutRouteV2124>,
        val nextAction: String,
        val upgradeRule: String,
        val boundary: String
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): MatrixShortcutReportV2124 {
        val consistency = GTIMReportConsistencyGateV2121.build(report, technicalLines)
        val external = report.optJSONObject("externalRouterV211310") ?: JSONObject()
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val handle = firstNonBlank(
            GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report),
            consistency.acceptedTarget,
            ledger.optString("selectedReviewTarget"),
            consistency.candidateLookupHandle,
            external.optString("targetId"),
            extractHandle(report.toString()),
            ""
        ).let { if (isInvalidHandle(it)) "" else it }
        val query = firstNonBlank(
            topicFromReport(report),
            external.optString("query"),
            handle,
            "immune expression matrix comparator metadata"
        )
        val key = handle.ifBlank { query }
        val rawMissing = joined(report, technicalLines).let { text ->
            text.contains("MATRIX", true) || text.contains("DGE_NOT_READY", true) || text.contains("OBSERVED_FILE_EVIDENCE", true) || text.contains("matrix", true)
        }
        val routes = mutableListOf<MatrixShortcutRouteV2124>()
        routes += route(
            "GREIN",
            "geo_processed_expression_check",
            key,
            if (handle.startsWith("GSE", true)) "https://www.ilincs.org/apps/grein/?gse=${enc(handle.uppercase(Locale.US))}" else "https://www.ilincs.org/apps/grein/",
            listOf("dataset availability", "sample group labels", "processed expression summary", "download/export availability"),
            "If available with usable comparator labels, move from raw-matrix dead stop to review-only processed-expression evidence capsule.",
            "availability_and_processed_summary_only"
        )
        routes += route(
            "refine.bio",
            "processed_expression_search",
            key,
            if (handle.isNotBlank()) "https://www.refine.bio/search?q=${enc(handle)}" else "https://www.refine.bio/search?q=${enc(query)}",
            listOf("normalized expression availability", "organism", "sample annotations", "download package clue"),
            "If a processed package exists, create a matrix-shortcut task and require reviewer confirmation before any gene claim.",
            "processed_matrix_lookup_only"
        )
        routes += route(
            "recount3",
            "rna_seq_processed_counts_check",
            key,
            if (handle.isNotBlank()) "https://jhubiostatistics.shinyapps.io/recount3-study-explorer/?study=${enc(handle)}" else "https://jhubiostatistics.shinyapps.io/recount3-study-explorer/",
            listOf("study presence", "project/sample metadata", "processed counts availability", "human/mouse scope"),
            "If study is present, prefer source-to-sample provenance and comparator labels before any DGE queue.",
            "rna_seq_count_lookup_only"
        )
        routes += route(
            "Expression Atlas / ArrayExpress",
            "arrayexpress_expression_lookup",
            key,
            "https://www.ebi.ac.uk/gxa/search?query=${enc(key)}",
            listOf("ArrayExpress/E-MTAB link", "baseline/differential expression hints", "organism/tissue", "experiment accession"),
            "If Atlas links a compatible experiment, use it as external evidence capsule, not internal proof.",
            "atlas_lookup_only"
        )
        routes += route(
            "GEO2R / GEO sample table",
            "comparator_label_probe",
            key,
            if (handle.startsWith("GSE", true)) "https://www.ncbi.nlm.nih.gov/geo/geo2r/?acc=${enc(handle.uppercase(Locale.US))}" else "https://www.ncbi.nlm.nih.gov/gds/?term=${enc(query)}",
            listOf("GSM groups", "case/control labels", "platform", "sample count"),
            "Use only to inspect labels and feasibility; do not treat browser output as reviewed internal DGE.",
            "label_feasibility_only"
        )
        val state = when {
            handle.isNotBlank() && rawMissing -> "MATRIX_SHORTCUT_CANDIDATE_READY"
            handle.isNotBlank() -> "MATRIX_SHORTCUT_LOOKUP_READY"
            else -> "MATRIX_SHORTCUT_TOPIC_SEARCH_READY"
        }
        return MatrixShortcutReportV2124(
            active = true,
            state = state,
            handle = handle,
            query = query,
            routes = routes,
            nextAction = "Use processed-expression shortcut sources before declaring matrix dead-end: check GREIN/refine.bio/recount3/Expression Atlas, then extract sample labels, processed matrix availability, and source-to-sample provenance.",
            upgradeRule = "Shortcut may upgrade usability from blocked to review-only evidence capsule; it cannot upgrade to internal DGE_READY or gene/pathway proof without verified matrix/comparator/sample-linkage review.",
            boundary = CLAIM_LIMIT
        )
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val s = build(report, technicalLines)
        val lines = mutableListOf<String>()
        lines += "Matrix shortcut resolver"
        lines += "Shortcut state: ${s.state} — raw GEO matrix missing no longer ends the run; processed-expression sources are queued for review-only lookup."
        lines += if (s.handle.isNotBlank()) "Shortcut handle: ${s.handle}" else "Shortcut query: ${s.query.take(180)}"
        lines += "What changes now: the app continues through compact/processed databases to find usable expression packages, comparator labels, and sample provenance instead of repeating the same matrix stop."
        s.routes.take(5).forEachIndexed { index, route ->
            lines += "${index + 1}. ${route.source}: ${route.routeType}; extract=${route.extracts.take(3).joinToString(", ")}; decision=${route.decisionImpact.take(150)}; link=${route.url.take(180)}"
        }
        lines += GTIMMatrixShortcutStatusLayerV2129.publicLines(report, technicalLines).take(3)
        lines += "Matrix shortcut boundary: ${s.upgradeRule}"
        return lines
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val s = build(report, technicalLines)
        val routes = JSONArray()
        s.routes.forEach { r ->
            routes.put(JSONObject()
                .put("source", r.source)
                .put("routeType", r.routeType)
                .put("queryOrHandle", r.queryOrHandle)
                .put("url", r.url)
                .put("extracts", JSONArray(r.extracts))
                .put("decisionImpact", r.decisionImpact)
                .put("safety", r.safety))
        }
        return JSONObject()
            .put("version", VERSION)
            .put("active", s.active)
            .put("state", s.state)
            .put("handle", s.handle)
            .put("query", s.query)
            .put("nextAction", s.nextAction)
            .put("upgradeRule", s.upgradeRule)
            .put("claimLimit", s.boundary)
            .put("routes", routes)
            .put("statusLayer", GTIMMatrixShortcutStatusLayerV2129.toJson(report, technicalLines))
    }

    fun technicalLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val s = build(report, technicalLines)
        return listOf(
            "Matrix shortcut resolver: version=$VERSION | state=${s.state} | handle=${s.handle.ifBlank { "NONE" }} | query=${s.query} | claim_limit=${s.boundary}",
            "Matrix shortcut next: ${s.nextAction}",
            "Matrix shortcut upgrade rule: ${s.upgradeRule}"
        ) + s.routes.map { "Matrix shortcut route: source=${it.source} | type=${it.routeType} | handle=${it.queryOrHandle} | url=${it.url} | safety=${it.safety}" }
    }

    private fun route(source: String, routeType: String, queryOrHandle: String, url: String, extracts: List<String>, decisionImpact: String, safety: String): MatrixShortcutRouteV2124 =
        MatrixShortcutRouteV2124(source, routeType, clean(queryOrHandle), url, extracts.map { clean(it) }, clean(decisionImpact), safety)

    private fun topicFromReport(report: JSONObject): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossierReport") ?: report.optJSONObject("mechanismDiscoveryDossier") ?: JSONObject()
        return firstNonBlank(topic.optString("normalizedTopic"), topic.optString("rawInput"), mechanism.optString("researchQuestion"), report.optString("topic"))
    }

    private fun extractHandle(text: String): String = Regex("\\b(GSE\\d{3,}|PRJNA\\d+|SRP\\d+|SRR\\d+|SDY\\d+|E-MTAB-\\d+)\\b", RegexOption.IGNORE_CASE)
        .find(text)?.value.orEmpty().uppercase(Locale.US)

    private fun isInvalidHandle(value: String): Boolean {
        val v = value.trim().uppercase(Locale.US)
        if (v.isBlank()) return false
        return v == "NO_TOPIC_COMPAT" ||
            v == "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" ||
            v == "BLOCKED" ||
            v == "UNKNOWN" ||
            v == "NONE" ||
            v.startsWith("PMID")
    }

    private fun joined(report: JSONObject, technicalLines: List<String>): String = report.toString() + " " + technicalLines.joinToString(" ")
    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")
    private fun clean(value: String): String = value.replace(Regex("\\s+"), " ").trim()
    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""
}
