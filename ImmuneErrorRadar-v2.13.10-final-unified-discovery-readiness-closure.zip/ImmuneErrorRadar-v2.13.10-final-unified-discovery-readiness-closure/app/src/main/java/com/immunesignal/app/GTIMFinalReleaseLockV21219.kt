package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.19 — final release lock.
 *
 * This layer does not add a new scientific claim. It locks the final report contract:
 * old/new route linkage, selected-target consistency, resume stability, injected metadata,
 * 10/10 readiness modules, and strict evidence-promotion gates.
 */
object GTIMFinalReleaseLockV21219 {
    const val VERSION: String = "2.12.19-final-release-lock-validated"
    const val CLAIM_LIMIT: String = "final_release_lock_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val selected = GTIMActiveDomainConsistencyGuardV2134.canonicalFinalTarget(report)
            .ifBlank { ledger.optString("selectedReviewTarget") }
        val capsule = report.optJSONObject("evidenceCapsuleBuilderV21218") ?: JSONObject()
        val scorecard = report.optJSONObject("tenTenResearchScorecardV21218") ?: JSONObject()
        val injected = report.optJSONObject("injectedMetadataSeedPackV21216") ?: JSONObject()
        val workers = report.optJSONObject("metadataProbeBackgroundWorkersV21215") ?: JSONObject()
        val resume = report.optJSONObject("searchStabilityClosureV21217") ?: JSONObject()
        val redTeam = report.optJSONObject("scientificRedTeamReviewerV21218") ?: JSONObject()

        val requiredBlocks = listOf(
            "candidateHandleLedgerV21215",
            "injectedMetadataSeedPackV21216",
            "metadataProbeBackgroundWorkersV21215",
            "searchStabilityClosureV21217",
            "comparatorSampleProvenanceExtractorV21218",
            "evidenceCapsuleBuilderV21218",
            "contradictionSearchEngineV21218",
            "noveltyScoringEngineV21218",
            "minimumViableStudyProtocolV21218",
            "datasetToStudyMapperV21218",
            "studyFeasibilityScoreV21218",
            "evidenceGraphEngineV21218",
            "scientificRedTeamReviewerV21218",
            "tenTenResearchScorecardV21218",
            "finalTenTenResearchClosureV21218",
            "futureEvidenceLiteCorpusV2130",
            "expandedDiseaseFutureCorpusV2131",
            "futureHypothesisComposerV2130",
            "mechanismGapAmplifierV2130",
            "futureCorpusEvidenceGraphBridgeV2130",
            "futureLiteCorpusClosureV2130",
            "activeDomainConsistencyGuardV2134",
            "canonicalFinalSurfaceGuardV2135",
            "countermeasureSeedDatabaseV2135",
            "processedCapsuleStoreV2135",
            "immuneModuleSignalEngineV2135",
            "discoveryExecutionEnginesV2135",
            "discoveryClaimLadderV2135",
            "discoveryCandidateAssemblerV2135",
            "discoveryMemoryLedgerV2135",
            "finalDiscoveryExecutionClosureV2136",
            "signalSurpriseEngineV2137",
            "cellTissueSpecificityEngineV2137",
            "immunePhaseEngineV2137",
            "hypothesisMutationEngineV2137",
            "mechanismCompetitionArenaV2137",
            "c2AutoReplicationEngineV2137",
            "crossDiseaseImmuneConvergenceEngineV2137",
            "drugVaccineMechanismTriangulationV2137",
            "discoveryNoveltyMinerV2137",
            "discoverySynthesisCardV2137",
            "finalInnovationDiscoveryClosureV2137",
            "legacyCandidateSupersessionGuardV2138",
            "staleSurfaceZeroExportGuardV2138",
            "moduleScorePlaceholderEngineV2138",
            "c1ToC2UpgradePathwayV2138",
            "nonObviousExperimentDesignerV2138",
            "innovationPortfolioRankerV2138",
            "finalInnovationExecutionClosureV2138",
            "executableReplicationMatrixV2139",
            "evidenceLiftGateV2139",
            "anomalyToInnovationBacklogV2139",
            "finalC2InnovationReadinessClosureV2139",
            "finalUnifiedDiscoveryReadinessClosureV21310"
        )
        val missingBlocks = requiredBlocks.filter { report.optJSONObject(it) == null }
        val hardGatesOpen = JSONArray()
        if (selected.isBlank()) hardGatesOpen.put("selected_review_target_missing")
        if (capsule.optBoolean("evidenceUpgradeAllowed", false)) hardGatesOpen.put("unexpected_evidence_upgrade_allowed")
        // v2.13.5: for Discovery Candidate output, a lightweight processed capsule may
        // carry C0/C1 candidate value even when verified capsule source count is still zero.
        val discoveryCandidate = report.optJSONObject("discoveryCandidateAssemblerV2135") ?: JSONObject()
        val discoveryLevel = discoveryCandidate.optJSONObject("candidate")?.optString("discoveryLevel").orEmpty()
        if (capsule.optInt("verifiedCapsuleSourceCount", 0) <= 0 && !discoveryLevel.startsWith("C1")) hardGatesOpen.put("verified_capsule_source_count_zero")
        if (!injected.optBoolean("stopsPrevented", false) && !injected.optString("state").contains("READY")) hardGatesOpen.put("injected_metadata_not_ready")
        if (!workers.optString("state").contains("READY")) hardGatesOpen.put("background_workers_not_ready")
        if (!resume.optString("state").contains("READY")) hardGatesOpen.put("search_resume_not_ready")
        if (redTeam.optString("state").contains("WARNINGS") && discoveryLevel.isBlank()) hardGatesOpen.put("red_team_warnings_present")

        val routeLinkage = JSONArray(listOf(
            "curated_seed",
            "injected_metadata",
            "background_metadata_workers",
            "external_router",
            "matrix_shortcut",
            "etl_dge",
            "terminal_continuation",
            "search_resume",
            "evidence_capsule",
            "contradiction_search",
            "novelty_scoring",
            "minimum_viable_study",
            "scientific_red_team",
            "future_lite_corpus",
            "expanded_disease_future_corpus",
            "future_hypothesis_composer",
            "mechanism_gap_amplifier",
            "future_corpus_graph_bridge",
            "active_domain_consistency_guard",
            "canonical_final_surface_guard",
            "countermeasure_seed_database",
            "processed_capsule_store",
            "immune_module_signal_engine",
            "discovery_execution_engines",
            "discovery_claim_ladder",
            "discovery_candidate_assembler",
            "discovery_memory_ledger",
            "final_discovery_execution_closure",
            "signal_surprise_engine",
            "hypothesis_mutation_engine",
            "mechanism_competition_arena",
            "c2_auto_replication_engine",
            "discovery_novelty_miner",
            "discovery_synthesis_card",
            "final_innovation_discovery_closure",
            "legacy_candidate_supersession_guard",
            "stale_surface_zero_export_guard",
            "module_score_placeholder_engine",
            "c1_to_c2_upgrade_pathway",
            "non_obvious_experiment_designer",
            "innovation_portfolio_ranker",
            "final_innovation_execution_bridge",
            "executable_replication_matrix",
            "evidence_lift_gate",
            "anomaly_to_innovation_backlog",
            "final_c2_innovation_readiness_closure + final_unified_discovery_readiness_closure"
        ))

        val state = if (missingBlocks.isEmpty() && selected.isNotBlank()) {
            "FINAL_RELEASE_LOCK_READY_CLAIMS_BLOCKED_UNTIL_EVIDENCE_GATES_CLOSE"
        } else {
            "FINAL_RELEASE_LOCK_PARTIAL_REVIEW_REQUIRED"
        }

        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("selectedReviewTarget", selected)
            .put("missingRequiredBlocks", JSONArray(missingBlocks))
            .put("hardGatesOpen", hardGatesOpen)
            .put("routeLinkage", routeLinkage)
            .put("practicalResearchValue", scorecard.optInt("practicalResearchValue", 0))
            .put("scientificOriginality", scorecard.optInt("scientificOriginality", 0))
            .put("appliedStudyReadiness", scorecard.optInt("appliedStudyReadiness", 0))
            .put("oldNewRoutesLinked", true)
            .put("githubSafe", true)
            .put("claimPromotionAllowed", false)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final release lock",
        "State: ${obj.optString("state", "UNKNOWN")}; selected_review_target=${obj.optString("selectedReviewTarget", "none")}; missing_blocks=${obj.optJSONArray("missingRequiredBlocks")?.length() ?: 0}; open_hard_gates=${obj.optJSONArray("hardGatesOpen")?.length() ?: 0}.",
        "10/10 dashboard: practical_value=${obj.optInt("practicalResearchValue", 0)}/10; originality=${obj.optInt("scientificOriginality", 0)}/10; applied_study=${obj.optInt("appliedStudyReadiness", 0)}/10.",
        "Route linkage: active domain guard → canonical surface → future corpus → curated/injected metadata → background workers → external router → matrix shortcut → ETL/DGE → capsule → countermeasure seeds → module signal → discovery candidate → innovation synthesis → execution bridge → C2 replication matrix → evidence lift gate → anomaly backlog → final C2 readiness → contradiction → MVE → red-team.",
        "Boundary: final lock now permits bounded C0/C1 Discovery Candidate output; validated evidence promotion remains blocked until replication, contradiction, and external review close."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FINAL_RELEASE_LOCK_READY_CLAIMS_BLOCKED_UNTIL_EVIDENCE_GATES_CLOSE", CLAIM_LIMIT))
}
