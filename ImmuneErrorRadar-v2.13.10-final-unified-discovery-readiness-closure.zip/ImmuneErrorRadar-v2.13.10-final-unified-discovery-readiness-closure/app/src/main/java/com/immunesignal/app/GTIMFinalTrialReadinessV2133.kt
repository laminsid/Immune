package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.3 — final test-readiness lock.
 *
 * This layer is intentionally conservative: it does not invent proof and it does not
 * promote evidence. It verifies that the newly added data-closure, corpus, resume,
 * capsule, contradiction, and study-protocol routes are visible in one final report
 * surface before the build is handed to GitHub/device testing.
 */
object GTIMFinalTrialReadinessV2133 {
    const val VERSION: String = "2.13.3-final-test-ready-data-closure-unified"
    const val CLAIM_LIMIT: String = "test_ready_lock_no_evidence_or_clinical_claim_upgrade"

    private val requiredBlocks: List<String> = listOf(
        "candidateHandleLedgerV21215",
        "injectedMetadataSeedPackV21216",
        "metadataProbeBackgroundWorkersV21215",
        "searchStabilityClosureV21217",
        "comparatorSampleProvenanceExtractorV21218",
        "evidenceCapsuleBuilderV21218",
        "contradictionSearchEngineV21218",
        "noveltyScoringEngineV21218",
        "minimumViableStudyProtocolV21218",
        "datasetToStudyMapperV21218",
        "studyFeasibilityScoreV21218",
        "evidenceGraphEngineV21218",
        "scientificRedTeamReviewerV21218",
        "tenTenResearchScorecardV21218",
        "finalTenTenResearchClosureV21218",
        "finalReleaseLockV21219",
        "futureEvidenceLiteCorpusV2130",
        "futureHypothesisComposerV2130",
        "mechanismGapAmplifierV2130",
        "futureCorpusEvidenceGraphBridgeV2130",
        "futureLiteCorpusClosureV2130",
        "expandedDiseaseFutureCorpusV2131",
        "verifiedMetadataClosurePackV2132",
        "closedEvidenceCapsuleV2132",
        "dataClosureStudyReadinessV2132",
        "finalDataClosureExecutionV2132",
        "activeDomainConsistencyGuardV2134",
        "canonicalFinalSurfaceGuardV2135",
        "countermeasureSeedDatabaseV2135",
        "processedCapsuleStoreV2135",
        "immuneModuleSignalEngineV2135",
        "discoveryExecutionEnginesV2135",
        "discoveryClaimLadderV2135",
        "discoveryCandidateAssemblerV2135",
        "discoveryMemoryLedgerV2135",
        "finalDiscoveryExecutionClosureV2136",
        "signalSurpriseEngineV2137",
        "cellTissueSpecificityEngineV2137",
        "immunePhaseEngineV2137",
        "hypothesisMutationEngineV2137",
        "mechanismCompetitionArenaV2137",
        "c2AutoReplicationEngineV2137",
        "crossDiseaseImmuneConvergenceEngineV2137",
        "drugVaccineMechanismTriangulationV2137",
        "discoveryNoveltyMinerV2137",
        "discoverySynthesisCardV2137",
        "finalInnovationDiscoveryClosureV2137",
            "legacyCandidateSupersessionGuardV2138",
            "staleSurfaceZeroExportGuardV2138",
            "moduleScorePlaceholderEngineV2138",
            "c1ToC2UpgradePathwayV2138",
            "nonObviousExperimentDesignerV2138",
            "innovationPortfolioRankerV2138",
            "finalInnovationExecutionClosureV2138",
            "executableReplicationMatrixV2139",
            "evidenceLiftGateV2139",
            "anomalyToInnovationBacklogV2139",
            "finalC2InnovationReadinessClosureV2139",
            "finalUnifiedDiscoveryReadinessClosureV21310"
    )

    fun toJson(report: JSONObject): JSONObject {
        val missing = requiredBlocks.filter { report.optJSONObject(it) == null }
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val workers = report.optJSONObject("metadataProbeBackgroundWorkersV21215") ?: JSONObject()
        val resume = report.optJSONObject("searchStabilityClosureV21217") ?: JSONObject()
        val closure = report.optJSONObject("finalDataClosureExecutionV2132") ?: JSONObject()
        val releaseLock = report.optJSONObject("finalReleaseLockV21219") ?: JSONObject()
        val redTeam = report.optJSONObject("scientificRedTeamReviewerV21218") ?: JSONObject()

        val activeGuard = report.optJSONObject("activeDomainConsistencyGuardV2134") ?: JSONObject()
        val selectedTarget = GTIMActiveDomainConsistencyGuardV2134.canonicalFinalTarget(report)
            .ifBlank { firstNonBlank(activeGuard.optString("canonicalFinalTarget"), closure.optString("selectedClosedTarget"), ledger.optString("selectedReviewTarget"), releaseLock.optString("selectedReviewTarget")) }
        val executed = workers.optJSONArray("executedSteps")?.length()
            ?: workers.optInt("executedStepCount", 0)
        val queued = workers.optJSONArray("queuedSteps")?.length()
            ?: workers.optInt("queuedStepCount", 0)
        val blocked = workers.optJSONArray("blockedSteps")?.length()
            ?: workers.optInt("blockedStepCount", 0)

        val openRisks = JSONArray()
        if (selectedTarget.isBlank()) openRisks.put("selected_review_target_not_locked_yet")
        if (!resume.optString("state").contains("READY")) openRisks.put("resume_state_not_ready")
        if (!workers.optString("state").contains("READY")) openRisks.put("background_worker_state_not_ready")
        if (redTeam.optString("state").contains("BLOCK")) openRisks.put("red_team_blocker_present")
        if (missing.isNotEmpty()) openRisks.put("missing_required_runtime_blocks")

        val state = if (missing.isEmpty() && openRisks.length() == 0) {
            "FINAL_TEST_READY_RELEASE_LOCKED"
        } else if (missing.isEmpty()) {
            "FINAL_TEST_READY_WITH_REVIEW_NOTES"
        } else {
            "FINAL_TEST_READINESS_PARTIAL"
        }

        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("selectedReviewTarget", selectedTarget)
            .put("requiredBlockCount", requiredBlocks.size)
            .put("missingRequiredBlocks", JSONArray(missing))
            .put("openReviewRisks", openRisks)
            .put("backgroundWorkerExecutedSteps", executed)
            .put("backgroundWorkerQueuedSteps", queued)
            .put("backgroundWorkerBlockedSteps", blocked)
            .put("oldNewRoutesLinked", true)
            .put("githubSafeWorkflowContract", "runner_native_java17_no_setup_java_no_actions_cache")
            .put("testPrompts", JSONArray(listOf(
                "depression kynurenine IDO1 KMO neuroimmune transcriptomics",
                "COVID post-viral interferon IL-6 TNF recovery severity",
                "Ebola filovirus host-response interferon endothelial injury",
                "allergy type-2 IgE eosinophil IL-4 IL-13 barrier",
                "cancer tumor immune microenvironment T-cell exhaustion myeloid inflammation"
            )))
            .put("expectedReportMarkers", JSONArray(listOf(
                "Injected metadata/provenance seed pack",
                "Background metadata workers",
                "Candidate handle ledger",
                "Closed evidence capsule",
                "Data-closure study readiness",
                "Contradiction search engine",
                "Minimum viable study protocol",
                "Final data-closure execution",
                "Final test-readiness lock",
                "Discovery Candidate Card",
                "Signal Surprise Engine",
                "Hypothesis Mutation Engine",
                "Discovery Synthesis Card",
                "Final Innovation Discovery Closure",
                "Final discovery-execution closure"
            )))
            .put("claimPromotionAllowed", false)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final test-readiness lock",
        "State: ${obj.optString("state", "UNKNOWN")}; selected_review_target=${obj.optString("selectedReviewTarget", "none")}; missing_blocks=${obj.optJSONArray("missingRequiredBlocks")?.length() ?: 0}; review_risks=${obj.optJSONArray("openReviewRisks")?.length() ?: 0}.",
        "Background execution: executed=${obj.optInt("backgroundWorkerExecutedSteps", 0)}; queued=${obj.optInt("backgroundWorkerQueuedSteps", 0)}; blocked=${obj.optInt("backgroundWorkerBlockedSteps", 0)}.",
        "GitHub safety: ${obj.optString("githubSafeWorkflowContract", "not declared")}; old/new routes linked=${obj.optBoolean("oldNewRoutesLinked", false)}.",
        "Test contract: run depression/kynurenine, COVID/post-viral, Ebola/filovirus, allergy/type-2, and cancer/TME prompts; verify capsule, comparator/provenance, contradiction, protocol, and final lock markers.",
        "Boundary: this is a test-ready release lock only; no diagnosis, treatment, mechanism proof, DGE claim, or clinical efficacy is promoted."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FINAL_TEST_READY_RELEASE_LOCKED", "runner_native_java17_no_setup_java_no_actions_cache", CLAIM_LIMIT))

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}
