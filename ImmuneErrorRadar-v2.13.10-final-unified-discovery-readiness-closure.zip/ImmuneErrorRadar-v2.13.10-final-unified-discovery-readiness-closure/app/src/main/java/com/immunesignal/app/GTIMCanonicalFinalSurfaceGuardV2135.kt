package com.immunesignal.app

import org.json.JSONObject

/** v2.13.5 — Canonical final-surface routing guard.
 * Forces legacy and new public blocks to use the same final target and suppresses
 * cross-domain future-corpus text. This fixes stale Study Result Card / Matrix Shortcut
 * handles after ActiveDomain data closure.
 */
object GTIMCanonicalFinalSurfaceGuardV2135 {
    const val VERSION: String = "2.13.5-canonical-final-surface-guard"
    const val CLAIM_LIMIT: String = "canonical_surface_guard_no_evidence_upgrade"

    fun canonicalTarget(report: JSONObject): String = GTIMActiveDomainConsistencyGuardV2134.canonicalFinalTarget(report)
        .ifBlank { report.optJSONObject("verifiedMetadataClosurePackV2132")?.optString("selectedClosedTarget").orEmpty() }
        .ifBlank { report.optJSONObject("finalDataClosureExecutionV2132")?.optString("selectedClosedTarget").orEmpty() }
        .ifBlank { report.optJSONObject("candidateHandleLedgerV21215")?.optString("selectedReviewTarget").orEmpty() }

    fun activeDomain(report: JSONObject): String = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)

    fun futureCorpusMatchesActive(report: JSONObject): Boolean {
        val active = activeDomain(report)
        val future = report.optJSONObject("futureEvidenceLiteCorpusV2130")?.optString("domainKey").orEmpty()
        return future.isBlank() || GTIMActiveDomainConsistencyGuardV2134.domainCompatible(active, future, GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report))
    }

    fun toJson(report: JSONObject): JSONObject {
        val active = activeDomain(report)
        val canonical = canonicalTarget(report)
        val futureMatches = futureCorpusMatchesActive(report)
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (canonical.isNotBlank()) "CANONICAL_FINAL_SURFACE_READY" else "CANONICAL_FINAL_SURFACE_NEEDS_TARGET")
            .put("activeDomain", active)
            .put("canonicalTarget", canonical)
            .put("futureCorpusMatchesActiveDomain", futureMatches)
            .put("futureCorpusRenderPolicy", if (futureMatches) "render_domain_specific_future_blocks" else "background_contradiction_only_no_future_hypothesis_targets_readouts")
            .put("oldNewRoutesLinked", true)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Canonical final-surface guard",
        "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; future_match=${obj.optBoolean("futureCorpusMatchesActiveDomain", false)}.",
        "Policy: ${obj.optString("futureCorpusRenderPolicy", "background-only when mismatched")}; old/new routes remain linked.",
        "Boundary: canonical routing improves report reliability; it does not prove biology."
    )
}
