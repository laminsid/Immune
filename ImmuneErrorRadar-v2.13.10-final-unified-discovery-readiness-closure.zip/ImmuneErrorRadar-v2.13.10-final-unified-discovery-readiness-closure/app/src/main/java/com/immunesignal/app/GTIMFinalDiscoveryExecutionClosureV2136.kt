package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.6 — final discovery-execution closure.
 * This is the last public-surface guard after v2.13.5. It verifies that the report can
 * emit a bounded Discovery Candidate while final rendering, future-corpus priors,
 * matrix shortcuts, and legacy release locks all agree on the same canonical target.
 * It does not validate biology, treatment, vaccine use, dosing, or efficacy.
 */
object GTIMFinalDiscoveryExecutionClosureV2136 {
    const val VERSION: String = "2.13.6-final-discovery-execution-closure"
    const val CLAIM_LIMIT: String = "final_discovery_execution_candidate_not_validated_scientific_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val subtype = GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report)
        val canonical = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val future = report.optJSONObject("futureEvidenceLiteCorpusV2130") ?: JSONObject()
        val futureSelected = future.optString("selectedDomain", future.optString("domainKey"))
        val futureDomain = future.optString("domainKey")
        val futureCompatible = future.optBoolean("futureCorpusCompatible", futureSelected == futureDomain && futureDomain == active) &&
            GTIMActiveDomainConsistencyGuardV2134.domainCompatible(active, futureDomain, subtype) && futureSelected == futureDomain
        val composer = report.optJSONObject("futureHypothesisComposerV2130") ?: JSONObject()
        val matrix = report.optJSONObject("matrixShortcutResolverV2124") ?: GTIMMatrixShortcutResolverV2124.toJson(report)
        val finalRelease = report.optJSONObject("finalReleaseLockV21219") ?: JSONObject()
        val finalTest = report.optJSONObject("finalTestReadinessV2133") ?: JSONObject()
        val discovery = report.optJSONObject("discoveryCandidateAssemblerV2135") ?: JSONObject()
        val candidate = discovery.optJSONObject("candidate") ?: JSONObject()
        val discoveryLevel = candidate.optString("discoveryLevel", "C0_ROUTE_ONLY")
        val stale = JSONArray()
        if (canonical.isBlank()) stale.put("canonical_target_missing")
        val matrixHandle = matrix.optString("handle")
        if (matrixHandle.isNotBlank() && canonical.isNotBlank() && matrixHandle != canonical) stale.put("matrix_handle_not_canonical:$matrixHandle->$canonical")
        val releaseTarget = finalRelease.optString("selectedReviewTarget")
        if (releaseTarget.isNotBlank() && canonical.isNotBlank() && releaseTarget != canonical) stale.put("final_release_target_not_canonical:$releaseTarget->$canonical")
        val testTarget = finalTest.optString("selectedReviewTarget")
        if (testTarget.isNotBlank() && canonical.isNotBlank() && testTarget != canonical) stale.put("final_test_target_not_canonical:$testTarget->$canonical")
        if (!futureCompatible && !composer.optString("state").contains("DOMAIN_MISMATCH")) stale.put("future_corpus_mismatch_not_suppressed:$futureSelected->$active")
        val canEmitCandidate = canonical.isNotBlank() && candidate.optString("canonicalTarget").ifBlank { canonical } == canonical && discoveryLevel.startsWith("C")
        val state = when {
            stale.length() == 0 && canEmitCandidate -> "FINAL_DISCOVERY_EXECUTION_CANDIDATE_READY"
            stale.length() == 0 -> "FINAL_DISCOVERY_EXECUTION_ROUTE_READY"
            else -> "FINAL_DISCOVERY_EXECUTION_REVIEW_NOTES"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("activeDomain", active)
            .put("activeSubtype", subtype)
            .put("canonicalTarget", canonical)
            .put("futureCorpusCompatible", futureCompatible)
            .put("futureCorpusRenderPolicy", if (futureCompatible) "domain_specific_future_blocks_allowed" else "background_contradiction_only_no_future_hypothesis_targets_readouts")
            .put("discoveryLevel", discoveryLevel)
            .put("discoveryCandidateReady", canEmitCandidate)
            .put("staleSurfaceFindings", stale)
            .put("oldNewRoutesLinked", true)
            .put("claimPromotionAllowed", false)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final discovery-execution closure",
        "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; discovery_level=${obj.optString("discoveryLevel", "C0_ROUTE_ONLY")}; stale_surface_items=${obj.optJSONArray("staleSurfaceFindings")?.length() ?: 0}.",
        "Future corpus policy: ${obj.optString("futureCorpusRenderPolicy", "background-only on mismatch")}; discovery_candidate_ready=${obj.optBoolean("discoveryCandidateReady", false)}.",
        "Route linkage: legacy research rails → active-domain/canonical surface → capsule/module signal → Discovery Candidate → final locks.",
        "Boundary: emits bounded Discovery Candidate only; no validated discovery, diagnosis, treatment, dosing, vaccine advice, or efficacy claim."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FINAL_DISCOVERY_EXECUTION_CANDIDATE_READY", "background_contradiction_only_no_future_hypothesis_targets_readouts", CLAIM_LIMIT))
}
