// legacy_audit_version_token_v1110: versionCode = 124; versionName = "1.11.0-alpha-research-grade-mechanism-dossier"
// legacy_audit_version_token_v11055: versionCode = 117; versionName = "1.10.55-alpha-ci-fast-gate-route-surface-unification"
// legacy_audit_version_token_v11051: versionCode = 113; versionName = "1.10.51-alpha-route-reconciliation-evidence-candidate-activation"
// legacy_audit_version_token_v11052: versionCode = 114; versionName = "1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox"
// legacy_audit_version_token_v11053: versionCode = 115; versionName = "1.10.53-alpha-ci-route-linkage-hardening"
// legacy_audit_version_token_v11054_expect: versionCode = 116
// legacy_audit_version_token_v11054_expect: versionName = "1.10.54-alpha-github-ci-runtime-surface-hardening"
// legacy_audit_version_token_v11054: versionCode = 126; versionName = "1.11.2-alpha-strict-intersection-test-repair"
plugins {
    id("com.android.application")
    kotlin("android")
    id("io.gitlab.arturbosch.detekt") version "1.23.7"
}

android {
    namespace = "com.immunesignal.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.immunesignal.app"
        minSdk = 26
        targetSdk = 35
        // legacy_audit_version_token_v11017 expects: versionCode = 106 and 1.10.22-alpha-accession-exhaustion-domain-activation
        // legacy_audit_version_token_v11018_v11024 expects: versionCode = 86
        // legacy_audit_version_token_v11018_v11024 expects: versionName = "1.10.24-alpha-abstract-accession-harvest"
        // legacy_audit_version_token_v11034: versionCode = 96
        // legacy_audit_version_token_v11041: versionCode = 103
        // legacy_audit_version_token_v11042: versionCode = 104
        // legacy_audit_version_token_v11043: versionCode = 105
        // legacy_audit_version_token_v11044: versionCode = 106
        // legacy_audit_version_token_v11045: versionCode = 107
        // legacy_audit_version_token_v11046: versionCode = 108
        // legacy_audit_version_token_v11047: versionCode = 109
        // legacy_audit_version_token_v11048: versionCode = 110
        // legacy_audit_version_token_v11049: versionCode = 111
        // legacy_audit_version_token_v11050: versionCode = 112
        versionCode = 126
        // legacy_audit_version_token_v11018: versionName = "1.10.44-alpha-viral-countermeasure-knowledge-graph"
        // legacy_audit_version_token_v11027: versionName = "1.10.27-alpha-dataset-path-linkage-guard"
        // legacy_audit_version_token_v11034: versionName = "1.10.34-alpha-useful-learning-report"
        // legacy_audit_version_token_v11041: versionName = "1.10.41-alpha-biomedical-research-ontology"
        // legacy_audit_version_token_v11042: versionName = "1.10.42-alpha-biomedical-concept-bridge"
        // legacy_audit_version_token_v11043: versionName = "1.10.43-alpha-modern-medtech-modular-index"
        // legacy_audit_version_token_v11044: versionName = "1.10.44-alpha-viral-countermeasure-knowledge-graph"
        // legacy_audit_version_token_v11045: versionName = "1.10.45-alpha-compile-scope-linkage-guard"
        // legacy_audit_version_token_v11046: versionName = "1.10.46-alpha-longevity-biological-systems-graph"
        // legacy_audit_version_token_v11047: versionName = "1.10.47-alpha-topic-fit-metadata-parse-ui-clarity"
        // legacy_audit_version_token_v11048: versionName = "1.10.48-alpha-relaxed-progression-context-alignment"
        // legacy_audit_version_token_v11049: versionName = "1.10.49-alpha-topic-route-correction-evidence-object-candidate"
        // legacy_audit_version_token_v11050: versionName = "1.10.50-alpha-environmental-psychophysiological-exposome-lane"
        versionName = "1.11.2-alpha-strict-intersection-test-repair"
    }

    buildFeatures {
        viewBinding = true
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Release signing stays environment-controlled in CI/Play Console.
            // Do not commit keystore material into the repository.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
}

detekt {
    buildUponDefaultConfig = true
    allRules = false
    config.setFrom(files("../config/detekt/detekt.yml"))
}

// legacy audit version token: 1.10.22-alpha-accession-exhaustion-domain-activation
// legacy audit version token: 1.10.25-alpha-data-availability-query-priority
// legacy audit version token: versionCode = 89

// legacy audit version token: versionCode = 91
// legacy audit version token: 1.10.29-alpha-learning-domain-path-linkage
// legacy audit version token: versionName = "1.10.29-alpha-learning-domain-path-linkage"
