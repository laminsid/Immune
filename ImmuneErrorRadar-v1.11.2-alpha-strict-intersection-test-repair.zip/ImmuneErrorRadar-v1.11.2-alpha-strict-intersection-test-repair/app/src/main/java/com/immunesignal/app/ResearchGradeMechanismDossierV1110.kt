package com.immunesignal.app

import java.util.Locale

/**
 * v1.11.1 route-integrity repair: keeps v1.11.0 dossier logic while tightening GitHub
 * route coverage, report labels, and matrix-readiness grading.
 *
 * v1.11.0: Research-grade Mechanism Discovery Dossier Engine.
 *
 * This layer moves the system from accession foraging to translational evidence mapping.
 * It never performs diagnosis, patient prediction, treatment advice, drug/supplement
 * ranking, differential expression claims, fold-change claims, p-values, or clinical
 * utility claims. It only asks whether a captured GEO/SRA-style dataset is structurally
 * ready for controlled mechanism analysis. Never invent accession IDs, sample labels,
 * gene-expression results, fold-changes, p-values, cytokine effects, or predictions.
 */
data class AccessionCandidateCardV1110(
    val accessionId: String,
    val repository: String,
    val titleOrSnippet: String,
    val organism: String,
    val cohortType: String,
    val assayPlatform: String,
    val sampleCount: String,
    val sampleGroupLabels: List<String>,
    val controlComparatorLabels: List<String>,
    val caseLabels: List<String>,
    val timepoints: List<String>,
    val tissueOrCellContext: String,
    val matrixAvailability: String,
    val metadataAvailability: String,
    val dataAccessLicenseStatus: String,
    val blockingGaps: List<String>,
    val dgeReadinessState: String,
    val evidenceObjectGate: String,
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
)

data class ComparatorMappingCardV1110(
    val accessionId: String,
    val status: String,
    val healthyControl: List<String>,
    val matchedControl: List<String>,
    val baseline: List<String>,
    val placebo: List<String>,
    val responder: List<String>,
    val nonResponder: List<String>,
    val caseLabel: List<String>,
    val exposedUnexposed: List<String>,
    val negativeControl: List<String>,
    val unknown: List<String>,
    val gate: String,
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
)

data class MechanismRouteProposalV1110(
    val routeId: String,
    val sourceRuleId: String,
    val targetMolecularAxis: String,
    val datasetReadiness: String,
    val requiredValidationFields: List<String>,
    val contradictionSearchTerms: List<String>,
    val missingEvidence: List<String>,
    val nextAccessionSpecificQuery: String,
    val whyThisRouteMayFail: List<String>,
    val forbiddenClaims: List<String>,
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
)

data class ResearchGradeMechanismDossierReportV1110(
    val active: Boolean,
    val state: String,
    val versionLabel: String,
    val researchQuestion: String,
    val accessionCandidates: List<AccessionCandidateCardV1110>,
    val comparatorMap: List<ComparatorMappingCardV1110>,
    val matrixAnalysisGate: String,
    val evidenceGrade: String,
    val mechanismRoutes: List<MechanismRouteProposalV1110>,
    val contradictionNullResultSearch: List<String>,
    val blockingGaps: List<String>,
    val nextDecisiveAction: String,
    val doNotBelieveYet: List<String>,
    val hardIntegrityLocks: List<String>,
    val conciseDossierLines: List<String>,
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
) {
    companion object {
        fun empty() = ResearchGradeMechanismDossierReportV1110(
            active = false,
            state = "NOT_EVALUATED",
            versionLabel = ResearchGradeMechanismDossierV1110.VERSION_LABEL,
            researchQuestion = "No Hyper-Drive or accession-matrix readiness context was available.",
            accessionCandidates = emptyList(),
            comparatorMap = emptyList(),
            matrixAnalysisGate = "DGE_NOT_READY_METADATA_GAP",
            evidenceGrade = "E — no accession candidate available",
            mechanismRoutes = emptyList(),
            contradictionNullResultSearch = emptyList(),
            blockingGaps = listOf("no accession candidate", "no matrix metadata", "no comparator map"),
            nextDecisiveAction = "Run Hyper-Drive accession search and create accession candidates before mechanism mapping.",
            doNotBelieveYet = ResearchGradeMechanismDossierV1110.DEFAULT_DO_NOT_BELIEVE,
            hardIntegrityLocks = ResearchGradeMechanismDossierV1110.DEFAULT_LOCKS,
            conciseDossierLines = emptyList()
        )
    }
}

object ResearchGradeMechanismDossierV1110 {
    const val VERSION_LABEL: String = "v1.11.2-alpha-strict-intersection-test-repair"
    const val CLAIM_BOUNDARY: String = "biomedical_research_data_engineering_only_not_clinical_claim"

    private val accessionRegex = Regex("\\b(GSE\\d+|GSM\\d+|GPL\\d+|PRJNA\\d+|PRJEB\\d+|SRP\\d+|SRR\\d+|ERR\\d+|E-MTAB-\\d+|SDY\\d+)\\b", RegexOption.IGNORE_CASE)
    private val forbiddenClaims = listOf(
        "diagnosis",
        "treatment recommendation",
        "dose recommendation",
        "supplement recommendation",
        "drug ranking",
        "patient flare prediction",
        "causal claim",
        "clinical utility claim",
        "scientific breakthrough claim",
        "fold-change or p-value without matrix analysis"
    )

    fun evaluate(
        steering: ResearchSteeringProfile?,
        matrix: MetadataClosureStrategyMatrixReport,
        candidates: List<DatasetAccessionCandidate>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        leadObjects: List<LeadObject>,
        attempts: List<DatasetSourceAttempt>
    ): ResearchGradeMechanismDossierReportV1110 {
        if (!RuntimeFeatureFlags.ENABLE_RESEARCH_GRADE_MECHANISM_DOSSIER_V1110) {
            return ResearchGradeMechanismDossierReportV1110.empty().copy(
                state = "DISABLED_BY_FEATURE_FLAG",
                nextDecisiveAction = "Enable v1.11.0 mechanism dossier feature flag."
            )
        }

        val accessionCards = buildAccessionCards(candidates, parsedMetadata, leadObjects, attempts)
        val comparatorCards = accessionCards.map { comparatorCard(it) }
        val verifiedRules = matrix.crossReferenceMatrix.filter { it.verified }
        val active = matrix.hyperDriveModeActive || accessionCards.isNotEmpty() || verifiedRules.isNotEmpty()
        if (!active) {
            return ResearchGradeMechanismDossierReportV1110.empty().copy(
                state = "READY_NO_HYPERDRIVE_CONTEXT",
                researchQuestion = researchQuestion(steering, verifiedRules),
                nextDecisiveAction = "Capture an accession pattern through Hyper-Drive before Accession-to-Matrix readiness evaluation."
            )
        }

        val matrixGate = matrixGate(accessionCards)
        val mechanismRoutes = buildRoutes(verifiedRules, accessionCards, matrix)
        val blockingGaps = accessionCards.flatMap { it.blockingGaps }.ifEmpty {
            listOf("no accession candidate", "no matrix metadata", "no comparator map")
        }.distinct().take(12)
        val contradictionQueries = contradictionQueries(mechanismRoutes, matrix)
        val evidenceGrade = evidenceGrade(accessionCards, mechanismRoutes, matrixGate)
        val state = when {
            accessionCards.isEmpty() -> "HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION"
            accessionCards.any { it.dgeReadinessState == "DGE_READY_FOR_CONTROLLED_REVIEW" } -> "MATRIX_READY_FOR_REVIEW_NO_CLAIM"
            comparatorCards.any { it.gate == "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" } -> "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT"
            else -> "DGE_NOT_READY_METADATA_GAP"
        }
        val next = nextAction(state, accessionCards, mechanismRoutes, matrix)
        val lines = conciseLines(
            state = state,
            researchQuestion = researchQuestion(steering, verifiedRules),
            evidenceGrade = evidenceGrade,
            cards = accessionCards,
            matrixGate = matrixGate,
            routes = mechanismRoutes,
            blockers = blockingGaps,
            next = next
        )
        return ResearchGradeMechanismDossierReportV1110(
            active = true,
            state = state,
            versionLabel = VERSION_LABEL,
            researchQuestion = researchQuestion(steering, verifiedRules),
            accessionCandidates = accessionCards,
            comparatorMap = comparatorCards,
            matrixAnalysisGate = matrixGate,
            evidenceGrade = evidenceGrade,
            mechanismRoutes = mechanismRoutes,
            contradictionNullResultSearch = contradictionQueries,
            blockingGaps = blockingGaps,
            nextDecisiveAction = next,
            doNotBelieveYet = DEFAULT_DO_NOT_BELIEVE,
            hardIntegrityLocks = DEFAULT_LOCKS,
            conciseDossierLines = lines
        )
    }

    private fun buildAccessionCards(
        candidates: List<DatasetAccessionCandidate>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        leadObjects: List<LeadObject>,
        attempts: List<DatasetSourceAttempt>
    ): List<AccessionCandidateCardV1110> {
        val byAccession = parsedMetadata.associateBy { normalizeAccession(it.accession) }
        val candidateCards = candidates.mapNotNull { candidate ->
            val ids = extractAccessions(listOf(candidate.accession, candidate.sourceTitle, candidate.sourceUrl, candidate.reasons.joinToString(" ")))
                .ifEmpty { listOf(candidate.accession).filter { it.isNotBlank() && it != "unknown" } }
            ids.map { accession -> cardFromCandidate(accession, candidate, byAccession[normalizeAccession(accession)]) }
        }.flatten()

        val leadCards = leadObjects.flatMap { lead ->
            val ids = extractAccessions(listOf(lead.detectedAccessions.joinToString(" "), lead.title, lead.snippet, lead.dataAvailabilityText))
            ids.map { accession -> cardFromLead(accession, lead) }
        }

        val attemptCards = attempts.flatMap { attempt ->
            extractAccessions(listOf(attempt.query, attempt.reason)).map { accession -> cardFromAttempt(accession, attempt) }
        }

        return (candidateCards + leadCards + attemptCards)
            .distinctBy { normalizeAccession(it.accessionId) + "|" + it.repository }
            .take(12)
    }

    private fun cardFromCandidate(accession: String, candidate: DatasetAccessionCandidate, metadata: ParsedDatasetMetadata?): AccessionCandidateCardV1110 {
        val groups = splitLabels(candidate.conditionLabelsHint) + (metadata?.conditionLabels ?: emptyList())
        val outcomes = splitLabels(candidate.outcomeLabelsHint) + (metadata?.outcomeLabels ?: emptyList())
        val controls = controlLabels(groups + (metadata?.controlLabels ?: emptyList()) + splitLabels(candidate.triggerResponseOutcomeHint))
        val cases = caseLabels(groups + outcomes)
        val timepoints = splitLabels(candidate.timeCourseHint) + (metadata?.timeCourseLabels ?: emptyList())
        val tissue = firstKnown(metadata?.tissueOrSource, candidate.triggerResponseOutcomeHint, "unknown")
        val platform = firstKnown(metadata?.assayType, candidate.dataType, "unknown")
        val matrixAvailability = matrixAvailability(candidate.dataType, metadata?.assayType, candidate.reasons.joinToString(" "))
        val metadataAvailability = if (metadata != null || groups.isNotEmpty() || outcomes.isNotEmpty()) "METADATA_PARTIAL_OR_PARSED" else "METADATA_UNKNOWN"
        val access = accessStatus(candidate.reasons.joinToString(" ") + " " + candidate.sourceUrl)
        val gaps = blockingGaps(
            accession = accession,
            organism = firstKnown(metadata?.organism, candidate.organismHint, "unknown"),
            groups = groups,
            controls = controls,
            cases = cases,
            timepoints = timepoints,
            tissue = tissue,
            platform = platform,
            sampleCount = candidate.sampleSizeHint,
            matrixAvailability = matrixAvailability,
            metadataAvailability = metadataAvailability,
            access = access,
            outcomes = outcomes
        )
        val dge = dgeReadiness(gaps)
        return AccessionCandidateCardV1110(
            accessionId = accession,
            repository = repositoryFor(accession, candidate.source),
            titleOrSnippet = candidate.sourceTitle.take(240),
            organism = firstKnown(metadata?.organism, candidate.organismHint, "unknown"),
            cohortType = cohortType(firstKnown(metadata?.organism, candidate.organismHint, "") + " " + groups.joinToString(" ")),
            assayPlatform = platform,
            sampleCount = candidate.sampleSizeHint.ifBlank { metadata?.sampleSizeStatus ?: "unknown" },
            sampleGroupLabels = groups.distinct().take(12),
            controlComparatorLabels = controls.distinct().take(12),
            caseLabels = cases.distinct().take(12),
            timepoints = timepoints.distinct().take(12),
            tissueOrCellContext = tissue,
            matrixAvailability = matrixAvailability,
            metadataAvailability = metadataAvailability,
            dataAccessLicenseStatus = access,
            blockingGaps = gaps,
            dgeReadinessState = dge,
            evidenceObjectGate = if (controls.isEmpty()) "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" else if (dge == "DGE_READY_FOR_CONTROLLED_REVIEW") "EVIDENCE_OBJECT_REVIEW_CANDIDATE_NO_CLAIM" else "EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS"
        )
    }

    private fun cardFromLead(accession: String, lead: LeadObject): AccessionCandidateCardV1110 {
        val groups = splitLabels(lead.domain + " " + lead.snippet)
        val controls = controlLabels(groups + splitLabels(lead.snippet))
        val cases = caseLabels(groups)
        val timepoints = if (lead.timeLikely) listOf("time_order_or_followup_likely") else emptyList()
        val platform = firstKnown(lead.omicsType, "unknown")
        val matrixAvailability = matrixAvailability(lead.omicsType, lead.dataAvailabilityText, lead.snippet)
        val access = accessStatus(lead.dataAvailabilityText)
        val gaps = blockingGaps(accession, lead.organism, groups, controls, cases, timepoints, lead.domain, platform, "unknown", matrixAvailability, "METADATA_FROM_LEAD_ONLY", access, if (lead.outcomeLikely) listOf("outcome_likely") else emptyList())
        return AccessionCandidateCardV1110(
            accessionId = accession,
            repository = repositoryFor(accession, lead.sourceFamily),
            titleOrSnippet = (lead.title.ifBlank { lead.snippet }).take(240),
            organism = lead.organism.ifBlank { "unknown" },
            cohortType = cohortType(lead.organism + " " + lead.snippet),
            assayPlatform = platform,
            sampleCount = if (lead.sampleSizeLikely) "sample_size_likely_unparsed" else "unknown",
            sampleGroupLabels = groups.take(12),
            controlComparatorLabels = controls.take(12),
            caseLabels = cases.take(12),
            timepoints = timepoints,
            tissueOrCellContext = lead.domain.ifBlank { "unknown" },
            matrixAvailability = matrixAvailability,
            metadataAvailability = "METADATA_FROM_LEAD_ONLY",
            dataAccessLicenseStatus = access,
            blockingGaps = gaps,
            dgeReadinessState = dgeReadiness(gaps),
            evidenceObjectGate = if (controls.isEmpty()) "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" else "EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS"
        )
    }

    private fun cardFromAttempt(accession: String, attempt: DatasetSourceAttempt): AccessionCandidateCardV1110 {
        val controls = controlLabels(splitLabels(attempt.query))
        val cases = caseLabels(splitLabels(attempt.query))
        val gaps = blockingGaps(accession, "unknown", splitLabels(attempt.query), controls, cases, emptyList(), "unknown", "unknown", "unknown", "MATRIX_UNKNOWN_REQUIRES_REPOSITORY_INSPECTION", "METADATA_UNKNOWN", "ACCESS_UNKNOWN", emptyList())
        return AccessionCandidateCardV1110(
            accessionId = accession,
            repository = repositoryFor(accession, attempt.sourceFamily),
            titleOrSnippet = attempt.query.take(240),
            organism = "unknown",
            cohortType = "unknown",
            assayPlatform = "unknown",
            sampleCount = "unknown",
            sampleGroupLabels = splitLabels(attempt.query).take(12),
            controlComparatorLabels = controls.take(12),
            caseLabels = cases.take(12),
            timepoints = emptyList(),
            tissueOrCellContext = "unknown",
            matrixAvailability = "MATRIX_UNKNOWN_REQUIRES_REPOSITORY_INSPECTION",
            metadataAvailability = "METADATA_UNKNOWN",
            dataAccessLicenseStatus = "ACCESS_UNKNOWN",
            blockingGaps = gaps,
            dgeReadinessState = "DGE_NOT_READY_METADATA_GAP",
            evidenceObjectGate = if (controls.isEmpty()) "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" else "EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS"
        )
    }

    private fun comparatorCard(card: AccessionCandidateCardV1110): ComparatorMappingCardV1110 {
        val labels = (card.sampleGroupLabels + card.controlComparatorLabels + card.caseLabels).map { it.lowercase(Locale.US) }
        fun pick(vararg keys: String): List<String> = labels.filter { label -> keys.any { key -> label.contains(key) } }.distinct().take(6)
        val healthy = pick("healthy")
        val matched = pick("matched")
        val baseline = pick("baseline", "pre")
        val placebo = pick("placebo")
        val responder = labels.filter { it.contains("responder") && !it.contains("non") }.distinct().take(6)
        val nonResponder = pick("non-responder", "nonresponder", "non responder")
        val case = pick("case", "patient", "sle", "lupus", "multiple sclerosis", "me/cfs", "rheumatoid")
        val exposed = pick("exposed", "unexposed", "treated", "untreated")
        val negative = pick("negative control", "unrelated marker", "null")
        val unknown = if (listOf(healthy, matched, baseline, placebo, responder, nonResponder, case, exposed, negative).all { it.isEmpty() }) listOf("unknown") else emptyList()
        val hasComparator = healthy.isNotEmpty() || matched.isNotEmpty() || baseline.isNotEmpty() || placebo.isNotEmpty() || nonResponder.isNotEmpty() || exposed.isNotEmpty() || negative.isNotEmpty()
        return ComparatorMappingCardV1110(
            accessionId = card.accessionId,
            status = if (hasComparator) "COMPARATOR_MAP_PARTIAL" else "COMPARATOR_UNKNOWN",
            healthyControl = healthy,
            matchedControl = matched,
            baseline = baseline,
            placebo = placebo,
            responder = responder,
            nonResponder = nonResponder,
            caseLabel = case,
            exposedUnexposed = exposed,
            negativeControl = negative,
            unknown = unknown,
            gate = if (hasComparator) "COMPARATOR_PARTIAL_NO_CLAIM" else "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT"
        )
    }

    private fun buildRoutes(
        verifiedRules: List<MetadataClosureIntersectionRuleV11057>,
        cards: List<AccessionCandidateCardV1110>,
        matrix: MetadataClosureStrategyMatrixReport
    ): List<MechanismRouteProposalV1110> {
        return verifiedRules.map { rule ->
            val axis = when (rule.ruleId) {
                "R1_NEURO_VIRAL_BRIDGE" -> "Latent viral transcriptional activation / neuro-immune autoimmunity axis"
                "R2_PSYCHEPHYSIOLOGICAL_EXPOSOME" -> "HPA/sleep-strain cytokine modulation axis"
                else -> "Verified cross-family translational evidence axis"
            }
            val missing = cards.flatMap { it.blockingGaps }.distinct().ifEmpty { matrix.hardClaimGates }.take(10)
            MechanismRouteProposalV1110(
                routeId = "MR_${rule.ruleId}",
                sourceRuleId = rule.ruleId,
                targetMolecularAxis = axis,
                datasetReadiness = if (cards.any { it.dgeReadinessState == "DGE_READY_FOR_CONTROLLED_REVIEW" }) "DGE_READY_FOR_CONTROLLED_REVIEW_NO_CLAIM" else "DGE_NOT_READY_METADATA_GAP",
                requiredValidationFields = listOf(
                    "expression matrix availability",
                    "sample metadata availability",
                    "case/control or baseline comparator",
                    "tissue/cell context",
                    "time/order labels for longitudinal claims",
                    "batch/platform artifact warning",
                    "outcome labels",
                    "contradiction/null-result search"
                ),
                contradictionSearchTerms = contradictionTermsFor(rule),
                missingEvidence = missing,
                nextAccessionSpecificQuery = rule.programmaticQueries.firstOrNull() ?: matrix.queryStreams.firstOrNull()?.query.orEmpty(),
                whyThisRouteMayFail = listOf(
                    "accession resolves to metadata-only record without downloadable matrix",
                    "sample groups do not separate case/control or baseline",
                    "time order is absent or reversed",
                    "cell-composition or batch effects explain the signal better",
                    "null-result or negative-control literature breaks the mechanism route"
                ),
                forbiddenClaims = forbiddenClaims
            )
        }
    }

    private fun contradictionQueries(routes: List<MechanismRouteProposalV1110>, matrix: MetadataClosureStrategyMatrixReport): List<String> {
        val fromRoutes = routes.flatMap { route ->
            route.contradictionSearchTerms.map { term -> "${route.targetMolecularAxis} AND ($term) AND (null result OR no association OR failed replication OR batch effect OR cell composition)" }
        }
        val fallback = matrix.detectedTargets.take(6).joinToString(" OR ").ifBlank { "immune transcriptome" }
        return (fromRoutes + "($fallback) AND (negative control OR no association OR failed replication OR heterogeneity OR batch effect)")
            .distinct()
            .take(6)
    }

    private fun evidenceGrade(cards: List<AccessionCandidateCardV1110>, routes: List<MechanismRouteProposalV1110>, gate: String): String = when {
        cards.any { it.dgeReadinessState == "DGE_READY_FOR_CONTROLLED_REVIEW" } -> "B — dataset structurally ready for controlled matrix review, no biological claim"
        cards.any { it.controlComparatorLabels.isNotEmpty() && it.matrixAvailability.startsWith("MATRIX_AVAILABLE") } -> "C+ — accession/comparator structure present, matrix or metadata gaps remain"
        cards.isNotEmpty() -> "C — accession candidate present, readiness gaps block DGE"
        routes.isNotEmpty() -> "D+ — verified mechanism route, no accession card yet"
        else -> "E — exploratory only"
    }

    private fun matrixGate(cards: List<AccessionCandidateCardV1110>): String = when {
        cards.any { it.dgeReadinessState == "DGE_READY_FOR_CONTROLLED_REVIEW" } -> "DGE_READY_FOR_CONTROLLED_REVIEW"
        cards.isEmpty() -> "DGE_NOT_READY_NO_ACCESSION"
        else -> "DGE_NOT_READY_METADATA_GAP"
    }

    private fun dgeReadiness(gaps: List<String>): String = if (gaps.isEmpty()) "DGE_READY_FOR_CONTROLLED_REVIEW" else "DGE_NOT_READY_METADATA_GAP"

    private fun blockingGaps(
        accession: String,
        organism: String,
        groups: List<String>,
        controls: List<String>,
        cases: List<String>,
        timepoints: List<String>,
        tissue: String,
        platform: String,
        sampleCount: String,
        matrixAvailability: String,
        metadataAvailability: String,
        access: String,
        outcomes: List<String>
    ): List<String> {
        val gaps = mutableListOf<String>()
        if (accession.isBlank() || accession == "unknown") gaps += "accession_id"
        if (!organism.contains("human", true) && !organism.contains("patient", true)) gaps += "human_or_patient_cohort"
        if (groups.isEmpty()) gaps += "sample_group_labels"
        if (controls.isEmpty()) gaps += "control_or_comparator"
        if (cases.isEmpty()) gaps += "case_labels"
        if (timepoints.isEmpty()) gaps += "time_order_or_longitudinal_labels"
        if (tissue.isBlank() || tissue == "unknown") gaps += "tissue_or_cell_context"
        if (platform.isBlank() || platform == "unknown") gaps += "assay_platform"
        if (sampleCount.isBlank() || sampleCount == "unknown" || sampleCount.contains("unknown", true)) gaps += "sample_count"
        if (!matrixAvailability.startsWith("MATRIX_AVAILABLE")) gaps += "expression_matrix_availability"
        if (!metadataAvailability.contains("PARSED", true) && !metadataAvailability.contains("PARTIAL", true)) gaps += "sample_metadata_availability"
        if (!access.contains("AVAILABLE", true) && !access.contains("OPEN", true)) gaps += "data_access_or_license_status"
        if (outcomes.isEmpty()) gaps += "outcome_labels"
        return gaps.distinct()
    }

    private fun matrixAvailability(dataType: String?, assayType: String?, text: String?): String {
        val corpus = listOfNotNull(dataType, assayType, text).joinToString(" ").lowercase(Locale.US)
        val omics = listOf("rna-seq", "rnaseq", "transcriptome", "gene expression", "microarray", "scrna", "single-cell").any { corpus.contains(it) }
        val matrix = listOf("expression matrix", "counts matrix", "raw counts", "series matrix", "supplementary file", "processed data").any { corpus.contains(it) }
        return when {
            omics && matrix -> "MATRIX_AVAILABLE_UNVERIFIED"
            omics -> "MATRIX_UNKNOWN_REQUIRES_REPOSITORY_INSPECTION"
            else -> "MATRIX_NOT_ESTABLISHED"
        }
    }

    private fun metadataAvailability(metadata: ParsedDatasetMetadata?): String = if (metadata != null) "METADATA_PARSED" else "METADATA_UNKNOWN"

    private fun accessStatus(text: String): String {
        val t = text.lowercase(Locale.US)
        return when {
            listOf("open", "available", "data availability", "geo", "sra", "supplementary", "download").any { t.contains(it) } -> "ACCESS_AVAILABLE_UNVERIFIED"
            listOf("restricted", "controlled access", "dbgap", "upon request").any { t.contains(it) } -> "ACCESS_RESTRICTED_OR_REQUEST_REQUIRED"
            else -> "ACCESS_UNKNOWN"
        }
    }

    private fun extractAccessions(chunks: List<String>): List<String> = chunks
        .flatMap { chunk -> accessionRegex.findAll(chunk).map { normalizeAccession(it.value) }.toList() }
        .distinct()

    private fun splitLabels(text: String): List<String> = text
        .split(',', ';', '|', '/', '\n')
        .map { it.trim().lowercase(Locale.US) }
        .filter { it.length >= 3 && it !in setOf("unknown", "none", "null") }
        .distinct()
        .take(20)

    private fun controlLabels(labels: List<String>): List<String> = labels.filter { label ->
        listOf("healthy", "control", "baseline", "placebo", "non-responder", "nonresponder", "unexposed", "untreated", "negative").any { label.contains(it) }
    }.distinct()

    private fun caseLabels(labels: List<String>): List<String> = labels.filter { label ->
        listOf("case", "patient", "sle", "lupus", "multiple sclerosis", "me/cfs", "rheumatoid", "covid", "ebv", "hhv", "flare", "responder", "exposed", "treated").any { label.contains(it) }
    }.distinct()

    private fun repositoryFor(accession: String, fallback: String): String = when {
        accession.startsWith("GSE", true) || accession.startsWith("GSM", true) || accession.startsWith("GPL", true) -> "GEO"
        accession.startsWith("PRJ", true) || accession.startsWith("SRP", true) || accession.startsWith("SRR", true) || accession.startsWith("ERR", true) -> "SRA/BioProject"
        accession.startsWith("E-MTAB", true) -> "ArrayExpress"
        accession.startsWith("SDY", true) -> "ImmPort"
        else -> fallback.ifBlank { "unknown" }
    }

    private fun cohortType(text: String): String = when {
        text.contains("human", true) || text.contains("patient", true) -> "human_or_patient_cohort"
        text.contains("mouse", true) || text.contains("murine", true) -> "animal_model_not_primary_human"
        text.contains("cell", true) || text.contains("in vitro", true) -> "cell_or_in_vitro_model"
        else -> "unknown"
    }

    private fun contradictionTermsFor(rule: MetadataClosureIntersectionRuleV11057): List<String> = when (rule.ruleId) {
        "R1_NEURO_VIRAL_BRIDGE" -> listOf("EBV no association SLE", "HHV-6 no association multiple sclerosis", "viral reactivation batch effect", "cell composition artifact", "negative control autoimmunity")
        "R2_PSYCHEPHYSIOLOGICAL_EXPOSOME" -> listOf("sleep deprivation cytokine no association", "cortisol DHEA null result", "IL-6 TNF-alpha batch effect", "curcumin ashwagandha placebo control", "HPA axis confounding")
        else -> listOf("no association", "failed replication", "negative control", "batch effect", "heterogeneity")
    }

    private fun researchQuestion(steering: ResearchSteeringProfile?, rules: List<MetadataClosureIntersectionRuleV11057>): String {
        val focus = steering?.focusQuestion?.takeIf { it.isNotBlank() }
        val ruleText = rules.joinToString("; ") { it.label }.takeIf { it.isNotBlank() }
        return firstKnown(focus, ruleText, "Which accession-level datasets are structurally ready to test the proposed immune mechanism route?")
    }

    private fun nextAction(state: String, cards: List<AccessionCandidateCardV1110>, routes: List<MechanismRouteProposalV1110>, matrix: MetadataClosureStrategyMatrixReport): String = when (state) {
        "HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION" -> "Run accession-specific GEO/SRA search from Hyper-Drive streams; create AccessionCandidate only from real GSE/GSM/PRJNA/SRP/SRR handles."
        "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" -> "Parse sample metadata for healthy/matched/baseline/placebo/responder/non-responder labels before creating EvidenceObject."
        "MATRIX_READY_FOR_REVIEW_NO_CLAIM" -> "Run controlled matrix-readiness review; keep all DGE/fold-change/p-value claims blocked until real analysis executes."
        else -> cards.firstOrNull()?.blockingGaps?.firstOrNull()?.let { "Close blocking gap: $it for ${cards.first().accessionId}." }
            ?: routes.firstOrNull()?.nextAccessionSpecificQuery?.let { "Execute accession-specific query: $it" }
            ?: matrix.nextAction
    }

    private fun conciseLines(
        state: String,
        researchQuestion: String,
        evidenceGrade: String,
        cards: List<AccessionCandidateCardV1110>,
        matrixGate: String,
        routes: List<MechanismRouteProposalV1110>,
        blockers: List<String>,
        next: String
    ): List<String> = listOf(
        "Research-Grade Mechanism Discovery Dossier",
        "State: $state | Evidence grade: $evidenceGrade",
        "Research question: ${researchQuestion.take(180)}",
        "Accession candidates: ${cards.size} | first=${cards.firstOrNull()?.accessionId ?: "none"}",
        "Comparator gate: ${cards.firstOrNull()?.evidenceObjectGate ?: "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT"}",
        "Matrix gate: $matrixGate",
        "Mechanism route: ${routes.firstOrNull()?.targetMolecularAxis ?: "none verified"}",
        "Blocking gaps: ${blockers.take(6).joinToString(", ")}",
        "Next decisive action: ${next.take(220)}",
        "Do not believe yet: no diagnosis, treatment, patient prediction, causal claim, clinical utility, DGE, fold-change, or p-value."
    )

    private fun normalizeAccession(value: String): String = value.trim().uppercase(Locale.US)
    private fun firstKnown(vararg values: String?): String = values.firstOrNull { !it.isNullOrBlank() && it != "unknown" } ?: "unknown"

    val DEFAULT_DO_NOT_BELIEVE = listOf(
        "No biological mechanism is proven by accession or metadata alone.",
        "No differential expression result exists until a real expression matrix, sample metadata, comparator structure, and analysis are available.",
        "No patient-level prediction, flare forecast, diagnosis, treatment, dose, or supplement recommendation is allowed.",
        "No fold-change, p-value, cytokine effect, or gene up-regulation may be invented."
    )

    val DEFAULT_LOCKS = listOf(
        "HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION",
        "DGE_NOT_READY_METADATA_GAP unless matrix + metadata + comparator + labels close",
        "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT when comparator labels are absent",
        "Mechanism route proposal is not a biological conclusion",
        "Contradiction/null-result search required before route strengthening"
    )
}
