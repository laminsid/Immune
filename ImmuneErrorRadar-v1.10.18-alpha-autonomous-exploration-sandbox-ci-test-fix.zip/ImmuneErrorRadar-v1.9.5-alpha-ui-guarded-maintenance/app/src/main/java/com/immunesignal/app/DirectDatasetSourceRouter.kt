package com.immunesignal.app

import java.util.Locale

/** v1.4.2/v1.10.10: chooses direct dataset families before generic PubMed, rotates after no-candidate stalls, and exits to archive/reframe after all bounded sources are exhausted. */
object DirectDatasetSourceRouter {
    data class SourceRoute(
        val sourceFamily: String,
        val ncbiDb: String,
        val priority: Int,
        val reason: String
    )

    fun shouldRunDatasetFirst(recentReports: List<String>, researchState: String, appliedPivot: PivotDecision, memory: PersistentFailureMemorySnapshot): Boolean {
        val normalizedState = researchState.trim().uppercase(Locale.US)
        val text = (recentReports.take(5).joinToString(" ") + " " + normalizedState + " " + appliedPivot.pivotType + " " + appliedPivot.nextIntent + " " + appliedPivot.nextQuerySeed).lowercase(Locale.US)
        if (normalizedState == "DATASET_HUNT" || normalizedState == "STAGNATION_RECOVERY") return true
        if (text.contains("evidence_first") || text.contains("accession_search")) return true
        if (text.contains("no_dataset_accession") || text.contains("no_evidence_object_no_upgrade")) return true
        if (text.contains("dataset candidates: 0") || text.contains("evidence objects: 0")) return true
        if (text.contains("dataset_foraging_no_candidate") || text.contains("next source family")) return true
        return memory.records.any { it.cooldownCyclesRemaining > 0 || it.timesFailed >= 2 }
    }

    fun routes(memory: PersistentFailureMemorySnapshot): List<SourceRoute> {
        val blocked = memory.records
            .filter { it.cooldownCyclesRemaining > 0 }
            .map { it.sourceFamily }
            .toSet()
        val forced = memory.records
            .asSequence()
            .sortedWith(compareByDescending<PersistentFailureRecord> { it.cooldownCyclesRemaining }.thenByDescending { it.lastAttemptedAtMillis })
            .map { it.forcedNextSource }
            .firstOrNull { it.isNotBlank() }
            .orEmpty()
        val routes = listOf(
            SourceRoute("GEO_GDS", "gds", 100, "Direct GEO/GDS dataset-source search for accessions and dataset metadata."),
            SourceRoute("SRA_PRJNA", "sra", 92, "Direct SRA/BioProject sequence-read search for PRJNA/SRP/SRA accessions after GEO/GDS misses."),
            SourceRoute("IMM_PORT_SDY", "pubmed", 86, "ImmPort/SDY accession mining through PubMed/NCBI-indexed metadata when direct GEO/SRA routes miss."),
            SourceRoute("PUBMED_ACCESSION_MINING", "pubmed", 74, "Targeted PubMed/PMC accession-mining query for GSE/SDY/PRJNA/SRP identifiers, not a broad mechanism search."),
            SourceRoute("PUBMED_ADJACENT_DOMAIN_MINING", "pubmed", 68, "Autonomous exploration sandbox: adjacent-domain and drug/perturbation dataset mining; research-only, no treatment or ranking claim."),
            SourceRoute("PUBMED_CONTRADICTION", "pubmed", 60, "Secondary contradiction/control search only after dataset routes are attempted."),
            SourceRoute("PUBMED_CONTROL", "pubmed", 55, "Secondary control/negative-control search around the best dataset shard.")
        )
        val accessionFamilies = AccessionAcquisitionHardening.routeFamiliesForNoAccession(memory)
        val normalizedForced = normalizeSourceFamily(forced)
        if (normalizedForced == "ARCHIVE_OR_REFRAME_ROUTE") {
            if (accessionFamilies.isNotEmpty()) {
                return listOf(accessionRecoveryRoute(routes, accessionFamilies, memory, "Persistent memory requested archive/reframe before any accession-family recovery query could leave the device."))
            }
            return listOf(archiveOrReframeRoute("Persistent memory says all bounded source families failed without candidate-level evidence."))
        }
        val available = routes.filterNot { blocked.contains(it.sourceFamily) }
        val ordered = available.sortedWith(
            compareByDescending<SourceRoute> { if (it.sourceFamily == forced) 1 else 0 }
                .thenByDescending { it.priority }
        )
        // v1.10.15: accession acquisition lock.
        // v1.10.18 CI fix: under NO_DATASET_ACCESSION/BROAD_QUERY pressure,
        // adjacent-domain exploration must not jump ahead of a required direct
        // accession recovery attempt. If all core accession families are cooling
        // down, intentionally allow one bounded recovery route from the core
        // family set before archive/reframe or adjacent PubMed exploration.
        if (accessionFamilies.isNotEmpty()) {
            val availableCoreAccession = ordered.filter { it.sourceFamily in accessionFamilies }
            if (availableCoreAccession.isNotEmpty()) {
                return (availableCoreAccession + ordered.filterNot { it.sourceFamily in accessionFamilies })
                    .distinctBy { it.sourceFamily }
            }
            return listOf(accessionRecoveryRoute(routes, accessionFamilies, memory, "All core accession families are cooling down, but no dataset handle exists yet."))
        }
        // v1.10.10 terminal guard: after all bounded families are cooling down,
        // stop pretending another network family is available. The next action is
        // to archive or reframe the route, not to keep looping through escapes.
        return listOf(archiveOrReframeRoute("All normal direct dataset families are in cooldown after no-candidate learning."))
    }


    private fun accessionRecoveryRoute(
        routes: List<SourceRoute>,
        accessionFamilies: List<String>,
        memory: PersistentFailureMemorySnapshot,
        reason: String
    ): SourceRoute {
        val forcedByMemory = memory.records
            .asSequence()
            .sortedWith(compareByDescending<PersistentFailureRecord> { it.cooldownCyclesRemaining }.thenByDescending { it.lastAttemptedAtMillis })
            .map { normalizeSourceFamily(it.forcedNextSource) }
            .firstOrNull { it in accessionFamilies }
        val preferred = forcedByMemory ?: accessionFamilies.firstOrNull().orEmpty()
        val route = routes.firstOrNull { it.sourceFamily == preferred }
            ?: routes.firstOrNull { it.sourceFamily in accessionFamilies }
            ?: routes.first { it.sourceFamily == "PUBMED_ACCESSION_MINING" }
        return route.copy(
            priority = route.priority + 20,
            reason = "v1.10.15 zero-query acquisition recovery: $reason Run one bounded ${route.sourceFamily} acquisition attempt before archive/reframe."
        )
    }

    fun routeForSourceFamily(sourceFamily: String): SourceRoute? = when (normalizeSourceFamily(sourceFamily)) {
        "GEO_GDS" -> SourceRoute("GEO_GDS", "gds", 100, "Direct GEO/GDS dataset-source search for accessions and dataset metadata.")
        "SRA_PRJNA" -> SourceRoute("SRA_PRJNA", "sra", 92, "Direct SRA/BioProject sequence-read search for PRJNA/SRP/SRA accessions after GEO/GDS misses.")
        "IMM_PORT_SDY" -> SourceRoute("IMM_PORT_SDY", "pubmed", 86, "ImmPort/SDY accession mining through PubMed/NCBI-indexed metadata when direct GEO/SRA routes miss.")
        "PUBMED_ACCESSION_MINING" -> SourceRoute("PUBMED_ACCESSION_MINING", "pubmed", 74, "Targeted PubMed/PMC accession-mining query for GSE/SDY/PRJNA/SRP identifiers, not a broad mechanism search.")
        "PUBMED_ADJACENT_DOMAIN_MINING" -> AutonomousExplorationSandboxPolicy.routeForSourceFamily("PUBMED_ADJACENT_DOMAIN_MINING")!!
        "PUBMED_CONTRADICTION" -> SourceRoute("PUBMED_CONTRADICTION", "pubmed", 60, "Secondary contradiction/control search only after dataset routes are attempted.")
        "PUBMED_CONTROL" -> SourceRoute("PUBMED_CONTROL", "pubmed", 55, "Secondary control/negative-control search around the best dataset shard.")
        "ARCHIVE_OR_REFRAME_ROUTE" -> archiveOrReframeRoute("Source rotation reached terminal archive/reframe state.")
        else -> null
    }

    private val rotationOrder = listOf(
        "GEO_GDS",
        "SRA_PRJNA",
        "IMM_PORT_SDY",
        "PUBMED_ACCESSION_MINING",
        "PUBMED_ADJACENT_DOMAIN_MINING",
        "PUBMED_CONTRADICTION",
        "PUBMED_CONTROL"
    )

    fun nextSourceAfterNoCandidate(sourceFamily: String): String = when (normalizeSourceFamily(sourceFamily)) {
        "GEO_GDS" -> "SRA_PRJNA"
        "SRA_PRJNA" -> "IMM_PORT_SDY"
        "IMM_PORT_SDY" -> "PUBMED_ACCESSION_MINING"
        "PUBMED_ACCESSION_MINING" -> "PUBMED_ADJACENT_DOMAIN_MINING"
        "PUBMED_ADJACENT_DOMAIN_MINING" -> "PUBMED_CONTRADICTION"
        "PUBMED_CONTRADICTION" -> "PUBMED_CONTROL"
        "PUBMED_CONTROL" -> "ARCHIVE_OR_REFRAME_ROUTE"
        else -> "SRA_PRJNA"
    }

    /**
     * v1.10.9 maintenance2: when a bounded forager attempts more than one
     * source family in the same cycle, the next source must advance past the
     * last attempted family and prefer a family not already tried in that same
     * cycle. Otherwise a GEO+SRA no-candidate cycle can persist "next SRA" and
     * silently repeat a route that already failed minutes earlier.
     */
    fun nextSourceAfterNoCandidateSequence(attemptedFamilies: List<String>): String {
        val normalized = attemptedFamilies
            .map { normalizeSourceFamily(it) }
            .filter { it in rotationOrder }
            .distinct()
        if (normalized.isEmpty()) return "GEO_GDS"
        val attemptedSet = normalized.toSet()
        val start = rotationOrder.indexOf(normalized.last()).takeIf { it >= 0 } ?: 0
        for (step in 1..rotationOrder.size) {
            val candidate = rotationOrder[(start + step) % rotationOrder.size]
            if (candidate !in attemptedSet) return candidate
        }
        return "ARCHIVE_OR_REFRAME_ROUTE"
    }

    private fun archiveOrReframeRoute(reason: String): SourceRoute = SourceRoute(
        sourceFamily = "ARCHIVE_OR_REFRAME_ROUTE",
        ncbiDb = "offline",
        priority = 0,
        reason = "$reason No more bounded source-family rotation should run until the hypothesis is reframed, narrowed, or archived."
    )

    private fun normalizeSourceFamily(sourceFamily: String): String = when (sourceFamily.trim().uppercase(Locale.US)) {
        "GEO_GDS_COOLDOWN_ESCAPE" -> "GEO_GDS"
        "PUBMED_ACCESSION_MINING_COOLDOWN_ESCAPE" -> "PUBMED_ACCESSION_MINING"
        "ARCHIVE_OR_REFRAME" -> "ARCHIVE_OR_REFRAME_ROUTE"
        else -> sourceFamily.trim().uppercase(Locale.US)
    }
}
