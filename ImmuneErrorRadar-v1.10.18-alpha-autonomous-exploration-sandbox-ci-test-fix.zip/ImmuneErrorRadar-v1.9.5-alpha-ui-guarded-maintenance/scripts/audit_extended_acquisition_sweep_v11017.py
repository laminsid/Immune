#!/usr/bin/env python3
from pathlib import Path

checks = {
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES', 'MIN_EXTENDED_ACCESSION_QUERY_PATHS', '1.10.18'
    ],
    'app/src/main/java/com/immunesignal/app/ExtendedAcquisitionSweepPolicy.kt': [
        'ExtendedAcquisitionSweepPolicy', 'extended_acquisition_sweep_not_biological_proof',
        'do not archive after a thin/fast dataset hunt', 'archiveAllowed'
    ],
    'app/src/main/java/com/immunesignal/app/AccessionAcquisitionHardening.kt': [
        'NO_ACCESSION_CONTINUE_SOURCE_SWEEP', 'sourceSweepArchiveAllowed', 'ExtendedAcquisitionSweepPolicy.nextAction'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ExtendedAcquisitionSweepPolicy.expandRoutes', 'MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES',
        'v1.10.17 extended acquisition sweep', 'DATASET_FORAGING_CONTINUE_SOURCE_SWEEP'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.10.18-alpha-autonomous-exploration-sandbox', 'ExtendedAcquisitionSweepPolicy'
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'ExtendedAcquisitionSweepPolicy'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'schemaVersion", 210'
    ],
    'app/build.gradle.kts': [
        'versionCode = 80', '1.10.18-alpha-autonomous-exploration-sandbox'
    ],
    'app/src/test/java/com/immunesignal/app/ExtendedAcquisitionSweepV11017Test.kt': [
        'oneFastSourceDoesNotPermitArchive', 'routeExpansionAddsDistinctAccessionFamiliesBeforeArchive'
    ],
    'docs/EXTENDED_ACQUISITION_SWEEP_v1.10.17.md': [
        'minimum source-family sweep', 'NO_ACCESSION_CONTINUE_SOURCE_SWEEP', 'not biological proof'
    ]
}
missing = []
for rel, needles in checks.items():
    text = Path(rel).read_text(encoding='utf-8')
    for needle in needles:
        if needle not in text:
            missing.append(f'{rel}: {needle}')
if missing:
    raise SystemExit('v1.10.17 extended acquisition sweep audit failed:\n' + '\n'.join(missing))
print('v1.10.17 extended acquisition sweep audit: PASS')
