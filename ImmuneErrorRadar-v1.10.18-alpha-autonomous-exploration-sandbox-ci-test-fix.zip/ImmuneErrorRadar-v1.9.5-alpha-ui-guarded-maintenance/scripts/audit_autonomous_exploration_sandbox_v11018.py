#!/usr/bin/env python3
from pathlib import Path

checks = {
    'app/src/main/java/com/immunesignal/app/AutonomousExplorationSandboxPolicy.kt': [
        'AutonomousExplorationSandboxPolicy',
        'exploration_sandbox_not_biological_proof',
        'drug_perturbation_research',
        'aging_immunosenescence_inflammaging',
        'diabetes_metabolic_inflammation',
        'gastric_acid_reflux_gut_barrier',
        'no treatment, dose, drug ranking'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetQueryCompiler.kt': [
        'AutonomousExplorationSandboxPolicy.queriesForRoute',
        'drug perturbation medication exposure aging diabetes metabolic inflammation reflux gut barrier dataset accession',
        'q_v11018_'
    ],
    'app/src/main/java/com/immunesignal/app/DirectDatasetSourceRouter.kt': [
        'PUBMED_ADJACENT_DOMAIN_MINING',
        'Autonomous exploration sandbox',
        'PUBMED_ACCESSION_MINING" -> "PUBMED_ADJACENT_DOMAIN_MINING"'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetAccessionResolver.kt': [
        'drug perturbation',
        'diabetes/metabolic condition labels candidate',
        'gastric-acid/reflux/gut-barrier labels candidate',
        'AutonomousExplorationSandboxPolicy.nearMissStatus'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.10.18-alpha-autonomous-exploration-sandbox',
        'AutonomousExplorationSandboxPolicy',
        'q_v11018_'
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'ENABLE_AUTONOMOUS_EXPLORATION_SANDBOX',
        'MIN_EXPLORATION_SANDBOX_QUERY_VARIANTS',
        '1.10.18'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'schemaVersion", 210'
    ],
    'app/build.gradle.kts': [
        'versionCode = 80',
        'versionName = "1.10.18-alpha-autonomous-exploration-sandbox"'
    ],
    'app/src/test/java/com/immunesignal/app/AutonomousExplorationSandboxV11018Test.kt': [
        'sandboxAddsAdjacentDomainsWithoutRelaxingClaims',
        'directRouterIncludesAdjacentDomainFamilyBeforeContradiction'
    ],
    'docs/AUTONOMOUS_EXPLORATION_SANDBOX_v1.10.18.md': [
        'Freedom in exploration',
        'Strictness in claims',
        'drug perturbation',
        'gastric-acid/reflux/gut-barrier'
    ]
}
missing = []
for path, tokens in checks.items():
    text = Path(path).read_text(errors='replace')
    for token in tokens:
        if token not in text:
            missing.append(f'{path}: {token}')
if missing:
    raise SystemExit('v1.10.18 autonomous exploration sandbox audit failed:\n' + '\n'.join(missing))
print('v1.10.18 autonomous exploration sandbox audit: PASS')
