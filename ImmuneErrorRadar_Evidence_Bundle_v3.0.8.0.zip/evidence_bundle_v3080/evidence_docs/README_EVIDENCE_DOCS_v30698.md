# ImmuneErrorRadar Evidence Documentation Pack v3.0.6.9.8

This pack contains the supporting documents requested for public repository/preprint release:

1. `docs/RECEIPTS_HASHES_v30698.md`
2. `assets/receipts/receipts_hashes_index_v30698.json`
3. `assets/receipts/receipts_hashes_index_v30698.csv`
4. `docs/TARGETED_GPL5175_REVIEW_MANIFEST_v30698.md`
5. `assets/manifests/targeted_GPL5175_review_manifest_v30698.csv`
6. `assets/manifests/gpl5175_targeted_probe_manifest_v1.source.json`
7. `docs/TIER0_BOUNDARIES_v30698.md`
8. `docs/REPLAY_DESCRIPTION_v30698.md`

These documents are designed to be copied into the GitHub repository under `docs/` and `assets/`.

Boundary: this pack documents Tier-0 computational hypothesis triage only. It does not provide clinical validation or wet-lab proof.
