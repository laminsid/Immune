# ImmuneErrorRadar Evidence Bundle v3.0.8.0

This bundle is intended for GitHub archival and independent review. It accompanies the local evidence viewer and the preprint.

## Boundary

This bundle documents executed, review-only hypothesis stress-tests. It does not provide medical advice, clinical validation, wet-lab evidence, or biological proof.

## Contents

- `preprint/` — submission-clean preprint PDF.
- `reports/` — generated ImmuneErrorRadar report PDFs available in this release context.
- `evidence_docs/` — receipt/hash index, targeted GPL5175 review manifest, Tier-0 boundaries, and replay description.

## Use

Open `../index.html` from the GitHub repository or from a local folder. Use the built-in SHA-256 verifier to check files against the known hashes shown in the viewer or in `evidence_docs/assets/receipts/receipts_hashes_index_v30698.json`.

## Claim boundary

The retained APM/B2M–TAP–HLA axis is data-only follow-up. Killed claims remain killed as written under current Tier-0 evidence. No wet-lab promotion is implied.
