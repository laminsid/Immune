package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.13 — Drug-discovery translation ladder.
 *
 * Converts a loose biomedical question into a staged pharma-style discovery pipeline.
 * The ladder raises rigor step-by-step while preserving early discovery value. It is
 * intentionally reporting/orchestration only: no diagnosis, therapy, dosing, mechanism,
 * or pathway proof is created by this layer.
 */
object GTIMDrugDiscoveryTranslationLadderV21213 {
    const val VERSION: String = "2.12.13-drug-discovery-translation-ladder"
    const val CLAIM_LIMIT: String = "translation_ladder_staging_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val domain = domain(report)
        val handles = handles(report)
        val utility = report.optJSONObject("publishedResearchUtilityScoreV21213")
        val continuation = report.optJSONObject("terminalDiscoveryContinuationV21212") ?: JSONObject()
        val activeStep = when {
            report.optJSONObject("reportConsistencyGateV2121")?.optBoolean("topicCompatibleTargetSelected", false) == true -> "05_dataset_capsule_candidate"
            handles.length() > 0 -> "04_dataset_or_literature_seed"
            domain != "open_mechanism_first" -> "03_target_biomarker_candidate"
            else -> "02_biological_route_candidate"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "PHARMA_STYLE_DISCOVERY_LADDER_ACTIVE")
            .put("domainKey", domain)
            .put("activeStep", activeStep)
            .put("candidateHandles", handles)
            .put("publishedResearchUtilityScore", utility?.optInt("score", -1) ?: -1)
            .put("ladder", ladder(domain, handles, continuation))
            .put("strictnessPolicy", "early_discovery_permitted_evidence_promotion_strict")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val active = obj.optString("activeStep", "unknown")
        val score = obj.optInt("publishedResearchUtilityScore", -1)
        val scoreText = if (score >= 0) score.toString() else "not scored yet"
        return listOf(
            "Drug-discovery translation ladder",
            "Active step: $active; published-research utility score=$scoreText/10; strictness=early discovery allowed, evidence promotion strict.",
            "Pipeline: topic signal → biological route → target/biomarker candidate → dataset/capsule candidate → comparator/sample linkage → contradiction check → publishable hypothesis.",
            "Boundary: ladder position is a research-readiness stage, not a therapeutic or clinical claim."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "PHARMA_STYLE_DISCOVERY_LADDER_ACTIVE",
        "topic signal → biological route → target/biomarker candidate",
        "early_discovery_permitted_evidence_promotion_strict",
        CLAIM_LIMIT
    ))

    private fun ladder(domain: String, handles: JSONArray, continuation: JSONObject): JSONArray {
        val handleState = if (handles.length() > 0) "present" else "missing"
        val stages = listOf(
            stage("01_topic_signal", "closed_or_active", "Capture the exact disease/exposure/phenotype question and prevent old-template contamination."),
            stage("02_biological_route_candidate", if (domain == "open_mechanism_first") "active" else "closed", "Map disease to route family without defaulting to microbiome/barrier unless positive signals exist."),
            stage("03_target_biomarker_candidate", if (domain != "open_mechanism_first") "active" else "pending", "Split target, biomarker/readout, endpoint, and context-of-use."),
            stage("04_dataset_or_literature_seed", handleState, "Use curated seed first; if missing, external lookup may create pending seed candidates."),
            stage("05_metadata_and_capsule_readiness", continuation.optString("state", "pending"), "Require SOFT/listing metadata, processed capsule or matrix hint, comparator labels, and source-to-sample linkage."),
            stage("06_contradiction_resistance", "required_before_upgrade", "Search negative/null/failed-replication and wrong-tissue/species evidence before any evidence upgrade."),
            stage("07_publishable_research_hypothesis", "research_only", "Produce falsifiable hypotheses and discriminator tests; no mechanism or treatment proof.")
        )
        val arr = JSONArray()
        stages.forEach { arr.put(it) }
        return arr
    }

    private fun stage(id: String, status: String, action: String): JSONObject = JSONObject()
        .put("stage", id)
        .put("status", status)
        .put("action", action)
        .put("claimLimit", "stage_readiness_only_no_evidence_upgrade")

    private fun domain(report: JSONObject): String {
        return report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainKey")
            ?: report.optJSONObject("terminalDiscoveryContinuationV21212")?.optString("domainKey")
            ?: GTIMStudyFocusNormalizerV21282.build(report.toString()).domain
    }

    private fun handles(report: JSONObject): JSONArray {
        val out = JSONArray()
        val regex = Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|SRR\\d+|PRJNA\\d+|PRJEB\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+|PMID:?\\d+|10\\.\\d{4,9}/[^\\s\\\"']+)\\b", RegexOption.IGNORE_CASE)
        regex.findAll(report.toString()).map { it.value.uppercase() }.distinct().take(12).forEach { out.put(it) }
        return out
    }
}
