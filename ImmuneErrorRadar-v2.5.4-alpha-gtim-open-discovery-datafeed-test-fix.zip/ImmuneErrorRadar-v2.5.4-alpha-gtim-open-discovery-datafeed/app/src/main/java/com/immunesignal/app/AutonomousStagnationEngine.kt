package com.immunesignal.app

import org.json.JSONObject
import java.util.Locale
import kotlin.math.max

/**
 * v1.3.6: Anti-stagnation layer.
 *
 * The previous v1.3.5 patch made empty cycles honest, but the next run could
 * still start from the same low-data PubMed neighborhood. This engine converts
 * a failed cycle into an applied next-cycle search move.
 */
object AutonomousStagnationEngine {
    data class StagnationPlan(
        val level: Int,
        val pendingPivot: PivotDecision,
        val effectiveMaxQueries: Int,
        val effectiveResultsPerQuery: Int,
        val reason: String
    ) {
        val active: Boolean get() = level > 0 && pendingPivot.pivotType != "NO_PIVOT"

        companion object {
            fun none(limits: ResearchRunLimits) = StagnationPlan(
                level = 0,
                pendingPivot = PivotDecision.none(),
                effectiveMaxQueries = limits.maxQueries,
                effectiveResultsPerQuery = limits.maxResultsPerQuery,
                reason = "No recent stagnation detected."
            )
        }
    }

    fun planFromRecentReports(recentReports: List<String>, limits: ResearchRunLimits): StagnationPlan {
        val parsed = recentReports.mapNotNull { runCatching { JSONObject(it) }.getOrNull() }
        if (parsed.isEmpty()) return StagnationPlan.none(limits)

        val consecutiveEmpty = parsed.take(5).takeWhile { report ->
            val delta = report.optJSONObject("knowledgeDelta")
            val newSources = delta?.optInt("newSourcesSaved", 0) ?: 0
            val repeated = delta?.optInt("repeatedSourcesSkipped", 0) ?: 0
            val pivot = report.optJSONObject("resilienceDecision")
            val pivotType = pivot?.optString("pivotType").orEmpty()
            val realPivot = pivotType.isNotBlank() && pivotType != "NO_PIVOT"
            newSources <= 0 && (repeated >= 5 || realPivot)
        }.size

        if (consecutiveEmpty <= 0) return StagnationPlan.none(limits)

        val latest = parsed.first()
        val priorPivot = latest.optJSONObject("resilienceDecision")?.let { pivotFromJson(it) } ?: PivotDecision.none()
        val evolved = latest.optJSONObject("queryEvolutionState")?.optString("evolvedQuery").orEmpty()
        val repeated = latest.optJSONObject("knowledgeDelta")?.optInt("repeatedSourcesSkipped", 0) ?: 0
        val level = when {
            consecutiveEmpty >= 3 || repeated >= 20 -> 3
            consecutiveEmpty >= 2 || repeated >= 10 -> 2
            else -> 1
        }

        val seed = when {
            evolved.isNotBlank() -> evolved
            priorPivot.nextQuerySeed.isNotBlank() -> priorPivot.nextQuerySeed
            else -> "immune response contradiction negative control longitudinal outcome dataset"
        }

        val pivot = ScopeDisciplineLock.sanitizePivot(
            priorPivot.copy(
                pivotType = when (level) {
                    3 -> "ANTI_STAGNATION_DEEP_ROTATION"
                    2 -> "APPLY_PREVIOUS_PIVOT_EXPANDED"
                    else -> "APPLY_PREVIOUS_PIVOT"
                },
                reason = "Applying prior failed-cycle lesson instead of restarting the same query lane. Consecutive empty cycles: $consecutiveEmpty; repeated skipped: $repeated.",
                nextIntent = if (level >= 2) "anti_stagnation_dataset_contradiction" else priorPivot.nextIntent.ifBlank { "evidence_lane_rotation" },
                nextQuerySeed = seed,
                priority = max(priorPivot.priority, 88)
            )
        )

        return StagnationPlan(
            level = level,
            pendingPivot = pivot,
            effectiveMaxQueries = max(limits.maxQueries, if (level >= 2) 6 else 5),
            effectiveResultsPerQuery = max(limits.maxResultsPerQuery, when (level) {
                3 -> 25
                2 -> 18
                else -> 12
            }),
            reason = "Recent cycles produced no useful source. The next run must widen PubMed retmax and apply the evolved query before normal lanes."
        )
    }

    private fun pivotFromJson(json: JSONObject): PivotDecision {
        return PivotDecision(
            pivotType = json.optString("pivotType", "NO_PIVOT"),
            reason = json.optString("reason", "Recovered from recent report."),
            nextIntent = json.optString("nextIntent", "evidence_lane_rotation"),
            nextQuerySeed = json.optString("nextQuerySeed", "immune response contradiction negative control longitudinal outcome dataset"),
            priority = json.optInt("priority", 80)
        )
    }

    fun antiStagnationQueries(plan: StagnationPlan): List<ResearchQuery> {
        if (!plan.active) return emptyList()
        val seed = plan.pendingPivot.nextQuerySeed.ifBlank { "immune response" }
        val safeSeed = seed.replace(Regex("\\s+"), " ").trim().take(500)
        val datasetTerms = "(GSE OR GEO OR ImmPort OR SDY OR PRJNA OR RNA-seq OR transcriptomic OR single-cell OR scRNA-seq)"
        val evidenceTerms = "(human OR patient OR cohort OR longitudinal OR time course OR severity OR recovery OR outcome)"
        val contradictionTerms = "(failed to replicate OR conflicting results OR no association OR heterogeneity OR negative control)"
        val base = if (safeSeed.isBlank()) "immune response" else safeSeed

        return listOf(
            ResearchQuery(
                id = "q_antistag_dataset_${plan.level}",
                label = "ANTI-STAGNATION: dataset accession search",
                query = "($base) AND $datasetTerms AND $evidenceTerms",
                reason = "The last cycle repeated known PubMed IDs. Search now prioritizes verifiable dataset/accession terms."
            ),
            ResearchQuery(
                id = "q_antistag_contradiction_${plan.level}",
                label = "ANTI-STAGNATION: contradiction/control search",
                query = "($base) AND $contradictionTerms AND $evidenceTerms",
                reason = "The researcher must try to falsify or weaken the hypothesis before another upgrade."
            ),
            ResearchQuery(
                id = "q_antistag_outcome_${plan.level}",
                label = "ANTI-STAGNATION: outcome-label search",
                query = "($base) AND (trigger OR exposure OR infection OR allergen) AND (response OR cytokine OR interferon OR T cell OR antibody) AND (outcome OR recovery OR severity)",
                reason = "Avoid isolated marker papers; require trigger-response-outcome structure."
            )
        )
    }
}
