package com.immunesignal.app

/**
 * GTIM v2.5.4 open-discovery-datafeed relaxed-exploration policy.
 *
 * This is not a claim-relaxation layer. It lowers the threshold for surfacing useful
 * research leads, source-metadata traces, and bounded mechanism candidates while keeping
 * diagnosis, treatment, DGE, fold-change, p-value, and confirmed-discovery claims blocked.
 */
object GTIMRelaxedExplorationPolicyV253 {
    const val UNIFIED_VERSION_NAME: String = "2.5.4-alpha-gtim-open-discovery-datafeed"
    const val UNIFIED_ENGINE_VERSION: String = "v2.5.4-alpha-gtim-open-discovery-datafeed"
    const val UNIFIED_VERSION_CODE: Int = 131
    const val UNIFIED_SCHEMA_VERSION: String = "2.5.4"

    const val MIN_ROUTE_FIT_FOR_EXPLORATORY_RULE: Int = 15
    const val MAX_SOURCE_METADATA_LEADS: Int = 12
    const val MAX_EXPLORATORY_RESEARCH_LEADS: Int = 12
    const val MIN_EXPLORATORY_CONFIDENCE: Int = 5
    const val MAX_EXPLORATORY_CONFIDENCE: Int = 82

    const val INCLUDE_SOURCE_OBJECTS_WITH_ACCESSION_ANCHORS: Boolean = true
    const val MAX_SOURCE_EVIDENCE_OBJECTS: Int = 14
    const val MAX_GTIM_EVIDENCE_OBJECTS: Int = 24
    const val MAX_GTIM_MECHANISM_CANDIDATES: Int = 12
    const val MIN_GTIM_CONFIDENCE_SCORE: Int = 3
    const val MAX_GTIM_CONFIDENCE_SCORE_NO_EXTERNAL_VALIDATION: Int = 86

    const val STRICTNESS_POSTURE: String =
        "open_discovery_datafeed_enabled_claim_confirmation_still_locked"

    val RELAXED_OUTPUTS_ALLOWED: List<String> = listOf(
        "weak textual leads",
        "source metadata traces",
        "repository-handle leads",
        "partial comparator hints",
        "negative/null-result hints",
        "manual PDF/snippet/PMID/DOI seeds",
        "external accession handles for secondary lookup",
        "matrix/file availability hints",
        "corpus-relative mechanism candidates",
        "falsifiable lab-validation plans",
        "data-feed action plan"
    )

    val CLAIMS_STILL_BLOCKED: List<String> = listOf(
        "diagnosis",
        "treatment recommendation",
        "patient prediction",
        "confirmed discovery from weak lead",
        "DGE/fold-change/p-value without matrix analysis",
        "human mechanism confirmation from cross-species or text-mined evidence"
    )
}
