package com.immunesignal.app

// legacy audit token: v1.10.22 continuity

import org.json.JSONObject
import java.util.Locale

/**
 * v1.10.19: Domain Expertise Memory.
 *
 * The system should not lose its local expertise every time a route fails. This
 * layer lets exploratory domains accumulate stable research priors and domain
 * vocabulary while still forbidding biological proof, clinical advice, drug
 * ranking, treatment selection, dosing, or causal upgrade without evidence
 * gates. It stabilizes useful beliefs; it does not make them true.
 */
object DomainExpertiseMemoryPolicy {
    const val CLAIM_LIMIT: String = "domain_expertise_memory_not_biological_proof"
    const val MODE: String = "DOMAIN_EXPERTISE_MEMORY"

    data class DomainExpertiseCard(
        val domainId: String,
        val label: String,
        val expertiseState: String,
        val expertiseScore: Int,
        val stableResearchPriors: List<String>,
        val workingVocabulary: List<String>,
        val protectedFromReset: List<String>,
        val falsificationGates: List<String>,
        val nextLearningAction: String,
        val priorExposureCount: Int = 0,
        val continuityAction: String = "Keep as searchable research prior only.",
        val claimLimit: String = CLAIM_LIMIT
    )

    data class DomainExpertiseReport(
        val active: Boolean,
        val mode: String,
        val summary: String,
        val cards: List<DomainExpertiseCard>,
        val stablePriorCount: Int,
        val protectedBeliefCount: Int,
        val carriedForwardDomainCount: Int,
        val matureDomainCount: Int,
        val continuityState: String,
        val continuitySummary: String,
        val nextAction: String,
        val claimLimit: String = CLAIM_LIMIT
    ) {
        companion object {
            fun empty() = DomainExpertiseReport(
                active = false,
                mode = MODE,
                summary = "Domain expertise memory was not evaluated.",
                cards = emptyList(),
                stablePriorCount = 0,
                protectedBeliefCount = 0,
                carriedForwardDomainCount = 0,
                matureDomainCount = 0,
                continuityState = "NOT_EVALUATED",
                continuitySummary = "No prior domain expertise continuity was evaluated.",
                nextAction = "Run exploration cycle before stabilizing domain expertise."
            )
        }
    }

    private data class DomainDefinition(
        val id: String,
        val label: String,
        val terms: List<String>,
        val priors: List<String>,
        val gates: List<String>,
        val next: String
    )

    private val domains = listOf(
        DomainDefinition(
            id = "antihistamine_histamine_mast_cell",
            label = "Antihistamines / histamine / mast-cell axis",
            terms = listOf("antihistamine", "histamine", "h1", "h2", "mast cell", "urticaria", "allergy"),
            priors = listOf(
                "Histamine/H1/H2 terms are useful as exposure or pathway vocabulary, not treatment advice.",
                "Mast-cell/allergy leads must still close outcome labels and controls before ranking."
            ),
            gates = listOf("accession", "condition labels", "outcome labels", "control/comparator", "no treatment/dose claim"),
            next = "Mine public gene-expression or cohort metadata using histamine/mast-cell vocabulary and preserve near-miss leads."
        ),
        DomainDefinition(
            id = "inflammatory_disease_chronic_inflammation",
            label = "Inflammatory disease / chronic inflammation expertise",
            terms = listOf("inflammatory disease", "chronic inflammation", "tnf", "il-6", "autoimmune", "cytokine", "inflammation"),
            priors = listOf(
                "Generic inflammation is a dangerous false bridge unless disease, tissue, outcome, and time context are explicit.",
                "TNF/IL-6 can guide search vocabulary but cannot prove a mechanism alone."
            ),
            gates = listOf("human/patient context", "tissue or cell context", "outcome labels", "time order", "negative/control signal"),
            next = "Build a reusable inflammation vocabulary bank while forcing tissue/outcome/time gates before interpretation."
        ),
        DomainDefinition(
            id = "drug_perturbation_research",
            label = "Drug perturbation / medication exposure research",
            terms = listOf("drug", "medication", "pharmacologic", "perturbation", "challenge", "exposure", "treated"),
            priors = listOf(
                "Drug terms are allowed only as perturbation/exposure metadata for research retrieval.",
                "Medication exposure can reveal immune-response contrasts, but not treatment value."
            ),
            gates = listOf("no treatment", "no dose", "no drug ranking", "accession", "metadata", "comparator/control"),
            next = "Search for public perturbation datasets and store exposure vocabulary without clinical recommendations."
        ),
        DomainDefinition(
            id = "aging_immunosenescence_inflammaging",
            label = "Aging / immunosenescence / inflammaging expertise",
            terms = listOf("aging", "ageing", "immunosenescence", "inflammaging", "elderly", "older adult"),
            priors = listOf(
                "Aging can change immune baselines; age must be treated as context or stratifier, not proof.",
                "Inflammaging leads need comparator age groups and outcome labels before use."
            ),
            gates = listOf("age group labels", "matched controls", "outcome labels", "cell/tissue context", "time order if causal language"),
            next = "Accumulate age-stratified immune dataset leads before merging with recovery or allergy axes."
        ),
        DomainDefinition(
            id = "diabetes_metabolic_inflammation",
            label = "Diabetes / metabolic inflammation expertise",
            terms = listOf("diabetes", "diabetic", "metabolic inflammation", "insulin", "glucose", "glycolysis", "mitochondrial"),
            priors = listOf(
                "Metabolic inflammation can change immune state, but disease/control and medication context are confounders.",
                "Diabetes-related immune leads need phenotype labels and comparator groups."
            ),
            gates = listOf("diabetes phenotype", "medication/exposure context", "control/comparator", "outcome labels", "sample metadata"),
            next = "Preserve diabetes/metabolic terms as a domain expertise track and seek phenotype-rich transcriptomic datasets."
        ),
        DomainDefinition(
            id = "gastric_acid_reflux_gut_barrier",
            label = "Gastric acid / reflux / gut-barrier expertise",
            terms = listOf("gastric acid", "gerd", "reflux", "gut barrier", "intestinal permeability", "microbiome", "stomach acid"),
            priors = listOf(
                "Gut-barrier/reflux terms may connect exposure, microbiome, and immune context, but are near-miss leads until accession and outcomes close.",
                "Microbiome-only evidence cannot upgrade immune hypotheses without immune readout and outcome labels."
            ),
            gates = listOf("immune readout", "gut/reflux phenotype", "outcome labels", "control/comparator", "accession"),
            next = "Build gut-barrier vocabulary and keep reflux/GERD as adjacent-domain leads, not conclusions."
        )
    )


    fun bootstrapQueryVocabularyForExploration(): List<String> {
        if (!RuntimeFeatureFlags.ENABLE_DOMAIN_QUERY_ACTIVATION) return emptyList()
        return domains
            .flatMap { it.terms.take(3) }
            .map { it.trim() }
            .filter { it.length in 2..48 }
            .distinct()
            .take(12)
    }

    fun reusableQueryVocabularyFromRecentReports(recentReports: List<String>): List<String> {
        if (!RuntimeFeatureFlags.ENABLE_DOMAIN_EXPERTISE_QUERY_REUSE || recentReports.isEmpty()) return emptyList()
        val terms = mutableListOf<String>()
        recentReports.forEach { line ->
            val report = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
            val forager = report.optJSONObject("datasetForagingReport") ?: report.optJSONObject("datasetForaging") ?: return@forEach
            val expertise = forager.optJSONObject("domainExpertiseReport") ?: return@forEach
            val cards = expertise.optJSONArray("cards") ?: return@forEach
            for (i in 0 until cards.length()) {
                val card = cards.optJSONObject(i) ?: continue
                val score = card.optInt("expertiseScore", 0)
                val state = card.optString("expertiseState", "")
                if (score < RuntimeFeatureFlags.MIN_DOMAIN_EXPERTISE_SCORE_TO_REUSE && !state.contains("MATURE", ignoreCase = true)) continue
                val vocab = card.optJSONArray("workingVocabulary") ?: continue
                for (j in 0 until vocab.length()) {
                    vocab.optString(j).takeIf { it.isNotBlank() }?.let { terms += it }
                }
            }
        }
        return terms.map { it.trim() }
            .filter { it.length in 2..48 }
            .distinct()
            .take(12)
    }

    fun build(
        attempts: List<DatasetSourceAttempt>,
        queries: List<ResearchQuery>,
        candidates: List<DatasetAccessionCandidate>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        existingCards: Int = 0,
        recentReports: List<String> = emptyList()
    ): DomainExpertiseReport {
        val priorExposure = extractPriorExposure(recentReports)
        val corpus = buildString {
            append(attempts.joinToString(" ") { it.query + " " + it.reason + " " + it.sourceFamily })
            append(' ')
            append(queries.joinToString(" ") { it.query + " " + it.reason + " " + it.label })
            append(' ')
            append(candidates.joinToString(" ") { it.sourceTitle + " " + it.conditionLabelsHint + " " + it.outcomeLabelsHint + " " + it.triggerResponseOutcomeHint })
            append(' ')
            append(parsedMetadata.joinToString(" ") { it.conditionLabels.joinToString(" ") + " " + it.outcomeLabels.joinToString(" ") + " " + it.tissueOrSource + " " + it.assayType })
        }.lowercase(Locale.US)
        val cards = domains.mapNotNull { domain ->
            val matchedTerms = domain.terms.filter { term -> corpus.contains(term.lowercase(Locale.US)) }
            val priorCount = priorExposure[domain.id] ?: 0
            if (matchedTerms.isEmpty() && priorCount <= 0) return@mapNotNull null
            val exposureCount = priorCount + if (matchedTerms.isNotEmpty()) 1 else 0
            val evidenceBonus = when {
                parsedMetadata.isNotEmpty() -> 35
                candidates.isNotEmpty() -> 25
                attempts.any { it.idsFound > 0 } -> 15
                else -> 8
            }
            val continuityBonus = (exposureCount * 7).coerceAtMost(28)
            val score = (matchedTerms.size * 9 + evidenceBonus + continuityBonus + existingCards.coerceAtMost(10)).coerceIn(15, 88)
            val state = when {
                parsedMetadata.isNotEmpty() -> "EVIDENCE_LINKED_EXPERTISE_NEEDS_GATES"
                candidates.isNotEmpty() -> "CANDIDATE_LINKED_EXPERTISE"
                exposureCount >= RuntimeFeatureFlags.MIN_DOMAIN_EXPERTISE_MATURITY_EXPOSURES -> "MATURE_DOMAIN_PRIOR_NEEDS_FALSIFICATION"
                exposureCount > 1 -> "CARRIED_FORWARD_DOMAIN_PRIOR"
                attempts.isNotEmpty() -> "SEARCH_EXPERIENCE_STABILIZED"
                else -> "EXPERTISE_SEEDING"
            }
            DomainExpertiseCard(
                domainId = domain.id,
                label = domain.label,
                expertiseState = state,
                expertiseScore = score,
                stableResearchPriors = domain.priors,
                workingVocabulary = (matchedTerms.ifEmpty { domain.terms.take(3) }).distinct().take(10),
                protectedFromReset = listOf(
                    "Do not discard this domain vocabulary after one failed sweep.",
                    "Carry forward as a research prior until falsified, not as biological proof.",
                    "Reuse only if it can close accession, metadata, outcome, control, or time-order gates.",
                    "Domain exposure count: $exposureCount cycle(s); preserve useful vocabulary unless a stronger falsification gate retires it."
                ),
                falsificationGates = domain.gates,
                nextLearningAction = domain.next,
                priorExposureCount = exposureCount,
                continuityAction = if (exposureCount >= RuntimeFeatureFlags.MIN_DOMAIN_EXPERTISE_MATURITY_EXPOSURES) {
                    "Treat as a mature domain prior: deepen within the domain before jumping to a new one, unless falsification gates fail."
                } else if (exposureCount > 1) {
                    "Carry forward and seek one stronger accession/metadata test before switching domains."
                } else {
                    "Seed the domain only; require repeated useful terms before maturity."
                }
            )
        }
        val summary = if (cards.isEmpty()) {
            "Domain expertise memory active but no domain reached stabilization terms this cycle."
        } else {
            "Domain expertise memory stabilized ${cards.size} domain track(s): ${cards.joinToString(", ") { it.domainId }}. Expertise is retained as research prior only; claims remain locked."
        }
        val carried = cards.count { it.priorExposureCount > 0 }
        val mature = cards.count { it.priorExposureCount >= RuntimeFeatureFlags.MIN_DOMAIN_EXPERTISE_MATURITY_EXPOSURES }
        val continuityState = when {
            mature > 0 -> "MATURE_DOMAIN_EXPERTISE_ACTIVE"
            carried > 0 -> "CARRIED_FORWARD_EXPERTISE_ACTIVE"
            cards.isNotEmpty() -> "NEW_DOMAIN_EXPERTISE_SEEDED"
            else -> "NO_DOMAIN_EXPERTISE_MATCH"
        }
        return DomainExpertiseReport(
            active = true,
            mode = MODE,
            summary = summary,
            cards = cards,
            stablePriorCount = cards.sumOf { it.stableResearchPriors.size },
            protectedBeliefCount = cards.sumOf { it.protectedFromReset.size },
            carriedForwardDomainCount = carried,
            matureDomainCount = mature,
            continuityState = continuityState,
            continuitySummary = "v1.10.26 continuity: carried=$carried, mature=$mature; domain priors persist across cycles but remain locked behind evidence gates.",
            nextAction = if (cards.isEmpty()) {
                "Inject safe domain vocabulary into one accession-mining query, then stabilize domains once repeated useful vocabulary appears."
            } else if (mature > 0) {
                "Deepen mature domain tracks before jumping domains; only retire a track through explicit falsification gates."
            } else {
                "Keep domain tracks alive across cycles; build expertise per domain while enforcing accession/metadata/outcome/control gates."
            }
        )
    }

    private fun extractPriorExposure(recentReports: List<String>): Map<String, Int> {
        if (recentReports.isEmpty()) return emptyMap()
        val counts = mutableMapOf<String, Int>()
        recentReports.forEach { line ->
            val report = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
            val forager = report.optJSONObject("datasetForagingReport") ?: report.optJSONObject("datasetForaging") ?: return@forEach
            val expertise = forager.optJSONObject("domainExpertiseReport") ?: return@forEach
            val cards = expertise.optJSONArray("cards") ?: return@forEach
            for (i in 0 until cards.length()) {
                val card = cards.optJSONObject(i) ?: continue
                val domainId = card.optString("domainId").takeIf { it.isNotBlank() } ?: continue
                counts[domainId] = (counts[domainId] ?: 0) + 1
            }
        }
        return counts
    }
}
