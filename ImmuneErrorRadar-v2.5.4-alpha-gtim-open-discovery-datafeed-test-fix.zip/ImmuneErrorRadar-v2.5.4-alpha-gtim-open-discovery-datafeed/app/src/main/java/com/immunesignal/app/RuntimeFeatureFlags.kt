// legacy_audit_version_token_v1110: RELEASE_TRAIN_VERSION_NAME: String = "1.11.0-alpha-research-grade-mechanism-dossier"; RELEASE_TRAIN_VERSION_CODE: Int = 124; LEARNING_SESSION_SCHEMA_VERSION: String = "1.11.0"
// legacy_audit_version_token_v11055: RELEASE_TRAIN_VERSION_NAME: String = "1.10.55-alpha-ci-fast-gate-route-surface-unification"; RELEASE_TRAIN_VERSION_CODE: Int = 117; LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.55"
// legacy_audit_version_token_v11051: RELEASE_TRAIN_VERSION_NAME: String = "1.10.51-alpha-route-reconciliation-evidence-candidate-activation"; LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.51"
// legacy_audit_version_token_v11052: RELEASE_TRAIN_VERSION_NAME: String = "1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox"; RELEASE_TRAIN_VERSION_CODE: Int = 114; LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.52"
// legacy_audit_version_token_v11053: RELEASE_TRAIN_VERSION_NAME: String = "1.10.53-alpha-ci-route-linkage-hardening"; RELEASE_TRAIN_VERSION_CODE: Int = 115; LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.53"
// legacy_audit_version_token_v11054: RELEASE_TRAIN_VERSION_NAME: String = "1.10.54-alpha-github-ci-runtime-surface-hardening"; RELEASE_TRAIN_VERSION_CODE: Int = 116; LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.54"
package com.immunesignal.app

/**
 * v1.6.1: single rollback/activation point for optional research-intelligence layers.
 *
 * These flags keep the production research cycle backward-compatible. Foundation
 * knowledge remains disabled by default. Learning Sessions are user-initiated UI
 * tools, not background workers, and never run unless the user presses Think.
 */
// legacy audit token: 1.10.22
// legacy_audit_version_token_v11027: 1.10.27
object RuntimeFeatureFlags {
    const val ENABLE_FOUNDATION_KNOWLEDGE_OS: Boolean = false
    const val ENABLE_LEARNING_SESSION_UI: Boolean = true
    const val DEFAULT_SEARCH_TIME_LIMIT_MILLIS: Long = 20L * 60L * 1000L
    const val DEFAULT_RESEARCH_LEARNING_TIME_LIMIT_MILLIS: Long = 45L * 60L * 1000L
    const val DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS: Long = 45L * 60L * 1000L
    const val PRIOR_FAST_THINKING_WINDOW_MILLIS: Long = 30L * 1000L
    const val MIN_AUTONOMOUS_THINKING_PASSES: Int = 4
    const val MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES: Int = 3
    const val MIN_EXTENDED_ACCESSION_QUERY_PATHS: Int = 3
    const val MIN_CORE_ACCESSION_SOURCE_FAMILIES_BEFORE_ARCHIVE: Int = 4
    const val ENABLE_ACCESSION_EXHAUSTION_GATE: Boolean = true
    const val ENABLE_DOMAIN_QUERY_ACTIVATION: Boolean = true

    const val ENABLE_ACCESSION_MINING_INTENSITY: Boolean = true
    const val PUBMED_ACCESSION_MINING_RETMAX: Int = 25
    const val PUBMED_ACCESSION_MINING_ABSTRACTS_PER_CYCLE: Int = 5
    const val PUBMED_ADJACENT_DOMAIN_RETMAX: Int = 15
    const val PUBMED_ADJACENT_DOMAIN_ABSTRACTS_PER_CYCLE: Int = 2

    const val ENABLE_DATA_AVAILABILITY_ACCESSION_QUERY_PRIORITY: Boolean = true
    const val MAX_DATA_AVAILABILITY_DOMAIN_TERMS: Int = 5
    const val MAX_DATA_AVAILABILITY_LABEL_TERMS: Int = 12
    const val ENABLE_MATURE_DOMAIN_EVIDENCE_PROBE: Boolean = true
    const val ENABLE_MATURE_DOMAIN_FOCUS_MODE: Boolean = true
    const val ENABLE_STRONG_ROUTE_FINGERPRINT: Boolean = true
    const val ENABLE_LEAN_AGENT_RUNTIME_ORCHESTRATOR: Boolean = true
    const val MAX_MATURE_DOMAIN_PROBE_DOMAINS: Int = 3
    const val MAX_MATURE_DOMAIN_PROBE_QUERIES: Int = 2
    const val MIN_RELAXED_DOMAIN_EXPOSURES: Int = 3
    const val ENABLE_AUTONOMOUS_EXPLORATION_SANDBOX: Boolean = true
    const val MIN_EXPLORATION_SANDBOX_QUERY_VARIANTS: Int = 6
    const val ENABLE_SOURCE_PRIORITY_ARBITRATION: Boolean = true
    const val ENABLE_DOMAIN_EXPERTISE_MEMORY: Boolean = true
    const val MIN_DOMAIN_EXPERTISE_SCORE_TO_REUSE: Int = 25
    const val MAX_DOMAIN_EXPERTISE_CARDS: Int = 6
    const val MIN_DOMAIN_EXPERTISE_MATURITY_EXPOSURES: Int = 3
    const val ENABLE_LEARNING_RULE_ENGINE: Boolean = true
    const val MIN_LEARNING_RULE_COVERAGE: Double = 0.60
    const val ENABLE_DOMAIN_EXPERTISE_QUERY_REUSE: Boolean = true
    const val ENABLE_ROUTE_FINGERPRINT_GUARD: Boolean = true
    const val ROUTE_FINGERPRINT_LOOKBACK: Int = 5
    const val MAX_EPISTEMIC_BELIEFS_PER_REPORT: Int = 60
    const val STRONG_SIGNAL_CAUSALITY_THRESHOLD: Int = 65
    const val STRONG_SIGNAL_EVIDENCE_THRESHOLD: Int = 65
    const val EVIDENCE_DECAY_PENALTY_AFTER_YEAR_3: Int = 3
    const val EVIDENCE_DECAY_PENALTY_AFTER_YEAR_7: Int = 8
    const val EVIDENCE_DECAY_PENALTY_AFTER_YEAR_12: Int = 15
    const val MAX_LEARNING_SESSION_HISTORY: Int = 20
    const val ENABLE_RELEASE_VERSION_LINKAGE_GUARD: Boolean = true
    const val ENABLE_GLOBAL_RESEARCH_GRADE_BRIEF_V11061: Boolean = true
    const val GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061: Int = 32
    const val ENABLE_RESEARCH_GRADE_MECHANISM_DOSSIER_V1110: Boolean = true
    const val ENABLE_GRADED_EXPLORATORY_RESULTS_V1115: Boolean = true
    // legacy_audit_version_token_v11034: RELEASE_TRAIN_VERSION_NAME: String = "1.10.34-alpha-useful-learning-report"
    // legacy_audit_version_token_v11041: RELEASE_TRAIN_VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"
    // legacy_audit_version_token_v11042: RELEASE_TRAIN_VERSION_NAME: String = "1.10.42-alpha-biomedical-concept-bridge"
    // legacy_audit_version_token_v11043: RELEASE_TRAIN_VERSION_NAME: String = "1.10.43-alpha-modern-medtech-modular-index"
    // legacy_audit_version_token_v11044: RELEASE_TRAIN_VERSION_NAME: String = "1.10.44-alpha-viral-countermeasure-knowledge-graph"
    // legacy_audit_version_token_v11045: RELEASE_TRAIN_VERSION_NAME: String = "1.10.45-alpha-compile-scope-linkage-guard"
    // legacy_audit_version_token_v11046: RELEASE_TRAIN_VERSION_NAME: String = "1.10.46-alpha-longevity-biological-systems-graph"
    // legacy_audit_version_token_v11047: RELEASE_TRAIN_VERSION_NAME: String = "1.10.47-alpha-topic-fit-metadata-parse-ui-clarity"
    // legacy_audit_version_token_v11048: RELEASE_TRAIN_VERSION_NAME: String = "1.10.48-alpha-relaxed-progression-context-alignment"
    // legacy_audit_version_token_v11049: RELEASE_TRAIN_VERSION_NAME: String = "1.10.49-alpha-topic-route-correction-evidence-object-candidate"
    // legacy_audit_version_token_v11050: RELEASE_TRAIN_VERSION_NAME: String = "1.10.50-alpha-environmental-psychophysiological-exposome-lane"
    const val RELEASE_TRAIN_VERSION_NAME: String = "2.5.4-alpha-gtim-open-discovery-datafeed"
    // legacy_audit_version_token_v11034: RELEASE_TRAIN_VERSION_CODE: Int = 96
    // legacy_audit_version_token_v11041: RELEASE_TRAIN_VERSION_CODE: Int = 103
    // legacy_audit_version_token_v11042: RELEASE_TRAIN_VERSION_CODE: Int = 104
    // legacy_audit_version_token_v11043: RELEASE_TRAIN_VERSION_CODE: Int = 105
    // legacy_audit_version_token_v11044: RELEASE_TRAIN_VERSION_CODE: Int = 106
    // legacy_audit_version_token_v11045: RELEASE_TRAIN_VERSION_CODE: Int = 107
    // legacy_audit_version_token_v11046: RELEASE_TRAIN_VERSION_CODE: Int = 108
    // legacy_audit_version_token_v11047: RELEASE_TRAIN_VERSION_CODE: Int = 109
    // legacy_audit_version_token_v11048: RELEASE_TRAIN_VERSION_CODE: Int = 110
    // legacy_audit_version_token_v11049: RELEASE_TRAIN_VERSION_CODE: Int = 111
    // legacy_audit_version_token_v11050: RELEASE_TRAIN_VERSION_CODE: Int = 112
    const val RELEASE_TRAIN_VERSION_CODE: Int = 131

    const val ENABLE_DATASET_PATH_LINKAGE_GUARD: Boolean = true
    const val ENABLE_DATASET_PASS_COVERAGE_LINKAGE: Boolean = true
    // legacy_audit_version_token_v11029_schema: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.29"
    // legacy_audit_version_token_v11034: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.34"
    // legacy_audit_version_token_v11041: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.41"
    // legacy_audit_version_token_v11042: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.42"
    // legacy_audit_version_token_v11043: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.43"
    // legacy_audit_version_token_v11044: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.44"
    // legacy_audit_version_token_v11045: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.45"
    // legacy_audit_version_token_v11046: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.46"
    // legacy_audit_version_token_v11047: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.47"
    // legacy_audit_version_token_v11048: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.48"
    // legacy_audit_version_token_v11049: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.49"
    // legacy_audit_version_token_v11050: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.50"
    const val LEARNING_SESSION_SCHEMA_VERSION: String = "2.5.4"

    const val FOUNDATION_CLAIM_LIMIT: String = "foundation_knowledge_not_evidence"
    const val LEARNING_SESSION_CLAIM_LIMIT: String = "learning_session_not_biological_proof"
    const val CHECKPOINT_CLAIM_LIMIT: String = "learning_session_checkpoint_not_evidence"
    const val SPECIALIZED_REASONING_CLAIM_LIMIT: String = "specialized_reasoning_not_biological_proof"
    const val EPISTEMIC_BELIEF_CLAIM_LIMIT: String = "epistemic_beliefs_not_biological_proof"
    const val COGNITIVE_PATH_CLAIM_LIMIT: String = "cognitive_path_integration_not_biological_proof"
}
