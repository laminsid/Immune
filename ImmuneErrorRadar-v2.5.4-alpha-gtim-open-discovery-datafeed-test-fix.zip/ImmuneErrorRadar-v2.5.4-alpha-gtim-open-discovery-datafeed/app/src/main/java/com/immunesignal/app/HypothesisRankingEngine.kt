package com.immunesignal.app

object HypothesisRankingEngine {
    fun rank(findings: List<ResearchFinding>): List<HypothesisRankCard> {
        if (findings.isEmpty()) return emptyList()
        val groups = findings.groupBy { HypothesisId.fromAxes(it.matchedAxes) }
        return groups.map { (id, items) ->
            val avgEvidence = items.map { it.evidence.evidenceQualityScore }.average().toInt()
            val avgFreshnessBoost = items.map { EvidenceFreshnessScorer.score(it).boostInRanking }.average().toInt().coerceIn(0, 5)
            val avgMechanisticDecayPenalty = items.map { EvidenceFreshnessScorer.decayPenaltyForMechanisticInterpretation(it) }.average().toInt().coerceIn(0, RuntimeFeatureFlags.EVIDENCE_DECAY_PENALTY_AFTER_YEAR_12)
            val adjustedEvidence = (avgEvidence + avgFreshnessBoost - avgMechanisticDecayPenalty).coerceIn(0, 100)
            val avgCausality = items.map { it.causality.causalityScore }.average().toInt()
            val repeatability = items.maxOfOrNull { it.personalPattern.repeatedObservationCount } ?: 0
            val negativeStatus = items.firstOrNull()?.negativeControl?.status ?: "unknown"
            val novelty = items.map { it.noveltyScore }.average().toInt()
            val score = (adjustedEvidence * 0.32 + avgCausality * 0.34 + novelty * 0.18 + (repeatability * 12).coerceAtMost(60) * 0.16).toInt().coerceIn(0, 100)
            val status = when {
                score >= ResearchPolicyLock.STRONG_SIGNAL_CAUSALITY_THRESHOLD && adjustedEvidence >= ResearchPolicyLock.STRONG_SIGNAL_EVIDENCE_THRESHOLD && repeatability >= ResearchPolicyLock.STRONG_SIGNAL_REPEATABILITY_THRESHOLD && negativeStatus != "control_required_before_strong" -> "STRONG_SIGNAL"
                score >= 55 -> "WATCH"
                score >= 35 -> "WEAK"
                else -> "NOISE_OR_UNKNOWN"
            }
            val label = items.maxByOrNull { it.noveltyScore }?.bridgeSignal ?: id
            HypothesisRankCard(
                hypothesisId = id,
                label = label,
                status = status,
                overallScore = score,
                evidenceQualityScore = adjustedEvidence,
                causalityScore = avgCausality,
                personalRepeatability = repeatability,
                negativeControlStatus = negativeStatus,
                nextBestMeasurement = items.firstOrNull()?.personalPattern?.nextBestMeasurement ?: "Add repeated timestamped observations.",
                whyRanked = buildList {
                    add("Evidence quality average: $avgEvidence/100; freshness-adjusted: $adjustedEvidence/100.")
                    add("Freshness boost: +$avgFreshnessBoost ranking point(s); mechanistic age-decay penalty: -$avgMechanisticDecayPenalty; ranking weight only, not biological proof.")
                    add("Causality score average: $avgCausality/100.")
                    add("Personal repeatability count: $repeatability.")
                    add("Negative-control status: $negativeStatus.")
                    addAll(ContradictionFinder.contradictionSearchPrompts(items.first().matchedAxes, label).take(2))
                }.take(7)
            )
        }.sortedByDescending { it.overallScore }.take(8)
    }
}
