package com.immunesignal.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

/**
 * v1.4.3: launcher is research-only; legacy daily/manual scan routes are closed from the runtime manifest.
 *
 * The old daily/manual scan form was intentionally removed from the first screen.
 * Immune Error Radar is a private autonomous research engine, not a daily health
 * tracker or diagnostic tool. Historical case/report screens remain available
 * for compatibility, but the primary flow is Search -> Evidence -> Learn.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<TextView>(R.id.engineVersionText).text =
            "Research leads only. Full technical details stay in Export."

        findViewById<Button>(R.id.researchAutopilotButton).setOnClickListener {
            startActivity(Intent(this, ResearchAutopilotActivity::class.java))
        }
        findViewById<Button>(R.id.historyButton).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }
}
