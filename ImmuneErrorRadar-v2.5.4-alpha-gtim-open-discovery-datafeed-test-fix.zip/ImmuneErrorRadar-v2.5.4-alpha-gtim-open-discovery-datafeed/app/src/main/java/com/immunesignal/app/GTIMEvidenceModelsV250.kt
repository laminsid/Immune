package com.immunesignal.app

/**
 * GTIM v2.5 evidence surface.
 *
 * These models deliberately sit above the existing v1.11.x accession/matrix dossier rather than
 * replacing it. They expose the global scientific product goal in a structured way while keeping
 * all claims bounded to research data-engineering and falsifiable hypothesis generation.
 */
data class GTIMEvidenceObjectV250(
    val objectId: String,
    val sourceType: String,
    val repository: String,
    val accessionId: String,
    val speciesTier: String,
    val assayOrPlatform: String,
    val tissueOrCellContext: String,
    val comparatorState: String,
    val matrixState: String,
    val evidenceStrength: String,
    val dataScarcityRole: String,
    val blockingGaps: List<String>,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMConnectedDotV250(
    val step: Int,
    val nodeType: String,
    val label: String,
    val supportLevel: String,
    val rationale: String
)

data class GTIMConfidenceIndexV250(
    val score: Int,
    val band: String,
    val formula: String,
    val drivers: List<String>,
    val penalties: List<String>
)

data class GTIMLabValidationPlanV250(
    val hypothesisId: String,
    val recommendedExperiments: List<String>,
    val positiveControl: String,
    val negativeControl: String,
    val expectedDirection: String,
    val falsificationCondition: String,
    val minimumEvidenceBeforeWetLab: List<String>
)

data class GTIMMechanismCandidateV250(
    val candidateId: String,
    val status: String,
    val targetAxis: String,
    val mechanismCascade: List<String>,
    val connectedDots: List<GTIMConnectedDotV250>,
    val corpusRelativeNoveltyStatement: String,
    val evidenceGrade: String,
    val confidenceIndex: GTIMConfidenceIndexV250,
    val contradictionNullResultSearch: List<String>,
    val labValidationPlan: GTIMLabValidationPlanV250,
    val whatWouldFalsify: List<String>,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMDiscoveryDossierReportV250(
    val active: Boolean,
    val engineIdentity: String,
    val missionStatement: String,
    val productMode: String,
    val noveltyBoundary: String,
    val evidenceObjects: List<GTIMEvidenceObjectV250>,
    val mechanismCandidates: List<GTIMMechanismCandidateV250>,
    val dataScarcityMitigation: List<String>,
    val globalUseCases: List<String>,
    val claimGuardrails: List<String>,
    val peerReviewDossierSections: List<String>,
    val routeIntegrity: GTIMRouteIntegrityReportV251 = GTIMRouteIntegrityReportV251(
        passed = false,
        status = "GTIM_ROUTE_NOT_EVALUATED",
        bridgePath = emptyList(),
        connectedSurfaces = emptyList(),
        requiredAnchors = emptyList(),
        brokenLinks = listOf("route integrity not evaluated"),
        weakLeadProtection = "not evaluated",
        playProtectPosture = "not evaluated",
        githubCiPosture = "not evaluated",
        nextRepairAction = "evaluate GTIM route integrity"
    ),
    val openDiscoveryDataFeed: GTIMOpenDiscoveryDataFeedReportV254 = GTIMOpenDiscoveryDataFeedReportV254.empty(),
    val releaseSurfaceHardening: GTIMReleaseSurfaceHardeningReportV252 = GTIMReleaseSurfaceHardeningReportV252(
        passed = false,
        status = "GTIM_RELEASE_SURFACE_NOT_EVALUATED",
        androidReleaseTrain = RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME,
        gtimProductEngineVersion = GTIMReleaseSurfaceHardeningV252.GTIM_PRODUCT_ENGINE_VERSION,
        verifiedSurfaces = emptyList(),
        blockingIssues = listOf("release surface not evaluated"),
        playProtectPosture = "not evaluated",
        githubPosture = "not evaluated",
        scientificClaimPosture = "not evaluated",
        nextAction = "evaluate GTIM release surface hardening"
    ),
    val conciseLines: List<String>,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty() = GTIMDiscoveryDossierReportV250(
            active = false,
            engineIdentity = GTIMClaimGuardV250.ENGINE_IDENTITY,
            missionStatement = GTIMClaimGuardV250.MISSION_STATEMENT,
            productMode = "SCIENTIFIC_HYPOTHESIS_FOUNDRY_IDLE",
            noveltyBoundary = GTIMClaimGuardV250.CORPUS_RELATIVE_NOVELTY_BOUNDARY,
            evidenceObjects = emptyList(),
            mechanismCandidates = emptyList(),
            dataScarcityMitigation = GTIMClaimGuardV250.DATA_SCARCITY_MITIGATION,
            globalUseCases = GTIMClaimGuardV250.GLOBAL_USE_CASES,
            claimGuardrails = GTIMClaimGuardV250.CLAIM_GUARDRAILS,
            peerReviewDossierSections = GTIMClaimGuardV250.PEER_REVIEW_DOSSIER_SECTIONS,
            openDiscoveryDataFeed = GTIMOpenDiscoveryDataFeedReportV254.empty(),
            conciseLines = listOf(
                GTIMClaimGuardV250.ENGINE_IDENTITY,
                "Mode: scientific hypothesis foundry, not clinical decision support.",
                "Status: no GTIM mechanism candidate created in this cycle."
            )
        )
    }
}
