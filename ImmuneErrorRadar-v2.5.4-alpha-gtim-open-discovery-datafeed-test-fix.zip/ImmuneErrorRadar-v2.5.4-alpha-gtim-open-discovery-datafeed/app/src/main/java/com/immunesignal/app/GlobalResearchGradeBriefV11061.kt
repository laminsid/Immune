package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.5.4: Global research-grade compact report with open discovery data-feed actions.
 *
 * The final brief must show what was learned, how to feed the engine next, and why the
 * result is still exploratory. Legacy audit tokens retained: Preliminary research lead; researchLeads=; graded research leads are allowed. Raw JSON, command traces, and parser internals stay in
 * the advanced technical export.
 */
object GlobalResearchGradeBriefV11061 {
    private const val CLAIM_BOUNDARY = "biomedical_research_data_engineering_only_not_clinical_claim"

    fun render(report: JSONObject): String = renderLines(report).joinToString("\n")

    fun renderLines(report: JSONObject): List<String> {
        val runtime = report.optJSONObject("runtime") ?: JSONObject()
        val execution = report.optJSONObject("executionLock") ?: JSONObject()
        val score = report.optJSONObject("score") ?: JSONObject()
        val readiness = report.optJSONObject("readiness") ?: JSONObject()
        val v3 = report.optJSONObject("v3Report") ?: JSONObject()
        val matrix = report.optJSONObject("metadataClosureStrategyMatrix") ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossier") ?: JSONObject()
        val accession = report.optJSONObject("accession") ?: JSONObject()
        val queries = report.optJSONArray("queries") ?: JSONArray()
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        val explicitAccessions = jsonArray(accession.optJSONArray("explicitAccessions"))
        val missingFields = jsonArray((report.optJSONObject("metadataClosure") ?: JSONObject()).optJSONArray("missingFields"))
        val mechanismGaps = jsonArray(mechanism.optJSONArray("blockingGaps"))
        val exploratoryLeads = mechanism.optJSONArray("exploratoryResearchLeads") ?: JSONArray()
        val accessionCards = jsonArray(mechanism.optJSONArray("accessionCandidates"))
        val mechanismRoutes = jsonArray(mechanism.optJSONArray("mechanismRoutes"))
        val gtim = mechanism.optJSONObject("globalTranslationalDossier") ?: JSONObject()
        val gtimCandidates = gtim.optJSONArray("mechanismCandidates") ?: JSONArray()
        val dataFeed = gtim.optJSONObject("openDiscoveryDataFeed") ?: JSONObject()
        val dataChannels = dataFeed.optJSONArray("dataFeedingChannels") ?: JSONArray()
        val dataActions = jsonArray(dataFeed.optJSONArray("immediateActions"))
        val topTargets = jsonArray(matrix.optJSONArray("detectedTargets")).take(6)
        val hardGates = jsonArray(matrix.optJSONArray("hardClaimGates"))
        val gtimConcise = jsonArray(gtim.optJSONArray("conciseLines"))
        val topCandidate = gtimCandidates.optJSONObject(0) ?: JSONObject()
        val confidence = topCandidate.optJSONObject("confidenceIndex") ?: JSONObject()
        val labPlan = (topCandidate.optJSONObject("labValidationPlan") ?: JSONObject()).optJSONArray("recommendedExperiments") ?: JSONArray()

        val title = "Global Research-Grade Discovery Brief"
        val evidenceGrade = firstNonBlank(mechanism.optString("evidenceGrade"), evidenceGrade(evidenceObjects.length(), explicitAccessions.size, score.optInt("routeFitScore", 0), score.optBoolean("hypothesisUpgradeAllowed", false)))
        val selectedRoute = firstNonBlank(
            report.optJSONObject("topicFit")?.optString("preferredLane") ?: "",
            accession.optString("state"),
            report.optJSONObject("forager")?.optString("state") ?: "",
            "dataset-hunt"
        ).replace('_', ' ')
        val primaryLead = firstNonBlank(
            mechanism.optString("bestResearchLeadSummary"),
            topCandidate.optString("targetAxis"),
            v3.optString("newUsefulLead"),
            v3.optString("supportingEvidence"),
            "Exploratory lead captured, but no repository-backed evidence object yet."
        )
        val blockers = (mechanismGaps + missingFields).distinct().take(5).joinToString(", ").ifBlank { "accession/comparator/matrix closure still needed" }
        val topQuery = (0 until dataChannels.length()).mapNotNull { dataChannels.optJSONObject(it)?.optString("querySeed")?.takeIf { q -> q.isNotBlank() } }.firstOrNull()
        val topDataAction = dataActions.firstOrNull() ?: dataChannels.optJSONObject(0)?.optString("nextAction") ?: firstNonBlank(mechanism.optString("nextDecisiveAction"), "Feed one PMID/DOI/GSE/PRJNA/SRP/SRR/E-MTAB/SDY/PDF/snippet seed.")
        val doNotBelieve = firstNonBlank(v3.optString("whatWeDoNotBelieveYet"), v3.optString("doNotBelieveYet"), "No biological claim is proven.")

        val lines = mutableListOf<String>()
        lines += title
        lines += "Engine: ${runtime.optString("engineVersion", "unknown")} | Lock: ${execution.optString("status", "UNKNOWN")} | State: ${runtime.optString("researchState", "UNKNOWN")}"
        lines += "Decision: Exploratory lead kept alive — no biological upgrade yet, but the engine should now be fed with stronger data."
        lines += "What the app learned: ${truncate(primaryLead, 210)}"
        lines += "Evidence grade: $evidenceGrade | mode=${mechanism.optString("researchResultMode", "GRADED_EXPLORATORY_RESULTS")} | researchLeads=${exploratoryLeads.length()} | candidates=${gtimCandidates.length()} | data-feed=${dataFeed.optString("status", "GTIM_OPEN_DISCOVERY_DATAFEED_NOT_VISIBLE")}"
        lines += "Scores: usability ${score.optInt("datasetUsabilityScore", 0)}/100 | route-fit ${score.optInt("routeFitScore", 0)}/100 | hypothesis ${score.optInt("hypothesisConfidenceScore", 0)}/100 | S_c=${confidence.optInt("score", 0)}/100 ${confidence.optString("band", "WEAK_OR_EXPLORATORY")}" 
        lines += "Route: ${truncate(selectedRoute, 130)}"
        if (topTargets.isNotEmpty()) lines += "Target intersection: ${topTargets.joinToString(", ")}"
        lines += "Why it is still weak: accession=${firstNonBlank(mechanism.optString("accessionValidationGate"), "UNRESOLVED")} | matrix=${firstNonBlank(mechanism.optString("matrixAnalysisGate"), "DGE_NOT_READY")} | blockers=$blockers"
        lines += "Data feed needed now: ${truncate(topDataAction, 220)}"
        if (!topQuery.isNullOrBlank()) lines += "Best next search/query seed: ${truncate(topQuery, 220)}"
        if (explicitAccessions.isNotEmpty()) {
            lines += "Accession IDs: ${explicitAccessions.take(8).joinToString(", ")}" 
        } else {
            lines += "Accession IDs: none confirmed yet; keep extracting handles, but do not fabricate IDs."
        }
        if (gtim.optBoolean("active", false)) {
            val routeIntegrity = gtim.optJSONObject("routeIntegrity") ?: JSONObject()
            val releaseHardening = gtim.optJSONObject("releaseSurfaceHardening") ?: JSONObject()
            lines += "GTIM dossier: ${truncate(gtim.optString("productMode", "SCIENTIFIC_HYPOTHESIS_FOUNDRY_IDLE"), 120)} | GTIM route integrity: ${routeIntegrity.optString("status", "GTIM_ROUTE_NOT_EVALUATED")} | GTIM release surface: ${releaseHardening.optString("status", "GTIM_RELEASE_SURFACE_NOT_EVALUATED")} | gtimProductEngineVersion=${releaseHardening.optString("gtimProductEngineVersion", "2.5.4")}"
            if (gtimConcise.isNotEmpty()) lines += "GTIM thesis: ${truncate(gtimConcise.first(), 170)}"
        }
        if (mechanismRoutes.isNotEmpty()) lines += "Mechanism route: ${truncate(mechanismRoutes.first(), 170)}"
        lines += "Contradiction status: ${truncate(firstNonBlank(v3.optString("counterEvidenceOrContradiction"), "Contradiction/null-result search should run, but must not suppress weak-lead display."), 180)}"
        lines += "Lab validation idea: ${truncate(jsonArray(labPlan).firstOrNull() ?: "not ready; first close accession/comparator/matrix gates", 170)}"
        lines += "Blocking gap: $blockers"
        lines += "Next discriminating action: ${truncate(topDataAction, 220)}"
        lines += "Do not believe yet: ${truncate(doNotBelieve, 190)}"
        if (hardGates.isNotEmpty()) lines += "Hard gates before upgrade: ${hardGates.take(6).joinToString(", ")}" 
        lines += "Search footprint: queries=${queries.length()} | readiness=${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")} | data channels=${dataChannels.length()}"
        lines += "Boundary: $CLAIM_BOUNDARY; graded research leads are allowed and open discovery leads are allowed, GTIM mechanism candidates are allowed, but no diagnosis, treatment, dose, supplement, causal claim, DGE/fold-change/p-value, or patient prediction."
        lines += "Appendix policy: raw JSON, command trace, parser cards, and source metadata stay in Advanced/technical export, not the final brief."
        return lines.take(RuntimeFeatureFlags.GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061.coerceAtLeast(20))
    }

    private fun evidenceGrade(evidenceObjects: Int, accessions: Int, routeFit: Int, upgradeAllowed: Boolean): String = when {
        upgradeAllowed && evidenceObjects > 0 && accessions > 0 -> "B — evidence object ready for controlled review"
        evidenceObjects > 0 && accessions > 0 -> "C+ — evidence object present, claims still gated"
        accessions > 0 -> "C — accession found, metadata closure required"
        routeFit >= 70 -> "D+ — high-priority route, no confirmed accession yet"
        routeFit >= 25 -> "D — useful weak lead; feed more data"
        else -> "E+ — early exploratory signal; keep if route is scientifically interesting"
    }

    private fun jsonArray(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { idx ->
            val value = array.opt(idx) ?: return@mapNotNull null
            when (value) {
                is JSONObject -> firstNonBlank(
                    value.optString("accessionId"),
                    value.optString("leadId"),
                    value.optString("targetAxis"),
                    value.optString("routeId"),
                    value.optString("targetMolecularAxis"),
                    value.optString("streamId"),
                    value.optString("querySeed"),
                    value.optString("query"),
                    value.optString("label"),
                    value.optString("gateId"),
                    value.optString("nextAction"),
                    value.toString()
                )
                else -> value.toString()
            }.takeIf { it.isNotBlank() }
        }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""

    private fun truncate(value: String, max: Int): String {
        val oneLine = value.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1).trimEnd() + "…"
    }
}
