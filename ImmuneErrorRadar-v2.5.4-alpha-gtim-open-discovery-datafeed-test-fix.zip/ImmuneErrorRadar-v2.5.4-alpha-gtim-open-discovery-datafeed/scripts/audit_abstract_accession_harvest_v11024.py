#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
checks = {
    'app/build.gradle.kts': ['versionCode = 86', 'versionName = "1.10.24-alpha-abstract-accession-harvest"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.24-alpha-abstract-accession-harvest', 'AccessionTextHarvestPolicy'],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': ['evidenceTextDigest', 'schemaVersion", 216'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['AccessionTextHarvestPolicy.digest', 'AccessionTextHarvestPolicy.flags', 'v1.10.24 abstract accession harvest'],
    'app/src/main/java/com/immunesignal/app/DatasetAccessionResolver.kt': ['finding.evidenceTextDigest'],
    'app/src/main/java/com/immunesignal/app/AccessionTextHarvestPolicy.kt': ['abstract_accession_harvest_not_biological_proof', 'DATA_AVAILABILITY_TEXT_SIGNAL', 'ACCESSION_TEXT_SIGNAL'],
    'app/src/test/java/com/immunesignal/app/AccessionTextHarvestV11024Test.kt': ['resolverReadsEvidenceTextDigestForExplicitAccession', 'GSE654321'],
    'docs/ABSTRACT_ACCESSION_HARVEST_v1.10.24.md': ['Abstract Accession Text Harvest', 'not biological proof'],
}
missing=[]
for rel, needles in checks.items():
    path=ROOT / rel
    if not path.exists():
        missing.append(f'{rel}: missing file')
        continue
    text=path.read_text()
    for needle in needles:
        if needle not in text:
            missing.append(f'{rel}: missing {needle!r}')
if missing:
    raise SystemExit('v1.10.24 abstract accession harvest audit failed:\n' + '\n'.join(missing))
print('v1.10.24 abstract accession harvest audit: PASS')
