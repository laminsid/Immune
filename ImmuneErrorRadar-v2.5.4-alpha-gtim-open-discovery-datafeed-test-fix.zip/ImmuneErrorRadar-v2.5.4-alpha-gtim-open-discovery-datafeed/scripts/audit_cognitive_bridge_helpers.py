#!/usr/bin/env python3
import pathlib, re
path = pathlib.Path("app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt")
text = path.read_text(errors="replace")
defs = set(re.findall(r"private\s+fun\s+((?:build|extract)V\d+[A-Za-z0-9_]+)\s*\(", text))
calls = set(re.findall(r"(?<!fun\s)((?:build|extract)V\d+[A-Za-z0-9_]+)\s*\(", text))
missing = sorted(calls - defs)
if missing:
    raise SystemExit("Undefined CognitiveNextCycleBridge helper(s): " + ", ".join(missing))
print("CognitiveNextCycleBridge helper audit: PASS")
