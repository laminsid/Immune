#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]

def require(path, token, reason):
    text = (root / path).read_text(encoding='utf-8')
    if token not in text:
        raise SystemExit(f"Missing autonomous planner restore guard: {path} -> {reason}")

planner = root / 'app/src/main/java/com/immunesignal/app/AutonomousResearcher.kt'
if not planner.exists():
    raise SystemExit('Missing AutonomousResearcher.kt: compile-critical planner types were removed')

require('app/src/main/java/com/immunesignal/app/AutonomousResearcher.kt', 'data class AutonomousResearchPlan', 'AutonomousResearchPlan type')
require('app/src/main/java/com/immunesignal/app/AutonomousResearcher.kt', 'data class AutonomousResearchLane', 'AutonomousResearchLane type')
require('app/src/main/java/com/immunesignal/app/AutonomousResearcher.kt', 'class AutonomousResearchPlanner', 'AutonomousResearchPlanner class')
require('app/src/main/java/com/immunesignal/app/QueryPlanner.kt', 'AutonomousResearchPlanner().queries(plan)', 'QueryPlanner autonomous lane wiring')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'AutonomousResearchPlanner().plan', 'ResearchAutopilot plan wiring')
require('app/src/main/java/com/immunesignal/app/ResearchModels.kt', 'autonomousPlanToJson', 'ResearchModels JSON serialization for autonomous plan')
print('autonomous planner restore v1.10.7 compile guard: PASS')
