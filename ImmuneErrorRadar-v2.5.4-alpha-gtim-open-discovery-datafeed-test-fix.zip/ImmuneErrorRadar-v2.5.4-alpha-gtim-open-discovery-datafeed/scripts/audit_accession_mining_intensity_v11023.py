from pathlib import Path
ROOT = Path('.')
checks = {
    'app/build.gradle.kts': ['versionCode = 86', 'versionName = "1.10.24-alpha-abstract-accession-harvest"'],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': ['schemaVersion", 216'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': ['ENABLE_ACCESSION_MINING_INTENSITY', 'PUBMED_ACCESSION_MINING_RETMAX', 'PUBMED_ACCESSION_MINING_ABSTRACTS_PER_CYCLE'],
    'app/src/main/java/com/immunesignal/app/AccessionMiningIntensityPolicy.kt': ['AccessionMiningIntensityPolicy', 'accession_mining_intensity_not_biological_proof', 'PUBMED_ACCESSION_MINING'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['AccessionMiningIntensityPolicy.planForSourceFamily', 'maxAbstractsPerCycle = intensityPlan.abstractBudget', 'v1.10.23 accession mining intensity'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.24-alpha-abstract-accession-harvest', 'AccessionMiningIntensityPolicy'],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': ['AccessionMiningIntensityPolicy'],
    'app/src/test/java/com/immunesignal/app/AccessionMiningIntensityV11023Test.kt': ['PUBMED_ACCESSION_MINING', 'assertTrue(plan.retMax >= 25)'],
    'docs/ACCESSION_MINING_INTENSITY_v1.10.23.md': ['Accession Mining Intensity', 'no biological proof'],
}
missing=[]
for rel, tokens in checks.items():
    p=ROOT/rel
    if not p.exists():
        missing.append(f'{rel}: missing file')
        continue
    text=p.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            missing.append(f'{rel}: missing token {token!r}')
if missing:
    raise SystemExit('v1.10.23 accession mining intensity audit failed:\n' + '\n'.join(missing))
print('v1.10.23 accession mining intensity audit: PASS')
