#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
required = {
    'app/src/main/java/com/immunesignal/app/DatasetForagingPathLinkageGuard.kt': [
        'v1.10.28',
        'coreQueryPathCount',
        'adjacentQueryPathCount',
        'matureProbeQueryPathCount',
        'PASS_COVERAGE_CONNECTED',
        'PASS_COVERAGE_GAP',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'coreQueryPathCount',
        'adjacentQueryPathCount',
        'matureProbeQueryPathCount',
        'coverageState',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'coreAccessionSourceSetV11028',
        'PASS3_ADJACENT_CONTRADICTION_CONTROL_CHECK',
        'v1.10.28 pass coverage linkage',
        'Dataset Pass Coverage Linkage',
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'pass coverage',
        'coverageState',
        'coreQueryPathCount',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'pass coverage',
        'coverageState',
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.10.29-alpha-learning-domain-path-linkage',
        'DatasetPassCoverageLinkageGuard',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'ENABLE_DATASET_PASS_COVERAGE_LINKAGE',
        '1.10.29',
    ],
    'app/build.gradle.kts': [
        'versionCode = 91',
        'versionName = "1.10.29-alpha-learning-domain-path-linkage"',
    ],
    'app/src/test/java/com/immunesignal/app/DatasetPassCoverageLinkageV11028Test.kt': [
        'DatasetPassCoverageLinkageV11028Test',
        'PASS_COVERAGE_CONNECTED',
        'PASS_COVERAGE_GAP',
    ],
    'docs/DATASET_PASS_COVERAGE_LINKAGE_v1.10.28.md': [
        'v1.10.28',
        'Dataset Pass Coverage Linkage',
        'dataset_path_linkage_not_biological_proof',
    ],
}
for rel, tokens in required.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.28 file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.28 token: {token}')
print('v1.10.28 dataset pass coverage linkage audit: PASS')
