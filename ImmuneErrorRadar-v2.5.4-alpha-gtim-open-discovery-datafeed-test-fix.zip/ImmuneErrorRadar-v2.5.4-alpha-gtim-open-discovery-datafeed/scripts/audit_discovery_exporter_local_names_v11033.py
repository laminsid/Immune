#!/usr/bin/env python3
"""Guard against same-scope local val/var redeclarations in DiscoveryReportExporter.export.

This caught the GitHub Kotlin failure where two root-scope locals were both named
`gaps` with different JSON types. The guard is intentionally narrow: it protects
the long PDF exporter function without policing legitimate shadowing elsewhere.
"""
from pathlib import Path
import re

path = Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt')
text = path.read_text(encoding='utf-8')
marker = 'fun export(context: Context, report: JSONObject): File'
start = text.find(marker)
if start < 0:
    raise SystemExit('DiscoveryReportExporter.export not found')
brace_start = text.find('{', start)
if brace_start < 0:
    raise SystemExit('DiscoveryReportExporter.export body not found')

scope_stack = [dict()]
line = text.count('\n', 0, brace_start) + 1
idx = brace_start + 1
string_quote = None
triple_string = False
line_comment = False
block_comment = False

ident = re.compile(r'[A-Za-z_]\w*')

def fail(name, first_line, second_line):
    raise SystemExit(
        f'same-scope local declaration conflict in DiscoveryReportExporter.export: '
        f'{name!r} first at line {first_line}, repeated at line {second_line}'
    )

while idx < len(text):
    ch = text[idx]
    nxt = text[idx:idx+2]
    tri = text[idx:idx+3]

    if ch == '\n':
        line += 1
        line_comment = False
        idx += 1
        continue
    if line_comment:
        idx += 1
        continue
    if block_comment:
        if nxt == '*/':
            block_comment = False
            idx += 2
        else:
            idx += 1
        continue
    if string_quote:
        if triple_string:
            if tri == '"""':
                string_quote = None
                triple_string = False
                idx += 3
            else:
                idx += 1
            continue
        if ch == '\\':
            idx += 2
            continue
        if ch == string_quote:
            string_quote = None
        idx += 1
        continue

    if nxt == '//':
        line_comment = True
        idx += 2
        continue
    if nxt == '/*':
        block_comment = True
        idx += 2
        continue
    if tri == '"""':
        string_quote = '"'
        triple_string = True
        idx += 3
        continue
    if ch in ('"', "'"):
        string_quote = ch
        idx += 1
        continue
    if ch == '{':
        scope_stack.append({})
        idx += 1
        continue
    if ch == '}':
        if len(scope_stack) == 1:
            break
        scope_stack.pop()
        idx += 1
        continue

    if text.startswith('val ', idx) or text.startswith('var ', idx):
        kind_len = 3
        j = idx + kind_len
        while j < len(text) and text[j].isspace():
            if text[j] == '\n':
                line += 1
            j += 1
        m = ident.match(text, j)
        if m:
            name = m.group(0)
            scope = scope_stack[-1]
            if name in scope:
                fail(name, scope[name], line)
            scope[name] = line
            idx = m.end()
            continue
    idx += 1

print('DiscoveryReportExporter local declaration guard: PASS')
