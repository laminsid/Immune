from pathlib import Path

checks = {
    'app/build.gradle.kts': ['versionCode = 86', 'versionName = "1.10.24-alpha-abstract-accession-harvest"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': ['MIN_CORE_ACCESSION_SOURCE_FAMILIES_BEFORE_ARCHIVE', 'ENABLE_ACCESSION_EXHAUSTION_GATE', 'ENABLE_DOMAIN_QUERY_ACTIVATION', '1.10.22'],
    'app/src/main/java/com/immunesignal/app/ExtendedAcquisitionSweepPolicy.kt': ['coreAccessionFamilies', 'missingCoreFamilies', 'PUBMED_ACCESSION_MINING'],
    'app/src/main/java/com/immunesignal/app/AccessionAcquisitionHardening.kt': ['v1.10.22 accession exhaustion gate', 'missingCoreFamilies', 'NO_ACCESSION_CONTINUE_SOURCE_SWEEP'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['MIN_CORE_ACCESSION_SOURCE_FAMILIES_BEFORE_ARCHIVE', 'bootstrapQueryVocabularyForExploration', 'v1.10.22 Accession Exhaustion Gate'],
    'app/src/main/java/com/immunesignal/app/DomainExpertiseMemoryPolicy.kt': ['bootstrapQueryVocabularyForExploration', 'Domain exposure count', 'v1.10.22 continuity'],
    'app/src/main/java/com/immunesignal/app/DatasetQueryCompiler.kt': ['allowDomainBoost', 'v1.10.22 domain query activation'],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': ['v1.10.22', 'domain expertise activation'],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': ['schemaVersion", 216'],
}
missing=[]
for path,tokens in checks.items():
    text=Path(path).read_text()
    for token in tokens:
        if token not in text:
            missing.append(f'{path}: {token}')
if missing:
    raise SystemExit('v1.10.22 accession exhaustion/domain activation audit failed:\n' + '\n'.join(missing))
print('v1.10.22 accession exhaustion/domain activation audit: PASS')
