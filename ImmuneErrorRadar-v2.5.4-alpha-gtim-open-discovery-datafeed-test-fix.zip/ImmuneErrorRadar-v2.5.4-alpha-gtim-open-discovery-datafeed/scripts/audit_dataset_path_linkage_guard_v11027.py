#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
required = {
    'app/src/main/java/com/immunesignal/app/DatasetForagingPathLinkageGuard.kt': [
        'DatasetForagingPathLinkageGuard',
        'DatasetForagingPathLinkageReport',
        'dataset_path_linkage_not_biological_proof',
        'coreSourcesAttempted',
        'matureProbeAttempted',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': [
        'pathLinkageReport',
        'DatasetForagingPathLinkageReport.empty()',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'pathLinkageReport',
        'pathLinkageToJson',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'PASS4_MATURE_DOMAIN_EVIDENCE_PROBE',
        'DatasetForagingPathLinkageGuard.evaluate',
        'finalForagerState',
        'finalForagerNextAction',
        'v1.10.27 path linkage guard',
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'pathLinkageReport',
        'pathLinkageReport',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'pathLinkageReport',
        'Path linkage',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'DatasetForagingPathLinkageGuard',
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.10.27-alpha-dataset-path-linkage-guard',
        'DatasetForagingPathLinkageGuard',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'ENABLE_DATASET_PATH_LINKAGE_GUARD',
        '1.10.27',
    ],
    'app/build.gradle.kts': [
        'versionCode = 89',
        'versionName = "1.10.27-alpha-dataset-path-linkage-guard"',
    ],
    'docs/DATASET_PATH_LINKAGE_GUARD_v1.10.27.md': [
        'v1.10.27',
        'Dataset Path Linkage Guard',
        'dataset_path_linkage_not_biological_proof',
    ],
    'app/src/test/java/com/immunesignal/app/DatasetPathLinkageGuardV11027Test.kt': [
        'DatasetPathLinkageGuardV11027Test',
        'CONNECTED_MATURE_DOMAIN_PROBE',
    ],
}
for rel, tokens in required.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.27 file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.27 token: {token}')
print('v1.10.27 dataset path linkage guard audit: PASS')
