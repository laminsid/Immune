#!/usr/bin/env python3
from pathlib import Path

WORKFLOW = Path(".github/workflows/android-debug.yml")
if not WORKFLOW.exists():
    raise SystemExit("GitHub workflow missing: .github/workflows/android-debug.yml")

text = WORKFLOW.read_text(errors="replace")

# Specific anti-patterns that broke GitHub under set -euo pipefail.
anti_patterns = [
    r"find . -maxdepth 5 -type f \( -name 'settings.gradle' -o -name 'settings.gradle.kts' \) | grep -q .",
    r"find . -path './.git' -prune -o -type f \( -name 'settings.gradle' -o -name 'settings.gradle.kts' \) -print | head -n 1",
    r"find .ci_project -maxdepth 4 -type f | sort | head",
    r"find .ci_project -maxdepth 4 -type f | sort -V | head",
]
for pattern in anti_patterns:
    if pattern in text:
        raise SystemExit(f"Unsafe pipefail workflow pattern found: {pattern}")

required = [
    'SETTINGS_PRECHECK="$(mktemp)"',
    'ZIP_CANDIDATES="$(mktemp)"',
    'sort -V "$ZIP_CANDIDATES" -o "$ZIP_CANDIDATES"',
    'SETTINGS_CANDIDATES="$(mktemp)"',
    "sed -n '1p' \"$SETTINGS_CANDIDATES\"",
]
missing = [token for token in required if token not in text]
if missing:
    raise SystemExit("Workflow pipefail safety token(s) missing: " + ", ".join(missing))

print("GitHub workflow pipefail safety audit: PASS")
