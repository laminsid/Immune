#!/usr/bin/env python3
from pathlib import Path

root = Path(__file__).resolve().parents[1]

def read(rel):
    return (root / rel).read_text(encoding='utf-8')

required_files = [
    'app/src/main/java/com/immunesignal/app/DataAvailabilityAccessionQueryPolicy.kt',
    'app/src/test/java/com/immunesignal/app/DataAvailabilityAccessionQueryV11025Test.kt',
    'docs/DATA_AVAILABILITY_QUERY_PRIORITY_v1.10.25.md',
]
for rel in required_files:
    if not (root / rel).exists():
        raise SystemExit(f'missing v1.10.25 file: {rel}')

policy = read('app/src/main/java/com/immunesignal/app/DataAvailabilityAccessionQueryPolicy.kt')
for token in [
    'data_availability_query_priority_not_biological_proof',
    'data availability',
    'deposited',
    'GSE',
    'PRJNA',
    'E-MTAB',
    'MAX_DATA_AVAILABILITY_DOMAIN_TERMS',
]:
    if token not in policy:
        raise SystemExit(f'v1.10.25 policy missing token: {token}')

compiler = read('app/src/main/java/com/immunesignal/app/DatasetQueryCompiler.kt')
for token in [
    'DataAvailabilityAccessionQueryPolicy.shouldUseForSourceFamily(route.sourceFamily)',
    'DataAvailabilityAccessionQueryPolicy.queries(domainVocabulary)',
    'DataAvailabilityAccessionQueryPolicy.reason(domainVocabulary)',
]:
    if token not in compiler:
        raise SystemExit(f'DatasetQueryCompiler missing v1.10.25 wiring token: {token}')

flags = read('app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt')
for token in [
    'ENABLE_DATA_AVAILABILITY_ACCESSION_QUERY_PRIORITY',
    'MAX_DATA_AVAILABILITY_DOMAIN_TERMS',
    'MAX_DATA_AVAILABILITY_LABEL_TERMS',
]:
    if token not in flags:
        raise SystemExit(f'RuntimeFeatureFlags missing v1.10.25 token: {token}')
if not any(v in flags for v in ['1.10.25', '1.10.26', '1.10.27']):
    raise SystemExit('RuntimeFeatureFlags missing accepted v1.10.25/v1.10.26/v1.10.27 schema token')

engine = read('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt')
if 'DataAvailabilityAccessionQueryPolicy' not in engine:
    raise SystemExit('EngineRuntimeStatus missing token: DataAvailabilityAccessionQueryPolicy')
if not any(v in engine for v in ['v1.10.25-alpha-data-availability-query-priority', 'v1.10.26-alpha-mature-domain-evidence-probe', 'v1.10.27-alpha-dataset-path-linkage-guard']):
    raise SystemExit('EngineRuntimeStatus missing accepted v1.10.25/v1.10.26/v1.10.27 engine version')

modules = read('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt')
if 'DataAvailabilityAccessionQueryPolicy' not in modules:
    raise SystemExit('RuntimeModuleRegistry missing DataAvailabilityAccessionQueryPolicy')

build = read('app/build.gradle.kts')
if not any(v in build for v in ['1.10.25-alpha-data-availability-query-priority', '1.10.26-alpha-mature-domain-evidence-probe', '1.10.27-alpha-dataset-path-linkage-guard']):
    raise SystemExit('build.gradle.kts version not updated for v1.10.25/v1.10.26/v1.10.27')
if not any(c in build for c in ['versionCode = 87', 'versionCode = 88', 'versionCode = 89']):
    raise SystemExit('build.gradle.kts versionCode not accepted for v1.10.25/v1.10.26/v1.10.27')

print('v1.10.25 data-availability accession query priority audit: PASS')
