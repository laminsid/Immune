#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
missing = []

def require(path, token, label):
    text = (ROOT / path).read_text(encoding='utf-8')
    if token not in text:
        missing.append(f'{path}: missing {label}: {token}')

checks = {
    'app/src/main/java/com/immunesignal/app/DomainExpertiseMemoryPolicy.kt': [
        'priorExposureCount',
        'continuityAction',
        'carriedForwardDomainCount',
        'matureDomainCount',
        'continuityState',
        'extractPriorExposure',
        'MATURE_DOMAIN_PRIOR_NEEDS_FALSIFICATION',
        'v1.10.22 continuity'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'carriedForwardDomainCount',
        'matureDomainCount',
        'priorExposureCount',
        'continuityAction'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'recentReports = recentReports',
        'v1.10.22 domain expertise continuity'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Domain expertise activation v1.10.22',
        'Prior exposure'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Expertise continuity',
        'priorExposureCount'
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'MIN_DOMAIN_EXPERTISE_MATURITY_EXPOSURES',
        '1.10.22'
    ],
    'app/build.gradle.kts': [
        'versionCode = 86',
        'versionName = "1.10.24-alpha-abstract-accession-harvest"'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'schemaVersion", 216'
    ],
    'app/src/test/java/com/immunesignal/app/DomainExpertiseContinuityV11020Test.kt': [
        'MATURE_DOMAIN_EXPERTISE_ACTIVE',
        'priorExposureCount'
    ],
    'docs/DOMAIN_EXPERTISE_CONTINUITY_v1.10.20.md': [
        'Domain Expertise Continuity v1.10.20',
        'research prior',
        'not biological proof'
    ]
}
for path, tokens in checks.items():
    for token in tokens:
        require(path, token, token)

if missing:
    raise SystemExit('v1.10.22 domain expertise continuity audit failed:\n' + '\n'.join(missing))
print('v1.10.22 domain expertise continuity audit: PASS')
