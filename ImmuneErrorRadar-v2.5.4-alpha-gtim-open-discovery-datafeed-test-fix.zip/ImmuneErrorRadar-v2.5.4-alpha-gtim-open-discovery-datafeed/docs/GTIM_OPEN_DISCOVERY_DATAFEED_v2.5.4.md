# GTIM v2.5.4 Open Discovery DataFeed

Version: `2.5.4-alpha-gtim-open-discovery-datafeed`
Schema: `2.5.4`

## Why
The v2.5.3 report showed the engine could keep weak leads alive, but it still behaved like a blocker-first system: unresolved accession, no matrix, no comparator, and raw command traces dominated the final brief. v2.5.4 makes the engine data-hungry instead of silent.

## What was relaxed
- Minimum route-fit for exploratory display lowered from 35 to 15.
- Weak/manual/source-metadata leads remain visible instead of being buried behind gates.
- More exploratory leads, evidence objects, and mechanism candidates are surfaced.
- Off-route leads can be shown as contrast/re-route material.
- Final brief now prioritizes: what was learned, why it is weak, what data to feed next, and what would upgrade it.

## Data-feed channels
- Manual seed intake: PMID, DOI, GSE, PRJNA, SRP/SRR, E-MTAB, SDY, PDF, snippet.
- GEO/GDS direct repository search.
- SRA/BioProject search.
- ArrayExpress/BioStudies search.
- ImmPort/SDY search.
- PubMed/PMC data-availability mining.
- Comparator label hunt.
- Matrix-file hint hunt.
- Null/contradiction queue.

## What remains locked
- No diagnosis.
- No treatment recommendation.
- No patient prediction.
- No DGE/fold-change/p-value without accession + comparator + matrix readiness.
- No confirmed mechanism from weak, text-mined, cross-species, or off-route evidence.

## Google Play / GitHub posture
The patch does not add sensitive permissions. INTERNET remains user-started research discovery only. No background telemetry, no hidden scraping, no patient clinical decision support.
