# Project Internal Sheet — Immune Error Radar v1.2

## Identity

Private Android research autopilot for immune-causal hypothesis mining.

## What changed in v1.2

v1.2 does not add a new biology module. It adds discipline:

- Hypothesis Object
- Hypothesis Impact Test
- Minimum Data Pack Gate
- Research State Engine
- Learning Delta Engine
- Research Mistake Library
- Falsification Builder
- Report Template V2

## Operating principle

Data is not learning unless it changes a hypothesis rank, state, gate, next evidence, or bias warning.

## Current modules

- Research Autopilot
- Evidence Quality / Source Classification
- Causality Scoring
- Negative Controls
- Personal Pattern Ledger
- Research Steering
- Omics / Gut / Hormone axes
- Research Lock System

## Do not add next

Do not add more biology axes until v1.2 lock outputs prove useful in repeated runs.

## Next best technical work

1. Persist Hypothesis Objects into a dedicated JSONL ledger.
2. Add UI filter by Discovery State and Bias Risk State.
3. Add a small graph view for Hypothesis Object history.
4. Add unit tests for MinimumDataPackGate and ResearchStateEngine.


## v1.2.1 hotfix

The v1.2 lock-system philosophy remains unchanged. This patch fixes silent scoring and delta bugs:

- Negative-control statuses now map to explicit evidence points.
- Empty finding cycles no longer create metadata-heavy bias alerts.
- Delta detection compares against the newest prior report per hypothesis.
- Minimum data pack matching now requires exact alternatives or multi-token evidence; loose substring matching is forbidden.
- UI/PDF evidence scores are rounded to one decimal.
- CI now runs unit tests before debug APK assembly.

Current rule: no further biology axes until lock-system regression tests remain stable over repeated changes.
