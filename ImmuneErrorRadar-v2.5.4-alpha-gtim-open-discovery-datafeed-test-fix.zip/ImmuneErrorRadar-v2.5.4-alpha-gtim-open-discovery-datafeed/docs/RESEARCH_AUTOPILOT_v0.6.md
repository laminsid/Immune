# Research Autopilot v0.6

## What changed

- Adds DNA/RNA/omics search families.
- Skips previously saved PubMed IDs to prefer new sources.
- Adds imported report intake: pasted text or text/csv/json file.
- Adds Stop button; search closes after current request or timeout.
- Enforces search cap: 10 minutes.
- Enforces learning cap: 15 minutes.
- Adds short report renderer and copy-to-clipboard action.
- Adds local cumulative knowledge delta: new sources, repeated skipped, axis pairs, DNA/RNA signals.

## Learning model

This is cumulative evidence mapping, not autonomous medical intelligence. The app learns by:

1. Storing seen source IDs.
2. Extracting axes from new papers and imported reports.
3. Detecting new axis pairs.
4. Ranking novelty.
5. Producing next research questions.

## Stop behavior

When Stop is pressed, the running flag is set. The current HTTP request may finish or timeout; then the cycle closes and writes a partial report.
