# Modern Medical Technology Intelligence v1.10.43

Version: `1.10.43-alpha-modern-medtech-modular-index`  
VersionCode: `105`

## Purpose

This layer extends the biomedical research ontology and concept bridge with a modular intelligence layer for modern medical and laboratory technologies.

It supports scientist/lab-facing research routing for:

- RNA / single-cell / spatial transcriptomics
- nanomedicine, LNP, exosome, and delivery-platform vocabulary
- multi-omics, proteomics, metabolomics, epigenomics
- advanced lab assays such as flow cytometry, CyTOF, ELISA, multiplex cytokine, qPCR, digital PCR
- accession repositories such as GEO/GSE, SRA/PRJNA/SRP/SRR, ArrayExpress/E-MTAB, ImmPort/SDY, dbGaP, ENA, PRIDE, MetaboLights
- computational medicine and biomarker-discovery vocabulary

## Modular retrieval rule

The system must not inject the whole biomedical knowledge base into every query. It selects only a few modules by topic, lead, bridge context, missing metadata fields, and evidence-prior routing.

Required order:

1. accession / repository / source ID
2. platform / assay / modality
3. sample and tissue/cell metadata
4. condition labels
5. outcome labels
6. control/comparator
7. time order or longitudinal signal
8. contradiction / negative-control review

## Boundaries

The layer cannot produce:

- patient diagnosis
- treatment recommendation
- drug dose recommendation
- therapeutic efficacy claim
- lab validation confirmation
- clinical utility confirmation
- causal mechanism confirmation
- scientific breakthrough confirmation

Claim limit: `modern_medical_technology_routing_only_not_lab_or_clinical_proof`.

## Integration

The layer is connected to:

- BiomedicalResearchOntologyV11041
- BiomedicalConceptBridgeV11042
- ImmuneEvidencePriorMatrixV11038
- EBVLeadVerificationV11037
- LeadClosureHandoffV11035
- MetadataClosureAgent
- DatasetForagingReport JSON
- DiscoveryReportExporter
- ResearchAutopilotActivity
- RuntimeModuleRegistry
- ReleaseVersionLinkageGuard
