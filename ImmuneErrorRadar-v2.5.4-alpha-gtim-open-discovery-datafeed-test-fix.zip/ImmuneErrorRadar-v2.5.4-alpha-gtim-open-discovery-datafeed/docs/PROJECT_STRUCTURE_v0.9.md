# Project Structure v0.9

```text
ImmuneErrorRadar/
├─ app/src/main/java/com/immunesignal/app/
│  ├─ ResearchAutopilot.kt
│  ├─ ResearchAutopilotActivity.kt
│  ├─ ResearchKnowledgeStore.kt
│  ├─ ResearchModels.kt
│  ├─ SourceClassifier.kt
│  ├─ BiologicalPlausibilityGraph.kt
│  ├─ CausalityScorer.kt
│  ├─ NegativeControlEngine.kt
│  ├─ PersonalPatternLedger.kt
│  ├─ ContradictionFinder.kt
│  └─ HypothesisRankingEngine.kt
├─ app/src/main/assets/
│  ├─ evidence_quality_rules_v0.1.json
│  ├─ causality_scoring_rules_v0.1.json
│  ├─ species_detection_rules_v0.1.json
│  ├─ study_design_weights_v0.1.json
│  ├─ negative_control_rules_v0.1.json
│  └─ biological_plausibility_graph_v0.2.json
├─ research/
│  ├─ evidence_quality.py
│  ├─ causality_scorer.py
│  ├─ negative_controls.py
│  ├─ personal_time_series.py
│  └─ hypothesis_ranker.py
├─ docs/
│  ├─ PROJECT_INTERNAL_SHEET_v0.9.md
│  └─ EVIDENCE_CAUSAL_LEARNING_v0.9.md
└─ scripts/
   └─ run_static_checks.sh
```
```
