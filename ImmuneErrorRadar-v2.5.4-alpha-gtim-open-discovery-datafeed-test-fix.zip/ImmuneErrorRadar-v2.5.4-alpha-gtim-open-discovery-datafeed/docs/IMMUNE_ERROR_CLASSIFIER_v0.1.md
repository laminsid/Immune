# Immune Error Classifier v0.1

## Product Role
This module is a research-grade signal organizer, not a medical device claim. It maps entered immune-related values into biological axes that can later support a validated bio-intelligence platform.

## Current Classifier Labels
- `low_signal_or_incomplete_pattern`
- `type2_allergic_dominant_signal`
- `tnf_il6_inflammatory_dominant_signal`
- `hyperinflammatory_or_systemic_signal`
- `urgent_clinical_warning_pattern`

## Immune State Vector
- Type-2 allergic axis
- TNF/IL-6 inflammatory axis
- Hyper-inflammatory axis
- Regulatory brake weakness
- Systemic damage signal
- Dominant compartment

## Safety Boundary
The classifier must never output diagnosis, treatment instructions, drug recommendations, or disease probabilities. It outputs signal strength and evidence completeness only.

## Biotech Roadmap
1. Allergy wedge: validate detection of Type-2/allergy-like signals.
2. Arthritis bridge: compare chronic inflammatory axis against allergy wedge.
3. Systemic inflammation: compare against ARDS/sepsis-like public data before rare-virus expansion.
4. Target Hypothesis Engine: generate biological hypotheses, not patient treatment instructions.
