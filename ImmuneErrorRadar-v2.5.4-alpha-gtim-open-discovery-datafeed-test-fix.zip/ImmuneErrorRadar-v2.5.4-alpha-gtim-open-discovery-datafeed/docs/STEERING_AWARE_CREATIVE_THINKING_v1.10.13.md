# v1.10.13 — Steering-aware Creative Thinking

This patch makes scientific steering axes first-class inputs to Creative Hypothesis Forge.

## Added axes
- Neuroimmunology
- Exposome / Microbiome
- Immunometabolism
- Chronomedicine
- In-silico Immunology

## Rule
Expanded thinking is allowed for route invention, search strategy, and kill criteria only. It is not evidence and cannot upgrade hypotheses or causal language.

Claim limits:
- steering_axis_not_evidence
- creative_steering_hypothesis_not_evidence
- expanded_thinking_not_evidence
