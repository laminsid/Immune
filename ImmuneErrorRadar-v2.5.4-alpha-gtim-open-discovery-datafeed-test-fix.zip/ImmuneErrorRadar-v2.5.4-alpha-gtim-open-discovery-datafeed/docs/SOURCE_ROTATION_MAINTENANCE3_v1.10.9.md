# Source Rotation Maintenance 3 — v1.10.9

## Purpose

This maintenance pass closes a persistence gap in the no-candidate source-rotation loop.
The previous v1.10.9 maintenance allowed a multi-source no-candidate cycle to compute the correct next family, but persistent failure memory could still save only the first failed source family. That left later failed families eligible for immediate retry in the next cycle.

## Changes

- Persist every `NoCandidateLearningRecord` from a no-candidate dataset-foraging cycle, not only the first record.
- Keep the shared `nextPreferredSource` computed from the whole attempted-source sequence.
- Add per-family signatures so multiple source-family failures from the same cycle can coexist in persistent memory.
- Update query feedback summary to report the final sequence-level next source family.
- Add regression tests proving:
  - `GEO_GDS + SRA_PRJNA` failures make `IMM_PORT_SDY` the first next route.
  - Both failed families are excluded from immediate retry by memory cooldown.
  - Query feedback summarizes the sequence-level next source, not only the first record.

## Safety invariant

No biological or clinical claim is upgraded by this change. The patch only improves evidence acquisition routing after a failed source-family attempt.

