# Project Internal Sheet — Immune Error Radar v1.3.3

## Identity
Private/global immune-intelligence research engine. It studies triggers, immune-response choices, failure modes, recovery, and antiviral defense logic. It is not a personal health tracker, medical diagnostic tool, or treatment recommender.

## Current baseline
v1.3.3-alpha-autonomous-resilience builds on v1.3.2 Autonomous Researcher and v1.2 Lock System.

## Operating law
Autonomous Researcher Mode is default. Research Steering is optional acceleration only.

## v1.3.3 purpose
Improve research behavior when search fails:
- no-result recovery,
- adaptive query evolution,
- selective top-2 abstract fetching,
- dataset candidate extraction,
- concise report V3,
- refactor seams for future cleanup.

## Main modules
- ResearchAutopilot.kt: orchestrator/facade.
- QueryPlanner.kt: builds autonomous + optional steering queries.
- NoResultRecoveryEngine.kt: converts failure signatures into pivot decisions.
- AdaptiveQueryEvolution.kt: changes search stage after failed or exhausted lanes.
- SelectiveAbstractFetcher.kt: fetches abstracts only for high-value candidates.
- DatasetCandidateExtractor.kt: extracts GEO/GSE/ImmPort/SDY-style dataset leads.
- ResearchReportV3Builder.kt: concise executive research report.
- FindingBuilder.kt / PubMedClient.kt: seams for future refactor.

## Strict non-goals
- No new biological axes in v1.3.3.
- No ML/GNN/Random Forest/PyTorch.
- No personal daily tracker.
- No diagnosis/treatment/medical recommendation.

## Acceptance tests
- No useful result produces a pivot decision.
- Abstract fetching stays capped at 2 candidates.
- Dataset identifiers produce DatasetCandidate output.
- Report V3 answers: result, lead, hypothesis change, why, next move, caution.
- Steering remains optional.
