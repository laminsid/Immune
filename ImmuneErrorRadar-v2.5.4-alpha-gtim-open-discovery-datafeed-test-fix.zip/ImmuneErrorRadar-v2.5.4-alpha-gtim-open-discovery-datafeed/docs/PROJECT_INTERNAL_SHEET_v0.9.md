# Immune Error Radar — Internal Project Sheet v0.9

## 1. Project identity

**Mode:** private individual research laboratory, not a commercial medical product.

**Core purpose:** use public research, personal notes, repeated observations, and AI-style scoring logic to explore immune over-response, hidden causal drivers, and cross-system bridges.

**Boundary:** hypothesis generation only. No diagnosis, no treatment, no drug/hormone recommendation, no proof of causality.

## 2. Current architecture

```text
Android APK
├─ Field intake: biomarkers, symptoms, causal context, gut/nutrition/hormone fields
├─ Research Autopilot: internet search + cumulative local memory
├─ Research Steering: user-chosen variables guide the search without code edits
├─ Manual Report Intake: pasted notes or uploaded text/csv/json
├─ Discovery Report: PDF + copyable short report
└─ Evidence/Causal Learning v0.9
   ├─ SourceClassifier
   ├─ EvidenceQualityEngine logic
   ├─ SpeciesClassifier: human / animal / cell / unknown
   ├─ StudyDesignClassifier
   ├─ CausalityScorer
   ├─ BiologicalPlausibilityGraph
   ├─ NegativeControlEngine
   ├─ PersonalPatternLedger
   ├─ ContradictionFinder
   └─ HypothesisRankingEngine
```

## 3. Research axes

- Type-2 allergy / mast-cell / histamine / IgE
- TNF / IL-6 autoimmune-inflammatory axis
- Hyperinflammatory / cytokine-storm-like axis
- Regulatory brake / IL-10 / Treg context
- Psychoneuroimmune stress/sleep axis
- Psychomusculoskeletal back/disc/pain-recovery axis
- Aging / immunosenescence / inflammaging axis
- Autonomic / blood-pressure / vascular instability axis
- DNA / epigenetic / genomic axis
- RNA / transcriptomic / single-cell axis
- Gastric acid / reflux / gut barrier / microbiome axis
- Nutrition / protein / muscle reserve axis
- Testosterone / androgen immune-modulation axis

## 4. Learning policy

A finding is not learned as truth. It is stored as a **ranked hypothesis lead**.

A lead is upgraded only when it improves across:

1. **Evidence quality** — source type, study design, human vs animal/cell.
2. **Biological plausibility** — known or plausible pathway graph.
3. **Measurable marker** — at least one observable marker or symptom score.
4. **Temporality** — exposure appears before outcome.
5. **Repeatability** — repeated personal or dataset episodes.
6. **Negative control** — reverse-time/shuffled/unrelated controls do not explain it.
7. **Contradiction review** — opposing evidence is searched and not stronger.

## 5. Hypothesis statuses

```text
STRONG_SIGNAL      = promising research signal; still not proof.
WATCH              = useful, needs more data or controls.
WEAK               = biologically interesting but under-supported.
NOISE_OR_UNKNOWN   = likely noise, too sparse, or not testable yet.
```

## 6. Current highest-value test

**Stress → allergy/mast-cell/histamine symptoms → BP instability**

Minimum repeated fields for 30 days:

```text
stress score
sleep quality
allergy intensity
flushing/itching/sneezing
BP systolic/diastolic
pulse
dizziness/faintness
stomach symptoms
protein/nutrition context
exercise/muscle fatigue
optional: CRP, IgE, IL-6, testosterone if lab-tested
```

## 7. What not to add next

Do not add more biological domains until v0.9 is stable. The next improvement should be proof discipline, not more variables.

## 8. Next technical milestone

v1.0 should add:

- better local time-series input screen,
- export/import JSON research pack,
- stronger PubMed metadata handling using tool/email settings,
- optional abstract fetch with source-quality parsing,
- unit tests for every scoring engine.
