# Learning Audit Monitor v1.10.36

Release: `1.10.36-alpha-learning-monitor-continuity`

## Purpose

v1.10.36 continues v1.10.35 by making the UI report more inspectable for the user.
The application already preserved weak/off-route leads and tracked metadata closure. This patch adds a compact **Learning audit monitor** that explains:

- what the cycle learned,
- which rules were pinned for the next cycle,
- which metadata/evidence fields remain missing,
- which route priors were saved,
- what would invalidate the saved prior,
- and the next audit action.

## Boundary

The monitor is report-only. It does not create biological evidence, does not upgrade hypotheses, does not rank treatments, and does not make clinical recommendations.

Claim limit: `learning_rules_ui_monitor_not_biological_proof`

## UI behavior

The main summary now contains one consolidated block:

- `Learning audit monitor`
- `State`
- `Learned now`
- `Rules kept`
- `Saved priors`
- `Still missing`
- `Invalidate if`
- `Next audit`

This replaces scattered learning/rule lines and makes it easier to monitor the system's memory without opening the full technical report.

## Engineering notes

- Adds `LearningRulesUiSummaryV11036.kt`.
- Adds `LearningRulesUiSummaryV11036Test.kt`.
- Keeps v1.10.35 lead-closure, metadata-closure, and unknown-route classifier intact.
- Adds exporter lines so the PDF/technical report also records the learning monitor.
- Updates release identity to `versionCode=98`, `versionName=1.10.36-alpha-learning-monitor-continuity`, active engine `v1.10.36-alpha-learning-monitor-continuity`, and schema `1.10.36`.

## Invalidation logic

The UI explicitly shows when a saved rule or prior should be treated as weak or invalid:

- no explicit accession or data-availability text,
- no outcome labels,
- no control/comparator,
- route vocabulary is absent from accession-level metadata,
- or a better route explains the same lead with fewer assumptions.
