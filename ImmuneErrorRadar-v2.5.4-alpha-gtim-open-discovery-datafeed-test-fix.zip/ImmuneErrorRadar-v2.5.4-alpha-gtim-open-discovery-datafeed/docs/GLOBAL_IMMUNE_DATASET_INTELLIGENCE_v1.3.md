# Global Immune Dataset Intelligence — v1.3

## Purpose

v1.3 redirects Immune Error Radar from personal-first tracking to a global immune-research engine. The Android app remains the control panel, but the core research objective is now:

> Discover how triggers activate immune response axes, how those axes lead to protection or damage, and what public datasets can test each hypothesis.

## What v1.3 adds

1. Dataset Discovery Engine
2. Dataset Quality Scorer
3. Immune Axis Mapper extension
4. Trigger → Response → Outcome Graph
5. Global Hypothesis Ledger
6. Antiviral Response Comparator
7. Global Discovery Report fields

## What v1.3 deliberately does not add

- No PyTorch / PyG inside APK
- No Random Forest training inside Android
- No SimCLR / contrastive model
- No clinical prediction or treatment recommendation
- No claim that immunity can be “strengthened” blindly

## Core research loop

```text
Search public literature/dataset metadata
→ classify source/species/study design
→ map markers/genes to immune axes
→ detect trigger-response-outcome edges
→ score dataset candidates
→ update global hypothesis ledger
→ output next dataset needed
```

## Global hypothesis examples

- HYP_INTERFERON_TIMING_RESOLUTION_001
- HYP_REGULATORY_BRAKE_CROSS_CONDITION_001
- HYP_TYPE2_TRANSCRIPTOMIC_STATE_001
- HYP_PROTECTION_DAMAGE_SPLIT_001

## Key lock

No global hypothesis may be promoted without:

1. Dataset candidate
2. Human or clearly translatable evidence
3. Immune axis mapping
4. Trigger-response-outcome structure
5. Contradiction/falsification path
6. Next dataset needed

## Relationship to v1.2

v1.2 remains the lock system. v1.3 does not bypass it. It adds global dataset intelligence as a new report layer and keeps evidence/causality/negative-control gates in front of every hypothesis.
