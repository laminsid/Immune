# Omics Axis v0.1 — DNA/RNA Research Layer

Purpose: add DNA, epigenetic, RNA, transcriptomic, and non-coding RNA evidence as research leads.

## Axes

- DNA / genomic axis: variants, SNPs, inherited susceptibility.
- Epigenetic aging axis: DNA methylation, chromatin, epigenetic clock signals.
- RNA transcriptomic axis: RNA-seq, scRNA-seq, gene-expression signatures.
- Non-coding RNA axis: miRNA/lncRNA regulatory signals.

## Boundary

The app must not infer disease, treatment, or personal therapy from DNA/RNA terms. Omics evidence is a hypothesis source until validated against curated datasets and repeated observations.

## Research question

Can DNA/RNA signatures reveal hidden immune states that routine markers like IgE, CRP, IL-6, or TNF miss?
