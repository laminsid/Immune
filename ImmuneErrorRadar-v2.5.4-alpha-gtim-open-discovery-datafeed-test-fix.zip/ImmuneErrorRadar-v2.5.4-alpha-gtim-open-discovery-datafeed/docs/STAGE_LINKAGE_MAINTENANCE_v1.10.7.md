# Immune Error Radar v1.10.7-alpha-stage-linkage-maintenance

## Goal

Maintenance and safe splitting, not new biological intelligence.

This patch continues the staged extraction of `ResearchAutopilot.runCycle` while preserving the routing chain:

`Directive Resolver -> Plan Stage -> Search Stage -> Phase Audit -> Path Maintenance Guard -> Report/PDF`

## Changes

### 1. Search execution extracted

Added `ResearchCycleSearchStage.kt`.

It now owns:

- PubMed query-batch execution handoff.
- duplicate PMID filtering against stored IDs and same-pass findings.
- typed runtime diagnostics mapping.
- stop/deadline checks.
- runtime failover planning and query construction.

`ResearchAutopilot.runCycle` still controls the orchestration, but the repairable network-search block is now isolated.

### 2. Runtime failover moved out of the main cycle

The old inline runtime failover block was replaced with:

`ResearchCycleSearchStage.buildRuntimeFailoverPlan(...)`

This makes the lock invariant easier to repair:

- if `unifiedSearchLockAfterForagerV204` is active, failover cannot run;
- if hard stagnation exists and no lock is active, failover produces bounded dataset/label queries.

### 3. Path maintenance guard

Added `ResearchCyclePathMaintenanceGuard.kt`.

It checks whether the following handoffs are connected:

- phase spine boundaries declared;
- plan stage active;
- phase audit active;
- directive owner matches plan-stage owner;
- lock violations are clean.

It outputs `pathMaintenanceReport` into JSON and PDF.

### 4. Report schema

Schema updated to `207` with a new field:

`pathMaintenanceReport`

### 5. Tests and audits

Added:

- `ResearchCycleSearchStageTest.kt`
- `ResearchCyclePathMaintenanceGuardTest.kt`
- `scripts/audit_stage_linkage_v1107.py`

Updated static checks and version-aware audits to accept v1.10.7.

## What this patch deliberately does not do

- It does not split the full reasoning stack yet.
- It does not migrate `ResearchCycleReport` to serialization.
- It does not move the whole `runCycle` into classes in one risky refactor.
- It does not change biological scoring or claim language.

## Next safe target

v1.10.8 should extract the **Reason stage boundary** into a wrapper that groups:

- ranking;
- dataset metadata closure;
- evidence objects;
- Learning OS.

That must be done without touching the scientific decision engines first.
