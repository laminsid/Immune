# v1.10.26 — Mature Domain Evidence Probe

This patch relaxes terminal archive behavior after the core accession sweep fails.
If mature domain expertise exists, the engine may run one or two bounded
mature-domain data-availability/accession probes before cooling down the route.

## Why

Recent reports showed improved routing but no useful findings: no accession, no
DatasetCandidate, and no EvidenceObject. At the same time, domain expertise had
started to mature. Archiving immediately discards potentially useful domain
learning.

## Behavior

- Core accession search still runs first.
- Mature domain probes run only after core accession families are exhausted.
- Mature domains are treated as working research priors, not proof.
- Probe queries reuse stabilized vocabulary such as histamine/mast-cell,
  chronic inflammation, drug perturbation, diabetes/metabolic inflammation, and
  adjacent immune contexts.
- Reports expose `matureDomainEvidenceProbeReport` with state, selected domains,
  query seeds, and claim limits.

## Guardrails

No diagnosis, treatment, dosage, drug ranking, or clinical recommendation is
created. No causal or biological proof is inferred. The claim limit is
`mature_domain_evidence_probe_not_biological_proof`.
