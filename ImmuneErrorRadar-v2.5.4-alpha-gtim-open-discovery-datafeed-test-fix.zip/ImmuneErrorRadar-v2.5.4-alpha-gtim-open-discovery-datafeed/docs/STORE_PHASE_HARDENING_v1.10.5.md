# Immune Error Radar v1.10.5 — Store + Phase Hardening

## Goal

This patch does not add a new cognitive layer. It stabilizes the base beneath the existing cognition stack.

## Completed

- Added `ResearchKnowledgeStoreFileOps` as a pure JVM-testable JSONL file operations helper.
- Delegated hot `ResearchKnowledgeStore` append/trim/read-last paths to the helper while keeping per-file locks in the Android store.
- Added regression tests for append-only writes, malformed JSONL rejection, last-N reads, and bounded trimming.
- Added `ResearchCyclePhaseSpine` as the first safe extraction boundary for `ResearchAutopilot.runCycle`.
- Added phase boundary tests covering Plan → Dataset Foraging → Search → Reason → Persist.
- Updated version/schema to v1.10.5 / schema 205.
- Added `scripts/audit_store_phase_v1105.py` to prevent missing store/phase hardening files and wiring.

## Not completed in this patch

- Full `ResearchAutopilot.runCycle` extraction was intentionally not performed in one step.
- Full ViewModel migration was not performed.
- Full `ResearchCycleReport` DTO split was not performed.
- Official Gradle wrapper JAR could not be generated in this environment because the wrapper distribution cannot be downloaded here. Existing `gradlew` remains a bootstrap script that uses local Gradle or downloads Gradle when network is available.

## Next safe patch

v1.10.6 should extract the PLAN phase only into a small class and add a regression test proving query budget and search-lock behavior is unchanged.
