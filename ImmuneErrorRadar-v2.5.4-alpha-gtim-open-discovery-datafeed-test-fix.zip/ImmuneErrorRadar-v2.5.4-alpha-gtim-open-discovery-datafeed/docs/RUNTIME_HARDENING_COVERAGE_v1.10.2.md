# Runtime Hardening Coverage v1.10.2

## Closed in this batch

1. Raw `HttpURLConnection` removed from `ResearchAutopilot` hot path and replaced by `NcbiClient` + OkHttp.
2. NCBI headers and rate limiting centralized.
3. HTTP 429 and non-2xx handling covered by unit tests.
4. User-Agent version drift covered by unit test.
5. Offline thinking JSONL access changed from full-file read to tail read.
6. Autonomous thought pulse JSONL access changed from full-file read to tail read.
7. Offline/pulse ledgers now use append-only writes with periodic trim.
8. Runtime modules now have typed registry entries instead of only a raw string inventory.
9. Boundary matching regression for `ppi` versus `shipping` preserved in tests.
10. Build target bytecode lowered to Java 11 as requested in the audit notes.

## Still intentionally deferred

- Full `ResearchCycleReport` DTO split.
- Full `kotlinx.serialization` migration.
- Full Activity -> ViewModel migration.
- Full `runCycle` phase extraction.
- Full changelog consolidation.

Those are architecture migrations and should be done as separate non-breaking batches after CI confirms this runtime hardening build.
