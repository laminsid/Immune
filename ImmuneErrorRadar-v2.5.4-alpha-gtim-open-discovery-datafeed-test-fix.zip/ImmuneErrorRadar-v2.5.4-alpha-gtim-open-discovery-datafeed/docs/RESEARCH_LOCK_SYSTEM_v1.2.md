# Research Lock System v1.2

## Purpose

This patch translates the DTOS lock discipline into Immune Error Radar without adding new biological scope.

The engine no longer treats every interesting source as a main finding. A source matters only if it changes a Hypothesis Object.

## Core law

No hypothesis upgrade without:

1. Data Trust
2. Evidence Score
3. Temporality
4. Measurable marker
5. Repeatability
6. Negative control
7. Contradiction/falsification check

## Hypothesis Object

Each active lead becomes a single source of truth:

- `hypothesisId`
- `status`
- `discoveryState`
- `biasRiskState`
- `dataTrustScore`
- `evidenceScore10`
- `causalityScore`
- `minimumDataPackStatus`
- `missingData`
- `nextBestMeasurement`
- `signalFlip`
- `decisionImpact`
- `falsification`

## States

Discovery State:

- Off
- Early
- Active
- Strong Candidate

Bias Risk State:

- Normal
- Watch
- Alert
- Severe Bias

## Quality Stop

If the Minimum Data Pack is blocked, the engine must not upgrade the hypothesis. It must output the missing data and the next best measurement.

## Delta-only learning

Every Search + Learn cycle now outputs delta cards:

- new hypothesis object
- rank changed
- quality stop
- human evidence added
- contradiction required
- no major flip

No repeated narrative should be treated as new learning.
