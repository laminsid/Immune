# Topic Route Correction + EvidenceObjectCandidate v1.10.49

This patch keeps v1.10.48's relaxed progression but corrects route selection before old mature-domain priors can dominate.

## Route correction rules
- RNA → `RNA_TRANSCRIPTOMIC_IMMUNE_STATE_LANE`
- DNA/genetics → `GENETIC_EPIGENETIC_IMMUNE_VARIANT_LANE`
- Ashwagandha/curcumin/quercetin/herbs → `HERB_EXPOSURE_HPA_IMMUNE_MODULATION_LANE`
- Rituximab/loratadine/immunomodulators → `DRUG_PERTURBATION_IMMUNE_CONTROL_LANE`
- Vaccine → vaccine immune response lanes only when vaccine terms are explicit.

## EvidenceObjectCandidate
`EvidenceObjectCandidateV11049` is created only when metadata is useful enough for the next evidence hunt but still not eligible for EvidenceObject. It remains blocked by:
- control/comparator
- contradiction or negative-control search
- route-fit closure
- no-treatment/no-dose guard

It is a work queue object, not proof.
