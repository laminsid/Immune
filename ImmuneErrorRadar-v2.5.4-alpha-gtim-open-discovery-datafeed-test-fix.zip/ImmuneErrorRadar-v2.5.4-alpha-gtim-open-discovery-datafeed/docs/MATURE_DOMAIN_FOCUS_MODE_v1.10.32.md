# v1.10.32 — Mature Domain Focus Mode

Release layer: `v1.10.32-alpha-mature-domain-focus-mode` integrated into current train `1.10.33-alpha-lean-agent-runtime`.

## Purpose

Turn mature domain experience into deeper lead capture. The engine should not jump horizontally between every domain after repeated broad failures. It selects one mature domain for a 2–3 cycle focus window and uses that domain only as a search prior.

## Added / connected modules

- `MatureDomainFocusModePolicy`
- `MatureDomainFocusReport`
- `DomainSpecificKillCriteriaReport`
- `DomainExpertiseScoreUpgradeReport`
- `KnowledgeGapQueueReport`
- `StrongRouteFingerprintReport`

## Rules

- Domain expertise is a search prior, not biological proof.
- Focus mode narrows query routing; it cannot upgrade a hypothesis.
- Kill criteria cool down only the focused domain; they do not archive the whole research route if leads or gaps remain.
- Knowledge gaps become queue items with priority, attempt count, cooldown, last source, and next query.
- Strong route fingerprinting includes intent, domain, source family, blockers, axes, normalized terms, and last outcome.

## Connected path

`DomainExpertiseReport → MatureDomainFocusReport → focused mature-domain query → KnowledgeGapQueue → StrongRouteFingerprint → ReportConsistencyGuard → final decision`

## Claim lock

`domain_focus_search_prior_not_biological_proof`
