# GTIM v2.5.1 Route Integrity Hardening

## Purpose

This patch prevents GTIM from becoming a detached reporting island. The global dossier must remain anchored to the existing v1.11.x path:

`ResearchGradeMechanismDossierV1110 -> GTIMDiscoveryDossierV250 -> DatasetForagingJson.globalTranslationalDossier -> GlobalResearchGradeBriefV11061 -> ResearchAutopilotActivity -> RuntimeModuleRegistry`

## What the guard checks

- The mechanism dossier is active.
- GTIM has evidence objects when source metadata/accessions exist.
- GTIM creates bounded mechanism candidates when evidence objects exist.
- GTIM candidate statuses do not claim confirmation.
- GTIM confidence does not reach 90+ without external validation.
- Manual snippets/text-mined leads stay exploratory and cannot become confirmed accessions.
- Cross-species evidence remains auxiliary and cannot become human confirmation.
- Google Play posture remains conservative: no new sensitive permissions, no telemetry, no background service, no clinical claims.

## Output surface

`routeIntegrity` is now exported with:

- `passed`
- `status`
- `bridgePath`
- `connectedSurfaces`
- `requiredAnchors`
- `brokenLinks`
- `weakLeadProtection`
- `playProtectPosture`
- `githubCiPosture`
- `nextRepairAction`

## Claim boundary

GTIM v2.5.1 generates corpus-relative, falsifiable research mechanism dossiers only. It does not diagnose, treat, recommend doses/supplements, predict patient outcomes, or confirm biological truth from weak evidence.
