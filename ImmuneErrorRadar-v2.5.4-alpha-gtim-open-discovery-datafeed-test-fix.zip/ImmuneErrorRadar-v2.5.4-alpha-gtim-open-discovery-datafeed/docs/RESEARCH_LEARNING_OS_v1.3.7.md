# Immune Error Radar v1.3.7 — Evidence Acquisition + Learning OS

## Purpose
v1.3.7 moves the Autonomous Immune Researcher from query rotation toward evidence-object learning.

The new learning loop is:

`incident → root cause → preventive gate → regression vector → forced next evidence path`

## New hard behavior

- A query pivot alone cannot upgrade a hypothesis.
- A hypothesis update needs an `EvidenceObject` with decision impact.
- A repeated empty PubMed neighborhood becomes a lane cooldown.
- A no-dataset cycle forces dataset accession search before another broad exploration.
- Discovery readiness remains `OFF` unless usable evidence objects and dataset labels exist.

## New evidence acquisition layer

- `DatasetAccessionResolver`: extracts GSE/GSM/GDS/SDY/PRJNA/SRP/SRA/ERP/DRP/E-MTAB/EGAS identifiers.
- `DatasetCandidateScorer`: scores dataset usability from organism, condition labels, outcome labels, time-course, sample size, and data type.
- `AbstractToDatasetBridge`: classifies whether a PubMed result points to a real dataset.
- `EvidenceObjectFactory`: turns findings into decision-impact evidence objects.
- `DiscoveryReadinessScorer`: computes 0–100 readiness and state: OFF / CANDIDATE / TESTABLE_LEAD.

## Learning OS layer

- `ResearchLearningLoopEngine`: creates the incident receipt, root-cause tags, preventive gates, lane cooldowns, and regression vectors.
- `ResearchPolicyLock`: keeps no diagnosis / no treatment / no causal overclaim / no query-only upgrade boundaries.

## Data-only update anchors

The following JSON assets were added so future rules can be updated without large code changes:

- `failure_root_causes_v1.3.7.json`
- `preventive_gates_v1.3.7.json`
- `dataset_patterns_v1.3.7.json`
- `regression_vectors_v1.3.7.json`
- `research_policy_lock_v1.3.7.json`

## Non-goals

v1.3.7 does not add new biological axes, new diseases, Random Forest, ML, symptom tracking, diagnosis, treatment recommendation, or medical advice.
