# Relaxed Progression Context Alignment v1.10.48

This patch lowers strictness only where the system was too conservative operationally: moving weak, context-aligned leads into minimum metadata inspection.

Canonical path:

`Context seed → route candidate → metadata lookup → contradiction/null search → EvidenceObject only if gates close`

Forbidden shortcut:

`Context seed → keyword match → route-fit boost → hypothesis upgrade`

## Policy

Context seeds may:

- improve lookup priority;
- improve parsing priority;
- choose the next route-specific vocabulary;
- keep weak leads alive long enough for metadata inspection.

Context seeds must not raise evidence confidence, biological belief probability, causal readiness, route-fit-to-proof, treatment confidence, or claim strength.

## Soft progression gates

These gates may stay open while the engine moves to metadata inspection:

- accession/source ID;
- control/comparator;
- outcome labels;
- time order;
- sample size;
- condition labels;
- license/data availability.

## Hard claim gates

These gates still block biological conclusions:

- accession/source ID;
- human/patient context;
- outcome labels;
- control/comparator;
- time order;
- contradiction or negative-control search;
- no treatment/dose/recommendation claim.

## Why this exists

The v1.10.46 reports showed candidates and weak leads but no parsed metadata. The system was safe, but too strict for progress. v1.10.48 keeps safety while allowing the next operational step.
