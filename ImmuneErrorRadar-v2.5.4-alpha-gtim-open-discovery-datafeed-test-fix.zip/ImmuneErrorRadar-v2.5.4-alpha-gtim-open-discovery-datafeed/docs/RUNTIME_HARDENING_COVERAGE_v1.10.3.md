# Runtime hardening coverage — v1.10.3

| Area | Status | Note |
|---|---:|---|
| HTTP errors not swallowed | Done in v1.10.1/v1.10.2 | Centralized in `NcbiClient` |
| Coroutine retry | Done | `delay()` replaces blocking sleep |
| NCBI rate limit | Done | 3/sec or 10/sec depending on API key |
| Dynamic User-Agent | Done | Uses `EngineRuntimeStatus.ACTIVE_ENGINE_VERSION` |
| AxisMatcher word boundaries | Done | Regression test added |
| JSONL/IO hot path | Partially done | append/read-last improvements applied; Room migration deferred |
| Prior search locks | Done in v1.10.3 | Unified `ResearchSearchDirectiveResolver` |
| Broad-search prevention | Done | `priorUnifiedSearchLockV203` controls dataset-first and failover |
| Full Gradle build | External CI required | Local environment lacks reliable Gradle/DNS |

## Remaining deferred work

- Full ViewModel migration.
- Serialization migration away from manual `*ToJson` functions.
- Full `ResearchAutopilot.runCycle` stage split into separate classes.
- Room migration for all hot ledgers.
