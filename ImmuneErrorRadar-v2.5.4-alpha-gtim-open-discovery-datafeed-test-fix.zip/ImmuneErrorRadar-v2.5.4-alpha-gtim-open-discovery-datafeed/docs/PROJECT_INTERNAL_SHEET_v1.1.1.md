# Immune Error Radar — Internal Project Sheet v1.1.1

## Project identity

Private research Android/Python system for exploring immune over-response, causal drivers, and cross-axis hypotheses.

It is not a diagnostic tool, treatment engine, or drug recommender. It is a private research notebook and hypothesis-ranking system.

## Current baseline

**Version:** v1.1.1-alpha-stable-research-baseline

This baseline is considered cleaner than v1.1.0 because it:

1. Fixes README/version drift.
2. Removes Python cache artifacts from the release package.
3. Adds a release `.gitignore`.
4. Documents the build route clearly in `BUILD.md`.
5. Fixes omics bridge false positives from `no/unknown` values.

## Core architecture

```text
Android APK
├─ Case intake
├─ Research Autopilot
├─ Research Steering
├─ Manual report import
├─ Knowledge memory
├─ Evidence quality scoring
├─ Causal scoring
├─ Negative controls
├─ Hypothesis ranking
└─ Report export

research/
├─ dataset registry loader
├─ marker dictionary / normalizer
├─ immune matrix builder
├─ baseline classifier
├─ cross-condition bridge
├─ omics bridge
├─ evidence quality
├─ causality scorer
├─ negative controls
├─ personal time series
└─ hypothesis ranker
```

## Active research axes

- Type-2 allergy / mast-cell / histamine.
- TNF/IL-6 inflammatory axis.
- Hyperinflammatory / storm-like axis.
- Regulatory brake weakness.
- Psychoneuroimmune stress/sleep axis.
- Psychomusculoskeletal pain/recovery axis.
- Aging / immunosenescence / inflammaging.
- Autonomic-vascular: sympathetic pressure-up vs histamine pressure-down.
- Gut/stomach acid/microbiome/nutrition/muscle/testosterone axis.
- DNA/RNA/omics axis.

## Learning law

Do not upgrade a relationship because it is interesting. Upgrade only when it survives:

1. Biological plausibility.
2. Measurable marker support.
3. Temporal order.
4. Repeatability.
5. Negative-control resistance.
6. Contradiction review.
7. Human/animal/cell evidence separation.

## Current strongest first test

```text
Stress spike
→ allergy / histamine-like symptoms
→ dizziness, flushing, or blood pressure instability
```

Required daily/episodic fields:

- Stress score.
- Sleep quality.
- Allergy intensity.
- Dizziness/flushing.
- BP systolic/diastolic.
- Pulse.
- Stomach symptoms.
- Food/protein context.
- Exercise/recovery.

## What not to add now

Do not add new biological domains until this baseline can rank and falsify existing hypotheses reliably.

Next engineering target should be maintainability and proof discipline:

```text
ResearchAutopilot split
+ stronger tests
+ personal time-series charts/export
+ contradiction search improvement
```

## Next recommended version

**v1.2 — Maintainability Split**

Split large modules:

```text
ResearchAutopilot.kt
→ PubMedClient.kt
→ QueryPlanner.kt
→ ResearchCycleRunner.kt
→ FindingBuilder.kt
→ ResearchReportAssembler.kt
```

and split large model files if they continue to grow.
