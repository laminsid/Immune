# Metadata Closure Hyper-Drive v1.10.58

## Purpose

Turn verified cross-family intersections from passive off-route snippets into hard-targeted accession extraction tasks.

## Trigger

Hyper-Drive activates when `MetadataClosureIntersectionRuleV11057` verifies either:

1. Neuro-Viral Bridge: EBV/HHV-6 + SLE/MS/ME-CFS + transcriptome/RNA-seq.
2. Psychophysiological Exposome: HPA-axis/Cortisol-DHEA/Sleep deprivation + IFN-alpha/IL-6/TNF-alpha.

## Route-fit elevation

Verified intersections force `forcedRouteFitTarget = 95/100` for retrieval priority only.

## Stream Alpha

Source families:

- `GEO_GDS`
- `SRA_BIOPROJECT`

Query:

`(EBV OR HHV-6) AND (SLE OR "Systemic Lupus" OR "Multiple Sclerosis") AND ("RNA-Seq" OR "Transcriptome") AND "Data Availability" AND (GSE[0-9]* OR PRJNA[0-9]*)`

## Stream Beta

Source families:

- `GEO_GDS`
- `SRA_BIOPROJECT`

Query:

`("HPA-axis" OR "Cortisol/DHEA ratio" OR "Sleep deprivation") AND ("Interferon-alpha" OR "IL-6" OR "TNF-alpha") AND ("Curcumin" OR "Ashwagandha") AND (GSM[0-9]* OR SRP[0-9]*)`

## Programmatic command log

Each stream emits:

- `EXECUTE_QUERY`
- `EXTRACT_ACCESSIONS`
- `MAP_CONTROL_COMPARATOR`

## Required accession patterns

- `GSE[0-9]*`
- `GSM[0-9]*`
- `PRJNA[0-9]*`
- `SRP[0-9]*`
- `SRR[0-9]*`

## Control/comparator linkage

Every verified stream adds:

`healthy control OR matched control OR baseline OR placebo OR responder OR non-responder OR negative control OR case_label OR contrast_definition`

## No fabricated accession IDs

The runtime may demand `accessions>0`, but it must not fabricate IDs. If no accession is found, it must log:

`HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION`

## Evidence object rule

`evidenceObjects>0` is allowed only after real accession metadata, human cohort metadata, outcome labels, control/comparator, time-order, data access text, and contradiction/null-result check close.

## Current compatibility note

Metadata Closure Strategy Matrix v1.10.61 keeps the v1.10.58 Hyper-Drive contract active under the current GitHub CI route/audit unification train.
