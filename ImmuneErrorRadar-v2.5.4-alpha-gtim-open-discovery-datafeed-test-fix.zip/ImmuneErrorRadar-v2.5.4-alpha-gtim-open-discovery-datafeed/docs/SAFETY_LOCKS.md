# Safety Architecture

## Layer 1 — Emergency Override
The app must stop interpretation when urgent clinical warning signs appear. It should show urgent guidance and let the user export/show entered data, but it must not continue with pseudo-diagnostic reasoning.

Red-flag examples:
- Breathing difficulty, chest pressure, or low oxygen concern
- Confusion, fainting, severe weakness, or cannot stay awake
- Rapid swelling of lips, tongue, or throat
- Very high fever with systemic signs
- Blue/grey lips or skin

Germany/EU: call 112 for life-threatening emergencies.  
Germany non-life-threatening medical help: 116117.

## Layer 2 — No Medical Claims
Forbidden:
- "You have rheumatoid arthritis"
- "You have cytokine storm"
- "Take a TNF inhibitor"
- "Start steroids"
- "This predicts your disease"

Allowed:
- "Type-2/allergy-like signal"
- "Inflammatory activity signal"
- "Systemic inflammatory warning pattern"
- "Discuss these entered values and symptoms with a qualified clinician"

## Layer 3 — Signal Strength, Not Confidence
The app must not present unvalidated statistical confidence. It uses:
- Signal strength
- Data quality
- Evidence completeness
- What this does not prove

## Layer 4 — Doctor Review Pack
PDF export is for discussion and data organization only. It must include:
- Biomarkers entered
- Symptoms/red flags selected
- Immune State Vector
- Evidence used
- Discussion prompts
- What is not proven
- Emergency guidance

## Layer 5 — Target Hypothesis Boundary
The future biotech layer may generate research hypotheses about pathways or targets. It must not produce patient-specific drug recommendations unless a regulated, clinically validated product line is created separately.

## v0.3 Causal-Origin Safety Locks

### Psychological causality lock

The app may mark psychological stress, sleep debt, panic/rapid breathing, or emotional events as possible trigger/amplifier/maintainer candidates. It must not claim that stress is the proven root cause of asthma, allergy, arthritis, disc degeneration, disc herniation, infection, or systemic inflammation.

### Musculoskeletal lock

Back/disc-like symptoms are mapped as mechanical / neuromuscular context only. The app does not diagnose disc degeneration, disc herniation, nerve compression, or structural injury. Neurological flags such as numbness, weakness, radiating pain, bladder/bowel changes, fever, trauma, or severe worsening override app interpretation and require real-world clinical review.

### Evidence ledger lock

Every causal-origin output must be treated as hypothesis-grade and evaluated against:

1. Temporal evidence
2. Biological plausibility
3. Repeatability
4. Alternative explanations
