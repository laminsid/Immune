# Research Mode v0.3

The private research mode produces:

- JSON schema v3
- immune state vector
- causal origin map
- evidence ledger
- research hypotheses
- PDF export

## Key principle

Hypothesis first. Never convert hypothesis into diagnosis or treatment without external validation.
