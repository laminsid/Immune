# Source Rotation Maintenance 2 — v1.10.9

## Purpose

This maintenance pass hardens the no-candidate learning loop after the source-rotation patch.

The key problem: when a bounded forager attempts more than one source family in the same cycle and all fail, the next-cycle source must advance past the last attempted source, not simply choose the next source after the first failed family.

## Fixes

- Added `DirectDatasetSourceRouter.nextSourceAfterNoCandidateSequence(...)`.
- Added a normalized `rotationOrder` and source-family normalization for cooldown escape aliases.
- Updated `ResearchAutopilot` so no-candidate records use the cycle-level next source when multiple source families were attempted.
- Added regression coverage proving `GEO_GDS + SRA_PRJNA` failure advances to `IMM_PORT_SDY` rather than repeating `SRA_PRJNA`.
- Updated the v1.10.9 audit guard to require the sequence-aware rotation path.

## Expected behavior

If a cycle attempts only:

```text
GEO_GDS
```

then the next preferred source is:

```text
SRA_PRJNA
```

If a cycle attempts:

```text
GEO_GDS, SRA_PRJNA
```

then the next preferred source is:

```text
IMM_PORT_SDY
```

If all normal source families were already attempted in the same bounded sequence, the system wraps safely to `GEO_GDS` only after the whole chain has been exhausted.

## Claim boundary

This changes source-routing behavior only. It does not upgrade hypotheses, prove biology, or allow causal/clinical claims.
