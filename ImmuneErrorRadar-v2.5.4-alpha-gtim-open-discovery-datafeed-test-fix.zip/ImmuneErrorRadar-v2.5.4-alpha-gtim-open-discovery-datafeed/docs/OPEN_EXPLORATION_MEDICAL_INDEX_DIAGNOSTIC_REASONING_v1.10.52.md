# Open Exploration Medical Index / Diagnostic Reasoning Sandbox v1.10.52

## Purpose
Let the research engine explore freely enough to discover unexpected links while making its reasoning visible.

## Pipeline
Term or exposure → dynamic node → route candidate → biomarker map → dataset query → comparator hunt → contradiction/null search → EvidenceObjectCandidate or archive.

## New first-class nodes
- Sugar / glucose / HbA1c / insulin
- Salt / sodium / blood pressure / osmotic stress
- EBV / Herpesviridae / molecular mimicry
- COVID / Long COVID / interferon / mitochondrial-fatigue context
- SLE / autoimmune flare / B-cell-antibody axis
- IL-6 / CRP / TNF-alpha inflammatory-marker context

## Diagnostic reasoning sandbox
The system can display differential possibilities and reasons for/against each route. These are hypotheses, not diagnoses.

## Hard limits
No final patient diagnosis, no treatment, no dosing, no drug ranking, no supplement advice, no emergency triage.
