# GTIM v2.5.2 Release Surface Hardening

This patch does not add a new scientific route. It closes the release surface around the existing GTIM v2.5.x dossier so the global research layer remains visible, bounded, and CI-checkable.

## Why this exists

Superseded by v2.5.4: the Android application release train, runtime engine, learning schema, and GTIM product direction are now unified as `2.5.4-alpha-gtim-open-discovery-datafeed`. v2.5.2 introduced the bridge; v2.5.4 closes the version split:

`Android release train v1.11.5 -> GTIM product engine v2.5.2`

## Added guard

`GTIMReleaseSurfaceHardeningV252` verifies:

- GTIM dossier is active when the mechanism dossier is active.
- GTIM route integrity already passed.
- evidence objects and bounded mechanism candidates are exported.
- compact UI/report lines exist.
- no-diagnosis and no-treatment guardrails are visible.
- novelty remains corpus-relative.
- every mechanism candidate has a falsification and lab-validation plan.
- no candidate claims confirmation.
- confidence cannot reach 90+ without external validation.

## Exported JSON field

`globalTranslationalDossier.releaseSurfaceHardening`

Important fields:

- `status`
- `androidReleaseTrain`
- `gtimProductEngineVersion`
- `verifiedSurfaces`
- `blockingIssues`
- `playProtectPosture`
- `githubPosture`
- `scientificClaimPosture`
- `nextAction`

## Play/GitHub posture

The patch adds no Android permissions, background service, telemetry, package visibility, location, camera, microphone, SMS, contacts, or call-log access. It only adds deterministic Kotlin models/guards, JSON export, brief/UI lines, tests, and a fast-gate audit.

## CI gate

`audit_gtim_v252_release_surface_hardening.py` is now part of `scripts/run_static_checks_fast.sh`.

Expected fast-gate line:

`GTIM v2.5.2 release-surface hardening audit: PASS`

## Claim boundary

GTIM remains a research-hypothesis dossier engine. It does not diagnose, treat, recommend doses/supplements, predict patient outcomes, or confirm biological truth from weak, text-mined, cross-species, or reference-control evidence.
