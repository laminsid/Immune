# v1.4.3 Route Audit

## Goal
Ensure the app behaves as a research engine and does not expose the old daily/manual scan path as a runtime route.

## Locked runtime paths
- Launcher: `MainActivity`
- Research execution: `ResearchAutopilotActivity`
- Local research archive: `HistoryActivity`

## Closed runtime paths
- `ResultActivity` is not registered in `AndroidManifest.xml`.
- The first page does not expose daily scan, symptom input, diagnosis, treatment, or health-score workflow.

## Active research path
`MainActivity -> ResearchAutopilotActivity -> ResearchAutopilot.runCycle -> Dataset-first forager / parser / learning OS -> report/export/archive`

## Actionable handoff rule
Report summaries must not say only “run another cycle”. A failed or empty cycle must produce a next-evidence action such as:
- DATASET_HUNT
- CONTRADICTION_HUNT
- CONTROL_SIGNAL_SEARCH
- METADATA_INSPECTION

## Static guard
`scripts/run_static_checks.sh` fails if legacy runtime routes or generic handoffs reappear.
