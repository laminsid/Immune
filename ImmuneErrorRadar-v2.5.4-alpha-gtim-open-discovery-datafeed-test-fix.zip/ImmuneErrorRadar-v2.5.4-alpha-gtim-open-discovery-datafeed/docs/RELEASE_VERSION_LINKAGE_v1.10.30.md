# v1.10.30 — Release Version Linkage & Documentation Lock

## Purpose

This release unifies the active release identity so GitHub/static checks do not drift while the dataset-foraging, learning, and domain-expertise paths remain connected.

## Active release identity

- `versionCode`: `92`
- `versionName`: `1.10.30-alpha-release-version-linkage-docs`
- `ACTIVE_ENGINE_VERSION`: `v1.10.30-alpha-release-version-linkage-docs`
- `LEARNING_SESSION_SCHEMA_VERSION`: `1.10.30`
- Release guard: `ReleaseVersionLinkageGuard`
- Claim limit: `release_version_linkage_not_biological_proof`

## What was unified

1. Gradle build identity.
2. Runtime active engine version.
3. Learning-session schema version.
4. Report/decision-card labels for dataset-foraging linkage.
5. Runtime module registry inclusion.
6. Static-check accepted release train.
7. Documentation index and changelog.
8. Audit coverage for release identity drift.

## What was intentionally not changed

- Historical docs and legacy audit tokens remain present as audit history.
- Biological/scientific claim gates remain unchanged.
- `ResearchModels` serialization schema remains backward-compatible where historical audits require it.
- No diagnosis, treatment, dosage, drug ranking, or clinical recommendation is introduced.

## Path linkage protected by this release

The following paths remain connected and auditable:

- Core accession sweep: `GEO_GDS`, `SRA_PRJNA`, `IMM_PORT_SDY`, `PUBMED_ACCESSION_MINING`.
- Adjacent-domain and contradiction/control pass coverage.
- Mature-domain evidence probe.
- Learning rule engine.
- No-candidate learning and query feedback.
- Failure memory.
- Domain expertise continuity and mature-domain priors.
- Dataset path/pass coverage linkage.
- Learning/domain path linkage.

## GitHub safety checklist

Before publishing a ZIP, the expected checks are:

```text
validate_json: PASS
Kotlin delimiter audit: PASS
v1.10.25–v1.10.30 audits: PASS
release hygiene audit: PASS
Kotlin string literal audit: PASS
XML parse: PASS
Layout ID check: PASS
py_compile: PASS
```

Gradle full compile remains the final authority in GitHub Actions when network access to `services.gradle.org` is available.
