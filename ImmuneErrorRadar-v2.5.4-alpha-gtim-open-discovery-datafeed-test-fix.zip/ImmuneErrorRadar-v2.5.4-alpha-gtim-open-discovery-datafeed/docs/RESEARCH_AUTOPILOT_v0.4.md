# Research Autopilot v0.4

Purpose: help a private researcher discover non-obvious links across immune over-response, stress/sleep, environmental exposure, infection, and musculoskeletal context.

## What it does

- Runs user-started internet searches against PubMed/NCBI metadata.
- Uses fixed and local-case-boosted queries.
- Scores findings by cross-axis bridge potential.
- Saves reports and findings locally.
- Exports Discovery PDF.

## What it does not do

- No diagnosis.
- No treatment advice.
- No drug ranking.
- No proof of causality.
- No autonomous clinical decision.

## Autopilot cycle

1. Build query pack.
2. Search PubMed esearch.
3. Fetch esummary metadata.
4. Match axes:
   - Type-2 allergy
   - TNF/IL-6 autoimmune inflammation
   - Hyperinflammatory/storm-like
   - Regulatory brake
   - Psychoneuroimmune
   - Psychomusculoskeletal
5. Score novelty.
6. Generate emergent links and next questions.
7. Store locally.

## Scientific rule

A discovery is only a research lead until it passes:

- Temporal evidence: trigger precedes signal.
- Biological plausibility: known or plausible mechanism.
- Repeatability: appears across repeated cases or datasets.
- Falsification: clear way to disprove the link.
