# Immune State Vector v0.2

Expanded vector fields:

- Type-2 allergic axis
- Mast-cell axis
- Eosinophil axis
- TNF/IL-6 inflammatory axis
- Hyper-inflammatory axis
- Regulatory brake weakness
- Systemic damage signal
- Psychoneuroimmune stress axis
- Mechanical load axis
- Neuromuscular guarding axis
- Dominant compartment

The vector is a research abstraction, not a clinical diagnosis.
