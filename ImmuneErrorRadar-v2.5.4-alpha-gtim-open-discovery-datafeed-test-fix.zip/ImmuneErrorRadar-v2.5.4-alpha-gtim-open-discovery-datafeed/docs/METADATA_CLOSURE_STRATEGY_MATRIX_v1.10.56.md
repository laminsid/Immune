# Metadata Closure Strategy Matrix v1.10.56

## Objective

Solve the metadata-closure bottleneck for multi-pass longitudinal human transcriptome dataset discovery. The layer treats weak/off-route text snippets as acquisition leads, not scientific evidence.

## Trigger

Activate when any of these are true:

1. A candidate or lead is `WEAK_DATASET_LEAD`, `OFF_ROUTE_USEFUL_DATASET`, `LEAD_ONLY_NOT_EVIDENCE`, exploratory, or low-usability.
2. A snippet contains priority virus/pathology/biomarker/modulator vocabulary.
3. A snippet also contains transcriptome/accession vocabulary such as `transcriptome`, `RNA-seq`, `GSE`, `PRJNA`, `SRA`, `SDY`, `accession`, or `data availability`.

## Priority matrix

- Viruses: EBV, HHV-6, SARS-CoV-2 / Long COVID, CMV.
- Pathologies: SLE, MS, ME/CFS, rheumatoid arthritis.
- Biomarkers: type I interferon, IL-6, TNF-alpha, cortisol/DHEA.
- Modulators: JAK inhibitors, rituximab, curcumin, ashwagandha, quercetin.

## Runtime rule

A weak/off-route hit must become `MINIMUM_METADATA_PROBE_FORCED`, not `FAIL` or `NOT_RUN`.

## Query streams

The layer emits exact streams for:

- `PUBMED_ACCESSION_MINING`
- `GEO_GDS`
- `SRA_BIOPROJECT`
- `IMM_PORT_SDY`
- `PUBMED_CONTRADICTION`

## Claim limit

`exploration_sandbox_not_biological_proof`

The layer cannot create diagnosis, treatment guidance, dosing advice, supplement recommendations, causal claims, or hypothesis upgrade. It only improves dataset acquisition and metadata closure.

## Current compatibility note

Metadata Closure Strategy Matrix v1.10.61 keeps this v1.10.56 contract active under the current GitHub CI route/audit unification train.
