# Longevity & Biological Systems Graph v1.10.46

Release: `1.10.46-alpha-longevity-biological-systems-graph`

## Purpose

This release adds a modular longevity and biological-systems routing layer on top of the existing dataset-first research engine. It is not a health-advice feature. It turns lifestyle, exposure, nutrition, herb/food, sleep, metabolic, mitochondrial, immune-aging, and environmental topics into falsifiable research paths.

## Core path

Every selected lane is forced into:

`Exposure -> Pathway -> Biomarker -> Dataset -> Outcome -> Contradiction`

The route may guide PubMed/dataset lookup, metadata closure, contradiction/null-result search, and report explanation. It cannot produce diagnosis, treatment, supplement, dose, or personal health recommendation language.

## Added lanes

- `CIRCADIAN_SLEEP_INTELLIGENCE`
- `METABOLIC_IMMUNE_LANE`
- `MITOCHONDRIAL_FATIGUE_LANE`
- `IMMUNE_AGING_IMMUNOSENESCENCE_LANE`
- `TOXIN_PLASTIC_ENVIRONMENT_EXPOSURE_LANE`
- `NUTRITION_MICRONUTRIENT_INTELLIGENCE`
- `HERBS_FOODS_EXPOSURE_CONTROL_LANE`

## Modular knowledge partitions

The layer avoids a single large knowledge block. It exposes a fast retrieval index across these small partitions:

- immune
- viral
- metabolic
- cardiovascular
- neurological
- endocrine_hpa
- mitochondrial
- nutrition
- drugs
- herbs_exposures
- longevity_biomarkers

## Biomarker dictionary strengthened

The route now recognizes and reports research biomarkers including CRP, IL-6, TNF-alpha, cortisol, glucose, HbA1c, insulin, HRV, blood pressure, VO2max, lipids, WBC/RBC, platelets, 25(OH)D, B12, zinc, selenium, iron/ferritin, magnesium, and omega-3 index.

## Required report fields

The UI/JSON report exposes:

- selected biological pathway
- why the system selected it
- required biomarkers
- missing data
- what would falsify the hypothesis
- next proposed search

## Linkage

The new report is wired into:

- `ResearchAutopilot`
- `DatasetForagingReport`
- `DatasetForagingJson`
- `BiomedicalKnowledgeGraphLinker`
- `IntegratedPathLinkageGuard`
- `LearningRulesUiSummary`
- `ResearchAutopilotActivity`
- `RuntimeModuleRegistry`
- `FinalReleaseStabilityGuard`
- static checks and release version linkage

## Safety boundary

`HealthAdviceClaimGuardV11046` blocks personal health-advice posture. Herbs, foods, vitamins, sleep, exercise, toxins, and environmental terms are treated as exposure/noise/control variables for research routing only.
