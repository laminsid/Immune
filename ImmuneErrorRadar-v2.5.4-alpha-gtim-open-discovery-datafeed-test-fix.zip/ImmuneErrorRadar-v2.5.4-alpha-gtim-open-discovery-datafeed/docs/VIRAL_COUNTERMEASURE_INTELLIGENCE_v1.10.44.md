# Viral Countermeasure Intelligence v1.10.44

Release: `1.10.44-alpha-viral-countermeasure-knowledge-graph`  
Claim limit: `viral_countermeasure_routing_only_not_wetlab_or_clinical_proof`

Adds a scientist/lab-facing research workflow inspired by vaccine discovery pipelines without exposing wet-lab protocols, manufacturing steps, viral engineering, or clinical recommendations.

## Connected layers
- Biomedical Research Ontology
- Biomedical Concept Bridge
- Modern Medical Technology Intelligence
- Evidence Prior Matrix
- EBV Criterion Lane
- Lead Closure / Metadata Closure
- Dataset accession routing
- Biomedical Dictionary/Database Linkage

## Hantavirus profile
The Hantavirus profile routes through identity, strain, antigen target prior, platform literature, evidence gates, and contradiction search. It remains a research prior until accession, strain scope, human relevance, control/comparator, time order, outcome labels and counter-evidence gates close.
