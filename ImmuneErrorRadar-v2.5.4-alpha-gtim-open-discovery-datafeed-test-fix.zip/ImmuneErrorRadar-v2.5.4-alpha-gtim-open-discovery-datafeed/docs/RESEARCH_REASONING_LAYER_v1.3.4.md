# Research Reasoning Layer v1.3.4

## Purpose

v1.3.4 adds a lightweight symbolic reasoning layer. It does not add ML, GNNs, Random Forests, or new biological axes. Its job is to make the autonomous researcher ask better questions after success or failure.

## Reasoning sequence

1. Observation — what happened in the cycle?
2. Interpreted meaning — what does the result/failure suggest?
3. Generated questions — what should be asked next?
4. Competing hypotheses — what alternative explanations remain possible?
5. Discriminator evidence — what evidence would separate them?
6. Search reframing — how should search level change?
7. Self-critique — what should not be believed yet?
8. Next reasoned move — the next autonomous action.

## Key rule

Learning remembers what happened. Reasoning decides what that result or failure means.

## Examples

If “regulatory brake” search fails, the engine should reason that the term may be too abstract and reframe toward IL-10, Treg, FOXP3, immune resolution, single-cell cell states, and outcome-labeled datasets.

If interferon/tissue-damage signals appear, the engine should keep competing explanations alive:

- early interferon supports recovery,
- late interferon contributes to damage,
- high viral load precedes delayed interferon,
- tissue damage may be driven by monocyte/neutrophil or TNF/IL-6 loops,
- regulatory brake failure may explain persistence.

## Boundary

This is a research reasoning layer only. It does not prove causality, diagnose, treat, predict protection, or recommend drugs.
