# Smart Report Integrity + Scope Discipline Locks — v1.3.5

## Purpose

v1.3.5 applies the v1.3.3 hard locks directly to the existing v1.3.4 research-reasoning baseline without adding new biology axes, ML models, diagnosis, treatment, or symptom-tracking behavior.

## Smart Report Integrity Lock

Every intelligent report must explicitly expose four fields:

1. Hypothesis
2. Supporting evidence
3. Counter-evidence / contradiction
4. What we do not believe yet

If any field is missing, the report is marked as rejected narrative polish by `SmartReportIntegrityLock`.

## Scope Discipline Lock

`ScopeDisciplineLock` blocks expansion wording such as diagnosis, treatment, random forest, patient prediction, new immune axis, and new biology axis. Recovery pivots must rotate evidence lane and vocabulary only.

## No-result recovery correction

The previous repeated-source fallback wording could imply `new_axis_pair_explore`. It is now replaced by:

- `REPEAT_TO_EVIDENCE_LANE_ROTATION`
- `evidence_lane_rotation`

This keeps the engine focused on contradiction search, negative controls, longitudinal outcome labels, and dataset verification using existing axes only.

## Acceptance rule

A cycle is useful only if it either:

- produces evidence plus an explicit contradiction/unknowns section, or
- honestly reports no support and generates a safer next autonomous move.
