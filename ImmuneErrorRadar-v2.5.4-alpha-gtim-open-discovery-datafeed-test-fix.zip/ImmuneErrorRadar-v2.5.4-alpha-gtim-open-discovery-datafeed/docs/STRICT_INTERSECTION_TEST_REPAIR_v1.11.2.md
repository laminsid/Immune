# Strict Intersection Test Repair v1.11.2

## Problem
GitHub unit tests failed at:

`MetadataClosureStrictIntersectionV11057Test > psychophysiologicalExposomeUnlocksAggressiveQueryStream`

The failing assertion expected:

`AGGRESSIVE_GEO_EXPOSOME_CYTOKINE_STREAM` contains `GSE[0-9]*`.

## Root cause
The v1.10.58/v1.11.1 Hyper-Drive Beta query used only:

`GSM[0-9]* OR SRP[0-9]*`

This was valid for sample/run-level extraction but violated the stricter v1.10.57 test contract for GEO aggressive stream discovery, which requires a series-level `GSE[0-9]*` surface.

## Repair
The Beta/aggressive accession pattern is now:

`GSE[0-9]* OR GSM[0-9]* OR PRJNA[0-9]* OR SRP[0-9]*`

This keeps GEO series, GEO sample, BioProject, and SRA study/run surfaces visible to the query generator.

## Claim boundary
This repair changes query generation only. It does not fabricate accessions, sample labels, gene expression values, fold changes, p-values, evidence objects, clinical predictions, diagnosis, treatment, supplement guidance, or causal claims.
