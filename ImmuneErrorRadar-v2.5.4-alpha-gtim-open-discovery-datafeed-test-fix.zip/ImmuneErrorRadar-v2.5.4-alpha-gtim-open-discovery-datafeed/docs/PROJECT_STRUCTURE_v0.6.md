# Project Structure v0.6

Inspired by the FennGuard maintenance style: small engines, explicit docs, static checks, GitHub workflow, and validation summaries.

## Android engines

- ResearchAutopilot.kt — internet search loop, source de-duplication, learning limits.
- ResearchKnowledgeStore.kt — cumulative local memory, findings, imported reports, source IDs.
- OmicsResearchAxis.kt — DNA/RNA text-axis helper.
- ResearchAutopilotActivity.kt — UI: Search + learn, Stop, import pasted/file report, copy short report.

## Research pipeline

- research/omics_bridge.py — DNA/RNA bridge detector for CSV matrices.
- research/immune_matrix_builder.py — builds immune-axis matrices.
- research/baseline_classifier.py — baseline research classifier.
- research/cross_condition_bridge.py — cross-condition bridge mining.

## Static checks

- scripts/run_static_checks.sh
- scripts/validate_json.py
- scripts/audit_kotlin_delimiters.py

## v0.7 additions

- `GutNutritionHormoneAxis.kt` — stomach acid, gut barrier/microbiome, nutrition/protein, muscle reserve, testosterone immune-modulation axes.
- `gut_nutrition_hormone_axis_rules_v0.1.json` — research rules for gut/nutrition/hormone hypotheses.
- `gut_metabolic_research_questions_v0.1.json` — seed questions for Research Autopilot.
- `research/gut_metabolic_hormone_bridge.py` — standalone Python classifier for gut/metabolic/hormone bridge candidates.
