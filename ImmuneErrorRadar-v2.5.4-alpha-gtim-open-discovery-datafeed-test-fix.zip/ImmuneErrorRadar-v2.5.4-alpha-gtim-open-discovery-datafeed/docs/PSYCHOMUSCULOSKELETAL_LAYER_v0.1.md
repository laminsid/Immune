# Psychomusculoskeletal Layer v0.1

Separates mechanical load, nerve flags, muscle guarding, and stress-amplified pain context.

## Inputs

- sitting/static posture hours
- heavy lifting
- sudden twist
- back/disc-like pain
- radiating leg pain
- numbness or weakness
- pain worse with stress/fear/tension

## Boundary

The app does not diagnose disc degeneration, disc herniation, nerve compression, or spinal disease.
