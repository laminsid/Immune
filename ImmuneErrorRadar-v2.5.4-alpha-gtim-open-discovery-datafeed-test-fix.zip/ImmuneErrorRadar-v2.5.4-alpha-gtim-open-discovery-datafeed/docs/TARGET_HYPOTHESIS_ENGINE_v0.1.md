# Target Hypothesis Engine v0.1 — Deferred Research Layer

This layer is intentionally documented but not activated in the Android APK.

## Allowed Output
- Candidate pathway involved
- Candidate biological target
- Public evidence references
- Existing drug class context
- Known uncertainty and risk
- Missing evidence

## Forbidden Output
- "Take this drug"
- "You need a TNF inhibitor"
- "This patient has cytokine storm"
- Any patient-specific treatment optimization

## Strategic Reason
The company-scale asset is not the APK. The APK is a local field collector and doctor-review pack. The defensible biotech asset is the ontology + longitudinal immune state dataset + validated classifier + target-hypothesis layer.
