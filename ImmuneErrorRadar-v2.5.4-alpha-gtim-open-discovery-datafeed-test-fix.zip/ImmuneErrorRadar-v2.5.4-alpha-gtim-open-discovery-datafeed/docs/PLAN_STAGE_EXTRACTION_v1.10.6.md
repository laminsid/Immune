# Immune Error Radar v1.10.6 — Plan Stage Extraction

This patch performs the first executable extraction from `ResearchAutopilot.runCycle` without a broad refactor.

## What changed

- Added `ResearchCyclePlanStage` as the last guard before network execution.
- Enforced directive budgets after query ranking and query-feedback rewriting.
- Added `cyclePlanStageReport` to JSON/PDF output.
- Added regression tests for narrow directives and offline-only directives.
- Updated runtime/schema version to `1.10.6-alpha-plan-stage-extraction` / schema `206`.

## Why it matters

Earlier versions had search locks, but the final query batch could still be shaped by several layers before reaching the network. v1.10.6 makes the final handoff explicit: the plan stage selects the exact query IDs allowed to leave PLAN and enter SEARCH.

## Non-goals

- No full `runCycle` rewrite.
- No ViewModel migration.
- No DTO serialization migration.
- No biological claim changes.
