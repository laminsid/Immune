# v1.10.9 — Source Rotation + No-Candidate Learning

Purpose: keep the v1.10.8 dataset-hunt unlock, but make failed dataset searches operationally useful.

## Changes

- Added `NoCandidateLearningRecord` to record source-family misses as learning objects.
- Added deterministic source rotation after no-candidate attempts:
  - `GEO_GDS` → `SRA_PRJNA`
  - `SRA_PRJNA` → `IMM_PORT_SDY`
  - `IMM_PORT_SDY` → `PUBMED_ACCESSION_MINING`
  - `PUBMED_ACCESSION_MINING` → `PUBMED_CONTRADICTION`
  - `PUBMED_CONTRADICTION` → `PUBMED_CONTROL`
- Added `IMM_PORT_SDY` and `PUBMED_ACCESSION_MINING` source routes.
- Added source-specific query templates for ImmPort/SDY and accession-mining.
- Updated persistent failure memory to use no-candidate records when choosing `forcedNextSource`.
- Updated report/UI/PDF output to display next source family after no-candidate failure.
- Preserved claim-safety: no hypothesis upgrade, causal claim, medical recommendation, or biological proof is created by source rotation.

## Expected report behavior

After a no-candidate GEO/GDS attempt, the report should show a next source recommendation:

```text
No-candidate learning:
• GEO_GDS → next SRA_PRJNA | missing accession_like_id
```

The next cycle should not return immediately to `THINK_FIRST` while no evidence object exists; it should run the next bounded source-family route.
