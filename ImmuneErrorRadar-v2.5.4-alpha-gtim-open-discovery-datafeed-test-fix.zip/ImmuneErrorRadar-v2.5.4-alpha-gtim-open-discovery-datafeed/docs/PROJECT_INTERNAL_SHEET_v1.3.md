# Project Internal Sheet — v1.3

## Identity

Immune Error Radar is a private global immune-intelligence research engine. It studies immune triggers, response axes, tissue outcomes, and recovery/failure patterns using public datasets and literature metadata.

## Current core

- Research Autopilot
- Research Steering
- Evidence Quality / Causality / Negative Controls
- Research Lock System
- Global Immune Dataset Intelligence

## v1.3 decision

Do not expand into heavy ML. Build dataset discovery and global immune mechanism mapping first.

## Main objects

- ResearchFinding
- HypothesisObject
- PublicDatasetCandidate
- ImmuneAxisSummary
- TriggerResponseEdge
- GlobalHypothesisLead
- AntiviralResponseNote

## First global priority

Find human longitudinal viral-response datasets with:

- interferon timing
- viral load or exposure timing
- cytokines / RNA-seq / single-cell data
- tissue damage or severity labels
- recovery vs deterioration outcomes

## Current rule

No claim about immune enhancement, antiviral protection, or variant resilience without a dataset-backed trigger-response-outcome chain.
