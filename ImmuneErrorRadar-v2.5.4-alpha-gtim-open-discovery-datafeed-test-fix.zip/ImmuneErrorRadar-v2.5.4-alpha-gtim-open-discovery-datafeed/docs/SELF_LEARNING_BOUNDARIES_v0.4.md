# Self-Learning Boundaries

The system can learn in three safe ways:

1. Literature learning: save public research leads and bridge hypotheses.
2. Local pattern learning: compare repeated private cases over time.
3. Dataset learning: offline Python pipeline builds matrices from public datasets.

It must not learn by:

- Inferring treatment from one case.
- Claiming psychological root cause from stress alone.
- Treating correlation as causality.
- Auto-changing medical thresholds without review.
- Uploading private case data.

Rule: every new link is stored as hypothesis-grade until manually promoted.
