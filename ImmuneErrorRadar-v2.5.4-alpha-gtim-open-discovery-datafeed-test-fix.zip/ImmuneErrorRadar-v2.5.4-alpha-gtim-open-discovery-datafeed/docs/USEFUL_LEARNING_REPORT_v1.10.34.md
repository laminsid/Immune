# v1.10.34 — Useful Learning Report

Release: `1.10.34-alpha-useful-learning-report`

This release makes every single-topic immune-lens search useful even when no `EvidenceObject` exists.

## What changed

- **Learning Value Score**: measures research progress without treating it as scientific proof.
- **Topic Memory Ledger**: stores each user topic as a resumable immune research thread.
- **Lead Inspection Queue**: turns weak/near-miss/manual leads into explicit follow-up items.
- **Progress without EvidenceObject**: recognizes useful outcomes such as `topic_stored`, `weak_lead_preserved`, `gap_queue_created`, and `query_strategy_changed`.
- **Three-layer report**: short UI summary, one-page research report, and technical appendix in Export/Advanced.

## Claim lock

The following remain blocked unless an EvidenceObject and metadata gates exist:

- biological proof
- causal claim
- diagnosis
- treatment recommendation
- drug ranking
- hypothesis upgrade

`Progress without EvidenceObject` is research progress only.
