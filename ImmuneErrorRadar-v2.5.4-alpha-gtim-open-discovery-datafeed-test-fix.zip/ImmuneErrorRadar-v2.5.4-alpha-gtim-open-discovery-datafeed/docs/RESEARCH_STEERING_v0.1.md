# Research Steering v0.1

Research Steering lets the private user direct the Research Autopilot without editing code.

## Inputs

- Variables: comma/semicolon/pipe/newline separated terms.
- Focus question: what relationship should be tested.
- Required context terms: optional constraints that must appear in generated queries.
- Excluded terms: terms to avoid.

## Behavior

1. The active steering profile is saved locally.
2. The next Search + learn cycle reads the active profile.
3. The engine generates directed PubMed bridge queries from the variables.
4. Steered queries are prioritized before default queries.
5. Findings matching steered axes/terms get a novelty boost.
6. Reports show the active steering profile and the number of steered queries generated.

## Research boundary

A steering variable is not evidence. It is a search instruction.
The report must continue to separate:

- variable
- trigger candidate
- amplifier candidate
- maintainer candidate
- marker candidate
- coincidence / weak link
- unknown

## Example

Variables:

```text
histamine, low blood pressure, stress, mast cell, stomach acid, testosterone, RNA-seq
```

Focus question:

```text
Does stress-amplified allergy connect to blood-pressure drops through mast-cell/histamine pathways, and is the pattern modified by gut acid or hormone state?
```

Generated search shapes:

```text
"histamine" AND "low blood pressure"
"stress" AND "mast cell"
"stomach acid" AND "testosterone"
"RNA-seq" AND "mast cell"
```

The result remains hypothesis-only until repeated data supports a temporal and biological pattern.
