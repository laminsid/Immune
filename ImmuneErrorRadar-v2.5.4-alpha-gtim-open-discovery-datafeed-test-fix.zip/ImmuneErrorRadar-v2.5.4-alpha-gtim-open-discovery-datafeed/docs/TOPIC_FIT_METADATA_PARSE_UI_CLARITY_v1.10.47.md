# Topic-Fit Metadata Parse UI Clarity v1.10.47

This patch keeps the v1.10.46 safety posture but reduces operational stalling.

## Problem fixed

The engine could preserve weak leads and block unsafe claims, but it sometimes replayed stale mature-domain priors and showed technical learning as if it were useful discovery. Candidate sets could also remain unparsed when all candidates were off-route.

## New decision order

1. Read the user's topic and research steering.
2. Select a preferred topic-fit lane.
3. Suppress stale mature-domain priors when topic-fit is low.
4. Force minimum metadata visibility when there are enough candidates but zero parsing decisions.
5. Keep hypothesis upgrade blocked until EvidenceObject gates pass.
6. Display Learning, Discovery, and Evidence separately.

## Output card

The user-facing report should start with:

- Topic.
- Selected route.
- Why the route was selected.
- Learning status.
- Discovery status.
- Evidence status.
- Missing gates.
- Invalidators.
- Next action.

## Claim limit

`topic_fit_metadata_parse_ui_clarity_not_biological_proof`

This means the layer guides search and report clarity only. It is not diagnosis, treatment, causal proof, drug ranking, supplement recommendation, or discovery confirmation.
