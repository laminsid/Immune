# Route Reconciliation + Evidence Candidate Activation v1.10.51

## Problem fixed
v1.10.50 successfully connected the exposome and topic-route correction layers, but some legacy report surfaces still printed old mature-domain route text. This created a trust problem: the decision layer selected the correct route, while the appendix could still display stale route language.

## Design
`RouteReconciliationEvidenceCandidateV11051` provides one canonical bridge:

`Corrected topic route -> reconciled legacy focus -> reconciled query seed -> comparator-hunt queries -> EvidenceObjectCandidate work queue`

## EvidenceObjectCandidate rule
An EvidenceObjectCandidate may be created only when metadata is useful but still not enough for evidence:

- metadata score >= 70
- outcome labels or contrastive slots exist
- control/comparator is missing
- usability is not `USABLE_FOR_TEST`

The candidate remains blocked by control/comparator and contradiction/null-result gates.

## Comparator Hunt execution
Comparator Hunt emits concrete query seeds for:

- healthy control
- matched control
- placebo
- responder vs non-responder
- baseline
- exposed vs unexposed
- untreated
- negative control
- no association / heterogeneity / failed replication

## No-islands contract
The layer is linked through:

- `TopicFitMetadataParseUiClarityV11047`
- `DatasetForagingJson`
- `DiscoveryReportExporter`
- `ResearchAutopilotActivity`
- `ResearchReportV3Builder`
- `ResearchAutopilot` learning notes
- `RuntimeModuleRegistry`
- `EngineRuntimeStatus`
- `ReleaseVersionLinkageGuard`
- release docs and static audits

## Claim boundary
This is routing/report hygiene and evidence-work-queue creation only. It is not biological proof.
