# Global Research Brief Report v1.10.61

Purpose: make the final user/export report concise, reviewer-grade, and suitable for serious biomedical research triage without exposing the full runtime trace by default.

## Changes

- Adds `GlobalResearchGradeBriefV11061`.
- Main UI summary now uses the global research-grade brief.
- PDF export now outputs a compact one-page discovery brief by default.
- Full technical traces remain available through Advanced/internal report paths, not the final report.
- Keeps the safety boundary: research leads only, no diagnosis, treatment, dose, supplement, or causal claim.

## Required properties

- Must expose evidence grade, accessions/evidenceObjects count, score separation, route, primary finding, blocking gap, contradiction status, next discriminating action, hard gates, and boundary.
- Must not fabricate accession IDs or evidence objects.
- Must remain compatible with v1.10.56-v1.10.60 Metadata Closure / Strict Intersection / Hyper-Drive layers.
