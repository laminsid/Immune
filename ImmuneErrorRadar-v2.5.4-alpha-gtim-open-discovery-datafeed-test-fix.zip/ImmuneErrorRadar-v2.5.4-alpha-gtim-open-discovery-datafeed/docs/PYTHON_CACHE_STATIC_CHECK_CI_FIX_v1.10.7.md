# v1.10.7 CI fix — Python cache artifact cleanup

## Problem
Some generated release ZIPs contained `scripts/__pycache__` from local audit runs. `run_static_checks.sh` correctly failed with `Python cache artifacts found in release tree`, even though the Kotlin/app code was not affected.

## Fix
`run_static_checks.sh` now removes transient `__pycache__` directories and `*.pyc` files at startup before running source audits. The release ZIP is also packaged with these artifacts excluded.

## Scope
No runtime logic changed. This is a CI/static-check packaging fix only.
