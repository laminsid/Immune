# Lead Closure Handoff v1.10.35

Release: `1.10.35-alpha-lead-closure-learning-rules`

## Purpose

This patch prevents a weak or off-route dataset lead from being lost between cycles. When a prior report contains a weak dataset lead, a near-miss accession, an off-route dataset, or an open secondary-lookup item, the next cycle is forced into lead closure instead of broad search.

## Decision contract

Allowed next moves after a weak lead:

1. `LEAD_OBJECT_SECONDARY_LOOKUP`
2. `MINIMUM_METADATA_CLOSURE`
3. `ARCHIVE_OR_COOLDOWN_WITH_EXPLICIT_REASON`

Blocked moves:

- broad PubMed exploration before closure
- hypothesis upgrade before an EvidenceObject
- causal, diagnostic, treatment, or drug-ranking language
- EBV/HHV-6/CMV claims without explicit dataset evidence

## Metadata Closure Agent

The closure agent tracks these fields exactly:

- accession
- human_or_patient_data
- sample_size
- condition_labels
- outcome_labels
- control_or_comparator
- time_order
- tissue_or_cell_context
- license_access
- data_availability_text

The report exposes both closed and missing fields so the UI can show what was learned and what still blocks evidence.

## Unknown Route Classifier

Off-route or unknown-route leads are classified as route priors only, never as biological proof. Supported priors:

- type2_allergy_mast_cell_route
- autoimmune_flare_route
- interferon_antiviral_route
- latent_virus_reactivation_route
- drug_perturbation_route
- stress_immune_psychoneuro_route
- barrier_tissue_route
- rna_transcriptomic_state_route

EBV, HHV-6, and CMV vocabulary is allowed only inside `latent_virus_reactivation_route` as `ROUTE_PRIOR_ONLY_NOT_EVIDENCE`.

## UI learning summary

The compact UI report now exposes:

- what changed in the current cycle
- which metadata fields were closed or missing
- selected route prior and confidence
- lead handoff state
- pinned rules saved by the engine

## Claim limit

`lead_closure_handoff_not_biological_proof`
