# Runtime Hardening Coverage v1.10.1

This file tracks the requested error list so the fixes do not disappear across future versions.

## P0 — implemented
1. HTTP errors now throw; HTTP 429 has `NcbiRateLimitException`.
2. Retry path uses suspend functions and coroutine `delay()`; `Thread.sleep` is forbidden by audit.
3. Placeholder `.local` NCBI email removed; contact email is supplied by `SecureNcbiCredentialStore`, defaulting to `research@vraimony.com`.
4. NCBI request rate limiter added: ~3 req/s without key, ~10 req/s with key.
5. User-Agent now uses `EngineRuntimeStatus.ACTIVE_ENGINE_VERSION` dynamically.
6. `AxisMatcher` now uses precompiled word-boundary regex rules.
7. Streams use explicit UTF-8.
8. Null error streams are safe; non-2xx still throws typed exceptions.

## P1 — implemented or guarded
9. Knowledge ledger hot path changed to append-only + periodic trim.
10. Last-N reads use `RandomAccessFile` tail reads.
11. JSONL validation uses `JSONObject(line)`; rejected lines are logged via `Log.w` with counters.
12. Report/imported/finding hot reads no longer depend on full-file scans for latest-N operations; finding seen IDs remain cached and updated.
13. File reads/writes go through per-file locks.
14. HTTP/JSON/rate-limit errors are typed and added to execution diagnostics.
15. Executed query IDs use a `MutableSet`.
16. Release build now enables minify/resource shrink and ProGuard rules.
17. ViewBinding is enabled for staged migration.
18. Gradle version aligned to 8.10.2; wrapper bootstrap/properties added. Official wrapper JAR was not generated locally because Gradle/DNS were unavailable.
19. NCBI API key moved to encrypted shared preferences with legacy plaintext migration/deletion.
20. Network security config added; cleartext disabled and NCBI domains scoped to HTTPS.

## P2 — partially implemented safely
21. Legacy `ResultActivity` and `activity_result.xml` removed.
22. Dead personal-profile model files removed after reference check: `ImmuneSignalEngine`, `HypothesisEngine`, `LongevityHypothesisEngine`, `PsychomusculoskeletalLayer`, `PsychoneuroimmuneLayer`, `AllergyAgingBridge`, `AutonomicVascularLayer`, `AgingImmuneAxis`, `CauseEvidenceLedger`, `CausalOriginEngine`, `GutNutritionHormoneAxis`, `AutonomousResearcher`.
23. `ACTIVE_MODULES` kept for compatibility but runtime-hardening modules were added; full `Module` interface migration deferred to avoid breaking existing audits.
24. `ResearchCycleReport` god-DTO split deferred; schema moved to 201 and top-level calibration flag added.
25. Serialization migration deferred because it touches nearly every report export path.
26. `runCycle` was hardened and converted to suspend; full Plan/Search/Score/Reason/Persist split deferred.
27. Retrofit/OkHttp migration deferred; hardened `HttpURLConnection` retained to avoid adding a large networking migration in same patch.
28. ViewBinding enabled; full ViewModel migration deferred.
29. Activity state-machine migration deferred.
30. Versioned class renaming deferred to avoid breaking static audits and report continuity.
31. DatasetForaging `copy()` cleanup deferred.
32. `run_static_checks.sh` retained but patched; Detekt added as the forward path.

## P3 — implemented or started
33. Full strings.xml migration deferred; new runtime/privacy copy was added in UI.
34. Button content descriptions added to Research Autopilot layout.
35. Detekt config added with forbidden `Thread.sleep` rule.
36. AxisMatcher boundary regression test added.
37. ResearchKnowledgeStore is guarded by runtime hardening audit; full temp-dir JVM tests require Android/Robolectric setup.
38. Instrumented UI tests deferred until Android Gradle build is available.
39. Versioned test renaming deferred.
40. Changelog consolidation deferred; new v1.10.1 changelog added under docs.
41. Java 17 retained for AGP/Kotlin compatibility; downgrade deferred.
42. Report JSON now includes `calibration = uncalibrated_heuristic`; findings add heuristic calibration flag.
43. Abstract text is not appended when absent/failed.
44. Abstract truncation is flagged with `ABSTRACT_TRUNCATED`.
45. UI now warns that NCBI network searches may be logged with IP; offline thinking remains local.

## Verification commands run locally
- `python3 scripts/audit_runtime_hardening_v1101.py` — PASS
- `python3 scripts/audit_kotlin_delimiters.py` — PASS
- `python3 scripts/validate_json.py` — PASS
- `python3 scripts/audit_cognitive_bridge_helpers.py` — PASS
- AxisMatcher isolated compile/run — PASS
- `bash -n scripts/run_static_checks.sh` — PASS

## Local build limitation
A full Gradle/Android build was not run in this sandbox because Gradle is not installed and DNS resolution to `services.gradle.org` failed. GitHub/Android CI remains the compile gate.
