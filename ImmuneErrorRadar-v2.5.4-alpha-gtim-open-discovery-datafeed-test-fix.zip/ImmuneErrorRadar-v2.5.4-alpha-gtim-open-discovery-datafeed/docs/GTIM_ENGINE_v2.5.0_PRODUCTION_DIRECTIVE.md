# GTIM-Engine v2.5.0 Production Directive

Current unified runtime: `2.5.4-alpha-gtim-open-discovery-datafeed`  
This document remains the original product directive; runtime/version linkage is now unified under v2.5.4.

## Product identity
GTIM-Engine is a global translational immunology and discovery dossier engine for research labs, precision-medicine investigators, biotech teams, and professors. It is a scientific hypothesis foundry: it turns fragmented immunology evidence into corpus-relative, falsifiable mechanism dossiers for the next laboratory experiment.

## Integrated path, not an isolated island
The v2.5 surface is wired into the existing v1.11.5 mechanism dossier path:

`ResearchGradeMechanismDossierV1110 -> GTIMDiscoveryDossierV250 -> DatasetForagingJson -> GlobalResearchGradeBriefV11061 -> ResearchAutopilotActivity`

It does not bypass accession validation, comparator extraction, matrix readiness, source metadata enrichment, contradiction search, or claim boundaries.

## Scope
GTIM maps research-grade mechanism candidates across:

- viral immunology and post-infectious immune dysregulation
- drug and immunomodulator response mapping
- antibiotic, microbiome, and host immune-response intersections
- allergy and hypersensitivity pathomechanisms
- exposure, longevity, metabolic, mitochondrial, and immune-aging research routes

## Claim boundary
GTIM does not diagnose, treat, recommend doses/supplements, predict patient outcomes, or make clinical-utility claims. It produces research hypotheses only.

## Novelty rule
Novelty is corpus-relative. The engine may say that an inspected corpus did not directly test a route. It must not claim that a mechanism has never been proposed in history unless a separately audited corpus search supports that claim.

## Data scarcity mitigation
When human matrices are scarce, GTIM can use:

- cross-species ortholog reasoning as auxiliary plausibility only
- reference-control priors for orientation only
- NLP-mined biomarker/cytokine/cell-type signals as weak leads only
- 2-hop/3-hop knowledge-graph bridges as mechanism candidates only

None of these can confirm a human mechanism.

## Output contract
Each candidate must expose:

- evidence object map
- connected dots map
- corpus-relative novelty statement
- confidence index S_c
- contradiction/null-result search
- matrix/comparator readiness status
- falsifiability and lab-validation plan
- what would falsify the hypothesis
- claim boundary

## Google Play / review posture
The application remains research-only and uses user-started network access for literature/dataset discovery. The GTIM upgrade adds no new sensitive permissions, telemetry, background services, package visibility, location, camera, microphone, SMS, call logs, or contact access.
