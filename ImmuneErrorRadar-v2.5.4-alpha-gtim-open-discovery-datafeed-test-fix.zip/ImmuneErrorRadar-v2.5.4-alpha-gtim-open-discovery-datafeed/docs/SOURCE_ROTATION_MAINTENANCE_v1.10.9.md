# v1.10.9 source-rotation maintenance

This maintenance pass stabilizes the source-rotation/no-candidate learning work.

## Fixes

- Updated the cooldown-escape regression test to include all v1.10.9 source families: `GEO_GDS`, `SRA_PRJNA`, `IMM_PORT_SDY`, `PUBMED_ACCESSION_MINING`, `PUBMED_CONTRADICTION`, and `PUBMED_CONTROL`.
- Preserved a deterministic cooldown escape: `PUBMED_ACCESSION_MINING_COOLDOWN_ESCAPE` when all normal direct routes are cooling down.
- Added no-candidate query feedback bridging: a failed source attempt now creates a visible query-feedback signal even when no normal post-forager query batch survives.
- Kept the claim boundary unchanged: no-candidate feedback is routing-only and cannot upgrade biology.

## Expected behavior

After a `GEO_GDS` no-candidate result, the next report should prefer `SRA_PRJNA` rather than repeat GEO/GDS or return immediately to `THINK_FIRST`.
