# Psychoneuroimmune Layer v0.1

Captures stress, sleep, emotional load, and rapid-breathing context as possible modifiers of immune/airway/inflammatory patterns.

## Inputs

- stress today 0–10
- stress last 7 days 0–10
- sleep/recovery quality 0–10
- major emotional event
- panic/rapid breathing

## Output

Psychoneuroimmune stress axis 0–100.

## Boundary

The output does not prove psychological causation. It only marks possible amplification or maintenance context.
