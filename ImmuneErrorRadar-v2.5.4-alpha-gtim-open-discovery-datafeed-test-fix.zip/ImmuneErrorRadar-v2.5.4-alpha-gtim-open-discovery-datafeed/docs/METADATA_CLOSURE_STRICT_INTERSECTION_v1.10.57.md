# Metadata Closure Strict Intersection v1.10.57

## Purpose

v1.10.57 resolves the operational problem where useful manual/off-route snippets remained low-priority because they did not fit the prior route. It adds strict cross-family intersection checks during Minimum Metadata Probe.

## R1 — Neuro-Viral Bridge

Trigger:

```text
Family_Viruses(EBV OR HHV-6)
AND Family_Pathologies(SLE OR MS OR ME/CFS)
AND (transcriptome OR RNA-seq)
```

Runtime effect:

```text
routeFitFloor >= 85
validationEmbargoBypassScope = metadata_probe_and_query_priority_only_no_claim_upgrade
```

Programmatic streams:

```text
GEO_GDS::(EBV OR HHV-6) AND (SLE OR multiple sclerosis OR ME/CFS) AND (transcriptome OR RNA-seq) AND (GSE[0-9]* OR GSM[0-9]* OR GPL[0-9]*)
SRA_BIOPROJECT::(EBV OR HHV-6) AND (SLE OR multiple sclerosis OR ME/CFS) AND (RNA-seq OR transcriptome) AND (PRJNA[0-9]* OR SRP[0-9]* OR SRR[0-9]*)
```

## R2 — Psychophysiological Exposome

Trigger:

```text
(HPA-axis OR Cortisol/DHEA OR Sleep-deprivation)
AND (IFN-alpha OR IL-6 OR TNF-alpha)
```

Runtime effect:

```text
AGGRESSIVE_QUERY_STREAM unlocked
validationEmbargoBypassScope = aggressive_query_stream_only_no_claim_upgrade
```

Programmatic streams:

```text
GEO_GDS::(HPA-axis OR cortisol OR DHEA OR sleep-deprivation) AND (IFN-alpha OR IL-6 OR TNF-alpha) AND (transcriptome OR RNA-seq OR gene expression) AND (GSE[0-9]* OR GSM[0-9]*)
SRA_BIOPROJECT::(HPA-axis OR cortisol OR DHEA OR sleep-deprivation) AND (IFN-alpha OR IL-6 OR TNF-alpha) AND (RNA-seq OR transcriptome) AND (PRJNA[0-9]* OR SRP[0-9]* OR SRR[0-9]*)
```

## Runtime gates

- `G6_NEURO_VIRAL_STRICT_INTERSECTION_ELEVATION`
- `G7_PSYCHEPHYSIOLOGICAL_EXPOSOME_AGGRESSIVE_STREAM`

## Guardrail

The strict intersection layer is routing-only. It may elevate route-fit and unlock targeted accession mining, but it cannot upgrade hypotheses or generate clinical claims.

## Current compatibility note

Metadata Closure Strategy Matrix v1.10.61 keeps the v1.10.57 strict-intersection contract active under the current GitHub CI route/audit unification train.
