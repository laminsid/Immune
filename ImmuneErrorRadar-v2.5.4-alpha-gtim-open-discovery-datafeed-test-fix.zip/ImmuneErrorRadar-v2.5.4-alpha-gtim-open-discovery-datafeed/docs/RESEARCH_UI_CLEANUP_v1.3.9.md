# Immune Error Radar v1.3.9 — Research-first UI Cleanup

## Decision
The former daily scan / symptom intake first page has been removed from the launcher flow.
The app now opens as a private autonomous research engine, not a personal health tracker.

## Primary user flow
1. Search public research and dataset signals.
2. Judge evidence, contradiction, controls, and dataset readiness.
3. Learn by saving incidents, root causes, preventive gates, lane cooldowns, and next actions.

## UI changes
- New research command center launcher.
- New professional autonomous researcher screen.
- Visible live state: idle, searching, learning saved, stopping, failed.
- Concise screen report: Search / Evidence / Learning / Next action.
- Full details remain available in PDF export.

## Safety boundary
No diagnosis, treatment, disease prediction, drug ranking, or clinical recommendation is generated.
