# Learning Rules + Domain Query Activation v1.10.21

This release repairs integration gaps rather than adding another large reasoning layer.

## Included
- Fixes false stagnation when pivotType is `NO_PIVOT`.
- Runs anti-stagnation queries only under real stagnation pivots.
- Unifies STRONG_SIGNAL thresholds through `ResearchPolicyLock` / `RuntimeFeatureFlags`.
- Caps epistemic belief inflation at 60 prioritized beliefs.
- Keeps source-priority arbitration accession-first without duplicate repaired routes.
- Routes BROAD evidence-lane rotation through MECHANISM before CONTRADICTION.
- Renames no-change delta to `stable_no_change`.
- Activates learning-rules as query/falsification priors only.
- Reuses mature domain expertise vocabulary inside dataset queries.
- Adds route fingerprint replay guard, knowledge-gap tasks, dynamic graph proposals, contradiction templates, and evidence decay.

## Claim lock
All new intelligence is routing-only. It cannot create diagnosis, treatment, dosage, drug ranking, clinical recommendation, causal proof, or biological proof.
