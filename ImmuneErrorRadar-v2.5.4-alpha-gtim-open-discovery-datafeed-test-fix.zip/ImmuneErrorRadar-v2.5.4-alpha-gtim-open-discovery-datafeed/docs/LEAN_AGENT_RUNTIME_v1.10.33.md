# v1.10.33 — Lean Agent Runtime

Release: `1.10.33-alpha-lean-agent-runtime`

## Purpose

Add a lightweight deterministic orchestrator without creating a permanent LLM-style agent. The runtime only selects necessary micro-agents, applies hard gates, saves deltas, and emits a compact decision card.

## Micro-agents represented

- `LeadForager`
- `AccessionTextHarvester`
- `ManualSeedParser`
- `DatasetCandidateBuilder`
- `MetadataGateChecker`
- `DomainExpertiseUpdater`
- `RouteFingerprintChecker`
- `ReportConsistencyGuard`

## Hard gates

- accession pattern gate
- PMID / DOI pattern gate
- metadata presence gate
- outcome / control / time gate
- archive allowed gate

## Runtime principle

No continuous reasoning. The system reasons only when events require it:

- `WEAK_LEAD_FOUND` → save lead, no claim
- `ACCESSION_FOUND` → parse metadata
- `OUTCOME_MISSING` → queue outcome-label probe
- `MATURE_DOMAIN` + failed core sources → focused mature-domain probe
- `REPLAY_ROUTE_DETECTED` → rewrite or block route
- `MANUAL_SEED_AMBIGUOUS` → secondary lookup allowed

## Claim lock

`lean_agent_runtime_routing_only_not_biological_proof`
