# Source Priority + Domain Expertise v1.10.19

v1.10.19 adds two linked controls.

## 1. Source Priority Arbitration

During `DATASET_HUNT` and `NO_ACCESSION`, accession-capable sources stay ahead of creative continuation, contradiction, control, and adjacent-domain exploration.

Core accession order:

1. `GEO_GDS`
2. `SRA_PRJNA`
3. `IMM_PORT_SDY`
4. `PUBMED_ACCESSION_MINING`

Adjacent and secondary lanes can still run, but they cannot override a missing core accession source while no dataset handle exists.

Claim limit: `source_priority_arbitration_not_biological_proof`.

## 2. Domain Expertise Memory

Exploration should not throw away useful learning after every no-candidate cycle. The system now stabilizes domain-level research priors and vocabulary as expertise tracks.

Initial domain tracks:

- Antihistamines / histamine / mast-cell axis
- Inflammatory disease / chronic inflammation
- Drug perturbation / medication exposure
- Aging / immunosenescence / inflammaging
- Diabetes / metabolic inflammation
- Gastric acid / reflux / gut-barrier

These tracks are retained as research priors only. They cannot create treatment advice, dosage, drug ranking, clinical recommendation, causal language, or hypothesis upgrade.

Claim limit: `domain_expertise_memory_not_biological_proof`.

## Operating rule

Freedom is allowed in exploration and domain learning. Strictness remains mandatory in claims.

A domain can become an expertise track before it becomes evidence. Evidence still requires accession, metadata, outcome labels, control/comparator, and time-order gates.
