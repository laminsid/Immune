# Python Research Pipeline v0.4

The `research/` folder adds a desktop-side bridge for public dataset work.

Files:

- `dataset_registry_loader.py` — validates dataset registry.
- `marker_dictionary.py` — canonical marker map.
- `unit_normalizer.py` — refuses unsafe unknown unit conversion.
- `immune_matrix_builder.py` — builds first immune-axis matrix.
- `baseline_classifier.py` — interpretable rule baseline.
- `cross_condition_bridge.py` — finds bridge candidates.

Near-term target:

Test whether a shared immune-axis vector can separate:

- Type-2 allergy dominant states.
- RA/TNF/IL-6 inflammatory states.
- Hyperinflammatory states.
- Stress/musculoskeletal amplification states.

Success is not medical accuracy. Success is proof that the vector carries separable biological signal worth deeper research.
