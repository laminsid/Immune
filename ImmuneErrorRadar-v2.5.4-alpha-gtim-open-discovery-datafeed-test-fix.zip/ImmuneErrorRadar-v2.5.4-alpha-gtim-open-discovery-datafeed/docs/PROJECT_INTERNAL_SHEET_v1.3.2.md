# Project Internal Sheet v1.3.3

## Current identity

Immune Error Radar is a private global immune intelligence research engine. Android is the control panel; public biomedical datasets/literature are the research substrate.

## Current law

Autonomous researcher mode is default. Steering is optional. Evidence locks remain mandatory.

## Main loop

Public sources → immune axes → trigger-response-outcome graph → hypothesis ledger → lock system → short discovery report.

## Active engines

- Research Autopilot
- Research Lock System
- Global Immune Dataset Intelligence
- Autonomous Research Planner
- Evidence/Causality/Negative Control modules
- Dataset / Axis / Trigger-response helpers in `research/`

## Current priority

Do not add new biological domains. Improve autonomous search strategy, report usefulness, and source quality.

## Hard exclusions

- No diagnosis.
- No treatment.
- No drug selection.
- No protection claims against viral variants.
- No heavy ML before curated datasets are available.
