# Static check compatibility fix — v1.10.7 CI patch

## Problem
`scripts/run_static_checks.sh` still contained legacy fixed-token checks for `schemaVersion", 204` inside several historical v1.7–v1.9 audit blocks.

The application schema has advanced to `207` in v1.10.7, so the static check failed even though the current model serialization contains `schemaVersion` correctly.

## Fix
The legacy string checks were changed from a fixed schema value token to a generic `schemaVersion",` token. This keeps the historical audit intent — verifying that model JSON includes a schemaVersion field — without forcing an old schema number.

## Scope
No runtime logic, research logic, model field, network behavior, or UI behavior was changed.
