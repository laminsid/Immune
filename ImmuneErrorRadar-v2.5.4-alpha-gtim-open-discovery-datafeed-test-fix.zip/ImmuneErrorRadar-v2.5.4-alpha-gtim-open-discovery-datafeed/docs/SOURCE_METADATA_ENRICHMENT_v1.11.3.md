# Accession Validation Comparator Extraction v1.11.4

## Purpose

This layer converts weak or off-route leads into repository-specific metadata work items instead of pretending that a manual snippet is a confirmed dataset accession.

## Key gates

- `ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED`
- `ACCESSION_TEXT_FOUND_METADATA_LOOKUP_REQUIRED`
- `ACCESSION_VALIDATED_METADATA_ENRICHMENT_REQUIRED`
- `COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT`
- `DGE_NOT_READY_METADATA_GAP`
- `HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION`

## Source-specific parser routes

- `GEO_SERIES_SAMPLE_MATRIX_PARSER`
- `SRA_BIOPROJECT_RUN_TABLE_PARSER`
- `ARRAYEXPRESS_IDF_SDRF_PARSER`
- `IMMPORT_STUDY_ARM_PARSER`
- `GENERIC_ACCESSION_METADATA_PARSER`

## EvidenceObject rule

An EvidenceObject is not created unless a real accession is present and the metadata closes sample labels, comparator/control structure, matrix availability, and required context fields.

## Claim boundary

Research-data engineering only. No clinical claim, diagnosis, treatment, patient prediction, DGE result, fold-change, p-value, or cytokine effect may be invented.
