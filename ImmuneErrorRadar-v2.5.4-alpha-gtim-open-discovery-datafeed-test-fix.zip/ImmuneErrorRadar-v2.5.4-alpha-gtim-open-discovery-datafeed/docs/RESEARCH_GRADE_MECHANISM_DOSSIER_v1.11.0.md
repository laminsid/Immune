# Research-Grade Mechanism Discovery Dossier — v1.11.0

## Purpose

v1.11.0 transitions Immune Error Radar from accession foraging to translational evidence mapping while remaining a biomedical research-data engineering layer only.

## Added runtime objects

- `AccessionCandidateCardV1110`
- `ComparatorMappingCardV1110`
- `MechanismRouteProposalV1110`
- `ResearchGradeMechanismDossierReportV1110`

## Key gates

- `HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION`
- `COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT`
- `DGE_NOT_READY_METADATA_GAP`
- `DGE_READY_FOR_CONTROLLED_REVIEW` only when matrix, metadata, comparator, case labels, tissue/cell context, time/order, and outcome labels close.

## Output boundary

The layer may output:

- research question
- accession candidate cards
- comparator map
- matrix readiness
- mechanism route proposal
- contradiction/null-result search terms
- blocking gaps
- next decisive action

It must not output:

- diagnosis
- treatment advice
- dose or supplement recommendation
- drug ranking
- patient flare prediction
- causal claim
- clinical utility claim
- breakthrough claim
- gene fold-change, p-value, or cytokine effect without real matrix analysis

## Release linkage

- versionCode: 124
- versionName: `1.11.0-alpha-research-grade-mechanism-dossier`
- active engine: `v1.11.0-alpha-research-grade-mechanism-dossier`
- learning schema: `1.11.0`
