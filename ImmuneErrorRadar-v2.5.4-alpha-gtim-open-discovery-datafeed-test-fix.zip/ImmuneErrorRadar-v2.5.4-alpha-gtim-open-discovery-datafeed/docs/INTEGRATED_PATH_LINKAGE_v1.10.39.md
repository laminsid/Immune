# Integrated Path Linkage v1.10.39

`v1.10.39-alpha-final-path-linkage-release` links the final release-era layers into one auditable decision surface.

## Linked layers
- Dataset path/pass coverage
- Learning/domain handoff
- Manual/weak lead linkage
- Lead closure handoff
- Metadata closure
- Unknown-route classifier
- EBV criterion lane
- Evidence Prior Matrix

## Operating rule
The system must not continue broad search while a weak/off-route lead still has open accession, control/comparator, time-order, or outcome metadata.

## Claim boundary
Integrated path linkage is routing integrity only. It is not biological proof, not EBV confirmation, not molecular mimicry confirmation, and not treatment guidance.
