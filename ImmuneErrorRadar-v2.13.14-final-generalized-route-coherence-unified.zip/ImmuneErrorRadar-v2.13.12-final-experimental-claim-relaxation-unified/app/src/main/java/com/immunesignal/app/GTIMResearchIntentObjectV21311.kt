package com.immunesignal.app

/**
 * v2.13.14 — Evidence-first route discovery models.
 *
 * The route is inferred from prompt/entities/corpus handles before a dataset can become
 * canonical. This avoids patching every new term and prevents a strong but wrong capsule
 * from overriding the biological/pathogen context.
 */
data class GTIMResearchIntentObjectV21311(
    val rawText: String,
    val entities: List<String>,
    val handles: List<String>,
    val candidateRoutes: List<GTIMRouteCandidateV21311>,
    val lockedRoute: String,
    val lockedSubtype: String,
    val locked: Boolean,
    val confidence: Double,
    val explanation: String
)

data class GTIMRouteCandidateV21311(
    val route: String,
    val subtype: String,
    val score: Double,
    val semanticScore: Double,
    val evidenceScore: Double,
    val datasetScore: Double,
    val reasons: List<String>
)

object GTIMResearchIntentObjectContractV21311 {
    const val VERSION: String = "2.13.14-final-generalized-route-coherence-unified"
    const val ENGINE_VERSION: String = "v2.13.14-final-generalized-route-coherence-unified"
    const val CLAIM_LIMIT: String = "evidence_first_route_discovery_no_evidence_upgrade"
}
