package com.immunesignal.app

import org.json.JSONObject

/**
 * legacy_v21314_compat_marker: 2.13.12.4-generalized-route-coherence-runtime-budget; 2.13.12.3-final-surface-domain-coherence-runtime-budget; 2.13.12.3-mobile-safe-first-surface.
 * Mobile-safe first-surface renderer.
 *
 * Keeps the on-device/PDF first surface short and deterministic while the old/new rails
 * remain linked in JSON and the technical appendix. This is a crash-prevention layer, not
 * a science/evidence layer.
 */
object GTIMMobileSafeFirstSurfaceV21313 {
    const val VERSION: String = "2.13.14-final-generalized-route-coherence-unified"
    const val CLAIM_LIMIT: String = "mobile_safe_surface_only_no_evidence_upgrade"

    fun renderCompactPreview(report: JSONObject): String {
        RuntimeCrashSafetyAndTopicGuardV2740.renderFailureCard(report)?.let { return it }
        val guard = GTIMFinalSurfaceDomainCoherenceGuardV21313.toJson(report)
        val active = guard.optString("activeDomain", "unknown")
        val canonical = guard.optString("canonicalTarget", "")
        val route = when (active) {
            "filovirus_viral_host_response" -> "filovirus host-response / capsule-module execution"
            else -> active.replace('_', ' ').ifBlank { "immune research route" }
        }
        return listOf(
            "Immune Research Summary",
            "• Active domain: $active",
            "• Canonical target: ${canonical.ifBlank { "not selected yet" }}",
            "• Route: $route",
            "• Output: compact on-device preview; full rails are saved/exportable.",
            "• Strictness: C0/C1/C2/C3 preview relaxed for testing; patient action, dosing, clinical implementation, and validated-proof claims remain blocked.",
            "• Next: verify topic-fit, comparator labels, sample provenance, processed capsule/matrix, module scores, negative control, and contradiction review.",
            "• Boundary: research-only. No diagnosis, treatment, dosing, vaccine advice, efficacy, or validated discovery claim."
        ).joinToString("\n")
    }

    fun render(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val technical = technicalLines.ifEmpty { GlobalResearchGradeBriefV11061.renderLines(report) }
        val guardJson = GTIMFinalSurfaceDomainCoherenceGuardV21313.toJson(report)
        val active = guardJson.optString("activeDomain", "unknown")
        val canonical = guardJson.optString("canonicalTarget", "")
        val lines = mutableListOf<String>()
        lines += "Immu DZ Global Research Dossier"
        lines += "Global Study Abstract"
        lines += "Study: ${GTIMFinalSurfaceDomainCoherenceGuardV21313.studyFocusFor(active)}; canonical_target=${canonical.ifBlank { "none" }}."
        lines += "Contribution: route isolation → canonical target check → capsule/module execution plan → replication/contradiction gates, without promoting evidence."
        lines += "Current result: ${resultLine(active, canonical)}"
        lines += "Decision gate: upgrade only after topic-fit, comparator labels, sample provenance, processed capsule/matrix, module scores, negative control, replication, and contradiction resistance."
        lines += ""
        lines += GTIMFinalSurfaceDomainCoherenceGuardV21313.publicLines(guardJson)
        lines += ""
        report.optJSONObject("finalRouteSearchHardeningClosureV213103")?.let { lines += GTIMFinalRouteSearchHardeningClosureV213103.publicLines(it) }
        lines += ""
        report.optJSONObject("finalUnifiedDiscoveryReadinessClosureV21310")?.let { lines += GTIMFinalUnifiedDiscoveryReadinessClosureV21310.publicLines(it) }
        lines += ""
        report.optJSONObject("experimentalClaimRelaxationV21312")?.let { lines += GTIMExperimentalClaimRelaxationV21312.publicLines(it) }
        lines += ""
        lines += GTIMStudyResultCardV2126.publicLines(report, technical)
        lines += ""
        lines += "Functional repair study dossier"
        lines += GTIMStudyResultCardV2126.compactDossierLines(report, technical)
        lines += ""
        lines += "Matrix / external evidence plan"
        lines += GTIMMatrixShortcutResolverV2124.publicLines(report, technical).take(6)
        lines += GTIMMatrixShortcutStatusLayerV2129.publicLines(report, technical).take(4)
        lines += ""
        report.optJSONObject("discoverySynthesisCardV2137")?.let { lines += GTIMDiscoverySynthesisCardV2137.publicLines(it) }
        lines += ""
        report.optJSONObject("finalC2InnovationReadinessClosureV2139")?.let { lines += GTIMFinalC2InnovationReadinessClosureV2139.publicLines(it) }
        lines += ""
        report.optJSONObject("finalReleaseLockV21219")?.let { lines += GTIMFinalReleaseLockV21219.publicLines(it).take(5) }
        lines += ""
        lines += "Compatibility appendix policy: legacy v2.12/v2.13 rails, debug tokens, external routes, old medical dossier blocks, and superseded candidates remain in JSON/export appendix only."
        lines += "Boundary: research-only evidence routing; no mechanism, causality, gene/pathway signal, diagnosis, treatment, dosing, efficacy, or patient prediction is proven."
        return GTIMFinalSurfaceDomainCoherenceGuardV21313.sanitizeFirstSurfaceLines(report, lines)
    }

    private fun resultLine(activeDomain: String, canonicalTarget: String): String = when {
        activeDomain == "filovirus_viral_host_response" && canonicalTarget.isNotBlank() -> "C1-ready discovery candidate surface; C2 execution prepared but blocked until module scoring/replication/negative-control/contradiction checks."
        canonicalTarget.isNotBlank() -> "actionable research lead; canonical target selected for review; no evidence upgrade yet."
        else -> "topic-level research route; canonical target still required before matrix/DGE review."
    }
}
