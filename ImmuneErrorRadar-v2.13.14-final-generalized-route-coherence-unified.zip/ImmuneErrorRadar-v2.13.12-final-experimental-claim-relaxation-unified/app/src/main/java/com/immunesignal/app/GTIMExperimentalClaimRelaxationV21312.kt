package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.14 — Experimental claim relaxation mode.
 *
 * Purpose: during app experiments, allow the report to surface C2/C3-style and
 * medical/therapeutic/vaccine/efficacy hypotheses as explicitly unvalidated sandbox
 * previews. This removes over-strict report suppression without turning the app into
 * clinical advice, dosing, or patient management software.
 */
object GTIMExperimentalClaimRelaxationV21312 {
    const val VERSION: String = "2.13.14-final-generalized-route-coherence-unified"
    const val ENGINE_VERSION: String = "v2.13.14-final-generalized-route-coherence-unified"
    const val MODE: String = "EXPERIMENTAL_SANDBOX_PREVIEW"
    const val CLAIM_LIMIT: String = "experimental_preview_allowed_not_patient_action_not_validated_proof"

    fun toJson(report: JSONObject): JSONObject {
        val lift = report.optJSONObject("evidenceLiftGateV2139") ?: JSONObject()
        val unified = report.optJSONObject("finalUnifiedDiscoveryReadinessClosureV21310") ?: JSONObject()
        val intent = report.optJSONObject("researchIntentDiscoveryRouterV21311") ?: JSONObject()
        val route = intent.optString("lockedRoute").ifBlank { unified.optString("activeDomain", "topic_level_route") }
        val subtype = intent.optString("lockedSubtype").ifBlank { unified.optString("activeSubtype", "unknown_or_unspecified") }
        val canonical = unified.optString("canonicalTarget").ifBlank {
            report.optJSONObject("canonicalTargetAfterRouteLockV21311")?.optString("canonicalTarget") ?: ""
        }
        val previewLevels = JSONArray(listOf(
            "C0_ROUTE_PREVIEW",
            "C1_DISCOVERY_CANDIDATE_PREVIEW",
            "C2_COMPUTATIONAL_REPLICATION_PREVIEW",
            "C3_CROSS_DATASET_ROBUSTNESS_PREVIEW",
            "MEDICAL_MECHANISM_PREVIEW",
            "THERAPEUTIC_HYPOTHESIS_PREVIEW",
            "VACCINE_RESPONSE_HYPOTHESIS_PREVIEW",
            "EFFICACY_HYPOTHESIS_PREVIEW"
        ))
        val openWarnings = JSONArray(listOf(
            "preview_labels_are_for_app_testing_not_validated_truth",
            "do_not_use_for_patient_action_or_medical_decision",
            "dosing_or_administration_instructions_are_not_generated",
            "clinical_implementation_requires_external_validation"
        ))
        return JSONObject()
            .put("version", VERSION)
            .put("engineVersion", ENGINE_VERSION)
            .put("state", "FINAL_EXPERIMENTAL_CLAIM_RELAXATION_READY")
            .put("mode", MODE)
            .put("activeDomain", route)
            .put("activeSubtype", subtype)
            .put("canonicalTarget", canonical)
            .put("c2PreviewAllowed", true)
            .put("c3PreviewAllowed", true)
            .put("medicalMechanismPreviewAllowed", true)
            .put("therapeuticHypothesisPreviewAllowed", true)
            .put("vaccineResponsePreviewAllowed", true)
            .put("efficacyHypothesisPreviewAllowed", true)
            .put("patientActionAllowed", false)
            .put("dosingProtocolAllowed", false)
            .put("clinicalImplementationAllowed", false)
            .put("validatedProofClaimAllowed", false)
            .put("previewLevels", previewLevels)
            .put("openRequirements", lift.optJSONArray("c2Blockers") ?: JSONArray())
            .put("warnings", openWarnings)
            .put("strictnessPolicy", "relaxed_for_C0_C1_C2_C3_medical_therapeutic_vaccine_efficacy_preview_in_sandbox; strict_against_patient_action_dosing_clinical_implementation_validated_proof")
            .put("routeLinkage", "legacy rails -> evidence-first route discovery -> experimental claim relaxation -> final release/test locks")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Experimental claim relaxation mode",
        "State: ${obj.optString("state", "UNKNOWN")}; mode=${obj.optString("mode", MODE)}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}",
        "Preview allowed: C2=${obj.optBoolean("c2PreviewAllowed", true)}, C3=${obj.optBoolean("c3PreviewAllowed", true)}, medical/therapeutic/vaccine/efficacy=${obj.optBoolean("medicalMechanismPreviewAllowed", true)}.",
        "Still not allowed: patient_action=${obj.optBoolean("patientActionAllowed", false)}, dosing_protocol=${obj.optBoolean("dosingProtocolAllowed", false)}, clinical_implementation=${obj.optBoolean("clinicalImplementationAllowed", false)}, validated_proof=${obj.optBoolean("validatedProofClaimAllowed", false)}.",
        "Strictness: ${obj.optString("strictnessPolicy", "experimental preview relaxed; patient action and validated proof guarded")}",
        "Boundary: this is an app-testing sandbox mode; C2/C3 and medical/therapeutic/vaccine/efficacy language is hypothesis-preview only, not actionable care or validated science."
    )
}
