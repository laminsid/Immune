#!/usr/bin/env python3
"""v1.9.5 focused project-health audit.
Checks the guarded UI maintenance patch without requiring Android Gradle.
"""
import json
import pathlib
import re
import sys
import xml.etree.ElementTree as ET

ROOT = pathlib.Path('.')
errors = []

def fail(msg: str):
    errors.append(msg)

# JSON assets and research config
for p in list((ROOT / 'app/src/main/assets').glob('*.json')) + list((ROOT / 'research').glob('*.json')):
    try:
        json.loads(p.read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f'JSON parse failed: {p}: {exc}')

# XML parse + ID integrity
xml_ids = set()
for p in (ROOT / 'app/src/main/res/layout').glob('*.xml'):
    try:
        ET.parse(p)
    except Exception as exc:
        fail(f'XML parse failed: {p}: {exc}')
    xml_ids.update(re.findall(r'@\+id/([A-Za-z0-9_]+)', p.read_text(encoding='utf-8')))
refs = set()
for p in (ROOT / 'app/src/main/java').rglob('*.kt'):
    refs.update(re.findall(r'R\.id\.([A-Za-z0-9_]+)', p.read_text(encoding='utf-8', errors='replace')))
missing = refs - xml_ids
if missing:
    fail('Missing layout IDs referenced from Kotlin: ' + ', '.join(sorted(missing)))

# Version consistency
version = '1.9.5-alpha-ui-guarded-maintenance'
if version not in (ROOT / 'app/build.gradle.kts').read_text():
    fail('versionName mismatch in app/build.gradle.kts')
if f'v{version}' not in (ROOT / 'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt').read_text():
    fail('ACTIVE_ENGINE_VERSION mismatch')
if 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.9.5"' not in (ROOT / 'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt').read_text():
    fail('Learning session schema mismatch')
if '.put("schemaVersion", 195)' not in (ROOT / 'app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text():
    fail('Research report schema version mismatch')

# UI complexity budget
layout = ROOT / 'app/src/main/res/layout/activity_research_autopilot.xml'
line_count = len(layout.read_text().splitlines())
if line_count > 320:
    fail(f'Research UI layout too large after slimming: {line_count} lines')
if 'Small learning report' not in layout.read_text():
    fail('Small learning report compatibility marker missing')

# Legacy result screen was removed in v1.10.1; keep it removed.
if (ROOT / 'app/src/main/java/com/immunesignal/app/ResultActivity.kt').exists():
    fail('Legacy ResultActivity returned after removal')
if (ROOT / 'app/src/main/res/layout/activity_result.xml').exists():
    fail('Legacy activity_result.xml returned after removal')

activity = (ROOT / 'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for token in ['Decision card', 'Learning receipt', 'Export shows the technical layers', 'uiCompatibilityAuditTokensV194']:
    if token not in activity:
        fail(f'Compact UI token missing: {token}')

# Regression checks from CI failure
for bad in ['.edgeType', '.speciesClass']:
    offenders = []
    for p in (ROOT / 'app/src/main/java/com/immunesignal/app').glob('ScientificDiscovery*.kt'):
        if bad in p.read_text(encoding='utf-8', errors='replace'):
            offenders.append(str(p))
    if offenders:
        fail(f'Unresolved-field regression {bad}: ' + ', '.join(offenders))

# Critical v1.8-v1.9 wiring must still exist
required_pairs = {
    'ResearchAutopilot.kt': ['ScientificDiscoveryQualityGateEngineV192.evaluate', 'ScientificDiscoveryRunbookEngineV193.compile'],
    'CognitiveNextCycleBridge.kt': ['extractV193RunbookTerms', 'buildV193RunbookReason', 'extractV192QualityGateTerms'],
    'ResearchModels.kt': ['scientificDiscoveryRunbookReport', 'scientificDiscoveryQualityGateReport', 'scientificDiscoveryProbeOutcomeLedgerReport'],
    'DiscoveryReportExporter.kt': ['Executable quality runbook v1.9.3', 'Discovery quality gate v1.9.2']
}
base = ROOT / 'app/src/main/java/com/immunesignal/app'
for rel, tokens in required_pairs.items():
    text = (base / rel).read_text(encoding='utf-8', errors='replace')
    for token in tokens:
        if token not in text:
            fail(f'Critical wiring token missing in {rel}: {token}')

if errors:
    print('v1.9.5 project-health audit: FAIL')
    for e in errors:
        print('-', e)
    sys.exit(1)
print('v1.9.5 project-health audit: PASS')
print(f'UI layout lines: {line_count} (target <= 320)')
print(f'Kotlin referenced IDs: {len(refs)}; XML IDs: {len(xml_ids)}')
