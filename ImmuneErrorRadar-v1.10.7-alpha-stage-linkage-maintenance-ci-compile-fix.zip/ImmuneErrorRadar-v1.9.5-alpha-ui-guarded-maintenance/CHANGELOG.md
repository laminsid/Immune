
## 1.10.6-alpha-plan-stage-extraction

- Added `ResearchCyclePlanStage` as the first executable runCycle phase extraction.
- Final network handoff now uses `selectedSearchQueriesV206`, not the raw query-feedback batch.
- Added `cyclePlanStageReport` to JSON/PDF.
- Added regression tests and audit guard for plan-stage budget enforcement.
