package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchCyclePlanStageTest {
    @Test
    fun activeDirectiveKeepsOnlyAllowedQueryAfterRewrites() {
        val allowed = query("q_allowed")
        val directive = ResearchSearchDirective(
            active = true,
            mode = "EVIDENCE_CLOSURE_NARROW_SEARCH",
            governingLayer = "evidence_closure",
            queries = listOf(allowed),
            reason = "close accession first",
            maxQueries = 1,
            maxResultsPerQuery = 3,
            blockDatasetFirst = true,
            trace = listOf("test")
        )
        val candidates = listOf(allowed.copy(query = "rewritten terms"), query("q_extra"))
        val selected = ResearchCyclePlanStage.enforceSearchBudget(directive, candidates)

        assertEquals(listOf("q_allowed"), selected.map { it.id })
        val report = ResearchCyclePlanStage.buildReport(
            directive = directive,
            candidateQueries = candidates,
            selectedQueries = selected,
            phaseSpine = ResearchCyclePhaseSpine.build()
        )
        assertEquals("DIRECTIVE_BOUNDED_PLAN", report.state)
        assertEquals(listOf("q_extra"), report.rejectedQueryIds)
        assertTrue(report.summary.contains("selected=1/2"))
    }

    @Test
    fun offlineDirectiveSelectsNoNetworkQueries() {
        val directive = ResearchSearchDirective(
            active = true,
            mode = "OFFLINE_THINK_ONLY",
            governingLayer = "linked_cognition_spine",
            queries = emptyList(),
            reason = "think first",
            maxQueries = 0,
            maxResultsPerQuery = 0,
            blockDatasetFirst = true,
            trace = listOf("offline")
        )

        val selected = ResearchCyclePlanStage.enforceSearchBudget(
            directive,
            listOf(query("q_should_not_run"))
        )

        assertTrue(selected.isEmpty())
        val report = ResearchCyclePlanStage.buildReport(
            directive = directive,
            candidateQueries = listOf(query("q_should_not_run")),
            selectedQueries = selected,
            phaseSpine = ResearchCyclePhaseSpine.build()
        )
        assertEquals("OFFLINE_ONLY_PLAN", report.state)
        assertTrue(report.nextPhase.contains("Skip network search"))
    }

    private fun query(id: String) = ResearchQuery(
        id = id,
        label = id,
        query = "human immune metadata outcome control",
        reason = "test"
    )
}
