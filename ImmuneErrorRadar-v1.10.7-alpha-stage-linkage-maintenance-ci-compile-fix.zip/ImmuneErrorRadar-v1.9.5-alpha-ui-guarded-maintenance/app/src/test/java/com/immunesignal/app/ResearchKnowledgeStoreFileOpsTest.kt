package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ResearchKnowledgeStoreFileOpsTest {
    @Test
    fun readLastValidJsonLinesSkipsMalformedWithoutDroppingValidTail() {
        val dir = createTempDir(prefix = "ier_store_ops_")
        val file = File(dir, "ledger.jsonl")
        file.writeText(
            listOf(
                "{\"id\":1}",
                "not-json",
                "{\"id\":2}",
                "{\"id\":3}"
            ).joinToString("\n", postfix = "\n"),
            Charsets.UTF_8
        )
        val rejected = mutableListOf<String>()
        val lines = ResearchKnowledgeStoreFileOps.readLastValidJsonLines(file, 2) { rejected += it }
        assertEquals(listOf("{\"id\":2}", "{\"id\":3}"), lines)
        assertTrue(rejected.contains("not-json"))
        dir.deleteRecursively()
    }

    @Test
    fun trimFileKeepsOnlyValidTail() {
        val dir = createTempDir(prefix = "ier_store_trim_")
        val file = File(dir, "reports.jsonl")
        (1..6).forEach { ResearchKnowledgeStoreFileOps.appendOnly(file, "{\"id\":$it}") }
        ResearchKnowledgeStoreFileOps.appendOnly(file, "broken")
        val remaining = ResearchKnowledgeStoreFileOps.trimFile(file, 3)
        assertEquals(3, remaining)
        assertEquals(
            listOf("{\"id\":4}", "{\"id\":5}", "{\"id\":6}"),
            ResearchKnowledgeStoreFileOps.readAllValidJsonLines(file)
        )
        dir.deleteRecursively()
    }

    @Test
    fun appendOnlyUsesUtf8AndAddsSingleJsonlLine() {
        val dir = createTempDir(prefix = "ier_store_append_")
        val file = File(dir, "thought.jsonl")
        ResearchKnowledgeStoreFileOps.appendOnly(file, "{\"text\":\"سلام\"}")
        assertEquals(listOf("{\"text\":\"سلام\"}"), file.readLines(Charsets.UTF_8))
        dir.deleteRecursively()
    }
}
