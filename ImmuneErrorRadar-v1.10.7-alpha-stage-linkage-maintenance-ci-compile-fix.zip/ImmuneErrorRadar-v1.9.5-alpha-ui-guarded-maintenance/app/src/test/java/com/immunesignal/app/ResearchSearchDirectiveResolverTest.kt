package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchSearchDirectiveResolverTest {
    @Test
    fun linkedSpineOverridesClosureAndMomentum() {
        val linked = LinkedCognitionSpineEngine.PriorSearchDirective(
            active = true,
            mode = "NARROW_SEARCH_ALLOWED",
            queries = listOf(query("q_linked")),
            reason = "spine owns the next action"
        )
        val closure = listOf(query("q_closure"))
        val momentum = CognitiveMomentumEngine.PriorSearchDirective(
            active = true,
            mode = "NARROW_SEARCH_ALLOWED",
            queries = listOf(query("q_momentum")),
            reason = "momentum also active"
        )

        val directive = ResearchSearchDirectiveResolver.resolvePrior(
            closureQueries = closure,
            linkedSpine = linked,
            momentum = momentum,
            baseMaxQueries = 6,
            baseResultsPerQuery = 20
        )

        assertTrue(directive.active)
        assertEquals("linked_cognition_spine", directive.governingLayer)
        assertEquals(listOf("q_linked"), directive.queries.map { it.id })
        assertEquals(1, directive.maxQueries)
        assertEquals(3, directive.maxResultsPerQuery)
    }

    @Test
    fun closureOverridesMomentumWhenNoLinkedSpine() {
        val directive = ResearchSearchDirectiveResolver.resolvePrior(
            closureQueries = listOf(query("q_closure")),
            linkedSpine = LinkedCognitionSpineEngine.PriorSearchDirective.none(),
            momentum = CognitiveMomentumEngine.PriorSearchDirective(
                active = true,
                mode = "NARROW_SEARCH_ALLOWED",
                queries = listOf(query("q_momentum")),
                reason = "momentum active"
            ),
            baseMaxQueries = 6,
            baseResultsPerQuery = 20
        )

        assertTrue(directive.active)
        assertEquals("evidence_closure", directive.governingLayer)
        assertEquals(listOf("q_closure"), directive.queries.map { it.id })
    }

    @Test
    fun noPriorLockLeavesPlannerInControl() {
        val directive = ResearchSearchDirectiveResolver.resolvePrior(
            closureQueries = emptyList(),
            linkedSpine = LinkedCognitionSpineEngine.PriorSearchDirective.none(),
            momentum = CognitiveMomentumEngine.PriorSearchDirective.none(),
            baseMaxQueries = 4,
            baseResultsPerQuery = 10
        )

        assertFalse(directive.active)
        assertEquals("BROAD_SEARCH_ALLOWED", directive.mode)
        assertEquals(4, directive.maxQueries)
        assertEquals(10, directive.maxResultsPerQuery)
    }

    private fun query(id: String) = ResearchQuery(
        id = id,
        label = id,
        query = "human immune outcome metadata",
        reason = "test query"
    )
}
