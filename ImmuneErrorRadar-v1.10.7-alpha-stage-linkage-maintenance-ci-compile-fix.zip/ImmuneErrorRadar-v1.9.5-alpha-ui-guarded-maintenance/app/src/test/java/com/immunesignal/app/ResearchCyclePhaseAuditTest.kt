package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchCyclePhaseAuditTest {
    @Test
    fun blocksRuntimeFailoverUnderSameCycleClosureLock() {
        val prior = ResearchSearchDirective.none(baseMaxQueries = 4, baseResultsPerQuery = 10)
        val closure = ResearchSearchDirective(
            active = true,
            mode = "SAME_CYCLE_ACCESSION_CLOSURE",
            governingLayer = "evidence_closure_same_cycle",
            queries = listOf(query("q_v204_closure")),
            reason = "dataset candidate requires closure",
            maxQueries = 1,
            maxResultsPerQuery = 3,
            blockDatasetFirst = true,
            trace = listOf("test")
        )

        val report = ResearchCyclePhaseAuditEngine.build(
            priorDirective = prior,
            postForagerDirective = closure,
            datasetFirstRequested = true,
            runtimeFailoverAttempted = false,
            executedQueryIds = listOf("q_v204_closure"),
            findingsCount = 1,
            rankedCount = 1,
            runtimeDiagnostics = emptyList(),
            stopped = false,
            stopReason = "completed"
        )

        assertEquals("LOCKED_NARROW", report.state)
        assertTrue(report.runtimeFailoverBlocked)
        assertTrue(report.lockViolations.isEmpty())
        assertEquals("evidence_closure_same_cycle", report.governingLayer)
    }

    @Test
    fun reportsViolationWhenFailoverRunsUnderActiveLock() {
        val prior = ResearchSearchDirective.none(baseMaxQueries = 4, baseResultsPerQuery = 10)
        val closure = ResearchSearchDirective(
            active = true,
            mode = "SAME_CYCLE_ACCESSION_CLOSURE",
            governingLayer = "evidence_closure_same_cycle",
            queries = listOf(query("q_v204_closure")),
            reason = "dataset candidate requires closure",
            maxQueries = 1,
            maxResultsPerQuery = 3,
            blockDatasetFirst = true,
            trace = listOf("test")
        )

        val report = ResearchCyclePhaseAuditEngine.build(
            priorDirective = prior,
            postForagerDirective = closure,
            datasetFirstRequested = true,
            runtimeFailoverAttempted = true,
            executedQueryIds = listOf("q_v204_closure", "q_runtime_dataset_accession"),
            findingsCount = 0,
            rankedCount = 0,
            runtimeDiagnostics = emptyList(),
            stopped = false,
            stopReason = "completed"
        )

        assertEquals("LOCK_VIOLATION", report.state)
        assertTrue(report.lockViolations.any { it.contains("RUNTIME_FAILOVER_RAN_DESPITE_ACTIVE_SEARCH_LOCK") })
    }

    private fun query(id: String) = ResearchQuery(
        id = id,
        label = id,
        query = "GSE250594 outcome labels metadata",
        reason = "test closure query"
    )
}
