package com.immunesignal.app

/**
 * v1.10.3 Research Search Directive Resolver.
 *
 * This is the pre-search decision spine. It unifies the previously separate
 * prior locks from Evidence Closure, Cognitive Momentum, and Linked Cognition
 * Spine so the network layer cannot accidentally spend a broad search cycle
 * while any prior evidence gap still requires closure.
 *
 * It is intentionally small and non-biological: it only decides whether the
 * next cycle may search broadly, narrowly, or not at all.
 */
data class ResearchSearchDirective(
    val active: Boolean,
    val mode: String,
    val governingLayer: String,
    val queries: List<ResearchQuery>,
    val reason: String,
    val maxQueries: Int,
    val maxResultsPerQuery: Int,
    val blockDatasetFirst: Boolean,
    val trace: List<String>,
    val claimLimit: String = "search_directive_resolver_not_biological_proof"
) {
    val isOfflineOnly: Boolean
        get() = mode == "OFFLINE_THINK_ONLY"

    val isNarrow: Boolean
        get() = active && (mode.contains("NARROW", ignoreCase = true) || mode.contains("CLOSURE", ignoreCase = true) || queries.size <= 1)

    companion object {
        fun none(baseMaxQueries: Int, baseResultsPerQuery: Int) = ResearchSearchDirective(
            active = false,
            mode = "BROAD_SEARCH_ALLOWED",
            governingLayer = "none",
            queries = emptyList(),
            reason = "No prior evidence-closure, momentum, or linked-spine lock is active.",
            maxQueries = baseMaxQueries,
            maxResultsPerQuery = baseResultsPerQuery,
            blockDatasetFirst = false,
            trace = listOf("resolver:none -> broad search remains governed by normal planner")
        )
    }
}

object ResearchSearchDirectiveResolver {
    fun resolvePrior(
        closureQueries: List<ResearchQuery>,
        linkedSpine: LinkedCognitionSpineEngine.PriorSearchDirective,
        momentum: CognitiveMomentumEngine.PriorSearchDirective,
        baseMaxQueries: Int,
        baseResultsPerQuery: Int
    ): ResearchSearchDirective {
        val trace = mutableListOf<String>()
        trace += "resolver:start baseMaxQueries=$baseMaxQueries baseResults=$baseResultsPerQuery"
        trace += "linkedSpine active=${linkedSpine.active} mode=${linkedSpine.mode} queries=${linkedSpine.queries.size}"
        trace += "closure active=${closureQueries.isNotEmpty()} queries=${closureQueries.size}"
        trace += "momentum active=${momentum.active} mode=${momentum.mode} queries=${momentum.queries.size}"

        // Priority is strict: the linked spine is the highest-level decision,
        // then explicit evidence-closure, then momentum. This prevents lower
        // layers from re-opening a broad search after the spine has constrained it.
        if (linkedSpine.active) {
            val queries = linkedSpine.queries.take(1)
            val offlineOnly = linkedSpine.mode == "OFFLINE_THINK_ONLY" || queries.isEmpty()
            return ResearchSearchDirective(
                active = true,
                mode = if (offlineOnly) "OFFLINE_THINK_ONLY" else "LINKED_SPINE_NARROW_SEARCH",
                governingLayer = "linked_cognition_spine",
                queries = queries,
                reason = linkedSpine.reason,
                maxQueries = if (offlineOnly) 0 else 1,
                maxResultsPerQuery = if (offlineOnly) 0 else minOf(3, baseResultsPerQuery),
                blockDatasetFirst = true,
                trace = trace + "resolver:governed_by_linked_spine"
            )
        }

        if (closureQueries.isNotEmpty()) {
            return ResearchSearchDirective(
                active = true,
                mode = "EVIDENCE_CLOSURE_NARROW_SEARCH",
                governingLayer = "evidence_closure",
                queries = closureQueries.take(1),
                reason = "Prior evidence-closure card blocks broad search until its accession/gap is closed.",
                maxQueries = 1,
                maxResultsPerQuery = minOf(3, baseResultsPerQuery),
                blockDatasetFirst = true,
                trace = trace + "resolver:governed_by_evidence_closure"
            )
        }

        if (momentum.active) {
            val queries = momentum.queries.take(1)
            val offlineOnly = momentum.mode == "OFFLINE_THINK_ONLY" || queries.isEmpty()
            return ResearchSearchDirective(
                active = true,
                mode = if (offlineOnly) "OFFLINE_THINK_ONLY" else "MOMENTUM_NARROW_SEARCH",
                governingLayer = "cognitive_momentum",
                queries = queries,
                reason = momentum.reason,
                maxQueries = if (offlineOnly) 0 else 1,
                maxResultsPerQuery = if (offlineOnly) 0 else minOf(3, baseResultsPerQuery),
                blockDatasetFirst = true,
                trace = trace + "resolver:governed_by_cognitive_momentum"
            )
        }

        return ResearchSearchDirective.none(baseMaxQueries, baseResultsPerQuery).copy(trace = trace + "resolver:allow_normal_planner")
    }

    fun resolveAfterForager(
        prior: ResearchSearchDirective,
        datasetForagingReport: DatasetForagingReport,
        baseQueries: List<ResearchQuery>,
        baseMaxQueries: Int,
        baseResultsPerQuery: Int
    ): ResearchSearchDirective {
        if (prior.active) return prior
        if (EvidenceClosureEngine.shouldUseClosureMode(datasetForagingReport)) {
            val queries = EvidenceClosureEngine.closureQueries(datasetForagingReport).take(1)
            return ResearchSearchDirective(
                active = true,
                mode = "SAME_CYCLE_ACCESSION_CLOSURE",
                governingLayer = "evidence_closure_same_cycle",
                queries = queries,
                reason = "Same-cycle dataset candidate requires metadata/outcome/control/time closure before broad PubMed expansion.",
                maxQueries = 1,
                maxResultsPerQuery = minOf(3, baseResultsPerQuery),
                blockDatasetFirst = true,
                trace = prior.trace + listOf(
                    "forager:dataset_active=${datasetForagingReport.active} candidates=${datasetForagingReport.candidates.size}",
                    "resolver:governed_by_same_cycle_evidence_closure"
                )
            )
        }
        return prior.copy(
            queries = baseQueries.take(baseMaxQueries),
            maxQueries = baseMaxQueries,
            maxResultsPerQuery = baseResultsPerQuery,
            trace = prior.trace + "resolver:post_forager_normal_queries=${baseQueries.size}"
        )
    }
}
