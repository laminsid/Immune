package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.10.4 cycle-phase audit.
 *
 * This is a non-biological wiring report. It verifies that the research cycle
 * actually followed the search directive spine across Plan -> Search -> Reason
 * -> Persist, and it exposes any lock violation before the output is trusted.
 */
data class ResearchCyclePhaseAuditReport(
    val active: Boolean,
    val version: String,
    val state: String,
    val governingLayer: String,
    val searchMode: String,
    val networkBudget: String,
    val datasetFirstBlocked: Boolean,
    val runtimeFailoverBlocked: Boolean,
    val lockViolations: List<String>,
    val phases: List<ResearchCyclePhaseSnapshot>,
    val nextGate: String,
    val summary: String,
    val claimLimit: String = "cycle_phase_audit_not_biological_proof"
) {
    companion object {
        fun empty() = ResearchCyclePhaseAuditReport(
            active = false,
            version = "v1.10.4",
            state = "NOT_EVALUATED",
            governingLayer = "none",
            searchMode = "unknown",
            networkBudget = "unknown",
            datasetFirstBlocked = false,
            runtimeFailoverBlocked = false,
            lockViolations = emptyList(),
            phases = emptyList(),
            nextGate = "No cycle-phase audit available.",
            summary = "Cycle-phase audit was not evaluated."
        )
    }
}

data class ResearchCyclePhaseSnapshot(
    val phase: String,
    val status: String,
    val owner: String,
    val decision: String,
    val evidence: List<String>
)

object ResearchCyclePhaseAuditEngine {
    fun build(
        priorDirective: ResearchSearchDirective,
        postForagerDirective: ResearchSearchDirective,
        datasetFirstRequested: Boolean,
        runtimeFailoverAttempted: Boolean,
        executedQueryIds: List<String>,
        findingsCount: Int,
        rankedCount: Int,
        runtimeDiagnostics: List<String>,
        stopped: Boolean,
        stopReason: String
    ): ResearchCyclePhaseAuditReport {
        val activeDirective = if (postForagerDirective.active) postForagerDirective else priorDirective
        val hasLock = postForagerDirective.active || postForagerDirective.blockDatasetFirst || priorDirective.active || priorDirective.blockDatasetFirst
        val runtimeFailoverBlocked = hasLock
        val violations = mutableListOf<String>()

        if (datasetFirstRequested && priorDirective.blockDatasetFirst) {
            violations += "DATASET_FIRST_RAN_DESPITE_PRIOR_LOCK"
        }
        if (runtimeFailoverAttempted && runtimeFailoverBlocked) {
            violations += "RUNTIME_FAILOVER_RAN_DESPITE_ACTIVE_SEARCH_LOCK"
        }
        if (activeDirective.maxQueries == 0 && executedQueryIds.isNotEmpty()) {
            violations += "OFFLINE_ONLY_DIRECTIVE_EXECUTED_NETWORK_QUERIES"
        }
        if (activeDirective.active && activeDirective.maxQueries in 1..1 && executedQueryIds.size > 1) {
            val allowed = activeDirective.queries.map { it.id }.toSet()
            val extra = executedQueryIds.filterNot { it in allowed }
            if (extra.isNotEmpty()) violations += "NARROW_DIRECTIVE_EXECUTED_EXTRA_QUERIES:${extra.take(4).joinToString(",") }"
        }

        val phases = listOf(
            ResearchCyclePhaseSnapshot(
                phase = "PLAN",
                status = if (priorDirective.active) "CONSTRAINED" else "OPEN",
                owner = priorDirective.governingLayer,
                decision = priorDirective.mode,
                evidence = priorDirective.trace.takeLast(4)
            ),
            ResearchCyclePhaseSnapshot(
                phase = "DATASET_FORAGING",
                status = if (datasetFirstRequested) "RAN" else "SKIPPED_OR_BLOCKED",
                owner = if (priorDirective.blockDatasetFirst) priorDirective.governingLayer else "direct_dataset_source_router",
                decision = if (priorDirective.blockDatasetFirst) "BLOCKED_BY_PRIOR_DIRECTIVE" else "router_decision",
                evidence = listOf("datasetFirstRequested=$datasetFirstRequested", "priorBlock=${priorDirective.blockDatasetFirst}")
            ),
            ResearchCyclePhaseSnapshot(
                phase = "SEARCH",
                status = if (executedQueryIds.isEmpty()) "NO_NETWORK_QUERY" else "EXECUTED_${executedQueryIds.size}_QUERY_IDS",
                owner = postForagerDirective.governingLayer,
                decision = postForagerDirective.mode,
                evidence = listOf(
                    "maxQueries=${postForagerDirective.maxQueries}",
                    "maxResults=${postForagerDirective.maxResultsPerQuery}",
                    "executed=${executedQueryIds.take(6).joinToString(",")}".take(220)
                )
            ),
            ResearchCyclePhaseSnapshot(
                phase = "RUNTIME_FAILOVER",
                status = if (runtimeFailoverAttempted) "RAN" else if (runtimeFailoverBlocked) "BLOCKED" else "NOT_TRIGGERED",
                owner = if (runtimeFailoverBlocked) postForagerDirective.governingLayer else "EngineRuntimeStatus",
                decision = if (runtimeFailoverBlocked) "BLOCK_FAILOVER_UNDER_ACTIVE_LOCK" else "ALLOW_ONLY_IF_HARD_STAGNATION",
                evidence = listOf("activeLock=$hasLock", "runtimeFailoverAttempted=$runtimeFailoverAttempted")
            ),
            ResearchCyclePhaseSnapshot(
                phase = "REASON",
                status = if (rankedCount > 0) "RANKED_${rankedCount}" else "NO_RANKED_FINDINGS",
                owner = "reasoning_stack",
                decision = "rank_then_gate",
                evidence = listOf("rawFindings=$findingsCount", "ranked=$rankedCount")
            ),
            ResearchCyclePhaseSnapshot(
                phase = "PERSIST",
                status = if (stopped) "STOPPED:$stopReason" else "READY_TO_SAVE",
                owner = "ResearchKnowledgeStore",
                decision = if (runtimeDiagnostics.isEmpty()) "persist_with_clean_runtime" else "persist_with_runtime_warnings",
                evidence = runtimeDiagnostics.take(4).ifEmpty { listOf("runtimeDiagnostics=none") }
            )
        )

        val state = when {
            violations.isNotEmpty() -> "LOCK_VIOLATION"
            postForagerDirective.isOfflineOnly -> "OFFLINE_ONLY"
            postForagerDirective.active -> "LOCKED_NARROW"
            runtimeDiagnostics.isNotEmpty() -> "PASS_WITH_RUNTIME_WARNINGS"
            else -> "PASS"
        }
        val networkBudget = "queries=${postForagerDirective.maxQueries}; resultsPerQuery=${postForagerDirective.maxResultsPerQuery}"
        val nextGate = when {
            violations.isNotEmpty() -> "Do not trust this cycle until search-lock violations are fixed."
            postForagerDirective.active -> "Continue only through ${postForagerDirective.governingLayer}: ${postForagerDirective.reason.take(160)}"
            runtimeDiagnostics.isNotEmpty() -> "Review typed runtime diagnostics before interpreting missing evidence as a scientific absence."
            else -> "Normal planner may run next cycle unless a new evidence gap appears."
        }
        val summary = "Cycle phase audit $state: owner=${postForagerDirective.governingLayer}; mode=${postForagerDirective.mode}; $networkBudget; violations=${violations.size}."

        return ResearchCyclePhaseAuditReport(
            active = true,
            version = "v1.10.4",
            state = state,
            governingLayer = postForagerDirective.governingLayer,
            searchMode = postForagerDirective.mode,
            networkBudget = networkBudget,
            datasetFirstBlocked = priorDirective.blockDatasetFirst,
            runtimeFailoverBlocked = runtimeFailoverBlocked,
            lockViolations = violations,
            phases = phases,
            nextGate = nextGate,
            summary = summary
        )
    }

    fun toJson(report: ResearchCyclePhaseAuditReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("state", report.state)
        .put("governingLayer", report.governingLayer)
        .put("searchMode", report.searchMode)
        .put("networkBudget", report.networkBudget)
        .put("datasetFirstBlocked", report.datasetFirstBlocked)
        .put("runtimeFailoverBlocked", report.runtimeFailoverBlocked)
        .put("lockViolations", JSONArray(report.lockViolations))
        .put("phases", JSONArray(report.phases.map { phaseToJson(it) }))
        .put("nextGate", report.nextGate)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun phaseToJson(phase: ResearchCyclePhaseSnapshot): JSONObject = JSONObject()
        .put("phase", phase.phase)
        .put("status", phase.status)
        .put("owner", phase.owner)
        .put("decision", phase.decision)
        .put("evidence", JSONArray(phase.evidence))
}
