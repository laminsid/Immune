package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.10.0 Linked Cognition Spine.
 *
 * This is the wiring layer above the post-search engines. Earlier patches made
 * evidence closure, post-search thinking, continuity, hypothesis graph, and
 * momentum useful. The spine makes them operate as one decision chain:
 * evidence -> thought -> continuity -> graph -> momentum -> next action.
 * It never proves biology; it only decides which local or network action is
 * allowed next and exposes disconnected layers before they create loops.
 */
data class LinkedCognitionSpineReport(
    val active: Boolean,
    val state: String,
    val linkIntegrityScore: Int,
    val routeMode: String,
    val governingLayer: String,
    val connectedLayers: List<String>,
    val disconnectedLayers: List<String>,
    val openEvidenceKeys: List<String>,
    val governingDecision: String,
    val nextAction: String,
    val searchDecision: String,
    val queryBudget: String,
    val handoffTrace: List<String>,
    val summary: String,
    val claimLimit: String = "linked_cognition_spine_not_biological_proof"
) {
    companion object {
        fun empty() = LinkedCognitionSpineReport(
            active = false,
            state = "NO_SPINE",
            linkIntegrityScore = 0,
            routeMode = "NO_ROUTE",
            governingLayer = "none",
            connectedLayers = emptyList(),
            disconnectedLayers = emptyList(),
            openEvidenceKeys = emptyList(),
            governingDecision = "Run or load a research cycle before linking cognition.",
            nextAction = "No linked action available.",
            searchDecision = "Search is not justified without a linked evidence key.",
            queryBudget = "NO_NETWORK",
            handoffTrace = emptyList(),
            summary = "No linked cognition spine is available."
        )
    }
}

object LinkedCognitionSpineEngine {
    data class PriorSearchDirective(
        val active: Boolean,
        val mode: String,
        val queries: List<ResearchQuery>,
        val reason: String
    ) {
        companion object {
            fun none() = PriorSearchDirective(
                active = false,
                mode = "NO_PRIOR_SPINE_LOCK",
                queries = emptyList(),
                reason = "No prior linked cognition spine lock."
            )
        }
    }

    fun build(
        evidenceClosure: EvidenceClosureReport,
        postSearchThinking: PostSearchThinkingReport,
        thinkingContinuity: ThinkingContinuityReport,
        hypothesisGraph: HypothesisGraphReport,
        cognitiveMomentum: CognitiveMomentumReport,
        datasetForaging: DatasetForagingReport,
        qualityGate: ScientificDiscoveryQualityGateReport,
        runbook: ScientificDiscoveryRunbookReport,
        executedQueries: List<ResearchQuery>,
        priorSpineWasActive: Boolean
    ): LinkedCognitionSpineReport {
        val layerStates = linkedMapOf(
            "evidence_closure" to evidenceClosure.active,
            "post_search_thinking" to postSearchThinking.active,
            "thinking_continuity" to thinkingContinuity.active,
            "hypothesis_graph" to hypothesisGraph.active,
            "cognitive_momentum" to cognitiveMomentum.active,
            "quality_gate" to qualityGate.active,
            "runbook" to runbook.active
        )
        val connected = layerStates.filterValues { it }.keys.toList()
        if (connected.isEmpty()) return LinkedCognitionSpineReport.empty()

        val disconnected = requiredLayersForCurrentState(evidenceClosure, hypothesisGraph, cognitiveMomentum, qualityGate, runbook)
            .filterNot { layerStates[it] == true }
            .distinct()

        val card = evidenceClosure.cards.firstOrNull()
        val accession = card?.accession?.takeIf { it.isNotBlank() && it != "none" }
        val openKeys = (
            evidenceClosure.cards.flatMap { it.missingFields } +
                thinkingContinuity.repeatedGaps +
                listOf(hypothesisGraph.weakestLink) +
                cognitiveMomentum.stalledEvidenceKeys +
                qualityGate.requiredBeforeRun +
                runbook.evidenceChecklist
            )
            .map { normalizeKey(it) }
            .filter { it.isNotBlank() && it != "none" && it != "unknown" }
            .distinct()
            .take(10)

        val closureBlocks = evidenceClosure.broadSearchBlocked || evidenceClosure.cards.any { it.blocksBroadSearch }
        val graphBlocks = startsWithLock(hypothesisGraph.searchDecision)
        val momentumBlocks = startsWithLock(cognitiveMomentum.searchDecision)
        val runbookBlocks = runbook.selectedRunMode.contains("REROUTE_OR_ARCHIVE", ignoreCase = true) ||
            runbook.routeDecision.contains("Do not", ignoreCase = true)
        val qualityBlocks = qualityGate.allowExecution.not() && qualityGate.active
        val blocksBroadSearch = closureBlocks || graphBlocks || momentumBlocks || runbookBlocks || qualityBlocks

        val governingLayer = when {
            closureBlocks && accession != null -> "evidence_closure"
            momentumBlocks -> "cognitive_momentum"
            graphBlocks -> "hypothesis_graph"
            qualityBlocks -> "quality_gate"
            runbookBlocks -> "runbook"
            thinkingContinuity.active -> "thinking_continuity"
            postSearchThinking.active -> "post_search_thinking"
            else -> connected.last()
        }
        val weakest = firstNonBlank(openKeys.firstOrNull().orEmpty(), hypothesisGraph.weakestLink, "one_decisive_evidence_key")
        val routeMode = when {
            blocksBroadSearch && accession != null -> "ACCESSION_CLOSURE_ONLY"
            blocksBroadSearch && hypothesisGraph.active -> "GRAPH_GAP_CLOSURE_ONLY"
            cognitiveMomentum.state == "MOMENTUM_ADVANCING" -> "BOUNDED_REPLICATION_ONLY"
            thinkingContinuity.active || postSearchThinking.active -> "OFFLINE_THINK_THEN_TEST"
            else -> "GUARDED_RESEARCH"
        }
        val linkIntegrityScore = computeIntegrityScore(
            connected = connected,
            disconnected = disconnected,
            openKeys = openKeys,
            executedQueries = executedQueries,
            priorSpineWasActive = priorSpineWasActive,
            hasAccession = accession != null,
            blocksBroadSearch = blocksBroadSearch
        )
        val state = when {
            disconnected.isNotEmpty() && linkIntegrityScore < 70 -> "SPINE_PARTIAL_NEEDS_WIRING"
            blocksBroadSearch && accession != null -> "SPINE_LOCKED_TO_ACCESSION_CLOSURE"
            blocksBroadSearch -> "SPINE_LOCKED_TO_EVIDENCE_GAP"
            cognitiveMomentum.state == "MOMENTUM_ADVANCING" -> "SPINE_ADVANCING_BOUNDED"
            openKeys.isNotEmpty() -> "SPINE_THINK_FIRST"
            else -> "SPINE_READY_FOR_BOUNDED_SEARCH"
        }
        val nextAction = firstNonBlank(
            card?.nextAction.orEmpty(),
            cognitiveMomentum.nextAction,
            hypothesisGraph.nextReasoningMove,
            thinkingContinuity.nextLocalQuestion,
            runbook.routeDecision,
            postSearchThinking.nextOfflineThought,
            "Select one falsifiable evidence key before using network search."
        ).take(300)
        val governingDecision = when {
            state == "SPINE_PARTIAL_NEEDS_WIRING" -> "Reconnect missing layer(s): ${disconnected.joinToString(", ")}; do not expand search until the chain is coherent."
            state == "SPINE_LOCKED_TO_ACCESSION_CLOSURE" -> "Close accession ${accession ?: "current"} on $weakest before any broad search."
            state == "SPINE_LOCKED_TO_EVIDENCE_GAP" -> "Close $weakest or archive/cool down the route; broad search remains blocked."
            state == "SPINE_ADVANCING_BOUNDED" -> "Progress exists, but only bounded verification/replication is allowed."
            state == "SPINE_THINK_FIRST" -> "Think locally until one discriminator is selected; network is optional and narrow only."
            else -> "Guarded bounded search is allowed with explicit evidence keys."
        }.take(300)
        val searchDecision = when (state) {
            "SPINE_PARTIAL_NEEDS_WIRING" -> "THINK_FIRST: repair cognition handoff before network search."
            "SPINE_LOCKED_TO_ACCESSION_CLOSURE" -> "NO_BROAD_SEARCH: accession closure only."
            "SPINE_LOCKED_TO_EVIDENCE_GAP" -> "NO_BROAD_SEARCH: close $weakest or archive route."
            "SPINE_ADVANCING_BOUNDED" -> "NARROW_SEARCH_ALLOWED: verify or replicate the moved evidence key only."
            "SPINE_THINK_FIRST" -> "THINK_FIRST: choose one discriminator before a query."
            else -> "NARROW_SEARCH_ALLOWED: one bounded evidence query."
        }
        val queryBudget = when {
            searchDecision.startsWith("NO_BROAD_SEARCH", true) && accession != null -> "MAX_1_QUERY_RETMAX_3"
            searchDecision.startsWith("NO_BROAD_SEARCH", true) -> "MAX_0_OR_1_QUERY"
            searchDecision.startsWith("THINK_FIRST", true) -> "NO_NETWORK_UNLESS_EXPLICIT_DISCRIMINATOR"
            else -> "MAX_1_TO_2_QUERIES"
        }
        val handoffTrace = buildHandoffTrace(
            evidenceClosure = evidenceClosure,
            postSearchThinking = postSearchThinking,
            thinkingContinuity = thinkingContinuity,
            hypothesisGraph = hypothesisGraph,
            cognitiveMomentum = cognitiveMomentum,
            searchDecision = searchDecision,
            datasetForaging = datasetForaging
        )
        return LinkedCognitionSpineReport(
            active = true,
            state = state,
            linkIntegrityScore = linkIntegrityScore,
            routeMode = routeMode,
            governingLayer = governingLayer,
            connectedLayers = connected,
            disconnectedLayers = disconnected,
            openEvidenceKeys = openKeys,
            governingDecision = governingDecision,
            nextAction = nextAction,
            searchDecision = searchDecision.take(260),
            queryBudget = queryBudget,
            handoffTrace = handoffTrace,
            summary = "Linked cognition spine: $state; integrity=$linkIntegrityScore/100; governing=$governingLayer; mode=$routeMode; open=${openKeys.take(3).joinToString(", ").ifBlank { "none" }}."
        )
    }

    fun priorSearchDirective(recentReportJsonLines: List<String>): PriorSearchDirective {
        val latest = recentReportJsonLines.asSequence()
            .mapNotNull { line -> runCatching { JSONObject(line) }.getOrNull() }
            .firstOrNull() ?: return PriorSearchDirective.none()
        val spine = latest.optJSONObject("linkedCognitionSpineReport") ?: JSONObject()
        val active = spine.optBoolean("active", false)
        if (!active) return PriorSearchDirective.none()
        val searchDecision = spine.optString("searchDecision")
        val routeMode = spine.optString("routeMode")
        val mustConstrain = searchDecision.startsWith("NO_BROAD_SEARCH", true) ||
            searchDecision.startsWith("THINK_FIRST", true) ||
            searchDecision.startsWith("NARROW_SEARCH_ALLOWED", true) ||
            routeMode.contains("CLOSURE", true)
        if (!mustConstrain) return PriorSearchDirective.none()

        val closure = latest.optJSONObject("evidenceClosureReport") ?: JSONObject()
        val card = closure.optJSONArray("cards")?.optJSONObject(0) ?: JSONObject()
        val accession = card.optString("accession").takeIf { it.isNotBlank() && it != "none" }
        val openKeys = arrayToList(spine.optJSONArray("openEvidenceKeys"))
        val weakest = firstNonBlank(openKeys.firstOrNull().orEmpty(), spine.optString("governingLayer"), "outcome_labels")
        val noNetwork = searchDecision.startsWith("THINK_FIRST", true) && accession == null && openKeys.isEmpty()
        if (noNetwork) {
            return PriorSearchDirective(
                active = true,
                mode = "OFFLINE_THINK_ONLY",
                queries = emptyList(),
                reason = "Prior linked cognition spine requires offline discriminator selection before network search."
            )
        }
        val queryText = buildPriorQuery(latest, card, accession, weakest)
        val safeId = (accession ?: weakest).lowercase().replace(Regex("[^a-z0-9_]+"), "_").take(36).ifBlank { "gap" }
        val query = ResearchQuery(
            id = "q_v200_spine_lock_$safeId",
            label = "v1.10 linked spine: ${accession ?: weakest}",
            query = queryText.take(560),
            reason = "Prior linked cognition spine governs this cycle. It permits at most one evidence-closure query and blocks broad search."
        )
        return PriorSearchDirective(
            active = true,
            mode = when {
                accession != null -> "ACCESSION_CLOSURE_ONLY"
                searchDecision.startsWith("THINK_FIRST", true) -> "THINK_FIRST_SINGLE_DISCRIMINATOR"
                else -> "GRAPH_GAP_CLOSURE_ONLY"
            },
            queries = listOf(query),
            reason = searchDecision.ifBlank { spine.optString("governingDecision", "Prior linked spine constrains search.") }
        )
    }

    fun toJson(report: LinkedCognitionSpineReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("state", report.state)
        .put("linkIntegrityScore", report.linkIntegrityScore)
        .put("routeMode", report.routeMode)
        .put("governingLayer", report.governingLayer)
        .put("connectedLayers", JSONArray(report.connectedLayers))
        .put("disconnectedLayers", JSONArray(report.disconnectedLayers))
        .put("openEvidenceKeys", JSONArray(report.openEvidenceKeys))
        .put("governingDecision", report.governingDecision)
        .put("nextAction", report.nextAction)
        .put("searchDecision", report.searchDecision)
        .put("queryBudget", report.queryBudget)
        .put("handoffTrace", JSONArray(report.handoffTrace))
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun requiredLayersForCurrentState(
        evidenceClosure: EvidenceClosureReport,
        hypothesisGraph: HypothesisGraphReport,
        cognitiveMomentum: CognitiveMomentumReport,
        qualityGate: ScientificDiscoveryQualityGateReport,
        runbook: ScientificDiscoveryRunbookReport
    ): List<String> {
        val required = mutableListOf("evidence_closure", "post_search_thinking", "thinking_continuity")
        if (evidenceClosure.active || hypothesisGraph.active || cognitiveMomentum.active) required += "hypothesis_graph"
        if (hypothesisGraph.active || evidenceClosure.broadSearchBlocked) required += "cognitive_momentum"
        if (qualityGate.active) required += "quality_gate"
        if (runbook.active) required += "runbook"
        return required.distinct()
    }

    private fun computeIntegrityScore(
        connected: List<String>,
        disconnected: List<String>,
        openKeys: List<String>,
        executedQueries: List<ResearchQuery>,
        priorSpineWasActive: Boolean,
        hasAccession: Boolean,
        blocksBroadSearch: Boolean
    ): Int {
        val base = 30
        val connectedScore = connected.size * 8
        val gapScore = if (openKeys.isNotEmpty()) 12 else 4
        val accessionScore = if (hasAccession) 10 else 0
        val disciplineScore = when {
            blocksBroadSearch && executedQueries.size <= 1 -> 16
            executedQueries.size <= 2 -> 10
            else -> -12
        }
        val continuityScore = if (priorSpineWasActive) 8 else 0
        val disconnectedPenalty = disconnected.size * 10
        return (base + connectedScore + gapScore + accessionScore + disciplineScore + continuityScore - disconnectedPenalty).coerceIn(0, 100)
    }

    private fun buildPriorQuery(latest: JSONObject, card: JSONObject, accession: String?, weakest: String): String {
        val graph = latest.optJSONObject("hypothesisGraphReport") ?: JSONObject()
        val runbook = latest.optJSONObject("scientificDiscoveryRunbookReport") ?: JSONObject()
        val dominant = firstNonBlank(
            graph.optString("dominantHypothesis"),
            (latest.optJSONObject("thinkingContinuityReport") ?: JSONObject()).optString("mergedHypothesisLine"),
            "immune transcriptomic route"
        )
        val condition = arrayToList(card.optJSONArray("conditionLabels")).take(4).joinToString(" ")
        val runbookClause = runbook.optString("primaryQueryClause", "")
        return if (accession != null) {
            listOf(
                accession,
                condition.ifBlank { "dataset metadata" },
                weakest,
                "outcome recovery severity endpoint longitudinal time-course serial follow-up control comparator placebo negative control sample size condition labels license"
            ).joinToString(" ")
        } else {
            listOf(
                dominant,
                weakest,
                runbookClause,
                "outcome recovery severity endpoint longitudinal time-course control comparator negative control metadata sample size condition labels"
            ).joinToString(" ")
        }.replace(Regex("\\s+"), " ").trim()
    }

    private fun buildHandoffTrace(
        evidenceClosure: EvidenceClosureReport,
        postSearchThinking: PostSearchThinkingReport,
        thinkingContinuity: ThinkingContinuityReport,
        hypothesisGraph: HypothesisGraphReport,
        cognitiveMomentum: CognitiveMomentumReport,
        searchDecision: String,
        datasetForaging: DatasetForagingReport
    ): List<String> {
        val trace = mutableListOf<String>()
        if (datasetForaging.active) trace += "forager:${datasetForaging.state}->candidates=${datasetForaging.candidates.size}"
        if (evidenceClosure.active) trace += "closure:${evidenceClosure.mode}->${evidenceClosure.selectedAccession}"
        if (postSearchThinking.active) trace += "thinking:${postSearchThinking.state}->hypotheses=${postSearchThinking.hypotheses.size}"
        if (thinkingContinuity.active) trace += "continuity:${thinkingContinuity.state}->gaps=${thinkingContinuity.repeatedGaps.take(3).joinToString(",")}" 
        if (hypothesisGraph.active) trace += "graph:${hypothesisGraph.state}->weakest=${hypothesisGraph.weakestLink}"
        if (cognitiveMomentum.active) trace += "momentum:${cognitiveMomentum.state}->${cognitiveMomentum.momentumScore}/100"
        trace += "decision:$searchDecision"
        return trace.map { it.take(220) }.take(10)
    }

    private fun startsWithLock(value: String): Boolean {
        return value.startsWith("NO_BROAD_SEARCH", true) || value.startsWith("THINK_FIRST", true)
    }

    private fun arrayToList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { idx -> arr.optString(idx).takeIf { it.isNotBlank() } }
    }

    private fun normalizeKey(value: String): String = value.trim().lowercase()
        .replace(Regex("[^a-z0-9_]+"), "_")
        .trim('_')
        .replace("recovery_severity_response", "outcome_labels")
        .replace("control_comparator", "control_or_comparator")
        .replace("comparator_control", "control_or_comparator")
        .replace("timecourse", "time_order")

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}
