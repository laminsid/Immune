package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.13.16 — Legacy leak firewall.
 *
 * This is not a new scientific layer. It prevents legacy v2.12/v2.13 compatibility rails
 * from re-entering the active first surface or forcing the app to rebuild the old long
 * renderLines() tree on mobile/PDF output. Old rails stay available in JSON/export and
 * technical appendix for GitHub/audit compatibility only.
 */
object GTIMLegacyLeakFirewallV21316 {
    const val PATCH_VERSION: String = "2.13.15.1-legacy-leak-firewall-on-v2.13.15"
    const val ACTIVE_RELEASE_VERSION: String = "2.13.15-final-hypothesis-first-discovery-unified"
    const val STATE_READY: String = "LEGACY_LEAK_FIREWALL_READY"
    const val CLAIM_LIMIT: String = "legacy_leak_firewall_rendering_only_no_evidence_upgrade"

    fun shouldUseHypothesisFirstSurface(report: JSONObject): Boolean {
        if (!RuntimeFeatureFlags.ENABLE_HYPOTHESIS_FIRST_DISCOVERY_V21315) return false
        if (!RuntimeFeatureFlags.ENABLE_LEGACY_LEAK_FIREWALL_V21316) return GTIMFinalSurfaceDomainCoherenceGuardV21313.shouldUseMobileSafeSurface(report)
        return report.has("hypothesisFirstDiscoveryEngineV21315") ||
            report.has("domainScopedClosureRendererV21315") ||
            report.has("finalSurfaceDomainCoherenceGuardV21313") ||
            report.has("generalizedRouteCoherenceGuardV21314") ||
            report.has("finalVersionUnificationGuardV21314") ||
            GTIMFinalSurfaceDomainCoherenceGuardV21313.shouldUseMobileSafeSurface(report)
    }

    fun toJson(report: JSONObject): JSONObject {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val canonical = GTIMFinalSurfaceDomainCoherenceGuardV21313.canonicalTarget(report)
        val hidden = hiddenLegacyClosures(active)
        return JSONObject()
            .put("patchVersion", PATCH_VERSION)
            .put("activeReleaseVersion", ACTIVE_RELEASE_VERSION)
            .put("state", STATE_READY)
            .put("activeDomain", active)
            .put("canonicalTarget", canonical)
            .put("blocksOldRenderTreeOnFirstSurface", true)
            .put("studyResultCardUsesTechnicalRenderLines", false)
            .put("legacyClosuresHiddenFromFirstSurface", hidden)
            .put("legacyRailsPlacement", "json_export_or_technical_appendix_only")
            .put("mobilePolicy", "do_not_call_GlobalResearchGradeBrief_renderLines_for_hypothesis_first_surface")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Legacy leak firewall",
        "State: ${obj.optString("state", STATE_READY)}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none").ifBlank { "none" }}",
        "Policy: old v2.12/v2.13 compatibility rails stay linked but cannot drive first-surface decisions or mobile rendering.",
        "Hidden legacy closures: ${obj.optJSONArray("legacyClosuresHiddenFromFirstSurface")?.length() ?: 0}; old_render_tree_blocked=${obj.optBoolean("blocksOldRenderTreeOnFirstSurface", true)}; study_card_legacy_renderlines=${obj.optBoolean("studyResultCardUsesTechnicalRenderLines", false)}",
        "Boundary: rendering/firewall only; no mechanism, diagnosis, treatment, dosing, vaccine, efficacy, or validated discovery claim."
    )

    fun sanitizeFirstSurface(report: JSONObject, lines: List<String>): List<String> {
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val canonical = GTIMFinalSurfaceDomainCoherenceGuardV21313.canonicalTarget(report)
        val scoped = lines.flatMap { line -> sanitizeLine(line, active, canonical) }
        return GTIMFinalSurfaceDomainCoherenceGuardV21313.sanitizeFirstSurfaceLines(report, scoped)
    }

    fun sanitizeLine(line: String, activeDomain: String, canonicalTarget: String): List<String> {
        val trimmed = line.trimEnd()
        if (trimmed.isBlank()) return listOf(trimmed)
        val lower = trimmed.lowercase(Locale.US)

        if (lower.contains("final bundibugyo/bdbv") && activeDomain != "filovirus_viral_host_response") {
            return listOf("Compatibility appendix only: Final Bundibugyo/BDBV runtime closure is hidden from first surface for active_domain=$activeDomain.")
        }
        if (lower.contains("bundibugyo") && lower.contains("closure") && activeDomain != "filovirus_viral_host_response") {
            return listOf("Compatibility appendix only: Bundibugyo/filovirus closure is hidden from first surface for active_domain=$activeDomain.")
        }
        if (lower.startsWith("experimental claim relaxation mode") || lower.startsWith("preview allowed:")) {
            return listOf("Experimental preview policy: C0/C1/C2/C3 labels may be generated as sandbox hypotheses only; evidence upgrade and clinical/actionable claims remain blocked.")
        }
        if (lower.contains("active_domain=topic_level_route_needs_evidence") && activeDomain != "topic_level_route_needs_evidence") {
            return listOf("State: HYPOTHESIS_FIRST_ACTIVE_DOMAIN_LOCKED; active_domain=$activeDomain; canonical_target=${canonicalTarget.ifBlank { "none" }}; legacy topic-level state retained in appendix.")
        }
        if (lower.contains("selected_review_target=") || lower.contains("canonical_target=")) {
            val handles = Regex("\\bGSE\\d{3,8}\\b", RegexOption.IGNORE_CASE).findAll(trimmed).map { it.value.uppercase(Locale.US) }.distinct().toList()
            val bad = handles.firstOrNull { h -> !GTIMGeneralizedRouteCoherenceGuardV21314.targetCompatibleWithActiveDomain(activeDomain, h) }
            if (bad != null) {
                return listOf("Historical lookup only: $bad is cross-domain for active_domain=$activeDomain; first-surface target suppressed; retain only in appendix/history/contradiction.")
            }
        }
        return listOf(trimmed)
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        PATCH_VERSION,
        STATE_READY,
        "do_not_call_GlobalResearchGradeBrief_renderLines_for_hypothesis_first_surface",
        "studyResultCardUsesTechnicalRenderLines=false",
        "json_export_or_technical_appendix_only",
        CLAIM_LIMIT
    ))

    private fun hiddenLegacyClosures(activeDomain: String): JSONArray {
        val closures = listOf(
            "finalBundibugyoSearchRuntimeClosureV213106" to "filovirus_viral_host_response",
            "bundibugyoRuntimeStabilityClosureV213105" to "filovirus_viral_host_response"
        )
        return JSONArray(closures.filterNot { (_, domain) -> GTIMGeneralizedRouteCoherenceGuardV21314.domainCompatible(activeDomain, domain) }.map { it.first })
    }
}
