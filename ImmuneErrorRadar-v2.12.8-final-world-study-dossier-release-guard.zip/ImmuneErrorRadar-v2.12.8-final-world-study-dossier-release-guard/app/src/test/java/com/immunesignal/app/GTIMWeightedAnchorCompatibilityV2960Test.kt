package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMWeightedAnchorCompatibilityV2960Test {

    @Test
    fun covidSoftMetadataPassesWeightedAnchorReview() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val weighted = GTIMWeightedAnchorCompatibilityV2960.evaluateText(
            "COVID patient PBMC disease state: COVID case healthy control interferon IL-6",
            contract
        )

        assertEquals(GTIMWeightedAnchorCompatibilityV2960.PASS_STATE, weighted.state)
        assertTrue(weighted.score >= 4)
        assertTrue(weighted.line.contains("claim_limit="))
    }

    @Test
    fun diabetesContractRejectsGutDepressionStickyMetadata() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Diabetes")
        val weighted = GTIMWeightedAnchorCompatibilityV2960.evaluateText(
            "gut microbiome depression tryptophan kynurenine IL-6 TNF human cohort",
            contract
        )

        assertEquals(GTIMWeightedAnchorCompatibilityV2960.NO_MATCH_STATE, weighted.state)
        assertTrue(weighted.negativeHits.contains("depression"))
    }

    @Test
    fun softProbeMarksMismatchedRowsAsReviewOnlyInsteadOfParsedPass() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Diabetes")
        val report = JSONObject().put("geoSoftText", """
            ^SAMPLE = GSM7000001
            !Sample_title = gut microbiome depression stool cohort
            !Sample_characteristics_ch1 = disease state: major depression case
            !Sample_supplementary_file = https://ftp.ncbi.nlm.nih.gov/geo/series/GSE117nnn/GSE117882/suppl/GSE117882_matrix.mtx.gz
        """.trimIndent())
        val soft = GTIMGeoSoftMetadataProbeV2950.build(contract, fileDiscovery("GSE117882"), report)

        assertEquals("GEO_SOFT_METADATA_TOPIC_MISMATCH_REVIEW_ONLY", soft.state)
        assertTrue(soft.line.contains("weighted_anchor=${GTIMWeightedAnchorCompatibilityV2960.NO_MATCH_STATE}"))
    }

    private fun fileDiscovery(target: String): GTIMRepositoryFileDiscoveryReportV2800 =
        GTIMRepositoryFileDiscoveryReportV2800(
            active = true,
            targetId = target,
            repository = "GEO",
            state = "FILE_DISCOVERY_REQUEST_READY",
            candidateFileTypes = GTIMRepositoryFileDiscoveryV2800.MATRIX_FILE_SIGNATURES,
            repositoryLookupUrls = emptyList(),
            downloadMode = "USER_STARTED_PUBLIC_REPOSITORY_ONLY",
            fileDiscoveryLine = "test",
            downloadRequestLine = "test",
            boundaryLine = "test"
        )
}
