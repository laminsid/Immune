package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMTherapeuticReverseTranslationRouterV2790Test {

    @Test
    fun ebolaRendersSafeTherapeuticProtocolWithoutTreatmentClaim() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Ebola Bundibugyo countermeasure host response"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE131907")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("2.7.9.0-therapeutic-reverse-translation-router"))
        assertTrue(rendered.contains("EBOLA_HOST_RESPONSE_REVERSE_TRANSLATION"))
        assertTrue(rendered.contains("Therapeutic dataset requirement:"))
        assertTrue(rendered.contains("survivor_vs_fatal"))
        assertTrue(rendered.contains("no vaccine/pathogen engineering"))
        assertFalse(rendered.contains("treatment advice confirmed"))
        assertFalse(rendered.contains("DGE_READY_REVIEW_ONLY | biological proof"))
    }

    @Test
    fun diabetesLaneBuildsMetabolicImmuneDatasetRequirementNotInjectionReplacementClaim() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes insulin resistance GLP-1 beta cell inflammation"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE117882")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("DIABETES_METABOLIC_IMMUNE_REVERSE_TRANSLATION"))
        assertTrue(rendered.contains("metabolic inflammation"))
        assertTrue(rendered.contains("responder_vs_non_responder"))
        assertTrue(rendered.contains("research_route_only_no_diabetes_treatment_or_injection_replacement_claim") || rendered.contains("no_DGE_ready_from_therapeutic_reasoning=true"))
        assertFalse(rendered.contains("replace insulin"))
        assertFalse(rendered.contains("dose"))
    }

    @Test
    fun cancerLaneIsImmunotherapyResponseResistanceNotCancerCure() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Cancer immunotherapy PD-1 responder non-responder T cell exhaustion"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE72056")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("CANCER_IMMUNOTHERAPY_RESPONSE_REVERSE_TRANSLATION"))
        assertTrue(rendered.contains("responder_vs_non_responder"))
        assertTrue(rendered.contains("T-cell exhaustion") || rendered.contains("T cell exhaustion"))
        assertTrue(rendered.contains("no_cancer_cure") || rendered.contains("no efficacy claim"))
        assertFalse(rendered.contains("cancer cure confirmed"))
    }

    @Test
    fun briefExecutionSurfaceSplitPreservesLegacyEtlTokens() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid vaccine trial response"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("DGE execution bridge:"))
        assertTrue(rendered.contains("Matrix ETL bridge:"))
        assertTrue(rendered.contains("Matrix ETL evidence packet:"))
        assertTrue(rendered.contains("Unified final readiness:"))
        assertTrue(rendered.contains("Therapeutic reverse translation:"))
        assertTrue(rendered.contains("no_DGE_ready_from_therapeutic_reasoning=true"))
    }
}
