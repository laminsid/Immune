package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMMicrobialReversalEngineV2111Test {

    @Test
    fun microbialReversalIsConnectedToRootCauseDossierAndDataHarmonization() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            "microplastic pollution bacteria dysbiosis barrier neuroinflammation toxin microbiome root cause reversal"
        )
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(
            contract,
            "GSE211100",
            null,
            dgeBlocked("GSE211100")
        )
        val root = dossier.ecoImmuneRootCause!!
        val reversal = root.microbialReversal!!
        val harmonization = dossier.dataHarmonization!!
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(root.active)
        assertTrue(reversal.active)
        assertTrue(reversal.version.contains("2.11.1"))
        assertTrue(reversal.damageMechanisms.isNotEmpty())
        assertTrue(reversal.counterFunctions.isNotEmpty())
        assertTrue(reversal.candidateRoutes.isNotEmpty())
        assertTrue(reversal.studyPlans.isNotEmpty())
        assertTrue(root.rootCauseGraphState.contains("microbial_reversal="))
        assertTrue(joined.contains("microbial reversal engine"))
        assertTrue(joined.contains("counter-function"))
        assertTrue(joined.contains("not_treatment"))
        assertTrue(harmonization.sourceCapsules.any { it.sourceFamily == "microbial_reversal_function" })
        assertTrue(harmonization.solutionRoutes.any { it.routeClass == "microbial_reversal_counter_function_bridge" })
        assertFalse(joined.contains("recommended dose"))
        assertFalse(joined.contains("wet-lab protocol"))
        assertFalse(joined.contains("clinical management plan"))
    }

    @Test
    fun engineeredRoutesStayLongHorizonAndResearchOnly() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            "unknown exposome toxin sensor actor microbial counter mechanism future root cause"
        )
        val report = GTIMMicrobialReversalEngineV2111.build(
            contract = contract,
            corpus = "toxin exposome engineered living sensor actor hypothesis no human trial",
            rootCandidates = emptyList(),
            dgeVerdict = dgeBlocked("OPEN")
        )

        assertTrue(report.active)
        assertTrue(report.candidateRoutes.any { it.candidateClass.contains("engineered", true) })
        assertTrue(report.candidateRoutes.all { it.claimLimit.contains("not_treatment") })
        assertTrue(report.studyPlans.any { it.killCriteria.isNotEmpty() })
        assertTrue(report.boundaryLine.contains("not_wet_lab"))
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
