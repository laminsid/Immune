package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMPublicRequestPlanCacheExportV2990Test {

    @Test
    fun requestPlanCreatesReviewOnlyConnectorIntentsWithoutExecutingHttp() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid host response")
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(
            contract,
            fileDiscovery("GSE166552"),
            JSONObject()
                .put("geoSoftText", covidSoftText())
                .put("publicExpressionAvailability", JSONObject().put("greinAvailable", true).put("recount3Available", true))
        )

        val plan = requireNotNull(bridge.publicExpressionRequestPlan)
        assertEquals("REQUEST_PLAN_READY_REVIEW_ONLY", plan.state)
        assertTrue(plan.requests.any { it.sourceId == "GREIN" })
        assertTrue(plan.requests.any { it.sourceId == "recount3" })
        assertTrue(plan.line.contains("no_network_execution_inside_planner=true"))
        assertFalse(plan.line.contains("DGE_READY_INTERNAL"))
    }

    @Test
    fun requestPlanIsBlockedWhenTargetIsNotTopicCompatible() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("")
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(
            contract,
            fileDiscovery("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"),
            JSONObject()
        )

        assertEquals("REQUEST_PLAN_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", bridge.publicExpressionRequestPlan?.state)
        assertEquals("LEARNING_CACHE_EXPORT_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", bridge.learningCacheExport?.state)
    }

    @Test
    fun cacheExportWritesOnlySmallOperationalTables() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid host response")
        val capsule = JSONObject()
            .put("dataset_id", "GSE166552")
            .put("contrast_id", "covid_vs_control")
            .put("claim_limit", "research_summary_not_clinical_claim")
            .put("provenance_hashes", JSONArray().put("sha256:abc"))
            .put("top_genes", JSONArray().put(JSONObject().put("gene", "IFIT1").put("direction", "up")))
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(
            contract,
            fileDiscovery("GSE166552"),
            JSONObject()
                .put("geoSoftText", covidSoftText())
                .put("externalEvidenceCapsule", capsule)
                .put("publicExpressionAvailability", JSONObject().put("greinAvailable", true))
        )

        val export = requireNotNull(bridge.learningCacheExport)
        assertEquals("LEARNING_CACHE_EXPORT_READY_REVIEW_ONLY", export.state)
        assertTrue(export.tables.contains("gtim_soft_sample_rows"))
        assertTrue(export.tables.contains("gtim_public_expression_routes"))
        assertTrue(export.tables.contains("gtim_capsule_top_genes"))
        assertTrue(export.line.contains("local_operational_memory_only=true"))
        assertFalse(export.line.contains("raw_matrix"))
    }

    private fun fileDiscovery(target: String, state: String = "FILE_DISCOVERY_REQUEST_READY"): GTIMRepositoryFileDiscoveryReportV2800 =
        GTIMRepositoryFileDiscoveryReportV2800(
            active = true,
            targetId = target,
            repository = if (target.startsWith("GSE")) "GEO" else "repository not surfaced",
            state = state,
            candidateFileTypes = GTIMRepositoryFileDiscoveryV2800.MATRIX_FILE_SIGNATURES,
            repositoryLookupUrls = emptyList(),
            downloadMode = if (state.contains("BLOCKED")) "BLOCKED_BEFORE_TOPIC_TARGET_GATE" else "USER_STARTED_PUBLIC_REPOSITORY_ONLY",
            fileDiscoveryLine = "test",
            downloadRequestLine = "test",
            boundaryLine = "test"
        )

    private fun covidSoftText(): String = """
        ^SAMPLE = GSM5000001
        !Sample_title = Healthy donor PBMC control
        !Sample_characteristics_ch1 = disease state: healthy control
        !Sample_supplementary_file = https://ftp.ncbi.nlm.nih.gov/geo/series/GSE166nnn/GSE166552/suppl/GSE166552_matrix.mtx.gz
        ^SAMPLE = GSM5000002
        !Sample_title = COVID patient PBMC
        !Sample_characteristics_ch1 = disease state: COVID case
        !Sample_relation = SRA: SRP777001
    """.trimIndent()
}
