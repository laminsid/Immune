package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMRepairPriorityValidationV2113Test {

    @Test
    fun repairPriorityRanksRoutesWithBiomarkersAndFalsification() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            "joint pain fatigue inflammation gut barrier microbiome metabolic toxin repair route"
        )
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSE211300", null, dgeBlocked("GSE211300"))
        val root = dossier.ecoImmuneRootCause!!
        val priority = root.repairPriorityValidation!!
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(priority.active)
        assertTrue(priority.version.contains("2.11.3"))
        assertTrue(priority.priorityRoutes.isNotEmpty())
        assertTrue(priority.globalBiomarkerPlan.isNotEmpty())
        assertTrue(priority.globalFalsificationPlan.isNotEmpty())
        assertTrue(priority.priorityRoutes.all { it.biomarkerPlan.isNotEmpty() })
        assertTrue(priority.priorityRoutes.all { it.falsificationPlan.isNotEmpty() })
        assertTrue(root.rootCauseGraphState.contains("repair_priority="))
        assertTrue(joined.contains("repair priority validation"))
        assertTrue(joined.contains("biomarkers"))
        assertTrue(joined.contains("falsification"))
        assertFalse(joined.contains("clinical management plan"))
        assertFalse(joined.contains("treatment recommendation"))
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
