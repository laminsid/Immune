package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMTopicCompatibleDGETargetGateV2777Test {

    @Test
    fun backgroundHandlesDoNotBecomeSoftDgeDownloadTarget() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray()
                            .put("GSE250594")
                            .put("GSE131907")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("NO_TOPIC_COMPATIBLE_DGE_TARGET"))
        assertTrue(rendered.contains("TOPIC_COMPATIBLE_ACCESSION_REQUIRED"))
        assertTrue(rendered.contains("DGE_NOT_READY_NO_TOPIC_COMPATIBLE_ACCESSION"))
        assertFalse(rendered.contains("target=NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED | readiness=33/100 | matrix=SOFT_MATRIX_CANDIDATE_NEEDS_DOWNLOAD"))
        assertFalse(rendered.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED: download/locate supplementary raw counts"))
    }

    @Test
    fun validCovidAccessionStillGetsSoftDgeBridge() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("target=GSE166552"))
        assertTrue(rendered.contains("signal_source=observed_only_v2771"))
        assertTrue(rendered.contains("MATRIX_DOWNLOAD_REQUIRED"))
        assertFalse(rendered.contains("state=DGE_EXECUTION_READY_REVIEW_ONLY"))
    }
}
