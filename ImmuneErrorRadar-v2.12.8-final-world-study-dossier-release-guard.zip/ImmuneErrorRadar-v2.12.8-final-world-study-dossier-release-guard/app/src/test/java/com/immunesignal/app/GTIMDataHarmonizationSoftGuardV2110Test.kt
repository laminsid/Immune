package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMDataHarmonizationSoftGuardV2110Test {

    @Test
    fun heterogeneousEvidenceProducesRoutesWithoutCausalUpgrade() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            "microplastic air pollution food fraud microbiome metabolism allergy barrier root cause"
        )
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(
            contract,
            "GSE211000",
            null,
            dgeBlocked("GSE211000")
        )
        val report = dossier.dataHarmonization!!
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(dossier.version.contains("2.11.0"))
        assertTrue(report.active)
        assertTrue(report.state.contains("DATA_HARMONIZATION"))
        assertTrue(report.policy.contains("soft_guard"))
        assertTrue(report.solutionRoutes.isNotEmpty())
        assertTrue(report.solutionRoutes.any { it.outputState.contains("ROUTE", true) })
        assertTrue(joined.contains("data harmonization"))
        assertTrue(joined.contains("spurious"))
        assertTrue(joined.contains("research route"))
        assertFalse(joined.contains("causal conclusion allowed"))
        assertFalse(joined.contains("clinical management plan"))
    }

    @Test
    fun highSpuriousRiskIsDowngradedButNotBlocked() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("unknown external exposure without mechanism")
        val root = GTIMEcoImmuneRootCauseReportV2108.empty().copy(
            active = true,
            state = "ECO_IMMUNE_ROOT_CAUSE_OPEN_SCAN_NO_STRONG_ROUTE",
            candidates = emptyList(),
            restorationRoutes = emptyList(),
            falsificationPlans = emptyList()
        )
        val report = GTIMDataHarmonizationGuardV2110.build(
            contract = contract,
            metadataBridge = null,
            dgeVerdict = dgeBlocked("OPEN"),
            establishedEvidence = emptyList(),
            discoveryFindings = emptyList(),
            mechanismMap = emptyList(),
            ecoImmuneRootCause = root
        )

        assertTrue(report.active)
        assertNotNull(report.spuriousCorrelationAssessment)
        assertTrue(report.solutionRoutes.isNotEmpty())
        assertTrue(report.spuriousCorrelationAssessment!!.allowedOutputState.contains("ALLOW"))
        assertFalse(report.spuriousCorrelationAssessment!!.allowedOutputState.contains("BLOCK"))
        assertTrue(report.line.contains("boundary="))
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
