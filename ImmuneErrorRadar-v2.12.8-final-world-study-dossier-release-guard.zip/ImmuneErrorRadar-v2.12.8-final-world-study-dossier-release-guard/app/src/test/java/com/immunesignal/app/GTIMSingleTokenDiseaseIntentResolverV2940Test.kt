package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMSingleTokenDiseaseIntentResolverV2940Test {

    @Test
    fun ebolaSingleTokenIsDiseaseIntentNotUnspecified() {
        val intent = GTIMResearchIntentParserV255.parse("Ebola")
        assertTrue(intent.diseasePhenotype.any { it.contains("Ebola", ignoreCase = true) })
        assertTrue(intent.triggerExposure.any { it.contains("Ebola", ignoreCase = true) || it.contains("filovirus", ignoreCase = true) })
        assertFalse(intent.parsedResearchIntentCard.joinToString("\n").contains("Disease / phenotype: not specified"))
        assertTrue(intent.missingIntentFields.contains("pathway").not() || intent.pathway.isNotEmpty())
    }

    @Test
    fun diabetesSingleTokenIsDiseaseIntentNotUnspecified() {
        val intent = GTIMResearchIntentParserV255.parse("Diabetes")
        assertTrue(intent.diseasePhenotype.any { it.contains("Diabetes", ignoreCase = true) })
        assertTrue(intent.pathway.any { it.contains("insulin", ignoreCase = true) || it.contains("metabolic", ignoreCase = true) })
        assertFalse(intent.parsedResearchIntentCard.joinToString("\n").contains("Disease / phenotype: not specified"))
    }

    @Test
    fun covidStillKeepsStrongParsedIntent() {
        val intent = GTIMResearchIntentParserV255.parse("Covid")
        assertTrue(intent.diseasePhenotype.any { it.contains("COVID", ignoreCase = true) })
        assertTrue(intent.pathway.any { it.contains("interferon", ignoreCase = true) })
        assertTrue(intent.comparatorWanted.isNotEmpty())
    }
}
