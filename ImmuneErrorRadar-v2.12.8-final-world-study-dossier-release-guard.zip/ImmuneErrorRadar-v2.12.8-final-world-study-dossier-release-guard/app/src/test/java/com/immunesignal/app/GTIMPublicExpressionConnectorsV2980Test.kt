package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMPublicExpressionConnectorsV2980Test {

    @Test
    fun publicConnectorsAttachToMetadataFirstBridgeWithoutInternalDgeReady() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid host response")
        val report = JSONObject()
            .put("geoSoftText", covidSoftText())
            .put("externalProcessedAvailability", JSONObject().put("recount3Available", true).put("greinAvailable", true))
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(contract, fileDiscovery("GSE166552"), report)

        val publicSources = requireNotNull(bridge.publicExpressionSources)
        assertEquals("PUBLIC_EXPRESSION_ROUTE_AVAILABLE_REVIEW_ONLY", publicSources.state)
        assertTrue(publicSources.routes.any { it.sourceId == "GREIN" })
        assertTrue(publicSources.routes.any { it.sourceId == "recount3" })
        assertFalse(publicSources.line.contains("DGE_READY"))
        assertTrue(bridge.line.contains("public_sources=${publicSources.state}"))
    }

    @Test
    fun externalCapsuleRequiresProvenanceAndClaimLimitBeforeImport() {
        val rejected = GTIMExternalEvidenceCapsuleImporterV2980.build(
            "GSE166552",
            JSONObject().put("externalEvidenceCapsule", JSONObject().put("dataset_id", "GSE166552").put("contrast_id", "covid_vs_control"))
        )

        assertTrue(rejected.state.startsWith("CAPSULE_REJECTED_"))
        assertTrue(rejected.blockers.contains("claim_limit_missing"))
        assertTrue(rejected.blockers.contains("provenance_hash_missing"))
    }

    @Test
    fun externalCapsuleCanSurfaceResearchSummaryWithoutInternalDgeReady() {
        val capsule = JSONObject()
            .put("dataset_id", "GSE166552")
            .put("contrast_id", "covid_vs_control")
            .put("source", "offline_capsule_builder")
            .put("claim_limit", "research_summary_not_clinical_claim")
            .put("provenance_hashes", JSONArray().put("sha256:abc"))
            .put("top_genes", JSONArray()
                .put(JSONObject().put("gene", "IFIT1").put("direction", "up").put("log2fc", 2.1).put("padj", 0.001).put("rank", 1).put("axis", "interferon"))
                .put(JSONObject().put("gene", "IL6").put("direction", "up").put("log2fc", 1.1).put("padj", 0.04).put("rank", 2).put("axis", "cytokine")))
            .put("pathways", JSONArray().put(JSONObject().put("name", "type I interferon signaling").put("direction", "up").put("score", 0.88).put("support_genes", JSONArray().put("IFIT1"))))
        val report = GTIMExternalEvidenceCapsuleImporterV2980.build("GSE166552", JSONObject().put("externalEvidenceCapsule", capsule))

        assertEquals("CAPSULE_EXTERNAL_DGE_SUMMARY_AVAILABLE", report.state)
        assertEquals(2, report.topGenes.size)
        assertTrue(report.line.contains("external_summary_not_internal_dge_ready=true"))
        assertFalse(report.line.contains("DGE_READY_INTERNAL"))
    }

    @Test
    fun learningCacheStoresRouteMemoryNotMedicalTruth() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid host response")
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(
            contract,
            fileDiscovery("GSE166552"),
            JSONObject()
                .put("geoSoftText", covidSoftText())
                .put("publicExpressionAvailability", JSONObject().put("greinAvailable", true))
        )

        val cache = requireNotNull(bridge.learningCache)
        assertEquals("LEARNING_CACHE_RECORD_READY_FOR_LOCAL_REUSE", cache.state)
        assertTrue(cache.record.storedFields.contains("soft_sample_rows"))
        assertTrue(cache.record.storedFields.contains("public_expression_preferred_route"))
        assertTrue(cache.line.contains("cache_is_operational_memory_not_medical_truth=true"))
    }

    @Test
    fun noTopicTargetBlocksPublicSourceAndLearningCachePaths() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("")
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(
            contract,
            fileDiscovery("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"),
            JSONObject()
        )

        assertEquals("PUBLIC_SOURCES_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", bridge.publicExpressionSources?.state)
        assertEquals("LEARNING_CACHE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", bridge.learningCache?.state)
        assertEquals("CAPSULE_NOT_SUPPLIED", bridge.externalEvidenceCapsule?.state)
    }

    private fun fileDiscovery(target: String, state: String = "FILE_DISCOVERY_REQUEST_READY"): GTIMRepositoryFileDiscoveryReportV2800 =
        GTIMRepositoryFileDiscoveryReportV2800(
            active = true,
            targetId = target,
            repository = if (target.startsWith("GSE")) "GEO" else "repository not surfaced",
            state = state,
            candidateFileTypes = GTIMRepositoryFileDiscoveryV2800.MATRIX_FILE_SIGNATURES,
            repositoryLookupUrls = emptyList(),
            downloadMode = if (state.contains("BLOCKED")) "BLOCKED_BEFORE_TOPIC_TARGET_GATE" else "USER_STARTED_PUBLIC_REPOSITORY_ONLY",
            fileDiscoveryLine = "test",
            downloadRequestLine = "test",
            boundaryLine = "test"
        )

    private fun covidSoftText(): String = """
        ^SAMPLE = GSM5000001
        !Sample_title = Healthy donor PBMC control
        !Sample_characteristics_ch1 = disease state: healthy control
        !Sample_supplementary_file = https://ftp.ncbi.nlm.nih.gov/geo/series/GSE166nnn/GSE166552/suppl/GSE166552_matrix.mtx.gz
        ^SAMPLE = GSM5000002
        !Sample_title = COVID patient PBMC
        !Sample_characteristics_ch1 = disease state: COVID case
        !Sample_relation = SRA: SRP777001
    """.trimIndent()
}
