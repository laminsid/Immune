package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMActualEtlFinalRunContractV2803Test {

    @Test
    fun allConcreteEtlGatesClosedQueuesReviewOnlyDgeButDoesNotRunOrClaimSignals() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid host response GSE166552"))
            .put("observedRepositoryFiles", JSONArray()
                .put(JSONObject()
                    .put("file_name", "GSE166552_raw_counts.csv")
                    .put("source_url", "https://example.org/GSE166552_raw_counts.csv")
                    .put("size_bytes", 123456L)
                    .put("checksum_or_etag", "sha256:test-counts")
                    .put("download_timestamp", "2026-05-23T12:00:00Z")
                    .put("parser_hint", "count_table"))
                .put(JSONObject()
                    .put("file_name", "GSE166552_sample_metadata.tsv")
                    .put("source_url", "https://example.org/GSE166552_sample_metadata.tsv")
                    .put("size_bytes", 2048L)
                    .put("checksum_or_etag", "sha256:test-meta")
                    .put("download_timestamp", "2026-05-23T12:00:01Z")
                    .put("parser_hint", "sample_metadata")))
            .put("sampleMetadataRows", JSONArray()
                .put(JSONObject().put("sample_id", "GSM_A").put("source_field", "characteristics_ch1").put("evidence_snippet", "COVID patient severe disease case"))
                .put(JSONObject().put("sample_id", "GSM_B").put("source_field", "characteristics_ch1").put("evidence_snippet", "healthy control donor")))
            .put("matrixSampleIds", JSONArray().put("GSM_A").put("GSM_B"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("Actual ETL final run contract:"))
        assertTrue(rendered.contains("FINAL_ETL_READY_REVIEW_ONLY_DGE_NOT_RUN"))
        assertTrue(rendered.contains("QUEUE_REVIEW_ONLY_DGE_ALLOWED_NOT_EXECUTED"))
        assertTrue(rendered.contains("no_dge_values_produced=true"))
        assertTrue(rendered.contains("no_gene_pathway_claim_without_dge_output=true"))
        assertFalse(rendered.contains("clinical management"))
    }

    @Test
    fun finalRunContractStopsBeforeFileProbingWhenNoTopicCompatibleTargetExists() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes broad query"))
            .put("observedRepositoryFiles", JSONArray()
                .put(JSONObject()
                    .put("file_name", "raw_counts.csv")
                    .put("source_url", "https://example.org/raw_counts.csv")
                    .put("size_bytes", 100L)
                    .put("checksum_or_etag", "sha256:x")
                    .put("download_timestamp", "2026-05-23T12:00:00Z")
                    .put("parser_hint", "count_table")))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_TOPIC_COMPATIBLE_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("FINAL_ETL_STOP_NO_TOPIC_COMPATIBLE_TARGET"))
        assertTrue(rendered.contains("first_blocking_gate=P0_TOPIC_COMPATIBLE_TARGET"))
        assertTrue(rendered.contains("QUEUE_REVIEW_ONLY_DGE_BLOCKED"))
        assertFalse(rendered.contains("FINAL_ETL_READY_REVIEW_ONLY_DGE_NOT_RUN"))
    }

    @Test
    fun incompleteObservedFileEvidenceBlocksFinalDgeQueueEvenWithMetadata() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Allergies GSE250594"))
            .put("observedRepositoryFiles", JSONArray()
                .put(JSONObject()
                    .put("file_name", "GSE250594_counts.tsv")
                    .put("source_url", "https://example.org/GSE250594_counts.tsv")
                    .put("size_bytes", 222L)
                    .put("parser_hint", "count_table")))
            .put("sampleMetadataRows", JSONArray()
                .put(JSONObject().put("sample_id", "META_1").put("source_field", "characteristics_ch1").put("evidence_snippet", "allergy disease case"))
                .put(JSONObject().put("sample_id", "META_2").put("source_field", "characteristics_ch1").put("evidence_snippet", "healthy control")))
            .put("matrixSampleIds", JSONArray().put("META_1").put("META_2"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE250594")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("OBSERVED_FILE_EVIDENCE_PARTIAL_REVIEW_REQUIRED"))
        assertTrue(rendered.contains("FINAL_ETL_STOP_OBSERVED_FILE_EVIDENCE_REQUIRED"))
        assertFalse(rendered.contains("QUEUE_REVIEW_ONLY_DGE_ALLOWED_NOT_EXECUTED"))
    }
}
