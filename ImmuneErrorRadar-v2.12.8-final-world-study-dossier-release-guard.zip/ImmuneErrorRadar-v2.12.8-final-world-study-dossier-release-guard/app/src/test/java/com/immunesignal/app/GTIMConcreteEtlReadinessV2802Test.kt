package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMConcreteEtlReadinessV2802Test {

    @Test
    fun observedSupplementaryFilesMetadataLabelsAndSampleIdsProduceReviewOnlyDgeReadinessVerdict() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid host response GSE166552"))
            .put("observedRepositoryFiles", JSONArray()
                .put(JSONObject()
                    .put("file_name", "GSE166552_raw_counts.csv")
                    .put("source_url", "https://example.org/GSE166552_raw_counts.csv")
                    .put("size_bytes", 123456L)
                    .put("checksum_or_etag", "sha256:test-counts")
                    .put("download_timestamp", "2026-05-23T12:00:00Z")
                    .put("parser_hint", "count_table"))
                .put(JSONObject()
                    .put("file_name", "GSE166552_sample_metadata.tsv")
                    .put("source_url", "https://example.org/GSE166552_sample_metadata.tsv")
                    .put("size_bytes", 2048L)
                    .put("checksum_or_etag", "sha256:test-meta")
                    .put("download_timestamp", "2026-05-23T12:00:01Z")
                    .put("parser_hint", "sample_metadata")))
            .put("sampleMetadataRows", JSONArray()
                .put(JSONObject()
                    .put("sample_id", "GSM_A")
                    .put("source_field", "characteristics_ch1")
                    .put("evidence_snippet", "COVID patient severe disease case"))
                .put(JSONObject()
                    .put("sample_id", "GSM_B")
                    .put("source_field", "characteristics_ch1")
                    .put("evidence_snippet", "healthy control donor")))
            .put("matrixSampleIds", JSONArray().put("GSM_A").put("GSM_B"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("Supplementary file discovery:"))
        assertTrue(rendered.contains("SUPPLEMENTARY_FILES_OBSERVED_REVIEW_ONLY"))
        assertTrue(rendered.contains("Matrix file classifier:"))
        assertTrue(rendered.contains("MATRIX_FILE_CLASSIFIED_REVIEW_ONLY"))
        assertTrue(rendered.contains("Sample metadata extractor:"))
        assertTrue(rendered.contains("SAMPLE_METADATA_EXTRACTED_REVIEW_ONLY"))
        assertTrue(rendered.contains("Case/control label suggester:"))
        assertTrue(rendered.contains("CASE_CONTROL_LABELS_SUGGESTED_WITH_EVIDENCE"))
        assertTrue(rendered.contains("Sample-ID linkage verifier:"))
        assertTrue(rendered.contains("SAMPLE_ID_LINKAGE_CONFIRMED_REVIEW_ONLY"))
        assertTrue(rendered.contains("DGE readiness verdict:"))
        assertTrue(rendered.contains("DGE_READY_REVIEW_ONLY_NOT_RUN"))
        assertFalse(rendered.contains("clinical management"))
    }

    @Test
    fun observedFilesDoNotOverrideTopicCompatibleTargetGate() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes broad query"))
            .put("observedRepositoryFiles", JSONArray()
                .put(JSONObject()
                    .put("file_name", "raw_counts.csv")
                    .put("source_url", "https://example.org/raw_counts.csv")
                    .put("size_bytes", 100L)
                    .put("checksum_or_etag", "sha256:x")
                    .put("parser_hint", "count_table")))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_TOPIC_COMPATIBLE_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("SUPPLEMENTARY_DISCOVERY_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"))
        assertTrue(rendered.contains("MATRIX_CLASSIFICATION_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"))
        assertTrue(rendered.contains("DGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"))
        assertFalse(rendered.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED: download/locate supplementary raw counts"))
    }

    @Test
    fun missingSampleIdLinkageBlocksDgeEvenWhenMatrixAndLabelsExist() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Allergies GSE250594"))
            .put("observedRepositoryFiles", JSONArray()
                .put(JSONObject()
                    .put("file_name", "GSE250594_counts.tsv")
                    .put("source_url", "https://example.org/GSE250594_counts.tsv")
                    .put("size_bytes", 222L)
                    .put("checksum_or_etag", "sha256:counts")
                    .put("parser_hint", "count_table")))
            .put("sampleMetadataRows", JSONArray()
                .put(JSONObject().put("sample_id", "META_1").put("source_field", "characteristics_ch1").put("evidence_snippet", "allergy disease case"))
                .put(JSONObject().put("sample_id", "META_2").put("source_field", "characteristics_ch1").put("evidence_snippet", "healthy control")))
            .put("matrixSampleIds", JSONArray().put("MATRIX_X").put("MATRIX_Y"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE250594")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("SAMPLE_ID_LINKAGE_FAILED_REVIEW_REQUIRED"))
        assertTrue(rendered.contains("DGE_BLOCKED_SAMPLE_ID_LINKAGE_NOT_CONFIRMED"))
        assertFalse(rendered.contains("DGE_READY_REVIEW_ONLY_NOT_RUN"))
    }
}
