package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMMatrixEtlEvidencePacketV2781Test {

    @Test
    fun noTopicCompatibleTargetBlocksEvidencePacketBeforeFileProbe() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray()
                            .put("GSE250594")
                            .put("GSE131907")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("Matrix ETL evidence packet:"))
        assertTrue(rendered.contains("2.7.8.1-matrix-etl-evidence-packet"))
        assertTrue(rendered.contains("BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"))
        assertTrue(rendered.contains("candidate_files=none"))
        assertFalse(rendered.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED: file probe"))
        assertFalse(rendered.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED: download"))
    }

    @Test
    fun covidTargetSurfacesConcreteFileAndMetadataEvidencePacket() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("target=GSE166552"))
        assertTrue(rendered.contains("Matrix ETL evidence packet:"))
        assertTrue(rendered.contains("REPOSITORY_FILE_SIGNATURE_PROBE_REQUIRED"))
        assertTrue(rendered.contains("candidate_files=matrix.mtx,barcodes.tsv,features.tsv"))
        assertTrue(rendered.contains("required_fields=title,source_name,characteristics"))
        assertTrue(rendered.contains("output=suggestion+confidence+source_field+evidence_snippet"))
        assertTrue(rendered.contains("sample_linkage_checks=metadata_row_ids,matrix_column_ids"))
        assertFalse(rendered.contains("DGE_READY_REVIEW_ONLY | biological proof"))
    }

    @Test
    fun directPacketKeepsBoundaryAndNeverClaimsDownloadedFile() {
        val etl = GTIMMatrixEtlMetadataBridgeReportV2780(
            active = true,
            targetId = "GSE250594",
            etlState = "ETL_FILE_DISCOVERY_REQUIRED",
            readinessScore = 48,
            fileDiscoveryState = "FILE_DISCOVERY_REQUIRED",
            metadataNormalizationState = "METADATA_NORMALIZATION_CANDIDATE_REVIEW_ONLY",
            comparatorNormalizationState = "COMPARATOR_NORMALIZATION_REQUIRED",
            sampleIdLinkageState = "SAMPLE_ID_LINKAGE_PENDING_FILE_DISCOVERY",
            dgeReadinessVerdict = "DGE_BLOCKED_MATRIX_FILE_DISCOVERY_REQUIRED",
            nextStep = "GSE250594: run repository file discovery before DGE.",
            gates = listOf("FILE_DISCOVERY_REQUIRED:: locate matrix files."),
            summaryLine = "Matrix ETL bridge: target=GSE250594",
            metadataLine = "Metadata normalization: state=METADATA_NORMALIZATION_CANDIDATE_REVIEW_ONLY",
            boundaryLine = "Matrix ETL boundary: dataset-readiness routing only."
        )

        val packet = GTIMMatrixEtlEvidencePacketV2781.build(etl)

        assertTrue(packet.summaryLine.contains("Matrix ETL evidence packet:"))
        assertTrue(packet.fileProbeLine.contains("no_download_claim_until_file_seen=true"))
        assertTrue(packet.boundaryLine.contains("no file was downloaded"))
        assertTrue(packet.boundaryLine.contains("no DGE was run"))
        assertTrue(packet.boundaryLine.contains("no biological proof"))
    }
}
