package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMEcologicalRestorationSymptomOverlapV2112Test {

    @Test
    fun ecologicalRestorationAndSymptomOverlapAreConnectedToDossier() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            "fatigue fever gut inflammation barrier dysbiosis microplastic toxin microbiome restoration"
        )
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSE211200", null, dgeBlocked("GSE211200"))
        val root = dossier.ecoImmuneRootCause!!
        val restoration = root.ecologicalRestoration!!
        val overlap = root.symptomOverlap!!
        val harmonization = dossier.dataHarmonization!!
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(restoration.active)
        assertTrue(restoration.version.contains("2.11.2"))
        assertTrue(restoration.collapseSignals.isNotEmpty())
        assertTrue(restoration.restorationSequences.isNotEmpty())
        assertTrue(restoration.analogyGuard.any { it.contains("NOT_PROOF") })
        assertTrue(overlap.active)
        assertTrue(overlap.dysfunctionHypotheses.isNotEmpty())
        assertTrue(overlap.discriminatingEvidence.isNotEmpty())
        assertTrue(overlap.restorativeFunctionRoutes.isNotEmpty())
        assertTrue(root.rootCauseGraphState.contains("ecological_restoration="))
        assertTrue(root.rootCauseGraphState.contains("symptom_overlap="))
        assertTrue(harmonization.sourceCapsules.any { it.capsuleId == "CAPSULE_ECOLOGICAL_RESTORATION_CONTEXT" })
        assertTrue(harmonization.sourceCapsules.any { it.capsuleId == "CAPSULE_SYMPTOM_OVERLAP_CONTEXT" })
        assertTrue(joined.contains("symptoms are overlap signals not disease identity"))
        assertTrue(joined.contains("ecological restoration model"))
        assertTrue(joined.contains("symptom overlap resolver"))
        assertFalse(joined.contains("proven cure"))
        assertFalse(joined.contains("recommended dose"))
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
