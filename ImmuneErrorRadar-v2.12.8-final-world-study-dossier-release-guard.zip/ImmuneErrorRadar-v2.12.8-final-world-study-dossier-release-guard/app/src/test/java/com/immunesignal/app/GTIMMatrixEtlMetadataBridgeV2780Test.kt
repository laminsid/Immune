package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMMatrixEtlMetadataBridgeV2780Test {

    @Test
    fun noTopicCompatibleTargetBlocksEtlBeforeFileDiscovery() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray()
                            .put("GSE250594")
                            .put("GSE131907")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("v2.7.8.0-matrix-etl-metadata-normalization-bridge"))
        assertTrue(rendered.contains("Matrix ETL bridge:"))
        assertTrue(rendered.contains("NO_TOPIC_COMPATIBLE_ETL_TARGET"))
        assertTrue(rendered.contains("DGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"))
        assertTrue(rendered.contains("ETL_BLOCKED_BEFORE_FILE_DISCOVERY"))
        assertFalse(rendered.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED: run repository file discovery"))
    }

    @Test
    fun covidAccessionGetsEtlFileDiscoveryAndMetadataNormalizationSurface() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("target=GSE166552"))
        assertTrue(rendered.contains("Matrix ETL bridge:"))
        assertTrue(rendered.contains("ETL_FILE_DISCOVERY_REQUIRED"))
        assertTrue(rendered.contains("DGE_BLOCKED_MATRIX_FILE_DISCOVERY_REQUIRED"))
        assertTrue(rendered.contains("Metadata normalization:"))
        assertTrue(rendered.contains("evidence_snippet"))
        assertTrue(rendered.contains("Matrix ETL next:"))
        assertFalse(rendered.contains("DGE_READY_REVIEW_ONLY | biological proof"))
    }

    @Test
    fun matrixEtlBridgeDoesNotUpgradeSoftLeadToDgeResult() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Allergies")
        val card = GTIMMatrixAuditCardV2745.build(
            report = JSONObject().put("mechanismDiscoveryDossierReport", JSONObject()
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE250594"))))),
            contract = contract,
            fallbackSeedHandles = listOf("GSE250594"),
            paperUnderstandingSummary = "GSE250594 allergy hypersensitivity IgE mast cell eosinophil single-cell RNA-seq data availability comparator labels ambiguous"
        )

        val bridge = GTIMMatrixEtlMetadataBridgeV2780.build(card)

        assertTrue(bridge.summaryLine.contains("Matrix ETL bridge:"))
        assertTrue(bridge.summaryLine.contains("target=GSE250594"))
        assertTrue(bridge.dgeReadinessVerdict.startsWith("DGE_BLOCKED_"))
        assertFalse(bridge.summaryLine.contains("DGE_READY_REVIEW_ONLY"))
        assertTrue(bridge.boundaryLine.contains("no biological proof"))
    }
}
