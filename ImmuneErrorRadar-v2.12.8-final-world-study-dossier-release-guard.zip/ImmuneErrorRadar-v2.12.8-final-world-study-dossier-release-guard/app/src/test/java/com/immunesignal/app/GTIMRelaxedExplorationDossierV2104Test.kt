package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMRelaxedExplorationDossierV2104Test {

    @Test
    fun relaxedExplorationKeepsHypothesesOpenWhileLockingOnlyClinicalAction() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("rare immune genetic pathway microbiome cytokine novel therapeutic idea")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", null, dgeBlocked("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED"))
        val joined = dossier.conciseLines.joinToString("\n")

        assertTrue(dossier.version.contains("2.11.0"))
        assertTrue(dossier.explorationPosture?.line?.contains("authority_sources_are_validation_targets_not_discovery_blockers") == true)
        assertTrue(joined.contains("weak/partial/novel therapeutic-route hypotheses"))
        assertTrue(joined.contains("not_a_discovery_blocker=true"))
        assertFalse(joined.lowercase().contains("recommended dose"))
        assertFalse(joined.lowercase().contains("stop medication"))
        assertFalse(joined.lowercase().contains("clinical management plan"))
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
