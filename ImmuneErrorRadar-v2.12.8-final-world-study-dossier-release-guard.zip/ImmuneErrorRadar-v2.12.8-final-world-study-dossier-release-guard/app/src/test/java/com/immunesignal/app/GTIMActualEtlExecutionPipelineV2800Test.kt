package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMActualEtlExecutionPipelineV2800Test {

    @Test
    fun noTopicCompatibleTargetBlocksDownloadMatrixDgeAndSignals() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes reverse translation drug response"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_TOPIC_COMPATIBLE_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("2.8.0-actual-etl-execution-pipeline"))
        assertTrue(rendered.contains("Repository file discovery:"))
        assertTrue(rendered.contains("BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"))
        assertTrue(rendered.contains("Matrix reader preview:"))
        assertTrue(rendered.contains("MATRIX_READER_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"))
        assertTrue(rendered.contains("Review-only DGE:"))
        assertTrue(rendered.contains("DGE_NOT_RUN_REVIEW_ONLY_BLOCKED"))
        assertTrue(rendered.contains("Gene/pathway signal extractor:"))
        assertTrue(rendered.contains("GENE_PATHWAY_EXTRACTION_BLOCKED_DGE_NOT_RUN"))
        assertFalse(rendered.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED: download/locate supplementary raw counts"))
    }

    @Test
    fun concreteCovidAccessionSurfacesDownloadMatrixMetadataLinkageDgeAndSignalGates() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid therapeutic host response"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("target=GSE166552"))
        assertTrue(rendered.contains("Repository download request:"))
        assertTrue(rendered.contains("matrix.mtx"))
        assertTrue(rendered.contains("Matrix reader preview:"))
        assertTrue(rendered.contains("Metadata cleaner:"))
        assertTrue(rendered.contains("Sample ID linkage:"))
        assertTrue(rendered.contains("Review-only DGE:"))
        assertTrue(rendered.contains("DESeq2"))
        assertTrue(rendered.contains("Gene/pathway signal extractor:"))
        assertTrue(rendered.contains("no_gene_signal_claim_without_dge=true"))
        assertFalse(rendered.contains("biological proof from DGE"))
    }

    @Test
    fun splitModulesExposeVersionTokensForMaintenance() {
        assertTrue(GTIMRepositoryFileDiscoveryV2800.VERSION.contains("2.8.0"))
        assertTrue(GTIMMatrixReaderPreviewV2800.VERSION.contains("matrix-reader-preview"))
        assertTrue(GTIMMetadataCleanerV2800.VERSION.contains("metadata-cleaner"))
        assertTrue(GTIMSampleIdLinkageEngineV2800.VERSION.contains("sample-id-linkage"))
        assertTrue(GTIMReviewOnlyDgePipelineV2800.VERSION.contains("review-only-dge"))
        assertTrue(GTIMGenePathwaySignalExtractorV2800.VERSION.contains("gene-pathway"))
        assertTrue(GTIMActualEtlExecutionSurfaceV2800.VERSION.contains("actual-etl-execution-surface"))
    }
}
