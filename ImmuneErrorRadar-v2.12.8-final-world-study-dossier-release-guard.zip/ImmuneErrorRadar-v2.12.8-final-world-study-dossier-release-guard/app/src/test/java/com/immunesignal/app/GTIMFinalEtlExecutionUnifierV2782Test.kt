package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalEtlExecutionUnifierV2782Test {

    @Test
    fun finalSurfaceBlocksNoTopicCompatibleTargetBeforeEtlOrDge() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray()
                            .put("GSE250594")
                            .put("GSE131907")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("2.7.8.2-final-etl-execution-unification"))
        assertTrue(rendered.contains("Unified final readiness:"))
        assertTrue(rendered.contains("FINAL_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"))
        assertTrue(rendered.contains("SELECT_TOPIC_COMPATIBLE_ACCESSION_BEFORE_ETL_OR_DGE"))
        assertTrue(rendered.contains("stop_before_file_probe_if_no_topic_target=true"))
        assertFalse(rendered.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED: download"))
        assertFalse(rendered.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED probe matrix"))
    }

    @Test
    fun finalSurfaceTurnsCovidTargetIntoOrderedEtlExecutionPlan() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("target=GSE166552"))
        assertTrue(rendered.contains("Unified execution order: P0 target gate -> P1 file discovery -> P2 metadata normalization -> P3 comparator evidence -> P4 sample-id linkage -> P5 review-only DGE"))
        assertTrue(rendered.contains("FINAL_FILE_DISCOVERY_REQUIRED"))
        assertTrue(rendered.contains("RUN_REPOSITORY_FILE_DISCOVERY_FIRST"))
        assertTrue(rendered.contains("no_download_claim_until_file_seen=true"))
        assertFalse(rendered.contains("DGE_READY_REVIEW_ONLY | biological proof"))
    }

    @Test
    fun directUnifierKeepsClaimLocksAndDoesNotRunDge() {
        val etl = GTIMMatrixEtlMetadataBridgeReportV2780(
            active = true,
            targetId = "GSE250594",
            etlState = "ETL_FILE_DISCOVERY_REQUIRED",
            readinessScore = 48,
            fileDiscoveryState = "FILE_DISCOVERY_REQUIRED",
            metadataNormalizationState = "METADATA_NORMALIZATION_CANDIDATE_REVIEW_ONLY",
            comparatorNormalizationState = "COMPARATOR_NORMALIZATION_REQUIRED",
            sampleIdLinkageState = "SAMPLE_ID_LINKAGE_PENDING_FILE_DISCOVERY",
            dgeReadinessVerdict = "DGE_BLOCKED_MATRIX_FILE_DISCOVERY_REQUIRED",
            nextStep = "GSE250594: run repository file discovery before DGE.",
            gates = listOf("FILE_DISCOVERY_REQUIRED:: locate matrix files."),
            summaryLine = "Matrix ETL bridge: target=GSE250594",
            metadataLine = "Metadata normalization: state=METADATA_NORMALIZATION_CANDIDATE_REVIEW_ONLY",
            boundaryLine = "Matrix ETL boundary: dataset-readiness routing only."
        )
        val packet = GTIMMatrixEtlEvidencePacketV2781.build(etl)
        val card = GTIMMatrixAuditCardReportV2745(
            active = true,
            targetId = "GSE250594",
            repository = "GEO",
            assayPlatform = "Single-cell RNA-seq",
            inspectedAbstractsCount = 0,
            extractedDesignModel = "not surfaced",
            matrixState = "DGE_NOT_READY_COMPARATOR_MAPPED_MATRIX_MISSING",
            dgeReadinessScore = 72,
            verifiedMetadataSlots = listOf("COMPARATOR_MAPPED"),
            blockingGaps = listOf("SOFT_MATRIX_LEAD_REVIEW:: raw/count matrix file is not directly verified."),
            nextDecisiveQuery = "GSE250594 sample table comparator raw counts",
            claimLockStatus = "NO_CLAIM",
            summaryLine = "Matrix audit: target=GSE250594",
            researchValueState = "COMPARATOR_REVIEW_LEAD",
            dgeExecutionState = "DGE_EXECUTION_BRIDGE_READY_SOFT",
            dgeExecutionBridgeLine = "DGE execution bridge: signal_source=observed_only_v2771 | state=DGE_EXECUTION_BRIDGE_READY_SOFT",
            dgeExecutionNextLine = "DGE execution next: boundary=review-only | MATRIX_DOWNLOAD_REQUIRED raw counts count matrix"
        )

        val unified = GTIMFinalEtlExecutionUnifierV2782.build(
            matrixAuditCard = card,
            etlBridge = etl,
            evidencePacket = packet,
            treatmentKnowledge = GTIMTreatmentKnowledgeReportV2772.empty(),
            treatmentExecution = GTIMTreatmentExecutionBridgeReportV2773.empty(),
            finalExecution = GTIMFinalExecutionReadinessReportV2774.empty()
        )

        assertTrue(unified.readinessLine.contains("FINAL_FILE_DISCOVERY_REQUIRED"))
        assertTrue(unified.executionOrderLine.contains("P0 target gate"))
        assertTrue(unified.stopRulesLine.contains("stop_before_dge_if_matrix_metadata_comparator_or_linkage_unclosed=true"))
        assertTrue(unified.boundaryLine.contains("no DGE was run"))
        assertTrue(unified.boundaryLine.contains("no biological proof"))
    }
}
