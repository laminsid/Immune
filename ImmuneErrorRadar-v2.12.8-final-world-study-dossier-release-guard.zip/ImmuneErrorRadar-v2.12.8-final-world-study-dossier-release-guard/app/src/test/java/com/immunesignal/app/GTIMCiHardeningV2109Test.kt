package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMCiHardeningV2109Test {

    @Test
    fun ciGuardPassesWhenRootCauseFreeSynthesisAndLedgerAreConnected() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            "root cause immune microbiome metabolism mucosal variant failure restoration hypothesis"
        )
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(
            contract,
            "GSE210900",
            null,
            dgeBlocked("GSE210900")
        )
        val guard = dossier.ciHardeningGuard!!
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(dossier.version.contains("2.11.0"))
        assertTrue(guard.active)
        assertTrue(guard.state.contains("PASS"))
        assertTrue(guard.blockers.isEmpty())
        assertTrue(joined.contains("ci hardening guard"))
        assertTrue(joined.contains("root_cause_active=true"))
        assertFalse(joined.contains("recommended dose"))
        assertFalse(joined.contains("clinical management plan"))
        assertFalse(joined.contains("proven cure"))
    }

    @Test
    fun ciGuardIsQualityLayerNotBiomedicalLogic() {
        val report = GTIMCiHardeningGuardV2109.build(
            dossierVersion = "2.10.9-ci-hardening-root-cause-dossier-internal-extension",
            rootCause = rootReport(),
            freeHypothesis = freeReport(),
            learningLedger = ledgerReport()
        )

        assertTrue(report.version.contains("2.10.9"))
        assertTrue(report.line.contains("github_ci_compile_regression_guard_no_new_biomedical_logic"))
        assertTrue(report.checks.any { it.contains("no_network_execution=true") })
        assertTrue(report.checks.any { it.contains("no_android_ui_dependency=true") })
        assertTrue(report.blockers.isEmpty())
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )

    private fun rootReport(): GTIMEcoImmuneRootCauseReportV2108 = GTIMEcoImmuneRootCauseReportV2108(
        active = true,
        version = GTIMEcoImmuneRootCauseEngineV2108.VERSION,
        state = "ECO_IMMUNE_ROOT_CAUSE_OPEN_RESEARCH_ROUTES",
        philosophy = GTIMEcoImmuneRootCauseEngineV2108.PHILOSOPHY,
        rootCauseGraphState = "test",
        candidates = listOf(
            GTIMEcoImmuneRootCauseCandidateV2108(
                candidateId = "TEST_ROOT",
                state = "OPEN",
                upstreamDysfunction = "ecological_function_loss",
                causalChain = "microbiome -> metabolism -> immune tone",
                restorationNeed = "restore missing function",
                supportingSignals = listOf("test"),
                missingEvidence = listOf("metadata"),
                falsificationTests = listOf("negative comparator"),
                contextModifiers = listOf("context"),
                priority = "MEDIUM",
                line = "root-cause candidate"
            )
        ),
        restorationRoutes = listOf(
            GTIMEcosystemRestorationRouteV2108(
                routeId = "RESTORE_TEST",
                routeClass = "microbiome_metabolite_function_restoration",
                restorationLogic = "test",
                researchLevers = listOf("test"),
                requiredEvidence = listOf("test"),
                safetyBoundary = "not_treatment_protocols",
                line = "eco restoration route"
            )
        ),
        falsificationPlans = listOf(
            GTIMRootCauseFalsificationPlanV2108(
                planId = "RCF_TEST",
                candidateId = "TEST_ROOT",
                decisiveTests = listOf("test"),
                weakeningSignals = listOf("test"),
                invalidationRule = "test",
                line = "root-cause falsification plan"
            )
        ),
        endpointFailureChecks = listOf("test"),
        contextEcologyModifiers = listOf("test"),
        boundaryLine = GTIMEcoImmuneRootCauseEngineV2108.BOUNDARY,
        line = "root report"
    )

    private fun freeReport(): GTIMFreeHypothesisSynthesisReportV2105 = GTIMFreeHypothesisSynthesisReportV2105(
        active = true,
        version = GTIMFreeHypothesisSynthesisEngineV2105.VERSION,
        state = "FREE_SYNTHESIS_OPEN_RESEARCH_ROUTES_AVAILABLE",
        synthesisMode = "test",
        foundationUse = "test",
        cards = listOf(
            GTIMFreeHypothesisSynthesisCardV2105(
                cardId = "FREE_TEST",
                state = "OPEN_FREE_SYNTHESIS_RESEARCH_ONLY",
                routeClass = "test_research_route",
                hypothesis = "test",
                mechanismBasis = "test",
                crossDomainAnalogy = "test",
                supportBasis = listOf("test"),
                missingEvidence = listOf("test"),
                falsificationTests = listOf("test"),
                explorationRank = "E_MECHANISM_ONLY",
                boundary = "research_only",
                line = "free hypothesis"
            )
        ),
        antiHallucinationLocks = GTIMFreeHypothesisSynthesisEngineV2105.ANTI_HALLUCINATION_LOCKS,
        boundaryLine = GTIMFreeHypothesisSynthesisEngineV2105.BOUNDARY,
        line = "free report"
    )

    private fun ledgerReport(): GTIMHypothesisLearningLedgerReportV2106 = GTIMHypothesisLearningLedgerReportV2106(
        active = true,
        version = GTIMHypothesisLearningLedgerV2106.VERSION,
        state = "HYPOTHESIS_LEDGER_RESEARCH_ROUTES_CAPTURED",
        entries = listOf(
            GTIMHypothesisLearningLedgerEntryV2106(
                entryId = "LEDGER_TEST",
                sourceCardId = "FREE_TEST",
                routeClass = "test_research_route",
                hypothesis = "test",
                learningStatus = "research_memory_only",
                nextProofTasks = listOf("test"),
                reinforcementSignals = listOf("test"),
                weakeningSignals = listOf("test"),
                falsificationPriority = "STANDARD_FALSIFICATION_PRIORITY",
                reusableLearningKey = "test",
                line = "ledger entry"
            )
        ),
        exportPolicy = GTIMHypothesisLearningLedgerV2106.EXPORT_POLICY,
        learningBoundary = GTIMHypothesisLearningLedgerV2106.BOUNDARY,
        line = "ledger report"
    )
}
