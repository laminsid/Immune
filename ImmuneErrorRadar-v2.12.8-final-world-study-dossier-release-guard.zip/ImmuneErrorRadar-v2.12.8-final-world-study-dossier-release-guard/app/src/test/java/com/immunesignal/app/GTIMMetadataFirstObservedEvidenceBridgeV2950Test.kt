package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMMetadataFirstObservedEvidenceBridgeV2950Test {

    @Test
    fun covidSoftMetadataProbeDoesNotRequireMatrixDownload() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid host response")
        val report = JSONObject().put("geoSoftText", covidSoftText())
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(contract, fileDiscovery("GSE166552"), report)

        assertEquals("GEO_SOFT_METADATA_PARSED_REVIEW_ONLY", bridge.softProbe.state)
        assertTrue(bridge.softProbe.sampleRows.size >= 2)
        assertTrue(bridge.softProbe.supplementaryFiles.any { it.fileName.contains("matrix", ignoreCase = true) })
        assertTrue(bridge.line.contains("no_dge_ready_from_metadata=true"))
        assertFalse(bridge.externalAvailability.state.contains("DGE_READY"))
    }

    @Test
    fun ebolaGseToSrpMappingRunsBeforeExternalAvailability() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Ebola")
        val report = JSONObject()
            .put("geoSoftText", ebolaSoftText())
            .put("externalProcessedAvailability", JSONObject().put("recount3Available", true))
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(contract, fileDiscovery("GSE131907"), report)

        assertEquals("SRP_MAPPING_FOUND", bridge.gseToSrpMapping.state)
        assertTrue(bridge.gseToSrpMapping.srpAccessions.contains("SRP999001"))
        assertEquals("EXTERNAL_PROCESSED_EXPRESSION_AVAILABLE", bridge.externalAvailability.state)
        assertTrue(bridge.externalAvailability.line.contains("never_equals_dge_ready=true"))
    }

    @Test
    fun diabetesDoesNotReuseGutDepressionStickyTargetBeforeProbe() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Diabetes")
        val candidate = GTIMMatrixAuditTargetCandidateV2748(
            id = "GSE117882",
            source = "fallbackSeedHandles",
            context = "gut microbiome depression tryptophan kynurenine",
            score = 90,
            reason = "previous run target"
        )

        val gate = GTIMTargetQueryConsistencyGateV2940.evaluate(candidate, contract)

        assertFalse(gate.etlTargetAllowed)
        assertEquals(GTIMTargetQueryConsistencyGateV2940.NEAR_MATCH_STATE, gate.surfaceState)
    }

    @Test
    fun comparatorSuggestionRequiresSnippetAndSourceFieldFromSoftRows() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val report = JSONObject().put("geoSoftText", covidSoftText())
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(contract, fileDiscovery("GSE166552"), report)
        val metadata = GTIMSampleMetadataExtractionReportV2802(
            active = true,
            targetId = "GSE166552",
            state = "SAMPLE_METADATA_EXTRACTED_REVIEW_ONLY",
            rows = bridge.softProbe.sampleRows,
            extractedFields = listOf("GEO_SOFT"),
            line = "test",
            boundaryLine = "test"
        )

        val labels = GTIMCaseControlLabelSuggesterV2802.build(metadata)

        assertEquals("CASE_CONTROL_LABELS_SUGGESTED_WITH_EVIDENCE", labels.state)
        assertTrue(labels.suggestions.all { it.sourceField.isNotBlank() && it.evidenceSnippet.isNotBlank() })
    }

    @Test
    fun largeObservedFileRoutesToTooLargeForDeviceNotDgeReady() {
        val soft = GTIMSoftMetadataProbeReportV2950(
            active = true,
            targetId = "GSE131907",
            state = "GEO_SOFT_METADATA_PARSED_REVIEW_ONLY",
            softUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE131907&targ=gsm&form=text",
            sampleRows = emptyList(),
            supplementaryFiles = listOf(GTIMObservedRepositoryFileV2802(
                fileName = "GSE131907_RAW.tar",
                sourceUrl = "https://ftp.ncbi.nlm.nih.gov/geo/series/GSE131nnn/GSE131907/suppl/GSE131907_RAW.tar",
                sizeBytes = 2_500_000_000L,
                checksumOrEtag = "etag",
                downloadTimestamp = "head_only",
                parserHint = "ARCHIVE_CONTAINER"
            )),
            sraAccessions = listOf("SRP999001"),
            bioProjectAccessions = emptyList(),
            line = "test",
            boundaryLine = "test"
        )

        val policy = GTIMDeviceFilePolicyV2950.build("GSE131907", soft, emptyList())

        assertEquals("OBSERVED_FILE_TOO_LARGE_FOR_DEVICE", policy.state)
        assertTrue(policy.line.contains("no_large_matrix_download_on_device=true"))
    }

    @Test
    fun blankAutonomousRunDoesNotReusePreviousTargetForMetadataBridge() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("")
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(
            contract,
            fileDiscovery("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", state = "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"),
            JSONObject()
        )

        assertEquals("METADATA_FIRST_BRIDGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", bridge.state)
        assertEquals("SRP_MAPPING_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", bridge.gseToSrpMapping.state)
        assertTrue(bridge.deviceFilePolicy.state.contains("BLOCKED_NO_TOPIC"))
    }


    @Test
    fun softSupplementaryReferencesDoNotCreateDgeReadyWithoutObservedFileEvidence() {
        val matrixClassifier = GTIMMatrixFileClassificationReportV2802(
            active = true,
            targetId = "GSE166552",
            state = "MATRIX_FILE_CLASSIFIED_REVIEW_ONLY",
            matrixFileTypes = listOf("mtx_gz"),
            parserPlan = listOf("parse_market_matrix_review_only"),
            line = "test",
            boundaryLine = "test"
        )
        val metadata = GTIMSampleMetadataExtractionReportV2802(
            active = true,
            targetId = "GSE166552",
            state = "SAMPLE_METADATA_EXTRACTED_REVIEW_ONLY",
            rows = listOf(
                GTIMSampleMetadataRowV2802("GSM1", "GEO_SOFT_SAMPLE", "disease state: healthy control", "disease state: healthy control"),
                GTIMSampleMetadataRowV2802("GSM2", "GEO_SOFT_SAMPLE", "disease state: COVID case", "disease state: COVID case")
            ),
            extractedFields = listOf("GEO_SOFT"),
            line = "test",
            boundaryLine = "test"
        )
        val labels = GTIMCaseControlLabelSuggesterV2802.build(metadata)
        val linkage = GTIMSampleIdLinkageVerificationReportV2802(
            active = true,
            targetId = "GSE166552",
            state = "SAMPLE_ID_LINKAGE_CONFIRMED_REVIEW_ONLY",
            metadataSampleCount = 2,
            matrixSampleCount = 2,
            matchedSampleCount = 2,
            missingFromMatrix = emptyList(),
            missingFromMetadata = emptyList(),
            line = "test",
            boundaryLine = "test"
        )
        val observed = GTIMObservedFileEvidenceReportV2801(
            active = true,
            targetId = "GSE166552",
            state = "OBSERVED_FILE_EVIDENCE_REQUIRED",
            observedFileCount = 0,
            observedFileTypes = emptyList(),
            requiredEvidenceFields = listOf("file_name", "source_url", "size_bytes", "checksum_or_etag", "download_timestamp", "parser_hint"),
            observedFileLine = "test",
            boundaryLine = "test"
        )
        val verdict = GTIMDgeReadinessVerdictV2802.build(
            targetId = "GSE166552",
            matrixClassifier = matrixClassifier,
            metadata = metadata,
            labels = labels,
            linkage = linkage,
            observedFileEvidence = observed
        )

        assertEquals("DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE", verdict.verdict)
        assertTrue(verdict.line.contains("observed_file_evidence=OBSERVED_FILE_EVIDENCE_REQUIRED"))
    }

    private fun fileDiscovery(target: String, state: String = "FILE_DISCOVERY_REQUEST_READY"): GTIMRepositoryFileDiscoveryReportV2800 =
        GTIMRepositoryFileDiscoveryReportV2800(
            active = true,
            targetId = target,
            repository = if (target.startsWith("GSE")) "GEO" else "repository not surfaced",
            state = state,
            candidateFileTypes = GTIMRepositoryFileDiscoveryV2800.MATRIX_FILE_SIGNATURES,
            repositoryLookupUrls = emptyList(),
            downloadMode = if (state.contains("BLOCKED")) "BLOCKED_BEFORE_TOPIC_TARGET_GATE" else "USER_STARTED_PUBLIC_REPOSITORY_ONLY",
            fileDiscoveryLine = "test",
            downloadRequestLine = "test",
            boundaryLine = "test"
        )

    private fun covidSoftText(): String = """
        ^SAMPLE = GSM5000001
        !Sample_title = Healthy donor PBMC control
        !Sample_characteristics_ch1 = disease state: healthy control
        !Sample_supplementary_file = https://ftp.ncbi.nlm.nih.gov/geo/series/GSE166nnn/GSE166552/suppl/GSE166552_matrix.mtx.gz
        ^SAMPLE = GSM5000002
        !Sample_title = COVID patient PBMC
        !Sample_characteristics_ch1 = disease state: COVID case
        !Sample_relation = SRA: SRP777001
    """.trimIndent()

    private fun ebolaSoftText(): String = """
        ^SAMPLE = GSM6000001
        !Sample_title = Ebola virus disease patient blood
        !Sample_characteristics_ch1 = disease state: Ebola virus disease case
        !Sample_relation = SRA: SRP999001
        ^SAMPLE = GSM6000002
        !Sample_title = healthy survivor control
        !Sample_characteristics_ch1 = disease state: healthy control
    """.trimIndent()
}
