package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMMedicalResearchDossierV2100Test {

    @Test
    fun dossierSeparatesEstablishedScienceFromGtimDiscovery() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("colon cancer MSI dMMR immunotherapy DNA repair")
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(
            contract,
            fileDiscovery("GSE999001"),
            JSONObject()
                .put("geoSoftText", cancerSoftText())
                .put("publicExpressionAvailability", JSONObject().put("greinAvailable", true))
        )
        val dge = dgeBlocked("GSE999001")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSE999001", bridge, dge)

        assertTrue(dossier.active)
        assertTrue(dossier.establishedEvidence.any { it.cardId == "ESTABLISHED_ONCO_BIOMARKER_FIRST" })
        assertTrue(dossier.discoveryFindings.any { it.sourceLayer == "metadata_first_bridge" })
        assertTrue(dossier.conciseLines.any { it.contains("Established science:") })
        assertTrue(dossier.conciseLines.any { it.contains("GTIM discovery:") })
        assertTrue(dossier.boundaryLine.contains("not clinical trial"))
    }

    @Test
    fun therapeuticRoutesRemainHypothesesAndNeverTreatmentAdvice() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("colon cancer triple attack apoptosis DNA damage mitotic arrest")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(
            contract,
            "GSE999001",
            null,
            dgeBlocked("GSE999001")
        )

        assertTrue(dossier.therapeuticRoutes.any { it.routeId == "ROUTE_ONCO_CELL_CYCLE_APOPTOSIS" })
        assertTrue(dossier.therapeuticRoutes.all { it.forbiddenClaims.contains("no dosing") })
        assertTrue(dossier.conciseLines.any { it.contains("not tested") || it.contains("authority") })
        assertFalse(dossier.conciseLines.joinToString("\n").contains("DGE_READY_INTERNAL"))
    }

    @Test
    fun externalCapsuleIsDiscoveryNotAuthorityValidatedResult() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid host response")
        val capsule = JSONObject()
            .put("dataset_id", "GSE166552")
            .put("contrast_id", "covid_vs_control")
            .put("claim_limit", "research_summary_not_clinical_claim")
            .put("provenance_hashes", JSONArray().put("sha256:abc"))
            .put("top_genes", JSONArray().put(JSONObject().put("gene", "IFIT1").put("direction", "up")))
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(
            contract,
            fileDiscovery("GSE166552"),
            JSONObject().put("geoSoftText", covidSoftText()).put("externalEvidenceCapsule", capsule)
        )
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSE166552", bridge, dgeBlocked("GSE166552"))

        assertTrue(dossier.discoveryFindings.any { it.validationStatus == "GTIM_DISCOVERY_NOT_VALIDATED_BY_REGULATORY_OR_CLINICAL_AUTHORITY" })
        assertTrue(dossier.validationLimits.any { it.limitId == "LIMIT_AUTHORITY_NOT_VALIDATED" })
        assertEquals("RESEARCH_DOSSIER_WITH_EXPLORATORY_UNVALIDATED_FINDINGS", dossier.evidenceDossierGrade)
    }

    private fun fileDiscovery(target: String): GTIMRepositoryFileDiscoveryReportV2800 =
        GTIMRepositoryFileDiscoveryReportV2800(
            active = true,
            targetId = target,
            repository = if (target.startsWith("GSE")) "GEO" else "repository not surfaced",
            state = "FILE_DISCOVERY_REQUEST_READY",
            candidateFileTypes = GTIMRepositoryFileDiscoveryV2800.MATRIX_FILE_SIGNATURES,
            repositoryLookupUrls = emptyList(),
            downloadMode = "USER_STARTED_PUBLIC_REPOSITORY_ONLY",
            fileDiscoveryLine = "test",
            downloadRequestLine = "test",
            boundaryLine = "test"
        )

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )

    private fun covidSoftText(): String = """
        ^SAMPLE = GSM5000001
        !Sample_title = Healthy donor PBMC control
        !Sample_characteristics_ch1 = disease state: healthy control
        ^SAMPLE = GSM5000002
        !Sample_title = COVID patient PBMC
        !Sample_characteristics_ch1 = disease state: COVID case
        !Sample_relation = SRA: SRP777001
    """.trimIndent()

    private fun cancerSoftText(): String = """
        ^SAMPLE = GSM9000001
        !Sample_title = dMMR colorectal tumor sample
        !Sample_characteristics_ch1 = disease state: colorectal cancer
        !Sample_characteristics_ch1 = biomarker: dMMR
        !Sample_relation = SRA: SRP999001
    """.trimIndent()
}
