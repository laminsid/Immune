package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMTargetQueryConsistencyGateV2940Test {

    @Test
    fun diabetesVsMicrobiomeDoesNotPassGutDepressionTarget() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Diabetes vs microbiome")
        val candidate = GTIMMatrixAuditTargetCandidateV2748(
            id = "GSE117882",
            source = "fallbackSeedHandles",
            context = "microbiome depression kynurenine IL-6 TNF single-cell RNA-seq",
            score = 75,
            reason = "background microbiome depression handle"
        )
        val gate = GTIMTargetQueryConsistencyGateV2940.evaluate(candidate, contract)
        assertFalse(gate.etlTargetAllowed)
        assertEquals("TARGET_BLOCKED_ROUTE_MISMATCH", gate.state)
        assertEquals(GTIMTargetQueryConsistencyGateV2940.NEAR_MATCH_STATE, gate.surfaceState)
    }

    @Test
    fun previousGutDepressionTargetCannotLeakIntoDiabetesRun() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Diabetes")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE117882")))))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE117882"),
            paperUnderstandingSummary = "previous route: gut microbiome depression target=GSE117882"
        )
        assertEquals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", card.targetId)
        assertTrue(card.accessionBridgeStatus.contains("NO_TOPIC_COMPATIBLE", ignoreCase = true))
    }

    @Test
    fun gutDepressionNearMatchIsReviewOnlyNotEtlTarget() {
        val contract = GTIMRunDecisionContractFactoryV2740.buildAutonomousSelectedTopic(
            rawQuery = "gut bacteria depression tryptophan kynurenine IL-6 TNF human cohort dataset",
            hasDatasetAccessions = true,
            matrixState = "DGE_NOT_READY_ACCESSION_HANDLE_CAPTURED_MATRIX_UNRESOLVED"
        )
        val candidate = GTIMMatrixAuditTargetCandidateV2748(
            id = "GSE117882",
            source = "paperLite",
            context = "gut microbiome depression tryptophan kynurenine IL-6 TNF GSE117882",
            score = 55,
            reason = "NEAR_MATCH_TOPIC_COMPATIBLE_REVIEW for gut_microbiome_to_neuroinflammation"
        )
        val gate = GTIMTargetQueryConsistencyGateV2940.evaluate(candidate, contract)
        assertFalse(gate.etlTargetAllowed)
        assertEquals("TARGET_HELD_FOR_NEAR_MATCH_REVIEW", gate.state)
        assertEquals(GTIMTargetQueryConsistencyGateV2940.NEAR_MATCH_STATE, gate.surfaceState)
    }
}
