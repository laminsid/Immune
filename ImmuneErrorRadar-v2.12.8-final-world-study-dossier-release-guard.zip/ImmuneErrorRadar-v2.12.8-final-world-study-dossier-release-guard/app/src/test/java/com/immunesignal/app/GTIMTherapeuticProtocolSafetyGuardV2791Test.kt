package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMTherapeuticProtocolSafetyGuardV2791Test {

    @Test
    fun therapeuticSurfaceShowsSafetyGateAndDoesNotBypassEtlSpine() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Ebola Bundibugyo therapeutic countermeasure host response"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE131907")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("2.7.9.1-therapeutic-protocol-safety-guard"))
        assertTrue(rendered.contains("Therapeutic safety gate:"))
        assertTrue(rendered.contains("etl_dependency=v2.7.8.2_final_etl_execution_unification"))
        assertTrue(rendered.contains("therapeutic_reasoning_cannot_open_dge_or_file_probe_without_etl_gate=true"))
        assertTrue(rendered.contains("Therapeutic safety stops:"))
        assertTrue(rendered.contains("no DGE_READY from therapeutic reasoning alone"))
        assertFalse(rendered.contains("Therapeutic protocol says DGE_READY"))
    }

    @Test
    fun noTopicCompatibleTargetBlocksTherapeuticProtocolBeforeFileProbe() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes reverse translation drug response"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_TOPIC_COMPATIBLE_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("THERAPEUTIC_PROTOCOL_BLOCKED_UNTIL_TOPIC_COMPATIBLE_TARGET") || rendered.contains("target_required_before_etl=true"))
        assertTrue(rendered.contains("no treatment advice"))
        assertFalse(rendered.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED: download/locate supplementary raw counts"))
    }

    @Test
    fun surfaceSplitKeepsTherapeuticRenderingOutOfBriefExecutionSurface() {
        val surfaceSource = GTIMBriefExecutionSurfaceV2790.VERSION
        assertTrue(surfaceSource.contains("brief-execution-surface-split"))
        assertTrue(GTIMTherapeuticProtocolSurfaceV2791.VERSION.contains("therapeutic-protocol-surface-split"))
    }
}
