package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMMedicalStudyStructureDossierV2101Test {

    @Test
    fun finalDossierIncludesPicoSearchEvidenceTableAndAuthorityGuard() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("colon cancer MSI dMMR immunotherapy DNA repair")
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(
            contract,
            fileDiscovery("GSE999101"),
            JSONObject()
                .put("geoSoftText", cancerSoftText())
                .put("publicExpressionAvailability", JSONObject().put("greinAvailable", true))
        )
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(
            contract = contract,
            targetId = "GSE999101",
            metadataBridge = bridge,
            dgeVerdict = dgeBlocked("GSE999101")
        )

        assertNotNull(dossier.researchProtocol)
        assertNotNull(dossier.searchStrategy)
        assertTrue(dossier.researchProtocol!!.framework.contains("PICO"))
        assertTrue(dossier.searchStrategy!!.databases.any { it.contains("GEO") })
        assertTrue(dossier.evidenceTable.any { it.rowId.startsWith("EVIDENCE_ESTABLISHED") })
        assertTrue(dossier.evidenceTable.any { it.rowId.startsWith("EVIDENCE_GTIM_DISCOVERY") })
        assertTrue(dossier.authorityValidationStatements.any { it.notYetValidatedStatement.contains("not tested", ignoreCase = true) || it.notYetValidatedStatement.contains("not approved", ignoreCase = true) })
        assertTrue(dossier.conciseLines.any { it.startsWith("Research protocol:") })
        assertTrue(dossier.conciseLines.any { it.startsWith("Search strategy:") })
        assertTrue(dossier.conciseLines.any { it.startsWith("Evidence table:") })
        assertTrue(dossier.conciseLines.any { it.startsWith("Authority validation:") })
    }

    @Test
    fun externalCapsuleStillDoesNotCreateTreatmentOrAuthorityClaim() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid interferon host response")
        val capsule = JSONObject()
            .put("dataset_id", "GSE166552")
            .put("contrast_id", "covid_vs_control")
            .put("claim_limit", "research_summary_not_clinical_claim")
            .put("provenance_hashes", JSONArray().put("sha256:abc"))
            .put("top_genes", JSONArray().put(JSONObject().put("gene", "IFIT1").put("direction", "up")))
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(
            contract,
            fileDiscovery("GSE166552"),
            JSONObject().put("geoSoftText", covidSoftText()).put("externalEvidenceCapsule", capsule)
        )
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSE166552", bridge, dgeBlocked("GSE166552"))
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(dossier.version.contains("2.11.0"))
        assertTrue(dossier.authorityValidationStatements.any { it.validationStatus.contains("NOT_VALIDATED", true) || it.notYetValidatedStatement.contains("not tested", true) })
        assertFalse(joined.contains("clinical management plan"))
        assertFalse(joined.contains("recommended dose"))
        assertFalse(joined.contains("proven treatment"))
        assertFalse(joined.contains("dge_ready_internal"))
    }

    private fun fileDiscovery(target: String): GTIMRepositoryFileDiscoveryReportV2800 =
        GTIMRepositoryFileDiscoveryReportV2800(
            active = true,
            targetId = target,
            repository = if (target.startsWith("GSE")) "GEO" else "repository not surfaced",
            state = "FILE_DISCOVERY_REQUEST_READY",
            candidateFileTypes = GTIMRepositoryFileDiscoveryV2800.MATRIX_FILE_SIGNATURES,
            repositoryLookupUrls = emptyList(),
            downloadMode = "USER_STARTED_PUBLIC_REPOSITORY_ONLY",
            fileDiscoveryLine = "test",
            downloadRequestLine = "test",
            boundaryLine = "test"
        )

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )

    private fun covidSoftText(): String = """
        ^SAMPLE = GSM5000001
        !Sample_title = Healthy donor PBMC control
        !Sample_characteristics_ch1 = disease state: healthy control
        ^SAMPLE = GSM5000002
        !Sample_title = COVID patient PBMC
        !Sample_characteristics_ch1 = disease state: COVID case
        !Sample_relation = SRA: SRP777001
    """.trimIndent()

    private fun cancerSoftText(): String = """
        ^SAMPLE = GSM9000001
        !Sample_title = dMMR colorectal tumor sample
        !Sample_characteristics_ch1 = disease state: colorectal cancer
        !Sample_characteristics_ch1 = biomarker: dMMR
        !Sample_relation = SRA: SRP999101
    """.trimIndent()
}
