package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMObservedFileEvidenceContractV2801Test {

    @Test
    fun candidateFileSignaturesDoNotBecomeObservedMatrixEvidence() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid host response GSE166552"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("Observed file evidence:"))
        assertTrue(rendered.contains("OBSERVED_FILE_EVIDENCE_REQUIRED"))
        assertTrue(rendered.contains("candidate_signatures_are_not_observed_files=true"))
        assertTrue(rendered.contains("MATRIX_READER_WAITING_FOR_OBSERVED_FILE_EVIDENCE"))
        assertTrue(rendered.contains("OBSERVED_MATRIX_FILE_EVIDENCE_REQUIRED"))
        assertFalse(rendered.contains("DGE_READY_REVIEW_ONLY_PENDING_RUN"))
        assertFalse(rendered.contains("MATRIX_READER_SCHEMA_CANDIDATE_REVIEW_ONLY | target=GSE166552"))
    }

    @Test
    fun noTopicCompatibleTargetBlocksObservedFileEvidenceToo() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes broad topic"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_TOPIC_COMPATIBLE_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("OBSERVED_FILE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"))
        assertTrue(rendered.contains("MATRIX_READER_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET"))
        assertFalse(rendered.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED: download/locate supplementary raw counts"))
    }

    @Test
    fun observedFileEvidenceContractExposesMaintenanceVersion() {
        assertTrue(GTIMObservedFileEvidenceContractV2801.VERSION.contains("2.8.1"))
    }
}
