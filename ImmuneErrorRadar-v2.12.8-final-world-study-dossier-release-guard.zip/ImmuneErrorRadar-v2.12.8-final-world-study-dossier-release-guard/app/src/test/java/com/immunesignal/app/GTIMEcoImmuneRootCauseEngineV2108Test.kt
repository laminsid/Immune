package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMEcoImmuneRootCauseEngineV2108Test {

    @Test
    fun rootCauseEngineSearchesUpstreamDysfunctionBeforeSymptomSuppression() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("COVID vaccine breakthrough fever variant mucosal microbiome metabolic immune failure")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSE210800", null, dgeBlocked("GSE210800"))
        val root = dossier.ecoImmuneRootCause!!
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(dossier.version.contains("2.11.0"))
        assertTrue(root.active)
        assertTrue(root.philosophy.contains("foundation_not_ceiling"))
        assertTrue(root.candidates.isNotEmpty())
        assertTrue(root.restorationRoutes.isNotEmpty())
        assertTrue(root.falsificationPlans.isNotEmpty())
        assertTrue(joined.contains("searches upstream root dysfunction before symptom suppression"))
        assertTrue(joined.contains("eco-immune root-cause engine"))
        assertTrue(joined.contains("root-cause candidate"))
        assertTrue(joined.contains("eco restoration route"))
        assertTrue(joined.contains("root-cause falsification plan"))
        assertFalse(joined.contains("recommended dose"))
        assertFalse(joined.contains("clinical management plan"))
        assertFalse(joined.contains("proven cure"))
    }

    @Test
    fun restorationRoutesRemainResearchOnlyAndDoNotBlockExploration() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("rare allergy skin gut fermentation histamine microbiome ecological deficit novel hypothesis")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", null, dgeBlocked("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED"))
        val root = dossier.ecoImmuneRootCause!!
        val free = dossier.freeHypothesisSynthesis!!

        assertTrue(root.boundaryLine.contains("research_hypotheses_only"))
        assertTrue(root.restorationRoutes.any { it.safetyBoundary.contains("not_treatment_protocols") })
        assertTrue(root.contextEcologyModifiers.any { it.contains("transferability") || it.contains("population_context") })
        assertTrue(free.cards.any { card ->
            card.missingEvidence.any { it.contains("microbiome", true) || it.contains("metabolic", true) || it.contains("upstream", true) || it.contains("barrier", true) }
        })
    }

    @Test
    fun openTopicStillGetsRootCauseScanWithoutDiseaseWhitelist() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("unexplained immune tissue stress ecology restoration path")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "OPEN_TOPIC", null, dgeBlocked("OPEN_TOPIC"))
        val root = dossier.ecoImmuneRootCause!!

        assertTrue(root.candidates.isNotEmpty())
        assertTrue(root.contextEcologyModifiers.isNotEmpty())
        assertTrue(root.endpointFailureChecks.any { it.contains("symptom relief") })
        assertTrue(root.line.contains("traditional_evidence_is_foundation_not_ceiling"))
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
