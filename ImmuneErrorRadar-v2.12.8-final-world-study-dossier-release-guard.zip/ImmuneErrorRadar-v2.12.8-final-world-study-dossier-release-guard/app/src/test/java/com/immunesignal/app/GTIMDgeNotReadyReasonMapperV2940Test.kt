package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMDgeNotReadyReasonMapperV2940Test {

    @Test
    fun observedFileStopMapsToUsefulDgeNotReadyReason() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val card = GTIMMatrixAuditCardV2745.build(
            report = org.json.JSONObject(),
            contract = contract,
            fallbackSeedHandles = listOf("GSE166552"),
            paperUnderstandingSummary = "COVID SARS-CoV-2 PBMC GSE166552 metadata sample control"
        )
        val etlBridge = GTIMMatrixEtlMetadataBridgeV2780.build(card)
        val packet = GTIMMatrixEtlEvidencePacketV2781.build(etlBridge)
        val treatmentKnowledge = GTIMTreatmentKnowledgeLayerV2772.evaluate(org.json.JSONObject(), contract, card, card.dgeExecutionBridgeLine)
        val treatmentExecution = GTIMTreatmentExecutionBridgeV2773.build(contract, treatmentKnowledge, card)
        val finalExecution = GTIMFinalExecutionReadinessV2774.build(card, treatmentKnowledge, treatmentExecution)
        val finalEtl = GTIMFinalEtlExecutionUnifierV2782.build(card, etlBridge, packet, treatmentKnowledge, treatmentExecution, finalExecution)
        val therapeutic = GTIMTherapeuticReverseTranslationRouterV2790.build(contract, treatmentKnowledge, treatmentExecution, finalEtl, card)
        val actual = GTIMActualEtlExecutionPipelineV2800.build(contract, card, etlBridge, finalEtl, therapeutic, org.json.JSONObject())
        val finalRun = GTIMActualEtlFinalRunContractV2803.build(actual)
        val label = GTIMDgeNotReadyReasonMapperV2940.label(actual, finalRun)
        assertEquals("DGE_NOT_READY_TARGET_FOUND_FILE_MISSING", label)
        assertTrue(GTIMDgeNotReadyReasonMapperV2940.line(actual, finalRun).contains("no_gene_pathway_without_dge=true"))
    }
}
