package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFreeHypothesisSynthesisV2105Test {

    @Test
    fun freeSynthesisUsesEstablishedScienceAsFoundationNotCeiling() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("colon cancer DNA repair MSI checkpoint apoptosis immune visibility novel combination")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSE210500", null, dgeBlocked("GSE210500"))
        val synthesis = dossier.freeHypothesisSynthesis
        val joined = dossier.conciseLines.joinToString("\n")

        assertTrue(dossier.version.contains("2.11.0"))
        assertTrue(synthesis?.active == true)
        assertTrue(synthesis?.foundationUse?.contains("foundation") == true)
        assertTrue(synthesis?.cards?.isNotEmpty() == true)
        assertTrue(joined.contains("traditional evidence is the foundation, not the ceiling"))
        assertTrue(joined.contains("Free hypothesis card:"))
        assertTrue(joined.contains("falsify="))
        assertFalse(joined.lowercase().contains("recommended dose"))
        assertFalse(joined.lowercase().contains("stop medication"))
        assertFalse(joined.lowercase().contains("clinical management plan"))
    }

    @Test
    fun unknownTopicStillGetsOpenFalsifiableHypothesisInsteadOfBeingBlocked() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("rare unexplained immune genetic syndrome tissue stress unusual mediator")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", null, dgeBlocked("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED"))
        val synthesis = dossier.freeHypothesisSynthesis
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(synthesis?.state?.contains("FREE_SYNTHESIS") == true)
        assertTrue(synthesis?.cards?.any { it.missingEvidence.isNotEmpty() && it.falsificationTests.isNotEmpty() } == true)
        assertTrue(joined.contains("authority_is_weight_not_blocker=true"))
        assertTrue(joined.contains("novel") || joined.contains("open"))
        assertFalse(joined.contains("proven treatment"))
        assertFalse(joined.contains("patient-specific"))
    }

    @Test
    fun synthesisLocksHallucinationByRequiringMechanismMissingEvidenceAndFalsification() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("autoimmune B cell CD19 cytokine reset hypothesis")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSEAUTO", null, dgeBlocked("GSEAUTO"))
        val synthesis = dossier.freeHypothesisSynthesis!!
        val card = synthesis.cards.first()

        assertTrue(synthesis.antiHallucinationLocks.contains("no_hypothesis_without_mechanism_basis"))
        assertTrue(synthesis.antiHallucinationLocks.contains("must_state_missing_evidence"))
        assertTrue(synthesis.antiHallucinationLocks.contains("must_state_falsification_tests"))
        assertTrue(card.mechanismBasis.isNotBlank())
        assertTrue(card.missingEvidence.isNotEmpty())
        assertTrue(card.falsificationTests.isNotEmpty())
        assertTrue(card.boundary.contains("not_clinical_claim"))
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
