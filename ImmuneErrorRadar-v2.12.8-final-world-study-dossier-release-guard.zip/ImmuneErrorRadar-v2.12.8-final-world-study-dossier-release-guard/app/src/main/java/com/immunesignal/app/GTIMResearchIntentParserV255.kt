package com.immunesignal.app

import java.util.Locale

/**
 * GTIM v2.5.5 Research Intent Parser.
 *
 * Converts a free-form or structured biomedical research question into a stable contract that
 * downstream route selection, data-feed planning, accession search, comparator mapping, matrix
 * readiness, contradiction search, and UI rendering can consume. This is intentionally local and
 * deterministic; it does not add network access, telemetry, or clinical inference.
 */
data class GTIMResearchIntentObjectV255(
    val active: Boolean,
    val parserVersion: String,
    val sourceText: String,
    val inputMode: String,
    val diseasePhenotype: List<String>,
    val triggerExposure: List<String>,
    val pathway: List<String>,
    val cellTissue: List<String>,
    val assayType: List<String>,
    val repositoryTargets: List<String>,
    val comparatorWanted: List<String>,
    val speciesPriority: String,
    val outputMode: String,
    val claimStrictness: String,
    val contradictionRequirement: String,
    val labValidationRequirement: String,
    val intentCompletenessScore: Int,
    val routeConstructionScore: Int,
    val queryReadinessScore: Int,
    val missingIntentFields: List<String>,
    val parsedResearchIntentCard: List<String>,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty(): GTIMResearchIntentObjectV255 = GTIMResearchIntentObjectV255(
            active = false,
            parserVersion = GTIMResearchIntentParserV255.VERSION,
            sourceText = "",
            inputMode = "NO_RESEARCH_INTENT_TEXT",
            diseasePhenotype = emptyList(),
            triggerExposure = emptyList(),
            pathway = emptyList(),
            cellTissue = emptyList(),
            assayType = emptyList(),
            repositoryTargets = GTIMResearchIntentParserV255.DEFAULT_REPOSITORIES,
            comparatorWanted = emptyList(),
            speciesPriority = "human_first_animal_auxiliary_only",
            outputMode = "discovery brief, no raw JSON by default",
            claimStrictness = "discovery_flexible_evidence_upgrade_strict_clinical_forbidden",
            contradictionRequirement = "contradiction/null-result search required for every candidate route",
            labValidationRequirement = "preliminary lab protocol draft allowed, not validation claim",
            intentCompletenessScore = 0,
            routeConstructionScore = 0,
            queryReadinessScore = 0,
            missingIntentFields = listOf("disease/phenotype", "trigger/exposure", "pathway", "cell/tissue", "assay", "comparator"),
            parsedResearchIntentCard = listOf("Parsed Research Intent: not available")
        )
    }
}

object GTIMResearchIntentParserV255 {
    const val VERSION: String = "2.7.3-final-proof-benchmark-learning-locked"
    const val STATE_INTENT_PARSED: String = "INTENT_PARSED_OPEN_DISCOVERY"

    val DEFAULT_REPOSITORIES: List<String> = listOf(
        "GEO", "SRA", "ArrayExpress", "BioProject", "ImmPort", "Europe PMC", "OpenAlex", "PubMed Data Availability", "Manual PMID/DOI/PDF/snippet seed"
    )

    private val structuredKeys: Map<String, Regex> = mapOf(
        "disease" to Regex("(?im)^\\s*(Disease\\s*/\\s*phenotype|Disease|Phenotype)\\s*:\\s*(.+)$"),
        "trigger" to Regex("(?im)^\\s*(Trigger\\s*/\\s*exposure|Trigger|Exposure)\\s*:\\s*(.+)$"),
        "pathway" to Regex("(?im)^\\s*(Pathway|Suspected pathway)\\s*:\\s*(.+)$"),
        "cell" to Regex("(?im)^\\s*(Cell\\s*/\\s*tissue|Cell|Tissue)\\s*:\\s*(.+)$"),
        "assay" to Regex("(?im)^\\s*(Assay|Assay type)\\s*:\\s*(.+)$"),
        "repository" to Regex("(?im)^\\s*(Repositories|Repository target|Must-search repositories)\\s*:\\s*(.+)$"),
        "comparator" to Regex("(?im)^\\s*(Comparator|Comparator wanted)\\s*:\\s*(.+)$"),
        "contradiction" to Regex("(?im)^\\s*(Contradiction|Main contradiction to check)\\s*:\\s*(.+)$"),
        "output" to Regex("(?im)^\\s*(Output|Output mode)\\s*:\\s*(.+)$")
    )

    fun parse(question: String, fallbackAxis: String = ""): GTIMResearchIntentObjectV255 {
        val raw = listOf(question, fallbackAxis).filter { it.isNotBlank() }.joinToString("\n").trim()
        if (raw.isBlank()) return GTIMResearchIntentObjectV255.empty()
        val forcedClosureGuard = GTIMForcedClosureCommandGuardV2737.evaluate(raw)
        val routingText = GTIMForcedClosureCommandGuardV2737.rewriteForRouting(raw)
        val structured = structuredKeys.mapValues { (_, regex) -> regex.find(routingText)?.groupValues?.getOrNull(2).orEmpty() }
        val structuredMode = structured.values.any { it.isNotBlank() }
        val extractedDisease = splitTerms(structured["disease"]).ifEmpty { extractTerms(routingText, DISEASE_TERMS) }
        val extractedTrigger = splitTerms(structured["trigger"]).ifEmpty { extractTerms(routingText, TRIGGER_TERMS) }
        val extractedPathway = splitTerms(structured["pathway"]).ifEmpty { extractTerms(routingText, PATHWAY_TERMS) }
        val extractedCell = splitTerms(structured["cell"]).ifEmpty { extractTerms(routingText, CELL_TISSUE_TERMS) }
        val extractedAssay = splitTerms(structured["assay"]).ifEmpty { extractTerms(routingText, ASSAY_TERMS) }
        val repositories = splitTerms(structured["repository"]).ifEmpty { extractTerms(routingText, REPOSITORY_TERMS).ifEmpty { DEFAULT_REPOSITORIES } }
        val extractedComparator = splitTerms(structured["comparator"]).ifEmpty { extractComparator(routingText) }
        val semanticDefaults = enrichSingleTopicDefaults(
            routingText,
            extractedDisease,
            extractedTrigger,
            extractedPathway,
            extractedCell,
            extractedAssay,
            extractedComparator
        )
        val disease = semanticDefaults.disease
        val trigger = semanticDefaults.trigger
        val pathway = semanticDefaults.pathway
        val cell = semanticDefaults.cell
        val assay = semanticDefaults.assay
        val comparator = semanticDefaults.comparator
        val contradiction = if (forcedClosureGuard.active) {
                "forced closure rejected; contradiction/null-result search remains required"
            } else structured["contradiction"]?.takeIf { it.isNotBlank() }
            ?: if (routingText.contains("contradiction", true) || routingText.contains("null", true) || routingText.contains("opposite", true)) {
                "active contradiction/null-result search requested"
            } else {
                "contradiction/null-result search required by GTIM policy"
            }
        val output = structured["output"]?.takeIf { it.isNotBlank() }
            ?: if (forcedClosureGuard.active) "exploratory route review only; no forced gate closure"
            else if (routingText.contains("no raw JSON", true) || routingText.contains("discovery brief", true)) "discovery brief, hide raw JSON and command trace" else "discovery brief, technical appendix hidden by default"

        val missing = buildList {
            if (disease.isEmpty()) add("disease/phenotype")
            if (trigger.isEmpty()) add("trigger/exposure")
            if (pathway.isEmpty()) add("pathway")
            if (cell.isEmpty()) add("cell/tissue")
            if (assay.isEmpty()) add("assay")
            if (comparator.isEmpty()) add("comparator")
        }
        val completeness = scoreCompleteness(disease, trigger, pathway, cell, assay, repositories, comparator)
        val routeScore = listOf(trigger, disease, pathway, cell).count { it.isNotEmpty() } * 20 + if (comparator.isNotEmpty()) 10 else 0
        val queryScore = listOf(repositories, assay, disease, trigger).count { it.isNotEmpty() } * 22 + if (comparator.isNotEmpty()) 8 else 0
        val card = listOf(
            "Parsed Research Intent",
            "Trigger: ${trigger.joinToString(", ").ifBlank { "not specified" }}",
            "Disease / phenotype: ${disease.joinToString(", ").ifBlank { "not specified" }}",
            "Pathway: ${pathway.joinToString(", ").ifBlank { "not specified" }}",
            "Cell / tissue: ${cell.joinToString(", ").ifBlank { "not specified" }}",
            "Comparator: ${comparator.joinToString(", ").ifBlank { "not specified" }}",
            "Assay: ${assay.joinToString(", ").ifBlank { "not specified" }}",
            "Repositories: ${repositories.joinToString(", ")}",
            "Output mode: $output",
            "Claim strictness: discovery flexible; evidence upgrade strict; clinical claims forbidden"
        )
        return GTIMResearchIntentObjectV255(
            active = true,
            parserVersion = VERSION,
            sourceText = raw.take(4000),
            inputMode = if (forcedClosureGuard.active) "FORCED_CLOSURE_REWRITTEN_AS_EXPLORATORY_ROUTE_REVIEW" else if (structuredMode) "STRUCTURED_INTAKE" else "FREE_TEXT_EXTRACTED_INTENT",
            diseasePhenotype = disease.take(10),
            triggerExposure = trigger.take(10),
            pathway = pathway.take(12),
            cellTissue = cell.take(10),
            assayType = assay.take(8),
            repositoryTargets = repositories.take(10),
            comparatorWanted = comparator.take(8),
            speciesPriority = if (raw.contains("animal", true) || raw.contains("mouse", true) || raw.contains("mice", true)) "human_first_cross_species_auxiliary_only" else "human_first_animal_auxiliary_only",
            outputMode = output,
            claimStrictness = if (forcedClosureGuard.active) "forced_closure_rejected_research_leads_only_no_gate_override" else "discovery_flexible_evidence_upgrade_strict_clinical_forbidden",
            contradictionRequirement = contradiction,
            labValidationRequirement = "preliminary lab protocol draft required for candidate routes; draft is not validation",
            intentCompletenessScore = completeness.coerceIn(0, 100),
            routeConstructionScore = routeScore.coerceIn(0, 100),
            queryReadinessScore = queryScore.coerceIn(0, 100),
            missingIntentFields = missing,
            parsedResearchIntentCard = card
        )
    }

    private data class SemanticIntentDefaultsV2744(
        val disease: List<String>,
        val trigger: List<String>,
        val pathway: List<String>,
        val cell: List<String>,
        val assay: List<String>,
        val comparator: List<String>
    )

    private fun enrichSingleTopicDefaults(
        text: String,
        disease: List<String>,
        trigger: List<String>,
        pathway: List<String>,
        cell: List<String>,
        assay: List<String>,
        comparator: List<String>
    ): SemanticIntentDefaultsV2744 {
        val lower = text.lowercase(Locale.US)
        val d = disease.toMutableList()
        val t = trigger.toMutableList()
        val p = pathway.toMutableList()
        val c = cell.toMutableList()
        val a = assay.toMutableList()
        val comp = comparator.toMutableList()
        fun addUnique(target: MutableList<String>, values: List<String>) {
            values.forEach { value ->
                if (value.isNotBlank() && target.none { it.equals(value, ignoreCase = true) }) target += value
            }
        }
        val singleTokenIntent = GTIMSingleTokenDiseaseIntentResolverV2940.expand(text)
        if (singleTokenIntent.active) {
            addUnique(d, singleTokenIntent.disease)
            addUnique(t, singleTokenIntent.trigger)
            addUnique(p, singleTokenIntent.pathway)
            addUnique(c, singleTokenIntent.cell)
            addUnique(a, singleTokenIntent.assay)
            addUnique(comp, singleTokenIntent.comparator)
        }

        val hasAllergy = Regex("""\b(allergy|allergies|allergic|hypersensitivity|atopy|atopic)\b""").containsMatchIn(lower)
        val hasCovid = Regex("""\b(covid|sars-cov-2|sars cov 2|pasc|long covid)\b""").containsMatchIn(lower)
        val hasDepression = Regex("""\b(depression|depressive|mood disorder|major depressive)\b""").containsMatchIn(lower)
        val hasBacteria = Regex("""\b(bacteria|microbiome|microbiota|gut bacteria|dysbiosis)\b""").containsMatchIn(lower)
        val hasLongevity = Regex("""\b(longevity|aging|ageing|immunosenescence|inflammaging)\b""").containsMatchIn(lower)

        if (hasAllergy) {
            addUnique(d, listOf("Allergic disease / hypersensitivity phenotype"))
            addUnique(t, listOf("allergen exposure"))
            addUnique(p, listOf("IgE", "mast cell activation", "eosinophil", "type 2 inflammation", "IL-4/IL-5/IL-13"))
            addUnique(c, listOf("mast cells", "eosinophils", "epithelial barrier", "blood"))
            addUnique(a, listOf("IgE/ELISA", "cytokine profiling", "IgE/ELISA", "flow cytometry"))
            addUnique(comp, listOf("allergic cases vs healthy controls"))
        }
        if (hasCovid) {
            addUnique(d, listOf("COVID", "Long COVID / PASC"))
            addUnique(t, listOf("SARS-CoV-2"))
            addUnique(p, listOf("interferon", "IL-6", "TNF", "cytokine", "post-viral inflammation"))
            addUnique(c, listOf("PBMC", "blood", "airway epithelial tissue"))
            addUnique(a, listOf("RNA-seq", "cytokine profiling", "single-cell RNA-seq"))
            addUnique(comp, listOf("COVID cases vs healthy/recovered controls"))
        }
        if (hasDepression) {
            addUnique(d, listOf("Depression / mood-neuroimmune phenotype"))
            addUnique(p, listOf("IL-6", "TNF", "CRP", "kynurenine pathway", "neuroimmune signaling"))
            addUnique(c, listOf("PBMC", "serum/plasma", "gut microbiome"))
            addUnique(a, listOf("cytokine profiling", "metabolomics", "RNA-seq"))
            addUnique(comp, listOf("depression cases vs matched controls"))
        }
        if (hasBacteria) {
            addUnique(t, listOf("Gut bacteria / microbiome axis"))
            addUnique(c, listOf("stool", "gut mucosa", "PBMC"))
            addUnique(a, listOf("16S microbiome", "shotgun metagenomics", "metabolomics"))
        }
        if (hasLongevity) {
            addUnique(d, listOf("Longevity / healthy aging phenotype", "Aging / immunosenescence phenotype"))
            addUnique(p, listOf("immunosenescence", "inflammaging", "senescence", "IL-6", "CRP"))
            addUnique(c, listOf("PBMC", "blood", "serum/plasma"))
            addUnique(a, listOf("RNA-seq", "epigenetic/omics profiling", "cytokine profiling"))
            addUnique(comp, listOf("older vs younger controls", "healthy aging vs frailty comparator"))
        }
        return SemanticIntentDefaultsV2744(
            disease = d.distinctBy { it.lowercase(Locale.US) }.take(10),
            trigger = t.distinctBy { it.lowercase(Locale.US) }.take(10),
            pathway = p.distinctBy { it.lowercase(Locale.US) }.take(12),
            cell = c.distinctBy { it.lowercase(Locale.US) }.take(10),
            assay = a.distinctBy { it.lowercase(Locale.US) }.take(8),
            comparator = comp.distinctBy { it.lowercase(Locale.US) }.take(8)
        )
    }

    private fun scoreCompleteness(
        disease: List<String>,
        trigger: List<String>,
        pathway: List<String>,
        cell: List<String>,
        assay: List<String>,
        repositories: List<String>,
        comparator: List<String>
    ): Int {
        var score = 0
        if (disease.isNotEmpty()) score += 18
        if (trigger.isNotEmpty()) score += 18
        if (pathway.isNotEmpty()) score += 16
        if (cell.isNotEmpty()) score += 14
        if (assay.isNotEmpty()) score += 12
        if (repositories.isNotEmpty()) score += 10
        if (comparator.isNotEmpty()) score += 12
        return score
    }

    private fun splitTerms(value: String?): List<String> {
        if (value.isNullOrBlank()) return emptyList()
        return value
            .split(";", ",", "|", "→", ">", " and ", " AND ", " or ", " OR ")
            .map { normalizeLabel(it) }
            .filter { it.length >= 2 }
            .distinctBy { it.lowercase(Locale.US) }
    }

    private fun extractTerms(text: String, terms: List<String>): List<String> {
        val lower = text.lowercase(Locale.US)
        return terms.filter { term -> termMatches(lower, term) }
            .map { canonical(it) }
            .distinctBy { it.lowercase(Locale.US) }
    }

    private fun termMatches(lowerText: String, term: String): Boolean {
        val needle = term.lowercase(Locale.US)
        // v2.7.4.1: false-friend guard. In research reports, "lead" usually means
        // a research lead, not Pb/heavy-metal exposure. Only accept the toxicology
        // meaning when exposure/poisoning/water/blood context is explicit.
        if (needle == "lead") {
            return Regex("""(?<![a-z0-9])lead(?:\s+(?:exposure|poisoning|toxicity|in\s+water|water|blood|level|levels|contamination|contaminated))(?![a-z0-9])""")
                .containsMatchIn(lowerText)
        }
        return if (needle.length <= 3 && needle.all { it.isLetterOrDigit() }) {
            Regex("(?<![a-z0-9])${Regex.escape(needle)}(?![a-z0-9])").containsMatchIn(lowerText)
        } else {
            lowerText.contains(needle)
        }
    }

    private fun extractComparator(text: String): List<String> {
        val comparators = mutableListOf<String>()
        val lower = text.lowercase(Locale.US)
        if (lower.contains("healthy")) comparators += "healthy controls"
        if (lower.contains("recovered")) comparators += "recovered controls"
        if (lower.contains("matched")) comparators += "matched controls"
        if (lower.contains("baseline")) comparators += "baseline"
        if (lower.contains("placebo")) comparators += "placebo"
        if (lower.contains("responder")) comparators += "responder/non-responder"
        if (lower.contains("exposed") || lower.contains("unexposed")) comparators += "exposed/unexposed"
        if (Regex("""(?<![A-Za-z0-9])vs(?![A-Za-z0-9])|versus|compared to|compare|comparison""", RegexOption.IGNORE_CASE).containsMatchIn(text)) comparators += "case vs control comparison"

        // v2.6.4 closure: cross-disease comparison must be captured at intent time,
        // before the learning loop has any findings. This is still routing only.
        val comparativeHits = listOf("cancer", "tumor", "hiv", "aids", "fungal", "candida", "aspergillus", "epidemic", "pandemic", "outbreak")
            .filter { lower.contains(it) }
            .distinct()
        if (comparativeHits.size >= 2) comparators += "cross-disease comparator: ${comparativeHits.take(6).joinToString(" vs ")}"
        return comparators.distinct()
    }

    private fun normalizeLabel(value: String): String = value.trim().trim('.', ':', '-', '—').replace(Regex("\\s+"), " ")

    private fun canonical(term: String): String = when (term.lowercase(Locale.US)) {
        "allergy" -> "Allergic disease / hypersensitivity phenotype"
        "allergies" -> "Allergic disease / hypersensitivity phenotype"
        "allergic" -> "Allergic disease / hypersensitivity phenotype"
        "hypersensitivity" -> "Allergic disease / hypersensitivity phenotype"
        "atopy" -> "Atopic / type-2 allergic phenotype"
        "atopic" -> "Atopic / type-2 allergic phenotype"
        "pasc" -> "Long COVID / PASC"
        "long covid" -> "Long COVID / PASC"
        "sars-cov-2" -> "SARS-CoV-2"
        "hhv-6" -> "HHV-6"
        "ebv" -> "EBV"
        "hiv" -> "HIV/AIDS"
        "ebola" -> "Ebola virus disease / viral hemorrhagic fever frame"
        "evd" -> "Ebola virus disease / viral hemorrhagic fever frame"
        "ebolavirus" -> "Ebola virus disease / viral hemorrhagic fever frame"
        "filovirus" -> "Ebola virus disease / viral hemorrhagic fever frame"
        "hanta" -> "Hantavirus disease / hemorrhagic fever renal-pulmonary syndrome frame"
        "hantavirus" -> "Hantavirus disease / hemorrhagic fever renal-pulmonary syndrome frame"
        "hfrs" -> "Hantavirus disease / hemorrhagic fever renal-pulmonary syndrome frame"
        "hcps" -> "Hantavirus disease / hemorrhagic fever renal-pulmonary syndrome frame"
        "diabetes" -> "Diabetes / metabolic-inflammatory phenotype"
        "diabetic" -> "Diabetes / metabolic-inflammatory phenotype"
        "type 2 diabetes" -> "Diabetes / metabolic-inflammatory phenotype"
        "t2d" -> "Diabetes / metabolic-inflammatory phenotype"
        "type 1 diabetes" -> "Type 1 diabetes / beta-cell autoimmune phenotype"
        "t1d" -> "Type 1 diabetes / beta-cell autoimmune phenotype"
        "aids" -> "HIV/AIDS"
        "tumor" -> "Cancer / tumor immune evasion"
        "cancer" -> "Cancer / tumor immune evasion"
        "fungal" -> "Fungal disease / Th17-neutrophil defense"
        "fungi" -> "Fungal disease / Th17-neutrophil defense"
        "pandemic" -> "Epidemic / pandemic immune response"
        "epidemic" -> "Epidemic / pandemic immune response"
        "outbreak" -> "Epidemic / pandemic immune response"
        "gut" -> "Gut / digestive microbiome-barrier axis"
        "digestive" -> "Gut / digestive microbiome-barrier axis"
        "gastrointestinal" -> "Gut / digestive microbiome-barrier axis"
        "microbiome" -> "Gut / digestive microbiome-barrier axis"
        "bacteria" -> "Gut bacteria / microbiome axis"
        "gut bacteria" -> "Gut bacteria / microbiome axis"
        "depression" -> "Depression / mood-neuroimmune phenotype"
        "anxiety" -> "Anxiety / stress-neuroimmune phenotype"
        "mood disorder" -> "Mood disorder / neuroimmune phenotype"
        "longevity" -> "Longevity / healthy aging phenotype"
        "aging" -> "Aging / immunosenescence phenotype"
        "ageing" -> "Aging / immunosenescence phenotype"
        "immunosenescence" -> "Immunosenescence"
        "inflammaging" -> "Inflammaging"
        "hormone" -> "Endocrine / hormone immune axis"
        "hormones" -> "Endocrine / hormone immune axis"
        "endocrine" -> "Endocrine / hormone immune axis"
        "pesticide" -> "Food pesticide residue immune axis"
        "pesticides" -> "Food pesticide residue immune axis"
        "glyphosate" -> "Food pesticide residue immune axis"
        "antibiotic" -> "Antibiotic exposure / livestock residue microbiome axis"
        "antibiotics" -> "Antibiotic exposure / livestock residue microbiome axis"
        "poultry" -> "Antibiotic exposure / livestock residue microbiome axis"
        "livestock" -> "Antibiotic exposure / livestock residue microbiome axis"
        "heavy metals" -> "Water heavy-metal immune axis"
        "heavy metal" -> "Water heavy-metal immune axis"
        "lead" -> "Water heavy-metal immune axis"
        "mercury" -> "Water heavy-metal immune axis"
        "arsenic" -> "Water heavy-metal immune axis"
        "cadmium" -> "Water heavy-metal immune axis"
        "plastic" -> "Plastic/microplastic endocrine-immune axis"
        "plastics" -> "Plastic/microplastic endocrine-immune axis"
        "microplastic" -> "Plastic/microplastic endocrine-immune axis"
        "microplastics" -> "Plastic/microplastic endocrine-immune axis"
        "bpa" -> "Plastic/microplastic endocrine-immune axis"
        "pfas" -> "Plastic/microplastic endocrine-immune axis"
        "tnf" -> "TNF"
        "il-6" -> "IL-6"
        "il6" -> "IL-6"
        "il-17" -> "IL-17"
        "pd-1" -> "PD-1"
        "pd-l1" -> "PD-L1"
        "pbmc" -> "PBMC"
        "scrna-seq" -> "scRNA-seq"
        "single-cell" -> "single-cell RNA-seq"
        else -> normalizeLabel(term)
    }

    private val DISEASE_TERMS = listOf(
        "Long COVID", "PASC", "SLE", "Systemic Lupus", "RA", "rheumatoid arthritis", "MS", "multiple sclerosis", "ME/CFS", "fatigue", "brain fog", "arthralgia", "allergy", "allergies", "allergic", "hypersensitivity", "atopy", "atopic", "autoimmune", "post-viral", "depression", "anxiety", "mood disorder", "neuroinflammation", "longevity", "aging", "ageing", "immunosenescence", "inflammaging",
        "cancer", "tumor", "oncology", "HIV", "AIDS", "Ebola", "EVD", "ebolavirus", "filovirus", "hantavirus", "Hanta", "HFRS", "HCPS", "Puumala", "Sin Nombre", "Andes virus", "Seoul virus", "Dobrava", "fungal", "fungi", "Candida", "Aspergillus", "epidemic", "pandemic", "outbreak", "COVID", "post-infectious", "diabetes", "diabetic", "type 2 diabetes", "type 1 diabetes", "T2D", "T1D",
        "gut", "digestive", "gastrointestinal", "intestinal", "microbiome", "endocrine", "hormone", "hormones", "pesticide", "pesticides", "antibiotic residue", "heavy metals", "microplastics", "plasticizers"
    )
    private val TRIGGER_TERMS = listOf(
        "EBV", "HHV-6", "SARS-CoV-2", "COVID", "viral reactivation", "virus", "vaccine", "antibiotic", "IL-6 inhibitor", "TNF inhibitor", "JAK inhibitor", "Rituximab", "corticosteroid", "allergen", "allergen exposure", "microbiome", "bacteria", "gut bacteria", "microbial metabolite", "tryptophan", "kynurenine",
        "tumor antigen", "chronic antigen", "viral load", "rodent exposure", "hantavirus lineage", "opportunistic infection", "fungal infection", "pathogen", "variant", "wave", "outbreak exposure", "immune checkpoint exposure",
        "gut barrier", "intestinal permeability", "digestive system", "stool", "fecal", "cortisol", "insulin", "thyroid", "estrogen", "androgen", "endocrine disruptor",
        "pesticide residue", "glyphosate", "organophosphate", "pyrethroid", "livestock antibiotics", "poultry antibiotics", "antibiotic residues", "resistome",
        "heavy metals", "lead", "mercury", "arsenic", "cadmium", "drinking water", "microplastics", "BPA", "phthalates", "PFAS", "plasticizer"
    )
    private val PATHWAY_TERMS = listOf(
        "interferon", "IL-6", "IL6", "TNF", "T-cell exhaustion", "B-cell", "autoantibody", "cytokine", "mast cell", "mast cell activation", "IgE", "eosinophil", "type 2 inflammation", "Th2", "IL-4", "IL-5", "IL-13", "JAK/STAT", "NF-kB", "mitochondrial", "inflammation",
        "PD-1", "PD-L1", "CTLA-4", "CD4 depletion", "CD8 exhaustion", "Th17", "IL-17", "IL-23", "neutrophil", "Dectin-1", "CARD9", "macrophage activation", "cytokine storm", "endothelial injury", "capillary leak", "platelet/coagulation", "interferon timing",
        "mucosal immunity", "intestinal barrier", "Treg", "IgA", "xenobiotic response", "oxidative stress", "HPA axis", "endocrine disruption", "resistome", "metabolic inflammation", "barrier disruption", "kynurenine pathway", "tryptophan metabolism", "microglia", "neuroimmune signaling", "senescence", "inflammaging", "immunosenescence"
    )
    private val CELL_TISSUE_TERMS = listOf(
        "PBMC", "T cells", "B cells", "monocytes", "macrophage", "mast cells", "eosinophils", "synovial", "blood", "plasma", "serum", "epithelial", "tissue", "organoid",
        "CD4 T cells", "CD8 T cells", "TIL", "tumor-infiltrating lymphocytes", "neutrophils", "dendritic cells", "endothelium", "platelets", "lung", "kidney", "mucosal tissue", "tumor microenvironment",
        "gut", "intestine", "intestinal tissue", "stool", "fecal", "liver", "kidney", "endocrine tissue", "water source", "biospecimen"
    )
    private val ASSAY_TERMS = listOf("RNA-seq", "scRNA-seq", "single-cell", "microarray", "transcriptome", "cytokine profiling", "IgE/ELISA", "flow cytometry", "qPCR", "Western blot", "ELISA", "proteomics", "metabolomics", "CyTOF", "Olink", "TCR-seq", "BCR-seq", "microbiome", "16S", "metagenomics", "metabolite", "biomonitoring")
    private val REPOSITORY_TERMS = listOf("GEO", "GDS", "SRA", "BioProject", "PRJNA", "ArrayExpress", "E-MTAB", "ImmPort", "SDY", "PubMed", "PMC", "Europe PMC", "OpenAlex", "Data Availability")
}
