package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.7 — Final global-study dossier guard.
 *
 * This is not another discovery engine. It is the final output contract that turns the
 * already-linked routes into a paper-like research dossier surface: abstract first,
 * contribution first, limits explicit, and technical rails kept out of the first page.
 * It deliberately keeps research-value output relaxed while evidence upgrades stay locked.
 */
object GTIMFinalGlobalStudyDossierGuardV2127 {
    const val VERSION: String = "2.12.7-final-global-study-dossier-guard"
    const val OUTPUT_CONTRACT: String = "global_study_dossier_first_surface_no_debug_trace"
    const val CLAIM_LIMIT: String = "research_only_no_diagnosis_no_treatment_no_gene_proof_no_organism_protocol"

    data class FinalDossier(
        val abstractLine: String,
        val proposedContribution: String,
        val methodFrame: String,
        val resultValue: String,
        val noveltyFrame: String,
        val evidenceDiscipline: String,
        val decisionGate: String,
        val appendixPolicy: String,
        val boundary: String
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): FinalDossier {
        val technical = if (technicalLines.isNotEmpty()) technicalLines else GlobalResearchGradeBriefV11061.renderLines(report)
        val card = report.optJSONObject("studyResultCardV2126") ?: GTIMStudyResultCardV2126.toJson(report, technical)
        val solution = report.optJSONObject("studyGradeFunctionalSolutionV2121") ?: GTIMStudyGradeFunctionalSolutionEngineV2121.toJson(report, technical)
        val functional = report.optJSONObject("functionalRepairDossierV2120") ?: GTIMFunctionalRepairDossierEngineV2120.toJson(report)
        val consistency = GTIMReportConsistencyGateV2121.build(report, technical)
        val matrix = report.optJSONObject("matrixShortcutResolverV2124") ?: GTIMMatrixShortcutResolverV2124.toJson(report, technical)
        val global = report.optJSONObject("globalReportLearningV2124") ?: JSONObject()

        val topic = card.optString("topic").ifBlank { topicFromReport(report, technical) }
        val hypothesis = card.optString("topResearchHypothesis").ifBlank { "root-cause model remains open; use this as a structured study lead" }
        val repair = card.optString("functionalRepairCandidate").ifBlank { solution.optString("functionalSolutionHypothesis") }
        val tool = card.optString("biologicalToolClass").ifBlank { firstRepairTool(functional) }
        val grade = card.optString("evidenceGrade").ifBlank { "D — research lead only" }
        val blockers = listOf(
            "target/candidate topic-fit",
            "matrix or processed-expression capsule",
            "comparator labels",
            "sample-to-source provenance",
            "independent contradiction check"
        )
        val repeated = jsonStrings(global.optJSONArray("repeatedMechanisms")).take(3).joinToString(", ")
        val matrixState = matrix.optString("shortcutState").ifBlank { "matrix shortcut review-only path available" }
        val targetState = when {
            consistency.topicCompatibleTargetSelected -> "accepted target=${consistency.acceptedTarget}"
            consistency.candidateLookupHandle.isNotBlank() -> "candidate handle=${consistency.candidateLookupHandle}; not accepted as internal target yet"
            else -> "topic-level search; no target accepted yet"
        }
        return FinalDossier(
            abstractLine = "Immu DZ proposes a research-only study frame for ${topic.oneLine()}: ${hypothesis.oneLine()}",
            proposedContribution = "Contribution: convert an immune/exposure question into root dysfunction + repair function + biological tool class + validation gates, rather than stopping at missing matrix evidence.",
            methodFrame = "Method: route isolation → candidate/target check → external lookup → matrix shortcut → functional repair dossier → study-grade solution → global cross-report learning.",
            resultValue = "Current result: ${grade.oneLine()}; repair candidate=${repair.oneLine().ifBlank { "function-first candidate still open" }}; tool class=${tool.oneLine().ifBlank { "not nominated yet" }}; $targetState; $matrixState.",
            noveltyFrame = "Novelty frame: ${solution.optString("noveltyFrame").ifBlank { "conceptual synthesis only until a dataset/capsule validates the route" }.oneLine()}${if (repeated.isNotBlank()) "; cross-run signals=$repeated" else ""}",
            evidenceDiscipline = "Evidence discipline: missing gates=${blockers.joinToString(", ")}; relaxed output creates study value only, never proof.",
            decisionGate = "Upgrade only after observed matrix/capsule + comparator labels + sample linkage + reviewed expression or external gene-list provenance + contradiction resistance.",
            appendixPolicy = "Appendix policy: compatibility rails, full external routes, debug tokens, and old medical dossier stay available for export/audit but outside the first decision surface.",
            boundary = CLAIM_LIMIT
        )
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val d = build(report, technicalLines)
        return listOf(
            "Global Study Abstract",
            d.abstractLine.takeClean(360),
            d.proposedContribution.takeClean(360),
            d.methodFrame.takeClean(360),
            d.resultValue.takeClean(420),
            d.noveltyFrame.takeClean(420),
            d.evidenceDiscipline.takeClean(360),
            "Decision gate: ${d.decisionGate.takeClean(360)}",
            "Output contract: $OUTPUT_CONTRACT; ${d.appendixPolicy.takeClean(260)}",
            "Boundary: research-only; no diagnosis, treatment, administration route, organism-engineering steps, environmental release, efficacy claim, or gene/pathway proof."
        )
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val d = build(report, technicalLines)
        return JSONObject()
            .put("version", VERSION)
            .put("outputContract", OUTPUT_CONTRACT)
            .put("abstractLine", d.abstractLine)
            .put("proposedContribution", d.proposedContribution)
            .put("methodFrame", d.methodFrame)
            .put("resultValue", d.resultValue)
            .put("noveltyFrame", d.noveltyFrame)
            .put("evidenceDiscipline", d.evidenceDiscipline)
            .put("decisionGate", d.decisionGate)
            .put("appendixPolicy", d.appendixPolicy)
            .put("claimLimit", d.boundary)
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        OUTPUT_CONTRACT,
        "Global Study Abstract",
        "root dysfunction + repair function + biological tool class + validation gates",
        "matrix shortcut",
        "global cross-report learning",
        CLAIM_LIMIT
    ))

    private fun topicFromReport(report: JSONObject, lines: List<String>): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        return topic.optString("normalizedTopic").ifBlank {
            topic.optString("rawInput").ifBlank {
                lines.firstOrNull { it.startsWith("Research topic:") }?.removePrefix("Research topic:")?.trim().orEmpty()
            }
        }.ifBlank { "current immune research question" }
    }

    private fun firstRepairTool(functional: JSONObject): String {
        val firstRepair = functional.optJSONArray("repairFunctions")?.optJSONObject(0) ?: JSONObject()
        return firstRepair.optString("biologicalToolClass")
    }

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx ->
        array.optString(idx).takeIf { it.isNotBlank() }
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
    private fun String.takeClean(max: Int): String {
        val clean = oneLine()
        return if (clean.length <= max) clean else clean.take(max - 1).trimEnd() + "…"
    }
}
