package com.immunesignal.app

// v2.12.0 — Builds the root-dysfunction model separately from UI rendering.
object GTIMFunctionalRepairDysfunctionModelBuilderV2120 {
    const val VERSION: String = "2.12.0-functional-repair-dysfunction-model-builder"

    fun build(topic: String, route: String, target: String, evidenceText: String): GTIMFunctionalDysfunctionModelV2120 {
        val corpus = listOf(topic, route, target, evidenceText).joinToString(" ").lowercase()
        val modelId = when {
            has(corpus, "allerg", "ige", "mast", "eosinophil", "type-2", "type 2") -> "barrier_type2_tolerance_failure_model"
            has(corpus, "depress", "kynuren", "tryptophan", "il-6", "tnf", "neuroimmune") -> "microbiome_metabolite_neuroimmune_model"
            has(corpus, "covid", "corona", "sars", "hanta", "ebola", "filovirus", "hemorrhagic", "virus", "viral", "interferon", "cytokine", "il-6", "tnf") -> "interferon_timing_cytokine_amplification_model"
            has(corpus, "diabet", "insulin", "glucose", "metabolic") -> "metabolic_inflammation_energy_context_model"
            has(corpus, "microplastic", "plastic", "toxin", "pollution", "particle") -> "exposure_barrier_bioremediation_model"
            has(corpus, "autoimmune", "arthritis", "lupus", "tolerance") -> "immune_tolerance_error_model"
            else -> "open_eco_immune_root_dysfunction_model"
        }
        val primary = primaryFor(modelId)
        val sketch = causalSketchFor(modelId)
        val bridge = bridgeFor(modelId)
        val context = listOf(
            "geography, diet, exposure, age, tissue, and sampling context may change transferability",
            "population context is a research modifier, not a deterministic identity claim",
            "symptoms are treated as non-specific signals until discriminating biomarkers are available"
        )
        val line = "Functional repair dysfunction model: version=$VERSION | id=$modelId | primary=${primary.oneLine()} | bridge=${bridge.joinToString(";").oneLine()} | context=${context.joinToString(";").oneLine()}"
        return GTIMFunctionalDysfunctionModelV2120(modelId, primary, sketch, bridge, context, line)
    }

    private fun primaryFor(modelId: String): String = when (modelId) {
        "barrier_type2_tolerance_failure_model" -> "barrier and immune-tolerance dysfunction may amplify type-2 inflammation rather than a single allergen-only explanation"
        "microbiome_metabolite_neuroimmune_model" -> "microbiome-metabolite imbalance may shift tryptophan/kynurenine and low-grade inflammatory tone into neuroimmune stress"
        "interferon_timing_cytokine_amplification_model" -> "antiviral timing and cytokine amplification may explain severity better than pathogen presence alone"
        "metabolic_inflammation_energy_context_model" -> "immune-metabolic energy context may sustain inflammatory amplification and poor tissue repair"
        "exposure_barrier_bioremediation_model" -> "environmental particle or toxin pressure may interact with barrier stress, immune activation, and microbial function loss"
        "immune_tolerance_error_model" -> "immune decision thresholds may remain biased toward attack instead of tolerance and resolution"
        else -> "unknown upstream eco-immune dysfunction requiring mechanism-first exploration"
    }

    private fun causalSketchFor(modelId: String): List<String> = when (modelId) {
        "barrier_type2_tolerance_failure_model" -> listOf("barrier stress", "microbiome-metabolite shift", "type-2 skew", "IgE/mast-cell/eosinophil amplification")
        "microbiome_metabolite_neuroimmune_model" -> listOf("microbial ecology shift", "tryptophan-kynurenine imbalance", "IL-6/TNF inflammatory tone", "neuroimmune stress")
        "interferon_timing_cytokine_amplification_model" -> listOf("viral trigger", "interferon timing mismatch", "IL-6/TNF/NF-kB amplification", "tissue inflammatory burden")
        "metabolic_inflammation_energy_context_model" -> listOf("metabolic stress", "immune-energy mismatch", "low-grade cytokine tone", "repair-resistance loop")
        "exposure_barrier_bioremediation_model" -> listOf("particle/toxin exposure", "binding or transformation uncertainty", "barrier irritation", "immune activation")
        "immune_tolerance_error_model" -> listOf("trigger persistence", "tolerance checkpoint failure", "auto-inflammatory amplification", "tissue damage loop")
        else -> listOf("non-specific symptom signal", "candidate dysfunction", "missing comparator", "falsification needed")
    }

    private fun bridgeFor(modelId: String): List<String> = when (modelId) {
        "barrier_type2_tolerance_failure_model" -> listOf("allergy", "asthma/eczema-like barrier phenotypes", "gut-barrier immune skew")
        "microbiome_metabolite_neuroimmune_model" -> listOf("depression", "IBD-like inflammation", "metabolic inflammation", "fatigue-like neuroimmune states")
        "interferon_timing_cytokine_amplification_model" -> listOf("viral infection severity", "post-viral inflammation", "mucosal immunity gaps")
        "metabolic_inflammation_energy_context_model" -> listOf("diabetes/metabolic syndrome", "fatty-liver-like inflammation", "chronic low-grade inflammatory phenotypes")
        "exposure_barrier_bioremediation_model" -> listOf("pollution exposure", "barrier inflammation", "microbial detox/adsorption research", "ecological resilience")
        "immune_tolerance_error_model" -> listOf("autoimmune inflammation", "barrier-triggered flares", "tolerance restoration routes")
        else -> listOf("shared symptoms do not prove shared disease", "bridge remains hypothesis-only")
    }

    private fun has(corpus: String, vararg needles: String): Boolean = needles.any { corpus.contains(it, true) }
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
