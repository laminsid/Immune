package com.immunesignal.app

// audit_guard_phrase: no administration; no evidence upgrade

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

// v2.12.1 — Report Consistency Gate.
// Separates an accepted topic-compatible target from a candidate lookup handle so the
// public report never says Target is accepted when ETL/DGE gates explicitly blocked it.
object GTIMReportConsistencyGateV2121 {
    const val VERSION: String = "2.12.1-report-consistency-target-handle-gate"
    const val CLAIM_LIMIT: String = "display_consistency_only_no_evidence_upgrade"

    data class TargetConsistency(
        val acceptedTarget: String,
        val candidateLookupHandle: String,
        val targetState: String,
        val candidateAccessionsFound: Int,
        val topicCompatibleTargetSelected: Boolean,
        val verifiedMatrixFiles: Int,
        val line: String
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): TargetConsistency {
        val joined = (technicalLines.joinToString(" ") + " " + report.toString()).take(12000)
        val candidates = extractCandidates(joined)
        val noTopicCompatibleTarget = joined.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true) ||
            joined.contains("DGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", true) ||
            joined.contains("FINAL_ETL_STOP_NO_TOPIC_COMPATIBLE_TARGET", true) ||
            joined.contains("P0_TOPIC_COMPATIBLE_TARGET", true)
        val observedFileStop = joined.contains("OBSERVED_FILE_EVIDENCE", true) || joined.contains("TARGET_FOUND_FILE_MISSING", true)
        val accepted = if (!noTopicCompatibleTarget) candidates.firstOrNull().orEmpty() else ""
        val candidate = candidates.firstOrNull().orEmpty()
        val verifiedMatrixFiles = countVerifiedMatrixSignals(joined)
        val state = when {
            accepted.isNotBlank() && observedFileStop -> "TARGET_ACCEPTED_FILE_EVIDENCE_MISSING"
            accepted.isNotBlank() -> "TARGET_ACCEPTED_TOPIC_COMPATIBLE"
            candidate.isNotBlank() -> "CANDIDATE_LOOKUP_HANDLE_NOT_ACCEPTED_AS_TARGET"
            else -> "NO_TARGET_OR_LOOKUP_HANDLE_YET"
        }
        val line = "Report consistency gate: version=$VERSION | state=$state | acceptedTarget=${accepted.ifBlank { "NONE" }} | candidateLookupHandle=${candidate.ifBlank { "NONE" }} | candidateAccessionsFound=${candidates.size} | topicCompatibleTargetSelected=${accepted.isNotBlank()} | verifiedMatrixFiles=$verifiedMatrixFiles | claim_limit=$CLAIM_LIMIT"
        return TargetConsistency(accepted, candidate, state, candidates.size, accepted.isNotBlank(), verifiedMatrixFiles, line)
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val c = build(report, technicalLines)
        val lines = mutableListOf<String>()
        lines += when {
            c.topicCompatibleTargetSelected -> "Target: ${c.acceptedTarget} — accepted as topic-compatible for the current route."
            c.candidateLookupHandle.isNotBlank() -> "Target: not accepted yet — candidate lookup handle ${c.candidateLookupHandle} needs topic-fit validation."
            else -> "Target: not selected yet — discover or feed a topic-compatible accession before ETL/DGE."
        }
        if (!c.topicCompatibleTargetSelected && c.candidateLookupHandle.isNotBlank()) {
            lines += "Candidate lookup handle: ${c.candidateLookupHandle} — useful for External Router search only, not an internal DGE target."
        }
        lines += "Evidence counters: candidateAccessionsFound=${c.candidateAccessionsFound}; topicCompatibleTargetSelected=${c.topicCompatibleTargetSelected}; verifiedMatrixFiles=${c.verifiedMatrixFiles}."
        lines += "Display boundary: candidate handles help lookup; they do not upgrade evidence or prove a gene/pathway signal."
        return lines
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val c = build(report, technicalLines)
        return JSONObject()
            .put("version", VERSION)
            .put("claimLimit", CLAIM_LIMIT)
            .put("state", c.targetState)
            .put("acceptedTarget", c.acceptedTarget)
            .put("candidateLookupHandle", c.candidateLookupHandle)
            .put("candidateAccessionsFound", c.candidateAccessionsFound)
            .put("topicCompatibleTargetSelected", c.topicCompatibleTargetSelected)
            .put("verifiedMatrixFiles", c.verifiedMatrixFiles)
            .put("line", c.line)
    }

    private fun extractCandidates(text: String): List<String> {
        val values = mutableListOf<String>()
        Regex("target=([A-Za-z0-9_.:-]+)").findAll(text).forEach { values += it.groupValues[1] }
        Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|SRR\\d+|PRJNA\\d+|PRJEB\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+)\\b", RegexOption.IGNORE_CASE)
            .findAll(text).forEach { values += it.value }
        return values.map { it.trim().uppercase(Locale.US) }
            .filter { it.isNotBlank() && it != "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" && it != "BLOCKED" }
            .distinct()
    }

    private fun countVerifiedMatrixSignals(text: String): Int {
        val lower = text.lowercase(Locale.US)
        if (lower.contains("matrix_not_verified") || lower.contains("file_missing") || lower.contains("matrix_unresolved")) return 0
        return listOf("matrix file verified", "observed matrix", "raw/count matrix verified", "dge_ready").count { lower.contains(it) }
    }
}
