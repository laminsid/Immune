# v1.11.5-alpha-graded-exploratory-research-results

- versionCode=129
- schema updated to `1.11.5`
- Added `ExploratoryResearchLeadV1115`.
- Added `GRADED_EXPLORATORY_RESULTS` mode.
- Reports now show useful in-progress research leads when EvidenceObject is blocked.
- Preserves `HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION` and no clinical-claim guardrails.
