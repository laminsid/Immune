package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.7.4.9 — Accession Token Pipeline State.
 *
 * Separates a captured accession handle from a fully resolved dataset object.
 * This prevents the false report pattern:
 *   accessions=4, seed handles queued=GSE..., but Matrix Audit says NO_ACCESSION_ID_CAPTURED.
 */
enum class GTIMAccessionResolutionStatusV2749(val code: String) {
    NO_ACCESSION_ID_CAPTURED("NO_ACCESSION_ID_CAPTURED"),
    ACCESSION_HANDLE_CAPTURED_DATASET_OBJECT_NOT_RESOLVED("ACCESSION_HANDLE_CAPTURED_DATASET_OBJECT_NOT_RESOLVED"),
    DATASET_OBJECT_RESOLUTION_PENDING("DATASET_OBJECT_RESOLUTION_PENDING"),
    METADATA_TRAITS_NOT_PARSED("METADATA_TRAITS_NOT_PARSED"),
    COMPARATOR_LABELS_MISSING_OR_AMBIGUOUS("COMPARATOR_LABELS_MISSING_OR_AMBIGUOUS"),
    MATRIX_FILE_NOT_READY("MATRIX_FILE_NOT_READY"),
    ACCESSION_HANDLE_CAPTURED_METADATA_PARTIAL("ACCESSION_HANDLE_CAPTURED_METADATA_PARTIAL"),
    DGE_READY("DGE_READY")
}

data class GTIMAccessionPipelineStateReportV2749(
    val target: GTIMMatrixAuditTargetCandidateV2748?,
    val allHandles: List<String>,
    val status: GTIMAccessionResolutionStatusV2749,
    val bridgeStatus: String,
    val reason: String,
    val targetContext: String
) {
    val targetId: String = target?.id ?: allHandles.firstOrNull() ?: GTIMAccessionResolutionStatusV2749.NO_ACCESSION_ID_CAPTURED.code
    val hasAnyHandle: Boolean = allHandles.isNotEmpty() || target != null
}

object GTIMAccessionPipelineStateV2749 {
    const val VERSION: String = "2.7.4.9-accession-token-pipeline-state"

    fun resolve(
        report: JSONObject,
        contract: GTIMRunDecisionContractV2740,
        fallbackSeedHandles: List<String> = emptyList(),
        paperUnderstandingSummary: String = ""
    ): GTIMAccessionPipelineStateReportV2749 {
        val handles = collectHandles(report, fallbackSeedHandles, paperUnderstandingSummary)
        val selected = GTIMMatrixAuditTargetSelectorV2748.selectScored(
            report = report,
            contract = contract,
            fallbackSeedHandles = handles,
            paperUnderstandingSummary = paperUnderstandingSummary
        )
        val targetId = selected?.id ?: handles.firstOrNull().orEmpty()
        val targetContext = buildTargetContext(report, selected, targetId, paperUnderstandingSummary)
        val status = classifyStatus(targetId, targetContext)
        val bridge = when (status) {
            GTIMAccessionResolutionStatusV2749.NO_ACCESSION_ID_CAPTURED -> "ACCESSION_CAPTURE_MISSING"
            GTIMAccessionResolutionStatusV2749.ACCESSION_HANDLE_CAPTURED_DATASET_OBJECT_NOT_RESOLVED,
            GTIMAccessionResolutionStatusV2749.DATASET_OBJECT_RESOLUTION_PENDING -> "ACCESSION_CAPTURED_AUDIT_ENGAGED_OBJECT_PENDING"
            GTIMAccessionResolutionStatusV2749.METADATA_TRAITS_NOT_PARSED,
            GTIMAccessionResolutionStatusV2749.COMPARATOR_LABELS_MISSING_OR_AMBIGUOUS -> "ACCESSION_CAPTURED_METADATA_GAP_AUDIT"
            GTIMAccessionResolutionStatusV2749.MATRIX_FILE_NOT_READY,
            GTIMAccessionResolutionStatusV2749.ACCESSION_HANDLE_CAPTURED_METADATA_PARTIAL -> "ACCESSION_CAPTURED_MATRIX_READINESS_PENDING"
            GTIMAccessionResolutionStatusV2749.DGE_READY -> "ACCESSION_CAPTURED_DGE_READY"
        }
        val reason = selected?.reason ?: if (handles.isNotEmpty()) {
            "accession handle captured in routing/seed phase; dataset object resolution pending"
        } else {
            "no accession-like token surfaced from report, seed handles, or paper-lite summary"
        }
        return GTIMAccessionPipelineStateReportV2749(
            target = selected,
            allHandles = handles,
            status = status,
            bridgeStatus = bridge,
            reason = reason,
            targetContext = targetContext.take(500)
        )
    }

    fun collectHandles(
        report: JSONObject,
        fallbackSeedHandles: List<String> = emptyList(),
        paperUnderstandingSummary: String = ""
    ): List<String> {
        val out = linkedSetOf<String>()
        fallbackSeedHandles.forEach { extractAccessions(it).forEach(out::add) }
        extractAccessions(paperUnderstandingSummary).forEach(out::add)
        collectFromJson(report).forEach(out::add)
        return out.filter { it.isNotBlank() }.distinct()
    }

    private fun collectFromJson(value: Any?): List<String> {
        val out = mutableListOf<String>()
        when (value) {
            is JSONObject -> {
                val keys = value.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    out += collectFromJson(value.opt(key))
                }
            }
            is JSONArray -> for (i in 0 until value.length()) out += collectFromJson(value.opt(i))
            is String -> out += extractAccessions(value)
            is Number -> Unit
            else -> if (value != null) out += extractAccessions(value.toString())
        }
        return out
    }

    private fun buildTargetContext(
        report: JSONObject,
        selected: GTIMMatrixAuditTargetCandidateV2748?,
        targetId: String,
        paperUnderstandingSummary: String
    ): String {
        val reportText = report.toString()
        val around = if (targetId.isNotBlank()) contextAround(reportText, targetId) else ""
        return listOf(
            selected?.context.orEmpty(),
            around,
            paperUnderstandingSummary,
            reportText.take(1200)
        ).joinToString(" ")
    }

    private fun classifyStatus(targetId: String, context: String): GTIMAccessionResolutionStatusV2749 {
        if (targetId.isBlank() || targetId == GTIMAccessionResolutionStatusV2749.NO_ACCESSION_ID_CAPTURED.code) {
            return GTIMAccessionResolutionStatusV2749.NO_ACCESSION_ID_CAPTURED
        }
        val n = normalize(context)
        val hasDatasetObject = containsAny(n, "gsm", "sample", "samples", "sample trait", "sample traits", "metadata", "dataset", "data availability", "supplementary")
        val hasTraitMatrix = containsAny(n, "trait", "phenotype", "characteristics", "condition", "disease state", "patient", "healthy", "control", "case")
        val hasComparator = containsAny(n, "control", "healthy", "matched", "baseline", "case", "recovered", "comparator")
        val hasMatrix = containsAny(n, "count matrix", "raw count", "counts", "expression matrix", "matrix file", "h5", "mtx", "rds", "supplementary file", "geo supplementary")
        val ready = containsAny(n, "dge ready", "matrix ready", "raw count matrix", "accession backed ready") && hasComparator
        return when {
            ready -> GTIMAccessionResolutionStatusV2749.DGE_READY
            !hasDatasetObject -> GTIMAccessionResolutionStatusV2749.ACCESSION_HANDLE_CAPTURED_DATASET_OBJECT_NOT_RESOLVED
            !hasTraitMatrix -> GTIMAccessionResolutionStatusV2749.METADATA_TRAITS_NOT_PARSED
            !hasComparator -> GTIMAccessionResolutionStatusV2749.COMPARATOR_LABELS_MISSING_OR_AMBIGUOUS
            !hasMatrix -> GTIMAccessionResolutionStatusV2749.MATRIX_FILE_NOT_READY
            else -> GTIMAccessionResolutionStatusV2749.ACCESSION_HANDLE_CAPTURED_METADATA_PARTIAL
        }
    }

    private fun extractAccessions(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val regex = Regex("(?i)\\b(GSE\\d+|GDS\\d+|PRJNA\\d+|SRP\\d+|SRR\\d+|E-MTAB-\\d+|SDY\\d+|PMID:\\d+|DOI:[A-Za-z0-9./_:-]+)\\b")
        return regex.findAll(text)
            .map { canonicalAccession(it.value) }
            .filter { it.isNotBlank() }
            .distinct()
            .toList()
    }

    private fun contextAround(text: String, token: String): String {
        val idx = text.indexOf(token, ignoreCase = true)
        if (idx < 0) return ""
        val start = (idx - 260).coerceAtLeast(0)
        val end = (idx + token.length + 260).coerceAtMost(text.length)
        return text.substring(start, end)
    }

    private fun canonicalAccession(value: String): String = value.trim().takeWhile { ch -> ch.isLetterOrDigit() || ch == ':' || ch == '-' || ch == '_' || ch == '.' || ch == '/' }

    private fun normalize(value: String): String = value.lowercase()
        .replace('_', ' ')
        .replace('-', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun containsAny(text: String, vararg needles: String): Boolean = needles.any { text.contains(it, ignoreCase = true) }
}
