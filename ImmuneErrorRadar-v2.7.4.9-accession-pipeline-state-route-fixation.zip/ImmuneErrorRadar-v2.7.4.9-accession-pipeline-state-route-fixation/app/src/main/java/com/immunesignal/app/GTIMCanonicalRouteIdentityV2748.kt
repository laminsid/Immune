package com.immunesignal.app

/**
 * v2.7.4.8 — Canonical Route Identity
 *
 * A single route/bridge identity normalizer used by renderers, matrix audit,
 * relationship discovery, benchmark, and data-feed guards. It prevents bugs where
 * a route is allowed under one display id but suppressed under another alias.
 */
object GTIMCanonicalRouteIdentityV2748 {
    const val VERSION: String = "2.7.4.8-canonical-route-identity"

    private val aliases: Map<String, String> = mapOf(
        "covid interferon cytokine bridge" to "covid_interferon_cytokine_bridge",
        "covid interferon" to "covid_interferon_cytokine_bridge",
        "long covid interferon" to "covid_interferon_cytokine_bridge",
        "sars cov 2 interferon" to "covid_interferon_cytokine_bridge",
        "allergy type2 ige mast eosinophil" to "allergy_type2_ige_mast_eosinophil",
        "allergy type 2 ige mast eosinophil" to "allergy_type2_ige_mast_eosinophil",
        "allergy type2 ige mast cell bridge" to "allergy_type2_ige_mast_eosinophil",
        "allergy type 2 ige mast cell bridge" to "allergy_type2_ige_mast_eosinophil",
        "allergy type2 to barrier immunity" to "allergy_type2_to_barrier_immunity",
        "allergy microbiome barrier axis" to "allergy_microbiome_barrier_axis",
        "ebola hemorrhagic viral host response" to "ebola_hemorrhagic_viral_host_response",
        "hemorrhagic viral host response" to "hemorrhagic_viral_host_response",
        "hiv retroviral cd4 immune depletion" to "hiv_retroviral_cd4_immune_depletion",
        "retroviral cd4 immune depletion" to "retroviral_cd4_immune_depletion",
        "hantavirus zoonotic viral immune route" to "hantavirus_zoonotic_viral_immune_route",
        "gut microbiome to neuroinflammation" to "gut_microbiome_to_neuroinflammation",
        "microbiome depression il6 bridge" to "gut_microbiome_to_neuroinflammation",
        "microbiome depression il 6 bridge" to "gut_microbiome_to_neuroinflammation",
        "microbiome tryptophan serotonin pathway" to "microbiome_tryptophan_serotonin_pathway",
        "microbiome hpa axis stress response" to "microbiome_hpa_axis_stress_response",
        "fungal exposure to barrier dysbiosis" to "fungal_exposure_to_barrier_dysbiosis",
        "yeast fungal to endocrine immune" to "yeast_fungal_to_endocrine_immune",
        "ibd barrier mucosal inflammation axis" to "ibd_barrier_mucosal_inflammation_axis",
        "ibd barrier microbiome axis" to "ibd_barrier_microbiome_axis"
    )

    private val routeIds: Set<String> = buildSet {
        addAll(GTIMPrimaryAnchorV2740.values().map { it.routeId })
        addAll(GTIMDiscoveryBridgeV2740.values().map { it.routeId })
        addAll(aliases.values)
    }

    fun canonicalize(value: String): String {
        val n = normalize(value)
        if (n.isBlank()) return ""
        routeIds.firstOrNull { normalize(it) == n }?.let { return it }
        aliases[n]?.let { return it }
        aliases.entries.firstOrNull { (alias, _) -> n.contains(alias) }?.let { return it.value }
        routeIds.firstOrNull { n.contains(normalize(it)) }?.let { return it }
        return n.replace(' ', '_')
    }

    fun extractRouteIds(text: String): Set<String> {
        val n = normalize(text)
        if (n.isBlank()) return emptySet()
        val direct = routeIds.filter { n.contains(normalize(it)) }.toMutableSet()
        aliases.forEach { (alias, routeId) ->
            if (n.contains(alias)) direct += routeId
        }
        if (containsAny(n, "covid", "sars cov 2", "long covid", "pasc") && containsAny(n, "interferon", "ifn", "il 6", "tnf", "pbmc")) direct += "covid_interferon_cytokine_bridge"
        if (containsAny(n, "allergy", "allergies", "allergic", "hypersensitivity", "ige", "mast cell", "eosinophil")) direct += "allergy_type2_ige_mast_eosinophil"
        if (containsAny(n, "ebola", "evd", "filovirus") && containsAny(n, "host response", "hemorrhagic", "pbmc", "blood", "cytokine", "transcript")) direct += "ebola_hemorrhagic_viral_host_response"
        if (containsAny(n, "microbiome", "microbiota", "gut bacteria", "gut brain", "tryptophan", "kynurenine") && containsAny(n, "depression", "mood", "neuroinflammation", "il 6", "tnf", "crp")) direct += "gut_microbiome_to_neuroinflammation"
        if (containsAny(n, "fungi", "fungal", "yeast", "candida", "mycology") && containsAny(n, "barrier", "th17", "neutrophil", "dysbiosis", "allergy")) direct += "fungal_exposure_to_barrier_dysbiosis"
        return direct.map { canonicalize(it) }.filter { it.isNotBlank() }.toSet()
    }

    fun isAllowedRouteText(text: String, contract: GTIMRunDecisionContractV2740): Boolean {
        val ids = extractRouteIds(text)
        if (ids.isEmpty()) return true
        return ids.all { contract.canUseRoute(it) || contract.allowedRoutes.contains(canonicalize(it)) }
    }

    fun isAnchorCompatibleText(text: String, contract: GTIMRunDecisionContractV2740): Boolean {
        val ids = extractRouteIds(text)
        if (ids.any { contract.canUseRoute(it) }) return true
        val n = normalize(text)
        val anchor = contract.primaryAnchor
        return when (anchor) {
            GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> containsAny(n, "covid", "sars cov 2", "long covid", "pasc", "interferon")
            GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> containsAny(n, "allergy", "allergies", "allergic", "hypersensitivity", "ige", "mast cell", "eosinophil")
            GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> containsAny(n, "ebola", "evd", "hemorrhagic", "filovirus")
            GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> containsAny(n, "microbiome", "gut bacteria", "tryptophan", "kynurenine", "depression", "mood")
            GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE -> containsAny(n, "ibd", "crohn", "colitis", "mucosal", "intestinal barrier")
            else -> n.contains(normalize(anchor.routeId))
        }
    }

    fun normalize(value: String): String = value.lowercase()
        .replace('→', ' ')
        .replace('↔', ' ')
        .replace("/", " ")
        .replace("_", " ")
        .replace("-", " ")
        .replace(Regex("[^a-z0-9α-ωΑ-Ω]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun containsAny(text: String, vararg needles: String): Boolean = needles.any { text.contains(it) }
}
