package com.immunesignal.app

data class MinimumDataPackAssessment(
    val status: String,
    val missingData: List<String>,
    val nextBestMeasurement: String,
    val rationale: List<String>
)

/**
 * Research Quality Stop.
 *
 * A hypothesis cannot be upgraded when its minimum data pack is weak. This is
 * intentionally conservative: it makes the engine ask for the next measurement
 * instead of producing strong claims from attractive literature links.
 */
object MinimumDataPackGate {
    fun assess(
        card: HypothesisRankCard,
        axes: List<String>,
        findings: List<ResearchFinding>,
        importedSignals: List<ImportedReportSignal>
    ): MinimumDataPackAssessment {
        val required = requiredFieldsFor(axes)
        val observed = observedFields(axes, findings, importedSignals, card)
        val missing = required.filterNot { req -> matchesRequiredField(req, observed) }
        val status = when {
            missing.isEmpty() && card.personalRepeatability >= 3 -> "PASS"
            missing.size <= 2 || card.personalRepeatability in 1..2 -> "PARTIAL"
            else -> "BLOCKED"
        }
        return MinimumDataPackAssessment(
            status = status,
            missingData = missing.take(8),
            nextBestMeasurement = nextMeasurementFor(axes, missing, card),
            rationale = buildList {
                add("Minimum data pack status: $status.")
                add("Personal repeatability: ${card.personalRepeatability} repeated observations.")
                if (missing.isNotEmpty()) add("Missing: ${missing.take(5).joinToString(", ")}.")
            }
        )
    }

    private fun requiredFieldsFor(axes: List<String>): List<String> {
        val out = linkedSetOf("timestamp", "symptom_intensity", "sleep_quality")
        if (axes.contains("psychoneuroimmune_axis")) out += listOf("stress_score", "event_timing")
        if (axes.contains("type2_allergy_axis")) out += listOf("allergy_intensity", "IgE_or_eosinophils", "exposure_context")
        if (axes.contains("autonomic_vascular_axis")) out += listOf("systolic_bp", "diastolic_bp", "pulse", "dizziness_or_flushing")
        if (axes.contains("gastric_acid_gut_axis") || axes.contains("gut_barrier_microbiome_axis")) out += listOf("reflux_or_gastric_symptoms", "meal_timing", "acid_suppression_context")
        if (axes.contains("nutrition_protein_axis") || axes.contains("muscle_mass_reserve_axis")) out += listOf("protein_or_diet_record", "exercise_or_muscle_fatigue")
        if (axes.contains("testosterone_immune_axis")) out += listOf("testosterone_lab_or_context", "fatigue_recovery")
        if (axes.contains("dna_genomic_axis")) out += listOf("variant_or_methylation_source", "source_quality")
        if (axes.contains("rna_transcriptomic_axis")) out += listOf("rna_dataset_or_gene_signature", "tissue_or_cell_context")
        if (axes.contains("tnf_il6_autoimmune_axis") || axes.contains("hyperinflammatory_axis")) out += listOf("CRP_or_IL6_or_TNF", "infection_or_autoimmune_context")
        return out.toList()
    }


    private fun matchesRequiredField(required: String, observed: Set<String>): Boolean {
        val normalizedObserved = observed.map { normalizeField(it) }.filter { it.isNotBlank() }.toSet()
        return required.lowercase()
            .split("_or_")
            .map { normalizeField(it) }
            .filter { it.isNotBlank() }
            .any { alternative -> matchesAlternative(alternative, normalizedObserved) }
    }

    private fun matchesAlternative(alternative: String, observed: Set<String>): Boolean {
        if (alternative in observed) return true
        val tokens = alternative.split("_").filter { it.length > 2 }
        if (tokens.isEmpty()) return false
        return tokens.all { token -> token in observed }
    }

    private fun normalizeField(value: String): String = value
        .lowercase()
        .replace("-", "_")
        .replace(" ", "_")
        .replace(Regex("[^a-z0-9_]+"), "_")
        .replace(Regex("_+"), "_")
        .trim('_')

    private fun observedFields(
        axes: List<String>,
        findings: List<ResearchFinding>,
        importedSignals: List<ImportedReportSignal>,
        card: HypothesisRankCard
    ): Set<String> {
        val text = buildString {
            append(axes.joinToString(" ")).append(' ')
            append(card.nextBestMeasurement).append(' ')
            append(card.whyRanked.joinToString(" ")).append(' ')
            append(findings.joinToString(" ") { it.title + " " + it.whyItMatters + " " + it.personalPattern.nextBestMeasurement }).append(' ')
            append(importedSignals.joinToString(" ") { it.extractedKeywords.joinToString(" ") + " " + it.preview })
        }.lowercase()
        val observed = mutableSetOf<String>()
        listOf("timestamp", "stress", "sleep", "allergy", "ige", "eosinophil", "pulse", "dizziness", "flushing", "reflux", "gastric", "protein", "muscle", "testosterone", "dna", "methylation", "rna", "gene", "crp", "il-6", "tnf", "infection").forEach {
            if (text.contains(it)) observed += normalizeField(it)
        }
        if (text.contains("blood pressure") || Regex("\bbp\b").containsMatchIn(text)) observed += "bp"
        if (text.contains("systolic")) observed += "systolic"
        if (text.contains("diastolic")) observed += "diastolic"
        if (text.contains("stress score")) observed += "stress_score"
        if (text.contains("symptom intensity")) observed += "symptom_intensity"
        if (text.contains("allergy intensity")) observed += "allergy_intensity"
        if (text.contains("sleep quality")) observed += "sleep_quality"
        if (Regex("\b(before|after|during|timing|timestamped)\b").containsMatchIn(text)) observed += "event_timing"
        if (Regex("\bmeal timing\b|\bafter meal\b|\bbefore meal\b|\bwith meal\b").containsMatchIn(text)) observed += "meal_timing"
        if (text.contains("acid suppression") || text.contains("ppi") || text.contains("antacid")) observed += "acid_suppression_context"
        if (text.contains("source quality")) observed += "source_quality"
        if (card.personalRepeatability > 0) observed += "timestamp"
        return observed
    }

    private fun nextMeasurementFor(axes: List<String>, missing: List<String>, card: HypothesisRankCard): String {
        if (missing.isNotEmpty()) return "Collect next missing field: ${missing.first()}."
        return when {
            axes.contains("autonomic_vascular_axis") -> "Measure BP + pulse before, during, and after the next allergy/stress episode."
            axes.contains("type2_allergy_axis") -> "Track allergy intensity + exposure + sleep/stress timing for 3 episodes."
            axes.contains("gastric_acid_gut_axis") -> "Track meal/reflux/acid-suppression timing against allergy or airway symptoms."
            axes.contains("rna_transcriptomic_axis") -> "Map the lead to a real RNA dataset or gene signature before upgrading."
            else -> card.nextBestMeasurement.ifBlank { "Add 3 timestamped repeated observations." }
        }
    }
}
