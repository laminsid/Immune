package com.immunesignal.app

import java.util.Locale

/**
 * Strips potentially-identifying tokens from research-steering inputs
 * BEFORE they are concatenated into outbound NCBI URLs.
 *
 * Rationale (v0.9.1 fix): The README claims "No private case data is uploaded."
 * But in v0.9.0, raw user-typed steering variables/required-terms were forwarded
 * verbatim to https://eutils.ncbi.nlm.nih.gov as URL query string. A user who
 * entered "testosterone 320 ng/dL" or "post-COVID rash July 2025" would leak
 * personal context to NCBI server logs.
 *
 * This sanitizer enforces the privacy contract: only generic medical terms
 * survive. Anything that looks like a value, date, name, or identifier is
 * removed and the user is informed via SanitizationResult.removed.
 *
 * This is a privacy guard, not a security guarantee. We still recommend the
 * user be conservative with steering inputs.
 */
object SteeringSanitizer {

    data class SanitizationResult(
        val cleaned: List<String>,
        val removed: List<String>,
        val warnings: List<String>
    )

    // Patterns that suggest personal/identifying content.
    private val numericValue = Regex("""\b\d+(?:[.,]\d+)?\s*(?:mg|ml|µg|ug|ng|pg|iu|kg|lb|cm|mm|mmhg|bpm|c|f|/dl|/l|/ul|%)?\b""", RegexOption.IGNORE_CASE)
    private val datePattern = Regex("""\b(?:19|20)\d{2}(?:[-/]\d{1,2}(?:[-/]\d{1,2})?)?\b""")
    private val monthPattern = Regex("""\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\b""", RegexOption.IGNORE_CASE)
    private val emailPattern = Regex("""\b[\w.+-]+@[\w-]+\.[\w.-]+\b""")
    private val urlPattern = Regex("""https?://\S+""", RegexOption.IGNORE_CASE)
    private val possessive = Regex("""\b(?:my|me|i'?m|i'?ve|i\s+have|mine|myself|our|us)\b""", RegexOption.IGNORE_CASE)
    private val locationHint = Regex("""\b(?:berlin|munich|hamburg|cologne|frankfurt|dresden|leipzig|stuttgart)\b""", RegexOption.IGNORE_CASE)
    // Capitalised single-word run that is NOT a known medical term — likely a name.
    private val possibleProperNoun = Regex("""\b[A-Z][a-z]{2,}\b""")

    // Whitelist of safe medical/biology stems. If a token is not in any pattern
    // above AND contains at least one whitelist stem, it passes.
    // This is INTENTIONALLY narrow. False rejections are safer than leaks.
    private val safeStems = listOf(
        "aller", "asthma", "ige", "eosin", "histamin", "mast", "type-2", "type 2",
        "tnf", "il-", "il6", "il10", "rheumat", "autoimm", "arthrit",
        "cytokine", "hyperinflam", "ards", "sepsis", "ferritin",
        "regulator", "treg", "immune", "inflamm",
        "stress", "sleep", "depress", "anxiet", "psychoneuro", "panic",
        "back pain", "disc", "muscle", "sensitiz", "fear avoidance", "mechanical",
        "aging", "immunosenescence", "inflammaging", "longevity", "senescence", "frailty",
        "blood pressure", "hypotension", "vasodilation", "autonomic", "dizziness",
        "heart rate", "vascular", "pulse",
        "dna", "genome", "genetic", "epigenetic", "methylation", "snp", "variant",
        "rna", "transcript", "mrna", "mirna", "single-cell", "single cell",
        "scrna", "gene expression",
        "stomach acid", "gastric", "hypochlorhydria", "achlorhydria",
        "reflux", "gerd", "ppi", "proton pump", "h pylori", "gastritis",
        "microbiome", "gut barrier", "intestinal permeability", "dysbiosis",
        "gut-lung", "gut immune",
        "nutrition", "protein", "diet", "malnutrition", "appetite", "amino acid",
        "muscle mass", "sarcopenia", "lean mass", "strength training",
        "resistance exercise", "myokine",
        "testosterone", "androgen", "hypogonadism", "sex hormone",
        "crp", "esr"
    )

    fun sanitize(inputs: List<String>): SanitizationResult {
        val cleaned = mutableListOf<String>()
        val removed = mutableListOf<String>()
        val warnings = mutableSetOf<String>()

        for (raw in inputs) {
            val term = raw.trim()
            if (term.isEmpty() || term.length < 2) continue
            if (term.length > 80) {
                removed += term
                warnings += "removed_too_long_term"
                continue
            }
            val lower = term.lowercase(Locale.US)

            if (numericValue.containsMatchIn(lower)) {
                removed += term; warnings += "removed_numeric_value (looks like a personal measurement)"
                continue
            }
            if (datePattern.containsMatchIn(lower)) {
                removed += term; warnings += "removed_date (looks like a personal date)"
                continue
            }
            if (monthPattern.containsMatchIn(lower)) {
                removed += term; warnings += "removed_month (looks like a personal date)"
                continue
            }
            if (emailPattern.containsMatchIn(lower)) {
                removed += term; warnings += "removed_email"
                continue
            }
            if (urlPattern.containsMatchIn(lower)) {
                removed += term; warnings += "removed_url"
                continue
            }
            if (possessive.containsMatchIn(lower)) {
                removed += term; warnings += "removed_possessive (use generic terms)"
                continue
            }
            if (locationHint.containsMatchIn(lower)) {
                removed += term; warnings += "removed_location_hint"
                continue
            }

            // Allow if any safe stem is present.
            val hasSafeStem = safeStems.any { lower.contains(it) }
            if (!hasSafeStem) {
                // If it's a single capitalised word, treat as possible proper noun.
                if (possibleProperNoun.matches(term)) {
                    removed += term; warnings += "removed_unknown_capitalised_token"
                } else {
                    // Unknown but safe-looking; allow but mark.
                    cleaned += term
                    warnings += "passed_unknown_term (review your steering inputs)"
                }
            } else {
                cleaned += term
            }
        }

        return SanitizationResult(
            cleaned = cleaned.distinctBy { it.lowercase(Locale.US) },
            removed = removed.distinctBy { it.lowercase(Locale.US) },
            warnings = warnings.toList()
        )
    }
}
