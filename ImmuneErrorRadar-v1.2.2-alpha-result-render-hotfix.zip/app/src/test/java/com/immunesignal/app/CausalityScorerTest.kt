package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for CausalityScorer.
 *
 * Critical v0.9.1 contract: the negativeControlStatus parameter MUST affect
 * the returned causalityScore. v0.9.0 ignored it numerically, contradicting
 * the README claim that negative-control resistance was part of the rule.
 */
class CausalityScorerTest {

    private fun ev(quality: Int, design: String = "human_cohort", species: String = "human") =
        EvidenceAssessment(
            sourceClass = if (species == "human") "human_observational" else "animal_model",
            speciesClass = species,
            studyDesign = design,
            humanEvidence = species == "human",
            evidenceQualityScore = quality,
            limitations = listOf("test")
        )

    private fun pp(repeated: Int) = PersonalPatternAssessment(
        repeatedObservationCount = repeated,
        temporalSupport = "test",
        strongestLocalAxes = listOf("psychoneuroimmune_axis"),
        nextBestMeasurement = "Add repeated dated entries."
    )

    @Test
    fun `negative control status changes the numeric score`() {
        val text = "stress before allergy histamine blood pressure mast cell mechanism"
        val axes = listOf("psychoneuroimmune_axis", "type2_allergy_axis", "autonomic_vascular_axis")
        val a = CausalityScorer.score(text, axes, ev(74), pp(3), "weak_no_control_possible")
        val b = CausalityScorer.score(text, axes, ev(74), pp(3), "control_required_before_strong")
        assertNotEquals(
            "negative control status must change the score; v0.9.0 ignored it",
            a.causalityScore,
            b.causalityScore
        )
        assertTrue("missing-control status must lower causality", b.causalityScore < a.causalityScore)
    }

    @Test
    fun `temporal language raises temporality subscore`() {
        val text = "longitudinal cohort showing histamine before allergy"
        val r = CausalityScorer.score(text, listOf("psychoneuroimmune_axis"), ev(74), pp(2))
        assertEquals(55, r.temporalityScore)
    }

    @Test
    fun `no temporal language and no temporal design defaults temporality to 20`() {
        val text = "association between markers"
        val r = CausalityScorer.score(text, listOf("type2_allergy_axis"), ev(35, design = "unknown_design"), pp(0))
        assertEquals(20, r.temporalityScore)
    }

    @Test
    fun `negative finding triggers contradiction penalty 25`() {
        val text = "RCT showed no association between testosterone and allergy"
        val r = CausalityScorer.score(text, listOf("type2_allergy_axis"), ev(88, design = "human_randomized_trial"), pp(2))
        assertEquals(25, r.contradictionPenalty)
    }

    @Test
    fun `score is clamped to 0..100`() {
        val text = "longitudinal mechanism pathway histamine il-6 mast cell autonomic"
        val r = CausalityScorer.score(text, listOf("psychoneuroimmune_axis", "autonomic_vascular_axis"), ev(100), pp(5))
        assertTrue("score must be clamped to 0..100, got ${r.causalityScore}", r.causalityScore in 0..100)
    }

    @Test
    fun `repeatability bucket 3+ gives 70`() {
        val r = CausalityScorer.score("x", listOf("psychoneuroimmune_axis"), ev(60), pp(5))
        assertEquals(70, r.repeatabilityScore)
    }

    @Test
    fun `repeatability bucket 0 gives 10`() {
        val r = CausalityScorer.score("x", listOf("psychoneuroimmune_axis"), ev(60), pp(0))
        assertEquals(10, r.repeatabilityScore)
    }
}
