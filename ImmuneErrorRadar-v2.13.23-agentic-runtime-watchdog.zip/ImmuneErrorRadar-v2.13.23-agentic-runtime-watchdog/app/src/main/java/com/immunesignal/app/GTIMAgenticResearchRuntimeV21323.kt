package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.23 — Agentic research runtime contract.
 *
 * This is not a separate island engine. It documents and exports the operating
 * model that replaces one long blocking Android foreground run:
 * one: fast agent planner from local scientific memory and route ontology,
 * two: short external proof batches,
 * three: local memory merge,
 * four: repeatable deepening passes with executed/queued separation.
 *
 * The purpose is to preserve global research quality without keeping a single
 * Activity job alive until Android kills it.
 */
object GTIMAgenticResearchRuntimeV21323 {
    const val VERSION: String = "2.13.23-agentic-research-runtime"
    const val CLAIM_BOUNDARY: String = "agentic_runtime_routes_research_only_not_evidence_not_medical_advice"

    fun startCard(topic: String, budget: GTIMMobileSearchBudgetV21322): String {
        return buildString {
            append("Agentic research mode\n")
            append("• Topic: ").append(topic.take(180).ifBlank { "captured topic" }).append("\n")
            append("• First answer source: local scientific memory, route ontology, prior reports, and curated seed capsules.\n")
            append("• External proof: split into short batches of max ").append(budget.maxQueries).append(" queries and ").append(budget.maxResultsPerQuery).append(" results/query.\n")
            append("• Safety: foreground pass closes at ").append(budget.hardTimeoutMillis / 1000L).append("s; deeper global suggestions are accumulated through saved passes.\n")
            append("• Boundary: agent suggestions are research leads until source/provenance/contradiction gates execute.")
        }
    }

    fun toJson(
        snapshot: ResearchTopicCaptureSnapshotV2740,
        budget: GTIMMobileSearchBudgetV21322,
        sameTopicPlan: GTIMSameTopicDeepeningPlanV2123,
        passState: String
    ): JSONObject {
        val topic = snapshot.normalizedTopic.ifBlank { "captured research topic" }
        val passes = JSONArray()
        passes.put(JSONObject()
            .put("pass", "P0_AGENT_PLANNER")
            .put("source", "local route ontology + previous report memory + curated metadata seeds")
            .put("output", "topic route, candidate mechanisms, source-family plan, falsification targets")
            .put("timeBehavior", "fast_first_surface"))
        passes.put(JSONObject()
            .put("pass", "P1_EXTERNAL_PROOF_BATCH")
            .put("source", "bounded PubMed/NCBI/metadata lookups")
            .put("output", "executed source handles and unresolved accessions")
            .put("timeBehavior", "short_cancellable_batch"))
        passes.put(JSONObject()
            .put("pass", "P2_MEMORY_MERGE")
            .put("source", "saved local reports and failure memory")
            .put("output", "what changed, what remains queued, next best query")
            .put("timeBehavior", "save_and_resume"))
        passes.put(JSONObject()
            .put("pass", "P3_GLOBAL_SUGGESTION_SURFACE")
            .put("source", "confirmed handles + plausible bridges + weak leads + missing evidence")
            .put("output", "research-only global suggestion card")
            .put("timeBehavior", "visible_without_blocking"))

        return JSONObject()
            .put("version", VERSION)
            .put("state", passState)
            .put("claimBoundary", CLAIM_BOUNDARY)
            .put("topic", topic.take(240))
            .put("whyAgentic", "Global suggestions should come from local knowledge synthesis plus short proof-seeking batches, not from one 10-20 minute foreground loop.")
            .put("foregroundRule", "The Activity may show progress only inside the mobile budget; deeper research is split into repeatable passes saved in local memory.")
            .put("mobileBudget", JSONObject()
                .put("hardTimeoutSeconds", budget.hardTimeoutMillis / 1000L)
                .put("searchSeconds", budget.searchMillis / 1000L)
                .put("learningSeconds", budget.learningMillis / 1000L)
                .put("maxQueries", budget.maxQueries)
                .put("maxResultsPerQuery", budget.maxResultsPerQuery)
                .put("maxAbstractsPerCycle", budget.maxAbstractsPerCycle))
            .put("agentPasses", passes)
            .put("sameTopicDeepening", JSONObject()
                .put("active", sameTopicPlan.active)
                .put("depth", sameTopicPlan.deepeningDepth)
                .put("rule", "deepening repeats safe passes; it must not extend one foreground job beyond the watchdog"))
            .put("executedQueuedRule", "Executed checks may be reported as progress. Queued checks remain hypotheses/tasks and cannot upgrade evidence.")
            .put("globalSuggestionRule", "A global answer can be proposed from accumulated agent memory, but evidence grade only rises after source/provenance/contradiction gates execute.")
    }
}
