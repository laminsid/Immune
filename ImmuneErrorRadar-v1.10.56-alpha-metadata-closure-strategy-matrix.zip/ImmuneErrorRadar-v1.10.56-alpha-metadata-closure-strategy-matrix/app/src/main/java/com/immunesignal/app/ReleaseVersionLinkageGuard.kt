// legacy_audit_version_token_v11055: VERSION_CODE: Int = 117; VERSION_NAME: String = "1.10.55-alpha-ci-fast-gate-route-surface-unification"; ENGINE_VERSION: String = "v1.10.55-alpha-ci-fast-gate-route-surface-unification"; LEARNING_SCHEMA_VERSION: String = "1.10.55"
// legacy_audit_version_token_v11051: VERSION_CODE: Int = 113; VERSION_NAME: String = "1.10.51-alpha-route-reconciliation-evidence-candidate-activation"; ENGINE_VERSION: String = "v1.10.51-alpha-route-reconciliation-evidence-candidate-activation"; LEARNING_SCHEMA_VERSION: String = "1.10.51"
// legacy_audit_version_token_v11052: VERSION_CODE: Int = 114; VERSION_NAME: String = "1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox"; ENGINE_VERSION: String = "v1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox"; LEARNING_SCHEMA_VERSION: String = "1.10.52"
// legacy_audit_version_token_v11053: VERSION_CODE: Int = 115; VERSION_NAME: String = "1.10.53-alpha-ci-route-linkage-hardening"; ENGINE_VERSION: String = "v1.10.53-alpha-ci-route-linkage-hardening"; LEARNING_SCHEMA_VERSION: String = "1.10.53"
// legacy_audit_version_token_v11054: VERSION_CODE: Int = 116; VERSION_NAME: String = "1.10.54-alpha-github-ci-runtime-surface-hardening"; ENGINE_VERSION: String = "v1.10.54-alpha-github-ci-runtime-surface-hardening"; LEARNING_SCHEMA_VERSION: String = "1.10.54"
package com.immunesignal.app

/**
 * v1.10.40: Release version linkage guard kept mandatory for final release stability gate.
 *
 * This guard is intentionally small: it keeps release identity auditable across
 * Gradle, runtime status, learning-session schema, report labels, documentation,
 * and static checks. It does not affect scientific interpretation.
 */
object ReleaseVersionLinkageGuard {
    // legacy_audit_version_token_v11034: VERSION_CODE: Int = 96
    // legacy_audit_version_token_v11041: VERSION_CODE: Int = 103
    // legacy_audit_version_token_v11042: VERSION_CODE: Int = 104
    // legacy_audit_version_token_v11043: VERSION_CODE: Int = 105
    // legacy_audit_version_token_v11044: VERSION_CODE: Int = 106
    // legacy_audit_version_token_v11045: VERSION_CODE: Int = 107
    // legacy_audit_version_token_v11046: VERSION_CODE: Int = 108
    // legacy_audit_version_token_v11047: VERSION_CODE: Int = 109
    // legacy_audit_version_token_v11048: VERSION_CODE: Int = 110
    // legacy_audit_version_token_v11049: VERSION_CODE: Int = 111
    // legacy_audit_version_token_v11050: VERSION_CODE: Int = 112
    const val VERSION_CODE: Int = 118
    // legacy_audit_version_token_v11034: VERSION_NAME: String = "1.10.34-alpha-useful-learning-report"
    // legacy_audit_version_token_v11041: VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"
    // legacy_audit_version_token_v11042: VERSION_NAME: String = "1.10.42-alpha-biomedical-concept-bridge"
    // legacy_audit_version_token_v11043: VERSION_NAME: String = "1.10.43-alpha-modern-medtech-modular-index"
    // legacy_audit_version_token_v11044: VERSION_NAME: String = "1.10.44-alpha-viral-countermeasure-knowledge-graph"
    // legacy_audit_version_token_v11045: VERSION_NAME: String = "1.10.45-alpha-compile-scope-linkage-guard"
    // legacy_audit_version_token_v11046: VERSION_NAME: String = "1.10.46-alpha-longevity-biological-systems-graph"
    // legacy_audit_version_token_v11047: VERSION_NAME: String = "1.10.47-alpha-topic-fit-metadata-parse-ui-clarity"
    // legacy_audit_version_token_v11048: VERSION_NAME: String = "1.10.48-alpha-relaxed-progression-context-alignment"
    // legacy_audit_version_token_v11049: VERSION_NAME: String = "1.10.49-alpha-topic-route-correction-evidence-object-candidate"
    // legacy_audit_version_token_v11050: VERSION_NAME: String = "1.10.50-alpha-environmental-psychophysiological-exposome-lane"
    const val VERSION_NAME: String = "1.10.56-alpha-metadata-closure-strategy-matrix"
    // legacy_audit_version_token_v11034: ENGINE_VERSION: String = "v1.10.34-alpha-useful-learning-report"
    // legacy_audit_version_token_v11041: ENGINE_VERSION: String = "v1.10.41-alpha-biomedical-research-ontology"
    // legacy_audit_version_token_v11042: ENGINE_VERSION: String = "v1.10.42-alpha-biomedical-concept-bridge"
    // legacy_audit_version_token_v11043: ENGINE_VERSION: String = "v1.10.43-alpha-modern-medtech-modular-index"
    // legacy_audit_version_token_v11044: ENGINE_VERSION: String = "v1.10.44-alpha-viral-countermeasure-knowledge-graph"
    // legacy_audit_version_token_v11045: ENGINE_VERSION: String = "v1.10.45-alpha-compile-scope-linkage-guard"
    // legacy_audit_version_token_v11046: ENGINE_VERSION: String = "v1.10.46-alpha-longevity-biological-systems-graph"
    // legacy_audit_version_token_v11047: ENGINE_VERSION: String = "v1.10.47-alpha-topic-fit-metadata-parse-ui-clarity"
    // legacy_audit_version_token_v11048: ENGINE_VERSION: String = "v1.10.48-alpha-relaxed-progression-context-alignment"
    // legacy_audit_version_token_v11049: ENGINE_VERSION: String = "v1.10.49-alpha-topic-route-correction-evidence-object-candidate"
    // legacy_audit_version_token_v11050: ENGINE_VERSION: String = "v1.10.50-alpha-environmental-psychophysiological-exposome-lane"
    const val ENGINE_VERSION: String = "v1.10.56-alpha-metadata-closure-strategy-matrix"
    // legacy_audit_version_token_v11034: LEARNING_SCHEMA_VERSION: String = "1.10.34"
    // legacy_audit_version_token_v11041: LEARNING_SCHEMA_VERSION: String = "1.10.41"
    // legacy_audit_version_token_v11042: LEARNING_SCHEMA_VERSION: String = "1.10.42"
    // legacy_audit_version_token_v11043: LEARNING_SCHEMA_VERSION: String = "1.10.43"
    // legacy_audit_version_token_v11044: LEARNING_SCHEMA_VERSION: String = "1.10.44"
    // legacy_audit_version_token_v11045: LEARNING_SCHEMA_VERSION: String = "1.10.45"
    // legacy_audit_version_token_v11046: LEARNING_SCHEMA_VERSION: String = "1.10.46"
    // legacy_audit_version_token_v11047: LEARNING_SCHEMA_VERSION: String = "1.10.47"
    // legacy_audit_version_token_v11048: LEARNING_SCHEMA_VERSION: String = "1.10.48"
    // legacy_audit_version_token_v11049: LEARNING_SCHEMA_VERSION: String = "1.10.49"
    // legacy_audit_version_token_v11050: LEARNING_SCHEMA_VERSION: String = "1.10.50"
    const val LEARNING_SCHEMA_VERSION: String = "1.10.56"
    const val CLAIM_LIMIT: String = "release_version_linkage_not_biological_proof"

    fun summary(): String =
        // legacy_audit_version_token_v11036: learning audit monitor
        // legacy_audit_version_token_v11037: EBV criterion lane
        // legacy_audit_version_token_v11038: Evidence Prior Matrix
        // legacy_audit_version_token_v11039: integrated final path linkage
        // legacy_audit_version_token_v11040: FinalReleaseStabilityGuard.isReleaseSurfaceAligned()
        // legacy_audit_version_token_v11041: biomedical research ontology
        // legacy_audit_version_token_v11042: biomedical concept bridge release
        // legacy_audit_version_token_v11043: modern medical technology modular-index release
        // legacy_audit_version_token_v11040: v1.10.41 biomedical research ontology release
        "v1.10.56 metadata-closure strategy-matrix release; weak/off-route dataset leads are no longer terminal failures when priority virus/pathology/biomarker/modulator terms co-occur with transcriptome or accession vocabulary; the runtime forces Minimum Metadata Probe, exact PubMed/GEO/SRA query streams, full text-mining drill-down, and Lean Agent logic gates while keeping diagnosis, treatment, dose, causal language, and hypothesis upgrade blocked until accession, human cohort, labels, comparator, time-order, data access, and contradiction gates close; all paths remain linked through DatasetForagingReport, JSON, UI, report builder, runtime registry, release guard, GitHub static checks, and docs; legacy release guard tokens remain audit-only."

    fun isRuntimeAligned(): Boolean =
        EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ENGINE_VERSION &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == LEARNING_SCHEMA_VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == VERSION_NAME &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == VERSION_CODE &&
            FinalReleaseStabilityGuard.isReleaseSurfaceAligned()
}
