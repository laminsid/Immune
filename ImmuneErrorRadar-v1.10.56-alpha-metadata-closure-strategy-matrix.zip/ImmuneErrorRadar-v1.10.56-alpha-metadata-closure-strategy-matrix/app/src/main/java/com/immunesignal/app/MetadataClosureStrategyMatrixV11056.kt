package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.56: Metadata Closure Strategy Matrix.
 *
 * Purpose: prevent weak/off-route transcriptome leads from collapsing into FAIL,
 * NOT_RUN, or narrative-only output. The layer converts low-usability snippets into
 * bounded minimum-metadata probes when they overlap the priority matrix:
 * latent viruses, autoimmune/fatigue pathologies, interferon/cytokine/HPA markers,
 * and modulator/control vocabulary. This is an evidence-foraging layer only.
 */
data class MetadataClosureDiscoveryHypothesisV11056(
    val hypothesisId: String,
    val label: String,
    val bridge: String,
    val matchedTargets: List<String>,
    val requiredMetadata: List<String>,
    val falsifiers: List<String>,
    val claimLimit: String = MetadataClosureStrategyMatrixV11056.CLAIM_LIMIT
)

data class MetadataClosureKeywordQueryStreamV11056(
    val streamId: String,
    val sourceFamily: String,
    val query: String,
    val purpose: String,
    val requiredTokens: List<String>,
    val claimLimit: String = MetadataClosureStrategyMatrixV11056.CLAIM_LIMIT
)

data class MetadataClosureMinimumProbeV11056(
    val probeId: String,
    val sourceId: String,
    val sourceFamily: String,
    val originalStatus: String,
    val routeFitBoost: Int,
    val reason: String,
    val requiredMetadataFields: List<String>,
    val drillDownForced: Boolean,
    val allowedRuntimeAction: String,
    val blockedRuntimeActions: List<String>,
    val claimLimit: String = MetadataClosureStrategyMatrixV11056.CLAIM_LIMIT
)

data class MetadataClosureLogicGateV11056(
    val gateId: String,
    val condition: String,
    val action: String,
    val blocksFailOrNotRun: Boolean,
    val blocksClaimUpgrade: Boolean,
    val claimLimit: String = MetadataClosureStrategyMatrixV11056.CLAIM_LIMIT
)

data class MetadataClosureStrategyMatrixReport(
    val active: Boolean,
    val state: String,
    val executionLock: String,
    val detectedTargets: List<String>,
    val routeFitBoostScore: Int,
    val textMiningDrillDownForced: Boolean,
    val discoveryHypotheses: List<MetadataClosureDiscoveryHypothesisV11056>,
    val queryStreams: List<MetadataClosureKeywordQueryStreamV11056>,
    val minimumMetadataProbes: List<MetadataClosureMinimumProbeV11056>,
    val leanRuntimeLogicGates: List<MetadataClosureLogicGateV11056>,
    val hardClaimGates: List<String>,
    val nextAction: String,
    val claimLimit: String = MetadataClosureStrategyMatrixV11056.CLAIM_LIMIT
) {
    companion object {
        fun empty() = MetadataClosureStrategyMatrixReport(
            active = false,
            state = "NOT_EVALUATED",
            executionLock = "NOT_LOADED",
            detectedTargets = emptyList(),
            routeFitBoostScore = 0,
            textMiningDrillDownForced = false,
            discoveryHypotheses = emptyList(),
            queryStreams = emptyList(),
            minimumMetadataProbes = emptyList(),
            leanRuntimeLogicGates = emptyList(),
            hardClaimGates = listOf("no clinical claim", "no diagnosis", "no treatment/dose recommendation", "no hypothesis upgrade without evidence object"),
            nextAction = "Run a dataset-first research cycle."
        )
    }
}

object MetadataClosureStrategyMatrixV11056 {
    const val VERSION_LABEL: String = "v1.10.56-alpha-metadata-closure-strategy-matrix"
    const val CLAIM_LIMIT: String = "exploration_sandbox_not_biological_proof"
    private const val MINIMUM_METADATA_PROBE_STATE: String = "MINIMUM_METADATA_PROBE_FORCED"

    private val accessionTokens = listOf(
        "accession", "gse", "gds", "geo", "prjna", "prjeb", "srp", "srr", "sra", "e-mtab", "arrayexpress", "sdy", "immport", "pmid", "doi", "data availability"
    )
    private val transcriptomeTokens = listOf(
        "transcriptome", "transcriptomic", "rna-seq", "rnaseq", "scrna", "single-cell", "gene expression", "microarray", "expression matrix", "bulk rna"
    )

    private val targetTerms: List<Pair<String, List<String>>> = listOf(
        "EBV" to listOf("ebv", "epstein-barr", "epstein barr"),
        "HHV-6" to listOf("hhv-6", "hhv6", "human herpesvirus 6"),
        "SARS-CoV-2_LONG_COVID" to listOf("sars-cov-2", "covid", "long covid", "post-acute covid", "pasc"),
        "CMV" to listOf("cmv", "cytomegalovirus"),
        "SLE" to listOf("sle", "systemic lupus", "lupus"),
        "MS" to listOf("multiple sclerosis", "ms ", " ms"),
        "ME_CFS" to listOf("me/cfs", "myalgic encephalomyelitis", "chronic fatigue syndrome"),
        "RA" to listOf("rheumatoid arthritis", "ra ", " ra"),
        "IFN_ALPHA_BETA" to listOf("interferon-alpha", "interferon beta", "interferon-beta", "type i interferon", "ifn-alpha", "ifna", "ifnb"),
        "IL6_TNF" to listOf("il-6", "il6", "tnf-alpha", "tnfα", "tnf"),
        "CORTISOL_DHEA" to listOf("cortisol", "dhea", "hpa axis", "hypothalamic-pituitary-adrenal"),
        "JAK_INHIBITOR_CONTROL" to listOf("jak inhibitor", "baricitinib", "tofacitinib", "ruxolitinib"),
        "RITUXIMAB_CONTROL" to listOf("rituximab", "anti-cd20", "cd20"),
        "CURCUMIN_NFKB_CONTEXT" to listOf("curcumin", "nf-kb", "nfkb", "nuclear factor kappa"),
        "ASHWAGANDHA_HPA_CONTEXT" to listOf("ashwagandha", "withania", "hpa regulation"),
        "QUERCETIN_CONTEXT" to listOf("quercetin")
    )

    fun evaluate(
        steering: ResearchSteeringProfile?,
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        attempts: List<DatasetSourceAttempt>,
        topicFit: TopicFitMetadataParseReport,
        metadataClosure: MetadataClosureReport,
        recentReports: List<String>
    ): MetadataClosureStrategyMatrixReport {
        val corpus = buildCorpus(steering, leadObjects, candidates, parsedMetadata, attempts, topicFit, metadataClosure, recentReports)
        val normalized = normalize(corpus)
        val detectedTargets = detectTargets(normalized)
        val hasMatrixHit = detectedTargets.isNotEmpty()
        val hasTranscriptomeOrAccession = containsAny(normalized, transcriptomeTokens) || containsAny(normalized, accessionTokens)
        val weakOrOffRoute = weakOrOffRouteSignal(leadObjects, candidates, attempts, topicFit, metadataClosure)
        val drillDownForced = hasMatrixHit && hasTranscriptomeOrAccession
        val active = weakOrOffRoute || drillDownForced || topicFit.forcedMinimumMetadataCount > 0 || metadataClosure.active
        if (!active) {
            return MetadataClosureStrategyMatrixReport.empty().copy(
                state = "STRATEGY_MATRIX_IDLE_READY",
                executionLock = "PASS_IDLE",
                detectedTargets = detectedTargets,
                nextAction = "Keep matrix ready; activate when a weak/off-route lead, transcriptome token, or accession token appears."
            )
        }
        val routeFitBoost = routeFitBoost(detectedTargets, hasTranscriptomeOrAccession, weakOrOffRoute, topicFit)
        val hypotheses = buildHypotheses(detectedTargets, normalized)
        val streams = buildQueryStreams(detectedTargets, normalized, topicFit.preferredLane)
        val probes = buildMinimumMetadataProbes(leadObjects, candidates, attempts, detectedTargets, routeFitBoost, drillDownForced)
        val gates = buildLogicGates(detectedTargets, hasTranscriptomeOrAccession)
        val hardClaimGates = listOf(
            "explicit accession or stable source identifier",
            "human/patient cohort metadata",
            "sample size and biospecimen context",
            "condition labels and outcome labels",
            "control/comparator or baseline",
            "time order / longitudinal sampling",
            "assay/platform and tissue/cell context",
            "data availability/licence/access text",
            "contradiction/null-result/negative-control search",
            "no diagnosis, treatment, dose, or supplement recommendation"
        )
        val state = when {
            drillDownForced && probes.isNotEmpty() -> "STRATEGY_MATRIX_FULL_TEXT_DRILLDOWN_FORCED"
            probes.isNotEmpty() -> MINIMUM_METADATA_PROBE_STATE
            drillDownForced -> "STRATEGY_MATRIX_ROUTE_FIT_ELEVATED"
            else -> "STRATEGY_MATRIX_ACTIVE_NO_PROBE_OBJECT"
        }
        return MetadataClosureStrategyMatrixReport(
            active = true,
            state = state,
            executionLock = "PASS_NO_FAIL_ON_WEAK_OR_OFF_ROUTE_LEAD",
            detectedTargets = detectedTargets,
            routeFitBoostScore = routeFitBoost,
            textMiningDrillDownForced = drillDownForced,
            discoveryHypotheses = hypotheses,
            queryStreams = streams,
            minimumMetadataProbes = probes,
            leanRuntimeLogicGates = gates,
            hardClaimGates = hardClaimGates,
            nextAction = nextAction(state, streams, probes, metadataClosure)
        )
    }

    private fun buildCorpus(
        steering: ResearchSteeringProfile?,
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        attempts: List<DatasetSourceAttempt>,
        topicFit: TopicFitMetadataParseReport,
        metadataClosure: MetadataClosureReport,
        recentReports: List<String>
    ): String = buildString {
        if (steering != null) {
            append(steering.focusQuestion).append(' ')
            append(steering.variables.joinToString(" ")).append(' ')
            append(steering.requiredTerms.joinToString(" ")).append(' ')
            append(steering.inferredAxes.joinToString(" ")).append(' ')
        }
        leadObjects.forEach { lead ->
            append(lead.title).append(' ').append(lead.snippet).append(' ')
            append(lead.detectedAccessions.joinToString(" ")).append(' ')
            append(lead.dataAvailabilityText).append(' ').append(lead.organism).append(' ')
            append(lead.omicsType).append(' ').append(lead.domain).append(' ')
        }
        candidates.forEach { candidate ->
            append(candidate.accession).append(' ').append(candidate.sourceTitle).append(' ')
            append(candidate.organismHint).append(' ').append(candidate.conditionLabelsHint).append(' ')
            append(candidate.outcomeLabelsHint).append(' ').append(candidate.triggerResponseOutcomeHint).append(' ')
            append(candidate.timeCourseHint).append(' ').append(candidate.dataType).append(' ')
            append(candidate.status).append(' ').append(candidate.reasons.joinToString(" ")).append(' ')
        }
        parsedMetadata.forEach { metadata ->
            append(metadata.accession).append(' ').append(metadata.organism).append(' ')
            append(metadata.conditionLabels.joinToString(" ")).append(' ')
            append(metadata.outcomeLabels.joinToString(" ")).append(' ')
            append(metadata.controlLabels.joinToString(" ")).append(' ')
            append(metadata.timeCourseLabels.joinToString(" ")).append(' ')
            append(metadata.tissueOrSource).append(' ').append(metadata.assayType).append(' ')
        }
        attempts.forEach { attempt -> append(attempt.query).append(' ').append(attempt.status).append(' ') }
        append(topicFit.preferredLane).append(' ').append(topicFit.contextSeeds.joinToString(" ")).append(' ')
        append(topicFit.exploratoryLinkQueries.joinToString(" ")).append(' ')
        append(metadataClosure.state).append(' ').append(metadataClosure.missingFields.joinToString(" ")).append(' ')
        append(recentReports.take(4).joinToString(" ").take(8_000))
    }

    private fun detectTargets(text: String): List<String> = targetTerms.mapNotNull { (id, terms) ->
        if (terms.any { text.contains(it) }) id else null
    }.distinct()

    private fun weakOrOffRouteSignal(
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        attempts: List<DatasetSourceAttempt>,
        topicFit: TopicFitMetadataParseReport,
        metadataClosure: MetadataClosureReport
    ): Boolean = leadObjects.isNotEmpty() ||
        candidates.any { candidate ->
            candidate.status.contains("WEAK", true) ||
                candidate.status.contains("OFF_ROUTE", true) ||
                candidate.status.contains("LEAD_ONLY", true) ||
                candidate.usabilityScore <= 35
        } ||
        attempts.any { it.status.contains("WEAK", true) || it.status.contains("NO_USABLE_METADATA", true) || it.status.contains("EXPLORATORY", true) } ||
        topicFit.state.contains("MINIMUM_METADATA", true) ||
        metadataClosure.state.contains("INCOMPLETE", true) ||
        metadataClosure.state.contains("SECONDARY_LOOKUP", true)

    private fun routeFitBoost(targets: List<String>, hasTranscriptomeOrAccession: Boolean, weakOrOffRoute: Boolean, topicFit: TopicFitMetadataParseReport): Int {
        var score = 0
        if (targets.isNotEmpty()) score += 25
        if (hasTranscriptomeOrAccession) score += 25
        if (weakOrOffRoute) score += 20
        if (topicFit.preferredLane.contains("RNA_TRANSCRIPTOMIC", true)) score += 15
        if (targets.any { it in setOf("EBV", "HHV-6", "CMV", "SARS-CoV-2_LONG_COVID") }) score += 10
        if (targets.any { it in setOf("SLE", "MS", "ME_CFS", "RA") }) score += 10
        return score.coerceIn(0, 95)
    }

    private fun buildHypotheses(targets: List<String>, text: String): List<MetadataClosureDiscoveryHypothesisV11056> {
        val selected = mutableListOf<MetadataClosureDiscoveryHypothesisV11056>()
        if (targets.any { it in setOf("EBV", "HHV-6", "CMV", "SARS-CoV-2_LONG_COVID") } || containsAny(text, listOf("reactivation", "latency", "latent"))) {
            selected += MetadataClosureDiscoveryHypothesisV11056(
                hypothesisId = "HPA_SLEEP_LATENT_VIRUS_TRANSCRIPTOME_BRIDGE",
                label = "Stress/sleep/HPA context may stratify latent-virus immune transcriptional states",
                bridge = "HPA-axis or sleep-deprivation terms are linked only as exposure/context variables; EBV/HHV-6/CMV/SARS-CoV-2 terms force transcriptome accession lookup and contradiction search.",
                matchedTargets = targets.filter { it in setOf("EBV", "HHV-6", "CMV", "SARS-CoV-2_LONG_COVID", "CORTISOL_DHEA") },
                requiredMetadata = listOf("viral serostatus/reactivation marker", "cortisol/DHEA or sleep/stress measure", "time-course", "human cohort", "control/comparator"),
                falsifiers = listOf("no accession or data availability text", "no viral marker/serostatus", "no longitudinal or baseline field", "signal explained by batch/cell-composition shift")
            )
        }
        if (targets.any { it in setOf("SLE", "MS", "RA") } || targets.any { it in setOf("IFN_ALPHA_BETA", "IL6_TNF") }) {
            selected += MetadataClosureDiscoveryHypothesisV11056(
                hypothesisId = "AUTOIMMUNE_IFN_CYTOKINE_ERROR_BRIDGE",
                label = "Autoimmune flare datasets may expose interferon/cytokine immune-error signatures under stress or viral context",
                bridge = "SLE/MS/RA + IFN/IL-6/TNF vocabulary elevates route-fit for human transcriptome datasets but remains blocked until comparator and time-order fields close.",
                matchedTargets = targets.filter { it in setOf("SLE", "MS", "RA", "IFN_ALPHA_BETA", "IL6_TNF", "EBV", "CMV") },
                requiredMetadata = listOf("disease activity/status labels", "therapy exposure field", "cytokine/interferon signature", "matched control", "time order"),
                falsifiers = listOf("no disease activity labels", "no healthy/matched comparator", "treatment exposure is confounded", "null/failed-replication result dominates")
            )
        }
        if (targets.contains("ME_CFS") || targets.contains("SARS-CoV-2_LONG_COVID") || containsAny(text, listOf("fatigue", "mitochondrial", "post-viral"))) {
            selected += MetadataClosureDiscoveryHypothesisV11056(
                hypothesisId = "LONG_COVID_ME_CFS_POST_VIRAL_IMMUNE_ERROR",
                label = "Long-COVID / ME-CFS transcriptome leads need post-viral, fatigue, cytokine, and control metadata closure",
                bridge = "Post-viral fatigue vocabulary triggers accession-first mining across PubMed/GEO/SRA and blocks broad narrative reuse until cohort, outcome, and control labels are present.",
                matchedTargets = targets.filter { it in setOf("SARS-CoV-2_LONG_COVID", "ME_CFS", "IL6_TNF", "IFN_ALPHA_BETA") },
                requiredMetadata = listOf("post-viral timing", "fatigue/outcome phenotype", "controls", "blood/tissue/cell source", "longitudinal follow-up"),
                falsifiers = listOf("no post-viral timing", "no outcome contrast", "cross-sectional-only weak metadata", "no null-result/negative-control search")
            )
        }
        if (targets.any { it.endsWith("CONTROL") || it.endsWith("CONTEXT") }) {
            selected += MetadataClosureDiscoveryHypothesisV11056(
                hypothesisId = "MODULATOR_AS_CONTROL_VARIABLE_NOT_TREATMENT",
                label = "JAK/Rituximab/curcumin/ashwagandha/quercetin tokens are control or exposure variables only",
                bridge = "Modulators refine stratification and confounder search; they never create treatment advice, ranking, or dosing claims.",
                matchedTargets = targets.filter { it.endsWith("CONTROL") || it.endsWith("CONTEXT") },
                requiredMetadata = listOf("exposure/therapy field", "baseline", "treated vs untreated or placebo", "dose field only as metadata", "negative control"),
                falsifiers = listOf("no exposure field", "no untreated/placebo comparator", "marketing/non-dataset source", "claims imply dose or recommendation")
            )
        }
        return selected.ifEmpty {
            listOf(
                MetadataClosureDiscoveryHypothesisV11056(
                    hypothesisId = "GENERAL_METADATA_CLOSURE_BRIDGE",
                    label = "Weak transcriptome/accession lead requires minimum metadata closure before interpretation",
                    bridge = "No target-specific biology is inferred; the runtime must close accession, cohort, label, comparator, time, and availability fields.",
                    matchedTargets = targets,
                    requiredMetadata = LeadClosureHandoffPolicy.REQUIRED_METADATA_FIELDS,
                    falsifiers = listOf("no accession", "no human metadata", "no comparator", "no outcome/time labels")
                )
            )
        }.take(4)
    }

    private fun buildQueryStreams(targets: List<String>, text: String, preferredLane: String): List<MetadataClosureKeywordQueryStreamV11056> {
        val viruses = chooseTerms(targets, listOf("EBV", "HHV-6", "CMV", "SARS-CoV-2_LONG_COVID"), listOf("EBV", "HHV-6", "CMV", "SARS-CoV-2", "Long COVID"))
        val pathologies = chooseTerms(targets, listOf("SLE", "MS", "ME_CFS", "RA"), listOf("SLE", "multiple sclerosis", "ME/CFS", "rheumatoid arthritis"))
        val biomarkers = chooseTerms(targets, listOf("IFN_ALPHA_BETA", "IL6_TNF", "CORTISOL_DHEA"), listOf("type I interferon", "IL-6", "TNF-alpha", "cortisol", "DHEA"))
        val modulators = chooseTerms(targets, listOf("JAK_INHIBITOR_CONTROL", "RITUXIMAB_CONTROL", "CURCUMIN_NFKB_CONTEXT", "ASHWAGANDHA_HPA_CONTEXT", "QUERCETIN_CONTEXT"), listOf("JAK inhibitor", "rituximab", "curcumin", "ashwagandha", "quercetin"))
        val stress = if (containsAny(text, listOf("stress", "sleep", "hpa", "cortisol", "dhea", "circadian")) || preferredLane.contains("STRESS", true) || preferredLane.contains("SLEEP", true)) {
            listOf("stress", "sleep deprivation", "HPA axis", "cortisol", "DHEA")
        } else listOf("stress", "sleep", "HPA axis")
        val diseaseBlock = (pathologies + viruses).distinct().joinToString(" OR ").ifBlank { "SLE OR multiple sclerosis OR ME/CFS OR rheumatoid arthritis OR EBV OR CMV OR SARS-CoV-2" }
        val bioBlock = biomarkers.distinct().joinToString(" OR ").ifBlank { "type I interferon OR IL-6 OR TNF-alpha OR cortisol OR DHEA" }
        val stressBlock = stress.distinct().joinToString(" OR ")
        val modulatorBlock = modulators.distinct().joinToString(" OR ").ifBlank { "JAK inhibitor OR rituximab OR curcumin OR ashwagandha OR quercetin" }
        return listOf(
            MetadataClosureKeywordQueryStreamV11056(
                streamId = "PUBMED_FULL_TEXT_ACCESSION_DRILLDOWN",
                sourceFamily = "PUBMED_ACCESSION_MINING",
                query = "($diseaseBlock) AND ($stressBlock OR $bioBlock) AND (transcriptome OR RNA-seq OR gene expression OR single-cell OR scRNA-seq) AND (GSE OR GEO OR PRJNA OR SRA OR accession OR data availability)",
                purpose = "Find papers whose snippets carry target/pathology text plus transcriptome/accession vocabulary.",
                requiredTokens = listOf("target/pathology", "transcriptome/RNA-seq", "GSE/GEO/PRJNA/SRA/accession")
            ),
            MetadataClosureKeywordQueryStreamV11056(
                streamId = "GEO_HUMAN_LONGITUDINAL_TRANSCRIPTOME",
                sourceFamily = "GEO_GDS",
                query = "human ($diseaseBlock) ($stressBlock) transcriptome longitudinal control sample metadata phenotype labels",
                purpose = "Search GEO/GDS for human longitudinal transcriptome records with phenotype/control labels.",
                requiredTokens = listOf("human", "longitudinal", "control", "sample metadata")
            ),
            MetadataClosureKeywordQueryStreamV11056(
                streamId = "SRA_BIOPROJECT_RNA_SEQ_METADATA",
                sourceFamily = "SRA_BIOPROJECT",
                query = "human RNA-seq ($diseaseBlock) ($bioBlock) BioProject PRJNA SRP SRA sample metadata case control longitudinal",
                purpose = "Search SRA/BioProject for RNA-seq metadata handles and serial/case-control structure.",
                requiredTokens = listOf("RNA-seq", "BioProject/PRJNA/SRP", "case/control", "metadata")
            ),
            MetadataClosureKeywordQueryStreamV11056(
                streamId = "IMMPORT_LONGITUDINAL_CYTOKINE_CONTROL",
                sourceFamily = "IMM_PORT_SDY",
                query = "SDY ImmPort human ($diseaseBlock) ($bioBlock) cytokine longitudinal control intervention baseline follow-up",
                purpose = "Look for ImmPort-style study handles when cytokine/HPA/therapy metadata is needed.",
                requiredTokens = listOf("SDY", "cytokine", "baseline/follow-up", "control")
            ),
            MetadataClosureKeywordQueryStreamV11056(
                streamId = "MODULATOR_CONTROL_CONFOUNDER_STREAM",
                sourceFamily = "PUBMED_CONTRADICTION",
                query = "($modulatorBlock) AND ($diseaseBlock) AND (transcriptome OR cytokine OR immune response) AND (placebo OR untreated OR matched control OR responder OR non-responder) AND (GSE OR accession OR supplementary data)",
                purpose = "Treat modulators as exposure/control/confounder metadata, not as recommendations.",
                requiredTokens = listOf("modulator", "control/placebo/untreated", "accession or supplementary data")
            ),
            MetadataClosureKeywordQueryStreamV11056(
                streamId = "CONTRADICTION_NULL_RESULT_STREAM",
                sourceFamily = "PUBMED_CONTRADICTION",
                query = "($diseaseBlock) AND ($stressBlock OR $bioBlock) AND (no association OR null result OR failed replication OR batch effect OR cell composition) AND (transcriptome OR RNA-seq OR gene expression)",
                purpose = "Force contradiction and artifact search before any hypothesis strengthening.",
                requiredTokens = listOf("no association/null/failed replication", "artifact", "transcriptome")
            )
        )
    }

    private fun buildMinimumMetadataProbes(
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        attempts: List<DatasetSourceAttempt>,
        targets: List<String>,
        routeFitBoost: Int,
        drillDownForced: Boolean
    ): List<MetadataClosureMinimumProbeV11056> {
        val leadProbes = leadObjects.take(3).mapIndexed { index, lead ->
            MetadataClosureMinimumProbeV11056(
                probeId = "MMP_LEAD_${index + 1}_${safeId(lead.leadId)}",
                sourceId = lead.detectedAccessions.firstOrNull() ?: lead.leadId,
                sourceFamily = lead.sourceFamily,
                originalStatus = "LEAD_ONLY_NOT_EVIDENCE",
                routeFitBoost = routeFitBoost,
                reason = "Lead object overlaps strategy matrix targets=${targets.joinToString(",").ifBlank { "none" }}; force accession/sample/label/control/time/data-availability probe.",
                requiredMetadataFields = LeadClosureHandoffPolicy.REQUIRED_METADATA_FIELDS,
                drillDownForced = drillDownForced,
                allowedRuntimeAction = "MINIMUM_METADATA_PROBE_THEN_CONTRADICTION_SEARCH",
                blockedRuntimeActions = listOf("FAIL", "NOT_RUN", "HYPOTHESIS_UPGRADE", "TREATMENT_OR_DOSING_CLAIM")
            )
        }
        val candidateProbes = candidates
            .filter { candidate -> candidate.status.contains("WEAK", true) || candidate.status.contains("OFF_ROUTE", true) || candidate.status.contains("LEAD_ONLY", true) || candidate.usabilityScore <= 35 || drillDownForced }
            .take(4)
            .mapIndexed { index, candidate ->
                MetadataClosureMinimumProbeV11056(
                    probeId = "MMP_CANDIDATE_${index + 1}_${safeId(candidate.accession)}",
                    sourceId = candidate.accession.ifBlank { candidate.sourceFindingId },
                    sourceFamily = candidate.source,
                    originalStatus = candidate.status.ifBlank { "WEAK_DATASET_LEAD" },
                    routeFitBoost = routeFitBoost,
                    reason = "Candidate low usability/off-route status is converted into a metadata probe because target/transcriptome/accession terms are present or unresolved.",
                    requiredMetadataFields = LeadClosureHandoffPolicy.REQUIRED_METADATA_FIELDS,
                    drillDownForced = drillDownForced,
                    allowedRuntimeAction = "PARSE_MINIMUM_METADATA",
                    blockedRuntimeActions = listOf("FAIL", "NOT_RUN", "BROAD_NARRATIVE_SUMMARY", "CAUSAL_LANGUAGE")
                )
            }
        val attemptProbe = if (leadProbes.isEmpty() && candidateProbes.isEmpty() && attempts.any { it.idsFound > 0 || it.status.contains("NO_USABLE_METADATA", true) }) {
            val attempt = attempts.first { it.idsFound > 0 || it.status.contains("NO_USABLE_METADATA", true) }
            listOf(
                MetadataClosureMinimumProbeV11056(
                    probeId = "MMP_ATTEMPT_${safeId(attempt.sourceFamily)}",
                    sourceId = attempt.sourceFamily,
                    sourceFamily = attempt.sourceFamily,
                    originalStatus = attempt.status,
                    routeFitBoost = routeFitBoost,
                    reason = "Source attempt returned IDs or unusable metadata; runtime must probe accession-like fields instead of dropping to NOT_RUN.",
                    requiredMetadataFields = LeadClosureHandoffPolicy.REQUIRED_METADATA_FIELDS,
                    drillDownForced = drillDownForced,
                    allowedRuntimeAction = "SECONDARY_LOOKUP_FOR_ACCESSION_AND_SAMPLE_METADATA",
                    blockedRuntimeActions = listOf("FAIL", "NOT_RUN", "ARCHIVE_WITHOUT_REASON")
                )
            )
        } else emptyList()
        return (leadProbes + candidateProbes + attemptProbe).distinctBy { it.probeId }.take(6)
    }

    private fun buildLogicGates(targets: List<String>, hasTranscriptomeOrAccession: Boolean): List<MetadataClosureLogicGateV11056> = listOf(
        MetadataClosureLogicGateV11056(
            gateId = "G1_WEAK_OR_OFF_ROUTE_NEVER_FAIL",
            condition = "candidate.status in WEAK_DATASET_LEAD/OFF_ROUTE_USEFUL_DATASET/LEAD_ONLY_NOT_EVIDENCE or usability <= 35",
            action = "force MINIMUM_METADATA_PROBE; preserve lead in ledger; keep state active",
            blocksFailOrNotRun = true,
            blocksClaimUpgrade = true
        ),
        MetadataClosureLogicGateV11056(
            gateId = "G2_STRATEGY_MATRIX_ROUTE_FIT_BOOST",
            condition = "snippet contains target virus/pathology/biomarker/modulator plus transcriptome/accession token; targets=${targets.joinToString(",").ifBlank { "none" }}; transcriptomeOrAccession=$hasTranscriptomeOrAccession",
            action = "increase route-fit for evidence acquisition only and force full text-mining drill-down",
            blocksFailOrNotRun = true,
            blocksClaimUpgrade = true
        ),
        MetadataClosureLogicGateV11056(
            gateId = "G3_METADATA_CLOSURE_BEFORE_INTERPRETATION",
            condition = "missing any accession/human/sample/condition/outcome/control/time/tissue/access/data-availability field",
            action = "request exact metadata field closure; no broad narrative summary",
            blocksFailOrNotRun = true,
            blocksClaimUpgrade = true
        ),
        MetadataClosureLogicGateV11056(
            gateId = "G4_CONTRADICTION_REQUIRED",
            condition = "minimum metadata is present but contradiction/null-result/batch/cell-composition artifact search has not run",
            action = "run contradiction stream before EvidenceObject creation",
            blocksFailOrNotRun = false,
            blocksClaimUpgrade = true
        ),
        MetadataClosureLogicGateV11056(
            gateId = "G5_MODULATOR_AS_CONTROL_ONLY",
            condition = "JAK inhibitor, rituximab, curcumin, ashwagandha, or quercetin appears",
            action = "route as exposure/control/confounder metadata; block treatment/dose/advice language",
            blocksFailOrNotRun = false,
            blocksClaimUpgrade = true
        )
    )

    private fun nextAction(state: String, streams: List<MetadataClosureKeywordQueryStreamV11056>, probes: List<MetadataClosureMinimumProbeV11056>, metadataClosure: MetadataClosureReport): String {
        val firstQuery = streams.firstOrNull()?.query ?: "No query stream generated."
        val firstProbe = probes.firstOrNull()?.sourceId ?: "current weak/off-route lead"
        return when {
            state == "STRATEGY_MATRIX_FULL_TEXT_DRILLDOWN_FORCED" -> "Run full text-mining drill-down for $firstProbe using: $firstQuery"
            state == MINIMUM_METADATA_PROBE_STATE -> "Run Minimum Metadata Probe for $firstProbe; close ${metadataClosure.missingFields.take(4).joinToString("+").ifBlank { "accession+control+time+outcome" }} before contradiction search."
            state == "STRATEGY_MATRIX_ROUTE_FIT_ELEVATED" -> "Execute accession-first query stream; keep all claims gated: $firstQuery"
            else -> "Keep lead active, generate accession/source lookup, and do not return FAIL or NOT_RUN."
        }.take(420)
    }

    private fun chooseTerms(targets: List<String>, ids: List<String>, defaults: List<String>): List<String> {
        val selected = targets.filter { it in ids }.map { id ->
            when (id) {
                "SARS-CoV-2_LONG_COVID" -> "SARS-CoV-2 OR Long COVID"
                "ME_CFS" -> "ME/CFS"
                "IFN_ALPHA_BETA" -> "type I interferon"
                "IL6_TNF" -> "IL-6 OR TNF-alpha"
                "CORTISOL_DHEA" -> "cortisol OR DHEA"
                "JAK_INHIBITOR_CONTROL" -> "JAK inhibitor"
                "RITUXIMAB_CONTROL" -> "rituximab OR anti-CD20"
                "CURCUMIN_NFKB_CONTEXT" -> "curcumin OR NF-kB"
                "ASHWAGANDHA_HPA_CONTEXT" -> "ashwagandha"
                "QUERCETIN_CONTEXT" -> "quercetin"
                "MS" -> "multiple sclerosis"
                "RA" -> "rheumatoid arthritis"
                else -> id
            }
        }
        return selected.ifEmpty { defaults }.distinct().take(8)
    }

    private fun containsAny(text: String, terms: List<String>): Boolean = terms.any { text.contains(it.lowercase(Locale.US)) }
    private fun normalize(text: String): String = text.lowercase(Locale.US).replace('–', '-').replace('—', '-').replace('_', ' ')
    private fun safeId(text: String): String = text.ifBlank { "unknown" }.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').take(42).ifBlank { "unknown" }
}
