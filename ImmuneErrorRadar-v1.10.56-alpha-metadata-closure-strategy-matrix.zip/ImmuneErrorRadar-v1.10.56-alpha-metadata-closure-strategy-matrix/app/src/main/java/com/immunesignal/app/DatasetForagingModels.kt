package com.immunesignal.app

/**
 * v1.4.0: Dataset-first autonomous foraging models.
 *
 * These models are intentionally evidence-acquisition primitives, not new
 * biological axes. They make the APK show whether it actually attempted direct
 * dataset families instead of only writing another PubMed pivot.
 */
data class TestableHypothesisShard(
    val shardId: String,
    val label: String,
    val evidenceQuestion: String,
    val querySeeds: List<String>
)

data class DatasetSourceAttempt(
    val sourceFamily: String,
    val ncbiDb: String,
    val query: String,
    val attempted: Boolean,
    val idsFound: Int,
    val candidatesExtracted: Int,
    val status: String,
    val reason: String
)

data class DatasetForagingPass(
    val passId: String,
    val label: String,
    val status: String,
    val attempts: List<DatasetSourceAttempt>
)

/** v1.10.9: turns a no-candidate source attempt into a routable learning object. */
data class NoCandidateLearningRecord(
    val sourceFamily: String,
    val queryId: String,
    val status: String,
    val missing: String,
    val nextPreferredSource: String,
    val reason: String
)

/** v1.4.4: separates dataset route relevance from raw dataset usability. */
data class DatasetRouteFitAssessment(
    val accession: String,
    val datasetRoute: String,
    val targetRoute: String,
    val routeFitScore: Int,
    val status: String,
    val allowedUse: String,
    val blocksHypothesisUpgrade: Boolean,
    val reasons: List<String>
)

/** v1.4.4: transparent score separation to avoid misleading single-score reports. */
data class DatasetScoreSeparation(
    val datasetUsabilityScore: Int,
    val routeFitScore: Int,
    val hypothesisConfidenceScore: Int,
    val hypothesisUpgradeAllowed: Boolean,
    val scoreState: String,
    val summary: String,
    val reasons: List<String>
) {
    companion object {
        fun empty() = DatasetScoreSeparation(
            datasetUsabilityScore = 0,
            routeFitScore = 0,
            hypothesisConfidenceScore = 0,
            hypothesisUpgradeAllowed = false,
            scoreState = "NOT_EVALUATED",
            summary = "Score separation was not evaluated in this cycle.",
            reasons = emptyList()
        )
    }
}

data class DatasetForagingReport(
    val active: Boolean,
    val state: String,
    val evidenceMode: String,
    val sourceFamiliesAttempted: List<String>,
    val hypothesisShards: List<TestableHypothesisShard>,
    val passes: List<DatasetForagingPass>,
    val candidates: List<DatasetAccessionCandidate>,
    val parsedMetadata: List<ParsedDatasetMetadata> = emptyList(),
    val contrastiveReport: ContrastiveEvidenceReport = ContrastiveEvidenceReport.empty(),
    val evidenceHypergraph: List<EvidenceHypergraphNode> = emptyList(),
    val cumulativeEvidence: CumulativeEvidenceReport = CumulativeEvidenceReport.empty(),
    val routeFitAssessments: List<DatasetRouteFitAssessment> = emptyList(),
    val scoreSeparation: DatasetScoreSeparation = DatasetScoreSeparation.empty(),
    val triageReport: DatasetTriageReport = DatasetTriageReport.empty(),
    val candidateActionReport: CandidateActionReport = CandidateActionReport.empty(),
    val autoContinuationReport: AutoContinuationReport = AutoContinuationReport.empty(),
    val reportConsistencyGuard: ReportConsistencyGuardReport = ReportConsistencyGuardReport.empty(),
    val failurePatternReport: FailurePatternReport = FailurePatternReport.empty(),
    val queryFeedbackPlan: QueryFeedbackPlan = QueryFeedbackPlan.passthrough(emptyList(), "No query feedback evaluated."),
    val freshnessReport: FreshnessReport = FreshnessReport.empty(),
    val noCandidateLearningRecords: List<NoCandidateLearningRecord> = emptyList(),
    val creativeHypothesisForgeReport: CreativeHypothesisForgeReport = CreativeHypothesisForgeReport.empty(),
    val expandedThinkingReport: ExpandedThinkingWindowReport = ExpandedThinkingWindowReport.empty(),
    val accessionAcquisitionReport: AccessionAcquisitionReport = AccessionAcquisitionReport.empty(),
    val domainExpertiseReport: DomainExpertiseMemoryPolicy.DomainExpertiseReport = DomainExpertiseMemoryPolicy.DomainExpertiseReport.empty(),
    val matureDomainEvidenceProbeReport: MatureDomainEvidenceProbePolicy.Report = MatureDomainEvidenceProbePolicy.Report.empty(),
    val pathLinkageReport: DatasetForagingPathLinkageReport = DatasetForagingPathLinkageReport.empty(),
    val learningDomainPathLinkageReport: LearningDomainPathLinkageReport = LearningDomainPathLinkageReport.empty(),
    val manualEvidenceSeedReport: ManualEvidenceSeedReport = ManualEvidenceSeedReport.empty(),
    val datasetLeadRelaxationReport: DatasetLeadRelaxationReport = DatasetLeadRelaxationReport.empty(),
    val evidenceDiscoveryBreakthroughReport: EvidenceDiscoveryBreakthroughReport = EvidenceDiscoveryBreakthroughReport.empty(),
    val evidenceActivitySeparationReport: EvidenceActivitySeparationReport = EvidenceActivitySeparationReport.empty(),
    val onePageExecutiveEvidenceReport: OnePageExecutiveEvidenceReport = OnePageExecutiveEvidenceReport.empty(),
    val evidenceLeadPathLinkageReport: EvidenceLeadPathLinkageReport = EvidenceLeadPathLinkageReport.empty(),
    val leadObjects: List<LeadObject> = emptyList(),
    val matureDomainFocusReport: MatureDomainFocusReport = MatureDomainFocusReport.empty(),
    val domainSpecificKillCriteriaReport: DomainSpecificKillCriteriaReport = DomainSpecificKillCriteriaReport.empty(),
    val domainExpertiseScoreUpgradeReport: DomainExpertiseScoreUpgradeReport = DomainExpertiseScoreUpgradeReport.empty(),
    val knowledgeGapQueueReport: KnowledgeGapQueueReport = KnowledgeGapQueueReport.empty(),
    val strongRouteFingerprintReport: StrongRouteFingerprintReport = StrongRouteFingerprintReport.empty(),
    val leanAgentRuntimeReport: LeanAgentRuntimeReport = LeanAgentRuntimeReport.empty(),
    val learningValueScoreReport: LearningValueScoreReport = LearningValueScoreReport.empty(),
    val topicMemoryLedgerReport: TopicMemoryLedgerReport = TopicMemoryLedgerReport.empty(),
    val leadInspectionQueueReport: LeadInspectionQueueReport = LeadInspectionQueueReport.empty(),
    val usefulReportLayersReport: UsefulReportLayersReport = UsefulReportLayersReport.empty(),
    val researchProgressWithoutEvidenceReport: ResearchProgressWithoutEvidenceReport = ResearchProgressWithoutEvidenceReport.empty(),
    val leadClosureHandoffReport: LeadClosureHandoffReport = LeadClosureHandoffReport.empty(),
    val metadataClosureReport: MetadataClosureReport = MetadataClosureReport.empty(),
    val unknownRouteClassificationReport: UnknownRouteClassificationReport = UnknownRouteClassificationReport.empty(),
    val ebvLeadVerificationReport: EBVLeadVerificationReport = EBVLeadVerificationReport.empty(),
    val evidencePriorSelectionReport: EvidencePriorSelectionReport = EvidencePriorSelectionReport.empty(),
    val biomedicalOntologyReport: BiomedicalResearchOntologyReport = BiomedicalResearchOntologyReport.empty(),
    val biomedicalConceptBridgeReport: BiomedicalConceptBridgeReport = BiomedicalConceptBridgeReport.empty(),
    val modernMedicalTechnologyReport: ModernMedicalTechnologyReport = ModernMedicalTechnologyReport.empty(),
    val viralCountermeasureReport: ViralCountermeasureReport = ViralCountermeasureReport.empty(),
    val longevityBiologicalSystemsReport: LongevityBiologicalSystemsReport = LongevityBiologicalSystemsReport.empty(),
    val biomedicalKnowledgeGraphLinkageReport: BiomedicalKnowledgeGraphLinkageReport = BiomedicalKnowledgeGraphLinkageReport.empty(),
    val topicFitMetadataParseReport: TopicFitMetadataParseReport = TopicFitMetadataParseReport.empty(),
    val metadataClosureStrategyMatrixReport: MetadataClosureStrategyMatrixReport = MetadataClosureStrategyMatrixReport.empty(),
    val integratedPathLinkageReport: IntegratedPathLinkageReport = IntegratedPathLinkageReport.empty(),
    val blockedLearningReason: String,
    val nextAction: String
) {
    companion object {
        fun empty() = DatasetForagingReport(
            active = false,
            state = "NOT_RUN",
            evidenceMode = "PUBMED_METADATA_ONLY",
            sourceFamiliesAttempted = emptyList(),
            hypothesisShards = emptyList(),
            passes = emptyList(),
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            contrastiveReport = ContrastiveEvidenceReport.empty(),
            evidenceHypergraph = emptyList(),
            cumulativeEvidence = CumulativeEvidenceReport.empty(),
            routeFitAssessments = emptyList(),
            scoreSeparation = DatasetScoreSeparation.empty(),
            triageReport = DatasetTriageReport.empty(),
            candidateActionReport = CandidateActionReport.empty(),
            autoContinuationReport = AutoContinuationReport.empty(),
            reportConsistencyGuard = ReportConsistencyGuardReport.empty(),
            failurePatternReport = FailurePatternReport.empty(),
            queryFeedbackPlan = QueryFeedbackPlan.passthrough(emptyList(), "No query feedback evaluated."),
            freshnessReport = FreshnessReport.empty(),
            noCandidateLearningRecords = emptyList(),
            creativeHypothesisForgeReport = CreativeHypothesisForgeReport.empty(),
            expandedThinkingReport = ExpandedThinkingWindowReport.empty(),
            accessionAcquisitionReport = AccessionAcquisitionReport.empty(),
            domainExpertiseReport = DomainExpertiseMemoryPolicy.DomainExpertiseReport.empty(),
            matureDomainEvidenceProbeReport = MatureDomainEvidenceProbePolicy.Report.empty(),
            pathLinkageReport = DatasetForagingPathLinkageReport.empty(),
            learningDomainPathLinkageReport = LearningDomainPathLinkageReport.empty(),
            manualEvidenceSeedReport = ManualEvidenceSeedReport.empty(),
            datasetLeadRelaxationReport = DatasetLeadRelaxationReport.empty(),
            evidenceDiscoveryBreakthroughReport = EvidenceDiscoveryBreakthroughReport.empty(),
            evidenceActivitySeparationReport = EvidenceActivitySeparationReport.empty(),
            onePageExecutiveEvidenceReport = OnePageExecutiveEvidenceReport.empty(),
            evidenceLeadPathLinkageReport = EvidenceLeadPathLinkageReport.empty(),
            leadObjects = emptyList(),
            matureDomainFocusReport = MatureDomainFocusReport.empty(),
            domainSpecificKillCriteriaReport = DomainSpecificKillCriteriaReport.empty(),
            domainExpertiseScoreUpgradeReport = DomainExpertiseScoreUpgradeReport.empty(),
            knowledgeGapQueueReport = KnowledgeGapQueueReport.empty(),
            strongRouteFingerprintReport = StrongRouteFingerprintReport.empty(),
            leanAgentRuntimeReport = LeanAgentRuntimeReport.empty(),
            learningValueScoreReport = LearningValueScoreReport.empty(),
            topicMemoryLedgerReport = TopicMemoryLedgerReport.empty(),
            leadInspectionQueueReport = LeadInspectionQueueReport.empty(),
            usefulReportLayersReport = UsefulReportLayersReport.empty(),
            researchProgressWithoutEvidenceReport = ResearchProgressWithoutEvidenceReport.empty(),
            leadClosureHandoffReport = LeadClosureHandoffReport.empty(),
            metadataClosureReport = MetadataClosureReport.empty(),
            unknownRouteClassificationReport = UnknownRouteClassificationReport.empty(),
            ebvLeadVerificationReport = EBVLeadVerificationReport.empty(),
            evidencePriorSelectionReport = EvidencePriorSelectionReport.empty(),
            biomedicalOntologyReport = BiomedicalResearchOntologyReport.empty(),
            biomedicalConceptBridgeReport = BiomedicalConceptBridgeReport.empty(),
            modernMedicalTechnologyReport = ModernMedicalTechnologyReport.empty(),
            viralCountermeasureReport = ViralCountermeasureReport.empty(),
            longevityBiologicalSystemsReport = LongevityBiologicalSystemsReport.empty(),
            biomedicalKnowledgeGraphLinkageReport = BiomedicalKnowledgeGraphLinkageReport.empty(),
            topicFitMetadataParseReport = TopicFitMetadataParseReport.empty(),
            metadataClosureStrategyMatrixReport = MetadataClosureStrategyMatrixReport.empty(),
            integratedPathLinkageReport = IntegratedPathLinkageReport.empty(),
            blockedLearningReason = "Dataset-first forager did not run in this cycle.",
            nextAction = "Run an autonomous research cycle."
        )
    }
}
