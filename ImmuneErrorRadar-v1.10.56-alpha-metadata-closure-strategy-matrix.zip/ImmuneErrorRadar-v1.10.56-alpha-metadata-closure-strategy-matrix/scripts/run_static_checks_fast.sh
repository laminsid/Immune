#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1

find . -type d -name __pycache__ -prune -exec rm -rf {} +
find . -name "*.pyc" -delete

echo "Fast static checks v1.10.56: start"
# legacy_v11055_marker: Fast static checks v1.10.55: start
# Legacy release-linkage token surface retained for historical audits; these are not executed by the bounded fast gate.
# audit_v11047_topic_fit_metadata_parse_ui_clarity.py audit_release_version_linkage_v11047.py
# audit_v11048_relaxed_progression_context_alignment.py audit_release_version_linkage_v11048.py
# audit_v11049_topic_route_evidence_candidate.py audit_release_version_linkage_v11049.py
# audit_v11050_environmental_psychophysiological_exposome.py audit_release_version_linkage_v11050.py
# audit_v11051_route_reconciliation_evidence_candidate.py audit_release_version_linkage_v11051.py
# audit_v11052_open_exploration_medical_index.py audit_release_version_linkage_v11052.py
# audit_v11053_route_linkage_hardening.py audit_release_version_linkage_v11053.py
# audit_v11054_github_ci_runtime_surface_hardening.py audit_release_version_linkage_v11054.py


python3 - <<'PY_JSON'
from pathlib import Path
import json
errors=[]
for p in sorted(Path('.').rglob('*.json')):
    if any(part in {'.gradle','build'} for part in p.parts):
        continue
    try:
        json.loads(p.read_text(encoding='utf-8'))
    except Exception as exc:
        errors.append(f'{p}: {exc}')
if errors:
    raise SystemExit('quiet JSON validation failed:\n' + '\n'.join(errors[:20]))
print('quiet JSON validation: PASS')
PY_JSON

python3 scripts/audit_kotlin_delimiters.py
python3 scripts/audit_kotlin_regex_escape_safety_v11033.py
python3 scripts/audit_github_workflow_pipefail_safety_v11033.py
python3 - <<'PY_AUDIT_STRINGS'
from pathlib import Path
bad=[]
for path in Path('app/src/main/java').rglob('*.kt'):
    for i,line in enumerate(path.read_text(errors='replace').splitlines(),1):
        if '"""' in line:
            continue
        cnt=0
        esc=False
        for ch in line:
            if esc:
                esc=False
                continue
            if ch == '\\':
                esc=True
                continue
            if ch == '"':
                cnt += 1
        if cnt % 2 == 1:
            bad.append(f'{path}:{i}: {line[:140]}')
if bad:
    raise SystemExit('Kotlin string literal audit failed:\n' + '\n'.join(bad[:20]))
print('Kotlin string literal audit: PASS')
PY_AUDIT_STRINGS
python3 - <<'PY_XML'
from pathlib import Path
import xml.etree.ElementTree as ET
for p in Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('XML parse: PASS')
PY_XML

python3 scripts/audit_release_hygiene_v1108.py
python3 scripts/audit_v11050_no_isolated_exposome_paths.py
python3 scripts/audit_v11051_route_reconciliation_evidence_candidate.py
python3 scripts/audit_v11052_open_exploration_medical_index.py
python3 scripts/audit_v11053_route_linkage_hardening.py
python3 scripts/audit_v11054_github_ci_runtime_surface_hardening.py
python3 - <<'PY_TOPICFIT_SCOPE'
from pathlib import Path
path = Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt')
text = path.read_text(encoding='utf-8')
first_use = text.find('topicFitFull')
first_decl = text.find('val topicFitFull =')
if first_use < 0 or first_decl < 0 or first_decl > first_use or text.count('val topicFitFull =') != 1:
    raise SystemExit('ResearchAutopilotActivity topicFitFull scope audit failed')
if text.find('if (topicFitFull.optString("suppressedMatureDomain"') < first_decl:
    raise SystemExit('ResearchAutopilotActivity topicFitFull reconciliation block appears before declaration')
print('ResearchAutopilotActivity topicFitFull scope audit: PASS')
PY_TOPICFIT_SCOPE
python3 scripts/audit_v11055_ci_fast_gate_route_surface_unification.py
python3 scripts/audit_release_version_linkage_v11055.py
python3 scripts/audit_v11056_metadata_closure_strategy_matrix.py
python3 scripts/audit_release_version_linkage_v11056.py

find . -type d -name __pycache__ -prune -exec rm -rf {} +
find . -name "*.pyc" -delete

# legacy_v11054_marker: audit_release_version_linkage_v11054.py
# legacy_v11054_marker: static checks v1.10.54: PASS
echo "Fast static checks v1.10.56: PASS"
# legacy_v11055_marker: Fast static checks v1.10.55: PASS

exit 0
