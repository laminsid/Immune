package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.8.2 — Concrete observed-file and sample-metadata execution modules for actual ETL readiness. */
data class GTIMObservedRepositoryFileV2802(
    val fileName: String,
    val sourceUrl: String,
    val sizeBytes: Long,
    val checksumOrEtag: String,
    val downloadTimestamp: String,
    val parserHint: String
)

data class GTIMSupplementaryFileDiscoveryReportV2802(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val observedFiles: List<GTIMObservedRepositoryFileV2802>,
    val supplementaryTypes: List<String>,
    val line: String,
    val boundaryLine: String
)

data class GTIMMatrixFileClassificationReportV2802(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val matrixFileTypes: List<String>,
    val parserPlan: List<String>,
    val line: String,
    val boundaryLine: String
)

data class GTIMSampleMetadataRowV2802(
    val sampleId: String,
    val sourceField: String,
    val evidenceSnippet: String,
    val rawText: String
)

data class GTIMSampleMetadataExtractionReportV2802(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val rows: List<GTIMSampleMetadataRowV2802>,
    val extractedFields: List<String>,
    val line: String,
    val boundaryLine: String
)

data class GTIMCaseControlLabelSuggestionV2802(
    val sampleId: String,
    val suggestedLabel: String,
    val confidence: Int,
    val sourceField: String,
    val evidenceSnippet: String
)

data class GTIMCaseControlLabelSuggestionReportV2802(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val suggestions: List<GTIMCaseControlLabelSuggestionV2802>,
    val caseCount: Int,
    val controlCount: Int,
    val line: String,
    val boundaryLine: String
)

data class GTIMSampleIdLinkageVerificationReportV2802(
    val active: Boolean,
    val targetId: String,
    val state: String,
    val metadataSampleCount: Int,
    val matrixSampleCount: Int,
    val matchedSampleCount: Int,
    val missingFromMatrix: List<String>,
    val missingFromMetadata: List<String>,
    val line: String,
    val boundaryLine: String
)

data class GTIMDgeReadinessVerdictReportV2802(
    val active: Boolean,
    val targetId: String,
    val verdict: String,
    val blockers: List<String>,
    val line: String,
    val boundaryLine: String
)

object GTIMSupplementaryFileDiscoveryV2802 {
    const val VERSION: String = "2.8.2-supplementary-file-discovery"

    fun build(
        fileDiscovery: GTIMRepositoryFileDiscoveryReportV2800,
        report: JSONObject? = null
    ): GTIMSupplementaryFileDiscoveryReportV2802 {
        if (fileDiscovery.state == "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET") {
            return emit(
                target = fileDiscovery.targetId,
                state = "SUPPLEMENTARY_DISCOVERY_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET",
                observedFiles = emptyList(),
                types = emptyList(),
                line = "Supplementary file discovery: version=$VERSION | state=SUPPLEMENTARY_DISCOVERY_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | target=${fileDiscovery.targetId} | observed_files=0 | file_types=none | topic_compatible_target_required=true"
            )
        }
        val observed = observedFiles(report).filter { it.fileName.isNotBlank() }
        val types = observed.map { classifyFileType(it.fileName, it.parserHint) }.distinct()
        val state = if (observed.isNotEmpty()) "SUPPLEMENTARY_FILES_OBSERVED_REVIEW_ONLY" else "SUPPLEMENTARY_FILE_DISCOVERY_REQUIRED"
        val line = if (observed.isNotEmpty()) {
            "Supplementary file discovery: version=$VERSION | state=$state | target=${fileDiscovery.targetId} | observed_files=${observed.size} | file_types=${types.joinToString(",")} | require_size_checksum_parser_hint=true"
        } else {
            "Supplementary file discovery: version=$VERSION | state=$state | target=${fileDiscovery.targetId} | observed_files=0 | planned_signatures=${fileDiscovery.candidateFileTypes.take(8).joinToString(",")} | no_file_claim_until_observed=true"
        }
        return emit(fileDiscovery.targetId, state, observed, types, line)
    }

    fun observedFiles(report: JSONObject?): List<GTIMObservedRepositoryFileV2802> {
        if (report == null) return emptyList()
        val arrays = listOfNotNull(
            report.optJSONArray("observedRepositoryFiles"),
            report.optJSONObject("actualEtlExecution")?.optJSONArray("observedRepositoryFiles"),
            report.optJSONObject("gtimActualEtl")?.optJSONArray("observedRepositoryFiles"),
            report.optJSONObject("mechanismDiscoveryDossierReport")?.optJSONArray("observedRepositoryFiles")
        )
        val out = mutableListOf<GTIMObservedRepositoryFileV2802>()
        for (array in arrays) {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val name = firstNonBlank(obj.optString("fileName"), obj.optString("file_name"), obj.optString("name"))
                val source = firstNonBlank(obj.optString("sourceUrl"), obj.optString("source_url"), obj.optString("url"))
                val checksum = firstNonBlank(obj.optString("checksumOrEtag"), obj.optString("checksum_or_etag"), obj.optString("etag"), obj.optString("sha256"))
                val stamp = firstNonBlank(obj.optString("downloadTimestamp"), obj.optString("download_timestamp"), obj.optString("observedAt"), "not_supplied")
                val hint = firstNonBlank(obj.optString("parserHint"), obj.optString("parser_hint"), obj.optString("type"), classifyFileType(name, ""))
                val size = when {
                    obj.has("sizeBytes") -> obj.optLong("sizeBytes", 0L)
                    obj.has("size_bytes") -> obj.optLong("size_bytes", 0L)
                    else -> 0L
                }
                if (name.isNotBlank()) {
                    out += GTIMObservedRepositoryFileV2802(name, source, size, checksum, stamp, hint)
                }
            }
        }
        return out.distinctBy { it.fileName.lowercase() + "|" + it.sourceUrl.lowercase() }
    }

    fun classifyFileType(fileName: String, parserHint: String): String {
        val text = "$fileName $parserHint".lowercase()
        return when {
            text.contains("matrix.mtx") || text.endsWith(".mtx") -> "MATRIX_MARKET_MTX"
            text.contains("barcodes.tsv") -> "CELL_BARCODES_TSV"
            text.contains("features.tsv") || text.contains("genes.tsv") -> "GENE_FEATURES_TSV"
            text.contains(".h5ad") -> "ANNDATA_H5AD"
            text.contains(".h5") || text.contains("hdf5") -> "HDF5_MATRIX"
            text.contains(".rds") || text.contains(".rdata") -> "R_OBJECT_MATRIX"
            text.contains("series_matrix") -> "GEO_SERIES_MATRIX"
            text.contains("count") && (text.endsWith(".tsv") || text.endsWith(".csv") || text.contains("tsv") || text.contains("csv")) -> "COUNT_TABLE"
            text.contains("expression") && (text.endsWith(".tsv") || text.endsWith(".csv") || text.contains("tsv") || text.contains("csv")) -> "EXPRESSION_TABLE"
            text.contains("metadata") || text.contains("sample") || text.contains("phenotype") || text.contains("pheno") -> "SAMPLE_METADATA_TABLE"
            text.endsWith(".fastq") || text.contains("fastq") -> "RAW_SEQUENCE_FASTQ"
            text.endsWith(".bam") || text.contains("bam") -> "ALIGNED_READS_BAM"
            text.endsWith(".zip") || text.endsWith(".tar") || text.endsWith(".gz") -> "ARCHIVE_CONTAINER"
            else -> "SUPPLEMENTARY_FILE_OTHER"
        }
    }

    private fun emit(target: String, state: String, observedFiles: List<GTIMObservedRepositoryFileV2802>, types: List<String>, line: String) =
        GTIMSupplementaryFileDiscoveryReportV2802(
            active = true,
            targetId = target,
            state = state,
            observedFiles = observedFiles,
            supplementaryTypes = types,
            line = normalize(line),
            boundaryLine = "Supplementary discovery boundary: planned signatures are not files; only observed public repository files with name/source/size/checksum/parser hint can advance matrix parsing."
        )

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""
    private fun normalize(value: String): String = value.replace(Regex("\\s+"), " ").trim()
}

object GTIMMatrixFileClassifierV2802 {
    const val VERSION: String = "2.8.2-matrix-file-classifier"

    fun build(supplementary: GTIMSupplementaryFileDiscoveryReportV2802): GTIMMatrixFileClassificationReportV2802 {
        if (supplementary.state.contains("BLOCKED_NO_TOPIC", true)) {
            return emit(supplementary.targetId, "MATRIX_CLASSIFICATION_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", emptyList(), emptyList(), "Matrix file classifier: version=$VERSION | state=MATRIX_CLASSIFICATION_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | target=${supplementary.targetId} | matrix_files=none")
        }
        val matrixTypes = supplementary.supplementaryTypes.filter { type ->
            type.contains("MATRIX") || type == "COUNT_TABLE" || type == "EXPRESSION_TABLE" || type == "ANNDATA_H5AD" || type == "HDF5_MATRIX" || type == "R_OBJECT_MATRIX"
        }.distinct()
        val parserPlan = matrixTypes.map { type ->
            when (type) {
                "MATRIX_MARKET_MTX" -> "parse_mtx_with_barcodes_features"
                "ANNDATA_H5AD", "HDF5_MATRIX" -> "parse_h5_or_h5ad_matrix"
                "R_OBJECT_MATRIX" -> "parse_rds_review_only"
                "GEO_SERIES_MATRIX" -> "parse_geo_series_matrix"
                "COUNT_TABLE" -> "parse_count_table"
                "EXPRESSION_TABLE" -> "parse_expression_table"
                else -> "manual_parser_review"
            }
        }.distinct()
        val state = if (matrixTypes.isNotEmpty()) "MATRIX_FILE_CLASSIFIED_REVIEW_ONLY" else "MATRIX_FILE_CLASSIFICATION_PENDING_OBSERVED_FILE"
        val line = "Matrix file classifier: version=$VERSION | state=$state | target=${supplementary.targetId} | matrix_file_types=${matrixTypes.ifEmpty { listOf("none") }.joinToString(",")} | parser_plan=${parserPlan.ifEmpty { listOf("pending_observed_matrix_file") }.joinToString(",")} | review_only=true"
        return emit(supplementary.targetId, state, matrixTypes, parserPlan, line)
    }

    private fun emit(target: String, state: String, types: List<String>, plan: List<String>, line: String) =
        GTIMMatrixFileClassificationReportV2802(
            active = true,
            targetId = target,
            state = state,
            matrixFileTypes = types,
            parserPlan = plan,
            line = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Matrix classification boundary: classifies observed file types only; does not read values or claim expression signal."
        )
}

object GTIMSampleMetadataExtractorV2802 {
    const val VERSION: String = "2.8.2-sample-metadata-extractor"
    private val FIELD_KEYS = listOf("sample_id", "title", "source_name", "characteristics", "disease", "tissue", "cell_type", "treatment", "severity", "timepoint", "case_control", "response")

    fun build(targetId: String, report: JSONObject?, cleaner: GTIMMetadataCleanerReportV2800): GTIMSampleMetadataExtractionReportV2802 {
        if (cleaner.state.contains("BLOCKED_NO_TOPIC", true)) {
            return emit(targetId, "SAMPLE_METADATA_EXTRACTION_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", emptyList(), emptyList(), "Sample metadata extractor: version=$VERSION | state=SAMPLE_METADATA_EXTRACTION_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | target=$targetId | rows=0 | fields=none")
        }
        val rows = metadataRows(report)
        val fields = if (rows.isNotEmpty()) FIELD_KEYS.filter { key -> rows.any { row -> row.rawText.contains(key, true) || row.sourceField.contains(key, true) } }.ifEmpty { listOf("sample_id", "evidence_text") } else cleaner.normalizedFields
        val state = if (rows.isNotEmpty()) "SAMPLE_METADATA_EXTRACTED_REVIEW_ONLY" else "SAMPLE_METADATA_EXTRACTION_REQUIRED"
        val line = "Sample metadata extractor: version=$VERSION | state=$state | target=$targetId | rows=${rows.size} | fields=${fields.take(10).joinToString(",")} | evidence_snippet_required=true"
        return emit(targetId, state, rows, fields, line)
    }

    fun metadataRows(report: JSONObject?): List<GTIMSampleMetadataRowV2802> {
        if (report == null) return emptyList()
        val arrays = listOfNotNull(
            report.optJSONArray("sampleMetadataRows"),
            report.optJSONObject("actualEtlExecution")?.optJSONArray("sampleMetadataRows"),
            report.optJSONObject("gtimActualEtl")?.optJSONArray("sampleMetadataRows"),
            report.optJSONObject("mechanismDiscoveryDossierReport")?.optJSONArray("sampleMetadataRows")
        )
        val out = mutableListOf<GTIMSampleMetadataRowV2802>()
        for (array in arrays) {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val sample = firstNonBlank(obj.optString("sampleId"), obj.optString("sample_id"), obj.optString("gsm"), obj.optString("id"))
                val sourceField = firstNonBlank(obj.optString("sourceField"), obj.optString("source_field"), obj.optString("field"), "metadata_row")
                val evidence = firstNonBlank(obj.optString("evidenceSnippet"), obj.optString("evidence_snippet"), obj.optString("evidence"), obj.optString("text"))
                val raw = obj.keys().asSequence().joinToString(" ") { key -> "$key=${obj.optString(key)}" }.ifBlank { evidence }
                if (sample.isNotBlank() || evidence.isNotBlank()) {
                    out += GTIMSampleMetadataRowV2802(sample.ifBlank { "sample_${out.size + 1}" }, sourceField, evidence.ifBlank { raw.take(180) }, raw)
                }
            }
        }
        return out.distinctBy { it.sampleId.lowercase() }
    }

    private fun emit(target: String, state: String, rows: List<GTIMSampleMetadataRowV2802>, fields: List<String>, line: String) =
        GTIMSampleMetadataExtractionReportV2802(
            active = true,
            targetId = target,
            state = state,
            rows = rows,
            extractedFields = fields,
            line = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Sample metadata boundary: extracted labels remain review-only and require source fields plus evidence snippets."
        )

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""
}

object GTIMCaseControlLabelSuggesterV2802 {
    const val VERSION: String = "2.8.2-case-control-label-suggester"

    fun build(metadata: GTIMSampleMetadataExtractionReportV2802): GTIMCaseControlLabelSuggestionReportV2802 {
        if (metadata.state.contains("BLOCKED_NO_TOPIC", true)) {
            return emit(metadata.targetId, "CASE_CONTROL_LABELING_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", emptyList(), "Case/control label suggester: version=$VERSION | state=CASE_CONTROL_LABELING_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | target=${metadata.targetId} | suggestions=0")
        }
        val suggestions = metadata.rows.mapNotNull { row -> suggest(row) }
        val caseCount = suggestions.count { it.suggestedLabel.contains("case") || it.suggestedLabel.contains("disease") || it.suggestedLabel.contains("severe") || it.suggestedLabel.contains("responder") || it.suggestedLabel == "treated" }
        val controlCount = suggestions.count { it.suggestedLabel.contains("control") || it.suggestedLabel == "baseline" || it.suggestedLabel == "untreated" }
        val state = when {
            metadata.rows.isEmpty() -> "CASE_CONTROL_LABELING_PENDING_METADATA_EXTRACTION"
            caseCount > 0 && controlCount > 0 -> "CASE_CONTROL_LABELS_SUGGESTED_WITH_EVIDENCE"
            suggestions.isNotEmpty() -> "CASE_CONTROL_LABELS_PARTIAL_REVIEW_REQUIRED"
            else -> "CASE_CONTROL_LABELS_NOT_INFERRED"
        }
        val preview = suggestions.take(3).joinToString(";") { "${it.sampleId}:${it.suggestedLabel}@${it.confidence} source_field=${it.sourceField} evidence_snippet=${it.evidenceSnippet.take(60)}" }
        val line = "Case/control label suggester: version=$VERSION | state=$state | target=${metadata.targetId} | suggestions=${suggestions.size} | case=$caseCount | control=$controlCount | preview=${preview.ifBlank { "none" }} | evidence_snippet_required=true"
        return emit(metadata.targetId, state, suggestions, line)
    }

    private fun suggest(row: GTIMSampleMetadataRowV2802): GTIMCaseControlLabelSuggestionV2802? {
        val text = (row.rawText + " " + row.evidenceSnippet).lowercase()
        val label = when {
            text.contains("healthy") || text.contains("normal control") || text.contains("control") || text.contains("ctrl") || text.contains("mock") || text.contains("normal donor") || text.contains("healthy donor") -> "healthy_control"
            text.contains("untreated") || text.contains("vehicle") || text.contains("no treatment") -> "untreated"
            text.contains("baseline") || text.contains("pre-treatment") || text.contains("pretreatment") || text.contains("pre treatment") -> "baseline"
            text.contains("recovered") || text.contains("convalescent") -> "recovered_control"
            text.contains("non-responder") || text.contains("nonresponder") || text.contains("non responder") -> "non_responder"
            text.contains("responder") -> "responder"
            text.contains("treated") || text.contains("therapy") || text.contains("vaccine") -> "treated"
            text.contains("severe") || text.contains("fatal") || text.contains("patient-group") || text.contains("patient group") || text.contains("patient") || text.contains("case") || text.contains("disease") || text.contains("covid") || text.contains("ebola") || text.contains("diabetes") || text.contains("cancer") || text.contains("tumor") || text.contains("allergy") || text.contains("hantavirus") || text.contains("hanta") -> "disease_case"
            else -> return null
        }
        val confidence = when (label) {
            "healthy_control" -> 82
            "disease_case" -> 74
            "treated", "untreated", "responder", "non_responder" -> 70
            else -> 66
        }
        return GTIMCaseControlLabelSuggestionV2802(row.sampleId, label, confidence, row.sourceField, row.evidenceSnippet.take(140))
    }

    private fun emit(target: String, state: String, suggestions: List<GTIMCaseControlLabelSuggestionV2802>, line: String) =
        GTIMCaseControlLabelSuggestionReportV2802(
            active = true,
            targetId = target,
            state = state,
            suggestions = suggestions,
            caseCount = suggestions.count { it.suggestedLabel.contains("case") || it.suggestedLabel.contains("disease") || it.suggestedLabel.contains("severe") || it.suggestedLabel.contains("responder") || it.suggestedLabel == "treated" },
            controlCount = suggestions.count { it.suggestedLabel.contains("control") || it.suggestedLabel == "baseline" || it.suggestedLabel == "untreated" },
            line = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Case/control boundary: labels are suggestions only; each requires source_field and evidence_snippet and never becomes final truth without review."
        )
}

object GTIMSampleIdLinkageVerifierV2802 {
    const val VERSION: String = "2.8.2-sample-id-linkage-verifier"

    fun build(
        targetId: String,
        report: JSONObject?,
        matrixClassifier: GTIMMatrixFileClassificationReportV2802,
        metadata: GTIMSampleMetadataExtractionReportV2802
    ): GTIMSampleIdLinkageVerificationReportV2802 {
        if (matrixClassifier.state.contains("BLOCKED_NO_TOPIC", true) || metadata.state.contains("BLOCKED_NO_TOPIC", true)) {
            return emit(targetId, "SAMPLE_ID_LINKAGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", 0, 0, 0, emptyList(), emptyList())
        }
        val metadataIds = metadata.rows.map { it.sampleId }.filter { it.isNotBlank() }.distinct()
        val matrixIds = matrixSampleIds(report)
        val metadataNorm = metadataIds.associateBy { normalizeSampleId(it) }
        val matrixNorm = matrixIds.associateBy { normalizeSampleId(it) }
        val matchedNorm = metadataNorm.keys.intersect(matrixNorm.keys).filter { it.isNotBlank() }
        val matched = matchedNorm.mapNotNull { metadataNorm[it] }
        val missingMatrix = metadataNorm.keys.minus(matrixNorm.keys).mapNotNull { metadataNorm[it] }.take(8)
        val missingMeta = matrixNorm.keys.minus(metadataNorm.keys).mapNotNull { matrixNorm[it] }.take(8)
        val state = when {
            matrixClassifier.state != "MATRIX_FILE_CLASSIFIED_REVIEW_ONLY" -> "SAMPLE_ID_LINKAGE_PENDING_MATRIX_FILE_CLASSIFICATION"
            metadataIds.isEmpty() -> "SAMPLE_ID_LINKAGE_PENDING_METADATA_ROWS"
            matrixIds.isEmpty() -> "SAMPLE_ID_LINKAGE_PENDING_MATRIX_SAMPLE_IDS"
            matched.size == metadataIds.size && matched.isNotEmpty() -> "SAMPLE_ID_LINKAGE_CONFIRMED_REVIEW_ONLY"
            matched.isNotEmpty() -> "SAMPLE_ID_LINKAGE_PARTIAL_REVIEW_REQUIRED"
            else -> "SAMPLE_ID_LINKAGE_FAILED_REVIEW_REQUIRED"
        }
        return emit(targetId, state, metadataIds.size, matrixIds.size, matched.size, missingMatrix, missingMeta)
    }

    private fun matrixSampleIds(report: JSONObject?): List<String> {
        if (report == null) return emptyList()
        val arrays = listOfNotNull(
            report.optJSONArray("matrixSampleIds"),
            report.optJSONArray("matrixColumnIds"),
            report.optJSONObject("actualEtlExecution")?.optJSONArray("matrixSampleIds"),
            report.optJSONObject("gtimActualEtl")?.optJSONArray("matrixSampleIds"),
            report.optJSONObject("mechanismDiscoveryDossierReport")?.optJSONArray("matrixSampleIds")
        )
        val out = mutableListOf<String>()
        for (array in arrays) {
            for (i in 0 until array.length()) {
                val value = array.optString(i).trim()
                if (value.isNotBlank()) out += value
            }
        }
        return out.distinct()
    }

    private fun normalizeSampleId(value: String): String = value
        .lowercase()
        .replace(Regex("[^a-z0-9]+"), "")
        .trim()

    private fun emit(target: String, state: String, metaCount: Int, matrixCount: Int, matchedCount: Int, missingMatrix: List<String>, missingMeta: List<String>): GTIMSampleIdLinkageVerificationReportV2802 {
        val line = "Sample-ID linkage verifier: version=$VERSION | state=$state | target=$target | metadata_samples=$metaCount | matrix_samples=$matrixCount | matched=$matchedCount | missing_from_matrix=${missingMatrix.ifEmpty { listOf("none") }.joinToString(",")} | missing_from_metadata=${missingMeta.ifEmpty { listOf("none") }.joinToString(",")}"
        return GTIMSampleIdLinkageVerificationReportV2802(
            active = true,
            targetId = target,
            state = state,
            metadataSampleCount = metaCount,
            matrixSampleCount = matrixCount,
            matchedSampleCount = matchedCount,
            missingFromMatrix = missingMatrix,
            missingFromMetadata = missingMeta,
            line = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "Sample-ID linkage boundary: DGE is blocked until matrix column IDs/cell barcodes match metadata sample rows under review."
        )
    }
}

object GTIMDgeReadinessVerdictV2802 {
    const val VERSION: String = "2.8.2-dge-readiness-verdict"

    fun build(
        targetId: String,
        matrixClassifier: GTIMMatrixFileClassificationReportV2802,
        metadata: GTIMSampleMetadataExtractionReportV2802,
        labels: GTIMCaseControlLabelSuggestionReportV2802,
        linkage: GTIMSampleIdLinkageVerificationReportV2802
    ): GTIMDgeReadinessVerdictReportV2802 {
        val blockers = mutableListOf<String>()
        if (matrixClassifier.state.contains("BLOCKED_NO_TOPIC", true)) blockers += "NO_TOPIC_COMPATIBLE_TARGET"
        if (matrixClassifier.state != "MATRIX_FILE_CLASSIFIED_REVIEW_ONLY") blockers += "MATRIX_FILE_NOT_CLASSIFIED"
        if (metadata.state != "SAMPLE_METADATA_EXTRACTED_REVIEW_ONLY") blockers += "SAMPLE_METADATA_NOT_EXTRACTED"
        if (labels.state != "CASE_CONTROL_LABELS_SUGGESTED_WITH_EVIDENCE") blockers += "CASE_CONTROL_LABELS_NOT_READY"
        if (linkage.state != "SAMPLE_ID_LINKAGE_CONFIRMED_REVIEW_ONLY") blockers += "SAMPLE_ID_LINKAGE_NOT_CONFIRMED"
        val verdict = if (blockers.isEmpty()) "DGE_READY_REVIEW_ONLY_NOT_RUN" else "DGE_BLOCKED_${blockers.first()}"
        val line = "DGE readiness verdict: version=$VERSION | verdict=$verdict | target=$targetId | blockers=${blockers.ifEmpty { listOf("none") }.joinToString(",")} | review_only=true | no_gene_signal_claim_without_dge=true"
        return GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = targetId,
            verdict = verdict,
            blockers = blockers,
            line = line.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = "DGE readiness boundary: verdict only; no DGE values, no pathway result, no clinical/treatment claim until review-only DGE output exists."
        )
    }
}
