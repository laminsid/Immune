package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.16 — Lightweight processed capsule schema.
 *
 * A capsule is not a raw matrix and not a validated scientific result. It is a tiny,
 * local, review-safe research substrate: accession/domain metadata, comparator hints,
 * module marker panels, and explicit limits. It exists to stop the app from repeating
 * "matrix missing" when a curated local substrate is available.
 */
data class GTIMProcessedCapsuleV21316(
    val capsuleId: String,
    val accession: String,
    val domain: String,
    val diseaseFamily: String,
    val species: String,
    val tissue: String,
    val comparators: List<String>,
    val sampleGroupsReady: Boolean,
    val matrixReady: Boolean,
    val modules: List<GTIMModuleDefinitionV21316>,
    val limitations: List<String>,
    val claimLimit: String = CLAIM_LIMIT,
    val expressionRows: List<GTIMExpressionSampleRowV21316> = emptyList()
) {
    fun toJson(): JSONObject = JSONObject()
        .put("capsule_id", capsuleId)
        .put("accession", accession)
        .put("domain", domain)
        .put("disease_family", diseaseFamily)
        .put("species", species)
        .put("tissue", tissue)
        .put("comparators", JSONArray(comparators))
        .put("sample_groups_ready", sampleGroupsReady)
        .put("matrix_ready", matrixReady)
        .put("modules", JSONArray(modules.map { it.toJson() }))
        .put("limitations", JSONArray(limitations))
        .put("claim_limit", claimLimit)
        .put("expression_rows", JSONArray(expressionRows.map { it.toJson() }))

    companion object {
        const val CLAIM_LIMIT: String = "processed_capsule_for_hypothesis_generation_not_validated_discovery"

        fun fromJson(json: JSONObject): GTIMProcessedCapsuleV21316 = GTIMProcessedCapsuleV21316(
            capsuleId = json.optString("capsule_id", json.optString("accession", "unknown_capsule")),
            accession = json.optString("accession", json.optString("capsule_id", "unknown")),
            domain = json.optString("domain", "unknown_domain"),
            diseaseFamily = json.optString("disease_family", json.optString("domain", "unknown_family")),
            species = json.optString("species", "unknown"),
            tissue = json.optString("tissue", "unknown"),
            comparators = json.optJSONArray("comparators").toStringList(),
            sampleGroupsReady = json.optBoolean("sample_groups_ready", false),
            matrixReady = json.optBoolean("matrix_ready", false),
            modules = json.optJSONArray("modules").toModuleList(),
            limitations = json.optJSONArray("limitations").toStringList(),
            claimLimit = json.optString("claim_limit", CLAIM_LIMIT),
            expressionRows = json.optJSONArray("expression_rows").toExpressionSampleRowList()
        )
    }
}



data class GTIMExpressionSampleRowV21316(
    val sampleId: String,
    val group: String,
    val values: Map<String, Double>
) {
    fun toJson(): JSONObject = JSONObject()
        .put("sample_id", sampleId)
        .put("group", group)
        .put("values", JSONObject(values))

    fun toExpressionSampleRow(): ExpressionSampleRowV30329 = ExpressionSampleRowV30329(sampleId, group, values)

    companion object {
        fun fromJson(json: JSONObject): GTIMExpressionSampleRowV21316 {
            val valuesJson = json.optJSONObject("values") ?: JSONObject()
            val values = mutableMapOf<String, Double>()
            valuesJson.keys().forEach { key ->
                val value = valuesJson.optDouble(key, Double.NaN)
                if (!value.isNaN()) values[key.uppercase()] = value
            }
            return GTIMExpressionSampleRowV21316(
                sampleId = json.optString("sample_id", json.optString("sampleId", "unknown_sample")),
                group = json.optString("group", "unknown_group"),
                values = values.toMap()
            )
        }
    }
}

data class GTIMModuleDefinitionV21316(
    val name: String,
    val markers: List<String>,
    val direction: String,
    val executionState: String = "ready_for_local_module_preview_not_scored",
    val evidenceLevel: String = "capsule_ready_not_proof"
) {
    fun toJson(): JSONObject = JSONObject()
        .put("name", name)
        .put("markers", JSONArray(markers))
        .put("direction", direction)
        .put("execution_state", executionState)
        .put("evidence_level", evidenceLevel)

    companion object {
        fun fromJson(json: JSONObject): GTIMModuleDefinitionV21316 = GTIMModuleDefinitionV21316(
            name = json.optString("name", "unnamed_module"),
            markers = json.optJSONArray("markers").toStringList(),
            direction = json.optString("direction", "direction_not_scored"),
            executionState = json.optString("execution_state", json.optString("score_state", "ready_for_local_module_preview_not_scored")),
            evidenceLevel = json.optString("evidence_level", "capsule_ready_not_proof")
        )
    }
}

enum class GTIMMatrixStateV21316 {
    LOCAL_PROCESSED_CAPSULE_AVAILABLE,
    LOCAL_DOMAIN_CAPSULE_AVAILABLE,
    CAPSULE_MISSING_ACQUISITION_TASK_CREATED
}

internal fun JSONArray?.toStringList(): List<String> {
    if (this == null) return emptyList()
    return (0 until length()).mapNotNull { index -> optString(index).takeIf { it.isNotBlank() } }
}

internal fun JSONArray?.toModuleList(): List<GTIMModuleDefinitionV21316> {
    if (this == null) return emptyList()
    return (0 until length()).mapNotNull { index -> optJSONObject(index)?.let(GTIMModuleDefinitionV21316::fromJson) }
}

internal fun JSONArray?.toExpressionSampleRowList(): List<GTIMExpressionSampleRowV21316> {
    if (this == null) return emptyList()
    return (0 until length()).mapNotNull { index -> optJSONObject(index)?.let(GTIMExpressionSampleRowV21316::fromJson) }
}
