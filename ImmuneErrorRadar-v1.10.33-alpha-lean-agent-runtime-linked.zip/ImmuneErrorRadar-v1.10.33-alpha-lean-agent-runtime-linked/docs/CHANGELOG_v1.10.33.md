# Changelog — v1.10.33

Release: `1.10.33-alpha-lean-agent-runtime`

- Updated release identity to `versionCode=95`, `versionName=1.10.33-alpha-lean-agent-runtime`, `ACTIVE_ENGINE_VERSION=v1.10.33-alpha-lean-agent-runtime`, and `LEARNING_SESSION_SCHEMA_VERSION=1.10.33`.
- Added `LeadObject` ledger model for weak/manual/near-miss leads.
- Added `LeanAgentRuntimePolicy` with deterministic micro-agent list, hard gates, state deltas, and compact decision card.
- Connected LeadObject ledger, mature-domain focus, knowledge gap queue, strong route fingerprint, and report consistency into `DatasetForagingReport` JSON/PDF/UI exports.
- Kept fast/full CI split and release linkage guard mandatory.

Runtime remains routing-only and claim-safe: `lean_agent_runtime_routing_only_not_biological_proof`.
