#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
python3 scripts/validate_json.py
python3 scripts/audit_kotlin_delimiters.py
python3 - <<'PY_AUDIT_STRINGS'
import pathlib
bad=[]
for path in pathlib.Path('app/src/main/java').rglob('*.kt'):
    for i,line in enumerate(path.read_text(errors='replace').splitlines(),1):
        if '"""' in line:
            continue
        cnt=0
        esc=False
        for ch in line:
            if esc:
                esc=False
                continue
            if ch == '\\':
                esc=True
                continue
            if ch == '"':
                cnt += 1
        if cnt % 2 == 1:
            bad.append(f'{path}:{i}: {line[:140]}')
if bad:
    raise SystemExit('Kotlin raw/newline string literal audit failed:\n' + '\n'.join(bad[:20]))
print('Kotlin string literal audit: PASS')
PY_AUDIT_STRINGS
python3 - <<'PY'
import pathlib, xml.etree.ElementTree as ET, re, sys
for p in pathlib.Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('XML parse: PASS')
manifest=pathlib.Path('app/src/main/AndroidManifest.xml').read_text()
for forbidden in ['QUERY_ALL_PACKAGES','WRITE_EXTERNAL_STORAGE','MANAGE_EXTERNAL_STORAGE','ACCESS_FINE_LOCATION']:
    if forbidden in manifest:
        raise SystemExit(f'Forbidden permission found: {forbidden}')
if 'android.permission.INTERNET' not in manifest:
    raise SystemExit('INTERNET permission expected for private Research Autopilot')
if '.ResultActivity' in manifest:
    raise SystemExit('Legacy ResultActivity must not be registered in runtime manifest')
main_layout = pathlib.Path('app/src/main/res/layout/activity_main.xml').read_text().lower()
for forbidden_ui in ['old daily scan', 'symptom input page', 'daily health score']:
    if forbidden_ui in main_layout:
        raise SystemExit(f'Legacy first-page wording remains: {forbidden_ui}')
xml_ids=set()
for p in pathlib.Path('app/src/main/res/layout').glob('*.xml'):
    xml_ids.update(re.findall(r'@\+id/([A-Za-z0-9_]+)', p.read_text()))
refs=set()
for p in pathlib.Path('app/src/main/java').rglob('*.kt'):
    refs.update(re.findall(r'R\.id\.([A-Za-z0-9_]+)', p.read_text()))
missing=refs-xml_ids
if missing:
    raise SystemExit(f'Missing layout ids: {sorted(missing)}')
print('Layout ID check: PASS')
PY

python3 - <<'PY'
import pathlib, re
version = '1.6.9-alpha-epistemic-belief-discipline'
build = pathlib.Path('app/build.gradle.kts').read_text()
if version not in build:
    raise SystemExit(f'Version mismatch: {version} not found in app/build.gradle.kts')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['runtimeStatus', 'executionLockReport', 'datasetForagingReport', 'persistentFailureMemory']:
    if required not in models:
        raise SystemExit(f'Missing report field: {required}')
for required in ['triageReport', 'failurePatternReport', 'queryFeedbackPlan', 'freshnessReport']:
    if required not in pathlib.Path('app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt').read_text():
        raise SystemExit(f'Missing v1.4.5 report field: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
for required in ['runtimeFailoverApplied', 'hardStagnationTriggered', 'runtime_dataset_accession', 'runDatasetFirstForaging', 'searchNcbiIds', 'DatasetParser.parse', 'ResearchStateEngine.actionableSummary', 'FailurePatternLedger', 'QueryFeedbackPlanner.improveBatch', 'MLDatasetTriageEngine.triage', 'EvidenceFreshnessScorer.report', 'FoundationKnowledgeIntegrationBridge', 'foundationAnalysisV151', 'enableFoundationKnowledgeOs']:
    if required not in autopilot:
        raise SystemExit(f'Missing execution wiring token: {required}')
router = pathlib.Path('app/src/main/java/com/immunesignal/app/DirectDatasetSourceRouter.kt').read_text()
if 'GEO_GDS_COOLDOWN_ESCAPE' not in router:
    raise SystemExit('Missing route hardening token: GEO_GDS_COOLDOWN_ESCAPE')
engine = pathlib.Path('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt').read_text()
if 'q_v142_' not in engine:
    raise SystemExit('Execution lock does not accept q_v142_ dataset-parser forced queries')
for required in ['FailurePatternLedger', 'QueryFeedbackPlanner', 'DatasetTriageEngine', 'MLDatasetTriageEngine', 'FailurePredictionModel', 'RouteEmbeddingScorer', 'EvidenceFreshnessScorer', 'FoundationKnowledgeLayer', 'AxisRankingEngine', 'FoundationConflictResolver', 'FoundationKnowledgeAccuracyLedger', 'FoundationPatchSuggestionLedger', 'LearningSessionManager', 'PhaseExecutor', 'ProgressTracker', 'QuestionEvolver', 'SessionMetrics', 'RuntimeFeatureFlags', 'LearningSessionIntegrityGuard', 'SessionHistoryPersistence', 'LearningSessionOutcomeBridge', 'SessionHandoff', 'CandidateActionResolver', 'MinimumMetadataParser', 'AutoContinuationTrigger', 'ReportConsistencyGuard', 'SpecializedReasoningEngine', 'HypothesisFalsificationPressure', 'NextDecisiveTestSelector', 'GeneralModelFailureGuard', 'CumulativeKnowledgeMapEngine', 'KnowledgeMapReport', 'EpistemicBeliefEngine', 'EpistemicBeliefReport', 'CognitivePathIntegrationEngine', 'CognitivePathIntegrationReport']:
    if required not in engine:
        raise SystemExit(f'Missing v1.5.7 active module: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
for required in ['CandidateActionResolver.resolve', 'MinimumMetadataParser.parse', 'AutoContinuationTrigger.evaluate', 'ReportConsistencyGuard.evaluate', 'candidateActionReport', 'autoContinuationReport', 'reportConsistencyGuard']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.5.8 auto-light learning wiring token: {required}')
models_foraging = pathlib.Path('app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt').read_text()
for required in ['CandidateActionReport', 'AutoContinuationReport', 'ReportConsistencyGuardReport']:
    if required not in models_foraging:
        raise SystemExit(f'Missing v1.5.8 foraging model field: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['candidateActionReport', 'autoContinuationReport', 'reportConsistencyGuard']:
    if required not in activity:
        raise SystemExit(f'Missing v1.5.8 UI visibility token: {required}')
for required in ['renderSimpleUserReport', 'renderMiniLearningReport', 'toggleAdvancedControls', 'learningMiniReportText', 'advancedControlsContainer']:
    if required not in activity:
        raise SystemExit(f'Missing v1.5.9 simple UI learning-brief token: {required}')
layout_research = pathlib.Path('app/src/main/res/layout/activity_research_autopilot.xml').read_text()
for required in ['learningMiniReportText', 'toggleAdvancedButton', 'advancedControlsContainer', 'Small learning report']:
    if required not in layout_research:
        raise SystemExit(f'Missing v1.5.9 simple UI layout token: {required}')
report_builder = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchReportV3Builder.kt').read_text()
for required in ['Auto-light learning: ACTIVE during SEARCH', 'CandidateActionResolver', 'Auto-light continuation queued', 'Report consistency']:
    if required not in report_builder:
        raise SystemExit(f'Missing v1.5.8 report consistency language: {required}')

models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
if 'Run a research cycle or import a report' in models:
    raise SystemExit('Generic non-actionable Next Evidence text remains')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['skipThinkingButton.setOnClickListener', 'private fun skipThinkingPhase()', 'skipCurrentOrNextPhase', 'startThinkingSession(SessionType.RESUMED)']:
    if required not in activity:
        raise SystemExit(f'Missing learning-session UI handler token: {required}')
manifest = pathlib.Path('app/src/main/AndroidManifest.xml').read_text()
if '.ResultActivity' in manifest:
    raise SystemExit('Legacy manual result route is still registered')

phase_executor = pathlib.Path('app/src/main/java/com/immunesignal/app/PhaseExecutor.kt').read_text()
for required in ['attachEvolvedQuestions', 'QuestionEvolver.generateQuestions', 'question_evolution_not_biological_proof', 'questionObjects']:
    if required not in phase_executor:
        raise SystemExit(f'Missing v1.5.7 question-evolution token: {required}')
progress_tracker = pathlib.Path('app/src/main/java/com/immunesignal/app/ProgressTracker.kt').read_text()
for required in ['JSONObject().apply', 'JSONArray()', 'generateJSONReport', 'RuntimeFeatureFlags.LEARNING_SESSION_CLAIM_LIMIT']:
    if required not in progress_tracker:
        raise SystemExit(f'Missing v1.5.7 safe progress JSON token: {required}')
manager = pathlib.Path('app/src/main/java/com/immunesignal/app/LearningSessionManager.kt').read_text()

outcome_bridge = pathlib.Path('app/src/main/java/com/immunesignal/app/LearningSessionOutcomeBridge.kt').read_text()
for required in ['session_handoff_not_biological_proof', 'buildHandoffFromInsights', 'NO_OUTCOME_LABELS', 'toJson()', 'compactSummary']:
    if required not in outcome_bridge:
        raise SystemExit(f'Missing v1.5.7 session-handoff token: {required}')
manager = pathlib.Path('app/src/main/java/com/immunesignal/app/LearningSessionManager.kt').read_text()
for required in ['LearningSessionHandoff', 'sessionHandoff', 'LearningSessionOutcomeBridge.buildHandoff']:
    if required not in manager:
        raise SystemExit(f'Missing v1.5.7 manager handoff token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
if 'handoff.compactSummary()' not in activity:
    raise SystemExit('Missing v1.5.7 UI handoff summary token')
integration = pathlib.Path('app/src/main/java/com/immunesignal/app/LearningSessionIntegration.kt').read_text()
if 'skipCurrentOrNextPhase("ui_bridge_skip_to_next_phase")' not in integration:
    raise SystemExit('LearningSessionUIBridge skip must use integrity-protected manager skip')

manager = pathlib.Path('app/src/main/java/com/immunesignal/app/LearningSessionManager.kt').read_text()
for required in ['buildSessionMetrics(normalized)', 'deltaFromPrevious', 'pendingPhases = emptyList()', 'buildSessionMetrics(session)']:
    if required not in manager:
        raise SystemExit(f'Missing v1.5.7 session-metrics token: {required}')

specialist = pathlib.Path('app/src/main/java/com/immunesignal/app/SpecializedReasoningEngine.kt').read_text()
for required in ['specialized_reasoning_not_biological_proof', 'Generic-AI risk', 'decisiveNextTest', 'falsificationDemand', 'axisDiscipline', 'EvidenceGapCard', 'HypothesisTournamentCard', 'ReasoningAuditQuestion', 'specialistVerdict', 'nextCycleProtocol']:
    if required not in specialist:
        raise SystemExit(f'Missing v1.6.1 specialist protocol token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['specializedReasoningReport', 'specializedReasoningToJson', 'specialistMoveToJson', 'evidenceGapToJson', 'hypothesisTournamentToJson', 'reasoningAuditToJson']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.1 specialist protocol JSON token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
for required in ['SpecializedReasoningEngine.evaluate', 'specializedReasoningReport', 'v1.6.1 specialist evidence protocol', 'v1.6.1 decisive next test']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.1 specialist protocol wiring token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['specializedReasoningReport', 'Specialized reasoning:', 'Specialist check:', 'specialistVerdict', 'evidenceGaps']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.1 specialist protocol UI token: {required}')

knowledge_map = pathlib.Path('app/src/main/java/com/immunesignal/app/CumulativeKnowledgeMapEngine.kt').read_text()
for required in ['knowledge_map_not_biological_proof', 'KnowledgeMapNode', 'KnowledgeMapEdge', 'KnowledgeMapGap', 'readPriorMap', 'changedSincePrevious']:
    if required not in knowledge_map:
        raise SystemExit(f'Missing v1.6.2 knowledge-map token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['knowledgeMapReport', 'knowledgeMapToJson', 'knowledgeMapNodeToJson', 'knowledgeMapEdgeToJson', 'knowledgeMapGapToJson']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.2 knowledge-map JSON token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
for required in ['CumulativeKnowledgeMapEngine.build', 'knowledgeMapReport', 'v1.6.2 cumulative knowledge map', 'v1.6.2 map next action']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.2 knowledge-map wiring token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['knowledgeMapReport', 'Knowledge map:', 'Map next:', 'Map state:']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.2 knowledge-map UI token: {required}')
exporter = pathlib.Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for required in ['Cumulative knowledge map', 'knowledgeMapReport', 'Top map links', 'knowledge_map_not_biological_proof']:
    if required not in exporter:
        raise SystemExit(f'Missing v1.6.2 knowledge-map PDF token: {required}')

belief = pathlib.Path('app/src/main/java/com/immunesignal/app/EpistemicBeliefEngine.kt').read_text()
for required in ['epistemic_beliefs_not_biological_proof', 'EpistemicBelief', 'EpistemicBeliefReport', 'credibility', 'REVISE_REQUIRED', 'RETIRED', 'foundationBeliefs']:
    if required not in belief:
        raise SystemExit(f'Missing v1.6.3 epistemic-belief token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['epistemicBeliefReport', 'epistemicBeliefToJson', 'epistemicBeliefItemToJson', 'epistemicBeliefUpdateToJson']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.3 epistemic-belief JSON token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
for required in ['EpistemicBeliefEngine.build', 'epistemicBeliefReport', 'v1.6.3 epistemic belief model', 'v1.6.3 belief next action']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.3 epistemic-belief wiring token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['epistemicBeliefReport', 'Belief model:', 'Belief next:', 'Next belief action']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.3 epistemic-belief UI token: {required}')
exporter = pathlib.Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for required in ['Epistemic belief model', 'epistemicBeliefReport', 'Top mutable beliefs', 'epistemic_beliefs_not_biological_proof']:
    if required not in exporter:
        raise SystemExit(f'Missing v1.6.3 epistemic-belief PDF token: {required}')

belief = pathlib.Path('app/src/main/java/com/immunesignal/app/EpistemicBeliefEngine.kt').read_text()
for required in ['EpistemicBeliefTransitionSummary', 'abandonmentQuestion', 'DROPPED_UNUSED_WEAK_BELIEF', 'buildTransitionSummary', 'shouldCarryPriorBelief', 'What evidence would make me abandon this belief?']:
    if required not in belief:
        raise SystemExit(f'Missing v1.6.9 epistemic-belief discipline token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['transitionSummary', 'epistemicBeliefTransitionSummaryToJson', 'abandonmentQuestion']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.9 epistemic-belief discipline JSON token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['Strengthened belief:', 'Weakened belief:', 'Dropped belief:', 'Belief abandonment test:', 'Belief changed: strengthened=']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.9 epistemic-belief discipline UI token: {required}')
exporter = pathlib.Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for required in ['Strengthened belief:', 'Weakened belief:', 'Dropped belief:', 'Belief abandonment test:', 'Pruning rule:']:
    if required not in exporter:
        raise SystemExit(f'Missing v1.6.9 epistemic-belief discipline PDF token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
for required in ['v1.6.9 epistemic belief discipline', 'v1.6.9 belief abandonment question']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.9 epistemic-belief discipline wiring token: {required}')
engine = pathlib.Path('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt').read_text()
for required in ['BeliefTransitionSummary', 'BeliefAbandonmentQuestion', 'UnusedWeakBeliefPruner']:
    if required not in engine:
        raise SystemExit(f'Missing v1.6.9 active module: {required}')


cognitive = pathlib.Path('app/src/main/java/com/immunesignal/app/CognitivePathIntegrationEngine.kt').read_text()
for required in ['cognitive_path_integration_not_biological_proof', 'CognitivePathIntegrationReport', 'CognitivePathDecision', 'map_updates_mutable_belief', 'belief_requires_specialist_test', 'specialist_test_controls_next_search']:
    if required not in cognitive:
        raise SystemExit(f'Missing v1.6.4 cognitive-path token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['cognitivePathIntegrationReport', 'cognitivePathIntegrationToJson', 'cognitivePathNodeToJson', 'cognitivePathLinkToJson', 'cognitivePathDecisionToJson']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.4 cognitive-path JSON token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
for required in ['CognitivePathIntegrationEngine.integrate', 'cognitivePathIntegrationReport', 'v1.6.4 cognitive path integration', 'v1.6.4 linked next action']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.4 cognitive-path wiring token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['cognitivePathIntegrationReport', 'Linked thinking path:', 'Linked path:', 'Linked next:']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.4 cognitive-path UI token: {required}')
exporter = pathlib.Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for required in ['Cognitive path integration', 'cognitivePathIntegrationReport', 'Integrated links', 'cognitive_path_integration_not_biological_proof']:
    if required not in exporter:
        raise SystemExit(f'Missing v1.6.4 cognitive-path PDF token: {required}')

calibration = pathlib.Path('app/src/main/java/com/immunesignal/app/CognitiveLoopCalibrationEngine.kt').read_text()
for required in ['cognitive_loop_calibration_not_biological_proof', 'CognitiveLoopCalibrationReport', 'dampenSimilarDirective', 'rewardSimilarDirective', 'METADATA_PROGRESS', 'CONTRASTIVE_GATE_STALLED']:
    if required not in calibration:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['cognitiveLoopCalibrationReport', 'cognitiveLoopCalibrationToJson', 'cognitiveLoopCalibrationSignalToJson']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration JSON token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
for required in ['CognitiveLoopCalibrationEngine.calibrate', 'cognitiveLoopCalibrationReport', 'v1.6.8 cognitive loop calibration']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration wiring token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['cognitiveLoopCalibrationReport', 'Loop calibration:', 'calibrationScore']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration UI token: {required}')
exporter = pathlib.Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for required in ['Cognitive loop calibration', 'cognitiveLoopCalibrationReport', 'Improved signals', 'Stalled signals']:
    if required not in exporter:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration PDF token: {required}')
store = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt').read_text()
for required in ['saveCognitiveLoopCalibrationFromReport', 'cognitive_loop_calibration', 'rewardSimilarDirective']:
    if required not in store:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration ledger token: {required}')

print('Execution wiring/version check: PASS')
PY

python3 -B -m py_compile research/*.py
find research -type d -name __pycache__ -prune -exec rm -rf {} +
find research -name '*.pyc' -delete

python3 - <<'PY'
import pathlib
bad=[]
for p in pathlib.Path('.').rglob('__pycache__'):
    bad.append(str(p))
for p in pathlib.Path('.').rglob('*.pyc'):
    bad.append(str(p))
if bad:
    raise SystemExit('Python cache artifacts found in release tree: ' + ', '.join(bad[:20]))
print('Python cache artifact check: PASS')
PY

if [[ "${RUN_SAMPLE_PIPELINE:-0}" == "1" ]]; then
  timeout 20 python3 research/omics_bridge.py research/examples/sample_cases.csv >/tmp/immune_omics_bridge.json
  timeout 20 python3 research/baseline_classifier.py research/examples/sample_matrix.csv >/tmp/immune_baseline.json || true
  timeout 20 python3 research/evidence_quality.py >/tmp/immune_evidence_quality.json
  timeout 20 python3 research/causality_scorer.py 'stress before allergy histamine blood pressure mast cell mechanism' >/tmp/immune_causality.json
  timeout 20 python3 research/personal_time_series.py research/examples/sample_personal_series.csv stress allergy_intensity >/tmp/immune_personal_series.json
  timeout 20 python3 research/negative_controls.py research/examples/sample_personal_series.csv stress dizziness >/tmp/immune_negative_controls.json
  timeout 20 python3 research/hypothesis_ranker.py research/examples/sample_hypotheses.csv >/tmp/immune_hypothesis_ranker.json
  timeout 20 python3 research/global_dataset_registry.py research/examples/global_dataset_candidates.csv >/tmp/immune_global_dataset_registry.json
  timeout 20 python3 research/immune_axis_mapper.py 'interferon IL10 CD8 antibody tissue damage recovery' >/tmp/immune_axis_mapper.json
  timeout 20 python3 research/trigger_response_graph.py 'virus interferon IL10 tissue damage recovery' >/tmp/immune_trigger_response_graph.json
  timeout 20 python3 research/pathogen_response_comparator.py 'virus interferon IL10 tissue damage recovery' >/tmp/immune_pathogen_response.json
  echo 'Research Python sample pipeline: PASS'
else
  echo 'Research Python compile checks: PASS'
  echo 'Sample pipeline skipped by default; run RUN_SAMPLE_PIPELINE=1 scripts/run_static_checks.sh to execute examples.'
fi


python3 - <<'PY'
from pathlib import Path
root = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': ['CognitiveNextCycleDirective', 'CognitiveNextCyclePlan', 'next_cycle_routing_only_not_biological_proof', 'isConsumed', 'sameRoutingFingerprint', 'already consumed once', 'Directive terms were already covered'],
    'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt': ['readActiveCognitiveNextCycleDirective', 'saveCognitiveNextCycleDirectiveFromReport', 'markCognitiveNextCycleDirectiveConsumed', 'cognitive_next_cycle_directive_suppressed', 'routingFingerprint'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['CognitiveNextCycleBridge.applyToQueries', 'cognitiveNextCyclePlanV165', 'v1.6.7 cognitive directive retirement'],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': ['cognitiveNextCyclePlan', 'cognitiveNextCyclePlanToJson', 'suppressedReason', 'directiveConsumed']
}
for rel, tokens in checks.items():
    text = (root / rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.6.7 directive-retirement token: {rel} -> {token}')
print('v1.6.7 cognitive loop continuity audit: PASS')
PY


python3 - <<'PY_AUDIT_V167'
import pathlib
bridge = pathlib.Path('app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt').read_text()
for required in ['consumedNoopPlan', 'retired_noop_or_already_satisfied', 'consumptionReason', 'routingFingerprint', 'Directive terms were already covered']:
    if required not in bridge:
        raise SystemExit(f'Missing v1.6.7 directive-retirement token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
if 'cognitiveNextCyclePlanV165.directiveConsumed' not in autopilot:
    raise SystemExit('ResearchAutopilot must consume directives for active and no-op retired plans')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['consumptionReason', 'routingFingerprint', 'useLimit']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.7 cognitive plan JSON field: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
if 'Closed loop retired' not in activity:
    raise SystemExit('UI must expose retired/satisfied cognitive directives')
print('v1.6.7 cognitive directive retirement audit: PASS')
PY_AUDIT_V167
