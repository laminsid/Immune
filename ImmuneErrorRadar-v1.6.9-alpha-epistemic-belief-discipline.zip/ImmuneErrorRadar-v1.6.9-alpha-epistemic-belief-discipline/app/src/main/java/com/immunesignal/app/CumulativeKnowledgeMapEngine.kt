package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v1.6.2: cumulative knowledge map.
 *
 * The engine must not search, score, then throw context away. This layer builds a
 * lightweight local map from prior reports plus the current cycle. It is an
 * orientation layer only: it links axes, datasets, hypotheses, evidence objects,
 * and open gaps so the next hunt starts from a map rather than from a blank query.
 */
data class KnowledgeMapNode(
    val nodeId: String,
    val nodeType: String,
    val label: String,
    val score: Int,
    val occurrences: Int,
    val evidenceIds: List<String>,
    val status: String,
    val summary: String
)

data class KnowledgeMapEdge(
    val fromNode: String,
    val toNode: String,
    val relation: String,
    val weight: Int,
    val supportCount: Int,
    val status: String,
    val rationale: String
)

data class KnowledgeMapGap(
    val gapId: String,
    val affectedNodes: List<String>,
    val severity: Int,
    val nextAction: String,
    val blocksUpgrade: Boolean
)

data class KnowledgeMapReport(
    val active: Boolean,
    val mapScore: Int,
    val state: String,
    val carriedForwardNodes: Int,
    val newNodesThisCycle: Int,
    val newLinksThisCycle: Int,
    val nodes: List<KnowledgeMapNode>,
    val edges: List<KnowledgeMapEdge>,
    val gaps: List<KnowledgeMapGap>,
    val carriedForwardInsights: List<String>,
    val changedSincePrevious: List<String>,
    val nextMapAction: String,
    val visibleBrief: String,
    val claimLimit: String = "knowledge_map_not_biological_proof"
) {
    companion object {
        fun empty() = KnowledgeMapReport(
            active = false,
            mapScore = 0,
            state = "NOT_BUILT",
            carriedForwardNodes = 0,
            newNodesThisCycle = 0,
            newLinksThisCycle = 0,
            nodes = emptyList(),
            edges = emptyList(),
            gaps = emptyList(),
            carriedForwardInsights = emptyList(),
            changedSincePrevious = listOf("Knowledge map has not run yet."),
            nextMapAction = "Run a research cycle to build the first local knowledge map.",
            visibleBrief = "No cumulative knowledge map yet.",
            claimLimit = "knowledge_map_not_biological_proof"
        )
    }
}

object CumulativeKnowledgeMapEngine {
    fun build(
        currentFindings: List<ResearchFinding>,
        hypothesisObjects: List<HypothesisObject>,
        evidenceObjects: List<EvidenceObject>,
        datasetForagingReport: DatasetForagingReport,
        specializedReasoningReport: SpecializedReasoningReport,
        recentReportLines: List<String>
    ): KnowledgeMapReport {
        val prior = readPriorMap(recentReportLines)
        val nodes = linkedMapOf<String, KnowledgeMapNode>()
        val edges = linkedMapOf<String, KnowledgeMapEdge>()
        val gaps = linkedMapOf<String, KnowledgeMapGap>()

        fun addNode(node: KnowledgeMapNode) {
            val previous = nodes[node.nodeId]
            nodes[node.nodeId] = if (previous == null) node else previous.copy(
                score = maxOf(previous.score, node.score),
                occurrences = previous.occurrences + node.occurrences,
                evidenceIds = (previous.evidenceIds + node.evidenceIds).distinct().take(12),
                status = if (previous.status == "ACTIVE" || node.status == "ACTIVE") "ACTIVE" else node.status,
                summary = node.summary.ifBlank { previous.summary }
            )
        }

        fun addEdge(edge: KnowledgeMapEdge) {
            val key = edgeKey(edge)
            val previous = edges[key]
            edges[key] = if (previous == null) edge else previous.copy(
                weight = maxOf(previous.weight, edge.weight),
                supportCount = previous.supportCount + edge.supportCount,
                status = if (previous.status == "SUPPORTED" || edge.status == "SUPPORTED") "SUPPORTED" else edge.status,
                rationale = edge.rationale.ifBlank { previous.rationale }
            )
        }

        fun addGap(gap: KnowledgeMapGap) {
            val previous = gaps[gap.gapId]
            gaps[gap.gapId] = if (previous == null) gap else previous.copy(
                affectedNodes = (previous.affectedNodes + gap.affectedNodes).distinct().take(16),
                severity = maxOf(previous.severity, gap.severity),
                blocksUpgrade = previous.blocksUpgrade || gap.blocksUpgrade
            )
        }

        prior.nodes.take(40).forEach { addNode(it.copy(status = "CARRIED_FORWARD")) }
        prior.edges.take(60).forEach { addEdge(it.copy(status = "CARRIED_FORWARD")) }
        prior.gaps.take(16).forEach { addGap(it) }

        val findingAxes = currentFindings.flatMap { it.matchedAxes }.filter { it.isNotBlank() }
        findingAxes.groupingBy { it }.eachCount().forEach { (axis, count) ->
            addNode(
                KnowledgeMapNode(
                    nodeId = nodeId("axis", axis),
                    nodeType = "AXIS",
                    label = axis,
                    score = (45 + count * 8).coerceAtMost(95),
                    occurrences = count,
                    evidenceIds = currentFindings.filter { axis in it.matchedAxes }.map { it.source + ":" + it.sourceId }.distinct().take(8),
                    status = "ACTIVE",
                    summary = "Axis observed in this cycle; kept as map context, not proof."
                )
            )
        }

        currentFindings.forEach { finding ->
            val sourceNode = nodeId("source", finding.source + ":" + finding.sourceId)
            addNode(
                KnowledgeMapNode(
                    nodeId = sourceNode,
                    nodeType = "SOURCE",
                    label = finding.title.take(90),
                    score = finding.evidence.evidenceQualityScore.coerceIn(0, 100),
                    occurrences = 1,
                    evidenceIds = listOf(finding.source + ":" + finding.sourceId),
                    status = "EVIDENCE_CANDIDATE",
                    summary = finding.whyItMatters.take(220)
                )
            )
            finding.matchedAxes.distinct().take(6).forEach { axis ->
                addEdge(
                    KnowledgeMapEdge(
                        fromNode = sourceNode,
                        toNode = nodeId("axis", axis),
                        relation = "mentions_axis",
                        weight = finding.evidence.evidenceQualityScore.coerceIn(20, 90),
                        supportCount = 1,
                        status = "SUPPORTED",
                        rationale = "Source mapped to axis by local axis matcher and evidence assessment."
                    )
                )
            }
            val axes = finding.matchedAxes.distinct().take(8)
            axes.flatMapIndexed { index, a -> axes.drop(index + 1).map { b -> a to b } }.forEach { pair ->
                addEdge(
                    KnowledgeMapEdge(
                        fromNode = nodeId("axis", pair.first),
                        toNode = nodeId("axis", pair.second),
                        relation = "co_observed_axis",
                        weight = 35 + minOf(finding.evidence.evidenceQualityScore / 3, 25),
                        supportCount = 1,
                        status = "HYPOTHESIS_GRADE",
                        rationale = "Axes appeared together in one source; this is a map lead, not a mechanism."
                    )
                )
            }
        }

        hypothesisObjects.take(12).forEach { hyp ->
            val hypNode = nodeId("hypothesis", hyp.hypothesisId)
            addNode(
                KnowledgeMapNode(
                    nodeId = hypNode,
                    nodeType = "HYPOTHESIS",
                    label = hyp.label.take(90),
                    score = ((hyp.evidenceScore10 * 10.0).toInt() + hyp.dataTrustScore) / 2,
                    occurrences = 1,
                    evidenceIds = emptyList(),
                    status = hyp.status,
                    summary = "${hyp.discoveryState}; missing=${hyp.missingData.joinToString(", ").take(120)}"
                )
            )
            hyp.missingData.take(5).forEach { missing ->
                addGap(
                    KnowledgeMapGap(
                        gapId = "missing_${sanitize(missing)}",
                        affectedNodes = listOf(hypNode),
                        severity = if (missing.contains("outcome", true) || missing.contains("time", true)) 85 else 65,
                        nextAction = "Collect missing field before hypothesis upgrade: $missing",
                        blocksUpgrade = true
                    )
                )
            }
        }

        datasetForagingReport.candidates.take(12).forEach { candidate ->
            val dataNode = nodeId("dataset", candidate.accession)
            addNode(
                KnowledgeMapNode(
                    nodeId = dataNode,
                    nodeType = "DATASET",
                    label = candidate.accession,
                    score = candidate.usabilityScore.coerceIn(0, 100),
                    occurrences = 1,
                    evidenceIds = listOf(candidate.sourceFindingId).filter { it.isNotBlank() },
                    status = candidate.status,
                    summary = candidate.sourceTitle.take(220)
                )
            )
            val text = listOf(candidate.conditionLabelsHint, candidate.outcomeLabelsHint, candidate.triggerResponseOutcomeHint, candidate.dataType).joinToString(" ")
            AxisMatcher.match(text).take(5).forEach { axis ->
                addNode(
                    KnowledgeMapNode(
                        nodeId = nodeId("axis", axis),
                        nodeType = "AXIS",
                        label = axis,
                        score = 55,
                        occurrences = 1,
                        evidenceIds = listOf(candidate.accession),
                        status = "DATASET_MAPPED",
                        summary = "Axis inferred from dataset metadata hints."
                    )
                )
                addEdge(
                    KnowledgeMapEdge(
                        fromNode = dataNode,
                        toNode = nodeId("axis", axis),
                        relation = "dataset_axis_hint",
                        weight = candidate.usabilityScore.coerceIn(20, 85),
                        supportCount = 1,
                        status = "NEEDS_METADATA",
                        rationale = "Dataset label hints point to this axis; minimum metadata still gates belief."
                    )
                )
            }
        }

        datasetForagingReport.routeFitAssessments.take(16).forEach { fit ->
            addEdge(
                KnowledgeMapEdge(
                    fromNode = nodeId("dataset", fit.accession),
                    toNode = nodeId("route", fit.targetRoute),
                    relation = "route_fit",
                    weight = fit.routeFitScore.coerceIn(0, 100),
                    supportCount = 1,
                    status = fit.status,
                    rationale = fit.allowedUse.take(220)
                )
            )
            addNode(
                KnowledgeMapNode(
                    nodeId = nodeId("route", fit.targetRoute),
                    nodeType = "ROUTE",
                    label = fit.targetRoute,
                    score = fit.routeFitScore.coerceIn(0, 100),
                    occurrences = 1,
                    evidenceIds = listOf(fit.accession),
                    status = fit.status,
                    summary = "Route target tracked so later searches do not restart from a blank route."
                )
            )
        }

        evidenceObjects.take(20).forEach { obj ->
            val evidenceNode = nodeId("evidence", obj.evidenceId)
            addNode(
                KnowledgeMapNode(
                    nodeId = evidenceNode,
                    nodeType = "EVIDENCE_OBJECT",
                    label = obj.title.take(90),
                    score = obj.qualityScore.coerceIn(0, 100),
                    occurrences = 1,
                    evidenceIds = listOf(obj.evidenceId),
                    status = obj.decisionImpact,
                    summary = obj.reasons.joinToString("; ").take(220)
                )
            )
            if (obj.linkedHypothesisId.isNotBlank()) {
                addEdge(
                    KnowledgeMapEdge(
                        fromNode = evidenceNode,
                        toNode = nodeId("hypothesis", obj.linkedHypothesisId),
                        relation = if (obj.contradictsHypothesis) "contradicts_hypothesis" else "supports_or_blocks_hypothesis",
                        weight = obj.qualityScore.coerceIn(0, 100),
                        supportCount = 1,
                        status = obj.decisionImpact,
                        rationale = "Evidence object carried into cumulative map with claim-safe decision impact."
                    )
                )
            }
        }

        if (datasetForagingReport.candidates.isNotEmpty() && datasetForagingReport.parsedMetadata.isEmpty()) {
            addGap(
                KnowledgeMapGap(
                    gapId = "minimum_metadata_not_parsed",
                    affectedNodes = datasetForagingReport.candidates.take(8).map { nodeId("dataset", it.accession) },
                    severity = 90,
                    nextAction = "Run minimum metadata parsing before contrastive evaluation or hypothesis upgrade.",
                    blocksUpgrade = true
                )
            )
        }
        if (datasetForagingReport.contrastiveReport.gateStatus == "NOT_EVALUATED") {
            addGap(
                KnowledgeMapGap(
                    gapId = "contrastive_gate_not_evaluated",
                    affectedNodes = datasetForagingReport.candidates.take(8).map { nodeId("dataset", it.accession) },
                    severity = 75,
                    nextAction = datasetForagingReport.contrastiveReport.nextContrastiveQuestion,
                    blocksUpgrade = true
                )
            )
        }
        specializedReasoningReport.evidenceGaps.take(6).forEach { gap ->
            addGap(
                KnowledgeMapGap(
                    gapId = "specialist_${sanitize(gap.gapId)}",
                    affectedNodes = hypothesisObjects.take(4).map { nodeId("hypothesis", it.hypothesisId) },
                    severity = gap.severity.coerceIn(0, 100),
                    nextAction = gap.requiredAction,
                    blocksUpgrade = gap.severity >= 70
                )
            )
        }

        val priorNodeIds = prior.nodes.map { it.nodeId }.toSet()
        val priorEdgeKeys = prior.edges.map { edgeKey(it) }.toSet()
        val newNodes = nodes.values.count { it.nodeId !in priorNodeIds }
        val newEdges = edges.values.count { edgeKey(it) !in priorEdgeKeys }
        val mapScore = (nodes.size * 3 + edges.size * 6 + nodes.values.count { it.status == "ACTIVE" } * 4 - gaps.values.count { it.blocksUpgrade } * 5)
            .coerceIn(0, 100)
        val state = when {
            nodes.isEmpty() -> "EMPTY"
            gaps.values.any { it.severity >= 85 && it.blocksUpgrade } -> "MAP_WITH_BLOCKING_GAPS"
            newEdges >= 3 -> "MAP_EXPANDING"
            prior.nodes.isNotEmpty() -> "MAP_CARRIED_FORWARD"
            else -> "MAP_STARTED"
        }
        val changed = buildList {
            add("Carried forward ${prior.nodes.size} prior node(s) and ${prior.edges.size} prior link(s).")
            add("Added $newNodes node(s) and $newEdges link(s) from this cycle.")
            if (gaps.isNotEmpty()) add("Tracked ${gaps.size} open gap(s); ${gaps.values.count { it.blocksUpgrade }} block upgrade.")
            if (datasetForagingReport.queryFeedbackPlan.active) add("Next search should use query feedback instead of restarting broad search.")
        }
        val topGap = gaps.values.maxByOrNull { it.severity }
        val nextAction = topGap?.nextAction
            ?: specializedReasoningReport.decisiveNextTest.takeIf { it.isNotBlank() }
            ?: "Use the highest-weight map links to choose the next dataset/hypothesis route."
        val brief = "Knowledge map: $state; carried ${prior.nodes.size} prior node(s), added $newNodes node(s) and $newEdges link(s). Next: ${nextAction.take(130)}"
        val carried = prior.visibleBrief.takeIf { it.isNotBlank() }?.let { listOf(it) }.orEmpty() + prior.carriedForwardInsights.take(3)

        return KnowledgeMapReport(
            active = true,
            mapScore = mapScore,
            state = state,
            carriedForwardNodes = prior.nodes.size,
            newNodesThisCycle = newNodes,
            newLinksThisCycle = newEdges,
            nodes = nodes.values.sortedWith(compareByDescending<KnowledgeMapNode> { it.score }.thenBy { it.nodeType }).take(80),
            edges = edges.values.sortedByDescending { it.weight + it.supportCount * 5 }.take(120),
            gaps = gaps.values.sortedByDescending { it.severity }.take(24),
            carriedForwardInsights = carried.distinct().take(6),
            changedSincePrevious = changed,
            nextMapAction = nextAction,
            visibleBrief = brief,
            claimLimit = "knowledge_map_not_biological_proof"
        )
    }

    private fun readPriorMap(lines: List<String>): KnowledgeMapReport {
        for (line in lines) {
            val obj = runCatching { JSONObject(line) }.getOrNull() ?: continue
            val map = obj.optJSONObject("knowledgeMapReport") ?: continue
            return KnowledgeMapReport(
                active = map.optBoolean("active", false),
                mapScore = map.optInt("mapScore", 0),
                state = map.optString("state", "PRIOR"),
                carriedForwardNodes = map.optInt("carriedForwardNodes", 0),
                newNodesThisCycle = map.optInt("newNodesThisCycle", 0),
                newLinksThisCycle = map.optInt("newLinksThisCycle", 0),
                nodes = parseNodes(map.optJSONArray("nodes")),
                edges = parseEdges(map.optJSONArray("edges")),
                gaps = parseGaps(map.optJSONArray("gaps")),
                carriedForwardInsights = strings(map.optJSONArray("carriedForwardInsights")),
                changedSincePrevious = strings(map.optJSONArray("changedSincePrevious")),
                nextMapAction = map.optString("nextMapAction", "Continue from prior map."),
                visibleBrief = map.optString("visibleBrief", "Prior knowledge map loaded."),
                claimLimit = map.optString("claimLimit", "knowledge_map_not_biological_proof")
            )
        }
        return KnowledgeMapReport.empty()
    }

    private fun parseNodes(arr: JSONArray?): List<KnowledgeMapNode> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            KnowledgeMapNode(
                nodeId = o.optString("nodeId"),
                nodeType = o.optString("nodeType"),
                label = o.optString("label"),
                score = o.optInt("score"),
                occurrences = o.optInt("occurrences", 1),
                evidenceIds = strings(o.optJSONArray("evidenceIds")),
                status = o.optString("status"),
                summary = o.optString("summary")
            )
        }.filter { it.nodeId.isNotBlank() }
    }

    private fun parseEdges(arr: JSONArray?): List<KnowledgeMapEdge> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            KnowledgeMapEdge(
                fromNode = o.optString("fromNode"),
                toNode = o.optString("toNode"),
                relation = o.optString("relation"),
                weight = o.optInt("weight"),
                supportCount = o.optInt("supportCount", 1),
                status = o.optString("status"),
                rationale = o.optString("rationale")
            )
        }.filter { it.fromNode.isNotBlank() && it.toNode.isNotBlank() }
    }

    private fun parseGaps(arr: JSONArray?): List<KnowledgeMapGap> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            KnowledgeMapGap(
                gapId = o.optString("gapId"),
                affectedNodes = strings(o.optJSONArray("affectedNodes")),
                severity = o.optInt("severity"),
                nextAction = o.optString("nextAction"),
                blocksUpgrade = o.optBoolean("blocksUpgrade", true)
            )
        }.filter { it.gapId.isNotBlank() }
    }

    private fun strings(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    }

    private fun nodeId(type: String, value: String): String = type.lowercase(Locale.US) + ":" + sanitize(value)

    private fun sanitize(value: String): String = value
        .lowercase(Locale.US)
        .replace(Regex("[^a-z0-9_:-]+"), "_")
        .trim('_')
        .take(90)
        .ifBlank { "unknown" }

    private fun edgeKey(edge: KnowledgeMapEdge): String = listOf(edge.fromNode, edge.relation, edge.toNode).joinToString("|")
}
