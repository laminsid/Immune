package com.immunesignal.app

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DiscoveryReportExporter {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US)


    fun exportText(context: Context, report: JSONObject, text: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "immune_discovery_${dateFormat.format(Date())}.txt")
        file.writeText(text.ifBlank { "No report content." })
        return file
    }

    fun export(context: Context, report: JSONObject): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "immune_discovery_${dateFormat.format(Date())}.pdf")
        val pdf = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f }
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; isFakeBoldText = true }
        var pageNum = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNum).create())
        var y = 36f

        fun newPage() {
            pdf.finishPage(page)
            pageNum += 1
            page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNum).create())
            y = 36f
        }

        fun line(text: String, p: Paint = paint) {
            val chunks = wrap(text, if (p == title) 52 else 88)
            for (chunk in chunks) {
                if (y > 805f) newPage()
                page.canvas.drawText(chunk, 32f, y, p)
                y += if (p == title) 22f else 15f
            }
        }

        line("Immune Error Radar — Research Autopilot Discovery Report", title)
        line("Generated: ${report.optString("createdAtText", "")}")
        line("Completed: ${report.optString("completedAtText", "")}")
        line("Stop reason: ${report.optString("stopReason", "completed")}")
        line("Boundary: research leads only. No diagnosis, treatment, drug ranking, or clinical recommendation.")
        val runtime = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val execution = report.optJSONObject("executionLockReport") ?: JSONObject()
        line("Active engine: ${runtime.optString("engineVersion", "unknown")}")
        line("Research state: ${runtime.optString("researchState", "UNKNOWN")}")
        line("Execution lock: ${execution.optString("status", "UNKNOWN")}")
        line("Effective search: ${runtime.optInt("effectiveMaxQueries", 0)} queries x ${runtime.optInt("effectiveResultsPerQuery", 0)} PubMed IDs")
        line("Runtime failover applied: ${runtime.optBoolean("runtimeFailoverApplied", false)}")
        val foragerTop = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        line("Dataset-first forager: ${foragerTop.optString("state", "NOT_RUN")} • mode ${foragerTop.optString("evidenceMode", "unknown")}")
        val topScoreSep = foragerTop.optJSONObject("scoreSeparation") ?: JSONObject()
        line("Score separation: usability ${topScoreSep.optInt("datasetUsabilityScore", 0)}/100 • route-fit ${topScoreSep.optInt("routeFitScore", 0)}/100 • hypothesis ${topScoreSep.optInt("hypothesisConfidenceScore", 0)}/100 • ${topScoreSep.optString("scoreState", "NOT_EVALUATED")}")
        line("Direct sources attempted: ${arrayToString(foragerTop.optJSONArray("sourceFamiliesAttempted"))}")
        y += 8f

        line("Short discovery summary", title)
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val v3 = report.optJSONObject("reportV3") ?: JSONObject()
        line("Cycle result: ${v3.optString("cycleResult", "No cycle result")}")
        line("Integrity lock: ${v3.optString("integrityStatus", "UNKNOWN")}")
        line("Hypothesis: ${v3.optString("hypothesis", "No active hypothesis")}")
        line("Supporting evidence: ${v3.optString("supportingEvidence", "No supporting evidence section")}")
        line("Counter-evidence / contradiction: ${v3.optString("counterEvidenceOrContradiction", "No contradiction section")}")
        line("What we do not believe yet: ${v3.optString("whatWeDoNotBelieveYet", "No unknowns section")}")
        line("Next autonomous move: ${v3.optString("nextAutonomousMove", "Run next cycle")}")
        line("New sources saved: ${delta.optInt("newSourcesSaved", 0)} • Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)} • DNA/RNA signals: ${delta.optInt("dnaRnaSignals", 0)} • Steered queries: ${delta.optInt("steeredQueriesGenerated", 0)} • Manual reports used: ${delta.optInt("manualReportSignalsUsed", 0)}")
        val steering = report.optJSONObject("activeSteeringProfile")
        if (steering != null) {
            line("Research steering", title)
            line("Variables: ${arrayToString(steering.optJSONArray("variables"))}")
            line("Focus: ${steering.optString("focusQuestion", "")}")
            line("Required: ${arrayToString(steering.optJSONArray("requiredTerms"))}")
            line("Excluded: ${arrayToString(steering.optJSONArray("excludedTerms"))}")
            line("Inferred axes: ${arrayToString(steering.optJSONArray("inferredAxes"))}")
        }
        line("New axis pairs:")
        writeArray(delta.optJSONArray("newAxisPairs")) { line("• $it") }
        line("Learning notes:")
        writeArray(delta.optJSONArray("learningNotes")) { line("• $it") }
        y += 8f

        line("Dataset parser & route audit v1.4.3", title)
        val forager = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        line("Active: ${forager.optBoolean("active", false)} • State: ${forager.optString("state", "NOT_RUN")} • Mode: ${forager.optString("evidenceMode", "unknown")}")
        line("Sources attempted: ${arrayToString(forager.optJSONArray("sourceFamiliesAttempted"))}")
        val scoreSep = forager.optJSONObject("scoreSeparation") ?: JSONObject()
        line("Score separation: dataset usability ${scoreSep.optInt("datasetUsabilityScore", 0)}/100 | route fit ${scoreSep.optInt("routeFitScore", 0)}/100 | hypothesis confidence ${scoreSep.optInt("hypothesisConfidenceScore", 0)}/100 | upgrade allowed ${scoreSep.optBoolean("hypothesisUpgradeAllowed", false)}")
        line("Score state: ${scoreSep.optString("scoreState", "NOT_EVALUATED")} — ${scoreSep.optString("summary", "none")}")
        val routeFits = forager.optJSONArray("routeFitAssessments") ?: JSONArray()
        if (routeFits.length() == 0) line("Route-fit gate: not evaluated") else for (i in 0 until routeFits.length().coerceAtMost(5)) {
            val rf = routeFits.optJSONObject(i) ?: continue
            line("• Route-fit ${rf.optString("accession")}: ${rf.optString("status")} • ${rf.optInt("routeFitScore")}/100 • ${rf.optString("datasetRoute")} → ${rf.optString("targetRoute")}")
            line("  Allowed use: ${rf.optString("allowedUse")}")
        }
        line("Blocked learning reason: ${forager.optString("blockedLearningReason", "none")}")
        line("Next action: ${forager.optString("nextAction", "none")}")
        val foragePasses = forager.optJSONArray("passes") ?: JSONArray()
        if (foragePasses.length() == 0) line("Foraging passes: none") else for (i in 0 until foragePasses.length().coerceAtMost(4)) {
            val pass = foragePasses.optJSONObject(i) ?: continue
            line("• ${pass.optString("passId")} — ${pass.optString("status")}")
        }
        val parsed = forager.optJSONArray("parsedMetadata") ?: JSONArray()
        line("Parsed dataset metadata:")
        if (parsed.length() == 0) line("• No parsed metadata yet.") else for (i in 0 until parsed.length().coerceAtMost(5)) {
            val d = parsed.optJSONObject(i) ?: continue
            line("• ${d.optString("accession")} — ${d.optString("usabilityVerdict")} • metadata ${d.optInt("metadataQualityScore")}/100 • ${d.optString("organism")} • ${d.optString("assayType")}")
            line("  Outcome: ${arrayToString(d.optJSONArray("outcomeLabels"))} | Control: ${arrayToString(d.optJSONArray("controlLabels"))} | Contrast: ${arrayToString(d.optJSONArray("contrastiveSlots"))}")
        }
        val contrastive = forager.optJSONObject("contrastiveReport") ?: JSONObject()
        val cumulative = forager.optJSONObject("cumulativeEvidence") ?: JSONObject()
        line("Contrastive gate: ${contrastive.optString("gateStatus", "NOT_EVALUATED")} — ${contrastive.optString("summary", "none")}")
        line("Next contrastive question: ${contrastive.optString("nextContrastiveQuestion", "none")}")
        line("Cumulative evidence: ${cumulative.optInt("score", 0)}/100 ${cumulative.optString("state", "OFF")}")
        val memory = report.optJSONObject("persistentFailureMemory") ?: JSONObject()
        line("Persistent failure memory: ${memory.optString("summary", "none")}")
        y += 8f

        line("Learning OS — root cause, gates, readiness", title)
        val learningOs = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incident = learningOs.optJSONObject("incident") ?: JSONObject()
        val readiness = learningOs.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        line("Root causes: ${arrayToString(incident.optJSONArray("rootCauses"))}")
        line("Observed: ${arrayToString(incident.optJSONArray("observedSignals"))}")
        line("Hypothesis update gate: ${learningOs.optString("hypothesisUpdateGateStatus", "NO_EVIDENCE_OBJECT_NO_UPGRADE")}")
        line("Discovery readiness: ${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")}")
        line("Next learning action: ${learningOs.optString("nextLearningAction", "none")}")
        line("Execution enforced actions: ${arrayToString(execution.optJSONArray("enforcedActions"))}")
        val gates = learningOs.optJSONArray("preventiveGates") ?: JSONArray()
        if (gates.length() == 0) line("Preventive gates: none") else for (i in 0 until gates.length().coerceAtMost(5)) {
            val g = gates.optJSONObject(i) ?: continue
            line("• ${g.optString("gateId")} → ${g.optString("forcedNextIntent")}: ${g.optString("action")}")
        }
        val cooldowns = learningOs.optJSONArray("laneCooldowns") ?: JSONArray()
        if (cooldowns.length() > 0) {
            line("Lane cooldowns:")
            for (i in 0 until cooldowns.length().coerceAtMost(3)) {
                val c = cooldowns.optJSONObject(i) ?: continue
                line("• ${c.optString("laneName")} blocked ${c.optInt("cooldownCycles")} cycles because ${c.optString("lastFailureReason")}")
            }
        }
        y += 8f

        line("Research reasoning — why the next question changed", title)
        val reasoning = report.optJSONObject("reasoningReport") ?: JSONObject()
        line("Observation: ${reasoning.optString("observation", "No reasoning observation yet.")}")
        line("Meaning: ${reasoning.optString("interpretedMeaning", "No interpretation yet.")}")
        line("Generated questions:")
        writeArray(reasoning.optJSONArray("generatedQuestions")) { line("• $it") }
        line("Competing explanations:")
        writeArray(reasoning.optJSONArray("competingHypotheses")) { line("• $it") }
        line("Discriminator evidence needed:")
        writeArray(reasoning.optJSONArray("discriminatorEvidence")) { line("• $it") }
        line("Reframed search: ${reasoning.optString("reframedSearch", "none")}")
        line("Self-critique:")
        writeArray(reasoning.optJSONArray("selfCritique")) { line("• $it") }
        line("Next reasoned move: ${reasoning.optString("nextReasonedMove", "Run next autonomous cycle.")}")
        y += 8f

        line("Specialized reasoning — beyond generic AI", title)
        val specialist = report.optJSONObject("specializedReasoningReport") ?: JSONObject()
        line("State: ${specialist.optString("state", "NOT_EVALUATED")} • Score ${specialist.optInt("specialistScore", 0)}/100")
        line("Weakest link: ${specialist.optString("weakestLink", "none")}")
        line("Strongest improvement: ${specialist.optString("strongestImprovement", "none")}")
        line("Decisive next test: ${specialist.optString("decisiveNextTest", "none")}")
        line("Falsification demand: ${specialist.optString("falsificationDemand", "none")}")
        line("Axis discipline: ${specialist.optString("axisDiscipline", "none")}")
        line("Specialist verdict: ${specialist.optString("specialistVerdict", "none")}")
        line("General-model failure risks:")
        writeArray(specialist.optJSONArray("generalModelFailureRisks")) { line("• $it") }
        val gaps = specialist.optJSONArray("evidenceGaps") ?: JSONArray()
        if (gaps.length() == 0) line("Evidence gaps: none") else for (i in 0 until gaps.length().coerceAtMost(4)) {
            val gap = gaps.optJSONObject(i) ?: continue
            line("• Gap ${gap.optString("gapId")} — ${gap.optString("status")} severity ${gap.optInt("severity")}/100")
            line("  Action: ${gap.optString("requiredAction")}")
        }
        val tournament = specialist.optJSONArray("hypothesisTournament") ?: JSONArray()
        if (tournament.length() > 0) {
            line("Hypothesis tournament:")
            for (i in 0 until tournament.length().coerceAtMost(4)) {
                val card = tournament.optJSONObject(i) ?: continue
                line("• ${card.optString("status")} ${card.optInt("score")}/100 — ${card.optString("label")}")
                line("  Discriminator: ${card.optString("nextDiscriminator")}")
            }
        }
        val protocol = specialist.optJSONArray("nextCycleProtocol") ?: JSONArray()
        if (protocol.length() > 0) {
            line("Next-cycle protocol:")
            writeArray(protocol) { line("• $it") }
        }
        val expertMoves = specialist.optJSONArray("expertMoves") ?: JSONArray()
        if (expertMoves.length() == 0) line("Expert moves: none") else for (i in 0 until expertMoves.length().coerceAtMost(6)) {
            val move = expertMoves.optJSONObject(i) ?: continue
            line("• ${move.optString("name")} — ${move.optString("status")} ${move.optInt("score")}/100")
            line("  Finding: ${move.optString("finding")}")
            line("  Next: ${move.optString("nextAction")}")
        }
        line("Claim limit: ${specialist.optString("claimLimit", "specialized_reasoning_not_biological_proof")}")
        y += 8f

        line("Epistemic belief model", title)
        val belief = report.optJSONObject("epistemicBeliefReport") ?: JSONObject()
        line("State: ${belief.optString("state", "NOT_BUILT")} • Score ${belief.optInt("beliefScore", 0)}/100")
        line("Brief: ${belief.optString("visibleBrief", "No belief model yet.")}")
        line("Carried: ${belief.optInt("carriedForwardBeliefs", 0)} belief(s) • New: ${belief.optInt("newBeliefsThisCycle", 0)} • Weakened: ${belief.optInt("weakenedBeliefs", 0)} • Revise: ${belief.optInt("revisedBeliefs", 0)}")
        val transitionSummary = belief.optJSONObject("transitionSummary") ?: JSONObject()
        line("Strengthened belief: ${transitionSummary.optString("strengthenedBelief", "None this cycle.")}")
        line("Weakened belief: ${transitionSummary.optString("weakenedBelief", "None this cycle.")}")
        line("Dropped belief: ${transitionSummary.optString("droppedBelief", "None this cycle.")}")
        line("Belief abandonment test: ${transitionSummary.optString("abandonmentQuestion", "What evidence would make me abandon this belief?")}")
        line("Pruning rule: ${transitionSummary.optString("pruningRule", "Weak unused beliefs are not carried forward.")}")
        line("Next belief action: ${belief.optString("nextBeliefAction", "Use beliefs as mutable search priors only.")}")
        val beliefUpdates = belief.optJSONArray("updates") ?: JSONArray()
        if (beliefUpdates.length() == 0) line("Belief updates: none") else for (i in 0 until beliefUpdates.length().coerceAtMost(4)) {
            val update = beliefUpdates.optJSONObject(i) ?: continue
            line("• ${update.optString("updateType")} ${update.optString("previousStatus")} → ${update.optString("newStatus")} — ${update.optString("beliefId")}")
            line("  Next: ${update.optString("nextAction")}")
        }
        val beliefItems = belief.optJSONArray("beliefs") ?: JSONArray()
        if (beliefItems.length() > 0) {
            line("Top mutable beliefs:")
            for (i in 0 until beliefItems.length().coerceAtMost(5)) {
                val item = beliefItems.optJSONObject(i) ?: continue
                line("• ${item.optString("status")} c=${item.optInt("credibility")}/100 — ${item.optString("statement")}")
                line("  Abandon if: ${item.optString("abandonmentQuestion", "What evidence would make me abandon this belief?")}")
            }
        }
        line("Claim limit: ${belief.optString("claimLimit", "epistemic_beliefs_not_biological_proof")}")
        y += 8f

        line("Cognitive path integration", title)
        val cognitivePath = report.optJSONObject("cognitivePathIntegrationReport") ?: JSONObject()
        line("State: ${cognitivePath.optString("state", "NOT_BUILT")} • Score ${cognitivePath.optInt("integrationScore", 0)}/100")
        line("Route integrity: ${cognitivePath.optString("routeIntegrity", "NOT_EVALUATED")}")
        line("Brief: ${cognitivePath.optString("visibleBrief", "No linked path yet.")}")
        val pathDecision = cognitivePath.optJSONObject("decision") ?: JSONObject()
        line("Decision: ${pathDecision.optString("decisionType", "NO_DECISION")} • blocks upgrade=${pathDecision.optBoolean("blocksHypothesisUpgrade", true)}")
        line("Next linked action: ${pathDecision.optString("action", "Use linked path for next cycle.")}")
        val requiredEvidence = pathDecision.optJSONArray("requiredEvidence") ?: JSONArray()
        if (requiredEvidence.length() > 0) {
            line("Required evidence from linked path:")
            writeArray(requiredEvidence) { line("• $it") }
        }
        val pathLinks = cognitivePath.optJSONArray("links") ?: JSONArray()
        if (pathLinks.length() > 0) {
            line("Integrated links:")
            for (i in 0 until pathLinks.length().coerceAtMost(4)) {
                val link = pathLinks.optJSONObject(i) ?: continue
                line("• ${link.optString("relation")} ${link.optInt("strength")}/100: ${link.optString("fromId")} → ${link.optString("toId")}")
            }
        }
        line("Claim limit: ${cognitivePath.optString("claimLimit", "cognitive_path_integration_not_biological_proof")}")
        val nextCyclePlan = report.optJSONObject("cognitiveNextCyclePlan") ?: JSONObject()
        if (nextCyclePlan.optBoolean("active", false) || nextCyclePlan.optBoolean("directiveConsumed", false)) {
            line("Closed cognitive loop for next cycle", title)
            line("Summary: ${nextCyclePlan.optString("summary", "No next-cycle directive applied.")}")
            line("Directive: ${nextCyclePlan.optString("directiveId", "none")} • follow-up=${nextCyclePlan.optBoolean("addedFollowUpQuery", false)} • consumed=${nextCyclePlan.optBoolean("directiveConsumed", false)}")
            val consumptionReason = nextCyclePlan.optString("consumptionReason")
            if (consumptionReason.isNotBlank()) line("Consumption reason: $consumptionReason")
            val appliedTerms = nextCyclePlan.optJSONArray("appliedTerms") ?: JSONArray()
            if (appliedTerms.length() > 0) {
                line("Terms carried into next search:")
                writeArray(appliedTerms) { line("• $it") }
            }
            line("Claim limit: ${nextCyclePlan.optString("claimLimit", "next_cycle_routing_only_not_biological_proof")}")
        }
        val loopCalibration = report.optJSONObject("cognitiveLoopCalibrationReport") ?: JSONObject()
        if (loopCalibration.optBoolean("active", false)) {
            line("Cognitive loop calibration", title)
            line("Outcome: ${loopCalibration.optString("outcome", "MIXED_PROGRESS")} • Score ${loopCalibration.optInt("calibrationScore", 0)}/100")
            line("Brief: ${loopCalibration.optString("visibleBrief", "The previous linked path was evaluated.")}")
            line("Next calibration action: ${loopCalibration.optString("nextCalibrationAction", "Keep the next loop bounded.")}")
            val improved = loopCalibration.optJSONArray("improvedSignals") ?: JSONArray()
            if (improved.length() > 0) {
                line("Improved signals:")
                for (i in 0 until improved.length().coerceAtMost(4)) {
                    val item = improved.optJSONObject(i) ?: continue
                    line("• ${item.optString("name")} +${item.optInt("score")}: ${item.optString("reason")}")
                }
            }
            val stalled = loopCalibration.optJSONArray("stalledSignals") ?: JSONArray()
            if (stalled.length() > 0) {
                line("Stalled signals:")
                for (i in 0 until stalled.length().coerceAtMost(4)) {
                    val item = stalled.optJSONObject(i) ?: continue
                    line("• ${item.optString("name")} -${item.optInt("score")}: ${item.optString("reason")}")
                }
            }
            line("Claim limit: ${loopCalibration.optString("claimLimit", "cognitive_loop_calibration_not_biological_proof")}")
        }
        y += 8f

        line("Cumulative knowledge map", title)
        val knowledgeMap = report.optJSONObject("knowledgeMapReport") ?: JSONObject()
        line("State: ${knowledgeMap.optString("state", "NOT_BUILT")} • Score ${knowledgeMap.optInt("mapScore", 0)}/100")
        line("Brief: ${knowledgeMap.optString("visibleBrief", "No cumulative map yet.")}")
        line("Carried: ${knowledgeMap.optInt("carriedForwardNodes", 0)} node(s) • New nodes: ${knowledgeMap.optInt("newNodesThisCycle", 0)} • New links: ${knowledgeMap.optInt("newLinksThisCycle", 0)}")
        line("Next map action: ${knowledgeMap.optString("nextMapAction", "Run next search with accumulated context.")}")
        val mapGaps = knowledgeMap.optJSONArray("gaps") ?: JSONArray()
        if (mapGaps.length() == 0) line("Map gaps: none") else for (i in 0 until mapGaps.length().coerceAtMost(4)) {
            val gap = mapGaps.optJSONObject(i) ?: continue
            line("• ${gap.optString("gapId")} — severity ${gap.optInt("severity")}/100; blocks=${gap.optBoolean("blocksUpgrade")}")
            line("  Next: ${gap.optString("nextAction")}")
        }
        val mapEdges = knowledgeMap.optJSONArray("edges") ?: JSONArray()
        if (mapEdges.length() > 0) {
            line("Top map links:")
            for (i in 0 until mapEdges.length().coerceAtMost(5)) {
                val edge = mapEdges.optJSONObject(i) ?: continue
                line("• ${edge.optString("relation")} ${edge.optInt("weight")}/100: ${edge.optString("fromNode")} → ${edge.optString("toNode")}")
            }
        }
        line("Claim limit: ${knowledgeMap.optString("claimLimit", "knowledge_map_not_biological_proof")}")
        y += 8f

                line("Research lock summary", title)
        val summary = report.optJSONObject("researchStateSummary") ?: JSONObject()
        line("Discovery State: ${summary.optString("discoveryState", "Off")} • Bias Risk: ${summary.optString("biasRiskState", "Normal")}")
        line("Next Evidence: ${summary.optString("nextEvidence", "none")}")
        line("Discovery Action: ${summary.optString("discoveryAction", "none")}")
        line("Bias Alarm: ${summary.optString("biasAlarm", "Normal")}")
        y += 8f

        line("Global immune dataset intelligence", title)
        val global = report.optJSONObject("globalImmuneIntelligence") ?: JSONObject()
        line("Mode: ${global.optString("mode", "global_dataset_intelligence")}")
        line("Next dataset needed: ${global.optString("nextGlobalDatasetNeeded", "none")}")
        line("Global action: ${global.optString("globalDiscoveryAction", "none")}")
        line("Global bias alarm: ${global.optString("globalBiasAlarm", "Normal")}")
        val datasets = global.optJSONArray("datasetCandidates") ?: JSONArray()
        line("Dataset candidates:")
        if (datasets.length() == 0) line("• No dataset candidate yet.") else for (i in 0 until datasets.length().coerceAtMost(6)) {
            val d = datasets.optJSONObject(i) ?: continue
            line("• ${d.optString("datasetId")} — ${d.optString("condition")} / ${d.optString("dataType")} / quality ${d.optInt("qualityScore")}/100")
        }
        val globalHypotheses = global.optJSONArray("globalHypotheses") ?: JSONArray()
        line("Global hypothesis ledger:")
        if (globalHypotheses.length() == 0) line("• No global hypothesis lead yet.") else for (i in 0 until globalHypotheses.length().coerceAtMost(5)) {
            val h = globalHypotheses.optJSONObject(i) ?: continue
            line("• ${h.optString("status")} — ${h.optString("hypothesisId")} | Trust ${h.optInt("dataTrustScore")}/100 | Evidence ${ScoreFormat.oneDecimal(h.optDouble("evidenceScore10"))}/10")
            line("  Q: ${h.optString("question")}")
            line("  Need: ${h.optString("nextDatasetNeeded")}")
        }
        y += 8f

        line("Hypothesis objects — gates, states, falsification", title)
        val objects = report.optJSONArray("hypothesisObjects") ?: JSONArray()
        if (objects.length() == 0) {
            line("No locked hypothesis objects yet.")
        } else {
            for (i in 0 until objects.length()) {
                val h = objects.optJSONObject(i) ?: continue
                line("${i + 1}. ${h.optString("status")} / ${h.optString("discoveryState")} — ${h.optString("label")}")
                line("   Trust ${h.optInt("dataTrustScore")}/100 • Evidence ${ScoreFormat.oneDecimal(h.optDouble("evidenceScore10"))}/10 • Causality ${h.optInt("causalityScore")}/100 • Bias ${h.optString("biasRiskState")}")
                line("   Gate: ${h.optString("minimumDataPackStatus")} • Flip: ${h.optString("signalFlip")}")
                line("   Impact: ${h.optString("decisionImpact")}")
                line("   Next: ${h.optString("nextBestMeasurement")}")
            }
        }
        y += 8f

        line("Learning deltas + mistake risks", title)
        val deltas = report.optJSONArray("learningDeltaCards") ?: JSONArray()
        if (deltas.length() == 0) line("No delta cards yet.") else for (i in 0 until deltas.length()) {
            val d = deltas.optJSONObject(i) ?: continue
            line("• ${d.optString("deltaType")} — ${d.optString("hypothesisId")}: ${d.optString("decisionImpact")}")
        }
        val mistakes = report.optJSONArray("mistakeRiskCards") ?: JSONArray()
        if (mistakes.length() == 0) line("No mistake risks yet.") else for (i in 0 until mistakes.length()) {
            val m = mistakes.optJSONObject(i) ?: continue
            line("• Risk: ${m.optString("risk")}")
            line("  Gate: ${m.optString("preventionGate")}")
        }
        y += 8f

        line("Hypothesis ranking — Evidence & causal learning", title)
        val cards = report.optJSONArray("hypothesisRankCards") ?: JSONArray()
        if (cards.length() == 0) {
            line("No ranked hypotheses yet.")
        } else {
            for (i in 0 until cards.length()) {
                val c = cards.optJSONObject(i) ?: continue
                line("${i + 1}. ${c.optString("status")} — ${c.optString("label")}")
                line("   Overall ${c.optInt("overallScore")}/100 • Evidence ${c.optInt("evidenceQualityScore")}/100 • Causality ${c.optInt("causalityScore")}/100 • Repeatability ${c.optInt("personalRepeatability")}")
                line("   Negative control: ${c.optString("negativeControlStatus")}")
                line("   Next measurement: ${c.optString("nextBestMeasurement")}")
            }
        }
        y += 8f

        line("Emergent links", title)
        writeArray(report.optJSONArray("emergentLinks")) { line("• $it") }
        y += 8f

        line("Imported report signals", title)
        val imported = report.optJSONArray("importedReportSignals") ?: JSONArray()
        if (imported.length() == 0) {
            line("No imported report signals used.")
        } else {
            for (i in 0 until imported.length()) {
                val r = imported.optJSONObject(i) ?: continue
                line("• ${r.optString("title")} — axes: ${arrayToString(r.optJSONArray("matchedAxes"))}")
            }
        }
        y += 8f

        line("Dataset acquisition + parser candidates v1.4.3", title)
        val ds137 = report.optJSONArray("datasetCandidatesV137") ?: JSONArray()
        if (ds137.length() == 0) line("No dataset accession candidate yet.") else for (i in 0 until ds137.length().coerceAtMost(8)) {
            val d = ds137.optJSONObject(i) ?: continue
            line("• ${d.optString("accession")} — ${d.optString("source")} • usability ${d.optInt("usabilityScore")}/100 • ${d.optString("status")}")
            line("  ${d.optString("organismHint")} | ${d.optString("conditionLabelsHint")} | ${d.optString("outcomeLabelsHint")}")
        }
        y += 8f

        line("Route-fit gate details", title)
        val routeGateDetails = (report.optJSONObject("datasetForagingReport") ?: JSONObject()).optJSONArray("routeFitAssessments") ?: JSONArray()
        if (routeGateDetails.length() == 0) line("No route-fit assessment yet.") else for (i in 0 until routeGateDetails.length().coerceAtMost(8)) {
            val r = routeGateDetails.optJSONObject(i) ?: continue
            line("• ${r.optString("accession")} — ${r.optString("status")} • fit ${r.optInt("routeFitScore")}/100 • blocks upgrade ${r.optBoolean("blocksHypothesisUpgrade")}")
            line("  ${r.optString("datasetRoute")} → ${r.optString("targetRoute")}")
        }
        y += 8f

        line("Evidence objects", title)
        val evObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        if (evObjects.length() == 0) line("No evidence object yet.") else for (i in 0 until evObjects.length().coerceAtMost(8)) {
            val e = evObjects.optJSONObject(i) ?: continue
            line("• ${e.optString("decisionImpact")} • quality ${e.optInt("qualityScore")}/100 — ${e.optString("title")}")
            line("  Accessions: ${arrayToString(e.optJSONArray("accessionIds"))} | contradiction ${e.optBoolean("contradictsHypothesis")} | control ${e.optBoolean("hasNegativeControl")}")
        }
        y += 8f

        line("Top findings", title)
        val findings = report.optJSONArray("findings") ?: JSONArray()
        for (i in 0 until findings.length()) {
            val f = findings.optJSONObject(i) ?: continue
            line("${i + 1}. ${f.optString("title")}")
            line("   Source: ${f.optString("source")} ${f.optString("sourceId")} • ${f.optString("published")} • novelty ${f.optInt("noveltyScore")}/100")
            val ev = f.optJSONObject("evidence") ?: JSONObject()
            val ca = f.optJSONObject("causality") ?: JSONObject()
            val neg = f.optJSONObject("negativeControl") ?: JSONObject()
            val pp = f.optJSONObject("personalPattern") ?: JSONObject()
            line("   Evidence: ${ev.optInt("evidenceQualityScore")}/100 • ${ev.optString("speciesClass", "unknown")} • ${ev.optString("studyDesign", "unknown")}")
            line("   Causality: ${ca.optInt("causalityScore")}/100 • Negative control: ${neg.optString("status", "unknown")} • Local repeats: ${pp.optInt("repeatedObservationCount", 0)}")
            line("   Bridge: ${f.optString("bridgeSignal")}")
            line("   Why it matters: ${f.optString("whyItMatters")}")
            line("   URL: ${f.optString("url")}")
            y += 5f
        }

        line("Next research questions", title)
        writeArray(report.optJSONArray("nextQuestions")) { line("• $it") }
        y += 8f

        line("Limitations", title)
        writeArray(report.optJSONArray("limitations")) { line("• $it") }

        pdf.finishPage(page)
        file.outputStream().use { pdf.writeTo(it) }
        pdf.close()
        return file
    }

    private fun writeArray(array: JSONArray?, writer: (String) -> Unit) {
        if (array == null || array.length() == 0) {
            writer("No items.")
            return
        }
        for (i in 0 until array.length()) writer(array.optString(i))
    }

    private fun arrayToString(array: JSONArray?): String {
        if (array == null || array.length() == 0) return "none"
        return (0 until array.length()).joinToString(", ") { array.optString(it) }
    }

    private fun wrap(text: String, max: Int): List<String> {
        val words = text.replace('\n', ' ').split(" ")
        val out = mutableListOf<String>()
        var current = ""
        words.forEach { word ->
            if ((current.length + word.length + 1) > max) {
                if (current.isNotBlank()) out += current
                current = word
            } else {
                current = if (current.isBlank()) word else "$current $word"
            }
        }
        if (current.isNotBlank()) out += current
        return out.ifEmpty { listOf("") }
    }
}
