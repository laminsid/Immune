# Release hygiene generated-artifacts fix — v2.6.3

This patch removes generated Python bytecode/cache artifacts from the distributable ZIP:

- `scripts/__pycache__/`
- `*.pyc`
- `*.pyo`

Reason: these files are local build/runtime artifacts and must not ship in release archives. The existing release hygiene audit correctly fails when they are present.
