package com.immunesignal.app

import java.util.Locale

data class GTIMExposomeImmuneBridgeCardV267(
    val id: String,
    val label: String,
    val exposureDomain: String,
    val immuneAxes: List<String>,
    val differentiatorGates: List<String>,
    val requiredExposureEvidence: List<String>,
    val requiredComparatorEvidence: List<String>,
    val querySeeds: List<String>,
    val upgradeBlockers: List<String>,
    val state: String = "EXPOSOME_IMMUNE_RESEARCH_PATH_ACTIVE",
    val claimLimit: String = GTIMExposomeImmuneBridgeV267.CLAIM_LIMIT
)

data class GTIMExposomeImmuneBridgeReportV267(
    val active: Boolean,
    val cards: List<GTIMExposomeImmuneBridgeCardV267>,
    val mandatoryDomainsCovered: List<String>,
    val missingMandatoryDomains: List<String>,
    val closureState: String,
    val nextAction: String,
    val claimLimit: String = GTIMExposomeImmuneBridgeV267.CLAIM_LIMIT
)

/**
 * v2.6.7: exposome-to-immune bridge closure.
 *
 * Opens bounded research routes for digestive/gut, endocrine/hormone, food pesticide,
 * livestock antibiotic-residue, water heavy-metal, and plastic/microplastic exposure axes.
 * This is exposure-route planning only: no dietary advice, diagnosis, treatment, or exposure
 * attribution is produced without measured exposure metadata and comparator/matrix gates.
 */
object GTIMExposomeImmuneBridgeV267 {
    const val VERSION: String = "2.7.3-final-proof-benchmark-learning-locked"
    const val CLAIM_LIMIT: String = "exposome_immune_bridges_research_leads_only_not_diagnosis_treatment_or_exposure_attribution"

    private val mandatoryDomainIds = listOf(
        "gut_digestive_microbiome_barrier",
        "endocrine_hormone_immune_axis",
        "food_pesticide_residue_immune_axis",
        "livestock_antibiotic_residue_microbiome_axis",
        "water_heavy_metal_immune_axis",
        "plastic_microplastic_endocrine_immune_axis"
    )

    private val cards = listOf(
        GTIMExposomeImmuneBridgeCardV267(
            id = "gut_digestive_microbiome_barrier_bridge",
            label = "Digestive system ↔ microbiome/barrier ↔ immune activation",
            exposureDomain = "gut_digestive_microbiome_barrier",
            immuneAxes = listOf("mucosal immunity", "intestinal permeability", "dysbiosis", "Th17/Treg balance", "IgA", "calprotectin"),
            differentiatorGates = listOf("stool/microbiome assay vs blood-only signal", "diet/antibiotic/probiotic metadata", "IBD/IBS/infection separation", "timepoint after exposure", "fecal vs plasma biomarker context"),
            requiredExposureEvidence = listOf("gut symptom/phenotype label", "diet or medication exposure metadata", "stool/biopsy/blood source", "microbiome or barrier marker", "timepoint"),
            requiredComparatorEvidence = listOf("healthy/matched control", "disease control", "baseline/pre-post comparator", "stool or mucosal matrix availability"),
            querySeeds = listOf(
                "gut microbiome intestinal permeability mucosal immunity Th17 Treg IgA calprotectin RNA-seq microbiome comparator dataset",
                "dysbiosis gut barrier immune activation stool microbiome PBMC transcriptome healthy controls data availability"
            ),
            upgradeBlockers = listOf("gut term without matrix source", "microbiome association treated as immune causality", "no control group", "no medication/diet metadata")
        ),
        GTIMExposomeImmuneBridgeCardV267(
            id = "endocrine_hormone_immune_axis_bridge",
            label = "Hormones/endocrine axis ↔ immune regulation",
            exposureDomain = "endocrine_hormone_immune_axis",
            immuneAxes = listOf("HPA axis", "cortisol", "sex hormones", "thyroid hormones", "insulin/metabolic inflammation", "cytokine regulation"),
            differentiatorGates = listOf("measured hormone vs inferred stress", "circadian/time-of-day metadata", "sex/age stratification", "endocrine disease separation", "metabolic confounder control"),
            requiredExposureEvidence = listOf("measured cortisol/thyroid/insulin/sex hormone", "collection time", "sex/age metadata", "endocrine phenotype", "medication exposure"),
            requiredComparatorEvidence = listOf("matched endocrine status", "baseline/pre-post comparator", "cytokine or cell-subset matrix", "clinical/metabolic covariates"),
            querySeeds = listOf(
                "cortisol HPA axis cytokine immune transcriptome PBMC endocrine comparator dataset",
                "thyroid hormone insulin estrogen androgen immune regulation cytokine profiling RNA-seq healthy controls"
            ),
            upgradeBlockers = listOf("hormone claim without measured hormone", "no time-of-day metadata", "stress narrative used as biological proof", "sex/age confounding unhandled")
        ),
        GTIMExposomeImmuneBridgeCardV267(
            id = "food_pesticide_residue_immune_axis_bridge",
            label = "Food pesticide residues ↔ immune/inflammatory signaling",
            exposureDomain = "food_pesticide_residue_immune_axis",
            immuneAxes = listOf("xenobiotic response", "oxidative stress", "innate inflammation", "barrier disruption", "cytokine shift", "microbiome perturbation"),
            differentiatorGates = listOf("measured pesticide/metabolite vs general food concern", "compound class separation", "dose/exposure window", "food matrix/source", "occupational vs dietary exposure"),
            requiredExposureEvidence = listOf("pesticide/metabolite measurement", "compound/class label", "food/dietary or occupational route", "dose/window proxy", "sample matrix"),
            requiredComparatorEvidence = listOf("exposed/unexposed comparator", "low/high exposure strata", "negative/control compound", "immune readout matrix"),
            querySeeds = listOf(
                "pesticide residue organophosphate glyphosate pyrethroid immune cytokine transcriptome microbiome exposed unexposed dataset",
                "dietary pesticide metabolite inflammation oxidative stress PBMC RNA-seq cohort data availability comparator"
            ),
            upgradeBlockers = listOf("pesticide mention without measured exposure", "compound classes merged as one mechanism", "occupational and dietary routes conflated", "no dose/window metadata")
        ),
        GTIMExposomeImmuneBridgeCardV267(
            id = "livestock_antibiotic_residue_microbiome_axis_bridge",
            label = "Antibiotic exposure/residues in poultry/livestock chain ↔ microbiome/immune axis",
            exposureDomain = "livestock_antibiotic_residue_microbiome_axis",
            immuneAxes = listOf("microbiome disruption", "resistome", "mucosal immunity", "Treg/Th17 balance", "barrier inflammation", "metabolic immune signaling"),
            differentiatorGates = listOf("therapeutic antibiotic use vs food-chain residue hypothesis", "residue measurement required", "animal product route", "resistome/microbiome matrix", "diet and medication confounding"),
            requiredExposureEvidence = listOf("antibiotic class/residue or recent antibiotic metadata", "food-chain route or medication route label", "stool microbiome/resistome", "time window", "diet metadata"),
            requiredComparatorEvidence = listOf("pre/post antibiotic comparator", "exposed/unexposed food-chain comparator", "resistome or microbiome matrix", "immune marker/cytokine readout"),
            querySeeds = listOf(
                "antibiotic residues poultry livestock microbiome resistome mucosal immunity Th17 Treg dataset",
                "food chain antibiotic exposure gut microbiome immune cytokine cohort exposed unexposed data availability"
            ),
            upgradeBlockers = listOf("food residue assumed without measurement", "therapeutic and dietary exposure conflated", "no microbiome/resistome matrix", "no time-window metadata")
        ),
        GTIMExposomeImmuneBridgeCardV267(
            id = "water_heavy_metal_immune_axis_bridge",
            label = "Heavy metals in water ↔ immune and inflammatory signaling",
            exposureDomain = "water_heavy_metal_immune_axis",
            immuneAxes = listOf("oxidative stress", "innate inflammation", "neuroimmune axis", "autoimmunity risk context", "mitochondrial stress", "barrier injury"),
            differentiatorGates = listOf("measured water or biospecimen level", "metal-specific separation", "chronic vs acute exposure", "kidney/liver/neuroimmune covariates", "geographic/source-water metadata"),
            requiredExposureEvidence = listOf("lead/mercury/arsenic/cadmium measurement", "water source or biomonitoring matrix", "duration/window", "geographic/source metadata", "biospecimen type"),
            requiredComparatorEvidence = listOf("low/high exposure strata", "matched geography control", "immune marker matrix", "negative/control metal if available"),
            querySeeds = listOf(
                "lead mercury arsenic cadmium drinking water immune inflammation cytokine transcriptome exposed unexposed dataset",
                "heavy metal exposure PBMC RNA-seq oxidative stress immune cohort water source biomonitoring comparator"
            ),
            upgradeBlockers = listOf("heavy metal concern without measured level", "different metals merged into one mechanism", "no source-water or biomonitoring matrix", "geography confounding unhandled")
        ),
        GTIMExposomeImmuneBridgeCardV267(
            id = "plastic_microplastic_endocrine_immune_axis_bridge",
            label = "Plastics/microplastics/plasticizers ↔ endocrine/immune disruption",
            exposureDomain = "plastic_microplastic_endocrine_immune_axis",
            immuneAxes = listOf("endocrine disruption", "barrier inflammation", "macrophage activation", "oxidative stress", "xenobiotic response", "microbiome perturbation"),
            differentiatorGates = listOf("microplastic particle vs chemical plasticizer", "measured BPA/phthalate/PFAS or particle burden", "matrix/source label", "endocrine vs immune readout separation", "dose/window metadata"),
            requiredExposureEvidence = listOf("BPA/phthalate/PFAS or microplastic measurement", "particle/chemical class", "biospecimen or environmental matrix", "exposure window", "source route"),
            requiredComparatorEvidence = listOf("exposed/unexposed comparator", "low/high exposure strata", "endocrine marker", "immune marker or transcriptome matrix"),
            querySeeds = listOf(
                "microplastics BPA phthalates PFAS endocrine immune inflammation transcriptome exposed unexposed cohort dataset",
                "plasticizer exposure cytokine macrophage oxidative stress microbiome immune PBMC RNA-seq data availability"
            ),
            upgradeBlockers = listOf("plastic exposure assumed without measurement", "particle and chemical exposure conflated", "no immune/endocrine readout", "no dose/window metadata")
        )
    )

    private val hardDomainTerms = listOf(
        "gut", "digestive", "gastrointestinal", "intestinal", "microbiome", "stool", "fecal", "barrier",
        "hormone", "hormones", "endocrine", "cortisol", "insulin", "thyroid", "estrogen", "androgen",
        "pesticide", "pesticides", "glyphosate", "organophosphate", "pyrethroid", "residue", "residues",
        "antibiotic", "antibiotics", "poultry", "livestock", "chicken", "meat", "resistome",
        "heavy metal", "heavy metals", "lead", "mercury", "arsenic", "cadmium", "drinking water", "water",
        "plastic", "plastics", "microplastic", "microplastics", "bpa", "phthalate", "phthalates", "pfas", "plasticizer"
    )

    private val lowSignalTokens = setOf(
        "immune", "immunity", "inflammation", "dataset", "cohort", "human", "control", "comparator", "exposure", "axis", "bridge"
    )

    private fun containsPhrase(text: String, phrase: String): Boolean {
        val escaped = phrase.lowercase(Locale.US)
            .trim()
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .joinToString("\\s+") { Regex.escape(it) }
        return escaped.isNotBlank() && Regex("(^|[^a-z0-9])$escaped([^a-z0-9]|$)").containsMatchIn(text)
    }

    fun cardsForText(text: String): List<GTIMExposomeImmuneBridgeCardV267> {
        val t = text.lowercase(Locale.US)
        val hardHit = hardDomainTerms.any { containsPhrase(t, it) }
        if (!hardHit) return emptyList()
        val matched = cards.filter { card ->
            val haystack = (listOf(card.id, card.label, card.exposureDomain) + card.immuneAxes + card.querySeeds)
                .joinToString(" ")
                .lowercase(Locale.US)
            haystack.split(' ', '/', '-', '↔', ',', ';', ':', '(', ')')
                .map { it.trim() }
                .filter { token -> token.length >= 4 && token !in lowSignalTokens }
                .any { token -> containsPhrase(t, token) }
        }
        return matched.ifEmpty { cards.take(3) }.distinctBy { it.id }.take(6)
    }

    fun closeCycle(text: String): GTIMExposomeImmuneBridgeReportV267 {
        val selected = cardsForText(text)
        val covered = mandatoryDomainIds.filter { domain -> selected.any { it.exposureDomain == domain } }
        val missing = mandatoryDomainIds - covered.toSet()
        val state = when {
            selected.isEmpty() -> "NO_EXPOSOME_IMMUNE_PATH_TRIGGERED"
            missing.isEmpty() -> "EXPOSOME_IMMUNE_CYCLE_CLOSED"
            else -> "EXPOSOME_IMMUNE_CYCLE_PARTIAL"
        }
        val next = when (state) {
            "EXPOSOME_IMMUNE_CYCLE_CLOSED" -> "Run exposure-metadata-first public lookup; keep routes exploratory until measured exposure, comparator, matrix, and contradiction gates close."
            "EXPOSOME_IMMUNE_CYCLE_PARTIAL" -> "Open missing exposure domain(s) if the question asks for a full exposome scan: ${missing.joinToString(", ")}."
            else -> "No gut/endocrine/food-water-plastic exposome bridge requested; keep normal learning loop."
        }
        return GTIMExposomeImmuneBridgeReportV267(
            active = selected.isNotEmpty(),
            cards = selected,
            mandatoryDomainsCovered = covered,
            missingMandatoryDomains = missing,
            closureState = state,
            nextAction = next
        )
    }

    fun querySeedsForText(text: String): List<String> = cardsForText(text)
        .flatMap { it.querySeeds }
        .distinct()
        .take(12)

    fun oneLine(report: GTIMExposomeImmuneBridgeReportV267): String =
        "${report.closureState}; cards=${report.cards.size}; covered=${report.mandatoryDomainsCovered.size}/6; next=${report.nextAction.take(160)}"
}
