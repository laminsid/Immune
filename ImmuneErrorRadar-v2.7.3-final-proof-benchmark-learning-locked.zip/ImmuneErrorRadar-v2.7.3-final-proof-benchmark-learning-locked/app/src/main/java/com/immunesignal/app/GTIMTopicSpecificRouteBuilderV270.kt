package com.immunesignal.app

import java.util.Locale

/**
 * v2.7.0 / patch-compatible with the 2.6.8 release train.
 *
 * Opens a bounded, topic-specific research route whenever the user changes topic or enters a
 * new disease/exposure/pathogen. This is a route builder and learning-prior generator only:
 * it never upgrades evidence, never closes matrix/contradiction gates, and never makes clinical
 * claims. It exists to prevent the engine from reusing a dominant old route such as stress/HPA
 * when the user asks for a new topic such as Hantavirus.
 */
data class GTIMTopicRouteProfileV270(
    val topicId: String,
    val displayName: String,
    val matchTerms: List<String>,
    val diseasePhenotype: List<String>,
    val triggerExposure: List<String>,
    val corePathways: List<String>,
    val cellTissue: List<String>,
    val assayTargets: List<String>,
    val comparatorTargets: List<String>,
    val routeCascade: List<String>,
    val hypotheses: List<String>,
    val differentiatorGates: List<String>,
    val querySeeds: List<String>,
    val connectedDotEdges: List<String>,
    val learningTasks: List<String>,
    val upgradeBlockers: List<String>,
    val claimLimit: String = GTIMTopicSpecificRouteBuilderV270.CLAIM_LIMIT
)

data class GTIMTopicRoutePlanV270(
    val active: Boolean,
    val version: String,
    val status: String,
    val primaryTopicId: String,
    val topicTitle: String,
    val topicShiftDetected: Boolean,
    val matchedProfiles: List<String>,
    val routeCascade: List<String>,
    val hypotheses: List<String>,
    val querySeeds: List<String>,
    val comparatorTargets: List<String>,
    val matrixTargets: List<String>,
    val differentiatorGates: List<String>,
    val connectedDotEdges: List<String>,
    val learningTasks: List<String>,
    val upgradeBlockers: List<String>,
    val nextAction: String,
    val claimLimit: String = GTIMTopicSpecificRouteBuilderV270.CLAIM_LIMIT
) {
    companion object {
        fun empty(): GTIMTopicRoutePlanV270 = GTIMTopicRoutePlanV270(
            active = false,
            version = GTIMTopicSpecificRouteBuilderV270.VERSION,
            status = "TOPIC_ROUTE_NOT_OPENED",
            primaryTopicId = "none",
            topicTitle = "No topic-specific route",
            topicShiftDetected = false,
            matchedProfiles = emptyList(),
            routeCascade = emptyList(),
            hypotheses = emptyList(),
            querySeeds = emptyList(),
            comparatorTargets = emptyList(),
            matrixTargets = GTIMTopicSpecificRouteBuilderV270.DEFAULT_MATRIX_TARGETS,
            differentiatorGates = emptyList(),
            connectedDotEdges = emptyList(),
            learningTasks = emptyList(),
            upgradeBlockers = emptyList(),
            nextAction = "Parse a topic before opening a topic-specific route."
        )
    }
}

object GTIMTopicSpecificRouteBuilderV270 {
    const val VERSION: String = "2.7.3-final-proof-benchmark-learning-locked"
    const val RELEASE_COMPAT_VERSION: String = "2.7.3-final-proof-benchmark-learning-locked"
    const val STATE: String = "TOPIC_SPECIFIC_ROUTE_OPENED_LEARNING_LINKED"
    const val CLAIM_LIMIT: String = "topic_specific_route_learning_only_not_evidence_not_diagnosis_not_treatment"

    val DEFAULT_MATRIX_TARGETS: List<String> = listOf(
        "accession handle",
        "species/host",
        "biospecimen",
        "cell/tissue context",
        "condition labels",
        "exposure or infection metadata",
        "case/control comparator",
        "timepoint/severity labels",
        "assay platform",
        "data availability statement"
    )

    private val profiles: List<GTIMTopicRouteProfileV270> = listOf(
        GTIMTopicRouteProfileV270(
            topicId = "hantavirus_endothelial_interferon_cytokine_route",
            displayName = "Hantavirus endothelial / interferon / cytokine route",
            matchTerms = listOf("hantavirus", "hanta", "hfrs", "hcps", "puumala", "sin nombre", "andes virus", "seoul virus", "dobrava", "rodent exposure"),
            diseasePhenotype = listOf("HFRS", "HCPS", "viral hemorrhagic / pulmonary syndrome", "acute hantavirus infection"),
            triggerExposure = listOf("rodent exposure", "hantavirus lineage", "acute viral infection", "endothelial tropism context"),
            corePathways = listOf("type I interferon timing", "endothelial activation", "capillary leak", "platelet/coagulation axis", "cytokine severity"),
            cellTissue = listOf("endothelium", "PBMC", "monocytes", "platelets", "lung", "kidney"),
            assayTargets = listOf("RNA-seq", "PBMC transcriptome", "cytokine profiling", "proteomics", "serology"),
            comparatorTargets = listOf("HFRS vs HCPS", "severe vs mild", "acute vs convalescent", "infected vs healthy control", "virus lineage metadata"),
            routeCascade = listOf("topic_detected:hantavirus", "exposure:rodent/lineage", "phenotype:HFRS_HCPS", "axis:endothelial_interferon_cytokine", "matrix:PBMC_endothelium", "contradiction:generic_viral_fever_vs_hantavirus_specific"),
            hypotheses = listOf(
                "Early interferon timing may separate controlled recovery from severe HCPS/HFRS.",
                "Endothelial activation and capillary leak are candidate differentiators from generic viral fever.",
                "Platelet/coagulation markers may separate renal-predominant from pulmonary-predominant phenotypes.",
                "Rodent exposure and viral lineage metadata must be present before route upgrade."
            ),
            differentiatorGates = listOf("hantavirus lineage", "renal vs pulmonary phenotype", "endothelial/capillary leak markers", "platelet/coagulation metadata", "acute vs convalescent timepoint"),
            querySeeds = listOf(
                "hantavirus HFRS HCPS PBMC transcriptome interferon endothelial cytokine GSE PRJNA comparator",
                "Puumala Sin Nombre Andes Seoul virus RNA-seq cytokine endothelial capillary leak severity controls",
                "hantavirus platelet coagulation endothelial activation acute convalescent data availability PMID DOI GSE"
            ),
            connectedDotEdges = listOf("rodent exposure -> hantavirus lineage", "hantavirus lineage -> endothelial activation", "endothelial activation -> capillary leak phenotype", "interferon timing -> cytokine severity", "platelet/coagulation -> renal/pulmonary split"),
            learningTasks = listOf("learn lineage/phenotype terms from each candidate", "record which tissue/cell matrix actually appears", "separate generic viral response from hantavirus-specific endothelial signal", "store null-result contradictions by phenotype"),
            upgradeBlockers = listOf("no hantavirus lineage metadata", "no acute/convalescent or severity comparator", "generic viral immune route only", "no accession/matrix confirmation", "no contradiction search")
        ),
        GTIMTopicRouteProfileV270(
            topicId = "stress_hpa_latent_virus_cytokine_route",
            displayName = "Stress / sleep / HPA / latent-virus immune route",
            matchTerms = listOf("stress", "sleep", "hpa", "cortisol", "glucocorticoid", "ebv", "hhv-6", "latent virus", "adversity"),
            diseasePhenotype = listOf("stress-linked immune transcription", "latent-virus immune activation", "post-viral immune dysregulation"),
            triggerExposure = listOf("chronic stress", "sleep disruption", "HPA-axis disruption", "latent-virus reactivation"),
            corePathways = listOf("glucocorticoid resistance", "type I interferon", "IL-6/TNF", "lymphocyte transcription"),
            cellTissue = listOf("PBMC", "lymphocytes", "T cells", "B cells", "monocytes"),
            assayTargets = listOf("RNA-seq", "microarray", "cytokine profiling", "qPCR"),
            comparatorTargets = listOf("high stress vs low stress", "sleep disruption vs control", "reactivation-positive vs negative", "case vs recovered/healthy control"),
            routeCascade = listOf("topic_detected:stress_hpa", "exposure:stress_sleep", "axis:glucocorticoid_resistance", "bridge:latent_virus", "output:interferon_cytokine"),
            hypotheses = listOf("HPA-axis disruption may shift lymphocyte transcription toward inflammatory cytokine programs.", "Latent-virus reactivation can act as an intermediate signal rather than a final proof.", "IL-6/TNF and interferon signatures must be separated by timepoint and comparator."),
            differentiatorGates = listOf("measured stress/sleep/HPA variable", "viral marker present", "cytokine/interferon readout", "matched control group", "time window"),
            querySeeds = listOf("stress sleep HPA glucocorticoid resistance EBV HHV-6 interferon IL-6 TNF PBMC transcriptome PMID DOI GSE", "chronic stress lymphocyte transcription latent virus reactivation data availability comparator"),
            connectedDotEdges = listOf("stress/sleep -> HPA-axis", "HPA-axis -> glucocorticoid resistance", "latent-virus marker -> interferon", "interferon/cytokine -> disease route hypothesis"),
            learningTasks = listOf("store whether HPA marker is measured or inferred", "record viral-marker type", "separate cytokine signal from clinical claim"),
            upgradeBlockers = listOf("HPA not measured", "viral reactivation only inferred", "no comparator", "no matrix/accession", "no contradiction search")
        ),
        GTIMTopicRouteProfileV270(
            topicId = "cancer_tcell_exhaustion_tme_route",
            displayName = "Cancer / tumor immune evasion route",
            matchTerms = listOf("cancer", "tumor", "oncology", "tme", "tumor microenvironment", "immune evasion", "checkpoint"),
            diseasePhenotype = listOf("tumor immune evasion", "cancer immune microenvironment"),
            triggerExposure = listOf("tumor antigen", "chronic antigen stimulation", "checkpoint exposure"),
            corePathways = listOf("T-cell exhaustion", "PD-1/PD-L1", "Treg", "myeloid suppression", "antigen presentation"),
            cellTissue = listOf("tumor microenvironment", "TIL", "CD8 T cells", "Treg", "myeloid cells"),
            assayTargets = listOf("scRNA-seq", "spatial transcriptomics", "bulk RNA-seq", "TCR-seq"),
            comparatorTargets = listOf("tumor vs adjacent normal", "responder vs non-responder", "pre/post treatment metadata", "cancer type"),
            routeCascade = listOf("topic_detected:cancer", "axis:immune_evasion", "cells:TIL_CD8_Treg_myeloid", "gate:cancer_type_treatment_metadata"),
            hypotheses = listOf("Exhaustion and myeloid suppression must be interpreted by cancer type and treatment context.", "Shared immune pathways do not imply equivalence with chronic infection."),
            differentiatorGates = listOf("cancer type", "treatment exposure", "tumor vs normal comparator", "responder status", "cell-state annotation"),
            querySeeds = listOf("cancer tumor microenvironment T cell exhaustion PD-1 CD8 single-cell GSE comparator responder nonresponder", "tumor immune evasion myeloid suppression Treg spatial transcriptomics data availability"),
            connectedDotEdges = listOf("tumor antigen -> chronic stimulation", "chronic stimulation -> exhaustion", "TME -> myeloid/Treg suppression", "metadata -> responder/nonresponder split"),
            learningTasks = listOf("store cancer-type dependency", "track treatment metadata", "separate immune-evasion route from infection route"),
            upgradeBlockers = listOf("no cancer type", "no tumor/normal or responder comparator", "treatment metadata missing", "no cell-state annotation")
        ),
        GTIMTopicRouteProfileV270(
            topicId = "hiv_aids_chronic_viral_immunodeficiency_route",
            displayName = "HIV/AIDS chronic viral immunodeficiency route",
            matchTerms = listOf("hiv", "aids", "cd4 depletion", "viral load", "antiretroviral", "art"),
            diseasePhenotype = listOf("HIV chronic viral infection", "AIDS immune depletion"),
            triggerExposure = listOf("viral load", "ART status", "opportunistic infection"),
            corePathways = listOf("CD4 depletion", "CD8 exhaustion", "chronic interferon", "immune activation"),
            cellTissue = listOf("PBMC", "CD4 T cells", "CD8 T cells", "monocytes", "lymph node"),
            assayTargets = listOf("RNA-seq", "scRNA-seq", "flow cytometry", "TCR-seq"),
            comparatorTargets = listOf("untreated vs ART-treated", "high vs low viral load", "progressor vs controller", "HIV-negative control"),
            routeCascade = listOf("topic_detected:hiv", "axis:chronic_viral_immunodeficiency", "cells:CD4_CD8", "gate:viral_load_ART"),
            hypotheses = listOf("Viral load and ART status are mandatory before interpreting exhaustion or cytokine signatures.", "Opportunistic infection must be separated from core HIV immune state."),
            differentiatorGates = listOf("viral load", "ART status", "CD4 count", "opportunistic infection metadata", "controller/progressor label"),
            querySeeds = listOf("HIV AIDS CD4 depletion CD8 exhaustion viral load ART PBMC transcriptome GSE PRJNA comparator", "HIV controller progressor immune activation interferon scRNA-seq data availability"),
            connectedDotEdges = listOf("viral load -> chronic immune activation", "CD4 depletion -> opportunistic vulnerability", "ART status -> transcriptional confounding", "CD8 exhaustion -> chronic antigen route"),
            learningTasks = listOf("store ART/viral-load metadata", "separate opportunistic infection from HIV route", "track CD4 count availability"),
            upgradeBlockers = listOf("no viral load", "no ART status", "no CD4 metadata", "opportunistic infection confounded", "no comparator")
        ),
        GTIMTopicRouteProfileV270(
            topicId = "fungal_th17_neutrophil_barrier_route",
            displayName = "Fungal / Th17-neutrophil defense route",
            matchTerms = listOf("fungal", "fungi", "candida", "aspergillus", "mold", "th17", "card9", "dectin"),
            diseasePhenotype = listOf("fungal infection", "mucocutaneous fungal susceptibility", "invasive fungal disease"),
            triggerExposure = listOf("Candida", "Aspergillus", "fungal antigen", "barrier disruption"),
            corePathways = listOf("Th17/IL-17", "neutrophil recruitment", "CARD9/Dectin-1", "epithelial barrier"),
            cellTissue = listOf("mucosa", "epithelium", "neutrophils", "Th17 cells", "PBMC"),
            assayTargets = listOf("RNA-seq", "cytokine profiling", "flow cytometry", "microbiome"),
            comparatorTargets = listOf("infected vs uninfected", "invasive vs colonization", "immunocompromised vs immunocompetent", "site of infection"),
            routeCascade = listOf("topic_detected:fungal", "axis:Th17_neutrophil", "gate:colonization_vs_invasive", "matrix:mucosa_PBMC"),
            hypotheses = listOf("Th17/neutrophil signals must be interpreted by colonization vs invasive disease.", "Barrier-site metadata is decisive for fungal immune route quality."),
            differentiatorGates = listOf("fungal species", "colonization vs invasive disease", "barrier site", "immunocompromised status", "neutrophil count/function"),
            querySeeds = listOf("Candida Aspergillus fungal infection Th17 IL-17 neutrophil CARD9 Dectin-1 transcriptome GSE PRJNA comparator", "fungal colonization invasive mucosal immunity RNA-seq data availability controls"),
            connectedDotEdges = listOf("fungal antigen -> Dectin/CARD9", "Dectin/CARD9 -> Th17", "Th17 -> neutrophil recruitment", "barrier site -> colonization/invasion split"),
            learningTasks = listOf("store fungal species/site", "separate colonization from invasive disease", "track immunosuppression metadata"),
            upgradeBlockers = listOf("species/site missing", "colonization not separated", "immunosuppression metadata missing", "no neutrophil/barrier readout")
        ),
        GTIMTopicRouteProfileV270(
            topicId = "exposome_gut_endocrine_toxicant_immune_route",
            displayName = "Exposome / gut / endocrine / toxicant immune route",
            matchTerms = listOf("gut", "digestive", "microbiome", "hormone", "endocrine", "pesticide", "glyphosate", "organophosphate", "antibiotic residue", "livestock antibiotics", "heavy metal", "lead", "mercury", "arsenic", "cadmium", "microplastic", "plastic", "bpa", "phthalate", "pfas"),
            diseasePhenotype = listOf("exposome-linked immune perturbation", "mucosal/endocrine immune bridge"),
            triggerExposure = listOf("food residue", "water contaminant", "plasticizer", "microbiome disruption", "hormone/endocrine signal"),
            corePathways = listOf("mucosal immunity", "barrier disruption", "endocrine-immune crosstalk", "xenobiotic/oxidative stress", "microbiome/resistome"),
            cellTissue = listOf("gut mucosa", "stool", "PBMC", "liver", "kidney", "biospecimen"),
            assayTargets = listOf("metagenomics", "16S", "metabolomics", "RNA-seq", "biomonitoring"),
            comparatorTargets = listOf("measured exposed vs unexposed", "dose/window proxy", "biospecimen concentration", "diet/water/source metadata"),
            routeCascade = listOf("topic_detected:exposome", "exposure:measured_required", "axis:gut_endocrine_toxicant", "gate:dose_window_comparator"),
            hypotheses = listOf("Exposure route is only useful if measured exposure metadata exists.", "Microbiome, endocrine and toxicant routes must remain separated until data links them."),
            differentiatorGates = listOf("measured exposure", "dose/window", "source matrix", "exposed/unexposed comparator", "chemical class separated"),
            querySeeds = listOf("pesticide microplastic heavy metal endocrine immune microbiome exposed unexposed transcriptome biomonitoring data availability", "gut microbiome hormone immune pesticide residue livestock antibiotic heavy metal water PFAS BPA GSE PRJNA comparator"),
            connectedDotEdges = listOf("exposure source -> measured exposure", "measured exposure -> tissue/cell matrix", "microbiome/endocrine/toxicant axis -> immune readout", "comparator -> route upgrade gate"),
            learningTasks = listOf("record measured vs inferred exposure", "separate chemical classes", "track dose/window availability"),
            upgradeBlockers = listOf("exposure not measured", "dose/window missing", "chemical classes conflated", "no exposed/unexposed comparator", "no biospecimen/source metadata")
        )
    )

    fun build(question: String, previousContext: String = ""): GTIMTopicRoutePlanV270 {
        if (!RuntimeFeatureFlags.ENABLE_TOPIC_SPECIFIC_ROUTE_BUILDER_V270) return GTIMTopicRoutePlanV270.empty()
        val raw = question.trim()
        if (raw.isBlank()) return GTIMTopicRoutePlanV270.empty()
        val selected = matchProfiles(raw).ifEmpty { listOf(dynamicProfile(raw)) }
        val primary = selected.first()
        val previousMatches = if (previousContext.isBlank()) emptyList() else matchProfiles(previousContext).map { it.topicId }
        val topicShift = previousMatches.isNotEmpty() && primary.topicId !in previousMatches
        val mergedRoute = selected.flatMap { it.routeCascade }.distinct().take(12)
        val mergedHypotheses = selected.flatMap { it.hypotheses }.distinct().take(8)
        val mergedQueries = selected.flatMap { it.querySeeds }.distinct().take(RuntimeFeatureFlags.TOPIC_SPECIFIC_ROUTE_QUERY_LIMIT_V270)
        val mergedComparators = selected.flatMap { it.comparatorTargets }.distinct().take(12)
        val gates = selected.flatMap { it.differentiatorGates }.distinct().take(14)
        val edges = selected.flatMap { it.connectedDotEdges }.distinct().take(14)
        val tasks = selected.flatMap { it.learningTasks }.distinct().take(10)
        val blockers = selected.flatMap { it.upgradeBlockers }.distinct().take(12)
        val action = "Open topic-specific route '${primary.displayName}', run ${mergedQueries.firstOrNull()?.take(180) ?: "repository lookup"}, then learn comparator/matrix/contradiction deltas without upgrading claims."
        return GTIMTopicRoutePlanV270(
            active = true,
            version = VERSION,
            status = if (topicShift) "TOPIC_SHIFT_ROUTE_OPENED" else STATE,
            primaryTopicId = primary.topicId,
            topicTitle = primary.displayName,
            topicShiftDetected = topicShift,
            matchedProfiles = selected.map { it.topicId },
            routeCascade = mergedRoute,
            hypotheses = mergedHypotheses,
            querySeeds = mergedQueries,
            comparatorTargets = mergedComparators,
            matrixTargets = DEFAULT_MATRIX_TARGETS,
            differentiatorGates = gates,
            connectedDotEdges = edges,
            learningTasks = tasks,
            upgradeBlockers = blockers,
            nextAction = action
        )
    }

    fun queriesForText(text: String, limit: Int = RuntimeFeatureFlags.TOPIC_SPECIFIC_ROUTE_QUERY_LIMIT_V270): List<String> =
        build(text).querySeeds.take(limit)

    fun learningOneLine(plan: GTIMTopicRoutePlanV270): String =
        if (!plan.active) "topic route not opened" else "${plan.status}; topic=${plan.primaryTopicId}; hypotheses=${plan.hypotheses.size}; edges=${plan.connectedDotEdges.size}; gates=${plan.differentiatorGates.size}; next=${plan.nextAction.take(160)}"

    fun reportCard(plan: GTIMTopicRoutePlanV270): List<String> = if (!plan.active) emptyList() else listOf(
        "Topic route: ${plan.topicTitle}",
        "Route: ${plan.routeCascade.joinToString(" → ").take(220)}",
        "Hypothesis: ${plan.hypotheses.firstOrNull().orEmpty().take(220)}",
        "Learning link: ${plan.connectedDotEdges.take(4).joinToString("; ").take(220)}",
        "Still blocked by: ${plan.upgradeBlockers.take(4).joinToString(", ").take(220)}"
    )

    private fun matchProfiles(text: String): List<GTIMTopicRouteProfileV270> {
        val normalized = normalize(text)
        return profiles.mapNotNull { profile ->
            val matched = profile.matchTerms.count { termMatches(normalized, it) }
            if (matched >= RuntimeFeatureFlags.TOPIC_SPECIFIC_ROUTE_MIN_MATCH_TERMS_V270) profile to matched else null
        }.sortedWith(compareByDescending<Pair<GTIMTopicRouteProfileV270, Int>> { it.second }.thenBy { it.first.topicId })
            .map { it.first }
            .take(RuntimeFeatureFlags.TOPIC_SPECIFIC_ROUTE_MAX_PROFILES_V270)
    }

    private fun dynamicProfile(raw: String): GTIMTopicRouteProfileV270 {
        val tokens = raw.lowercase(Locale.US)
            .split(Regex("[^a-z0-9+/-]+"))
            .map { it.trim('-', '/', '+') }
            .filter { it.length >= 4 && it !in STOP_WORDS }
            .distinct()
            .take(6)
        val label = tokens.take(3).joinToString(" ").ifBlank { "new biomedical topic" }
        val topicId = "dynamic_topic_" + label.replace(Regex("[^a-z0-9]+"), "_").trim('_').ifBlank { "general" }
        val queryCore = tokens.joinToString(" ").ifBlank { "immune response" }
        return GTIMTopicRouteProfileV270(
            topicId = topicId,
            displayName = "Dynamic topic-specific route: $label",
            matchTerms = tokens,
            diseasePhenotype = listOf(label),
            triggerExposure = listOf("topic-specific trigger/exposure to be resolved"),
            corePathways = listOf("immune pathway to be resolved", "inflammation/interferon/cytokine screen"),
            cellTissue = listOf("PBMC", "disease-relevant tissue", "biospecimen to be resolved"),
            assayTargets = listOf("RNA-seq", "scRNA-seq", "cytokine profiling", "metadata mining"),
            comparatorTargets = listOf("case vs control", "severity/timepoint comparator", "exposed vs unexposed if exposure topic", "species/tissue comparator"),
            routeCascade = listOf("topic_detected:$topicId", "axis:resolve_disease_trigger_pathway", "matrix:find_accession", "gate:comparator_metadata_contradiction"),
            hypotheses = listOf("This new topic should receive its own route before reusing older dominant routes.", "First evidence task is to resolve disease/trigger/pathway/cell/comparator metadata."),
            differentiatorGates = listOf("topic-specific disease/phenotype", "trigger/exposure", "pathway signal", "cell/tissue matrix", "case/control or timepoint comparator"),
            querySeeds = listOf("$queryCore immune response transcriptome cytokine comparator GSE PRJNA PMID DOI data availability", "$queryCore PBMC RNA-seq scRNA-seq disease control metadata accession"),
            connectedDotEdges = listOf("new topic -> independent route", "route -> accession search", "accession -> comparator/matrix gate", "findings -> learning ledger only"),
            learningTasks = listOf("store topic as a new route key", "learn which metadata fields are repeatedly missing", "connect only evidence-supported edges to older routes"),
            upgradeBlockers = listOf("topic not mapped to disease/trigger/pathway", "no accession", "no comparator", "no matrix metadata", "no contradiction search")
        )
    }

    private fun termMatches(normalizedText: String, term: String): Boolean {
        val normalizedTerm = normalize(term)
        if (normalizedTerm.length <= 3) {
            return Regex("(^|[^a-z0-9])${Regex.escape(normalizedTerm)}([^a-z0-9]|$)").containsMatchIn(normalizedText)
        }
        return normalizedText.contains(normalizedTerm)
    }

    private fun normalize(value: String): String = value.lowercase(Locale.US)
        .replace('–', '-')
        .replace('—', '-')
        .replace(Regex("\\s+"), " ")
        .trim()

    private val STOP_WORDS = setOf(
        "compare", "versus", "against", "between", "during", "about", "with", "without", "using", "into", "from", "that", "this", "what", "when", "where", "route", "report", "immune", "immunity", "research", "study", "data", "dataset"
    )
}
