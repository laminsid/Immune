package com.immunesignal.app

import java.util.Locale

/**
 * v2.6.9 patch-layer: curated prior lookup seeds for the stress/sleep/HPA → immune
 * transcription / latent-virus / cytokine route.
 *
 * Critical guard: these seeds are lookup accelerators. They can surface a route, but they do not
 * close contradiction, accession, comparator, matrix, causality, or clinical gates without resolver
 * confirmation and normal evidence checks.
 */
data class GTIMPriorLiteratureSeedV269(
    val axis: String,
    val canonicalPmid: String,
    val canonicalDoi: String,
    val userProvidedHandles: List<String>,
    val routeUse: String,
    val query: String,
    val safetyNote: String,
    val claimLimit: String = GTIMKnownPriorEvidenceSeedsV269.CLAIM_LIMIT
)

data class GTIMPriorMatrixSeedV269(
    val axis: String,
    val accession: String,
    val routeUse: String,
    val query: String,
    val verifierStatus: String,
    val matrixGateHint: String,
    val safetyNote: String,
    val claimLimit: String = GTIMKnownPriorEvidenceSeedsV269.CLAIM_LIMIT
)

object GTIMKnownPriorEvidenceSeedsV269 {
    const val VERSION: String = "2.7.3-final-proof-benchmark-learning-locked"
    const val PATCH_LABEL: String = "2.6.8.4-known-prior-evidence-seed-injection"
    const val CLAIM_LIMIT: String = "known_prior_seed_lookup_only_not_gate_closure"

    val literatureSeeds: List<GTIMPriorLiteratureSeedV269> = listOf(
        GTIMPriorLiteratureSeedV269(
            axis = "stress_hpa_ctra_latent_virus_route",
            canonicalPmid = "22114171",
            canonicalDoi = "10.1126/science.1211719",
            userProvidedHandles = listOf("PMID:22114171", "DOI:10.1126/science.1211719"),
            routeUse = "prior literature lookup seed for chronic physiological stress, leukocyte transcriptional response, antiviral/interferon directionality, and latent-virus reactivation hypotheses",
            query = "PMID 22114171 OR DOI 10.1126/science.1211719 chronic stress lymphocyte transcription adversity interferon EBV HHV-6 latent virus reactivation cytokine",
            safetyNote = "Route prior only. Does not prove EBV/HHV-6 reactivation, cytokine storm, causality, diagnosis, or treatment. Requires contradiction and dataset resolver checks."
        ),
        GTIMPriorLiteratureSeedV269(
            axis = "hpa_glucocorticoid_resistance_il6_tnf_route",
            canonicalPmid = "22474371",
            canonicalDoi = "10.1073/pnas.1118355109",
            userProvidedHandles = listOf("USER_PROVIDED_PMID:24591641", "USER_PROVIDED_DOI:10.1103/pnas.1321654111", "CORRECTED_PMID:22474371", "CORRECTED_DOI:10.1073/pnas.1118355109"),
            routeUse = "corrected prior literature lookup seed for chronic stress, glucocorticoid receptor resistance, inflammatory down-regulation failure, IL-6/TNF route construction",
            query = "PMID 22474371 OR DOI 10.1073/pnas.1118355109 chronic stress glucocorticoid receptor resistance inflammation IL-6 TNF HPA cortisol",
            safetyNote = "User-provided PMID/DOI pair is retained as an alias but not treated as validated; corrected canonical identifiers are used for lookup. Prior seed does not close contradiction gate."
        ),
        GTIMPriorLiteratureSeedV269(
            axis = "multiple_sclerosis_th17_demyelination_route",
            canonicalPmid = "33028661",
            canonicalDoi = "10.1038/s41577-020-00466-y",
            userProvidedHandles = listOf("PMID:33028661", "DOI:10.1038/s41577-020-00466-y"),
            routeUse = "prior literature lookup seed for MS Th17/IL-17 demyelination, BBB disruption, neurofilament and B-cell route construction",
            query = "PMID 33028661 OR DOI 10.1038/s41577-020-00466-y multiple sclerosis Th17 IL-17 demyelination BBB NfL ocrelizumab biomarker",
            safetyNote = "MS route prior only. Does not prove causality or treatment effect without comparator, matrix and contradiction checks."
        ),
        GTIMPriorLiteratureSeedV269(
            axis = "type1_diabetes_islet_autoantibody_route",
            canonicalPmid = "30413496",
            canonicalDoi = "10.1056/NEJMoa1902187",
            userProvidedHandles = listOf("PMID:30413496", "DOI:10.1056/NEJMoa1902187"),
            routeUse = "prior literature lookup seed for T1D anti-CD3/islet autoantibody/beta-cell preservation route construction",
            query = "PMID 30413496 OR DOI 10.1056/NEJMoa1902187 teplizumab type 1 diabetes anti-CD3 beta cell preservation islet autoantibody comparator",
            safetyNote = "T1D route prior only. Requires dataset, comparator and clinical endpoint verification before any upgrade."
        ),
        GTIMPriorLiteratureSeedV269(
            axis = "inflammatory_bowel_disease_mucosal_il23_route",
            canonicalPmid = "28768163",
            canonicalDoi = "10.1016/j.cell.2017.05.014",
            userProvidedHandles = listOf("PMID:28768163", "DOI:10.1016/j.cell.2017.05.014"),
            routeUse = "prior literature lookup seed for IBD mucosal immunity, dysbiosis, Th17/IL-23 and fecal-calprotectin comparator route construction",
            query = "PMID 28768163 OR DOI 10.1016/j.cell.2017.05.014 IBD gut immune dysbiosis Th17 IL-23 vedolizumab fecal calprotectin comparator",
            safetyNote = "IBD mucosal route prior only. Lookup seed does not prove mechanism or therapeutic response without matrix/comparator checks."
        )
    )

    val matrixSeeds: List<GTIMPriorMatrixSeedV269> = listOf(
        GTIMPriorMatrixSeedV269(
            axis = "stress_hpa_long_covid_interferon_matrix_candidate",
            accession = "GSE152202",
            routeUse = "user-requested matrix seed; routed through verifier before matrix gate because public index evidence may indicate route mismatch",
            query = "GSE152202 long COVID autoimmune interferon cytokine RNA-seq cellular stress HPA comparator matrix data availability",
            verifierStatus = "VERIFY_ROUTE_BEFORE_USE",
            matrixGateHint = "MATRIX_READY_CANDIDATE_ONLY_AFTER_GEO_METADATA_MATCH",
            safetyNote = "Do not force Matrix Gate READY. If GEO metadata does not match Long COVID / immune PBMC route, classify as off-route or unrelated dataset."
        ),
        GTIMPriorMatrixSeedV269(
            axis = "sars_cov_2_peripheral_blood_transcriptome_matrix_candidate",
            accession = "GSE166552",
            routeUse = "human peripheral blood SARS-CoV-2 transcriptome seed for infection/inflammation route; RA/SLE usage requires explicit secondary comparator evidence",
            query = "GSE166552 COVID-19 infected peripheral blood transcriptome PBMC lncRNA circRNA cytokine interferon healthy controls data availability",
            verifierStatus = "PARTIAL_ROUTE_MATCH_REQUIRES_COMPARATOR_CHECK",
            matrixGateHint = "MATRIX_READY_CANDIDATE_FOR_SARS_COV_2_BLOOD_ROUTE_ONLY",
            safetyNote = "Do not treat as direct RA/SLE evidence unless metadata or paper explicitly contains that comparator."
        )
    )

    val allHandles: List<String> = (literatureSeeds.flatMap { listOf(it.canonicalPmid, it.canonicalDoi) + it.userProvidedHandles } + matrixSeeds.map { it.accession }).distinct()

    fun queriesForText(text: String, limit: Int = RuntimeFeatureFlags.KNOWN_PRIOR_SEED_QUERY_LIMIT_V269): List<String> {
        if (!RuntimeFeatureFlags.ENABLE_KNOWN_PRIOR_EVIDENCE_SEEDS_V269) return emptyList()
        val normalized = text.lowercase(Locale.US)
        val selectedLiterature = literatureSeeds.filter { seed -> seed.matches(normalized) }
        val selectedMatrices = matrixSeeds.filter { seed -> seed.matches(normalized) }
        val fallback = (selectedLiterature.ifEmpty { literatureSeeds.take(2) }.map { seed ->
            "(${seed.canonicalPmid} OR ${seed.canonicalDoi}) ${seed.query} claim-limit:${seed.claimLimit} gate-effect:no_auto_closure"
        } + selectedMatrices.ifEmpty { matrixSeeds.take(2) }.map { seed ->
            "${seed.accession} ${seed.query} verifier:${seed.verifierStatus} matrix-hint:${seed.matrixGateHint} claim-limit:${seed.claimLimit}"
        })
        return fallback.distinct().take(limit)
    }

    fun handlesForText(text: String, limit: Int = RuntimeFeatureFlags.KNOWN_PRIOR_SEED_QUERY_LIMIT_V269): List<String> {
        if (!RuntimeFeatureFlags.ENABLE_KNOWN_PRIOR_EVIDENCE_SEEDS_V269) return emptyList()
        val normalized = text.lowercase(Locale.US)
        val lit = literatureSeeds.filter { it.matches(normalized) }.flatMap { listOf(it.canonicalPmid, it.canonicalDoi) + it.userProvidedHandles }
        val matrices = matrixSeeds.filter { it.matches(normalized) }.map { it.accession }
        return (lit + matrices).ifEmpty { allHandles }.distinct().take(limit)
    }

    fun routeCardForText(text: String): List<String> {
        val queries = queriesForText(text, limit = 4)
        if (queries.isEmpty()) return emptyList()
        return listOf(
            "Known prior seed layer active: ${PATCH_LABEL}",
            "Gate effect: lookup accelerator only; contradiction and matrix gates remain strict",
            "Canonical literature handles: ${literatureSeeds.joinToString { it.canonicalPmid + '/' + it.canonicalDoi }}",
            "Matrix candidates: ${matrixSeeds.joinToString { it.accession + '=' + it.matrixGateHint }}",
            "Claim limit: $CLAIM_LIMIT"
        )
    }

    private fun GTIMPriorLiteratureSeedV269.matches(normalized: String): Boolean {
        val tokens = (axis.split('_') + query.split(' ') + userProvidedHandles + listOf(canonicalPmid, canonicalDoi))
            .map { it.lowercase(Locale.US).trim('(', ')', ',', ';', ':') }
            .filter { it.length >= 4 }
        return tokens.any { normalized.contains(it) }
    }

    private fun GTIMPriorMatrixSeedV269.matches(normalized: String): Boolean {
        val tokens = (axis.split('_') + query.split(' ') + listOf(accession))
            .map { it.lowercase(Locale.US).trim('(', ')', ',', ';', ':') }
            .filter { it.length >= 4 }
        return tokens.any { normalized.contains(it) }
    }
}
