# Changelog — v1.2.0-alpha-research-lock-system

## Added

- Hypothesis Object model.
- Minimum Data Pack gate.
- Hypothesis Impact Test.
- Discovery State / Bias Risk State.
- Learning Delta cards.
- Research Mistake Library.
- Falsification Builder.
- Report Template V2 for short copyable report.
- PDF and on-screen report sections for research locks.
- Research lock rule assets.

## Changed

- ResearchAutopilot now builds hypothesis objects after ranking.
- Report schema moved to version 12.
- README and internal project sheet updated.
- App versionName set to `1.2.0-alpha-research-lock-system`.

## Intent

This is a discipline patch, not a new biological expansion.
