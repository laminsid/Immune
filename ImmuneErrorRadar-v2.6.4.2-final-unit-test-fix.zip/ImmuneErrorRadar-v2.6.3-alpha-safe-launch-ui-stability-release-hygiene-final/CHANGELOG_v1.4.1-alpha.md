# Immune Error Radar v1.4.1-alpha — Path Verification & Route Hardening

## Purpose

This patch verifies the v1.4.0 dataset-first forager wiring and closes two route-level weaknesses found during full package review.

## Changes

- Active engine version raised to `v1.4.1-alpha-path-verified`.
- Execution lock now treats `q_v140_*` dataset-first queries as valid forced evidence-path execution.
- Direct dataset router now has a cooldown-escape path (`GEO_GDS_COOLDOWN_ESCAPE`) so DATASET_HUNT cannot become an active forager with zero source attempts when all normal routes are cooling down.
- Static checks now verify the new version and cooldown-escape routing token.
- Report/export labels updated to v1.4.1 where user-facing.

## Boundary

No new biology axis, no diagnosis, no treatment advice, no medical prediction, and no ML model were added.
