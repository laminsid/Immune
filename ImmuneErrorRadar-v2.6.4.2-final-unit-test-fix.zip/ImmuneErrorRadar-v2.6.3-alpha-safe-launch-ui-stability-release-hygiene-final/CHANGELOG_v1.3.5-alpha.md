# v1.3.5-alpha — Smart Report Integrity + Scope Discipline Locks

## Added

- Added `SmartReportIntegrityLock.kt`.
- Added `ScopeDisciplineLock.kt`.
- Added required report fields to `ResearchReportV3`:
  - `hypothesis`
  - `supportingEvidence`
  - `counterEvidenceOrContradiction`
  - `whatWeDoNotBelieveYet`
  - `integrityStatus`
  - `integrityFailures`
- Added JVM tests for report integrity and scope lock behavior.

## Changed

- `ResearchReportV3Builder` now builds the four accountability fields before rendering a report.
- Repeated-source no-result fallback no longer uses new-axis wording.
- Replaced `REPEAT_TO_NEW_AXIS_PAIR` with `REPEAT_TO_EVIDENCE_LANE_ROTATION`.
- Replaced `new_axis_pair_explore` with `evidence_lane_rotation`.
- UI brief report and PDF export now show hypothesis, support, counter-evidence, unknowns, and integrity status.

## Boundaries preserved

- No new biology axes.
- No ML / Random Forest.
- No diagnosis.
- No treatment advice.
- No symptom-tracking product behavior.
