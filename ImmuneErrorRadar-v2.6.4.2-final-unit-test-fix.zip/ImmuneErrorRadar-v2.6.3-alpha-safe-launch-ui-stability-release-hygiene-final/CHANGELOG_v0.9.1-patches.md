# v0.9.1-patches — Discipline Patch (Tier 1 + selected Tier 2)

Date: 2026-05-09
Scope: 7 patches. No new features. Every change is a bug fix, a privacy fix,
a parity fix, or a performance fix that closes a documented v0.9.0 contradiction.

## Changed files

```text
app/build.gradle.kts                                                 (P1)
app/src/main/java/com/immunesignal/app/SourceClassifier.kt           (P4)
app/src/main/java/com/immunesignal/app/CausalityScorer.kt            (P5)
app/src/main/java/com/immunesignal/app/SteeringSanitizer.kt          (P3, NEW)
app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt          (P3, P5, P6)
app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt     (P7)
research/causality_scorer.py                                         (P2)
research/hypothesis_ranker.py                                        (P2)
research/parity_fixtures.py                                          (P2, NEW)
docs/CANONICAL_SCORING_FORMULA_v0.9.1.md                             (NEW)
```

## Patches

### P1 — Version metadata
- `versionCode` 6 → 9
- `versionName` "0.6.0-alpha-genomics-autopilot" → "0.9.0-alpha-evidence-causal-learning"
- v0.9.0 shipped with v0.6 metadata, breaking on-device version tracking.

### P2 — Canonical scoring formula
- New `docs/CANONICAL_SCORING_FORMULA_v0.9.1.md` is the single source of truth.
- Python `causality_scorer.py` now matches Kotlin: adds `design_boost`,
  `negative_control_penalty`, and bucketed (not linear) repeatability scoring.
- Python `hypothesis_ranker.py` now includes the `novelty` term (previously
  silently dropped).
- New `research/parity_fixtures.py` emits canonical expected values for
  3 causality + 4 ranking fixtures so future drift is detectable.

### P3 — Steering PII sanitizer
- New `SteeringSanitizer.kt` strips numeric values, dates, months, emails,
  URLs, possessives, location hints, and unknown capitalised tokens BEFORE
  steering tokens are forwarded to NCBI.
- Closes the v0.9.0 contradiction: README claimed "No private case data is
  uploaded" but `buildSteeredQueries` shipped raw user input verbatim.
- Whitelist of safe medical stems is intentionally narrow. False rejections
  are safer than leaks.

### P4 — SourceClassifier human-evidence regressions
- `mixed_human_animal` now maps to a new `human_relevant_with_animal_context`
  source class instead of falling through to `unknown_metadata` (was being
  penalised twice).
- A `synthesis` (meta-analysis / systematic review) of human studies now
  correctly reports `humanEvidence = true` unless species was explicitly
  animal/cell.

### P5 — Negative-control integrated into causality
- `CausalityScorer.score(...)` accepts a new `negativeControlStatus` parameter
  and applies a penalty (12 / 6 / 0) into the numeric score itself.
- `ResearchAutopilot.fetchPubMedSummariesBatch(...)` now uses a two-pass
  evaluation: preview neg-control from axes alone → causality with that as
  input → final neg-control with the now-real causality score.
- Closes the v0.9.0 contradiction: scientific rule named negative-control
  resistance as part of the upgrade gate, but the numeric score never used it.

### P6 — NCBI optimisations
- Adds `tool=` and `email=` to every NCBI URL (required by E-utilities policy).
- Adds optional `api_key=` via local file `ncbi_api_key.txt` (raises rate
  limit from 3 req/s to 10 req/s).
- New `fetchPubMedSummariesBatch(...)` joins up to 200 IDs per esummary call
  instead of one HTTP round-trip per pmid.
- Estimated cycle time: ~3 minutes → ~30 seconds for a typical 12-query run.
- New `httpGetWithRetry(...)` adds 2 retries with exponential backoff on
  transient failures (was silently swallowing them).

### P7 — Append-only writes + cached uniqueness check
- `appendUniqueFinding(...)` no longer reads the entire findings file from
  disk on every call. A `seenIdCache` is built once per process and updated
  in-memory.
- New `appendOnly(...)` helper uses `MODE_APPEND` for the hot path.
- New `trimFile(...)` runs only when the cache exceeds 1.2× the cap.
- Eliminates O(n²) flash I/O on every research cycle.

## Validation

```text
JSON parse: PASS
Kotlin delimiter audit: PASS
XML parse: PASS
Layout ID check: PASS
Research Python checks: PASS
Parity fixtures: emits 7 canonical expected values for v0.9.1
```

Limitations: full Android Gradle build was not run in the patch container.
Open the project in Android Studio or use GitHub Actions for the final APK.

## Next (deferred to v1.0)

- Statistical sanity gates (n<14, permutation count, METADATA_ONLY cap).
- Coroutine + WorkManager migration for `runCycle`.
- Replace `onActivityResult` with `ActivityResultContracts.OpenDocument`.
- Single-source biological plausibility graph (load JSON, drop hardcoded copy).
- Unit test fixtures comparing Kotlin output to `parity_fixtures.py` output.
- Permutation-based negative control (1000 shuffles, empirical p-value).
- Abstract fetch via `efetch.fcgi` for richer evidence classification.
