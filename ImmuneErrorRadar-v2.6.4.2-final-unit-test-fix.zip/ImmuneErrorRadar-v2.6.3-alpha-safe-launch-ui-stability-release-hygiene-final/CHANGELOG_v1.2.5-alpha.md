# Immune Error Radar v1.2.5-alpha-build-audit-hotfix

## Purpose
Build/release audit hotfix after v1.2.4.

## Fixes
- Added root `gradle.properties` with AndroidX enabled.
- Replaced bundled GitHub Actions workflow with the robust ZIP-aware workflow.
- Kept the AndroidX property injection in CI as a safety net.
- Bumped versionCode/versionName to v1.2.5.

## Audit notes
- Static checks: PASS.
- Python sample pipeline: PASS.
- Local pure-Kotlin/JVM test simulation: 86/86 PASS using JUnit/JSON stubs.
- Full Android Gradle build still needs GitHub Actions / Android SDK environment.
