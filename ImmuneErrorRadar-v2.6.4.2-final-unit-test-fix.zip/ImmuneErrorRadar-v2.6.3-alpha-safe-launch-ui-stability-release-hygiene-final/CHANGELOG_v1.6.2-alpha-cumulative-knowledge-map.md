# ImmuneErrorRadar v1.6.2-alpha-cumulative-knowledge-map

## Purpose
The research loop should not collect many sources and then discard context. v1.6.2 adds a local cumulative knowledge map so every Search cycle carries forward prior axes, datasets, hypotheses, evidence links, and unresolved gaps.

## Added
- `CumulativeKnowledgeMapEngine.kt`
- `KnowledgeMapReport`
- `KnowledgeMapNode`
- `KnowledgeMapEdge`
- `KnowledgeMapGap`
- JSON export via `knowledgeMapReport`
- UI brief: Knowledge map state, carried nodes, new links, next map action
- PDF section: Cumulative knowledge map
- Static checks for v1.6.2 map wiring
- Unit test: `CumulativeKnowledgeMapV162Test.kt`

## Safety boundary
The map is an orientation and memory layer only. It does not prove biology, diagnose, treat, or upgrade hypotheses. Evidence gates still decide belief.

## New rule
Search adds to the map. The map guides the next search. Evidence gates the belief.
