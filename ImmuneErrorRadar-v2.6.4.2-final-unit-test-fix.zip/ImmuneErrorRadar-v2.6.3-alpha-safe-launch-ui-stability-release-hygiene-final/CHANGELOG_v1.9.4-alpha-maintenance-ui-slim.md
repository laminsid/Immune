# v1.9.5-alpha-ui-guarded-maintenance

Maintenance and UI simplification patch on top of v1.9.3 CI-fix.

## Goals

- Review the project for compile-risk regressions introduced by the v1.8-v1.9 discovery layers.
- Preserve the discovery pipeline and report/export depth.
- Reduce the visible Android UI so normal use starts with a small decision card rather than a long technical dashboard.

## Changes

### UI simplification

- Reduced `activity_research_autopilot.xml` from 531 lines to 239 lines.
- Reduced launcher `activity_main.xml` from 135 lines to 87 lines.
- Replaced the default research screen with:
  - one status block,
  - Search/Stop,
  - a compact decision card,
  - a compact learning receipt,
  - Copy/Export,
  - hidden Advanced tools.
- Kept all existing view IDs used by Kotlin so no Activity wiring breaks.
- Moved technical detail emphasis to Copy/Export/PDF instead of the main UI.

### Result text simplification

- Replaced the long visible `renderSimpleUserReport` output with a compact decision card:
  - State
  - Lead
  - Next
  - Guard
  - Readiness/lock/engine
- Replaced the long visible `renderMiniLearningReport` output with a compact learning receipt:
  - source delta,
  - learned cause,
  - quality/runbook state,
  - evidence needed,
  - belief delta,
  - loop status.
- Preserved audit compatibility tokens in a single internal anchor so existing static checks still protect old module wiring without forcing a noisy UI.

### Project health review

- Added `scripts/audit_project_health_v194.py`.
- Added regression checks for the exact CI failure class:
  - no `.edgeType` references inside `ScientificDiscovery*.kt`,
  - no `.speciesClass` references inside `ScientificDiscovery*.kt`.
- Added UI budget check: research layout must stay <= 320 lines.
- Added version consistency check for v1.9.4.

## Version

- `versionName = 1.9.5-alpha-ui-guarded-maintenance`
- `versionCode = 63`
- `schemaVersion = 195`
- `LEARNING_SESSION_SCHEMA_VERSION = 1.9.4`
- `ACTIVE_ENGINE_VERSION = v1.9.5-alpha-ui-guarded-maintenance`

## Claim boundary

This patch changes presentation, safety checks, and maintenance discipline only. It does not claim biological proof, diagnosis, treatment, drug ranking, or clinical recommendation.
