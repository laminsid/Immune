# CHANGELOG v1.3.4-alpha — Research Reasoning Layer

## Added

- `ResearchReasoningEngine.kt`
- `ResearchQuestionGenerator`
- `CompetingHypothesisBuilder`
- `DiscriminatorEngine`
- `SearchReframingEngine`
- `SelfCriticEngine`
- `ResearchReasoningReport` JSON export
- Short-report reasoning section in `ResearchAutopilotActivity`
- PDF reasoning section in `DiscoveryReportExporter`
- Unit tests: `ResearchReasoningEngineV134Test`
- Documentation: `docs/RESEARCH_REASONING_LAYER_v1.3.4.md`

## Changed

- Schema version: 134
- versionCode: 23
- versionName: `1.3.4-alpha-research-reasoning`

## Non-goals

- No ML model added.
- No biological axis added.
- No clinical/diagnostic/treatment function added.
