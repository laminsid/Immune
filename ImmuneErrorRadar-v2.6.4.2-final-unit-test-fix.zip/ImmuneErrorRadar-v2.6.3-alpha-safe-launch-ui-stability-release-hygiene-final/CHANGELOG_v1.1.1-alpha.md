# v1.1.1-alpha-stable-research-baseline

## Purpose

Small stabilization patch after v1.1.0-alpha.

## Changes

- README now reflects v1.1.1 instead of v0.9.
- App versionName bumped to `1.1.1-alpha-stable-research-baseline`.
- Release `.gitignore` added.
- Removed `research/__pycache__` and all `*.pyc` artifacts from ZIP.
- Added `BUILD.md` with GitHub Actions/local build instructions.
- Fixed `research/omics_bridge.py` so column presence alone does not count as DNA/RNA signal.
- Added `docs/PROJECT_INTERNAL_SHEET_v1.1.1.md`.
- Static checks now also fail if `__pycache__` or `*.pyc` files are present.

## Omics bridge fix

Before: `dna_methylation=unknown` or `rna_seq=no` could still be counted as omics hits because the column name contained DNA/RNA terms.

Now: only meaningful row values count as active omics signals. Values such as blank, `no`, `unknown`, `none`, `false`, `not measured`, or `negative` do not count.
