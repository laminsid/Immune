# Immune Error Radar v1.4.0-alpha — Dataset-First Autonomous Forager

## Problem fixed

The engine had become disciplined about failure but still looked like it stopped learning after a few attempts because it kept relying on PubMed metadata loops. Reports showed root causes and gates, yet `Dataset candidates = 0` and `Evidence objects = 0` could persist.

## Implemented changes

- Added `HypothesisDecomposer.kt` to split the broad research mission into testable evidence shards.
- Added `DatasetQueryCompiler.kt` to generate narrow dataset-source queries from those shards.
- Added `DirectDatasetSourceRouter.kt` to route stuck cycles into direct dataset families.
- Added `DatasetForagingModels.kt` and `DatasetForagingJson.kt`.
- Added persistent cross-cycle failure memory in `PersistentFailureMemory.kt`.
- Wired `ResearchAutopilot.kt` to run dataset-first acquisition when the system enters `DATASET_HUNT`, detects no evidence object, or persistent failure memory indicates repeated failure.
- Added direct NCBI source attempts for `gds` and `sra` databases.
- Added multi-pass foraging report: dataset accession hunt, metadata usability inspection, contradiction/control check.
- Updated `ResearchModels.kt` schema to include `datasetForagingReport` and `persistentFailureMemory`.
- Updated UI and PDF export to show forager state, sources attempted, blocked learning reason, next action, and persistent memory.
- Updated static checks to validate v1.4.0 version and new report fields.
- Added `DatasetFirstForagerV140Test.kt`.

## Guardrails

- No new biological axis expansion.
- No symptom tracker reintroduction.
- No diagnosis, treatment, drug ranking, or clinical recommendation.
- No hypothesis upgrade from query changes alone.
- Dataset candidate does not equal discovery; it only enables inspection.
