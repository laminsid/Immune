# CHANGELOG v1.2.2-alpha — Result Render Hotfix

## Fixed

- Added missing `renderGutNutritionHormone(gut: JSONObject): String` in `ResultActivity.kt`.
- Fixes Kotlin compile error:
  `Unresolved reference: renderGutNutritionHormone`.
- Keeps the gut/nutrition/hormone output as hypothesis-grade research text with explicit boundary wording.

## Scope

- No new research axis.
- No schema change.
- No model expansion.
- Compile/runtime UI rendering hotfix only.
