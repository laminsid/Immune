# ImmuneErrorRadar v1.6.4-alpha-integrated-cognitive-path

## Purpose
This release connects the previously added intelligence layers into one controlled cognitive path. It is not a random feature addition. It links:

Search / dataset foraging → cumulative knowledge map → mutable epistemic beliefs → specialist evidence protocol → one next research action.

## Added
- `CognitivePathIntegrationEngine.kt`
- `CognitivePathIntegrationReport`
- `CognitivePathDecision`
- `CognitivePathNode`
- `CognitivePathLink`
- JSON export: `cognitivePathIntegrationReport`
- PDF section: `Cognitive path integration`
- UI summary: `Linked thinking path` and `Linked path`
- Unit test: `CognitivePathIntegrationV164Test.kt`

## Fixed
- Removed duplicate `status` named argument in `EpistemicBeliefEngine.kt` that could break Kotlin compilation.
- Updated schema/version wiring to v1.6.4.

## Behavior
- The system now produces one linked decision rather than separate map/belief/reasoning suggestions.
- If route fit is high but metadata is missing, the linked decision blocks hypothesis upgrade and points to minimum metadata parsing.
- If a belief is weakened, revised, or retired, the next route is constrained by that belief status.
- The next search terms are built from required evidence, map gaps, specialist gaps, belief requirements, and route-fit context.

## Boundary
Cognitive path integration is a routing and reasoning-control layer only. It does not prove biology, diagnose, recommend treatment, or upgrade hypotheses without evidence gates.
