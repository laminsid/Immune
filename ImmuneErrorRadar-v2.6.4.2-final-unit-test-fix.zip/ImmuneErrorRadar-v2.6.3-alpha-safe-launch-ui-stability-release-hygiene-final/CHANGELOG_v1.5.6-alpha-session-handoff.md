# ImmuneErrorRadar v1.5.6-alpha-session-handoff

## Goal
Close the remaining gap between completed Learning Sessions and the next research cycle by adding a safe, non-evidence handoff layer.

## Added
- `LearningSessionOutcomeBridge.kt`
- `LearningSessionHandoff`
- Session handoff JSON export inside checkpoints
- UI handoff compact summary after completed sessions
- Protected UIBridge skip logic through `LearningSessionManager.skipCurrentOrNextPhase()`
- Unit test: `LearningSessionV156HandoffTest.kt`

## Behavior
- Converts failure clusters into optional query additions such as outcome/recovery/severity/human/time-course terms.
- Extracts proposed routes, blind-spot warnings, and evolved questions.
- Does not update hypotheses automatically.
- Does not update foundation knowledge JSON automatically.
- Does not create biological, diagnostic, or treatment claims.

## Claim limit
`session_handoff_not_biological_proof`
