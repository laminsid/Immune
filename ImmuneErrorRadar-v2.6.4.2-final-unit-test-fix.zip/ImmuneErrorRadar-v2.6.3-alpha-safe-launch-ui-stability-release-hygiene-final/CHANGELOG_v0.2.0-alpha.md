# Changelog — v0.2.0-alpha

## Strategic Upgrade
- Repositioned the APK as `Immune Error Radar / Immune Signal Field Collector`, not a standalone medical diagnostic app.
- Added biotech platform direction: APK → intake → immune state model → classifiers → target hypothesis engine.

## Classifier Upgrade
- Added `ImmuneStateVector` with five axes:
  - Type-2 allergic axis
  - TNF/IL-6 inflammatory axis
  - Hyper-inflammatory axis
  - Regulatory brake weakness
  - Systemic damage signal
- Added classifier labels:
  - low-signal/incomplete
  - type2 allergic dominant
  - TNF/IL-6 inflammatory dominant
  - hyperinflammatory/systemic
  - urgent clinical warning
- Replaced unvalidated `Confidence %` output with:
  - Signal strength
  - Data quality
  - Evidence completeness

## Doctor Review Pack
- Added `DoctorReportExporter.kt`.
- Added PDF export from the result screen.
- Added FileProvider support with local cache export only.

## Safety and Privacy
- Kept no `INTERNET` permission.
- Kept no broad package/storage permissions.
- Added Germany/EU emergency guidance: 112 and 116117.
- Removed missing `ic_launcher_round` manifest reference.
- Expanded safety docs and regulatory boundary language.

## Data/Research Assets
- Added `IMMUNE_ERROR_ONTOLOGY_v0.1.json` as app asset.
- Added dataset registry placeholder CSV.
- Added Immune Error Classifier documentation.
- Added Target Hypothesis Engine documentation as deferred research layer.

## Checks Run in This Environment
- XML parse: PASS.
- Ontology JSON parse: PASS.
- Forbidden permission grep: PASS.
- Required file presence: PASS.

## Not Run Here
- Full Android Gradle build was not run in this container because Android SDK/Gradle runtime is not available here. GitHub Actions workflow is included to build `:app:assembleDebug`.
