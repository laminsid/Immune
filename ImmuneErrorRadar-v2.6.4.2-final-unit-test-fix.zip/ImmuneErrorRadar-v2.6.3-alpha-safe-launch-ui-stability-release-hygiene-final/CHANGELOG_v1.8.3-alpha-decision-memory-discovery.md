# Immune Error Radar v1.8.3-alpha-decision-memory-discovery

## Purpose

This patch builds on v1.8.2 weighted discovery intelligence. It converts scientific weights and deep-discovery outputs into a falsifiable decision-memory contract so the next cycle knows what was selected, what was blocked, how success is recognized, and what should change if the next test fails.

## Added

- `ScientificDiscoveryDecisionLedgerV183.kt`
- `ScientificDiscoveryDecisionEngineV183`
- `ScientificDiscoveryDecisionReport`
- Selected move / blocked move surface
- Success criteria / failure criteria
- Next-cycle contract
- Change-if-fails policy
- Query-impact terms and evidence-impact keys
- Decision-memory persistence in `ResearchKnowledgeStore`
- Decision-memory routing into `CognitiveNextCycleBridge`
- UI and PDF report sections
- Static audit `PY_AUDIT_V183`

## Claim boundary

`scientific_decision_memory_guides_routing_not_proof`: this layer guides search routing only. It does not prove biology, causality, diagnosis, treatment, protection, or clinical relevance.
