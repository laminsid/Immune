# Build

Recommended local/CI Gradle version: 8.10.2.

```bash
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

The included `gradlew` bootstraps Gradle 8.10.2 if a system Gradle is not already installed. CI uses `gradle/actions/setup-gradle` pinned to 8.10.2, then invokes `./gradlew` when present.

## Static checks

```bash
bash scripts/run_static_checks.sh
python3 scripts/audit_runtime_hardening_v1101.py
```

## Release build

Release builds enable R8/minify and resource shrinking. Signing remains environment/CI controlled; no keystore material should be committed.
