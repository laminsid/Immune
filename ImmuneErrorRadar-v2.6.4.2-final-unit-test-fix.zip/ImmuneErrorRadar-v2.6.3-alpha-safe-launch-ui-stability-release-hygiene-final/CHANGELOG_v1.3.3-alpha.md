# Immune Error Radar v1.3.3-alpha — Autonomous Resilience Patch

## Goal
Improve autonomous research behavior without adding new biological axes or ML models.

## Added
- NoResultRecoveryEngine: converts no-result/repeated-source cycles into explicit pivot decisions.
- AdaptiveQueryEvolution: evolves search intent across broad, mechanism, contradiction, dataset, omics, time-course, and outcome-label stages.
- SelectiveAbstractFetcher: metadata-first scan with max 2 abstracts per cycle and eligibility threshold.
- DatasetCandidateExtractor: extracts GSE/GEO/ImmPort/SDY-style dataset leads with species, data type, outcome/time-course hints, priority score, and next verification step.
- ResearchReportV3Builder: short executive report with cycle result, useful lead, hypothesis change, why it matters, next autonomous move, and what not to believe yet.
- QueryPlanner / FindingBuilder / PubMedClient seams to prepare safe refactoring while keeping ResearchAutopilot as the orchestrator.

## Changed
- Research Steering remains optional acceleration; Autonomous Researcher remains default.
- Reports emphasize useful delta and next autonomous move, not internal lock noise.
- ResearchRunLimits now supports selective abstracts: maxAbstractsPerCycle=2 and abstractEligibilityThreshold=65.

## Not Added
- No new biological axes.
- No ML, GNN, Random Forest, PyTorch, or personal daily tracker.
