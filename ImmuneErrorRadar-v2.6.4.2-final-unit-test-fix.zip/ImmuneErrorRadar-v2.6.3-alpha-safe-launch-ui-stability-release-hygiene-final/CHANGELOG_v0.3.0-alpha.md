# CHANGELOG — v0.3.0-alpha

## Added

- CausalOriginEngine.kt
- PsychoneuroimmuneLayer.kt
- PsychomusculoskeletalLayer.kt
- TriggerTimeline.kt
- CauseEvidenceLedger.kt
- HypothesisEngine.kt
- CauseContextInput model
- CausalOriginMap model
- CauseEvidenceLedger model
- expanded ImmuneStateVector with mast-cell, eosinophil, psychoneuroimmune, mechanical, and neuromuscular axes
- causal-origin mapping UI fields
- musculoskeletal/back/disc context UI fields
- research hypotheses output
- causal-origin evidence output
- PDF export sections for cause context, causal origin map, and research hypotheses

## Changed

- Product mode updated from simple signal collector to private research notebook.
- JSON schema bumped from 2 to 3.
- Version bumped to 0.3.0-alpha.
- Result screen now shows Immune State Vector + Causal Origin Map.

## Safety boundaries

- No treatment, therapy, medication, surgery, exercise, or supplement recommendation.
- Psychological stress is modeled only as trigger/amplifier/maintainer candidate.
- Back/disc-like symptoms are not diagnosed.
- Urgent flags remain gated toward real-world care.
