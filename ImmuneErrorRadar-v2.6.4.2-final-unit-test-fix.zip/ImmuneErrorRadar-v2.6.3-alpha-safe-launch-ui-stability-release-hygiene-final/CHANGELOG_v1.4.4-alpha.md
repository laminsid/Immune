# Immune Error Radar v1.4.4-alpha — Route-Fit Gate & Score Separation

v1.4.4 is a research-integrity patch after the first dataset-foraging report. It does not add new biology, ML, diagnosis, treatment advice, or clinical ranking.

## What changed
- Added `RouteFitGate.kt` to separate dataset route relevance from raw dataset usability.
- Added explicit `DatasetRouteFitAssessment` and `DatasetScoreSeparation` report objects.
- Split scores into:
  - dataset usability,
  - route fit,
  - hypothesis confidence.
- Prevented off-route datasets from upgrading unrelated hypotheses.
- Fixed dataset-source parsing so NCBI/GEO document text is classified separately from the search query text.
- Stopped query terms such as `viral` / `interferon` from contaminating dataset axes when a GEO result is actually allergy/contact-dermatitis/skin.
- Updated evidence objects so route-blocked datasets keep `decisionImpact = no_upgrade`.
- Added route-fit and score-separation sections to text/PDF exports.
- Kept the previous AAPT color fix for `chip_dark.xml` by using valid ARGB color `#22FFFFFF`.

## Intended behavior
A dataset such as `GSE250594` can be reported as a useful contact-dermatitis / skin / IL-1 single-cell lead, but it cannot upgrade an antiviral/interferon timing hypothesis unless an in-route viral/interferon dataset is found.

## Validation
- JSON validation: PASS
- Kotlin delimiter audit: PASS
- XML parse: PASS
- Layout ID check: PASS
- Execution wiring/version check: PASS
- Python research compile checks: PASS
