# ImmuneErrorRadar v1.7.0-alpha-closed-cognitive-loop-control

This release upgrades the existing v1.6.9 cognitive/belief loop into a stricter closed-loop research-control layer. It does not add biological claims, clinical interpretation, or a standalone random model. It wires new learning-control reports into the existing ResearchAutopilot cycle, JSON export, PDF export, mini learning report, runtime module registry, and static audits.

## Added on top of existing paths

- DirectiveLifecycleEngine: tracks proposed/stored/applied/measured/retired/replay-blocked directive state.
- EvidenceGainQueryRanker: ranks the active query batch by expected blocker closure, belief testing, outcome/time/control value, and repeat-failure avoidance.
- BeliefFalsificationContractEngine: generates strengthen/weaken/abandon/do-not-route contracts for active beliefs.
- MemoryConsolidationEngine: separates main, archived, routing, and blocked beliefs to reduce weak belief accumulation.
- CausalReadinessGate: separates association-only, route-fit-only, temporal candidate, controlled comparison, repeated human signal, and intervention-supported states.
- ReflectionLessonEngine: converts repeated search failures into prevention rules.
- MiniPeerReviewGate: applies a reviewer-style HOLD/INSPECT/ADVANCE_WITH_LIMITS verdict before upgrade language.
- ReportSimplificationLayer: exposes what changed, got stronger/weaker/dropped, and the next test while leaving technical detail in the appendix.

## Existing flow preserved

The patch keeps the existing flow intact:

Dataset-first forager → Learning OS → Specialist Evidence Protocol → Cumulative Knowledge Map → Epistemic Belief Model → Cognitive Path Integration → Cognitive Next-Cycle Bridge → Cognitive Loop Calibration.

v1.7.0 sits above that chain as a control/reporting layer and feeds into query ordering, memory hygiene, causal wording limits, and report clarity.

## Version

- versionName: 1.7.0-alpha-closed-cognitive-loop-control
- versionCode: 52
- schemaVersion: 170
- active engine: v1.7.0-alpha-closed-cognitive-loop-control

## Claim boundary

All v1.7.0 additions are routing, calibration, belief hygiene, or report-control features. They do not prove biology, diagnosis, treatment, causality, protection, or drug value.
