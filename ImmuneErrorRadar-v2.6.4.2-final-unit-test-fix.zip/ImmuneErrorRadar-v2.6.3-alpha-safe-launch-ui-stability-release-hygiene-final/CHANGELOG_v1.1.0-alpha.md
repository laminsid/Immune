# v1.1.0-alpha-research-discipline

Date: 2026-05-09
Scope: Closes every remaining item from the original audit. Cumulative
patch including everything from `v0.9.1` and `v1.0.0-alpha`, plus six new
fixes that close the original v0.9.0 audit completely.

This is still alpha. The product is not validated for clinical use.

---

## What changed since v1.0.0-alpha

### M1 — `AxisMatcher.kt` consolidation

`matchAxes` (in ResearchAutopilot) and `inferAxes` (in ResearchKnowledgeStore)
were two near-duplicate dictionaries. The same input could produce different
axis sets depending on which engine called it — silent classification drift.

Fix: new `AxisMatcher` object holds the canonical 15-axis dictionary as a
single source of truth. Both legacy methods now delegate to it. New
`AxisMatcherTest` (11 tests) documents the keyword set so future edits are
deliberate, not accidental.

Regressions caught and reinstated: `frailty` for aging, `vascular`/`heart rate`
for autonomic, `chromatin` for DNA, `male hormone` for testosterone, `mast`
without "cell" for type-2 — all of these were in `matchAxes` but missing from
`inferAxes`.

### M2 — Coroutine + lifecycleScope migration

`ResearchAutopilotActivity` previously launched a raw `Thread` that:
- leaked Activity context on rotation/destroy
- could trigger ANRs if save happened during destroy
- had no structured cancellation (only a `@Volatile stopRequested` flag)

Fix: migrated to `ComponentActivity` and `lifecycleScope.launch(Dispatchers.IO)`.
The cycle is now:
- automatically cancelled when the Activity is destroyed
- cancellable via `researchJob?.cancel()` from the Stop button
- cleanly separated between IO and Main threads via `withContext(Dispatchers.Main)`

### M3 — `ActivityResultContracts` migration

Replaced the deprecated `startActivityForResult` / `onActivityResult` pair
with `registerForActivityResult(ActivityResultContracts.OpenDocument())`.
The launcher is registered as a property and called via `.launch(...)` from
the import button. No more `@Deprecated` warning, no request-code constant.

### M4 — `BiologicalPlausibilityGraph` ↔ JSON parity

The hardcoded Kotlin graph had 9 edges; the asset JSON `v0.1` had 7. Drift
without contract.

Fix:
- Added `biological_plausibility_graph_v0.2.json` with all 9 edges + the
  scoring constants (base_score, edge_bonus, omics_bonus, multi_axis_bonus).
- Added `BiologicalPlausibilityGraphTest.json_asset_matches_Kotlin_edges`
  that fails if you edit one without the other.
- Added a docblock on the Kotlin object pointing to the JSON spec and the
  enforcing test, with a clear rationale for keeping both.

### M5 — Statistical sanity flags emitted in finding output

`CANONICAL_SCORING_FORMULA_v0.9.1.md` documented sanity gates as PLANNED;
v1.1 wires them in:

`ResearchFinding` now carries a `sanityFlags: List<String>` field
(default empty for backward compatibility). `ResearchAutopilot.buildFindingFromDoc`
sets:
- `ABSTRACT_FETCH_FAILED` — efetch returned nothing for this PMID.
- `METADATA_ONLY` — species was unknown AND no abstract was retrieved.
  When set, evidence_quality is capped at 45 to prevent metadata-only
  sources from ranking with full-text-evidence sources.
- `LOW_POWER` — `repeatedObservationCount` is 1 or 2 (one or two repeats
  is suggestive but underpowered).

`ResearchJsonCodec.findingToJson` now serialises `sanityFlags`, so saved
reports and exports show them.

### M6 — Removed `OmicsResearchAxis.kt` (dead code)

`grep` confirmed `OmicsResearchAxis` was defined but never called anywhere.
The fractional 0..1 score I flagged earlier was never read. Removing rather
than fixing dead code reduces the surface that future contributors can
mis-use. If genuine omics handling is needed in v2.0, build it deliberately
on top of `AxisMatcher`.

---

## Cumulative changes since v0.9.0

This release rolls in every previous patch:

| Patch | What | Detail |
|---|---|---|
| **P1** | versionCode/Name | Was 3 versions stale |
| **P2** | Canonical scoring | Single doc + Python ↔ Kotlin parity |
| **P3** | Steering PII sanitiser | Closes the README privacy claim |
| **P4** | SourceClassifier | mixed/synthesis humanEvidence regressions |
| **P5** | Causality + neg-control | Negative-control now in numeric score |
| **P6** | NCBI compliance | tool/email/api_key + batched esummary + retry |
| **P7** | append-only writes | Eliminates O(n²) flash I/O |
| **A** | Unit tests | 50 JUnit tests across 6 classes |
| **B** | Abstract fetch | efetch.fcgi + tolerant parser |
| **C** | Permutation neg-control | 1000 shuffles + Phipson-Smyth p-value |
| **M1** | AxisMatcher | Single axis-classification source |
| **M2** | Coroutines | lifecycleScope + Dispatchers + structured cancel |
| **M3** | ActivityResultContracts | Modern result-API |
| **M4** | Graph JSON parity | Edge-set parity test |
| **M5** | Sanity flags | METADATA_ONLY, LOW_POWER, ABSTRACT_FETCH_FAILED |
| **M6** | Dead-code removal | Deleted OmicsResearchAxis |

## Files added / changed in v1.1

```text
ADDED  app/src/main/java/com/immunesignal/app/AxisMatcher.kt
ADDED  app/src/main/assets/biological_plausibility_graph_v0.2.json
ADDED  app/src/test/java/com/immunesignal/app/AxisMatcherTest.kt
DELETED app/src/main/java/com/immunesignal/app/OmicsResearchAxis.kt   (dead code)

CHANGED  app/build.gradle.kts                  (+coroutines, +activity-ktx, +lifecycle-runtime-ktx)
CHANGED  app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt  (ComponentActivity + coroutines + ActivityResultContracts)
CHANGED  app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt          (matchAxes delegates + sanity flags)
CHANGED  app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt     (inferAxes delegates)
CHANGED  app/src/main/java/com/immunesignal/app/ResearchModels.kt             (sanityFlags field + serialisation)
CHANGED  app/src/main/java/com/immunesignal/app/BiologicalPlausibilityGraph.kt (parity docblock)
CHANGED  app/src/test/java/com/immunesignal/app/BiologicalPlausibilityGraphTest.kt (json parity test)
```

## Test count by class

```
AxisMatcherTest                       11 tests
BiologicalPlausibilityGraphTest        5 tests
CausalityScorerTest                    7 tests
HypothesisRankingEngineTest            5 tests
SourceClassifierTest                   7 tests
SteeringSanitizerTest                 10 tests
AbstractParserTest                     4 tests
                                    ─────
                                      49 tests total
```

## Validation actually run

```text
JSON parse:               PASS  (26 asset files)
Kotlin delimiter audit:   PASS  (39 source files, main + test)
XML parse:                PASS
Layout ID check:          PASS
Research Python checks:   PASS
Permutation neg-control:  forward p=0.001 / reverse p=0.45 on synthetic
                          forward signal — verdict correct.
Parity fixtures:          7 canonical expected values written to
                          research/expected_parity_v1.1.json.
```

Limitation: full Android Gradle build was not executed in the patch
container (no Android SDK). Run `./gradlew :app:assembleDebug` and
`./gradlew :app:testDebugUnitTest` locally or via CI.

## Risk register

1. **Tests not actually executed** in the patch container — only static
   delimiter + Python checks. Run `./gradlew :app:testDebugUnitTest`
   before tagging release. All 49 tests use pure JVM (no Robolectric).
2. **`SteeringSanitizer` whitelist is intentionally narrow.** Legitimate
   medical terms not in the list will be flagged. Expand `safeStems` as
   real-world false rejections appear.
3. **Coroutines dependency adds ~700 KB to the APK.** Acceptable trade-off
   for the lifecycle-leak fix; acknowledge in release notes.
4. **`ComponentActivity` migration changes how the OS treats this Activity.**
   Layout uses only basic widgets so AppCompat is not required, but if
   a future feature pulls in an AppCompat widget, it will need
   `AppCompatActivity` or theme migration.
5. **JSON parity test may skip in CI** if working directory differs.
   The test currently uses a relative path with a graceful skip; for
   hard enforcement, switch to a Gradle resource copy in `src/test/resources/`.

## Status of the original audit

Every issue I raised in the initial feasibility study now has either a
landed patch or a documented deferral with rationale.

**Closed:**
- Scoring drift between Python and Kotlin
- Privacy contract violation in steering inputs
- versionCode/Name mismatch
- SourceClassifier humanEvidence regressions
- Negative-control not in causality score
- NCBI compliance and rate-limit handling
- O(n²) flash I/O on every cycle
- Title-only evidence classification
- Single-shuffle negative-control test
- No unit tests
- matchAxes / inferAxes drift
- Raw Thread + Activity-leak risk
- onActivityResult deprecation
- BiologicalPlausibilityGraph JSON / Kotlin drift
- No statistical sanity flags
- OmicsResearchAxis dead code

**Deferred to v2.0 (with rationale):**
- WorkManager-based background runs (current lifecycle is good enough for
  the foreground-only use case)
- Permutation test on Android (currently Python-only — embedding 1000-shuffle
  Pearson on-device would require porting; deferred until users actually
  collect enough data to benefit)
- Full ComponentActivity → AppCompatActivity migration (waiting on Material
  components actually being needed)
- W3C VC / RFC-3161 export for findings (not yet a real-world ask)
