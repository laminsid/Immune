# Immune Error Radar v1.4.3-alpha — Route Cleanup & Path Audit

## Purpose
v1.4.3 is a cleanup and path-verification release after v1.4.2. It does not add new biology, ML, diagnosis, or treatment behavior. It closes stale runtime paths and makes every report handoff actionable.

## Changes
- Active engine updated to `v1.4.3-alpha-route-cleanup`.
- Legacy `ResultActivity` is no longer registered in the runtime manifest.
- First screen text cleaned: no old daily scan/symptom-input framing.
- `ResearchStateEngine.actionableSummary(...)` rewrites generic handoffs into executable next-evidence actions.
- Empty default `Next Evidence` no longer says “run a cycle or import a report”; it now points to direct dataset hunt.
- Reports now preserve dataset parser/intelligence output while giving clearer next actions.
- Static checks now fail when:
  - legacy ResultActivity is registered,
  - legacy daily/symptom text appears on the first page,
  - generic non-actionable next-evidence text remains,
  - required v1.4.3 routing tokens are missing.

## Non-goals
- No clinical prediction.
- No diagnosis.
- No treatment recommendation.
- No new biological axes.
- No ML / Random Forest / Hypergraph Neural Network.
- No human-hypothesis upgrade from animal/cell evidence.
