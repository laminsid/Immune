package com.immunesignal.app

/** User-triggered public data resolver plan; not a background scraper. */
data class GTIMOpenDataResolverReportV256(
    val active: Boolean,
    val version: String,
    val status: String,
    val resolverActions: List<GTIMPublicResolverActionV257>,
    val supportedSources: List<String>,
    val blockedBehaviors: List<String>,
    val playProtectPosture: String,
    val githubPosture: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty() = GTIMOpenDataResolverReportV256(
            active = false,
            version = GTIMOpenDataResolverV256.VERSION,
            status = "GTIM_OPEN_DATA_RESOLVER_IDLE",
            resolverActions = emptyList(),
            supportedSources = GTIMOpenDataResolverV256.SUPPORTED_SOURCES,
            blockedBehaviors = GTIMOpenDataResolverV256.BLOCKED_BEHAVIORS,
            playProtectPosture = "not evaluated",
            githubPosture = "not evaluated"
        )
    }
}

object GTIMOpenDataResolverV256 {
    const val VERSION: String = "2.6.3-alpha-safe-launch-ui-stability"
    val SUPPORTED_SOURCES = listOf("PubMed/Europe PMC", "GEO/GDS", "SRA/BioProject", "ArrayExpress/BioStudies", "ImmPort/SDY", "Manual PMID/DOI/PDF/snippet seed")
    val BLOCKED_BEHAVIORS = listOf("No hidden background scraping", "No patient data upload", "No tracking", "No clinical decision", "Public data lookup only", "User-triggered network action")

    fun plan(plan: GTIMDataFeedPlanV255, dataFeed: GTIMOpenDiscoveryDataFeedReportV254, dashboard: GTIMProfessorDiscoveryDashboardReportV257): GTIMOpenDataResolverReportV256 {
        val actions = dashboard.publicDataResolverActions.ifEmpty {
            (plan.repositorySearchPlan.map { query ->
                GTIMPublicResolverActionV257(
                    sourceFamily = query.repository,
                    actionType = query.purpose,
                    queryOrSeed = query.query,
                    userTriggerRequired = true,
                    expectedClosure = query.metadataTargets.take(5).joinToString(", "),
                    blockedClaims = GTIMProfessorDiscoveryDashboardV257.BLOCKED_MISUSES,
                    playProtectPosture = "Run only when user starts lookup"
                )
            } + dataFeed.dataFeedingChannels.map { channel ->
                GTIMPublicResolverActionV257(
                    sourceFamily = channel.sourceFamily,
                    actionType = channel.intakeMode,
                    queryOrSeed = channel.querySeed,
                    userTriggerRequired = true,
                    expectedClosure = channel.expectedGain,
                    blockedClaims = GTIMProfessorDiscoveryDashboardV257.BLOCKED_MISUSES,
                    playProtectPosture = channel.playProtectPosture
                )
            }).distinctBy { it.sourceFamily + it.queryOrSeed }.take(12)
        }
        return GTIMOpenDataResolverReportV256(
            active = actions.isNotEmpty(),
            version = VERSION,
            status = if (actions.isNotEmpty()) "GTIM_USER_TRIGGERED_PUBLIC_DATA_RESOLVER_READY" else "GTIM_OPEN_DATA_RESOLVER_WAITING_FOR_INTENT",
            resolverActions = actions.take(12),
            supportedSources = SUPPORTED_SOURCES,
            blockedBehaviors = BLOCKED_BEHAVIORS,
            playProtectPosture = "User-triggered public lookup only; no background scraping, no hidden telemetry, no patient data upload, no sensitive Android permissions.",
            githubPosture = "Resolver plan is deterministic and static-audit visible; CI does not require network calls."
        )
    }
}
