package com.immunesignal.app

/**
 * GTIM v2.5.7 Professor-facing discovery dashboard and user-triggered public data resolver plan.
 *
 * This layer does not perform background network work. It closes the product surface gap by turning
 * intent + data-feed + discovery/evidence split into a researcher-readable dashboard, a graph-ready
 * model, and explicit user-started public resolver actions. It keeps evidence and clinical gates
 * unchanged.
 */
data class GTIMPublicResolverActionV257(
    val sourceFamily: String,
    val actionType: String,
    val queryOrSeed: String,
    val userTriggerRequired: Boolean,
    val expectedClosure: String,
    val blockedClaims: List<String>,
    val playProtectPosture: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMGraphNodeV257(
    val nodeId: String,
    val label: String,
    val nodeType: String,
    val evidenceState: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMGraphEdgeV257(
    val fromNodeId: String,
    val toNodeId: String,
    val relation: String,
    val supportLevel: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMProfessorDiscoveryDashboardReportV257(
    val active: Boolean,
    val version: String,
    val status: String,
    val dashboardSummary: String,
    val discoveryView: List<String>,
    val evidenceView: List<String>,
    val contradictionView: List<String>,
    val publicDataResolverActions: List<GTIMPublicResolverActionV257>,
    val graphNodes: List<GTIMGraphNodeV257>,
    val graphEdges: List<GTIMGraphEdgeV257>,
    val nextBestActions: List<String>,
    val blockedMisuses: List<String>,
    val playProtectPosture: String,
    val githubPosture: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty() = GTIMProfessorDiscoveryDashboardReportV257(
            active = false,
            version = GTIMProfessorDiscoveryDashboardV257.VERSION,
            status = "GTIM_PROFESSOR_DASHBOARD_IDLE",
            dashboardSummary = "Professor-facing discovery dashboard not evaluated.",
            discoveryView = emptyList(),
            evidenceView = emptyList(),
            contradictionView = emptyList(),
            publicDataResolverActions = emptyList(),
            graphNodes = emptyList(),
            graphEdges = emptyList(),
            nextBestActions = emptyList(),
            blockedMisuses = GTIMProfessorDiscoveryDashboardV257.BLOCKED_MISUSES,
            playProtectPosture = "not evaluated",
            githubPosture = "not evaluated"
        )
    }
}

object GTIMProfessorDiscoveryDashboardV257 {
    const val VERSION: String = "2.6.3-alpha-safe-launch-ui-stability"
    const val STATUS_READY: String = "GTIM_PROFESSOR_DASHBOARD_READY"
    val BLOCKED_MISUSES: List<String> = listOf(
        "No diagnosis, treatment, dose, supplement, or patient-specific prediction",
        "No DGE/fold-change/p-value from semantic priors or text-mined leads",
        "No confirmed mechanism from candidate route, manual snippet, cross-species support, or data-feed plan",
        "No hidden background scraping, patient data upload, tracking, or uncontrolled API polling"
    )

    fun build(
        intent: GTIMResearchIntentObjectV255,
        plan: GTIMDataFeedPlanV255,
        split: GTIMDiscoveryEvidenceSplitReportV256,
        dataFeed: GTIMOpenDiscoveryDataFeedReportV254
    ): GTIMProfessorDiscoveryDashboardReportV257 {
        if (!intent.active && !split.active && !dataFeed.active) return GTIMProfessorDiscoveryDashboardReportV257.empty()
        val route = split.candidateRoutes.firstOrNull()
        val summary = when {
            intent.active && route != null -> "Question parsed; candidate route built; evidence upgrade remains gated."
            intent.active -> "Question parsed; data-feed plan is ready; candidate route requires stronger terms or seed."
            else -> "Open discovery surface is ready; structured intake is recommended."
        }
        val resolverActions = buildResolverActions(plan, dataFeed)
        val nodes = buildGraphNodes(intent, split)
        val edges = buildGraphEdges(nodes, split)
        return GTIMProfessorDiscoveryDashboardReportV257(
            active = true,
            version = VERSION,
            status = STATUS_READY,
            dashboardSummary = summary,
            discoveryView = listOf(
                "Parsed intent completeness: ${intent.intentCompletenessScore}/100",
                "Candidate routes: ${split.candidateRoutes.size}; discovery value: ${split.threeDimensionalScore.discoveryValueScore}/100",
                "Best route: ${route?.cascade?.joinToString(" → ") ?: "not built yet"}",
                "Best repository query: ${plan.repositorySearchPlan.firstOrNull()?.query ?: dataFeed.dataFeedingChannels.firstOrNull()?.querySeed ?: "feed one PMID/DOI/accession/PDF/snippet seed"}"
            ),
            evidenceView = listOf(
                "Data Quality: ${split.threeDimensionalScore.dataQualityScore}/100",
                "Evidence confidence: ${split.threeDimensionalScore.evidenceConfidenceScore}/100",
                "Evidence upgrade remains locked until accession/comparator/matrix/metadata/contradiction gaps close.",
                "Candidate route is not an evidence object; semantic prior is not an expression matrix."
            ),
            contradictionView = split.activeContradictionEngine.contradictionQueries.ifEmpty {
                listOf("Run null-result / no-association / opposite-direction search before upgrading any route.")
            }.take(6),
            publicDataResolverActions = resolverActions,
            graphNodes = nodes,
            graphEdges = edges,
            nextBestActions = listOf(
                plan.bestNextAction,
                dataFeed.immediateActions.firstOrNull() ?: "Feed one concrete research handle: PMID, DOI, GSE, PRJNA, SRP/SRR, E-MTAB, SDY, PDF, or snippet.",
                "Open contradiction search before raising confidence.",
                "Keep result as exploratory until evidence gates close."
            ).filter { it.isNotBlank() }.distinct().take(6),
            blockedMisuses = BLOCKED_MISUSES,
            playProtectPosture = "User-triggered public data resolver plan only; no background scraping, no hidden telemetry, no patient data upload, no sensitive Android permissions.",
            githubPosture = "Dashboard/resolver/graph surfaces are deterministic, JSON-visible, brief-visible, registry-visible, and covered by static audit."
        )
    }

    private fun buildResolverActions(plan: GTIMDataFeedPlanV255, dataFeed: GTIMOpenDiscoveryDataFeedReportV254): List<GTIMPublicResolverActionV257> {
        val fromPlan = plan.repositorySearchPlan.map { query ->
            GTIMPublicResolverActionV257(
                sourceFamily = query.repository,
                actionType = query.purpose,
                queryOrSeed = query.query,
                userTriggerRequired = true,
                expectedClosure = query.metadataTargets.take(5).joinToString(", ").ifBlank { "accession/comparator/matrix metadata" },
                blockedClaims = BLOCKED_MISUSES,
                playProtectPosture = "Run only when the user starts a public repository/literature lookup."
            )
        }
        val fromFeed = dataFeed.dataFeedingChannels.map { channel ->
            GTIMPublicResolverActionV257(
                sourceFamily = channel.sourceFamily,
                actionType = channel.intakeMode,
                queryOrSeed = channel.querySeed,
                userTriggerRequired = true,
                expectedClosure = channel.expectedGain,
                blockedClaims = BLOCKED_MISUSES,
                playProtectPosture = channel.playProtectPosture
            )
        }
        return (fromPlan + fromFeed)
            .distinctBy { it.sourceFamily + it.queryOrSeed }
            .take(12)
    }

    private fun buildGraphNodes(intent: GTIMResearchIntentObjectV255, split: GTIMDiscoveryEvidenceSplitReportV256): List<GTIMGraphNodeV257> {
        val terms = mutableListOf<Pair<String, String>>()
        terms += intent.triggerExposure.take(4).map { "trigger" to it }
        terms += intent.diseasePhenotype.take(4).map { "phenotype" to it }
        terms += intent.pathway.take(6).map { "pathway" to it }
        terms += intent.cellTissue.take(5).map { "cell_tissue" to it }
        split.candidateRoutes.firstOrNull()?.cascade?.take(6)?.forEach { terms += "route_node" to it }
        return terms.distinctBy { it.second.lowercase() }.take(20).mapIndexed { idx, pair ->
            GTIMGraphNodeV257(
                nodeId = "GTIM_NODE_${idx + 1}",
                label = pair.second,
                nodeType = pair.first,
                evidenceState = "DISCOVERY_NODE_NOT_CONFIRMED_EVIDENCE"
            )
        }
    }

    private fun buildGraphEdges(nodes: List<GTIMGraphNodeV257>, split: GTIMDiscoveryEvidenceSplitReportV256): List<GTIMGraphEdgeV257> {
        val routeLabels = split.candidateRoutes.firstOrNull()?.cascade.orEmpty()
        val edges = mutableListOf<GTIMGraphEdgeV257>()
        for (idx in 0 until routeLabels.size - 1) {
            val from = nodes.firstOrNull { it.label == routeLabels[idx] } ?: continue
            val to = nodes.firstOrNull { it.label == routeLabels[idx + 1] } ?: continue
            edges += GTIMGraphEdgeV257(
                fromNodeId = from.nodeId,
                toNodeId = to.nodeId,
                relation = "candidate_mechanism_bridge",
                supportLevel = "EXPLORATORY_ROUTE_NOT_EVIDENCE"
            )
        }
        if (edges.isEmpty() && nodes.size >= 2) {
            for (idx in 0 until minOf(nodes.size - 1, 6)) {
                edges += GTIMGraphEdgeV257(
                    fromNodeId = nodes[idx].nodeId,
                    toNodeId = nodes[idx + 1].nodeId,
                    relation = "graph_ready_visual_bridge",
                    supportLevel = "PLAUSIBILITY_ONLY_NOT_EVIDENCE"
                )
            }
        }
        return edges.take(12)
    }
}
