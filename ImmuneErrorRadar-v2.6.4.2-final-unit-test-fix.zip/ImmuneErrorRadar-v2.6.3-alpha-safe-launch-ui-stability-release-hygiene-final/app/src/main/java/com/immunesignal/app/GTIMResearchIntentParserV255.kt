package com.immunesignal.app

import java.util.Locale

/**
 * GTIM v2.5.5 Research Intent Parser.
 *
 * Converts a free-form or structured biomedical research question into a stable contract that
 * downstream route selection, data-feed planning, accession search, comparator mapping, matrix
 * readiness, contradiction search, and UI rendering can consume. This is intentionally local and
 * deterministic; it does not add network access, telemetry, or clinical inference.
 */
data class GTIMResearchIntentObjectV255(
    val active: Boolean,
    val parserVersion: String,
    val sourceText: String,
    val inputMode: String,
    val diseasePhenotype: List<String>,
    val triggerExposure: List<String>,
    val pathway: List<String>,
    val cellTissue: List<String>,
    val assayType: List<String>,
    val repositoryTargets: List<String>,
    val comparatorWanted: List<String>,
    val speciesPriority: String,
    val outputMode: String,
    val claimStrictness: String,
    val contradictionRequirement: String,
    val labValidationRequirement: String,
    val intentCompletenessScore: Int,
    val routeConstructionScore: Int,
    val queryReadinessScore: Int,
    val missingIntentFields: List<String>,
    val parsedResearchIntentCard: List<String>,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty(): GTIMResearchIntentObjectV255 = GTIMResearchIntentObjectV255(
            active = false,
            parserVersion = GTIMResearchIntentParserV255.VERSION,
            sourceText = "",
            inputMode = "NO_RESEARCH_INTENT_TEXT",
            diseasePhenotype = emptyList(),
            triggerExposure = emptyList(),
            pathway = emptyList(),
            cellTissue = emptyList(),
            assayType = emptyList(),
            repositoryTargets = GTIMResearchIntentParserV255.DEFAULT_REPOSITORIES,
            comparatorWanted = emptyList(),
            speciesPriority = "human_first_animal_auxiliary_only",
            outputMode = "discovery brief, no raw JSON by default",
            claimStrictness = "discovery_flexible_evidence_upgrade_strict_clinical_forbidden",
            contradictionRequirement = "contradiction/null-result search required for every candidate route",
            labValidationRequirement = "preliminary lab protocol draft allowed, not validation claim",
            intentCompletenessScore = 0,
            routeConstructionScore = 0,
            queryReadinessScore = 0,
            missingIntentFields = listOf("disease/phenotype", "trigger/exposure", "pathway", "cell/tissue", "assay", "comparator"),
            parsedResearchIntentCard = listOf("Parsed Research Intent: not available")
        )
    }
}

object GTIMResearchIntentParserV255 {
    const val VERSION: String = "2.6.3-alpha-safe-launch-ui-stability"
    const val STATE_INTENT_PARSED: String = "INTENT_PARSED_OPEN_DISCOVERY"

    val DEFAULT_REPOSITORIES: List<String> = listOf(
        "GEO", "SRA", "ArrayExpress", "BioProject", "ImmPort", "PubMed Data Availability", "Manual PMID/DOI/PDF/snippet seed"
    )

    private val structuredKeys: Map<String, Regex> = mapOf(
        "disease" to Regex("(?im)^\\s*(Disease\\s*/\\s*phenotype|Disease|Phenotype)\\s*:\\s*(.+)$"),
        "trigger" to Regex("(?im)^\\s*(Trigger\\s*/\\s*exposure|Trigger|Exposure)\\s*:\\s*(.+)$"),
        "pathway" to Regex("(?im)^\\s*(Pathway|Suspected pathway)\\s*:\\s*(.+)$"),
        "cell" to Regex("(?im)^\\s*(Cell\\s*/\\s*tissue|Cell|Tissue)\\s*:\\s*(.+)$"),
        "assay" to Regex("(?im)^\\s*(Assay|Assay type)\\s*:\\s*(.+)$"),
        "repository" to Regex("(?im)^\\s*(Repositories|Repository target|Must-search repositories)\\s*:\\s*(.+)$"),
        "comparator" to Regex("(?im)^\\s*(Comparator|Comparator wanted)\\s*:\\s*(.+)$"),
        "contradiction" to Regex("(?im)^\\s*(Contradiction|Main contradiction to check)\\s*:\\s*(.+)$"),
        "output" to Regex("(?im)^\\s*(Output|Output mode)\\s*:\\s*(.+)$")
    )

    fun parse(question: String, fallbackAxis: String = ""): GTIMResearchIntentObjectV255 {
        val raw = listOf(question, fallbackAxis).filter { it.isNotBlank() }.joinToString("\n").trim()
        if (raw.isBlank()) return GTIMResearchIntentObjectV255.empty()
        val structured = structuredKeys.mapValues { (_, regex) -> regex.find(raw)?.groupValues?.getOrNull(2).orEmpty() }
        val structuredMode = structured.values.any { it.isNotBlank() }
        val disease = splitTerms(structured["disease"]).ifEmpty { extractTerms(raw, DISEASE_TERMS) }
        val trigger = splitTerms(structured["trigger"]).ifEmpty { extractTerms(raw, TRIGGER_TERMS) }
        val pathway = splitTerms(structured["pathway"]).ifEmpty { extractTerms(raw, PATHWAY_TERMS) }
        val cell = splitTerms(structured["cell"]).ifEmpty { extractTerms(raw, CELL_TISSUE_TERMS) }
        val assay = splitTerms(structured["assay"]).ifEmpty { extractTerms(raw, ASSAY_TERMS) }
        val repositories = splitTerms(structured["repository"]).ifEmpty { extractTerms(raw, REPOSITORY_TERMS).ifEmpty { DEFAULT_REPOSITORIES } }
        val comparator = splitTerms(structured["comparator"]).ifEmpty { extractComparator(raw) }
        val contradiction = structured["contradiction"]?.takeIf { it.isNotBlank() }
            ?: if (raw.contains("contradiction", true) || raw.contains("null", true) || raw.contains("opposite", true)) {
                "active contradiction/null-result search requested"
            } else {
                "contradiction/null-result search required by GTIM policy"
            }
        val output = structured["output"]?.takeIf { it.isNotBlank() }
            ?: if (raw.contains("no raw JSON", true) || raw.contains("discovery brief", true)) "discovery brief, hide raw JSON and command trace" else "discovery brief, technical appendix hidden by default"

        val missing = buildList {
            if (disease.isEmpty()) add("disease/phenotype")
            if (trigger.isEmpty()) add("trigger/exposure")
            if (pathway.isEmpty()) add("pathway")
            if (cell.isEmpty()) add("cell/tissue")
            if (assay.isEmpty()) add("assay")
            if (comparator.isEmpty()) add("comparator")
        }
        val completeness = scoreCompleteness(disease, trigger, pathway, cell, assay, repositories, comparator)
        val routeScore = listOf(trigger, disease, pathway, cell).count { it.isNotEmpty() } * 20 + if (comparator.isNotEmpty()) 10 else 0
        val queryScore = listOf(repositories, assay, disease, trigger).count { it.isNotEmpty() } * 22 + if (comparator.isNotEmpty()) 8 else 0
        val card = listOf(
            "Parsed Research Intent",
            "Trigger: ${trigger.joinToString(", ").ifBlank { "not specified" }}",
            "Disease / phenotype: ${disease.joinToString(", ").ifBlank { "not specified" }}",
            "Pathway: ${pathway.joinToString(", ").ifBlank { "not specified" }}",
            "Cell / tissue: ${cell.joinToString(", ").ifBlank { "not specified" }}",
            "Comparator: ${comparator.joinToString(", ").ifBlank { "not specified" }}",
            "Assay: ${assay.joinToString(", ").ifBlank { "not specified" }}",
            "Repositories: ${repositories.joinToString(", ")}",
            "Output mode: $output",
            "Claim strictness: discovery flexible; evidence upgrade strict; clinical claims forbidden"
        )
        return GTIMResearchIntentObjectV255(
            active = true,
            parserVersion = VERSION,
            sourceText = raw.take(4000),
            inputMode = if (structuredMode) "STRUCTURED_INTAKE" else "FREE_TEXT_EXTRACTED_INTENT",
            diseasePhenotype = disease.take(10),
            triggerExposure = trigger.take(10),
            pathway = pathway.take(12),
            cellTissue = cell.take(10),
            assayType = assay.take(8),
            repositoryTargets = repositories.take(10),
            comparatorWanted = comparator.take(8),
            speciesPriority = if (raw.contains("animal", true) || raw.contains("mouse", true) || raw.contains("mice", true)) "human_first_cross_species_auxiliary_only" else "human_first_animal_auxiliary_only",
            outputMode = output,
            claimStrictness = "discovery_flexible_evidence_upgrade_strict_clinical_forbidden",
            contradictionRequirement = contradiction,
            labValidationRequirement = "preliminary lab protocol draft required for candidate routes; draft is not validation",
            intentCompletenessScore = completeness.coerceIn(0, 100),
            routeConstructionScore = routeScore.coerceIn(0, 100),
            queryReadinessScore = queryScore.coerceIn(0, 100),
            missingIntentFields = missing,
            parsedResearchIntentCard = card
        )
    }

    private fun scoreCompleteness(
        disease: List<String>,
        trigger: List<String>,
        pathway: List<String>,
        cell: List<String>,
        assay: List<String>,
        repositories: List<String>,
        comparator: List<String>
    ): Int {
        var score = 0
        if (disease.isNotEmpty()) score += 18
        if (trigger.isNotEmpty()) score += 18
        if (pathway.isNotEmpty()) score += 16
        if (cell.isNotEmpty()) score += 14
        if (assay.isNotEmpty()) score += 12
        if (repositories.isNotEmpty()) score += 10
        if (comparator.isNotEmpty()) score += 12
        return score
    }

    private fun splitTerms(value: String?): List<String> {
        if (value.isNullOrBlank()) return emptyList()
        return value
            .split(";", ",", "|", "→", ">", " and ", " AND ", " or ", " OR ")
            .map { normalizeLabel(it) }
            .filter { it.length >= 2 }
            .distinctBy { it.lowercase(Locale.US) }
    }

    private fun extractTerms(text: String, terms: List<String>): List<String> {
        val lower = text.lowercase(Locale.US)
        return terms.filter { term -> termMatches(lower, term) }
            .map { canonical(it) }
            .distinctBy { it.lowercase(Locale.US) }
    }

    private fun termMatches(lowerText: String, term: String): Boolean {
        val needle = term.lowercase(Locale.US)
        return if (needle.length <= 3 && needle.all { it.isLetterOrDigit() }) {
            Regex("(?<![a-z0-9])${Regex.escape(needle)}(?![a-z0-9])").containsMatchIn(lowerText)
        } else {
            lowerText.contains(needle)
        }
    }

    private fun extractComparator(text: String): List<String> {
        val comparators = mutableListOf<String>()
        val lower = text.lowercase(Locale.US)
        if (lower.contains("healthy")) comparators += "healthy controls"
        if (lower.contains("recovered")) comparators += "recovered controls"
        if (lower.contains("matched")) comparators += "matched controls"
        if (lower.contains("baseline")) comparators += "baseline"
        if (lower.contains("placebo")) comparators += "placebo"
        if (lower.contains("responder")) comparators += "responder/non-responder"
        if (lower.contains("exposed") || lower.contains("unexposed")) comparators += "exposed/unexposed"
        if (Regex("\bvs\b|versus|compared to|compare|comparison", RegexOption.IGNORE_CASE).containsMatchIn(text)) comparators += "case vs control comparison"

        // v2.6.4 closure: cross-disease comparison must be captured at intent time,
        // before the learning loop has any findings. This is still routing only.
        val comparativeHits = listOf("cancer", "tumor", "hiv", "aids", "fungal", "candida", "aspergillus", "epidemic", "pandemic", "outbreak")
            .filter { lower.contains(it) }
            .distinct()
        if (comparativeHits.size >= 2) comparators += "cross-disease comparator: ${comparativeHits.take(6).joinToString(" vs ")}"
        return comparators.distinct()
    }

    private fun normalizeLabel(value: String): String = value.trim().trim('.', ':', '-', '—').replace(Regex("\\s+"), " ")

    private fun canonical(term: String): String = when (term.lowercase(Locale.US)) {
        "pasc" -> "Long COVID / PASC"
        "long covid" -> "Long COVID / PASC"
        "sars-cov-2" -> "SARS-CoV-2"
        "hhv-6" -> "HHV-6"
        "ebv" -> "EBV"
        "hiv" -> "HIV/AIDS"
        "aids" -> "HIV/AIDS"
        "tumor" -> "Cancer / tumor immune evasion"
        "cancer" -> "Cancer / tumor immune evasion"
        "fungal" -> "Fungal disease / Th17-neutrophil defense"
        "fungi" -> "Fungal disease / Th17-neutrophil defense"
        "pandemic" -> "Epidemic / pandemic immune response"
        "epidemic" -> "Epidemic / pandemic immune response"
        "outbreak" -> "Epidemic / pandemic immune response"
        "tnf" -> "TNF"
        "il-6" -> "IL-6"
        "il6" -> "IL-6"
        "il-17" -> "IL-17"
        "pd-1" -> "PD-1"
        "pd-l1" -> "PD-L1"
        "pbmc" -> "PBMC"
        "scrna-seq" -> "scRNA-seq"
        "single-cell" -> "single-cell RNA-seq"
        else -> normalizeLabel(term)
    }

    private val DISEASE_TERMS = listOf(
        "Long COVID", "PASC", "SLE", "Systemic Lupus", "RA", "rheumatoid arthritis", "MS", "multiple sclerosis", "ME/CFS", "fatigue", "brain fog", "arthralgia", "allergy", "hypersensitivity", "autoimmune", "post-viral",
        "cancer", "tumor", "oncology", "HIV", "AIDS", "fungal", "fungi", "Candida", "Aspergillus", "epidemic", "pandemic", "outbreak", "COVID", "post-infectious"
    )
    private val TRIGGER_TERMS = listOf(
        "EBV", "HHV-6", "SARS-CoV-2", "COVID", "viral reactivation", "virus", "vaccine", "antibiotic", "IL-6 inhibitor", "TNF inhibitor", "JAK inhibitor", "Rituximab", "corticosteroid", "allergen", "microbiome",
        "tumor antigen", "chronic antigen", "viral load", "opportunistic infection", "fungal infection", "pathogen", "variant", "wave", "outbreak exposure", "immune checkpoint exposure"
    )
    private val PATHWAY_TERMS = listOf(
        "interferon", "IL-6", "IL6", "TNF", "T-cell exhaustion", "B-cell", "autoantibody", "cytokine", "mast cell", "IgE", "eosinophil", "IL-4", "IL-5", "IL-13", "JAK/STAT", "NF-kB", "mitochondrial", "inflammation",
        "PD-1", "PD-L1", "CTLA-4", "CD4 depletion", "CD8 exhaustion", "Th17", "IL-17", "IL-23", "neutrophil", "Dectin-1", "CARD9", "macrophage activation", "cytokine storm", "endothelial injury", "interferon timing"
    )
    private val CELL_TISSUE_TERMS = listOf(
        "PBMC", "T cells", "B cells", "monocytes", "macrophage", "mast cells", "eosinophils", "synovial", "blood", "plasma", "serum", "epithelial", "tissue", "organoid",
        "CD4 T cells", "CD8 T cells", "TIL", "tumor-infiltrating lymphocytes", "neutrophils", "dendritic cells", "mucosal tissue", "tumor microenvironment"
    )
    private val ASSAY_TERMS = listOf("RNA-seq", "scRNA-seq", "single-cell", "microarray", "transcriptome", "cytokine profiling", "flow cytometry", "qPCR", "Western blot", "ELISA", "proteomics", "metabolomics", "CyTOF", "Olink", "TCR-seq", "BCR-seq")
    private val REPOSITORY_TERMS = listOf("GEO", "GDS", "SRA", "BioProject", "PRJNA", "ArrayExpress", "E-MTAB", "ImmPort", "SDY", "PubMed", "PMC", "Europe PMC", "Data Availability")
}
