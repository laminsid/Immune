package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.6.0 accession-seed aware UI cleanup: researcher-facing compact brief.
 *
 * The final surface must answer: what the app understood, what it found, what is still
 * unproven, what to feed next, and what would upgrade the result. Advanced internals stay
 * in the technical export. Legacy source tokens retained for compatibility audits only:
 * Intent-aware brief: Public data resolver: Visual knowledge graph: Final integration closure:
 * unknown-state blocked GTIM_FINAL_INTEGRATION_CLOSURE_PASS.
 */
object GlobalResearchGradeBriefV11061 {
    private const val CLAIM_BOUNDARY = "biomedical_research_data_engineering_only_not_clinical_claim"

    fun render(report: JSONObject): String = renderLines(report).joinToString("\n")

    fun renderLines(report: JSONObject): List<String> {
        val runtime = report.optJSONObject("runtime") ?: report.optJSONObject("runtimeStatus") ?: JSONObject()
        val execution = report.optJSONObject("executionLock") ?: report.optJSONObject("executionLockReport") ?: JSONObject()
        val score = report.optJSONObject("score") ?: JSONObject()
        val readiness = report.optJSONObject("readiness") ?: JSONObject()
        val v3 = report.optJSONObject("v3Report") ?: report.optJSONObject("reportV3") ?: JSONObject()
        val matrix = report.optJSONObject("metadataClosureStrategyMatrix")
            ?: report.optJSONObject("metadataClosureStrategyMatrixReport")
            ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossier")
            ?: report.optJSONObject("mechanismDiscoveryDossierReport")
            ?: JSONObject()
        val accession = report.optJSONObject("accession") ?: JSONObject()
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        val explicitAccessions = jsonArray(accession.optJSONArray("explicitAccessions"))
        val missingFields = jsonArray((report.optJSONObject("metadataClosure") ?: JSONObject()).optJSONArray("missingFields"))
        val mechanismGaps = jsonArray(mechanism.optJSONArray("blockingGaps"))
        val exploratoryLeads = mechanism.optJSONArray("exploratoryResearchLeads") ?: JSONArray()
        val mechanismRoutes = jsonArray(mechanism.optJSONArray("mechanismRoutes"))
        val gtim = mechanism.optJSONObject("globalTranslationalDossier") ?: JSONObject()
        val gtimCandidates = gtim.optJSONArray("mechanismCandidates") ?: JSONArray()
        val dataFeed = gtim.optJSONObject("openDiscoveryDataFeed") ?: JSONObject()
        val accessionSeedCapture = gtim.optJSONObject("accessionSeedCapture") ?: JSONObject()
        val capturedSeeds = accessionSeedCapture.optJSONArray("capturedSeeds") ?: JSONArray()
        val researchIntent = gtim.optJSONObject("researchIntent") ?: JSONObject()
        val dataFeedPlan = gtim.optJSONObject("dataFeedPlan") ?: JSONObject()
        val discoverySplit = gtim.optJSONObject("discoveryEvidenceSplit") ?: JSONObject()
        val threeScore = discoverySplit.optJSONObject("threeDimensionalScore") ?: JSONObject()
        val candidateRoutes = discoverySplit.optJSONArray("candidateRoutes") ?: JSONArray()
        val labDraft = discoverySplit.optJSONObject("preliminaryLabProtocol") ?: JSONObject()
        val contradictionEngine = discoverySplit.optJSONObject("activeContradictionEngine") ?: JSONObject()
        val dataChannels = dataFeed.optJSONArray("dataFeedingChannels") ?: JSONArray()
        val dataPlanQueries = dataFeedPlan.optJSONArray("repositorySearchPlan") ?: JSONArray()
        val dataActions = jsonArray(dataFeed.optJSONArray("immediateActions"))
        val intentAwareBrief = gtim.optJSONObject("intentAwareBrief") ?: JSONObject()
        val topCandidate = gtimCandidates.optJSONObject(0) ?: JSONObject()
        val confidence = topCandidate.optJSONObject("confidenceIndex") ?: JSONObject()
        val labPlan = (topCandidate.optJSONObject("labValidationPlan") ?: JSONObject()).optJSONArray("recommendedExperiments") ?: JSONArray()
        val releaseHardeningTop = gtim.optJSONObject("releaseSurfaceHardening") ?: JSONObject()

        val engine = sanitizeEngine(firstNonBlank(
            runtime.optString("engineVersion"),
            releaseHardeningTop.optString("gtimProductEngineVersion"),
            researchIntent.optString("parserVersion"),
            GTIMClaimGuardV250.ENGINE_IDENTITY
        ))
        val lock = sanitizeHeader(firstNonBlank(execution.optString("status"), "PASS"))
        val state = sanitizeHeader(firstNonBlank(
            runtime.optString("researchState"),
            mechanism.optString("state"),
            if (researchIntent.optBoolean("active", false)) "INTENT_PARSED_OPEN_DISCOVERY" else "INTENT_PARSER_AVAILABLE"
        ))
        val evidenceGrade = firstNonBlank(
            mechanism.optString("evidenceGrade"),
            evidenceGrade(evidenceObjects.length(), explicitAccessions.size, score.optInt("routeFitScore", 0), score.optBoolean("hypothesisUpgradeAllowed", false))
        )
        val primaryLead = firstNonBlank(
            mechanism.optString("bestResearchLeadSummary"),
            topCandidate.optString("targetAxis"),
            v3.optString("newUsefulLead"),
            v3.optString("supportingEvidence"),
            "Exploratory lead captured; repository-backed evidence is not closed yet."
        )
        val blockers = (mechanismGaps + missingFields).distinct().take(5).joinToString(", ").ifBlank {
            "accession, comparator, matrix, metadata, and contradiction closure"
        }
        val topQuery = (0 until dataPlanQueries.length()).mapNotNull { dataPlanQueries.optJSONObject(it)?.optString("query")?.takeIf { q -> q.isNotBlank() } }.firstOrNull()
            ?: (0 until dataChannels.length()).mapNotNull { dataChannels.optJSONObject(it)?.optString("querySeed")?.takeIf { q -> q.isNotBlank() } }.firstOrNull()
            ?: jsonArray(intentAwareBrief.optJSONArray("repositoryQueriesToRun")).firstOrNull()
        val topDataAction = firstNonBlank(
            dataFeedPlan.optString("bestNextAction"),
            dataActions.firstOrNull() ?: "",
            dataChannels.optJSONObject(0)?.optString("nextAction") ?: "",
            mechanism.optString("nextDecisiveAction"),
            "Run a user-triggered public data lookup or feed one PMID/DOI/GSE/PRJNA/SRP/SRR/E-MTAB/SDY/PDF/snippet seed."
        )
        val firstRoute = candidateRoutes.optJSONObject(0) ?: JSONObject()
        val routeCascade = jsonArray(firstRoute.optJSONArray("cascade")).joinToString(" → ")
        val strongestRoute = firstNonBlank(
            routeCascade,
            mechanismRoutes.firstOrNull() ?: "",
            topCandidate.optString("targetAxis"),
            "No candidate route reached display quality yet."
        )
        val parsedIntent = parsedIntentSummary(researchIntent)
        val dataChannelsCount = maxOf(dataChannels.length(), dataPlanQueries.length(), jsonArray(intentAwareBrief.optJSONArray("repositoryQueriesToRun")).size, capturedSeeds.length())
        val accessionCountForBrief = maxOf(explicitAccessions.size, capturedSeeds.length(), evidenceObjectsWithAccessionCount(gtim))
        val primaryCapturedSeed = accessionSeedCapture.optString("primarySeed")
        val capturedSeedStatus = accessionSeedCapture.optString("status", "ACCESSION_SEED_CAPTURED_MATRIX_PENDING")
        val capturedSeedRouteState = capturedSeeds.optJSONObject(0)?.optString("routeState", "ROUTE_UNRESOLVED_METADATA_PENDING") ?: "ROUTE_UNRESOLVED_METADATA_PENDING"
        val scoreLine = "Intent ${researchIntent.optInt("intentCompletenessScore", 0)}/100 | Data-feed ${dataFeedPlan.optInt("dataFeedPlanScore", 0)}/100 | Route ${maxOf(score.optInt("routeFitScore", 0), researchIntent.optInt("routeConstructionScore", 0), threeScore.optInt("biologicalPlausibilityScore", 0))}/100 | Discovery ${maxOf(score.optInt("hypothesisConfidenceScore", 0), threeScore.optInt("discoveryValueScore", 0))}/100 | Evidence S_c ${maxOf(confidence.optInt("score", 0), threeScore.optInt("evidenceConfidenceScore", 0))}/100"
        val contradiction = firstNonBlank(
            contradictionEngine.optString("summary"),
            v3.optString("counterEvidenceOrContradiction"),
            "Run null-result, opposite-direction, species-mismatch, tissue-mismatch, and comparator-weakness search."
        )
        val labIdea = firstNonBlank(
            jsonArray(labDraft.optJSONArray("suggestedValidationDesign")).firstOrNull() ?: "",
            jsonArray(labPlan).firstOrNull() ?: "",
            "Draft only: define cohort/comparator first, then qPCR/cytokine/flow-cytometry validation."
        )

        val lines = mutableListOf<String>()
        lines += "Global Research-Grade Discovery Brief"
        lines += "Engine: $engine | Lock: $lock | State: $state"
        lines += "What the app understood: ${truncate(parsedIntent, 260)}"
        lines += "Strongest exploratory route: ${truncate(strongestRoute, 240)} | ${firstRoute.optString("status", "EXPLORATORY_ROUTE_NOT_EVIDENCE")}"
        lines += "What it found: ${truncate(primaryLead, 220)}"
        lines += "Evidence state: $evidenceGrade | leads=${exploratoryLeads.length()} | routes=${candidateRoutes.length()} | accessions=$accessionCountForBrief | matrix=${firstNonBlank(mechanism.optString("matrixAnalysisGate"), "DGE_NOT_READY")}"
        if (primaryCapturedSeed.isNotBlank()) {
            lines += "Captured accession seed: $primaryCapturedSeed | $capturedSeedStatus | route=$capturedSeedRouteState"
        }
        lines += "Scores: $scoreLine"
        lines += "Three-dimensional grade: Data Quality ${threeScore.optInt("dataQualityScore", 0)}/100 | Novelty ${threeScore.optInt("noveltyScore", 0)}/100 | Biological Plausibility ${threeScore.optInt("biologicalPlausibilityScore", 0)}/100"
        lines += "Best data feed now: ${truncate(topDataAction, 230)}"
        if (!topQuery.isNullOrBlank()) lines += "Best query to run: ${truncate(topQuery, 230)}"
        lines += "Contradiction check: ${truncate(contradiction, 210)}"
        lines += "Preliminary lab idea: ${truncate(labIdea, 220)}"
        lines += "Upgrade gates: ${truncate(blockers, 220)}"
        lines += "Do not believe yet: no mechanism, causality, DGE, clinical outcome, diagnosis, treatment, dose, or patient prediction is proven."
        lines += "Technical appendix: hidden from main brief; raw JSON, command trace, parser cards, and source metadata remain in advanced export."
        lines += "Boundary: $CLAIM_BOUNDARY; discovery routes are allowed, evidence upgrade remains strict."
        if (dataChannelsCount == 0) {
            lines.add(8, "Data-feed visibility warning: no public data channel was surfaced; run user-triggered resolver or structured intake.")
        }
        return lines.take(RuntimeFeatureFlags.GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061.coerceAtMost(18).coerceAtLeast(12))
    }

    private fun evidenceObjectsWithAccessionCount(gtim: JSONObject): Int {
        val evidenceObjects = gtim.optJSONArray("evidenceObjects") ?: JSONArray()
        var count = 0
        for (i in 0 until evidenceObjects.length()) {
            val accession = evidenceObjects.optJSONObject(i)?.optString("accessionId").orEmpty()
            if (accession.isNotBlank()) count += 1
        }
        return count
    }

    private fun parsedIntentSummary(intent: JSONObject): String {
        val card = jsonArray(intent.optJSONArray("parsedResearchIntentCard")).filterNot { it.equals("Parsed Research Intent", true) }
        if (card.isNotEmpty()) return card.take(8).joinToString(" | ")
        val parts = listOf(
            "Trigger=${intent.optString("triggerExposure")}",
            "Disease=${intent.optString("diseasePhenotype")}",
            "Pathway=${intent.optString("pathway")}",
            "Cell/tissue=${intent.optString("cellTissue")}",
            "Comparator=${intent.optString("comparatorWanted")}",
            "Assay=${intent.optString("assayType")}",
            "Repositories=${jsonArray(intent.optJSONArray("repositoryTargets")).joinToString(", ")}",
            "Output=${intent.optString("outputMode")}"
        ).filter { !it.endsWith("=") && !it.endsWith("=, ") }
        return parts.joinToString(" | ").ifBlank { "Research Intent parser available; use structured intake for stronger routing." }
    }

    private fun evidenceGrade(evidenceObjects: Int, accessions: Int, routeFit: Int, upgradeAllowed: Boolean): String = when {
        upgradeAllowed && evidenceObjects > 0 && accessions > 0 -> "B — evidence object ready for controlled review"
        evidenceObjects > 0 && accessions > 0 -> "C+ — evidence object present, claims still gated"
        accessions > 0 -> "C — accession found, metadata closure required"
        routeFit >= 70 -> "D+ — high-priority route, no confirmed accession yet"
        routeFit >= 25 -> "D — useful weak lead; feed more data"
        else -> "E+ — early exploratory signal; keep if route is scientifically interesting"
    }

    private fun jsonArray(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { idx ->
            val value = array.opt(idx) ?: return@mapNotNull null
            when (value) {
                is JSONObject -> firstNonBlank(
                    value.optString("accessionId"),
                    value.optString("leadId"),
                    value.optString("targetAxis"),
                    value.optString("routeId"),
                    value.optString("targetMolecularAxis"),
                    value.optString("streamId"),
                    value.optString("querySeed"),
                    value.optString("query"),
                    value.optString("label"),
                    value.optString("gateId"),
                    value.optString("nextAction"),
                    value.toString()
                )
                else -> value.toString()
            }.takeIf { it.isNotBlank() }
        }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""

    private fun truncate(value: String, max: Int): String {
        val oneLine = value.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1).trimEnd() + "…"
    }

    private fun sanitizeHeader(value: String): String = when (value.trim().uppercase()) {
        "UNKNOWN", "ENGINE: UNKNOWN", "LOCK: UNKNOWN", "STATE: UNKNOWN" -> "PASS"
        else -> value.ifBlank { "PASS" }
    }

    private fun sanitizeEngine(value: String): String = when (value.trim().uppercase()) {
        "UNKNOWN", "ENGINE: UNKNOWN" -> GTIMClaimGuardV250.ENGINE_IDENTITY
        else -> value.ifBlank { GTIMClaimGuardV250.ENGINE_IDENTITY }
    }
}
