package com.immunesignal.app

/** Intent-aware researcher brief renderer. Sections include: What the app understood; What it found; What it could not prove; technical appendix hidden. */
data class GTIMIntentAwareBriefReportV255(
    val active: Boolean,
    val version: String,
    val status: String,
    val whatTheAppUnderstood: List<String>,
    val whatItFound: List<String>,
    val whatItCouldNotProve: List<String>,
    val candidateRoutes: List<String>,
    val bestDataFeedsNow: List<String>,
    val repositoryQueriesToRun: List<String>,
    val contradictionSearchNeeded: List<String>,
    val preliminaryLabValidationIdea: List<String>,
    val doNotBelieveYet: List<String>,
    val appendixPolicy: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty() = GTIMIntentAwareBriefReportV255(
            active = false,
            version = GTIMIntentAwareBriefRendererV255.VERSION,
            status = "GTIM_INTENT_AWARE_BRIEF_IDLE",
            whatTheAppUnderstood = emptyList(),
            whatItFound = emptyList(),
            whatItCouldNotProve = emptyList(),
            candidateRoutes = emptyList(),
            bestDataFeedsNow = emptyList(),
            repositoryQueriesToRun = emptyList(),
            contradictionSearchNeeded = emptyList(),
            preliminaryLabValidationIdea = emptyList(),
            doNotBelieveYet = emptyList(),
            appendixPolicy = "technical appendix hidden from final brief"
        )
    }
}

object GTIMIntentAwareBriefRendererV255 {
    const val VERSION: String = "2.6.3-alpha-safe-launch-ui-stability"

    fun render(
        intent: GTIMResearchIntentObjectV255,
        plan: GTIMDataFeedPlanV255,
        split: GTIMDiscoveryEvidenceSplitReportV256,
        dashboard: GTIMProfessorDiscoveryDashboardReportV257
    ): GTIMIntentAwareBriefReportV255 {
        if (!intent.active && !split.active && !dashboard.active) return GTIMIntentAwareBriefReportV255.empty()
        return GTIMIntentAwareBriefReportV255(
            active = true,
            version = VERSION,
            status = "GTIM_INTENT_AWARE_BRIEF_READY",
            whatTheAppUnderstood = intent.parsedResearchIntentCard.ifEmpty { listOf("Parsed Research Intent: available but incomplete") },
            whatItFound = listOf(
                "Candidate routes: ${split.candidateRoutes.size}",
                "Discovery value: ${split.threeDimensionalScore.discoveryValueScore}/100",
                "Best route: ${split.candidateRoutes.firstOrNull()?.cascade?.joinToString(" → ") ?: "not built yet"}"
            ),
            whatItCouldNotProve = listOf(
                "Evidence confidence: ${split.threeDimensionalScore.evidenceConfidenceScore}/100",
                "Data Quality: ${split.threeDimensionalScore.dataQualityScore}/100",
                "Still missing accession/comparator/matrix/metadata/contradiction closure before upgrade"
            ),
            candidateRoutes = split.candidateRoutes.map { "${it.routeId}: ${it.cascade.joinToString(" → ")} | ${it.status}" }.take(8),
            bestDataFeedsNow = dashboard.publicDataResolverActions.map { "${it.sourceFamily}: ${it.queryOrSeed}" }.take(8),
            repositoryQueriesToRun = plan.repositorySearchPlan.map { "${it.priority} / ${it.repository}: ${it.query}" }.take(10),
            contradictionSearchNeeded = split.activeContradictionEngine.contradictionQueries.take(8),
            preliminaryLabValidationIdea = split.preliminaryLabProtocol.suggestedValidationDesign.take(6),
            doNotBelieveYet = split.evidenceUpgradeStillLocked.take(8),
            appendixPolicy = "raw JSON, command trace, parser internals, source metadata, and route IDs stay in Advanced/technical export"
        )
    }
}
