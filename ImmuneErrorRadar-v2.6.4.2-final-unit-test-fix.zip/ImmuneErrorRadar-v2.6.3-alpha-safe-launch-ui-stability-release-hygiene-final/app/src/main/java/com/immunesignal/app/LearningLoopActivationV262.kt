package com.immunesignal.app

data class LearningLoopActivationReportV262(
    val active: Boolean,
    val state: String,
    val learningRuleMatches: Int,
    val axisPerformanceRecords: List<AxisPerformanceRecordV262>,
    val proposedPlausibilityEdges: List<ProposedPlausibilityEdge>,
    val bayesianRevisions: List<BayesianBeliefRevisionCardV262>,
    val knowledgeGapTasks: List<KnowledgeGapTask>,
    val routeReplayRisk: Boolean,
    val epistemicDistance: EpistemicDistanceReportV262,
    val comparativeDiseaseClosure: DiseaseComparisonCycleClosureReportV264,
    val nextLoopAction: String,
    val claimLimit: String = LearningLoopActivationV262.CLAIM_LIMIT
)

/**
 * Audit token: LearningLoopActivationV262.build
 * v2.6.3: closes the learning loop by wiring existing learning assets into the
 * next-cycle search posture. Rules, memory, gaps, graph edges, fingerprints,
 * and belief updates remain routing/priority signals only.
 */
object LearningLoopActivationV262 {
    const val CLAIM_LIMIT = "learning_loop_activation_routing_only_not_biological_proof"

    fun build(
        findings: List<ResearchFinding>,
        evidenceObjects: List<EvidenceObject>,
        beliefReport: EpistemicBeliefReport,
        gapMiner: ScientificDiscoveryGapMinerReport,
        routeFingerprint: RouteFingerprintReport,
        learningRuleMatches: List<LearningRuleMatch>,
        recentReports: List<String>
    ): LearningLoopActivationReportV262 {
        val axisPerformance = AxisPerformanceLearningV262.build(findings, evidenceObjects, recentReports)
        val proposedEdges = DynamicPlausibilityGraphLearner.propose(findings)
        val bayesian = BayesianBeliefRevisionV262.revise(beliefReport.beliefs, evidenceObjects)
        val gapTasks = KnowledgeGapTaskScheduler.build(gapMiner)
        val distance = EpistemicDistanceMeterV262.score(previousReportJson = recentReports.firstOrNull(), beliefReport = beliefReport, gapMiner = gapMiner)
        val replay = routeFingerprint.fingerprint?.repeatedWithinLookback == true
        val comparativeCorpus = buildString {
            append(findings.joinToString(" ") { it.title + " " + it.bridgeSignal + " " + it.matchedAxes.joinToString(" ") })
            append(' ')
            append(evidenceObjects.joinToString(" ") { it.title + " " + it.sourceId + " " + it.reasons.joinToString(" ") })
            append(' ')
            append(recentReports.joinToString(" "))
        }
        val comparativeClosure = GTIMComparativeDiseasePathwaysV264.closeCycle(comparativeCorpus)
        val state = when {
            replay -> "LEARNING_LOOP_REROUTE_REQUIRED"
            comparativeClosure.active -> "LEARNING_LOOP_COMPARATIVE_PATHS_ACTIVE"
            gapTasks.isNotEmpty() -> "LEARNING_LOOP_GAP_TASKS_ACTIVE"
            learningRuleMatches.isNotEmpty() -> "LEARNING_LOOP_RULES_ACTIVE"
            proposedEdges.isNotEmpty() -> "LEARNING_LOOP_PLAUSIBILITY_EDGES_PROPOSED"
            else -> "LEARNING_LOOP_MONITORING"
        }
        val action = when (state) {
            "LEARNING_LOOP_REROUTE_REQUIRED" -> "Change source family, comparator target, or evidence key before rewarding progress."
            "LEARNING_LOOP_COMPARATIVE_PATHS_ACTIVE" -> GTIMComparativeDiseasePathwaysV264.oneLine(comparativeClosure)
            "LEARNING_LOOP_GAP_TASKS_ACTIVE" -> "Schedule top knowledge-gap query: ${gapTasks.first().targetQuery.take(180)}"
            "LEARNING_LOOP_RULES_ACTIVE" -> LearningRuleEngine.nextAction(learningRuleMatches)
            "LEARNING_LOOP_PLAUSIBILITY_EDGES_PROPOSED" -> "Use proposed graph edge as search prior only; seek accession/comparator evidence."
            else -> "Keep collecting structured accession/comparator/matrix evidence."
        }
        return LearningLoopActivationReportV262(
            active = RuntimeFeatureFlags.ENABLE_LEARNING_LOOP_ACTIVATION_V262,
            state = state,
            learningRuleMatches = learningRuleMatches.size,
            axisPerformanceRecords = axisPerformance,
            proposedPlausibilityEdges = proposedEdges,
            bayesianRevisions = bayesian,
            knowledgeGapTasks = gapTasks,
            routeReplayRisk = replay,
            epistemicDistance = distance,
            comparativeDiseaseClosure = comparativeClosure,
            nextLoopAction = action
        )
    }

    fun oneLine(report: LearningLoopActivationReportV262): String =
        "${report.state}; rules=${report.learningRuleMatches}; axes=${report.axisPerformanceRecords.size}; edges=${report.proposedPlausibilityEdges.size}; comparative=${report.comparativeDiseaseClosure.cards.size}; gaps=${report.knowledgeGapTasks.size}; distance=${"%.1f".format(report.epistemicDistance.distanceScore)}; next=${report.nextLoopAction.take(160)}"
}
