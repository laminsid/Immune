package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMDiscoveryDossierV250Test {
    @Test
    fun confirmedAccessionBuildsConnectedGtimDossierWithoutBypassingGates() {
        val candidate = DatasetAccessionCandidate(
            accession = "GSE250001",
            source = "GEO_GDS",
            organismHint = "human patients",
            conditionLabelsHint = "healthy control; SLE case; baseline",
            outcomeLabelsHint = "response nonresponse",
            triggerResponseOutcomeHint = "IL-6 TNF-alpha RNA-seq transcriptome sample metadata",
            timeCourseHint = "baseline follow-up",
            sampleSizeHint = "n=18",
            dataType = "RNA-seq transcriptome series matrix",
            usabilityScore = 65,
            status = "ACCESSION_TEXT_FOUND",
            sourceFindingId = "geo_gse250001",
            sourceTitle = "GSE250001 human SLE RNA-seq healthy control case baseline IL-6 TNF-alpha",
            sourceUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE250001",
            reasons = listOf("GSE250001", "series matrix", "sample metadata", "healthy control", "case")
        )

        val report = ResearchGradeMechanismDossierV1110.evaluate(
            steering = null,
            matrix = MetadataClosureStrategyMatrixReport.empty().copy(hyperDriveModeActive = true),
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            leadObjects = emptyList(),
            attempts = emptyList()
        )

        val gtim = report.globalTranslationalDossier
        assertTrue(gtim.active)
        assertTrue(gtim.engineIdentity.contains("GTIM-Engine v2.6.3"))
        assertTrue(gtim.evidenceObjects.isNotEmpty())
        assertTrue(gtim.mechanismCandidates.isNotEmpty())
        assertTrue(gtim.mechanismCandidates.first().corpusRelativeNoveltyStatement.contains("Corpus-relative"))
        assertTrue(gtim.mechanismCandidates.first().labValidationPlan.recommendedExperiments.isNotEmpty())
        assertTrue(gtim.routeIntegrity.passed)
        assertEquals("GTIM_ROUTE_CONNECTED_WITH_ACCESSION_ANCHOR", gtim.routeIntegrity.status)
        assertTrue(gtim.routeIntegrity.bridgePath.contains("DatasetForagingJson.globalTranslationalDossier"))
        assertTrue(gtim.releaseSurfaceHardening.passed)
        assertEquals("GTIM_RELEASE_SURFACE_HARDENED", gtim.releaseSurfaceHardening.status)
        assertTrue(gtim.releaseSurfaceHardening.gtimProductEngineVersion.contains("2.6.3"))
        assertTrue(gtim.claimGuardrails.any { it.contains("No diagnosis") })
    }

    @Test
    fun manualSnippetStaysUnconfirmedAndOnlyProducesBoundedGtimSourceObject() {
        val candidate = DatasetAccessionCandidate(
            accession = "MANUAL_TEXT_SNIPPET_without_repository_handle_0",
            source = "MANUAL_EVIDENCE_SEED_MODE",
            organismHint = "human cohort",
            conditionLabelsHint = "Long COVID IL-6 TNF-alpha",
            outcomeLabelsHint = "response",
            triggerResponseOutcomeHint = "transcriptome RNA-seq data availability",
            timeCourseHint = "baseline follow-up",
            sampleSizeHint = "unknown",
            dataType = "RNA-seq transcriptome",
            usabilityScore = 10,
            status = "OFF_ROUTE_USEFUL_DATASET",
            sourceFindingId = "manual_without_repository_handle",
            sourceTitle = "Manual text snippet without repository accession",
            sourceUrl = "",
            reasons = listOf("WEAK_DATASET_LEAD", "OFF_ROUTE")
        )

        val report = ResearchGradeMechanismDossierV1110.evaluate(
            steering = null,
            matrix = MetadataClosureStrategyMatrixReport.empty().copy(hyperDriveModeActive = true),
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            leadObjects = emptyList(),
            attempts = emptyList()
        )

        assertTrue(report.accessionCandidates.isEmpty())
        assertEquals("ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED", report.state)
        val gtim = report.globalTranslationalDossier
        assertTrue(gtim.active)
        assertTrue(gtim.evidenceObjects.isNotEmpty())
        assertEquals("GRADE_1_WEAK_TEXTUAL_LEAD", gtim.evidenceObjects.first().evidenceStrength)
        assertTrue(gtim.routeIntegrity.passed)
        assertEquals("GTIM_ROUTE_CONNECTED_WITH_METADATA_ANCHOR", gtim.routeIntegrity.status)
        assertTrue(gtim.routeIntegrity.weakLeadProtection.contains("cannot become confirmed accessions"))
        assertTrue(gtim.releaseSurfaceHardening.passed)
        assertEquals("GTIM_RELEASE_SURFACE_HARDENED", gtim.releaseSurfaceHardening.status)
        assertTrue(gtim.releaseSurfaceHardening.scientificClaimPosture.contains("hypothesis-generation only"))
        assertTrue(gtim.mechanismCandidates.all { it.confidenceIndex.score < 76 })
    }
}
