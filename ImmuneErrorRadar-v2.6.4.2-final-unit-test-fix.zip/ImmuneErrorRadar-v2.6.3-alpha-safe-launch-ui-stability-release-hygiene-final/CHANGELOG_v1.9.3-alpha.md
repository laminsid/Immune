# Immune Error Radar v1.9.3-alpha — Executable Quality Runbook

## Goal

v1.9.2 introduced a Discovery Quality Gate that decides whether a proposed strategy deserves execution. v1.9.3 turns that gate decision into a concrete, bounded runbook so the next cycle has one clear execution packet instead of scattered guidance.

## Added

- `ScientificDiscoveryRunbookV193.kt`
- `ScientificDiscoveryRunbookEngineV193`
- `ScientificDiscoveryRunbookReport`
- `DiscoveryRunbookStepCard`
- `scientific_term_index_v1.9.3.json`

## What the new layer does

The runbook compiles:

- selected run mode
- primary query clause
- evidence checklist
- hard stop conditions
- pass signals
- fail signals
- blocked replay keys
- execution budget
- route decision
- bounded runbook steps

## Integration points

v1.9.3 is wired into:

- `ResearchAutopilot`
- `ResearchModels`
- `ResearchKnowledgeStore`
- `CognitiveNextCycleBridge`
- `DiscoveryReportExporter`
- `DeepDiscoveryReasonerV180`
- `EngineRuntimeStatus`
- `RuntimeFeatureFlags`
- `scripts/run_static_checks.sh`

## Scientific term index update

The scientific/decision index now includes new decision-control terms:

- `executable_quality_runbook`
- `hard_stop_condition`
- `evidence_checklist_closure`
- `bounded_execution_budget`

## Claim boundary

The runbook is routing and execution-control only. It does not prove biology, diagnosis, treatment, causality, mechanism, or immune outcome.
