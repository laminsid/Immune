# ImmuneErrorRadar v1.5.1-alpha-foundation-sessions

## Summary
This release merges the v1.4.6 Foundation Knowledge OS and the v1.5.0 Learning Sessions layer into the existing v1.4.5 ML-triage route-fit codebase without replacing the core ResearchAutopilot flow.

## Core rules preserved
- ML ranks the hunt; evidence gates the belief; reports show the limits.
- Foundation knowledge guides search and conflict handling; it is not evidence.
- Foundation JSON packs are never auto-updated; the system records patch suggestions only.
- Learning sessions are bounded, checkpointed review sessions; they do not diagnose, treat, or prove biology.

## Added / integrated
- FoundationKnowledgeLayer
- AxisRankingEngine
- FoundationConflictResolver
- FoundationKnowledgeAccuracyLedger
- FoundationPatchSuggestionLedger
- FoundationKnowledgeIntegrationBridge
- biology_foundation_pack.json
- psychoneuroimmune_context_pack.json
- foundation_conflict_rules.json
- foundation_success_metrics.json
- immunology_axis_rules.json
- Learning session UI controls: Think / Continue / Pause / Stop session
- ProgressTracker output attached to the Research Autopilot screen
- Safer PhaseExecutor implementation using report summaries instead of missing report internals

## Defaults
- Foundation Knowledge OS is integrated but disabled by default via `enableFoundationKnowledgeOs = false`.
- Advanced learning sessions are user-controlled; no auto-start by default.

## Validation
Static checks passed:
- JSON validation
- Kotlin delimiter audit
- XML parse
- Layout ID check
- Execution wiring / version check
- Python cache artifact check
- Research Python compile checks

Full Gradle build was not executed in this environment because the project archive does not include a Gradle wrapper and the system Gradle command is unavailable.
