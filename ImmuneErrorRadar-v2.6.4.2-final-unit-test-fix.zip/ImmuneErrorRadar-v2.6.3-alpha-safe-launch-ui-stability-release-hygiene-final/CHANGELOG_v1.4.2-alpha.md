# Immune Error Radar v1.4.2-alpha — Dataset Parser & Outcome Label Intelligence

## Purpose
Move from finding dataset accessions to interpreting whether dataset metadata is usable for hypothesis testing.

## Added
- `DatasetParser.kt` to parse accession candidates into condition labels, outcome labels, control labels, time-course labels, assay type, tissue/source, and usability verdict.
- `OutcomeLabelDetector.kt` and `ControlGroupDetector.kt`.
- `ContrastiveEvidenceGate.kt` for response/non-response, mild/severe, exposed/control, recovery/persistence, and early/late comparison slots.
- `CumulativeEvidenceScorer.kt` with conservative cumulative evidence scoring; no Bayesian or predictive overclaim.
- `EvidenceHypergraphLite.kt` as a lightweight evidence graph, not a neural network.
- `dataset_parser_rules_v1.4.2.json` policy/rules asset.
- `DatasetParserV142Test.kt` unit tests.

## Changed
- Active engine raised to `v1.4.2-alpha-dataset-parser-intelligence`.
- Dataset foraging report now emits `parsedMetadata`, `contrastiveReport`, `evidenceHypergraph`, and `cumulativeEvidence`.
- UI/PDF/text exports show parser verdicts, contrastive gate, and cumulative evidence state.
- Query IDs for dataset-parser routes now use `q_v142_`; execution lock accepts both legacy `q_v140_` and `q_v142_`.

## Boundaries
- No medical advice, diagnosis, treatment, or drug selection.
- No ML training, Hypergraph Neural Networks, or future-variant prediction.
- Non-human/species-shift evidence may generate hypotheses only; it cannot upgrade human hypotheses.
