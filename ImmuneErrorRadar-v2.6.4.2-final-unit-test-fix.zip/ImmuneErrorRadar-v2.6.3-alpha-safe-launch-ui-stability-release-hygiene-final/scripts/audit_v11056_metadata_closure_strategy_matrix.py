#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(rel, tokens):
    path = ROOT / rel
    if not path.exists():
        errors.append(f'missing file: {rel}')
        return
    text = path.read_text(errors='ignore')
    for token in tokens:
        if token not in text:
            errors.append(f'missing token in {rel}: {token}')

require('app/src/main/java/com/immunesignal/app/MetadataClosureStrategyMatrixV11056.kt', [
    'VERSION_LABEL: String = "v1.10.60-alpha-github-ci-route-audit-unification"',
    'exploration_sandbox_not_biological_proof',
    'PASS_NO_FAIL_ON_WEAK_OR_OFF_ROUTE_LEAD',
    'MINIMUM_METADATA_PROBE_FORCED',
    'PUBMED_FULL_TEXT_ACCESSION_DRILLDOWN',
    'GEO_HUMAN_LONGITUDINAL_TRANSCRIPTOME',
    'SRA_BIOPROJECT_RNA_SEQ_METADATA',
    'CONTRADICTION_NULL_RESULT_STREAM',
    'G1_WEAK_OR_OFF_ROUTE_NEVER_FAIL',
    'G5_MODULATOR_AS_CONTROL_ONLY',
    'JAK inhibitor',
    'rituximab',
    'curcumin',
    'ashwagandha',
    'quercetin',
    'EBV',
    'HHV-6',
    'CMV',
    'SARS-CoV-2',
])
require('app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt', [
    'metadataClosureStrategyMatrixReport: MetadataClosureStrategyMatrixReport',
    'MetadataClosureStrategyMatrixReport.empty()'
])
require('app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt', [
    'metadataClosureStrategyMatrixReport',
    'metadataClosureStrategyMatrixToJson',
    'metadataClosureQueryStreamToJson',
    'metadataClosureMinimumProbeToJson',
    'metadataClosureLogicGateToJson'
])
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', [
    'MetadataClosureStrategyMatrixV11058.evaluate',
    'metadataClosureStrategyMatrixTopV11056',
    'metadataClosureStrategyMatrixReportV11056',
    'metadataClosureStrategyMatrixReport = metadataClosureStrategyMatrixTopV11056',
    'metadataClosureStrategyMatrixReport = metadataClosureStrategyMatrixReportV11056'
])
require('app/src/main/java/com/immunesignal/app/ResearchReportV3Builder.kt', [
    'strategyMatrix',
    'Strategy matrix drill-down forced',
    'Weak/off-route lead converted to minimum metadata probe',
    'Metadata Closure Strategy Matrix v1.10.60'
])
require('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt', [
    'metadataClosureStrategyMatrixReport',
    'Metadata Closure Strategy Matrix v1.10.60',
    'First query stream',
    'Matrix next'
])
require('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt', [
    'metadataClosureStrategyMatrixReport',
    'Metadata Closure Strategy Matrix v1.10.60',
    'First query stream',
    'Hard gates',
    'Minimum probes'
])
require('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt', [
    'MetadataClosureStrategyMatrixV11056',
    'MinimumMetadataProbeV11056',
    'StrategyMatrixQueryStreamsV11056'
])
require('docs/METADATA_CLOSURE_STRATEGY_MATRIX_v1.10.56.md', [
    'Metadata Closure Strategy Matrix v1.10.60',
    'MINIMUM_METADATA_PROBE_FORCED',
    'PUBMED_ACCESSION_MINING',
    'GEO_GDS',
    'SRA_BIOPROJECT'
])
require('docs/CHANGELOG_v1.10.56.md', [
    '1.10.56-alpha-metadata-closure-strategy-matrix',
    'versionCode=118',
    'schema updated to `1.10.56`'
])
if errors:
    print('v1.10.56 metadata closure strategy matrix audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.56 metadata closure strategy matrix audit: PASS')
