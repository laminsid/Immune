from pathlib import Path
checks = {
    'app/build.gradle.kts': ['versionCode = 111', 'versionName = "1.10.49-alpha-topic-route-correction-evidence-object-candidate"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['ACTIVE_ENGINE_VERSION = "v1.10.49-alpha-topic-route-correction-evidence-object-candidate"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': ['RELEASE_TRAIN_VERSION_NAME: String = "1.10.49-alpha-topic-route-correction-evidence-object-candidate"', 'RELEASE_TRAIN_VERSION_CODE: Int = 111', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.49"'],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 111', 'VERSION_NAME: String = "1.10.49-alpha-topic-route-correction-evidence-object-candidate"', 'ENGINE_VERSION: String = "v1.10.49-alpha-topic-route-correction-evidence-object-candidate"', 'LEARNING_SCHEMA_VERSION: String = "1.10.49"'],
    'docs/CHANGELOG_v1.10.49.md': ['v1.10.49-alpha-topic-route-correction-evidence-object-candidate'],
}
missing=[]
for file,tokens in checks.items():
    text=Path(file).read_text(encoding='utf-8') if Path(file).exists() else ''
    for token in tokens:
        if token not in text:
            missing.append(f'{file}: missing {token}')
if missing:
    raise SystemExit('\n'.join(missing))
print('v1.10.49 release linkage audit: PASS')
