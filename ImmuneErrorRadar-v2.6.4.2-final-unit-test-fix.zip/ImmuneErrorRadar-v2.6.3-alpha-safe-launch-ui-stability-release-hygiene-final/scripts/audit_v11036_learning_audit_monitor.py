#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.36 file: {rel}')
    return p.read_text(errors='replace')

checks = {
    'app/src/main/java/com/immunesignal/app/LearningRulesUiSummaryV11036.kt': [
        'LearningRulesUiSummary', 'LearningRulesAuditCard', 'Learning audit monitor',
        'learnedDetails', 'pinnedRules', 'savedPriors', 'stillMissing', 'invalidators',
        'learning_rules_ui_monitor_not_biological_proof', 'EBV/HHV-6/CMV',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'LearningRulesUiSummary.renderCompact', 'LearningRulesUiSummary.renderMini',
        'Immune Research Summary', 'Learning Summary',
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Learning audit monitor v1.10.36', 'learningAudit.monitorState', 'learningAudit.invalidators',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'LearningRulesUiSummary', 'LearningRulesAuditMonitor',
    ],
    'app/src/test/java/com/immunesignal/app/LearningRulesUiSummaryV11036Test.kt': [
        'LearningRulesUiSummaryV11036Test', 'auditCardShowsLearnedRulesMissingFieldsAndInvalidators',
        'compactUiTextRemainsUserFacingAndBounded',
    ],
    'docs/LEARNING_AUDIT_MONITOR_v1.10.36.md': [
        'Learning Audit Monitor', 'learning_rules_ui_monitor_not_biological_proof',
        'Invalidate if', 'versionCode=98',
    ],
    'docs/CHANGELOG_v1.10.36.md': [
        '1.10.36-alpha-learning-monitor-continuity', 'versionCode=98',
        'Learning audit monitor', 'LearningRulesUiSummaryV11036Test',
    ],
}

for rel, tokens in checks.items():
    text = read(rel)
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.36 token: {token}')
print('v1.10.36 learning audit monitor audit: PASS')
