#!/usr/bin/env python3
from pathlib import Path
required = {
    'app/src/main/java/com/immunesignal/app/ResearchGradeMechanismDossierV1110.kt': [
        'v1.11.1 route-integrity repair',
        'HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION',
        'DGE_NOT_READY_METADATA_GAP',
        'COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT',
        'matrixAvailability.startsWith("MATRIX_AVAILABLE")',
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Metadata/Hyper-Drive Strategy Matrix v1.11.1',
        'Research-Grade Mechanism Dossier v1.11.1',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Metadata/Hyper-Drive Strategy Matrix v1.11.1',
        'Mechanism Dossier v1.11.1',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchReportV3Builder.kt': [
        'Metadata/Hyper-Drive Strategy Matrix v1.11.1',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'mechanismDiscoveryDossierToJson',
        'accessionCandidateCardToJson',
        'comparatorMappingCardToJson',
        'mechanismRouteProposalToJson',
    ],
    'scripts/run_static_checks_fast.sh': [
        'audit_v1111_github_route_integrity_repair.py',
        'audit_release_version_linkage_v1111.py',
    ],
}
missing=[]
for rel,tokens in required.items():
    text=Path(rel).read_text(encoding='utf-8', errors='replace') if Path(rel).exists() else ''
    for token in tokens:
        if token not in text:
            missing.append(f'{rel}: missing {token}')
# Prevent current report surface from claiming the old matrix label after v1.11.1.
for rel in ['app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt','app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt','app/src/main/java/com/immunesignal/app/ResearchReportV3Builder.kt']:
    text=Path(rel).read_text(encoding='utf-8', errors='replace')
    if 'Metadata Closure Strategy Matrix v1.10.61' in text:
        missing.append(f'{rel}: stale current matrix report label still present')
# Ensure no dangerous ready state can be reached from non-available matrix predicate.
rg=Path('app/src/main/java/com/immunesignal/app/ResearchGradeMechanismDossierV1110.kt').read_text(encoding='utf-8', errors='replace')
if 'matrixAvailability.startsWith("MATRIX")' in rg:
    missing.append('ResearchGradeMechanismDossierV1110.kt: loose MATRIX predicate still present')
if missing:
    raise SystemExit('v1.11.1 GitHub route integrity repair audit failed:\n' + '\n'.join(missing))
print('v1.11.1 GitHub route integrity repair audit: PASS')
