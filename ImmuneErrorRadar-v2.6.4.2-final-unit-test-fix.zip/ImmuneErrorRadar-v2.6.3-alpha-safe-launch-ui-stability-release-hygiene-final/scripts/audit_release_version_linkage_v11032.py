#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.32 file: {rel}')
    return p.read_text(errors='replace')

checks = {
    'app/src/main/java/com/immunesignal/app/MatureDomainFocusAndLeanRuntime.kt': [
        'MatureDomainFocusModePolicy', 'MatureDomainFocusReport', 'DomainSpecificKillCriteriaReport',
        'DomainExpertiseScoreUpgradeReport', 'KnowledgeGapQueueReport', 'StrongRouteFingerprintReport',
        'domain_focus_search_prior_not_biological_proof', 'FOCUS_CYCLES', 'buildFocusedQuery',
    ],
    'app/src/main/java/com/immunesignal/app/MatureDomainEvidenceProbePolicy.kt': [
        'MatureDomainFocusModePolicy.selectSeed', 'v1.10.32 focus mode',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': [
        'matureDomainFocusReport', 'domainSpecificKillCriteriaReport', 'domainExpertiseScoreUpgradeReport',
        'knowledgeGapQueueReport', 'strongRouteFingerprintReport',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'matureDomainFocusReport', 'knowledgeGapQueueReport', 'strongRouteFingerprintReport',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'MatureDomainFocusModePolicy.evaluate', 'MatureDomainFocusModePolicy.killCriteria',
        'MatureDomainFocusModePolicy.gapQueue', 'MatureDomainFocusModePolicy.strongFingerprint',
    ],
    'app/src/test/java/com/immunesignal/app/MatureDomainFocusLeanRuntimeV11033Test.kt': [
        'matureDomainFocusPersistsAsRoutingPrior', 'domainSpecificKillCriteriaDoesNotArchiveGlobalResearch',
        'knowledgeGapQueueRoutesOpenOutcomeAndMetadataGaps', 'strongRouteFingerprintBlocksSemanticReplayShape',
    ],
    'docs/MATURE_DOMAIN_FOCUS_MODE_v1.10.32.md': ['v1.10.32', 'Mature Domain Focus Mode', 'Knowledge gaps', 'Claim lock'],
    'docs/CHANGELOG_v1.10.32.md': ['v1.10.32', 'domain-specific kill criteria', 'semantic route fingerprinting'],
}

for rel, tokens in checks.items():
    text = read(rel)
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.32 token: {token}')
print('v1.10.32 mature-domain focus audit: PASS')
