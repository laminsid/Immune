#!/usr/bin/env python3
from pathlib import Path

required = {
    'app/src/main/java/com/immunesignal/app/ResearchGradeMechanismDossierV1110.kt': [
        'ResearchGradeMechanismDossierV1110',
        'AccessionCandidateCardV1110',
        'ComparatorMappingCardV1110',
        'MechanismRouteProposalV1110',
        'DGE_NOT_READY_METADATA_GAP',
        'COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT',
        'HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION',
        'Never invent',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': [
        'mechanismDiscoveryDossierReport: ResearchGradeMechanismDossierReportV1110',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'mechanismDiscoveryDossierReport',
        'mechanismDiscoveryDossierToJson',
        'accessionCandidateCardToJson',
        'comparatorMappingCardToJson',
        'mechanismRouteProposalToJson',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ResearchGradeMechanismDossierV1110.evaluate',
        'mechanismDiscoveryDossierReport = mechanismDiscoveryDossierReportV1110',
    ],
    'app/src/main/java/com/immunesignal/app/GlobalResearchGradeBriefV11061.kt': [
        'mechanismDiscoveryDossierReport',
        'Matrix gate:',
        'DGE/fold-change/p-value',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'ResearchGradeMechanismDossierV1110',
        'AccessionCandidateMatrixReadinessV1110',
        'ComparatorMappingGateV1110',
        'DgeReadinessMetadataGateV1110',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'ENABLE_RESEARCH_GRADE_MECHANISM_DOSSIER_V1110',
    ],
}

missing = []
for rel, tokens in required.items():
    path = Path(rel)
    text = path.read_text(encoding='utf-8', errors='replace') if path.exists() else ''
    for token in tokens:
        if token not in text:
            missing.append(f'{rel}: missing {token}')

forbidden_surface = [
    'patient flare prediction allowed',
    'clinical utility confirmed',
    'scientific breakthrough confirmed',
    'dose recommendation allowed',
]
all_text = '\n'.join(Path(p).read_text(encoding='utf-8', errors='replace') for p in required if Path(p).exists())
for token in forbidden_surface:
    if token in all_text:
        missing.append(f'forbidden surface present: {token}')

if missing:
    raise SystemExit('v1.11.0 mechanism dossier audit failed:\n' + '\n'.join(missing))
print('v1.11.0 mechanism dossier audit: PASS')
