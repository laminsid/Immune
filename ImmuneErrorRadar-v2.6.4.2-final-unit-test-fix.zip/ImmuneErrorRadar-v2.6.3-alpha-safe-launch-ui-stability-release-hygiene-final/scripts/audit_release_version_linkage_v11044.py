#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
checks = {
 'app/build.gradle.kts': ['versionCode = 106', 'versionName = "1.10.44-alpha-viral-countermeasure-knowledge-graph"'],
 'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': ['RELEASE_TRAIN_VERSION_CODE: Int = 106', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.44"', '1.10.44-alpha-viral-countermeasure-knowledge-graph'],
 'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['ACTIVE_ENGINE_VERSION = "v1.10.44-alpha-viral-countermeasure-knowledge-graph"'],
 'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 106', 'VERSION_NAME: String = "1.10.44-alpha-viral-countermeasure-knowledge-graph"', 'LEARNING_SCHEMA_VERSION: String = "1.10.44"'],
 'docs/CHANGELOG_v1.10.44.md': ['versionCode=106', '1.10.44-alpha-viral-countermeasure-knowledge-graph']
}
for rel, tokens in checks.items():
    text = (ROOT/rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'MISSING {token} in {rel}')
print('v1.10.44 release linkage audit: PASS')
