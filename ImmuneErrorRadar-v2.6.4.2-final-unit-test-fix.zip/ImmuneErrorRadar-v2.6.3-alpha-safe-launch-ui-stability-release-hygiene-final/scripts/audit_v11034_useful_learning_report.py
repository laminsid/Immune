#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.34 file: {rel}')
    return p.read_text(errors='replace')

checks = {
    'app/src/main/java/com/immunesignal/app/UsefulLearningReportV11034.kt': [
        'LearningValueScoreReport', 'TopicMemoryLedgerReport', 'LeadInspectionQueueReport',
        'UsefulReportLayersReport', 'ResearchProgressWithoutEvidenceReport',
        'useful_learning_report_not_biological_proof', 'topic_stored', 'weak_lead_preserved',
        'progress without EvidenceObject'.replace('p', 'P') if False else 'Progress without EvidenceObject',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': [
        'learningValueScoreReport', 'topicMemoryLedgerReport', 'leadInspectionQueueReport',
        'usefulReportLayersReport', 'researchProgressWithoutEvidenceReport',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'learningValueScoreReport', 'topicMemoryLedgerReport', 'leadInspectionQueueReport',
        'usefulReportLayersReport', 'researchProgressWithoutEvidenceReport',
        'learningValueScoreToJson', 'leadInspectionQueueToJson',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'UsefulLearningReportPolicy.learningValueScore', 'UsefulLearningReportPolicy.topicMemoryLedger',
        'UsefulLearningReportPolicy.leadInspectionQueue', 'UsefulLearningReportPolicy.progressWithoutEvidence',
        'UsefulLearningReportPolicy.reportLayers', 'UsefulLearningReportPolicy.learningNote',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Research value:', 'What changed:', 'Leads to check:', 'Learning Summary',
        'learningValueScoreReport', 'topicMemoryLedgerReport', 'leadInspectionQueueReport',
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Useful learning v1.10.34', 'Topic memory v1.10.34', 'Lead inspection queue v1.10.34',
        'Research progress without EvidenceObject v1.10.34',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'UsefulLearningReportPolicy', 'TopicMemoryLedger', 'LeadInspectionQueue', 'ThreeLayerUsefulReport',
    ],
    'docs/USEFUL_LEARNING_REPORT_v1.10.34.md': [
        'v1.10.34', 'Learning Value Score', 'Topic Memory Ledger', 'Lead Inspection Queue', 'Progress without EvidenceObject',
    ],
    'docs/CHANGELOG_v1.10.34.md': [
        '1.10.34-alpha-useful-learning-report', 'versionCode=96', 'Learning Value Score', 'Lead Inspection Queue',
    ],
}

for rel, tokens in checks.items():
    text = read(rel)
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.34 token: {token}')

print('v1.10.34 useful learning report audit: PASS')
