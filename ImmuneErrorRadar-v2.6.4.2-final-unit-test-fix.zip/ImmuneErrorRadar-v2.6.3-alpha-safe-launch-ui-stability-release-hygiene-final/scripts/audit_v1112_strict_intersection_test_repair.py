#!/usr/bin/env python3
from pathlib import Path
source = Path('app/src/main/java/com/immunesignal/app/MetadataClosureStrategyMatrixV11056.kt').read_text(encoding='utf-8', errors='replace')
test = Path('app/src/test/java/com/immunesignal/app/MetadataClosureStrictIntersectionV11057Test.kt').read_text(encoding='utf-8', errors='replace')
checks = [
    ('source', source, 'streamId = "AGGRESSIVE_GEO_EXPOSOME_CYTOKINE_STREAM"'),
    ('source', source, 'streamId = "AGGRESSIVE_SRA_EXPOSOME_CYTOKINE_STREAM"'),
    ('source', source, 'GSE[0-9]* OR GSM[0-9]* OR PRJNA[0-9]* OR SRP[0-9]*'),
    ('source', source, 'HYPER_BETA_GEO_GDS_EXPOSOME_MODULATOR_ACCESSION'),
    ('source', source, 'HYPER_BETA_SRA_BIOPROJECT_EXPOSOME_MODULATOR_ACCESSION'),
    ('test', test, 'psychophysiologicalExposomeUnlocksAggressiveQueryStream'),
    ('test', test, 'AGGRESSIVE_GEO_EXPOSOME_CYTOKINE_STREAM" && it.query.contains("GSE[0-9]*")'),
    ('test', test, 'AGGRESSIVE_SRA_EXPOSOME_CYTOKINE_STREAM" && it.query.contains("SRP[0-9]*")'),
]
missing=[f'{label}: missing {token}' for label,text,token in checks if token not in text]
if 'AGGRESSIVE_GEO_EXPOSOME_CYTOKINE_STREAM' in source:
    idx=source.index('AGGRESSIVE_GEO_EXPOSOME_CYTOKINE_STREAM')
    window=source[idx:idx+650]
    if 'GSE[0-9]*' not in window:
        missing.append('AGGRESSIVE_GEO_EXPOSOME_CYTOKINE_STREAM window does not include GSE[0-9]*')
if 'AGGRESSIVE_SRA_EXPOSOME_CYTOKINE_STREAM' in source:
    idx=source.index('AGGRESSIVE_SRA_EXPOSOME_CYTOKINE_STREAM')
    window=source[idx:idx+650]
    if 'SRP[0-9]*' not in window:
        missing.append('AGGRESSIVE_SRA_EXPOSOME_CYTOKINE_STREAM window does not include SRP[0-9]*')
for rel,tokens in {
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': ['Metadata/Hyper-Drive Strategy Matrix v1.11.2', 'Research-Grade Mechanism Dossier v1.11.2'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': ['Metadata/Hyper-Drive Strategy Matrix v1.11.2', 'Mechanism Dossier v1.11.2'],
    'scripts/run_static_checks_fast.sh': ['audit_v1112_strict_intersection_test_repair.py', 'audit_release_version_linkage_v1112.py'],
}.items():
    text=Path(rel).read_text(encoding='utf-8', errors='replace') if Path(rel).exists() else ''
    for token in tokens:
        if token not in text:
            missing.append(f'{rel}: missing {token}')
if missing:
    raise SystemExit('v1.11.2 strict intersection test repair audit failed' + ':\n' + '\n'.join(missing))
print('v1.11.2 strict intersection test repair audit: PASS')
