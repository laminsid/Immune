#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
errors=[]
# Version-label owner integrity: known owner objects must keep their own labels.
owners = {
    'app/src/main/java/com/immunesignal/app/RouteReconciliationEvidenceCandidateV11051.kt': 'v1.10.51-alpha-route-reconciliation-evidence-candidate-activation',
    'app/src/main/java/com/immunesignal/app/OpenExplorationMedicalIndexV11052.kt': 'v1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox',
    'app/src/main/java/com/immunesignal/app/RouteLinkageHardeningV11053.kt': 'v1.10.53-alpha-ci-route-linkage-hardening',
    'app/src/main/java/com/immunesignal/app/GithubCiRuntimeSurfaceHardeningV11054.kt': 'v1.10.54-alpha-github-ci-runtime-surface-hardening',
}
for rel,label in owners.items():
    p=ROOT/rel
    if not p.exists():
        errors.append(f'missing owner file: {rel}')
        continue
    text=p.read_text(errors='ignore')
    if f'VERSION_LABEL: String = "{label}"' not in text:
        errors.append(f'wrong VERSION_LABEL in {rel}; expected {label}')
# Runtime module registry and report linkage.
registry=(ROOT/'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt').read_text(errors='ignore')
if 'GithubCiRuntimeSurfaceHardeningV11054' not in registry:
    errors.append('RuntimeModuleRegistry missing GithubCiRuntimeSurfaceHardeningV11054')
topic=(ROOT/'app/src/main/java/com/immunesignal/app/TopicFitMetadataParseUiClarityV11047.kt').read_text(errors='ignore')
for token in ['GithubCiRuntimeSurfaceHardeningV11054.summary()', 'RouteLinkageHardeningV11053.reportLinkageSummary()', 'diagnosticReasoningLines = openExploration.reasoningLines']:
    if token not in topic:
        errors.append(f'TopicFit missing token: {token}')
# Static scripts must print PASS after v1.10.54 audits.
for rel in ['scripts/run_static_checks_fast.sh','scripts/run_static_checks_full.sh']:
    p=ROOT/rel
    text=p.read_text(errors='ignore')
    audit_pos=text.rfind('audit_release_version_linkage_v11054.py')
    pass_pos=text.rfind('static checks v1.10.54: PASS')
    if audit_pos == -1:
        errors.append(f'{rel} missing v1.10.54 release audit')
    if pass_pos == -1:
        errors.append(f'{rel} missing final v1.10.54 PASS marker')
    if audit_pos != -1 and pass_pos != -1 and pass_pos < audit_pos:
        errors.append(f'{rel} prints PASS before final v1.10.54 audit')
# Workflow remains pipefail-safe and uses fast default for push/PR.
workflow=(ROOT/'.github/workflows/android-debug.yml').read_text(errors='ignore')
if 'find .ci_project -maxdepth 4 -type f | sort | head' in workflow:
    errors.append('workflow has unsafe sort|head pipe')
for token in ['STATIC_MODE="fast"', 'workflow_dispatch', 'gradle-version: "8.10.2"']:
    if token not in workflow:
        errors.append(f'workflow missing token: {token}')
# No generated artifacts should be present at release time.
for pattern in ['.gradle', 'build', '__pycache__']:
    found=[p for p in ROOT.rglob(pattern) if p.is_dir()]
    if found:
        errors.append(f'generated directory present: {found[0]}')
for pattern in ['*.apk','*.aab','*.aar','*.pyc']:
    found=list(ROOT.rglob(pattern))
    if found:
        errors.append(f'generated/binary artifact present: {found[0]}')
if errors:
    print('v1.10.54 GitHub CI/runtime surface hardening audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.54 GitHub CI/runtime surface hardening audit: PASS')
