#!/usr/bin/env python3
"""v1.10.45 compile-scope guard.

Catches the exact class of CI failure where a feature layer references fields that do
not exist on ResearchSteeringProfile (for example it.topic / it.focus). This is not a
replacement for Gradle compilation; it is a fast pre-compile guard for known linkage
mistakes inside lean-agent integration files.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
models = ROOT / 'app/src/main/java/com/immunesignal/app/ResearchModels.kt'
ontology = ROOT / 'app/src/main/java/com/immunesignal/app/BiomedicalResearchOntologyV11041.kt'

text_models = models.read_text(errors='replace')
text_ontology = ontology.read_text(errors='replace')

m = re.search(r'data class ResearchSteeringProfile\s*\((.*?)\n\)', text_models, re.S)
if not m:
    raise SystemExit('ResearchSteeringProfile data class not found')
fields = set(re.findall(r'val\s+(\w+)\s*:', m.group(1)))
required_fields = {'profileId', 'createdAtMillis', 'variables', 'focusQuestion', 'requiredTerms', 'excludedTerms', 'inferredAxes'}
missing = sorted(required_fields - fields)
if missing:
    raise SystemExit('ResearchSteeringProfile required fields missing: ' + ', '.join(missing))

for bad in ['it.topic', 'it.focus,', 'it.focus)', 'it.focus ']:
    if bad in text_ontology:
        raise SystemExit(f'Forbidden unresolved ResearchSteeringProfile reference remains: {bad}')

required_tokens = [
    'it.profileId',
    'it.focusQuestion',
    'it.variables.joinToString(" ")',
    'it.requiredTerms.joinToString(" ")',
    'it.excludedTerms.joinToString(" ")',
    'it.inferredAxes.joinToString(" ")',
]
for token in required_tokens:
    if token not in text_ontology:
        raise SystemExit(f'Missing corrected steering corpus token: {token}')

# Targeted project-wide bad-pattern check for the same issue inside compile-visible source.
for path in (ROOT / 'app/src/main/java/com/immunesignal/app').glob('*.kt'):
    txt = path.read_text(errors='replace')
    if re.search(r'steering\?\.let\s*\{[^}]*\bit\.topic\b', txt, re.S):
        raise SystemExit(f'Potential unresolved steering.topic use in {path}')
    if re.search(r'steering\?\.let\s*\{[^}]*\bit\.focus\b', txt, re.S):
        raise SystemExit(f'Potential unresolved steering.focus use in {path}')

print('v1.10.45 compile scope guard audit: PASS')
