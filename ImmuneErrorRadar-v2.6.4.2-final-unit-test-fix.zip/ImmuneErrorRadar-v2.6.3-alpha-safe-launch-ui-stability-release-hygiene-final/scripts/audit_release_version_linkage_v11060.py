#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
version = '1.10.60-alpha-github-ci-route-audit-unification'
engine = 'v1.10.60-alpha-github-ci-route-audit-unification'
checks = {
    'app/build.gradle.kts': ['versionCode = 122', f'veersionName = "{version}"'.replace('veersionName','versionName')],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [f'RELEASE_TRAIN_VERSION_NAME: String = "{version}"', 'RELEASE_TRAIN_VERSION_CODE: Int = 122', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.60"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [f'ACTIVE_ENGINE_VERSION = "{engine}"', 'GithubCiRouteAuditUnificationV11060'],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 122', f'VERSION_NAME: String = "{version}"', f'ENGINE_VERSION: String = "{engine}"', 'LEARNING_SCHEMA_VERSION: String = "1.10.60"'],
    'app/src/main/java/com/immunesignal/app/MetadataClosureStrategyMatrixV11056.kt': [f'VERSION_LABEL: String = "{engine}"'],
    'docs/CHANGELOG_v1.10.60.md': [version, 'versionCode=122', 'schema updated to `1.10.60`'],
    'docs/GITHUB_CI_ROUTE_AUDIT_UNIFICATION_v1.10.60.md': ['GitHub CI Route Audit Unification v1.10.60'],
}
errors=[]
for rel,tokens in checks.items():
    path=ROOT/rel
    if not path.exists():
        errors.append(f'missing {rel}')
        continue
    text=path.read_text(errors='ignore')
    for token in tokens:
        if token not in text:
            errors.append(f'{rel} missing {token}')
if errors:
    print('v1.10.60 release linkage audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.60 release linkage audit: PASS')
