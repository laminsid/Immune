#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
checks={
 'app/src/main/java/com/immunesignal/app/GTIMResearchIntentParserV255.kt': ['GTIMResearchIntentParserV255','GTIMResearchIntentObjectV255','diseasePhenotype','triggerExposure','labValidationRequirement','intentCompletenessScore','Parsed Research Intent','STRUCTURED_INTAKE'],
 'app/src/main/java/com/immunesignal/app/GTIMDataFeedPlannerV255.kt': ['GTIMDataFeedPlannerV255','GTIMDataFeedPlanV255','repositorySearchPlan','querySeeds','accessionPatterns','GTIM_DATAFEED_PLAN_VISIBLE','bestNextAction'],
 'app/src/main/java/com/immunesignal/app/GTIMEvidenceModelsV250.kt': ['researchIntent: GTIMResearchIntentObjectV255','dataFeedPlan: GTIMDataFeedPlanV255'],
 'app/src/main/java/com/immunesignal/app/GTIMDiscoveryDossierV250.kt': ['GTIMResearchIntentParserV255.parse','GTIMDataFeedPlannerV255.plan','Parsed Research Intent:'],
 'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['researchIntent','dataFeedPlan','gtimResearchIntentToJson','gtimDataFeedPlanToJson','repositorySearchPlan'],
 'app/src/main/java/com/immunesignal/app/GlobalResearchGradeBriefV11061.kt': ['What the app understood:','Parsed Research Intent','fallbackEngine','fallbackLock','fallbackState','data-feed'],
 'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': ['GTIMResearchIntentParserV255','GTIMDataFeedPlannerV255','GTIMIntentAwareBriefRendererV255'],
 'app/src/test/java/com/immunesignal/app/GTIMResearchIntentParserV255Test.kt': ['structuredQuestionBuildsResearchIntentObject','intentFeedsDataFeedPlannerAndDoesNotReturnZeroScores','candidateRouteDoesNotBecomeEvidenceObjectOrMatrix'],
}
errors=[]
for rel,toks in checks.items():
    p=ROOT/rel
    if not p.exists():
        errors.append(f'missing {rel}')
        continue
    text=p.read_text(errors='replace')
    for tok in toks:
        if tok not in text:
            errors.append(f'{rel}: missing {tok!r}')
brief=(ROOT/'app/src/main/java/com/immunesignal/app/GlobalResearchGradeBriefV11061.kt').read_text(errors='replace')
for forbidden in ['Engine: ${runtime.optString("engineVersion", "unknown")}', 'GTIM_OPEN_DISCOVERY_DATAFEED_NOT_VISIBLE")']:
    if forbidden in brief:
        errors.append(f'brief still contains unsafe fallback: {forbidden}')
if errors:
    raise SystemExit('GTIM v2.5.5 research intent parser audit failed:\n'+'\n'.join(errors))
print('GTIM v2.5.5 research intent parser audit: PASS')
