#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
checks = {
 'app/src/main/java/com/immunesignal/app/ViralCountermeasureIntelligenceV11044.kt': [
   'ViralCountermeasureIntelligenceV11044', 'HANTAVIRUS_COUNTERMEASURE_PROFILE',
   'AntigenTargetPriorCard', 'NoWetlabProtocolGuard', 'biomedical_dictionary_database_linkage_not_biological_proof'
 ],
 'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': ['viralCountermeasureReport', 'biomedicalKnowledgeGraphLinkageReport'],
 'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['viralCountermeasureReport', 'biomedicalKnowledgeGraphLinkageReport', 'viralCountermeasureToJson'],
 'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['ViralCountermeasureIntelligenceV11044.evaluate', 'BiomedicalKnowledgeGraphLinkerV11044.link', 'v1.10.44 viral countermeasure intelligence'],
 'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': ['ViralCountermeasureIntelligence', 'BiomedicalKnowledgeGraphLinker'],
 'app/src/main/assets/viral_countermeasure_profiles_v1.10.44.json': ['HANTAVIRUS_COUNTERMEASURE_PROFILE', 'countermeasure efficacy confirmed'],
 'app/src/main/assets/biomedical_knowledge_graph_index_v1.10.44.json': ['viral_countermeasure', 'accession_repositories'],
 'docs/CHANGELOG_v1.10.44.md': ['versionCode=106', 'ViralCountermeasureIntelligenceV11044']
}
for rel, tokens in checks.items():
    text = (ROOT/rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'MISSING {token} in {rel}')
print('v1.10.44 viral countermeasure + knowledge graph audit: PASS')
