#!/usr/bin/env python3
from pathlib import Path

checks = {
    'app/build.gradle.kts': ['versionCode = 124', 'versionName = "1.11.0-alpha-research-grade-mechanism-dossier"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.11.0-alpha-research-grade-mechanism-dossier"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 124',
        'LEARNING_SESSION_SCHEMA_VERSION: String = "1.11.0"',
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'ACTIVE_ENGINE_VERSION = "v1.11.0-alpha-research-grade-mechanism-dossier"',
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 124',
        'VERSION_NAME: String = "1.11.0-alpha-research-grade-mechanism-dossier"',
        'ENGINE_VERSION: String = "v1.11.0-alpha-research-grade-mechanism-dossier"',
        'LEARNING_SCHEMA_VERSION: String = "1.11.0"',
        'research-grade mechanism dossier release',
    ],
}
missing=[]
for rel,tokens in checks.items():
    path=Path(rel)
    text=path.read_text(encoding='utf-8', errors='replace') if path.exists() else ''
    for token in tokens:
        if token not in text:
            missing.append(f'{rel}: missing {token}')
if missing:
    raise SystemExit('v1.11.0 release linkage audit failed:\n' + '\n'.join(missing))
print('v1.11.0 release linkage audit: PASS')
