#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
version = '1.10.56-alpha-metadata-closure-strategy-matrix'
engine = 'v1.10.56-alpha-metadata-closure-strategy-matrix'
checks = {
    'app/build.gradle.kts': ['versionCode = 118', f'versionName = "{version}"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [f'ACTIVE_ENGINE_VERSION = "{engine}"', 'MetadataClosureStrategyMatrixV11056'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [f'RELEASE_TRAIN_VERSION_NAME: String = "{version}"', 'RELEASE_TRAIN_VERSION_CODE: Int = 118', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.56"'],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 118', f'VERSION_NAME: String = "{version}"', f'ENGINE_VERSION: String = "{engine}"', 'LEARNING_SCHEMA_VERSION: String = "1.10.56"'],
    'app/src/main/java/com/immunesignal/app/MetadataClosureStrategyMatrixV11056.kt': [f'VERSION_LABEL: String = "{engine}"', 'PASS_NO_FAIL_ON_WEAK_OR_OFF_ROUTE_LEAD'],
    'docs/CHANGELOG_v1.10.56.md': [version, 'versionCode=118', 'schema updated to `1.10.56`'],
    'docs/METADATA_CLOSURE_STRATEGY_MATRIX_v1.10.56.md': ['Metadata Closure Strategy Matrix v1.10.56'],
}
errors=[]
for rel,tokens in checks.items():
    p=ROOT/rel
    if not p.exists():
        errors.append(f'missing file: {rel}')
        continue
    text=p.read_text(errors='ignore')
    for token in tokens:
        if token not in text:
            errors.append(f'missing token in {rel}: {token}')
if errors:
    print('v1.10.56 release linkage audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.56 release linkage audit: PASS')
