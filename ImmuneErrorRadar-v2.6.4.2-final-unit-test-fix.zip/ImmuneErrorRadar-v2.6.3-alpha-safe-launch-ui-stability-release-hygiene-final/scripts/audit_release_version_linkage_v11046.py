#!/usr/bin/env python3
from pathlib import Path
# v1.10.59_patch_note_fast_gate_owned_by_v11055: historical release audits no longer require old audits inside fast gate.
ROOT = Path(__file__).resolve().parents[1]
checks = {
 'app/build.gradle.kts': ['versionCode = 108', 'versionName = "1.10.46-alpha-longevity-biological-systems-graph"'],
 'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': ['RELEASE_TRAIN_VERSION_CODE: Int = 108', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.46"', '1.10.46-alpha-longevity-biological-systems-graph'],
 'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['ACTIVE_ENGINE_VERSION = "v1.10.46-alpha-longevity-biological-systems-graph"', 'active_longevity_biological_systems_graph_v11046'],
 'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 108', 'VERSION_NAME: String = "1.10.46-alpha-longevity-biological-systems-graph"', 'LEARNING_SCHEMA_VERSION: String = "1.10.46"'],
 'app/src/main/java/com/immunesignal/app/FinalReleaseStabilityGuardV11040.kt': ['LongevityBiologicalSystemsGraph', 'HealthAdviceClaimGuard', 'FastBiologicalRetrievalIndex'],
 'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': ['LongevityBiologicalSystemsGraph', 'LifestyleToLabMapper', 'FastBiologicalRetrievalIndex', 'HealthAdviceClaimGuard'],
 'scripts/run_static_checks_full.sh': ['audit_v11046_longevity_biological_systems_graph.py', 'audit_release_version_linkage_v11046.py'],
 'docs/CHANGELOG_v1.10.46.md': ['versionCode=108', '1.10.46-alpha-longevity-biological-systems-graph']
}
for rel, tokens in checks.items():
    text = (ROOT/rel).read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'MISSING {token} in {rel}')
print('v1.10.46 release linkage audit: PASS')
