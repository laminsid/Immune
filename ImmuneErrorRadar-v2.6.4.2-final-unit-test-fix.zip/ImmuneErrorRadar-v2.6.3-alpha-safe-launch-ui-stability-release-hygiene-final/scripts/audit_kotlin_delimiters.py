#!/usr/bin/env python3
import pathlib, sys
pairs={'(':')','{':'}','[':']'}
openers=set(pairs)
closers=set(pairs.values())
errors=[]
for p in list(pathlib.Path('app/src/main/java').rglob('*.kt')) + list(pathlib.Path('app/src/test/java').rglob('*.kt')):
    stack=[]
    text=p.read_text(encoding='utf-8')
    in_str=False; esc=False
    for i,ch in enumerate(text):
        if in_str:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch=='"': in_str=False
            continue
        if ch=='"':
            in_str=True; continue
        if ch in openers:
            stack.append((ch,i))
        elif ch in closers:
            if not stack or pairs[stack[-1][0]]!=ch:
                errors.append(f'{p}: unexpected {ch} at {i}')
                break
            stack.pop()
    if stack:
        errors.append(f'{p}: unclosed {stack[-1][0]} at {stack[-1][1]}')
if errors:
    print('\n'.join(errors)); sys.exit(1)
print('Kotlin delimiter audit: PASS')
