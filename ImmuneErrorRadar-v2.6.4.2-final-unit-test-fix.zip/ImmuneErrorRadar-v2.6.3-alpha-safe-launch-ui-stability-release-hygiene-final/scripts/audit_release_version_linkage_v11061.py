#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
version = '1.10.61-alpha-global-research-brief-report'
engine = 'v1.10.61-alpha-global-research-brief-report'
checks = {
    'app/build.gradle.kts': ['versionCode = 123', f'versionName = "{version}"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [f'RELEASE_TRAIN_VERSION_NAME: String = "{version}"', 'RELEASE_TRAIN_VERSION_CODE: Int = 123', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.61"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [f'ACTIVE_ENGINE_VERSION = "{engine}"'],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 123', f'VERSION_NAME: String = "{version}"', f'ENGINE_VERSION: String = "{engine}"', 'LEARNING_SCHEMA_VERSION: String = "1.10.61"'],
    'app/src/main/java/com/immunesignal/app/MetadataClosureStrategyMatrixV11056.kt': [f'VERSION_LABEL: String = "{engine}"'],
    'docs/CHANGELOG_v1.10.61.md': [version, 'versionCode=123', 'schema updated to `1.10.61`'],
    'docs/GLOBAL_RESEARCH_BRIEF_REPORT_v1.10.61.md': ['Global Research Brief Report v1.10.61'],
}
errors=[]
for rel,tokens in checks.items():
    path=ROOT/rel
    if not path.exists():
        errors.append(f'missing {rel}')
        continue
    text=path.read_text(errors='ignore')
    for token in tokens:
        if token not in text:
            errors.append(f'{rel} missing {token}')
if errors:
    print('v1.10.61 release linkage audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.61 release linkage audit: PASS')
