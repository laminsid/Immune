#!/usr/bin/env python3
from pathlib import Path

activity = Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text(errors='replace')
layout = Path('app/src/main/res/layout/activity_research_autopilot.xml').read_text(errors='replace')
main_layout = Path('app/src/main/res/layout/activity_main.xml').read_text(errors='replace')
main_activity = Path('app/src/main/java/com/immunesignal/app/MainActivity.kt').read_text(errors='replace')

def require(text, token, label):
    if token not in text:
        raise SystemExit(f'English compact UI audit missing in {label}: {token}')

for token in [
    'Enter one topic or question for immune-focused research',
    'Immune Search',
    'Learning summary: no run yet.',
    'Advanced details',
    'Boundary: immune research leads only. No diagnosis, treatment, drug ranking, or medical advice.',
]:
    require(layout, token, 'activity_research_autopilot.xml')

for token in [
    'Immune Research Summary',
    'Research value:',
    'What changed:',
    'Useful lead:',
    'Leads to check:',
    'Learning Summary',
    'friendlyLead(',
    'friendlyNextAction(',
    'friendlyProgressCategories(',
    'stripTechnicalCodes(',
]:
    require(activity, token, 'ResearchAutopilotActivity.kt')

for forbidden in [
    'تقرير بحث مناعي مختصر', 'تعلم تلقائي', 'قيمة التعلم', 'فجوات مفتوحة',
    'اكتب سؤالًا', 'بحث مناعي', 'لا تشخيص', 'الجاهزية البحثية',
    '• النتيجة:', '• أفضل lead:', '• القفل:'
]:
    if forbidden in activity or forbidden in layout or forbidden in main_layout:
        raise SystemExit(f'Visible UI still contains Arabic/old mixed text: {forbidden}')

visible_block = activity[activity.find('private fun renderSimpleUserReport'):activity.find('private fun renderMiniLearningReport')]
visible_block += activity[activity.find('private fun renderMiniLearningReport'):activity.find('private fun renderPostSearchThinkingCard')]
for forbidden in [
    'WEAK_DATASET_LEAD_FOUND', 'OFF_ROUTE_DATASET', 'MANUAL_TEXT_SNIPPET',
    'NO_CONTRADICTION_SEARCH', 'NO_CONTROL_SIGNAL', 'BROAD_QUERY',
    'Execution lock:', 'Forager:', 'Active engine:', 'claim-limit', 'EvidenceObject yet'
]:
    if forbidden in visible_block:
        raise SystemExit(f'Compact visible report still exposes technical token: {forbidden}')

if 'Active engine: ${EngineRuntimeStatus.ACTIVE_ENGINE_VERSION}' in main_activity:
    raise SystemExit('Main screen still exposes engine version directly')

print('v1.10.34 English compact UI audit: PASS')
