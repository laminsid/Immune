#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
errors=[]
# Owner module and registry.
owner=ROOT/'app/src/main/java/com/immunesignal/app/CiFastGateRouteSurfaceUnificationV11055.kt'
owner_text=owner.read_text(errors='ignore') if owner.exists() else ''
for token in ['FAST_CI_GATE_DEFAULT','FULL_RELEASE_GATE_OPT_IN','CORRECTED_ROUTE_SURFACE_MUST_REACH_JSON_UI_EXPORT_AND_LEGACY_CARDS','ci_fast_gate_route_surface_unification_not_biological_proof']:
    if token not in owner_text:
        errors.append(f'owner missing token: {token}')
registry=(ROOT/'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt').read_text(errors='ignore')
if 'CiFastGateRouteSurfaceUnificationV11055' not in registry:
    errors.append('RuntimeModuleRegistry missing CiFastGateRouteSurfaceUnificationV11055')
# run_static_checks.sh must be bounded by default and full opt-in.
runner=(ROOT/'scripts/run_static_checks.sh').read_text(errors='ignore')
for token in ['CI_RESEARCH_FULL_CHECKS', 'run_static_checks_fast.sh', 'run_static_checks_full.sh']:
    if token not in runner:
        errors.append(f'run_static_checks.sh missing token: {token}')
if 'CI_RESEARCH_FULL_CHECKS' not in runner or 'exec bash scripts/run_static_checks_fast.sh' not in runner:
    errors.append('run_static_checks.sh must default to fast and reserve full for opt-in')
# Fast gate should include current release and route-surface audits but not replay all historical release audits.
fast=(ROOT/'scripts/run_static_checks_fast.sh').read_text(errors='ignore')
for token in ['quiet JSON validation', 'audit_v11050_no_isolated_exposome_paths.py', 'audit_v11051_route_reconciliation_evidence_candidate.py', 'audit_v11052_open_exploration_medical_index.py', 'audit_v11053_route_linkage_hardening.py', 'audit_v11054_github_ci_runtime_surface_hardening.py', 'audit_v11055_ci_fast_gate_route_surface_unification.py', 'audit_release_version_linkage_v11055.py', 'Fast static checks v1.10.55: PASS']:
    if token not in fast:
        errors.append(f'run_static_checks_fast.sh missing token: {token}')
old_replay_tokens=['audit_release_version_linkage_v11030.py','audit_release_version_linkage_v11034.py','audit_v11033_unit_regression_contracts.py']
for token in old_replay_tokens:
    if token in fast:
        errors.append(f'fast gate still replays historical audit: {token}')
# Full gate remains available and ends with current checks.
full=(ROOT/'scripts/run_static_checks_full.sh').read_text(errors='ignore')
if 'audit_release_version_linkage_v11055.py' not in full or 'Full static checks v1.10.55: PASS' not in full:
    errors.append('full gate missing v1.10.55 final audit/PASS marker')
# Workflow should keep push/PR fast by default.
workflow=(ROOT/'.github/workflows/android-debug.yml').read_text(errors='ignore')
for token in ['STATIC_MODE="fast"', 'workflow_dispatch', 'run_static_checks_fast.sh']:
    if token not in workflow:
        errors.append(f'workflow missing fast/default token: {token}')
if 'find .ci_project -maxdepth 4 -type f | sort | head' in workflow:
    errors.append('workflow has unsafe sort|head pipe')
# Current release must stay aligned.
for rel in ['app/build.gradle.kts','app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt','app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt','app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt']:
    text=(ROOT/rel).read_text(errors='ignore')
    if '1.10.55-alpha-ci-fast-gate-route-surface-unification' not in text:
        errors.append(f'{rel} missing current version name')
# No generated artifacts.
for pattern in ['.gradle','build','__pycache__']:
    for path in ROOT.rglob(pattern):
        if path.is_dir():
            errors.append(f'generated directory present: {path}')
            break
for pattern in ['*.apk','*.aab','*.aar','*.pyc']:
    found=list(ROOT.rglob(pattern))
    if found:
        errors.append(f'generated/binary artifact present: {found[0]}')
if errors:
    print('v1.10.55 CI fast-gate route-surface unification audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.55 CI fast-gate route-surface unification audit: PASS')
