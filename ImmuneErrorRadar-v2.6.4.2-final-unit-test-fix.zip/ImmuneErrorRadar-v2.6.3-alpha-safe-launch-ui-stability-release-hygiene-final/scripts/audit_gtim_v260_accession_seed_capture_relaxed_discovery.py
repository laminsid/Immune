#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
required = {
    'app/src/main/java/com/immunesignal/app/GTIMAccessionSeedCaptureV260.kt': [
        'GTIMAccessionSeedCaptureV260',
        'ACCESSION_SEED_CAPTURED_MATRIX_PENDING',
        'ROUTE_UNRESOLVED_METADATA_PENDING',
        'ACCESSION_SEED_NOT_EVIDENCE_OBJECT',
        'GSE\\s*\\d+',
        'no hidden background scraping',
    ],
    'app/src/main/java/com/immunesignal/app/GTIMEvidenceModelsV250.kt': [
        'accessionSeedCapture: GTIMAccessionSeedCaptureReportV260',
    ],
    'app/src/main/java/com/immunesignal/app/GTIMDiscoveryDossierV250.kt': [
        'GTIMAccessionSeedCaptureV260.evaluate',
        'primary_accession_seed_capture',
        'GRADE_2_REPOSITORY_HANDLE_SEED_NOT_EVIDENCE',
        'ACCESSION_SEED_CAPTURE_RELAXES_DISCOVERY_NOT_EVIDENCE',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'gtimAccessionSeedCaptureToJson',
        'gtimCapturedAccessionSeedToJson',
        'accessionSeedCapture',
    ],
    'app/src/main/java/com/immunesignal/app/GlobalResearchGradeBriefV11061.kt': [
        'Captured accession seed:',
        'accessionCountForBrief',
        'evidenceObjectsWithAccessionCount',
    ],
    'app/src/main/java/com/immunesignal/app/GTIMOpenDiscoveryDataFeedingV254.kt': [
        'DF_ACCESSION_SEED_METADATA_CLOSURE',
        'captured accession seed is visible',
        'accession_seed_metadata_closure',
    ],
    'app/src/test/java/com/immunesignal/app/GTIMAccessionSeedCaptureV260Test.kt': [
        'gseSeedIsCapturedWithoutMatrixOrComparatorAndDoesNotBecomeEvidenceClaim',
        'GSE152202',
    ],
    'app/build.gradle.kts': [
        'versionCode = 136',
        'versionName = "2.6.0-alpha-gtim-accession-seed-capture-relaxed-discovery"',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "2.6.0-alpha-gtim-accession-seed-capture-relaxed-discovery"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 136',
        'LEARNING_SESSION_SCHEMA_VERSION: String = "2.6.0"',
    ],
}
errors=[]
for rel, tokens in required.items():
    path=root/rel
    if not path.exists():
        errors.append(f'missing {rel}')
        continue
    text=path.read_text()
    for token in tokens:
        if token not in text:
            errors.append(f'{rel} missing token: {token}')
if errors:
    print('GTIM v2.6.0 accession seed capture audit: FAIL')
    for e in errors:
        print(' -', e)
    raise SystemExit(1)
print('GTIM v2.6.0 accession seed capture + relaxed discovery audit: PASS')
