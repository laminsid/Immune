#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(rel, tokens):
    path = ROOT / rel
    if not path.exists():
        errors.append(f'missing file: {rel}')
        return ''
    text = path.read_text(errors='ignore')
    for token in tokens:
        if token not in text:
            errors.append(f'missing token in {rel}: {token}')
    return text

matrix = require('app/src/main/java/com/immunesignal/app/MetadataClosureStrategyMatrixV11056.kt', [
    'v1.10.60-alpha-github-ci-route-audit-unification',
    'PASS_NO_FAIL_ON_WEAK_OR_OFF_ROUTE_LEAD',
    'MINIMUM_METADATA_PROBE_FORCED',
    'MetadataClosureStrategyMatrixV11057',
    'MetadataClosureStrategyMatrixV11058',
    'R1_NEURO_VIRAL_BRIDGE',
    'R2_PSYCHEPHYSIOLOGICAL_EXPOSOME',
    'G6_NEURO_VIRAL_STRICT_INTERSECTION_ELEVATION',
    'G7_PSYCHEPHYSIOLOGICAL_EXPOSOME_AGGRESSIVE_STREAM',
    'G8_HARD_TARGETING_ACCESSION_GENERATION',
    'G9_HARD_DATA_EXTRACTION_DEMAND_NO_FABRICATION',
    'hyperDriveModeActive',
    'hardDataExtractionMode',
    'criticalUsabilityAnomaly',
    'forcedRouteFitTarget',
    'multiDimensionalAccessionSearchStreams',
    'programmaticCommandLog',
    'runtimeDataDemand',
    'controlComparatorLinkageQueries',
    'HYPER_ALPHA_GEO_GDS_NEURO_VIRAL_DATA_AVAILABILITY',
    'HYPER_ALPHA_SRA_BIOPROJECT_NEURO_VIRAL_DATA_AVAILABILITY',
    'HYPER_BETA_GEO_GDS_EXPOSOME_MODULATOR_ACCESSION',
    'HYPER_BETA_SRA_BIOPROJECT_EXPOSOME_MODULATOR_ACCESSION',
    'GSE[0-9]*',
    'GSM[0-9]*',
    'PRJNA[0-9]*',
    'SRP[0-9]*',
    'NEXT_JSON_DEMAND::accessions>0_or_log_HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION',
])
for unsafe in [
    'val alpha = "(EBV OR HHV-6) AND (SLE OR "Systemic Lupus"',
    'val beta = "("HPA-axis" OR "Cortisol/DHEA ratio"',
    'query = "(EBV OR HHV-6) AND (SLE OR "Systemic Lupus"',
    'query = "("HPA-axis" OR "Cortisol/DHEA ratio"',
]:
    if unsafe in matrix:
        errors.append(f'unsafe normal Kotlin string literal remains: {unsafe}')
for safe in [
    'val alpha = """(EBV OR HHV-6)',
    'val beta = """("HPA-axis"',
    'query = """(EBV OR HHV-6)',
    'query = """("HPA-axis"',
]:
    if safe not in matrix:
        errors.append(f'missing triple-quoted query literal token: {safe}')

require('app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt', [
    'metadataClosureStrategyMatrixReport: MetadataClosureStrategyMatrixReport',
    'MetadataClosureStrategyMatrixReport.empty()',
])
require('app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt', [
    'metadataClosureStrategyMatrixReport',
    'metadataClosureStrategyMatrixToJson',
    'metadataClosureIntersectionRuleToJson',
    'hyperDriveModeActive',
    'multiDimensionalAccessionSearchStreams',
    'programmaticCommandLog',
    'runtimeDataDemand',
    'controlComparatorLinkageQueries',
])
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', [
    'MetadataClosureStrategyMatrixV11058.evaluate',
    'metadataClosureStrategyMatrixTopV11056',
    'metadataClosureStrategyMatrixReportV11056',
    'metadataClosureStrategyMatrixReport = metadataClosureStrategyMatrixTopV11056',
    'metadataClosureStrategyMatrixReport = metadataClosureStrategyMatrixReportV11056',
])
require('app/src/main/java/com/immunesignal/app/ResearchReportV3Builder.kt', [
    'Metadata Closure Strategy Matrix v1.10.60',
    'multiDimensionalStreams',
    'commands=',
    'demand=',
])
require('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt', [
    'Metadata Closure Strategy Matrix v1.10.60',
    'hyperDrive',
    'forcedTarget',
])
require('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt', [
    'Metadata Closure Strategy Matrix v1.10.60',
    'Hyper-Drive first stream',
    'Programmatic commands',
    'Runtime data demand',
    'Control/comparator linkage queries',
])
require('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt', [
    'MetadataClosureStrategyMatrixV11056',
    'MinimumMetadataProbeV11056',
    'StrategyMatrixQueryStreamsV11056',
    'StrictIntersectionPriorityElevationV11057',
    'MetadataClosureStrategyMatrixV11058',
    'HyperDriveHardDataExtractionV11058',
    'GithubCiRouteAuditUnificationV11060',
    'MetadataHyperDriveAuditCoverageV11060',
])
require('scripts/run_static_checks_fast.sh', [
    'audit_v11056_metadata_closure_strategy_matrix.py',
    'audit_v11057_strict_intersection_priority_elevation.py',
    'audit_v11058_hyper_drive_hard_data_extraction.py',
    'audit_v11060_github_ci_route_audit_unification.py',
    'audit_release_version_linkage_v11060.py',
    'Fast static checks v1.10.60: PASS',
])
require('docs/GITHUB_CI_ROUTE_AUDIT_UNIFICATION_v1.10.60.md', [
    'GitHub CI Route Audit Unification v1.10.60',
    'v1.10.56', 'v1.10.57', 'v1.10.58', 'v1.10.59', 'v1.10.60',
    'No fabricated accession IDs',
])
require('docs/CHANGELOG_v1.10.60.md', [
    '1.10.60-alpha-github-ci-route-audit-unification',
    'versionCode=122',
    'schema updated to `1.10.60`',
])
if errors:
    print('v1.10.60 GitHub CI route/audit unification audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.60 GitHub CI route/audit unification audit: PASS')
