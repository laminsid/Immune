#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
errors=[]

def require(rel, tokens):
    path=ROOT/rel
    if not path.exists():
        errors.append(f'missing file: {rel}')
        return ''
    text=path.read_text(errors='ignore')
    for token in tokens:
        if token not in text:
            errors.append(f'{rel} missing token: {token}')
    return text

brief=require('app/src/main/java/com/immunesignal/app/GlobalResearchGradeBriefV11061.kt', [
    'GlobalResearchGradeBriefV11061',
    'Global Research-Grade Discovery Brief',
    'Evidence grade:',
    'Blocking gap:',
    'Contradiction status:',
    'Accession IDs:',
    'Next discriminating action:',
    'Appendix policy:',
    'GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061',
    'no diagnosis, treatment, dose, supplement',
])
activity=require('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt', [
    'GlobalResearchGradeBriefV11061.render(report)',
    'GlobalResearchGradeBriefV11061.render(report))',
])
exporter=require('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt', [
    'exportConcisePdfV11061',
    'GlobalResearchGradeBriefV11061.renderLines(report)',
    'ENABLE_GLOBAL_RESEARCH_GRADE_BRIEF_V11061',
])
flags=require('app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt', [
    'ENABLE_GLOBAL_RESEARCH_GRADE_BRIEF_V11061',
    'GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061',
    'GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061',
])
require('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt', [
    'MetadataClosureStrategyMatrixV11056', 'StrictIntersectionPriorityElevationV11057',
    'HyperDriveHardDataExtractionV11058', 'GithubCiRouteAuditUnificationV11060',
    'GlobalResearchGradeBriefV11061',
    'ConciseFinalReportExportV11061',
    'TechnicalAppendixDemotionV11061',
])
require('app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt', [
    'global research brief/report release',
    'research-grade mechanism dossier release',
])
require('docs/GLOBAL_RESEARCH_BRIEF_REPORT_v1.10.61.md', [
    'Global Research Brief Report v1.10.61',
    'PDF export now outputs a compact one-page discovery brief',
    'Must not fabricate accession IDs or evidence objects',
])
if 'Learning notes:' in brief or 'Epistemic belief model' in brief or 'Cognitive path integration' in brief:
    errors.append('GlobalResearchGradeBriefV11061 should not reintroduce verbose technical sections')
if 'renderBriefReport(report) + "\\n\\n" + renderReport(report)' in activity:
    errors.append('TXT fallback still concatenates the long technical report')
if errors:
    print('v1.10.61 global research brief audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.61 global research brief audit: PASS')
