#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/IntegratedPathLinkageV11039.kt': [
        'IntegratedPathLinkageGuard', 'IntegratedPathLinkageReport', 'FINAL_PATHS_CONNECTED_METADATA_LOCKED', 'v1.10.39-alpha-final-path-linkage-release'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': ['integratedPathLinkageReport'],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['integratedPathLinkageReport', 'integratedPathLinkageToJson'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['IntegratedPathLinkageGuard.evaluate', 'v1.10.39 integrated path linkage'],
    'app/src/main/java/com/immunesignal/app/DatasetForagingPathLinkageGuard.kt': ['leadClosureSources', 'leadPaths=', 'matureProbeConsumedByLeadPath = matureProbeReport.active && leadInspectionFinalState'],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': ['Integrated path linkage v1.10.39', 'Final path decision'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': ['Integrated Path Linkage v1.10.39', 'Final path decision'],
    'docs/INTEGRATED_PATH_LINKAGE_v1.10.39.md': ['Integrated Path Linkage v1.10.39', 'EBV criterion lane', 'Evidence Prior Matrix'],
    'docs/CHANGELOG_v1.10.39.md': ['v1.10.39-alpha-final-path-linkage-release', 'VersionCode: `101`'],
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.39 integrated path file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.39 token: {token}')
print('v1.10.39 integrated path linkage audit: PASS')
