#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
version = '1.10.54-alpha-github-ci-runtime-surface-hardening'
engine = 'v1.10.54-alpha-github-ci-runtime-surface-hardening'
checks = {
    'app/build.gradle.kts': ['versionCode = 116', f'versionName = "{version}"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [f'ACTIVE_ENGINE_VERSION = "{engine}"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [f'RELEASE_TRAIN_VERSION_NAME: String = "{version}"', 'RELEASE_TRAIN_VERSION_CODE: Int = 116', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.54"'],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 116', f'VERSION_NAME: String = "{version}"', f'ENGINE_VERSION: String = "{engine}"', 'LEARNING_SCHEMA_VERSION: String = "1.10.54"'],
    'app/src/main/java/com/immunesignal/app/GithubCiRuntimeSurfaceHardeningV11054.kt': [f'VERSION_LABEL: String = "{engine}"', 'VERSION_LABELS_MATCH_OWNING_RELEASES', 'STATIC_CHECK_PASS_PRINTS_AFTER_FINAL_AUDIT'],
    'docs/CHANGELOG_v1.10.54.md': [version, 'versionCode=116', 'schema `1.10.54`'],
    'docs/GITHUB_CI_RUNTIME_SURFACE_HARDENING_v1.10.54.md': ['GitHub CI Runtime Surface Hardening v1.10.54'],
}
errors=[]
for rel,tokens in checks.items():
    p=ROOT/rel
    if not p.exists():
        errors.append(f'missing file: {rel}')
        continue
    text=p.read_text(errors='ignore')
    for token in tokens:
        if token not in text:
            errors.append(f'missing token in {rel}: {token}')
if errors:
    print('v1.10.54 release linkage audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.54 release linkage audit: PASS')
