#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.31 compatible file: {rel}')
    return p.read_text(errors='replace')

checks = {
    'app/src/main/java/com/immunesignal/app/EvidenceLeadAndManualSeed.kt': [
        'WEAK_DATASET_LEAD_FOUND', 'NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION',
        'ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP', 'NO_PUBLIC_DATASET_AFTER_FULL_SWEEP',
        'MANUAL_EVIDENCE_SEED_MODE', 'LEAD_ONLY_NOT_EVIDENCE', 'fun toLeadObjects(',
        'postPubMedSearchStrategies', 'Activity ≠ Evidence', 'EvidenceLeadPathLinkageReport',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': [
        'manualEvidenceSeedReport', 'datasetLeadRelaxationReport', 'evidenceDiscoveryBreakthroughReport',
        'evidenceActivitySeparationReport', 'onePageExecutiveEvidenceReport', 'evidenceLeadPathLinkageReport', 'leadObjects',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'manualEvidenceSeeds', 'ReportConsistencyGuard.preventArchiveProbeConflict',
        'DATASET_FORAGING_WEAK_DATASET_LEAD_FOUND', 'EvidenceLeadAndManualSeedPolicy.manualSeedAttempt',
        'EvidenceLeadAndManualSeedPolicy.toLeadObjects', 'EvidenceLeadAndManualSeedPolicy.linkage',
    ],
    'app/src/test/java/com/immunesignal/app/EvidenceLeadManualSeedV11031Test.kt': [
        'manualSeedCreatesLeadOnlyCandidate', 'weakDatasetLeadIsStoredButNotUpgraded',
        'reportConsistencyPreventsArchiveProbeConflict', 'manualSeedAttemptIsRecordedAsForagerAttempt',
        'evidenceLeadPathLinkageConnectsManualSeedRelaxationBreakthroughAndDecision',
    ],
    'docs/EVIDENCE_LEAD_AND_MANUAL_SEED_v1.10.31.md': [
        'v1.10.31', 'Manual Evidence Injection Mode', 'Dataset Lead Relaxation Gate', 'Report Consistency Guard',
    ],
    '.github/workflows/android-debug.yml': ['run_static_checks_fast.sh', 'run_static_checks_full.sh', 'pull_request'],
}

for rel, tokens in checks.items():
    text = read(rel)
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.31 compatible token: {token}')

print('v1.10.31 evidence lead/manual seed audit: PASS (current release compatible)')
