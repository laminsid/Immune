#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/FinalReleaseStabilityGuardV11040.kt': [
        'FinalReleaseStabilityGuard', 'FinalReleaseStabilityReport',
        'FINAL_RELEASE_STABILITY_LOCKED', 'LeadClosureHandoffPolicy',
        'MetadataClosureAgent', 'EBVLeadVerificationPolicy', 'ImmuneEvidencePriorMatrix',
        'IntegratedPathLinkageGuard', 'final_release_stability_not_biological_proof'
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'FinalReleaseStabilityGuard', 'ReleaseContinuityAuditGuard'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.10.41-alpha-biomedical-research-ontology', 'FinalReleaseStabilityGuard',
        'ReleaseContinuityAuditGuard'
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'FinalReleaseStabilityGuard.isReleaseSurfaceAligned()',
        'v1.10.41 biomedical research ontology release'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Release stability gate v1.10.40', 'FinalReleaseStabilityReport.fromRuntime()'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Release Stability Gate v1.10.40', 'FinalReleaseStabilityReport.fromRuntime()'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'v1.10.40 release stability gate', 'FinalReleaseStabilityGuard.missingRequiredLayers()'
    ],
    'docs/RELEASE_STABILITY_GATE_v1.10.40.md': [
        'Release Stability Gate v1.10.40', 'GitHub', 'Google Console',
        'not biological proof'
    ],
    'docs/CHANGELOG_v1.10.40.md': [
        'v1.10.40-alpha-release-stability-gate', 'VersionCode: `102`',
        'FinalReleaseStabilityGuard'
    ],
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.40 release stability file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.40 token: {token}')
# Guard against reintroducing unsafe random context injection.
prior = (ROOT / 'app/src/main/java/com/immunesignal/app/ImmuneEvidencePriorMatrixV11038.kt').read_text(errors='replace')
if 'random.choice(' in prior or 'java.util.Random' in prior or 'kotlin.random.Random' in prior:
    raise SystemExit('unsafe random context injection found in evidence prior matrix')
print('v1.10.40 release stability gate audit: PASS')
