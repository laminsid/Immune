from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/TopicFitMetadataParseUiClarityV11047.kt': [
        'ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE',
        'PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE',
        'ENDOCRINE_HORMONE_HPA_IMMUNE_LANE',
        'DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE',
        'PHYSICAL_LIGHT_RADIATION_CIRCADIAN_IMMUNE_LANE',
        'TOXIN_SUBSTANCE_EXPOSURE_IMMUNE_LANE',
        'AGE_LIFE_STAGE_IMMUNE_CONTEXT_LANE',
        'Exposure policy: exposure/context only',
        'exposure is not measurable with timing/intensity/frequency/context fields',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'EnvironmentalPsychophysiologicalExposomeLaneV11050',
        'ExposomeToLabMapperV11050',
        'NoExposureAdviceGuardV11050',
    ],
    'docs/ENVIRONMENTAL_PSYCHOPHYSIOLOGICAL_EXPOSOME_v1.10.50.md': [
        'Exposure -> Pathway -> Biomarker -> Dataset -> Outcome -> Comparator -> Contradiction',
        'never provides personal health advice',
    ],
    'app/src/main/assets/environmental_psychophysiological_exposome_v1.10.50.json': [
        'exposome_context_routing_only_not_health_advice',
        'ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE',
        'PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE',
        'DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE',
        'forbiddenClaims'
    ],
    'docs/CHANGELOG_v1.10.50.md': [
        'v1.10.50-alpha-environmental-psychophysiological-exposome-lane',
        'environmental, psychophysiological, hormonal',
    ],
}
for file_name, tokens in checks.items():
    text = Path(file_name).read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{file_name}: missing token {token!r}')
print('v1.10.50 environmental/psychophysiological exposome audit: PASS')
