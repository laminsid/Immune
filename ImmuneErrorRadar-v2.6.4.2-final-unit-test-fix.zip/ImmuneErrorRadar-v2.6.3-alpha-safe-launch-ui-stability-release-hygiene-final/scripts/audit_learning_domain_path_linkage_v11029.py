from pathlib import Path

root = Path('.')
required = [
    'app/src/main/java/com/immunesignal/app/LearningDomainPathLinkageGuard.kt',
    'app/src/test/java/com/immunesignal/app/LearningDomainPathLinkageV11029Test.kt',
    'docs/LEARNING_DOMAIN_PATH_LINKAGE_v1.10.29.md',
]
for rel in required:
    if not (root / rel).exists():
        raise SystemExit(f'Missing required v1.10.29 file: {rel}')

models = (root / 'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt').read_text()
for token in ['learningDomainPathLinkageReport', 'LearningDomainPathLinkageReport.empty()']:
    if token not in models:
        raise SystemExit(f'Missing DatasetForagingReport linkage field token: {token}')

json = (root / 'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt').read_text()
for token in ['learningDomainPathLinkageToJson', 'learningRuleMatchCount', 'domainVocabularyLinkedToQueries', 'matureProbeLinkedToDomainExpertise']:
    if token not in json:
        raise SystemExit(f'Missing JSON serialization token: {token}')

autopilot = (root / 'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
for token in [
    'LearningDomainPathLinkageGuard.evaluate',
    'learningDomainPathLinkageReport = learningDomainPathLinkageReportV11029',
    'v1.10.29 learning/domain path linkage',
    'Learning/Domain Path Linkage connects learning rules',
]:
    if token not in autopilot:
        raise SystemExit(f'Missing ResearchAutopilot wiring token: {token}')

engine = (root / 'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt').read_text()
for token in ['v1.10.29-alpha-learning-domain-path-linkage', 'LearningDomainPathLinkageGuard']:
    if token not in engine:
        raise SystemExit(f'Missing EngineRuntimeStatus token: {token}')

registry = (root / 'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt').read_text()
if 'StaticRuntimeModule("LearningDomainPathLinkageGuard", "integrity")' not in registry:
    raise SystemExit('LearningDomainPathLinkageGuard missing from RuntimeModuleRegistry')

flags = (root / 'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt').read_text()
if 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.29"' not in flags:
    raise SystemExit('Learning session schema version must be 1.10.29')

exporter = (root / 'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for token in ['Learning/domain path linkage v1.10.29', 'learningDomainPathLinkageReport']:
    if token not in exporter:
        raise SystemExit(f'Missing exporter token: {token}')

activity = (root / 'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for token in ['Learning/domain linkage', 'learningDomainPathLinkageReport', 'Link flags: feedback=']:
    if token not in activity:
        raise SystemExit(f'Missing UI token: {token}')

build = (root / 'app/build.gradle.kts').read_text()
for token in ['versionCode = 91', '1.10.29-alpha-learning-domain-path-linkage']:
    if token not in build:
        raise SystemExit(f'Missing build version token: {token}')

guard = (root / 'app/src/main/java/com/immunesignal/app/LearningDomainPathLinkageGuard.kt').read_text()
for token in [
    'learning_domain_path_linkage_not_biological_proof',
    'LearningRuleEngine.nextAction',
    'domainVocabularyLinkedToQueries',
    'matureProbeLinkedToDomainExpertise',
    'queryFeedbackLinked',
]:
    if token not in guard:
        raise SystemExit(f'Missing guard behavior token: {token}')

print('v1.10.29 learning/domain path linkage audit: PASS')
