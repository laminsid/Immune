#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(rel, tokens):
    path = ROOT / rel
    if not path.exists():
        errors.append(f'missing file: {rel}')
        return ''
    text = path.read_text(errors='ignore')
    for token in tokens:
        if token not in text:
            errors.append(f'missing token in {rel}: {token}')
    return text

matrix = require('app/src/main/java/com/immunesignal/app/MetadataClosureStrategyMatrixV11056.kt', [
    'v1.10.59-alpha-github-unified-route-repair',
    'MetadataClosureStrategyMatrixV11058',
    'hyperDriveModeActive',
    'hardDataExtractionMode',
    'criticalUsabilityAnomaly',
    'forcedRouteFitTarget',
    'multiDimensionalAccessionSearchStreams',
    'programmaticCommandLog',
    'runtimeDataDemand',
    'controlComparatorLinkageQueries',
    'HYPER_ALPHA_GEO_GDS_NEURO_VIRAL_DATA_AVAILABILITY',
    'HYPER_ALPHA_SRA_BIOPROJECT_NEURO_VIRAL_DATA_AVAILABILITY',
    'HYPER_BETA_GEO_GDS_EXPOSOME_MODULATOR_ACCESSION',
    'HYPER_BETA_SRA_BIOPROJECT_EXPOSOME_MODULATOR_ACCESSION',
    'G8_HARD_TARGETING_ACCESSION_GENERATION',
    'G9_HARD_DATA_EXTRACTION_DEMAND_NO_FABRICATION',
    'NEXT_JSON_DEMAND::accessions>0_or_log_HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION',
])

# Guard the actual regression: embedded quoted search terms must not be placed in a normal Kotlin string.
unsafe_patterns = [
    'val alpha = "(EBV OR HHV-6) AND (SLE OR "Systemic Lupus"',
    'val beta = "("HPA-axis" OR "Cortisol/DHEA ratio"',
    'query = "(EBV OR HHV-6) AND (SLE OR "Systemic Lupus"',
    'query = "("HPA-axis" OR "Cortisol/DHEA ratio"',
]
for pattern in unsafe_patterns:
    if pattern in matrix:
        errors.append(f'unsafe normal Kotlin string literal remains: {pattern}')
for token in [
    'val alpha = """(EBV OR HHV-6)',
    'val beta = """("HPA-axis"',
    'query = """(EBV OR HHV-6)',
    'query = """("HPA-axis"',
]:
    if token not in matrix:
        errors.append(f'missing triple-quoted query literal token: {token}')

require('app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt', [
    'hyperDriveModeActive',
    'hardDataExtractionMode',
    'criticalUsabilityAnomaly',
    'forcedRouteFitTarget',
    'multiDimensionalAccessionSearchStreams',
    'programmaticCommandLog',
    'runtimeDataDemand',
    'controlComparatorLinkageQueries',
])
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', [
    'MetadataClosureStrategyMatrixV11058.evaluate',
])
require('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt', [
    'MetadataClosureStrategyMatrixV11058',
    'HyperDriveHardDataExtractionV11058',
    'GithubUnifiedRouteRepairV11059',
    'HyperDriveQueryLiteralCompileGuardV11059',
    'FastFullGateVersionUnificationV11059',
])
require('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt', [
    'Metadata Closure Strategy Matrix v1.10.59',
    'Hyper-Drive first stream',
    'Programmatic commands',
    'Runtime data demand',
    'Control/comparator linkage queries',
])
require('docs/GITHUB_UNIFIED_ROUTE_REPAIR_v1.10.59.md', [
    'GitHub Unified Route Repair v1.10.59',
    'triple-quoted',
    'Stream Alpha',
    'Stream Beta',
])
require('docs/CHANGELOG_v1.10.59.md', [
    '1.10.59-alpha-github-unified-route-repair',
    'versionCode=121',
    'schema updated to `1.10.59`',
])

if errors:
    print('v1.10.59 GitHub unified route repair audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.59 GitHub unified route repair audit: PASS')
