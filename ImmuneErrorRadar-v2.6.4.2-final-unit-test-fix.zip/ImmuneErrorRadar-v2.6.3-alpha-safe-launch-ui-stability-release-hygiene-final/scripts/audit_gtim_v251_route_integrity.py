#!/usr/bin/env python3
from pathlib import Path
errors=[]
root=Path('.')

def read(path):
    p=root/path
    if not p.exists():
        errors.append(f'missing {path}')
        return ''
    return p.read_text(encoding='utf-8', errors='replace')

checks={
 'app/src/main/java/com/immunesignal/app/GTIMRouteIntegrityGuardV251.kt': [
    'GTIMRouteIntegrityReportV251',
    'GTIMRouteIntegrityGuardV251',
    'manual snippets/text-mined leads remain exploratory',
    'no new sensitive permissions',
    'ResearchGradeMechanismDossierV1110',
    'DatasetForagingJson.globalTranslationalDossier',
 ],
 'app/src/main/java/com/immunesignal/app/GTIMEvidenceModelsV250.kt': [
    'val routeIntegrity: GTIMRouteIntegrityReportV251',
    'GTIM_ROUTE_NOT_EVALUATED',
 ],
 'app/src/main/java/com/immunesignal/app/GTIMDiscoveryDossierV250.kt': [
    'GTIMRouteIntegrityGuardV251.evaluate',
    'routeIntegrity = routeIntegrity',
    'Route integrity:',
 ],
 'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
    'gtimRouteIntegrityToJson',
    '.put("routeIntegrity", gtimRouteIntegrityToJson(item.routeIntegrity))',
 ],
 'app/src/main/java/com/immunesignal/app/GlobalResearchGradeBriefV11061.kt': [
    'GTIM route integrity:',
    'routeIntegrity',
 ],
 'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
    'GTIM route integrity:',
    'GTIM_ROUTE_NOT_EVALUATED',
 ],
 'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
    'GTIMRouteIntegrityGuardV251',
 ],
 'app/src/test/java/com/immunesignal/app/GTIMDiscoveryDossierV250Test.kt': [
    'GTIM_ROUTE_CONNECTED_WITH_ACCESSION_ANCHOR',
    'GTIM_ROUTE_CONNECTED_WITH_METADATA_ANCHOR',
    'cannot become confirmed accessions',
 ],
}
for path,tokens in checks.items():
    text=read(path)
    for token in tokens:
        if token not in text:
            errors.append(f'{path}: missing {token}')

manifest=read('app/src/main/AndroidManifest.xml')
for forbidden in ['QUERY_ALL_PACKAGES','ACCESS_FINE_LOCATION','READ_SMS','RECORD_AUDIO','CAMERA','READ_CONTACTS','READ_CALL_LOG','PACKAGE_USAGE_STATS']:
    if forbidden in manifest:
        errors.append(f'manifest contains forbidden/sensitive permission: {forbidden}')

route=read('app/src/main/java/com/immunesignal/app/GTIMRouteIntegrityGuardV251.kt')
if 'confidenceIndex.score >= 90' not in route:
    errors.append('route guard must cap GTIM confidence from 90+ external-validation-looking claims')
if 'CONFIRMED' not in route:
    errors.append('route guard must reject confirmed wording in GTIM candidate status')

if errors:
    raise SystemExit('GTIM v2.5.1 route integrity audit failed:\n' + '\n'.join(errors))
print('GTIM v2.5.1 route integrity audit: PASS')
