from pathlib import Path
ROOT = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/SourcePriorityArbitrationPolicy.kt': [
        'SourcePriorityArbitrationPolicy', 'coreAccessionFamilies', 'creative/control routes cannot override accession sweep', 'source_priority_arbitration_not_biological_proof'
    ],
    'app/src/main/java/com/immunesignal/app/DomainExpertiseMemoryPolicy.kt': [
        'DomainExpertiseMemoryPolicy', 'antihistamine_histamine_mast_cell', 'inflammatory_disease_chronic_inflammation', 'domain_expertise_memory_not_biological_proof', 'stableResearchPriors'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'SourcePriorityArbitrationPolicy.arbitrateRoutes', 'DomainExpertiseMemoryPolicy.build', 'v1.10.19 source priority arbitration', 'domain expertise'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': [
        'domainExpertiseReport', 'DomainExpertiseMemoryPolicy.DomainExpertiseReport.empty()'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'domainExpertiseReport', 'domainExpertiseToJson', 'domainExpertiseCardToJson'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Domain expertise', 'Dataset parser, accession acquisition, source arbitration & domain expertise activation'
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'ENABLE_SOURCE_PRIORITY_ARBITRATION', 'ENABLE_DOMAIN_EXPERTISE_MEMORY', '1.10.22'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.10.24-alpha-abstract-accession-harvest', 'SourcePriorityArbitrationPolicy', 'DomainExpertiseMemoryPolicy'
    ],
    'app/build.gradle.kts': ['versionCode = 86', 'versionName = "1.10.24-alpha-abstract-accession-harvest"'],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': ['schemaVersion", 216']
}
missing=[]
for path,tokens in checks.items():
    text=(ROOT/path).read_text(errors='replace')
    for token in tokens:
        if token not in text:
            missing.append(f'{path}: {token}')
if missing:
    raise SystemExit('v1.10.19/20 source-priority/domain-expertise audit failed:\n' + '\n'.join(missing))
print('v1.10.19/20 source priority + domain expertise audit: PASS')
