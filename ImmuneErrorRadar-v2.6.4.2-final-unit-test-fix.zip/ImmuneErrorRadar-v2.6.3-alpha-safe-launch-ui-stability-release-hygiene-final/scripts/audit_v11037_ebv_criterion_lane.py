#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/EBVLeadVerificationV11037.kt': [
        'EBVLeadVerificationPolicy', 'EBVLeadVerificationReport',
        'ebv_criterion_lane_not_biological_proof', 'molecular_mimicry_context',
        'EBV_CRITERION_NEEDS_SECONDARY_LOOKUP', 'EBV causality', 'first scientific breakthrough'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': ['ebvLeadVerificationReport'],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['ebvLeadVerificationReport', 'ebvLeadVerificationToJson'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['EBVLeadVerificationPolicy.evaluate', 'v1.10.37 EBV criterion lane'],
    'app/src/main/java/com/immunesignal/app/LearningRulesUiSummaryV11036.kt': ['EBV criterion lane', 'EBV is a falsifiable verification criterion only'],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': ['EBV criterion lane v1.10.37'],
    'app/src/test/java/com/immunesignal/app/EBVLeadVerificationV11037Test.kt': ['EBVLeadVerificationV11037Test', 'ebvCriterionOpensButBlocksBreakthroughClaims'],
    'docs/EBV_CRITERION_LANE_v1.10.37.md': ['EBV Criterion Lane v1.10.37', 'not as a discovery or breakthrough'],
    'docs/CHANGELOG_v1.10.37.md': ['1.10.37-alpha-ebv-criterion-lane', 'EBVLeadVerificationPolicy'],
}
for rel, tokens in checks.items():
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.37 EBV criterion file: {rel}')
    text = p.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.37 EBV token: {token}')
print('v1.10.37 EBV criterion lane audit: PASS')
