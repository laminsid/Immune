from pathlib import Path
import json

ROOT = Path('.')

def read(path: str) -> str:
    p = ROOT / path
    if not p.exists():
        raise SystemExit(f'missing required file: {path}')
    return p.read_text(encoding='utf-8')

asset_path = 'app/src/main/assets/environmental_psychophysiological_exposome_v1.10.50.json'
asset = json.loads(read(asset_path))
lanes = [family['id'] for family in asset.get('families', [])]
if len(lanes) != 7:
    raise SystemExit(f'expected 7 exposome lane families, found {len(lanes)}')

owner = read('app/src/main/java/com/immunesignal/app/EnvironmentalPsychophysiologicalExposomeLaneV11050.kt')
topic = read('app/src/main/java/com/immunesignal/app/TopicFitMetadataParseUiClarityV11047.kt')
json_export = read('app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt')
autopilot = read('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt')
models = read('app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt')
activity = read('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt')
exporter = read('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt')
learning_ui = read('app/src/main/java/com/immunesignal/app/LearningRulesUiSummaryV11036.kt')
report_builder = read('app/src/main/java/com/immunesignal/app/ResearchReportV3Builder.kt')
registry = read('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt')
status = read('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt')
docs = read('docs/ENVIRONMENTAL_PSYCHOPHYSIOLOGICAL_EXPOSOME_v1.10.50.md') + '\n' + read('docs/CHANGELOG_v1.10.50.md')

required_owner_tokens = [
    'object EnvironmentalPsychophysiologicalExposomeLaneV11050',
    'object ExposomeToLabMapperV11050',
    'object NoExposureAdviceGuardV11050',
    'ASSET_NAME: String = "environmental_psychophysiological_exposome_v1.10.50.json"',
    'PATHWAY_TEMPLATE: String = "Exposure -> Pathway -> Biomarker -> Dataset -> Outcome -> Comparator -> Contradiction"',
    'selectLane(topicText',
    'contextSeeds(topicText',
    'biomarkersForLane',
    'comparatorsForLane',
    'forbiddenClaims'
]
for token in required_owner_tokens:
    if token not in owner:
        raise SystemExit(f'exposome owner missing token: {token}')

for lane in lanes:
    if lane not in owner:
        raise SystemExit(f'lane {lane} is present in asset but missing from Kotlin owner')
    if lane not in topic:
        raise SystemExit(f'lane {lane} is present in asset but not reachable from TopicFit layer')
    if lane not in docs:
        raise SystemExit(f'lane {lane} is present in asset/code but missing from docs/changelog')

wiring_checks = {
    'TopicFit delegates lane selection to owner': ('EnvironmentalPsychophysiologicalExposomeLaneV11050.selectLane', topic),
    'TopicFit delegates seeds to owner': ('EnvironmentalPsychophysiologicalExposomeLaneV11050.contextSeeds', topic),
    'TopicFit uses lab mapper': ('ExposomeToLabMapperV11050.biomarkersForLane', topic),
    'TopicFit uses no-advice guard': ('NoExposureAdviceGuardV11050.forbiddenClaims', topic),
    'Autopilot evaluates TopicFit': ('TopicFitMetadataParseUiClarityV11047.evaluate', autopilot),
    'DatasetForaging model carries report': ('topicFitMetadataParseReport: TopicFitMetadataParseReport', models),
    'DatasetForaging JSON serializes report': ('topicFitMetadataParseToJson', json_export),
    'DatasetForaging JSON serializes EvidenceObjectCandidate': ('evidenceObjectCandidateToJson', json_export),
    'Activity renders exposome route': ('Exposome Topic Route', activity),
    'Exporter renders exposome route': ('Exposome Topic Route / EvidenceObjectCandidate v1.10.50', exporter),
    'Learning summary reads topicFit report': ('topicFitMetadataParseReport', learning_ui),
    'V3 report builder uses topicFit report': ('topicFitMetadataParseReport', report_builder),
    'Runtime registry includes exposome owner': ('EnvironmentalPsychophysiologicalExposomeLaneV11050', registry),
    'Runtime registry includes lab mapper': ('ExposomeToLabMapperV11050', registry),
    'Runtime registry includes advice guard': ('NoExposureAdviceGuardV11050', registry),
    'Runtime status includes exposome owner': ('EnvironmentalPsychophysiologicalExposomeLaneV11050', status),
    'Runtime status includes lab mapper': ('ExposomeToLabMapperV11050', status),
}
for label, (token, text) in wiring_checks.items():
    if token not in text:
        raise SystemExit(f'isolated exposome path detected: {label} missing token {token!r}')

for forbidden in ['treatment recommendation', 'dose advice', 'personal behavior prescription']:
    if forbidden not in owner and forbidden not in asset_path:
        raise SystemExit(f'no-advice guard missing forbidden token: {forbidden}')

print('v1.10.50 no-isolated-exposome-paths audit: PASS')
