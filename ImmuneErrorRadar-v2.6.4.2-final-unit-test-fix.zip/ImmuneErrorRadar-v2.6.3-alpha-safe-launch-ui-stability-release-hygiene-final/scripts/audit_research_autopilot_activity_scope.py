from pathlib import Path
path = Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt')
text = path.read_text(encoding='utf-8')
needle = 'topicFitFull'
first_use = text.find(needle)
if first_use < 0:
    raise SystemExit('ResearchAutopilotActivity scope audit failed: topicFitFull is absent')
first_decl = text.find('val topicFitFull =')
if first_decl < 0:
    raise SystemExit('ResearchAutopilotActivity scope audit failed: topicFitFull is used but not declared')
if first_decl > first_use:
    raise SystemExit('ResearchAutopilotActivity scope audit failed: topicFitFull declaration appears after first use')
if text.count('val topicFitFull =') != 1:
    raise SystemExit(f'ResearchAutopilotActivity scope audit failed: expected one topicFitFull declaration, found {text.count("val topicFitFull =")}')
# Guard against the historical failure: legacy reconciliation blocks must not appear before the local report object exists.
anchor = 'val foragerSection = report.optJSONObject("datasetForagingReport") ?: JSONObject()'
if anchor not in text:
    raise SystemExit('ResearchAutopilotActivity scope audit failed: foragerSection anchor missing')
if text.find('if (topicFitFull.optString("suppressedMatureDomain"') < first_decl:
    raise SystemExit('ResearchAutopilotActivity scope audit failed: reconciliation block appears before topicFitFull declaration')
print('ResearchAutopilotActivity topicFitFull scope audit: PASS')
