#!/usr/bin/env python3
from pathlib import Path
checks = {
    'app/build.gradle.kts': ['versionCode = 126', 'versionName = "1.11.2-alpha-strict-intersection-test-repair"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.11.2-alpha-strict-intersection-test-repair"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 126',
        'LEARNING_SESSION_SCHEMA_VERSION: String = "1.11.2"',
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'ACTIVE_ENGINE_VERSION = "v1.11.2-alpha-strict-intersection-test-repair"',
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 126',
        'VERSION_NAME: String = "1.11.2-alpha-strict-intersection-test-repair"',
        'ENGINE_VERSION: String = "v1.11.2-alpha-strict-intersection-test-repair"',
        'LEARNING_SCHEMA_VERSION: String = "1.11.2"',
        'strict-intersection test repair release',
    ],
}
missing=[]
for rel,tokens in checks.items():
    text=Path(rel).read_text(encoding='utf-8', errors='replace') if Path(rel).exists() else ''
    for token in tokens:
        if token not in text:
            missing.append(f'{rel}: missing {token}')
if missing:
    raise SystemExit('v1.11.2 release linkage audit failed' + ':\n' + '\n'.join(missing))
print('v1.11.2 release linkage audit: PASS')
