#!/usr/bin/env python3
from pathlib import Path
version='1.11.4-alpha-accession-validation-comparator-extraction'
checks = {
    'app/build.gradle.kts': ['versionCode = 128', f'versionName = "{version}"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [f'RELEASE_TRAIN_VERSION_NAME: String = "{version}"', 'RELEASE_TRAIN_VERSION_CODE: Int = 128', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.11.4"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [f'ACTIVE_ENGINE_VERSION = "v{version}"', 'AccessionValidationComparatorExtractionV1114'],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [f'VERSION_NAME: String = "{version}"', f'ENGINE_VERSION: String = "v{version}"', 'LEARNING_SCHEMA_VERSION: String = "1.11.4"'],
    'app/src/main/java/com/immunesignal/app/ResearchGradeMechanismDossierV1110.kt': [f'VEERSION_LABEL: String = "v{version}"'.replace('VEERSION','VERSION'), 'AccessionValidationCardV1114'],
    'docs/CHANGELOG_v1.11.4.md': [version, 'versionCode=128', 'schema updated to `1.11.4`'],
    'docs/ACCESSION_VALIDATION_COMPARATOR_EXTRACTION_v1.11.4.md': ['Accession Validation Comparator Extraction', 'EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION'],
}
missing=[]
for rel,tokens in checks.items():
    p=Path(rel)
    text=p.read_text(encoding='utf-8', errors='replace') if p.exists() else ''
    for token in tokens:
        if token not in text:
            missing.append(f'{rel}: missing {token}')
if missing:
    raise SystemExit('v1.11.4 release linkage audit failed:\n' + '\n'.join(missing))
print('v1.11.4 release linkage audit: PASS')
