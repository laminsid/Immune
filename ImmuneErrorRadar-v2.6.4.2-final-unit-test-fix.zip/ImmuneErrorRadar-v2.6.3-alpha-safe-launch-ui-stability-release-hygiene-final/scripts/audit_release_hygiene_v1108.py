#!/usr/bin/env python3
"""v1.10.8 final hygiene guard.

Prevents local build/cache artifacts from entering release source ZIPs and
protects the dataset-hunt unlock from noisy packaged state. This is intentionally
source-only: it does not require Gradle or network access.
"""
from pathlib import Path

ROOT = Path('.')
forbidden_dirs = {'.gradle', 'build', '.pytest_cache', '__pycache__'}
forbidden_suffixes = {'.pyc', '.pyo', '.apk', '.aab', '.log'}
allowed_log_paths = set()

offenders = []
for path in ROOT.rglob('*'):
    rel = path.relative_to(ROOT)
    parts = set(rel.parts)
    if path.is_dir() and path.name in forbidden_dirs:
        offenders.append(str(rel))
        continue
    if path.is_file():
        if parts & forbidden_dirs:
            offenders.append(str(rel))
            continue
        if path.suffix.lower() in forbidden_suffixes and str(rel) not in allowed_log_paths:
            offenders.append(str(rel))

if offenders:
    raise SystemExit('release hygiene audit failed; remove generated artifacts:\n' + '\n'.join(sorted(offenders)[:80]))

required = [
    'scripts/audit_dataset_hunt_unlock_v1108.py',
    'app/src/main/java/com/immunesignal/app/DatasetHuntSearchUnlockPolicy.kt',
    'app/src/main/java/com/immunesignal/app/DatasetQueryCompiler.kt',
    'app/src/main/java/com/immunesignal/app/DatasetAccessionResolver.kt',
]
missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    raise SystemExit('release hygiene audit failed; missing release-critical file(s): ' + ', '.join(missing))

print('v1.10.8 release hygiene audit: PASS')
