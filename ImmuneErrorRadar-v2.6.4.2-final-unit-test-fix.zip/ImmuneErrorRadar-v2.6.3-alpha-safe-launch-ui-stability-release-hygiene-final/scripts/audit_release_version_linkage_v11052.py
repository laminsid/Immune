#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
version = '1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox'
engine = 'v1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox'
checks = {
    'app/build.gradle.kts': ['versionCode = 114', f'versionName = "{version}"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [f'ACTIVE_ENGINE_VERSION = "{engine}"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [f'RELEASE_TRAIN_VERSION_NAME: String = "{version}"', 'RELEASE_TRAIN_VERSION_CODE: Int = 114', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.52"'],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 114', f'VERSION_NAME: String = "{version}"', f'ENGINE_VERSION: String = "{engine}"', 'LEARNING_SCHEMA_VERSION: String = "1.10.52"'],
}
errors=[]
for rel, tokens in checks.items():
    text=(ROOT/rel).read_text(errors='ignore')
    for token in tokens:
        if token not in text:
            errors.append(f'{rel}: missing {token}')
if errors:
    print('v1.10.52 release linkage audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.52 release linkage audit: PASS')
