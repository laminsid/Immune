from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
checks = {
    'app/src/main/java/com/immunesignal/app/TopicFitMetadataParseUiClarityV11047.kt': [
        'RELAXED_PROGRESSION_NO_CLAIM_RELAXATION',
        'controlledContextSeeds',
        'softProgressionGates',
        'hardClaimGates',
        'routeFitBoostPolicy',
        'Context alignment may raise lookup priority and parsing priority only'
    ],
    'app/src/main/java/com/immunesignal/app/CandidateActionResolver.kt': [
        'v1.10.48 lowers strictness only',
        'contextAlignmentPriority',
        'routeScore < 20',
        'OFF_ROUTE_MINIMUM_METADATA_PROBE',
        'claim upgrade remains blocked until accession/control/time/outcome/contradiction gates close'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'strictnessMode',
        'progressionAllowed',
        'contextSeeds',
        'softProgressionGates',
        'hardClaimGates',
        'routeFitBoostPolicy'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Strictness:',
        'Context seeds:',
        'Hard claim gates:',
        'progress relaxed; claims still gated'
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'RelaxedProgressionContextAlignmentV11048',
        'ControlledContextSeedAligner',
        'SoftProgressionHardClaimGate'
    ],
    'docs/CHANGELOG_v1.10.48.md': [
        '1.10.48-alpha-relaxed-progression-context-alignment',
        'versionCode=110',
        'lower strictness only for research progression',
        'no claim relaxation'
    ],
    'docs/RELAXED_PROGRESSION_CONTEXT_ALIGNMENT_v1.10.48.md': [
        'Relaxed Progression Context Alignment v1.10.48',
        'Context seed → route candidate → metadata lookup → contradiction/null search',
        'must not raise evidence confidence'
    ]
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing required file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel}: missing token {token!r}')
print('v1.10.48 relaxed progression context alignment audit: PASS')
