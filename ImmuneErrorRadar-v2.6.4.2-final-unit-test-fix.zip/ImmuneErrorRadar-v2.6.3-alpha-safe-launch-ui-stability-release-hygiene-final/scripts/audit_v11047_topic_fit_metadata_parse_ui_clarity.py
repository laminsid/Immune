#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
checks = {
    'app/src/main/java/com/immunesignal/app/TopicFitMetadataParseUiClarityV11047.kt': [
        'TopicFitMetadataParseUiClarityV11047',
        'TopicFitMetadataParseReport',
        'preferredLane',
        'suppressedMatureDomain',
        'learningStatus',
        'discoveryStatus',
        'evidenceStatus',
        'topic_fit_metadata_parse_ui_clarity_not_biological_proof',
        'VACCINE_IMMUNE_RESPONSE_LANE',
        'DRUG_PERTURBATION_MICROBIOME_BARRIER_IMMUNE_LANE',
    ],
    'app/src/main/java/com/immunesignal/app/CandidateActionResolver.kt': [
        'forceMinimumMetadataWhenStalled',
        'OFF_ROUTE_MINIMUM_METADATA_PROBE',
        'minimum metadata visibility only',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': [
        'topicFitMetadataParseReport: TopicFitMetadataParseReport',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'topicFitMetadataParseReport',
        'topicFitMetadataParseToJson',
        'learningStatus',
        'discoveryStatus',
        'evidenceStatus',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'topicFitMetadataParseTopV11047',
        'TopicFitMetadataParseUiClarityV11047.evaluate',
        'v1.10.47 topic-fit metadata parse UI clarity',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchReportV3Builder.kt': [
        'Minimum metadata probe forced',
        'Learning:',
        'Discovery:',
        'Evidence:',
        'Topic-fit dominance keeps the user topic ahead of stale priors',
    ],
    'app/src/main/java/com/immunesignal/app/LearningRulesUiSummaryV11036.kt': [
        'topic-fit prior',
        'Learning success and discovery success must be shown separately',
        'TOPIC_FIT_METADATA_PARSE_UI_CLARITY',
        'MINIMUM_METADATA_FORCED_DISCOVERY_STILL_LOCKED',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Topic-Fit Metadata Parse v1.10.47',
        'Selected route:',
        'Learning:',
        'Discovery:',
        'Evidence:',
        'Missing gates:',
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Topic-Fit / Metadata Parse UI Clarity v1.10.47',
        'Suppressed stale prior',
        'Forced metadata / parsed / evidence objects',
    ],
    'app/src/main/java/com/immunesignal/app/LongevityBiologicalSystemsGraphV11046.kt': [
        'VACCINE_IMMUNE_RESPONSE_LANE',
        'DRUG_PERTURBATION_MICROBIOME_BARRIER_IMMUNE_LANE',
        'preferredFromTopic',
        'topicFitBoost',
    ],
    'app/src/main/res/values/strings.xml': [
        '<string name="app_name">ImmuneSignal Research</string>',
    ],
    'app/src/main/AndroidManifest.xml': [
        'android:label="@string/app_name"',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'TopicFitMetadataParseUiClarityV11047',
        'TopicFitDominanceGate',
        'LearningDiscoverySeparationCard',
    ],
    'docs/CHANGELOG_v1.10.47.md': [
        'versionCode=109',
        '1.10.47-alpha-topic-fit-metadata-parse-ui-clarity',
        'ImmuneSignal Research',
    ],
    'docs/TOPIC_FIT_METADATA_PARSE_UI_CLARITY_v1.10.47.md': [
        'Topic-Fit Metadata Parse UI Clarity v1.10.47',
        'Learning, Discovery, and Evidence separately',
    ],
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'MISSING FILE {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'MISSING {token!r} in {rel}')
print('v1.10.47 topic-fit metadata parse UI clarity audit: PASS')
