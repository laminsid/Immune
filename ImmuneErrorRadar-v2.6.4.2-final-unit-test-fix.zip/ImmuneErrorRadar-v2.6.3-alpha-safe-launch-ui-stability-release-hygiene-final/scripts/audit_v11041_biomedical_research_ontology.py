#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/BiomedicalResearchOntologyV11041.kt': [
        'BiomedicalResearchOntologyReport',
        'BiomedicalResearchOntologyV11041',
        'DIAGNOSTIC_PHENOTYPE_VOCABULARY_ALLOWED_FOR_RESEARCH_LINKING',
        'ORGAN_SYSTEMS',
        'BLOOD_HEMATOLOGY_VASCULAR',
        'PATHOGENS_VIRUS_BACTERIA_PARASITE',
        'COMMON_DISEASES_AND_CLINICAL_PHENOTYPES',
        'GENETICS_CELLS_CHROMOSOMES_MITOCHONDRIA',
        'MEDICATIONS_RESEARCH_PERTURBATIONS',
        'HERBS_FOODS_NUTRITION_EXPOSURES',
        'VITAMINS_AND_IMMUNE_FUNCTION',
        'no dose',
        'no treatment advice',
        'not_patient_diagnosis',
    ],
    'app/src/main/assets/biomedical_research_ontology_v1.10.41.json': [
        'organ_systems', 'blood_hematology', 'pathogens',
        'common_diseases_and_diagnostic_phenotypes',
        'genetics_cells_chromosomes_mitochondria',
        'medications_as_research_perturbations',
        'herbs_foods_vitamins_exposures',
        'patient diagnosis', 'treatment recommendation'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': ['biomedicalOntologyReport: BiomedicalResearchOntologyReport'],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['biomedicalOntologyReport', 'biomedicalOntologyToJson'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['BiomedicalResearchOntologyV11041.evaluate', 'v1.10.41 biomedical research ontology'],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': ['Biomedical research ontology v1.10.41', 'diagnosticPhenotypeMode'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': ['Biomedical Research Ontology v1.10.41', 'Diagnostic phenotype mode'],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': ['BiomedicalResearchOntology', 'DiagnosticPhenotypeVocabulary'],
    'app/src/main/java/com/immunesignal/app/FinalReleaseStabilityGuardV11040.kt': ['BiomedicalResearchOntology'],
    'docs/BIOMEDICAL_RESEARCH_ONTOLOGY_v1.10.41.md': ['Scientist / lab mode', 'diagnostic phenotype vocabulary', 'does not diagnose'],
    'docs/CHANGELOG_v1.10.41.md': ['v1.10.41-alpha-biomedical-research-ontology', 'VersionCode: `103`'],
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.41 ontology file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.41 ontology token: {token}')
print('v1.10.41 biomedical research ontology audit: PASS')
