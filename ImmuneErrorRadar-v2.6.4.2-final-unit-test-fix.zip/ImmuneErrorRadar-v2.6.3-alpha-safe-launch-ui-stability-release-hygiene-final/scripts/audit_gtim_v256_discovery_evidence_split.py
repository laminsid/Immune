#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
checks={
 'app/build.gradle.kts': ['versionCode = 132','versionName = "2.5.6-alpha-gtim-intent-discovery-evidence-split"','targetSdk = 35'],
 'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': ['RELEASE_TRAIN_VERSION_NAME: String = "2.5.6-alpha-gtim-intent-discovery-evidence-split"','RELEASE_TRAIN_VERSION_CODE: Int = 132','LEARNING_SESSION_SCHEMA_VERSION: String = "2.5.6"'],
 'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['ACTIVE_ENGINE_VERSION = "v2.5.6-alpha-gtim-intent-discovery-evidence-split"'],
 'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 132','VERSION_NAME: String = "2.5.6-alpha-gtim-intent-discovery-evidence-split"','ENGINE_VERSION: String = "v2.5.6-alpha-gtim-intent-discovery-evidence-split"','LEARNING_SCHEMA_VERSION: String = "2.5.6"'],
 'app/src/main/java/com/immunesignal/app/GTIMDiscoveryEvidenceSplitV256.kt': ['GTIMThreeDimensionalScoreV256','Data Quality','SEMANTIC_PRIOR_NOT_MATRIX','ACTIVE_CONTRADICTION_ENGINE_READY','LAB_PROTOCOL_DRAFT_NOT_VALIDATION','Candidate route ≠ evidence object','Discovery is flexible; evidence upgrade is strict; clinical claims are forbidden'],
 'app/src/main/java/com/immunesignal/app/GTIMEvidenceModelsV250.kt': ['discoveryEvidenceSplit: GTIMDiscoveryEvidenceSplitReportV256'],
 'app/src/main/java/com/immunesignal/app/GTIMDiscoveryDossierV250.kt': ['GTIMDiscoveryEvidenceSplitV256.evaluate','Candidate routes:'],
 'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['discoveryEvidenceSplit','gtimDiscoveryEvidenceSplitToJson','gtimThreeDimensionalScoreToJson','gtimPreliminaryLabProtocolToJson'],
 'app/src/main/java/com/immunesignal/app/GlobalResearchGradeBriefV11061.kt': ['Three-dimensional grade:','Strongest exploratory route:','Lab validation idea:','semantic prior='],
 'docs/GTIM_DISCOVERY_EVIDENCE_SPLIT_v2.5.6.md': ['Semantic Mechanism Prior','LAB_PROTOCOL_DRAFT_NOT_VALIDATION','EXPLORATORY_ROUTE_NOT_EVIDENCE'],
 'app/src/main/assets/gtim_open_discovery_datafeed_v2.5.6.json': ['SEMANTIC_PRIOR_NOT_MATRIX','No diagnosis']
}
errors=[]
for rel,toks in checks.items():
    p=ROOT/rel
    if not p.exists():
        errors.append(f'missing {rel}')
        continue
    text=p.read_text(errors='replace')
    for tok in toks:
        if tok not in text:
            errors.append(f'{rel}: missing {tok!r}')
manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text(errors='replace')
for forbidden in ['QUERY_ALL_PACKAGES','ACCESS_FINE_LOCATION','CAMERA','RECORD_AUDIO','READ_SMS','READ_CONTACTS','READ_CALL_LOG','BODY_SENSORS','PACKAGE_USAGE_STATS']:
    if forbidden in manifest:
        errors.append(f'forbidden Play-sensitive permission/token present: {forbidden}')
if errors:
    raise SystemExit('GTIM v2.5.6 discovery/evidence split audit failed:\n'+'\n'.join(errors))
print('GTIM v2.5.6 discovery/evidence split audit: PASS')
