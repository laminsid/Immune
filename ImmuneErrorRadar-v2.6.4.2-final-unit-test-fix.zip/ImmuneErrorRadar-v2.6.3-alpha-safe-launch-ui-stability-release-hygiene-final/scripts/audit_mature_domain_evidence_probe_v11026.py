#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
required = {
    'app/src/main/java/com/immunesignal/app/MatureDomainEvidenceProbePolicy.kt': [
        'MatureDomainEvidenceProbePolicy',
        'MATURE_DOMAIN_EVIDENCE_PROBE',
        'mature_domain_evidence_probe_not_biological_proof',
        'no diagnosis, treatment, dose, drug ranking, causal claim, or biological proof',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'ENABLE_MATURE_DOMAIN_EVIDENCE_PROBE',
        'MAX_MATURE_DOMAIN_PROBE_QUERIES',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': [
        'matureDomainEvidenceProbeReport',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'matureDomainEvidenceProbeReport',
        'matureDomainProbeToJson',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'MatureDomainEvidenceProbePolicy.shouldRunProbe',
        'MatureDomainEvidenceProbePolicy.compileProbeQueries',
        'DATASET_FORAGING_MATURE_DOMAIN_EVIDENCE_PROBE',
        'v1.10.26 mature-domain evidence probe',
    ],
    'app/build.gradle.kts': [
        'versionCode = 89',
        'versionName = "1.10.27-alpha-dataset-path-linkage-guard"',
    ],
    'docs/MATURE_DOMAIN_EVIDENCE_PROBE_v1.10.26.md': [
        'v1.10.26',
        'Mature Domain Evidence Probe',
        'No diagnosis, treatment, dosage, drug ranking, or clinical recommendation',
    ],
}
for rel, tokens in required.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.26 file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.26 token: {token}')
print('v1.10.26 mature-domain evidence probe audit: PASS')
