# CHANGELOG v1.3.2-alpha — Autonomous Researcher

## Added

- `AutonomousResearchPlanner` and `AutonomousResearchPlan`.
- Explore / Deepen / Challenge / Dataset-Evolve research lanes.
- Autonomous plan JSON export in every research report.
- Report rendering for autonomous plan and next strategy.
- UI copy clarifying that Research Steering is optional.

## Changed

- Query order now prioritizes autonomous lanes before broad defaults.
- If previous cycles returned no useful source, the planner rotates toward dataset/omics/contradiction search.
- Brief reports no longer push the user to steer as the primary solution.

## Still intentionally excluded

- No heavy ML layer.
- No PyTorch Geometric.
- No clinical recommendations.
