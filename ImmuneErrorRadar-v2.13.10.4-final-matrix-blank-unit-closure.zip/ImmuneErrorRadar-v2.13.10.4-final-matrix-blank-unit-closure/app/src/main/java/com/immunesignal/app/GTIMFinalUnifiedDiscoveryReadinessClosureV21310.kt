package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.10.4 — final route/search hardening closure.
 *
 * This layer does not add another biological claim. It is the final identity + route
 * unification lock: one active version, one canonical target, one relaxed C0/C1 discovery
 * candidate surface, and explicit C2/C3 execution blockers. Legacy v2.12/v2.13 rails remain
 * connected as compatibility modules only.
 */
object GTIMFinalUnifiedDiscoveryReadinessClosureV21310 {
    const val VERSION: String = "2.13.10.4-final-matrix-blank-unit-closure"
    const val ENGINE_VERSION: String = "v2.13.10.4-final-matrix-blank-unit-closure"
    const val CLAIM_LIMIT: String = "final_unified_readiness_closure_only_no_validated_discovery_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report)
        val canonicalTarget = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val c2Closure = report.optJSONObject("finalC2InnovationReadinessClosureV2139") ?: JSONObject()
        val evidenceLift = report.optJSONObject("evidenceLiftGateV2139") ?: JSONObject()
        val staleGuard = report.optJSONObject("staleSurfaceZeroExportGuardV2138") ?: JSONObject()
        val finalRelease = report.optJSONObject("finalReleaseLockV21219") ?: JSONObject()
        val staleItems = staleGuard.optInt("staleSurfaceItems", 0)
        val versionAligned = EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ENGINE_VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == 186 &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == "2.13.10.4" &&
            ReleaseVersionLinkageGuard.VERSION_NAME == VERSION &&
            ReleaseVersionLinkageGuard.ENGINE_VERSION == ENGINE_VERSION
        val c2Blocked = evidenceLift.optBoolean("c2Blocked", true) || c2Closure.optString("state").contains("BLOCKED")
        val c1Allowed = evidenceLift.optString("allowedOutputLevel").contains("C1") ||
            c2Closure.optString("allowedOutputLevel").contains("C1") ||
            report.optJSONObject("discoveryClaimLadderV2135")?.optString("level")?.contains("C1") == true
        val state = when {
            !versionAligned -> "FINAL_UNIFIED_DISCOVERY_READINESS_VERSION_DRIFT"
            staleItems > 0 -> "FINAL_UNIFIED_DISCOVERY_READINESS_SURFACE_REVIEW"
            canonicalTarget.isBlank() -> "FINAL_UNIFIED_DISCOVERY_READINESS_NEEDS_CANONICAL_TARGET"
            c2Blocked -> "FINAL_UNIFIED_DISCOVERY_READINESS_READY_C2_BLOCKED_UNTIL_EXECUTION"
            else -> "FINAL_UNIFIED_DISCOVERY_READINESS_READY_REVIEW_REQUIRED"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("engineVersion", ENGINE_VERSION)
            .put("state", state)
            .put("activeDomain", domain)
            .put("canonicalTarget", canonicalTarget)
            .put("versionAligned", versionAligned)
            .put("legacyRailsMode", "compatibility_only")
            .put("legacyVersionRequestsClosed", true)
            .put("staleSurfaceItems", staleItems)
            .put("allowedDiscoveryOutput", if (c1Allowed) "C0_C1_RELAXED_DISCOVERY_CANDIDATE" else "C0_ROUTE_ONLY")
            .put("c2BlockedUntilExecution", c2Blocked)
            .put("c2UpgradeRequirements", JSONArray(listOf(
                "execute_primary_module_scores",
                "run_same_module_on_second_same_domain_dataset",
                "compare_direction_effect_size_FDR_or_equivalent_quality",
                "run_negative_control",
                "run_contradiction_dataset",
                "external_review_before_validated_claim"
            )))
            .put("routeLinkage", "legacy rails -> active-domain guard -> canonical final surface -> future corpus -> capsule/module signal -> innovation synthesis -> execution bridge -> C2 readiness -> final unified closure")
            .put("finalReleaseState", finalRelease.optString("state", "not_yet_rendered"))
            .put("strictnessPolicy", "C0_C1_relaxed_for_non_obvious_candidates; C2_C3_validated_discovery_and_all_clinical_claims_blocked_until_execution")
            .put("claimPromotionAllowed", false)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final unified discovery-readiness closure",
        "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; version_aligned=${obj.optBoolean("versionAligned", false)}.",
        "Allowed output: ${obj.optString("allowedDiscoveryOutput", "C0_ROUTE_ONLY")}; C2_blocked_until_execution=${obj.optBoolean("c2BlockedUntilExecution", true)}; stale_surface_items=${obj.optInt("staleSurfaceItems", -1)}.",
        "C2 upgrade path: ${obj.optJSONArray("c2UpgradeRequirements")?.length() ?: 0} execution requirements remain open before any validated discovery claim.",
        "Route linkage: ${obj.optString("routeLinkage", "legacy_and_new_routes_linked")}",
        "Boundary: final unified closure permits bounded discovery candidates only; no validated scientific, diagnostic, treatment, dosing, vaccine, patient-prediction, or efficacy claim."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        ENGINE_VERSION,
        "FINAL_UNIFIED_DISCOVERY_READINESS_READY_C2_BLOCKED_UNTIL_EXECUTION",
        "legacyVersionRequestsClosed",
        "C0_C1_RELAXED_DISCOVERY_CANDIDATE",
        CLAIM_LIMIT
    ))
}
