package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.13.4 — Active-domain and final-surface consistency guard.
 *
 * This is a conservative routing lock. It keeps legacy rails and future-corpus rails
 * connected, but prevents future corpus/global-memory text from overriding the user's
 * active topic. It also makes the final surface prefer a verified closed target when
 * data-closure succeeds.
 */
object GTIMActiveDomainConsistencyGuardV2134 {
    const val VERSION: String = "2.13.4-active-domain-final-surface-consistency"
    const val CLAIM_LIMIT: String = "domain_consistency_guard_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val activeDomain = activeDomainKey(report)
        val subtype = activeSubtype(report)
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val closure = report.optJSONObject("finalDataClosureExecutionV2132") ?: JSONObject()
        val verified = report.optJSONObject("verifiedMetadataClosurePackV2132") ?: JSONObject()
        val future = report.optJSONObject("futureEvidenceLiteCorpusV2130") ?: JSONObject()
        val expanded = report.optJSONObject("expandedDiseaseFutureCorpusV2131") ?: JSONObject()
        val release = report.optJSONObject("finalReleaseLockV21219") ?: JSONObject()

        val ledgerTarget = ledger.optString("selectedReviewTarget")
        val closedTarget = firstNonBlank(closure.optString("selectedClosedTarget"), verified.optString("selectedClosedTarget"))
        val releaseTarget = release.optString("selectedReviewTarget")
        val canonicalTarget = canonicalFinalTarget(report)
        val futureDomain = future.optString("domainKey")
        val expandedDomain = expanded.optString("domainKey")

        val mismatches = JSONArray()
        if (ledgerTarget.isNotBlank() && !handleFitsActiveDomain(ledgerTarget, activeDomain, subtype)) {
            mismatches.put("ledger_selected_review_target_cross_domain:$ledgerTarget")
        }
        if (closedTarget.isNotBlank() && !handleFitsActiveDomain(closedTarget, activeDomain, subtype)) {
            mismatches.put("closed_target_cross_domain:$closedTarget")
        }
        if (futureDomain.isNotBlank() && !domainCompatible(activeDomain, futureDomain, subtype)) {
            mismatches.put("future_corpus_domain_cross_domain:$futureDomain")
        }
        if (expandedDomain.isNotBlank() && !expandedDomainAllowed(activeDomain, expandedDomain)) {
            mismatches.put("expanded_corpus_background_only:$expandedDomain")
        }
        if (releaseTarget.isNotBlank() && canonicalTarget.isNotBlank() && releaseTarget != canonicalTarget) {
            mismatches.put("release_target_not_canonical:$releaseTarget->$canonicalTarget")
        }

        val state = if (mismatches.length() == 0) {
            "ACTIVE_DOMAIN_CONSISTENCY_READY"
        } else {
            "ACTIVE_DOMAIN_CONSISTENCY_READY_WITH_DEMOTIONS"
        }

        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("activeDomainKey", activeDomain)
            .put("activeSubtype", subtype)
            .put("ledgerSelectedReviewTarget", ledgerTarget)
            .put("selectedClosedTarget", closedTarget)
            .put("canonicalFinalTarget", canonicalTarget)
            .put("futureCorpusDomain", futureDomain)
            .put("expandedCorpusDomain", expandedDomain)
            .put("mismatchCount", mismatches.length())
            .put("demotedCrossDomainSurfaceItems", mismatches)
            .put("policy", "ActiveDomain overrides FutureCorpusDomain; verified closed target overrides candidate ledger only when domain/subtype compatible; cross-domain future blocks are background/contradiction only.")
            .put("oldNewRoutesLinked", true)
            .put("claimPromotionAllowed", false)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun canonicalFinalTarget(report: JSONObject): String {
        val active = activeDomainKey(report)
        val subtype = activeSubtype(report)
        val closure = report.optJSONObject("finalDataClosureExecutionV2132") ?: JSONObject()
        val verified = report.optJSONObject("verifiedMetadataClosurePackV2132") ?: JSONObject()
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val release = report.optJSONObject("finalReleaseLockV21219") ?: JSONObject()
        val candidates = linkedSetOf<String>()
        listOf(
            closure.optString("selectedClosedTarget").takeIf { closure.optInt("readinessScore", 0) >= 7 },
            verified.optString("selectedClosedTarget").takeIf { verified.optString("state").contains("READY") },
            ledger.optString("selectedReviewTarget"),
            release.optString("selectedReviewTarget")
        ).filterNotNull().filter { it.isNotBlank() }.forEach { candidates.add(it) }
        collectSurfaceHandles(report, candidates)

        // v2.13.10.2: filovirus/Ebola subtype is stricter than broad viral host-response.
        // COVID/post-viral targets such as GSE166552 must never become canonical for
        // subtype=viral_filovirus. Prefer a known filovirus-compatible target if present.
        if (subtype == "viral_filovirus" || active.contains("filovirus", ignoreCase = true)) {
            return candidates.firstOrNull { it.equals("GSE45291", ignoreCase = true) }
                ?: candidates.firstOrNull { handleFitsActiveDomain(it, "filovirus_viral_host_response", "viral_filovirus") }
                ?: ""
        }
        return candidates.firstOrNull { handleFitsActiveDomain(it, active, subtype) }.orEmpty()
    }

    fun activeDomainKey(report: JSONObject): String {
        val selector = report.optJSONObject("domainSpecificHypothesisSelectorV2129") ?: JSONObject()
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val focus = report.optJSONObject("studyFocusNormalizerV21282") ?: JSONObject()
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val primary = listOf(
            topic.optString("rawInput"), topic.optString("normalizedTopic"),
            report.optString("researchTopic"), report.optString("normalizedTopic"),
            focus.optString("studyFocus"), focus.optString("title"),
            selector.optString("studyFocus"), selector.optString("domainKey"), selector.optString("topResearchHypothesis"),
            ledger.optString("domainKey")
        ).joinToString(" ").lowercase(Locale.US)
        val selectorDomain = selector.optString("domainKey").lowercase(Locale.US)
        // v2.13.10.2: Ebola/filovirus terms in the active user topic outrank the broad
        // viral_interferon selector. Otherwise filovirus reports can inherit COVID targets.
        if (has(primary, "ebola", "filovirus", "hemorrhagic fever")) return "filovirus_viral_host_response"
        // v2.13.6: selector domain is the first trusted route lock after pathogen subtype.
        // Free-text primary may contain legacy future-corpus text from old report blocks;
        // it must not override an explicit domain selector.
        if (isCanonicalDomain(selectorDomain)) return selectorDomain
        return when {
            has(primary, "ebola", "filovirus", "hemorrhagic fever") -> "filovirus_viral_host_response"
            has(primary, "covid", "sars-cov-2", "post-covid", "post viral", "post-viral") -> "viral_interferon_cytokine"
            has(primary, "depress", "kynuren", "tryptophan", "ido1", "kmo", "neuroimmune", "mood") -> "depression_kynurenine_neuroimmune"
            has(primary, "alzheimer", "microglia", "complement", "inflammasome", "synaptic") -> "neuroinflammation_alzheimer"
            has(primary, "allerg", "type-2", "type 2", "ige", "eosinophil", "mast", "asthma", "eczema") -> "allergy_type2_barrier"
            selectorDomain.isNotBlank() -> selectorDomain
            else -> "open_mechanism_first"
        }
    }

    fun activeSubtype(report: JSONObject): String {
        val text = listOf(
            report.optJSONObject("topicCapture")?.optString("rawInput").orEmpty(),
            report.optJSONObject("topicCapture")?.optString("normalizedTopic").orEmpty(),
            report.optString("researchTopic"),
            report.optJSONObject("studyFocusNormalizerV21282")?.optString("studyFocus").orEmpty(),
            report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("studyFocus").orEmpty()
        ).joinToString(" ").lowercase(Locale.US)
        return when {
            has(text, "ebola", "filovirus", "hemorrhagic fever") -> "viral_filovirus"
            has(text, "covid", "sars-cov-2", "post-covid", "post viral", "post-viral") -> "viral_covid_postviral"
            has(text, "hanta", "hantavirus") -> "viral_hantavirus"
            has(text, "viral", "virus", "interferon") -> "viral_generic"
            else -> "nonviral_or_unspecified"
        }
    }

    fun domainCompatible(activeDomain: String, candidateDomain: String, subtype: String = "nonviral_or_unspecified"): Boolean {
        val a = activeDomain.lowercase(Locale.US)
        val c = candidateDomain.lowercase(Locale.US)
        if (subtype == "viral_filovirus") return c.contains("filovirus")
        return when {
            a == c -> true
            a.contains("filovirus") -> c.contains("filovirus")
            a.contains("viral_interferon") -> c.contains("viral_interferon") && !c.contains("filovirus")
            a.contains("depression_kynurenine") -> c.contains("depression_kynurenine")
            a.contains("allergy_type2") -> c.contains("allergy_type2")
            a.contains("neuroinflammation_alzheimer") -> c.contains("neuroinflammation_alzheimer")
            else -> false
        }
    }

    fun handleFitsActiveDomain(handle: String, activeDomain: String, subtype: String): Boolean {
        val family = knownHandleFamily(handle) ?: return true
        if (subtype == "viral_filovirus") return family.contains("filovirus", ignoreCase = true)
        return domainCompatible(activeDomain, family, subtype)
    }

    private fun collectSurfaceHandles(report: JSONObject, out: MutableSet<String>) {
        fun add(value: String) { if (value.isNotBlank()) out.add(value.uppercase(Locale.US)) }
        fun addArray(array: JSONArray?) {
            if (array == null) return
            for (i in 0 until array.length()) {
                val item = array.opt(i)
                when (item) {
                    is String -> add(item)
                    is JSONObject -> add(firstNonBlank(item.optString("handle"), item.optString("target"), item.optString("id"), item.optString("accession")))
                }
            }
        }
        listOf(
            "candidateHandleLedgerV21215", "terminalDiscoveryContinuationV21212",
            "injectedMetadataSeedPackV21216", "futureEvidenceLiteCorpusV2130"
        ).forEach { key ->
            val obj = report.optJSONObject(key) ?: return@forEach
            add(obj.optString("selectedReviewTarget"))
            add(obj.optString("selectedClosedTarget"))
            add(obj.optString("canonicalTarget"))
            addArray(obj.optJSONArray("candidateHandles"))
            addArray(obj.optJSONArray("allCandidateHandles"))
            addArray(obj.optJSONArray("handles"))
        }
        Regex("\\b(GSE\\d{3,8})\\b", RegexOption.IGNORE_CASE)
            .findAll(report.toString())
            .map { it.value.uppercase(Locale.US) }
            .forEach { out.add(it) }
    }

    fun knownHandleFamily(handle: String): String? = when (handle.uppercase(Locale.US)) {
        "GSE102556" -> "depression_kynurenine_neuroimmune"
        "GSE152202", "GSE166552", "GSE152418", "GSE157103" -> "viral_interferon_cytokine"
        "GSE45291" -> "filovirus_viral_host_response"
        "GSE250594", "GSE146170", "GSE146352" -> "allergy_type2_barrier"
        "GSE72056", "GSE131907" -> "oncology_tumor_microenvironment"
        "GSE49454" -> "rheumatoid_autoimmune_synovial_inflammation"
        else -> null
    }

    private fun isCanonicalDomain(domain: String): Boolean = domain in setOf(
        "filovirus_viral_host_response",
        "viral_interferon_cytokine",
        "depression_kynurenine_neuroimmune",
        "neuroinflammation_alzheimer",
        "allergy_type2_barrier",
        "open_mechanism_first"
    )

    private fun expandedDomainAllowed(activeDomain: String, expandedDomain: String): Boolean {
        val a = activeDomain.lowercase(Locale.US)
        val e = expandedDomain.lowercase(Locale.US)
        return when {
            e.isBlank() -> true
            a.contains("cancer") || a.contains("oncology") || a.contains("tumor") -> e.contains("cancer") || e.contains("oncology") || e.contains("tumor")
            a.contains("allergy") -> false
            a.contains("depression") -> false
            a.contains("viral") || a.contains("filovirus") -> false
            else -> true
        }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
    private fun has(text: String, vararg needles: String): Boolean = needles.any { text.contains(it.lowercase(Locale.US)) }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Active domain consistency guard",
        "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomainKey", "unknown")}; subtype=${obj.optString("activeSubtype", "unknown")}; canonical_target=${obj.optString("canonicalFinalTarget", "none")}; demotions=${obj.optInt("mismatchCount", 0)}.",
        "Policy: ${obj.optString("policy", "active domain controls final surface")}",
        "Boundary: route consistency is improved; evidence promotion remains blocked until hard gates close."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "ACTIVE_DOMAIN_CONSISTENCY_READY", "ActiveDomain overrides FutureCorpusDomain", CLAIM_LIMIT))
}
