package com.immunesignal.app

import org.json.JSONObject

/**
 * legacy_v21313_audit_marker: GTIMFinalSurfaceDomainCoherenceGuardV21313.sanitizeFirstSurfaceLines is superseded at runtime by GTIMLegacyLeakFirewallV21316.sanitizeFirstSurface.
 * legacy_v21314_compat_marker: 2.13.12.4-generalized-route-coherence-runtime-budget; 2.13.12.3-final-surface-domain-coherence-runtime-budget; 2.13.12.3-mobile-safe-first-surface.
 * Mobile-safe first-surface renderer.
 *
 * Keeps the on-device/PDF first surface short and deterministic while the old/new rails
 * remain linked in JSON and the technical appendix. This is a crash-prevention layer, not
 * a science/evidence layer.
 */
object GTIMMobileSafeFirstSurfaceV21313 {
    // legacy_v21314_active_compat: VERSION: String = "2.13.14-final-generalized-route-coherence-unified"
    const val VERSION: String = "2.13.15-final-hypothesis-first-discovery-unified"
    const val CLAIM_LIMIT: String = "mobile_safe_surface_only_no_evidence_upgrade"

    fun renderCompactPreview(report: JSONObject): String {
        RuntimeCrashSafetyAndTopicGuardV2740.renderFailureCard(report)?.let { return it }
        if (GTIMFinalActiveDecisionSurfaceV21317.shouldOwnSurface(report)) return GTIMFinalActiveDecisionSurfaceV21317.renderLines(report).take(12).joinToString("\n")
        val hypothesis = GTIMHypothesisFirstDiscoveryEngineV21315.toJson(report)
        val active = hypothesis.optString("activeDomain", "unknown")
        val canonical = hypothesis.optString("canonicalTarget", "")
        return listOf(
            "Immune Research Summary",
            "• Primary result: ${hypothesis.optString("primaryResult", "C0_ROUTE_HYPOTHESIS")}",
            "• Active domain: $active",
            "• Canonical target: ${canonical.ifBlank { "not selected yet" }}",
            "• Hypothesis: ${hypothesis.optString("primaryHypothesis", "route-specific hypothesis pending")}",
            "• Output: compact on-device preview; full rails are saved/exportable.",
            "• Strictness: C0/C1/C2/C3 sandbox preview relaxed; missing evidence is an execution checklist only; clinical/actionable/validated-proof claims remain blocked.",
            "• Next: ${hypothesis.optString("bestSearchQuery", "verify topic-compatible dataset/capsule")}",
            "• Boundary: research-only. No diagnosis, treatment, dosing, vaccine advice, efficacy, or validated discovery claim."
        ).joinToString("\n")
    }

    fun render(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        if (GTIMFinalActiveDecisionSurfaceV21317.shouldOwnSurface(report)) return GTIMFinalActiveDecisionSurfaceV21317.renderLines(report)
        val technical = technicalLines // v2.13.15.1: never rebuild the old renderLines tree on hypothesis-first/mobile first surface
        val guardJson = GTIMFinalSurfaceDomainCoherenceGuardV21313.toJson(report)
        val active = guardJson.optString("activeDomain", "unknown")
        val canonical = guardJson.optString("canonicalTarget", "")
        val lines = mutableListOf<String>()
        lines += "Immu DZ Global Research Dossier"
        lines += "Global Study Abstract"
        lines += "Study: ${GTIMFinalSurfaceDomainCoherenceGuardV21313.studyFocusFor(active)}; canonical_target=${canonical.ifBlank { "none" }}."
        lines += "Contribution: route isolation → canonical target check → capsule/module execution plan → replication/contradiction gates, without promoting evidence."
        val hypothesis = report.optJSONObject("hypothesisFirstDiscoveryEngineV21315") ?: GTIMHypothesisFirstDiscoveryEngineV21315.toJson(report)
        val scope = report.optJSONObject("domainScopedClosureRendererV21315") ?: GTIMDomainScopedClosureRendererV21315.toJson(report)
        lines += "Current result: ${hypothesis.optString("primaryResult", resultLine(active, canonical))}"
        lines += "Decision gate: C0/C1/C2/C3 sandbox preview is allowed even without matrix or replication; topic-fit, comparator labels, provenance, capsule/matrix, module scores, negative control, replication, and contradiction are execution checklist items for proof/clinical promotion only."
        lines += ""
        lines += GTIMHypothesisFirstDiscoveryEngineV21315.publicLines(hypothesis)
        lines += ""
        lines += GTIMFinalSurfaceDomainCoherenceGuardV21313.publicLines(guardJson)
        lines += ""
        lines += GTIMDomainScopedClosureRendererV21315.publicLines(scope)
        lines += ""
        lines += GTIMLegacyLeakFirewallV21316.publicLines(report.optJSONObject("legacyLeakFirewallV21316") ?: GTIMLegacyLeakFirewallV21316.toJson(report))
        lines += ""
        report.optJSONObject("finalRouteSearchHardeningClosureV213103")?.let { lines += GTIMDomainScopedClosureRendererV21315.renderOrAppendixNote("finalRouteSearchHardeningClosureV213103", active, GTIMFinalRouteSearchHardeningClosureV213103.publicLines(it)) }
        lines += ""
        report.optJSONObject("finalUnifiedDiscoveryReadinessClosureV21310")?.let { lines += GTIMDomainScopedClosureRendererV21315.renderOrAppendixNote("finalUnifiedDiscoveryReadinessClosureV21310", active, GTIMFinalUnifiedDiscoveryReadinessClosureV21310.publicLines(it)) }
        lines += ""
        report.optJSONObject("experimentalClaimRelaxationV21312")?.let {
            lines += GTIMLegacyLeakFirewallV21316.sanitizeFirstSurface(report, GTIMExperimentalClaimRelaxationV21312.publicLines(it))
        }
        lines += ""
        lines += GTIMStudyResultCardV2126.publicLines(report, technical)
        lines += ""
        lines += "Functional repair study dossier"
        lines += GTIMStudyResultCardV2126.compactDossierLines(report, technical)
        lines += ""
        lines += "Matrix / external evidence plan"
        lines += GTIMMatrixShortcutResolverV2124.publicLines(report, technical).take(6)
        lines += GTIMMatrixShortcutStatusLayerV2129.publicLines(report, technical).take(4)
        lines += ""
        report.optJSONObject("discoverySynthesisCardV2137")?.let { lines += GTIMDiscoverySynthesisCardV2137.publicLines(it) }
        lines += ""
        report.optJSONObject("finalC2InnovationReadinessClosureV2139")?.let { lines += GTIMFinalC2InnovationReadinessClosureV2139.publicLines(it) }
        lines += ""
        report.optJSONObject("finalBundibugyoSearchRuntimeClosureV213106")?.let { lines += GTIMDomainScopedClosureRendererV21315.renderOrAppendixNote("finalBundibugyoSearchRuntimeClosureV213106", active, GTIMFinalBundibugyoSearchRuntimeClosureV213106.publicLines(it)) }
        lines += ""
        report.optJSONObject("finalReleaseLockV21219")?.let { lines += GTIMFinalReleaseLockV21219.publicLines(it).take(6) }
        lines += ""
        lines += "Compatibility appendix policy: legacy v2.12/v2.13 rails, debug tokens, external routes, old medical dossier blocks, and superseded candidates remain in JSON/export appendix only."
        lines += "Boundary: research-only evidence routing; no mechanism, causality, gene/pathway signal, diagnosis, treatment, dosing, efficacy, or patient prediction is proven."
        return GTIMLegacyLeakFirewallV21316.sanitizeFirstSurface(report, lines)
    }

    private fun resultLine(activeDomain: String, canonicalTarget: String): String = when {
        canonicalTarget.isNotBlank() -> "C1/C2/C3 sandbox candidate; missing execution gates do not block preview."
        activeDomain.isNotBlank() && activeDomain != "open_mechanism_first" -> "C0 route hypothesis; target/capsule discovery required but hypothesis output is allowed."
        else -> "topic-level research route; active domain still required before hypothesis upgrade."
    }
}
