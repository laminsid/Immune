package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * legacy_v21314_compat_marker: 2.13.12.4-generalized-route-coherence-runtime-budget; 2.13.12.3-final-surface-domain-coherence-runtime-budget; 2.13.12.3-mobile-safe-first-surface.
 * v2.13.14.4 — generalized route/domain coherence guard.
 *
 * This layer replaces one-off COVID/filovirus surface fixes with a generic contract:
 * user topic -> active domain/subtype -> canonical target -> first-surface blocks.
 * Any block that carries another domain, pathogen, or known accession family is kept as
 * appendix/history/contradiction only. It is rendering/orchestration only and never upgrades evidence.
 */
object GTIMGeneralizedRouteCoherenceGuardV21314 {
    // legacy_v21314_active_compat: VERSION: String = "2.13.14-final-generalized-route-coherence-unified"
    const val VERSION: String = "2.13.15-final-hypothesis-first-discovery-unified"
    const val CLAIM_LIMIT: String = "generalized_route_coherence_only_no_evidence_or_clinical_claim"
    const val MAX_FIRST_SURFACE_LINES: Int = 96
    const val MAX_FIRST_SURFACE_CHARS: Int = 18000

    data class DomainProfile(
        val domain: String,
        val studyFocus: String,
        val routeLabel: String,
        val toolClass: String,
        val hypothesis: String,
        val repairFunction: String,
        val keywords: List<String>,
        val blockedIfActiveElsewhere: Boolean = true
    )

    private val profiles: Map<String, DomainProfile> = listOf(
        DomainProfile(
            "filovirus_viral_host_response",
            "filovirus host-response study",
            "filovirus host-response/capsule/module execution",
            "filovirus_host_response_module_route",
            "filovirus outcome may be stratified by immune timing plus endothelial/coagulation injury modules rather than static cytokine intensity alone",
            "score interferon timing, endothelial/coagulation injury, cytokine amplification, and severity/survival comparator modules before any C2 upgrade",
            listOf("bundibugyo", "bdbv", "ebola", "ebolavirus", "filovirus", "viral hemorrhagic", "hemorrhagic fever")
        ),
        DomainProfile(
            "viral_hantavirus_host_response",
            "hantavirus host-response study",
            "hantavirus host-response/capsule/module execution",
            "hantavirus_host_response_module_route",
            "hantavirus severity may depend on interferon timing, endothelial/vascular injury, and immune-amplification modules rather than generic viral inflammation",
            "verify hantavirus topic-fit, vascular/endothelial injury context, comparator labels, sample provenance, and module scores before any C2 upgrade",
            listOf("hanta", "hantavirus", "hantaan", "sin nombre", "puumala", "andes virus")
        ),
        DomainProfile(
            "viral_dengue_host_response",
            "dengue host-response study",
            "dengue host-response/capsule/module execution",
            "dengue_host_response_module_route",
            "dengue severity may depend on interferon timing, vascular-leak/endothelial injury, platelet/coagulation context, and cytokine-amplification modules",
            "verify dengue topic-fit, severity/comparator labels, vascular-leak/endothelial readouts, sample provenance, and module scores before any C2 upgrade",
            listOf("dengue", "denv", "dengue virus")
        ),
        DomainProfile(
            "viral_zika_host_response",
            "Zika host-response study",
            "Zika host-response/capsule/module execution",
            "zika_host_response_module_route",
            "Zika host-response may depend on interferon timing, neurodevelopmental/tissue tropism context, and immune amplification rather than generic viral cytokine activity",
            "verify Zika topic-fit, tissue/tropism context, comparator labels, sample provenance, and module scores before any C2 upgrade",
            listOf("zika", "zikv", "zika virus")
        ),
        DomainProfile(
            "viral_influenza_host_response",
            "influenza host-response study",
            "influenza host-response/capsule/module execution",
            "influenza_host_response_module_route",
            "influenza severity may depend on interferon timing, epithelial injury, cytokine amplification, and recovery-state modules",
            "verify influenza topic-fit, infected/control or severity labels, epithelial/airway context, sample provenance, and module scores before any C2 upgrade",
            listOf("influenza", "flu", "h1n1", "h3n2", "avian influenza")
        ),
        DomainProfile(
            "viral_interferon_cytokine",
            "viral interferon-cytokine host-response study",
            "COVID/post-viral interferon-cytokine host-response/capsule/module execution",
            "interferon_cytokine_host_response_route",
            "viral trigger may dysregulate interferon timing and IL-6/TNF amplification; test whether host-response, endothelial/tissue injury, and recovery-state signatures track severity or persistence",
            "map interferon timing, cytokine amplification, endothelial/tissue injury, and recovery-state markers before nominating barrier or microbiome repair context",
            listOf("covid", "sars-cov-2", "sars", "corona", "post-covid", "long covid", "post-viral")
        ),
        DomainProfile(
            "viral_generic_host_response",
            "pathogen-specific viral host-response study",
            "pathogen-specific viral host-response/capsule/module execution",
            "pathogen_specific_viral_host_response_route",
            "the viral topic may require pathogen-specific host-response routing before borrowing COVID, filovirus, or generic interferon templates",
            "first lock the pathogen/subtype, then verify topic-compatible dataset handles, comparator labels, sample provenance, and module scores before any C2 upgrade",
            listOf("virus", "viral", "pathogen", "interferon", "cytokine"),
            blockedIfActiveElsewhere = false
        ),
        DomainProfile(
            "depression_kynurenine_neuroimmune",
            "depression kynurenine-neuroimmune enzyme study",
            "depression/kynurenine neuroimmune execution",
            "kynurenine_enzyme_neuroimmune_route",
            "depression with kynurenine pathway signals may reflect IDO1/KMO-linked tryptophan metabolism and neuroimmune neurotransmission stress",
            "map IDO1/KMO and tryptophan-kynurenine readouts before nominating microbiome or barrier-support repair routes",
            listOf("depress", "kynuren", "tryptophan", "ido1", "tdo2", "kmo", "neuroimmune", "mood")
        ),
        DomainProfile(
            "allergy_type2_barrier",
            "allergy/type-2 microbiome-barrier study",
            "allergy/type-2 barrier execution",
            "natural_commensal_or_postbiotic_barrier_route",
            "barrier/tolerance dysfunction may lower type-2 inflammatory thresholds; test IgE, mast-cell, eosinophil, epithelial, and type-2 cytokine readouts",
            "prioritize epithelial/barrier, tolerance-threshold, IgE/mast/eosinophil, and type-2 readouts before any repair claim",
            listOf("allerg", "asthma", "eczema", "ige", "eosinophil", "mast", "type-2", "type 2")
        ),
        DomainProfile(
            "metabolic_inflammation",
            "metabolic inflammation immune-energy study",
            "metabolic inflammation execution",
            "metabolite_restoration_or_postbiotic_route",
            "metabolic stress may create immune-energy mismatch and barrier-linked inflammatory amplification",
            "verify metabolic comparator labels, insulin/glucose context, inflammatory tone, barrier/endotoxin readouts, and capsule availability before any repair claim",
            listOf("diabet", "insulin", "glucose", "metabolic", "obesity", "lps", "endotoxin")
        ),
        DomainProfile(
            "environmental_exposure_xenobiotic",
            "environmental-exposure immune/barrier study",
            "environmental exposure immune/barrier execution",
            "bioremediation_or_binding_function_research_route",
            "xenobiotic or particle pressure may interact with endocrine signaling, barrier stress, and inflammatory amplification",
            "verify exposure annotation, biosafety boundaries, tissue/species, comparator labels, and immune/barrier readouts before any repair-function claim",
            listOf("pfas", "bpa", "phthalate", "microplastic", "xenobiotic", "pollution", "toxin")
        ),
        DomainProfile(
            "oncology_tumor_microenvironment",
            "tumor microenvironment immune study",
            "tumor microenvironment execution",
            "tumor_microenvironment_immune_route",
            "tumor immune-state differences may depend on microenvironment modules rather than a single inflammatory marker",
            "verify tumor/control or subtype labels, tissue provenance, immune-cell/module signals, and contradiction datasets before any discovery upgrade",
            listOf("cancer", "tumor", "tumour", "oncology", "tme", "melanoma", "carcinoma")
        )
    ).associateBy { it.domain }

    fun effectiveActiveDomain(report: JSONObject, fallback: String = ""): String {
        // User/topic text has priority. Legacy report blocks may contain old route names, so
        // they must not override the current question.
        pathogenDomainFromText(primaryTopicText(report))?.let { return it }
        val normalized = fallback.trim().lowercase(Locale.US)
        if (normalized.isNotBlank() && normalized != "viral_interferon_cytokine") return normalized
        if (normalized == "viral_interferon_cytokine") return normalized
        val locked = firstNonBlank(
            report.optJSONObject("activeDomainConsistencyGuardV2134")?.optString("activeDomainKey").orEmpty(),
            report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainKey").orEmpty()
        )
        if (locked.isNotBlank() && locked != "open_mechanism_first") return locked
        pathogenDomainFromText(reportText(report))?.let { return it }
        return "open_mechanism_first"
    }

    fun toJson(report: JSONObject, fallbackActiveDomain: String = ""): JSONObject {
        val active = effectiveActiveDomain(report, fallbackActiveDomain)
        val subtype = GTIMDomainScopedClosureRendererV21315.normalizedSubtype(active, firstNonBlank(
            report.optJSONObject("finalRouteSearchHardeningClosureV213103")?.optString("activeSubtype").orEmpty(),
            report.optJSONObject("finalUnifiedDiscoveryReadinessClosureV21310")?.optString("activeSubtype").orEmpty(),
            report.optJSONObject("finalBundibugyoSearchRuntimeClosureV213106")?.optString("activeSubtype").orEmpty(),
            report.optJSONObject("activeDomainConsistencyGuardV2134")?.optString("activeSubtype").orEmpty(),
            GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report)
        ))
        val canonical = canonicalTargetFor(report, active)
        return JSONObject()
            .put("version", VERSION)
            .put("activeDomain", active)
            .put("activeSubtype", subtype)
            .put("canonicalTarget", canonical)
            .put("algorithm", "generic_block_domain_inference_then_active_domain_match")
            .put("supportedDomainProfiles", JSONArray(profiles.keys.sorted()))
            .put("firstSurfacePolicy", "render only active-domain-compatible blocks; cross-domain handles/routes become appendix/history/contradiction")
            .put("oneOffCovidOrFilovirusRule", false)
            .put("mobileRuntimePolicy", "compact first surface; full legacy rails retained in JSON/export appendix")
            .put("claimPromotionAllowed", true)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun studyFocusFor(activeDomain: String, fallback: String = ""): String =
        profile(activeDomain).studyFocus.ifBlank { fallback.ifBlank { "immune root-dysfunction study" } }

    fun domainLineFor(activeDomain: String, fallback: String = ""): String {
        val p = profile(activeDomain)
        return if (p.domain == "open_mechanism_first") fallback else
            "Active-domain hypothesis lock: ${p.domain} → ${p.toolClass}; repair=${p.repairFunction}; claim_limit=$CLAIM_LIMIT"
    }

    fun topHypothesisFor(activeDomain: String, fallback: String = ""): String =
        profile(activeDomain).hypothesis.ifBlank { fallback }

    fun repairFunctionFor(activeDomain: String, fallback: String = ""): String =
        profile(activeDomain).repairFunction.ifBlank { fallback }

    fun biologicalToolFor(activeDomain: String, fallback: String = ""): String =
        profile(activeDomain).toolClass.ifBlank { fallback }

    fun sanitizeFirstSurfaceLines(report: JSONObject, fallbackActiveDomain: String, canonicalTarget: String, lines: List<String>): List<String> {
        val active = effectiveActiveDomain(report, fallbackActiveDomain)
        val subtype = GTIMDomainScopedClosureRendererV21315.normalizedSubtype(active, GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report))
        val canonical = canonicalTarget.ifBlank { canonicalTargetFor(report, active) }
        val out = mutableListOf<String>()
        val seen = linkedSetOf<String>()
        var charBudget = 0
        for (line in lines) {
            val sanitized = sanitizeLine(line, active, subtype, canonical) ?: continue
            val bounded = sanitized.take(520)
            if (bounded.isBlank() && out.lastOrNull().isNullOrBlank()) continue
            val key = bounded.lowercase(Locale.US).replace(Regex("\\s+"), " ").trim()
            if (key.isNotBlank() && !seen.add(key)) continue
            if (out.size >= MAX_FIRST_SURFACE_LINES || charBudget + bounded.length > MAX_FIRST_SURFACE_CHARS) {
                out += "First-surface budget: additional compatibility/debug rails are retained in JSON/export appendix, not rendered on-device."
                break
            }
            out += bounded
            charBudget += bounded.length + 1
        }
        return out
    }

    fun sanitizeLine(line: String, activeDomain: String, subtype: String, canonicalTarget: String): String? {
        val trimmed = line.trimEnd()
        if (trimmed.isBlank()) return trimmed
        val lower = trimmed.lowercase(Locale.US)
        if (isHistoricalOrBlockedContext(lower)) return trimmed

        val lineDomain = inferLineDomain(trimmed)
        val handles = handlesInLine(trimmed)
        val mismatchedHandle = handles.firstOrNull { handle ->
            val family = knownHandleFamily(handle)
            family != null && !domainCompatible(activeDomain, family, subtype)
        }
        val domainMismatch = lineDomain != null && !domainCompatible(activeDomain, lineDomain, subtype)

        if (trimmed.startsWith("Study focus:")) return "Study focus: ${studyFocusFor(activeDomain)}"
        if (trimmed.startsWith("Domain lock:")) return "Domain lock: ${domainLineFor(activeDomain)}"
        if (trimmed.startsWith("Top research hypothesis:") && (domainMismatch || containsConflictingPathogen(lower, activeDomain))) {
            return "Top research hypothesis: ${topHypothesisFor(activeDomain)}"
        }
        if (trimmed.startsWith("Best functional repair candidate:") && (domainMismatch || containsConflictingPathogen(lower, activeDomain))) {
            return "Best functional repair candidate: ${repairFunctionFor(activeDomain)}"
        }
        if (trimmed.startsWith("Candidate biological tool class:") && (domainMismatch || containsConflictingTool(lower, activeDomain))) {
            return "Candidate biological tool class: ${biologicalToolFor(activeDomain)}"
        }
        if (trimmed.startsWith("Research route:") && (domainMismatch || containsConflictingPathogen(lower, activeDomain))) {
            return "Research route: active-domain route: ${profile(activeDomain).routeLabel}; cross-domain legacy routes remain appendix/background only."
        }
        if ((trimmed.startsWith("State:") || trimmed.startsWith("Status:")) && domainMismatch) {
            return "State: ACTIVE_DOMAIN_ROUTE_NEEDS_EVIDENCE; active_domain=$activeDomain; canonical_target=${canonicalTarget.ifBlank { "none" }}; mismatched legacy state retained in appendix."
        }
        if (trimmed.startsWith("Next best action:") && mismatchedHandle != null) {
            return if (canonicalTarget.isNotBlank()) {
                "Next best action: Inspect $canonicalTarget as the canonical target; keep $mismatchedHandle as appendix/history only until it proves topic compatibility."
            } else {
                "Next best action: select a topic-compatible canonical target for $activeDomain before using $mismatchedHandle."
            }
        }
        if ((trimmed.startsWith("Shortcut handle:") || trimmed.startsWith("Selected") || lower.contains("selected_review_target=")) && mismatchedHandle != null) {
            return historicalLine(mismatchedHandle, activeDomain, canonicalTarget)
        }
        if (mismatchedHandle != null) return historicalLine(mismatchedHandle, activeDomain, canonicalTarget)
        if (domainMismatch && isDecisionSurfaceLine(trimmed)) return null
        return trimmed
    }

    fun inferLineDomain(line: String): String? {
        val lower = line.lowercase(Locale.US)
        handlesInLine(line).firstNotNullOfOrNull { knownHandleFamily(it) }?.let { return it }
        Regex("(?:active_domain|activeDomain|domain|domainKey|selected_domain|selectedDomain)[:=]([a-zA-Z0-9_\\-]+)")
            .find(lower)?.groupValues?.getOrNull(1)?.replace('-', '_')?.let { token ->
                if (token.isNotBlank() && token != "unknown" && token != "none") return normalizeDomainToken(token)
            }
        pathogenDomainFromText(lower)?.let { return it }
        profiles.values.firstOrNull { p -> p.domain != "viral_generic_host_response" && p.keywords.any { lower.contains(it.lowercase(Locale.US)) } }?.let { return it.domain }
        if (listOf("virus", "viral", "interferon", "cytokine", "host-response", "host response").any { lower.contains(it) }) {
            return "viral_generic_host_response"
        }
        return null
    }

    fun domainCompatible(activeDomain: String, candidateDomain: String, subtype: String = ""): Boolean {
        val a = normalizeDomainToken(activeDomain)
        val c = normalizeDomainToken(candidateDomain)
        if (a.isBlank() || c.isBlank() || a == c) return true
        if (c == "viral_generic_host_response") return a.startsWith("viral_") || a.contains("filovirus")
        if (a == "viral_generic_host_response") return c.startsWith("viral_") || c.contains("filovirus")
        if (a == "viral_interferon_cytokine") return c == "viral_interferon_cytokine" || c == "viral_generic_host_response"
        if (a.startsWith("viral_") || a.contains("filovirus")) return c == a || c == "viral_generic_host_response"
        return false
    }

    fun knownHandleFamily(handle: String): String? = when (handle.uppercase(Locale.US)) {
        "GSE102556" -> "depression_kynurenine_neuroimmune"
        "GSE152202", "GSE166552", "GSE152418", "GSE157103" -> "viral_interferon_cytokine"
        "GSE45291" -> "filovirus_viral_host_response"
        "GSE250594", "GSE146170", "GSE146352" -> "allergy_type2_barrier"
        "GSE72056", "GSE131907" -> "oncology_tumor_microenvironment"
        "GSE49454" -> "rheumatoid_autoimmune_synovial_inflammation"
        else -> GTIMActiveDomainConsistencyGuardV2134.knownHandleFamily(handle)
    }

    fun targetCompatibleWithActiveDomain(activeDomain: String, handle: String, subtype: String = ""): Boolean {
        if (handle.isBlank()) return true
        val family = knownHandleFamily(handle) ?: return true
        return domainCompatible(activeDomain, family, subtype)
    }

    fun canonicalTargetFor(report: JSONObject, fallbackActiveDomain: String = ""): String {
        val active = effectiveActiveDomain(report, fallbackActiveDomain)
        val subtype = GTIMDomainScopedClosureRendererV21315.normalizedSubtype(active, firstNonBlank(
            report.optJSONObject("finalRouteSearchHardeningClosureV213103")?.optString("activeSubtype").orEmpty(),
            report.optJSONObject("finalUnifiedDiscoveryReadinessClosureV21310")?.optString("activeSubtype").orEmpty(),
            report.optJSONObject("finalBundibugyoSearchRuntimeClosureV213106")?.optString("activeSubtype").orEmpty(),
            report.optJSONObject("activeDomainConsistencyGuardV2134")?.optString("activeSubtype").orEmpty(),
            GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report)
        ))
        val candidates = linkedSetOf<String>()
        fun add(value: String) {
            val v = value.trim().uppercase(Locale.US)
            if (v.isNotBlank() && Regex("^(GSE\\d{3,8}|BDBV[_A-Z0-9-]*)$").matches(v)) candidates += v
        }
        fun addArray(array: JSONArray?) {
            if (array == null) return
            for (i in 0 until array.length()) {
                when (val item = array.opt(i)) {
                    is String -> add(item)
                    is JSONObject -> listOf("canonicalTarget", "selectedReviewTarget", "selectedClosedTarget", "handle", "target", "accession", "id").forEach { add(item.optString(it)) }
                }
            }
        }
        listOf(
            "finalRouteSearchHardeningClosureV213103",
            "finalUnifiedDiscoveryReadinessClosureV21310",
            "finalBundibugyoSearchRuntimeClosureV213106",
            "canonicalFinalSurfaceGuardV2135",
            "activeDomainConsistencyGuardV2134",
            "verifiedMetadataClosurePackV2132",
            "processedCapsuleStoreV2135",
            "matrixShortcutResolverV2124",
            "candidateHandleLedgerV21215"
        ).forEach { key ->
            val obj = report.optJSONObject(key) ?: return@forEach
            listOf("canonicalTarget", "canonicalFinalTarget", "selectedReviewTarget", "selectedClosedTarget", "handle", "target").forEach { add(obj.optString(it)) }
            listOf("candidateHandles", "allCandidateHandles", "handles", "candidateTargets").forEach { addArray(obj.optJSONArray(it)) }
        }
        add(GTIMFinalBundibugyoSearchRuntimeClosureV213106.finalCanonicalTarget(report))
        add(GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report))
        return candidates.firstOrNull { targetCompatibleWithActiveDomain(active, it, subtype) }.orEmpty()
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "generic_block_domain_inference_then_active_domain_match",
        "viral_hantavirus_host_response",
        "viral_dengue_host_response",
        "viral_zika_host_response",
        "viral_influenza_host_response",
        "oneOffCovidOrFilovirusRule=false",
        CLAIM_LIMIT
    ))

    private fun profile(domain: String): DomainProfile = profiles[normalizeDomainToken(domain)] ?: DomainProfile(
        normalizeDomainToken(domain).ifBlank { "open_mechanism_first" },
        domain.replace('_', ' ').ifBlank { "open immune root-dysfunction study" },
        "active-domain evidence routing",
        "open_function_first_route",
        "the active topic requires route-specific evidence extraction before any dataset, mechanism, or repair claim",
        "lock the active domain, select a compatible target, verify comparator/sample provenance, then run capsule/module/contradiction checks",
        emptyList(),
        blockedIfActiveElsewhere = false
    )

    private fun pathogenDomainFromText(text: String): String? {
        val lower = text.lowercase(Locale.US)
        return when {
            has(lower, "bundibugyo", "bdbv", "ebola", "ebolavirus", "filovirus", "marburg", "viral hemorrhagic", "hemorrhagic fever") -> "filovirus_viral_host_response"
            has(lower, "hanta", "hantavirus", "hantaan", "sin nombre", "puumala", "andes virus") -> "viral_hantavirus_host_response"
            has(lower, "dengue", "denv") -> "viral_dengue_host_response"
            has(lower, "zika", "zikv") -> "viral_zika_host_response"
            has(lower, "influenza", "h1n1", "h3n2", "avian influenza") -> "viral_influenza_host_response"
            has(lower, "covid", "sars-cov-2", "post-covid", "long covid", "post viral", "post-viral") -> "viral_interferon_cytokine"
            has(lower, "nipah", "rsv", "measles", "chikungunya", "west nile", "virus", "viral") -> "viral_generic_host_response"
            else -> null
        }
    }

    private fun containsConflictingPathogen(lower: String, activeDomain: String): Boolean {
        val inferred = pathogenDomainFromText(lower) ?: return false
        return !domainCompatible(activeDomain, inferred)
    }

    private fun containsConflictingTool(lower: String, activeDomain: String): Boolean {
        val p = profile(activeDomain)
        val knownToolTokens = profiles.values.map { it.toolClass.lowercase(Locale.US) }.filter { it.isNotBlank() }
        return knownToolTokens.any { lower.contains(it) && !lower.contains(p.toolClass.lowercase(Locale.US)) }
    }

    private fun isDecisionSurfaceLine(line: String): Boolean {
        val lower = line.lowercase(Locale.US)
        return listOf("study focus:", "domain lock:", "research route:", "state:", "status:", "next best action:", "shortcut handle:", "target", "candidate", "selected_review_target").any { lower.contains(it) }
    }

    private fun historicalLine(handle: String, activeDomain: String, canonicalTarget: String): String = if (canonicalTarget.isNotBlank() && !handle.equals(canonicalTarget, ignoreCase = true)) {
        "Historical lookup only: $handle is cross-domain for active_domain=$activeDomain and superseded_by_canonical_target=$canonicalTarget; retain only as appendix/history/contradiction."
    } else {
        "Historical lookup only: $handle is cross-domain for active_domain=$activeDomain; not_active_target until topic compatibility is proven."
    }

    private fun handlesInLine(line: String): List<String> = Regex("\\bGSE\\d{3,8}\\b", RegexOption.IGNORE_CASE)
        .findAll(line)
        .map { it.value.uppercase(Locale.US) }
        .distinct()
        .toList()

    private fun primaryTopicText(report: JSONObject): String = listOf(
        report.optJSONObject("topicCapture")?.optString("rawInput").orEmpty(),
        report.optJSONObject("topicCapture")?.optString("normalizedTopic").orEmpty(),
        report.optString("researchTopic"),
        report.optString("normalizedTopic"),
        report.optString("topic"),
        report.optJSONObject("studyFocusNormalizerV21282")?.optString("studyFocus").orEmpty()
    ).joinToString(" ").lowercase(Locale.US)

    private fun reportText(report: JSONObject): String = listOf(
        report.optJSONObject("topicCapture")?.optString("rawInput").orEmpty(),
        report.optJSONObject("topicCapture")?.optString("normalizedTopic").orEmpty(),
        report.optString("researchTopic"), report.optString("normalizedTopic"), report.optString("topic"),
        report.optJSONObject("studyFocusNormalizerV21282")?.optString("studyFocus").orEmpty(),
        report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("studyFocus").orEmpty(),
        report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainKey").orEmpty()
    ).joinToString(" ").lowercase(Locale.US)

    private fun normalizeDomainToken(value: String): String = value.trim().lowercase(Locale.US).replace('-', '_')
    private fun isHistoricalOrBlockedContext(lower: String): Boolean = listOf(
        "historical lookup only", "superseded_by_canonical_target", "not_active_target", "blocked", "background/contradiction", "contradiction/background", "appendix", "compatibility", "demoted"
    ).any { lower.contains(it) }
    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
    private fun has(text: String, vararg needles: String): Boolean = needles.any { text.contains(it.lowercase(Locale.US)) }
}
