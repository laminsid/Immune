package com.immunesignal.app

/**
 * v1.10.47 + v1.10.48: topic-fit, controlled relaxation, minimum-metadata forcing, and UI clarity patch.
 *
 * This layer fixes a real operational failure observed in v1.10.46/v1.10.47 reports:
 * old mature-domain priors can dominate unrelated topics, many candidates can be
 * retained without any parsed metadata, and the UI can confuse useful learning
 * with a scientific discovery. The layer is deliberately bounded: it never
 * creates an EvidenceObject, diagnosis, treatment, dose, or causal claim. v1.10.48 lowers strictness only for progression: context-aligned leads can move to metadata inspection without relaxing claim gates.
 */
data class TopicFitMetadataParseReport(
    val active: Boolean,
    val state: String,
    val topicLabel: String,
    val preferredLane: String,
    val topicFitScore: Int,
    val suppressedMatureDomain: String,
    val forcedMinimumMetadataCount: Int,
    val parsedMetadataCount: Int,
    val evidenceObjectCount: Int,
    val learningStatus: String,
    val discoveryStatus: String,
    val evidenceStatus: String,
    val missingGates: List<String>,
    val invalidators: List<String>,
    val userSummaryLines: List<String>,
    val nextAction: String,
    val reasons: List<String>,
    val strictnessMode: String,
    val progressionAllowed: Boolean,
    val contextSeeds: List<String>,
    val softProgressionGates: List<String>,
    val hardClaimGates: List<String>,
    val contextAlignmentStatus: String,
    val routeFitBoostPolicy: String,
    val claimLimit: String = CLAIM_LIMIT
) {
    companion object {
        const val CLAIM_LIMIT: String = "topic_fit_metadata_parse_ui_clarity_not_biological_proof"

        fun empty() = TopicFitMetadataParseReport(
            active = false,
            state = "NOT_EVALUATED",
            topicLabel = "unknown",
            preferredLane = "none",
            topicFitScore = 0,
            suppressedMatureDomain = "none",
            forcedMinimumMetadataCount = 0,
            parsedMetadataCount = 0,
            evidenceObjectCount = 0,
            learningStatus = "not evaluated",
            discoveryStatus = "not evaluated",
            evidenceStatus = "not evaluated",
            missingGates = emptyList(),
            invalidators = emptyList(),
            userSummaryLines = emptyList(),
            nextAction = "Run a research cycle.",
            reasons = emptyList(),
            strictnessMode = "NOT_EVALUATED",
            progressionAllowed = false,
            contextSeeds = emptyList(),
            softProgressionGates = emptyList(),
            hardClaimGates = emptyList(),
            contextAlignmentStatus = "NOT_EVALUATED",
            routeFitBoostPolicy = "No context alignment evaluated."
        )
    }
}

object TopicFitMetadataParseUiClarityV11047 {
    const val CLAIM_LIMIT: String = TopicFitMetadataParseReport.CLAIM_LIMIT
    const val STRICTNESS_MODE: String = "RELAXED_PROGRESSION_NO_CLAIM_RELAXATION"

    fun evaluate(
        steering: ResearchSteeringProfile?,
        matureFocus: MatureDomainFocusReport,
        longevity: LongevityBiologicalSystemsReport,
        candidateAction: CandidateActionReport,
        parsedMetadata: List<ParsedDatasetMetadata>,
        evidenceObjects: List<EvidenceObject>,
        metadataClosure: MetadataClosureReport
    ): TopicFitMetadataParseReport {
        val topicText = topicText(steering)
        val topicLabel = topicLabel(topicText)
        val preferredLane = preferredLane(topicText, longevity.selectedLane)
        val matureDomain = matureFocus.selectedDomain.ifBlank { "none" }
        val suppressed = suppressedMatureDomain(topicText, matureDomain)
        val topicFit = topicFitScore(topicText, matureDomain, preferredLane)
        val forcedCount = candidateAction.minimumMetadataAccessions.size
        val missing = buildMissingGates(metadataClosure, parsedMetadata)
        val contextSeeds = controlledContextSeeds(topicText, preferredLane, longevity)
        val softGates = softProgressionGates(missing)
        val hardGates = hardClaimGates(missing)
        val contextAlignment = contextAlignmentStatus(topicText, contextSeeds, suppressed, candidateAction)
        val progressionAllowed = candidateAction.decisions.isNotEmpty() || contextSeeds.isNotEmpty() || parsedMetadata.isNotEmpty()
        val evidenceCount = evidenceObjects.size
        val parsedCount = parsedMetadata.size
        val discovery = when {
            evidenceCount > 0 -> "evidence_object_present"
            parsedCount > 0 -> "metadata_probe_only_no_discovery"
            candidateAction.decisions.isNotEmpty() -> "candidate_leads_only_no_discovery"
            else -> "no_discovery_yet"
        }
        val learning = when {
            suppressed != "none" -> "topic_fit_corrected_stale_prior"
            forcedCount > 0 -> "minimum_metadata_parse_forced"
            parsedCount > 0 -> "metadata_visibility_improved"
            contextSeeds.isNotEmpty() -> "context_aligned_lookup_ready"
            else -> "routing_memory_only"
        }
        val evidenceStatus = when {
            evidenceCount > 0 -> "evidence_object_available_but_still_claim_gated"
            parsedCount > 0 -> "parsed_metadata_available_not_biological_proof"
            else -> "no_evidence_object_yet"
        }
        val state = when {
            suppressed != "none" && forcedCount > 0 -> "TOPIC_FIT_CORRECTED_AND_METADATA_FORCED"
            suppressed != "none" -> "TOPIC_FIT_SUPPRESSED_STALE_PRIOR"
            forcedCount > 0 -> "MINIMUM_METADATA_PARSE_FORCED_NO_UPGRADE"
            parsedCount > 0 -> "PARSED_METADATA_VISIBLE_NO_UPGRADE"
            progressionAllowed -> "RELAXED_PROGRESSION_CONTEXT_ALIGNED_NO_UPGRADE"
            else -> "TOPIC_FIT_ACTIVE_NO_EVIDENCE_OBJECT"
        }
        val invalidators = listOf(
            "no explicit accession/source ID after secondary lookup",
            "no control/comparator after minimum metadata closure",
            "no outcome labels or case/contrast definition",
            "no time order or longitudinal/serial signal",
            "topic-fit remains low and a stale mature prior keeps replaying"
        )
        val next = when {
            forcedCount > 0 -> "Parse the forced minimum-metadata candidate(s), then run contradiction/null-result search before strengthening any biological link."
            parsedCount > 0 && missing.isNotEmpty() -> "Close ${missing.take(3).joinToString("+")} on parsed metadata before any hypothesis upgrade."
            suppressed != "none" -> "Cooldown stale mature-domain prior and execute the topic-specific lane: $preferredLane."
            contextSeeds.isNotEmpty() -> "Run context-aligned secondary lookup with ${contextSeeds.take(5).joinToString("+")}; parse minimum metadata even if route-fit is still weak."
            else -> "Run topic-specific secondary lookup; do not broaden through stale mature-domain priors."
        }
        val reasons = buildList {
            add("Topic-fit dominance runs before mature-domain reuse.")
            add("Learning and discovery are separated: learning can be useful while discovery remains absent.")
            add("v1.10.48 strictness is lowered only for progress: context seeds and weak leads may move to metadata inspection; claim gates stay hard.")
            if (suppressed != "none") add("Suppressed mature domain '$suppressed' because topic '$topicLabel' prefers '$preferredLane'.")
            if (forcedCount > 0) add("CandidateActionResolver forced $forcedCount minimum metadata parse(s) without allowing a hypothesis upgrade.")
            if (contextSeeds.isNotEmpty()) add("Controlled context seeds selected for lookup priority only: ${contextSeeds.take(6).joinToString(", ")}.")
            if (parsedCount == 0) add("No parsed metadata is visible yet; UI must not imply a discovery.")
        }
        val userSummary = listOf(
            "Topic: $topicLabel",
            "Selected route: $preferredLane",
            "Why selected: topic-fit gate outranks stale mature-domain priors.",
            "Strictness: $STRICTNESS_MODE",
            "Learning: $learning",
            "Discovery: $discovery",
            "Evidence: $evidenceStatus",
            "Context seeds: ${contextSeeds.take(6).joinToString(", ").ifBlank { "none" }}",
            "Soft progression gates: ${softGates.take(5).joinToString(", ").ifBlank { "none" }}",
            "Hard claim gates: ${hardGates.take(5).joinToString(", ").ifBlank { "none" }}",
            "Invalidates if: ${invalidators.take(2).joinToString("; ")}",
            "Next: $next"
        )
        return TopicFitMetadataParseReport(
            active = true,
            state = state,
            topicLabel = topicLabel,
            preferredLane = preferredLane,
            topicFitScore = topicFit,
            suppressedMatureDomain = suppressed,
            forcedMinimumMetadataCount = forcedCount,
            parsedMetadataCount = parsedCount,
            evidenceObjectCount = evidenceCount,
            learningStatus = learning,
            discoveryStatus = discovery,
            evidenceStatus = evidenceStatus,
            missingGates = missing,
            invalidators = invalidators,
            userSummaryLines = userSummary,
            nextAction = next,
            reasons = reasons,
            strictnessMode = STRICTNESS_MODE,
            progressionAllowed = progressionAllowed,
            contextSeeds = contextSeeds,
            softProgressionGates = softGates,
            hardClaimGates = hardGates,
            contextAlignmentStatus = contextAlignment,
            routeFitBoostPolicy = "Context alignment may raise lookup priority and parsing priority only; it must not raise evidence confidence, route-fit-to-proof, or hypothesis probability.",
            claimLimit = CLAIM_LIMIT
        )
    }

    fun topicText(steering: ResearchSteeringProfile?): String {
        return listOf(
            steering?.focusQuestion.orEmpty(),
            steering?.variables?.joinToString(" ").orEmpty(),
            steering?.requiredTerms?.joinToString(" ").orEmpty(),
            steering?.inferredAxes?.joinToString(" ").orEmpty()
        ).joinToString(" ").lowercase()
    }

    fun preferredLane(topicText: String, fallbackSystemsLane: String = "none"): String {
        return when {
            containsAny(topicText, "vaccine", "vaccination", "immunization", "immune response") -> {
                if (containsAny(topicText, "aging", "elderly", "older", "cmv", "immunosenescence", "t-cell", "t cell")) {
                    "IMMUNE_AGING_VACCINE_RESPONSE_LANE"
                } else {
                    "VACCINE_IMMUNE_RESPONSE_LANE"
                }
            }
            containsAny(topicText, "antibiotic", "antibiotics", "microbiome", "dysbiosis") -> "DRUG_PERTURBATION_MICROBIOME_BARRIER_IMMUNE_LANE"
            containsAny(topicText, "sleep", "circadian", "insomnia", "hrv", "cortisol", "night") -> "CIRCADIAN_SLEEP_INTELLIGENCE"
            containsAny(topicText, "fatigue", "me/cfs", "long covid", "mitochondria", "metabolomics") -> "MITOCHONDRIAL_FATIGUE_LANE"
            containsAny(topicText, "longevity", "aging", "senescence", "immunosenescence", "cmv") -> "IMMUNE_AGING_IMMUNOSENESCENCE_LANE"
            containsAny(topicText, "allergy", "allergies", "histamine", "antihistamine", "mast cell", "urticaria") -> "TYPE2_ALLERGY_MAST_CELL_LANE"
            fallbackSystemsLane.isNotBlank() && fallbackSystemsLane != "OFF" -> fallbackSystemsLane
            else -> "GENERAL_IMMUNE_DATASET_CLOSURE_LANE"
        }
    }

    private fun topicLabel(topicText: String): String = when {
        containsAny(topicText, "vaccine", "vaccination", "immunization") -> "Vaccine"
        containsAny(topicText, "antibiotic", "antibiotics") -> "Antibiotics"
        containsAny(topicText, "sleep", "circadian") -> "Sleep/Circadian"
        containsAny(topicText, "fatigue", "me/cfs", "long covid") -> "Fatigue/Long COVID"
        containsAny(topicText, "longevity", "aging", "senescence") -> "Longevity/Aging"
        containsAny(topicText, "allergy", "allergies", "histamine", "antihistamine") -> "Allergy/Histamine"
        topicText.isBlank() -> "unknown"
        else -> topicText.split(Regex("\\s+")).take(4).joinToString(" ")
    }

    private fun suppressedMatureDomain(topicText: String, matureDomain: String): String {
        if (matureDomain == "none" || matureDomain.isBlank()) return "none"
        val mature = matureDomain.lowercase()
        val allergyTopic = containsAny(topicText, "allergy", "allergies", "histamine", "antihistamine", "mast cell", "urticaria")
        val staleAntihistamine = mature.contains("antihistamine") || mature.contains("mast_cell") || mature.contains("histamine")
        val topicExplicitlyDifferent = containsAny(topicText, "vaccine", "vaccination", "antibiotic", "antibiotics", "longevity", "sleep", "circadian", "fatigue", "long covid", "mitochondria")
        return if (staleAntihistamine && topicExplicitlyDifferent && !allergyTopic) matureDomain else "none"
    }

    private fun topicFitScore(topicText: String, matureDomain: String, preferredLane: String): Int {
        val suppressed = suppressedMatureDomain(topicText, matureDomain) != "none"
        return when {
            suppressed -> 35
            preferredLane == "GENERAL_IMMUNE_DATASET_CLOSURE_LANE" -> 55
            preferredLane.contains("VACCINE") && containsAny(topicText, "vaccine", "vaccination", "immunization") -> 92
            preferredLane.contains("ANTIBIOTIC", true) || preferredLane.contains("DRUG_PERTURBATION", true) -> 90
            preferredLane.contains("SLEEP", true) || preferredLane.contains("CIRCADIAN", true) -> 90
            preferredLane.contains("FATIGUE", true) || preferredLane.contains("MITOCHONDRIAL", true) -> 88
            else -> 72
        }
    }

    private fun buildMissingGates(metadataClosure: MetadataClosureReport, parsedMetadata: List<ParsedDatasetMetadata>): List<String> {
        val fromClosure = metadataClosure.missingFields
        val parsedGaps = buildList {
            if (parsedMetadata.isEmpty()) {
                add("minimum_metadata")
                add("accession")
            }
            if (parsedMetadata.none { it.controlLabels.isNotEmpty() }) add("control_or_comparator")
            if (parsedMetadata.none { it.outcomeLabels.isNotEmpty() }) add("outcome_labels")
            if (parsedMetadata.none { it.timeCourseLabels.isNotEmpty() }) add("time_order")
        }
        return (fromClosure + parsedGaps)
            .map { it.replace("comparator_control", "control_or_comparator") }
            .distinct()
            .take(10)
    }


    private fun controlledContextSeeds(topicText: String, preferredLane: String, longevity: LongevityBiologicalSystemsReport): List<String> {
        val seeds = mutableListOf<String>()
        when (preferredLane) {
            "VACCINE_IMMUNE_RESPONSE_LANE" -> seeds += listOf("vaccine response", "human cohort", "neutralizing antibody", "T-cell response", "control", "time-course", "adverse immune response", "nonresponse")
            "IMMUNE_AGING_VACCINE_RESPONSE_LANE" -> seeds += listOf("CMV serostatus", "T-cell exhaustion", "immunosenescence", "vaccine response", "older adults", "CRP", "IL-6", "negative control")
            "DRUG_PERTURBATION_MICROBIOME_BARRIER_IMMUNE_LANE" -> seeds += listOf("antibiotics", "microbiome", "barrier tissue", "dysbiosis", "inflammation", "control cohort", "before after", "no association")
            "CIRCADIAN_SLEEP_INTELLIGENCE" -> seeds += listOf("sleep", "circadian", "cortisol", "HRV", "CRP", "IL-6", "light exposure", "night eating", "null result")
            "MITOCHONDRIAL_FATIGUE_LANE" -> seeds += listOf("mitochondrial", "fatigue", "Long COVID", "ME/CFS", "metabolomics", "oxidative stress", "matched control", "failed replication")
            "IMMUNE_AGING_IMMUNOSENESCENCE_LANE" -> seeds += listOf("CMV", "T-cell subsets", "T-cell exhaustion", "CRP", "IL-6", "TNF-alpha", "older adults", "no association")
            "TYPE2_ALLERGY_MAST_CELL_LANE" -> seeds += listOf("histamine", "mast cell", "IgE", "eosinophil", "allergy", "control", "negative control", "heterogeneity")
            else -> seeds += listOf("human cohort", "dataset accession", "outcome labels", "control comparator", "time order", "contradiction")
        }
        if (topicText.contains("ebv") || topicText.contains("epstein") || longevity.selectedLane.contains("IMMUNE_AGING")) seeds += listOf("EBV", "HHV-6", "CMV", "molecular mimicry", "failed replication")
        if (topicText.contains("hpa") || topicText.contains("stress") || topicText.contains("cortisol")) seeds += listOf("HPA axis", "cortisol", "stress immune", "diurnal rhythm")
        return seeds.distinct().take(12)
    }

    private fun softProgressionGates(missing: List<String>): List<String> {
        val allowed = setOf("minimum_metadata", "accession", "control_or_comparator", "outcome_labels", "time_order", "sample_size", "condition_labels", "license_access")
        return missing.filter { it in allowed }.distinct()
    }

    private fun hardClaimGates(missing: List<String>): List<String> {
        return (missing + listOf("contradiction_or_negative_control", "human_or_patient_data", "no_treatment_or_dose_claim"))
            .map { it.replace("comparator_control", "control_or_comparator") }
            .distinct()
            .take(12)
    }

    private fun contextAlignmentStatus(
        topicText: String,
        contextSeeds: List<String>,
        suppressed: String,
        candidateAction: CandidateActionReport
    ): String {
        return when {
            contextSeeds.isNotEmpty() && candidateAction.minimumMetadataAccessions.isNotEmpty() -> "CONTEXT_ALIGNED_METADATA_PROBE_READY"
            contextSeeds.isNotEmpty() && suppressed != "none" -> "CONTEXT_ALIGNED_STALE_PRIOR_SUPPRESSED"
            contextSeeds.isNotEmpty() && topicText.isNotBlank() -> "CONTEXT_ALIGNED_SECONDARY_LOOKUP_READY"
            else -> "NO_CONTEXT_ALIGNMENT"
        }
    }

    private fun containsAny(text: String, vararg terms: String): Boolean = terms.any { text.contains(it.lowercase()) }
}
