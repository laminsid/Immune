package com.immunesignal.app

object ResearchReportV3Builder {
    fun build(
        findings: List<ResearchFinding>,
        hypothesisObjects: List<HypothesisObject>,
        learningDeltas: List<LearningDeltaCard>,
        datasetCandidates: List<DatasetCandidateV133>,
        pivot: PivotDecision,
        repeatedSkipped: Int,
        global: GlobalImmuneIntelligenceReport
    ): ResearchReportV3 {
        val safePivot = ScopeDisciplineLock.sanitizePivot(pivot)
        val topFinding = findings.maxByOrNull { it.noveltyScore }
        val topDataset = datasetCandidates.maxByOrNull { it.priorityScore }
        val topDelta = learningDeltas.firstOrNull { it.deltaType != "no_change" }
        val topHypothesis = hypothesisObjects.maxByOrNull { it.evidenceScore10 + it.causalityScore / 20.0 }
        val contradictionFindings = findings.filter { finding ->
            finding.causality.contradictionPenalty > 0 ||
                finding.negativeControl.status.contains("fail", ignoreCase = true) ||
                finding.negativeControl.status.contains("control_required", ignoreCase = true) ||
                finding.sanityFlags.contains("METADATA_ONLY") ||
                finding.sanityFlags.contains("ABSTRACT_FETCH_FAILED")
        }
        val cycleResult = when {
            topDataset != null && topDataset.priorityScore >= 60 -> "Dataset lead found"
            topDelta != null -> "Hypothesis changed"
            topFinding != null -> "Useful delta"
            safePivot.pivotType != "NO_PIVOT" -> "No useful delta — strategy pivoted"
            repeatedSkipped > 0 -> "Stalled by repeated sources"
            else -> "No useful delta"
        }
        val lead = when {
            topDataset != null -> "${topDataset.datasetId}: ${topDataset.dataType}, ${topDataset.species}, ${topDataset.outcomeLabelsHint}."
            topFinding != null -> topFinding.title
            else -> "No new useful source saved in this cycle."
        }
        val hypothesisText = buildHypothesisText(topHypothesis, topDelta, topFinding, global, safePivot)
        val supporting = buildSupportingEvidence(topDataset, topFinding, topHypothesis, findings)
        val counterEvidence = buildCounterEvidence(contradictionFindings, findings, safePivot)
        val unknowns = buildWhatNotBelieveYet(topFinding, topDataset, topHypothesis, contradictionFindings, safePivot)
        val changed = when {
            topDelta != null -> "${topDelta.hypothesisId}: ${topDelta.previousStatus} → ${topDelta.currentStatus} (${topDelta.deltaType})."
            topHypothesis != null -> "${topHypothesis.hypothesisId}: ${topHypothesis.status}, discovery ${topHypothesis.discoveryState}, bias ${topHypothesis.biasRiskState}."
            else -> "No hypothesis upgraded."
        }
        val why = when {
            topDataset != null -> topDataset.whyUseful
            topFinding != null -> topFinding.whyItMatters
            global.globalDiscoveryAction.isNotBlank() -> global.globalDiscoveryAction
            else -> "The cycle mainly informed search strategy rather than biology."
        }
        val next = when {
            topDataset != null -> topDataset.nextVerificationStep
            safePivot.pivotType != "NO_PIVOT" -> "Pivot to ${safePivot.nextIntent}: ${safePivot.nextQuerySeed}".take(260)
            global.nextGlobalDatasetNeeded.isNotBlank() -> global.nextGlobalDatasetNeeded
            contradictionFindings.isEmpty() && findings.isNotEmpty() -> "Run explicit contradiction search before upgrading this hypothesis."
            else -> "Run the next autonomous Explore/Deepen/Challenge cycle."
        }
        val caution = unknowns
        val report = ResearchReportV3(
            cycleResult = cycleResult,
            newUsefulLead = lead,
            hypothesisChanged = changed,
            whyItMatters = why,
            nextAutonomousMove = next,
            doNotBelieveYet = caution,
            technicalPointer = "Open Full Technical Report for locks, evidence, bias, and raw findings.",
            hypothesis = hypothesisText,
            supportingEvidence = supporting,
            counterEvidenceOrContradiction = counterEvidence,
            whatWeDoNotBelieveYet = caution
        )
        return SmartReportIntegrityLock.enforce(report)
    }

    private fun buildHypothesisText(
        topHypothesis: HypothesisObject?,
        topDelta: LearningDeltaCard?,
        topFinding: ResearchFinding?,
        global: GlobalImmuneIntelligenceReport,
        pivot: PivotDecision
    ): String {
        return when {
            topHypothesis != null -> "${topHypothesis.hypothesisId}: ${topHypothesis.label} — state ${topHypothesis.discoveryState}/${topHypothesis.biasRiskState}."
            topDelta != null -> "${topDelta.hypothesisId}: hypothesis state changed from ${topDelta.previousStatus} to ${topDelta.currentStatus}."
            topFinding != null -> "Candidate lead from source ${topFinding.sourceId}: ${topFinding.bridgeSignal.ifBlank { topFinding.title }}."
            global.globalHypotheses.isNotEmpty() -> global.globalHypotheses.first().question
            pivot.pivotType != "NO_PIVOT" -> "Current autonomous search hypothesis is under-specified; the cycle produced a strategy pivot rather than biological confirmation."
            else -> "No active hypothesis passed the minimum evidence gates in this cycle."
        }
    }

    private fun buildSupportingEvidence(
        topDataset: DatasetCandidateV133?,
        topFinding: ResearchFinding?,
        topHypothesis: HypothesisObject?,
        findings: List<ResearchFinding>
    ): String {
        return when {
            topDataset != null -> "Dataset candidate ${topDataset.datasetId} (${topDataset.dataType}, ${topDataset.species}) with priority ${topDataset.priorityScore}; still requires accession/sample/outcome verification."
            topFinding != null -> "Top source: ${topFinding.title}; evidence quality ${topFinding.evidence.evidenceQualityScore}/100; causality ${topFinding.causality.causalityScore}/100; species ${topFinding.evidence.speciesClass}."
            topHypothesis != null -> "Hypothesis score: evidence ${topHypothesis.evidenceScore10}/10, data trust ${topHypothesis.dataTrustScore}/100, causality ${topHypothesis.causalityScore}/100."
            findings.isNotEmpty() -> "${findings.size} finding(s) survived ranking, but none reached dataset/hypothesis lead priority."
            else -> "No supporting evidence survived this cycle; this absence is reported explicitly rather than hidden."
        }
    }

    private fun buildCounterEvidence(
        contradictionFindings: List<ResearchFinding>,
        findings: List<ResearchFinding>,
        pivot: PivotDecision
    ): String {
        val direct = contradictionFindings.firstOrNull()
        return when {
            direct != null -> "Counter-signal: ${direct.title}; contradiction penalty ${direct.causality.contradictionPenalty}; negative-control status ${direct.negativeControl.status}; flags ${direct.sanityFlags.joinToString(", ").ifBlank { "none" }}."
            pivot.nextIntent == "contradiction_search" -> "No direct contradiction survived yet; the next move is contradiction search, so confirmation is forbidden."
            findings.isNotEmpty() -> "No explicit contradiction found in surviving findings; absence of contradiction is not confirmation. Run failed-replication/no-association search next."
            else -> "No counter-evidence found because no useful evidence survived; this blocks any upgrade."
        }
    }

    private fun buildWhatNotBelieveYet(
        topFinding: ResearchFinding?,
        topDataset: DatasetCandidateV133?,
        topHypothesis: HypothesisObject?,
        contradictionFindings: List<ResearchFinding>,
        pivot: PivotDecision
    ): String {
        val warnings = mutableListOf<String>()
        warnings += "Do not treat correlation as causation."
        if (topDataset != null) warnings += "Do not believe dataset usefulness until accession, sample size, labels, and license are verified."
        if (topFinding == null && topDataset == null) warnings += "Do not believe any discovery claim from this cycle; it mainly changed search strategy."
        if (topFinding != null && topFinding.evidence.speciesClass != "human") warnings += "Do not generalize animal/cell-only evidence to humans."
        if (topFinding != null && topFinding.sanityFlags.contains("METADATA_ONLY")) warnings += "Do not believe mechanism strength from metadata-only evidence."
        if (topHypothesis != null && topHypothesis.minimumDataPackStatus != "PASS") warnings += "Do not upgrade hypothesis before the minimum data pack passes."
        if (contradictionFindings.isEmpty()) warnings += "Do not assume there is no contradiction; explicit contradiction search is still required."
        if (pivot.pivotType != "NO_PIVOT") warnings += "Do not treat the pivot as evidence; it is only a better next search direction."
        return warnings.distinct().joinToString(" ")
    }
}
