package com.immunesignal.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Toast

class MainActivity : Activity() {
    private val engine = ImmuneSignalEngine()

    private lateinit var caseLabelInput: EditText
    private lateinit var ageInput: EditText
    private lateinit var tempInput: EditText
    private lateinit var crpInput: EditText
    private lateinit var esrInput: EditText
    private lateinit var igeInput: EditText
    private lateinit var eosInput: EditText
    private lateinit var il6Input: EditText
    private lateinit var tnfInput: EditText
    private lateinit var il10Input: EditText
    private lateinit var ferritinInput: EditText
    private lateinit var histamineInput: EditText
    private lateinit var stressTodayInput: EditText
    private lateinit var stress7dInput: EditText
    private lateinit var sleepQualityInput: EditText
    private lateinit var sittingHoursInput: EditText
    private lateinit var causeNotesInput: EditText
    private lateinit var recoverySlowInput: EditText
    private lateinit var fatigueAfterStressInput: EditText
    private lateinit var exerciseRecoveryInput: EditText
    private lateinit var allergyIntensityInput: EditText
    private lateinit var systolicInput: EditText
    private lateinit var diastolicInput: EditText
    private lateinit var restingPulseInput: EditText
    private lateinit var refluxHeartburnInput: EditText
    private lateinit var bloatingDyspepsiaInput: EditText
    private lateinit var dietDiversityInput: EditText
    private lateinit var proteinIntakeInput: EditText
    private lateinit var bodyWeightInput: EditText
    private lateinit var testosteroneInput: EditText
    private lateinit var gutHormoneNotesInput: EditText
    private lateinit var allergySymptomsBox: CheckBox
    private lateinit var jointSymptomsBox: CheckBox
    private lateinit var breathingBox: CheckBox
    private lateinit var confusionBox: CheckBox
    private lateinit var swellingBox: CheckBox
    private lateinit var majorEventBox: CheckBox
    private lateinit var panicBreathingBox: CheckBox
    private lateinit var pollenDustBox: CheckBox
    private lateinit var coldAirBox: CheckBox
    private lateinit var smokeFragranceBox: CheckBox
    private lateinit var moldPetsBox: CheckBox
    private lateinit var recentInfectionBox: CheckBox
    private lateinit var heavyLiftingBox: CheckBox
    private lateinit var suddenTwistBox: CheckBox
    private lateinit var backDiscPainBox: CheckBox
    private lateinit var radiatingPainBox: CheckBox
    private lateinit var numbnessWeaknessBox: CheckBox
    private lateinit var painStressBox: CheckBox
    private lateinit var frequentInfectionsBox: CheckBox
    private lateinit var slowWoundHealingBox: CheckBox
    private lateinit var foodSensitivityBox: CheckBox
    private lateinit var seasonalPatternBox: CheckBox
    private lateinit var allergyAfterStressBox: CheckBox
    private lateinit var allergyAfterPoorSleepBox: CheckBox
    private lateinit var dizzinessStandingBox: CheckBox
    private lateinit var faintnessAllergyBox: CheckBox
    private lateinit var flushingWarmthBox: CheckBox
    private lateinit var coldHandsFeetBox: CheckBox
    private lateinit var lowAcidPatternBox: CheckBox
    private lateinit var ppiAntacidBox: CheckBox
    private lateinit var gastritisHpyloriBox: CheckBox
    private lateinit var irregularMealsBox: CheckBox
    private lateinit var muscleMassLowBox: CheckBox
    private lateinit var strengthTrainingBox: CheckBox
    private lateinit var appetiteLowBox: CheckBox
    private lateinit var lowLibidoDriveBox: CheckBox
    private lateinit var lowMorningEnergyBox: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        findViewById<Button>(R.id.analyzeButton).setOnClickListener { analyze() }
        findViewById<Button>(R.id.historyButton).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<Button>(R.id.researchAutopilotButton).setOnClickListener {
            startActivity(Intent(this, ResearchAutopilotActivity::class.java))
        }
        findViewById<Button>(R.id.clearButton).setOnClickListener { clearForm() }
    }

    private fun bindViews() {
        caseLabelInput = findViewById(R.id.caseLabelInput)
        ageInput = findViewById(R.id.ageInput)
        tempInput = findViewById(R.id.tempInput)
        crpInput = findViewById(R.id.crpInput)
        esrInput = findViewById(R.id.esrInput)
        igeInput = findViewById(R.id.igeInput)
        eosInput = findViewById(R.id.eosInput)
        il6Input = findViewById(R.id.il6Input)
        tnfInput = findViewById(R.id.tnfInput)
        il10Input = findViewById(R.id.il10Input)
        ferritinInput = findViewById(R.id.ferritinInput)
        histamineInput = findViewById(R.id.histamineInput)
        stressTodayInput = findViewById(R.id.stressTodayInput)
        stress7dInput = findViewById(R.id.stress7dInput)
        sleepQualityInput = findViewById(R.id.sleepQualityInput)
        sittingHoursInput = findViewById(R.id.sittingHoursInput)
        causeNotesInput = findViewById(R.id.causeNotesInput)
        recoverySlowInput = findViewById(R.id.recoverySlowInput)
        fatigueAfterStressInput = findViewById(R.id.fatigueAfterStressInput)
        exerciseRecoveryInput = findViewById(R.id.exerciseRecoveryInput)
        allergyIntensityInput = findViewById(R.id.allergyIntensityInput)
        systolicInput = findViewById(R.id.systolicInput)
        diastolicInput = findViewById(R.id.diastolicInput)
        restingPulseInput = findViewById(R.id.restingPulseInput)
        refluxHeartburnInput = findViewById(R.id.refluxHeartburnInput)
        bloatingDyspepsiaInput = findViewById(R.id.bloatingDyspepsiaInput)
        dietDiversityInput = findViewById(R.id.dietDiversityInput)
        proteinIntakeInput = findViewById(R.id.proteinIntakeInput)
        bodyWeightInput = findViewById(R.id.bodyWeightInput)
        testosteroneInput = findViewById(R.id.testosteroneInput)
        gutHormoneNotesInput = findViewById(R.id.gutHormoneNotesInput)
        allergySymptomsBox = findViewById(R.id.allergySymptomsBox)
        jointSymptomsBox = findViewById(R.id.jointSymptomsBox)
        breathingBox = findViewById(R.id.breathingBox)
        confusionBox = findViewById(R.id.confusionBox)
        swellingBox = findViewById(R.id.swellingBox)
        majorEventBox = findViewById(R.id.majorEventBox)
        panicBreathingBox = findViewById(R.id.panicBreathingBox)
        pollenDustBox = findViewById(R.id.pollenDustBox)
        coldAirBox = findViewById(R.id.coldAirBox)
        smokeFragranceBox = findViewById(R.id.smokeFragranceBox)
        moldPetsBox = findViewById(R.id.moldPetsBox)
        recentInfectionBox = findViewById(R.id.recentInfectionBox)
        heavyLiftingBox = findViewById(R.id.heavyLiftingBox)
        suddenTwistBox = findViewById(R.id.suddenTwistBox)
        backDiscPainBox = findViewById(R.id.backDiscPainBox)
        radiatingPainBox = findViewById(R.id.radiatingPainBox)
        numbnessWeaknessBox = findViewById(R.id.numbnessWeaknessBox)
        painStressBox = findViewById(R.id.painStressBox)
        frequentInfectionsBox = findViewById(R.id.frequentInfectionsBox)
        slowWoundHealingBox = findViewById(R.id.slowWoundHealingBox)
        foodSensitivityBox = findViewById(R.id.foodSensitivityBox)
        seasonalPatternBox = findViewById(R.id.seasonalPatternBox)
        allergyAfterStressBox = findViewById(R.id.allergyAfterStressBox)
        allergyAfterPoorSleepBox = findViewById(R.id.allergyAfterPoorSleepBox)
        dizzinessStandingBox = findViewById(R.id.dizzinessStandingBox)
        faintnessAllergyBox = findViewById(R.id.faintnessAllergyBox)
        flushingWarmthBox = findViewById(R.id.flushingWarmthBox)
        coldHandsFeetBox = findViewById(R.id.coldHandsFeetBox)
        lowAcidPatternBox = findViewById(R.id.lowAcidPatternBox)
        ppiAntacidBox = findViewById(R.id.ppiAntacidBox)
        gastritisHpyloriBox = findViewById(R.id.gastritisHpyloriBox)
        irregularMealsBox = findViewById(R.id.irregularMealsBox)
        muscleMassLowBox = findViewById(R.id.muscleMassLowBox)
        strengthTrainingBox = findViewById(R.id.strengthTrainingBox)
        appetiteLowBox = findViewById(R.id.appetiteLowBox)
        lowLibidoDriveBox = findViewById(R.id.lowLibidoDriveBox)
        lowMorningEnergyBox = findViewById(R.id.lowMorningEnergyBox)
    }

    private fun analyze() {
        val input = buildCaseInput()
        val result = engine.analyze(input)
        val record = CaseRecord(input, result)
        val json = JsonCodec.caseToJson(record)

        LocalCaseStore(this).save(json)

        startActivity(Intent(this, ResultActivity::class.java).apply {
            putExtra(ResultActivity.EXTRA_CASE_JSON, json.toString())
        })
    }

    private fun buildCaseInput(): CaseInput {
        val now = System.currentTimeMillis()
        val label = caseLabelInput.text.toString().trim().ifBlank { "Case ${now.toString().takeLast(5)}" }
        return CaseInput(
            id = "case_$now",
            createdAtMillis = now,
            label = label,
            age = parseInt(ageInput, 0, 120),
            temperatureC = parseDouble(tempInput),
            biomarkers = BiomarkerInput(
                crpMgL = parseDouble(crpInput),
                esrMmH = parseDouble(esrInput),
                totalIgeIuMl = parseDouble(igeInput),
                eosinophilsCellsUl = parseDouble(eosInput),
                il6PgMl = parseDouble(il6Input),
                tnfAlphaPgMl = parseDouble(tnfInput),
                il10PgMl = parseDouble(il10Input),
                ferritinNgMl = parseDouble(ferritinInput),
                histamine = parseDouble(histamineInput)
            ),
            symptoms = SymptomInput(
                allergyLike = allergySymptomsBox.isChecked,
                jointInflammatoryLike = jointSymptomsBox.isChecked,
                breathingDanger = breathingBox.isChecked,
                confusionOrFainting = confusionBox.isChecked,
                rapidSwelling = swellingBox.isChecked
            ),
            causeContext = CauseContextInput(
                stressToday0To10 = parseInt(stressTodayInput, 0, 10),
                stressLast7Days0To10 = parseInt(stress7dInput, 0, 10),
                sleepQuality0To10 = parseInt(sleepQualityInput, 0, 10),
                majorEmotionalEvent = majorEventBox.isChecked,
                panicOrRapidBreathing = panicBreathingBox.isChecked,
                pollenDustExposure = pollenDustBox.isChecked,
                coldAirExposure = coldAirBox.isChecked,
                smokeFragranceExposure = smokeFragranceBox.isChecked,
                moldOrPetsExposure = moldPetsBox.isChecked,
                recentInfectionLike = recentInfectionBox.isChecked,
                longSittingHours = parseInt(sittingHoursInput, 0, 24),
                heavyLifting = heavyLiftingBox.isChecked,
                suddenTwist = suddenTwistBox.isChecked,
                backOrDiscPain = backDiscPainBox.isChecked,
                radiatingLegPain = radiatingPainBox.isChecked,
                numbnessOrWeakness = numbnessWeaknessBox.isChecked,
                painWorseWithStress = painStressBox.isChecked,
                notes = causeNotesInput.text.toString().trim().ifBlank { null }
            ),
            agingAutonomic = AgingAutonomicInput(
                infectionRecoverySlow0To10 = parseInt(recoverySlowInput, 0, 10),
                frequentInfections = frequentInfectionsBox.isChecked,
                fatigueAfterStress0To10 = parseInt(fatigueAfterStressInput, 0, 10),
                exerciseRecovery0To10 = parseInt(exerciseRecoveryInput, 0, 10),
                slowWoundHealing = slowWoundHealingBox.isChecked,
                allergyIntensity0To10 = parseInt(allergyIntensityInput, 0, 10),
                foodSensitivityEpisode = foodSensitivityBox.isChecked,
                seasonalPattern = seasonalPatternBox.isChecked,
                allergyAfterStress = allergyAfterStressBox.isChecked,
                allergyAfterPoorSleep = allergyAfterPoorSleepBox.isChecked,
                systolicBpMmHg = parseInt(systolicInput, 40, 260),
                diastolicBpMmHg = parseInt(diastolicInput, 30, 160),
                restingPulseBpm = parseInt(restingPulseInput, 30, 220),
                dizzinessOnStanding = dizzinessStandingBox.isChecked,
                faintnessDuringAllergy = faintnessAllergyBox.isChecked,
                flushingOrWarmth = flushingWarmthBox.isChecked,
                coldHandsFeet = coldHandsFeetBox.isChecked
            ),
            gutNutritionHormone = GutNutritionHormoneInput(
                refluxHeartburn0To10 = parseInt(refluxHeartburnInput, 0, 10),
                bloatingDyspepsia0To10 = parseInt(bloatingDyspepsiaInput, 0, 10),
                suspectedLowAcidPattern = lowAcidPatternBox.isChecked,
                ppiOrAntacidUse = ppiAntacidBox.isChecked,
                knownGastritisOrHpylori = gastritisHpyloriBox.isChecked,
                mealTimingIrregular = irregularMealsBox.isChecked,
                dietDiversity0To10 = parseInt(dietDiversityInput, 0, 10),
                proteinIntakeEstimateG = parseDouble(proteinIntakeInput),
                bodyWeightKg = parseDouble(bodyWeightInput),
                muscleMassLossOrLow = muscleMassLowBox.isChecked,
                strengthTraining = strengthTrainingBox.isChecked,
                appetiteLow = appetiteLowBox.isChecked,
                testosteroneNgDl = parseDouble(testosteroneInput),
                lowLibidoOrLowMorningDrive = lowLibidoDriveBox.isChecked,
                lowMorningEnergy = lowMorningEnergyBox.isChecked,
                notes = gutHormoneNotesInput.text.toString().trim().ifBlank { null }
            )
        )
    }

    private fun parseDouble(input: EditText): Double? {
        val raw = input.text.toString().trim().replace(',', '.')
        if (raw.isEmpty()) return null
        val value = raw.toDoubleOrNull()
        if (value == null || value < 0.0 || value.isNaN() || value.isInfinite()) {
            Toast.makeText(this, "Ignored invalid value: $raw", Toast.LENGTH_SHORT).show()
            return null
        }
        return value
    }

    private fun parseInt(input: EditText, min: Int, max: Int): Int? {
        val raw = input.text.toString().trim()
        if (raw.isEmpty()) return null
        val value = raw.toIntOrNull()
        return if (value != null && value in min..max) value else null
    }

    private fun clearForm() {
        listOf(
            caseLabelInput, ageInput, tempInput, crpInput, esrInput, igeInput, eosInput, il6Input,
            tnfInput, il10Input, ferritinInput, histamineInput, stressTodayInput, stress7dInput,
            sleepQualityInput, sittingHoursInput, causeNotesInput, recoverySlowInput, fatigueAfterStressInput,
            exerciseRecoveryInput, allergyIntensityInput, systolicInput, diastolicInput, restingPulseInput,
            refluxHeartburnInput, bloatingDyspepsiaInput, dietDiversityInput, proteinIntakeInput, bodyWeightInput,
            testosteroneInput, gutHormoneNotesInput
        ).forEach { it.text.clear() }
        listOf(
            allergySymptomsBox, jointSymptomsBox, breathingBox, confusionBox, swellingBox,
            majorEventBox, panicBreathingBox, pollenDustBox, coldAirBox, smokeFragranceBox,
            moldPetsBox, recentInfectionBox, heavyLiftingBox, suddenTwistBox, backDiscPainBox,
            radiatingPainBox, numbnessWeaknessBox, painStressBox, frequentInfectionsBox, slowWoundHealingBox,
            foodSensitivityBox, seasonalPatternBox, allergyAfterStressBox, allergyAfterPoorSleepBox,
            dizzinessStandingBox, faintnessAllergyBox, flushingWarmthBox, coldHandsFeetBox,
            lowAcidPatternBox, ppiAntacidBox, gastritisHpyloriBox, irregularMealsBox, muscleMassLowBox,
            strengthTrainingBox, appetiteLowBox, lowLibidoDriveBox, lowMorningEnergyBox
        ).forEach { it.isChecked = false }
    }
}
