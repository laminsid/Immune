package com.immunesignal.app

data class ResearchStates(val discoveryState: String, val biasRiskState: String)

object ResearchStateEngine {
    fun classify(card: HypothesisRankCard, gate: MinimumDataPackAssessment, findings: List<ResearchFinding>): ResearchStates {
        val discovery = when {
            card.status == "STRONG_SIGNAL" && gate.status == "PASS" && card.causalityScore >= 65 -> "Strong Candidate"
            card.overallScore >= 65 && gate.status != "BLOCKED" -> "Active"
            card.overallScore >= 40 -> "Early"
            else -> "Off"
        }
        val weakHuman = findings.isNotEmpty() && findings.none { it.evidence.speciesClass == "human" }
        val metadataCount = findings.count { it.sanityFlags.contains("METADATA_ONLY") || it.sanityFlags.contains("ABSTRACT_FETCH_FAILED") }
        val metadataHeavy = findings.isNotEmpty() && metadataCount * 2 >= findings.size
        val bias = when {
            gate.status == "BLOCKED" && card.status == "STRONG_SIGNAL" -> "Severe Bias"
            card.negativeControlStatus.contains("fail", ignoreCase = true) -> "Severe Bias"
            weakHuman || metadataHeavy || card.personalRepeatability == 0 -> "Alert"
            gate.status == "PARTIAL" -> "Watch"
            findings.isNotEmpty() && card.negativeControlStatus.contains("control", ignoreCase = true) -> "Watch"
            else -> "Normal"
        }
        return ResearchStates(discovery, bias)
    }

    fun summarize(objects: List<HypothesisObject>, mistakes: List<MistakeRiskCard>): ResearchStateSummary {
        if (objects.isEmpty()) return ResearchStateSummary.empty()
        val discovery = when {
            objects.any { it.discoveryState == "Strong Candidate" } -> "Strong Candidate"
            objects.any { it.discoveryState == "Active" } -> "Active"
            objects.any { it.discoveryState == "Early" } -> "Early"
            else -> "Off"
        }
        val bias = when {
            objects.any { it.biasRiskState == "Severe Bias" } -> "Severe Bias"
            objects.any { it.biasRiskState == "Alert" } -> "Alert"
            objects.any { it.biasRiskState == "Watch" } -> "Watch"
            else -> "Normal"
        }
        val top = objects.maxByOrNull { it.dataTrustScore + it.causalityScore } ?: objects.first()
        val risk = mistakes.firstOrNull()
        return ResearchStateSummary(
            discoveryState = discovery,
            biasRiskState = bias,
            nextEvidence = top.nextBestMeasurement,
            discoveryAction = "Track ${top.label.take(80)} with the minimum data pack before upgrading.",
            biasAlarm = if (risk != null) "$bias: ${risk.risk}; gate: ${risk.preventionGate}" else "$bias: no dominant mistake risk detected."
        )
    }
}
