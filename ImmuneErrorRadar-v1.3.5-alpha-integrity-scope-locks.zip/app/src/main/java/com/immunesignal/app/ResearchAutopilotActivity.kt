package com.immunesignal.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * v1.1: migrated from Activity to ComponentActivity.
 *
 * Previously a raw Thread ran the research cycle, which:
 * - leaked Activity context on rotation/destroy
 * - risked ANRs if save happened during destroy
 * - had no structured cancellation
 *
 * v1.1 uses lifecycleScope.launch so the cycle is automatically cancelled
 * when the Activity is destroyed, and runs on Dispatchers.IO. The Stop
 * button cancels the Job. The deprecated startActivityForResult is replaced
 * by registerForActivityResult(ActivityResultContracts.OpenDocument()).
 */
class ResearchAutopilotActivity : ComponentActivity() {
    private lateinit var outputText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var reportInput: EditText
    private lateinit var steeringVariablesInput: EditText
    private lateinit var steeringFocusInput: EditText
    private lateinit var steeringRequiredInput: EditText
    private lateinit var steeringExcludeInput: EditText
    private lateinit var activeSteeringText: TextView
    private lateinit var runButton: Button
    private lateinit var stopButton: Button
    private lateinit var copyBriefButton: Button
    private lateinit var exportPdfButton: Button
    private var latestReport: JSONObject? = null
    @Volatile private var stopRequested: Boolean = false
    @Volatile private var running: Boolean = false
    private var researchJob: Job? = null

    // v1.1: ActivityResultContracts replaces deprecated onActivityResult.
    // Registered before onStart per the contract requirement.
    private val openReportLauncher: ActivityResultLauncher<Array<String>> =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) importReportUri(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_research_autopilot)
        outputText = findViewById(R.id.autopilotOutputText)
        progress = findViewById(R.id.autopilotProgress)
        reportInput = findViewById(R.id.manualReportInput)
        steeringVariablesInput = findViewById(R.id.steeringVariablesInput)
        steeringFocusInput = findViewById(R.id.steeringFocusInput)
        steeringRequiredInput = findViewById(R.id.steeringRequiredInput)
        steeringExcludeInput = findViewById(R.id.steeringExcludeInput)
        activeSteeringText = findViewById(R.id.activeSteeringText)
        runButton = findViewById(R.id.runAutopilotButton)
        stopButton = findViewById(R.id.stopAutopilotButton)
        copyBriefButton = findViewById(R.id.copyBriefReportButton)
        exportPdfButton = findViewById(R.id.exportDiscoveryPdfButton)

        runButton.setOnClickListener { runCycle() }
        stopButton.setOnClickListener { stopResearch() }
        findViewById<Button>(R.id.saveSteeringButton).setOnClickListener { saveSteering() }
        findViewById<Button>(R.id.clearSteeringButton).setOnClickListener { clearSteering() }
        findViewById<Button>(R.id.importPastedReportButton).setOnClickListener { importPastedReport() }
        findViewById<Button>(R.id.importReportFileButton).setOnClickListener { openReportFile() }
        copyBriefButton.setOnClickListener { copyBriefReport() }
        exportPdfButton.setOnClickListener { exportPdf() }
        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
        updateRunningUi(false)
        refreshActiveSteering()
        renderLatestReports()
    }

    override fun onDestroy() {
        // v1.1: ensure background work stops if user destroys the screen.
        researchJob?.cancel()
        researchJob = null
        latestReport = null
        super.onDestroy()
    }

    private fun runCycle() {
        if (running) {
            Toast.makeText(this, "Research is already running.", Toast.LENGTH_SHORT).show()
            return
        }
        stopRequested = false
        running = true
        updateRunningUi(true)
        val steering = ResearchKnowledgeStore(this).readActiveSteering()
        outputText.text = "Autonomous researcher started…\n\nSearch limit: 10 minutes. Learning limit: 15 minutes.\n" +
            (if (steering != null) "Optional steering active: ${steering.variables.joinToString(", ")}\nFocus: ${steering.focusQuestion.ifBlank { "connect variables and look for hidden bridges" }}\n" else "No steering active. Autonomous mode will choose Explore + Deepen + Challenge lanes by itself.\n") +
            "The engine skips previously saved PubMed IDs, rotates strategy when sources repeat, and only upgrades hypotheses through the lock system."
        // v1.1: lifecycleScope auto-cancels on Activity destroy. Dispatchers.IO
        // is appropriate for blocking HTTP. UI updates use withContext(Main).
        researchJob = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val report = ResearchAutopilot(this@ResearchAutopilotActivity).runCycle(
                    shouldStop = { stopRequested },
                    limits = ResearchRunLimits(
                        maxSearchMillis = 10L * 60L * 1000L,
                        maxLearningMillis = 15L * 60L * 1000L,
                        maxQueries = 4,
                        maxResultsPerQuery = 5,
                        fetchAbstracts = false
                    )
                )
                val json = ResearchJsonCodec.reportToJson(report)
                ResearchKnowledgeStore(this@ResearchAutopilotActivity).saveReport(json)
                withContext(Dispatchers.Main) {
                    latestReport = json
                    running = false
                    updateRunningUi(false)
                    outputText.text = renderBriefReport(json) + "\n\n--- Report preview ---\n" + renderReportPreview(json) + "\n\nFull details are available via Export report."
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    running = false
                    updateRunningUi(false)
                    outputText.text = "Research cycle failed.\n\n${e.message}\n\nCheck internet connection, NCBI availability, or import a text report and run again."
                }
            }
        }
    }



    private fun saveSteering() {
        val variables = steeringVariablesInput.text.toString().trim()
        if (variables.length < 2) {
            Toast.makeText(this, "Enter at least one research variable.", Toast.LENGTH_SHORT).show()
            return
        }
        val profile = ResearchKnowledgeStore(this).saveActiveSteering(
            variablesText = variables,
            focusQuestion = steeringFocusInput.text.toString(),
            requiredTermsText = steeringRequiredInput.text.toString(),
            excludedTermsText = steeringExcludeInput.text.toString()
        )
        refreshActiveSteering()
        outputText.text = "Research steering saved.\n\nVariables: ${profile.variables.joinToString(", ")}\nAxes: ${profile.inferredAxes.joinToString(", ").ifBlank { "none yet" }}\n\nPress Search + learn. Steering will accelerate the autonomous researcher without disabling its own Explore/Deepen/Challenge plan."
    }

    private fun clearSteering() {
        ResearchKnowledgeStore(this).clearActiveSteering()
        steeringVariablesInput.setText("")
        steeringFocusInput.setText("")
        steeringRequiredInput.setText("")
        steeringExcludeInput.setText("")
        refreshActiveSteering()
        outputText.text = "Research steering cleared. Autonomous Researcher mode remains active and will choose its own search lanes."
    }

    private fun refreshActiveSteering() {
        val profile = ResearchKnowledgeStore(this).readActiveSteering()
        if (profile == null) {
            activeSteeringText.text = "Active steering: none. Autonomous Researcher mode is active; steering is optional if you want to accelerate a specific idea."
            return
        }
        activeSteeringText.text = "Active steering:\n" +
            "Variables: ${profile.variables.joinToString(", ")}\n" +
            "Focus: ${profile.focusQuestion.ifBlank { "connect variables and find non-obvious mechanisms" }}\n" +
            "Required: ${profile.requiredTerms.joinToString(", ").ifBlank { "none" }}\n" +
            "Excluded: ${profile.excludedTerms.joinToString(", ").ifBlank { "none" }}\n" +
            "Inferred axes: ${profile.inferredAxes.joinToString(", ").ifBlank { "none" }}"
    }

    private fun stopResearch() {
        if (!running) {
            Toast.makeText(this, "No active research cycle.", Toast.LENGTH_SHORT).show()
            return
        }
        stopRequested = true
        // v1.1: also cancel the coroutine for fast hard-stop on long-tail HTTP.
        researchJob?.cancel()
        outputText.text = outputText.text.toString() + "\n\nStop requested. Current network request will finish or timeout, then the report will be closed."
    }

    private fun updateRunningUi(isRunning: Boolean) {
        progress.visibility = if (isRunning) View.VISIBLE else View.GONE
        runButton.isEnabled = !isRunning
        stopButton.isEnabled = isRunning
        exportPdfButton.isEnabled = !isRunning
        copyBriefButton.isEnabled = !isRunning
    }

    private fun importPastedReport() {
        val text = reportInput.text.toString().trim()
        if (text.length < 20) {
            Toast.makeText(this, "Paste a longer report/note first.", Toast.LENGTH_SHORT).show()
            return
        }
        val signal = ResearchKnowledgeStore(this).saveImportedReport("Pasted report", text)
        reportInput.setText("")
        outputText.text = "Imported report saved.\n\nDetected axes: ${signal.matchedAxes.joinToString(", ").ifBlank { "none" }}\nKeywords: ${signal.extractedKeywords.joinToString(", ").ifBlank { "none" }}\n\nRun research cycle. The autonomous planner will use this as one optional clue, not as the only direction."
    }

    private fun openReportFile() {
        // v1.1: ActivityResultContracts.OpenDocument launcher.
        // The MIME type list is passed as the launcher's input.
        openReportLauncher.launch(arrayOf("text/plain", "text/csv", "application/json"))
    }

    private fun importReportUri(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (text.length < 20) {
                Toast.makeText(this, "File is empty or too short.", Toast.LENGTH_LONG).show()
                return
            }
            val signal = ResearchKnowledgeStore(this).saveImportedReport("Imported file", text)
            outputText.text = "Imported file saved.\n\nDetected axes: ${signal.matchedAxes.joinToString(", ").ifBlank { "none" }}\nKeywords: ${signal.extractedKeywords.joinToString(", ").ifBlank { "none" }}\nPreview: ${signal.preview}\n\nRun research cycle. The autonomous planner will use this file as one optional clue, not as the only direction."
        } catch (e: Exception) {
            Toast.makeText(this, "Could not import file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderLatestReports() {
        val latest = ResearchKnowledgeStore(this).readLatestReports(1).firstOrNull()
        if (latest != null) {
            latestReport = JSONObject(latest)
            outputText.text = renderBriefReport(latestReport!!) + "\n\n--- Report preview ---\n" + renderReportPreview(latestReport!!) + "\n\nFull details are available via Export report."
        } else {
            outputText.text = "Research Autopilot is ready.\n\nUse it as a private research engine. It can:\n• Search new PubMed/NCBI metadata\n• Add DNA/RNA/transcriptomic hypotheses\n• Import your own reports as text/file\n• Stop early when you press Stop\n• Output a brief report you can copy\n\nNo diagnosis, no treatment, no causality proof."
        }
    }

    private fun renderBriefReport(report: JSONObject): String {
        val v3 = report.optJSONObject("reportV3")
        if (v3 != null && v3.optString("cycleResult").isNotBlank()) {
            return listOf(
                "AUTONOMOUS DISCOVERY REPORT",
                "Cycle result: ${v3.optString("cycleResult")}",
                "Hypothesis: ${v3.optString("hypothesis", "No active hypothesis passed the evidence gates.")}",
                "Supporting evidence: ${v3.optString("supportingEvidence", v3.optString("newUsefulLead"))}",
                "Counter-evidence / contradiction: ${v3.optString("counterEvidenceOrContradiction", "No contradiction section available.")}",
                "What we do not believe yet: ${v3.optString("whatWeDoNotBelieveYet", v3.optString("doNotBelieveYet"))}",
                "Hypothesis changed: ${v3.optString("hypothesisChanged")}",
                "Why it matters: ${v3.optString("whyItMatters")}",
                "Next autonomous move: ${v3.optString("nextAutonomousMove")}",
                "Integrity lock: ${v3.optString("integrityStatus", "UNKNOWN")}"
            ).toMutableList().apply {
                val reasoning = report.optJSONObject("reasoningReport") ?: JSONObject()
                val meaning = reasoning.optString("interpretedMeaning", "")
                val nextReasoned = reasoning.optString("nextReasonedMove", "")
                if (meaning.isNotBlank()) {
                    add("")
                    add("Reasoning:")
                    add("• $meaning")
                }
                if (nextReasoned.isNotBlank()) add("• Next reasoned move: $nextReasoned")
            }.joinToString("\n")
        }
        if ((report.optJSONArray("hypothesisObjects")?.length() ?: 0) > 0) {
            return ResearchReportTemplateV2.renderBrief(report)
        }
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val findings = report.optJSONArray("findings") ?: JSONArray()
        val top = findings.optJSONObject(0)
        val lines = mutableListOf<String>()
        lines += "SHORT DISCOVERY REPORT"
        lines += "Generated: ${report.optString("createdAtText", "")}"
        lines += "Stop reason: ${report.optString("stopReason", "completed")}"
        lines += "New sources: ${delta.optInt("newSourcesSaved", findings.length())} | Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        lines += "DNA/RNA signals: ${delta.optInt("dnaRnaSignals", 0)} | Manual reports used: ${delta.optInt("manualReportSignalsUsed", 0)}"
        lines += "Steered queries: ${delta.optInt("steeredQueriesGenerated", 0)}"
        val plan = report.optJSONObject("autonomousPlan") ?: JSONObject()
        lines += "Autonomous mode: ${plan.optString("strategy", "explore_deepen_challenge")}"
        val cards = report.optJSONArray("hypothesisRankCards") ?: JSONArray()
        val topCard = cards.optJSONObject(0)
        if (topCard != null) {
            lines += "Top hypothesis: ${topCard.optString("status")} • ${topCard.optInt("overallScore")}/100"
        }
        lines += ""
        lines += "Top new lead:"
        if (top != null) {
            lines += "• ${top.optString("title")}"
            lines += "• ${top.optString("bridgeSignal")}"
            lines += "• Novelty: ${top.optInt("noveltyScore")}/100"
            val ev = top.optJSONObject("evidence") ?: JSONObject()
            val ca = top.optJSONObject("causality") ?: JSONObject()
            lines += "• Evidence: ${ev.optInt("evidenceQualityScore", 0)}/100 ${ev.optString("speciesClass", "unknown")}/${ev.optString("studyDesign", "unknown")}"
            lines += "• Causality: ${ca.optInt("causalityScore", 0)}/100"
        } else {
            val skipped = delta.optInt("repeatedSourcesSkipped", 0)
            if (skipped > 0) {
                val plan = report.optJSONObject("autonomousPlan") ?: JSONObject()
                lines += "• No useful new source saved. $skipped PubMed IDs were already known."
                lines += "• Next autonomous strategy: ${plan.optString("nextStrategyIfNoUsefulSource", "rotate to dataset/omics/contradiction search")}."
            } else {
                lines += "• No useful new source saved. The autonomous planner will change lanes next cycle; optional steering/import can accelerate it."
            }
        }
        lines += ""
        lines += "Main emerging link:"
        val links = report.optJSONArray("emergentLinks")
        lines += "• " + (links?.optString(0) ?: "None")
        lines += ""
        lines += "Next question:"
        val qs = report.optJSONArray("nextQuestions")
        lines += "• " + (qs?.optString(0) ?: "Which public dataset has trigger, immune-response axis, and outcome labels?")
        return lines.joinToString("\n")
    }

    private fun renderReportPreview(report: JSONObject): String {
        val lines = mutableListOf<String>()
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val findings = report.optJSONArray("findings") ?: JSONArray()
        val summary = report.optJSONObject("researchStateSummary") ?: JSONObject()
        val v3 = report.optJSONObject("reportV3") ?: JSONObject()
        val pivot = report.optJSONObject("resilienceDecision") ?: JSONObject()
        val datasets = report.optJSONArray("datasetCandidatesV133") ?: JSONArray()
        lines += "Result"
        lines += "• Cycle: ${v3.optString("cycleResult", if (findings.length() > 0) "Useful delta" else "No useful delta")}"
        lines += "• Integrity lock: ${v3.optString("integrityStatus", "UNKNOWN")}"
        lines += "• Hypothesis: ${v3.optString("hypothesis", "No active hypothesis.")}"
        lines += "• Counter-evidence: ${v3.optString("counterEvidenceOrContradiction", "Not evaluated.")}"
        lines += "• New useful sources: ${delta.optInt("newSourcesSaved", findings.length())}"
        lines += "• Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        lines += "• Dataset candidates: ${datasets.length()}"
        lines += "• Discovery state: ${summary.optString("discoveryState", "Off")}"
        lines += "• Bias risk: ${summary.optString("biasRiskState", "Normal")}"
        val pivotType = pivot.optString("pivotType", "NO_PIVOT")
        if (pivotType != "NO_PIVOT") lines += "• Pivot: $pivotType → ${pivot.optString("nextIntent", "change_strategy")}"
        val reasoning = report.optJSONObject("reasoningReport") ?: JSONObject()
        lines += ""
        lines += "Reasoning"
        lines += "• " + reasoning.optString("observation", "No reasoning observation yet.")
        lines += "• " + reasoning.optString("interpretedMeaning", "No interpretation yet.")
        lines += ""
        lines += "Action"
        lines += "• " + reasoning.optString("nextReasonedMove", v3.optString("nextAutonomousMove", "Run the next autonomous cycle."))
        return lines.joinToString("\n")
    }

    private fun renderReport(report: JSONObject): String {
        val lines = mutableListOf<String>()
        lines += "Research Autopilot Discovery Report"
        lines += "Generated: " + report.optString("createdAtText", "")
        lines += "Completed: " + report.optString("completedAtText", "")
        lines += "Stop reason: " + report.optString("stopReason", "completed")
        lines += "Search ms: " + report.optLong("searchDurationMillis") + " | Learning ms: " + report.optLong("learningDurationMillis")
        val steering = report.optJSONObject("activeSteeringProfile")
        lines += ""
        lines += "Research steering"
        if (steering == null) {
            lines += "• None used."
        } else {
            lines += "• Variables: " + jsonArrayToList(steering.optJSONArray("variables")).joinToString(", ").ifBlank { "none" }
            lines += "• Focus: " + steering.optString("focusQuestion", "")
            lines += "• Required: " + jsonArrayToList(steering.optJSONArray("requiredTerms")).joinToString(", ").ifBlank { "none" }
            lines += "• Excluded: " + jsonArrayToList(steering.optJSONArray("excludedTerms")).joinToString(", ").ifBlank { "none" }
            lines += "• Inferred axes: " + jsonArrayToList(steering.optJSONArray("inferredAxes")).joinToString(", ").ifBlank { "none" }
        }
        lines += ""
        lines += "Autonomous research plan"
        val plan = report.optJSONObject("autonomousPlan") ?: JSONObject()
        lines += "• Mode: ${plan.optString("mode", "autonomous_researcher")}"
        lines += "• Strategy: ${plan.optString("strategy", "explore_deepen_challenge")}"
        lines += "• Next if no useful source: ${plan.optString("nextStrategyIfNoUsefulSource", "rotate strategy")}" 
        val lanes = plan.optJSONArray("lanes") ?: JSONArray()
        if (lanes.length() == 0) {
            lines += "• No autonomous lanes recorded."
        } else {
            for (i in 0 until lanes.length()) {
                val lane = lanes.optJSONObject(i) ?: continue
                lines += "• ${lane.optString("laneType")}: ${lane.optString("label")}"
                lines += "  Reason: ${lane.optString("reason")}"
            }
        }
        lines += ""
        lines += "Knowledge delta"
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        lines += "• New sources saved: ${delta.optInt("newSourcesSaved", 0)}"
        lines += "• Repeated sources skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        lines += "• DNA/RNA signals: ${delta.optInt("dnaRnaSignals", 0)}"
        lines += "• Steered queries generated: ${delta.optInt("steeredQueriesGenerated", 0)}"
        lines += "• Manual report signals used: ${delta.optInt("manualReportSignalsUsed", 0)}"
        lines += "• New axis pairs:"
        appendArray(lines, delta.optJSONArray("newAxisPairs"))
        lines += "• Learning notes:"
        appendArray(lines, delta.optJSONArray("learningNotes"))
        lines += ""
        lines += "Research lock summary"
        val summary = report.optJSONObject("researchStateSummary") ?: JSONObject()
        lines += "• Discovery State: ${summary.optString("discoveryState", "Off")}"
        lines += "• Bias Risk State: ${summary.optString("biasRiskState", "Normal")}"
        lines += "• Next Evidence: ${summary.optString("nextEvidence", "none")}"
        lines += "• Discovery Action: ${summary.optString("discoveryAction", "none")}"
        lines += "• Bias Alarm: ${summary.optString("biasAlarm", "Normal")}" 
        lines += ""
        lines += "Hypothesis objects"
        val objects = report.optJSONArray("hypothesisObjects") ?: JSONArray()
        if (objects.length() == 0) {
            lines += "• No locked hypothesis objects yet."
        } else {
            for (i in 0 until objects.length()) {
                val h = objects.optJSONObject(i) ?: continue
                lines += "${i + 1}. ${h.optString("status")} / ${h.optString("discoveryState")} — ${h.optString("label")}" 
                lines += "   Trust ${h.optInt("dataTrustScore")}/100 | Evidence ${ScoreFormat.oneDecimal(h.optDouble("evidenceScore10"))}/10 | Causality ${h.optInt("causalityScore")}/100 | Bias ${h.optString("biasRiskState")}" 
                lines += "   Gate ${h.optString("minimumDataPackStatus")} | Flip ${h.optString("signalFlip")}" 
                lines += "   Next measurement: ${h.optString("nextBestMeasurement")}" 
                lines += "   Missing data: ${jsonArrayToList(h.optJSONArray("missingData")).joinToString(", ").ifBlank { "none" }}"
            }
        }
        lines += ""
        lines += "Learning delta cards"
        appendObjectArray(lines, report.optJSONArray("learningDeltaCards"), listOf("deltaType", "hypothesisId", "decisionImpact", "nextAction"))
        lines += ""
        lines += "Top mistake risks"
        appendObjectArray(lines, report.optJSONArray("mistakeRiskCards"), listOf("risk", "preventionGate"))
        lines += ""
        lines += "Hypothesis ranking"
        val cards = report.optJSONArray("hypothesisRankCards") ?: JSONArray()
        if (cards.length() == 0) {
            lines += "• No ranked hypotheses yet."
        } else {
            for (i in 0 until cards.length()) {
                val c = cards.optJSONObject(i) ?: continue
                lines += "${i + 1}. ${c.optString("status")} — ${c.optString("label")}"
                lines += "   Overall ${c.optInt("overallScore")}/100 | Evidence ${c.optInt("evidenceQualityScore")}/100 | Causality ${c.optInt("causalityScore")}/100 | Repeatability ${c.optInt("personalRepeatability")}"
                lines += "   Negative control: ${c.optString("negativeControlStatus")}"
                lines += "   Next measurement: ${c.optString("nextBestMeasurement")}"
                appendArray(lines, c.optJSONArray("whyRanked"))
            }
        }
        lines += ""
        lines += "Emergent links"
        appendArray(lines, report.optJSONArray("emergentLinks"))
        lines += ""
        lines += "Imported report signals"
        val imported = report.optJSONArray("importedReportSignals") ?: JSONArray()
        if (imported.length() == 0) {
            lines += "• None used."
        } else {
            for (i in 0 until imported.length()) {
                val r = imported.optJSONObject(i) ?: continue
                lines += "• ${r.optString("title")} → ${jsonArrayToList(r.optJSONArray("matchedAxes")).joinToString(", ")}".take(500)
            }
        }
        lines += ""
        lines += "Top findings"
        val findings = report.optJSONArray("findings") ?: JSONArray()
        if (findings.length() == 0) {
            lines += "• No new findings saved in this cycle."
        } else {
            for (i in 0 until findings.length()) {
                val f = findings.optJSONObject(i) ?: continue
                lines += "${i + 1}. " + f.optString("title")
                lines += "   " + f.optString("source") + " " + f.optString("sourceId") + " • " + f.optString("published") + " • novelty " + f.optInt("noveltyScore") + "/100"
                lines += "   Axes: " + jsonArrayToList(f.optJSONArray("matchedAxes")).joinToString(", ")
                val ev = f.optJSONObject("evidence") ?: JSONObject()
                val ca = f.optJSONObject("causality") ?: JSONObject()
                val neg = f.optJSONObject("negativeControl") ?: JSONObject()
                val pp = f.optJSONObject("personalPattern") ?: JSONObject()
                lines += "   Evidence: ${ev.optInt("evidenceQualityScore", 0)}/100 | ${ev.optString("speciesClass", "unknown")} | ${ev.optString("studyDesign", "unknown")}"
                lines += "   Causality: ${ca.optInt("causalityScore", 0)}/100 | Negative control: ${neg.optString("status", "unknown")}"
                lines += "   Personal pattern: ${pp.optInt("repeatedObservationCount", 0)} repeats | ${pp.optString("temporalSupport", "unknown")}"
                lines += "   " + f.optString("bridgeSignal")
                lines += "   " + f.optString("whyItMatters")
            }
        }
        lines += ""
        lines += "Next questions"
        appendArray(lines, report.optJSONArray("nextQuestions"))
        lines += ""
        lines += "Limitations"
        appendArray(lines, report.optJSONArray("limitations"))
        return lines.joinToString("\n")
    }

    private fun appendArray(lines: MutableList<String>, arr: JSONArray?) {
        if (arr == null || arr.length() == 0) {
            lines += "• None."
            return
        }
        for (i in 0 until arr.length()) lines += "• ${arr.optString(i)}"
    }

    private fun appendObjectArray(lines: MutableList<String>, arr: JSONArray?, keys: List<String>) {
        if (arr == null || arr.length() == 0) {
            lines += "• None."
            return
        }
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val rendered = keys.mapNotNull { key ->
                val value = obj.optString(key)
                if (value.isBlank()) null else "$key: $value"
            }.joinToString(" | ")
            lines += "• $rendered"
        }
    }

    private fun jsonArrayToList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    }

    private fun copyBriefReport() {
        val report = latestReport
        if (report == null) {
            Toast.makeText(this, "No report to copy yet.", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Immune Error Radar brief report", renderBriefReport(report)))
        Toast.makeText(this, "Brief report copied.", Toast.LENGTH_SHORT).show()
    }

    private fun exportPdf() {
        val report = latestReport
        if (report == null) {
            Toast.makeText(this, "Run a research cycle first.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val file = DiscoveryReportExporter.export(this, report)
            shareFile(file, "application/pdf", "Share discovery PDF")
        } catch (e: Exception) {
            runCatching {
                val fallback = DiscoveryReportExporter.exportText(this, report, renderBriefReport(report) + "\n\n" + renderReport(report))
                shareFile(fallback, "text/plain", "Share discovery text report")
                Toast.makeText(this, "PDF failed; exported TXT instead.", Toast.LENGTH_LONG).show()
            }.onFailure { err ->
                Toast.makeText(this, "Report export failed: ${err.message ?: e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun shareFile(file: File, mimeType: String, chooserTitle: String) {
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, chooserTitle))
    }
}
