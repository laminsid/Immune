package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.13 — Target validation card.
 *
 * Separates target, biomarker/readout, dataset anchor, context-of-use, blockers, and the
 * next discriminator test. This prevents a research lead from being mistaken for proof.
 */
object GTIMTargetValidationCardV21213 {
    const val VERSION: String = "2.12.13-target-validation-card"
    const val CLAIM_LIMIT: String = "target_validation_card_research_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val domain = domain(report)
        val targets = targetCandidates(domain)
        val biomarkers = biomarkerCandidates(domain)
        val handles = handles(report)
        val utility = report.optJSONObject("publishedResearchUtilityScoreV21213") ?: JSONObject()
        val consistency = report.optJSONObject("reportConsistencyGateV2121") ?: JSONObject()
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (handles.length() > 0) "EXTERNAL_REVIEW_TARGET_SELECTED_NOT_EVIDENCE_YET" else "TARGET_ROUTE_SELECTED_DATASET_NEEDED")
            .put("domainKey", domain)
            .put("targetCandidates", targets)
            .put("biomarkerOrReadoutCandidates", biomarkers)
            .put("datasetAnchors", handles)
            .put("contextOfUse", "research_hypothesis_generation_and_evidence_readiness_only")
            .put("evidenceState", evidenceState(consistency, handles, utility))
            .put("blockers", blockers(consistency, handles))
            .put("nextDiscriminatorTest", discriminator(domain, handles))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val targets = jsonStrings(obj.optJSONArray("targetCandidates")).take(4).joinToString(", ").ifBlank { "not selected" }
        val biomarkers = jsonStrings(obj.optJSONArray("biomarkerOrReadoutCandidates")).take(4).joinToString(", ").ifBlank { "not selected" }
        val anchors = jsonStrings(obj.optJSONArray("datasetAnchors")).take(4).joinToString(", ").ifBlank { "none yet" }
        return listOf(
            "Target validation card",
            "State: ${obj.optString("state", "UNKNOWN")}; targets=$targets; readouts=$biomarkers; dataset anchors=$anchors.",
            "Next discriminator: ${obj.optString("nextDiscriminatorTest", "select a topic-compatible dataset and comparator labels").takeClean(260)}",
            "Boundary: target/readout selection is not mechanism proof or treatment evidence."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "EXTERNAL_REVIEW_TARGET_SELECTED_NOT_EVIDENCE_YET",
        "targetCandidates",
        "biomarkerOrReadoutCandidates",
        "contextOfUse",
        CLAIM_LIMIT
    ))

    private fun evidenceState(consistency: JSONObject, handles: JSONArray, utility: JSONObject): String = when {
        consistency.optBoolean("topicCompatibleTargetSelected", false) && consistency.optInt("verifiedMatrixFiles", 0) > 0 -> "capsule_or_matrix_review_candidate_not_claim"
        handles.length() > 0 && utility.optInt("score", 0) >= 6 -> "metadata_supported_lead_not_evidence_yet"
        handles.length() > 0 -> "candidate_handle_only_not_evidence_yet"
        else -> "route_only_dataset_anchor_needed"
    }

    private fun blockers(consistency: JSONObject, handles: JSONArray): JSONArray {
        val out = JSONArray()
        if (handles.length() == 0) out.put("dataset_or_publication_anchor_missing")
        if (!consistency.optBoolean("topicCompatibleTargetSelected", false)) out.put("topic_fit_not_closed")
        if (consistency.optInt("verifiedMatrixFiles", 0) <= 0) out.put("matrix_or_processed_capsule_not_verified")
        out.put("independent_contradiction_check_required")
        return out
    }

    private fun targetCandidates(domain: String): JSONArray = JSONArray(when (domain) {
        "depression_kynurenine_neuroimmune" -> listOf("IDO1", "KMO", "tryptophan-kynurenine enzyme axis", "microglia/neuroimmune signaling", "glutamate/NMDA context")
        "viral_interferon_cytokine" -> listOf("interferon timing axis", "IL-6/TNF cytokine module", "endothelial/tissue injury module", "viral host-response module")
        "allergy_type2_barrier" -> listOf("IL-4/IL-13 type-2 axis", "IgE/mast/eosinophil module", "epithelial barrier module", "tolerance threshold module")
        else -> listOf("domain-specific mechanism target", "immune readout module", "phenotype-specific comparator axis")
    })

    private fun biomarkerCandidates(domain: String): JSONArray = JSONArray(when (domain) {
        "depression_kynurenine_neuroimmune" -> listOf("kynurenine/tryptophan ratio", "IDO1/KMO expression", "IL-6/TNF tone", "glutamate/NMDA-associated readout")
        "viral_interferon_cytokine" -> listOf("IFN module timing", "IL-6/TNF", "CRP/inflammatory tone", "recovery/severity comparator labels")
        "allergy_type2_barrier" -> listOf("IgE", "eosinophil/mast-cell markers", "IL-4/IL-13", "epithelial/barrier markers")
        else -> listOf("phenotype-linked biomarker", "immune module readout", "sample-level comparator readout")
    })

    private fun discriminator(domain: String, handles: JSONArray): String {
        val handle = handles.optString(0).ifBlank { "a topic-compatible dataset" }
        return when (domain) {
            "depression_kynurenine_neuroimmune" -> "For $handle, verify depression/control or high-inflammation comparator labels, then test IDO1/KMO/kynurenine readouts before any microbiome/barrier branch."
            "viral_interferon_cytokine" -> "For $handle, verify severity/recovery comparator labels and sample timing, then test interferon/IL-6/TNF modules against negative/contradiction evidence."
            "allergy_type2_barrier" -> "For $handle, verify allergy/type-2 comparator labels, tissue relevance, and epithelial/IgE/eosinophil readouts."
            else -> "For $handle, verify comparator labels, tissue/species, sample provenance, and one domain-specific readout before evidence upgrade."
        }
    }

    private fun domain(report: JSONObject): String = report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainKey")
        ?: report.optJSONObject("terminalDiscoveryContinuationV21212")?.optString("domainKey")
        ?: GTIMStudyFocusNormalizerV21282.build(report.toString()).domain

    private fun handles(report: JSONObject): JSONArray {
        val out = JSONArray()
        Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|SRR\\d+|PRJNA\\d+|PRJEB\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+|PMID:?\\d+|10\\.\\d{4,9}/[^\\s\\\"']+)\\b", RegexOption.IGNORE_CASE)
            .findAll(report.toString()).map { it.value.uppercase() }.distinct().take(12).forEach { out.put(it) }
        return out
    }

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx -> array.optString(idx).takeIf { it.isNotBlank() } }

    private fun String.takeClean(max: Int): String {
        val clean = replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= max) clean else clean.take(max).trimEnd()
    }
}
