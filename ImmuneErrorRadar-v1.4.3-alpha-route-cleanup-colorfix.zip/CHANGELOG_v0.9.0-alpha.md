# v0.9.0-alpha — Evidence Quality & Causal Learning Engine

## Added

- Evidence assessment models inside `ResearchModels.kt`.
- Source/species/study-design classification.
- Biological plausibility graph.
- Causality scoring.
- Negative-control assessment.
- Personal pattern repeatability ledger.
- Contradiction prompts.
- Hypothesis ranking cards.
- Evidence/causality/negative-control fields in short report, detailed report, and PDF.
- Internal project sheet for easier continuation by a developer.
- Python research scripts for evidence quality, causality, negative controls, personal time-series, and hypothesis ranking.

## Changed

- Research findings are now ranked by novelty + evidence quality + causality + steering overlap.
- Reports now separate human/animal/cell/unknown evidence where metadata allows.
- The app no longer treats a new paper as a strong lead unless it survives basic evidence and causal checks.

## Boundary

This remains a private research notebook. It does not prove causality, diagnose, or recommend treatment.
