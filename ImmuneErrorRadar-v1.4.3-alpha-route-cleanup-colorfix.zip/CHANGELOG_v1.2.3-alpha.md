# Immune Error Radar v1.2.3-alpha — Test Name Hotfix

## Fixed
- Renamed a Kotlin/JUnit test function in `CausalityScorerTest.kt` that contained `0..100` inside the backtick test name.
- Kotlin/JUnit rejected the generated method name with `Name contains illegal characters: ..`.
- No runtime logic changed.

## Build impact
- Fixes `:app:compileDebugUnitTestKotlin` failure.
