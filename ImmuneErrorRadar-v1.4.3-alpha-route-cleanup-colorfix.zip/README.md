# Immune Error Radar v1.3.4-alpha — Autonomous Researcher with Reasoning Layer

Immune Error Radar is a private Android research engine for studying immune over-response, immune trigger logic, antiviral response, recovery, regulatory failure, and cross-condition immune mechanisms.

It is **not** a personal symptom diary as its main purpose. The Android app is a control panel for global immune research: search public literature/dataset metadata, map immune axes, rank hypotheses, and produce discovery reports.

## Core objective

Study how the immune system decides:

```text
Trigger → Immune response axis → Tissue effect → Outcome
```

Examples:

- Allergen → Type-2 / IgE / mast-cell axis → airway or skin irritation
- Virus → interferon / T-cell / antibody response → recovery or deterioration
- Self-antigen → TNF / IL-6 inflammatory axis → chronic autoimmune-like burden
- Regulatory failure → weak IL-10/Treg brake → runaway amplification

The long-term research aim is to understand how immune responses can become more precise against new viral variants without becoming destructive.

## v1.3.3 additions


- AutonomousResearchPlanner / AutonomousResearcher mode
- Explore + Deepen + Challenge research lanes by default
- Query evolution after no-useful-source cycles
- Research steering is optional acceleration, not a requirement
- Reports now show the autonomous plan and next strategy
- GlobalImmuneIntelligenceEngine
- DatasetDiscoveryEngine
- DatasetQualityScorer
- ImmuneAxisMapper
- TriggerResponseGraphBuilder
- GlobalHypothesisLedgerBuilder
- PathogenResponseComparator
- Global report section in JSON/PDF/brief output
- Extended AxisMatcher for antiviral/adaptive/tissue-damage/recovery axes
- Python research helpers for global dataset curation and trigger-response graphing

## What v1.3 does not do

- No PyTorch / PyTorch Geometric inside APK
- No Random Forest or SimCLR inside Android
- No clinical prediction
- No diagnosis
- No treatment or drug recommendation
- No claim of protection against future viral variants

## Android privacy model

- Private imported reports remain on device.
- Autonomous Researcher uses the internet only for public literature metadata search and keeps low-data metadata-first defaults.
- Research steering terms are sanitized before outbound search.
- No account, telemetry, tracking, or server sync.

## Safety boundary

This project is a hypothesis and dataset-discovery engine only. Every lead remains research-grade until source quality, species, dataset access, trigger-response-outcome labels, contradiction checks, and falsification paths are reviewed.

## Build

Open in Android Studio or use GitHub Actions. This alpha ZIP does not bundle a Gradle Wrapper. See `BUILD.md`.

```bash
gradle :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Static checks

```bash
bash scripts/run_static_checks.sh
RUN_SAMPLE_PIPELINE=1 bash scripts/run_static_checks.sh
```

## Research pipeline examples

```bash
python3 research/global_dataset_registry.py research/examples/global_dataset_candidates.csv
python3 research/immune_axis_mapper.py "interferon IL10 CD8 antibody tissue damage recovery"
python3 research/trigger_response_graph.py "virus interferon IL10 tissue damage recovery"
python3 research/pathogen_response_comparator.py "virus interferon IL10 tissue damage recovery"
```

## Project rule

Do not add heavy ML until public datasets are curated. Current priority:

```text
Dataset discovery → axis mapping → trigger-response-outcome graph → global hypothesis ledger → falsification
```

See:

- `docs/GLOBAL_IMMUNE_DATASET_INTELLIGENCE_v1.3.md`
- `docs/PROJECT_INTERNAL_SHEET_v1.3.md`
- `docs/BACKLOG_v2_ML_IDEAS.md`

## v1.3.4 additions — Research Reasoning Layer

v1.3.4 does not add ML, a new biological axis, or a personal tracker. It adds a symbolic research-reasoning layer above the existing Autonomous Researcher:

- `ResearchQuestionGenerator`: converts a result or failure into sharper biological questions.
- `CompetingHypothesisBuilder`: keeps multiple explanations alive instead of letting one hypothesis dominate.
- `DiscriminatorEngine`: identifies what evidence would distinguish competing explanations.
- `SearchReframingEngine`: changes the level of search, for example concept → marker/gene → cell type → dataset → outcome labels.
- `SelfCriticEngine`: blocks overbelief by asking whether the engine is confirming bias, overusing metadata, or generalizing animal/cell evidence to humans.

Operating law: learning remembers what happened; reasoning decides what the failure or result means and what question should be asked next.

## v1.3.5 additions — Smart Report Integrity + Scope Discipline

v1.3.5 applies the v1.3.3 hard locks directly to the v1.3.4 reasoning baseline:

- Every intelligent report must show: hypothesis, supporting evidence, counter-evidence / contradiction, and what the engine does not believe yet.
- `SmartReportIntegrityLock` marks reports missing those fields as rejected narrative polish.
- `ScopeDisciplineLock` prevents drift into diagnosis, treatment, Random Forest/ML, patient prediction, new disease modules, or new biology axes.
- No-result repeated-source recovery now rotates evidence lane and vocabulary only: `REPEAT_TO_EVIDENCE_LANE_ROTATION` / `evidence_lane_rotation`.

Operating law: a report is not accepted because it sounds intelligent; it is accepted only if it exposes belief, support, contradiction, uncertainty, and the next autonomous move.

## v1.3.7-alpha — Evidence Acquisition + Learning OS

This patch converts repeated research failure into an explicit learning loop:

`incident → root cause → preventive gate → regression vector → forced next evidence path`

The researcher now extracts dataset accession candidates, builds evidence objects, scores discovery readiness, blocks hypothesis upgrades from query pivots alone, and shows Learning OS details in the report/PDF.

Strict boundaries remain: no diagnosis, no treatment recommendation, no personal health prediction, no new biology axes, no ML/Random Forest before dataset readiness.

## v1.3.8-alpha — Execution Wiring + Active Learning Loop

v1.3.8 fixes the practical failure observed in device reports: the engine could correctly *describe* stagnation but still continue through the same low-data PubMed loop.

This patch adds execution enforcement:

- Active engine version is written into every report: `v1.3.8-alpha-execution-wiring`.
- Runtime status shows active modules, research state, effective query budget, retmax, executed query ids, and forced queries.
- Execution lock fails if a forced pivot exists but no forced query was executed.
- Hard stagnation condition now triggers same-cycle dataset hunt:
  - `newFindings == 0`
  - `repeatedSkipped >= 10`
  - `datasetCandidates == 0`
- Same-cycle failover executes DATASET_HUNT immediately instead of only writing “strategy pivoted”.
- Forced dataset/accession queries are visible in JSON, UI preview, and PDF export.
- Default UI run budget is raised from `4 × 5` to `6 × 12`, while forced/stagnation mode can escalate to `6 × 20–25`.
- The report now exposes `Execution lock: PASS/FAIL` separately from the smart-report integrity lock.

Operating law: if the engine says a lane failed, the next executable action must change; otherwise the execution lock fails.

## v1.3.9-alpha — Research-first UI Cleanup

v1.3.9 removes the old daily scan form from the first page and makes the product match its real purpose: a private autonomous immune research engine.

Primary visible loop:

1. **Search** — public research, PubMed/NCBI metadata, dataset/accession hints.
2. **Evidence** — dataset candidates, evidence objects, contradiction/control checks.
3. **Learn** — root causes, preventive gates, cooldowns, and next action.

The on-screen report is now concise. Full technical details remain in Export report.

## v1.4.0-alpha — Dataset-First Autonomous Forager

v1.4.0 addresses the repeated device behavior where the app could diagnose failure, create root causes, and still fail to acquire evidence objects. This release changes the active research loop from PubMed-first metadata rotation to a dataset-first acquisition loop when the system is stuck.

What changed:

- Active engine version upgraded in v1.4.2: `v1.4.2-alpha-dataset-parser-intelligence`.
- Broad missions are decomposed into testable evidence shards before search.
- When the state is `DATASET_HUNT`, direct dataset families are attempted before broad PubMed lanes:
  - GEO/GDS through NCBI `gds`
  - SRA/PRJNA through NCBI `sra`
  - PubMed contradiction/control searches only as secondary passes
- Every dataset-first run records a multi-pass acquisition report:
  - PASS1 dataset accession hunt
  - PASS2 metadata usability inspection
  - PASS3 contradiction/control check
- Persistent failure memory is stored across cycles so repeated failure produces cooldown and a forced next source.
- Reports now expose `datasetForagingReport` and `persistentFailureMemory` alongside `runtimeStatus`, `executionLockReport`, `learningOsReport`, and `evidenceObjects`.

Non-goals remain unchanged: no diagnosis, no treatment, no medical advice, no ML expansion, no new biological axes, and no discovery claim without evidence objects.


## v1.4.1-alpha — Path Verification & Route Hardening

v1.4.1 verifies the v1.4.0 dataset-first execution paths and closes route-level stalls:

- `q_v140_*` dataset-first queries now count as valid forced evidence-path execution in the execution lock.
- `GEO_GDS_COOLDOWN_ESCAPE` prevents DATASET_HUNT from becoming active with zero source routes when normal dataset families are cooling down.
- Static checks now verify version, dataset route fallback, and q_v140 execution-lock acceptance.

Boundary unchanged: no medical advice, no diagnosis, no treatment, no health prediction, no new biology axis, and no ML model.


## v1.4.2-alpha — Dataset Parser & Outcome Label Intelligence

v1.4.2 moves the project from Dataset-First Forager to Dataset Interpreter:

- Parses dataset candidates for condition labels, outcome labels, control labels, time-course labels, assay type, tissue/source, and sample-size hints.
- Adds Contrastive Evidence Gate for responder/non-responder, mild/severe, recovery/persistence, exposed/control, and early/late slots.
- Adds conservative Cumulative Evidence Score without clinical or Bayesian overclaiming.
- Adds Evidence Hypergraph Lite as a simple evidence map, not a neural network.
- Keeps strict scope discipline: no medical advice, no treatment, no ML training, no future-variant prediction, and no cross-species human-hypothesis upgrade.


## v1.4.3-alpha — Route Cleanup & Path Audit

v1.4.3 cleans the runtime paths after the dataset-parser release. The first screen is research-only, the legacy manual/daily result route is no longer registered in the manifest, and report summaries now produce actionable next-evidence handoffs instead of generic “run another cycle” text.

Active engine: `v1.4.3-alpha-route-cleanup`.

Runtime path: `MainActivity → ResearchAutopilotActivity → ResearchAutopilot.runCycle → Dataset-first forager/parser/learning OS → report/export/archive`.

Non-goals remain unchanged: no diagnosis, no treatment, no future-variant prediction, no ML training, no new biological axes, and no hypothesis upgrade without interpretable evidence objects.
