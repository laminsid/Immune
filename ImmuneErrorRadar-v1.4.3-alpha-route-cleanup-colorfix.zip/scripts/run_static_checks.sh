#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
python3 scripts/validate_json.py
python3 scripts/audit_kotlin_delimiters.py
python3 - <<'PY'
import pathlib, xml.etree.ElementTree as ET, re, sys
for p in pathlib.Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('XML parse: PASS')
manifest=pathlib.Path('app/src/main/AndroidManifest.xml').read_text()
for forbidden in ['QUERY_ALL_PACKAGES','WRITE_EXTERNAL_STORAGE','MANAGE_EXTERNAL_STORAGE','ACCESS_FINE_LOCATION']:
    if forbidden in manifest:
        raise SystemExit(f'Forbidden permission found: {forbidden}')
if 'android.permission.INTERNET' not in manifest:
    raise SystemExit('INTERNET permission expected for private Research Autopilot')
if '.ResultActivity' in manifest:
    raise SystemExit('Legacy ResultActivity must not be registered in runtime manifest')
main_layout = pathlib.Path('app/src/main/res/layout/activity_main.xml').read_text().lower()
for forbidden_ui in ['old daily scan', 'symptom input page', 'daily health score']:
    if forbidden_ui in main_layout:
        raise SystemExit(f'Legacy first-page wording remains: {forbidden_ui}')
xml_ids=set()
for p in pathlib.Path('app/src/main/res/layout').glob('*.xml'):
    xml_ids.update(re.findall(r'@\+id/([A-Za-z0-9_]+)', p.read_text()))
refs=set()
for p in pathlib.Path('app/src/main/java').rglob('*.kt'):
    refs.update(re.findall(r'R\.id\.([A-Za-z0-9_]+)', p.read_text()))
missing=refs-xml_ids
if missing:
    raise SystemExit(f'Missing layout ids: {sorted(missing)}')
print('Layout ID check: PASS')
PY

python3 - <<'PY'
import pathlib, re
version = '1.4.3-alpha-route-cleanup'
build = pathlib.Path('app/build.gradle.kts').read_text()
if version not in build:
    raise SystemExit(f'Version mismatch: {version} not found in app/build.gradle.kts')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['runtimeStatus', 'executionLockReport', 'datasetForagingReport', 'persistentFailureMemory']:
    if required not in models:
        raise SystemExit(f'Missing report field: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
for required in ['runtimeFailoverApplied', 'hardStagnationTriggered', 'runtime_dataset_accession', 'runDatasetFirstForaging', 'searchNcbiIds', 'DatasetParser.parse', 'ResearchStateEngine.actionableSummary']:
    if required not in autopilot:
        raise SystemExit(f'Missing execution wiring token: {required}')
router = pathlib.Path('app/src/main/java/com/immunesignal/app/DirectDatasetSourceRouter.kt').read_text()
if 'GEO_GDS_COOLDOWN_ESCAPE' not in router:
    raise SystemExit('Missing route hardening token: GEO_GDS_COOLDOWN_ESCAPE')
engine = pathlib.Path('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt').read_text()
if 'q_v142_' not in engine:
    raise SystemExit('Execution lock does not accept q_v142_ dataset-parser forced queries')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
if 'Run a research cycle or import a report' in models:
    raise SystemExit('Generic non-actionable Next Evidence text remains')
manifest = pathlib.Path('app/src/main/AndroidManifest.xml').read_text()
if '.ResultActivity' in manifest:
    raise SystemExit('Legacy manual result route is still registered')
print('Execution wiring/version check: PASS')
PY

python3 -B -m py_compile research/*.py
find research -type d -name __pycache__ -prune -exec rm -rf {} +
find research -name '*.pyc' -delete

python3 - <<'PY'
import pathlib
bad=[]
for p in pathlib.Path('.').rglob('__pycache__'):
    bad.append(str(p))
for p in pathlib.Path('.').rglob('*.pyc'):
    bad.append(str(p))
if bad:
    raise SystemExit('Python cache artifacts found in release tree: ' + ', '.join(bad[:20]))
print('Python cache artifact check: PASS')
PY

if [[ "${RUN_SAMPLE_PIPELINE:-0}" == "1" ]]; then
  timeout 20 python3 research/omics_bridge.py research/examples/sample_cases.csv >/tmp/immune_omics_bridge.json
  timeout 20 python3 research/baseline_classifier.py research/examples/sample_matrix.csv >/tmp/immune_baseline.json || true
  timeout 20 python3 research/evidence_quality.py >/tmp/immune_evidence_quality.json
  timeout 20 python3 research/causality_scorer.py 'stress before allergy histamine blood pressure mast cell mechanism' >/tmp/immune_causality.json
  timeout 20 python3 research/personal_time_series.py research/examples/sample_personal_series.csv stress allergy_intensity >/tmp/immune_personal_series.json
  timeout 20 python3 research/negative_controls.py research/examples/sample_personal_series.csv stress dizziness >/tmp/immune_negative_controls.json
  timeout 20 python3 research/hypothesis_ranker.py research/examples/sample_hypotheses.csv >/tmp/immune_hypothesis_ranker.json
  timeout 20 python3 research/global_dataset_registry.py research/examples/global_dataset_candidates.csv >/tmp/immune_global_dataset_registry.json
  timeout 20 python3 research/immune_axis_mapper.py 'interferon IL10 CD8 antibody tissue damage recovery' >/tmp/immune_axis_mapper.json
  timeout 20 python3 research/trigger_response_graph.py 'virus interferon IL10 tissue damage recovery' >/tmp/immune_trigger_response_graph.json
  timeout 20 python3 research/pathogen_response_comparator.py 'virus interferon IL10 tissue damage recovery' >/tmp/immune_pathogen_response.json
  echo 'Research Python sample pipeline: PASS'
else
  echo 'Research Python compile checks: PASS'
  echo 'Sample pipeline skipped by default; run RUN_SAMPLE_PIPELINE=1 scripts/run_static_checks.sh to execute examples.'
fi
