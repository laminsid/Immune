#!/usr/bin/env python3
import json, pathlib
for p in pathlib.Path('.').rglob('*.json'):
    if '.gradle' in p.parts or 'build' in p.parts:
        continue
    json.loads(p.read_text(encoding='utf-8'))
    print('JSON PASS', p)
