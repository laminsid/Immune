# v1.0.0-alpha-research-discipline

Date: 2026-05-09
Scope: Closes the v0.9.0 → v1.0 milestone listed in `README.md`. Cumulative
patch including everything from `v0.9.1-patches` plus three v1.0 items:

1. JVM unit tests for every scoring engine (junit + parity fixtures)
2. PubMed abstract fetch via efetch.fcgi (richer evidence classification)
3. Permutation-based negative control (1000 shuffles, empirical p-value)

This is still alpha. The product is not validated for clinical use.

---

## What changed since v0.9.0

### v0.9.1 patches (rolled in)

- **P1** Version metadata corrected (was 3 versions stale).
- **P2** Canonical scoring formula doc + Python ↔ Kotlin parity.
- **P3** Steering PII sanitizer (closes README privacy claim).
- **P4** SourceClassifier human-evidence regressions (mixed/synthesis).
- **P5** Negative-control integrated into causality numeric score.
- **P6** NCBI compliance (tool/email/api_key) + batched esummary + retry.
- **P7** Append-only writes + cached uniqueness check (O(n²) → O(n)).

See `CHANGELOG_v0.9.1-patches.md` for details.

### v1.0 additions

#### A. Unit tests for every scoring engine (`app/src/test/`)
Five JUnit test classes covering:
- `SourceClassifierTest` (7 tests) — verifies the v0.9.1 humanEvidence
  regressions and the new `human_relevant_with_animal_context` class.
- `CausalityScorerTest` (7 tests) — proves negativeControlStatus changes
  the numeric score (the v0.9.0 contradiction).
- `HypothesisRankingEngineTest` (5 tests) — proves the STRONG_SIGNAL hard
  gate works (high score blocked by `control_required_before_strong`).
- `SteeringSanitizerTest` (10 tests) — exhaustive PII redaction proofs.
- `BiologicalPlausibilityGraphTest` (4 tests) + `AbstractParserTest`
  (4 tests) — bound checks and abstract parsing tolerance.

Run with `./gradlew :app:testDebugUnitTest`. Tests use pure JVM (no
Robolectric needed) because we add `org.json:json:20231013` as
`testImplementation`.

Total: **37 unit tests** covering the scoring contract.

#### B. Abstract fetch via `efetch.fcgi`

`ResearchAutopilot.fetchPubMedAbstractsBatch(pmids)` issues a single
batched `efetch` call (up to 200 PMIDs) per query, then merges the
abstract text into `evidenceText` before classification.

Why this matters: title-only classification missed mechanism keywords
(pathway, cytokine, mast cell, autonomic), study-design keywords
(longitudinal, prospective, randomised), and contradiction signals
(no association, conflicting). Abstracts unlock all of these.

Cost: one extra batched HTTP call per query. With API key, total cycle
time stays under the v0.9.1 budget.

`ResearchAutopilot.parseAbstractText(text)` is `internal` and tolerant
of NCBI's per-journal format variations. Records are split by record
header, with a fallback linear scan if no record headers are present.

#### C. Permutation-based negative control (`research/negative_controls.py`)

Replaces the v0.9.0 single-shuffle method with N=1000 permutations and an
empirical p-value computed via Phipson & Smyth (2010) add-one correction:

```
p = (extreme_count + 1) / (valid_perms + 1)
```

For each `(exposure, outcome)` series, the test reports:
- Lag-0 same-day correlation (baseline)
- **Forward** lag-1: `exposure[t] → outcome[t+1]` with permutation p-value
- **Reverse-time** lag-1: `outcome[t] → exposure[t+1]` with permutation
  p-value (negative control: should be weaker than forward if the causal
  direction is real)

Output includes a structured `verdict`:
- `withhold_judgement_collect_more_data` (n < 14)
- `forward_signal_passes_negative_control`
- `reverse_time_just_as_strong_likely_confound`
- `forward_signal_does_not_clearly_beat_chance`
- `cannot_compute`

Sample-size flag (`INSUFFICIENT_DATA`, `LOW_POWER`, `OK`) is set on every
result. v0.9.0 silently emitted unstable correlations on n=5 inputs.

Verified on synthetic data: with a known causal forward signal in 60-day
synthetic series, `forward p=0.001` and `reverse p=0.45`, verdict
`forward_signal_passes_negative_control`. With the bundled n=5 sample,
the verdict correctly returns `withhold_judgement_collect_more_data`
instead of producing fake numbers.

---

## Files added / changed

```text
ADDED  app/src/test/java/com/immunesignal/app/SourceClassifierTest.kt
ADDED  app/src/test/java/com/immunesignal/app/CausalityScorerTest.kt
ADDED  app/src/test/java/com/immunesignal/app/HypothesisRankingEngineTest.kt
ADDED  app/src/test/java/com/immunesignal/app/SteeringSanitizerTest.kt
ADDED  app/src/test/java/com/immunesignal/app/BiologicalPlausibilityGraphTest.kt
ADDED  app/src/main/java/com/immunesignal/app/SteeringSanitizer.kt           (from v0.9.1)
ADDED  research/parity_fixtures.py                                            (from v0.9.1)
ADDED  research/expected_parity_v1.0.json                                     (NEW v1.0)
ADDED  docs/CANONICAL_SCORING_FORMULA_v0.9.1.md                               (from v0.9.1)
ADDED  CHANGELOG_v0.9.1-patches.md                                            (from v0.9.1)

CHANGED  app/build.gradle.kts                  (versionCode/Name + JUnit + org.json testDeps)
CHANGED  app/src/main/java/com/immunesignal/app/SourceClassifier.kt
CHANGED  app/src/main/java/com/immunesignal/app/CausalityScorer.kt
CHANGED  app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt
CHANGED  app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt
CHANGED  research/causality_scorer.py
CHANGED  research/hypothesis_ranker.py
CHANGED  research/negative_controls.py
CHANGED  scripts/audit_kotlin_delimiters.py    (also scans app/src/test/java)
```

## Validation

```text
JSON parse: PASS                (25 asset files)
Kotlin delimiter audit: PASS    (now scans main + test sources)
XML parse: PASS
Layout ID check: PASS
Research Python checks: PASS
Permutation neg-control:        forward p=0.001 / reverse p=0.45 on synthetic
                                forward signal — verdict correct.
Parity fixtures:                7 canonical expected values written to
                                research/expected_parity_v1.0.json.
```

Limitation: full Android Gradle build was not run in the patch container
(no Android SDK). Run `./gradlew :app:assembleDebug` and
`./gradlew :app:testDebugUnitTest` locally or via CI.

## Known gaps deferred to v1.1

- Hardcoded `BiologicalPlausibilityGraph` still duplicates
  `biological_plausibility_graph_v0.1.json`. Pick one source.
- `matchAxes` and `inferAxes` keyword dictionaries diverge slightly. Merge.
- `runCycle` uses a raw Thread — migrate to `WorkManager` / `lifecycleScope`.
- `onActivityResult` deprecated — migrate to `ActivityResultContracts`.
- `OmicsResearchAxis.score()` produces fractional 0..1 outputs that are
  later compared with thresholds expecting 0..100 — review semantics.
- Statistical sanity gates (n < 14, METADATA_ONLY cap) flagged in code
  comments but not yet wired into the UI.

## Risk register

1. **Tests not actually executed in this container** — only static delimiter
   audit. Run `./gradlew :app:testDebugUnitTest` before tagging release.
2. **`SteeringSanitizer` whitelist is intentionally narrow.** Legitimate
   medical terms not in the list will be flagged. Expand `safeStems` as
   real-world false rejections appear.
3. **Abstract fetch increases NCBI traffic by ~50%** (one extra request
   per query). Strongly recommend adding the API key file
   (`<filesDir>/ncbi_api_key.txt`) to keep the per-second budget.
4. **Permutation test is slow on large n** (~0.4s for n=60, n_perm=1000).
   Will need vectorisation in numpy if scaled to multi-thousand-row series.
