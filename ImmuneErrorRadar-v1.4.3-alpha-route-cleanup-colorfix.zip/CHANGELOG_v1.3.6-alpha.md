# v1.3.6-alpha — Anti-Stagnation Applied Pivot Patch

## Problem fixed
v1.3.5 correctly rejected narrative-polish reports, but an empty cycle could still restart from the same low-data PubMed neighborhood. The report could say "strategy pivoted" while the next run did not actually apply the pivot strongly enough.

## Changes
- Added `AutonomousStagnationEngine.kt`.
- The engine now reads recent reports and detects repeated empty cycles.
- If the last cycle had zero useful sources and repeated PubMed IDs, the next run applies the previous pivot before normal autonomous lanes.
- Low-data limits are widened only under stagnation:
  - queries: minimum 5–6 instead of fixed 4
  - PubMed retmax: minimum 12/18/25 depending on stagnation level
- Added anti-stagnation query lanes:
  - dataset accession search
  - contradiction/control search
  - trigger-response-outcome search
- Added visible learning notes when anti-stagnation is active.
- Added unit tests: `AutonomousStagnationEngineV136Test.kt`.

## Still blocked intentionally
- No new biological axes.
- No Random Forest or ML model.
- No diagnostic or treatment claims.
- No discovery claim when no source survives.
