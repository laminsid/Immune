# Immune Error Radar v0.8.0-alpha — Research Steering Patch

## Added

- User-facing Research Steering section in Research Autopilot.
- Save/Clear steering profile controls.
- Variables, focus question, required context, and excluded terms inputs.
- Active steering profile display.
- Directed variable-bridge query generation without code changes.
- Steered query priority before default queries.
- Steering-aware novelty boosting.
- Steering profile embedded in JSON/PDF/brief reports.
- New asset: `research_steering_rules_v0.1.json`.
- New doc: `docs/RESEARCH_STEERING_v0.1.md`.

## Validation

- Static XML/JSON checks pass.
- Kotlin delimiter audit passes.
- Research core Kotlin files compile with local stubs.
- Python research scripts compile.

## Boundary

Research steering is a hypothesis-generation control layer. It does not prove causality and does not produce diagnosis, treatment, or drug recommendations.
