# Immune Error Radar v0.6.0-alpha — Omics Autopilot + Knowledge Intake

## Added

- DNA/RNA/omics research axis.
- OmicsResearchAxis.kt.
- Search queries for DNA methylation, epigenetics, RNA-seq, transcriptomics, miRNA, scRNA.
- Manual report intake via pasted text.
- Manual report intake via text/csv/json file picker.
- Stop button for active research cycle.
- Search cap: 10 minutes.
- Learning cap: 15 minutes.
- Short copyable report.
- Cumulative knowledge delta: new sources, repeated skipped, new axis pairs, DNA/RNA signals.
- GitHub-style static checks inspired by FennGuard project hygiene.

## Fixed

- Fixed invalid Kotlin string check in research axis boost logic.
- Strengthened source de-duplication policy.

## Boundary

Still research-only. No diagnosis, no treatment, no drug ranking, no clinical decision.
