package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DatasetFirstForagerV140Test {
    @Test
    fun decomposesBroadMissionIntoTestableShards() {
        val shards = HypothesisDecomposer.decompose("Which public datasets can map trigger-response-outcome immune patterns?")
        assertTrue(shards.size >= 3)
        assertTrue(shards.any { it.shardId.contains("ALLERGY") })
        assertTrue(shards.all { it.evidenceQuestion.contains("Mission context") })
    }

    @Test
    fun datasetFirstRouterActivatesAfterNoDatasetFailure() {
        val recent = listOf("NO_DATASET_ACCESSION NO_EVIDENCE_OBJECT_NO_UPGRADE dataset candidates: 0")
        val active = DirectDatasetSourceRouter.shouldRunDatasetFirst(
            recentReports = recent,
            researchState = "RESEARCH_NORMAL",
            appliedPivot = PivotDecision.none(),
            memory = PersistentFailureMemorySnapshot.empty()
        )
        assertTrue(active)
    }

    @Test
    fun compilerCreatesNarrowDatasetQueries() {
        val queries = DatasetQueryCompiler.compile(
            HypothesisDecomposer.decompose("baseline mission"),
            PersistentFailureMemorySnapshot.empty()
        )
        assertTrue(queries.isNotEmpty())
        assertTrue(queries.any { it.query.contains("GSE") || it.query.contains("RNA-seq") || it.query.contains("single-cell") })
        assertTrue(queries.none { it.label.contains("daily", ignoreCase = true) })
    }

    @Test
    fun foragingReportDefaultsAreSafe() {
        val report = DatasetForagingReport.empty()
        assertEquals("NOT_RUN", report.state)
        assertEquals(false, report.active)
    }
}
