package com.immunesignal.app

import kotlin.math.roundToInt

class GutNutritionHormoneAxis {
    fun profile(
        input: CaseInput,
        type2Axis: Int,
        tnfIl6Axis: Int,
        hyperAxis: Int,
        stressAxis: Int,
        evidence: MutableList<String>
    ): GutNutritionHormoneMap {
        val gut = input.gutNutritionHormone
        val reflux = gut.refluxHeartburn0To10 ?: 0
        val dyspepsia = gut.bloatingDyspepsia0To10 ?: 0
        val diet = gut.dietDiversity0To10 ?: 5
        val proteinPerKg = proteinPerKg(gut.proteinIntakeEstimateG, gut.bodyWeightKg)

        var acid = 0
        if (reflux >= 6) acid += 25
        if (dyspepsia >= 6) acid += 20
        if (gut.suspectedLowAcidPattern) acid += 22
        if (gut.ppiOrAntacidUse) acid += 18
        if (gut.knownGastritisOrHpylori) acid += 18
        if (gut.mealTimingIrregular) acid += 8
        acid = acid.coerceIn(0, 100)
        if (acid >= 35) evidence += "Gut/acid axis: reflux/dyspepsia/acid-suppression or gastritis-like context may interact with allergy through gut barrier, digestion, microbiome, or reflux-airway routes."

        var gutBarrier = 0
        if (diet <= 3) gutBarrier += 20
        if (gut.ppiOrAntacidUse) gutBarrier += 15
        if (gut.knownGastritisOrHpylori) gutBarrier += 15
        if (input.symptoms.allergyLike) gutBarrier += 12
        if (type2Axis >= 45) gutBarrier += 12
        if (tnfIl6Axis >= 40) gutBarrier += 10
        gutBarrier = gutBarrier.coerceIn(0, 100)

        var nutrition = 0
        if (diet >= 7) nutrition += 25 else if (diet <= 3) nutrition -= 20
        if (proteinPerKg != null) nutrition += when {
            proteinPerKg >= 1.2 -> 28
            proteinPerKg >= 0.8 -> 16
            proteinPerKg < 0.6 -> -25
            else -> 0
        }
        if (gut.appetiteLow) nutrition -= 15
        nutrition = (50 + nutrition).coerceIn(0, 100)

        var muscle = 45
        if (gut.muscleMassLossOrLow) muscle -= 28
        if (gut.strengthTraining) muscle += 22
        if (proteinPerKg != null && proteinPerKg >= 1.0) muscle += 15
        if (gut.appetiteLow) muscle -= 10
        if (input.age != null && input.age >= 45) muscle -= 8
        muscle = muscle.coerceIn(0, 100)

        var testosterone = 0
        val t = gut.testosteroneNgDl
        if (t != null) testosterone += when {
            t < 250.0 -> 35
            t < 350.0 -> 22
            t > 900.0 -> 18
            else -> 8
        }
        if (gut.lowLibidoOrLowMorningDrive) testosterone += 18
        if (gut.lowMorningEnergy) testosterone += 12
        if (muscle <= 35) testosterone += 8
        if (hyperAxis >= 50 || tnfIl6Axis >= 45) testosterone += 8
        testosterone = testosterone.coerceIn(0, 100)
        if (testosterone >= 35) evidence += "Hormone axis: testosterone context may modulate immune tone, muscle reserve, recovery, and inflammatory balance; this is hypothesis-grade and not endocrine diagnosis."

        var metabolic = 0
        if (nutrition <= 35) metabolic += 20
        if (muscle <= 35) metabolic += 18
        if (stressAxis >= 60) metabolic += 15
        if (gut.appetiteLow) metabolic += 10
        if (input.agingAutonomic.fatigueAfterStress0To10 != null && input.agingAutonomic.fatigueAfterStress0To10 >= 7) metabolic += 12
        metabolic = metabolic.coerceIn(0, 100)

        val hypotheses = mutableListOf<String>()
        if (acid >= 40 && type2Axis >= 35) hypotheses += "Gut-acid/allergy bridge candidate: gastric irritation, reflux, low-acid suspicion, PPI/antacid context, or gastritis-like history may interact with allergy through gut barrier, microbiome, or reflux-airway pathways."
        if (gutBarrier >= 40 && type2Axis >= 35) hypotheses += "Microbiome/gut-barrier candidate: allergy reactivity may be shaped by diet diversity, microbiome state, gastric context, and gut-lung/gut-immune signaling."
        if (muscle <= 35 && tnfIl6Axis >= 35) hypotheses += "Muscle-inflammation reserve candidate: lower muscle reserve with inflammatory markers may indicate weaker metabolic buffering or slower recovery."
        if (nutrition <= 40 && input.agingAutonomic.infectionRecoverySlow0To10 != null && input.agingAutonomic.infectionRecoverySlow0To10 >= 6) hypotheses += "Nutrition-recovery candidate: low diet/protein/appetite signals may correlate with slower immune recovery and fatigue patterns."
        if (testosterone >= 35) hypotheses += "Testosterone-immune modulation candidate: androgen context may interact with inflammatory tone, immune responsiveness, muscle mass, and recovery."
        if (hypotheses.isEmpty()) hypotheses += "Gut/nutrition/hormone layer recorded no dominant pattern; repeat with time-series if symptoms cluster around meals, reflux, protein intake, muscle loss, or hormone data."

        val dominant = listOf(
            "gastric_acid_dysregulation_candidate" to acid,
            "gut_barrier_microbiome_candidate" to gutBarrier,
            "nutrition_protein_recovery_candidate" to (100 - nutrition),
            "low_muscle_reserve_candidate" to (100 - muscle),
            "testosterone_immune_modulation_candidate" to testosterone,
            "metabolic_stress_candidate" to metabolic
        ).maxByOrNull { it.second }?.first ?: "mixed_or_undermeasured"

        val interp = buildString {
            append("Gut/metabolic/hormone map is hypothesis-grade. ")
            append("It tests whether stomach-acid context, digestive symptoms, diet diversity, protein/muscle reserve, and testosterone context modify immune reactivity or recovery. ")
            append("It does not diagnose GERD, gastritis, low stomach acid, microbiome disorder, malnutrition, sarcopenia, or testosterone deficiency.")
        }

        return GutNutritionHormoneMap(
            gastricAcidDysregulationAxis = acid,
            gutBarrierMicrobiomeAxis = gutBarrier,
            nutritionProteinAxis = nutrition,
            muscleMassReserveAxis = muscle,
            testosteroneImmuneModulationAxis = testosterone,
            metabolicStressAxis = metabolic,
            dominantPattern = dominant,
            researchInterpretation = interp,
            competingHypotheses = hypotheses
        )
    }

    private fun proteinPerKg(proteinG: Double?, weightKg: Double?): Double? {
        if (proteinG == null || weightKg == null || proteinG <= 0.0 || weightKg <= 0.0) return null
        return ((proteinG / weightKg) * 100.0).roundToInt() / 100.0
    }
}
