package com.immunesignal.app

import kotlin.math.roundToInt

class ImmuneSignalEngine {
    private val pniLayer = PsychoneuroimmuneLayer()
    private val pmsLayer = PsychomusculoskeletalLayer()
    private val causalEngine = CausalOriginEngine()
    private val agingAxis = AgingImmuneAxis()
    private val autonomicVascularLayer = AutonomicVascularLayer()
    private val allergyAgingBridge = AllergyAgingBridge()
    private val hypothesisEngine = HypothesisEngine()
    private val longevityHypothesisEngine = LongevityHypothesisEngine()
    private val gutNutritionHormoneAxis = GutNutritionHormoneAxis()

    fun analyze(input: CaseInput): SignalResult {
        val evidence = mutableListOf<String>()
        val causeEvidence = mutableListOf<String>()
        val notProven = listOf(
            "This app does not diagnose allergy, asthma, rheumatoid arthritis, disc herniation, pneumonia, cytokine storm, autoimmune disease, infection, or cancer.",
            "This app does not recommend drugs, biologics, steroids, antibiotics, immune suppression, surgery, supplements, exercises, or lifestyle treatment as medical advice.",
            "Psychological stress is modeled only as a trigger/amplifier/maintainer candidate, not automatic proof of root cause.",
            "Back/disc-like patterns are not diagnosed here; radiating pain, numbness, weakness, bladder/bowel symptoms, trauma, fever, or severe worsening require real-world clinical review.",
            "The output is a research notebook and immune-signal organizer. It is not a validated clinical probability, lab interpretation service, or emergency triage system.",
            "Reference ranges vary by laboratory, age, pregnancy status, medications, infection history, vaccination history, and clinical context.",
            "Entered values are treated as user-entered and are not independently verified by this app.",
            "The allergy-aging relation is modeled as competing research hypotheses only; high allergy does not prove slower aging, and low allergy does not prove immune decline.",
            "Gut-acid, nutrition, muscle-mass, and testosterone links are exploratory. They do not diagnose reflux, gastritis, low stomach acid, microbiome disorder, malnutrition, sarcopenia, or hormone deficiency."
        )

        val quality = dataQuality(input)
        val stressAxis = pniLayer.stressAxis(input, causeEvidence)
        val mechanicalAxis = pmsLayer.mechanicalLoadAxis(input, causeEvidence)
        val neuroGuardingAxis = pmsLayer.neuroMuscularGuardingAxis(input, causeEvidence)
        val causeMap = causalEngine.map(input, stressAxis, mechanicalAxis, neuroGuardingAxis, causeEvidence)

        val type2 = type2AllergicAxisScore(input, evidence, causeMap)
        val mast = mastCellAxisScore(input, evidence, causeMap)
        val eos = eosinophilAxisScore(input, evidence)
        val tnfIl6 = tnfIl6InflammatoryAxisScore(input, evidence, causeMap)
        val hyper = hyperInflammatoryAxisScore(input, evidence, causeMap)
        val brakeWeakness = regulatoryBrakeWeaknessScore(input, tnfIl6, hyper, stressAxis, evidence)
        val damage = systemicDamageSignalScore(input, evidence)
        val emergency = emergencyGateScore(input, evidence, hyper, damage, neuroGuardingAxis)
        val agingProfile = agingAxis.profile(input, type2, tnfIl6, hyper, brakeWeakness, damage, evidence)
        val autonomicProfile = autonomicVascularLayer.profile(input, type2, mast, stressAxis, evidence)
        val gutHormoneMap = gutNutritionHormoneAxis.profile(input, type2, tnfIl6, hyper, stressAxis, evidence)
        val compartment = dominantCompartment(input, type2, tnfIl6, hyper, mechanicalAxis, neuroGuardingAxis)
        val vector = ImmuneStateVector(
            type2AllergicAxis = type2,
            mastCellAxis = mast,
            eosinophilAxis = eos,
            tnfIl6InflammatoryAxis = tnfIl6,
            hyperInflammatoryAxis = hyper,
            regulatoryBrakeWeakness = brakeWeakness,
            systemicDamageSignal = damage,
            psychoneuroimmuneStressAxis = stressAxis,
            mechanicalLoadAxis = mechanicalAxis,
            neuroMuscularGuardingAxis = neuroGuardingAxis,
            immunosenescenceAxis = agingProfile.immunosenescenceAxis,
            inflammagingAxis = agingProfile.inflammagingAxis,
            immuneResponsivenessAxis = agingProfile.immuneResponsivenessAxis,
            sympatheticPressureUpAxis = autonomicProfile.sympatheticPressureUp,
            histaminePressureDownAxis = autonomicProfile.histaminePressureDown,
            bloodPressureInstabilityAxis = autonomicProfile.bloodPressureInstability,
            gastricAcidDysregulationAxis = gutHormoneMap.gastricAcidDysregulationAxis,
            gutBarrierMicrobiomeAxis = gutHormoneMap.gutBarrierMicrobiomeAxis,
            nutritionProteinAxis = gutHormoneMap.nutritionProteinAxis,
            muscleMassReserveAxis = gutHormoneMap.muscleMassReserveAxis,
            testosteroneImmuneModulationAxis = gutHormoneMap.testosteroneImmuneModulationAxis,
            dominantCompartment = compartment
        )
        val agingAutonomicMap = allergyAgingBridge.map(input, vector, agingProfile, autonomicProfile, evidence)

        val researchHypotheses = (hypothesisEngine.generate(input, vector, causeMap) +
            longevityHypothesisEngine.generate(input, vector, agingAutonomicMap) +
            agingAutonomicMap.competingHypotheses +
            gutHormoneMap.competingHypotheses).distinct()
        val strongest = maxOf(type2, mast, eos, tnfIl6, hyper, damage, stressAxis, mechanicalAxis, neuroGuardingAxis, agingProfile.agingLoadIndex, autonomicProfile.bloodPressureInstability, gutHormoneMap.gastricAcidDysregulationAxis, gutHormoneMap.gutBarrierMicrobiomeAxis, gutHormoneMap.testosteroneImmuneModulationAxis)
        val signalStrength = signalStrength(strongest, quality)
        val signalLabel = signalStrengthLabel(signalStrength)
        val completeness = evidenceCompleteness(quality)

        return when {
            emergency >= 70 -> baseResult(
                severity = "RED / urgent",
                classifierLabel = "urgent_clinical_warning_pattern",
                pattern = "Urgent warning pattern — stop interpretation and seek real-world care",
                signalStrength = signalStrength,
                signalLabel = signalLabel,
                quality = quality,
                completeness = completeness,
                vector = vector,
                causeMap = causeMap,
                agingMap = agingAutonomicMap,
                gutMap = gutHormoneMap,
                evidence = evidence,
                causeEvidence = causeEvidence,
                researchHypotheses = researchHypotheses,
                discussionPrompts = emergencyDiscussionPrompts(),
                safeActions = listOf(
                    "If symptoms are severe, rapidly worsening, or life-threatening, call emergency services now. Germany/EU: 112.",
                    "For non-life-threatening medical help in Germany, contact 116117 or a qualified clinician.",
                    "Do not wait for repeated measurements inside the app when red flags are present.",
                    "Show the entered data and recent lab results, trigger timeline, medication list, allergies, and recent infection/vaccine history to the clinician."
                ),
                notProven = notProven
            )
            hyper >= 55 || damage >= 65 -> baseResult(
                severity = "AMBER / high caution",
                classifierLabel = "hyperinflammatory_or_systemic_signal",
                pattern = "Systemic inflammatory signal — clinician review should not be delayed",
                signalStrength = signalStrength,
                signalLabel = signalLabel,
                quality = quality,
                completeness = completeness,
                vector = vector,
                causeMap = causeMap,
                agingMap = agingAutonomicMap,
                gutMap = gutHormoneMap,
                evidence = evidence,
                causeEvidence = causeEvidence,
                researchHypotheses = researchHypotheses,
                discussionPrompts = systemicDiscussionPrompts(),
                safeActions = listOf(
                    "Use this as a concise clinician-review pack, especially with fever, shortness of breath, weakness, worsening symptoms, or repeated abnormal labs.",
                    "If breathing difficulty, chest pain, fainting, confusion, blue/grey lips, or rapid throat/tongue swelling appears, treat it as urgent and seek emergency care.",
                    "Do not start, stop, or escalate medication based on this app."
                ),
                notProven = notProven
            )
            neuroGuardingAxis >= 60 || (mechanicalAxis >= 50 && input.causeContext.backOrDiscPain) -> baseResult(
                severity = if (input.causeContext.numbnessOrWeakness) "AMBER / high caution" else "AMBER / caution",
                classifierLabel = "neuro_musculoskeletal_causal_signal",
                pattern = "Musculoskeletal / neuro-guarding signal with possible stress amplification",
                signalStrength = signalStrength,
                signalLabel = signalLabel,
                quality = quality,
                completeness = completeness,
                vector = vector,
                causeMap = causeMap,
                agingMap = agingAutonomicMap,
                gutMap = gutHormoneMap,
                evidence = evidence,
                causeEvidence = causeEvidence,
                researchHypotheses = researchHypotheses,
                discussionPrompts = musculoskeletalDiscussionPrompts(),
                safeActions = listOf(
                    "Use this as a structured trigger-and-symptom note for a clinician or physiotherapy/orthopedic review when symptoms persist or worsen.",
                    "Seek timely clinical review for numbness, weakness, radiating leg pain, fever, trauma, bladder/bowel changes, or severe worsening.",
                    "Do not assume stress caused a disc problem; model it only as a possible amplifier/maintainer unless repeated evidence supports more."
                ),
                notProven = notProven
            )
            type2 >= tnfIl6 && type2 >= 35 -> baseResult(
                severity = "AMBER / caution",
                classifierLabel = "type2_allergic_dominant_signal",
                pattern = "Type-2 / allergic-like immune over-response signal",
                signalStrength = signalStrength,
                signalLabel = signalLabel,
                quality = quality,
                completeness = completeness,
                vector = vector,
                causeMap = causeMap,
                agingMap = agingAutonomicMap,
                gutMap = gutHormoneMap,
                evidence = evidence,
                causeEvidence = causeEvidence,
                researchHypotheses = researchHypotheses,
                discussionPrompts = allergyDiscussionPrompts(),
                safeActions = listOf(
                    "Use this as a structured note for an allergist, ENT doctor, pulmonologist, or primary-care clinician if symptoms are recurrent, severe, or worsening.",
                    "Track triggers, timing, seasonality, foods, medicines, breathing symptoms, sleep, stress, and response to clinician-prescribed treatment.",
                    "Do not self-diagnose allergy, asthma, sinus infection, or anaphylaxis from this app."
                ),
                notProven = notProven
            )
            tnfIl6 >= 35 -> baseResult(
                severity = "AMBER / caution",
                classifierLabel = "tnf_il6_inflammatory_dominant_signal",
                pattern = "Inflammatory / autoimmune-like activity signal",
                signalStrength = signalStrength,
                signalLabel = signalLabel,
                quality = quality,
                completeness = completeness,
                vector = vector,
                causeMap = causeMap,
                agingMap = agingAutonomicMap,
                gutMap = gutHormoneMap,
                evidence = evidence,
                causeEvidence = causeEvidence,
                researchHypotheses = researchHypotheses,
                discussionPrompts = inflammatoryDiscussionPrompts(),
                safeActions = listOf(
                    "Use this as a structured note for a physician or rheumatologist, especially with joint swelling, morning stiffness, fever, weight loss, or persistent CRP/ESR elevation.",
                    "Ask the clinician whether the entered pattern is clinically meaningful in your context and whether examination or further tests are needed.",
                    "Do not self-treat with immune suppressants, steroids, antibiotics, biologics, or high-dose anti-inflammatory medication based on this app."
                ),
                notProven = notProven
            )
            else -> baseResult(
                severity = "GREEN / no strong signal",
                classifierLabel = "low_signal_or_incomplete_pattern",
                pattern = "No strong immune/causal over-response signal in entered data",
                signalStrength = signalStrength(25, quality),
                signalLabel = signalStrengthLabel(signalStrength(25, quality)),
                quality = quality,
                completeness = completeness,
                vector = vector,
                causeMap = causeMap,
                agingMap = agingAutonomicMap,
                gutMap = gutHormoneMap,
                evidence = if (evidence.isEmpty()) mutableListOf("No entered value crossed this prototype's caution gates.") else evidence,
                causeEvidence = if (causeEvidence.isEmpty()) mutableListOf("No causal-origin clue crossed this prototype's gates.") else causeEvidence,
                researchHypotheses = researchHypotheses,
                discussionPrompts = listOf(
                    "Are symptoms persistent, worsening, or recurring despite low signal in entered data?",
                    "Are important values, trigger-timing, sleep, stress, exposure, gut/diet/protein/muscle, hormone, or mechanical-load data missing?",
                    "Could symptoms have a non-immune, non-psychological, structural, infectious, or medication-related cause that needs review?"
                ),
                safeActions = listOf(
                    "Continue normal medical follow-up if symptoms persist or worsen.",
                    "Repeat or complete missing lab values only through a qualified clinician.",
                    "A green result does not rule out early disease, infection, allergy, asthma, autoimmune illness, gut disorder, hormone issue, nutrition problem, disc injury, or nerve compression."
                ),
                notProven = notProven
            )
        }
    }

    private fun baseResult(
        severity: String,
        classifierLabel: String,
        pattern: String,
        signalStrength: Int,
        signalLabel: String,
        quality: Int,
        completeness: String,
        vector: ImmuneStateVector,
        causeMap: CausalOriginMap,
        agingMap: AgingAutonomicMap,
        gutMap: GutNutritionHormoneMap,
        evidence: MutableList<String>,
        causeEvidence: MutableList<String>,
        researchHypotheses: List<String>,
        discussionPrompts: List<String>,
        safeActions: List<String>,
        notProven: List<String>
    ) = SignalResult(
        severity = severity,
        classifierLabel = classifierLabel,
        pattern = pattern,
        signalStrengthPercent = signalStrength,
        signalStrengthLabel = signalLabel,
        dataQualityPercent = quality,
        evidenceCompleteness = completeness,
        immuneStateVector = vector,
        causalOriginMap = causeMap,
        agingAutonomicMap = agingMap,
        gutNutritionHormoneMap = gutMap,
        evidence = evidence.distinct(),
        causeEvidence = causeEvidence.distinct(),
        researchHypotheses = researchHypotheses.distinct(),
        discussionPrompts = discussionPrompts,
        safeActions = safeActions,
        notProven = notProven
    )

    private fun dataQuality(input: CaseInput): Int {
        val values = listOf(
            input.age?.toDouble(), input.temperatureC,
            input.biomarkers.crpMgL, input.biomarkers.esrMmH, input.biomarkers.totalIgeIuMl,
            input.biomarkers.eosinophilsCellsUl, input.biomarkers.il6PgMl, input.biomarkers.tnfAlphaPgMl,
            input.biomarkers.il10PgMl, input.biomarkers.ferritinNgMl, input.biomarkers.histamine,
            input.causeContext.stressToday0To10?.toDouble(), input.causeContext.stressLast7Days0To10?.toDouble(),
            input.causeContext.sleepQuality0To10?.toDouble(), input.causeContext.longSittingHours?.toDouble(),
            input.agingAutonomic.infectionRecoverySlow0To10?.toDouble(), input.agingAutonomic.fatigueAfterStress0To10?.toDouble(),
            input.agingAutonomic.exerciseRecovery0To10?.toDouble(), input.agingAutonomic.allergyIntensity0To10?.toDouble(),
            input.agingAutonomic.systolicBpMmHg?.toDouble(), input.agingAutonomic.diastolicBpMmHg?.toDouble(),
            input.agingAutonomic.restingPulseBpm?.toDouble(),
            input.gutNutritionHormone.refluxHeartburn0To10?.toDouble(),
            input.gutNutritionHormone.bloatingDyspepsia0To10?.toDouble(),
            input.gutNutritionHormone.dietDiversity0To10?.toDouble(),
            input.gutNutritionHormone.proteinIntakeEstimateG,
            input.gutNutritionHormone.bodyWeightKg,
            input.gutNutritionHormone.testosteroneNgDl
        )
        val present = values.count { it != null && it >= 0.0 }
        val impossiblePenalty = values.count { it != null && (it < 0.0 || it.isNaN() || it.isInfinite()) } * 10
        val symptomBonus = if (listOf(
                input.symptoms.allergyLike,
                input.symptoms.jointInflammatoryLike,
                input.symptoms.breathingDanger,
                input.symptoms.confusionOrFainting,
                input.symptoms.rapidSwelling,
                input.causeContext.majorEmotionalEvent,
                input.causeContext.panicOrRapidBreathing,
                input.causeContext.pollenDustExposure,
                input.causeContext.recentInfectionLike,
                input.causeContext.backOrDiscPain,
                input.agingAutonomic.frequentInfections,
                input.agingAutonomic.slowWoundHealing,
                input.agingAutonomic.foodSensitivityEpisode,
                input.agingAutonomic.seasonalPattern,
                input.agingAutonomic.allergyAfterStress,
                input.agingAutonomic.allergyAfterPoorSleep,
                input.agingAutonomic.dizzinessOnStanding,
                input.agingAutonomic.faintnessDuringAllergy,
                input.agingAutonomic.flushingOrWarmth,
                input.agingAutonomic.coldHandsFeet
            ).any { it }
        ) 12 else 0
        val cytokinePenalty = listOf(input.biomarkers.il6PgMl, input.biomarkers.tnfAlphaPgMl, input.biomarkers.il10PgMl, input.biomarkers.histamine).count { it == null } * 2
        return (present * 6 + symptomBonus - impossiblePenalty - cytokinePenalty).coerceIn(20, 100)
    }

    private fun type2AllergicAxisScore(input: CaseInput, evidence: MutableList<String>, cause: CausalOriginMap): Int {
        var score = 0
        val b = input.biomarkers
        if (input.symptoms.allergyLike) { score += 25; evidence += "Allergy-like symptoms selected." }
        if (cause.allergenExposure >= 35) { score += 12; evidence += "Allergen/environment driver supports Type-2 context." }
        if (cause.psychologicalStress >= 50 && input.symptoms.allergyLike) { score += 6; evidence += "Stress may amplify airway/allergy-like symptoms; not proof of root cause." }
        b.totalIgeIuMl?.let {
            when {
                it >= 300 -> { score += 30; evidence += "High total IgE entered: ${format(it)} IU/mL." }
                it >= 150 -> { score += 20; evidence += "Elevated total IgE entered: ${format(it)} IU/mL." }
                it >= 100 -> { score += 10; evidence += "Borderline/elevated total IgE entered: ${format(it)} IU/mL; lab ranges vary." }
            }
        }
        b.eosinophilsCellsUl?.let {
            when {
                it >= 700 -> { score += 30; evidence += "High eosinophils entered: ${format(it)} cells/µL." }
                it >= 500 -> { score += 20; evidence += "Elevated eosinophils entered: ${format(it)} cells/µL." }
                it >= 300 -> { score += 10; evidence += "Mild eosinophil elevation entered: ${format(it)} cells/µL; clinical context matters." }
            }
        }
        b.histamine?.let { if (it > 0) { score += 5; evidence += "Histamine value entered; interpretation is lab-specific and timing-sensitive." } }
        return score.coerceAtMost(100)
    }

    private fun mastCellAxisScore(input: CaseInput, evidence: MutableList<String>, cause: CausalOriginMap): Int {
        var score = 0
        if (input.symptoms.rapidSwelling) score += 35
        if (input.symptoms.allergyLike) score += 18
        if (cause.allergenExposure >= 30) score += 16
        input.biomarkers.histamine?.let { if (it > 0) score += 12 }
        return score.coerceAtMost(100)
    }

    private fun eosinophilAxisScore(input: CaseInput, evidence: MutableList<String>): Int {
        var score = 0
        input.biomarkers.eosinophilsCellsUl?.let {
            when {
                it >= 700 -> score += 60
                it >= 500 -> score += 45
                it >= 300 -> score += 25
            }
        }
        if (input.symptoms.allergyLike && score > 0) score += 15
        return score.coerceAtMost(100)
    }

    private fun tnfIl6InflammatoryAxisScore(input: CaseInput, evidence: MutableList<String>, cause: CausalOriginMap): Int {
        var score = 0
        val b = input.biomarkers
        if (input.symptoms.jointInflammatoryLike) { score += 25; evidence += "Joint pain/swelling or morning stiffness selected." }
        if (cause.infectionTrigger >= 35) { score += 8; evidence += "Recent infection-like context can trigger inflammatory marker interpretation." }
        b.crpMgL?.let {
            when {
                it >= 30 -> { score += 30; evidence += "High CRP entered: ${format(it)} mg/L." }
                it >= 10 -> { score += 18; evidence += "Elevated CRP entered: ${format(it)} mg/L." }
                it >= 5 -> { score += 10; evidence += "Mild CRP elevation entered: ${format(it)} mg/L." }
            }
        }
        b.esrMmH?.let { if (it >= 30) { score += 18; evidence += "Elevated ESR entered: ${format(it)} mm/h." } }
        b.il6PgMl?.let {
            when {
                it >= 50 -> { score += 24; evidence += "Marked IL-6 elevation entered: ${format(it)} pg/mL." }
                it >= 15 -> { score += 16; evidence += "IL-6 elevation entered: ${format(it)} pg/mL." }
            }
        }
        b.tnfAlphaPgMl?.let {
            when {
                it >= 50 -> { score += 20; evidence += "Marked TNF-α elevation entered: ${format(it)} pg/mL." }
                it >= 15 -> { score += 12; evidence += "TNF-α elevation entered: ${format(it)} pg/mL." }
            }
        }
        return score.coerceAtMost(100)
    }

    private fun hyperInflammatoryAxisScore(input: CaseInput, evidence: MutableList<String>, cause: CausalOriginMap): Int {
        var score = 0
        val b = input.biomarkers
        if (cause.infectionTrigger >= 45) score += 12
        input.temperatureC?.let { if (it >= 39.4) { score += 18; evidence += "High fever entered: ${format(it)} °C." } }
        b.crpMgL?.let { if (it >= 100) { score += 28; evidence += "Very high CRP entered: ${format(it)} mg/L." } }
        b.ferritinNgMl?.let { if (it >= 1000) { score += 25; evidence += "Very high ferritin entered: ${format(it)} ng/mL." } }
        b.il6PgMl?.let {
            when {
                it >= 150 -> { score += 30; evidence += "Very marked IL-6 elevation entered: ${format(it)} pg/mL." }
                it >= 80 -> { score += 20; evidence += "Marked IL-6 elevation entered: ${format(it)} pg/mL." }
            }
        }
        b.tnfAlphaPgMl?.let { if (it >= 100) { score += 18; evidence += "Very marked TNF-α elevation entered: ${format(it)} pg/mL." } }
        return score.coerceAtMost(100)
    }

    private fun regulatoryBrakeWeaknessScore(input: CaseInput, tnfIl6: Int, hyper: Int, stressAxis: Int, evidence: MutableList<String>): Int {
        var score = 0
        input.biomarkers.il10PgMl?.let {
            when {
                it > 0 && it < 3 -> { score += 28; evidence += "Low IL-10 entered; interpretation is lab-specific and not diagnostic." }
                it >= 3 && it < 7 -> { score += 12; evidence += "Lower IL-10 entered; interpretation is lab-specific." }
            }
        }
        if ((tnfIl6 >= 45 || hyper >= 45) && score > 0) score += 15
        if (stressAxis >= 60) { score += 8; evidence += "High stress/recovery load may weaken regulation or maintain symptoms; hypothesis-grade only." }
        return score.coerceAtMost(100)
    }

    private fun systemicDamageSignalScore(input: CaseInput, evidence: MutableList<String>): Int {
        var score = 0
        val b = input.biomarkers
        if (input.symptoms.breathingDanger) score += 25
        if (input.symptoms.confusionOrFainting) score += 25
        input.temperatureC?.let { if (it >= 39.4) score += 18 }
        b.crpMgL?.let { if (it >= 100) score += 24 else if (it >= 30) score += 12 }
        b.ferritinNgMl?.let { if (it >= 1000) score += 22 }
        b.il6PgMl?.let { if (it >= 80) score += 15 }
        return score.coerceAtMost(100)
    }

    private fun emergencyGateScore(input: CaseInput, evidence: MutableList<String>, hyper: Int, damage: Int, neuroGuarding: Int): Int {
        var score = 0
        val s = input.symptoms
        if (s.breathingDanger) { score += 45; evidence += "Red flag: breathing difficulty, chest pressure, or low oxygen concern." }
        if (s.confusionOrFainting) { score += 45; evidence += "Red flag: confusion, fainting, severe weakness, or cannot stay awake." }
        if (s.rapidSwelling) { score += 45; evidence += "Red flag: rapid swelling of lips, tongue, or throat." }
        if (input.causeContext.numbnessOrWeakness && neuroGuarding >= 45) { score += 15; evidence += "Back/disc neurological caution flag: numbness or weakness selected." }
        if (hyper >= 75) score += 20
        if (damage >= 70) score += 20
        return score.coerceAtMost(100)
    }

    private fun dominantCompartment(input: CaseInput, type2: Int, tnfIl6: Int, hyper: Int, mechanical: Int, neuro: Int): String {
        return when {
            input.symptoms.breathingDanger && hyper >= 40 -> "lung/systemic"
            input.symptoms.rapidSwelling -> "airway/allergic"
            input.symptoms.allergyLike && type2 >= tnfIl6 -> "sinus/airway/skin"
            input.symptoms.jointInflammatoryLike -> "joint/systemic"
            input.causeContext.backOrDiscPain && (mechanical >= 35 || neuro >= 35) -> "spine/nerve/muscle"
            hyper >= 55 -> "systemic"
            else -> "unspecified"
        }
    }

    private fun signalStrength(raw: Int, quality: Int): Int {
        val signal = (raw * 0.70 + quality * 0.30).roundToInt()
        return signal.coerceIn(15, 95)
    }

    private fun signalStrengthLabel(score: Int): String = when {
        score >= 75 -> "strong prototype signal"
        score >= 50 -> "moderate prototype signal"
        score >= 35 -> "limited prototype signal"
        else -> "low prototype signal"
    }

    private fun evidenceCompleteness(quality: Int): String = when {
        quality >= 80 -> "useful research entry but not clinically validated"
        quality >= 55 -> "partial"
        else -> "limited / many unknowns"
    }

    private fun allergyDiscussionPrompts() = listOf(
        "Could this pattern fit allergic rhinitis, asthma, medication/food reaction, infection, stress-amplified airway sensitivity, or another cause?",
        "Are timing, seasonality, trigger exposure, sleep/stress, and eosinophil/IgE values clinically meaningful?",
        "Are any additional tests or specialist review appropriate in this specific clinical context?"
    )

    private fun inflammatoryDiscussionPrompts() = listOf(
        "Are CRP/ESR/cytokine values persistent, repeated, and clinically meaningful?",
        "Do joint symptoms, morning stiffness, swelling, fatigue, fever, or weight loss justify further examination?",
        "Could infection, medication, injury, autoimmune disease, stress amplification, sleep debt, or another inflammatory condition explain the pattern?"
    )

    private fun systemicDiscussionPrompts() = listOf(
        "Is this a systemic inflammatory picture requiring timely clinical assessment?",
        "Are fever, ferritin, CRP, IL-6/TNF-α, oxygen symptoms, or organ-related symptoms present or worsening?",
        "What urgent causes must be ruled out before assuming allergy, stress, or autoimmune disease?"
    )

    private fun musculoskeletalDiscussionPrompts() = listOf(
        "Are back/disc-like symptoms mechanical, nerve-related, inflammatory, stress-amplified, or mixed?",
        "Are radiating pain, numbness, weakness, fever, trauma, bladder/bowel symptoms, or severe worsening present?",
        "Do stress, sleep debt, long sitting, lifting, or sudden twisting repeatedly precede flares?"
    )

    private fun emergencyDiscussionPrompts() = listOf(
        "Show the clinician the red flags selected and the exact entered lab/trigger values.",
        "Ask what immediate clinical assessment is needed; do not rely on app interpretation.",
        "If in Germany/EU and life-threatening symptoms are present, call 112."
    )

    private fun format(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else "%.1f".format(value)
}
