package com.immunesignal.app

/**
 * Hardcoded biological plausibility graph.
 *
 * v1.1 contract: this graph MUST stay in lock-step with
 * `app/src/main/assets/biological_plausibility_graph_v0.2.json`.
 * The JSON file is the canonical specification (auditable, diffable).
 * `BiologicalPlausibilityGraphTest.json_asset_matches_Kotlin_edges` enforces
 * this contract — if you edit one, edit the other and rerun the tests.
 *
 * Why hardcoded too: this object is called from `CausalityScorer` which has
 * no Android `Context`, so it cannot read assets at runtime without invasive
 * plumbing. The JSON-as-spec + test-as-enforcer pattern keeps a single
 * source of truth without surgery on every caller.
 */
object BiologicalPlausibilityGraph {
    private val knownPairs = mapOf(
        setOf("psychoneuroimmune_axis", "type2_allergy_axis") to "stress/autonomic signaling may modulate mast-cell and Type-2 reactivity",
        setOf("type2_allergy_axis", "autonomic_vascular_axis") to "histamine/mast-cell mediator release can plausibly affect vascular tone",
        setOf("gastric_acid_gut_axis", "type2_allergy_axis") to "gut barrier/reflux/microbiome context can interact with airway or allergy symptoms",
        setOf("testosterone_immune_axis", "type2_allergy_axis") to "sex-hormone signaling can plausibly modulate Type-2 inflammation",
        setOf("nutrition_protein_axis", "muscle_mass_reserve_axis") to "protein and muscle reserve affect recovery and inflammatory resilience",
        setOf("rna_transcriptomic_axis", "tnf_il6_autoimmune_axis") to "gene-expression states can expose inflammatory pathway activation",
        setOf("dna_genomic_axis", "aging_immune_axis") to "genetic/epigenetic signals can bridge aging clocks and immune remodeling",
        setOf("regulatory_brake_axis", "hyperinflammatory_axis") to "regulatory failure is a plausible brake-loss path in severe inflammation",
        setOf("psychomusculoskeletal_axis", "psychoneuroimmune_axis") to "sleep/stress/fear-avoidance can plausibly affect pain persistence and muscle guarding"
    )

    fun plausibilityScore(axes: List<String>): Pair<Int, List<String>> {
        val notes = mutableListOf<String>()
        var score = 20
        val axisSet = axes.toSet()
        knownPairs.forEach { (pair, mechanism) ->
            if (axisSet.containsAll(pair)) {
                score += 18
                notes += mechanism
            }
        }
        if (axes.any { it.contains("rna") || it.contains("dna") }) {
            score += 8
            notes += "omics axis can reveal hidden upstream state but needs curated datasets."
        }
        if (axes.size >= 3) {
            score += 8
            notes += "multi-axis bridge found; stronger as a hypothesis, weaker as proof until temporality is tested."
        }
        if (notes.isEmpty()) notes += "No known graph edge matched; keep as speculative until a mechanism is found."
        return score.coerceIn(0, 100) to notes.distinct()
    }
}
