package com.immunesignal.app

/**
 * v1.4.0: Dataset-first autonomous foraging models.
 *
 * These models are intentionally evidence-acquisition primitives, not new
 * biological axes. They make the APK show whether it actually attempted direct
 * dataset families instead of only writing another PubMed pivot.
 */
data class TestableHypothesisShard(
    val shardId: String,
    val label: String,
    val evidenceQuestion: String,
    val querySeeds: List<String>
)

data class DatasetSourceAttempt(
    val sourceFamily: String,
    val ncbiDb: String,
    val query: String,
    val attempted: Boolean,
    val idsFound: Int,
    val candidatesExtracted: Int,
    val status: String,
    val reason: String
)

data class DatasetForagingPass(
    val passId: String,
    val label: String,
    val status: String,
    val attempts: List<DatasetSourceAttempt>
)

data class DatasetForagingReport(
    val active: Boolean,
    val state: String,
    val evidenceMode: String,
    val sourceFamiliesAttempted: List<String>,
    val hypothesisShards: List<TestableHypothesisShard>,
    val passes: List<DatasetForagingPass>,
    val candidates: List<DatasetAccessionCandidate>,
    val parsedMetadata: List<ParsedDatasetMetadata> = emptyList(),
    val contrastiveReport: ContrastiveEvidenceReport = ContrastiveEvidenceReport.empty(),
    val evidenceHypergraph: List<EvidenceHypergraphNode> = emptyList(),
    val cumulativeEvidence: CumulativeEvidenceReport = CumulativeEvidenceReport.empty(),
    val blockedLearningReason: String,
    val nextAction: String
) {
    companion object {
        fun empty() = DatasetForagingReport(
            active = false,
            state = "NOT_RUN",
            evidenceMode = "PUBMED_METADATA_ONLY",
            sourceFamiliesAttempted = emptyList(),
            hypothesisShards = emptyList(),
            passes = emptyList(),
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            contrastiveReport = ContrastiveEvidenceReport.empty(),
            evidenceHypergraph = emptyList(),
            cumulativeEvidence = CumulativeEvidenceReport.empty(),
            blockedLearningReason = "Dataset-first forager did not run in this cycle.",
            nextAction = "Run an autonomous research cycle."
        )
    }
}
