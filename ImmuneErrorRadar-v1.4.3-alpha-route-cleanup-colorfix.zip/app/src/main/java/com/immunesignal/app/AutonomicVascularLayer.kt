package com.immunesignal.app

class AutonomicVascularLayer {
    fun profile(
        input: CaseInput,
        type2Axis: Int,
        mastCellAxis: Int,
        stressAxis: Int,
        evidence: MutableList<String>
    ): AutonomicVascularProfile {
        val a = input.agingAutonomic
        var sympatheticUp = 0
        var histamineDown = 0
        var instability = 0

        sympatheticUp += stressAxis / 2
        if (input.causeContext.panicOrRapidBreathing) sympatheticUp += 20
        a.restingPulseBpm?.let { if (it >= 100) sympatheticUp += 20 else if (it >= 85) sympatheticUp += 10 }
        a.systolicBpMmHg?.let { if (it >= 140) sympatheticUp += 16 else if (it >= 130) sympatheticUp += 8 }
        a.diastolicBpMmHg?.let { if (it >= 90) sympatheticUp += 12 }

        histamineDown += mastCellAxis / 3
        if (type2Axis >= 50) histamineDown += 10
        if (a.flushingOrWarmth) histamineDown += 18
        if (a.faintnessDuringAllergy) histamineDown += 18
        if ((input.biomarkers.histamine ?: 0.0) > 0.0) histamineDown += 10
        a.systolicBpMmHg?.let { if (it < 100) histamineDown += 15 }
        a.diastolicBpMmHg?.let { if (it < 60) histamineDown += 10 }

        if (a.dizzinessOnStanding) instability += 20
        if (a.faintnessDuringAllergy) instability += 20
        if (a.coldHandsFeet) instability += 8
        if (sympatheticUp >= 50 && histamineDown >= 40) instability += 18
        a.systolicBpMmHg?.let { if (it < 95 || it >= 150) instability += 10 }
        a.diastolicBpMmHg?.let { if (it < 55 || it >= 95) instability += 8 }

        if (sympatheticUp >= 55 && histamineDown >= 45) {
            evidence += "Autonomic-vascular tension detected: stress may push pressure upward while allergy/histamine-like signals may push vasodilation downward."
        } else if (histamineDown >= 55) {
            evidence += "Histamine/vasodilation-like pressure-down clue detected; only a research hypothesis unless repeated with timing."
        } else if (sympatheticUp >= 55) {
            evidence += "Sympathetic pressure-up clue detected through stress/pulse/BP context."
        }

        return AutonomicVascularProfile(
            sympatheticPressureUp = sympatheticUp.coerceIn(0, 100),
            histaminePressureDown = histamineDown.coerceIn(0, 100),
            bloodPressureInstability = instability.coerceIn(0, 100)
        )
    }
}
