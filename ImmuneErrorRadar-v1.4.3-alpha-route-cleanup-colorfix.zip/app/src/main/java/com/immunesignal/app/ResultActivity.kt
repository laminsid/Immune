package com.immunesignal.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ResultActivity : Activity() {
    companion object {
        const val EXTRA_CASE_JSON = "case_json"
    }

    private lateinit var record: JSONObject

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        val raw = intent.getStringExtra(EXTRA_CASE_JSON)
        if (raw.isNullOrBlank()) {
            finish()
            return
        }
        record = JSONObject(raw)
        display(record)
        findViewById<Button>(R.id.exportPdfButton).setOnClickListener { exportPdf() }
        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
    }

    private fun display(record: JSONObject) {
        val result = record.getJSONObject("result")
        val severity = result.optString("severity")
        val pattern = result.optString("pattern")
        val label = record.optString("label", "Case")
        val createdAt = record.optString("createdAtText", "")
        val signalPercent = result.optInt("signalStrengthPercent", 0)
        val signalLabel = result.optString("signalStrengthLabel", "prototype signal")
        val quality = result.optInt("dataQualityPercent", 0)
        val completeness = result.optString("evidenceCompleteness", "partial")
        val vector = result.optJSONObject("immuneStateVector") ?: JSONObject()
        val cause = result.optJSONObject("causalOriginMap") ?: JSONObject()
        val aging = result.optJSONObject("agingAutonomicMap") ?: JSONObject()
        val gut = result.optJSONObject("gutNutritionHormoneMap") ?: JSONObject()

        findViewById<TextView>(R.id.resultTitle).text = "Immune Error Radar"
        findViewById<TextView>(R.id.caseInfo).text = "$label • $createdAt"
        findViewById<TextView>(R.id.severityText).text = severity
        findViewById<TextView>(R.id.patternText).text = pattern
        findViewById<TextView>(R.id.signalText).text = "Signal strength: $signalLabel ($signalPercent%)\nData quality: $quality% • Evidence: $completeness"
        findViewById<TextView>(R.id.vectorText).text = renderVector(vector)
        findViewById<TextView>(R.id.causeText).text = renderCause(cause)
        findViewById<TextView>(R.id.agingAutonomicText).text = renderAgingAutonomic(aging)
        findViewById<TextView>(R.id.gutNutritionHormoneText).text = renderGutNutritionHormone(gut)

        val resultCard = findViewById<LinearLayout>(R.id.resultCard)
        when {
            severity.startsWith("RED") -> resultCard.setBackgroundResource(R.drawable.result_red)
            severity.startsWith("GREEN") -> resultCard.setBackgroundResource(R.drawable.result_green)
            else -> resultCard.setBackgroundResource(R.drawable.result_amber)
        }

        findViewById<TextView>(R.id.hypothesesText).text = block("Research hypotheses", result.optJSONArray("researchHypotheses"))
        findViewById<TextView>(R.id.actionsText).text = block("Safe next actions", result.optJSONArray("safeActions"))
        findViewById<TextView>(R.id.discussionText).text = block("Clinician / research discussion prompts", result.optJSONArray("discussionPrompts"))
        findViewById<TextView>(R.id.evidenceText).text = block("Immune evidence used", result.optJSONArray("evidence"))
        findViewById<TextView>(R.id.causeEvidenceText).text = block("Causal-origin evidence used", result.optJSONArray("causeEvidence"))
        findViewById<TextView>(R.id.notProvenText).text = block("What this does not prove", result.optJSONArray("notProven"))
    }

    private fun exportPdf() {
        try {
            val file = DoctorReportExporter.export(this, record)
            shareFile(file)
        } catch (e: Exception) {
            Toast.makeText(this, "PDF export failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareFile(file: File) {
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share research / clinician PDF"))
    }

    private fun renderVector(vector: JSONObject): String {
        return "Immune + Neuro/Musculoskeletal State Vector — research prototype\n" +
            "• Type-2 allergic axis: ${vector.optInt("type2AllergicAxis", 0)}/100\n" +
            "• Mast-cell axis: ${vector.optInt("mastCellAxis", 0)}/100\n" +
            "• Eosinophil axis: ${vector.optInt("eosinophilAxis", 0)}/100\n" +
            "• TNF/IL-6 inflammatory axis: ${vector.optInt("tnfIl6InflammatoryAxis", 0)}/100\n" +
            "• Hyper-inflammatory axis: ${vector.optInt("hyperInflammatoryAxis", 0)}/100\n" +
            "• Regulatory brake weakness: ${vector.optInt("regulatoryBrakeWeakness", 0)}/100\n" +
            "• Systemic damage signal: ${vector.optInt("systemicDamageSignal", 0)}/100\n" +
            "• Psychoneuroimmune stress axis: ${vector.optInt("psychoneuroimmuneStressAxis", 0)}/100\n" +
            "• Mechanical load axis: ${vector.optInt("mechanicalLoadAxis", 0)}/100\n" +
            "• Neuromuscular guarding axis: ${vector.optInt("neuroMuscularGuardingAxis", 0)}/100\n" +
            "• Immunosenescence axis: ${vector.optInt("immunosenescenceAxis", 0)}/100\n" +
            "• Inflammaging axis: ${vector.optInt("inflammagingAxis", 0)}/100\n" +
            "• Immune responsiveness axis: ${vector.optInt("immuneResponsivenessAxis", 0)}/100\n" +
            "• Sympathetic pressure-up axis: ${vector.optInt("sympatheticPressureUpAxis", 0)}/100\n" +
            "• Histamine pressure-down axis: ${vector.optInt("histaminePressureDownAxis", 0)}/100\n" +
            "• Blood-pressure instability axis: ${vector.optInt("bloodPressureInstabilityAxis", 0)}/100\n" +
            "• Gastric-acid dysregulation axis: ${vector.optInt("gastricAcidDysregulationAxis", 0)}/100\n" +
            "• Gut-barrier/microbiome axis: ${vector.optInt("gutBarrierMicrobiomeAxis", 0)}/100\n" +
            "• Nutrition/protein axis: ${vector.optInt("nutritionProteinAxis", 0)}/100\n" +
            "• Muscle-mass reserve axis: ${vector.optInt("muscleMassReserveAxis", 0)}/100\n" +
            "• Testosterone immune-modulation axis: ${vector.optInt("testosteroneImmuneModulationAxis", 0)}/100\n" +
            "• Dominant compartment: ${vector.optString("dominantCompartment", "unspecified")}"
    }

    private fun renderCause(cause: JSONObject): String {
        val ledger = cause.optJSONObject("ledger") ?: JSONObject()
        return "Causal Origin Map — hypothesis-grade only\n" +
            "• Dominant driver: ${cause.optString("dominantDriver", "mixed_or_unknown")}\n" +
            "• Allergen/environment: ${cause.optInt("allergenExposure", 0)}/100\n" +
            "• Psychological stress/amplification: ${cause.optInt("psychologicalStress", 0)}/100\n" +
            "• Sleep/recovery debt: ${cause.optInt("sleepRecoveryDebt", 0)}/100\n" +
            "• Infection trigger: ${cause.optInt("infectionTrigger", 0)}/100\n" +
            "• Mechanical load: ${cause.optInt("mechanicalLoad", 0)}/100\n" +
            "• Neuromuscular guarding: ${cause.optInt("neuroMuscularGuarding", 0)}/100\n" +
            "• Mixed/uncertain: ${cause.optInt("mixedUncertain", 0)}/100\n" +
            "\nInterpretation: ${cause.optString("interpretation", "Unknown")}\n" +
            "\nLedger:\n" +
            "• Temporal: ${ledger.optString("temporalEvidence", "Unknown")}\n" +
            "• Plausibility: ${ledger.optString("biologicalPlausibility", "Unknown")}\n" +
            "• Repeatability: ${ledger.optString("repeatability", "Unknown")}\n" +
            "• Caution: ${ledger.optString("caution", "Unknown")}"
    }


    private fun renderAgingAutonomic(aging: JSONObject): String {
        val hypotheses = aging.optJSONArray("competingHypotheses")
        val lines = mutableListOf<String>()
        lines += "Aging / Allergy / Autonomic Bridge — research hypotheses only"
        lines += "• Dominant pattern: ${aging.optString("dominantPattern", "mixed_or_unknown")}"
        lines += "• Allergy reactivity index: ${aging.optInt("allergyReactivityIndex", 0)}/100"
        lines += "• Aging load index: ${aging.optInt("agingLoadIndex", 0)}/100"
        lines += "• Immunosenescence axis: ${aging.optInt("immunosenescenceAxis", 0)}/100"
        lines += "• Inflammaging axis: ${aging.optInt("inflammagingAxis", 0)}/100"
        lines += "• Immune responsiveness axis: ${aging.optInt("immuneResponsivenessAxis", 0)}/100"
        lines += "• Resilience index: ${aging.optInt("resilienceIndex", 0)}/100"
        lines += "• Sympathetic pressure-up: ${aging.optInt("sympatheticPressureUp", 0)}/100"
        lines += "• Histamine pressure-down: ${aging.optInt("histaminePressureDown", 0)}/100"
        lines += "• BP instability: ${aging.optInt("bloodPressureInstability", 0)}/100"
        lines += "\nInterpretation: ${aging.optString("researchInterpretation", "Unknown")}"
        lines += "\nCompeting hypotheses:"
        if (hypotheses == null || hypotheses.length() == 0) {
            lines += "• No aging/autonomic hypotheses recorded."
        } else {
            for (i in 0 until hypotheses.length()) lines += "• ${hypotheses.optString(i)}"
        }
        return lines.joinToString("\n")
    }

    private fun renderGutNutritionHormone(gut: JSONObject): String {
        val hypotheses = gut.optJSONArray("competingHypotheses")
        val lines = mutableListOf<String>()
        lines += "Gut Acid / Nutrition / Muscle / Testosterone Bridge — research hypotheses only"
        lines += "• Dominant pattern: ${gut.optString("dominantPattern", "mixed_or_unknown")}"
        lines += "• Gastric-acid dysregulation axis: ${gut.optInt("gastricAcidDysregulationAxis", 0)}/100"
        lines += "• Gut-barrier / microbiome axis: ${gut.optInt("gutBarrierMicrobiomeAxis", 0)}/100"
        lines += "• Nutrition / protein axis: ${gut.optInt("nutritionProteinAxis", 0)}/100"
        lines += "• Muscle-mass reserve axis: ${gut.optInt("muscleMassReserveAxis", 0)}/100"
        lines += "• Testosterone immune-modulation axis: ${gut.optInt("testosteroneImmuneModulationAxis", 0)}/100"
        lines += "• Metabolic stress axis: ${gut.optInt("metabolicStressAxis", 0)}/100"
        lines += "\nInterpretation: ${gut.optString("researchInterpretation", "Unknown")}"
        lines += "\nCompeting hypotheses:"
        if (hypotheses == null || hypotheses.length() == 0) {
            lines += "• No gut/nutrition/hormone hypotheses recorded."
        } else {
            for (i in 0 until hypotheses.length()) lines += "• ${hypotheses.optString(i)}"
        }
        lines += "\nBoundary: This is a research bridge, not a diagnosis of stomach-acid disorder, hormone deficiency, microbiome disease, or nutrition status."
        return lines.joinToString("\n")
    }

    private fun block(title: String, values: JSONArray?): String {
        val lines = mutableListOf(title)
        if (values == null || values.length() == 0) {
            lines += "• No items recorded."
        } else {
            for (i in 0 until values.length()) {
                lines += "• ${values.optString(i)}"
            }
        }
        return lines.joinToString("\n")
    }
}
