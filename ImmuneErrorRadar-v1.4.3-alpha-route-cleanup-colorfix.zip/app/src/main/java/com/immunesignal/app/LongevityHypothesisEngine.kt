package com.immunesignal.app

class LongevityHypothesisEngine {
    fun generate(input: CaseInput, vector: ImmuneStateVector, aging: AgingAutonomicMap): List<String> {
        val out = mutableListOf<String>()
        if (aging.dominantPattern.contains("preserved_responsiveness")) {
            out += "Test allergy-aging inverse candidate: do repeated allergy spikes coexist with low inflammaging markers and fast recovery?"
        }
        if (aging.dominantPattern.contains("chronic_irritation")) {
            out += "Test chronic allergy burden candidate: do allergy spikes plus poor sleep/stress raise CRP/IL-6/TNF or fatigue over time?"
        }
        if (aging.bloodPressureInstability >= 45) {
            out += "Track BP/pulse before, during, and after allergy/stress episodes to test autonomic-mast-cell vascular instability."
        }
        if (aging.sympatheticPressureUp >= 50 && aging.histaminePressureDown >= 40) {
            out += "Compare two competing autonomic forces: stress/sympathetic pressure-up vs histamine-like vasodilation pressure-down."
        }
        if (vector.immunosenescenceAxis >= 45 && vector.immuneResponsivenessAxis <= 35) {
            out += "Low responsiveness + slow recovery/frequent infections may be an immunosenescence-like candidate; needs repeated observations."
        }
        if (input.agingAutonomic.allergyAfterPoorSleep || input.agingAutonomic.allergyAfterStress) {
            out += "Sleep/stress preceding allergy symptoms should be modeled as trigger timing, not mere correlation."
        }
        if (out.isEmpty()) {
            out += "Aging/allergy/autonomic layer has no strong pattern yet; repeat entries and add BP, pulse, recovery, allergy intensity, CRP/IL-6 where available."
        }
        return out.distinct()
    }
}
