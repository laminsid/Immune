package com.immunesignal.app

class AgingImmuneAxis {
    fun profile(
        input: CaseInput,
        type2Axis: Int,
        tnfIl6Axis: Int,
        hyperAxis: Int,
        regulatoryBrakeWeakness: Int,
        systemicDamageSignal: Int,
        evidence: MutableList<String>
    ): AgingImmuneProfile {
        val a = input.agingAutonomic
        val age = input.age ?: 0
        var immunosenescence = 0
        var inflammaging = 0
        var responsiveness = 0
        var resilience = 50

        if (age >= 70) immunosenescence += 25 else if (age >= 55) immunosenescence += 14 else if (age >= 40) immunosenescence += 6
        if (a.frequentInfections) { immunosenescence += 20; evidence += "Frequent infections selected; tracked as immunosenescence-like research clue, not proof." }
        a.infectionRecoverySlow0To10?.let { if (it >= 7) immunosenescence += 18 else if (it >= 4) immunosenescence += 8; resilience -= it * 3 }
        if (a.slowWoundHealing) { immunosenescence += 12; evidence += "Slow wound/skin recovery selected; hypothesis-grade aging/recovery clue." }

        input.biomarkers.crpMgL?.let { if (it >= 10) inflammaging += 25 else if (it >= 3) inflammaging += 12 }
        input.biomarkers.il6PgMl?.let { if (it >= 15) inflammaging += 20 else if (it >= 7) inflammaging += 8 }
        input.biomarkers.tnfAlphaPgMl?.let { if (it >= 15) inflammaging += 16 else if (it >= 7) inflammaging += 6 }
        if (hyperAxis >= 45) inflammaging += 15
        if (systemicDamageSignal >= 45) inflammaging += 12
        a.fatigueAfterStress0To10?.let { if (it >= 7) inflammaging += 10; resilience -= it * 2 }

        responsiveness += type2Axis / 3
        if ((input.biomarkers.totalIgeIuMl ?: 0.0) >= 100.0) responsiveness += 12
        if ((input.biomarkers.eosinophilsCellsUl ?: 0.0) >= 300.0) responsiveness += 10
        a.allergyIntensity0To10?.let { responsiveness += it * 4 }
        if (a.seasonalPattern) responsiveness += 8
        if (a.foodSensitivityEpisode) responsiveness += 6

        // Controlled responsiveness is treated differently from chronic inflammatory burden.
        if (responsiveness >= 45 && inflammaging < 35 && immunosenescence < 35) {
            resilience += 18
            evidence += "Allergy/reactivity with lower aging-load markers is kept as a preserved-responsiveness hypothesis, not a conclusion."
        }
        if (responsiveness >= 55 && inflammaging >= 45) {
            evidence += "Allergy/reactivity plus inflammatory load may indicate chronic immune irritation rather than protective responsiveness."
        }
        if (regulatoryBrakeWeakness >= 45) inflammaging += 8
        a.exerciseRecovery0To10?.let { resilience += it * 3 }
        input.causeContext.sleepQuality0To10?.let { resilience += (it - 5) * 4 }

        return AgingImmuneProfile(
            immunosenescenceAxis = immunosenescence.coerceIn(0, 100),
            inflammagingAxis = inflammaging.coerceIn(0, 100),
            immuneResponsivenessAxis = responsiveness.coerceIn(0, 100),
            agingLoadIndex = ((immunosenescence + inflammaging) / 2).coerceIn(0, 100),
            resilienceIndex = resilience.coerceIn(0, 100)
        )
    }
}
