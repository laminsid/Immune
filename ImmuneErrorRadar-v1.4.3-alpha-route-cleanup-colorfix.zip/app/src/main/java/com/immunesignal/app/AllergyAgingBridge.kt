package com.immunesignal.app

class AllergyAgingBridge {
    fun map(
        input: CaseInput,
        vector: ImmuneStateVector,
        aging: AgingImmuneProfile,
        vascular: AutonomicVascularProfile,
        evidence: MutableList<String>
    ): AgingAutonomicMap {
        val allergyReactivity = maxOf(
            vector.type2AllergicAxis,
            vector.mastCellAxis,
            vector.eosinophilAxis,
            input.agingAutonomic.allergyIntensity0To10?.times(10) ?: 0
        ).coerceIn(0, 100)
        val agingLoad = aging.agingLoadIndex
        val hypotheses = mutableListOf<String>()
        val pattern: String
        val interpretation: String

        when {
            allergyReactivity >= 55 && agingLoad < 35 && aging.resilienceIndex >= 55 -> {
                pattern = "allergy_high__aging_load_low__preserved_responsiveness_candidate"
                interpretation = "High allergy/reactivity with lower aging-load and fair recovery. Test as preserved immune responsiveness, not as anti-aging proof."
                hypotheses += "High allergic reactivity may sometimes mark preserved Type-2 responsiveness when inflammaging and slow-recovery signals are low."
            }
            allergyReactivity >= 55 && aging.inflammagingAxis >= 45 -> {
                pattern = "allergy_high__inflammaging_high__chronic_irritation_candidate"
                interpretation = "High allergy/reactivity plus inflammatory aging load. Test as chronic immune irritation rather than protective responsiveness."
                hypotheses += "Allergy spikes plus CRP/IL-6/TNF/sleep debt may reflect inflammatory-aging burden."
            }
            allergyReactivity < 30 && aging.immunosenescenceAxis >= 45 -> {
                pattern = "allergy_low__immunosenescence_high__weak_responsiveness_candidate"
                interpretation = "Low allergy reactivity with immunosenescence-like clues. Track infections, recovery speed, and longitudinal immune response."
                hypotheses += "Low reactivity plus frequent infections/slow recovery may represent weak immune responsiveness."
            }
            allergyReactivity < 35 && agingLoad < 35 -> {
                pattern = "quiet_resilient_candidate"
                interpretation = "Low allergy reactivity and low aging-load signal in entered data. Repeatability and missing markers matter."
                hypotheses += "Quiet immune state may be resilient or may simply be under-measured; repeat over time."
            }
            else -> {
                pattern = "mixed_aging_allergy_autonomic_pattern"
                interpretation = "Mixed allergy-aging-autonomic pattern. Needs repeated timing and more complete biomarkers."
                hypotheses += "The allergy-aging relation may be nonlinear: too low, controlled, and chronically high reactivity can mean different things."
            }
        }

        if (vascular.bloodPressureInstability >= 45) {
            hypotheses += "Stress/allergy/BP timing may reveal autonomic-mast-cell vascular interaction if repeated across episodes."
        }
        if (vascular.sympatheticPressureUp >= 50 && vascular.histaminePressureDown >= 40) {
            hypotheses += "Competing forces candidate: sympathetic pressure-up vs histamine/vasodilation pressure-down."
        }
        if (hypotheses.any { it.contains("preserved", ignoreCase = true) }) {
            evidence += "Allergy-aging inverse relation is stored only as a candidate pattern requiring longitudinal confirmation."
        }

        return AgingAutonomicMap(
            immunosenescenceAxis = aging.immunosenescenceAxis,
            inflammagingAxis = aging.inflammagingAxis,
            immuneResponsivenessAxis = aging.immuneResponsivenessAxis,
            allergyReactivityIndex = allergyReactivity,
            agingLoadIndex = agingLoad,
            resilienceIndex = aging.resilienceIndex,
            sympatheticPressureUp = vascular.sympatheticPressureUp,
            histaminePressureDown = vascular.histaminePressureDown,
            bloodPressureInstability = vascular.bloodPressureInstability,
            dominantPattern = pattern,
            researchInterpretation = interpretation,
            competingHypotheses = hypotheses.distinct()
        )
    }
}
