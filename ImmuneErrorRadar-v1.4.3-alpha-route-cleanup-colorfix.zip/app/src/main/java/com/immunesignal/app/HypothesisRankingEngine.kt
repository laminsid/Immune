package com.immunesignal.app

object HypothesisRankingEngine {
    fun rank(findings: List<ResearchFinding>): List<HypothesisRankCard> {
        if (findings.isEmpty()) return emptyList()
        val groups = findings.groupBy { HypothesisId.fromAxes(it.matchedAxes) }
        return groups.map { (id, items) ->
            val avgEvidence = items.map { it.evidence.evidenceQualityScore }.average().toInt()
            val avgCausality = items.map { it.causality.causalityScore }.average().toInt()
            val repeatability = items.maxOfOrNull { it.personalPattern.repeatedObservationCount } ?: 0
            val negativeStatus = items.firstOrNull()?.negativeControl?.status ?: "unknown"
            val novelty = items.map { it.noveltyScore }.average().toInt()
            val score = (avgEvidence * 0.32 + avgCausality * 0.34 + novelty * 0.18 + (repeatability * 12).coerceAtMost(60) * 0.16).toInt().coerceIn(0, 100)
            val status = when {
                score >= 72 && repeatability >= 3 && negativeStatus != "control_required_before_strong" -> "STRONG_SIGNAL"
                score >= 55 -> "WATCH"
                score >= 35 -> "WEAK"
                else -> "NOISE_OR_UNKNOWN"
            }
            val label = items.maxByOrNull { it.noveltyScore }?.bridgeSignal ?: id
            HypothesisRankCard(
                hypothesisId = id,
                label = label,
                status = status,
                overallScore = score,
                evidenceQualityScore = avgEvidence,
                causalityScore = avgCausality,
                personalRepeatability = repeatability,
                negativeControlStatus = negativeStatus,
                nextBestMeasurement = items.firstOrNull()?.personalPattern?.nextBestMeasurement ?: "Add repeated timestamped observations.",
                whyRanked = buildList {
                    add("Evidence quality average: $avgEvidence/100.")
                    add("Causality score average: $avgCausality/100.")
                    add("Personal repeatability count: $repeatability.")
                    add("Negative-control status: $negativeStatus.")
                    addAll(ContradictionFinder.contradictionSearchPrompts(items.first().matchedAxes, label).take(2))
                }.take(7)
            )
        }.sortedByDescending { it.overallScore }.take(8)
    }
}
