package com.immunesignal.app

class PsychomusculoskeletalLayer {
    fun mechanicalLoadAxis(input: CaseInput, evidence: MutableList<String>): Int {
        val c = input.causeContext
        var score = 0
        c.longSittingHours?.let {
            when {
                it >= 8 -> { score += 24; evidence += "Long sitting / static load entered: $it hours." }
                it >= 4 -> { score += 12; evidence += "Moderate static sitting load entered: $it hours." }
            }
        }
        if (c.heavyLifting) { score += 22; evidence += "Heavy lifting selected." }
        if (c.suddenTwist) { score += 18; evidence += "Sudden twist/load event selected." }
        if (c.backOrDiscPain) { score += 16; evidence += "Back/disc-like pain selected." }
        return score.coerceIn(0, 100)
    }

    fun neuroMuscularGuardingAxis(input: CaseInput, evidence: MutableList<String>): Int {
        val c = input.causeContext
        var score = 0
        if (c.backOrDiscPain && c.painWorseWithStress) { score += 28; evidence += "Back pain reported as worse with stress; treat as an amplification clue, not proof of cause." }
        if (c.radiatingLegPain) { score += 24; evidence += "Radiating leg pain selected; this is a clinical review flag." }
        if (c.numbnessOrWeakness) { score += 32; evidence += "Numbness/weakness selected; neurological red-flag review may be needed." }
        if ((c.stressToday0To10 ?: 0) >= 7 && c.backOrDiscPain) { score += 16; evidence += "High stress plus back pain may indicate muscle guarding / pain amplification context." }
        return score.coerceIn(0, 100)
    }
}
