package com.immunesignal.app

import java.util.Locale

/** v1.4.2: chooses direct dataset families before generic PubMed and prevents zero-route forager stalls. */
object DirectDatasetSourceRouter {
    data class SourceRoute(
        val sourceFamily: String,
        val ncbiDb: String,
        val priority: Int,
        val reason: String
    )

    fun shouldRunDatasetFirst(recentReports: List<String>, researchState: String, appliedPivot: PivotDecision, memory: PersistentFailureMemorySnapshot): Boolean {
        val text = (recentReports.take(5).joinToString(" ") + " " + researchState + " " + appliedPivot.pivotType + " " + appliedPivot.nextIntent + " " + appliedPivot.nextQuerySeed).lowercase(Locale.US)
        if (researchState == "DATASET_HUNT" || researchState == "STAGNATION_RECOVERY") return true
        if (text.contains("no_dataset_accession") || text.contains("no_evidence_object_no_upgrade")) return true
        if (text.contains("dataset candidates: 0") || text.contains("evidence objects: 0")) return true
        return memory.records.any { it.cooldownCyclesRemaining > 0 || it.timesFailed >= 2 }
    }

    fun routes(memory: PersistentFailureMemorySnapshot): List<SourceRoute> {
        val blocked = memory.records.filter { it.cooldownCyclesRemaining > 0 }.map { it.sourceFamily }.toSet()
        val routes = listOf(
            SourceRoute("GEO_GDS", "gds", 100, "Direct GEO/GDS dataset-source search for accessions and dataset metadata."),
            SourceRoute("SRA_PRJNA", "sra", 90, "Direct SRA/BioProject sequence-read search for PRJNA/SRP/SRA accessions."),
            SourceRoute("PUBMED_CONTRADICTION", "pubmed", 60, "Secondary contradiction/control search only after dataset routes are attempted."),
            SourceRoute("PUBMED_CONTROL", "pubmed", 55, "Secondary control/negative-control search around the best dataset shard.")
        )
        val available = routes.filterNot { blocked.contains(it.sourceFamily) }.sortedByDescending { it.priority }
        if (available.isNotEmpty()) return available
        // v1.4.2 path hardening: never let DATASET_HUNT become an empty route set.
        // If all normal families are cooling down, perform a controlled outcome-label
        // rewrite through GEO/GDS so the forager records a real source attempt instead
        // of silently returning zero attempts.
        return listOf(
            SourceRoute(
                "GEO_GDS_COOLDOWN_ESCAPE",
                "gds",
                40,
                "All normal direct dataset families are in cooldown; perform a controlled outcome-label rewrite to keep the evidence loop executable."
            )
        )
    }
}
