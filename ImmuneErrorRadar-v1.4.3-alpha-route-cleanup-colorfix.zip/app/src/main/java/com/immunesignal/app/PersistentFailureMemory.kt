package com.immunesignal.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** v1.4.0: persistent failure memory across cycles. */
data class PersistentFailureRecord(
    val failedQueryHash: String,
    val sourceFamily: String,
    val rootCause: String,
    val cooldownCyclesRemaining: Int,
    val lastAttemptedAtMillis: Long,
    val timesFailed: Int,
    val forcedNextSource: String
)

data class PersistentFailureMemorySnapshot(
    val records: List<PersistentFailureRecord>,
    val summary: String
) {
    companion object {
        fun empty() = PersistentFailureMemorySnapshot(emptyList(), "No persistent failure memory yet.")
    }
}

class PersistentFailureMemory(private val context: Context) {
    private val fileName = "immune_research_failure_memory.json"
    private val maxRecords = 80

    fun read(): PersistentFailureMemorySnapshot {
        val text = runCatching { context.openFileInput(fileName).bufferedReader().use { it.readText() } }.getOrNull().orEmpty()
        if (text.isBlank()) return PersistentFailureMemorySnapshot.empty()
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return PersistentFailureMemorySnapshot.empty()
        val arr = root.optJSONArray("records") ?: JSONArray()
        val records = (0 until arr.length()).mapNotNull { idx ->
            val obj = arr.optJSONObject(idx) ?: return@mapNotNull null
            PersistentFailureRecord(
                failedQueryHash = obj.optString("failedQueryHash"),
                sourceFamily = obj.optString("sourceFamily"),
                rootCause = obj.optString("rootCause"),
                cooldownCyclesRemaining = obj.optInt("cooldownCyclesRemaining", 0).coerceAtLeast(0),
                lastAttemptedAtMillis = obj.optLong("lastAttemptedAtMillis"),
                timesFailed = obj.optInt("timesFailed", 0),
                forcedNextSource = obj.optString("forcedNextSource")
            )
        }
        return PersistentFailureMemorySnapshot(records, root.optString("summary", "Persistent failure memory loaded."))
    }

    fun recordCycle(
        executedQueries: List<ResearchQuery>,
        learningOsReport: LearningOsReport,
        datasetForagingReport: DatasetForagingReport,
        evidenceObjects: List<EvidenceObject>
    ): PersistentFailureMemorySnapshot {
        val previous = read().records.map { it.copy(cooldownCyclesRemaining = (it.cooldownCyclesRemaining - 1).coerceAtLeast(0)) }.toMutableList()
        val rootCauses = learningOsReport.incident.rootCauses
        val hasEvidence = evidenceObjects.isNotEmpty() || datasetForagingReport.candidates.isNotEmpty()
        if (!hasEvidence && rootCauses.isNotEmpty()) {
            val family = if (datasetForagingReport.sourceFamiliesAttempted.isNotEmpty()) {
                datasetForagingReport.sourceFamiliesAttempted.first()
            } else {
                "broad_pubmed_mapping"
            }
            val signature = executedQueries.takeLast(6).joinToString("|") { it.id + ":" + it.query.take(80) }.hashCode().toString()
            val root = rootCauses.joinToString("+").take(160)
            val existingIndex = previous.indexOfFirst { it.failedQueryHash == signature || it.sourceFamily == family && it.rootCause == root }
            val updated = if (existingIndex >= 0) {
                val old = previous[existingIndex]
                old.copy(
                    cooldownCyclesRemaining = maxOf(old.cooldownCyclesRemaining, 5),
                    lastAttemptedAtMillis = System.currentTimeMillis(),
                    timesFailed = old.timesFailed + 1,
                    forcedNextSource = nextSourceFor(root)
                )
            } else {
                PersistentFailureRecord(
                    failedQueryHash = signature,
                    sourceFamily = family,
                    rootCause = root,
                    cooldownCyclesRemaining = 5,
                    lastAttemptedAtMillis = System.currentTimeMillis(),
                    timesFailed = 1,
                    forcedNextSource = nextSourceFor(root)
                )
            }
            if (existingIndex >= 0) previous[existingIndex] = updated else previous += updated
        }
        val trimmed = previous.sortedWith(compareByDescending<PersistentFailureRecord> { it.cooldownCyclesRemaining }.thenByDescending { it.lastAttemptedAtMillis }).take(maxRecords)
        val snapshot = PersistentFailureMemorySnapshot(
            records = trimmed,
            summary = if (trimmed.isEmpty()) "No active persistent failure blocks." else "${trimmed.count { it.cooldownCyclesRemaining > 0 }} active cooldown records; next forced source: ${trimmed.first().forcedNextSource}."
        )
        write(snapshot)
        return snapshot
    }

    private fun nextSourceFor(root: String): String = when {
        root.contains("NO_DATASET_ACCESSION") || root.contains("BROAD_QUERY") -> "GEO_GDS"
        root.contains("WRONG_VOCABULARY") -> "SRA_PRJNA"
        root.contains("NO_CONTRADICTION_SEARCH") -> "PUBMED_CONTRADICTION"
        root.contains("NO_CONTROL_SIGNAL") -> "PUBMED_CONTROL"
        else -> "GEO_GDS"
    }

    private fun write(snapshot: PersistentFailureMemorySnapshot) {
        val root = JSONObject()
            .put("summary", snapshot.summary)
            .put("records", JSONArray(snapshot.records.map { recordToJson(it) }))
        context.openFileOutput(fileName, Context.MODE_PRIVATE).bufferedWriter().use { it.write(root.toString()) }
    }

    companion object {
        fun memoryToJson(snapshot: PersistentFailureMemorySnapshot): JSONObject = JSONObject()
            .put("summary", snapshot.summary)
            .put("records", JSONArray(snapshot.records.map { recordToJson(it) }))

        private fun recordToJson(item: PersistentFailureRecord): JSONObject = JSONObject()
            .put("failedQueryHash", item.failedQueryHash)
            .put("sourceFamily", item.sourceFamily)
            .put("rootCause", item.rootCause)
            .put("cooldownCyclesRemaining", item.cooldownCyclesRemaining)
            .put("lastAttemptedAtMillis", item.lastAttemptedAtMillis)
            .put("timesFailed", item.timesFailed)
            .put("forcedNextSource", item.forcedNextSource)
    }
}
