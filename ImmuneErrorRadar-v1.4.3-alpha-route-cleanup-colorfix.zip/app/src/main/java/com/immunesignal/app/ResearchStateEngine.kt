package com.immunesignal.app

data class ResearchStates(val discoveryState: String, val biasRiskState: String)

object ResearchStateEngine {
    fun classify(card: HypothesisRankCard, gate: MinimumDataPackAssessment, findings: List<ResearchFinding>): ResearchStates {
        val discovery = when {
            card.status == "STRONG_SIGNAL" && gate.status == "PASS" && card.causalityScore >= 65 -> "Strong Candidate"
            card.overallScore >= 65 && gate.status != "BLOCKED" -> "Active"
            card.overallScore >= 40 -> "Early"
            else -> "Off"
        }
        val weakHuman = findings.isNotEmpty() && findings.none { it.evidence.speciesClass == "human" }
        val metadataCount = findings.count { it.sanityFlags.contains("METADATA_ONLY") || it.sanityFlags.contains("ABSTRACT_FETCH_FAILED") }
        val metadataHeavy = findings.isNotEmpty() && metadataCount * 2 >= findings.size
        val bias = when {
            gate.status == "BLOCKED" && card.status == "STRONG_SIGNAL" -> "Severe Bias"
            card.negativeControlStatus.contains("fail", ignoreCase = true) -> "Severe Bias"
            weakHuman || metadataHeavy || card.personalRepeatability == 0 -> "Alert"
            gate.status == "PARTIAL" -> "Watch"
            findings.isNotEmpty() && card.negativeControlStatus.contains("control", ignoreCase = true) -> "Watch"
            else -> "Normal"
        }
        return ResearchStates(discovery, bias)
    }

    fun summarize(objects: List<HypothesisObject>, mistakes: List<MistakeRiskCard>): ResearchStateSummary {
        if (objects.isEmpty()) return ResearchStateSummary.empty()
        val discovery = when {
            objects.any { it.discoveryState == "Strong Candidate" } -> "Strong Candidate"
            objects.any { it.discoveryState == "Active" } -> "Active"
            objects.any { it.discoveryState == "Early" } -> "Early"
            else -> "Off"
        }
        val bias = when {
            objects.any { it.biasRiskState == "Severe Bias" } -> "Severe Bias"
            objects.any { it.biasRiskState == "Alert" } -> "Alert"
            objects.any { it.biasRiskState == "Watch" } -> "Watch"
            else -> "Normal"
        }
        val top = objects.maxByOrNull { it.dataTrustScore + it.causalityScore } ?: objects.first()
        val risk = mistakes.firstOrNull()
        return ResearchStateSummary(
            discoveryState = discovery,
            biasRiskState = bias,
            nextEvidence = top.nextBestMeasurement,
            discoveryAction = "Track ${top.label.take(80)} with the minimum data pack before upgrading.",
            biasAlarm = if (risk != null) "$bias: ${risk.risk}; gate: ${risk.preventionGate}" else "$bias: no dominant mistake risk detected."
        )
    }

    /**
     * v1.4.3: Report-level path cleanup. The old generic "run another cycle"
     * handoff hid whether the next cycle should use dataset, contradiction, or
     * control evidence. This method rewrites the summary into an executable
     * research handoff while keeping discovery claims locked OFF when evidence is absent.
     */
    fun actionableSummary(
        base: ResearchStateSummary,
        datasetForagingReport: DatasetForagingReport,
        learningOsReport: LearningOsReport,
        runtimeStatus: ActiveResearchEngineStatus,
        discoveryReadiness: DiscoveryReadinessReport
    ): ResearchStateSummary {
        val firstGate = learningOsReport.preventiveGates.firstOrNull()
        val nextEvidence = when {
            datasetForagingReport.candidates.isNotEmpty() ->
                "Inspect dataset metadata: condition labels, outcome labels, controls, time-course, sample size, and license for ${datasetForagingReport.candidates.first().accession}."
            datasetForagingReport.active && firstGate != null ->
                "${firstGate.forcedNextIntent.uppercase()}: ${firstGate.action} Query seed: ${firstGate.forcedQuerySeed}"
            datasetForagingReport.active ->
                datasetForagingReport.nextAction
            firstGate != null ->
                "${firstGate.forcedNextIntent.uppercase()}: ${firstGate.action} Query seed: ${firstGate.forcedQuerySeed}"
            runtimeStatus.researchState == "DATASET_HUNT" ->
                "DATASET_HUNT: attempt GEO/GDS and SRA/PRJNA routes; then parse outcome/control/time-course labels."
            else -> base.nextEvidence
        }
        val action = when {
            discoveryReadiness.state == "OFF" ->
                "Discovery remains OFF. Do not upgrade hypotheses until an EvidenceObject or interpretable DatasetCandidate exists."
            datasetForagingReport.cumulativeEvidence.state != "OFF" ->
                "Use cumulative evidence score ${datasetForagingReport.cumulativeEvidence.score}/100 as research triage only; verify labels before modeling."
            else -> base.discoveryAction
        }
        val bias = when {
            learningOsReport.incident.rootCauses.isNotEmpty() ->
                "${base.biasRiskState}: ${learningOsReport.incident.rootCauses.joinToString(" + ")}; gates=${learningOsReport.preventiveGates.map { it.gateId }.joinToString(", ").ifBlank { "none" }}"
            else -> base.biasAlarm
        }
        return base.copy(
            discoveryState = discoveryReadiness.state.lowercase().replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
            nextEvidence = nextEvidence,
            discoveryAction = action,
            biasAlarm = bias
        )
    }

}
