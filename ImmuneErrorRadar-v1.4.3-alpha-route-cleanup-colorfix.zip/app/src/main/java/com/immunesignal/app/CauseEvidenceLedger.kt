package com.immunesignal.app

object CauseEvidenceLedgerBuilder {
    fun build(input: CaseInput, dominantDriver: String): CauseEvidenceLedger {
        val c = input.causeContext
        val temporal = when {
            c.recentInfectionLike -> "Recent infection-like context was entered before/around symptoms. Timing remains user-reported."
            c.majorEmotionalEvent -> "Major emotional event was entered before/around symptoms. Timing remains user-reported."
            c.heavyLifting || c.suddenTwist -> "Mechanical event was entered before/around back or pain symptoms. Timing remains user-reported."
            c.pollenDustExposure || c.coldAirExposure || c.smokeFragranceExposure || c.moldOrPetsExposure -> "Environmental exposure was entered before/around symptoms. Timing remains user-reported."
            else -> "Temporal evidence is weak or not entered."
        }
        val plausibility = when (dominantDriver) {
            "allergen_or_environment_dominant" -> "Biological plausibility: environmental exposures can align with Type-2 / airway-allergic signaling in susceptible contexts."
            "stress_amplified" -> "Biological plausibility: stress, sleep debt, sympathetic activation, and rapid breathing can amplify airway, inflammatory, and pain perception patterns."
            "infection_triggered" -> "Biological plausibility: infection-like context can trigger inflammatory marker changes and systemic symptoms."
            "mechanical_or_disc_load_dominant" -> "Biological plausibility: load, twisting, and static posture can align with musculoskeletal pain and disc-related patterns."
            "neuro_muscular_guarding_dominant" -> "Biological plausibility: stress, fear, guarding, sleep debt, and nerve symptoms can maintain or amplify pain patterns."
            else -> "Biological plausibility is mixed or incomplete; no single driver should be over-weighted."
        }
        val repeatability = "Repeatability is unknown in this single entry. The app needs multiple dated entries to test whether the same trigger pattern repeats."
        val caution = "Causal map is hypothesis-grade only. Psychological factors are treated as trigger/amplifier/maintainer candidates, not automatic root causes. Structural, infectious, allergic, and inflammatory causes may coexist."
        return CauseEvidenceLedger(temporal, plausibility, repeatability, caution)
    }
}
