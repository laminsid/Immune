package com.immunesignal.app

class CausalOriginEngine {
    fun map(input: CaseInput, stressAxis: Int, mechanicalAxis: Int, neuroGuardingAxis: Int, causeEvidence: MutableList<String>): CausalOriginMap {
        val c = input.causeContext
        var allergen = 0
        var infection = 0
        var sleepDebt = 0

        if (c.pollenDustExposure) { allergen += 28; causeEvidence += "Cause clue: pollen/dust exposure selected." }
        if (c.coldAirExposure) { allergen += 12; causeEvidence += "Cause clue: cold-air exposure selected." }
        if (c.smokeFragranceExposure) { allergen += 18; causeEvidence += "Cause clue: smoke/fragrance exposure selected." }
        if (c.moldOrPetsExposure) { allergen += 18; causeEvidence += "Cause clue: mold/pets exposure selected." }
        if (input.symptoms.allergyLike && allergen > 0) allergen += 16

        if (c.recentInfectionLike) { infection += 36; causeEvidence += "Cause clue: recent cold/flu/infection-like context selected." }
        input.temperatureC?.let { if (it >= 38.0) { infection += 18; causeEvidence += "Cause clue: fever entered with infection context relevance." } }

        c.sleepQuality0To10?.let {
            if (it <= 3) sleepDebt += 32 else if (it <= 5) sleepDebt += 18
        }
        if (sleepDebt > 0) causeEvidence += "Cause clue: sleep/recovery debt may weaken regulation or amplify symptoms."

        val psychological = stressAxis
        val mechanical = mechanicalAxis
        val neuro = neuroGuardingAxis
        val mixed = listOf(allergen, psychological, infection, sleepDebt, mechanical, neuro).count { it >= 25 } * 12

        val drivers = mapOf(
            "allergen_or_environment_dominant" to allergen,
            "stress_amplified" to psychological,
            "infection_triggered" to infection,
            "sleep_recovery_debt" to sleepDebt,
            "mechanical_or_disc_load_dominant" to mechanical,
            "neuro_muscular_guarding_dominant" to neuro
        )
        val dominant = drivers.maxByOrNull { it.value }?.takeIf { it.value >= 30 }?.key ?: "mixed_or_unknown"
        val interpretation = interpretationFor(dominant, drivers, mixed)
        val ledger = CauseEvidenceLedgerBuilder.build(input, dominant)

        return CausalOriginMap(
            dominantDriver = dominant,
            allergenExposure = allergen.coerceIn(0, 100),
            psychologicalStress = psychological.coerceIn(0, 100),
            sleepRecoveryDebt = sleepDebt.coerceIn(0, 100),
            infectionTrigger = infection.coerceIn(0, 100),
            mechanicalLoad = mechanical.coerceIn(0, 100),
            neuroMuscularGuarding = neuro.coerceIn(0, 100),
            mixedUncertain = mixed.coerceIn(0, 100),
            interpretation = interpretation,
            ledger = ledger
        )
    }

    private fun interpretationFor(dominant: String, drivers: Map<String, Int>, mixed: Int): String {
        val second = drivers.toList().sortedByDescending { it.second }.drop(1).firstOrNull()
        val secondText = second?.takeIf { it.second >= 25 }?.let { " Secondary candidate: ${it.first} (${it.second}/100)." } ?: ""
        val base = when (dominant) {
            "allergen_or_environment_dominant" -> "Likely exposure/allergen-dominant trigger map."
            "stress_amplified" -> "Likely stress-amplified pattern; not proof that stress is the root cause."
            "infection_triggered" -> "Likely infection-triggered inflammatory context."
            "sleep_recovery_debt" -> "Likely recovery/sleep-debt amplifier."
            "mechanical_or_disc_load_dominant" -> "Likely mechanical-load or disc-context dominant map."
            "neuro_muscular_guarding_dominant" -> "Likely neuromuscular guarding or pain-amplification context."
            else -> "Mixed or unknown origin map; evidence is insufficient for a dominant driver."
        }
        return base + secondText + if (mixed >= 36) " Multiple drivers are active; treat as network causality." else ""
    }
}
