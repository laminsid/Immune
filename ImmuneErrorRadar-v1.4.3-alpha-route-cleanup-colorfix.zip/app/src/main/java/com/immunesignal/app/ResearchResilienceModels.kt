package com.immunesignal.app

/**
 * v1.3.3: Autonomous Resilience Patch.
 * These models make failure useful: a no-result cycle becomes a pivot decision,
 * not an empty report.
 */
data class FailureSignature(
    val newUsefulSources: Int,
    val repeatedSkipped: Int,
    val metadataOnlyRatio: Double,
    val sameLaneFailureCount: Int,
    val abstractFetchFailures: Int,
    val datasetCandidateCount: Int,
    val hypothesisDeltaCount: Int,
    val failedLane: String
)

data class PivotDecision(
    val pivotType: String,
    val reason: String,
    val nextIntent: String,
    val nextQuerySeed: String,
    val priority: Int
) {
    companion object {
        fun none() = PivotDecision(
            pivotType = "NO_PIVOT",
            reason = "Cycle produced useful delta or no recovery condition was triggered.",
            nextIntent = "continue_current_autonomous_plan",
            nextQuerySeed = "",
            priority = 0
        )
    }
}

data class QueryEvolutionState(
    val hypothesisId: String,
    val currentStage: String,
    val nextStage: String,
    val evolvedQuery: String,
    val reason: String
)

data class AbstractCandidateScore(
    val pmid: String,
    val score: Int,
    val reasons: List<String>
)

data class DatasetCandidateV133(
    val datasetId: String,
    val source: String,
    val species: String,
    val sampleSizeHint: String,
    val dataType: String,
    val conditionHint: String,
    val outcomeLabelsHint: String,
    val timeCourseHint: String,
    val priorityScore: Int,
    val whyUseful: String,
    val nextVerificationStep: String,
    val sourceTitle: String,
    val sourceUrl: String
)

data class ResearchReportV3(
    val cycleResult: String,
    val newUsefulLead: String,
    val hypothesisChanged: String,
    val whyItMatters: String,
    val nextAutonomousMove: String,
    val doNotBelieveYet: String,
    val technicalPointer: String,
    // v1.3.3 hard lock fields: every intelligent report must expose these four sections.
    val hypothesis: String = "No hypothesis evaluated yet.",
    val supportingEvidence: String = "No supporting evidence evaluated yet.",
    val counterEvidenceOrContradiction: String = "No contradiction search evaluated yet.",
    val whatWeDoNotBelieveYet: String = "No hypothesis is proven.",
    val integrityStatus: String = "UNVALIDATED",
    val integrityFailures: List<String> = emptyList()
) {
    companion object {
        fun empty() = ResearchReportV3(
            cycleResult = "No cycle yet",
            newUsefulLead = "Run autonomous research.",
            hypothesisChanged = "None",
            whyItMatters = "No evidence evaluated yet.",
            nextAutonomousMove = "Start Explore + Deepen + Challenge cycle.",
            doNotBelieveYet = "No hypothesis is proven.",
            technicalPointer = "Full technical report contains locks, bias, and evidence details.",
            hypothesis = "No hypothesis evaluated yet.",
            supportingEvidence = "No supporting evidence evaluated yet.",
            counterEvidenceOrContradiction = "No contradiction search evaluated yet.",
            whatWeDoNotBelieveYet = "No hypothesis is proven.",
            integrityStatus = "PASS",
            integrityFailures = emptyList()
        )
    }
}
