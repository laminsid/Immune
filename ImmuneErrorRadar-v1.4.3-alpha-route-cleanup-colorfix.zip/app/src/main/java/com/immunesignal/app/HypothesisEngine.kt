package com.immunesignal.app

class HypothesisEngine {
    fun generate(input: CaseInput, vector: ImmuneStateVector, cause: CausalOriginMap): List<String> {
        val hypotheses = mutableListOf<String>()
        if (vector.type2AllergicAxis >= 45) {
            hypotheses += "Research hypothesis: Type-2 / mast-cell / eosinophil axis may be dominant; test whether exposures and symptoms repeat seasonally or after specific triggers."
        }
        if (vector.tnfIl6InflammatoryAxis >= 45) {
            hypotheses += "Research hypothesis: TNF/IL-6 inflammatory axis may be active; compare repeated CRP/ESR/cytokine timing with joint/systemic symptoms."
        }
        if (vector.regulatoryBrakeWeakness >= 35) {
            hypotheses += "Research hypothesis: regulatory brake weakness may coexist with inflammatory activation; track whether recovery is delayed after triggers."
        }
        if (vector.hyperInflammatoryAxis >= 45 || vector.systemicDamageSignal >= 45) {
            hypotheses += "Research hypothesis: systemic inflammatory pattern requires real-world clinical context; do not interpret as cytokine storm without clinical confirmation."
        }
        if (cause.psychologicalStress >= 45) {
            hypotheses += "Research hypothesis: psychological load may act as amplifier/maintainer; compare stress/sleep spikes against airway, sinus, joint, or pain flares."
        }
        if (cause.mechanicalLoad >= 40 || cause.neuroMuscularGuarding >= 40) {
            hypotheses += "Research hypothesis: musculoskeletal load plus neuromuscular guarding may explain back/disc-like symptoms; separate structural load, nerve flags, and stress amplification."
        }
        if (cause.infectionTrigger >= 35) {
            hypotheses += "Research hypothesis: recent infection may be a trigger for inflammatory activation; compare fever, CRP, fatigue, airway/lung symptoms, and recovery curve."
        }
        if (hypotheses.isEmpty()) {
            hypotheses += "Research hypothesis: current entry is low-signal or incomplete; collect repeated entries with trigger timing, sleep, stress, exposures, and labs."
        }
        hypotheses += TriggerTimeline.compactSummary(input)
        return hypotheses.distinct()
    }
}
