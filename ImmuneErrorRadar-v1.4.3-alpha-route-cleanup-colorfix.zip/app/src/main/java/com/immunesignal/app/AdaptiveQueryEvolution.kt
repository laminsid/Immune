package com.immunesignal.app

import java.util.Locale

object AdaptiveQueryEvolution {
    private val stages = listOf("BROAD", "MECHANISM", "CONTRADICTION", "DATASET", "OMICS", "TIME_COURSE", "OUTCOME_LABELS")

    fun evolve(seed: String, pivot: PivotDecision, activeAxes: List<String>): QueryEvolutionState {
        val current = inferStage(seed, pivot)
        val next = when (pivot.nextIntent) {
            "dataset_hunting", "dataset_verification" -> "DATASET"
            "selective_abstract_review" -> "MECHANISM"
            "contradiction_search" -> "CONTRADICTION"
            "evidence_lane_rotation" -> "CONTRADICTION"
            else -> stages.getOrElse((stages.indexOf(current) + 1).coerceAtLeast(1)) { "DATASET" }
        }
        val axisTerms = activeAxes.take(3).joinToString(" ").replace("_", " ")
        val evolved = buildString {
            append("(")
            append(seed.ifBlank { pivot.nextQuerySeed.ifBlank { "immune response" } })
            append(") AND ")
            append(stageTerms(next))
            if (axisTerms.isNotBlank()) append(" AND ($axisTerms)")
        }
        return QueryEvolutionState(
            hypothesisId = "global_autonomous_frontier",
            currentStage = current,
            nextStage = next,
            evolvedQuery = evolved,
            reason = pivot.reason
        )
    }

    private fun inferStage(seed: String, pivot: PivotDecision): String {
        val t = (seed + " " + pivot.nextIntent + " " + pivot.pivotType).lowercase(Locale.US)
        return when {
            t.contains("dataset") || t.contains("gse") || t.contains("geo") || t.contains("immport") -> "DATASET"
            t.contains("contradict") || t.contains("heterogeneity") || t.contains("no association") -> "CONTRADICTION"
            t.contains("rna") || t.contains("single-cell") || t.contains("omics") -> "OMICS"
            t.contains("time") || t.contains("longitudinal") -> "TIME_COURSE"
            t.contains("outcome") || t.contains("severity") || t.contains("recovery") -> "OUTCOME_LABELS"
            t.contains("mechanism") || t.contains("pathway") -> "MECHANISM"
            else -> "BROAD"
        }
    }

    private fun stageTerms(stage: String): String = when (stage) {
        "MECHANISM" -> "(mechanism OR pathway OR cytokine OR immune regulation)"
        "CONTRADICTION" -> "(contradictory OR conflicting results OR heterogeneity OR no association OR nonresponse)"
        "DATASET" -> "(GSE OR GEO OR ImmPort OR SDY OR dataset OR cohort)"
        "OMICS" -> "(RNA-seq OR transcriptomic OR single-cell OR scRNA OR epigenetic)"
        "TIME_COURSE" -> "(time course OR longitudinal OR early response OR delayed response)"
        "OUTCOME_LABELS" -> "(severity OR recovery OR deterioration OR outcome OR viral load)"
        else -> "(human OR patient OR cohort OR dataset)"
    }
}
