package com.immunesignal.app

import kotlin.math.roundToInt

/**
 * v1.3 Global Immune Dataset Intelligence Engine.
 *
 * This layer deliberately builds on the existing Research Autopilot and v1.2
 * lock system. It does not add a heavy ML model and it does not create a
 * personal-tracking pathway. Its job is to translate public literature findings
 * into global research objects:
 * - candidate datasets/cohorts to inspect,
 * - immune-axis summaries,
 * - trigger -> response -> outcome edges,
 * - global hypothesis leads,
 * - antiviral-response research notes.
 */
object GlobalImmuneIntelligenceEngine {

    fun build(
        findings: List<ResearchFinding>,
        importedSignals: List<ImportedReportSignal>,
        steering: ResearchSteeringProfile?
    ): GlobalImmuneIntelligenceReport {
        val datasetCandidates = DatasetDiscoveryEngine.candidates(findings, importedSignals)
        val axisMap = ImmuneAxisMapper.summarize(findings, importedSignals)
        val edges = TriggerResponseGraphBuilder.edges(findings, axisMap)
        val hypotheses = GlobalHypothesisLedgerBuilder.build(edges, datasetCandidates, findings)
        val antiviral = PathogenResponseComparator.notes(findings, edges, hypotheses)
        val nextDataset = chooseNextDatasetNeed(hypotheses, datasetCandidates, findings)
        val action = chooseGlobalDiscoveryAction(hypotheses, datasetCandidates, steering)
        val biasAlarm = chooseGlobalBiasAlarm(hypotheses, datasetCandidates, findings)
        return GlobalImmuneIntelligenceReport(
            mode = "global_dataset_intelligence_v1.3",
            datasetCandidates = datasetCandidates,
            axisMap = axisMap,
            triggerResponseEdges = edges,
            globalHypotheses = hypotheses,
            antiviralResponseNotes = antiviral,
            nextGlobalDatasetNeeded = nextDataset,
            globalDiscoveryAction = action,
            globalBiasAlarm = biasAlarm
        )
    }

    private fun chooseNextDatasetNeed(
        hypotheses: List<GlobalHypothesisLead>,
        datasets: List<PublicDatasetCandidate>,
        findings: List<ResearchFinding>
    ): String {
        hypotheses.firstOrNull { it.status == "ACTIVE_CANDIDATE" || it.status == "WATCH" }?.let {
            return it.nextDatasetNeeded
        }
        if (datasets.none { it.dataType.contains("RNA", ignoreCase = true) }) {
            return "Find human RNA-seq or single-cell immune datasets with clear condition and outcome labels."
        }
        if (findings.none { it.matchedAxes.contains("interferon_antiviral_axis") }) {
            return "Find antiviral-response datasets with interferon timing, viral load, and recovery vs deterioration outcomes."
        }
        return "Find longitudinal human immune datasets where trigger, response axis, tissue outcome, and recovery are all time-stamped."
    }

    private fun chooseGlobalDiscoveryAction(
        hypotheses: List<GlobalHypothesisLead>,
        datasets: List<PublicDatasetCandidate>,
        steering: ResearchSteeringProfile?
    ): String {
        val steered = steering?.variables?.take(5)?.joinToString(", ").orEmpty()
        val prefix = if (steered.isNotBlank()) "For steered variables ($steered), " else ""
        val top = hypotheses.maxByOrNull { it.dataTrustScore + (it.evidenceScore10 * 10).roundToInt() }
        if (top != null) {
            return prefix + "prioritize '${top.hypothesisId}' and collect the missing dataset: ${top.nextDatasetNeeded}"
        }
        if (datasets.isNotEmpty()) {
            return prefix + "screen top dataset candidates for human samples, omics depth, and outcome labels before building any model."
        }
        return prefix + "run dataset-discovery queries before adding new biological axes or ML components."
    }

    private fun chooseGlobalBiasAlarm(
        hypotheses: List<GlobalHypothesisLead>,
        datasets: List<PublicDatasetCandidate>,
        findings: List<ResearchFinding>
    ): String {
        val animalHeavy = findings.isNotEmpty() && findings.count { it.evidence.speciesClass != "human" } > findings.size / 2
        val noDatasets = datasets.isEmpty()
        val lowTrust = hypotheses.any { it.dataTrustScore < 55 && it.status != "NOISE" }
        return when {
            noDatasets -> "Watch: no explicit dataset candidate yet; do not infer global immune rules from literature titles alone."
            animalHeavy -> "Alert: evidence is animal/cell-heavy; separate mechanism plausibility from human immune behavior."
            lowTrust -> "Watch: at least one global hypothesis has weak trust; require cross-source human dataset confirmation."
            else -> "Normal: global hypotheses remain gated by dataset quality, species separation, and contradiction search."
        }
    }
}

object DatasetDiscoveryEngine {
    fun candidates(findings: List<ResearchFinding>, importedSignals: List<ImportedReportSignal>): List<PublicDatasetCandidate> {
        val fromFindings = findings.mapNotNull { finding -> fromFinding(finding) }
        val fromImports = importedSignals.mapNotNull { signal -> fromImportedSignal(signal) }
        return (fromFindings + fromImports)
            .distinctBy { it.source + ":" + it.datasetId }
            .sortedByDescending { it.qualityScore }
            .take(12)
    }

    private fun fromFinding(finding: ResearchFinding): PublicDatasetCandidate? {
        val text = (finding.title + " " + finding.bridgeSignal + " " + finding.whyItMatters).lowercase()
        val datasetLike = listOf("dataset", "cohort", "rna-seq", "single-cell", "gene expression", "gse", "immport", "atlas", "transcriptomic", "proteomic", "longitudinal")
            .any { text.contains(it) } || finding.matchedAxes.any { it == "rna_transcriptomic_axis" || it == "dna_genomic_axis" || it == "interferon_antiviral_axis" }
        if (!datasetLike) return null
        val dataType = when {
            text.contains("single-cell") || text.contains("scrna") -> "single-cell RNA / cell-state"
            text.contains("rna-seq") || text.contains("transcript") || finding.matchedAxes.contains("rna_transcriptomic_axis") -> "RNA / transcriptomic"
            text.contains("methylation") || text.contains("genomic") || finding.matchedAxes.contains("dna_genomic_axis") -> "DNA / epigenetic"
            text.contains("cytokine") || text.contains("proteomic") -> "cytokine / protein"
            else -> "literature-indexed dataset candidate"
        }
        val condition = inferCondition(finding.matchedAxes, text)
        val quality = DatasetQualityScorer.score(finding, dataType)
        return PublicDatasetCandidate(
            datasetId = "PubMed:${finding.sourceId}",
            source = finding.source,
            condition = condition,
            dataType = dataType,
            speciesClass = finding.evidence.speciesClass,
            sampleHint = sampleHint(text),
            matchedAxes = finding.matchedAxes,
            qualityScore = quality,
            accessNote = "Candidate only: inspect paper/full text for downloadable dataset accession (GEO/ImmPort/HCA/Open Targets).",
            url = finding.url
        )
    }

    private fun fromImportedSignal(signal: ImportedReportSignal): PublicDatasetCandidate? {
        val text = (signal.title + " " + signal.preview + " " + signal.extractedKeywords.joinToString(" ")).lowercase()
        val looksLikeDataset = listOf("dataset", "gse", "immport", "cohort", "rna-seq", "single-cell", "sample", "patient")
            .any { text.contains(it) }
        if (!looksLikeDataset) return null
        return PublicDatasetCandidate(
            datasetId = signal.reportId,
            source = "ImportedReport",
            condition = inferCondition(signal.matchedAxes, text),
            dataType = when {
                text.contains("single-cell") -> "single-cell RNA / cell-state"
                text.contains("rna") || signal.matchedAxes.contains("rna_transcriptomic_axis") -> "RNA / transcriptomic"
                text.contains("dna") || signal.matchedAxes.contains("dna_genomic_axis") -> "DNA / epigenetic"
                else -> "manual dataset candidate"
            },
            speciesClass = if (text.contains("human") || text.contains("patient")) "human" else "unknown",
            sampleHint = sampleHint(text),
            matchedAxes = signal.matchedAxes,
            qualityScore = 45 + signal.matchedAxes.size.coerceAtMost(4) * 5,
            accessNote = "Imported note: verify source, license, sample size, and accession before use.",
            url = "local-import:${signal.reportId}"
        )
    }

    private fun inferCondition(axes: List<String>, text: String): String = when {
        axes.contains("interferon_antiviral_axis") || text.contains("virus") || text.contains("viral") -> "viral response / antiviral immunity"
        axes.contains("type2_allergy_axis") && text.contains("asthma") -> "asthma / allergic airway"
        axes.contains("type2_allergy_axis") -> "allergy / Type-2 response"
        axes.contains("tnf_il6_autoimmune_axis") -> "autoimmune inflammatory / RA-like"
        axes.contains("hyperinflammatory_axis") -> "hyperinflammatory / ARDS-like"
        axes.contains("aging_immune_axis") -> "aging / inflammaging"
        axes.contains("gastric_acid_gut_axis") || axes.contains("gut_barrier_microbiome_axis") -> "gut-immune interaction"
        else -> "cross-condition immune response"
    }

    private fun sampleHint(text: String): String {
        val nRegex = Regex("""\b(n\s*=\s*|sample[s]?\s*=\s*|patients?\s*=\s*)(\d{2,5})""", RegexOption.IGNORE_CASE)
        val hit = nRegex.find(text)
        return if (hit != null) "possible n=${hit.groupValues[2]}" else "sample size not extracted"
    }
}

object DatasetQualityScorer {
    fun score(finding: ResearchFinding, dataType: String): Int {
        var score = 30
        if (finding.evidence.speciesClass == "human") score += 18
        if (finding.evidence.studyDesign.contains("cohort", ignoreCase = true)) score += 10
        if (finding.evidence.studyDesign.contains("trial", ignoreCase = true)) score += 12
        if (dataType.contains("RNA", ignoreCase = true) || dataType.contains("single-cell", ignoreCase = true)) score += 12
        if (finding.matchedAxes.contains("interferon_antiviral_axis")) score += 8
        if (finding.matchedAxes.contains("regulatory_brake_axis")) score += 6
        if (finding.sanityFlags.contains("METADATA_ONLY")) score -= 15
        if (finding.sanityFlags.contains("ABSTRACT_FETCH_FAILED")) score -= 10
        return score.coerceIn(0, 100)
    }
}

object ImmuneAxisMapper {
    fun summarize(findings: List<ResearchFinding>, importedSignals: List<ImportedReportSignal>): List<ImmuneAxisSummary> {
        val evidenceByAxis = mutableMapOf<String, MutableList<String>>()
        findings.forEach { finding ->
            finding.matchedAxes.forEach { axis -> evidenceByAxis.getOrPut(axis) { mutableListOf() }.add(finding.title.take(120)) }
        }
        importedSignals.forEach { signal ->
            signal.matchedAxes.forEach { axis -> evidenceByAxis.getOrPut(axis) { mutableListOf() }.add("Imported: ${signal.title.take(100)}") }
        }
        return AxisMatcher.knownAxes().mapNotNull { axis ->
            val evidence = evidenceByAxis[axis].orEmpty()
            if (evidence.isEmpty()) return@mapNotNull null
            ImmuneAxisSummary(
                axis = axis,
                count = evidence.size,
                role = roleFor(axis),
                topEvidence = evidence.first()
            )
        }.sortedByDescending { it.count }.take(15)
    }

    private fun roleFor(axis: String): String = when (axis) {
        "type2_allergy_axis" -> "false-alarm / Type-2 allergic response"
        "interferon_antiviral_axis" -> "early antiviral detection and viral-control axis"
        "tnf_il6_autoimmune_axis" -> "inflammatory amplification / autoimmune-like axis"
        "regulatory_brake_axis" -> "immune braking and resolution control"
        "hyperinflammatory_axis" -> "runaway inflammatory escalation"
        "tcell_activation_axis" -> "cellular adaptive antiviral / autoimmune response"
        "bcell_antibody_axis" -> "antibody / humoral memory response"
        "tissue_damage_axis" -> "host tissue injury / containment cost"
        "resolution_recovery_axis" -> "shutdown, repair, and return-to-baseline"
        "rna_transcriptomic_axis" -> "active immune-state expression readout"
        "dna_genomic_axis" -> "longer-term susceptibility or epigenetic context"
        else -> "modifier or context axis"
    }
}

object TriggerResponseGraphBuilder {
    fun edges(findings: List<ResearchFinding>, axisMap: List<ImmuneAxisSummary>): List<TriggerResponseEdge> {
        val axes = axisMap.map { it.axis }.toSet()
        val out = mutableListOf<TriggerResponseEdge>()
        fun addIf(condition: Boolean, trigger: String, axis: String, outcome: String, rationale: String) {
            if (!condition) return
            val evidence = evidenceFor(axis, findings)
            val status = when {
                evidence >= 70 -> "ACTIVE_CANDIDATE"
                evidence >= 50 -> "WATCH"
                else -> "EARLY"
            }
            out += TriggerResponseEdge(trigger, axis, outcome, evidence, status, rationale)
        }
        addIf(axes.contains("type2_allergy_axis"), "allergen / harmless exposure", "type2_allergy_axis", "airway/skin/gut irritation", "Maps false-alarm immune response through IgE, mast-cell, histamine, and eosinophil signals.")
        addIf(axes.contains("interferon_antiviral_axis"), "virus / variant exposure", "interferon_antiviral_axis", "viral control vs delayed escalation", "Tests whether early antiviral signaling separates recovery from hyperinflammatory deterioration.")
        addIf(axes.contains("tnf_il6_autoimmune_axis"), "self-antigen / chronic inflammatory stimulus", "tnf_il6_autoimmune_axis", "joint/systemic inflammatory burden", "Maps persistent inflammatory amplification through TNF/IL-6-like axes.")
        addIf(axes.contains("regulatory_brake_axis"), "response shutdown requirement", "regulatory_brake_axis", "resolution vs runaway amplification", "Regulatory brake failure is a cross-condition candidate from allergy/autoimmune to severe inflammation.")
        addIf(axes.contains("tissue_damage_axis"), "immune collateral damage", "tissue_damage_axis", "lung/joint/epithelial damage", "Separates protective response from harmful tissue cost.")
        addIf(axes.contains("resolution_recovery_axis"), "post-response phase", "resolution_recovery_axis", "repair and return-to-baseline", "Captures the learning target: smarter immunity means timing, precision, and recovery, not blind strength.")
        return out.sortedByDescending { it.evidenceScore }.take(12)
    }

    private fun evidenceFor(axis: String, findings: List<ResearchFinding>): Int {
        val relevant = findings.filter { it.matchedAxes.contains(axis) }
        if (relevant.isEmpty()) return 0
        val avgEvidence = relevant.map { it.evidence.evidenceQualityScore }.average().toInt()
        val humanBoost = relevant.count { it.evidence.speciesClass == "human" }.coerceAtMost(3) * 5
        val abstractPenalty = relevant.count { it.sanityFlags.contains("ABSTRACT_FETCH_FAILED") }.coerceAtMost(3) * 3
        return (avgEvidence + humanBoost - abstractPenalty).coerceIn(0, 100)
    }
}

object GlobalHypothesisLedgerBuilder {
    fun build(
        edges: List<TriggerResponseEdge>,
        datasets: List<PublicDatasetCandidate>,
        findings: List<ResearchFinding>
    ): List<GlobalHypothesisLead> {
        val leads = mutableListOf<GlobalHypothesisLead>()
        val axes = findings.flatMap { it.matchedAxes }.toSet()
        if (axes.contains("interferon_antiviral_axis") || axes.contains("hyperinflammatory_axis")) {
            leads += lead(
                "HYP_INTERFERON_TIMING_RESOLUTION_001",
                "Does early interferon response separate controlled viral recovery from damaging hyperinflammation?",
                listOf("influenza", "COVID/ARDS", "RSV", "hantavirus candidate"),
                edges, datasets, "interferon_antiviral_axis",
                "Longitudinal human viral RNA/cytokine dataset with early timepoints, viral load, and recovery vs deterioration labels.",
                "If severe outcomes occur without delayed/weak early antiviral or exaggerated inflammatory signals, downgrade this hypothesis."
            )
        }
        if (axes.contains("regulatory_brake_axis") && (axes.contains("tnf_il6_autoimmune_axis") || axes.contains("hyperinflammatory_axis"))) {
            leads += lead(
                "HYP_REGULATORY_BRAKE_CROSS_CONDITION_001",
                "Does weak regulatory braking appear across autoimmune-like inflammation and severe viral hyperinflammation?",
                listOf("RA", "ARDS/sepsis-like hyperinflammation", "viral deterioration"),
                edges, datasets, "regulatory_brake_axis",
                "Human cross-condition dataset with IL-10/Treg/regulatory markers plus outcomes and time course.",
                "If regulatory markers do not differ between resolving and deteriorating cases, keep as context not driver."
            )
        }
        if (axes.contains("type2_allergy_axis") && axes.contains("rna_transcriptomic_axis")) {
            leads += lead(
                "HYP_TYPE2_TRANSCRIPTOMIC_STATE_001",
                "Can RNA/transcriptomic signatures separate harmless-trigger allergy from inflammatory or viral immune states?",
                listOf("allergy", "asthma", "RA-like inflammation", "viral response"),
                edges, datasets, "rna_transcriptomic_axis",
                "Human RNA-seq dataset containing allergy/asthma plus comparator inflammatory or viral cohorts.",
                "If transcriptomic signatures collapse into non-specific inflammation without axis separation, downgrade."
            )
        }
        if (axes.contains("tissue_damage_axis") && (axes.contains("interferon_antiviral_axis") || axes.contains("hyperinflammatory_axis"))) {
            leads += lead(
                "HYP_PROTECTION_DAMAGE_SPLIT_001",
                "Which immune axes separate pathogen control from tissue-damaging over-response?",
                listOf("respiratory viruses", "ARDS", "hyperinflammation"),
                edges, datasets, "tissue_damage_axis",
                "Dataset with pathogen burden, immune markers, tissue-damage markers, and clinical outcome.",
                "If tissue damage tracks pathogen load alone rather than immune-axis imbalance, downgrade immune-overresponse explanation."
            )
        }
        if (leads.isEmpty()) {
            leads += GlobalHypothesisLead(
                hypothesisId = "HYP_GLOBAL_IMMUNE_MAPPING_BASELINE",
                question = "Which public datasets can map trigger-response-outcome immune patterns across allergy, autoimmunity, and viral response?",
                conditions = listOf("allergy", "autoimmune inflammation", "viral response"),
                evidenceScore10 = 3.0,
                dataTrustScore = 40,
                status = "EARLY",
                nextDatasetNeeded = "Find at least one human omics or cytokine dataset with condition labels and outcome/response labels.",
                falsifier = "If no public dataset contains usable trigger-response-outcome structure, restrict to literature mapping until data exists."
            )
        }
        return leads.sortedWith(compareByDescending<GlobalHypothesisLead> { it.status == "ACTIVE_CANDIDATE" }.thenByDescending { it.dataTrustScore }).take(6)
    }

    private fun lead(
        id: String,
        question: String,
        conditions: List<String>,
        edges: List<TriggerResponseEdge>,
        datasets: List<PublicDatasetCandidate>,
        axis: String,
        nextDataset: String,
        falsifier: String
    ): GlobalHypothesisLead {
        val edgeScore = edges.filter { it.responseAxis == axis }.maxOfOrNull { it.evidenceScore } ?: 35
        val datasetScore = datasets.filter { it.matchedAxes.contains(axis) }.maxOfOrNull { it.qualityScore } ?: 25
        val trust = ((edgeScore * 0.55) + (datasetScore * 0.45)).roundToInt().coerceIn(0, 100)
        val evidence10 = (trust / 10.0).coerceIn(0.0, 10.0)
        val status = when {
            trust >= 72 -> "ACTIVE_CANDIDATE"
            trust >= 55 -> "WATCH"
            else -> "EARLY"
        }
        return GlobalHypothesisLead(id, question, conditions, evidence10, trust, status, nextDataset, falsifier)
    }
}

object PathogenResponseComparator {
    fun notes(
        findings: List<ResearchFinding>,
        edges: List<TriggerResponseEdge>,
        hypotheses: List<GlobalHypothesisLead>
    ): List<AntiviralResponseNote> {
        val axes = findings.flatMap { it.matchedAxes }.toSet()
        val notes = mutableListOf<AntiviralResponseNote>()
        if (axes.contains("interferon_antiviral_axis")) {
            notes += AntiviralResponseNote(
                theme = "Interferon timing",
                status = if (hypotheses.any { it.hypothesisId.contains("INTERFERON") && it.status != "EARLY" }) "WATCH" else "EARLY",
                involvedAxes = listOf("interferon_antiviral_axis", "hyperinflammatory_axis", "resolution_recovery_axis").filter { axes.contains(it) },
                researchNote = "Study whether early antiviral signaling predicts controlled recovery while delayed/excess inflammatory signaling predicts deterioration."
            )
        }
        if (axes.contains("tcell_activation_axis") || axes.contains("bcell_antibody_axis")) {
            notes += AntiviralResponseNote(
                theme = "Adaptive antiviral response",
                status = "EARLY",
                involvedAxes = listOf("tcell_activation_axis", "bcell_antibody_axis").filter { axes.contains(it) },
                researchNote = "Separate T-cell and antibody memory from acute inflammatory damage; do not collapse adaptive protection into cytokine intensity."
            )
        }
        if (edges.any { it.responseAxis == "tissue_damage_axis" }) {
            notes += AntiviralResponseNote(
                theme = "Protection vs damage split",
                status = "WATCH",
                involvedAxes = listOf("tissue_damage_axis", "tnf_il6_autoimmune_axis", "regulatory_brake_axis").filter { axes.contains(it) },
                researchNote = "The useful target is not stronger immunity; it is preserving pathogen control while reducing tissue damage and improving resolution."
            )
        }
        if (notes.isEmpty()) {
            notes += AntiviralResponseNote(
                theme = "Antiviral response coverage",
                status = "OFF",
                involvedAxes = emptyList(),
                researchNote = "No antiviral-response axis was detected this cycle; prioritize viral-response dataset discovery before variant-resilience claims."
            )
        }
        return notes
    }
}
