package com.immunesignal.app

import org.json.JSONObject

object LearningDeltaEngine {
    fun build(current: List<HypothesisObject>, previousReportLines: List<String>): List<LearningDeltaCard> {
        val previous = linkedMapOf<String, String>()
        previousReportLines
            .mapNotNull { runCatching { JSONObject(it) }.getOrNull() }
            .forEach { report ->
                val arr = report.optJSONArray("hypothesisObjects") ?: return@forEach
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val id = obj.optString("hypothesisId")
                    if (id.isNotBlank() && !previous.containsKey(id)) {
                        previous[id] = obj.optString("status", "UNKNOWN")
                    }
                }
            }
        return current.take(8).map { obj ->
            val prev = previous[obj.hypothesisId] ?: "NEW"
            val deltaType = when {
                prev == "NEW" -> "new_hypothesis_object"
                prev != obj.status && obj.signalFlip != "no_major_flip" -> "rank_changed_with_${obj.signalFlip}"
                prev != obj.status -> "rank_changed"
                obj.signalFlip != "no_major_flip" -> obj.signalFlip
                else -> "delta_only_watch"
            }
            LearningDeltaCard(
                hypothesisId = obj.hypothesisId,
                deltaType = deltaType,
                previousStatus = prev,
                currentStatus = obj.status,
                signalFlip = obj.signalFlip,
                decisionImpact = obj.decisionImpact,
                nextAction = obj.nextBestMeasurement
            )
        }
    }
}
