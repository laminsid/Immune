package com.immunesignal.app

import android.content.Context
import org.json.JSONObject
import java.util.Locale

class ResearchKnowledgeStore(private val context: Context) {
    private val reportFile = "immune_research_autopilot_reports.jsonl"
    private val findingFile = "immune_research_findings.jsonl"
    private val importedReportFile = "immune_imported_reports.jsonl"
    private val knowledgeLedgerFile = "immune_knowledge_ledger.jsonl"
    private val steeringProfileFile = "immune_active_research_steering.json"
    private val maxReports = 150
    private val maxFindings = 2500
    private val maxImportedReports = 250
    private val maxLedgerLines = 3000

    // v0.9.1: cache of seen source IDs.
    // v0.9.0 read the entire findings file from disk every time a new finding
    // was about to be appended (O(n²) flash I/O across a research cycle).
    // We now memoize the set, refresh on first use, and update in-memory on save.
    @Volatile private var seenIdCache: MutableSet<String>? = null

    fun saveReport(reportJson: JSONObject) {
        appendTrimmed(reportFile, reportJson.toString(), maxReports)
        val findings = reportJson.optJSONArray("findings")
        if (findings != null) {
            for (i in 0 until findings.length()) {
                val item = findings.optJSONObject(i) ?: continue
                appendUniqueFinding(item)
            }
        }
        val links = reportJson.optJSONArray("emergentLinks")
        if (links != null) {
            for (i in 0 until links.length()) {
                val item = JSONObject()
                    .put("kind", "emergent_link")
                    .put("createdAtMillis", System.currentTimeMillis())
                    .put("value", links.optString(i))
                appendTrimmed(knowledgeLedgerFile, item.toString(), maxLedgerLines)
            }
        }
    }

    fun saveImportedReport(title: String, text: String): ImportedReportSignal {
        val clean = text.take(200_000)
        val signal = ImportedReportSignal(
            reportId = "import_${System.currentTimeMillis()}",
            createdAtMillis = System.currentTimeMillis(),
            title = title.ifBlank { "Manual research note" }.take(120),
            matchedAxes = inferAxes(clean),
            extractedKeywords = extractKeywords(clean),
            preview = clean.replace("\n", " ").take(450)
        )
        val json = ResearchJsonCodec.importedSignalToJson(signal)
            .put("rawText", clean)
        appendTrimmed(importedReportFile, json.toString(), maxImportedReports)
        return signal
    }

    fun readLatestReports(limit: Int): List<String> = readAll(reportFile).takeLast(limit).asReversed()

    fun readRecentFindings(limit: Int): List<JSONObject> {
        return readAll(findingFile)
            .takeLast(limit)
            .mapNotNull { runCatching { JSONObject(it) }.getOrNull() }
            .asReversed()
    }

    fun readImportedSignals(limit: Int): List<ImportedReportSignal> {
        return readAll(importedReportFile)
            .takeLast(limit)
            .mapNotNull { runCatching { ResearchJsonCodec.importedSignalFromJson(JSONObject(it)) }.getOrNull() }
            .asReversed()
    }

    fun readImportedRawText(limit: Int): List<String> {
        return readAll(importedReportFile)
            .takeLast(limit)
            .mapNotNull { runCatching { JSONObject(it).optString("rawText") }.getOrNull() }
            .filter { it.isNotBlank() }
            .asReversed()
    }

    fun saveActiveSteering(
        variablesText: String,
        focusQuestion: String,
        requiredTermsText: String,
        excludedTermsText: String
    ): ResearchSteeringProfile {
        val variables = parseList(variablesText).take(16)
        val requiredTerms = parseList(requiredTermsText).take(12)
        val excludedTerms = parseList(excludedTermsText).take(12)
        val combined = (variables + requiredTerms + focusQuestion).joinToString(" ")
        val profile = ResearchSteeringProfile(
            profileId = "steer_${System.currentTimeMillis()}",
            createdAtMillis = System.currentTimeMillis(),
            variables = variables,
            focusQuestion = focusQuestion.trim().take(500),
            requiredTerms = requiredTerms,
            excludedTerms = excludedTerms,
            inferredAxes = inferAxes(combined)
        )
        context.openFileOutput(steeringProfileFile, Context.MODE_PRIVATE).bufferedWriter().use { writer ->
            writer.write(ResearchJsonCodec.steeringProfileToJson(profile).toString())
        }
        val ledgerItem = JSONObject()
            .put("kind", "research_steering_saved")
            .put("createdAtMillis", profile.createdAtMillis)
            .put("variables", profile.variables.joinToString(", "))
            .put("focusQuestion", profile.focusQuestion)
            .put("inferredAxes", profile.inferredAxes.joinToString(", "))
        appendTrimmed(knowledgeLedgerFile, ledgerItem.toString(), maxLedgerLines)
        return profile
    }

    fun readActiveSteering(): ResearchSteeringProfile? {
        return try {
            val text = context.openFileInput(steeringProfileFile).bufferedReader().use { it.readText() }
            if (text.isBlank()) null else ResearchJsonCodec.steeringProfileFromJson(JSONObject(text))
        } catch (_: Exception) {
            null
        }
    }

    fun clearActiveSteering() {
        runCatching { context.deleteFile(steeringProfileFile) }
        val ledgerItem = JSONObject()
            .put("kind", "research_steering_cleared")
            .put("createdAtMillis", System.currentTimeMillis())
        appendTrimmed(knowledgeLedgerFile, ledgerItem.toString(), maxLedgerLines)
    }

    fun seenSourceIds(): Set<String> {
        // v0.9.1: cached on first call; mutated on every appendUniqueFinding.
        seenIdCache?.let { return it }
        synchronized(this) {
            seenIdCache?.let { return it }
            val set = readAll(findingFile)
                .mapNotNull { line ->
                    runCatching {
                        val obj = JSONObject(line)
                        obj.optString("source") + ":" + obj.optString("sourceId")
                    }.getOrNull()
                }
                .filter { it.length > 2 }
                .toMutableSet()
            seenIdCache = set
            return set
        }
    }

    fun seenAxisPairs(): Set<String> {
        return readAll(findingFile)
            .mapNotNull { runCatching { JSONObject(it).optJSONArray("matchedAxes") }.getOrNull() }
            .flatMap { arr ->
                val axes = (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }.sorted()
                axes.flatMapIndexed { idx, a -> axes.drop(idx + 1).map { b -> "$a + $b" } }
            }
            .toSet()
    }

    private fun appendUniqueFinding(finding: JSONObject) {
        val key = finding.optString("source") + ":" + finding.optString("sourceId")
        if (key.length <= 2) return
        val cache = seenSourceIds() as MutableSet<String>
        if (cache.contains(key)) return
        appendOnly(findingFile, finding.toString())
        cache.add(key)
        // Periodic trim: only when the file grows past 1.2x its cap.
        // Reading the file back is acceptable here because it runs at most
        // once per ~500 inserts instead of once per insert.
        if (cache.size > (maxFindings * 1.2).toInt()) {
            trimFile(findingFile, maxFindings)
            // Rebuild cache after trim.
            seenIdCache = null
        }
    }

    private fun inferAxes(text: String): List<String> {
        // v1.1: delegate to AxisMatcher single source of truth.
        return AxisMatcher.match(text)
    }

    private fun extractKeywords(text: String): List<String> {
        val t = text.lowercase(Locale.US)
        val dictionary = listOf(
            "ige", "eosinophil", "mast cell", "histamine", "il-4", "il-5", "il-13", "tnf", "il-6", "il-10",
            "crp", "ferritin", "dna methylation", "epigenetic", "genome", "snp", "rna-seq", "single-cell", "mirna",
            "immunosenescence", "inflammaging", "autonomic", "blood pressure", "stress", "sleep", "disc", "back pain",
            "gastric acid", "reflux", "gerd", "ppi", "h pylori", "microbiome", "gut barrier", "diet diversity",
            "protein intake", "muscle mass", "sarcopenia", "testosterone", "androgen"
        )
        return dictionary.filter { t.contains(it) }.take(24)
    }

    private fun parseList(text: String): List<String> {
        return text
            .replace("\n", ",")
            .split(",", ";", "|", "،")
            .map { it.trim() }
            .filter { it.length >= 2 }
            .distinctBy { it.lowercase(Locale.US) }
    }

    private fun appendTrimmed(fileName: String, line: String, maxLines: Int) {
        // Used for low-frequency files (reports, ledger). Hot paths use
        // appendOnly + periodic trimFile.
        val existing = readAll(fileName).toMutableList()
        existing.add(line)
        val trimmed = existing.takeLast(maxLines)
        context.openFileOutput(fileName, Context.MODE_PRIVATE).bufferedWriter().use { writer ->
            trimmed.forEach {
                writer.write(it)
                writer.newLine()
            }
        }
    }

    /**
     * v0.9.1: O(1) append. Use only on hot paths where we keep an in-memory
     * cache for uniqueness; combine with [trimFile] periodically.
     */
    private fun appendOnly(fileName: String, line: String) {
        context.openFileOutput(fileName, Context.MODE_APPEND).bufferedWriter().use { writer ->
            writer.write(line)
            writer.newLine()
        }
    }

    private fun trimFile(fileName: String, maxLines: Int) {
        val existing = readAll(fileName)
        if (existing.size <= maxLines) return
        val trimmed = existing.takeLast(maxLines)
        context.openFileOutput(fileName, Context.MODE_PRIVATE).bufferedWriter().use { writer ->
            trimmed.forEach {
                writer.write(it)
                writer.newLine()
            }
        }
    }

    private fun readAll(fileName: String): List<String> {
        return try {
            context.openFileInput(fileName).bufferedReader().useLines { lines ->
                lines.map { it.trim() }.filter { it.startsWith("{") && it.endsWith("}") }.toList()
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
