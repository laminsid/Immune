package com.immunesignal.app

import java.util.Locale

object EvidenceObjectFactory {
    fun build(findings: List<ResearchFinding>, datasets: List<DatasetAccessionCandidate>): List<EvidenceObject> {
        return findings.map { finding ->
            val linkedDatasets = datasets.filter { it.sourceFindingId == finding.source + ":" + finding.sourceId }
            val text = (finding.title + " " + finding.bridgeSignal + " " + finding.whyItMatters + " " + finding.evidence.studyDesign + " " + finding.negativeControl.status).lowercase(Locale.US)
            val contradiction = finding.causality.contradictionPenalty > 0 || listOf(
                "failed to replicate", "no association", "conflicting", "not significant", "heterogeneity", "contradict"
            ).any { text.contains(it) }
            val negativeControl = !finding.negativeControl.status.contains("weak_no_control", true) &&
                !finding.negativeControl.status.contains("unknown", true) &&
                finding.negativeControl.status.isNotBlank()
            val longitudinal = listOf("longitudinal", "follow-up", "time course", "baseline", "prospective").any { text.contains(it) }
            val mechanism = finding.causality.biologicalPlausibilityScore >= 55 || listOf("mechanism", "pathway", "signaling", "activation", "inhibition").any { text.contains(it) }
            val causalSafe = finding.causality.causalityScore >= 60 && negativeControl && !contradiction
            val supports = finding.evidence.evidenceQualityScore >= 55 && finding.noveltyScore >= 55 && !contradiction
            val impact = when {
                contradiction -> "blocks_or_downgrades_hypothesis"
                linkedDatasets.any { it.usabilityScore >= 60 } -> "dataset_candidate_for_hypothesis_testing"
                supports && causalSafe -> "supports_hypothesis_with_causal_caution"
                supports -> "supports_hypothesis_weakly"
                else -> "no_upgrade"
            }
            EvidenceObject(
                evidenceId = "ev_${finding.source}_${finding.sourceId}",
                sourceType = finding.source,
                sourceId = finding.sourceId,
                title = finding.title.take(240),
                accessionIds = linkedDatasets.map { it.accession }.filter { it != "DATASET_ACCESSION_UNRESOLVED" }.distinct(),
                supportsHypothesis = supports,
                contradictsHypothesis = contradiction,
                hasNegativeControl = negativeControl,
                hasLongitudinalSignal = longitudinal,
                hasMechanisticSignal = mechanism,
                causalClaimSafe = causalSafe,
                linkedHypothesisId = inferHypothesisId(finding),
                decisionImpact = impact,
                qualityScore = ((finding.evidence.evidenceQualityScore + finding.causality.causalityScore + linkedDatasets.maxOfOrNull { it.usabilityScore }.orZero()) / 3).coerceIn(0, 100),
                reasons = buildReasons(finding, linkedDatasets, contradiction, negativeControl, longitudinal, mechanism, causalSafe)
            )
        }.sortedByDescending { it.qualityScore }
    }

    private fun Int?.orZero(): Int = this ?: 0

    private fun inferHypothesisId(finding: ResearchFinding): String {
        val axes = finding.matchedAxes.take(3).joinToString("_").ifBlank { "general_immune" }
        return "HYP_${axes.uppercase(Locale.US).take(80)}"
    }

    private fun buildReasons(
        finding: ResearchFinding,
        datasets: List<DatasetAccessionCandidate>,
        contradiction: Boolean,
        negativeControl: Boolean,
        longitudinal: Boolean,
        mechanism: Boolean,
        causalSafe: Boolean
    ): List<String> {
        val out = mutableListOf<String>()
        out += "Evidence quality ${finding.evidence.evidenceQualityScore}/100; causality ${finding.causality.causalityScore}/100."
        if (datasets.isNotEmpty()) out += "Dataset bridge: ${datasets.first().status}."
        if (contradiction) out += "Contradiction/counter-signal detected."
        if (negativeControl) out += "Negative/control awareness present."
        if (longitudinal) out += "Longitudinal/time-course signal present."
        if (mechanism) out += "Mechanistic/pathway signal present."
        if (!causalSafe) out += "Causal claim remains unsafe."
        return out.distinct()
    }
}
