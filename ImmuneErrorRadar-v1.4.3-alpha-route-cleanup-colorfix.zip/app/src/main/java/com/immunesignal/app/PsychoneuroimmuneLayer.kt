package com.immunesignal.app

class PsychoneuroimmuneLayer {
    fun stressAxis(input: CaseInput, evidence: MutableList<String>): Int {
        val c = input.causeContext
        var score = 0
        c.stressToday0To10?.let {
            when {
                it >= 8 -> { score += 26; evidence += "High stress today entered: $it/10." }
                it >= 5 -> { score += 16; evidence += "Moderate stress today entered: $it/10." }
            }
        }
        c.stressLast7Days0To10?.let {
            when {
                it >= 8 -> { score += 24; evidence += "High stress over last 7 days entered: $it/10." }
                it >= 5 -> { score += 14; evidence += "Moderate stress over last 7 days entered: $it/10." }
            }
        }
        c.sleepQuality0To10?.let {
            when {
                it <= 3 -> { score += 22; evidence += "Poor sleep/recovery entered: $it/10." }
                it <= 5 -> { score += 12; evidence += "Reduced sleep/recovery entered: $it/10." }
            }
        }
        if (c.majorEmotionalEvent) { score += 18; evidence += "Major emotional event selected." }
        if (c.panicOrRapidBreathing) { score += 18; evidence += "Panic/rapid breathing episode selected; may amplify airway symptoms." }
        return score.coerceIn(0, 100)
    }
}
