package com.immunesignal.app

import java.util.Locale

/** v1.4.0: compiles narrow dataset-source queries from testable shards. */
object DatasetQueryCompiler {
    fun compile(shards: List<TestableHypothesisShard>, memory: PersistentFailureMemorySnapshot): List<ResearchQuery> {
        val killedFamilies = memory.records
            .filter { it.cooldownCyclesRemaining > 0 }
            .map { it.sourceFamily.lowercase(Locale.US) }
            .toSet()
        val out = mutableListOf<ResearchQuery>()
        for (shard in shards) {
            val seeds = shard.querySeeds.take(2)
            for ((idx, seed) in seeds.withIndex()) {
                out += ResearchQuery(
                    id = "q_v142_${shard.shardId.lowercase(Locale.US)}_$idx",
                    label = "v1.4.2 dataset shard: ${shard.label}",
                    query = seed,
                    reason = "Hypothesis decomposition: ${shard.evidenceQuestion}"
                )
            }
        }
        if (killedFamilies.contains("broad_pubmed_mapping")) {
            return out.filterNot { it.query.lowercase(Locale.US).contains("broad") }
        }
        return out.distinctBy { it.id }
    }
}
