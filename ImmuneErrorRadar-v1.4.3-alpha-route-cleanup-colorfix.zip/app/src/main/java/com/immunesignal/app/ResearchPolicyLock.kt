package com.immunesignal.app

object ResearchPolicyLock {
    val hardRules = listOf(
        "No diagnosis.",
        "No treatment recommendation.",
        "No personal health prediction.",
        "No causal claim without controls/mechanism/replication.",
        "No discovery claim without a dataset or evidence object.",
        "No hypothesis upgrade from query pivot alone.",
        "No new biological axis expansion during v1.3.x.",
        "No ML model before dataset readiness is Candidate or Testable Lead."
    )

    fun blocksHypothesisUpgrade(evidenceObjects: List<EvidenceObject>): Boolean {
        return evidenceObjects.none { it.decisionImpact != "no_upgrade" }
    }
}
