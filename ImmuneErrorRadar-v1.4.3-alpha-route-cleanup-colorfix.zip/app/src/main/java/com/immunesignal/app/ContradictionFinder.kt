package com.immunesignal.app

object ContradictionFinder {
    fun contradictionSearchPrompts(axes: List<String>, label: String): List<String> {
        val prompts = mutableListOf<String>()
        if (axes.contains("type2_allergy_axis") && axes.contains("aging_immune_axis")) {
            prompts += "Search for evidence that chronic allergy increases inflammatory burden rather than preserving immune youth."
        }
        if (axes.contains("psychoneuroimmune_axis") && axes.contains("autonomic_vascular_axis")) {
            prompts += "Search for evidence that stress raises blood pressure rather than lowering it through histamine-like pathways."
        }
        if (axes.contains("testosterone_immune_axis")) {
            prompts += "Search for evidence that testosterone effects differ by sex, age, dose, and disease context."
        }
        if (axes.contains("gastric_acid_gut_axis")) {
            prompts += "Search for evidence separating reflux/GERD, low-acid suspicion, PPI use, and microbiome mechanisms."
        }
        if (prompts.isEmpty()) prompts += "Search for null findings, no-association papers, and context-dependent failures for: $label."
        return prompts.take(4)
    }
}
