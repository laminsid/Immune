package com.immunesignal.app

/** Facade-friendly query planner for v1.3.3. Keeps steering optional and autonomous lanes primary. */
class QueryPlanner {
    fun build(plan: AutonomousResearchPlan, steering: ResearchSteeringProfile?, pivot: PivotDecision = PivotDecision.none(), maxQueries: Int = 4): List<ResearchQuery> {
        val out = mutableListOf<ResearchQuery>()
        val safePivot = ScopeDisciplineLock.sanitizePivot(pivot)
        if (safePivot.pivotType != "NO_PIVOT") {
            out += ResearchQuery("q_pivot_${safePivot.pivotType.lowercase()}", "PIVOT: ${safePivot.nextIntent}", safePivot.nextQuerySeed, safePivot.reason)
            out += AutonomousStagnationEngine.antiStagnationQueries(
                AutonomousStagnationEngine.StagnationPlan(
                    level = if (safePivot.pivotType.contains("ANTI_STAGNATION")) 3 else 1,
                    pendingPivot = safePivot,
                    effectiveMaxQueries = maxQueries,
                    effectiveResultsPerQuery = 0,
                    reason = safePivot.reason
                )
            )
        }
        out += AutonomousResearchPlanner().queries(plan)
        if (steering != null && steering.variables.isNotEmpty()) {
            val joined = steering.variables.take(6).joinToString(" AND ") { term -> "\"$term\"" }
            val required = steering.requiredTerms.take(4).joinToString(" AND ") { term -> "\"$term\"" }
            val query = listOf(joined, required).filter { it.isNotBlank() }.joinToString(" AND ").ifBlank { joined }
            out += ResearchQuery("q_steer_optional", "GUIDED BOOST: optional user steering", query, "Steering accelerates a specific idea but does not replace autonomous Explore/Deepen/Challenge.")
        }
        return out.distinctBy { it.id }.take(maxQueries.coerceAtLeast(1))
    }
}
