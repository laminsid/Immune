# CHANGELOG v1.3.9-alpha — Research UI Cleanup + Search/Learn Visibility

## Changed
- Removed the old daily/manual scan form from the launcher screen.
- Rebuilt the first screen as a research command center.
- Rebuilt the autonomous researcher UI with a professional Search → Evidence → Learn flow.
- Added visible research stage messaging so the user can see when the engine is searching, judging evidence, and saving learning.
- Replaced the long on-screen report preview with a concise Research Command Board.
- Kept full technical details in export/copy paths.

## Guardrails preserved
- No diagnosis or treatment flow added.
- No new biology axes added.
- Execution wiring, dataset hunt failover, evidence learning OS, and integrity locks remain active.
