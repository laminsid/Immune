# Changelog — v1.3.0-alpha Global Dataset Intelligence

## Added

- GlobalImmuneIntelligenceEngine.kt
- DatasetDiscoveryEngine
- DatasetQualityScorer
- ImmuneAxisMapper
- TriggerResponseGraphBuilder
- GlobalHypothesisLedgerBuilder
- PathogenResponseComparator
- PublicDatasetCandidate / ImmuneAxisSummary / TriggerResponseEdge / GlobalHypothesisLead / AntiviralResponseNote models
- Global report JSON section
- Global report PDF/brief rendering
- New global assets and docs
- Python research helpers:
  - global_dataset_registry.py
  - immune_axis_mapper.py
  - trigger_response_graph.py
  - pathogen_response_comparator.py

## Changed

- Research Autopilot now prioritizes global public dataset and antiviral-response queries before older context queries.
- Product mode upgraded to Global Immune Dataset Intelligence Engine.
- AxisMatcher extended with antiviral/adaptive/tissue-damage/recovery axes.
- Static sample pipeline includes global dataset intelligence scripts.

## Not added

- No PyTorch / PyG in APK
- No ML training inside Android
- No personal-first time-series roadmap
- No treatment or diagnosis claims
