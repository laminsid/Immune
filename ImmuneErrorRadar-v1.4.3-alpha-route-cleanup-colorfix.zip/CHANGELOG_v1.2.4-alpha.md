# Immune Error Radar v1.2.4-alpha — Unit Test Hotfix

Fixes CI unit-test failures reported after v1.2.3.

## Fixes
- MinimumDataPackGate: corrected word-boundary regex strings so phrases such as `meal timing` satisfy `meal_timing` while generic `meal` still does not.
- ResearchStateEngine: empty finding sets no longer produce bias Watch/Alert through controls-required placeholders.
- SteeringSanitizer: safe interleukin terms such as `il-6` survive sanitization while numeric personal measurements remain blocked.
- DoctorReportExporter: fixed nullable `JSONObject.opt()` warning.
- Bumped version to `1.2.4-alpha-unit-test-hotfix`.
