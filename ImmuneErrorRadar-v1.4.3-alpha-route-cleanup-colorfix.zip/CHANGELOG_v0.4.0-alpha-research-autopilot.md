# v0.4.0-alpha — Research Autopilot Patch

## Added

- Internet permission for private user-started research discovery.
- Research Autopilot screen.
- PubMed/NCBI metadata search cycle.
- Local research knowledge store.
- Discovery PDF export.
- Cross-axis novelty scoring.
- Research Python pipeline:
  - dataset_registry_loader.py
  - marker_dictionary.py
  - unit_normalizer.py
  - immune_matrix_builder.py
  - baseline_classifier.py
  - cross_condition_bridge.py

## Preserved boundaries

- No diagnosis.
- No treatment.
- No drug recommendation.
- No proof of causality.
- No private case upload.

## Intent

Turn the APK from a private notebook into a private research autopilot that searches for non-obvious immune/cause bridges while keeping claims hypothesis-grade.
