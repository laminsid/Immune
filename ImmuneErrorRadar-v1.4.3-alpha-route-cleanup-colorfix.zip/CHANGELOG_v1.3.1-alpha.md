# v1.3.1-alpha — Usability, data-use and export hotfix

- Default research cycle reduced to low-data mode: 4 queries × 5 PubMed IDs.
- Abstract fetching disabled by default in APK to avoid high mobile data usage.
- UI report simplified: brief + preview in-app; full details exported.
- Export report fixed: FileProvider now allows cache/exports and TXT fallback exists if PDF sharing fails.
- No-source cycles now explain repeated-source exhaustion and next action clearly.
- Research Autopilot screen copy simplified.
