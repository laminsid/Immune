# CHANGELOG v1.3.8-alpha — Execution Wiring + Active Learning Loop

## Why

Device reports showed repeated early stagnation: no new useful sources, repeated PubMed IDs, zero dataset candidates, and a report saying “strategy pivoted” without visible evidence that the next execution path changed.

## Added

- `EngineRuntimeStatus.kt`
- `ActiveResearchEngineStatus`
- `ExecutionLockReport`
- `RuntimeDatasetHuntFailover`
- Same-cycle hard-stagnation detection
- Same-cycle dataset/accession failover queries
- Runtime JSON export:
  - `runtimeStatus`
  - `executionLockReport`
- UI preview fields:
  - active engine
  - execution lock
  - research state
  - effective query budget
  - runtime failover applied
- PDF export fields for runtime status and execution enforcement
- Unit tests in `ExecutionWiringV138Test.kt`

## Changed

- Android version bumped to `1.3.8-alpha-execution-wiring`.
- Default UI research run increased to 6 queries × 12 PubMed IDs.
- Forced/stagnation paths now raise the effective search budget automatically.
- Research notes now report actual executed query count and effective PubMed retmax instead of always saying 4 × 5.

## Boundary

No new biology axes, no diagnosis, no treatment, no health prediction, no Random Forest/ML. This is an execution-wiring patch only.
