# CHANGELOG — v1.3.7-alpha Evidence Acquisition + Learning OS

## Added

- Dataset accession acquisition layer:
  - `DatasetAccessionResolver.kt`
  - `DatasetCandidateScorer.kt`
  - `AbstractToDatasetBridge.kt`
- Evidence-object layer:
  - `EvidenceObjectFactory.kt`
  - `EvidenceObject` model
- Learning OS layer:
  - `ResearchLearningLoopEngine.kt`
  - `ResearchIncidentReceipt`
  - `PreventiveGateDecision`
  - `RegressionVector`
  - `LaneCooldownRecord`
- Discovery readiness layer:
  - `DiscoveryReadinessScorer.kt`
  - `DiscoveryReadinessReport`
- Policy lock:
  - `ResearchPolicyLock.kt`
- Data-only JSON rule anchors:
  - `failure_root_causes_v1.3.7.json`
  - `preventive_gates_v1.3.7.json`
  - `dataset_patterns_v1.3.7.json`
  - `regression_vectors_v1.3.7.json`
  - `research_policy_lock_v1.3.7.json`
- Tests:
  - `EvidenceAcquisitionV137Test.kt`

## Changed

- `ResearchAutopilot.kt` now builds dataset candidates v1.3.7, evidence objects, discovery readiness, and a Learning OS report for every cycle.
- `QueryPlanner.kt` receives a forced Learning OS pivot from the previous failed cycle before normal autonomous lanes.
- `ResearchReportV3Builder.kt` blocks hypothesis upgrades when no decision-impact evidence object exists.
- `ResearchJsonCodec` now exports schema `137` and serializes dataset candidates v1.3.7, evidence objects, discovery readiness, and Learning OS report.
- Research UI and PDF export now show root causes, gates, cooldowns, regression vectors, evidence objects, and discovery readiness.

## Safety / scope

- No new biology axes.
- No ML / Random Forest.
- No diagnosis, treatment, or health prediction.
- No discovery claim without evidence objects and dataset readiness.
