# Changelog — v1.2.1-alpha-research-lock-hotfix

This release fixes silent logic bugs found in the v1.2 Research Lock System. It does not add new biological scope.

## Critical fixes

- Fixed negative-control scoring dead branch in `EvidenceScore.estimate`.
- Fixed false `metadataHeavy` alert when findings are empty in `ResearchStateEngine`.
- Fixed newest-prior-status handling in `LearningDeltaEngine`; duplicate hypothesis IDs now keep the latest prior report entry.
- Fixed overly permissive minimum-data matching in `MinimumDataPackGate`.

## Quality and UI fixes

- Evidence score formatting now uses one decimal via `ScoreFormat`.
- Removed hidden double-credit of human evidence in `DataTrustScore`.
- Preserved combined rank-change + signal-flip delta types.
- Renamed weak-evidence risk variable in `ResearchMistakeLibrary` to match behavior.

## Tests and CI

- Added v1.2 regression tests for Hypothesis Object, Minimum Data Pack, Impact Test, Research State, Learning Delta, Falsification, Mistake Library, and Report Template.
- Updated GitHub Actions to run `gradle :app:testDebugUnitTest` before `assembleDebug`.

## Cleanup

- Removed duplicate `biological_plausibility_graph_v0.1.json`.
- Updated README and internal project sheet.
