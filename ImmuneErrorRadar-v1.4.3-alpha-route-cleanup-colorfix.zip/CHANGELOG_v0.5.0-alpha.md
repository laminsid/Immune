# Immune Error Radar v0.5.0-alpha — Aging / Autonomic / Allergy Axis Patch

Added:
- AgingImmuneAxis.kt
- AllergyAgingBridge.kt
- AutonomicVascularLayer.kt
- LongevityHypothesisEngine.kt
- AgingAutonomicModels.kt
- Aging/autonomic inputs in MainActivity
- Aging / Allergy / Autonomic Bridge in results and PDF
- Research Autopilot queries for allergy-aging, immunosenescence, inflammaging, histamine, blood pressure, autonomic dynamics
- Assets for aging-axis rules and longevity research questions
- Python helper script: research/aging_autonomic_bridge.py

Research boundaries:
- High allergy does not prove slower aging.
- Low allergy does not prove immunosenescence.
- Stress and histamine/BP relations are candidate temporal patterns, not clinical conclusions.
