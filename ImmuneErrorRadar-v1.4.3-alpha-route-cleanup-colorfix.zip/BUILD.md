# Build Instructions — Immune Error Radar v1.1.1-alpha

## Recommended build path

This repository is prepared for GitHub Actions using `gradle/actions/setup-gradle`.
The workflow is:

```text
.github/workflows/android-debug.yml
```

It runs static checks and then builds:

```bash
gradle :app:assembleDebug
```

## Local build

A Gradle Wrapper is not bundled in this alpha ZIP. For local builds, either:

1. Open the project in Android Studio and let it sync Gradle, or
2. Install Gradle 8.10.2+ and run:

```bash
gradle :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Static checks

```bash
scripts/run_static_checks.sh
```

## Why no wrapper in this ZIP?

The earlier alpha ZIPs were generated in a restricted environment without Android SDK/Gradle Wrapper generation. The CI workflow uses a pinned Gradle version, so GitHub builds remain reproducible enough for this alpha stage. Add a real Gradle Wrapper later from a trusted Android Studio/Gradle installation rather than copying an unknown wrapper JAR.
