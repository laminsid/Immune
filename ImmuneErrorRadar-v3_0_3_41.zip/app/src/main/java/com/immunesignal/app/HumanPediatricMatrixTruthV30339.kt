package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.39 — source truth and null-result ledger for pediatric human oncology matrices.
 *
 * Goal: keep the app hypothesis-generative while preventing false upgrades. A bundled
 * human pediatric matrix can open a falsifiable discovery hypothesis, but its accession,
 * organism, statistics, seeded support, and replication status must stay explicit.
 */
object HumanPediatricMatrixTruthV30339 {
    const val REQUIRED_TOKEN: String = "V30339_HUMAN_PEDIATRIC_MATRIX_SOURCE_TRUTH_NULL_LEDGER"
    const val VERSION_NAME: String = "3.0.3.39-human-pediatric-matrix-truth-null-ledger"
    const val BOUNDARY: String = "Human pediatric matrix truth separates DGE fuel from retrieval evidence; null/non-significant DGE can generate new hypotheses but cannot certify discovery, mechanism support, treatment efficacy, diagnosis, or patient action."

    val humanPediatricDatasetCandidates: List<HumanPediatricDatasetCandidateV30339> = listOf(
        HumanPediatricDatasetCandidateV30339(
            accession = "GSE85047",
            organism = "HUMAN",
            disease = "primary untreated pediatric neuroblastoma",
            role = "EMBEDDED_EXPLICIT_MATRIX_FUEL",
            comparator = "MYCN_amplified_vs_non_amplified",
            rowState = "EMBEDDED_DECLARED_SOURCE_ROWS_PRESENT",
            upgradeUse = "first human pediatric MYCN DGE fuel; review-only until ETL mapping and replication"
        ),
        HumanPediatricDatasetCandidateV30339(
            accession = "TARGET-NBL",
            organism = "HUMAN",
            disease = "pediatric neuroblastoma",
            role = "INDEPENDENT_REPLICATION_CANDIDATE",
            comparator = "MYCN_high_or_amplified_vs_non_amplified; immune infiltration modules",
            rowState = "ROWS_NOT_EMBEDDED_REQUEST_ETL_OR_USER_MATRIX",
            upgradeUse = "replicate MYCN/TME direction and map gene-symbol immune modules"
        ),
        HumanPediatricDatasetCandidateV30339(
            accession = "GSE49710",
            organism = "HUMAN",
            disease = "primary neuroblastoma",
            role = "HUMAN_REPLICATION_CANDIDATE",
            comparator = "MYCN/status/risk labels if available",
            rowState = "ROWS_NOT_EMBEDDED_REQUEST_ETL_OR_USER_MATRIX",
            upgradeUse = "second human cohort candidate before score >=8"
        ),
        HumanPediatricDatasetCandidateV30339(
            accession = "GSE3446",
            organism = "HUMAN",
            disease = "metastatic neuroblastoma lacking MYCN amplification",
            role = "CONTROL_OR_CONTEXT_CANDIDATE_NOT_PRIMARY_MYCN_COMPARATOR",
            comparator = "age/risk groups; not a complete MYCN-amplified comparator by itself",
            rowState = "ROWS_NOT_EMBEDDED_REQUEST_ETL_OR_USER_MATRIX",
            upgradeUse = "context/falsifier only unless paired with MYCN-amplified cohort"
        )
    )

    fun evaluate(
        topic: String,
        state: ResearchStateV3,
        expressionSignal: ProcessedExpressionSignalReportV30329
    ): HumanPediatricMatrixTruthSnapshotV30339 {
        val focus = PediatricOncologyUnifiedFocusV30338.isFocus(topic, expressionSignal.dataset) ||
            expressionSignal.matrixFuel?.fuelOrigin == PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN
        if (!focus) return HumanPediatricMatrixTruthSnapshotV30339.inactive()

        val fuel = expressionSignal.matrixFuel
        val top = expressionSignal.estimates
            .filter { it.rawMatrixDgeExecuted }
            .maxByOrNull { kotlin.math.abs(it.effectSize) }
        val matrixSource = fuel?.matrixFuelSourceAccession ?: fuel?.accession ?: "none"
        val dgeOn = fuel?.dgeExecutedOnAccession ?: expressionSignal.dataset
        val retrievalBest = fuel?.retrievalEvidenceBestAccession ?: expressionSignal.dataset
        val evidenceAccessions = state.ledgerSnapshot.visibleEvidence.mapNotNull { it.accession?.trim()?.takeIf { a -> a.isNotBlank() } }.distinct()
        val mouseEvidence = state.ledgerSnapshot.visibleEvidence
            .filter { it.organismMatch.equals("MOUSE", true) }
            .mapNotNull { it.accession }
            .distinct()
            .take(6)
        val humanEvidence = state.ledgerSnapshot.visibleEvidence
            .filter { it.organismMatch.equals("HUMAN", true) }
            .mapNotNull { it.accession }
            .distinct()
            .take(6)
        val seededSupport = state.ledgerSnapshot.visibleEvidence
            .filter { it.accession.orEmpty().startsWith("PEDONC_SOURCE") || it.source == SourceKindV3.LOCAL_MEMORY }
            .mapNotNull { it.accession }
            .distinct()
        val independentSupport = state.ledgerSnapshot.visibleEvidence
            .filter { node ->
                node.countsAsSupport &&
                    !node.accession.orEmpty().startsWith("PEDONC_SOURCE") &&
                    node.source != SourceKindV3.LOCAL_MEMORY &&
                    node.accession.orEmpty().isNotBlank()
            }
            .mapNotNull { it.accession }
            .distinct()
        val ciCrossesZero = top?.markerResults?.let { results ->
            results.isNotEmpty() && results.minOf { it.ciLow } <= 0.0 && results.maxOf { it.ciHigh } >= 0.0
        } ?: false
        val bestP = top?.markerResults?.minOfOrNull { it.adjustedPValue } ?: 1.0
        val medianP = top?.markerResults?.map { it.adjustedPValue }?.sorted()?.let { it[it.size / 2] } ?: 1.0
        val nullState = when {
            top == null -> "NO_RAW_DGE_TO_CLASSIFY"
            ciCrossesZero && bestP > 0.05 -> "DIRECTIONAL_NULL_REVIEW_SIGNAL_CI_CROSSES_ZERO_P_NOT_SIGNIFICANT"
            ciCrossesZero -> "DIRECTIONAL_SIGNAL_UNSTABLE_CI_CROSSES_ZERO"
            bestP <= 0.05 -> "DIRECTIONAL_SIGNAL_STATISTICALLY_VISIBLE_REVIEW_ONLY_REQUIRES_REPLICATION"
            else -> "DIRECTIONAL_REVIEW_SIGNAL_NOT_NULL_BY_CI_BUT_NOT_DISCOVERY_CERTIFIED"
        }
        val organismState = when {
            matrixSource.equals(PediatricOncologyExplicitMatrixV30337.SOURCE_ACCESSION, true) -> "HUMAN_PEDIATRIC_MATRIX_SOURCE_PRIORITY"
            mouseEvidence.isNotEmpty() && humanEvidence.isEmpty() -> "MOUSE_MODEL_CONTEXT_ONLY_HUMAN_MATRIX_REQUIRED"
            mouseEvidence.isNotEmpty() && humanEvidence.isNotEmpty() -> "MIXED_ORGANISM_EVIDENCE_HUMAN_MATRIX_MUST_CONTROL_UPGRADE"
            else -> "ORGANISM_SUPPORT_REVIEW_ONLY"
        }
        val sourceTruthState = when {
            matrixSource.equals("none", true) -> "NO_MATRIX_SOURCE_TO_VERIFY"
            !dgeOn.equals(matrixSource, true) -> "MATRIX_SOURCE_MISMATCH_BLOCKS_DISCOVERY_UPGRADE"
            !top?.accession.orEmpty().equals(matrixSource, true) -> "SIGNAL_ACCESSION_MISMATCH_BLOCKS_DISCOVERY_UPGRADE"
            else -> "MATRIX_SOURCE_TRUTH_CLEAN"
        }
        val seedState = when {
            seededSupport.isNotEmpty() && independentSupport.isEmpty() -> "SEEDED_SUPPORT_ONLY_NOT_INDEPENDENT"
            seededSupport.isNotEmpty() -> "SEEDED_SUPPORT_PRESENT_BUT_NOT_COUNTED_AS_INDEPENDENT"
            else -> "NO_SEEDED_SUPPORT_DOMINANCE_DETECTED"
        }
        val generatedHypotheses = rankHypotheses(nullState, top?.effectSize ?: 0.0)
        val upgradeBlockers = mutableListOf<String>()
        if (sourceTruthState != "MATRIX_SOURCE_TRUTH_CLEAN") upgradeBlockers += "matrix_signal_source_mismatch"
        if (organismState.contains("MOUSE_MODEL")) upgradeBlockers += "human_pediatric_matrix_required"
        if (seedState == "SEEDED_SUPPORT_ONLY_NOT_INDEPENDENT") upgradeBlockers += "seeded_support_not_independent"
        if (nullState.contains("NULL") || nullState.contains("UNSTABLE")) upgradeBlockers += "null_or_unstable_statistics"
        if (fuel?.certifiedForDiscovery != true) upgradeBlockers += "matrix_not_certified_or_replicated"

        return HumanPediatricMatrixTruthSnapshotV30339(
            active = true,
            state = "HUMAN_PEDIATRIC_MATRIX_TRUTH_READY",
            sourceTruthState = sourceTruthState,
            matrixFuelSourceAccession = matrixSource,
            dgeExecutedOnAccession = dgeOn,
            retrievalEvidenceBestAccession = retrievalBest,
            signalEstimateAccession = top?.accession ?: "none",
            organismPriorityState = organismState,
            humanEvidenceAccessions = humanEvidence,
            mouseEvidenceAccessions = mouseEvidence,
            seedIndependenceState = seedState,
            seededSupportAccessions = seededSupport,
            independentSupportAccessions = independentSupport,
            nullResultState = nullState,
            effectSize = top?.effectSize ?: 0.0,
            bestAdjustedP = bestP,
            medianAdjustedP = medianP,
            ciCrossesZero = ciCrossesZero,
            generatedHypotheses = generatedHypotheses,
            upgradeBlockers = upgradeBlockers.distinct(),
            datasetCandidates = humanPediatricDatasetCandidates,
            nextAction = nextAction(nullState, sourceTruthState)
        )
    }

    private fun rankHypotheses(nullState: String, effect: Double): List<GeneratedPediatricHypothesisV30339> {
        val direction = if (effect < -0.2) "directionally_colder_mycn_high" else if (effect > 0.2) "directionally_hotter_mycn_high" else "near_null_mycn_bulk"
        return listOf(
            GeneratedPediatricHypothesisV30339(
                id = "H1_NULL_AWARE_MYCN_NOT_SUFFICIENT",
                rank = 1,
                hypothesis = "MYCN amplification alone may be an insufficient classifier for pediatric neuroblastoma immune-cold state; the stronger discovery target is a MYCN-high subgroup split by CD8/NK cytotoxicity plus GD2/B7-H3 target-barrier axes.",
                whyNew = "It treats the current non-significant MYCN bulk result as a falsifier of a simple MYCN→cold-TME story and redirects discovery toward subgroup structure.",
                requiredTest = "Run GSE85047 gene-mapped rows plus an independent human cohort; stratify MYCN-amplified tumors by CD8/NK module, CD276/B7-H3, GD2 biosynthesis, hypoxia/stroma markers.",
                currentEvidenceState = nullState,
                priority = "HIGH_DISCOVERY_VALUE_IF_REPLICATED"
            ),
            GeneratedPediatricHypothesisV30339(
                id = "H2_GD2_ADCC_ESCAPE_SPLIT",
                rank = 2,
                hypothesis = "In pediatric neuroblastoma, GD2/dinutuximab-relevant ADCC may fail not because GD2 biology is absent, but because FCGR3A/NK cytotoxic recruitment and antigen-presentation context are uncoupled from MYCN status.",
                whyNew = "It moves beyond MYCN risk status into a response-mechanism axis that needs treatment-response or immune-effector labels.",
                requiredTest = "Acquire human neuroblastoma response-labeled data for anti-GD2/dinutuximab-beta + chemotherapy, or a single-cell/spatial dataset with GD2-pathway and NK/CD8 effector compartments.",
                currentEvidenceState = "TRANSLATION_HYPOTHESIS_REQUIRES_RESPONSE_LABELED_HUMAN_DATA",
                priority = "MEDIUM_HIGH_TRANSLATION_VALUE"
            ),
            GeneratedPediatricHypothesisV30339(
                id = "H3_B7H3_TME_PENETRATION_BARRIER",
                rank = 3,
                hypothesis = "B7-H3/CD276-high pediatric solid tumors may require a dual readout: target abundance plus TME penetration barrier state; CD276 alone should not be treated as a CAR-T readiness proxy.",
                whyNew = "It converts B7-H3 CAR-T news into a falsifiable transcriptomic/spatial hypothesis rather than a treatment claim.",
                requiredTest = "Use pediatric solid-tumor single-cell/spatial matrices with CD276, T/NK infiltration, hypoxia/stroma and exclusion markers; compare infiltrated vs excluded regions.",
                currentEvidenceState = "MECHANISM_AXIS_OPEN_REVIEW_ONLY",
                priority = "HIGH_PLATFORM_HYPOTHESIS_VALUE"
            ),
            GeneratedPediatricHypothesisV30339(
                id = "H4_SINGLE_CELL_CELL_OF_ORIGIN_GATE",
                rank = 4,
                hypothesis = "Bulk neuroblastoma immune signals may be diluted by tumor-cell, myeloid, stromal and endothelial mixture; true discovery requires compartment-specific single-cell/spatial decomposition before mechanism support.",
                whyNew = "It explains why a bulk matrix can return a directional null while single-cell evidence still suggests immune exclusion.",
                requiredTest = "Replicate in human scRNA-seq/spatial pediatric neuroblastoma with cell-type labels and MYCN/risk metadata.",
                currentEvidenceState = direction,
                priority = "FOUNDATIONAL_MECHANISM_GATE"
            )
        )
    }

    private fun nextAction(nullState: String, sourceTruthState: String): String = when {
        sourceTruthState != "MATRIX_SOURCE_TRUTH_CLEAN" -> "Fix source truth first: DGE accession, matrix fuel source, module accession and retrieval evidence must be displayed separately before interpreting hypotheses."
        nullState.contains("NULL") -> "Treat current DGE as a documented null/directional seed; run human replication and subgroup discovery rather than marketing MYCN as proven immune-cold mechanism."
        else -> "Use current human pediatric matrix signal to rank hypotheses, then require independent human replication and single-cell/spatial compartment mapping before any score >=8 upgrade."
    }
}

data class HumanPediatricDatasetCandidateV30339(
    val accession: String,
    val organism: String,
    val disease: String,
    val role: String,
    val comparator: String,
    val rowState: String,
    val upgradeUse: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("accession", accession)
        .put("organism", organism)
        .put("disease", disease)
        .put("role", role)
        .put("comparator", comparator)
        .put("rowState", rowState)
        .put("upgradeUse", upgradeUse)
}

data class GeneratedPediatricHypothesisV30339(
    val id: String,
    val rank: Int,
    val hypothesis: String,
    val whyNew: String,
    val requiredTest: String,
    val currentEvidenceState: String,
    val priority: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("rank", rank)
        .put("hypothesis", hypothesis)
        .put("whyNew", whyNew)
        .put("requiredTest", requiredTest)
        .put("currentEvidenceState", currentEvidenceState)
        .put("priority", priority)
}

data class HumanPediatricMatrixTruthSnapshotV30339(
    val active: Boolean,
    val state: String,
    val sourceTruthState: String,
    val matrixFuelSourceAccession: String,
    val dgeExecutedOnAccession: String,
    val retrievalEvidenceBestAccession: String,
    val signalEstimateAccession: String,
    val organismPriorityState: String,
    val humanEvidenceAccessions: List<String>,
    val mouseEvidenceAccessions: List<String>,
    val seedIndependenceState: String,
    val seededSupportAccessions: List<String>,
    val independentSupportAccessions: List<String>,
    val nullResultState: String,
    val effectSize: Double,
    val bestAdjustedP: Double,
    val medianAdjustedP: Double,
    val ciCrossesZero: Boolean,
    val generatedHypotheses: List<GeneratedPediatricHypothesisV30339>,
    val upgradeBlockers: List<String>,
    val datasetCandidates: List<HumanPediatricDatasetCandidateV30339>,
    val nextAction: String,
    val boundary: String = HumanPediatricMatrixTruthV30339.BOUNDARY
) {
    fun toJson(): JSONObject = JSONObject()
        .put("schema", "human_pediatric_matrix_truth_v30339")
        .put("requiredToken", HumanPediatricMatrixTruthV30339.REQUIRED_TOKEN)
        .put("active", active)
        .put("state", state)
        .put("sourceTruthState", sourceTruthState)
        .put("matrixFuelSourceAccession", matrixFuelSourceAccession)
        .put("dgeExecutedOnAccession", dgeExecutedOnAccession)
        .put("retrievalEvidenceBestAccession", retrievalEvidenceBestAccession)
        .put("signalEstimateAccession", signalEstimateAccession)
        .put("organismPriorityState", organismPriorityState)
        .put("humanEvidenceAccessions", JSONArray(humanEvidenceAccessions))
        .put("mouseEvidenceAccessions", JSONArray(mouseEvidenceAccessions))
        .put("seedIndependenceState", seedIndependenceState)
        .put("seededSupportAccessions", JSONArray(seededSupportAccessions))
        .put("independentSupportAccessions", JSONArray(independentSupportAccessions))
        .put("nullResultState", nullResultState)
        .put("effectSize", round3(effectSize))
        .put("bestAdjustedP", round4(bestAdjustedP))
        .put("medianAdjustedP", round4(medianAdjustedP))
        .put("ciCrossesZero", ciCrossesZero)
        .put("generatedHypotheses", JSONArray(generatedHypotheses.map { it.toJson() }))
        .put("upgradeBlockers", JSONArray(upgradeBlockers))
        .put("datasetCandidates", JSONArray(datasetCandidates.map { it.toJson() }))
        .put("nextAction", nextAction)
        .put("boundary", boundary)

    companion object {
        fun inactive(): HumanPediatricMatrixTruthSnapshotV30339 = HumanPediatricMatrixTruthSnapshotV30339(
            active = false,
            state = "HUMAN_PEDIATRIC_MATRIX_TRUTH_INACTIVE",
            sourceTruthState = "not_applicable",
            matrixFuelSourceAccession = "none",
            dgeExecutedOnAccession = "none",
            retrievalEvidenceBestAccession = "none",
            signalEstimateAccession = "none",
            organismPriorityState = "not_applicable",
            humanEvidenceAccessions = emptyList(),
            mouseEvidenceAccessions = emptyList(),
            seedIndependenceState = "not_applicable",
            seededSupportAccessions = emptyList(),
            independentSupportAccessions = emptyList(),
            nullResultState = "not_applicable",
            effectSize = 0.0,
            bestAdjustedP = 1.0,
            medianAdjustedP = 1.0,
            ciCrossesZero = false,
            generatedHypotheses = emptyList(),
            upgradeBlockers = emptyList(),
            datasetCandidates = emptyList(),
            nextAction = "inactive"
        )
    }
}
