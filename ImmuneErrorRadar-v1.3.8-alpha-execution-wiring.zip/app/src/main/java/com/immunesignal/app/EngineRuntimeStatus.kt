package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.3.8: execution wiring guard.
 *
 * Earlier versions could write a correct pivot in the report without proving
 * that the next run actually executed the forced evidence path. This object is
 * intentionally small and explicit: it records which engine is active, which
 * modules are on, which research state was forced, which queries were actually
 * executed, and whether the execution lock passed.
 */
data class ActiveResearchEngineStatus(
    val engineVersion: String,
    val activeModules: List<String>,
    val researchState: String,
    val appliedPivotType: String,
    val effectiveMaxQueries: Int,
    val effectiveResultsPerQuery: Int,
    val runtimeFailoverApplied: Boolean,
    val forcedQueries: List<String>,
    val executedQueryIds: List<String>
)

data class ExecutionLockReport(
    val status: String,
    val failures: List<String>,
    val enforcedActions: List<String>
)

object EngineRuntimeStatus {
    const val ACTIVE_ENGINE_VERSION = "v1.3.8-alpha-execution-wiring"

    val ACTIVE_MODULES = listOf(
        "SmartReportIntegrityLock",
        "ScopeDisciplineLock",
        "AutonomousStagnationEngine",
        "EvidenceLearningOS",
        "DatasetAccessionResolver",
        "LaneCooldown",
        "ExecutionWiringGuard",
        "RuntimeDatasetHuntFailover"
    )

    fun stateFor(appliedPivot: PivotDecision, stagnationActive: Boolean): String {
        val pivotText = (appliedPivot.pivotType + " " + appliedPivot.nextIntent + " " + appliedPivot.nextQuerySeed).lowercase()
        return when {
            pivotText.contains("dataset") || pivotText.contains("accession") -> "DATASET_HUNT"
            pivotText.contains("contradiction") || pivotText.contains("negative control") -> "CONTRADICTION_HUNT"
            stagnationActive -> "STAGNATION_RECOVERY"
            appliedPivot.pivotType != "NO_PIVOT" -> "FORCED_EVIDENCE_PATH"
            else -> "RESEARCH_NORMAL"
        }
    }

    fun enforceQueryBudget(
        baseLimits: ResearchRunLimits,
        appliedPivot: PivotDecision,
        stagnationPlan: AutonomousStagnationEngine.StagnationPlan
    ): Pair<Int, Int> {
        val forced = appliedPivot.pivotType != "NO_PIVOT" || stagnationPlan.active
        val maxQueries = maxOf(baseLimits.maxQueries, stagnationPlan.effectiveMaxQueries, if (forced) 6 else baseLimits.maxQueries)
        val retMax = maxOf(baseLimits.maxResultsPerQuery, stagnationPlan.effectiveResultsPerQuery, if (forced) 20 else baseLimits.maxResultsPerQuery)
        return maxQueries to retMax
    }

    fun hardStagnationTriggered(newFindingsCount: Int, repeatedSkipped: Int, datasetCandidateCount: Int): Boolean {
        return newFindingsCount <= 0 && repeatedSkipped >= 10 && datasetCandidateCount <= 0
    }

    fun runtimeFailoverPivot(repeatedSkipped: Int): PivotDecision {
        return ScopeDisciplineLock.sanitizePivot(
            PivotDecision(
                pivotType = "RUNTIME_STAGNATION_DATASET_HUNT",
                reason = "Hard stagnation triggered during this run: no fresh useful sources, repeated skipped=$repeatedSkipped, and no dataset candidate. Execute dataset/accession hunt now instead of only writing a future pivot.",
                nextIntent = "runtime_dataset_hunt",
                nextQuerySeed = "GSE OR GEO OR SDY OR ImmPort OR PRJNA OR SRP RNA-seq single-cell immune response outcome severity longitudinal negative control",
                priority = 99
            )
        )
    }

    fun buildExecutionLock(
        runtimeStatus: ActiveResearchEngineStatus,
        learningOsReport: LearningOsReport,
        hardStagnationObserved: Boolean
    ): ExecutionLockReport {
        val failures = mutableListOf<String>()
        val enforced = mutableListOf<String>()

        if (runtimeStatus.engineVersion != ACTIVE_ENGINE_VERSION) {
            failures += "Active engine version mismatch."
        }
        if (runtimeStatus.activeModules.toSet().containsAll(ACTIVE_MODULES).not()) {
            failures += "Not all v1.3.8 execution modules are active."
        }

        if (runtimeStatus.appliedPivotType != "NO_PIVOT") {
            if (runtimeStatus.forcedQueries.isEmpty()) failures += "Forced pivot exists but no forced queries were generated."
            if (runtimeStatus.executedQueryIds.none { it.startsWith("q_pivot_") || it.startsWith("q_antistag_") || it.startsWith("q_runtime_") }) {
                failures += "Forced pivot exists but no forced query id was executed."
            }
            enforced += "Forced evidence path executed for ${runtimeStatus.appliedPivotType}."
        }

        if (hardStagnationObserved) {
            val causes = learningOsReport.incident.rootCauses
            if (causes.isEmpty()) failures += "Hard stagnation observed but no root cause was recorded."
            if (learningOsReport.preventiveGates.isEmpty()) failures += "Hard stagnation observed but no preventive gate was created."
            if (learningOsReport.regressionVectors.isEmpty()) failures += "Hard stagnation observed but no regression vector was created."
            if (learningOsReport.laneCooldowns.isEmpty()) failures += "Hard stagnation observed but no lane cooldown was created."
            enforced += "Hard stagnation converted to incident, gate, regression vector, and cooldown."
        }

        if (runtimeStatus.runtimeFailoverApplied) {
            enforced += "Runtime dataset hunt failover executed inside the same cycle."
        }

        return ExecutionLockReport(
            status = if (failures.isEmpty()) "PASS" else "FAIL",
            failures = failures,
            enforcedActions = enforced.ifEmpty { listOf("Normal research cycle; no forced execution needed.") }
        )
    }

    fun runtimeStatusToJson(item: ActiveResearchEngineStatus): JSONObject = JSONObject()
        .put("engineVersion", item.engineVersion)
        .put("activeModules", JSONArray(item.activeModules))
        .put("researchState", item.researchState)
        .put("appliedPivotType", item.appliedPivotType)
        .put("effectiveMaxQueries", item.effectiveMaxQueries)
        .put("effectiveResultsPerQuery", item.effectiveResultsPerQuery)
        .put("runtimeFailoverApplied", item.runtimeFailoverApplied)
        .put("forcedQueries", JSONArray(item.forcedQueries))
        .put("executedQueryIds", JSONArray(item.executedQueryIds))

    fun executionLockToJson(item: ExecutionLockReport): JSONObject = JSONObject()
        .put("status", item.status)
        .put("failures", JSONArray(item.failures))
        .put("enforcedActions", JSONArray(item.enforcedActions))
}
