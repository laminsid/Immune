package com.immunesignal.app

/**
 * Final v3.0.3.34 post-report closure guard.
 *
 * This closes the user-attested matrix line after the report-driven hardening wave:
 * - no implicit lite/scaffold rows are injected into ordinary runs,
 * - user-attested matrices remain declared-source, not app-certified,
 * - legacy identity guards must not leak mismatch warnings into v3.0.3.34,
 * - contaminated RA/cancer ontology input is sanitized or isolated,
 * - Alzheimer/diabetes comparisons are exposed as dual-lane plans,
 * - static-check runner calls stay direct and do not use undefined helper functions.
 */
object ResearchEngineV30334PostReportFinalGuard {
    const val REQUIRED_TOKEN: String = "V30334_POST_REPORT_FINAL_CLOSURE_GUARD"
    const val IDENTITY: String = "V30334_POST_REPORT_FINAL_NO_IMPLICIT_LITE_ROWS_DUAL_LANE_ONTOLOGY_IDENTITY"
    const val FINAL_VERSION_NAME: String = "3.0.3.34-final-unified-user-attested-matrix-engine"
    const val FINAL_ENGINE_VERSION: String = "v3.0.3.34-final-unified-user-attested-matrix-engine"
    const val FINAL_SCHEMA_VERSION: String = "3.0.3.34-final-unified"
    const val FINAL_VERSION_CODE_MIN: Int = 254
    const val NO_IMPLICIT_LITE_ROWS_RULE: String = "NO_IMPLICIT_LITE_SCAFFOLD_ROWS_WITHOUT_EXPLICIT_OPT_IN"
    const val USER_MATRIX_BOUNDARY: String = "USER_ATTESTED_DECLARED_SOURCE_NOT_APP_CERTIFIED_NO_SCORE_8_NO_DISCOVERY"
    const val DUAL_LANE_RULE: String = "ALZHEIMER_DIABETES_COMPARATIVE_DUAL_LANE_VISIBLE_IN_REPORT"
    const val ONTOLOGY_CONTAMINATION_RULE: String = "RA_TUMOR_ASSOCIATED_TERMS_SANITIZED_OR_REQUIRE_EXPLICIT_COMPARATIVE_FRAME"

    fun warnings(): List<String> {
        if (ResearchEngineV3ReleaseIdentity.UNIFICATION_TOKEN == ResearchEngineV30335CuratedCapsuleMatrixFuelGuard.IDENTITY) return emptyList()
        val warnings = mutableListOf<String>()
        if (ResearchEngineV3ReleaseIdentity.VERSION_NAME != FINAL_VERSION_NAME) warnings += "v30334_post_report_final_version_name_mismatch:${ResearchEngineV3ReleaseIdentity.VERSION_NAME}"
        if (ResearchEngineV3ReleaseIdentity.ENGINE_VERSION != FINAL_ENGINE_VERSION) warnings += "v30334_post_report_final_engine_version_mismatch:${ResearchEngineV3ReleaseIdentity.ENGINE_VERSION}"
        if (ResearchEngineV3ReleaseIdentity.SCHEMA_VERSION != FINAL_SCHEMA_VERSION) warnings += "v30334_post_report_final_schema_version_mismatch:${ResearchEngineV3ReleaseIdentity.SCHEMA_VERSION}"
        if (ResearchEngineV3ReleaseIdentity.VERSION_CODE < FINAL_VERSION_CODE_MIN) warnings += "v30334_post_report_final_version_code_below_254"
        if (ResearchEngineV3ReleaseIdentity.UNIFICATION_TOKEN != ResearchEngineV30334FinalUnificationGuard.IDENTITY) warnings += "v30334_post_report_final_unification_token_mismatch"
        return warnings
    }
}
