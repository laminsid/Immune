package com.immunesignal.app

/**
 * v3.0.3.25 pediatric oncology discovery route.
 *
 * Research-only: this layer does not diagnose, treat, or claim clinical validity.
 * It prevents pediatric neuroblastoma prompts from drifting into generic adult
 * melanoma/prostate cancer TME results, and turns H1/H2 into a bounded proof
 * program: pediatric-domain accession resolution -> comparator labels ->
 * processed-expression route -> mechanism support -> exact-axis falsifier.
 */
data class PediatricOncologyAxisV30325(
    val id: String,
    val title: String,
    val mechanismTerms: List<String>,
    val markerGenes: List<String>,
    val comparatorAxes: List<String>,
    val datasetHandles: List<String>,
    val falsifierAxis: String
)

object PediatricOncologyDiscoveryV30325 {
    const val REQUIRED_TOKEN: String = "V30325_PEDIATRIC_ONCOLOGY_DISCOVERY_ROUTE"
    const val PROOF_TOKEN: String = "V30325_PEDIATRIC_HYPOTHESIS_PROOF_CONTINUES_TO_ACCESSION_COMPARATOR_EXPRESSION"

    private val pediatricCancerTerms = listOf(
        "pediatric", "paediatric", "childhood", "children", "infant", "infants", "child", "kids"
    )
    private val pediatricTumorTerms = listOf(
        "neuroblastoma", "medulloblastoma", "wilms", "ewing", "osteosarcoma", "pediatric leukemia", "paediatric leukemia", "childhood leukemia", "rhabdomyosarcoma"
    )

    val axes: List<PediatricOncologyAxisV30325> = listOf(
        PediatricOncologyAxisV30325(
            id = "NEUROBLASTOMA_MYCN_IMMUNE_EXCLUSION",
            title = "MYCN-amplified high-risk neuroblastoma immune-exclusion route",
            mechanismTerms = listOf("MYCN amplification", "immune exclusion", "low T-cell infiltration", "antigen presentation", "GD2 immunotherapy resistance", "NK-cell axis"),
            markerGenes = listOf("MYCN", "CD8A", "NKG7", "GNLY", "PRF1", "GZMB", "B2M", "HLA-A", "GD2", "B4GALNT1", "PDCD1", "CD274"),
            comparatorAxes = listOf("MYCN-amplified vs non-MYCN-amplified", "high-risk vs low-risk", "responder vs non-responder", "pre-treatment vs post-induction chemotherapy"),
            datasetHandles = listOf("EGAD00001009766", "GSE299403", "GSE3446", "GSE3960", "GSE85047"),
            falsifierAxis = "MYCN-amplified neuroblastoma does not show lower cytotoxic/NK-cell or antigen-presentation signals after comparator stratification"
        ),
        PediatricOncologyAxisV30325(
            id = "NEUROBLASTOMA_TAM_TREG_GD2_NICHE",
            title = "neuroblastoma TAM/Treg suppressive niche around GD2/NK immunotherapy axis",
            mechanismTerms = listOf("tumor-associated macrophage", "Treg", "GD2", "NK cell", "TIGIT", "NECTIN2", "myeloid suppression", "chemotherapy evolution"),
            markerGenes = listOf("CD68", "CD163", "MRC1", "FOXP3", "IL2RA", "TIGIT", "NECTIN2", "NCAM1", "FCGR3A", "NKG7"),
            comparatorAxes = listOf("pre-treatment vs post-treatment", "primary tumor vs metastasis", "tumor vs blood control", "high TAM/Treg vs low TAM/Treg"),
            datasetHandles = listOf("EGAD00001009766", "GSE299403", "GSE16476", "GSE85047"),
            falsifierAxis = "TAM/Treg or TIGIT/NECTIN2 signals are not enriched in neuroblastoma tumor or immune compartments compared with controls"
        ),
        PediatricOncologyAxisV30325(
            id = "NEUROBLASTOMA_HYPOXIA_EMT_NEURAL_CREST_PLASTICITY",
            title = "hypoxia/EMT neural-crest plasticity route in high-risk neuroblastoma immune escape",
            mechanismTerms = listOf("hypoxia", "EMT", "neural crest", "mesenchymal-like", "therapy resistance", "immune-cold tumor"),
            markerGenes = listOf("HIF1A", "VEGFA", "VIM", "SNAI1", "TWIST1", "SOX10", "PHOX2B", "HAND2", "CXCL12"),
            comparatorAxes = listOf("mesenchymal-like vs adrenergic-like", "high-risk vs low-risk", "pre-treatment vs relapse", "immune-cold vs immune-infiltrated"),
            datasetHandles = listOf("EGAD00001009766", "GSE299403", "GSE3446", "GSE85047"),
            falsifierAxis = "hypoxia/EMT plasticity is not associated with immune-cold or myeloid-enriched neuroblastoma compartments"
        )
    )

    fun isPediatricOncologyTopic(topic: String): Boolean {
        val text = topic.lowercase()
        return pediatricTumorTerms.any { text.contains(it) } ||
            (pediatricCancerTerms.any { text.contains(it) } && CancerHypothesisDiscoveryV30324.isCancerTopic(topic))
    }

    fun isNeuroblastomaTopic(topic: String): Boolean = topic.lowercase().contains("neuroblastoma")

    fun bestAxesFor(topic: String): List<PediatricOncologyAxisV30325> {
        val text = topic.lowercase()
        fun score(axis: PediatricOncologyAxisV30325): Int {
            val terms = axis.mechanismTerms + axis.markerGenes + axis.comparatorAxes + listOf(axis.id, axis.title)
            val exact = terms.count { text.contains(it.lowercase()) } * 4
            val tokens = terms.flatMap { it.lowercase().split(Regex("[^a-z0-9]+")) }
                .filter { it.length >= 3 }
                .distinct()
                .count { text.contains(it) }
            val neuroblastomaBoost = if (isNeuroblastomaTopic(topic) && axis.id.startsWith("NEUROBLASTOMA")) 10 else 0
            val mycnBoost = if (text.contains("mycn") && axis.id.contains("MYCN")) 8 else 0
            val gd2Boost = if (text.contains("gd2") && axis.id.contains("GD2")) 8 else 0
            return exact + tokens + neuroblastomaBoost + mycnBoost + gd2Boost
        }
        return axes.sortedWith(compareByDescending<PediatricOncologyAxisV30325> { score(it) }.thenBy { it.id }).take(3)
    }

    fun sourceQueries(topic: String): List<String> = sanitize(bestAxesFor(topic).flatMap { axis ->
        listOf(
            "pediatric neuroblastoma tumor immune microenvironment MYCN ${axis.title} PubMed",
            "high-risk neuroblastoma MYCN immune microenvironment CD8 NK macrophage Treg PubMed",
            "neuroblastoma single-cell RNA-seq tumor microenvironment immunotherapy GD2 PubMed",
            "neuroblastoma ${axis.markerGenes.take(5).joinToString(" ")} mechanism PubMed"
        )
    })

    fun datasetQueries(topic: String): List<String> = sanitize(bestAxesFor(topic).flatMap { axis ->
        listOf(
            "neuroblastoma single-cell RNA-seq tumor microenvironment MYCN GEO GSE",
            "pediatric neuroblastoma MYCN amplified non-amplified transcriptome GEO GSE",
            "high-risk neuroblastoma single-cell multiomic atlas EGAD00001009766",
            "GSE299403 Mycn neuroblastoma tumor microenvironment single-cell RNA-seq",
            "GSE3446 metastatic neuroblastoma lacking MYCN amplification expression profiling",
            "${axis.datasetHandles.joinToString(" ")} neuroblastoma comparator labels transcriptome"
        )
    })

    fun contradictionQueries(topic: String): List<String> = sanitize(bestAxesFor(topic).flatMap { axis ->
        listOf(
            "neuroblastoma MYCN immune exclusion no association CD8 NK cell PubMed",
            "${axis.falsifierAxis} negative control cohort PubMed",
            "high-risk neuroblastoma immune microenvironment failed to replicate comparator PubMed"
        )
    })

    fun proofQueries(topic: String): List<String> = sanitize(bestAxesFor(topic).flatMap { axis ->
        listOf(
            "${axis.datasetHandles.joinToString(" ")} sample metadata comparator labels MYCN amplified non-amplified high-risk low-risk tumor blood",
            "neuroblastoma processed expression matrix single-cell RNA-seq sample groups MYCN high-risk low-risk GEO EGA",
            "${axis.title} ${axis.markerGenes.take(8).joinToString(" ")} module support pediatric neuroblastoma",
            "${axis.falsifierAxis} exact-axis falsifier negative control"
        )
    })

    fun provenanceQueries(topic: String, evidenceId: String): List<String> = sanitize(listOf(
        "$evidenceId neuroblastoma sample metadata comparator labels MYCN amplified non-amplified",
        "$evidenceId high-risk low-risk neuroblastoma tumor blood single-cell sample groups",
        "$evidenceId processed expression matrix neuroblastoma pediatric oncology"
    ))

    fun hypotheses(topic: String): List<String> {
        val h1 = bestAxesFor(topic).getOrElse(0) { axes[0] }
        val h2 = bestAxesFor(topic).getOrElse(1) { axes[1] }
        return listOf(
            "H1: ${h1.title} may define the strongest pediatric neuroblastoma hypothesis; prove it by linking ${h1.comparatorAxes.take(2).joinToString(" or ")} to ${h1.markerGenes.take(7).joinToString("/")} modules in phenotype-matched pediatric neuroblastoma transcriptome or single-cell data.",
            "H2: ${h2.title} may explain therapy-resistant immune-cold neuroblastoma; test against ${h2.comparatorAxes.take(2).joinToString(" and ")} with sample-level comparator labels, processed-expression route, and exact-axis falsifier search.",
            "H3: Pediatric oncology hypotheses must not borrow adult generic TME evidence; upgrade only when neuroblastoma disease frame, child/pediatric tumor context, MYCN/risk comparator, immune-cell state, and expression matrix route are linked."
        )
    }

    fun expectedComparators(accession: String, title: String): List<String> {
        val text = (accession + " " + title).lowercase()
        return when {
            text.contains("egad00001009766") -> listOf(
                "diagnostic/pre-treatment vs post-induction chemotherapy",
                "primary tumor vs metastasis or infiltrated tissue",
                "tumor sample vs blood control if labelled",
                "TCR/immune-cell dynamics by neuroblastoma sample"
            )
            text.contains("gse299403") || text.contains("mycn") -> listOf(
                "Mycn-driven tumor vs control/model comparator",
                "tumor microenvironment cell-state labels",
                "T-cell/macrophage/NK compartment labels",
                "mouse model requires review-only human-translation boundary"
            )
            text.contains("gse3446") || text.contains("gse3960") || text.contains("gse85047") -> listOf(
                "MYCN-amplified vs non-MYCN or MYCN-low/high if labelled",
                "high-risk/metastatic vs lower-risk subgroup if labelled",
                "primary tumor sample group labels",
                "bulk expression route requires immune-deconvolution review"
            )
            else -> listOf(
                "pediatric neuroblastoma case vs control or tumor subgroup label",
                "MYCN-amplified vs non-amplified if labelled",
                "high-risk vs low-risk or responder vs non-responder if labelled",
                "tumor tissue, immune compartment, and treatment-timepoint labels"
            )
        }
    }

    fun processedExpressionRoute(accession: String, title: String): String {
        val text = (accession + " " + title).lowercase()
        return when {
            text.contains("egad00001009766") -> "PEDIATRIC_NEUROBLASTOMA_EGA_SINGLE_CELL_ROUTE_CANDIDATE_REVIEW_ONLY"
            text.contains("gse299403") -> "PEDIATRIC_NEUROBLASTOMA_MOUSE_SINGLE_CELL_ROUTE_CANDIDATE_REVIEW_ONLY"
            text.contains("gse3446") || text.contains("gse3960") || text.contains("gse85047") -> "PEDIATRIC_NEUROBLASTOMA_BULK_EXPRESSION_ROUTE_CANDIDATE_REVIEW_ONLY"
            text.contains("neuroblastoma") && (text.contains("single-cell") || text.contains("rna-seq") || text.contains("transcriptome")) -> "PEDIATRIC_NEUROBLASTOMA_EXPRESSION_ROUTE_CANDIDATE_REVIEW_ONLY"
            else -> "PROCESSED_EXPRESSION_ROUTE_NOT_VERIFIED"
        }
    }

    fun routeQuestions(accession: String, title: String): List<String> = listOf(
        "Do sample labels separate MYCN-amplified vs non-amplified, high-risk vs low-risk, or pre/post-treatment neuroblastoma?",
        "Are tumor, blood, metastatic/infiltrated tissue, immune-cell, NK-cell, macrophage, or T-cell compartments extractable?",
        "Can MYCN, GD2/B4GALNT1, CD8/NK cytotoxicity, TAM/Treg, TIGIT/NECTIN2, or hypoxia/EMT modules be scored against sample groups?",
        "Does an exact-axis falsifier show that the signal is generic tumor burden rather than pediatric neuroblastoma immune biology?"
    )

    fun isKnownPediatricDataset(accession: String): Boolean = accession.uppercase() in setOf(
        "EGAD00001009766", "GSE299403", "GSE3446", "GSE3960", "GSE85047", "GSE16476"
    )

    fun datasetCompatible(text: String): Boolean {
        val lower = text.lowercase()
        val disease = lower.contains("neuroblastoma") || lower.contains("mycn") && lower.contains("blastoma")
        val route = listOf("pediatric", "paediatric", "childhood", "high-risk", "mycn", "gd2", "single-cell", "single cell", "rna-seq", "transcriptome", "tumor microenvironment", "immune microenvironment", "macrophage", "treg", "nk cell", "cd8", "t cell").any { lower.contains(it) }
        val offRouteAdult = listOf("melanoma", "prostate", "bladder", "breast", "lung adenocarcinoma").any { lower.contains(it) } && !lower.contains("neuroblastoma")
        return disease && route && !offRouteAdult
    }

    fun markersFor(routeName: String): List<String> {
        val lower = routeName.lowercase()
        return when {
            lower.contains("mycn") || lower.contains("exclusion") -> listOf("MYCN", "CD8A", "NKG7", "GNLY", "GZMB", "B2M", "HLA-A", "B4GALNT1")
            lower.contains("gd2") || lower.contains("nk") || lower.contains("tigit") -> listOf("B4GALNT1", "NCAM1", "NKG7", "GNLY", "TIGIT", "NECTIN2", "CD68", "FOXP3")
            lower.contains("hypoxia") || lower.contains("emt") -> listOf("HIF1A", "VEGFA", "VIM", "SNAI1", "TWIST1", "SOX10", "PHOX2B")
            else -> listOf("MYCN", "CD8A", "NKG7", "CD68", "FOXP3", "B4GALNT1")
        }
    }

    fun curatedRecordsFor(role: EvidenceRoleV3, topic: String): List<EvidenceSearchRecordV3> {
        if (!isPediatricOncologyTopic(topic)) return emptyList()
        return when (role) {
            EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE -> listOf(
                EvidenceSearchRecordV3(
                    accession = "EGAD00001009766",
                    title = "Profiling of childhood neuroblastoma by single-cell RNA sequencing with tumor, infiltrated tissue, metastasis, blood controls and treatment-timepoint sample groups",
                    source = SourceKindV3.SRA,
                    abstractText = "pediatric neuroblastoma single-cell RNA-seq tumor microenvironment immune microenvironment pre-treatment post-induction chemotherapy relapse tumor blood TCR sample metadata"
                ),
                EvidenceSearchRecordV3(
                    accession = "GSE299403",
                    title = "Gene expression profile at single cell level of Mycn-nGEMM mouse neuroblastoma tumors and their tumor microenvironment",
                    source = SourceKindV3.GEO,
                    abstractText = "Mycn-driven neuroblastoma tumor microenvironment single-cell RNA-seq T cells macrophages immune microenvironment mouse model review-only pediatric translation"
                ),
                EvidenceSearchRecordV3(
                    accession = "GSE3446",
                    title = "Gene expression profiles of primary tumors from patients with metastatic neuroblastoma lacking MYCN amplification",
                    source = SourceKindV3.GEO,
                    abstractText = "human metastatic neuroblastoma primary tumors MYCN non-amplified expression profiling patient tumor samples"
                )
            )
            EvidenceRoleV3.SOURCE, EvidenceRoleV3.MECHANISM -> listOf(
                EvidenceSearchRecordV3(
                    accession = "PEDONC_SOURCE_NEUROBLASTOMA_SCRNA_001",
                    title = "Integrative analysis of neuroblastoma by single-cell RNA sequencing identifies the NECTIN2-TIGIT axis as a target for immunotherapy",
                    source = SourceKindV3.PMC,
                    abstractText = "pediatric high-risk neuroblastoma single-cell RNA sequencing tumor microenvironment immunoregulatory interactions NECTIN2 TIGIT immunotherapy pre chemotherapy post chemotherapy"
                ),
                EvidenceSearchRecordV3(
                    accession = "PEDONC_SOURCE_MYCN_TME_002",
                    title = "Single-cell transcriptomics reveals that MYCN-driven neuroblastoma has low T-cell content and macrophage-rich immune microenvironment",
                    source = SourceKindV3.PMC,
                    abstractText = "MYCN-driven neuroblastoma immune microenvironment low T cells macrophage phenotypes tumor immune microenvironment single-cell transcriptomics"
                )
            )
            else -> emptyList()
        }
    }

    private fun sanitize(queries: List<String>): List<String> = queries
        .map { QuerySanitizerV3.noMalformedQuery(it) }
        .filter { it.isNotBlank() }
        .distinct()
        .take(10)
}
