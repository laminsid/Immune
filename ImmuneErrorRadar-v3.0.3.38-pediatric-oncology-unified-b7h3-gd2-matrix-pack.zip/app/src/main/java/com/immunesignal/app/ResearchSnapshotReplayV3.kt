package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/**
 * v3.0.3.18 — zero-network replay/audit surface.
 *
 * The replay key is useful only if it points to a deterministic payload. This
 * helper rebuilds a stable audit object from the stored session snapshot and
 * evidence ledger without touching NCBI. It does not claim to rerun science; it
 * proves that a report can be inspected/re-rendered from the captured run state.
 */
object ResearchSnapshotReplayV3 {
    val VERSION: String = ResearchEngineV3ReleaseIdentity.VERSION_NAME
    // legacy audit marker only: 3.0.3.20-final-unified-metadata-probe-runtime
    const val REQUIRED_TOKEN: String = "V30317_SNAPSHOT_REPLAY_WITHOUT_NETWORK"

    fun replayAudit(report: ResearchEngineReportV3): JSONObject = replayAudit(report.toJson())

    fun replayAudit(reportJson: JSONObject): JSONObject {
        val snapshot = reportJson.optJSONObject("sessionSnapshot") ?: JSONObject()
        val evidence = reportJson.optJSONArray("evidence") ?: JSONArray()
        val closure = reportJson.optJSONObject("closure") ?: JSONObject()
        val acceptedIds = snapshot.optJSONArray("acceptedEvidenceIds") ?: JSONArray()
        val rejectedIds = snapshot.optJSONArray("rejectedEvidenceIds") ?: JSONArray()
        val queries = snapshot.optJSONArray("queriesAttempted") ?: JSONArray()
        val seed = JSONObject()
            .put("replayKey", snapshot.optString("replayKey", ""))
            .put("normalizedQueryStem", snapshot.optString("normalizedQueryStem", ""))
            .put("queriesAttempted", queries)
            .put("acceptedEvidenceIds", acceptedIds)
            .put("rejectedEvidenceIds", rejectedIds)
            .put("closureOpenGates", closure.optJSONArray("openGates") ?: JSONArray())
            .put("evidenceAccessions", JSONArray((0 until evidence.length()).mapNotNull { i ->
                evidence.optJSONObject(i)?.optString("accession")?.takeIf { it.isNotBlank() }
            }))
        return JSONObject()
            .put("schema", "research_snapshot_replay_v3")
            .put("version", VERSION)
            .put("requiredToken", REQUIRED_TOKEN)
            .put("networkRequired", false)
            .put("replayKey", snapshot.optString("replayKey", ""))
            .put("normalizedQueryStem", snapshot.optString("normalizedQueryStem", ""))
            .put("domain", snapshot.optString("domain", "UNKNOWN"))
            .put("queriesAttempted", queries)
            .put("acceptedEvidenceIds", acceptedIds)
            .put("rejectedEvidenceIds", rejectedIds)
            .put("stableReplayHash", stableHash(seed.toString()))
            .put("canRebuildFromSnapshot", snapshot.length() > 0 && queries.length() > 0)
    }

    private fun stableHash(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .take(16)
        .joinToString("") { "%02x".format(it) }
}
