package com.immunesignal.app

sealed class ResearchObjectiveV3(
    open val topic: String,
    open val hypothesisId: String? = null,
    open val evidenceId: String? = null
) {
    abstract val id: String
    abstract val kind: String
    abstract fun querySeeds(): List<String>

    protected fun stem(): String = ResearchTopicNormalizerV3.profile(topic).toQueryStem()

    data class FindSourceEvidence(override val topic: String) : ResearchObjectiveV3(topic) {
        override val id: String = "source:$topic"
        override val kind: String = "FindSourceEvidence"
        override fun querySeeds(): List<String> = DomainQueryTemplateV3.sourceQueries(topic)
    }

    data class FindDatasetEvidence(override val topic: String) : ResearchObjectiveV3(topic) {
        override val id: String = "dataset:$topic"
        override val kind: String = "FindDatasetEvidence"
        override fun querySeeds(): List<String> = DomainQueryTemplateV3.datasetQueries(topic)
    }

    data class FindProvenance(override val topic: String, override val evidenceId: String) : ResearchObjectiveV3(topic, evidenceId = evidenceId) {
        override val id: String = "provenance:$evidenceId"
        override val kind: String = "FindProvenance"
        override fun querySeeds(): List<String> = DomainQueryTemplateV3.provenanceQueries(topic, evidenceId)
    }

    data class FindContradiction(override val topic: String, override val hypothesisId: String) : ResearchObjectiveV3(topic, hypothesisId = hypothesisId) {
        override val id: String = "contradiction:$hypothesisId"
        override val kind: String = "FindContradiction"
        override fun querySeeds(): List<String> = DomainQueryTemplateV3.contradictionQueries(topic)
    }

    data class RankHypotheses(override val topic: String) : ResearchObjectiveV3(topic) {
        override val id: String = "rank:$topic"
        override val kind: String = "RankHypotheses"
        override fun querySeeds(): List<String> = listOf(QuerySanitizerV3.noMalformedQuery("${stem()} hypothesis ranking evidence quality"))
    }

    /**
     * v3.0.3.23-p8: after hypotheses are ranked, the engine must continue trying
     * to strengthen or weaken them with targeted evidence. This objective is not
     * a final renderer; it searches for hypothesis-proof routes: comparator labels,
     * processed-expression/matrix linkage, tissue/cell-state mechanism evidence,
     * and exact-axis falsification cues.
     */
    data class ContinueHypothesisProof(override val topic: String, override val hypothesisId: String = "H1_PRIMARY") : ResearchObjectiveV3(topic, hypothesisId = hypothesisId) {
        override val id: String = "hypothesis_proof:$hypothesisId:$topic"
        override val kind: String = "ContinueHypothesisProof"
        override fun querySeeds(): List<String> {
            if (CancerHypothesisDiscoveryV30324.isCancerTopic(topic)) {
                return CancerHypothesisDiscoveryV30324.proofQueries(topic)
            }
            val base = stem()
            return listOf(
                "$base sample metadata comparator labels severity subtype healthy control tissue cell source transcriptome",
                "$base processed expression matrix RNA-seq single-cell GEO comparator sample groups",
                "$base immune mechanism validation tissue cell state pathway cohort falsifier negative control"
            ).map { QuerySanitizerV3.noMalformedQuery(it) }
        }
    }

    data class CompileReport(override val topic: String) : ResearchObjectiveV3(topic) {
        override val id: String = "compile:$topic"
        override val kind: String = "CompileReport"
        override fun querySeeds(): List<String> = emptyList()
    }
}

data class ResearchObjectiveOutcomeV3(
    val objective: ResearchObjectiveV3,
    val queriesAttempted: List<String>,
    val nodes: List<EvidenceNodeV3>,
    val exhausted: Boolean,
    val budgetDelta: BudgetUsageV3 = BudgetUsageV3(),
    val notes: List<String> = emptyList()
) {
    fun toSummaryLine(): String {
        val state = if (exhausted) "exhausted" else "executed"
        return "${objective.kind}[$state]: queries=${queriesAttempted.size}; nodes=${nodes.size}"
    }
}
