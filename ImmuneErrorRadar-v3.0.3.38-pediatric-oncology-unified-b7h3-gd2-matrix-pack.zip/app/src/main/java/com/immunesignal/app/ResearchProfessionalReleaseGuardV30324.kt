package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.24 professional-global release guard.
 *
 * This guard is intentionally about trustworthiness, not biological truth. It
 * prevents a polished report from looking stronger than its evidence route:
 * high-quality data can be displayed, but it cannot count as hypothesis support
 * unless topical relevance, disease-domain, organism, and tissue/mechanism gates
 * agree. It also confirms that the new dossier-learning and proof-loop surfaces
 * are connected on every V3 run.
 */
data class ResearchProfessionalReleaseGuardSnapshotV30324(
    val passed: Boolean,
    val blockers: List<String>,
    val warnings: List<String>,
    val releaseMode: String = "PROFESSIONAL_GLOBAL_RESEARCH_ONLY",
    val trustBoundary: String = "not_proof_not_diagnosis_not_treatment_not_clinical_advice",
    val supportCount: Int,
    val offRouteCount: Int,
    val visibleEvidenceCount: Int,
    val dossierLinked: Boolean,
    val proofLoopLinked: Boolean,
    val relevanceGateLinked: Boolean
) {
    fun toJson(): JSONObject = JSONObject()
        .put("passed", passed)
        .put("blockers", JSONArray(blockers))
        .put("warnings", JSONArray(warnings))
        .put("releaseMode", releaseMode)
        .put("trustBoundary", trustBoundary)
        .put("supportCount", supportCount)
        .put("offRouteCount", offRouteCount)
        .put("visibleEvidenceCount", visibleEvidenceCount)
        .put("dossierLinked", dossierLinked)
        .put("proofLoopLinked", proofLoopLinked)
        .put("relevanceGateLinked", relevanceGateLinked)
        .put("requiredToken", REQUIRED_TOKEN)

    companion object {
        const val REQUIRED_TOKEN: String = "V30324_PROFESSIONAL_GLOBAL_RELEASE_GUARD_RELEVANCE_DOSSIER_PROOF_LINKED"
    }
}

object ResearchProfessionalReleaseGuardV30324 {
    const val REQUIRED_TOKEN: String = ResearchProfessionalReleaseGuardSnapshotV30324.REQUIRED_TOKEN

    fun evaluate(
        state: ResearchStateV3,
        closure: ResearchClosureSnapshotV3,
        metadataProbe: ResearchMetadataProbeIngestionReportV3,
        datasetModuleScore: ResearchDatasetModuleScoreCardV3,
        proofContinuation: ResearchHypothesisProofContinuationSnapshotV3,
        dossierLearningReceipt: ResearchDossierLearningReceiptV30324
    ): ResearchProfessionalReleaseGuardSnapshotV30324 {
        val visible = state.ledgerSnapshot.visibleEvidence
        val support = visible.filter { it.countsAsSupport }
        val offRoute = visible.filter { !it.countsAsSupport }
        val blockers = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        val weakSupport = support.filter {
            it.topicalRelevance < 60 ||
                it.domainMatch != "PASS" ||
                it.diseaseMatch != "PASS" ||
                it.organismMatch == "PLANT"
        }
        if (weakSupport.isNotEmpty()) {
            warnings += "support_evidence_failed_professional_relevance_gate_review:${weakSupport.mapNotNull { it.accession }.distinct().take(5).joinToString(",").ifBlank { "visible_support" }}"
        }
        if (visible.any { it.organismMatch == "PLANT" && it.countsAsSupport }) {
            blockers += "non_mammalian_or_plant_evidence_counted_as_support"
        }
        if (closure.canCloseReport && support.isEmpty()) {
            blockers += "report_ready_without_supporting_evidence"
        }
        if (!dossierLearningReceipt.active) {
            warnings += "dossier_learning_receipt_missing_review"
        }
        if (!proofContinuation.active) {
            warnings += "hypothesis_proof_loop_missing_review"
        }
        if (visible.isNotEmpty() && visible.none { it.topicalRelevance < 100 || !it.countsAsSupport || it.domainMatch != "PASS" }) {
            warnings += "relevance_gate_surface_present_but_no_rejections_observed_in_this_run"
        }
        if (offRoute.any { it.accession.orEmpty().startsWith("GSE", ignoreCase = true) }) {
            warnings += "off_route_dataset_recorded_as_learning_signal_not_support"
        }
        if (metadataProbe.active && support.none { it.role in setOf(EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE) }) {
            warnings += "metadata_probe_waiting_for_supporting_dataset_or_provenance"
        }
        if (datasetModuleScore.active && datasetModuleScore.moduleScore > 0 && support.none { it.role in setOf(EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE) }) {
            warnings += "module_score_attempted_without_supporting_dataset_or_provenance_review"
        }
        val contradictionNoEvidenceMismatch = support.isEmpty() &&
            closure.contradictionObjectiveExhausted &&
            closure.noValidFalsifierFoundAfterSearch
        if (contradictionNoEvidenceMismatch) {
            warnings += "falsifier_exhaustion_not_interpretable_without_primary_support"
        }

        return ResearchProfessionalReleaseGuardSnapshotV30324(
            passed = blockers.isEmpty(),
            blockers = blockers.distinct(),
            warnings = warnings.distinct(),
            supportCount = support.size,
            offRouteCount = offRoute.size,
            visibleEvidenceCount = visible.size,
            dossierLinked = dossierLearningReceipt.active,
            proofLoopLinked = proofContinuation.active,
            relevanceGateLinked = true
        )
    }
}
