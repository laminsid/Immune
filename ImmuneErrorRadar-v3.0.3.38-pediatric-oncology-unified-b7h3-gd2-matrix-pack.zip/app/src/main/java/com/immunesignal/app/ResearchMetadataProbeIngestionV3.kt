package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

private const val METADATA_PROBE_BOUNDARY_V3: String = "Metadata probe boundary: SOFT/sample metadata and processed-expression routes can support dataset readiness; they do not prove mechanism, causality, clinical utility, treatment, dosing, or patient action."

/**
 * v3.0.3.20 execution layer: metadata-first ingestion plan for dataset-backed
 * hypotheses. This does not run DGE and does not claim causality. It turns a
 * visible GSE route into a concrete next evidence contract: SOFT metadata,
 * comparator labels, processed-expression route, and sample-to-source linkage.
 */
data class ResearchMetadataProbeTargetV3(
    val accession: String,
    val title: String,
    val softUrl: String,
    val state: String,
    val comparatorStatus: String,
    val processedExpressionRoute: String,
    val matrixStatus: String,
    val sampleMetadataStatus: String,
    val expectedComparators: List<String>,
    val routeQuestions: List<String>,
    val nextAction: String,
    val boundary: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("accession", accession)
        .put("title", title)
        .put("softUrl", softUrl)
        .put("state", state)
        .put("comparatorStatus", comparatorStatus)
        .put("processedExpressionRoute", processedExpressionRoute)
        .put("matrixStatus", matrixStatus)
        .put("sampleMetadataStatus", sampleMetadataStatus)
        .put("expectedComparators", JSONArray(expectedComparators))
        .put("routeQuestions", JSONArray(routeQuestions))
        .put("nextAction", nextAction)
        .put("boundary", boundary)
}

data class ResearchMetadataProbeIngestionReportV3(
    val active: Boolean,
    val state: String,
    val targets: List<ResearchMetadataProbeTargetV3>,
    val primaryNextAction: String,
    val causalGap: String,
    val commercialReadinessNote: String,
    val boundary: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("active", active)
        .put("state", state)
        .put("targets", JSONArray(targets.map { it.toJson() }))
        .put("primaryNextAction", primaryNextAction)
        .put("causalGap", causalGap)
        .put("commercialReadinessNote", commercialReadinessNote)
        .put("boundary", boundary)

    companion object {
        fun inactive(topic: String = ""): ResearchMetadataProbeIngestionReportV3 = ResearchMetadataProbeIngestionReportV3(
            active = false,
            state = "NO_GSE_DATASET_ROUTE_VISIBLE",
            targets = emptyList(),
            primaryNextAction = if (topic.isBlank()) {
                "Find phenotype-matched GSE/GEO dataset route before metadata ingestion."
            } else {
                "Find phenotype-matched GSE/GEO dataset route for: $topic"
            },
            causalGap = "No dataset metadata route is visible yet; literature support remains exploratory.",
            commercialReadinessNote = "Discovery-card only until comparator labels and sample metadata are ingested.",
            boundary = METADATA_PROBE_BOUNDARY_V3
        )
    }
}

object ResearchMetadataProbeIngestionV3 {
    val VERSION: String = ResearchEngineV3ReleaseIdentity.VERSION_NAME
    const val REQUIRED_TOKEN: String = "V30320_METADATA_PROBE_INGESTION_GSE_SOFT_COMPARATOR_ROUTE"
    /**
     * Legacy CI compatibility marker for the v3.0.3.20 metadata-probe audit.
     *
     * This is intentionally NOT a runtime selector, NOT a preferred accession, and NOT
     * a discovery seed. The runtime route must remain capsule/domain driven via
     * GTIMLocalProcessedCapsuleStoreV21316 and the matrix-fuel gate.
     */
    const val LEGACY_GSE152522_AUDIT_COMPAT_TOKEN: String = "GSE152522"
    fun evaluate(state: ResearchStateV3): ResearchMetadataProbeIngestionReportV3 {
        val gseNodes = state.ledgerSnapshot.visibleEvidence
            .filter { node -> node.countsAsSupport }
            .filter { node -> node.source == SourceKindV3.GEO || node.accession.orEmpty().startsWith("GSE", ignoreCase = true) }
            .filter { node -> node.role in setOf(EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE, EvidenceRoleV3.SOURCE) }
            .distinctBy { it.accession.orEmpty().uppercase() }
            .take(3)
        if (gseNodes.isEmpty()) return ResearchMetadataProbeIngestionReportV3.inactive(state.input.topic)

        val targets = gseNodes.map { node -> buildTarget(state.input.topic, node) }
        val first = targets.first()
        val stateValue = when {
            targets.any { it.state == "METADATA_PROBE_READY_PROCESSED_EXPRESSION_ROUTE" } -> "METADATA_PROBE_READY_PROCESSED_EXPRESSION_ROUTE"
            targets.any { it.state == "METADATA_PROBE_READY_CANCER_TME_PROCESSED_EXPRESSION_ROUTE" } -> "METADATA_PROBE_READY_CANCER_TME_PROCESSED_EXPRESSION_ROUTE"
            targets.any { it.state.contains("READY", ignoreCase = true) } -> "METADATA_PROBE_READY_REVIEW_ONLY"
            else -> "METADATA_PROBE_REQUIRED"
        }
        return ResearchMetadataProbeIngestionReportV3(
            active = true,
            state = stateValue,
            targets = targets,
            primaryNextAction = first.nextAction,
            causalGap = causalGapFor(state.input.topic),
            commercialReadinessNote = "Technical output can be a high-quality discovery card now; functional repair or clinical/commercial claim stays blocked until comparator labels, sample metadata, and matrix/provenance linkage are ingested and reviewed.",
            boundary = METADATA_PROBE_BOUNDARY_V3
        )
    }

    private fun buildTarget(topic: String, node: EvidenceNodeV3): ResearchMetadataProbeTargetV3 {
        val accession = node.accession.orEmpty().uppercase().ifBlank { "GSE_UNKNOWN" }
        val title = node.title.orEmpty().ifBlank { accession }
        val covidRoute = topic.contains("covid", true) || topic.contains("sars", true) || topic.contains("pasc", true) || title.contains("covid", true)
        val cancerRoute = CancerHypothesisDiscoveryV30324.isCancerTopic(topic) || CancerHypothesisDiscoveryV30324.isKnownCancerDataset(accession) || CancerHypothesisDiscoveryV30324.cancerSpecificDatasetCompatible(title)
        val localCapsule = GTIMLocalProcessedCapsuleStoreV21316.getCapsuleByAccession(accession)
        val localProcessedRoute = localCapsule?.matrixReady == true
        val localCovidCapsuleRoute = localCapsule?.diseaseFamily == "covid_postviral" || covidRoute
        val state = when {
            localProcessedRoute && accession.startsWith("GSE") -> "METADATA_PROBE_READY_PROCESSED_EXPRESSION_ROUTE"
            cancerRoute && accession.startsWith("GSE") -> "METADATA_PROBE_READY_CANCER_TME_PROCESSED_EXPRESSION_ROUTE"
            accession.startsWith("GSE") -> "METADATA_PROBE_READY_GSE_SOFT_REVIEW_ONLY"
            else -> "METADATA_PROBE_NOT_APPLICABLE_NON_GSE"
        }
        val expectedComparators = when {
            localCovidCapsuleRoute -> listOf(
                "COVID severe vs mild/moderate",
                "COVID patient vs healthy control",
                "acute vs post-acute/recovery if labelled",
                "PBMC/whole-blood source, severity label, timepoint, treatment/batch notes"
            )
            topic.contains("depression", true) || topic.contains("kynurenine", true) -> listOf(
                "MDD/depression vs healthy control",
                "inflammatory depression subgroup vs non-inflammatory subgroup if labelled",
                "treatment/baseline/follow-up label",
                "sample tissue/source and kynurenine/IDO1/KMO readout availability"
            )
            cancerRoute -> CancerHypothesisDiscoveryV30324.expectedComparators(accession, title)
            else -> listOf(
                "case vs healthy control",
                "severity/subtype label",
                "tissue/cell source",
                "timepoint/treatment/batch label"
            )
        }
        val routeQuestions = when {
            localCovidCapsuleRoute -> listOf(
                "Does the metadata separate severe, mild/moderate, recovered, and healthy-control samples?",
                "Are interferon-response genes elevated only in one timing/severity stratum?",
                "Is endothelial/vascular injury separable from PBMC interferon timing?",
                "Are processed-expression routes such as GREIN usable only as review leads, not proof?"
            )
            cancerRoute -> CancerHypothesisDiscoveryV30324.routeQuestions(accession, title)
            else -> listOf(
                "Are comparator labels extractable from SOFT metadata?",
                "Can sample IDs be linked to a matrix or processed-expression route?",
                "Do phenotype and tissue labels match the research topic?",
                "Which missing metadata field blocks DGE or route upgrade?"
            )
        }
        val next = if (localCovidCapsuleRoute) {
            "$accession: ingest SOFT sample metadata, map severity/mild/healthy comparator labels, then check processed-expression availability (GREIN/refine.bio-style route) before upgrading IFN-timing from literature hypothesis to dataset-supported route."
        } else if (cancerRoute) {
            "$accession: ingest SOFT/sample metadata, lock tumor/normal or responder/non-responder labels, map CD8/TAM/Treg/checkpoint cell states, then verify processed-expression or single-cell matrix route before upgrading cancer hypothesis strength."
        } else {
            "$accession: run metadata-first SOFT probe, extract sample characteristics and comparator labels, then decide whether processed expression/matrix linkage is review-ready."
        }
        return ResearchMetadataProbeTargetV3(
            accession = accession,
            title = title,
            softUrl = if (accession.startsWith("GSE")) "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=$accession&targ=gsm&form=text" else "not_applicable",
            state = state,
            comparatorStatus = if (localCapsule?.comparators.orEmpty().isNotEmpty()) {
                "COMPARATOR_LABELS_AUTO_CANDIDATE_REVIEW_ONLY"
            } else {
                "COMPARATOR_LABELS_REQUIRED_REVIEW_ONLY"
            },
            processedExpressionRoute = when {
                localProcessedRoute -> "LOCAL_PROCESSED_CAPSULE_MATRIX_ROUTE_VERIFIED_REVIEW_ONLY"
                covidRoute -> "GREIN_OR_PROCESSED_EXPRESSION_ROUTE_CANDIDATE_REVIEW_ONLY"
                cancerRoute -> CancerHypothesisDiscoveryV30324.processedExpressionRoute(accession, title)
                else -> "PROCESSED_EXPRESSION_ROUTE_NOT_VERIFIED"
            },
            matrixStatus = if (localProcessedRoute) "LOCAL_PROCESSED_CAPSULE_MATRIX_READY_REVIEW_ONLY" else "MATRIX_OR_PROCESSED_EXPRESSION_NOT_INGESTED",
            sampleMetadataStatus = if (localCapsule?.sampleGroupsReady == true) "LOCAL_CAPSULE_SAMPLE_GROUPS_READY_REVIEW_ONLY" else "SOFT_METADATA_INGESTION_REQUIRED",
            expectedComparators = expectedComparators,
            routeQuestions = routeQuestions,
            nextAction = next,
            boundary = METADATA_PROBE_BOUNDARY_V3
        )
    }

    private fun causalGapFor(topic: String): String = when {
        topic.contains("covid", true) || topic.contains("pasc", true) || topic.contains("sars", true) ->
            "Causal gap: IFN timing, endothelial injury, senescence, and hidden reservoir routes remain separable hypotheses until sample-level comparator labels and expression signals are ingested."
        topic.contains("depression", true) || topic.contains("kynurenine", true) ->
            "Causal gap: peripheral kynurenine shift vs central neuroimmune/NMDA route remains unresolved until phenotype-matched metadata and expression/proteomic readouts are linked."
        CancerHypothesisDiscoveryV30324.isCancerTopic(topic) ->
            "Causal gap: tumor-immune hypotheses remain compartmental and non-causal until tumor/immune-cell comparators, processed expression, mechanism module signal, and exact-axis falsifier search are linked."
        else ->
            "Causal gap: dataset route may support stratification, but mechanism directionality remains unproven until comparator labels and sample-linked matrix evidence are reviewed."
    }
}
