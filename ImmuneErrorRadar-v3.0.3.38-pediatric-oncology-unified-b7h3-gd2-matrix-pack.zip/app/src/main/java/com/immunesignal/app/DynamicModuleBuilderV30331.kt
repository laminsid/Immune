package com.immunesignal.app

/**
 * v3.0.3.31 — dynamic module construction for unseeded topics.
 *
 * This builds small, transparent marker panels when no curated capsule exists.
 * It is not proof; DYNAMIC_MODULE_REVIEW_ONLY means it only gives the signal executor a concrete module to compute
 * once disease-matched sample rows and comparator labels exist.
 */
object DynamicModuleBuilderV30331 {
    const val REQUIRED_TOKEN: String = "V30331_DYNAMIC_MODULE_BUILDER_UNSEEDED_DISEASE_TOPICS"

    fun build(
        topic: String,
        dataset: String,
        datasetModuleScore: ResearchDatasetModuleScoreCardV3,
        mechanismSignal: MechanismModuleSignalSnapshotV30328
    ): List<CapsuleModuleLite> {
        val lower = (topic + " " + dataset + " " + datasetModuleScore.capsuleId + " " + mechanismSignal.axis).lowercase()
        val pediatricTranslationModules = PediatricOncologyUnifiedFocusV30338.modulesFor(topic, dataset)
        val curatedModule = CuratedLightMatrixFuelPackV30335.moduleFor(topic, dataset)
        val modules = when {
            pediatricTranslationModules.isNotEmpty() -> pediatricTranslationModules
            curatedModule != null -> listOf(curatedModule)
            lower.contains("rheumatoid") || Regex("(^|[^a-z0-9])ra([^a-z0-9]|$)").containsMatchIn(lower) || lower.contains("synovial") -> listOf(
                CapsuleModuleLite("dynamic_ra_synovium_tnf_il6_il17_module", listOf("TNF", "IL6", "IL17A", "IL17F", "CCL2", "CXCL8", "MMP3", "CXCL13", "CD68", "LST1"), "case_enrichment_expected_review_only")
            )
            lower.contains("lupus nephritis") || lower.contains("kidney biopsy") || lower.contains("renal lupus") -> listOf(
                CapsuleModuleLite("dynamic_lupus_nephritis_ifn_complement_module", listOf("IFIT1", "ISG15", "MX1", "C1QA", "C3", "CXCL10", "STAT1", "IRF7"), "case_enrichment_expected_review_only")
            )
            lower.contains("multiple sclerosis") || lower.contains("rrms") || lower.contains("myelin") -> listOf(
                CapsuleModuleLite("dynamic_ms_myelin_microglia_il17_ifn_module", listOf("MBP", "MOG", "PLP1", "AIF1", "CX3CR1", "IL17A", "IFIT1", "ISG15"), "case_context_shift_expected_review_only")
            )
            lower.contains("neuroblastoma") || lower.contains("mycn") -> listOf(
                CapsuleModuleLite("dynamic_neuroblastoma_mycn_cd8_tigit_module", listOf("MYCN", "CD8A", "NKG7", "GNLY", "PRF1", "GZMB", "B2M", "TIGIT", "NECTIN2"), "mycn_high_immune_exclusion_review_only")
            )
            lower.contains("cancer") || lower.contains("tumor") || lower.contains("tumour") || lower.contains("checkpoint") -> listOf(
                CapsuleModuleLite("dynamic_cancer_cd8_checkpoint_tme_module", listOf("CD8A", "GZMB", "PRF1", "PDCD1", "CD274", "FOXP3", "VEGFA", "CXCL9", "CXCL10"), "immune_excluded_or_checkpoint_shift_review_only"),
                CapsuleModuleLite("dynamic_cancer_hypoxia_emt_myeloid_module", listOf("VEGFA", "CA9", "VIM", "SNAI1", "CD68", "LST1", "IL10", "TGFB1"), "hypoxia_emt_myeloid_remodeling_review_only")
            )
            lower.contains("ulcerative colitis") || lower.contains("crohn") || lower.contains("ibd") -> listOf(
                CapsuleModuleLite("dynamic_ibd_epithelial_neutrophil_il23_module", listOf("IL23A", "IL23R", "CXCL8", "S100A8", "S100A9", "MUC2", "CLDN1", "REG3A"), "barrier_neutrophil_axis_review_only")
            )
            lower.contains("allergy") || lower.contains("allergic") || lower.contains("asthma") -> listOf(
                CapsuleModuleLite("dynamic_allergy_type2_il4_il5_il13_module", listOf("IL4", "IL5", "IL13", "FCER1A", "CLC", "POSTN"), "type2_allergic_inflammation_review_only")
            )
            lower.contains("inflammation") || lower.contains("inflammatory") || lower.contains("cytokine") -> listOf(
                CapsuleModuleLite("dynamic_general_inflammation_tnf_il6_il1b_module", listOf("TNF", "IL6", "IL1B", "CXCL8", "NFKB1", "PTGS2"), "generic_inflammation_review_only")
            )
            lower.contains("alzheimer") || lower.contains("c1q") || lower.contains("synaptic") -> listOf(
                CapsuleModuleLite("dynamic_alzheimer_microglia_c1q_complement_module", listOf("C1QA", "C1QB", "C3", "AIF1", "TREM2", "TYROBP", "CX3CR1"), "microglia_complement_shift_review_only")
            )
            lower.contains("diabetes") || lower.contains("insulin resistance") || lower.contains("adipose") -> listOf(
                CapsuleModuleLite("dynamic_diabetes_adipose_macrophage_il6_tnf_module", listOf("TNF", "IL6", "CCL2", "NLRP3", "LEP", "ADIPOQ", "SLC2A4", "CD68"), "metabolic_inflammation_shift_review_only")
            )
            mechanismSignal.markers.isNotEmpty() -> listOf(CapsuleModuleLite(mechanismSignal.module, mechanismSignal.markers, mechanismSignal.axis))
            else -> emptyList()
        }
        return modules.map { module ->
            if (module.markers.any { it == "IMMUNE_AXIS" }) module.copy(markers = listOf("TNF", "IL6", "CXCL10", "CD68", "CD3D", "CD8A")) else module
        }
    }
}
