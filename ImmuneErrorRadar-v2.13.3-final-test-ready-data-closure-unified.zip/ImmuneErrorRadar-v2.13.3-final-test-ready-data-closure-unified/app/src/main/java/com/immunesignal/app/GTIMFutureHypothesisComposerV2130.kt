package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.0 — Compose future-facing, testable hypotheses from the offline lite corpus. */
object GTIMFutureHypothesisComposerV2130 {
    const val VERSION: String = "2.13.0-future-hypothesis-composer"
    const val CLAIM_LIMIT: String = "future_hypotheses_are_testable_leads_not_discoveries"

    fun toJson(report: JSONObject): JSONObject {
        val corpus = report.optJSONObject("futureEvidenceLiteCorpusV2130") ?: GTIMFutureEvidenceLiteCorpusV2130.toJson(report)
        val selectedTarget = report.optJSONObject("candidateHandleLedgerV21215")?.optString("selectedReviewTarget").orEmpty()
        val hypotheses = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("highValueHypotheses"))
        val bridges = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("crossDomainBridges"))
        val readouts = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("readouts"))
        val variants = JSONArray()
        val seeds = if (hypotheses.isNotEmpty()) hypotheses else listOf("under-tested immune bridge may define a measurable subgroup")
        seeds.take(4).forEachIndexed { index, h ->
            variants.put(JSONObject()
                .put("id", "FH${index + 1}")
                .put("hypothesis", h)
                .put("bridge", bridges.getOrNull(index % bridges.size.coerceAtLeast(1)) ?: "context -> immune mediator -> tissue module -> phenotype")
                .put("minimumReadouts", JSONArray(readouts.take(4)))
                .put("selectedReviewTarget", selectedTarget.ifBlank { "not_selected_yet" })
                .put("falsifier", "fails if comparator labels, tissue context, sample provenance, or contradiction check do not support the bridge"))
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "FUTURE_HYPOTHESIS_VARIANTS_READY")
            .put("domainKey", corpus.optString("domainKey"))
            .put("variants", variants)
            .put("bestVariant", variants.optJSONObject(0) ?: JSONObject())
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val best = obj.optJSONObject("bestVariant") ?: JSONObject()
        return listOf(
            "Future hypothesis composer",
            "State: ${obj.optString("state", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}; variants=${obj.optJSONArray("variants")?.length() ?: 0}.",
            "Top future-facing hypothesis: ${best.optString("hypothesis", "no hypothesis composed")}",
            "Bridge: ${best.optString("bridge", "no bridge selected")}",
            "Boundary: these are testable leads, not discoveries, mechanisms, treatments, or clinical predictions."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FUTURE_HYPOTHESIS_VARIANTS_READY", CLAIM_LIMIT))
}
