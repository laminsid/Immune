package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.13.2 — Verified metadata closure pack.
 *
 * A small curated pack of real, source-checked dataset facts used to close the
 * metadata/comparator/provenance *readiness* layer when live network lookup is not
 * available. It also demotes frequently misrouted handles (for example melanoma or lung
 * cancer single-cell series used inside depression/viral reports). This pack does not
 * run DGE and never proves mechanism, diagnosis, treatment, or efficacy.
 */
object GTIMVerifiedMetadataClosurePackV2132 {
    const val VERSION: String = "2.13.2-verified-metadata-closure-pack"
    const val ASSET_NAME: String = "gtim_verified_metadata_closure_pack_v2.13.2.json"
    const val CLAIM_LIMIT: String = "verified_metadata_study_readiness_not_biological_proof"

    private val entries: List<JSONObject> by lazy {
        listOf(
            entry("GSE102556", "depression_kynurenine_neuroimmune", "major_depression_transcriptomics", "Sex-specific Transcriptional Signatures in Human Depression", "human_and_mouse_separated", 341,
                listOf("major depression", "non-depressed controls", "male/female", "six human brain regions", "mouse chronic variable stress comparator layer"),
                "COMPARATOR_LABELS_CLOSED_FROM_GEO_BRIEF_REVIEW_REQUIRED", "TISSUE_SPECIES_CLOSED_HUMAN_BRAIN_AND_MOUSE_MODEL_SEPARATED", "SAMPLE_PROVENANCE_CLOSED_GSM_SERIES_AVAILABLE_REVIEW_REQUIRED", "SERIES_MATRIX_AND_RNA_SEQ_REVIEW_ROUTE_AVAILABLE_CHECK_GEO_FILES",
                "primary_depression_dataset_candidate_not_specific_kynurenine_metabolomics", "Compare IDO1/KMO/kynurenine-module genes and IL-6/TNF neuroimmune modules across MDD/control strata with sex and brain-region stratification."),
            entry("GSE152418", "viral_interferon_cytokine", "covid_severity_host_response", "Systems biological assessment of immunity to severe and mild COVID-19 infections", "human", 145,
                listOf("COVID-19 patients", "age/sex matched controls", "severity/recovery labels expected from study design"),
                "COMPARATOR_LABELS_CLOSED_COVID_VS_CONTROL_SEVERITY_REVIEW_REQUIRED", "TISSUE_SPECIES_CLOSED_HUMAN_IMMUNE_CELLS_PBMC_CONTEXT", "SAMPLE_PROVENANCE_CLOSED_GSM_SERIES_AVAILABLE_REVIEW_REQUIRED", "PROCESSED_EXPRESSION_CAPSULE_ROUTE_AVAILABLE_REVIEW_REQUIRED",
                "primary_covid_interferon_cytokine_dataset_candidate", "Compare IFN timing, IL-6/TNF and tissue-injury modules between COVID severity groups and matched controls."),
            entry("GSE166552", "viral_interferon_cytokine", "recurrent_covid_coding_noncoding_rna", "Differential circRNA, lncRNA and mRNA expression in recurrent COVID-19 patients and healthy people", "human", 0,
                listOf("recurrent COVID-19 patients", "healthy controls"),
                "COMPARATOR_LABELS_CLOSED_COVID_RECURRENCE_VS_HEALTHY_REVIEW_REQUIRED", "TISSUE_SPECIES_CLOSED_HUMAN_REVIEW_REQUIRED", "SAMPLE_PROVENANCE_PARTIAL_GEO_REPOSITORY_AVAILABLE", "TRANSCRIPTOME_NONCODING_RNA_CAPSULE_ROUTE_POSSIBLE",
                "secondary_covid_recurrence_dataset_candidate", "Use recurrence/healthy contrast to test whether IFN/cytokine and noncoding RNA signatures replicate COVID persistence route."),
            entry("GSE146170", "allergy_type2_barrier", "allergy_asthma_hdm_t_cell", "Single-cell transcriptomic analysis of allergen-specific T cells in allergy and asthma", "human", 18,
                listOf("asthmatics with HDM allergy", "asthmatics without HDM allergy", "non-asthmatics with HDM allergy", "non-asthmatics without HDM allergy"),
                "COMPARATOR_LABELS_CLOSED_FOUR_GROUP_HDM_ASTHMA_DESIGN", "TISSUE_SPECIES_CLOSED_HUMAN_CD4_T_HELPER_TREG", "SAMPLE_PROVENANCE_CLOSED_BIOPROJECT_PRJNA609655_SRA_SRP251235", "SUPPLEMENTARY_UMI_AND_ANNOTATION_FILES_AVAILABLE",
                "primary_allergy_type2_t_cell_dataset_candidate", "Compare HDM-reactive TH/Treg subsets and IL-9/type-2 markers across the four comparator groups."),
            entry("GSE146352", "allergy_type2_barrier", "atopic_dermatitis_atopic_march_skin", "Human skin expression in normal, atopic dermatitis and atopic march patients", "human", 6,
                listOf("Normal", "Atopic dermatitis", "Atopic march"),
                "COMPARATOR_LABELS_CLOSED_NORMAL_AD_ATOPIC_MARCH", "TISSUE_SPECIES_CLOSED_HUMAN_SKIN", "SAMPLE_PROVENANCE_CLOSED_GSM_SERIES_AVAILABLE", "SERIES_MATRIX_AND_PROCESSED_DATA_AVAILABLE_IN_SAMPLE_TABLE",
                "secondary_skin_barrier_allergy_dataset_candidate", "Test epithelial barrier and Th17/type-2 marker separation across normal, AD and atopic march groups."),
            entry("GSE72056", "oncology_tumor_microenvironment", "melanoma_single_cell_tumor_microenvironment", "Single cell RNA-seq analysis of melanoma", "human", 4645,
                listOf("melanoma tumor single cells", "malignant and non-malignant inferred cell classes"),
                "COMPARATOR_LABELS_CLOSED_TUMOR_CELL_CLASSIFICATION_REVIEW_REQUIRED", "TISSUE_SPECIES_CLOSED_HUMAN_MELANOMA_TUMOR", "SAMPLE_PROVENANCE_CLOSED_GSM_SERIES_SRA_AVAILABLE_FOR_MANY_SAMPLES", "PROCESSED_SINGLE_CELL_FILE_AVAILABLE_RAW_DATA_PARTIAL_DB_GAP_NOTE",
                "oncology_tme_seed_demote_if_used_for_depression_or_viral", "Use only for tumor microenvironment hypotheses: malignant/non-malignant cell states, immune infiltration, TME modules."),
            entry("GSE131907", "oncology_tumor_microenvironment", "lung_adenocarcinoma_single_cell_tme", "Single-cell atlas of lung adenocarcinoma progression", "human", 0,
                listOf("primary lung adenocarcinoma", "lymph node metastasis", "brain metastasis", "pleural effusion", "normal lung/lymph node context"),
                "COMPARATOR_LABELS_CLOSED_TUMOR_PROGRESSION_SITE_CONTEXT_REVIEW_REQUIRED", "TISSUE_SPECIES_CLOSED_HUMAN_LUNG_CANCER_TME", "SAMPLE_PROVENANCE_CLOSED_GEO_SERIES_AVAILABLE_REVIEW_REQUIRED", "SINGLE_CELL_CAPSULE_ROUTE_AVAILABLE_REVIEW_REQUIRED",
                "oncology_tme_seed_demote_if_used_for_ebola_covid_without_cancer_context", "Use for TME immune-cell composition and tumor progression comparisons only."),
            entry("GSE49454", "rheumatoid_autoimmune_synovial_inflammation", "systemic_lupus_autoimmune_transcriptomics", "Public SLE transcriptomic dataset reused for glucocorticoid and autoimmune signatures", "human", 62,
                listOf("SLE cohort", "healthy/control or disease comparator requires review", "glucocorticoid dose/signature context"),
                "COMPARATOR_LABELS_PARTIAL_AUTOIMMUNE_CONTEXT_REVIEW_REQUIRED", "TISSUE_SPECIES_CLOSED_HUMAN_REVIEW_REQUIRED", "SAMPLE_PROVENANCE_PARTIAL_PUBLIC_GEO_DATASET_REVIEW_REQUIRED", "AUTOIMMUNE_SIGNATURE_CAPSULE_ROUTE_POSSIBLE",
                "autoimmune_background_seed_not_depression_primary_target", "Use only to test autoimmune inflammation/signature questions or as contradiction/background for neuroimmune overlap.")
        )
    }

    fun toJson(report: JSONObject): JSONObject {
        val domain = domainKey(report)
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: GTIMCandidateHandleLedgerV21215.toJson(report)
        val handles = (jsonStrings(ledger.optJSONArray("allCandidateHandles")) + extractHandles(report.toString())).distinct()
        val directMatches = handles.mapNotNull { lookup(it) }
        val verifiedMatches = directMatches.filter { compatible(domain, it.optString("domainRoute")) }
        val demoted = directMatches.filterNot { compatible(domain, it.optString("domainRoute")) }
        val preferred = (verifiedMatches.firstOrNull() ?: preferredForDomain(domain))?.let { JSONObject(it.toString()) } ?: JSONObject()
        val replacementSuggested = preferred.optString("handle").isNotBlank() && handles.none { it.equals(preferred.optString("handle"), true) }
        val closed = preferred.optString("handle").isNotBlank()
        return JSONObject()
            .put("version", VERSION)
            .put("asset", ASSET_NAME)
            .put("domainKey", domain)
            .put("state", if (closed) "VERIFIED_METADATA_CLOSURE_READY" else "NO_VERIFIED_METADATA_CLOSURE")
            .put("selectedClosedTarget", preferred.optString("handle"))
            .put("replacementSuggested", replacementSuggested)
            .put("verifiedMatches", JSONArray(verifiedMatches.map { JSONObject(it.toString()) }))
            .put("demotedMismatchedSeeds", JSONArray(demoted.map { JSONObject(it.toString()) }))
            .put("demotedMismatchCount", demoted.size)
            .put("comparatorClosed", closed && preferred.optString("comparatorLabelsStatus").contains("CLOSED"))
            .put("sampleProvenanceClosed", closed && preferred.optString("sampleProvenanceStatus").contains("CLOSED"))
            .put("tissueSpeciesClosed", closed && preferred.optString("tissueSpeciesStatus").contains("CLOSED"))
            .put("matrixOrCapsuleRoutable", closed && (preferred.optString("matrixOrCapsuleHint").contains("AVAILABLE") || preferred.optString("matrixOrCapsuleHint").contains("ROUTE") || preferred.optString("matrixOrCapsuleHint").contains("POSSIBLE")))
            .put("humanAnimalInVitroSeparation", preferred.optString("organismLevel", "unknown"))
            .put("sampleGroups", preferred.optJSONArray("sampleGroups") ?: JSONArray())
            .put("nextExperiment", preferred.optString("minimumViableExperiment"))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun lookup(handle: String): JSONObject? {
        val h = handle.uppercase(Locale.US)
        return entries.firstOrNull { it.optString("handle").equals(h, true) }?.let { JSONObject(it.toString()) }
    }

    fun preferredForDomain(domain: String): JSONObject? {
        val d = domain.lowercase(Locale.US)
        return entries.firstOrNull { compatible(d, it.optString("domainRoute")) }?.let { JSONObject(it.toString()) }
    }

    fun publicLines(obj: JSONObject): List<String> {
        val groups = jsonStrings(obj.optJSONArray("sampleGroups")).take(5).joinToString("; ").ifBlank { "not closed" }
        return listOf(
            "Verified metadata closure pack",
            "State: ${obj.optString("state", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}; selected_closed_target=${obj.optString("selectedClosedTarget", "none")}; replacement_suggested=${obj.optBoolean("replacementSuggested", false)}; demoted_mismatches=${obj.optInt("demotedMismatchCount", 0)}.",
            "Closed readiness gates: comparator=${obj.optBoolean("comparatorClosed", false)}; sample_provenance=${obj.optBoolean("sampleProvenanceClosed", false)}; tissue/species=${obj.optBoolean("tissueSpeciesClosed", false)}; matrix/capsule_route=${obj.optBoolean("matrixOrCapsuleRoutable", false)}.",
            "Sample groups: $groups.",
            "Next experiment: ${obj.optString("nextExperiment", "not available")}.",
            "Boundary: verified metadata closes study-readiness fields only; it is not DGE, mechanism proof, diagnosis, treatment, dosing, or efficacy evidence."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, ASSET_NAME, "VERIFIED_METADATA_CLOSURE_READY", "demotedMismatchedSeeds", "GSE102556", "GSE146170", "GSE152418", CLAIM_LIMIT))

    private fun entry(handle: String, route: String, family: String, title: String, organismLevel: String, sampleCount: Int, groups: List<String>, comparator: String, tissue: String, provenance: String, matrix: String, use: String, mve: String): JSONObject = JSONObject()
        .put("handle", handle.uppercase(Locale.US))
        .put("handleType", "GSE")
        .put("domainRoute", route)
        .put("topicFamily", family)
        .put("title", title)
        .put("organismLevel", organismLevel)
        .put("sampleCount", sampleCount)
        .put("sampleGroups", JSONArray(groups))
        .put("comparatorLabelsStatus", comparator)
        .put("tissueSpeciesStatus", tissue)
        .put("sampleProvenanceStatus", provenance)
        .put("matrixOrCapsuleHint", matrix)
        .put("studyUse", use)
        .put("minimumViableExperiment", mve)
        .put("claimLimit", CLAIM_LIMIT)

    private fun compatible(domain: String, route: String): Boolean {
        val d = domain.lowercase(Locale.US)
        val r = route.lowercase(Locale.US)
        return when {
            d.isBlank() -> false
            d == r -> true
            d.contains("depression") && r.contains("depression") -> true
            d.contains("viral_interferon") && r.contains("viral_interferon") -> true
            d.contains("covid") && r.contains("viral_interferon") -> true
            d.contains("allergy") && r.contains("allergy") -> true
            (d.contains("cancer") || d.contains("oncology") || d.contains("tumor")) && r.contains("oncology") -> true
            (d.contains("rheumatoid") || d.contains("autoimmune") || d.contains("lupus")) && (r.contains("autoimmune") || r.contains("rheumatoid")) -> true
            else -> false
        }
    }

    private fun domainKey(report: JSONObject): String {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215")
        val candidates = listOf(
            ledger?.optString("domainKey"),
            report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainSpecificRoute"),
            report.optJSONObject("finalResearchValueBoosterV212101")?.optString("domainSpecificRoute"),
            report.optJSONObject("studyResultCardV2126")?.optString("domainSpecificRoute")
        ).filterNotNull().filter { it.isNotBlank() }
        if (candidates.isNotEmpty()) return candidates.first()
        val text = report.toString().lowercase(Locale.US)
        return when {
            text.contains("kynurenine") || text.contains("depression") -> "depression_kynurenine_neuroimmune"
            text.contains("covid") || text.contains("interferon") || text.contains("viral") -> "viral_interferon_cytokine"
            text.contains("allergy") || text.contains("type-2") || text.contains("ige") -> "allergy_type2_barrier"
            text.contains("cancer") || text.contains("tumor") || text.contains("melanoma") -> "oncology_tumor_microenvironment"
            text.contains("rheumatoid") || text.contains("autoimmune") || text.contains("lupus") -> "rheumatoid_autoimmune_synovial_inflammation"
            else -> "unknown"
        }
    }

    private fun extractHandles(text: String): List<String> = Regex("\\b(GSE\\d+)\\b", RegexOption.IGNORE_CASE).findAll(text).map { it.value.uppercase(Locale.US) }.distinct().toList()
    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx -> array.optString(idx).takeIf { it.isNotBlank() } }
}
