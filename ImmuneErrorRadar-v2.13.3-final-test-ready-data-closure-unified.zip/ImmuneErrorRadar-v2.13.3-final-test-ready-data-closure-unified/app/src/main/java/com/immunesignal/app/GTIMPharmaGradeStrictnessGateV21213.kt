package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.13 — Pharma-grade strictness gate.
 *
 * Raises rigor at the promotion boundary while keeping discovery continuation alive. This
 * is the central bridge from older relaxed GTIM routes to the new drug-discovery-style
 * target/readout/capsule/contradiction discipline.
 */
object GTIMPharmaGradeStrictnessGateV21213 {
    const val VERSION: String = "2.12.13-pharma-grade-strictness-gate"
    const val CLAIM_LIMIT: String = "strict_promotion_gate_no_clinical_or_mechanism_claim"

    fun toJson(report: JSONObject): JSONObject {
        val target = report.optJSONObject("targetValidationCardV21213") ?: GTIMTargetValidationCardV21213.toJson(report)
        val utility = report.optJSONObject("publishedResearchUtilityScoreV21213") ?: GTIMPublishedResearchUtilityScoreV21213.toJson(report)
        val negative = report.optJSONObject("negativeEvidenceMemoryV21213") ?: GTIMNegativeEvidenceMemoryV21213.toJson(report)
        val consistency = report.optJSONObject("reportConsistencyGateV2121") ?: JSONObject()
        val closed = hardClosed(consistency, utility, negative)
        val missing = missingGates(consistency, utility, negative)
        return JSONObject()
            .put("version", VERSION)
            .put("state", if (closed) "STRICT_PROMOTION_READY_FOR_EXTERNAL_REVIEW_NOT_CLAIM" else "STRICT_PROMOTION_BLOCKED_DISCOVERY_CONTINUES")
            .put("discoveryMayContinue", true)
            .put("claimPromotionAllowed", false)
            .put("externalReviewReadiness", closed)
            .put("targetValidationState", target.optString("state"))
            .put("publishedResearchUtilityScore", utility.optInt("score", 0))
            .put("hardPromotionGates", hardGateList())
            .put("missingHardGates", missing)
            .put("negativeEvidenceItems", negative.optJSONArray("negativeEvidenceItems") ?: JSONArray())
            .put("strictnessUpgrade", "more_strict_at_evidence_promotion_not_at_hypothesis_discovery")
            .put("legacyRouteBridge", "old_ETL_DGE_external_router_matrix_shortcut_routes_remain_linked_before_strict_gate")
            .put("nextAction", nextAction(closed, missing))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val missing = obj.optJSONArray("missingHardGates") ?: JSONArray()
        return listOf(
            "Pharma-grade strictness gate",
            "State: ${obj.optString("state", "UNKNOWN")}; discovery_continues=${obj.optBoolean("discoveryMayContinue", true)}; claim_promotion_allowed=${obj.optBoolean("claimPromotionAllowed", false)}.",
            "Strictness upgrade: ${obj.optString("strictnessUpgrade", "promotion strictness raised while discovery stays open")}; missing hard gates=${missing.length()}.",
            "Next: ${obj.optString("nextAction", "continue discovery while hard promotion gates remain blocked").takeClean(300)}",
            "Boundary: no mechanism, gene/pathway, treatment, dosing, diagnosis, or patient prediction claim."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "STRICT_PROMOTION_BLOCKED_DISCOVERY_CONTINUES",
        "discoveryMayContinue",
        "claimPromotionAllowed",
        "more_strict_at_evidence_promotion_not_at_hypothesis_discovery",
        "old_ETL_DGE_external_router_matrix_shortcut_routes_remain_linked_before_strict_gate",
        CLAIM_LIMIT
    ))

    private fun hardClosed(consistency: JSONObject, utility: JSONObject, negative: JSONObject): Boolean {
        return consistency.optBoolean("topicCompatibleTargetSelected", false) &&
            consistency.optInt("verifiedMatrixFiles", 0) > 0 &&
            utility.optInt("score", 0) >= 8 &&
            (negative.optJSONArray("negativeEvidenceItems")?.length() ?: 0) == 0
    }

    private fun missingGates(consistency: JSONObject, utility: JSONObject, negative: JSONObject): JSONArray {
        val out = JSONArray()
        if (!consistency.optBoolean("topicCompatibleTargetSelected", false)) out.put("topic_compatible_target_not_closed")
        if (consistency.optInt("verifiedMatrixFiles", 0) <= 0) out.put("verified_matrix_or_processed_capsule_missing")
        if (utility.optInt("score", 0) < 8) out.put("published_research_utility_score_below_external_review_threshold")
        if ((negative.optJSONArray("negativeEvidenceItems")?.length() ?: 0) > 0) out.put("negative_or_missing_evidence_items_present")
        out.put("external_review_required_before_any_claim")
        return out
    }

    private fun hardGateList(): JSONArray = JSONArray(listOf(
        "topic-compatible target selected",
        "metadata tissue/species/comparator labels closed",
        "sample-to-source provenance closed",
        "matrix or processed-expression capsule verified",
        "published research utility score >= 8/10",
        "contradiction and negative evidence check clean",
        "external review before any biological or clinical claim"
    ))

    private fun nextAction(closed: Boolean, missing: JSONArray): String = if (closed) {
        "Prepare external review dossier with target, biomarker/readout, dataset/capsule, comparator/sample provenance, and contradiction summary; still do not claim clinical validity."
    } else {
        "Continue old+new routes until hard gates close: ${jsonStrings(missing).take(5).joinToString(", ")}"
    }

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx -> array.optString(idx).takeIf { it.isNotBlank() } }

    private fun String.takeClean(max: Int): String {
        val clean = replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= max) clean else clean.take(max).trimEnd()
    }
}
