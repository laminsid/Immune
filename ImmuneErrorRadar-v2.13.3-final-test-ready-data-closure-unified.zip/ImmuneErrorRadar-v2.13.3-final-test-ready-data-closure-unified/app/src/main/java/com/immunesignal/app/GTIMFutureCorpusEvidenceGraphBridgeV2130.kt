package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.0 — Bridges the future lite corpus into the existing evidence graph. */
object GTIMFutureCorpusEvidenceGraphBridgeV2130 {
    const val VERSION: String = "2.13.0-future-corpus-evidence-graph-bridge"
    const val CLAIM_LIMIT: String = "graph_bridge_is_prior_structure_not_evidence"

    fun toJson(report: JSONObject): JSONObject {
        val corpus = report.optJSONObject("futureEvidenceLiteCorpusV2130") ?: GTIMFutureEvidenceLiteCorpusV2130.toJson(report)
        val domain = corpus.optString("domainKey")
        val targets = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("primaryTargets"))
        val readouts = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("readouts"))
        val handles = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("candidateHandles"))
        val edges = JSONArray()
        targets.take(4).forEach { t -> edges.put(JSONObject().put("from", domain).put("to", t).put("edge", "prior_target_candidate")) }
        readouts.take(4).forEach { r -> edges.put(JSONObject().put("from", "target_module").put("to", r).put("edge", "measurable_readout_candidate")) }
        handles.take(4).forEach { h -> edges.put(JSONObject().put("from", h).put("to", domain).put("edge", "dataset_lookup_seed_review_only")) }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "FUTURE_CORPUS_GRAPH_BRIDGE_READY")
            .put("domainKey", domain)
            .put("nodeCount", 1 + targets.take(4).size + readouts.take(4).size + handles.take(4).size)
            .put("edges", edges)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Future corpus evidence-graph bridge",
        "State: ${obj.optString("state", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}; nodes=${obj.optInt("nodeCount", 0)}; edges=${obj.optJSONArray("edges")?.length() ?: 0}.",
        "Use: connects future corpus priors into the existing evidence graph so reports reason over targets/readouts/handles instead of loose text.",
        "Boundary: graph edges are priors and routing aids, not biological proof."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FUTURE_CORPUS_GRAPH_BRIDGE_READY", CLAIM_LIMIT))
}
