package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.0 — Turns corpus gaps into decisive future experiments. */
object GTIMMechanismGapAmplifierV2130 {
    const val VERSION: String = "2.13.0-mechanism-gap-amplifier"
    const val CLAIM_LIMIT: String = "mechanism_gap_plan_not_mechanism_proof"

    fun toJson(report: JSONObject): JSONObject {
        val corpus = report.optJSONObject("futureEvidenceLiteCorpusV2130") ?: GTIMFutureEvidenceLiteCorpusV2130.toJson(report)
        val gaps = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("missingExperiments"))
        val negatives = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("negativeControls"))
        val readouts = GTIMFutureEvidenceLiteCorpusV2130.jsonStrings(corpus.optJSONArray("readouts"))
        val decisiveExperiment = gaps.firstOrNull() ?: "direct topic-fit capsule with comparator labels, sample provenance, and contradiction check"
        return JSONObject()
            .put("version", VERSION)
            .put("state", "MECHANISM_GAP_AMPLIFIED_TO_TEST_PLAN")
            .put("domainKey", corpus.optString("domainKey"))
            .put("decisiveMissingExperiment", decisiveExperiment)
            .put("requiredReadouts", JSONArray(readouts.take(6)))
            .put("negativeControls", JSONArray(negatives.take(4)))
            .put("fastestFalsifier", negatives.firstOrNull() ?: "wrong tissue/species or missing comparator labels")
            .put("whyThisCanOutrunLiterature", "It targets the missing experiment/subgroup bridge, not the already-known pathway label.")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Mechanism gap amplifier",
        "State: ${obj.optString("state", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}",
        "Decisive missing experiment: ${obj.optString("decisiveMissingExperiment", "not defined")}",
        "Fastest falsifier: ${obj.optString("fastestFalsifier", "not defined")}",
        "Boundary: a mechanism gap is a research target, not a proven mechanism."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "MECHANISM_GAP_AMPLIFIED_TO_TEST_PLAN", CLAIM_LIMIT))
}
