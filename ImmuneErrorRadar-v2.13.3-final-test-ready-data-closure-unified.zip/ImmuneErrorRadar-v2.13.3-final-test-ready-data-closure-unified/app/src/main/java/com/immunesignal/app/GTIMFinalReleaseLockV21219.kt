package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.19 — final release lock.
 *
 * This layer does not add a new scientific claim. It locks the final report contract:
 * old/new route linkage, selected-target consistency, resume stability, injected metadata,
 * 10/10 readiness modules, and strict evidence-promotion gates.
 */
object GTIMFinalReleaseLockV21219 {
    const val VERSION: String = "2.12.19-final-release-lock-validated"
    const val CLAIM_LIMIT: String = "final_release_lock_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: JSONObject()
        val selected = ledger.optString("selectedReviewTarget")
        val capsule = report.optJSONObject("evidenceCapsuleBuilderV21218") ?: JSONObject()
        val scorecard = report.optJSONObject("tenTenResearchScorecardV21218") ?: JSONObject()
        val injected = report.optJSONObject("injectedMetadataSeedPackV21216") ?: JSONObject()
        val workers = report.optJSONObject("metadataProbeBackgroundWorkersV21215") ?: JSONObject()
        val resume = report.optJSONObject("searchStabilityClosureV21217") ?: JSONObject()
        val redTeam = report.optJSONObject("scientificRedTeamReviewerV21218") ?: JSONObject()

        val requiredBlocks = listOf(
            "candidateHandleLedgerV21215",
            "injectedMetadataSeedPackV21216",
            "metadataProbeBackgroundWorkersV21215",
            "searchStabilityClosureV21217",
            "comparatorSampleProvenanceExtractorV21218",
            "evidenceCapsuleBuilderV21218",
            "contradictionSearchEngineV21218",
            "noveltyScoringEngineV21218",
            "minimumViableStudyProtocolV21218",
            "datasetToStudyMapperV21218",
            "studyFeasibilityScoreV21218",
            "evidenceGraphEngineV21218",
            "scientificRedTeamReviewerV21218",
            "tenTenResearchScorecardV21218",
            "finalTenTenResearchClosureV21218",
            "futureEvidenceLiteCorpusV2130",
            "expandedDiseaseFutureCorpusV2131",
            "futureHypothesisComposerV2130",
            "mechanismGapAmplifierV2130",
            "futureCorpusEvidenceGraphBridgeV2130",
            "futureLiteCorpusClosureV2130"
        )
        val missingBlocks = requiredBlocks.filter { report.optJSONObject(it) == null }
        val hardGatesOpen = JSONArray()
        if (selected.isBlank()) hardGatesOpen.put("selected_review_target_missing")
        if (capsule.optBoolean("evidenceUpgradeAllowed", false)) hardGatesOpen.put("unexpected_evidence_upgrade_allowed")
        if (capsule.optInt("verifiedCapsuleSourceCount", 0) <= 0) hardGatesOpen.put("verified_capsule_source_count_zero")
        if (!injected.optBoolean("stopsPrevented", false) && !injected.optString("state").contains("READY")) hardGatesOpen.put("injected_metadata_not_ready")
        if (!workers.optString("state").contains("READY")) hardGatesOpen.put("background_workers_not_ready")
        if (!resume.optString("state").contains("READY")) hardGatesOpen.put("search_resume_not_ready")
        if (redTeam.optString("state").contains("WARNINGS")) hardGatesOpen.put("red_team_warnings_present")

        val routeLinkage = JSONArray(listOf(
            "curated_seed",
            "injected_metadata",
            "background_metadata_workers",
            "external_router",
            "matrix_shortcut",
            "etl_dge",
            "terminal_continuation",
            "search_resume",
            "evidence_capsule",
            "contradiction_search",
            "novelty_scoring",
            "minimum_viable_study",
            "scientific_red_team",
            "future_lite_corpus",
            "expanded_disease_future_corpus",
            "future_hypothesis_composer",
            "mechanism_gap_amplifier",
            "future_corpus_graph_bridge"
        ))

        val state = if (missingBlocks.isEmpty() && selected.isNotBlank()) {
            "FINAL_RELEASE_LOCK_READY_CLAIMS_BLOCKED_UNTIL_EVIDENCE_GATES_CLOSE"
        } else {
            "FINAL_RELEASE_LOCK_PARTIAL_REVIEW_REQUIRED"
        }

        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("selectedReviewTarget", selected)
            .put("missingRequiredBlocks", JSONArray(missingBlocks))
            .put("hardGatesOpen", hardGatesOpen)
            .put("routeLinkage", routeLinkage)
            .put("practicalResearchValue", scorecard.optInt("practicalResearchValue", 0))
            .put("scientificOriginality", scorecard.optInt("scientificOriginality", 0))
            .put("appliedStudyReadiness", scorecard.optInt("appliedStudyReadiness", 0))
            .put("oldNewRoutesLinked", true)
            .put("githubSafe", true)
            .put("claimPromotionAllowed", false)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final release lock",
        "State: ${obj.optString("state", "UNKNOWN")}; selected_review_target=${obj.optString("selectedReviewTarget", "none")}; missing_blocks=${obj.optJSONArray("missingRequiredBlocks")?.length() ?: 0}; open_hard_gates=${obj.optJSONArray("hardGatesOpen")?.length() ?: 0}.",
        "10/10 dashboard: practical_value=${obj.optInt("practicalResearchValue", 0)}/10; originality=${obj.optInt("scientificOriginality", 0)}/10; applied_study=${obj.optInt("appliedStudyReadiness", 0)}/10.",
        "Route linkage: future corpus → expanded disease corpus → curated seed → injected metadata → background workers → external router → matrix shortcut → ETL/DGE → capsule → contradiction → minimum study → red-team.",
        "Boundary: final lock validates release coherence only; evidence promotion remains blocked until hard gates close."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(VERSION, "FINAL_RELEASE_LOCK_READY_CLAIMS_BLOCKED_UNTIL_EVIDENCE_GATES_CLOSE", CLAIM_LIMIT))
}
