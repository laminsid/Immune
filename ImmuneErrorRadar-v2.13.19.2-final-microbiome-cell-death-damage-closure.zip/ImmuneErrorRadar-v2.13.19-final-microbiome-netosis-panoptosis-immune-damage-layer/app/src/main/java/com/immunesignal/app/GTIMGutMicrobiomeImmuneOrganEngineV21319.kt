package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.19 — Gut microbiome as endocrine-immune organ research lens. */
object GTIMGutMicrobiomeImmuneOrganEngineV21319 {
    const val VERSION: String = "2.13.19-gut-microbiome-endocrine-immune-organ-engine"
    const val CLAIM_LIMIT: String = "microbiome_signal_not_microbiome_cause_not_treatment_claim"

    fun toJson(report: JSONObject): JSONObject {
        val topic = report.optString("topic", report.optString("query", "")).lowercase()
        val active = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val role = when {
            topic.contains("microbiome") || topic.contains("scfa") || topic.contains("gut") -> "metabolite_signaler"
            active.contains("allergy") -> "barrier_regulator"
            active.contains("cancer") -> "immunotherapy_response_modifier"
            active.contains("diabetes") || active.contains("metabolic") -> "metabolic_immune_amplifier"
            active.contains("hantavirus") || active.contains("covid") || active.contains("filovirus") -> "systemic_inflammation_modifier"
            else -> "unknown"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", "GUT_MICROBIOME_ENDOCRINE_IMMUNE_ORGAN_LENS_READY")
            .put("microbiome_role", role)
            .put("candidate_capsules", JSONArray(listOf("gut_microbiome_endocrine_immune_organ", "scfa_immune_training_axis", "tryptophan_indole_ahr_axis", "bile_acid_immune_modulation_axis")))
            .put("claim_limit", CLAIM_LIMIT)
            .put("microbiome_cause_claim_allowed", false)
            .put("microbiome_treatment_claim_allowed", false)
    }
}
