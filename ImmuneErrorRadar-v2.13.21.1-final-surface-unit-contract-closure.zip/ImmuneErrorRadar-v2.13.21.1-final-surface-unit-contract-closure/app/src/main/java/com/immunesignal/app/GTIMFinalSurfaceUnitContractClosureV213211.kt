package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.21.1 — final surface unit-contract closure.
 *
 * This is a small compatibility/acceptance layer. It pins the unit-test surface markers
 * that define the current final first surface after the addition of microbiome, NETosis,
 * thymic/cybernetic, exosome, and immunometabolism cards. It is rendering-only and does
 * not create proof, diagnosis, treatment, dosing, patient action, or clinical claims.
 */
object GTIMFinalSurfaceUnitContractClosureV213211 {
    const val VERSION: String = "2.13.21.1-final-surface-unit-contract-closure"
    const val STATE_READY: String = "FINAL_SURFACE_UNIT_CONTRACT_CLOSURE_READY"
    const val CLAIM_LIMIT: String = "surface_contract_closure_only_no_proof_no_treatment_no_clinical_action"

    fun toJson(report: JSONObject): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("state", STATE_READY)
        .put("required_first_surface_markers", requiredMarkers())
        .put("legacy_surface_owner_allowed", false)
        .put("c2_c3_sandbox_preview_allowed", true)
        .put("validated_proof_allowed", false)
        .put("treatment_dosing_clinical_action_allowed", false)
        .put("legacy_policy", "legacy_rails_json_export_appendix_audit_compatibility_only")
        .put("claim_limit", CLAIM_LIMIT)

    fun renderLines(report: JSONObject): List<String> = listOf(
        "Final surface unit-contract closure",
        "State: $STATE_READY; version=$VERSION; legacy_surface_owner_allowed=false.",
        "Pinned markers: Primary hypothesis, Immune decision state, Capsule state, Concept/paradigm candidate, Best execution route, Falsifier, Claim boundary.",
        "Pinned paradigm markers: Paradigm candidate card, Old assumption challenged, Cross-disease mechanism, Therapeutic/modality lens, Protein interaction/binding lens, validated_binding_or_efficacy_claim=BLOCKED.",
        "Policy: C0/C1/C2/C3 sandbox preview allowed; validated proof, treatment, dosing, patient action, and clinical implementation are blocked.",
        "Boundary: $CLAIM_LIMIT."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        STATE_READY,
        "Final requirements coverage closure",
        "Primary hypothesis",
        "Immune decision state",
        "Capsule state",
        "Concept/paradigm candidate",
        "Best execution route",
        "Falsifier",
        "Claim boundary",
        "legacy_surface_owner_allowed=false",
        "Paradigm candidate card",
        "Old assumption challenged",
        "Cross-disease mechanism",
        "Therapeutic/modality lens",
        "Protein interaction/binding lens",
        "validated_binding_or_efficacy_claim=BLOCKED",
        "Compatibility appendix policy",
        "Legacy leak firewall",
        "Study Result Card",
        CLAIM_LIMIT
    ))

    private fun requiredMarkers(): JSONArray = auditTokens()
}
