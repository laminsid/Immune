# Changelog — v1.10.33

Release: `1.10.33-alpha-lean-agent-runtime`

- Updated release identity to `versionCode=95`, `versionName=1.10.33-alpha-lean-agent-runtime`, `ACTIVE_ENGINE_VERSION=v1.10.33-alpha-lean-agent-runtime`, and `LEARNING_SESSION_SCHEMA_VERSION=1.10.33`.
- Added `LeadObject` ledger model for weak/manual/near-miss leads.
- Added `LeanAgentRuntimePolicy` with deterministic micro-agent list, hard gates, state deltas, and compact decision card.
- Connected LeadObject ledger, mature-domain focus, knowledge gap queue, strong route fingerprint, and report consistency into `DatasetForagingReport` JSON/PDF/UI exports.
- Kept fast/full CI split and release linkage guard mandatory.

Runtime remains routing-only and claim-safe: `lean_agent_runtime_routing_only_not_biological_proof`.

## GitHub compile hotfix — DiscoveryReportExporter local declaration guard

- Fixed a Kotlin compile failure in `DiscoveryReportExporter.kt` caused by same-scope local declarations named `gaps` with different JSON types.
- Renamed the report-local variables to role-specific names:
  - `knowledgeGapQueue`
  - `specialistEvidenceGaps`
  - `gapMinerMissingEvidence`
- Added `scripts/audit_discovery_exporter_local_names_v11033.py` and wired it into fast/full static checks to prevent this class of GitHub Kotlin failure from returning.
- No scientific-claim behavior changed; this is a compile-stability and CI guard fix only.

## Report linkage hardening continuation

- Hardened `ReportConsistencyGuard.includePathLinkageWarnings` so a linkage state containing `WARNINGS` cannot be hidden even if the warning list is accidentally empty.
- Normalized impossible `PASS` + non-empty warning combinations to `CAUTION`.
- Forced merged linkage consistency reports to remain `active=true` when any path-linkage caution is injected.
- Added regression coverage for warning-state-without-warning-text and PASS-with-warning normalization.
- Extended `scripts/audit_v11033_unit_regression_contracts.py` so fast/full static checks enforce these report-consistency contracts.
