from pathlib import Path

root = Path('app/src/main/java/com/immunesignal/app')
linkage = (root / 'DatasetForagingPathLinkageGuard.kt').read_text(errors='replace')
focus = (root / 'MatureDomainFocusAndLeanRuntime.kt').read_text(errors='replace')
consistency = (root / 'ReportConsistencyGuard.kt').read_text(errors='replace')
autopilot = (root / 'ResearchAutopilot.kt').read_text(errors='replace')

def require(haystack, token, label):
    if token not in haystack:
        raise SystemExit(f'v1.10.33 regression contract missing in {label}: {token}')

for token in [
    'val matureProbeConsumedByLeadPath = matureProbeReport.active && matureAttempted && leadInspectionFinalState && leadInspectionNextAction',
    'val matureProbeExposedInFinalState = foragerState.contains("MATURE_DOMAIN", ignoreCase = true) || matureProbeConsumedByLeadPath',
    'CONNECTED_MATURE_DOMAIN_TO_LEAD_INSPECTION',
    'consumedByLead=$matureProbeConsumedByLeadPath',
]:
    require(linkage, token, 'DatasetForagingPathLinkageGuard.kt')

intent_block = '''val intent = when {
            focus.active -> "mature_domain_focus_probe"
            gapQueue.items.any { it.gapId == "outcome_labels" } -> "outcome_label_probe"
            else -> "dataset_lead_foraging"
        }'''
require(focus, intent_block, 'MatureDomainFocusAndLeanRuntime.kt')

for token in [
    'fun includePathLinkageWarnings(',
    'Dataset path linkage: $it',
    'pathLinkageReport.state.contains("WARNINGS", ignoreCase = true)',
    'learningDomainPathLinkageReport.state.contains("WARNINGS", ignoreCase = true)',
    'val baseNeedsCaution = base.warnings.isNotEmpty() && base.status.equals("PASS", ignoreCase = true)',
    'active = true,',
    'Report consistency blocked: unresolved path-linkage warnings remain',
]:
    require(consistency, token, 'ReportConsistencyGuard.kt')

for token in [
    'ReportConsistencyGuard.includePathLinkageWarnings(',
    'learningDomainPathLinkageReport = learningDomainPathLinkageReportV11029,',
]:
    require(autopilot, token, 'ResearchAutopilot.kt')

print('v1.10.33 unit/report linkage regression contract audit: PASS')
