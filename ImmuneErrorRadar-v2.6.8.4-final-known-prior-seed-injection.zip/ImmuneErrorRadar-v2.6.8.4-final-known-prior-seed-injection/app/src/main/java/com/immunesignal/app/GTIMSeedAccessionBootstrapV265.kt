package com.immunesignal.app

import java.util.Locale

/**
 * v2.6.5: deterministic seed-accession bootstrap for exploratory research mode.
 *
 * These seeds are lookup accelerators only. They never upgrade a hypothesis unless the normal
 * repository resolver closes accession, comparator, metadata, matrix, and contradiction gates.
 */
data class GTIMSeedAccessionV265(
    val axis: String,
    val handles: List<String>,
    val seedQuery: String,
    val expectedUse: String,
    val claimLimit: String = GTIMSeedAccessionBootstrapV265.CLAIM_LIMIT
)

object GTIMSeedAccessionBootstrapV265 {
    const val VERSION: String = "2.6.8-final-unified-route-learning-closure"
    const val CLAIM_LIMIT: String = "seed_accessions_for_lookup_only_not_evidence"

    val seeds: List<GTIMSeedAccessionV265> = listOf(
        GTIMSeedAccessionV265(
            axis = "allergy_type2_skin_inflammation",
            handles = listOf("GSE250594"),
            seedQuery = "GSE250594 nickel challenge anakinra placebo single-cell skin immune response comparator",
            expectedUse = "metadata closure and route-fit testing only"
        ),
        GTIMSeedAccessionV265(
            axis = "off_route_negative_learning_control",
            handles = listOf("GSE117882"),
            seedQuery = "GSE117882 immune transcriptome metadata comparator route-fit negative control",
            expectedUse = "counter-signal / off-route learning control; do not upgrade hypotheses"
        ),
        GTIMSeedAccessionV265(
            axis = "viral_long_covid_interferon",
            handles = listOf("GSE152418", "GSE157103"),
            seedQuery = "COVID Long COVID interferon PBMC transcriptome GSE comparator recovered healthy controls data availability",
            expectedUse = "first-pass public lookup seed; require resolver confirmation"
        ),
        GTIMSeedAccessionV265(
            axis = "autoimmune_type1_ifn_sle_ra",
            handles = listOf("GSE49454", "GSE45291"),
            seedQuery = "SLE rheumatoid arthritis type I interferon PBMC transcriptome GSE comparator disease activity controls",
            expectedUse = "autoimmune route bootstrap; require metadata and contradiction closure"
        ),
        GTIMSeedAccessionV265(
            axis = "stress_hpa_latent_virus_prior_literature",
            handles = listOf("PMID:22114171", "DOI:10.1126/science.1211719", "PMID:22474371", "DOI:10.1073/pnas.1118355109"),
            seedQuery = "stress sleep HPA cortisol glucocorticoid resistance lymphocyte transcription EBV HHV-6 IL-6 TNF interferon PMID DOI",
            expectedUse = "known prior literature lookup seed only; contradiction gate remains open until resolver confirmation"
        ),
        GTIMSeedAccessionV265(
            axis = "stress_hpa_viral_immune_matrix_candidates",
            handles = listOf("GSE152202", "GSE166552"),
            seedQuery = "GSE152202 GSE166552 Long COVID SARS-CoV-2 peripheral blood transcriptome interferon cytokine comparator matrix data availability",
            expectedUse = "matrix candidate bootstrap only; verify GEO metadata before Matrix Gate READY"
        ),
        GTIMSeedAccessionV265(
            axis = "hyperinflammatory_hlh_mas_crs",
            handles = emptyList(),
            seedQuery = "HLH MAS cytokine release syndrome ferritin IL-18 IL-6 transcriptome GSE SDY PRJNA comparator controls",
            expectedUse = "query seed only until explicit accession is resolved"
        ),
        GTIMSeedAccessionV265(
            axis = "cancer_tcell_exhaustion_tumor_microenvironment",
            handles = listOf("GSE72056", "GSE131907"),
            seedQuery = "cancer tumor microenvironment T cell exhaustion PD-1 CD8 single-cell GSE comparator responder nonresponder",
            expectedUse = "cancer immune-evasion comparator bootstrap; no treatment ranking"
        ),
        GTIMSeedAccessionV265(
            axis = "hiv_aids_chronic_viral_immunodeficiency",
            handles = emptyList(),
            seedQuery = "HIV AIDS chronic viral infection CD4 depletion CD8 exhaustion transcriptome GSE PRJNA comparator viral load controls",
            expectedUse = "query seed only until explicit accession is resolved"
        ),
        GTIMSeedAccessionV265(
            axis = "fungal_th17_neutrophil_defense",
            handles = emptyList(),
            seedQuery = "Candida Aspergillus fungal infection Th17 IL-17 neutrophil CARD9 Dectin-1 transcriptome GSE PRJNA comparator",
            expectedUse = "query seed only until explicit accession is resolved"
        ),
        GTIMSeedAccessionV265(
            axis = "epidemic_pandemic_immune_response",
            handles = emptyList(),
            seedQuery = "epidemic pandemic outbreak immune response interferon cytokine storm PBMC RNA-seq GSE PRJNA severity controls",
            expectedUse = "query seed only until explicit accession is resolved"
        ),
        GTIMSeedAccessionV265(
            axis = "gut_digestive_microbiome_barrier",
            handles = emptyList(),
            seedQuery = "gut microbiome intestinal permeability mucosal immunity Th17 Treg IgA calprotectin transcriptome microbiome comparator GSE PRJNA",
            expectedUse = "query seed only until explicit accession is resolved; no gut-health advice"
        ),
        GTIMSeedAccessionV265(
            axis = "endocrine_hormone_immune_axis",
            handles = emptyList(),
            seedQuery = "cortisol HPA axis thyroid insulin estrogen androgen cytokine PBMC transcriptome endocrine immune comparator GSE",
            expectedUse = "query seed only until explicit accession is resolved; measured hormone metadata required"
        ),
        GTIMSeedAccessionV265(
            axis = "food_pesticide_residue_immune_axis",
            handles = emptyList(),
            seedQuery = "pesticide residue glyphosate organophosphate pyrethroid immune cytokine microbiome exposed unexposed dataset",
            expectedUse = "query seed only until explicit accession is resolved; measured exposure required"
        ),
        GTIMSeedAccessionV265(
            axis = "livestock_antibiotic_residue_microbiome_axis",
            handles = emptyList(),
            seedQuery = "poultry livestock antibiotic residues food chain microbiome resistome mucosal immunity exposed unexposed dataset",
            expectedUse = "query seed only until explicit accession is resolved; distinguish therapeutic antibiotic use from residue hypothesis"
        ),
        GTIMSeedAccessionV265(
            axis = "water_heavy_metal_immune_axis",
            handles = emptyList(),
            seedQuery = "lead mercury arsenic cadmium drinking water heavy metal immune inflammation transcriptome biomonitoring comparator dataset",
            expectedUse = "query seed only until explicit accession is resolved; water or biospecimen measurement required"
        ),
        GTIMSeedAccessionV265(
            axis = "plastic_microplastic_endocrine_immune_axis",
            handles = emptyList(),
            seedQuery = "microplastics BPA phthalates PFAS plasticizer endocrine immune inflammation transcriptome exposed unexposed dataset",
            expectedUse = "query seed only until explicit accession is resolved; particle and chemical exposures must remain separated"
        )
    )

    fun queriesForText(text: String, limit: Int = RuntimeFeatureFlags.EXPLORATORY_MAX_BOOTSTRAP_ACCESSION_SEEDS_V265): List<String> {
        if (!RuntimeFeatureFlags.ENABLE_SEED_ACCESSION_BOOTSTRAP_V265) return emptyList()
        val normalized = text.lowercase(Locale.US)
        val selected = seeds.filter { seed ->
            val axisTokens = seed.axis.split('_').filter { it.length >= 3 }
            axisTokens.any { normalized.contains(it) } || seed.seedQuery.lowercase(Locale.US).split(' ').any { token -> token.length >= 5 && normalized.contains(token) }
        }.ifEmpty { seeds.take(4) }
        val bootstrapQueries = selected.flatMap { seed ->
            val handlePrefix = seed.handles.take(4).joinToString(" OR ").ifBlank { "GSE OR PRJNA OR SRP OR E-MTAB OR SDY" }
            listOf("($handlePrefix) ${seed.seedQuery} claim-limit:${seed.claimLimit}")
        }
        val knownPriorQueries = GTIMKnownPriorEvidenceSeedsV269.queriesForText(text, limit = limit)
        return (knownPriorQueries + bootstrapQueries).distinct().take(limit)
    }

    fun handlesForText(text: String, limit: Int = RuntimeFeatureFlags.EXPLORATORY_MAX_BOOTSTRAP_ACCESSION_SEEDS_V265): List<String> {
        if (!RuntimeFeatureFlags.ENABLE_SEED_ACCESSION_BOOTSTRAP_V265) return emptyList()
        val normalized = text.lowercase(Locale.US)
        val bootstrapHandles = seeds.filter { seed -> seed.axis.split('_').any { it.length >= 3 && normalized.contains(it) } || seed.seedQuery.lowercase(Locale.US).split(' ').any { it.length >= 5 && normalized.contains(it) } }
            .flatMap { it.handles }
        val knownPriorHandles = GTIMKnownPriorEvidenceSeedsV269.handlesForText(text, limit = limit)
        return (knownPriorHandles + bootstrapHandles)
            .distinct()
            .take(limit)
    }
}
