# Archived Changelogs

Use this folder for older detailed changelog snapshots.

Keep only one consolidated `CHANGELOG.md` in the repository root. This keeps the public GitHub landing page clean while preserving historical development notes for auditability.

Suggested cleanup:

```bash
mkdir -p docs/changelogs
# Move old root-level changelog files, keeping only CHANGELOG.md at root.
git mv CHANGELOG_*.md docs/changelogs/ 2>/dev/null || true
git mv *CHANGELOG*.md docs/changelogs/ 2>/dev/null || true
# Move the consolidated changelog back if it was captured by a broad move.
git mv docs/changelogs/CHANGELOG.md CHANGELOG.md 2>/dev/null || true
```
