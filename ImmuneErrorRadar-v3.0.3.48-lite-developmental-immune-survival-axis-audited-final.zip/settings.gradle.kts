pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
    plugins {
        id("com.android.application") version "8.8.2"
        id("org.jetbrains.kotlin.android") version "1.9.24"
        id("io.gitlab.arturbosch.detekt") version "1.23.7"
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "ImmuneErrorRadar"
include(":app")
