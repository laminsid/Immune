# Pediatric Oncology v3.0.3.38 — Unified B7-H3/GD2/Matrix Focus

## Decision
This release consolidates the pediatric oncology work into one ZIP: source code, the GSE85047 CSV matrix, capsule assets, tests, audits, and documentation.

## Scope
Primary focus is pediatric neuroblastoma, specifically MYCN-amplified vs non-MYCN tumors using a declared-source GSE85047 probe-level matrix. Other pediatric cancers remain routed through pediatric oncology knowledge, but this matrix must not be reused for leukemia, sarcoma, or brain tumor claims unless a matching matrix is attached.

## Learning injected from the two research notes
1. B7-H3/CD276 CAR-T is a pediatric solid tumor translation axis: it should drive target-expression + TME-penetration hypotheses, not treatment claims.
2. GD2/dinutuximab-beta + chemotherapy is a neuroblastoma chemo-immunotherapy response axis: it should drive ADCC/NK/CD8 hypotheses, not direct efficacy claims from GSE85047.
3. Single-cell/spatial profiling is required to split bulk tumor signal into tumor cell, T/NK, macrophage/myeloid, stroma, endothelium, and hypoxia compartments.
4. GSE85047 is explicit matrix fuel for MYCN risk biology. It can make rows>0 and execute real DGE, but it is not ETL-certified and not treatment-response evidence.

## Claim locks
- No clinical advice.
- No dosing or treatment recommendation.
- No certified discovery from declared-source single dataset alone.
- No mechanism support from probe-level matrix until gene mapping + replication + falsifier checks.
- Score >=8 requires verified/replicated matrix or ETL-certified evidence.

## Key embedded files
- `app/src/main/assets/pediatric_oncology/gse85047_neuroblastoma_mycn_probe_matrix_v30337.csv`
- `research/matrices/gse85047_neuroblastoma_mycn_probe_matrix_v30338_embedded.csv`
- `app/src/main/assets/gtim_capsules/pediatric_neuroblastoma_mycn_gd2_b7h3_v30338.json`

## Expected report behavior
For neuroblastoma/MYCN/GD2/B7-H3 topics, the report should show:
- `rowCount > 0`
- case/control rows present
- raw matrix DGE executed for the probe module
- a Pediatric oncology translation lens v3.0.3.38 section
- research-only boundaries preserved
