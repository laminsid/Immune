# v3.0.3.37 — Pediatric Oncology Explicit Matrix Focus

## Scope
Focuses the research engine on a pediatric oncology route, specifically pediatric neuroblastoma / MYCN-amplified vs non-MYCN samples using a declared-source GSE85047 probe-level matrix subset.

## Added
- `PediatricOncologyExplicitMatrixV30337` with 12 declared-source sample rows from GSE85047 sample tables.
- CSV asset: `app/src/main/assets/pediatric_oncology/gse85047_neuroblastoma_mycn_probe_matrix_v30337.csv`.
- Pediatric oncology matrix integration through the existing `MatrixFuelProviderV30331` path, not a new DGE calculator.
- Pediatric comparator labels: `case_mycn_amplified` vs `control_non_mycn`.
- Pediatric DGE signal state: `PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_EXECUTED_REVIEW_ONLY`.
- Certification gate state: `PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_REVIEW_ONLY_NOT_CERTIFIED`.
- Regression tests ensuring rows fill, DGE executes, mechanism support stays locked, and unrelated pediatric cancers do not receive the GSE85047 neuroblastoma matrix.
- Static audit: `scripts/audit_research_engine_v30337_pediatric_oncology_matrix_focus.py`.

## Boundaries
- The matrix is probe-level and declared-source only.
- It is not ETL-certified, not platform-gene mapped, not replicated, and not clinical evidence.
- It may drive hypothesis ranking and real DGE execution, but cannot unlock mechanism support, certified discovery, treatment claims, or score >= 8 by itself.

## Why
Previous v3.0.3.35/36 reports kept returning preview/checkpoint because `explicitMatrixRows` stayed empty. This release injects a real pediatric neuroblastoma matrix into the existing explicit matrix path so `rows > 0` and real DGE can execute.
