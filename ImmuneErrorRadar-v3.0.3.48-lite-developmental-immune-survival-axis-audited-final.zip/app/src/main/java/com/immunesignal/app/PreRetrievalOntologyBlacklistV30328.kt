package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * Lightweight pre-retrieval blacklist. It does not make the engine stricter at
 * hypothesis generation time; it only avoids burning scarce budget on known
 * organism/domain drift queries before they reach the ledger.
 */
data class PreRetrievalFilterSnapshotV30328(
    val blockedQueries: List<String>,
    val reasons: List<String>
) {
    fun toJson(): JSONObject = JSONObject()
        .put("blockedQueries", JSONArray(blockedQueries))
        .put("reasons", JSONArray(reasons))
}

object PreRetrievalOntologyBlacklistV30328 {
    const val REQUIRED_TOKEN: String = "V30328_PRE_RETRIEVAL_ONTOLOGY_BLACKLIST"

    fun filter(topic: String, role: EvidenceRoleV3, queries: List<String>): Pair<List<String>, PreRetrievalFilterSnapshotV30328> {
        val raw = topic.lowercase()
        val humanDisease = listOf("cancer", "neuroblastoma", "multiple sclerosis", "rrms", "alzheimer", "diabetes", "rheumatoid", "lupus", "covid", "allergy", "asthma").any { raw.contains(it) }
        val blocked = mutableListOf<String>()
        val reasons = mutableListOf<String>()
        val allowed = queries.filter { q ->
            val lower = q.lowercase()
            val plantDrift = humanDisease && listOf("arabidopsis", "plant immunity", "jasmonic", "crop", "rice", "wheat", "maize").any { lower.contains(it) }
            val adultCancerDrift = (raw.contains("neuroblastoma") || raw.contains("pediatric") || raw.contains("childhood")) &&
                listOf("melanoma", "prostate cancer", "bladder cancer", "lurbinectedin", "camrelizumab").any { lower.contains(it) } &&
                !lower.contains("neuroblastoma")
            if (plantDrift || (adultCancerDrift && role in setOf(EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE, EvidenceRoleV3.MECHANISM))) {
                blocked += q
                reasons += if (plantDrift) "blocked_pre_retrieval_organism_blacklist" else "blocked_pre_retrieval_pediatric_oncology_adult_cancer_drift"
                false
            } else {
                true
            }
        }
        return (if (allowed.isEmpty()) queries.take(1) else allowed) to PreRetrievalFilterSnapshotV30328(blocked.distinct(), reasons.distinct())
    }
}
