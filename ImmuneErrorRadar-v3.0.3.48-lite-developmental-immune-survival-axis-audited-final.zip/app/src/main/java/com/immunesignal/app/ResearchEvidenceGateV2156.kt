package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.15.6 — strict evidence-handle classifier for the clean runtime.
 *
 * The previous bounded probe layer correctly prevented infinite waits, but some
 * negative probe markers could still look like evidence because they contained
 * words such as "checked" or "executed". This classifier separates:
 * - attempted probes / gaps / local planning markers
 * - positive source/provenance/contradiction handles that may close a gate
 *
 * It is intentionally small and deterministic so the UI, report builder, and
 * tests read the same closure logic.
 */
object ResearchEvidenceGateV2156 {
    const val VERSION: String = "2.15.6-evidence-handle-classifier"
    const val REQUIRED_TOKEN: String = "V2156_NEGATIVE_PROBE_MARKERS_DO_NOT_CLOSE_PROOF_GATE"

    fun isNegativeOrPlanningMarker(handle: String): Boolean {
        val h = handle.lowercase()
        return listOf(
            "not_evidence",
            "proof_gap_",
            "proof_gate_open_",
            "probe_disabled",
            "probe_error",
            "no_handle_found",
            "no_verified_dataset_yet",
            "no_clear_sample_link_yet",
            "no_pubmed_hit_yet",
            "no_handle_yet",
            "local_only",
            "planned_not_evidence",
            "required_not_closed",
            "requires_proof_not_closed"
        ).any { h.contains(it) }
    }

    fun isPositiveSourceHandle(handle: String): Boolean {
        val h = handle.lowercase()
        if (isNegativeOrPlanningMarker(h)) return false
        return h.startsWith("source_handle_closed_pubmed_") ||
            h.startsWith("dataset_verified_gds_") ||
            h.contains("accession_verified") ||
            h.contains("dataset_verified")
    }

    fun isPositiveProvenanceHandle(handle: String): Boolean {
        val h = handle.lowercase()
        if (isNegativeOrPlanningMarker(h)) return false
        return h.startsWith("metadata_probe_executed_pubmed_") ||
            h.startsWith("provenance_probe_executed_") ||
            h.startsWith("comparator_probe_executed_pubmed_") ||
            h.startsWith("sample_probe_executed_pubmed_") ||
            h.contains("sample_id_linked") ||
            h.contains("metadata_verified") ||
            h.contains("provenance_closed")
    }

    fun isPositiveContradictionHandle(handle: String): Boolean {
        val h = handle.lowercase()
        if (isNegativeOrPlanningMarker(h)) return false
        return h.startsWith("contradiction_checked_pubmed_") ||
            h.startsWith("contradiction_checked_wrong_") ||
            h.startsWith("contradiction_checked_failed_") ||
            h.startsWith("contradiction_checked_replication_") ||
            h.startsWith("falsification_probe_executed_pubmed_") ||
            h.contains("falsification_closed")
    }

    fun isPositiveMechanismHandle(handle: String): Boolean {
        val h = handle.lowercase()
        if (isNegativeOrPlanningMarker(h)) return false
        return h.startsWith("mechanism_linkage_probe_executed_pubmed_") ||
            h.contains("mechanism_linkage_closed")
    }

    fun gateState(handles: List<String>): GateState {
        val source = handles.any { isPositiveSourceHandle(it) }
        val provenance = handles.any { isPositiveProvenanceHandle(it) }
        val contradiction = handles.any { isPositiveContradictionHandle(it) }
        val mechanism = handles.any { isPositiveMechanismHandle(it) }
        return GateState(
            hasSource = source,
            hasProvenance = provenance,
            hasContradiction = contradiction,
            hasMechanism = mechanism,
            negativeOrGapCount = handles.count { isNegativeOrPlanningMarker(it) }
        )
    }

    data class GateState(
        val hasSource: Boolean,
        val hasProvenance: Boolean,
        val hasContradiction: Boolean,
        val hasMechanism: Boolean,
        val negativeOrGapCount: Int
    ) {
        val closed: Boolean get() = hasSource && hasProvenance && hasContradiction

        fun toJson(): JSONObject = JSONObject()
            .put("version", VERSION)
            .put("requiredToken", REQUIRED_TOKEN)
            .put("hasPositiveSource", hasSource)
            .put("hasPositiveProvenance", hasProvenance)
            .put("hasPositiveContradiction", hasContradiction)
            .put("hasPositiveMechanism", hasMechanism)
            .put("negativeOrGapCount", negativeOrGapCount)
            .put("closed", closed)
    }

    fun positiveHandlesJson(handles: List<String>): JSONObject {
        val source = handles.filter { isPositiveSourceHandle(it) }
        val provenance = handles.filter { isPositiveProvenanceHandle(it) }
        val contradiction = handles.filter { isPositiveContradictionHandle(it) }
        val mechanism = handles.filter { isPositiveMechanismHandle(it) }
        return JSONObject()
            .put("version", VERSION)
            .put("requiredToken", REQUIRED_TOKEN)
            .put("source", JSONArray(source.take(12)))
            .put("provenance", JSONArray(provenance.take(12)))
            .put("contradiction", JSONArray(contradiction.take(12)))
            .put("mechanism", JSONArray(mechanism.take(12)))
            .put("gapMarkers", JSONArray(handles.filter { isNegativeOrPlanningMarker(it) }.take(20)))
    }
}
