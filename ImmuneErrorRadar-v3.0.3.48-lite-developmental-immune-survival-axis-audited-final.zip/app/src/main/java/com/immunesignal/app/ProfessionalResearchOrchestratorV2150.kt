package com.immunesignal.app

import org.json.JSONObject

object ProfessionalResearchOrchestratorV2150 {
    const val VERSION: String = "2.17.2-independent-evidence-orchestrator"
    const val REQUIRED_TOKEN: String = "V2172_ORCHESTRATOR_USES_INDEPENDENT_REVIEWABLE_EVIDENCE"
    const val LEGACY_REQUIRED_TOKEN_V2170: String = "V2170_ORCHESTRATOR_USES_REAL_EVIDENCE_ACQUISITION"
    const val LEGACY_REQUIRED_TOKEN_V2162: String = "V2162_ORCHESTRATOR_VERSION_ALIGNED_PAUSE_TIMEOUT"
    const val LEGACY_REQUIRED_TOKEN_V2160: String = "V2160_ORCHESTRATOR_CANNOT_REPORT_READY_WITH_PHANTOM_EVIDENCE"
    const val PAUSE_TIMEOUT_MARKER: String = "pause_timeout_auto_checkpoint_not_evidence"
    const val PAUSE_TIMEOUT_TOKEN: String = "V2162_PAUSE_LOOP_BOUNDED_TO_AUTO_CHECKPOINT"
    const val LEGACY_REQUIRED_TOKEN_V2150: String = "V2150_PROFESSIONAL_ORCHESTRATOR_TASK_QUEUE_RESET"
    const val PROOF_GATED_BY_V2154: String = "V2154_PROOF_GATE_PREVENTS_FAST_5_SECOND_REPORT"
    // ResearchExecutionPolicyV2154.reportCanClose compatibility: final close is now additionally gated by ResearchRunDepthGuardV2159.reportCanClose.

    fun run(
        topic: String,
        shouldPause: () -> Boolean,
        shouldStop: () -> Boolean,
        onState: (ResearchRunContractV2150, JSONObject) -> Unit,
        policy: ResearchExecutionPolicyV2154.Policy = ResearchExecutionPolicyV2154.interactive()
    ): JSONObject {
        val runStartedAtMillis = System.currentTimeMillis()
        var softBudgetReached = false
        var pauseTimeoutReached = false
        var contract = ResearchRunContractV2150.create(topic).withStatus(ResearchRunStatusV2150.RUNNING)
        if (policy.allowUnitTestProofSimulation) {
            contract = contract
                .withEvidenceHandle("source_handle_closed_pubmed_111111__title_unit_test_source")
                .withEvidenceHandle("metadata_probe_executed_pubmed_222222__title_unit_test_metadata")
                .withEvidenceHandle("contradiction_checked_pubmed_333333__title_unit_test_falsifier")
        }
        onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "run_started")
            .put("runtimeClosureAuditV2157", ResearchRuntimeClosureAuditV2157.toJson(contract)))

        for (task in contract.tasks) {
            if (policy.maxSingleRunMillis > 0L && System.currentTimeMillis() - runStartedAtMillis >= policy.maxSingleRunMillis) {
                softBudgetReached = true
                contract = contract
                    .withEvidenceHandle("runtime_soft_budget_reached_not_evidence")
                    .withCheckpoint("runtime_soft_budget_${System.currentTimeMillis()}")
                onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "runtime_soft_budget_reached")
                    .put("runtimeClosureAuditV2157", ResearchRuntimeClosureAuditV2157.toJson(contract)))
                break
            }
            if (shouldStop()) break
            contract = waitIfPaused(contract, shouldPause, shouldStop, onState, policy.maxPauseMillis)
            if (contract.evidenceHandles.contains(PAUSE_TIMEOUT_MARKER)) {
                pauseTimeoutReached = true
                break
            }
            if (shouldStop()) break

            contract = contract.withStatus(ResearchRunStatusV2150.RUNNING)
                .updateTask(task.id, ResearchTaskStatusV2150.RUNNING)
            onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "task_running_${task.id}"))
            sleep(policy.localTaskSleepMs)

            val proofTask = task.requiresProofProvider || ResearchExecutionPolicyV2154.requiresProof(task.id)
            val proofClosed = ResearchExecutionPolicyV2154.hasClosedProofGate(contract) || policy.allowUnitTestProofSimulation
            if (proofTask && !proofClosed) {
                contract = contract.updateTask(task.id, ResearchTaskStatusV2150.WAITING_FOR_PROOF)
                    .withEvidenceHandle("proof_gate_waiting_${task.id.lowercase()}_not_evidence")
                    .withCheckpoint("proof_wait_${task.id.lowercase()}_${System.currentTimeMillis()}")
                onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "proof_wait_${task.id}")
                    .put("proofWaitReason", ResearchExecutionPolicyV2154.waitingReason(task.id))
                    .put("proofGatedRuntimeV2154", ResearchExecutionPolicyV2154.proofGateJson(contract))
                    .put("boundedProofProbeV2155", ResearchProofProbeV2155.REQUIRED_TOKEN))

                // Compatibility token for old audits only: proof_wait_tick_. The runtime no longer
                // loops over proof_wait_tick_ events. It executes one bounded proof probe per task
                // and then continues to a checkpoint-backed closure.
                val probeResult = ResearchProofProbeV2155.execute(contract.topic, task.id, policy)
                contract = ResearchProofProbeV2155.applyResult(contract, probeResult)
                contract = enrichContractAfterTask(contract.updateTask(task.id, ResearchTaskStatusV2150.DONE), task.id)
                    .withCheckpoint("checkpoint_${task.id.lowercase()}_${System.currentTimeMillis()}")
                onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "bounded_probe_done_${task.id}")
                    .put("proofProbeV2155", probeResult.toJson())
                    .put("proofGatedRuntimeV2154", ResearchExecutionPolicyV2154.proofGateJson(contract))
                    .put("runtimeClosureAuditV2157", ResearchRuntimeClosureAuditV2157.toJson(contract)))
                if (policy.maxSingleRunMillis > 0L && System.currentTimeMillis() - runStartedAtMillis >= policy.maxSingleRunMillis) {
                    softBudgetReached = true
                    contract = contract
                        .withEvidenceHandle("runtime_soft_budget_reached_after_probe_not_evidence")
                        .withCheckpoint("runtime_soft_budget_after_probe_${System.currentTimeMillis()}")
                    break
                }
                continue
            }

            contract = enrichContractAfterTask(contract.updateTask(task.id, ResearchTaskStatusV2150.DONE), task.id)
            contract = contract.withCheckpoint("checkpoint_${task.id.lowercase()}_${System.currentTimeMillis()}")
            onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "task_done_${task.id}")
                .put("runtimeClosureAuditV2157", ResearchRuntimeClosureAuditV2157.toJson(contract)))
        }

        if (!shouldStop() && !softBudgetReached) {
            val depthBefore = ResearchRunDepthGuardV2159.evaluate(contract, System.currentTimeMillis() - runStartedAtMillis, policy)
            val needsDepthReview = policy.interactive && policy.enableResearchDepthGuard &&
                (System.currentTimeMillis() - runStartedAtMillis < policy.minInteractiveRunMillis || depthBefore.fastClosePrevented)
            if (needsDepthReview) {
                contract = contract
                    .withEvidenceHandle("research_depth_guard_started_not_evidence")
                    .withCheckpoint("research_depth_guard_started_${System.currentTimeMillis()}")
                onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "research_depth_guard_started")
                    .put("researchRunDepthGuardV2159", depthBefore.toJson()))

                for (depthTaskId in ResearchRunDepthGuardV2159.finalVerificationTasks()) {
                    if (shouldStop()) break
                    if (policy.maxSingleRunMillis > 0L && System.currentTimeMillis() - runStartedAtMillis >= policy.maxSingleRunMillis) {
                        softBudgetReached = true
                        break
                    }
                    val probeResult = ResearchProofProbeV2155.execute(
                        topic = contract.topic + " focused verification " + depthTaskId.lowercase(),
                        taskId = depthTaskId,
                        policy = policy
                    )
                    contract = ResearchProofProbeV2155.applyResult(contract, probeResult)
                        .withCheckpoint("research_depth_guard_${depthTaskId.lowercase()}_${System.currentTimeMillis()}")
                    onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "research_depth_guard_probe_${depthTaskId}")
                        .put("proofProbeV2155", probeResult.toJson())
                        .put("researchRunDepthGuardV2159", ResearchRunDepthGuardV2159.evaluate(contract, System.currentTimeMillis() - runStartedAtMillis, policy).toJson())
                        .put("proofGatedRuntimeV2154", ResearchExecutionPolicyV2154.proofGateJson(contract)))
                    sleep(policy.depthGuardSleepMs)
                }

                while (!shouldStop() && !softBudgetReached &&
                    policy.interactive && policy.enableResearchDepthGuard &&
                    System.currentTimeMillis() - runStartedAtMillis < policy.minInteractiveRunMillis) {
                    if (policy.maxSingleRunMillis > 0L && System.currentTimeMillis() - runStartedAtMillis >= policy.maxSingleRunMillis) {
                        softBudgetReached = true
                        break
                    }
                    contract = contract.withCheckpoint("research_depth_guard_pacing_${System.currentTimeMillis()}")
                    onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "research_depth_guard_pacing")
                        .put("researchRunDepthGuardV2159", ResearchRunDepthGuardV2159.evaluate(contract, System.currentTimeMillis() - runStartedAtMillis, policy).toJson()))
                    sleep(policy.depthGuardSleepMs.coerceIn(250L, 2_000L))
                }
            }
        }

        val completed = contract.completedTaskCount
        val elapsedAtClose = System.currentTimeMillis() - runStartedAtMillis
        contract = when {
            shouldStop() -> contract.withStatus(ResearchRunStatusV2150.STOPPED)
            pauseTimeoutReached -> contract.withStatus(ResearchRunStatusV2150.CHECKPOINT_READY)
            softBudgetReached -> contract.withStatus(ResearchRunStatusV2150.CHECKPOINT_READY)
            ResearchRunDepthGuardV2159.reportCanClose(contract, elapsedAtClose, policy) && completed >= contract.totalTaskCount -> contract.withStatus(ResearchRunStatusV2150.REPORT_READY)
            completed >= 2 -> contract.withStatus(ResearchRunStatusV2150.CHECKPOINT_READY)
            else -> contract.withStatus(ResearchRunStatusV2150.FAILED_SAFE)
        }
        val finalDepth = ResearchRunDepthGuardV2159.evaluate(contract, System.currentTimeMillis() - runStartedAtMillis, policy)
        val finalReport = ResearchBriefBuilderV2150.buildReport(contract, if (softBudgetReached) "run_closed_soft_budget" else "run_closed")
            .put("professionalResearchOrchestratorV2150", JSONObject()
                .put("version", VERSION)
                .put("requiredToken", REQUIRED_TOKEN)
                .put("oldV2145V2146LoopReplaced", true)
                .put("noDeepeningPassCounter", true)
                .put("noCountdownDrivenRuntime", true)
                .put("taskQueueOwnsProgress", true)
                .put("proofGatedByV2154", PROOF_GATED_BY_V2154)
                .put("noFastFiveSecondReport", true)
                .put("boundedProofProbeV2155", ResearchProofProbeV2155.REQUIRED_TOKEN)
                .put("noInfiniteProofWait", true)
                .put("evidenceGateV2156", ResearchEvidenceGateV2156.REQUIRED_TOKEN)
                .put("runtimeClosureAuditV2157", ResearchRuntimeClosureAuditV2157.REQUIRED_TOKEN)
                .put("researchDepthGuardV2159", ResearchRunDepthGuardV2159.REQUIRED_TOKEN)
                .put("researchProofContractV2160", ResearchProofContractV2160.REQUIRED_TOKEN)
                .put("realEvidenceAcquisitionV2170", ResearchEvidenceAcquisitionV2170.REQUIRED_TOKEN)
                .put("evidenceDiversityAuditV2172", ResearchEvidenceDiversityAuditV2172.REQUIRED_TOKEN)
                .put("phantomEvidenceDepthBlocked", true)
                .put("softBudgetReached", softBudgetReached)
                .put("pauseTimeoutReached", pauseTimeoutReached)
                .put("pauseTimeoutTokenV2162", PAUSE_TIMEOUT_TOKEN)
                .put("elapsedMillis", System.currentTimeMillis() - runStartedAtMillis))
            .put("proofGatedRuntimeV2154", ResearchExecutionPolicyV2154.proofGateJson(contract))
            .put("researchRunDepthGuardV2159", finalDepth.toJson())
        onState(contract, finalReport)
        return finalReport
    }

    private fun waitIfPaused(
        input: ResearchRunContractV2150,
        shouldPause: () -> Boolean,
        shouldStop: () -> Boolean,
        onState: (ResearchRunContractV2150, JSONObject) -> Unit,
        maxPauseMillis: Long
    ): ResearchRunContractV2150 {
        var contract = input
        var lastPausedEmitAt = 0L
        val pauseStartedAt = System.currentTimeMillis()
        while (shouldPause() && !shouldStop()) {
            val now = System.currentTimeMillis()
            if (maxPauseMillis > 0L && now - pauseStartedAt >= maxPauseMillis) {
                contract = contract
                    .withStatus(ResearchRunStatusV2150.CHECKPOINT_READY)
                    .withEvidenceHandle(PAUSE_TIMEOUT_MARKER)
                    .withCheckpoint("auto_checkpoint_pause_timeout_${now}")
                onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "pause_timeout_auto_checkpoint")
                    .put("pauseTimeoutTokenV2162", PAUSE_TIMEOUT_TOKEN)
                    .put("maxPauseMillis", maxPauseMillis)
                    .put("pausedElapsedMillis", now - pauseStartedAt))
                return contract
            }
            contract = contract.withStatus(ResearchRunStatusV2150.PAUSED)
            if (now - lastPausedEmitAt >= 1_000L) {
                onState(contract, ResearchCheckpointStoreV2150.checkpointJson(contract, "paused")
                    .put("pauseTimeoutTokenV2162", PAUSE_TIMEOUT_TOKEN)
                    .put("maxPauseMillis", maxPauseMillis)
                    .put("pausedElapsedMillis", now - pauseStartedAt))
                lastPausedEmitAt = now
            }
            sleep(250L)
        }
        return if (contract.status == ResearchRunStatusV2150.PAUSED && !shouldStop()) {
            contract.withStatus(ResearchRunStatusV2150.RUNNING)
        } else {
            contract
        }
    }

    private fun sleep(ms: Long) {
        if (ms <= 0L) return
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    private fun enrichContractAfterTask(contract: ResearchRunContractV2150, taskId: String): ResearchRunContractV2150 {
        val t = contract.topic.lowercase()
        var c = contract
        when (taskId) {
            "T2_LOCAL_MEMORY_MAP" -> {
                if (t.contains("ebola") || t.contains("bundibugyo") || t.contains("filovirus")) {
                    c = c.withHypothesis("Filovirus vascular-innate failure route: interferon evasion, macrophage amplification, endothelial leak, coagulation/NETosis lens.")
                }
                if (t.contains("covid") || t.contains("sars")) {
                    c = c.withHypothesis("Mucosal antiviral timing route: type-I/type-III interferon, epithelial/endothelial structural immunity, immunothrombosis.")
                }
                if (t.contains("cancer") || t.contains("tumor") || t.contains("tumour")) {
                    c = c.withHypothesis("Tumor immune-exclusion split: antigen presentation, T-cell exhaustion, FOXP3/Treg tolerance, stromal exclusion, onco-microbiome.")
                }
                if (t.contains("allerg") || t.contains("asthma") || t.contains("eczema")) {
                    c = c.withHypothesis("Barrier/tolerance split: epithelial structural memory, type-2 inflammation, Treg tolerance and microbiome-metabolite modulation.")
                }
            }
            "T4_SOURCE_HANDLES" -> c = c.withEvidenceHandle("candidate_source_handles_planned_not_evidence")
            "T5_METADATA_PROVENANCE" -> c = c.withEvidenceHandle("metadata_provenance_required_not_closed")
            "T7_CONTRADICTION_FALSIFICATION" -> c = c.withEvidenceHandle("contradiction_falsification_required_not_closed")
            "T8_MECHANISM_LINKAGE" -> c = c.withEvidenceHandle("mechanism_linkage_requires_proof_not_closed")
        }
        return c
    }
}
