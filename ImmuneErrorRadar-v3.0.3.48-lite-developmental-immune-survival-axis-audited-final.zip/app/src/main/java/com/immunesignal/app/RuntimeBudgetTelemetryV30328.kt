package com.immunesignal.app

import org.json.JSONObject

/**
 * Budget telemetry without increasing the interactive cap. This explains where
 * the small mobile budget was spent so failed runs can be improved deliberately.
 */
data class RuntimeBudgetTelemetrySnapshotV30328(
    val sourceSearchCalls: Int,
    val datasetSearchCalls: Int,
    val contradictionSearchCalls: Int,
    val provenanceSearchCalls: Int,
    val proofContinuationCalls: Int,
    val stoppedBecause: String,
    val matrixState: String = "not_evaluated",
    val matrixRows: Int = 0,
    val matrixCaseRows: Int = 0,
    val matrixControlRows: Int = 0,
    val rawDgeExecuted: Boolean = false,
    val runtimeBottleneck: String = "not_evaluated"
) {
    fun toJson(): JSONObject = JSONObject()
        .put("sourceSearchCalls", sourceSearchCalls)
        .put("datasetSearchCalls", datasetSearchCalls)
        .put("contradictionSearchCalls", contradictionSearchCalls)
        .put("provenanceSearchCalls", provenanceSearchCalls)
        .put("proofContinuationCalls", proofContinuationCalls)
        .put("stoppedBecause", stoppedBecause)
        .put("matrixState", matrixState)
        .put("matrixRows", matrixRows)
        .put("matrixCaseRows", matrixCaseRows)
        .put("matrixControlRows", matrixControlRows)
        .put("rawDgeExecuted", rawDgeExecuted)
        .put("runtimeBottleneck", runtimeBottleneck)
}

object RuntimeBudgetTelemetryV30328 {
    const val REQUIRED_TOKEN: String = "V30332_RUNTIME_BUDGET_TELEMETRY_WITH_MATRIX_STAGE_NO_CAP_INCREASE"
    const val LEGACY_REQUIRED_TOKEN: String = "V30328_RUNTIME_BUDGET_TELEMETRY_NO_CAP_INCREASE"

    fun evaluate(
        state: ResearchStateV3,
        closure: ResearchClosureSnapshotV3,
        expressionSignal: ProcessedExpressionSignalReportV30329? = null
    ): RuntimeBudgetTelemetrySnapshotV30328 {
        fun calls(kind: String): Int = state.ledgerSnapshot.objectiveOutcomes
            .filter { it.objective.kind == kind }
            .sumOf { it.queriesAttempted.size }
        val stoppedBecause = closure.openGates.firstOrNull()
            ?: if (!state.input.budget.hasCapacity(state.budgetUsage, state.executedObjectiveCount)) "budget_exhausted" else "planner_completed"
        val fuel = expressionSignal?.matrixFuel
        val bottleneck = when {
            closure.openGates.contains("budget_exhausted_before_closure") -> "retrieval_budget_exhausted_before_closure"
            expressionSignal?.rawMatrixDgeExecuted == true && fuel?.certifiedForDiscovery == false -> "matrix_certification_missing_review_only_fuel"
            fuel?.rowCount.orZero() > 0 && expressionSignal?.rawMatrixDgeExecuted != true -> "matrix_grouping_or_marker_mapping"
            fuel?.rowCount.orZero() == 0 && expressionSignal?.active == true -> "matrix_rows_missing"
            calls("FindDatasetEvidence") == 0 -> "dataset_search_not_reached"
            calls("FindSourceEvidence") > calls("FindDatasetEvidence") + calls("FindContradiction") -> "source_retrieval_dominant"
            else -> stoppedBecause
        }
        return RuntimeBudgetTelemetrySnapshotV30328(
            sourceSearchCalls = calls("FindSourceEvidence"),
            datasetSearchCalls = calls("FindDatasetEvidence"),
            contradictionSearchCalls = calls("FindContradiction"),
            provenanceSearchCalls = calls("FindProvenance"),
            proofContinuationCalls = calls("ContinueHypothesisProof"),
            stoppedBecause = stoppedBecause,
            matrixState = fuel?.state ?: "not_available",
            matrixRows = fuel?.rowCount.orZero(),
            matrixCaseRows = fuel?.caseRowCount.orZero(),
            matrixControlRows = fuel?.controlRowCount.orZero(),
            rawDgeExecuted = expressionSignal?.rawMatrixDgeExecuted == true,
            runtimeBottleneck = bottleneck
        )
    }

    private fun Int?.orZero(): Int = this ?: 0
}
