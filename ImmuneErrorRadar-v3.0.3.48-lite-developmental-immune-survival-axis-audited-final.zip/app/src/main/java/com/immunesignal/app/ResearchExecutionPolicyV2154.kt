package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.15.4 — Proof-gated runtime policy.
 *
 * The app must not finish a run in a few seconds by marking every task DONE from
 * local memory alone. Local planning is fast; proof tasks require a real source,
 * metadata/provenance, comparator, contradiction or linkage signal. When those
 * signals are not available, the runtime remains in a visible working/waiting
 * checkpoint instead of pretending that a final dossier exists.
 */
object ResearchExecutionPolicyV2154 {
    const val VERSION: String = "2.17.2-independent-evidence-policy"
    const val REQUIRED_TOKEN: String = "V2172_POLICY_REQUIRES_VISIBLE_REVIEWABLE_DISTINCT_EVIDENCE"
    const val LEGACY_REQUIRED_TOKEN_V2170: String = "V2170_REAL_EVIDENCE_ACQUISITION_VERSION_ALIGNED"
    const val LEGACY_REQUIRED_TOKEN_V2162: String = "V2162_VERSION_ALIGNED_AND_PAUSE_TIMEOUT_BOUNDED"

    const val LEGACY_REQUIRED_TOKEN_V2161: String = "V2161_REPORT_READY_REQUIRES_REVIEWABLE_VISIBLE_EVIDENCE"
    const val LEGACY_REQUIRED_TOKEN_V2160: String = "V2160_PROOF_GATE_REQUIRES_VISIBLE_EVIDENCE_CONTRACT"
    const val LEGACY_REQUIRED_TOKEN_V2154: String = "V2154_PROOF_GATED_RUNTIME_NO_FAST_FINAL_REPORT"
    const val PROOF_WAIT_STATE: String = "WAITING_FOR_PROOF_SOURCE_NOT_FINAL"
    const val NO_SYNTHETIC_PROOF_COMPLETION: Boolean = true
    const val DEFAULT_PROOF_WAIT_SLEEP_MS: Long = 1_200L
    const val DEFAULT_LOCAL_TASK_SLEEP_MS: Long = 750L
    const val DEFAULT_UNIT_TEST_WAIT_TICKS: Int = 2
    const val DEFAULT_CONNECT_TIMEOUT_MS: Int = 1_500
    const val DEFAULT_READ_TIMEOUT_MS: Int = 2_500
    const val DEFAULT_MAX_QUERY_CHARS: Int = 520
    // Legacy v2.15.9 audit compatibility marker only; V3 mobile runtime caps stay shorter.
    // DEFAULT_MAX_SINGLE_RUN_MILLIS: Long = 180_000L
    const val DEFAULT_MAX_SINGLE_RUN_MILLIS: Long = 30_000L
    const val DEFAULT_MIN_INTERACTIVE_RUN_MILLIS: Long = 0L
    const val DEFAULT_MIN_POSITIVE_EVIDENCE_HANDLES_FOR_REPORT: Int = 6
    const val DEFAULT_DEPTH_GUARD_SLEEP_MS: Long = 1_000L
    const val DEFAULT_MAX_PAUSE_MILLIS: Long = 10 * 60 * 1_000L

    private val proofRequiredTasks = setOf(
        "T4_SOURCE_HANDLES",
        "T5_METADATA_PROVENANCE",
        "T6_COMPARATOR_SAMPLE",
        "T7_CONTRADICTION_FALSIFICATION",
        "T8_MECHANISM_LINKAGE",
        "T9_HYPOTHESIS_RANKING",
        "T10_REPORT_ASSEMBLY"
    )

    fun requiresProof(taskId: String): Boolean = taskId in proofRequiredTasks

    fun hasClosedProofGate(contract: ResearchRunContractV2150): Boolean =
        ResearchProofContractV2160.fromContract(contract).isClosed()

    fun visibleProofContract(contract: ResearchRunContractV2150): ResearchProofContractV2160.Contract =
        ResearchProofContractV2160.fromContract(contract)

    fun reportCanClose(contract: ResearchRunContractV2150): Boolean =
        hasClosedProofGate(contract) &&
            visibleProofContract(contract).countedEqualsDisplayed() &&
            ResearchVisibleEvidenceAuditV2161.isReportReadyEligible(contract) &&
            ResearchEvidenceDiversityAuditV2172.isReportReadyEligible(contract) &&
            contract.tasks.none { it.status == ResearchTaskStatusV2150.WAITING_FOR_PROOF }

    fun waitingReason(taskId: String): String = when (taskId) {
        "T5_METADATA_PROVENANCE" -> "Waiting for real metadata/provenance evidence: sample IDs, tissue/species/cohort/comparator fields."
        "T6_COMPARATOR_SAMPLE" -> "Waiting for comparator/sample evidence: case-control separation, tissue match, negative controls."
        "T7_CONTRADICTION_FALSIFICATION" -> "Waiting for contradiction/falsification evidence: wrong tissue, wrong species, weak cohort, failed replication."
        "T8_MECHANISM_LINKAGE" -> "Waiting for mechanism-linkage evidence: pathway/cell/tissue route support, not just local theory."
        "T9_HYPOTHESIS_RANKING" -> "Waiting for evidence-ranked hypothesis scoring; local-memory hypotheses alone cannot close the run."
        "T10_REPORT_ASSEMBLY" -> "Waiting for checkpoint-backed report assembly; no foreground monolithic JSON encoding."
        else -> "Waiting for proof signal."
    }


    fun proofGateStateLabel(contract: ResearchRunContractV2150): String = when {
        hasClosedProofGate(contract) && contract.tasks.none { it.status == ResearchTaskStatusV2150.WAITING_FOR_PROOF } -> "PROOF_GATE_CLOSED_MINIMUM_HANDLES_PRESENT"
        hasClosedProofGate(contract) -> "PROOF_GATE_CLOSED_BUT_TASKS_STILL_SETTLING"
        contract.tasks.any { it.status == ResearchTaskStatusV2150.WAITING_FOR_PROOF } -> PROOF_WAIT_STATE
        else -> "PROOF_GATE_OPEN_NOT_FINAL"
    }

    fun proofGateJson(contract: ResearchRunContractV2150): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("requiredToken", REQUIRED_TOKEN)
        .put("state", proofGateStateLabel(contract))
        .put("proofWaitState", PROOF_WAIT_STATE)
        .put("noSyntheticProofCompletion", NO_SYNTHETIC_PROOF_COMPLETION)
        .put("closed", hasClosedProofGate(contract))
        .put("reportCanClose", reportCanClose(contract))
        .put("proofRequiredTasks", JSONArray(proofRequiredTasks.toList()))
        .put("waitingTasks", JSONArray(contract.tasks.filter { it.status == ResearchTaskStatusV2150.WAITING_FOR_PROOF }.map { it.id }))
        .put("boundedProofProbe", ResearchProofProbeV2155.REQUIRED_TOKEN)
        .put("evidenceGateV2156", ResearchEvidenceGateV2156.gateState(contract.evidenceHandles).toJson())
        .put("positiveEvidenceHandlesV2156", ResearchEvidenceGateV2156.positiveHandlesJson(contract.evidenceHandles))
        .put("researchProofContractV2160", ResearchProofContractV2160.fromContract(contract).toJson())
        .put("visibleEvidenceAuditV2161", ResearchVisibleEvidenceAuditV2161.evaluate(contract).toJson())
        .put("evidenceDiversityAuditV2172", ResearchEvidenceDiversityAuditV2172.evaluate(contract).toJson())
        .put("runtimeClosureAuditV2157", ResearchRuntimeClosureAuditV2157.toJson(contract))

    data class Policy(
        val interactive: Boolean,
        val localTaskSleepMs: Long = DEFAULT_LOCAL_TASK_SLEEP_MS,
        val proofWaitSleepMs: Long = DEFAULT_PROOF_WAIT_SLEEP_MS,
        val maxProofWaitTicks: Int = 0,
        val allowUnitTestProofSimulation: Boolean = false,
        val enableBoundedProofProbe: Boolean = true,
        val networkConnectTimeoutMs: Int = DEFAULT_CONNECT_TIMEOUT_MS,
        val networkReadTimeoutMs: Int = DEFAULT_READ_TIMEOUT_MS,
        val maxQueryChars: Int = DEFAULT_MAX_QUERY_CHARS,
        val maxSingleRunMillis: Long = DEFAULT_MAX_SINGLE_RUN_MILLIS,
        val enableResearchDepthGuard: Boolean = false,
        val minInteractiveRunMillis: Long = 0L,
        val minPositiveEvidenceHandlesForReport: Int = DEFAULT_MIN_POSITIVE_EVIDENCE_HANDLES_FOR_REPORT,
        val depthGuardSleepMs: Long = DEFAULT_DEPTH_GUARD_SLEEP_MS,
        val maxPauseMillis: Long = DEFAULT_MAX_PAUSE_MILLIS
    )

    fun interactive(): Policy = Policy(
        interactive = true,
        maxProofWaitTicks = 0,
        enableBoundedProofProbe = true,
        enableResearchDepthGuard = true,
        minInteractiveRunMillis = DEFAULT_MIN_INTERACTIVE_RUN_MILLIS,
        minPositiveEvidenceHandlesForReport = DEFAULT_MIN_POSITIVE_EVIDENCE_HANDLES_FOR_REPORT,
        maxSingleRunMillis = DEFAULT_MAX_SINGLE_RUN_MILLIS
    )

    fun unitTestNoFastFinish(): Policy = Policy(
        interactive = false,
        localTaskSleepMs = 1L,
        proofWaitSleepMs = 1L,
        maxProofWaitTicks = DEFAULT_UNIT_TEST_WAIT_TICKS,
        allowUnitTestProofSimulation = false,
        enableBoundedProofProbe = false
    )

    fun unitTestWithClosedProof(): Policy = Policy(
        interactive = false,
        localTaskSleepMs = 1L,
        proofWaitSleepMs = 1L,
        maxProofWaitTicks = 0,
        allowUnitTestProofSimulation = true,
        enableBoundedProofProbe = false
    )
}
