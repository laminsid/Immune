package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

private const val PROFESSIONAL_DISCOVERY_BOUNDARY_V30329: String = "Professional discovery card is a research-only dossier surface. It may rank falsifiable discovery candidates, but it never claims clinical proof, diagnosis, treatment, dosing, patient advice, or guaranteed biological causality."

data class AntiOverfittingCheckV30329(
    val state: String,
    val seededAccessions: List<String>,
    val unseededAccessions: List<String>,
    val generalizationWarning: String,
    val passed: Boolean
) {
    fun toJson(): JSONObject = JSONObject()
        .put("state", state)
        .put("seededAccessions", JSONArray(seededAccessions))
        .put("unseededAccessions", JSONArray(unseededAccessions))
        .put("generalizationWarning", generalizationWarning)
        .put("passed", passed)
}

data class ProfessionalHypothesisCardV30329(
    val hypothesisId: String,
    val state: String,
    val evidenceChain: List<String>,
    val computedSignal: JSONObject,
    val noveltyScore: Int,
    val falsifierState: String,
    val nextExperiment: String,
    val scoreCap: Int,
    val scoreCapReason: String,
    val claimBoundary: String = PROFESSIONAL_DISCOVERY_BOUNDARY_V30329
) {
    fun toJson(): JSONObject = JSONObject()
        .put("hypothesisId", hypothesisId)
        .put("state", state)
        .put("evidenceChain", JSONArray(evidenceChain))
        .put("computedSignal", computedSignal)
        .put("noveltyScore", noveltyScore)
        .put("falsifierState", falsifierState)
        .put("nextExperiment", nextExperiment)
        .put("scoreCap", scoreCap)
        .put("scoreCapReason", scoreCapReason)
        .put("claimBoundary", claimBoundary)
}

data class ProfessionalDiscoveryReportV30329(
    val active: Boolean,
    val state: String,
    val cards: List<ProfessionalHypothesisCardV30329>,
    val antiOverfitting: AntiOverfittingCheckV30329,
    val doneCriteria: List<String>,
    val nextAction: String,
    val boundary: String = PROFESSIONAL_DISCOVERY_BOUNDARY_V30329
) {
    fun toJson(): JSONObject = JSONObject()
        .put("schema", "professional_discovery_report_v30329")
        .put("requiredToken", ProfessionalDiscoveryCardBuilderV30329.REQUIRED_TOKEN)
        .put("active", active)
        .put("state", state)
        .put("cards", JSONArray(cards.map { it.toJson() }))
        .put("antiOverfitting", antiOverfitting.toJson())
        .put("doneCriteria", JSONArray(doneCriteria))
        .put("nextAction", nextAction)
        .put("boundary", boundary)
}

object ProfessionalDiscoveryCardBuilderV30329 {
    const val REQUIRED_TOKEN: String = "V30329_PROFESSIONAL_DISCOVERY_HYPOTHESIS_CARD_COMPLETE_EVIDENCE_CHAIN"

    fun evaluate(
        state: ResearchStateV3,
        closure: ResearchClosureSnapshotV3,
        comparatorVariables: ComparatorVariableExtractionReportV30329,
        expressionSignal: ProcessedExpressionSignalReportV30329,
        gapNovelty: DiscoveryGapNoveltyReportV30329,
        falsifier: ExecutedFalsifierReportV30329,
        crossDataset: CrossDatasetSignalReportV30329
    ): ProfessionalDiscoveryReportV30329 {
        val evidenceChain = evidenceChain(state)
        val certifiedFuelGate = CertifiedMatrixFuelGateV30332.evaluate(expressionSignal)
        val scoreCap = scoreCapFor(expressionSignal, falsifier, closure)
        val topEstimate = expressionSignal.estimates.maxByOrNull { kotlin.math.abs(it.effectSize) }
        val matrixReality = expressionSignal.matrixFuel?.realityAssessment()
        val curatedPriorSeed = expressionSignal.rawMatrixDgeExecuted && expressionSignal.matrixFuel?.fuelOrigin == CuratedLightMatrixFuelPackV30335.FUEL_ORIGIN
        val computedSignal = JSONObject()
            .put("dataset", expressionSignal.dataset)
            .put("state", expressionSignal.state)
            .put("rawMatrixDgeExecuted", expressionSignal.rawMatrixDgeExecuted)
            .put("module", topEstimate?.module ?: "none")
            .put("effectSize", topEstimate?.effectSize ?: 0.0)
            .put("confidenceInterval", topEstimate?.confidenceInterval ?: "not_available")
            .put("pValue", topEstimate?.pValueLabel ?: "not_available")
            .put("supportState", topEstimate?.supportState ?: "none")
            .put("matrixCertification", certifiedFuelGate.state)
            .put("certifiedForDiscovery", certifiedFuelGate.certifiedForDiscovery)
            .put("analysisMode", matrixReality?.analysisMode ?: "NO_MATRIX_PREVIEW")
            .put("scientificInterpretability", matrixReality?.scientificInterpretability ?: "NONE_PIPELINE_ONLY")
            .put("effectDisplayPolicy", topEstimate?.effectDisplayPolicy ?: matrixReality?.effectDisplayPolicy ?: "PIPELINE_SANITY_VALUE_HIDE_FROM_MAIN_CLAIM")
            .put("statisticalCoherenceState", topEstimate?.statisticalCoherenceState ?: "not_evaluated")
            .put("effectPlausibilityState", topEstimate?.effectPlausibilityState ?: "not_evaluated")
            .put("curatedPriorHypothesisDiscoverySeed", curatedPriorSeed)
        val cardState = when {
            closure.canCloseReport && certifiedFuelGate.certifiedForDiscovery && expressionSignal.rawMatrixDgeExecuted && gapNovelty.novelty.noveltyScore >= 70 && falsifier.survived -> "REPORT_READY_DISCOVERY_CANDIDATE"
            curatedPriorSeed -> "CURATED_PRIOR_HYPOTHESIS_DISCOVERY_SEED_NOT_CERTIFIED"
            expressionSignal.rawMatrixDgeExecuted && !certifiedFuelGate.certifiedForDiscovery -> "RAW_DGE_REVIEW_SIGNAL_NOT_DISCOVERY_CERTIFIED"
            expressionSignal.hasMechanismSupport && falsifier.survived -> "CONDITIONAL_DISCOVERY_LEAD_REVIEW_ONLY"
            gapNovelty.state == "DOCUMENTED_RESEARCH_GAP_READY" -> "DOCUMENTED_GAP_HYPOTHESIS"
            else -> "EVIDENCE_TRIAGE_WITH_DISCOVERY_GAPS"
        }
        val nextExperiment = nextExperiment(comparatorVariables, expressionSignal, crossDataset)
        val card = ProfessionalHypothesisCardV30329(
            hypothesisId = state.input.primaryHypothesisId,
            state = cardState,
            evidenceChain = evidenceChain,
            computedSignal = computedSignal,
            noveltyScore = gapNovelty.novelty.noveltyScore,
            falsifierState = falsifier.state,
            nextExperiment = nextExperiment,
            scoreCap = scoreCap.first,
            scoreCapReason = scoreCap.second
        )
        val antiOverfitting = antiOverfitting(state)
        val doneCriteria = listOf(
            "reportReady=${closure.canCloseReport}",
            "computedSignalRawMatrix=${expressionSignal.rawMatrixDgeExecuted}",
            "noveltyHigh=${gapNovelty.novelty.noveltyScore >= 70}",
            "falsifierSurvived=${falsifier.survived}",
            "unseededGeneralization=${antiOverfitting.passed}"
        )
        val stateName = when {
            cardState == "REPORT_READY_DISCOVERY_CANDIDATE" && antiOverfitting.passed -> "PROFESSIONAL_DISCOVERY_ENGINE_THRESHOLD_CROSSED"
            cardState == "REPORT_READY_DISCOVERY_CANDIDATE" -> "DISCOVERY_CANDIDATE_NEEDS_UNSEEDED_GENERALIZATION"
            cardState == "CURATED_PRIOR_HYPOTHESIS_DISCOVERY_SEED_NOT_CERTIFIED" -> "CURATED_PRIOR_DISCOVERY_SEED_READY"
            cardState == "RAW_DGE_REVIEW_SIGNAL_NOT_DISCOVERY_CERTIFIED" -> "RAW_DGE_REVIEW_SIGNAL_READY_CERTIFICATION_MISSING"
            cardState == "CONDITIONAL_DISCOVERY_LEAD_REVIEW_ONLY" -> "PROFESSIONAL_DISCOVERY_LEAD_READY_REVIEW_ONLY"
            cardState == "DOCUMENTED_GAP_HYPOTHESIS" -> "RESEARCH_GAP_OUTPUT_READY"
            else -> "DISCOVERY_UPGRADE_STILL_INCOMPLETE"
        }
        val next = when (stateName) {
            "PROFESSIONAL_DISCOVERY_ENGINE_THRESHOLD_CROSSED" -> "Export the card as a falsifiable discovery dossier and replicate on an independent unseeded dataset."
            "DISCOVERY_CANDIDATE_NEEDS_UNSEEDED_GENERALIZATION" -> "Run a fresh non-seeded topic/dataset, such as RA synovium or lupus nephritis, before claiming general discovery capability."
            "CURATED_PRIOR_DISCOVERY_SEED_READY" -> "Use this as a generated hypothesis seed: run a verified ETL/user-attested matrix and an independent replication/falsifier before mechanism support, score >=8, or certified discovery."
            "RAW_DGE_REVIEW_SIGNAL_READY_CERTIFICATION_MISSING" -> "The DGE path ran on non-certified review/scaffold fuel; replace with real GEO ETL or user-supplied rows carrying provenance before treating effect size as biology."
            "PROFESSIONAL_DISCOVERY_LEAD_READY_REVIEW_ONLY" -> "Attach or fetch raw matrix rows to replace preview signal with valid effect size/CI/p-value."
            "RESEARCH_GAP_OUTPUT_READY" -> "Sell/use this as a high-quality research-gap dossier, not a discovery proof."
            else -> "Close comparator → matrix → mechanism signal → falsifier in that order; do not inflate score by wording."
        }
        return ProfessionalDiscoveryReportV30329(
            active = true,
            state = stateName,
            cards = listOf(card),
            antiOverfitting = antiOverfitting,
            doneCriteria = doneCriteria,
            nextAction = next
        )
    }

    private fun evidenceChain(state: ResearchStateV3): List<String> = state.ledgerSnapshot.visibleEvidence
        .filter { it.countsAsSupport || it.role in setOf(EvidenceRoleV3.CONTRADICTION, EvidenceRoleV3.FALSIFIER) }
        .map { node ->
            listOfNotNull(
                node.accession?.takeIf { it.isNotBlank() },
                node.role.name,
                node.qualityTier.name,
                node.title?.take(80)
            ).joinToString(" | ")
        }
        .distinct()
        .take(10)

    private fun scoreCapFor(
        expressionSignal: ProcessedExpressionSignalReportV30329,
        falsifier: ExecutedFalsifierReportV30329,
        closure: ResearchClosureSnapshotV3
    ): Pair<Int, String> = when {
        expressionSignal.matrixFuel?.fuelOrigin == CuratedLightMatrixFuelPackV30335.FUEL_ORIGIN -> 7 to "score_cap:curated_prior_can_generate_hypothesis_discovery_seed_but_not_score_8_or_mechanism_support"
        !expressionSignal.hasMechanismSupport -> 7 to "score_cap:mechanism_support_required_for_8_or_higher"
        !falsifier.survived -> 8 to "score_cap:falsifier_must_survive_for_9_or_higher"
        !expressionSignal.rawMatrixDgeExecuted -> 8 to "score_cap:raw_matrix_effect_required_for_9_or_higher"
        !closure.canCloseReport -> 8 to "score_cap:closure_open_gates"
        else -> 10 to "score_cap:professional_discovery_route_complete"
    }

    private fun nextExperiment(
        comparatorVariables: ComparatorVariableExtractionReportV30329,
        expressionSignal: ProcessedExpressionSignalReportV30329,
        crossDataset: CrossDatasetSignalReportV30329
    ): String {
        val gate = CertifiedMatrixFuelGateV30332.evaluate(expressionSignal)
        val activeAccession = comparatorVariables.bestAccession.takeIf { it != "none" } ?: expressionSignal.dataset.takeIf { it != "none" } ?: "active dataset"
        return when {
            comparatorVariables.readiness < 60 -> "SOFT metadata experiment: manually/automatically label case/control, subtype, tissue/cell source, and timepoint for $activeAccession."
            !expressionSignal.rawMatrixDgeExecuted -> "Matrix experiment: attach processed expression rows for ${expressionSignal.dataset}, group by $activeAccession, and compute module effect size + CI + p-value."
            !gate.certifiedForDiscovery && gate.certificationLevel == CuratedLightMatrixFuelPackV30335.CERTIFICATION_LEVEL -> "Verification experiment: curated prior generated a hypothesis seed for ${expressionSignal.dataset}; run verified ETL or user-attested matrix plus independent replication/falsifier before any score >=8 upgrade."
            !gate.certifiedForDiscovery && gate.certificationLevel == "USER_ATTESTED_WITH_DECLARED_SOURCE" -> "Replication/certification experiment: user-attested rows for ${expressionSignal.dataset} are research-only; add independent replication or ETL-verified rows before any discovery upgrade."
            !gate.certifiedForDiscovery -> "Certification experiment: replace lite/review rows for ${expressionSignal.dataset} with ETL-derived rows or a user-attested matrix plus independent replication before any discovery upgrade."
            crossDataset.sharedSignals.isNotEmpty() -> "Replication experiment: test ${crossDataset.sharedSignals.first().signal} on ${crossDataset.sharedSignals.first().accessions.joinToString(" vs ")}."
            else -> "Independent validation experiment: find a second phenotype-compatible dataset and run same comparator/module signal."
        }
    }

    private fun antiOverfitting(state: ResearchStateV3): AntiOverfittingCheckV30329 {
        val seededPrefixes = setOf("PEDONC", "COVID", "GSE152522")
        val accessions = state.ledgerSnapshot.visibleEvidence.mapNotNull { it.accession?.uppercase() }.distinct()
        val seeded = accessions.filter { acc -> seededPrefixes.any { acc.contains(it) } }
        val unseeded = accessions.filterNot { it in seeded }
        val passed = unseeded.isNotEmpty() && (seeded.isEmpty() || unseeded.size >= seeded.size)
        val stateName = when {
            passed -> "UNSEEDED_OR_GENERAL_ROUTE_VISIBLE"
            accessions.isEmpty() -> "NO_ACCESSION_TO_TEST_GENERALIZATION"
            else -> "SEEDED_ROUTE_DOMINANCE_WARNING"
        }
        val warning = when (stateName) {
            "UNSEEDED_OR_GENERAL_ROUTE_VISIBLE" -> "At least one non-seeded accession is visible; still replicate before broad generalization."
            "NO_ACCESSION_TO_TEST_GENERALIZATION" -> "No dataset accession exists; anti-overfitting cannot be evaluated."
            else -> "Discovery may be seed/capsule-bound; test a new topic such as RA synovium or lupus nephritis before claiming general discovery."
        }
        return AntiOverfittingCheckV30329(stateName, seeded, unseeded, warning, passed)
    }
}
