package com.immunesignal.app

import org.json.JSONObject

/**
 * Final v3 report-grade layer.
 *
 * Keep ResearchRunStatusV3 stable for legacy tests/exporters. This layer adds the
 * decision-grade the user actually needs: a checkpoint can explain the dominant
 * missing gate, while a REPORT_READY result can still be labeled conditional,
 * dataset-supported, or discovery-candidate without pretending it is proof.
 */
enum class ReportReadinessGradeV3 {
    REFINE_REQUIRED,
    CHECKPOINT_EVIDENCE_GAP,
    CHECKPOINT_DATASET_GAP,
    CHECKPOINT_CONTESTED_ROUTE,
    REPORT_READY_CONDITIONAL,
    REPORT_READY_DATASET_SUPPORTED,
    REPORT_READY_PARTIAL_ROUTE,
    EXPERIMENTAL_HYPOTHESIS_READY_NOT_VALIDATED,
    DISCOVERY_CANDIDATE
}

enum class SupportQualityGradeV3 {
    INSUFFICIENT,
    REVIEW_OR_SOURCE_ONLY,
    REVIEW_SUPPORTED_BUT_DATASET_UNCONFIRMED_AND_CONTESTED,
    DATASET_MATCHED,
    MULTI_ACCESSION_DATASET_SUPPORTED,
    SINGLE_HUMAN_MATRIX_SIGNAL_WITH_LINKED_CONTEXT,
    DISCOVERY_CANDIDATE_READY
}

data class ResearchReadinessAssessmentV3(
    val readinessGrade: ReportReadinessGradeV3,
    val supportQuality: SupportQualityGradeV3,
    val sourceCount: Int,
    val datasetCount: Int,
    val provenanceCount: Int,
    val contradictionCount: Int,
    val independentAccessions: Int,
    val summary: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("readinessGrade", readinessGrade.name)
        .put("supportQuality", supportQuality.name)
        .put("sourceCount", sourceCount)
        .put("datasetCount", datasetCount)
        .put("provenanceCount", provenanceCount)
        .put("contradictionCount", contradictionCount)
        .put("independentAccessions", independentAccessions)
        .put("summary", summary)

    companion object {
        fun evaluate(state: ResearchStateV3, closure: ResearchClosureSnapshotV3): ResearchReadinessAssessmentV3 {
            val minTier = state.input.budget.minimumEvidenceQuality
            val visible = state.ledgerSnapshot.visibleEvidence.filter { it.countsAsSupport && it.qualityTier.isAtLeast(minTier) }
            val sourceCount = visible.count { it.role == EvidenceRoleV3.SOURCE }
            val datasetCount = visible.count { it.role == EvidenceRoleV3.DATASET }
            val provenanceCount = visible.count { it.role == EvidenceRoleV3.PROVENANCE }
            val contradictionCount = visible.count { it.role in setOf(EvidenceRoleV3.CONTRADICTION, EvidenceRoleV3.FALSIFIER) }
            val independent = closure.distinctAccessions.size
            val hasDatasetRoute = datasetCount + provenanceCount > 0
            val overloadedRoute = ResearchPrimaryRouteGuardV3.hasOverloadedTopic(state.input.topic)
            val pediatricExperimentalTopic = PediatricProofAxisSelectorV30341.isPediatricNeuroblastomaTopic(state.input.topic)
            val hasGse85047SignalFuel = state.ledgerSnapshot.visibleEvidence.any { it.accession.orEmpty().equals("GSE85047", ignoreCase = true) } || state.input.topic.contains("GSE85047", ignoreCase = true)
            val hasMultiDatasetRoute = datasetCount >= 2 || (datasetCount >= 1 && provenanceCount >= 1)
            val hasSourceSupport = sourceCount > 0
            val hasContest = contradictionCount > 0 || closure.contradictionEvidenceFound
            val discoveryCandidate = closure.canCloseReport &&
                hasSourceSupport &&
                datasetCount >= 2 &&
                provenanceCount >= 1 &&
                independent >= 3 &&
                closure.contradictionSearchCompleted &&
                !hasContest &&
                closure.openGates.isEmpty() &&
                closure.visibleTierCDCount < closure.visibleTierABCount

            val supportQuality = when {
                pediatricExperimentalTopic && hasGse85047SignalFuel -> SupportQualityGradeV3.SINGLE_HUMAN_MATRIX_SIGNAL_WITH_LINKED_CONTEXT
                discoveryCandidate -> SupportQualityGradeV3.DISCOVERY_CANDIDATE_READY
                !hasSourceSupport && !hasDatasetRoute -> SupportQualityGradeV3.INSUFFICIENT
                hasContest && !hasDatasetRoute -> SupportQualityGradeV3.REVIEW_SUPPORTED_BUT_DATASET_UNCONFIRMED_AND_CONTESTED
                hasMultiDatasetRoute && independent >= 2 -> SupportQualityGradeV3.MULTI_ACCESSION_DATASET_SUPPORTED
                hasDatasetRoute -> SupportQualityGradeV3.DATASET_MATCHED
                else -> SupportQualityGradeV3.REVIEW_OR_SOURCE_ONLY
            }

            val readiness = when {
                pediatricExperimentalTopic && hasGse85047SignalFuel && closure.canCloseReport -> ReportReadinessGradeV3.EXPERIMENTAL_HYPOTHESIS_READY_NOT_VALIDATED
                discoveryCandidate -> ReportReadinessGradeV3.DISCOVERY_CANDIDATE
                !ResearchIntentGateV3.evaluate(state.input.topic).allowed -> ReportReadinessGradeV3.REFINE_REQUIRED
                closure.canCloseReport && overloadedRoute -> ReportReadinessGradeV3.REPORT_READY_PARTIAL_ROUTE
                closure.canCloseReport && closure.noValidFalsifierFoundAfterSearch -> ReportReadinessGradeV3.REPORT_READY_CONDITIONAL
                closure.canCloseReport && supportQuality in setOf(SupportQualityGradeV3.DATASET_MATCHED, SupportQualityGradeV3.MULTI_ACCESSION_DATASET_SUPPORTED) -> ReportReadinessGradeV3.REPORT_READY_DATASET_SUPPORTED
                closure.canCloseReport -> ReportReadinessGradeV3.REPORT_READY_CONDITIONAL
                closure.openGates.any { it.contains("dataset", ignoreCase = true) || it.contains("provenance", ignoreCase = true) } -> ReportReadinessGradeV3.CHECKPOINT_DATASET_GAP
                hasContest -> ReportReadinessGradeV3.CHECKPOINT_CONTESTED_ROUTE
                else -> ReportReadinessGradeV3.CHECKPOINT_EVIDENCE_GAP
            }

            val summary = when (readiness) {
                ReportReadinessGradeV3.REFINE_REQUIRED -> "Topic is too broad or missing a mechanism axis; refine before network research."
                ReportReadinessGradeV3.CHECKPOINT_EVIDENCE_GAP -> "Checkpoint: visible research support is still insufficient for report-ready closure."
                ReportReadinessGradeV3.CHECKPOINT_DATASET_GAP -> "Checkpoint: source evidence exists, but a phenotype-matched dataset/provenance route is still missing."
                ReportReadinessGradeV3.CHECKPOINT_CONTESTED_ROUTE -> "Checkpoint: contesting evidence is visible; split or falsify the route before upgrading."
                ReportReadinessGradeV3.REPORT_READY_CONDITIONAL -> "Report-ready conditional: evidence gates are closed and contradiction search was handled, but this remains route stability, not proof."
                ReportReadinessGradeV3.REPORT_READY_DATASET_SUPPORTED -> "Report-ready dataset-supported: source plus phenotype-matched dataset/provenance evidence are visible."
                ReportReadinessGradeV3.REPORT_READY_PARTIAL_ROUTE -> "Report-ready partial route: primary route is closed, but secondary axes remain unclosed: " + ResearchPrimaryRouteGuardV3.secondaryRouteLabels(state.input.topic).joinToString(", ").ifBlank { "none" }
                ReportReadinessGradeV3.EXPERIMENTAL_HYPOTHESIS_READY_NOT_VALIDATED -> "Experimental hypothesis-ready: GSE85047 can generate a strong underpowered 6v6 research signal, but this is not report-ready proof, not discovery-certified, and requires full GSE85047 plus human replication rows."
                ReportReadinessGradeV3.DISCOVERY_CANDIDATE -> "Discovery-candidate ready: multi-accession dataset route, provenance, source support, and completed falsifier search are visible; still research-only."
            }

            return ResearchReadinessAssessmentV3(
                readinessGrade = readiness,
                supportQuality = supportQuality,
                sourceCount = sourceCount,
                datasetCount = datasetCount,
                provenanceCount = provenanceCount,
                contradictionCount = contradictionCount,
                independentAccessions = independent,
                summary = summary
            )
        }
    }
}
