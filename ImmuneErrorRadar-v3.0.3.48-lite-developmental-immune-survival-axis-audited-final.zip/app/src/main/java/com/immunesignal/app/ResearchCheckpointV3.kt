package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

data class ResearchObjectiveTraceV3(
    val objectiveId: String,
    val objectiveKind: String,
    val status: String,
    val queriesAttempted: List<String>,
    val evidenceIds: List<String>,
    val exhausted: Boolean,
    val notes: List<String>
) {
    fun toJson(): JSONObject = JSONObject()
        .put("objectiveId", objectiveId)
        .put("objectiveKind", objectiveKind)
        .put("status", status)
        .put("queriesAttempted", JSONArray(queriesAttempted))
        .put("evidenceIds", JSONArray(evidenceIds))
        .put("exhausted", exhausted)
        .put("notes", JSONArray(notes))
}

data class ResearchCheckpointV3(
    val topic: String,
    val status: ResearchRunStatusV3,
    val reason: String,
    val executedObjectiveCount: Int,
    val objectiveTraces: List<ResearchObjectiveTraceV3>,
    val openGates: List<String>,
    val openGapDiagnostics: List<ResearchGapV3>,
    val budgetUsage: BudgetUsageV3,
    val contradictionState: ResearchContradictionClosureStateV3? = null,
    val contradictionTruth: ContradictionTruthStateV30328? = null,
    val researchOnlyBoundary: String = RESEARCH_ONLY_BOUNDARY
) {
    fun contradictionTrace(): ResearchObjectiveTraceV3? =
        objectiveTraces.firstOrNull { it.objectiveKind == "FindContradiction" }

    fun hasExecutedContradictionQuery(): Boolean =
        contradictionTrace()?.queriesAttempted?.isNotEmpty() == true

    fun toJson(): JSONObject {
        val contradiction = contradictionTrace()
        val contradictionExhausted = contradictionTruth?.exhausted ?: contradictionState?.exhausted ?: (contradiction?.exhausted == true)
        val contradictionFound = contradictionTruth?.found ?: contradictionState?.found ?: (contradiction?.evidenceIds?.isNotEmpty() == true)
        val contradictionAttempted = contradictionTruth?.attempted ?: contradictionState?.attempted ?: (contradiction != null)
        val aggregatedQueries = objectiveTraces.flatMap { it.queriesAttempted }.distinct()
        return JSONObject()
            .put("topic", topic)
            .put("status", status.name)
            .put("reason", reason)
            .put("executedObjectiveCount", executedObjectiveCount)
            .put("objectiveTraces", JSONArray(objectiveTraces.map { it.toJson() }))
            .put("openGates", JSONArray(openGates))
            .put("openGapDiagnostics", ResearchGapDetectorV3.toJson(openGapDiagnostics))
            .put("budgetUsage", budgetUsage.toJson())
            .put("researchOnlyBoundary", researchOnlyBoundary)
            // v3.0.3.3: flat compatibility fields for ActivityBridge/export tests.
            // The full audit trail remains in objectiveTraces; these fields prevent
            // UI consumers from treating a missing key as an unexecuted objective.
            .put("contradictionObjectiveExecuted", contradictionAttempted)
            .put("contradictionObjectiveExhausted", contradictionExhausted)
            .put("contradictionEvidenceFound", contradictionFound)
            .put("contradictionSearchCompleted", contradictionState?.searchCompleted ?: (contradictionAttempted && (contradictionFound || contradictionExhausted)))
            .put("noValidFalsifierFoundAfterSearch", contradictionState?.noValidFalsifierFoundAfterSearch ?: (contradictionAttempted && contradictionExhausted && !contradictionFound))
            .put("contradictionStatus", contradictionTruth?.status ?: contradictionState?.status ?: "FALSIFIER_TRACE_DERIVED")
            .put("contradictionTruth", contradictionTruth?.toJson() ?: JSONObject())
            .put("contradictionQueriesAttempted", JSONArray(contradiction?.queriesAttempted ?: emptyList<String>()))
            .put("queriesAttempted", JSONArray(aggregatedQueries))
    }

    companion object {
        const val RESEARCH_ONLY_BOUNDARY: String =
            "Research-only checkpoint: executed checks are shown separately from missing evidence; no clinical advice or validated medical conclusion is implied."
    }
}

object ResearchCheckpointCompilerV3 {
    fun compile(state: ResearchStateV3, closure: ResearchClosureSnapshotV3): ResearchCheckpointV3 {
        val gaps = ResearchGapDetectorV3.detect(state)
        val reason = closure.openGates.firstOrNull() ?: when {
            !state.input.budget.hasCapacity(state.budgetUsage, state.executedObjectiveCount) -> "budget_exhausted_without_open_gate_detail"
            else -> "planner_exhausted_without_report_ready"
        }
        return ResearchCheckpointV3(
            topic = state.input.topic,
            status = if (closure.canCloseReport) ResearchRunStatusV3.REPORT_READY else ResearchRunStatusV3.CHECKPOINT_READY,
            reason = reason,
            executedObjectiveCount = state.executedObjectiveCount,
            objectiveTraces = state.ledgerSnapshot.objectiveOutcomes.map { outcome ->
                ResearchObjectiveTraceV3(
                    objectiveId = outcome.objective.id,
                    objectiveKind = outcome.objective.kind,
                    status = when {
                        outcome.objective is ResearchObjectiveV3.RankHypotheses -> "internal_rank_reducer"
                        outcome.objective is ResearchObjectiveV3.CompileReport -> "internal_compile_reducer"
                        outcome.exhausted -> "executed_exhausted"
                        else -> "executed_with_evidence"
                    },
                    queriesAttempted = outcome.queriesAttempted,
                    evidenceIds = outcome.nodes.map { it.id },
                    exhausted = outcome.exhausted,
                    notes = outcome.notes
                )
            },
            openGates = closure.openGates,
            openGapDiagnostics = gaps,
            budgetUsage = state.budgetUsage,
            contradictionState = ResearchContradictionClosureV3.evaluate(state.ledgerSnapshot, state.input.budget.minimumEvidenceQuality),
            contradictionTruth = ContradictionTruthStateBuilderV30328.evaluate(state)
        )
    }
}
