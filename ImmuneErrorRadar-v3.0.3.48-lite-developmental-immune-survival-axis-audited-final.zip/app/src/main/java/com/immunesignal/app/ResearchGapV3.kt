package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

enum class ResearchGapSeverityV3 {
    BLOCKER,
    STRONG,
    MEDIUM,
    INFO
}

data class ResearchGapV3(
    val id: String,
    val gateName: String,
    val severity: ResearchGapSeverityV3,
    val rationale: String,
    val nextObjectiveKind: String,
    val requiredRole: EvidenceRoleV3? = null
) {
    fun toSummaryLine(): String = "$id:$severity -> $nextObjectiveKind ($gateName)"

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("gateName", gateName)
        .put("severity", severity.name)
        .put("rationale", rationale)
        .put("nextObjectiveKind", nextObjectiveKind)
        .put("requiredRole", requiredRole?.name ?: "")
}

// legacy audit token retained as a non-functional compatibility marker only:
// GAP_VISIBLE_CONTRADICTION was retired in v3.0.3.20 because closure now accepts
// an executed-and-exhausted contradiction search with no valid falsifier found.
// Active gates: GAP_CONTRADICTION_ATTEMPT, GAP_CONTRADICTION_SEARCH_INCOMPLETE,
// INFO_NO_VALID_FALSIFIER_FOUND.

object ResearchGapDetectorV3 {
    const val REQUIRED_TOKEN: String = "V3_GAP_DETECTOR_OBJECTIVE_SPAWN_NOT_FIXED_TASK_LIST"

    fun detect(state: ResearchStateV3): List<ResearchGapV3> {
        val snapshot = state.ledgerSnapshot
        val minTier = state.input.budget.minimumEvidenceQuality
        val gaps = mutableListOf<ResearchGapV3>()
        val hasSource = snapshot.hasSatisfyingRole(EvidenceRoleV3.SOURCE, minTier)
        val hasDataset = snapshot.hasSatisfyingRole(EvidenceRoleV3.DATASET, minTier)
        val hasProvenance = snapshot.hasSatisfyingRole(EvidenceRoleV3.PROVENANCE, minTier)
        val contradictionState = ResearchContradictionClosureV3.evaluate(snapshot, minTier)
        val contradictionAttempted = contradictionState.attempted
        val contradictionFound = contradictionState.found
        val distinct = snapshot.distinctAccessions()
        val visible = snapshot.visibleEvidence
        val tierAB = visible.count { it.qualityTier.isAtLeast(QualityTierV3.B) }
        val tierCD = visible.size - tierAB

        if (!hasSource) {
            gaps += ResearchGapV3(
                id = "GAP_SOURCE_EVIDENCE",
                gateName = "visible_source_evidence",
                severity = ResearchGapSeverityV3.BLOCKER,
                rationale = "No visible Tier ${minTier.name}-or-better source evidence is attached to the ledger.",
                nextObjectiveKind = "FindSourceEvidence",
                requiredRole = EvidenceRoleV3.SOURCE
            )
        }
        if (!hasDataset && !hasProvenance) {
            gaps += ResearchGapV3(
                id = "GAP_DATASET_OR_PROVENANCE",
                gateName = "visible_dataset_or_provenance_evidence",
                severity = ResearchGapSeverityV3.BLOCKER,
                rationale = "The ledger has no dataset/provenance node strong enough to support research closure.",
                nextObjectiveKind = "FindDatasetEvidence",
                requiredRole = EvidenceRoleV3.DATASET
            )
        } else if (hasDataset && !hasProvenance) {
            gaps += ResearchGapV3(
                id = "GAP_PROVENANCE_DETAIL",
                gateName = "visible_provenance_detail",
                severity = ResearchGapSeverityV3.STRONG,
                rationale = "Dataset evidence exists but sample/comparator provenance has not been established as a separate node.",
                nextObjectiveKind = "FindProvenance",
                requiredRole = EvidenceRoleV3.PROVENANCE
            )
        }
        if (state.input.budget.requireContradictionAttempt && !contradictionAttempted) {
            gaps += ResearchGapV3(
                id = "GAP_CONTRADICTION_ATTEMPT",
                gateName = "contradiction_objective_not_executed",
                severity = ResearchGapSeverityV3.BLOCKER,
                rationale = "The engine must execute a contradiction/falsifier objective before it can close.",
                nextObjectiveKind = "FindContradiction",
                requiredRole = EvidenceRoleV3.CONTRADICTION
            )
        } else if (!contradictionFound && !contradictionState.exhausted) {
            gaps += ResearchGapV3(
                id = "GAP_CONTRADICTION_SEARCH_INCOMPLETE",
                gateName = "contradiction_search_not_exhausted",
                severity = ResearchGapSeverityV3.BLOCKER,
                rationale = "A contradiction objective started, but the ledger does not show a valid falsifier or an exhausted search.",
                nextObjectiveKind = "FindContradiction",
                requiredRole = EvidenceRoleV3.CONTRADICTION
            )
        } else if (contradictionState.noValidFalsifierFoundAfterSearch) {
            gaps += ResearchGapV3(
                id = "INFO_NO_VALID_FALSIFIER_FOUND",
                gateName = "no_valid_falsifier_found_after_exhausted_search",
                severity = ResearchGapSeverityV3.INFO,
                rationale = "Contradiction/falsifier search was executed and exhausted; no valid Tier ${minTier.name}-or-better falsifier was found. This is a documented negative search result, not proof.",
                nextObjectiveKind = "DocumentNegativeContradictionResult",
                requiredRole = EvidenceRoleV3.CONTRADICTION
            )
        }
        if (distinct.size < state.input.budget.minimumIndependentAccessions) {
            gaps += ResearchGapV3(
                id = "GAP_INDEPENDENT_ACCESSIONS",
                gateName = "minimum_independent_accessions",
                severity = ResearchGapSeverityV3.STRONG,
                rationale = "Visible evidence is not independently diversified enough: ${distinct.size}/${state.input.budget.minimumIndependentAccessions} accessions.",
                nextObjectiveKind = "FindDatasetEvidence",
                requiredRole = EvidenceRoleV3.DATASET
            )
        }
        if (!snapshot.hasCriticalRoleIndependence()) {
            gaps += ResearchGapV3(
                id = "GAP_CRITICAL_ROLE_INDEPENDENCE",
                gateName = "critical_role_independence_violation",
                severity = ResearchGapSeverityV3.BLOCKER,
                rationale = "A single accession is being reused across critical roles; source/provenance/contradiction evidence must stay independently reviewable.",
                nextObjectiveKind = "FindContradiction",
                requiredRole = EvidenceRoleV3.CONTRADICTION
            )
        }
        if (!snapshot.objectiveExecuted("rank:")) {
            gaps += ResearchGapV3(
                id = "GAP_HYPOTHESIS_RANKING",
                gateName = "hypothesis_ranking_not_executed",
                severity = ResearchGapSeverityV3.MEDIUM,
                rationale = "Evidence exists, but hypotheses have not been ranked under the current ledger state.",
                nextObjectiveKind = "RankHypotheses",
                requiredRole = EvidenceRoleV3.HYPOTHESIS_RANKING
            )
        } else if (!snapshot.objectiveExecuted("hypothesis_proof:")) {
            gaps += ResearchGapV3(
                id = "GAP_HYPOTHESIS_PROOF_CONTINUATION",
                gateName = "hypothesis_proof_continuation_not_executed",
                severity = ResearchGapSeverityV3.MEDIUM,
                rationale = "A generated hypothesis must trigger targeted comparator/expression/mechanism proof acquisition before final compilation.",
                nextObjectiveKind = "ContinueHypothesisProof",
                requiredRole = EvidenceRoleV3.MECHANISM
            )
        }
        if (tierAB == 0) {
            gaps += ResearchGapV3(
                id = "GAP_NO_TIER_AB",
                gateName = "no_visible_tier_a_or_b_research_evidence",
                severity = ResearchGapSeverityV3.BLOCKER,
                rationale = "Only weak/context evidence is visible; report closure would overstate the run.",
                nextObjectiveKind = "FindSourceEvidence",
                requiredRole = EvidenceRoleV3.SOURCE
            )
        }
        if (tierCD > tierAB) {
            gaps += ResearchGapV3(
                id = "GAP_WEAK_EVIDENCE_MAJORITY",
                gateName = "tier_c_d_majority_blocks_report_ready",
                severity = ResearchGapSeverityV3.STRONG,
                rationale = "Tier C/D evidence outnumbers Tier A/B evidence; the report must stay in checkpoint mode.",
                nextObjectiveKind = "FindDatasetEvidence",
                requiredRole = EvidenceRoleV3.DATASET
            )
        }
        return gaps.distinctBy { it.id }
    }

    fun toJson(gaps: List<ResearchGapV3>): JSONArray = JSONArray(gaps.map { it.toJson() })
}
