package com.immunesignal.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * v2.17.1 — network-safe real evidence acquisition parser.
 *
 * v2.16.0/v2.16.1 made evidence visible and reviewable. v2.17.0 added the
 * missing upstream producer: bounded NCBI eSearch + eSummary parsing into
 * reviewable PubMed / GEO handles. v2.17.1 makes that producer mobile-safe:
 * shared evidence pool, rate limiting, retryable 429/503 handling, safe JSON
 * parsing, and a User-Agent that does not depend on legacy engine-version tokens.
 */
object ResearchEvidenceAcquisitionV2170 {
    const val VERSION: String = "2.17.4-role-scoped-deterministic-evidence-acquisition"
    const val LEGACY_VERSION_V2171: String = "2.17.1-network-safe-evidence-pool"
    const val REQUIRED_TOKEN: String = "V2171_NETWORK_SAFE_SHARED_EVIDENCE_POOL_RATE_LIMITED"
    const val FINAL_REQUIRED_TOKEN_V2172: String = "V2172_INDEPENDENT_EVIDENCE_POOL_NO_TRIPLE_COUNT"
    const val FINAL_REQUIRED_TOKEN_V30320_ACQ: String = "V30320_NCBI_BOOLEAN_QUERY_ENCODING_RETMAX_RELEVANCE_HARDENING"
    const val FINAL_REQUIRED_TOKEN_V30320_RUNTIME: String = "V30320_ROLE_SCOPED_ACQUISITION_NO_UNNEEDED_PUBMED_GEO_ABSTRACTS"
    const val LEGACY_REQUIRED_TOKEN_V2170: String = "V2170_REAL_PUBMED_GEO_PARSER_PRODUCES_REVIEWABLE_HANDLES"
    const val CLAIM_BOUNDARY: String = "reviewable source handles are research leads, not proof, diagnosis, treatment, or clinical advice"
    const val USER_AGENT_VERSION: String = "2.17.2"
    const val LEGACY_USER_AGENT_VERSION_V2171: String = "2.17.1"
    // legacy audit token: USER_AGENT_VERSION: String = "2.17.1"
    const val USER_AGENT_TOKEN: String = "ImmuneErrorRadar/2.17.2 evidence-acquisition-v2172"
    const val MIN_REQUEST_GAP_MS: Long = 180L

    private const val MAX_POOL_CACHE_SIZE: Int = 12
    private const val HTTP_RETRY_DELAY_MS: Long = 1_000L
    private var lastRequestAt: Long = 0L
    private val poolLock = Any()
    private val poolCache = linkedMapOf<String, SharedEvidencePool>()

    data class PubMedRecord(
        val pmid: String,
        val title: String,
        val journal: String = "",
        val pubDate: String = "",
        val abstractText: String = ""
    ) {
        fun sourceMarker(): String = "source_handle_closed_pubmed_${pmid}__title_${slug(title)}"
        fun metadataMarker(): String = "metadata_probe_executed_pubmed_${pmid}__title_${slug(title)}"
        fun comparatorMarker(): String = "comparator_probe_executed_pubmed_${pmid}__title_${slug(title)}"
        fun sampleMarker(): String = "sample_probe_executed_pubmed_${pmid}__title_${slug(title)}"
        fun contradictionMarker(): String = "contradiction_checked_pubmed_${pmid}__title_${slug(title)}"
        fun falsificationMarker(): String = "falsification_probe_executed_pubmed_${pmid}__title_${slug(title)}"
        fun mechanismMarker(): String = "mechanism_linkage_probe_executed_pubmed_${pmid}__title_${slug(title)}"
        fun rankingMarker(): String = "hypothesis_ranking_probe_executed_pubmed_${pmid}__title_${slug(title)}"
    }

    data class DatasetRecord(
        val accession: String,
        val title: String,
        val source: String = "NCBI GEO/GDS",
        val summary: String = ""
    ) {
        fun datasetMarker(): String = "dataset_verified_gds_${accession}__title_${slug(title)}"
        fun provenanceMarker(): String = "provenance_closed_gds_${accession}__title_${slug(title)}"
    }

    data class SharedEvidencePool(
        val query: String,
        val pubMedRecords: List<PubMedRecord>,
        val geoRecords: List<DatasetRecord>,
        val errors: List<String> = emptyList()
    ) {
        val isEmpty: Boolean get() = pubMedRecords.isEmpty() && geoRecords.isEmpty()
        fun toGapMarker(taskId: String): String =
            "proof_gap_${taskId.lowercase()}_shared_pool_empty_not_evidence"
    }

    fun sharedEvidencePool(term: String, policy: ResearchExecutionPolicyV2154.Policy): SharedEvidencePool =
        sharedEvidencePool(
            term = term,
            policy = policy,
            fetchPubMed = true,
            fetchGeo = true,
            fetchAbstracts = false
        )

    fun sharedEvidencePool(
        term: String,
        policy: ResearchExecutionPolicyV2154.Policy,
        fetchPubMed: Boolean,
        fetchGeo: Boolean,
        fetchAbstracts: Boolean
    ): SharedEvidencePool {
        val query = normalizeQueryTerm(term, policy)
        val key = listOf(query.lowercase(), "pm=$fetchPubMed", "geo=$fetchGeo", "abs=$fetchAbstracts").joinToString("|")
        synchronized(poolLock) {
            poolCache[key]?.let { return it }
        }

        val errors = mutableListOf<String>()
        val pubMed = if (fetchPubMed) {
            runCatching { pubMedRecords(query, NcbiQueryExecutionGuardV3.pubMedRetMax(), policy, fetchAbstracts) }
                .onFailure { errors += "pubmed_${it.javaClass.simpleName}" }
                .getOrDefault(emptyList())
        } else {
            emptyList()
        }
        val geo = if (fetchGeo) {
            runCatching { geoRecords(query, NcbiQueryExecutionGuardV3.gdsRetMax(), policy) }
                .onFailure { errors += "gds_${it.javaClass.simpleName}" }
                .getOrDefault(emptyList())
        } else {
            emptyList()
        }
        val pool = SharedEvidencePool(query = query, pubMedRecords = pubMed, geoRecords = geo, errors = errors.distinct())

        synchronized(poolLock) {
            poolCache[key] = pool
            while (poolCache.size > MAX_POOL_CACHE_SIZE) {
                val first = poolCache.keys.firstOrNull() ?: break
                poolCache.remove(first)
            }
        }
        return pool
    }

    fun clearSharedEvidencePoolForTests() {
        synchronized(poolLock) { poolCache.clear() }
    }

    fun clearSharedEvidencePoolForRun() {
        synchronized(poolLock) { poolCache.clear() }
    }

    fun pubMedRecords(term: String, retMax: Int, policy: ResearchExecutionPolicyV2154.Policy, fetchAbstracts: Boolean = false): List<PubMedRecord> {
        val ids = ncbiIds("pubmed", term, retMax, policy)
        if (ids.isEmpty()) return emptyList()
        val summaries = pubMedSummary(ids, policy).ifEmpty { ids.map { PubMedRecord(it, "PubMed record $it") } }
        if (!fetchAbstracts) return summaries
        val abstracts = runCatching { pubMedAbstractMap(ids.take(4), policy) }.getOrDefault(emptyMap())
        return summaries.map { record ->
            val abstractText = abstracts[record.pmid].orEmpty()
            if (abstractText.isBlank()) record else record.copy(abstractText = abstractText)
        }
    }

    fun geoRecords(term: String, retMax: Int, policy: ResearchExecutionPolicyV2154.Policy): List<DatasetRecord> {
        val ids = ncbiIds("gds", term, retMax, policy)
        if (ids.isEmpty()) return emptyList()
        val summaries = gdsSummary(ids, policy)
        return if (summaries.isNotEmpty()) summaries else ids.map { DatasetRecord(it, "NCBI GEO/GDS record $it") }
    }

    fun pubMedRecordsFromSummaryJson(jsonText: String, preferredIds: List<String> = emptyList()): List<PubMedRecord> {
        val root = runCatching { JSONObject(jsonText) }.getOrNull()
            ?.optJSONObject("result") ?: return emptyList()
        val ids = mutableListOf<String>()
        val uids = root.optJSONArray("uids")
        if (uids != null) {
            for (i in 0 until uids.length()) {
                val id = uids.optString(i).trim()
                if (id.isNotBlank()) ids += id
            }
        }
        if (ids.isEmpty()) ids += preferredIds.filter { it.isNotBlank() }
        return ids.mapNotNull { id ->
            val item = root.optJSONObject(id) ?: return@mapNotNull PubMedRecord(id, "PubMed record $id")
            val title = item.optString("title", "PubMed record $id").trim().ifBlank { "PubMed record $id" }
            val journal = item.optString("fulljournalname", item.optString("source", "")).trim()
            val pubDate = item.optString("pubdate", item.optString("epubdate", "")).trim()
            PubMedRecord(id, title, journal, pubDate)
        }
    }

    fun gdsRecordsFromSummaryJson(jsonText: String, preferredIds: List<String> = emptyList()): List<DatasetRecord> {
        val root = runCatching { JSONObject(jsonText) }.getOrNull()
            ?.optJSONObject("result") ?: return emptyList()
        val ids = mutableListOf<String>()
        val uids = root.optJSONArray("uids")
        if (uids != null) {
            for (i in 0 until uids.length()) {
                val id = uids.optString(i).trim()
                if (id.isNotBlank()) ids += id
            }
        }
        if (ids.isEmpty()) ids += preferredIds.filter { it.isNotBlank() }
        return ids.mapNotNull { id ->
            val item = root.optJSONObject(id) ?: return@mapNotNull DatasetRecord(id, "NCBI GEO/GDS record $id")
            val accession = item.optString("accession", item.optString("gds", id)).trim().ifBlank { id }
            val summary = item.optString("summary", "").trim()
            val title = item.optString("title", summary.ifBlank { "NCBI GEO/GDS record $accession" }).trim().ifBlank { "NCBI GEO/GDS record $accession" }
            DatasetRecord(accession, title, summary = summary)
        }
    }

    fun parseIdListFromESearchJson(jsonText: String, retMax: Int): List<String> {
        val arr = runCatching { JSONObject(jsonText) }.getOrNull()
            ?.optJSONObject("esearchresult")
            ?.optJSONArray("idlist") ?: return emptyList()
        val out = mutableListOf<String>()
        for (i in 0 until arr.length().coerceAtMost(retMax.coerceAtLeast(1))) {
            val id = arr.optString(i).trim()
            if (id.isNotBlank()) out += id
        }
        return out
    }

    private fun pubMedSummary(ids: List<String>, policy: ResearchExecutionPolicyV2154.Policy): List<PubMedRecord> {
        val joined = ids.take(NcbiQueryExecutionGuardV3.summaryIdLimit()).joinToString(",")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id=$joined"
        return pubMedRecordsFromSummaryJson(httpGet(url, policy), ids)
    }

    private fun pubMedAbstractMap(ids: List<String>, policy: ResearchExecutionPolicyV2154.Policy): Map<String, String> {
        val joined = ids.take(NcbiQueryExecutionGuardV3.summaryIdLimit()).joinToString(",")
        if (joined.isBlank()) return emptyMap()
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id=$joined"
        return parseAbstractsFromPubMedXml(httpGet(url, policy))
    }

    fun parseAbstractsFromPubMedXml(xmlText: String): Map<String, String> {
        if (xmlText.isBlank()) return emptyMap()
        val out = linkedMapOf<String, String>()
        val articleRegex = Regex("<PubmedArticle\\b.*?</PubmedArticle>", RegexOption.DOT_MATCHES_ALL)
        val pmidRegex = Regex("<PMID[^>]*>(\\d+)</PMID>")
        val abstractRegex = Regex("<AbstractText[^>]*>(.*?)</AbstractText>", RegexOption.DOT_MATCHES_ALL)
        for (article in articleRegex.findAll(xmlText).map { it.value }) {
            val pmid = pmidRegex.find(article)?.groupValues?.getOrNull(1).orEmpty()
            if (pmid.isBlank()) continue
            val abstract = abstractRegex.findAll(article)
                .map { cleanXmlText(it.groupValues.getOrNull(1).orEmpty()) }
                .filter { it.isNotBlank() }
                .joinToString(" ")
                .trim()
            if (abstract.isNotBlank()) out[pmid] = abstract
        }
        return out
    }

    private fun gdsSummary(ids: List<String>, policy: ResearchExecutionPolicyV2154.Policy): List<DatasetRecord> {
        val joined = ids.take(NcbiQueryExecutionGuardV3.summaryIdLimit()).joinToString(",")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=gds&retmode=json&id=$joined"
        return gdsRecordsFromSummaryJson(httpGet(url, policy), ids)
    }

    fun buildESearchUrlForTests(db: String, term: String, retMax: Int, policy: ResearchExecutionPolicyV2154.Policy): String =
        NcbiQueryExecutionGuardV3.buildESearchUrl(db, term, retMax, policy)

    fun normalizeQueryForESearchForTests(term: String, policy: ResearchExecutionPolicyV2154.Policy): String =
        NcbiQueryExecutionGuardV3.normalizeForESearch(term, policy)

    private fun ncbiIds(db: String, term: String, retMax: Int, policy: ResearchExecutionPolicyV2154.Policy): List<String> {
        val boundedRetMax = retMax.coerceIn(1, NcbiQueryExecutionGuardV3.MAX_ESEARCH_RETMAX)
        val url = NcbiQueryExecutionGuardV3.buildESearchUrl(db, term, boundedRetMax, policy)
        return parseIdListFromESearchJson(httpGet(url, policy), boundedRetMax)
    }

    private fun httpGet(urlText: String, policy: ResearchExecutionPolicyV2154.Policy): String {
        var lastError: Throwable? = null
        repeat(2) { attempt ->
            try {
                return httpGetOnce(urlText, policy)
            } catch (t: RetryableHttpException) {
                lastError = t
                if (attempt == 0) sleepQuietly(HTTP_RETRY_DELAY_MS)
            }
        }
        throw lastError ?: IllegalStateException("retryable HTTP request failed without error")
    }

    private fun httpGetOnce(urlText: String, policy: ResearchExecutionPolicyV2154.Policy): String {
        waitForNcbiRateLimitSlot()
        val connection = (URL(urlText).openConnection() as HttpURLConnection).apply {
            connectTimeout = policy.networkConnectTimeoutMs.coerceIn(1_000, 8_000)
            readTimeout = policy.networkReadTimeoutMs.coerceIn(1_500, 10_000)
            requestMethod = "GET"
            setRequestProperty("User-Agent", USER_AGENT_TOKEN)
            setRequestProperty("Accept", "application/json")
        }
        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            when (code) {
                in 200..299 -> body
                429, 503 -> throw RetryableHttpException(code, body.take(160))
                else -> throw IllegalStateException("HTTP $code from NCBI: ${body.take(120)}")
            }
        } finally {
            connection.disconnect()
        }
    }

    @Synchronized
    private fun waitForNcbiRateLimitSlot() {
        val now = System.currentTimeMillis()
        val gap = now - lastRequestAt
        if (gap in 0 until MIN_REQUEST_GAP_MS) {
            sleepQuietly(MIN_REQUEST_GAP_MS - gap)
        }
        lastRequestAt = System.currentTimeMillis()
    }

    private fun normalizeQueryTerm(term: String, policy: ResearchExecutionPolicyV2154.Policy): String =
        NcbiQueryExecutionGuardV3.normalizeForESearch(term, policy)

    private fun cleanXmlText(text: String): String = text
        .replace(Regex("<[^>]+>"), " ")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun sleepQuietly(ms: Long) {
        try {
            Thread.sleep(ms.coerceAtLeast(0L))
        } catch (ie: InterruptedException) {
            Thread.currentThread().interrupt()
            throw RetryableHttpException(-1, "interrupted")
        }
    }

    private class RetryableHttpException(val code: Int, detail: String) : RuntimeException("retryable HTTP $code from NCBI: $detail")

    private fun slug(text: String): String = text
        .replace(Regex("[^A-Za-z0-9]+"), "_")
        .trim('_')
        .take(90)
        .ifBlank { "record" }
}
