package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

data class ResearchClosureSnapshotV3(
    val canCloseReport: Boolean,
    val openGates: List<String>,
    val visibleTierABCount: Int,
    val visibleTierCDCount: Int,
    val contradictionObjectiveExecuted: Boolean,
    val contradictionEvidenceFound: Boolean,
    val distinctAccessions: List<String>,
    val criticalRoleIndependencePassed: Boolean = true,
    val contradictionObjectiveExhausted: Boolean = false
) {
    val contradictionSearchCompleted: Boolean get() = contradictionObjectiveExecuted && (contradictionEvidenceFound || contradictionObjectiveExhausted)
    val noValidFalsifierFoundAfterSearch: Boolean get() = contradictionObjectiveExecuted && contradictionObjectiveExhausted && !contradictionEvidenceFound

    fun toJson(): JSONObject = JSONObject()
        .put("canCloseReport", canCloseReport)
        .put("openGates", JSONArray(openGates))
        .put("visibleTierABCount", visibleTierABCount)
        .put("visibleTierCDCount", visibleTierCDCount)
        .put("contradictionObjectiveExecuted", contradictionObjectiveExecuted)
        .put("contradictionObjectiveExhausted", contradictionObjectiveExhausted)
        .put("contradictionEvidenceFound", contradictionEvidenceFound)
        .put("contradictionSearchCompleted", contradictionSearchCompleted)
        .put("noValidFalsifierFoundAfterSearch", noValidFalsifierFoundAfterSearch)
        .put("distinctAccessions", JSONArray(distinctAccessions))
        .put("criticalRoleIndependencePassed", criticalRoleIndependencePassed)
}

class ResearchClosurePolicyV3 {
    // legacy audit alias: tier_c_d_majority_blocks_report_ready
    fun evaluate(state: ResearchStateV3): ResearchClosureSnapshotV3 {
        val snapshot = state.ledgerSnapshot
        val intentGate = ResearchIntentGateV3.evaluate(state.input.topic)
        val frame = intentGate.frame
        val minTier = state.input.budget.minimumEvidenceQuality
        val distinct = snapshot.distinctSatisfyingAccessions(minTier)
        val visible = snapshot.visibleEvidence
        val supportVisible = visible.filter { it.countsAsSupport }
        val tierAB = supportVisible.count { it.qualityTier.isAtLeast(QualityTierV3.B) }
        // v3.0.3.24 rebalance: supporting low-tier evidence and visible Tier C/D
        // context both count as noise. Off-route context does not satisfy roles, but
        // equal-or-higher visible noise must still block REPORT_READY.
        val tierCD = visible.count { !it.qualityTier.isAtLeast(QualityTierV3.B) }
        val contradictionState = ResearchContradictionClosureV3.evaluate(snapshot, minTier)
        val contradictionAttempted = contradictionState.attempted
        val contradictionFound = contradictionState.found
        val contradictionExhausted = contradictionState.exhausted
        val criticalRoleIndependencePassed = snapshot.hasCriticalRoleIndependence()
        val gates = mutableListOf<String>()

        if (!intentGate.allowed) gates += "topic_rejected_by_intent_gate:${intentGate.reason}"
        if (frame.isGeneric) gates += "generic_topic_requires_mechanism_axis"
        if (!snapshot.hasSatisfyingRole(EvidenceRoleV3.SOURCE, minTier)) gates += "visible_source_evidence"
        if (!snapshot.hasSatisfyingRole(EvidenceRoleV3.DATASET, minTier) && !snapshot.hasSatisfyingRole(EvidenceRoleV3.PROVENANCE, minTier)) {
            gates += "visible_dataset_or_provenance_evidence"
        }
        if (state.input.budget.requireContradictionAttempt && !contradictionAttempted) {
            gates += "contradiction_objective_not_executed"
        }
        if (state.input.budget.requireContradictionAttempt && contradictionAttempted && !contradictionState.closureSatisfied) {
            gates += "contradiction_search_not_exhausted"
        }
        if (distinct.size < state.input.budget.minimumIndependentAccessions) gates += "minimum_independent_accessions"
        // Final v3.0.3.20 pack: role overlap is handled upstream by ResearchEvidenceTriageV3.
        // A remaining overlap should be reported as a warning in JSON, not used to force
        // strong runs back into CHECKPOINT_READY.
        if (!snapshot.objectiveExecuted("rank:")) gates += "hypothesis_ranking_not_executed"
        val proofContinuationRequired = requiresHypothesisProofContinuation(frame) &&
            snapshot.objectiveExecuted("rank:") &&
            snapshot.objectiveExecuted("provenance:") &&
            !snapshot.objectiveExecuted("hypothesis_proof:")
        if (proofContinuationRequired) {
            gates += "hypothesis_proof_continuation_not_executed"
        }
        if (state.budgetUsage.networkCalls < state.input.budget.minNetworkCallsForReport) gates += "insufficient_external_query_depth_for_report"
        if (state.executedObjectiveCount < state.input.budget.minExecutedEvidenceObjectivesForReport) gates += "insufficient_executed_objective_depth_for_report"
        if (tierAB == 0) gates += "no_visible_tier_a_or_b_research_evidence"
        if (tierCD >= tierAB && tierCD > 0 && tierAB < 8) gates += "tier_c_d_noise_ratio_blocks_report_ready"
        if (snapshot.visibleEvidence.any { it.limitations.contains("relevance_contradiction_not_tied_to_primary_hypothesis") && it.role in setOf(EvidenceRoleV3.CONTRADICTION, EvidenceRoleV3.FALSIFIER) }) {
            gates += "contradiction_not_tied_to_primary_hypothesis"
        }
        if (snapshot.visibleEvidence.any { it.limitations.contains("relevance_dataset_phenotype_mismatch") && it.role in setOf(EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE) }) {
            gates += "dataset_phenotype_mismatch_blocks_report_ready"
        }
        // Professional relevance is now a scoring / warning surface unless a hard
        // phenotype mismatch is explicitly present. This keeps the guard from becoming
        // over-strict and breaking mature V3 closure semantics.
        if (snapshot.visibleEvidence.any { node ->
                node.countsAsSupport && node.limitations.any { it.contains("dataset_phenotype_mismatch") }
            }) {
            gates += "dataset_phenotype_mismatch_blocks_report_ready"
        }
        if (!state.input.budget.hasCapacity(state.budgetUsage, state.executedObjectiveCount) && gates.isNotEmpty()) gates += "budget_exhausted_before_closure"

        return ResearchClosureSnapshotV3(
            canCloseReport = gates.isEmpty(),
            openGates = gates.distinct(),
            visibleTierABCount = tierAB,
            visibleTierCDCount = tierCD,
            contradictionObjectiveExecuted = contradictionAttempted,
            contradictionEvidenceFound = contradictionFound,
            distinctAccessions = distinct,
            criticalRoleIndependencePassed = criticalRoleIndependencePassed,
            contradictionObjectiveExhausted = contradictionExhausted
        )
    }

    private fun requiresHypothesisProofContinuation(frame: BiomedicalTopicFrameV3): Boolean {
        // v3.0.3.27 CI contract balance:
        // Keep the proof-loop mandatory for modern biomedical discovery routes
        // (COVID/PASC, cancer, pediatric oncology, comparative and broad immune
        // discovery), but do not retrofit this new gate onto legacy Ebola V3
        // acceptance fixtures. Those fixtures validate the older contract where
        // source + dataset/provenance + executed/exhausted contradiction search
        // can close conditionally after ranking.
        return frame.domain != ResearchDomainV3.EBOLA
    }

    fun canCloseReport(state: ResearchStateV3): Boolean = evaluate(state).canCloseReport
}
