package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * Query constructor for comparative topics: left frame, right frame, then bridge.
 * It only builds retrieval lanes; it does not claim proof.
 */
data class ComparativeDualRetrievalPlanV30328(
    val leftQuery: String,
    val rightQuery: String,
    val bridgeQuery: String,
    val suffix: String,
    val frame: StructuredQuestionFrameV30328
) {
    fun queries(): List<String> = listOf(leftQuery, rightQuery, bridgeQuery)
    fun toJson(): JSONObject = JSONObject()
        .put("leftQuery", leftQuery)
        .put("rightQuery", rightQuery)
        .put("bridgeQuery", bridgeQuery)
        .put("suffix", suffix)
        .put("frame", frame.toJson())
}

object ComparativeDualRetrievalExecutorV30328 {
    const val REQUIRED_TOKEN: String = "V30328_COMPARATIVE_DUAL_RETRIEVAL_EXECUTOR"

    fun build(topic: String, suffix: String): ComparativeDualRetrievalPlanV30328 {
        val frame = StructuredQuestionFrameExtractorV30328.extract(topic)
        val left = when (frame.leftDisease) {
            "alzheimer_disease" -> "Alzheimer disease ${frame.leftMechanism} ${frame.leftTissue} neuroinflammation transcriptome"
            else -> "${frame.leftDisease} ${frame.leftMechanism} ${frame.leftTissue} immune transcriptome"
        }
        val right = when (frame.rightDisease) {
            "type2_diabetes_or_metabolic_disease" -> "type 2 diabetes insulin resistance adipose macrophage IL-6 TNF transcriptome"
            "none" -> "phenotype matched immune comparator transcriptome"
            else -> "${frame.rightDisease} ${frame.rightMechanism} ${frame.rightTissue} immune transcriptome"
        }
        val bridge = "${frame.leftDisease} vs ${frame.rightDisease} immune comparison ${frame.sharedAxis} ${frame.comparatorNeeded}"
        return ComparativeDualRetrievalPlanV30328(
            leftQuery = QuerySanitizerV3.noMalformedQuery("$left $suffix"),
            rightQuery = QuerySanitizerV3.noMalformedQuery("$right $suffix"),
            bridgeQuery = QuerySanitizerV3.noMalformedQuery("$bridge $suffix"),
            suffix = suffix,
            frame = frame
        )
    }

    fun queries(topic: String, suffix: String): List<String> = build(topic, suffix).queries().distinct().take(5)
}
