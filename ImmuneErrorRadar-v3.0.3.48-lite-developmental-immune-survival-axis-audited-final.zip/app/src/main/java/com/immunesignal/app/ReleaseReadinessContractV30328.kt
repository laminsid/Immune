package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * Final v3.0.3.28 linkage contract: verifies the new pieces are connected to
 * old V3 routes. It is a report/audit surface, not a closure blocker.
 */
data class ReleaseReadinessContractSnapshotV30328(
    val linkedRoutes: List<String>,
    val warnings: List<String>
) {
    val passed: Boolean get() = warnings.isEmpty()
    fun toJson(): JSONObject = JSONObject()
        .put("passed", passed)
        .put("linkedRoutes", JSONArray(linkedRoutes))
        .put("warnings", JSONArray(warnings))
}

object ReleaseReadinessContractV30328 {
    const val REQUIRED_TOKEN: String = "V30328_RELEASE_READINESS_CONTRACT_ALL_ROUTES_LINKED"

    fun evaluate(
        contradictionTruth: ContradictionTruthStateV30328,
        proofExecution: HypothesisProofExecutionSnapshotV30328,
        mechanismSignal: MechanismModuleSignalSnapshotV30328,
        telemetry: RuntimeBudgetTelemetrySnapshotV30328
    ): ReleaseReadinessContractSnapshotV30328 {
        val routes = listOf(
            "contradiction_truth_state",
            "proof_execution",
            "mechanism_signal_runner",
            "biomedical_relevance_lite",
            "dossier_query_bias",
            "pre_retrieval_blacklist",
            "runtime_budget_telemetry"
        )
        val warnings = mutableListOf<String>()
        if (!proofExecution.active) warnings += "proof_execution_not_linked"
        if (!mechanismSignal.active) warnings += "mechanism_signal_not_linked"
        if (!contradictionTruth.attempted && contradictionTruth.status != "FALSIFIER_SEARCH_PENDING") warnings += "contradiction_truth_state_inconsistent"
        if (telemetry.stoppedBecause.isBlank()) warnings += "runtime_telemetry_missing_stop_reason"
        return ReleaseReadinessContractSnapshotV30328(routes, warnings)
    }
}
