package com.immunesignal.app

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sqrt
import org.json.JSONArray
import org.json.JSONObject

private const val PROCESSED_EXPRESSION_SIGNAL_BOUNDARY_V30329: String = "Signal execution is research-only. Raw matrix DGE is computed only when grouped sample-level expression rows are available and mapped to real case/control labels. Local processed capsules can produce a transparent module-preview statistic, but preview never substitutes for raw sample-level differential expression, mechanism support, discovery readiness, causal proof, diagnosis, treatment, dosing, or patient action."

data class ExpressionSampleRowV30329(
    val sampleId: String,
    val group: String,
    val values: Map<String, Double>
)

data class MatrixComputationResultV30329(
    val marker: String,
    val caseMean: Double,
    val controlMean: Double,
    val effectSize: Double,
    val ciLow: Double,
    val ciHigh: Double,
    val pValue: Double,
    val adjustedPValue: Double,
    val nCase: Int,
    val nControl: Int,
    val degreesOfFreedom: Double,
    val statisticFamily: String = "welch_t_approx"
) {
    fun toJson(): JSONObject = JSONObject()
        .put("marker", marker)
        .put("caseMean", round3(caseMean))
        .put("controlMean", round3(controlMean))
        .put("effectSize", round3(effectSize))
        .put("ciLow", round3(ciLow))
        .put("ciHigh", round3(ciHigh))
        .put("pValue", round4(pValue))
        .put("adjustedPValue", round4(adjustedPValue))
        .put("nCase", nCase)
        .put("nControl", nControl)
        .put("degreesOfFreedom", round3(degreesOfFreedom))
        .put("statisticFamily", statisticFamily)
}

data class ModuleSignalEstimateV30329(
    val accession: String,
    val module: String,
    val markers: List<String>,
    val effectDirection: String,
    val effectSize: Double,
    val confidenceInterval: String,
    val pValueLabel: String,
    val statisticState: String,
    val rawMatrixDgeExecuted: Boolean,
    val computedFrom: String,
    val supportState: String,
    val markerResults: List<MatrixComputationResultV30329> = emptyList(),
    val statisticalCoherenceState: String = "not_evaluated",
    val effectPlausibilityState: String = "not_evaluated",
    val scientificInterpretability: String = "not_evaluated",
    val effectDisplayPolicy: String = "RESEARCH_REVIEW_VALUE_WITH_BOUNDARY",
    // v3.0.3.36 integrity fix: preview triage heuristic is carried in its own field and
    // MUST NOT populate effectSize. effectSize is reserved for raw-matrix DGE output only.
    val previewTriageScore: Double = 0.0
) {
    fun toJson(): JSONObject = JSONObject()
        .put("accession", accession)
        .put("module", module)
        .put("markers", JSONArray(markers))
        .put("effectDirection", effectDirection)
        .put("effectSize", round3(effectSize))
        .put("confidenceInterval", confidenceInterval)
        .put("pValueLabel", pValueLabel)
        .put("statisticState", statisticState)
        .put("rawMatrixDgeExecuted", rawMatrixDgeExecuted)
        .put("computedFrom", computedFrom)
        .put("supportState", supportState)
        .put("statisticalCoherenceState", statisticalCoherenceState)
        .put("effectPlausibilityState", effectPlausibilityState)
        .put("scientificInterpretability", scientificInterpretability)
        .put("effectDisplayPolicy", effectDisplayPolicy)
        .put("previewTriageScore", round3(previewTriageScore))
        .put("markerResults", JSONArray(markerResults.map { it.toJson() }))
}

data class ProcessedExpressionSignalReportV30329(
    val active: Boolean,
    val state: String,
    val dataset: String,
    val moduleCount: Int,
    val rawMatrixDgeExecuted: Boolean,
    val estimates: List<ModuleSignalEstimateV30329>,
    val nextAction: String,
    val boundary: String = PROCESSED_EXPRESSION_SIGNAL_BOUNDARY_V30329,
    val matrixFuel: MatrixFuelSnapshotV30330? = null
) {
    val bestEffectSize: Double get() = estimates.maxOfOrNull { abs(it.effectSize) } ?: 0.0
    val hasMechanismSupport: Boolean get() = estimates.any { it.supportState == "MECHANISM_SIGNAL_SUPPORTED_BY_CERTIFIED_RAW_MATRIX" || it.supportState == "MECHANISM_SIGNAL_SUPPORTED_BY_RAW_MATRIX" }
    val hasPreviewSupport: Boolean get() = estimates.any { it.supportState == "MODULE_PREVIEW_REVIEW_ONLY_NOT_MECHANISM_SUPPORT" }

    fun toJson(): JSONObject = JSONObject()
        .put("schema", "processed_expression_signal_execution_v30331")
        .put("requiredToken", ProcessedExpressionSignalExecutorV30329.REQUIRED_TOKEN)
        .put("matrixFuelToken", MatrixFuelProviderV30330.REQUIRED_TOKEN)
        .put("matrixFuelTokenV30331", MatrixFuelProviderV30331.REQUIRED_TOKEN)
        .put("certifiedMatrixFuelGateTokenV30332", CertifiedMatrixFuelGateV30332.REQUIRED_TOKEN)
        .put("active", active)
        .put("state", state)
        .put("dataset", dataset)
        .put("moduleCount", moduleCount)
        .put("rawMatrixDgeExecuted", rawMatrixDgeExecuted)
        .put("bestEffectSize", round3(bestEffectSize))
        .put("hasMechanismSupport", hasMechanismSupport)
        .put("hasPreviewSupport", hasPreviewSupport)
        .put("certifiedForDiscovery", matrixFuel?.certifiedForDiscovery == true)
        .put("analysisMode", matrixFuel?.analysisMode ?: "NO_MATRIX_PREVIEW")
        .put("scientificInterpretability", matrixFuel?.scientificInterpretability ?: "NONE_PIPELINE_ONLY")
        .put("matrixReality", matrixFuel?.realityAssessment()?.toJson() ?: JSONObject())
        .put("matrixFuel", matrixFuel?.toJson() ?: JSONObject())
        .put("estimates", JSONArray(estimates.map { it.toJson() }))
        .put("nextAction", nextAction)
        .put("boundary", boundary)

    companion object {
        fun inactive(reason: String): ProcessedExpressionSignalReportV30329 = ProcessedExpressionSignalReportV30329(
            active = false,
            state = "PROCESSED_EXPRESSION_SIGNAL_INACTIVE",
            dataset = "none",
            moduleCount = 0,
            rawMatrixDgeExecuted = false,
            estimates = emptyList(),
            nextAction = reason
        )
    }
}

object ProcessedExpressionMatrixCalculatorV30329 {
    const val REQUIRED_TOKEN: String = "V30330_ACTUAL_MATRIX_MODULE_EFFECT_CALCULATOR_WELCH_T_MULTIPLE_TEST_SAFE"
    const val LEGACY_REQUIRED_TOKEN: String = "V30329_ACTUAL_MATRIX_MODULE_EFFECT_CALCULATOR"
    const val V30341_SAMPLE_LEVEL_MODULE_SCORE_TOKEN: String = "V30341_PER_SAMPLE_MODULE_SCORE_WELCH_TEST_NOT_MARKER_MEDIAN_PROXY"

    fun calculate(
        rows: List<ExpressionSampleRowV30329>,
        caseGroup: String,
        controlGroup: String,
        markers: List<String>
    ): List<MatrixComputationResultV30329> = calculate(rows, listOf(caseGroup), listOf(controlGroup), markers)

    fun calculate(
        rows: List<ExpressionSampleRowV30329>,
        caseGroups: List<String>,
        controlGroups: List<String>,
        markers: List<String>
    ): List<MatrixComputationResultV30329> {
        val caseLabels = caseGroups.map { ComparatorGroupResolverV30330.normalizeLabel(it) }.filter { it.isNotBlank() }
        val controlLabels = controlGroups.map { ComparatorGroupResolverV30330.normalizeLabel(it) }.filter { it.isNotBlank() }
        val caseRows = rows.filter { row -> caseLabels.any { label -> row.group == label || row.group.contains(label) || label.contains(row.group) } }
        val controlRows = rows.filter { row -> controlLabels.any { label -> row.group == label || row.group.contains(label) || label.contains(row.group) } }
        if (caseRows.size < 2 || controlRows.size < 2) return emptyList()
        val distinctMarkers = markers.distinct().map { it.uppercase() }
        val rawResults = distinctMarkers.mapNotNull { marker ->
            val caseValues = caseRows.mapNotNull { it.values[marker] ?: it.values[marker.lowercase()] }
            val controlValues = controlRows.mapNotNull { it.values[marker] ?: it.values[marker.lowercase()] }
            if (caseValues.size < 2 || controlValues.size < 2) return@mapNotNull null
            val caseMean = caseValues.average()
            val controlMean = controlValues.average()
            val pooled = pooledSd(caseValues, controlValues).takeIf { it > 0.0 } ?: return@mapNotNull null
            val effect = (caseMean - controlMean) / pooled
            val seEffect = sqrt(1.0 / caseValues.size + 1.0 / controlValues.size)
            val df = welchDf(caseValues, controlValues).coerceAtLeast(1.0)
            val critical = tCritical95(df)
            val ciLow = effect - critical * seEffect
            val ciHigh = effect + critical * seEffect
            val t = abs(effect / seEffect)
            val p = studentTPValue(t, df).coerceIn(0.0, 1.0)
            MatrixComputationResultV30329(
                marker = marker,
                caseMean = caseMean,
                controlMean = controlMean,
                effectSize = effect,
                ciLow = ciLow,
                ciHigh = ciHigh,
                pValue = p,
                adjustedPValue = p,
                nCase = caseValues.size,
                nControl = controlValues.size,
                degreesOfFreedom = df
            )
        }
        val multiplier = rawResults.size.coerceAtLeast(1)
        return rawResults.map { it.copy(adjustedPValue = (it.pValue * multiplier).coerceIn(0.0, 1.0)) }
    }

    fun calculatePerSampleModuleScore(
        rows: List<ExpressionSampleRowV30329>,
        caseGroups: List<String>,
        controlGroups: List<String>,
        markers: List<String>
    ): List<MatrixComputationResultV30329> {
        val caseLabels = caseGroups.map { ComparatorGroupResolverV30330.normalizeLabel(it) }.filter { it.isNotBlank() }
        val controlLabels = controlGroups.map { ComparatorGroupResolverV30330.normalizeLabel(it) }.filter { it.isNotBlank() }
        val distinctMarkers = markers.distinct().map { it.uppercase() }
        if (distinctMarkers.isEmpty()) return emptyList()
        val markerStats = distinctMarkers.mapNotNull { marker ->
            val values = rows.mapNotNull { it.values[marker] ?: it.values[marker.lowercase()] }
            if (values.size < 3) null else {
                val mean = values.average()
                val sd = sqrt(variance(values)).takeIf { it > 0.0 } ?: return@mapNotNull null
                marker to (mean to sd)
            }
        }.toMap()
        if (markerStats.isEmpty()) return emptyList()
        fun rowScore(row: ExpressionSampleRowV30329): Double? {
            val zValues = markerStats.mapNotNull { (marker, stats) ->
                val value = row.values[marker] ?: row.values[marker.lowercase()]
                value?.let { (it - stats.first) / stats.second }
            }
            return if (zValues.size < 2) null else zValues.average()
        }
        val caseValues = rows.filter { row -> caseLabels.any { label -> row.group == label || row.group.contains(label) || label.contains(row.group) } }.mapNotNull { rowScore(it) }
        val controlValues = rows.filter { row -> controlLabels.any { label -> row.group == label || row.group.contains(label) || label.contains(row.group) } }.mapNotNull { rowScore(it) }
        if (caseValues.size < 2 || controlValues.size < 2) return emptyList()
        val caseMean = caseValues.average()
        val controlMean = controlValues.average()
        val pooled = pooledSd(caseValues, controlValues).takeIf { it > 0.0 } ?: return emptyList()
        val effect = (caseMean - controlMean) / pooled
        val seEffect = sqrt(1.0 / caseValues.size + 1.0 / controlValues.size)
        val df = welchDf(caseValues, controlValues).coerceAtLeast(1.0)
        val critical = tCritical95(df)
        val ciLow = effect - critical * seEffect
        val ciHigh = effect + critical * seEffect
        val t = abs(effect / seEffect)
        val p = studentTPValue(t, df).coerceIn(0.0, 1.0)
        return listOf(
            MatrixComputationResultV30329(
                marker = "PER_SAMPLE_MODULE_SCORE",
                caseMean = caseMean,
                controlMean = controlMean,
                effectSize = effect,
                ciLow = ciLow,
                ciHigh = ciHigh,
                pValue = p,
                adjustedPValue = p,
                nCase = caseValues.size,
                nControl = controlValues.size,
                degreesOfFreedom = df,
                statisticFamily = "per_sample_module_score_welch_t"
            )
        )
    }

    private fun pooledSd(a: List<Double>, b: List<Double>): Double {
        val va = variance(a)
        val vb = variance(b)
        return sqrt(((a.size - 1) * va + (b.size - 1) * vb) / (a.size + b.size - 2).coerceAtLeast(1))
    }

    private fun variance(values: List<Double>): Double {
        if (values.size < 2) return 0.0
        val mean = values.average()
        return values.sumOf { (it - mean).pow(2.0) } / (values.size - 1)
    }

    private fun welchDf(a: List<Double>, b: List<Double>): Double {
        val va = variance(a)
        val vb = variance(b)
        val na = a.size.toDouble()
        val nb = b.size.toDouble()
        val top = (va / na + vb / nb).pow(2.0)
        val bottom = (va / na).pow(2.0) / (na - 1.0).coerceAtLeast(1.0) + (vb / nb).pow(2.0) / (nb - 1.0).coerceAtLeast(1.0)
        return if (bottom == 0.0) (a.size + b.size - 2).toDouble() else top / bottom
    }

    private fun tCritical95(df: Double): Double = when {
        df < 2.0 -> 12.706
        df < 3.0 -> 4.303
        df < 5.0 -> 3.182
        df < 10.0 -> 2.571
        df < 20.0 -> 2.228
        df < 30.0 -> 2.086
        df < 60.0 -> 2.000
        else -> 1.960
    }

    private fun studentTPValue(t: Double, df: Double): Double {
        if (t <= 0.0) return 1.0
        val upper = minOf(t, 12.0)
        val steps = 240
        val h = upper / steps
        var area = 0.0
        for (i in 0..steps) {
            val x = i * h
            val weight = when (i) { 0, steps -> 1.0; else -> if (i % 2 == 0) 2.0 else 4.0 }
            area += weight * studentTPdf(x, df)
        }
        val cdf = (0.5 + area * h / 3.0).coerceIn(0.0, 1.0)
        return (2.0 * (1.0 - cdf)).coerceIn(0.0, 1.0)
    }

    private fun studentTPdf(x: Double, df: Double): Double {
        val logNumerator = logGamma((df + 1.0) / 2.0)
        val logDenominator = logGamma(df / 2.0) + 0.5 * ln(df * Math.PI)
        val logTail = -((df + 1.0) / 2.0) * ln(1.0 + (x * x) / df)
        return exp(logNumerator - logDenominator + logTail)
    }

    // Lanczos approximation; deterministic and dependency-free.
    private fun logGamma(z: Double): Double {
        val coefficients = doubleArrayOf(
            676.5203681218851, -1259.1392167224028, 771.32342877765313,
            -176.61502916214059, 12.507343278686905, -0.13857109526572012,
            9.9843695780195716e-6, 1.5056327351493116e-7
        )
        if (z < 0.5) return ln(Math.PI) - ln(kotlin.math.sin(Math.PI * z)) - logGamma(1.0 - z)
        var x = 0.99999999999980993
        val zz = z - 1.0
        coefficients.forEachIndexed { i, c -> x += c / (zz + i + 1.0) }
        val t = zz + coefficients.size - 0.5
        return 0.5 * ln(2.0 * Math.PI) + (zz + 0.5) * ln(t) - t + ln(x)
    }
}

object ProcessedExpressionSignalExecutorV30329 {
    const val REQUIRED_TOKEN: String = "V30330_PROCESSED_EXPRESSION_SIGNAL_EXECUTOR_RAW_MATRIX_GATED"
    const val LEGACY_REQUIRED_TOKEN: String = "V30329_PROCESSED_EXPRESSION_SIGNAL_EXECUTOR_EFFECT_SIZE_CI_PVALUE"

    fun evaluate(
        state: ResearchStateV3,
        metadataProbe: ResearchMetadataProbeIngestionReportV3,
        datasetModuleScore: ResearchDatasetModuleScoreCardV3,
        comparatorVariables: ComparatorVariableExtractionReportV30329,
        mechanismSignal: MechanismModuleSignalSnapshotV30328,
        matrixRows: List<ExpressionSampleRowV30329> = emptyList(),
        matrixFuel: MatrixFuelSnapshotV30330? = null
    ): ProcessedExpressionSignalReportV30329 {
        val retrievalDataset = datasetModuleScore.dataset.takeIf { it != "none" }
            ?: comparatorVariables.bestAccession.takeIf { it != "none" }
            ?: metadataProbe.targets.firstOrNull()?.accession
            ?: mechanismSignal.dataset.takeIf { it != "none" }
            ?: "none"
        val dataset = when {
            matrixFuel?.fuelOrigin == PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN -> matrixFuel?.dgeExecutedOnAccession?.takeIf { it != "none" } ?: PediatricOncologyExplicitMatrixV30337.SOURCE_ACCESSION
            else -> retrievalDataset
        }
        if (dataset == "none") return ProcessedExpressionSignalReportV30329.inactive("No dataset accession or matrix route is available for signal execution.")

        val capsule = GTIMLocalProcessedCapsuleStoreV21316.getCapsuleByAccession(dataset)
        val curatedModules = when {
            capsule != null -> capsule.modules.map { CapsuleModuleLite(it.name, it.markers, it.direction) }
            datasetModuleScore.immuneRoutes.isNotEmpty() -> datasetModuleScore.immuneRoutes.map { CapsuleModuleLite(it.route, it.markers, it.status) }
            mechanismSignal.markers.isNotEmpty() -> listOf(CapsuleModuleLite(mechanismSignal.module, mechanismSignal.markers, mechanismSignal.axis))
            else -> emptyList()
        }
        val dynamicModules = DynamicModuleBuilderV30331.build(state.input.topic, dataset, datasetModuleScore, mechanismSignal)
        val pediatricProbeModules = if (
            PediatricOncologyExplicitMatrixV30337.isEligible(state.input.topic, dataset) &&
            matrixRows.any { row -> PediatricOncologyExplicitMatrixV30337.markers.any { marker -> row.values.containsKey(marker) } }
        ) {
            listOf(PediatricOncologyExplicitMatrixV30337.module())
        } else {
            emptyList()
        }
        val pediatricTranslationModulesV30338 = PediatricOncologyUnifiedFocusV30338.modulesFor(state.input.topic, dataset)
        val modules = (pediatricProbeModules + pediatricTranslationModulesV30338 + curatedModules + dynamicModules)
            .filter { it.markers.isNotEmpty() && it.markers.none { marker -> marker == "IMMUNE_AXIS" } }
            .distinctBy { it.name.lowercase() }
            .take(5)
        if (modules.isEmpty()) return ProcessedExpressionSignalReportV30329.inactive("No marker module is available for $dataset; keep as evidence-gap hypothesis.")

        val bestComparator = comparatorVariables.variables.maxByOrNull { it.confidence }
        val comparatorReady = comparatorVariables.state.contains("READY", true) || comparatorVariables.state.contains("PARTIAL", true)
        val matrixCandidate = datasetModuleScore.expressionRoute.contains("CANDIDATE", true) ||
            datasetModuleScore.expressionRoute.contains("VERIFIED", true) ||
            datasetModuleScore.expressionRoute.contains("GREIN", true) ||
            capsule?.matrixReady == true
        val resolution = matrixFuel?.groupResolution ?: ComparatorGroupResolverV30331.resolve(state.input.topic, bestComparator, metadataProbe, datasetModuleScore)
        val rowsReady = matrixRows.isNotEmpty() && resolution.ready
        val certifiedFuel = matrixFuel?.certifiedForDiscovery ?: false
        val estimates = modules.map { module ->
            if (rowsReady) {
                val sampleLevelComputed = if (matrixFuel?.fuelOrigin == PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN) {
                    ProcessedExpressionMatrixCalculatorV30329.calculatePerSampleModuleScore(
                        rows = matrixRows,
                        caseGroups = resolution.caseLabels,
                        controlGroups = resolution.controlLabels,
                        markers = module.markers
                    )
                } else emptyList()
                val computed = sampleLevelComputed.ifEmpty {
                    ProcessedExpressionMatrixCalculatorV30329.calculate(
                        rows = matrixRows,
                        caseGroups = resolution.caseLabels,
                        controlGroups = resolution.controlLabels,
                        markers = module.markers
                    )
                }
                if (computed.isNotEmpty()) return@map rawEstimate(dataset, module, computed, certifiedFuel, matrixFuel)
            }
            previewEstimate(
                dataset = dataset,
                module = module,
                comparatorReady = comparatorReady,
                matrixCandidate = matrixCandidate,
                moduleScore = datasetModuleScore.moduleScore,
                comparatorReadiness = comparatorVariables.readiness,
                source = if (capsule != null) "local_processed_capsule:${capsule.capsuleId}" else "dataset_module_score:${datasetModuleScore.state}"
            )
        }
        val rawMatrixComputed = estimates.any { it.rawMatrixDgeExecuted }
        val stateName = when {
            rawMatrixComputed && certifiedFuel -> "RAW_MATRIX_DGE_EXECUTED_EFFECT_SIZE_CI_PVALUE_READY"
            rawMatrixComputed && matrixFuel?.fuelOrigin == CuratedLightMatrixFuelPackV30335.FUEL_ORIGIN -> "CURATED_PRIOR_DGE_EXECUTED_HYPOTHESIS_DISCOVERY_SEED"
            rawMatrixComputed && matrixFuel?.fuelOrigin == PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN -> "PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_EXECUTED_REVIEW_ONLY"
            rawMatrixComputed -> "RAW_MATRIX_DGE_EXECUTED_REVIEW_FUEL_ONLY_NOT_DISCOVERY_CERTIFIED"
            estimates.isNotEmpty() && matrixRows.isNotEmpty() -> "MATRIX_ROWS_PRESENT_BUT_COMPARATOR_OR_MARKER_MATCH_BLOCKED"
            estimates.isNotEmpty() -> "MODULE_PREVIEW_ONLY_NO_MECHANISM_SUPPORT"
            else -> "PROCESSED_EXPRESSION_SIGNAL_PENDING"
        }
        val next = when (stateName) {
            "RAW_MATRIX_DGE_EXECUTED_EFFECT_SIZE_CI_PVALUE_READY" -> "Use raw matrix DGE result as research-only mechanism signal; still require exact-axis falsifier and independent replication."
            "CURATED_PRIOR_DGE_EXECUTED_HYPOTHESIS_DISCOVERY_SEED" -> "Curated disease/organ matrix prior executed a first DGE pass and may generate a falsifiable hypothesis-discovery seed; verified/replicated matrix is still required for mechanism support, score >=8, or certified discovery."
            "PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_EXECUTED_REVIEW_ONLY" -> "Pediatric oncology declared-source GSE85047 probe matrix executed real DGE; use it to rank neuroblastoma hypotheses, but require platform mapping, ETL verification, and independent replication before mechanism support, score >=8, or certified discovery."
            "RAW_MATRIX_DGE_EXECUTED_REVIEW_FUEL_ONLY_NOT_DISCOVERY_CERTIFIED" -> "Lite review rows exercised the DGE path, but they are not certified full ETL fuel and cannot pass mechanism/certified-discovery gates."
            "MATRIX_ROWS_PRESENT_BUT_COMPARATOR_OR_MARKER_MATCH_BLOCKED" -> "Map comparator axis to real group labels and marker names before DGE can support a discovery card."
            "MODULE_PREVIEW_ONLY_NO_MECHANISM_SUPPORT" -> "Preview is visible for triage only. Attach explicit sample-level expression rows; preview cannot pass mechanism/discovery gates."
            else -> "Acquire processed expression matrix rows and comparator labels before mechanism support or discovery status."
        }
        return ProcessedExpressionSignalReportV30329(
            active = true,
            state = stateName,
            dataset = dataset,
            moduleCount = modules.size,
            rawMatrixDgeExecuted = rawMatrixComputed,
            estimates = estimates,
            nextAction = next,
            matrixFuel = matrixFuel
        )
    }

    private fun rawEstimate(dataset: String, module: CapsuleModuleLite, computed: List<MatrixComputationResultV30329>, certifiedFuel: Boolean, matrixFuel: MatrixFuelSnapshotV30330?): ModuleSignalEstimateV30329 {
        val reality = SyntheticScaffoldDataGuardV30333.assess(matrixFuel)
        val sampleLevelModule = computed.size == 1 && computed.first().marker == "PER_SAMPLE_MODULE_SCORE"
        val moduleEffect = computed.map { it.effectSize }.average()
        val ciLow = computed.minOf { it.ciLow }
        val ciHigh = computed.maxOf { it.ciHigh }
        val bestAdjustedP = computed.minOf { it.adjustedPValue }
        val medianAdjustedP = computed.map { it.adjustedPValue }.sorted().let { values -> values[values.size / 2] }
        val nCase = computed.maxOfOrNull { it.nCase } ?: 0
        val nControl = computed.maxOfOrNull { it.nControl } ?: 0
        val powerLabel = when {
            nCase < 5 || nControl < 5 -> "UNDERPOWERED_BELOW_MINIMUM"
            nCase < 10 || nControl < 10 -> "UNDERPOWERED_SMALL_N_${nCase}v${nControl}"
            else -> "SAMPLE_SIZE_REVIEW_ONLY_${nCase}v${nControl}"
        }
        val plausibility = EffectSizePlausibilityGuardV30333.label(moduleEffect, reality)
        val direction = when {
            moduleEffect >= 0.2 -> "case_upregulated_or_module_enriched"
            moduleEffect <= -0.2 -> "case_downregulated_or_module_depleted"
            else -> "near_null_or_small_effect"
        }
        val supported = certifiedFuel && abs(moduleEffect) >= 0.5 && bestAdjustedP <= 0.1 && medianAdjustedP <= 0.2
        return ModuleSignalEstimateV30329(
            accession = dataset,
            module = module.name,
            markers = module.markers,
            effectDirection = direction,
            effectSize = moduleEffect,
            confidenceInterval = if (sampleLevelModule) "per_sample_module_score_95CI=[${round3(ciLow)}, ${round3(ciHigh)}]; ciLevel=PER_SAMPLE_MODULE_SCORE_WELCH" else "module_marker_range_95CI=[${round3(ciLow)}, ${round3(ciHigh)}]; ciLevel=MODULE_MARKER_RANGE",
            pValueLabel = if (sampleLevelModule) "per_sample_module_welch_p=${round4(bestAdjustedP)}; pValueLevel=PER_SAMPLE_MODULE_SCORE; samplePower=$powerLabel" else "module_median_bonferroni_adjusted_p=${round4(medianAdjustedP)}; marker_best_bonferroni_adjusted_p=${round4(bestAdjustedP)}; pValueLevel=MODULE_MARKER_MEDIAN_PROXY",
            statisticState = if (sampleLevelModule) "RAW_MATRIX_PER_SAMPLE_MODULE_SCORE_WELCH_TEST_V30341" else "RAW_MATRIX_WELCH_T_DGE_WITH_BONFERRONI_MARKER_CORRECTION_V30333_CI_PVALUE_LEVELS_EXPLICIT",
            rawMatrixDgeExecuted = true,
            computedFrom = when {
                matrixFuel?.fuelOrigin == PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN -> "sample_level_expression_rows:${matrixFuel?.dgeExecutedOnAccession ?: "none"}:source=${matrixFuel?.matrixFuelSourceAccession ?: "none"}:retrieval=${matrixFuel?.retrievalEvidenceBestAccession ?: "none"}"
                else -> "sample_level_expression_rows"
            },
            supportState = when {
                supported -> "MECHANISM_SIGNAL_SUPPORTED_BY_CERTIFIED_RAW_MATRIX"
                matrixFuel?.fuelOrigin == CuratedLightMatrixFuelPackV30335.FUEL_ORIGIN -> "CURATED_PRIOR_RAW_MATRIX_SIGNAL_HYPOTHESIS_DISCOVERY_NOT_MECHANISM_SUPPORT"
                matrixFuel?.fuelOrigin == PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN && sampleLevelModule && (nCase < 10 || nControl < 10) -> "PEDIATRIC_ONCOLOGY_UNDERPOWERED_PER_SAMPLE_MODULE_SCORE_REVIEW_NOT_MECHANISM_SUPPORT"
                matrixFuel?.fuelOrigin == PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN && ciLow <= 0.0 && ciHigh >= 0.0 && bestAdjustedP > 0.05 -> "PEDIATRIC_ONCOLOGY_DIRECTIONAL_NULL_RAW_DGE_REVIEW_NOT_MECHANISM_SUPPORT"
                matrixFuel?.fuelOrigin == PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN -> "PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_RAW_DGE_REVIEW_NOT_MECHANISM_SUPPORT"
                !certifiedFuel -> "RAW_MATRIX_SIGNAL_REVIEW_FUEL_NOT_CERTIFIED_MECHANISM_SUPPORT"
                else -> "RAW_MATRIX_SIGNAL_WEAK_OR_UNSTABLE"
            },
            markerResults = computed,
            statisticalCoherenceState = StatisticalCoherenceGuardV30333.evaluate(
                ModuleSignalEstimateV30329(dataset, module.name, module.markers, direction, moduleEffect, "module_marker_range_95CI=[${round3(ciLow)}, ${round3(ciHigh)}]", "module_median_bonferroni_adjusted_p=${round4(medianAdjustedP)}; marker_best_bonferroni_adjusted_p=${round4(bestAdjustedP)}", "temp", true, "temp", "temp")
            ).state,
            effectPlausibilityState = plausibility.first,
            scientificInterpretability = reality.scientificInterpretability,
            effectDisplayPolicy = if (plausibility.first.contains("HIDE")) "PIPELINE_SANITY_VALUE_HIDE_FROM_MAIN_CLAIM" else reality.effectDisplayPolicy
        )
    }

    private fun previewEstimate(
        dataset: String,
        module: CapsuleModuleLite,
        comparatorReady: Boolean,
        matrixCandidate: Boolean,
        moduleScore: Int,
        comparatorReadiness: Int,
        source: String
    ): ModuleSignalEstimateV30329 {
        val markerWeight = module.markers.size.coerceAtMost(8)
        val preview = ((moduleScore / 500.0) + (comparatorReadiness / 1000.0) + markerWeight * 0.03).coerceIn(0.05, 0.75)
        val state = when {
            comparatorReady && matrixCandidate -> "PREVIEW_READY_BUT_RAW_MATRIX_ROWS_MISSING"
            comparatorReady -> "PREVIEW_COMPARATOR_READY_MATRIX_NOT_VERIFIED"
            else -> "PREVIEW_COMPARATOR_INCOMPLETE"
        }
        return ModuleSignalEstimateV30329(
            accession = dataset,
            module = module.name,
            markers = module.markers,
            effectDirection = module.direction,
            effectSize = 0.0,
            confidenceInterval = "preview_only_no_ci",
            pValueLabel = "preview_only_no_p_value",
            statisticState = state,
            rawMatrixDgeExecuted = false,
            computedFrom = source,
            supportState = "MODULE_PREVIEW_REVIEW_ONLY_NOT_MECHANISM_SUPPORT",
            markerResults = emptyList(),
            scientificInterpretability = "NONE_PREVIEW_TRIAGE_ONLY",
            effectDisplayPolicy = "PREVIEW_TRIAGE_NOT_AN_EFFECT_SIZE_DO_NOT_DISPLAY_AS_EFFECT",
            previewTriageScore = preview
        )
    }
}

data class CapsuleModuleLite(val name: String, val markers: List<String>, val direction: String)

internal fun round3(value: Double): Double = kotlin.math.round(value * 1000.0) / 1000.0
internal fun round4(value: Double): Double = kotlin.math.round(value * 10000.0) / 10000.0
