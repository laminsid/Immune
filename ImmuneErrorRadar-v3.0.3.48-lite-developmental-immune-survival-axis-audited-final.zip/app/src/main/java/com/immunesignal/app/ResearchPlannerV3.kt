package com.immunesignal.app

data class ResearchPlanDecisionV3(
    val objective: ResearchObjectiveV3?,
    val gaps: List<ResearchGapV3>,
    val rationale: String
) {
    fun toSummaryLine(): String {
        val objectiveText = objective?.kind ?: "NO_OBJECTIVE"
        val gapText = gaps.take(3).joinToString(",") { it.id }.ifBlank { "no_open_gaps" }
        return "$objectiveText <- $gapText; $rationale"
    }
}

class ResearchPlannerV3 {
    fun nextObjective(state: ResearchStateV3): ResearchObjectiveV3? = nextDecision(state).objective

    fun nextDecision(state: ResearchStateV3): ResearchPlanDecisionV3 {
        val topic = state.input.topic
        val snapshot = state.ledgerSnapshot
        val gaps = ResearchGapDetectorV3.detect(state)
        val minTier = state.input.budget.minimumEvidenceQuality
        val alreadyExecuted = snapshot.executedObjectiveIds.toSet()

        fun decision(objective: ResearchObjectiveV3?, rationale: String): ResearchPlanDecisionV3 =
            ResearchPlanDecisionV3(objective = objective, gaps = gaps, rationale = rationale)

        // Compatibility + proof-loop contract: once ranking has executed, the next
        // reducer must continue hypothesis proof before any compile path. This guard
        // is intentionally before source/dataset gap planning so synthetic or resumed
        // states that already contain rank:<topic> cannot fall back to generic search.
        if (!alreadyExecuted.any { it.startsWith("hypothesis_proof:") } && shouldContinueHypothesisProof(state)) {
            return decision(
                ResearchObjectiveV3.ContinueHypothesisProof(topic = topic, hypothesisId = state.input.primaryHypothesisId),
                "hypothesis_generated_must_continue_to_evidence_proof_not_stop_at_ranking"
            )
        }

        if (!snapshot.hasSatisfyingRole(EvidenceRoleV3.SOURCE, minTier) && !snapshot.objectiveExhausted("source:")) {
            return decision(ResearchObjectiveV3.FindSourceEvidence(topic), "source_gap_has_highest_priority")
        }
        if (!snapshot.hasSatisfyingRole(EvidenceRoleV3.DATASET, minTier) && !snapshot.objectiveExhausted("dataset:")) {
            return decision(ResearchObjectiveV3.FindDatasetEvidence(topic), "dataset_or_provenance_gap_blocks_closure")
        }
        // Contradiction is a closure-blocking gate. It must run before provenance enrichment,
        // otherwise source+dataset+provenance can consume the bounded network budget and leave
        // the required falsifier objective unexecuted, as seen in mobile runs.
        if (!hasContradiction(snapshot, minTier) && !snapshot.objectiveExhausted("contradiction:")) {
            return decision(
                ResearchObjectiveV3.FindContradiction(topic = topic, hypothesisId = state.input.primaryHypothesisId),
                "contradiction_or_falsifier_gap_must_be_executed_not_suggested_before_optional_provenance"
            )
        }
        if (!snapshot.hasSatisfyingRole(EvidenceRoleV3.PROVENANCE, minTier) &&
            snapshot.hasSatisfyingRole(EvidenceRoleV3.DATASET, minTier) &&
            !snapshot.objectiveExhausted("provenance:")) {
            val datasetNode = snapshot.visibleEvidence.firstOrNull { it.role == EvidenceRoleV3.DATASET }
            val evidenceId = datasetNode?.accession?.ifBlank { null } ?: datasetNode?.id ?: "dataset_candidate"
            return decision(
                ResearchObjectiveV3.FindProvenance(topic = topic, evidenceId = evidenceId),
                "dataset_found_but_provenance_detail_missing_after_contradiction_attempt"
            )
        }
        if (!alreadyExecuted.any { it.startsWith("rank:") }) {
            return decision(ResearchObjectiveV3.RankHypotheses(topic), "ledger_ready_for_hypothesis_ranking")
        }
        if (!alreadyExecuted.any { it.startsWith("compile:") }) {
            return decision(ResearchObjectiveV3.CompileReport(topic), "compile_is_last_internal_reducer_after_gap_attempts")
        }
        return decision(null, "planner_exhausted_all_known_gap_routes")
    }

    private fun shouldContinueHypothesisProof(state: ResearchStateV3): Boolean {
        val snapshot = state.ledgerSnapshot
        if (!snapshot.objectiveExecuted("rank:")) return false
        if (snapshot.objectiveExecuted("hypothesis_proof:")) return false
        if (state.executedObjectiveCount >= state.input.budget.maxObjectives - 1) return false
        if (state.budgetUsage.networkCalls >= state.input.budget.maxNetworkCalls) return false
        // Continue proof whenever the engine has a candidate hypothesis route or an evidence gap.
        // The objective is bounded and review-only; it may strengthen, weaken, or leave the hypothesis unchanged.
        return true
    }

    private fun hasContradiction(snapshot: EvidenceLedgerSnapshotV3, minimumTier: QualityTierV3): Boolean =
        snapshot.hasSatisfyingRole(EvidenceRoleV3.CONTRADICTION, minimumTier) ||
            snapshot.hasSatisfyingRole(EvidenceRoleV3.FALSIFIER, minimumTier)
}
