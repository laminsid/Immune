package com.immunesignal.app

import kotlin.math.abs
import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.33 — data reality closure.
 *
 * The internal engine state is now wired; the remaining scientific bottleneck is
 * data reality: disease-matched evidence plus certified matrix provenance. These
 * guards prevent local scaffold rows, generic disease drift, or inconsistent
 * statistics from being read as scientific discovery.
 */
data class MatrixRealityAssessmentV30333(
    val analysisMode: String,
    val fuelOrigin: String,
    val certificationLevel: String,
    val scientificInterpretability: String,
    val biologicallyInterpretable: Boolean,
    val effectDisplayPolicy: String,
    val warnings: List<String>,
    val verificationLevel: String = "NONE",
    val signalValidity: String = "NOT_ASSESSED"
) {
    fun toJson(): JSONObject = JSONObject()
        .put("schema", "matrix_reality_assessment_v30333")
        .put("syntheticScaffoldToken", SyntheticScaffoldDataGuardV30333.REQUIRED_TOKEN)
        .put("realGeoEtlConnectorToken", RealGeoEtlConnectorV30333.REQUIRED_TOKEN)
        .put("analysisMode", analysisMode)
        .put("fuelOrigin", fuelOrigin)
        .put("certificationLevel", certificationLevel)
        .put("verificationLevel", verificationLevel)
        .put("signalValidity", signalValidity)
        .put("scientificInterpretability", scientificInterpretability)
        .put("biologicallyInterpretable", biologicallyInterpretable)
        .put("effectDisplayPolicy", effectDisplayPolicy)
        .put("warnings", JSONArray(warnings))
}

object SyntheticScaffoldDataGuardV30333 {
    const val REQUIRED_TOKEN: String = "V30333_SYNTHETIC_SCAFFOLD_DATA_GUARD_PIPELINE_ONLY_NOT_BIOLOGY"

    fun assess(fuel: MatrixFuelSnapshotV30330?): MatrixRealityAssessmentV30333 {
        // v3.0.3.34: the fuel snapshot is now the source of truth. String/source parsing is
        // a legacy fallback only; user-declared matrices are USER_ATTESTED, not certified.
        val hasRows = fuel?.rowCount.orZero() > 0
        val rawReady = fuel?.rawRowsReady == true
        val declaredFuelOrigin = fuel?.fuelOrigin?.takeIf { it.isNotBlank() && it != "UNKNOWN_OR_NONE" }
        val declaredCertification = fuel?.certificationLevel?.takeIf { it.isNotBlank() && it != "REVIEW_ONLY_UNCERTIFIED" }
        val fuelOrigin = declaredFuelOrigin ?: legacyFuelOriginFromSource(fuel?.source.orEmpty(), hasRows)
        val certificationLevel = declaredCertification ?: legacyCertificationFor(fuelOrigin)
        val analysisMode = fuel?.analysisMode?.takeIf { it.isNotBlank() && it != "NO_MATRIX_PREVIEW" } ?: when {
            rawReady && certificationLevel in setOf("CERTIFIED_GEO_ETL", "ETL_VERIFIED_GEO") -> "CERTIFIED_DGE"
            rawReady && certificationLevel == "USER_ATTESTED_WITH_DECLARED_SOURCE" -> "USER_ATTESTED_DGE"
            rawReady && certificationLevel == CuratedLightMatrixFuelPackV30335.CERTIFICATION_LEVEL -> CuratedLightMatrixFuelPackV30335.ANALYSIS_MODE
            rawReady -> "LITE_REVIEW_DGE"
            hasRows -> "ROWS_PRESENT_GROUPING_OR_MARKER_BLOCKED"
            else -> "NO_MATRIX_PREVIEW"
        }
        val verificationLevel = fuel?.verificationLevel?.ifBlank { "NONE" } ?: "NONE"
        val signalValidity = fuel?.signalValidity?.ifBlank { "NOT_ASSESSED" } ?: "NOT_ASSESSED"
        val interpretability = fuel?.scientificInterpretability?.takeIf { it.isNotBlank() } ?: when (analysisMode) {
            "CERTIFIED_DGE" -> "MODERATE_CERTIFIED_SINGLE_DATASET"
            "USER_ATTESTED_DGE" -> if (signalValidity.contains("UNDERPOWERED", true)) "UNDERPOWERED_USER_ATTESTED_REVIEW_ONLY" else "MODERATE_SINGLE_DATASET_RESEARCH_ONLY_NOT_INDEPENDENTLY_VERIFIED"
            CuratedLightMatrixFuelPackV30335.ANALYSIS_MODE -> CuratedLightMatrixFuelPackV30335.INTERPRETABILITY
            "LITE_REVIEW_DGE" -> if (fuelOrigin == "LITE_SCAFFOLD") "NONE_PIPELINE_ONLY" else "LOW_REVIEW_ONLY"
            "ROWS_PRESENT_GROUPING_OR_MARKER_BLOCKED" -> "NONE_PIPELINE_ONLY"
            else -> "NONE_PIPELINE_ONLY"
        }
        val warnings = mutableListOf<String>()
        if (fuelOrigin == CuratedLightMatrixFuelPackV30335.FUEL_ORIGIN) warnings += "v30335_curated_light_matrix_prior_can_seed_hypothesis_discovery_but_not_certified_mechanism_support"
        if (fuelOrigin == "LITE_SCAFFOLD") warnings += "v30333_lite_scaffold_rows_pipeline_validation_only_not_biological_evidence"
        if (fuelOrigin == "USER_SUPPLIED_ROWS_NO_PROVENANCE_REVIEW_ONLY") warnings += "v30333_user_rows_missing_declared_source_receipt"
        if (certificationLevel == "USER_ATTESTED_WITH_DECLARED_SOURCE") warnings += "v30334_user_attested_declared_source_not_app_verified_no_discovery_unlock"
        if (verificationLevel == "DECLARED_SOURCE_ONLY") warnings += "v30334_declared_source_only_not_verified_by_app"
        if (signalValidity.contains("UNDERPOWERED", true)) warnings += "v30334_underpowered_single_dataset_no_score_upgrade"
        if (analysisMode == "ROWS_PRESENT_GROUPING_OR_MARKER_BLOCKED") warnings += "v30333_rows_present_but_comparator_or_marker_mapping_not_ready"
        if (analysisMode == "NO_MATRIX_PREVIEW") warnings += "v30333_no_sample_level_matrix_rows_available"
        val displayPolicy = when {
            interpretability == "NONE_PIPELINE_ONLY" -> "PIPELINE_SANITY_VALUE_HIDE_FROM_MAIN_CLAIM"
            interpretability == CuratedLightMatrixFuelPackV30335.INTERPRETABILITY -> "CURATED_PRIOR_HYPOTHESIS_DISCOVERY_VALUE_WITH_NOT_CERTIFIED_BOUNDARY"
            interpretability.contains("UNDERPOWERED", true) -> "UNDERPOWERED_RESEARCH_VALUE_WITH_STRONG_CAUTION"
            certificationLevel == "USER_ATTESTED_WITH_DECLARED_SOURCE" -> "USER_ATTESTED_RESEARCH_VALUE_WITH_STRONG_BOUNDARY"
            else -> "RESEARCH_REVIEW_VALUE_WITH_BOUNDARY"
        }
        return MatrixRealityAssessmentV30333(
            analysisMode = analysisMode,
            fuelOrigin = fuelOrigin,
            certificationLevel = certificationLevel,
            verificationLevel = verificationLevel,
            signalValidity = signalValidity,
            scientificInterpretability = interpretability,
            biologicallyInterpretable = interpretability in setOf("MODERATE_CERTIFIED_SINGLE_DATASET", "MODERATE_SINGLE_DATASET_RESEARCH_ONLY_NOT_INDEPENDENTLY_VERIFIED") && !signalValidity.contains("UNDERPOWERED", true),
            effectDisplayPolicy = displayPolicy,
            warnings = warnings.distinct()
        )
    }

    private fun legacyFuelOriginFromSource(source: String, hasRows: Boolean): String = when {
        source.contains("geo_etl_certified", true) -> "CERTIFIED_GEO_ETL"
        source.contains("user_attested", true) || source.contains("declared_source", true) -> "USER_ATTESTED_WITH_DECLARED_SOURCE"
        source.contains("user_supplied", true) && source.contains("provenance", true) -> "USER_ATTESTED_WITH_DECLARED_SOURCE" // legacy marker; no live certification.
        source.contains("explicit", true) || source.contains("user", true) -> "USER_SUPPLIED_ROWS_NO_PROVENANCE_REVIEW_ONLY"
        source.contains("capsule", true) -> "LOCAL_CAPSULE_REVIEW_ONLY"
        source.contains("curated_light_matrix_prior", true) || source.contains("curated_prior", true) -> CuratedLightMatrixFuelPackV30335.FUEL_ORIGIN
        source.contains("lite", true) || source.contains("scaffold", true) -> "LITE_SCAFFOLD"
        hasRows -> "UNKNOWN_ROWS_REVIEW_ONLY"
        else -> "NO_MATRIX_ROWS"
    }

    private fun legacyCertificationFor(fuelOrigin: String): String = when (fuelOrigin) {
        "CERTIFIED_GEO_ETL" -> "CERTIFIED_GEO_ETL"
        "USER_ATTESTED_WITH_DECLARED_SOURCE" -> "USER_ATTESTED_WITH_DECLARED_SOURCE"
        CuratedLightMatrixFuelPackV30335.FUEL_ORIGIN -> CuratedLightMatrixFuelPackV30335.CERTIFICATION_LEVEL
        "LITE_SCAFFOLD" -> "LITE_SCAFFOLD_REVIEW_ONLY"
        "LOCAL_CAPSULE_REVIEW_ONLY" -> "LOCAL_CAPSULE_REVIEW_ONLY"
        "USER_SUPPLIED_ROWS_NO_PROVENANCE_REVIEW_ONLY" -> "USER_SUPPLIED_ROWS_NO_PROVENANCE_REVIEW_ONLY"
        "UNKNOWN_ROWS_REVIEW_ONLY" -> "UNKNOWN_ROWS_REVIEW_ONLY"
        else -> "NO_MATRIX_ROWS"
    }

    private fun Int?.orZero(): Int = this ?: 0
}

object RealGeoEtlConnectorV30333 {
    const val REQUIRED_TOKEN: String = "V30333_REAL_GEO_ETL_CONNECTOR_CERTIFIED_PROVENANCE_CONTRACT"

    fun collect(state: ResearchStateV3, accession: String): Pair<List<ExpressionSampleRowV30329>, List<String>> {
        // Android/mobile runtime cannot assume network ETL during a small interactive run.
        // This connector defines the certification contract and keeps the old budget intact.
        // Future real rows must enter through ETL-derived assets or explicit user rows with
        // provenance; local lite rows remain scaffold review fuel.
        val warnings = mutableListOf<String>()
        if (accession.isNotBlank() && accession != "none") {
            warnings += "v30333_geo_etl_contract_present_but_no_certified_etl_rows_attached_for_$accession"
        }
        if (state.input.explicitMatrixRows.isNotEmpty() && state.input.explicitMatrixProvenance.isBlank()) {
            warnings += "v30334_explicit_matrix_rows_seen_without_provenance_receipt_review_only"
        }
        return emptyList<ExpressionSampleRowV30329>() to warnings.distinct()
    }
}

object DiseaseOntologyGateV30333 {
    const val REQUIRED_TOKEN: String = "V30333_DISEASE_ONTOLOGY_GATE_DISEASE_TISSUE_COHORT_ABOVE_DOMAIN"

    fun evaluate(topic: String, evidenceText: String, requestedRole: EvidenceRoleV3, source: SourceKindV3): DiseaseSpecificityDecisionV30331 {
        val base = DiseaseSpecificityGateV30331.evaluate(topic, evidenceText, requestedRole, source)
        val t = topic.lowercase()
        val e = evidenceText.lowercase()
        val datasetLike = requestedRole in setOf(EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE) || source in setOf(SourceKindV3.GEO, SourceKindV3.SRA)
        if (isRaTopic(t) && datasetLike) {
            val periodontitisDrift = e.hasAnyV30333("periodontitis", "gingivitis", "dental", "ligature-induced") && !e.hasAnyV30333("rheumatoid", "synovial", "synovium", "arthritis")
            val genericTnfrTcell = e.hasAnyV30333("tnfr1", "tnfr2", "t-cells", "t cells") && !e.hasAnyV30333("rheumatoid", "synovial", "synovium", "arthritis", "joint")
            val synovialRelevant = e.hasAnyV30333("synovial", "synovium", "joint", "pannus", "synovial fibroblast", "inflammatory cell states in rheumatoid arthritis")
            val exactRa = e.hasAnyV30333("rheumatoid arthritis", "ra patients", "rheumatoid")
            return when {
                periodontitisDrift -> base.copy(
                    state = "DISEASE_ONTOLOGY_BLOCKED_RA_PERIODONTITIS_DRIFT",
                    supportAllowed = false,
                    tierCap = QualityTierV3.D,
                    diseaseScore = 5,
                    tissueScore = 5,
                    organismScore = 45,
                    matchedFrame = "rheumatoid_arthritis",
                    limitations = (base.limitations + RATopicHardeningPackV30333.PERIODONTITIS_BLOCK).distinct()
                )
                genericTnfrTcell -> base.copy(
                    state = "DISEASE_ONTOLOGY_BLOCKED_RA_GENERIC_TCELL_TNFR_ONLY",
                    supportAllowed = false,
                    tierCap = QualityTierV3.D,
                    diseaseScore = 15,
                    tissueScore = 20,
                    organismScore = 90,
                    matchedFrame = "rheumatoid_arthritis",
                    limitations = (base.limitations + RATopicHardeningPackV30333.GENERIC_TCELL_BLOCK).distinct()
                )
                exactRa && synovialRelevant -> base.copy(
                    state = "DISEASE_ONTOLOGY_RA_SYNOVIUM_COHORT_MATCH_STRONG",
                    supportAllowed = true,
                    tierCap = QualityTierV3.A,
                    diseaseScore = 95,
                    tissueScore = 90,
                    organismScore = if (e.hasAnyV30333("mouse", "mice", "murine")) 55 else 90,
                    matchedFrame = "rheumatoid_arthritis",
                    limitations = base.limitations.filterNot { it.contains("domain", true) }
                )
                synovialRelevant -> base.copy(
                    state = "DISEASE_ONTOLOGY_RA_SYNOVIUM_RELEVANT_TRANSLATIONAL_REVIEW",
                    supportAllowed = true,
                    tierCap = QualityTierV3.B,
                    diseaseScore = 70,
                    tissueScore = 85,
                    organismScore = if (e.hasAnyV30333("mouse", "mice", "murine")) 55 else 75,
                    matchedFrame = "rheumatoid_arthritis",
                    limitations = (base.limitations + "v30333_ra_synovium_relevant_but_needs_exact_ra_cohort_or_human_provenance").distinct()
                )
                else -> base.copy(
                    state = "DISEASE_ONTOLOGY_BLOCKED_RA_DOMAIN_ONLY_NOT_DISEASE_MATCHED",
                    supportAllowed = false,
                    tierCap = QualityTierV3.D,
                    limitations = (base.limitations + "v30333_ra_dataset_requires_ra_synovium_joint_or_pbmc_disease_specific_cohort").distinct()
                )
            }
        }

        val specialistRoute = SpecialistRouterV30335.route(topic, evidenceText)
        val specialistCapsule = CuratedDiseaseCapsuleStoreV30335.capsuleById(specialistRoute.routeId)
        if (specialistRoute.active && specialistCapsule != null && datasetLike) {
            val forbiddenDrift = specialistCapsule.hasForbiddenConfusion(evidenceText) && !specialistCapsule.evidenceLooksSpecific(evidenceText)
            val diseaseSpecific = specialistCapsule.evidenceLooksSpecific(evidenceText)
            if (forbiddenDrift) {
                return base.copy(
                    state = "DISEASE_ONTOLOGY_BLOCKED_V30335_SPECIALIST_FORBIDDEN_CONFUSION_${specialistRoute.routeId.uppercase()}",
                    supportAllowed = false,
                    tierCap = QualityTierV3.D,
                    diseaseScore = 10,
                    tissueScore = 10,
                    matchedFrame = specialistRoute.routeId,
                    limitations = (base.limitations + "v30335_forbidden_confusion_block:${specialistRoute.routeId}").distinct()
                )
            }
            if (diseaseSpecific) {
                return base.copy(
                    state = "DISEASE_ONTOLOGY_MATCHED_V30335_SPECIALIST_ROUTE_${specialistRoute.routeId.uppercase()}",
                    supportAllowed = true,
                    tierCap = if (e.hasAnyV30333("human", "patient", "cohort", "biopsy", "pbmc", "single-cell", "single cell", "transcriptome")) QualityTierV3.A else QualityTierV3.B,
                    diseaseScore = 88,
                    tissueScore = if (specialistRoute.primaryTissue != "unknown") 82 else 65,
                    organismScore = if (e.hasAnyV30333("mouse", "mice", "murine")) 55 else 85,
                    matchedFrame = specialistRoute.routeId,
                    limitations = (base.limitations + "v30335_specialist_route_prior_used_for_filtering_not_discovery_certification").distinct()
                )
            }
        }

                if (t.hasAnyV30333("pediatric", "childhood", "neuroblastoma") && datasetLike && e.hasAnyV30333("mouse", "mice", "murine", "ngemm") && !e.hasAnyV30333("human", "patient", "pediatric", "childhood", "children")) {
            return base.copy(
                state = "DISEASE_ONTOLOGY_TRANSLATIONAL_MOUSE_MODEL_NOT_TIER_A_HUMAN_PEDIATRIC_SUPPORT",
                supportAllowed = true,
                tierCap = QualityTierV3.B,
                limitations = (base.limitations + "v30333_mouse_model_neuroblastoma_translational_not_human_pediatric_tier_a").distinct()
            )
        }
        return base
    }

    private fun isRaTopic(value: String): Boolean = value.contains("rheumatoid") || Regex("(^|[^a-z0-9])ra([^a-z0-9]|$)").containsMatchIn(value)
}

object RATopicHardeningPackV30333 {
    const val REQUIRED_TOKEN: String = "V30333_RA_TOPIC_HARDENING_PACK_SYNOVIUM_OVER_GENERIC_TCELL"
    const val PERIODONTITIS_BLOCK: String = "v30333_ra_cannot_accept_periodontitis_as_support"
    const val GENERIC_TCELL_BLOCK: String = "v30333_ra_cannot_accept_generic_tcell_tnfr_as_disease_dataset_support"
}

object OntologyLeakageGuardV30333 {
    const val REQUIRED_TOKEN: String = "V30333_ONTOLOGY_LEAKAGE_GUARD_NO_CANCER_TERMS_IN_RA_ROUTE"

    fun sanitizeQuery(topic: String, query: String): String {
        val t = topic.lowercase()
        var out = query
        if (t.contains("rheumatoid") || Regex("(?i)(^|[^a-z0-9])RA([^a-z0-9]|$)").containsMatchIn(topic)) {
            listOf("tumor-associated", "tumour-associated", "tumor associated", "tumour associated", "TME", "checkpoint escape").forEach {
                out = out.replace(it, "", ignoreCase = true)
            }
        }
        return QuerySanitizerV3.noMalformedQuery(out)
    }
}

data class StatisticalCoherenceReportV30333(
    val state: String,
    val coherence: String,
    val warnings: List<String>
) {
    fun toJson(): JSONObject = JSONObject()
        .put("schema", "statistical_coherence_v30333")
        .put("requiredToken", StatisticalCoherenceGuardV30333.REQUIRED_TOKEN)
        .put("state", state)
        .put("coherence", coherence)
        .put("warnings", JSONArray(warnings))
}

object StatisticalCoherenceGuardV30333 {
    const val REQUIRED_TOKEN: String = "V30333_STATISTICAL_COHERENCE_GUARD_CI_AND_PVALUE_SAME_LEVEL"

    fun evaluate(estimate: ModuleSignalEstimateV30329): StatisticalCoherenceReportV30333 {
        val warnings = mutableListOf<String>()
        val ciCrossesZero = estimate.confidenceInterval.contains("[-", true) && Regex(",\\s*[0-9]").containsMatchIn(estimate.confidenceInterval)
        val pStrong = Regex("adjusted_p=([0-9.]+E?-?[0-9]*)", RegexOption.IGNORE_CASE).findAll(estimate.pValueLabel).mapNotNull { it.groupValues.getOrNull(1)?.toDoubleOrNull() }.any { it <= 0.05 }
        if (estimate.pValueLabel.contains("best_bonferroni", true) && estimate.confidenceInterval.contains("module_mean", true)) {
            warnings += "v30333_statistical_level_mismatch_ci_module_range_vs_best_marker_pvalue"
        }
        if (ciCrossesZero && pStrong) warnings += "v30333_ci_crosses_zero_but_best_marker_p_significant_review_only"
        val state = when {
            warnings.isEmpty() -> "STATISTICAL_LEVELS_COHERENT_REVIEW"
            ciCrossesZero && pStrong -> "STATISTICAL_LEVEL_MISMATCH_REVIEW_ONLY"
            else -> "STATISTICAL_PRESENTATION_WARNING_REVIEW_ONLY"
        }
        return StatisticalCoherenceReportV30333(state, if (warnings.isEmpty()) "OK" else "LOW", warnings.distinct())
    }
}

object EffectSizePlausibilityGuardV30333 {
    const val REQUIRED_TOKEN: String = "V30333_EFFECT_SIZE_PLAUSIBILITY_GUARD_EXTREME_EFFECT_SCAFFOLD_WARNING"

    fun label(effect: Double, reality: MatrixRealityAssessmentV30333): Pair<String, List<String>> {
        val warnings = mutableListOf<String>()
        val absEffect = abs(effect)
        val state = when {
            absEffect > 10.0 -> "LIKELY_SCAFFOLD_OR_LOW_VARIANCE_ARTIFACT_HIDE_FROM_MAIN_CLAIM"
            absEffect > 5.0 -> "LIKELY_SCAFFOLD_OR_LOW_VARIANCE_ARTIFACT"
            absEffect > 3.0 -> "EXTREME_EFFECT_REVIEW_REQUIRED"
            else -> "EFFECT_SIZE_WITHIN_REVIEW_RANGE"
        }
        if (absEffect > 3.0) warnings += "v30333_extreme_effect_size_requires_variance_and_data_origin_review"
        if (!reality.biologicallyInterpretable) warnings += "v30333_effect_from_non_interpretable_scaffold_or_review_fuel"
        return state to warnings.distinct()
    }
}

private fun String.hasAnyV30333(vararg needles: String): Boolean = needles.any { contains(it, ignoreCase = true) }
