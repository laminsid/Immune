package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.31 — disease-first dataset gate.
 *
 * Domain/mechanism similarity is no longer enough for Tier A/B dataset support.
 * A dataset must match the disease frame, tissue/cohort context, and organism/provenance
 * expectations before it can feed metadata probes, module scoring, or report support.
 */
data class DiseaseSpecificityDecisionV30331(
    val state: String,
    val supportAllowed: Boolean,
    val tierCap: QualityTierV3,
    val diseaseScore: Int,
    val tissueScore: Int,
    val organismScore: Int,
    val matchedFrame: String,
    val limitations: List<String>
) {
    fun toJson(): JSONObject = JSONObject()
        .put("schema", "disease_specificity_gate_v30331")
        .put("requiredToken", DiseaseSpecificityGateV30331.REQUIRED_TOKEN)
        .put("state", state)
        .put("supportAllowed", supportAllowed)
        .put("tierCap", tierCap.name)
        .put("diseaseScore", diseaseScore)
        .put("tissueScore", tissueScore)
        .put("organismScore", organismScore)
        .put("matchedFrame", matchedFrame)
        .put("limitations", JSONArray(limitations))
}

object DiseaseSpecificityGateV30331 {
    const val REQUIRED_TOKEN: String = "V30331_DISEASE_MATCH_ABOVE_DOMAIN_MATCH_GENERALIZATION_GATE"

    fun evaluate(
        topic: String,
        evidenceText: String,
        requestedRole: EvidenceRoleV3,
        source: SourceKindV3
    ): DiseaseSpecificityDecisionV30331 {
        val topicLower = topic.lowercase()
        val text = evidenceText.lowercase()
        val datasetLike = requestedRole in setOf(EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE) || source in setOf(SourceKindV3.GEO, SourceKindV3.SRA)
        val frame = frameFor(topicLower)
        if (frame == "generic_or_unknown") {
            return DiseaseSpecificityDecisionV30331(
                state = "DISEASE_SPECIFICITY_NOT_REQUIRED_GENERIC_FRAME",
                supportAllowed = true,
                tierCap = QualityTierV3.A,
                diseaseScore = 50,
                tissueScore = 35,
                organismScore = organismScore(topicLower, text),
                matchedFrame = frame,
                limitations = emptyList()
            )
        }

        val diseaseScore = diseaseScore(frame, text)
        val tissueScore = tissueScore(frame, text)
        val organism = organismScore(topicLower, text)
        val incompatible = incompatibleDiseaseDrift(frame, text)
        val pediatricHumanModelMismatch = topicLower.hasAny("pediatric", "paediatric", "childhood", "human") && text.hasAny("mouse", "mice", "murine", "rat") && !text.hasAny("human", "patients", "patient", "child", "children", "pediatric", "paediatric")
        val exactEnough = diseaseScore >= 70 || (frame == "rheumatoid_arthritis" && tissueScore >= 65) || (frame == "lupus_nephritis" && tissueScore >= 70)
        val support = if (!datasetLike) {
            !incompatible && organism > 0 && (diseaseScore >= 45 || tissueScore >= 45)
        } else {
            !incompatible && !pediatricHumanModelMismatch && organism >= 45 && exactEnough
        }
        val limitations = mutableListOf<String>()
        if (incompatible) limitations += "v30331_disease_specificity_incompatible_disease_drift"
        if (datasetLike && !exactEnough) limitations += "v30331_dataset_not_exact_disease_or_tissue_cohort_match"
        if (pediatricHumanModelMismatch) limitations += "v30331_pediatric_human_query_mouse_model_translational_not_tier_a_support"
        if (organism < 45) limitations += "v30331_organism_or_provenance_not_support_ready"
        val state = when {
            support && diseaseScore >= 80 && tissueScore >= 50 -> "DISEASE_TISSUE_COHORT_MATCH_STRONG"
            support -> "DISEASE_SPECIFIC_MATCH_ALLOWED_REVIEW_ONLY"
            pediatricHumanModelMismatch -> "TRANSLATIONAL_MODEL_ONLY_NOT_HUMAN_DISEASE_SUPPORT"
            incompatible -> "DISEASE_SPECIFICITY_BLOCKED_INCOMPATIBLE_DISEASE"
            else -> "DISEASE_SPECIFICITY_BLOCKED_DOMAIN_MATCH_ONLY"
        }
        val cap = when {
            support && organism >= 70 && diseaseScore >= 70 -> QualityTierV3.A
            support -> QualityTierV3.B
            else -> QualityTierV3.D
        }
        return DiseaseSpecificityDecisionV30331(
            state = state,
            supportAllowed = support,
            tierCap = cap,
            diseaseScore = diseaseScore,
            tissueScore = tissueScore,
            organismScore = organism,
            matchedFrame = frame,
            limitations = limitations.distinct()
        )
    }

    private fun frameFor(topic: String): String = when {
        topic.hasAny("rheumatoid", " ra ", "ra autoimmune", "synovial") || Regex("(^|[^a-z0-9])ra([^a-z0-9]|$)").containsMatchIn(topic) -> "rheumatoid_arthritis"
        topic.hasAny("lupus nephritis", "sle nephritis", "kidney biopsy", "renal lupus") -> "lupus_nephritis"
        topic.hasAny("multiple sclerosis", "rrms", "myelin") -> "multiple_sclerosis"
        topic.hasAny("neuroblastoma", "mycn") -> "pediatric_neuroblastoma"
        topic.hasAny("cancer", "tumor", "tumour", "melanoma", "checkpoint", "tme") -> "cancer_tme"
        topic.hasAny("ulcerative colitis", "crohn", "ibd", "colon", "intestinal") -> "ibd_barrier"
        topic.hasAny("alzheimer", "c1q", "synaptic pruning") -> "alzheimer_neuroimmune"
        topic.hasAny("diabetes", "insulin resistance", "adipose") -> "diabetes_metabolic"
        topic.hasAny("covid", "sars-cov-2", "pasc") -> "covid_postviral"
        topic.hasAny("allergy", "allergic", "asthma", "type 2") -> "allergy_type2"
        else -> "generic_or_unknown"
    }

    private fun diseaseScore(frame: String, text: String): Int = when (frame) {
        "rheumatoid_arthritis" -> when {
            text.hasAny("rheumatoid arthritis", "ra patients", "rheumatoid") -> 90
            text.hasAny("synovium", "synovial", "joint synovial", "arthritis") -> 70
            else -> 10
        }
        "lupus_nephritis" -> when {
            text.hasAny("lupus nephritis", "sle nephritis") -> 95
            text.hasAny("systemic lupus", "sle", "renal biopsy", "kidney biopsy") -> 75
            else -> 10
        }
        "multiple_sclerosis" -> when {
            text.hasAny("multiple sclerosis", "relapsing-remitting", "relapsing remitting", "rrms", "ms patients") -> 95
            text.hasAny("myelin", "oligodendrocyte") -> 70
            else -> 10
        }
        "pediatric_neuroblastoma" -> when {
            text.hasAny("neuroblastoma") && text.hasAny("mycn", "pediatric", "paediatric", "childhood", "child") -> 95
            text.hasAny("neuroblastoma") -> 80
            else -> 10
        }
        "cancer_tme" -> when {
            text.hasAny("melanoma", "tumor", "tumour", "cancer", "carcinoma", "neoplasm", "small cell lung", "breast cancer") -> 85
            else -> 15
        }
        "ibd_barrier" -> when {
            text.hasAny("ulcerative colitis", "crohn", "inflammatory bowel", "ibd") -> 95
            text.hasAny("colon", "intestinal", "epithelial barrier") -> 65
            else -> 10
        }
        "alzheimer_neuroimmune" -> when {
            text.hasAny("alzheimer", "dementia") -> 90
            text.hasAny("microglia", "synaptic pruning", "c1q") -> 65
            else -> 10
        }
        "diabetes_metabolic" -> when {
            text.hasAny("type 2 diabetes", "t2d", "diabetes", "insulin resistance", "adipose") -> 90
            else -> 10
        }
        "covid_postviral" -> if (text.hasAny("covid", "sars-cov-2", "pasc", "long covid")) 95 else 10
        "allergy_type2" -> if (text.hasAny("allergy", "allergic", "asthma", "rhinitis", "ige", "eosinophil", "mast cell")) 90 else 10
        else -> 50
    }

    private fun tissueScore(frame: String, text: String): Int = when (frame) {
        "rheumatoid_arthritis" -> if (text.hasAny("synovium", "synovial", "joint", "fibroblast", "macrophage", "t cell", "tnf", "il-6", "il-17")) 80 else 20
        "lupus_nephritis" -> if (text.hasAny("kidney", "renal", "glomer", "biopsy", "interferon", "complement")) 85 else 20
        "multiple_sclerosis" -> if (text.hasAny("myelin", "oligodendrocyte", "cns", "brain", "microglia", "b cell", "t cell", "ifn")) 85 else 25
        "pediatric_neuroblastoma" -> if (text.hasAny("mycn", "tumor", "tumour", "t cell", "cd8", "single-cell", "single cell")) 80 else 25
        "cancer_tme" -> if (text.hasAny("tumor microenvironment", "tumour microenvironment", "tme", "cd8", "checkpoint", "macrophage", "treg", "hypoxia", "emt", "single-cell", "single cell")) 80 else 25
        "ibd_barrier" -> if (text.hasAny("colon", "intestinal", "epithelial", "barrier", "neutrophil", "il-23", "il23")) 85 else 20
        "alzheimer_neuroimmune" -> if (text.hasAny("microglia", "c1q", "complement", "synaptic", "brain")) 85 else 20
        "diabetes_metabolic" -> if (text.hasAny("adipose", "macrophage", "insulin", "beta-cell", "islet", "metabolic", "tnf", "il-6")) 80 else 20
        else -> 50
    }

    private fun organismScore(topic: String, text: String): Int = when {
        text.hasAny("arabidopsis", "plant", "maize", "rice") -> 0
        text.hasAny("human", "patients", "patient", "clinical", "pbmc", "blood", "biopsy", "tumor", "tumour", "pediatric", "paediatric", "childhood", "children") -> 90
        text.hasAny("mouse", "mice", "murine", "rat") -> if (topic.hasAny("mouse", "murine", "animal")) 70 else 45
        text.hasAny("mammal", "mammalian") -> 55
        else -> 60
    }

    private fun incompatibleDiseaseDrift(frame: String, text: String): Boolean = when (frame) {
        "rheumatoid_arthritis" -> text.hasAny("periodontitis", "gingivitis", "dental", "lung organoid", "particulate matter") && !text.hasAny("rheumatoid", "synovial", "arthritis")
        "multiple_sclerosis" -> text.hasAny("arabidopsis", "plant", "periodontitis")
        "pediatric_neuroblastoma" -> text.hasAny("adult breast cancer", "melanoma") && !text.hasAny("neuroblastoma")
        "lupus_nephritis" -> text.hasAny("periodontitis", "tumor", "tumour") && !text.hasAny("lupus", "kidney", "renal")
        else -> false
    }
}

private fun String.hasAny(vararg needles: String): Boolean = needles.any { contains(it, ignoreCase = true) }
