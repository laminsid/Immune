package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.15.7 — runtime closure audit.
 *
 * The clean runtime has two different kinds of completion:
 * - execution completion: the finite task queue was attempted without looping.
 * - evidence closure: source + provenance + contradiction gates are positively closed.
 *
 * A 100% task queue must not be interpreted as a final research proof when the
 * evidence gates are still open. This audit object makes that distinction visible
 * to UI, export, tests and future cleanup scripts.
 */
object ResearchRuntimeClosureAuditV2157 {
    const val VERSION: String = "2.15.7-runtime-closure-audit"
    const val REQUIRED_TOKEN: String = "V2157_EXECUTION_DONE_IS_NOT_EVIDENCE_CLOSED"

    fun toJson(contract: ResearchRunContractV2150): JSONObject {
        val gate = ResearchEvidenceGateV2156.gateState(contract.evidenceHandles)
        val proof = ResearchProofContractV2160.fromContract(contract)
        val openGates = mutableListOf<String>()
        if (!proof.hasVisibleSource) openGates += "visible_source_handle"
        if (!proof.hasVisibleProvenance) openGates += "visible_metadata_provenance_or_sample"
        if (!proof.hasVisibleContradiction) openGates += "visible_contradiction_falsification"
        val mechanismClosed = proof.mechanismHandles.isNotEmpty()
        val diversityAudit = ResearchEvidenceDiversityAuditV2172.evaluate(proof)
        if (!diversityAudit.hasIndependentEvidenceSupport) openGates += "independent_reviewable_evidence_diversity"
        if (!mechanismClosed) openGates += "mechanism_linkage_optional"
        val executionComplete = contract.tasks.all {
            it.status == ResearchTaskStatusV2150.DONE ||
                it.status == ResearchTaskStatusV2150.FAILED ||
                it.status == ResearchTaskStatusV2150.SKIPPED
        }
        val mandatoryClosed = listOf(proof.hasVisibleSource, proof.hasVisibleProvenance, proof.hasVisibleContradiction).count { it }
        val evidenceClosurePercent = ((mandatoryClosed * 100) / 3).coerceIn(0, 100)
        val reportEligible = contract.status == ResearchRunStatusV2150.REPORT_READY && ResearchExecutionPolicyV2154.reportCanClose(contract)
        return JSONObject()
            .put("version", VERSION)
            .put("requiredToken", REQUIRED_TOKEN)
            .put("executionProgressPercent", contract.progressPercent.coerceIn(0, 100))
            .put("executionComplete", executionComplete)
            .put("evidenceClosurePercent", evidenceClosurePercent)
            .put("mandatoryEvidenceGatesClosed", mandatoryClosed)
            .put("mandatoryEvidenceGatesTotal", 3)
            .put("positiveSource", proof.hasVisibleSource)
            .put("positiveProvenance", proof.hasVisibleProvenance)
            .put("positiveContradiction", proof.hasVisibleContradiction)
            .put("positiveMechanismOptional", proof.mechanismHandles.isNotEmpty())
            .put("visibleEvidenceCount", proof.visibleEvidenceCount())
            .put("displayedEvidenceLineCount", proof.displayedEvidenceLineCount())
            .put("countedEqualsDisplayed", proof.countedEqualsDisplayed())
            .put("evidenceDiversityAuditV2172", diversityAudit.toJson())
            .put("negativeOrGapCount", gate.negativeOrGapCount)
            .put("openGates", JSONArray(openGates))
            .put("reportEligible", reportEligible)
            .put("checkpointIsValid", ResearchRunStateMachineV2150.canExport(contract.status) && !reportEligible)
            .put("interpretation", interpretation(contract, evidenceClosurePercent, reportEligible))
            .put("nextBestRuntimeAction", nextBestAction(openGates, reportEligible))
    }

    private fun interpretation(contract: ResearchRunContractV2150, evidenceClosurePercent: Int, reportEligible: Boolean): String = when {
        reportEligible -> "REPORT_READY: task queue completed and mandatory proof gates are positively closed."
        contract.status == ResearchRunStatusV2150.STOPPED -> "STOPPED: user stopped the run; checkpoint is exportable but not final evidence."
        contract.status == ResearchRunStatusV2150.FAILED_SAFE -> "FAILED_SAFE: runtime recovered with a compact checkpoint; no final claim is allowed."
        evidenceClosurePercent == 0 -> "CHECKPOINT_READY: execution may be complete, but mandatory evidence gates are still open."
        evidenceClosurePercent < 100 -> "CHECKPOINT_READY: partial evidence closure only; export as working research checkpoint, not final report."
        else -> "CHECKPOINT_READY: evidence gates look closed, but runtime status is not REPORT_READY; keep as checkpoint."
    }

    private fun nextBestAction(openGates: List<String>, reportEligible: Boolean): String = when {
        reportEligible -> "Export compact report and review handles manually."
        openGates.contains("visible_source_handle") -> "Run a narrower source-handle query first; do not deepen every route at once."
        openGates.contains("visible_metadata_provenance_or_sample") -> "Focus next run on one dataset/accession and close sample/comparator provenance."
        openGates.contains("visible_contradiction_falsification") -> "Run a contradiction/falsification query for tissue, species, cohort and negative evidence."
        else -> "Export checkpoint and continue with one focused missing gate."
    }
}
