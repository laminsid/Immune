package com.immunesignal.app

/**
 * v3.0.3.12 — bounded query sanitizer.
 *
 * Keeps biomedical tokens queryable while removing malformed tails, duplicated
 * suffixes, and control characters that made precise questions produce zero-hit
 * PubMed/GEO searches (for example: "covid-19 sars-" or repeated "ige").
 */
object QuerySanitizerV3 {
    val VERSION: String = ResearchEngineV3ReleaseIdentity.VERSION_NAME
    // legacy audit marker only: 3.0.3.20-final-unified-metadata-probe-runtime
    const val REQUIRED_TOKEN: String = "V30312_QUERY_SANITIZER_NO_MALFORMED_TAILS_NO_DUPLICATE_SUFFIXES"

    private val controlChars = Regex("[\\u0000-\\u001F\\u007F-\\u009F\\uFFFE\\uFFFF]")
    private val whitespace = Regex("\\s+")
    private val danglingHyphen = Regex("(?i)\\b[a-z]{2,}-$")

    fun sanitizeText(raw: String): String {
        var text = raw
            .replace(controlChars, " ")
            .replace('–', '-')
            .replace('—', '-')
            .replace(Regex("(?i)\\bsars\\s*[- ]?\\s*cov\\s*[- ]?\\s*2\\b"), "SARS-CoV-2")
            .replace(Regex("(?i)\\bcovid\\s*[- ]?\\s*19\\b"), "COVID-19")
            .replace(Regex("(?i)\\brna\\s*[- ]?\\s*seq\\b"), "RNA-seq")
            .replace(Regex("(?i)\\btype\\s*[- ]?\\s*2\\b"), "type 2")
            .replace(whitespace, " ")
            .trim()
        while (danglingHyphen.containsMatchIn(text)) {
            text = text.replace(danglingHyphen, "").replace(whitespace, " ").trim()
        }
        return text
    }

    fun tokens(raw: String): List<String> {
        val cleaned = sanitizeText(raw).lowercase()
        return Regex("[a-z0-9]+(?:-[a-z0-9]+)*").findAll(cleaned)
            .map { canonicalToken(it.value) }
            .filter { it.length >= 2 }
            .filterNot { it in genericStopTokens }
            .toList()
    }

    fun uniqueTokens(rawTokens: Iterable<String>, max: Int = 16): List<String> {
        val seen = linkedSetOf<String>()
        rawTokens.flatMap { tokens(it) }
            .filter { it.length >= 2 }
            .filterNot { it in genericStopTokens }
            .forEach { token ->
                if (seen.size < max) seen += token
            }
        return seen.toList()
    }

    fun compactQuery(terms: Iterable<String>, maxTerms: Int = 16): String = uniqueTokens(terms, maxTerms)
        .joinToString(" ")
        .replace(Regex("(?i)\\bcovid-19\\s+sars-$"), "COVID-19")
        .replace(Regex("(?i)\\bige\\s+ige\\b"), "IgE")
        .trim()

    fun uniquePhrases(rawTerms: Iterable<String>, max: Int = 16): List<String> {
        val seen = linkedSetOf<String>()
        rawTerms
            .map { noMalformedQuery(it).trim() }
            .filter { it.length >= 2 }
            .filterNot { it.lowercase() in genericStopTokens }
            .forEach { term ->
                val key = canonicalPhraseKey(term)
                if (key.isNotBlank() && seen.none { canonicalPhraseKey(it) == key } && seen.size < max) seen += term
            }
        return seen.toList()
    }

    fun compactPhraseQuery(terms: Iterable<String>, maxPhrases: Int = 12): String = uniquePhrases(terms, maxPhrases)
        .joinToString(" ")
        .replace(whitespace, " ")
        .trim()

    fun noMalformedQuery(query: String): String {
        val cleaned = sanitizeText(query)
        val parts = cleaned.split(Regex("\\s+")).filter { it.isNotBlank() }
        val out = mutableListOf<String>()
        val seenTail = linkedSetOf<String>()
        for (part in parts) {
            val canonical = canonicalToken(part)
            if (canonical.endsWith("-") || canonical == "sars-") continue
            val key = canonical.lowercase()
            if (key in setOf("ige", "covid-19", "sars-cov-2") && key in seenTail) continue
            if (key in setOf("ige", "covid-19", "sars-cov-2")) seenTail += key
            out += part
        }
        return out.joinToString(" ").replace(whitespace, " ").trim()
    }

    private fun canonicalToken(token: String): String {
        val t = token.trim().lowercase().removeSuffix("-")
        return when (t) {
            "sarscov2", "sars-cov", "sarscov", "sars-cov-2" -> "sars-cov-2"
            "covid19", "covid-19" -> "covid-19"
            else -> t
        }
    }

    private fun canonicalPhraseKey(term: String): String = sanitizeText(term).lowercase()
        .replace(Regex("[^a-z0-9]+"), " ")
        .replace(whitespace, " ")
        .trim()

    private val genericStopTokens = setOf(
        "and", "or", "the", "for", "with", "without", "into", "from", "build", "research", "only",
        "dossier", "primary", "focus", "hard", "rules", "use", "then", "continue", "reject", "demote",
        "generate", "least", "evidence", "data", "information", "pubmed", "geo", "dataset", "cohort",
        "human", "humans", "study", "studies", "review", "systematic", "analysis", "biology"
    )
}
