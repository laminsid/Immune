package com.immunesignal.app

class ResearchObjectiveExecutorV3(
    private val adapter: EvidenceAdapterV3 = NcbiEvidenceAdapterV3(),
    private val classifier: EvidenceClassifierV3 = EvidenceClassifierV3
) {
    fun execute(objective: ResearchObjectiveV3, state: ResearchStateV3): ResearchObjectiveOutcomeV3 {
        if (objective is ResearchObjectiveV3.CompileReport || objective is ResearchObjectiveV3.RankHypotheses) {
            return ResearchObjectiveOutcomeV3(
                objective = objective,
                queriesAttempted = emptyList(),
                nodes = emptyList(),
                exhausted = false,
                notes = listOf("${objective.kind}_is_internal_state_reducer_no_network_fetch")
            )
        }
        val role = roleFor(objective)
        val nodes = mutableListOf<EvidenceNodeV3>()
        val attempted = mutableListOf<String>()
        var networkCalls = 0
        var emptyQueries = 0
        val sourceFamilies = mutableMapOf<String, Int>()
        val notes = mutableListOf<String>()
        val objectiveStartedAt = System.currentTimeMillis()
        val objectiveHardLimitMs = 9_000L
        val objectiveCallLimit = state.input.budget.allowedNetworkCallsForObjective(
            role = role,
            usage = state.budgetUsage,
            snapshot = state.ledgerSnapshot
        )

        if (objectiveCallLimit <= 0) {
            return ResearchObjectiveOutcomeV3(
                objective = objective,
                queriesAttempted = emptyList(),
                nodes = emptyList(),
                exhausted = true,
                notes = listOf("objective_budget_reserve_blocked:${objective.kind}:role=${role.name}")
            )
        }

        val expandedSeeds = ResearchQueryFallbackFanoutV3.expand(objective.querySeeds(), role, state.input.topic)
        if (expandedSeeds != objective.querySeeds()) {
            notes += "adaptive_short_query_fanout_enabled:${role.name}:seeds=${expandedSeeds.size}"
        }
        val (preFilteredSeeds, preFilterSnapshot) = PreRetrievalOntologyBlacklistV30328.filter(state.input.topic, role, expandedSeeds)
        if (preFilterSnapshot.blockedQueries.isNotEmpty()) {
            notes += "pre_retrieval_blacklist_blocked:${preFilterSnapshot.blockedQueries.size}:${preFilterSnapshot.reasons.joinToString("|")}" 
        }
        val (querySeeds, dossierBiasSnapshot) = DossierLearningQueryBiasV30328.apply(state.input.topic, preFilteredSeeds, state.ledgerSnapshot)
        if (dossierBiasSnapshot.promotedSignals.isNotEmpty() || dossierBiasSnapshot.demotedSignals.isNotEmpty()) {
            notes += "dossier_learning_query_bias_applied:promoted=${dossierBiasSnapshot.promotedSignals.size}:demoted=${dossierBiasSnapshot.demotedSignals.size}"
        }

        for (query in querySeeds) {
            if (System.currentTimeMillis() - objectiveStartedAt > objectiveHardLimitMs) {
                notes += "objective_elapsed_time_cap_reached:${objective.kind}:ms=${System.currentTimeMillis() - objectiveStartedAt}"
                break
            }
            if (networkCalls >= objectiveCallLimit) {
                notes += "objective_query_reserve_reached:${objective.kind}:limit=$objectiveCallLimit"
                break
            }
            if (!state.input.budget.canStartObjective(
                    objective = objective,
                    usage = state.budgetUsage + BudgetUsageV3(networkCalls = networkCalls, emptyQueries = emptyQueries),
                    executedObjectives = state.executedObjectiveCount,
                    snapshot = state.ledgerSnapshot
                )
            ) {
                notes += "budget_capacity_reached_before_query:$query"
                break
            }
            attempted += query
            var batch = adapter.search(query, role, state)
            networkCalls += batch.networkCalls.coerceAtLeast(0)

            if (batch.isEmpty && batch.errors.isNotEmpty() && state.input.budget.retryEmptyNetworkErrorOnce && networkCalls < objectiveCallLimit) {
                notes += "retry_empty_error_query_once:$query"
                val retry = adapter.search(query, role, state)
                networkCalls += retry.networkCalls.coerceAtLeast(0)
                batch = EvidenceSearchBatchV3(
                    query = query,
                    records = if (retry.records.isNotEmpty()) retry.records else batch.records,
                    networkCalls = batch.networkCalls + retry.networkCalls,
                    errors = batch.errors + retry.errors
                )
            }

            if (batch.isEmpty) emptyQueries += 1
            batch.errors.forEach { notes += "adapter_error:$it" }
            val classified = batch.records
                .sortedWith(compareBy<EvidenceSearchRecordV3> { it.source.name }
                    .thenBy { it.accession.orEmpty() }
                    .thenBy { it.title })
                .map { record -> classifier.classify(record, role, state.input.topic, query) }
            val triaged = ResearchEvidenceTriageV3.apply(classified, role, state)

            triaged.map { it.sourceFamily }.distinct().forEach { family ->
                sourceFamilies[family] = (sourceFamilies[family] ?: 0) + 1
            }
            nodes += triaged
            val satisfiedThisQuery = triaged.any { node ->
                when (role) {
                    EvidenceRoleV3.CONTRADICTION -> node.satisfiesResearchRole(EvidenceRoleV3.CONTRADICTION) || node.satisfiesResearchRole(EvidenceRoleV3.FALSIFIER)
                    else -> node.satisfiesResearchRole(role)
                }
            }
            if (satisfiedThisQuery || ResearchEvidenceTriageV3.shouldStopObjective(nodes, role)) {
                notes += "early_stop_relevance_target_reached:${objective.kind}:nodes=${nodes.size}:networkCalls=$networkCalls"
                break
            }
            if (System.currentTimeMillis() - objectiveStartedAt > objectiveHardLimitMs) {
                notes += "objective_elapsed_time_cap_reached_after_query:${objective.kind}:ms=${System.currentTimeMillis() - objectiveStartedAt}"
                break
            }
        }

        val satisfied = nodes.any { node ->
            when (role) {
                EvidenceRoleV3.CONTRADICTION -> node.satisfiesResearchRole(EvidenceRoleV3.CONTRADICTION) || node.satisfiesResearchRole(EvidenceRoleV3.FALSIFIER)
                else -> node.satisfiesResearchRole(role)
            }
        }
        return ResearchObjectiveOutcomeV3(
            objective = objective,
            queriesAttempted = attempted,
            nodes = nodes.distinctBy { it.id },
            exhausted = !satisfied,
            budgetDelta = BudgetUsageV3(
                networkCalls = networkCalls,
                emptyQueries = emptyQueries,
                sourceFamilyCounts = sourceFamilies
            ),
            notes = notes
        )
    }

    private fun roleFor(objective: ResearchObjectiveV3): EvidenceRoleV3 = when (objective) {
        is ResearchObjectiveV3.FindSourceEvidence -> EvidenceRoleV3.SOURCE
        is ResearchObjectiveV3.FindDatasetEvidence -> EvidenceRoleV3.DATASET
        is ResearchObjectiveV3.FindProvenance -> EvidenceRoleV3.PROVENANCE
        is ResearchObjectiveV3.FindContradiction -> EvidenceRoleV3.CONTRADICTION
        is ResearchObjectiveV3.RankHypotheses -> EvidenceRoleV3.HYPOTHESIS_RANKING
        is ResearchObjectiveV3.ContinueHypothesisProof -> EvidenceRoleV3.MECHANISM
        is ResearchObjectiveV3.CompileReport -> EvidenceRoleV3.CONTEXT
    }
}
