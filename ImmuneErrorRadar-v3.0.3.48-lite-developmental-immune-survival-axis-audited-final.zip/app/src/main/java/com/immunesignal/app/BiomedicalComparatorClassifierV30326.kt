package com.immunesignal.app

/** Lightweight comparator-axis classifier for SOFT/sample titles and accession summaries. */
object BiomedicalComparatorClassifierV30326 {
    const val REQUIRED_TOKEN: String = "V30326_BIOMEDICAL_COMPARATOR_CLASSIFIER_LITE"

    data class Result(
        val caseAxis: String,
        val severityAxis: String,
        val tissueAxis: String,
        val timeAxis: String,
        val confidenceBoost: Int,
        val missing: List<String>
    )

    fun classify(text: String): Result {
        val lower = text.lowercase()
        val caseAxis = when {
            hasAny(lower, "mycn amplified vs non-mycn", "mycn-amplified", "mycn amplified", "non-mycn") -> "MYCN_amplified_vs_non_MYCN"
            hasAny(lower, "tumor vs adjacent normal", "tumor vs normal", "tumour vs normal", "matched normal") -> "tumor_vs_adjacent_normal_or_matched_control"
            hasAny(lower, "responder vs non-responder", "responder vs nonresponder", "non-responder", "nonresponder") -> "responder_vs_non_responder"
            hasAny(lower, "patient vs healthy", "healthy control", "case control", "case-control") -> "case_or_patient_vs_healthy_control"
            else -> "missing"
        }
        val severityAxis = when {
            hasAny(lower, "high-risk", "high risk", "low-risk", "low risk") -> "high_risk_vs_low_risk"
            hasAny(lower, "immune hot", "immune cold", "excluded", "inflamed") -> "immune_hot_cold_or_excluded_subtype_axis"
            hasAny(lower, "relapse", "remission", "active lesion", "inactive lesion") -> "relapse_or_activity_axis"
            hasAny(lower, "stage", "grade", "subtype", "disease activity") -> "subtype_or_activity_candidate"
            else -> "missing"
        }
        val tissueAxis = when {
            hasAny(lower, "neuroblastoma", "adrenal", "neural crest") -> "neuroblastoma_tumor_or_neural_crest_compartment"
            hasAny(lower, "tumor tissue", "tumour tissue", "single-cell", "single cell", "scrna") -> "tumor_tissue_or_single_cell_compartment_candidate"
            hasAny(lower, "pbmc", "blood", "whole-blood") -> "blood_or_pbmc_source_candidate"
            hasAny(lower, "myelin", "oligodendrocyte", "microglia", "cns") -> "cns_myelin_microglia_compartment"
            hasAny(lower, "adipose", "macrophage") -> "adipose_macrophage_compartment"
            else -> "missing"
        }
        val timeAxis = when {
            hasAny(lower, "pre-treatment", "pretreatment", "baseline", "before treatment") && hasAny(lower, "post-treatment", "posttreatment", "after treatment") -> "pre_vs_post_treatment_time_axis"
            hasAny(lower, "acute", "post-acute", "recovery", "recovered") -> "acute_vs_recovery_time_axis"
            hasAny(lower, "timepoint", "follow-up", "longitudinal") -> "timepoint_candidate"
            else -> "missing"
        }
        val missing = listOf("case/control" to caseAxis, "severity/subtype" to severityAxis, "tissue/cell source" to tissueAxis, "timepoint" to timeAxis)
            .filter { it.second == "missing" }
            .map { it.first }
        val boost = (listOf(caseAxis, severityAxis, tissueAxis, timeAxis).count { it != "missing" } * 8).coerceIn(0, 32)
        return Result(caseAxis, severityAxis, tissueAxis, timeAxis, boost, missing)
    }

    private fun hasAny(text: String, vararg needles: String): Boolean = needles.any { text.contains(it) }
}
