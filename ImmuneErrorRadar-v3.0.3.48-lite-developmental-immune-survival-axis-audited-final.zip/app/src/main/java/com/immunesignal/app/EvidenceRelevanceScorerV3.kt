package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.20 — topic/domain/dynamic-concept relevance gate.
 * Evidence is accepted only when it fits the biomedical frame, not merely because
 * it came back from a query. This is the guard against allergy reports built from
 * COVID/epilepsy papers or depression reports built from unrelated psychosocial
 * reviews.
 */
data class EvidenceRelevanceScoreV3(
    val topicMatch: Boolean,
    val mechanismMatch: Boolean,
    val diseaseCompatible: Boolean,
    val datasetPhenotypeCompatible: Boolean,
    val contradictionGrounded: Boolean,
    val limitations: List<String>
) {
    val acceptableSource: Boolean get() = topicMatch && mechanismMatch && diseaseCompatible
    val acceptableDataset: Boolean get() = topicMatch && diseaseCompatible && datasetPhenotypeCompatible
    val acceptableContradiction: Boolean get() = topicMatch && diseaseCompatible && contradictionGrounded

    fun toJson(): JSONObject = JSONObject()
        .put("topicMatch", topicMatch)
        .put("mechanismMatch", mechanismMatch)
        .put("diseaseCompatible", diseaseCompatible)
        .put("datasetPhenotypeCompatible", datasetPhenotypeCompatible)
        .put("contradictionGrounded", contradictionGrounded)
        .put("limitations", JSONArray(limitations))
}

object EvidenceRelevanceScorerV3 {
    const val REQUIRED_TOKEN: String = "V30312_EVIDENCE_RELEVANCE_SCORER_TOPIC_MECHANISM_DISEASE_DATASET"

    fun score(frame: BiomedicalTopicFrameV3, evidenceText: String, requestedRole: EvidenceRoleV3): EvidenceRelevanceScoreV3 {
        val text = evidenceText.lowercase()
        val topicMatch = domainTopicMatch(frame, text)
        val mechanismMatch = mechanismMatch(frame, text)
        val diseaseCompatible = diseaseCompatible(frame, text)
        val datasetPhenotypeCompatible = datasetPhenotypeCompatible(frame, text)
        val contradictionGrounded = contradictionGrounded(frame, text)
        val limitations = mutableListOf<String>()
        if (!topicMatch) limitations += "relevance_topic_profile_mismatch"
        if (!mechanismMatch && requestedRole == EvidenceRoleV3.SOURCE) limitations += "relevance_mechanism_axis_missing"
        if (!mechanismMatch && requestedRole in setOf(EvidenceRoleV3.CONTRADICTION, EvidenceRoleV3.FALSIFIER) && !contradictionGrounded) {
            limitations += "relevance_mechanism_axis_missing"
        }
        if (!diseaseCompatible) limitations += "relevance_disease_compatibility_failed"
        if (!datasetPhenotypeCompatible && requestedRole in setOf(EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE)) limitations += "relevance_dataset_phenotype_mismatch"
        if (!contradictionGrounded && requestedRole in setOf(EvidenceRoleV3.CONTRADICTION, EvidenceRoleV3.FALSIFIER)) limitations += "relevance_contradiction_not_tied_to_primary_hypothesis"
        return EvidenceRelevanceScoreV3(topicMatch, mechanismMatch, diseaseCompatible, datasetPhenotypeCompatible, contradictionGrounded, limitations.distinct())
    }

    private fun domainTopicMatch(frame: BiomedicalTopicFrameV3, text: String): Boolean = when (frame.domain) {
        ResearchDomainV3.COVID -> any(text, "covid", "covid-19", "sars-cov-2", "sars cov 2", "long covid", "pasc", "coronavirus")
        ResearchDomainV3.ALLERGY_TYPE2 -> any(text, "allergy", "allergies", "allergic", "atopic", "asthma", "rhinitis", "ige", "eosinophil", "mast cell", "type 2 inflammation", "il-4", "il-5", "il-13")
        ResearchDomainV3.DEPRESSION_KYNURENINE -> any(text, "depression", "depressive", "mdd", "major depressive") && any(text, "kynurenine", "tryptophan", "ido1", "kmo", "quinolinic", "kynurenic", "microglia", "neuroimmune")
        ResearchDomainV3.CANCER -> CancerHypothesisDiscoveryV30324.cancerSpecificDatasetCompatible(text) || (
            any(text, "cancer", "tumor", "tumour", "carcinoma", "oncolog", "malignan", "neoplasm", "melanoma", "leukemia", "lymphoma") &&
            any(text, "immune", "immunotherapy", "checkpoint", "cd8", "t cell", "macrophage", "treg", "tumor microenvironment", "tumour microenvironment", "tme")
        )
        ResearchDomainV3.EBOLA -> any(text, "ebola", "bundibugyo", "bdbv", "filovirus")
        ResearchDomainV3.COMPARATIVE -> comparativeMatch(frame, text)
        ResearchDomainV3.GENERAL_IMMUNE -> {
            val concepts = GenericBiomedicalConceptExtractorV3.extract(frame.rawInput)
            val diseaseTerms = concepts.aliases.flatMap { it.allDiseaseLikeTerms() } + concepts.diseaseOrExposureTerms
            val diseaseHit = diseaseTerms.any { containsPhrase(text, it.lowercase()) }
            val mechanismHit = (concepts.mechanismTerms + concepts.mediatorTerms + concepts.cellTerms + frame.allConceptTerms()).any { containsPhrase(text, it.lowercase()) }
            diseaseHit && (mechanismHit || concepts.hasMechanismAxis)
        }
    }

    private fun mechanismMatch(frame: BiomedicalTopicFrameV3, text: String): Boolean {
        val frameTerms = (frame.mechanismTerms + frame.geneOrProteinTerms + frame.cellTerms).map { it.lowercase() }
        if (frameTerms.any { text.contains(it) }) return true
        return any(text, "cytokine", "interferon", "complement", "immune dysregulation", "immune response", "immunopathogenesis", "host response", "pbmc", "transcriptome", "rna-seq", "t cell", "b cell", "macrophage", "microglia", "eosinophil", "mast cell", "ige", "checkpoint", "pd-1", "pd-l1", "ctla4", "cd8", "treg", "tumor microenvironment", "tumour microenvironment", "tme", "ifn-gamma", "hypoxia", "emt")
    }

    private fun diseaseCompatible(frame: BiomedicalTopicFrameV3, text: String): Boolean {
        if (frame.domain == ResearchDomainV3.COMPARATIVE) return comparativeMatch(frame, text)
        if (frame.diseaseTerms.isEmpty()) return false
        return frame.diseaseTerms.any { term ->
            val t = term.lowercase()
            when (t) {
                "covid-19" -> any(text, "covid", "sars-cov-2", "long covid", "pasc")
                "allergy" -> any(text, "allergy", "allergies", "allergic", "atopic", "asthma", "rhinitis", "ige", "eosinophil")
                "depression" -> any(text, "depression", "depressive", "mdd", "major depressive")
                "cancer" -> any(text, "cancer", "tumor", "tumour", "carcinoma", "oncolog", "melanoma", "leukemia", "lymphoma")
                else -> {
                    val concepts = GenericBiomedicalConceptExtractorV3.extract(frame.rawInput)
                    val aliases = concepts.aliases.flatMap { it.allDiseaseLikeTerms() }.map { it.lowercase() }
                    containsPhrase(text, t) || aliases.any { containsPhrase(text, it) }
                }
            }
        }
    }

    private fun datasetPhenotypeCompatible(frame: BiomedicalTopicFrameV3, text: String): Boolean {
        if (!domainTopicMatch(frame, text)) return false
        if (any(text, "platform annotation", "affymetrix human genome", "array platform", "gpl")) return false
        val hasDatasetStructure = any(text, "dataset", "gse", "geo", "transcriptome", "rna-seq", "single-cell", "single cell", "cohort", "sample", "samples", "patients", "controls", "healthy control", "phenotype", "expression profiling", "proteomics")
        if (!hasDatasetStructure) return false
        return when (frame.domain) {
            ResearchDomainV3.ALLERGY_TYPE2 -> hasAllergyPhenotypeCue(text) && !hasIncompatibleAllergyDatasetDrift(text)
            ResearchDomainV3.COVID -> any(text, "covid", "sars-cov-2", "sars cov 2", "long covid", "pasc", "coronavirus")
            ResearchDomainV3.DEPRESSION_KYNURENINE -> any(text, "depression", "depressive", "mdd", "major depressive") && any(text, "kynurenine", "tryptophan", "ido1", "kmo", "quinolinic", "kynurenic", "neuroimmune", "microglia")
            ResearchDomainV3.CANCER -> CancerHypothesisDiscoveryV30324.cancerSpecificDatasetCompatible(text)
            ResearchDomainV3.COMPARATIVE -> comparativeDatasetPhenotypeCompatible(frame, text)
            else -> true
        }
    }

    private fun hasAllergyPhenotypeCue(text: String): Boolean = any(
        text,
        "allergy", "allergies", "allergic", "atopic", "atopy", "asthma", "rhinitis", "dermatitis",
        "ige", "eosinophil", "mast cell", "type 2 inflammation", "type-2 inflammation", "il-4", "il-5", "il-13"
    )

    private fun hasIncompatibleAllergyDatasetDrift(text: String): Boolean {
        val incompatible = any(text, "renal ischemia", "ischemia-reperfusion", "kidney injury", "renal protection", "neurodegenerative", "breast cancer", "tumor", "tumour", "covid", "sars-cov-2")
        return incompatible && !hasAllergyPhenotypeCue(text)
    }

    private fun comparativeDatasetPhenotypeCompatible(frame: BiomedicalTopicFrameV3, text: String): Boolean {
        val sides = ResearchTopicNormalizerV3.splitComparativeTerms(frame.rawInput).map { BiomedicalTopicFrameV3.from(it) }.take(2)
        if (sides.size < 2) return false
        val sideMatches = sides.count { side -> domainTopicMatch(side, text) || side.diseaseTerms.any { text.contains(it.lowercase()) } || side.mechanismTerms.any { text.contains(it.lowercase()) } }
        val bridgeCue = any(text, "immune", "cytokine", "interferon", "inflammation", "transcriptome", "pbmc", "cohort", "comparison", "shared pathway")
        return sideMatches >= 1 && bridgeCue
    }

    private fun contradictionGrounded(frame: BiomedicalTopicFrameV3, text: String): Boolean {
        val strictFalsifier = any(text, "negative control", "no association", "not associated", "failed to replicate", "does not support", "does not confirm", "null association", "absence of association", "falsification study", "falsification", "refutes", "does not replicate")
        val legacyLimitationFalsifier = frame.domain == ResearchDomainV3.EBOLA && any(text, "limitation", "tissue specificity limitation", "comparator limitation")
        val study = any(text, "cohort", "case-control", "transcriptome", "rna-seq", "dataset", "sample", "patients", "human", "pbmc", "tissue", "controls", "study", "healthy control")
        return domainTopicMatch(frame, text) && (strictFalsifier || legacyLimitationFalsifier) && study
    }

    private fun comparativeMatch(frame: BiomedicalTopicFrameV3, text: String): Boolean {
        val sides = ResearchTopicNormalizerV3.splitComparativeTerms(frame.rawInput).map { BiomedicalTopicFrameV3.from(it) }.take(2)
        if (sides.size < 2) return false
        val sideMatches = sides.count { side ->
            domainTopicMatch(side, text) ||
                side.diseaseTerms.any { text.contains(it.lowercase()) } ||
                side.mechanismTerms.any { text.contains(it.lowercase()) } ||
                side.allConceptTerms().any { it.length >= 4 && text.contains(it.lowercase()) }
        }
        val bridgeCue = any(text, "immune", "cytokine", "interferon", "inflammation", "type 2", "ige", "eosinophil", "mast cell", "transcriptome", "pbmc", "cohort", "comparison", "shared pathway", "immunosenescence", "inflammaging")
        return sideMatches >= 2 || (sideMatches >= 1 && bridgeCue)
    }

    private fun containsPhrase(text: String, term: String): Boolean {
        val t = term.trim().lowercase()
        if (t.isBlank()) return false
        return if (t.length <= 3) {
            Regex("(?i)(^|[^a-z0-9])${Regex.escape(t)}([^a-z0-9]|$)").containsMatchIn(text)
        } else {
            text.contains(t)
        }
    }

    private fun any(text: String, vararg terms: String): Boolean = terms.any { containsPhrase(text, it.lowercase()) }
}
