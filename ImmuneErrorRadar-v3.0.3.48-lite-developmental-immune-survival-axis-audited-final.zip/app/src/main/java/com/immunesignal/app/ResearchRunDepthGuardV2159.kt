package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.15.9 — research-depth guard.
 *
 * v2.15.8 fixed proof-gate tests and release hygiene, but the interactive mobile
 * runtime could still complete in roughly ten seconds when NCBI returned small
 * handle lists quickly. That is safe for ANR, but too shallow for a professional
 * research dossier. This guard separates proof handles exist from the run had
 * enough elapsed research depth to be user-facing as REPORT_READY.
 */
object ResearchRunDepthGuardV2159 {
    const val VERSION: String = "2.17.2-research-depth-independent-evidence-gate"
    const val REQUIRED_TOKEN: String = "V2172_DEPTH_GUARD_REQUIRES_INDEPENDENT_REVIEWABLE_EVIDENCE"
    const val LEGACY_REQUIRED_TOKEN_V2161: String = "V2161_DEPTH_GUARD_REQUIRES_REVIEWABLE_VISIBLE_EVIDENCE"
    const val LEGACY_REQUIRED_TOKEN_V21591: String = "V2159_1_DEPTH_GUARD_NEVER_BYPASSES_PROOF_GATE"
    const val LEGACY_REQUIRED_TOKEN_V2159: String = "V2159_FAST_CLOSE_PREVENTED_RESEARCH_DEPTH_REQUIRED"

    private val finalVerificationTaskIds = listOf(
        "T4_SOURCE_HANDLES",
        "T5_METADATA_PROVENANCE",
        "T7_CONTRADICTION_FALSIFICATION",
        "T8_MECHANISM_LINKAGE",
        "T9_HYPOTHESIS_RANKING"
    )

    fun finalVerificationTasks(): List<String> = finalVerificationTaskIds

    fun distinctPositiveHandles(handles: List<String>): List<String> = handles
        .filter { handle ->
            ResearchEvidenceGateV2156.isPositiveSourceHandle(handle) ||
                ResearchEvidenceGateV2156.isPositiveProvenanceHandle(handle) ||
                ResearchEvidenceGateV2156.isPositiveContradictionHandle(handle) ||
                ResearchEvidenceGateV2156.isPositiveMechanismHandle(handle)
        }
        .distinct()

    fun evaluate(
        contract: ResearchRunContractV2150,
        elapsedMillis: Long,
        policy: ResearchExecutionPolicyV2154.Policy
    ): DepthState {
        val proofContract = ResearchProofContractV2160.fromContract(contract)
        val positive = proofContract.displayedEvidenceLines()
        val minElapsed = if (policy.interactive && policy.enableResearchDepthGuard) policy.minInteractiveRunMillis else 0L
        val minHandles = if (policy.enableResearchDepthGuard) policy.minPositiveEvidenceHandlesForReport.coerceAtLeast(3) else 0
        val elapsedReady = elapsedMillis >= minElapsed
        val handleDepthReady = positive.size >= minHandles
        val gateClosed = ResearchExecutionPolicyV2154.reportCanClose(contract) && proofContract.countedEqualsDisplayed() && ResearchVisibleEvidenceAuditV2161.isReportReadyEligible(contract) && ResearchEvidenceDiversityAuditV2172.isReportReadyEligible(contract)
        val active = policy.enableResearchDepthGuard && policy.interactive
        // Depth guard may be inactive for tests/non-interactive runs, but the mandatory
        // proof gate must never be bypassed. v2.15.9.1 fixes the v2.15.9 regression
        // where !active made reportEligibleAfterDepth true even when source/provenance/
        // contradiction proof was still open.
        val ready = gateClosed && (!active || (elapsedReady && handleDepthReady))
        val reasons = mutableListOf<String>()
        if (active && !elapsedReady) reasons += "elapsed_below_minimum_${minElapsed}ms"
        if (active && !handleDepthReady) reasons += "positive_handle_depth_below_${minHandles}"
        if (!gateClosed) reasons += "mandatory_proof_gate_open"
        if (reasons.isEmpty()) reasons += "research_depth_ready"
        return DepthState(
            active = active,
            elapsedMillis = elapsedMillis,
            minimumElapsedMillis = minElapsed,
            positiveHandleCount = positive.size,
            minimumPositiveHandleCount = minHandles,
            gateClosed = gateClosed,
            elapsedReady = elapsedReady,
            handleDepthReady = handleDepthReady,
            reportEligibleAfterDepth = ready,
            fastClosePrevented = active && gateClosed && !ready,
            reasons = reasons,
            samplePositiveHandles = positive.take(12)
        )
    }

    fun reportCanClose(
        contract: ResearchRunContractV2150,
        elapsedMillis: Long,
        policy: ResearchExecutionPolicyV2154.Policy
    ): Boolean = evaluate(contract, elapsedMillis, policy).reportEligibleAfterDepth

    data class DepthState(
        val active: Boolean,
        val elapsedMillis: Long,
        val minimumElapsedMillis: Long,
        val positiveHandleCount: Int,
        val minimumPositiveHandleCount: Int,
        val gateClosed: Boolean,
        val elapsedReady: Boolean,
        val handleDepthReady: Boolean,
        val reportEligibleAfterDepth: Boolean,
        val fastClosePrevented: Boolean,
        val reasons: List<String>,
        val samplePositiveHandles: List<String>
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("version", VERSION)
            .put("requiredToken", REQUIRED_TOKEN)
            .put("active", active)
            .put("elapsedMillis", elapsedMillis)
            .put("minimumElapsedMillis", minimumElapsedMillis)
            .put("positiveHandleCount", positiveHandleCount)
            .put("minimumPositiveHandleCount", minimumPositiveHandleCount)
            .put("gateClosed", gateClosed)
            .put("elapsedReady", elapsedReady)
            .put("handleDepthReady", handleDepthReady)
            .put("reportEligibleAfterDepth", reportEligibleAfterDepth)
            .put("fastClosePrevented", fastClosePrevented)
            .put("reasons", JSONArray(reasons))
            .put("samplePositiveHandles", JSONArray(samplePositiveHandles))
            .put("visibleEvidenceRule", ResearchProofContractV2160.REQUIRED_TOKEN)
            .put("reviewableEvidenceRule", ResearchVisibleEvidenceAuditV2161.REQUIRED_TOKEN)
            .put("independentEvidenceRule", ResearchEvidenceDiversityAuditV2172.REQUIRED_TOKEN)
    }
}
