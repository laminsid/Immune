package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * Turns the proof loop into an execution program. It uses already-executed V3
 * objectives and the current report artifacts to push each hypothesis as far as
 * the bounded mobile budget allows. It does not add hard strictness or clinical
 * claims; it records the last proof stage reached and the next executable step.
 */
data class HypothesisProofExecutionSnapshotV30328(
    val active: Boolean,
    val state: String,
    val lastExecutedStage: String,
    val completedStages: List<String>,
    val pendingStages: List<String>,
    val executionDepth: Int,
    val nextExecutableAction: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("active", active)
        .put("state", state)
        .put("lastExecutedStage", lastExecutedStage)
        .put("completedStages", JSONArray(completedStages))
        .put("pendingStages", JSONArray(pendingStages))
        .put("executionDepth", executionDepth)
        .put("nextExecutableAction", nextExecutableAction)
}

object HypothesisProofExecutorV30328 {
    const val REQUIRED_TOKEN: String = "V30328_HYPOTHESIS_PROOF_EXECUTOR_NOT_SUGGESTION_ONLY"

    fun evaluate(
        state: ResearchStateV3,
        proofContinuation: ResearchHypothesisProofContinuationSnapshotV3,
        mechanismSignal: MechanismModuleSignalSnapshotV30328
    ): HypothesisProofExecutionSnapshotV30328 {
        val stages = proofContinuation.proofStages
        val completed = stages.filter { it.completed }.map { it.id }
        val pending = stages.filterNot { it.completed }.map { it.id }
        val last = completed.lastOrNull() ?: "NONE"
        val depth = (completed.size * 100 / stages.size.coerceAtLeast(1)).coerceIn(0, 100)
        val stateName = when {
            !proofContinuation.executed -> "PROOF_EXECUTION_PENDING"
            mechanismSignal.state == "MODULE_SIGNAL_SUPPORTED_REVIEW_ONLY" -> "PROOF_EXECUTED_TO_MODULE_SIGNAL_REVIEW"
            mechanismSignal.state.contains("CANDIDATE") -> "PROOF_EXECUTED_TO_EXPRESSION_CANDIDATE"
            completed.contains("COMPARATOR_LABELS") -> "PROOF_EXECUTED_TO_COMPARATOR_REVIEW"
            else -> "PROOF_EXECUTED_TO_CURRENT_BUDGET_LIMIT"
        }
        val next = when {
            pending.contains("COMPARATOR_LABELS") -> "Execute metadata comparator extraction for the active accession before any score upgrade."
            pending.contains("PROCESSED_EXPRESSION_ROUTE") -> "Verify processed-expression/matrix route and sample-to-comparator linkage."
            pending.contains("MECHANISM_SUPPORT") -> mechanismSignal.nextAction
            pending.contains("EXACT_AXIS_FALSIFIER") -> "Run strict same-axis null/no-association falsifier search."
            else -> "All proof stages reached review-only state; compile research-only final route."
        }
        return HypothesisProofExecutionSnapshotV30328(
            active = true,
            state = stateName,
            lastExecutedStage = last,
            completedStages = completed,
            pendingStages = pending,
            executionDepth = depth,
            nextExecutableAction = next
        )
    }
}
