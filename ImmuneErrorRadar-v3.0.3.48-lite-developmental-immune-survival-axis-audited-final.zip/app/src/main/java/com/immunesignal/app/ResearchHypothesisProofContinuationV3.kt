package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.23-p9 — hypothesis proof continuation finalization.
 *
 * A generated H1/H2 is not the end of the run. After hypothesis ranking, V3 opens
 * a bounded proof program that tries to strengthen or weaken the hypothesis by
 * checking four review-only proof routes: comparator labels, processed-expression
 * or matrix linkage, tissue/cell-state mechanism evidence, and exact-axis
 * falsifier handling. The output remains research-only and never claims
 * biological proof, diagnosis, treatment, dosing, or clinical action.
 */
data class ResearchHypothesisProofStageV3(
    val id: String,
    val state: String,
    val completed: Boolean,
    val evidence: List<String>,
    val nextAction: String
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("state", state)
        .put("completed", completed)
        .put("evidence", JSONArray(evidence))
        .put("nextAction", nextAction)
}

data class ResearchHypothesisProofContinuationSnapshotV3(
    val active: Boolean,
    val state: String,
    val executed: Boolean,
    val queriesAttempted: List<String>,
    val evidenceIds: List<String>,
    val nextProofObjective: String,
    val proofMeaning: String,
    val proofStages: List<ResearchHypothesisProofStageV3> = emptyList(),
    val proofCompletionScore: Int = 0,
    val evidenceUpgradeState: String = "PROOF_PROGRAM_NOT_EVALUATED",
    val canAttemptUpgrade: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject()
        .put("active", active)
        .put("state", state)
        .put("executed", executed)
        .put("queriesAttempted", JSONArray(queriesAttempted))
        .put("evidenceIds", JSONArray(evidenceIds))
        .put("nextProofObjective", nextProofObjective)
        .put("proofMeaning", proofMeaning)
        .put("proofStages", JSONArray(proofStages.map { it.toJson() }))
        .put("proofCompletionScore", proofCompletionScore)
        .put("evidenceUpgradeState", evidenceUpgradeState)
        .put("canAttemptUpgrade", canAttemptUpgrade)
}

object ResearchHypothesisProofContinuationV3 {
    const val REQUIRED_TOKEN: String = "V30323_HYPOTHESIS_PROOF_CONTINUES_AFTER_GENERATION"
    const val FINAL_TOKEN: String = "V30323_HYPOTHESIS_PROOF_PROGRAM_COMPARATOR_EXPRESSION_FALSIFIER"

    fun evaluate(state: ResearchStateV3): ResearchHypothesisProofContinuationSnapshotV3 {
        val outcome = state.ledgerSnapshot.objectiveOutcomes.firstOrNull { it.objective is ResearchObjectiveV3.ContinueHypothesisProof }
        val proofEvidence = outcome?.nodes.orEmpty()
            .filter { it.role in setOf(EvidenceRoleV3.MECHANISM, EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE, EvidenceRoleV3.CONTRADICTION, EvidenceRoleV3.FALSIFIER) }
            .filter { it.qualityTier.isAtLeast(state.input.budget.minimumEvidenceQuality) }
        val metadataProbe = ResearchMetadataProbeIngestionV3.evaluate(state)
        val comparatorRoutes = DatasetComparatorLabelExtractorV3.extract(metadataProbe)
        val expressionRoutes = ProcessedExpressionRouteVerifierV3.verify(metadataProbe, comparatorRoutes)
        val contradictionState = ResearchContradictionClosureV3.evaluate(state.ledgerSnapshot, state.input.budget.minimumEvidenceQuality)
        val stages = buildStages(state, outcome, proofEvidence, comparatorRoutes, expressionRoutes, contradictionState)
        val completedStages = stages.count { it.completed }
        val proofCompletionScore = ((completedStages.toDouble() / stages.size.coerceAtLeast(1).toDouble()) * 100.0).toInt().coerceIn(0, 100)
        val canAttemptUpgrade = stages.any { it.id == "COMPARATOR_LABELS" && it.completed } &&
            stages.any { it.id == "PROCESSED_EXPRESSION_ROUTE" && it.completed } &&
            stages.any { it.id == "EXACT_AXIS_FALSIFIER" && it.completed }
        val stateName = when {
            outcome == null -> "PROOF_CONTINUATION_PENDING"
            canAttemptUpgrade && proofEvidence.isNotEmpty() -> "PROOF_CONTINUATION_READY_FOR_EVIDENCE_UPGRADE_REVIEW_ONLY"
            proofEvidence.isNotEmpty() -> "PROOF_CONTINUATION_EVIDENCE_FOUND_REVIEW_ONLY"
            outcome.exhausted -> "PROOF_CONTINUATION_EXECUTED_NO_UPGRADE_YET"
            else -> "PROOF_CONTINUATION_EXECUTED_REVIEW_ONLY"
        }
        val evidenceUpgradeState = when {
            canAttemptUpgrade -> "EVIDENCE_UPGRADE_ROUTE_OPEN_REVIEW_ONLY"
            outcome == null -> "EVIDENCE_UPGRADE_WAITING_FOR_PROOF_OBJECTIVE"
            else -> "EVIDENCE_UPGRADE_NEEDS_MISSING_PROOF_STAGES"
        }
        val next = when (stateName) {
            "PROOF_CONTINUATION_PENDING" -> "Run ContinueHypothesisProof before final compilation."
            "PROOF_CONTINUATION_READY_FOR_EVIDENCE_UPGRADE_REVIEW_ONLY" -> "Review comparator labels and expression-route linkage, then run module-signal review; no clinical claim."
            "PROOF_CONTINUATION_EVIDENCE_FOUND_REVIEW_ONLY" -> "Link proof-continuation evidence to comparator labels, expression route, or exact falsifier axis."
            "PROOF_CONTINUATION_EXECUTED_NO_UPGRADE_YET" -> stages.firstOrNull { !it.completed }?.nextAction ?: "Refine disease+tissue+mechanism proof queries; do not stop at H1/H2 text."
            else -> "Continue proof loop if evidence target score remains below 10/10."
        }
        return ResearchHypothesisProofContinuationSnapshotV3(
            active = true,
            state = stateName,
            executed = outcome != null,
            queriesAttempted = outcome?.queriesAttempted.orEmpty().take(6),
            evidenceIds = proofEvidence.map { it.accession?.ifBlank { null } ?: it.id }.distinct().take(8),
            nextProofObjective = next,
            proofMeaning = "Hypotheses are treated as research targets: the engine continues evidence acquisition after generation instead of only ranking them.",
            proofStages = stages,
            proofCompletionScore = proofCompletionScore,
            evidenceUpgradeState = evidenceUpgradeState,
            canAttemptUpgrade = canAttemptUpgrade
        )
    }

    private fun buildStages(
        state: ResearchStateV3,
        outcome: ResearchObjectiveOutcomeV3?,
        proofEvidence: List<EvidenceNodeV3>,
        comparatorRoutes: List<ResearchComparatorLabelRouteV3>,
        expressionRoutes: List<ResearchProcessedExpressionRouteV3>,
        contradictionState: ResearchContradictionClosureStateV3
    ): List<ResearchHypothesisProofStageV3> {
        val rankDone = state.ledgerSnapshot.objectiveExecuted("rank:")
        val proofDone = outcome != null
        val bestComparator = comparatorRoutes.maxByOrNull { it.confidence }
        val bestExpression = expressionRoutes.maxByOrNull { it.confidence }
        val mechanismIds = proofEvidence
            .filter { it.role == EvidenceRoleV3.MECHANISM }
            .map { it.accession?.ifBlank { null } ?: it.id }
            .distinct()
            .take(4)
        val falsifierCompleted = contradictionState.attempted && (contradictionState.exhausted || contradictionState.found)
        return listOf(
            ResearchHypothesisProofStageV3(
                id = "HYPOTHESIS_GENERATED",
                state = if (rankDone) "HYPOTHESIS_RANKING_EXECUTED" else "HYPOTHESIS_RANKING_PENDING",
                completed = rankDone,
                evidence = state.ledgerSnapshot.executedObjectiveIds.filter { it.startsWith("rank:") }.take(2),
                nextAction = "Generate and rank H1/H2 before proof continuation."
            ),
            ResearchHypothesisProofStageV3(
                id = "PROOF_OBJECTIVE_EXECUTED",
                state = if (proofDone) "CONTINUE_HYPOTHESIS_PROOF_EXECUTED" else "CONTINUE_HYPOTHESIS_PROOF_PENDING",
                completed = proofDone,
                evidence = outcome?.queriesAttempted.orEmpty().take(3),
                nextAction = "Run ContinueHypothesisProof with comparator/expression/mechanism/falsifier queries."
            ),
            ResearchHypothesisProofStageV3(
                id = "COMPARATOR_LABELS",
                state = bestComparator?.state ?: "COMPARATOR_LABELS_NOT_AVAILABLE",
                completed = bestComparator?.state?.contains("READY", ignoreCase = true) == true || bestComparator?.state?.contains("PARTIAL", ignoreCase = true) == true,
                evidence = listOfNotNull(bestComparator?.accession, bestComparator?.caseControlAxis, bestComparator?.severityOrSubtypeAxis).filter { it != "missing" }.take(4),
                nextAction = "Extract case/control, severity/subtype, tissue/cell source, and timepoint labels from SOFT/sample metadata."
            ),
            ResearchHypothesisProofStageV3(
                id = "PROCESSED_EXPRESSION_ROUTE",
                state = bestExpression?.state ?: "EXPRESSION_ROUTE_NOT_AVAILABLE",
                completed = bestExpression?.state?.contains("CANDIDATE", ignoreCase = true) == true || bestExpression?.state?.contains("VERIFIED", ignoreCase = true) == true,
                evidence = listOfNotNull(bestExpression?.accession, bestExpression?.routeType).take(4),
                nextAction = "Verify processed-expression/matrix route and sample-to-comparator linkage before module upgrade."
            ),
            ResearchHypothesisProofStageV3(
                id = "MECHANISM_SUPPORT",
                state = if (mechanismIds.isNotEmpty()) "MECHANISM_EVIDENCE_FOUND_REVIEW_ONLY" else "MECHANISM_EVIDENCE_NOT_FOUND_YET",
                completed = mechanismIds.isNotEmpty(),
                evidence = mechanismIds,
                nextAction = "Acquire disease+tissue+cell-state mechanism support tied to the exact hypothesis axis."
            ),
            ResearchHypothesisProofStageV3(
                id = "EXACT_AXIS_FALSIFIER",
                state = contradictionState.status,
                completed = falsifierCompleted,
                evidence = state.ledgerSnapshot.visibleEvidence
                    .filter { it.role in setOf(EvidenceRoleV3.CONTRADICTION, EvidenceRoleV3.FALSIFIER) }
                    .map { it.accession?.ifBlank { null } ?: it.id }
                    .distinct()
                    .take(4),
                nextAction = "Run strict null/no-association search against the same disease+tissue+comparator axis."
            )
        )
    }
}
