package com.immunesignal.app

/** Lightweight consensus map used only to lower novelty when a hypothesis restates a
 * well-known axis. It is not evidence and never upgrades support. */
object ConsensusKnowledgePackV30331 {
    const val REQUIRED_TOKEN: String = "V30331_CONSENSUS_KNOWLEDGE_PACK_NOVELTY_PENALTY_ACTIVE"

    fun penalty(topic: String, signals: List<String>, evidenceText: String): Pair<Int, List<String>> {
        val lower = (topic + " " + evidenceText + " " + signals.joinToString(" ")).lowercase()
        val hits = linkedSetOf<String>()
        fun hit(name: String, vararg terms: String) { if (terms.all { lower.contains(it) }) hits += name }
        hit("cancer_cd8_exhaustion_checkpoint_consensus", "cd8", "checkpoint")
        hit("cancer_treg_tam_hypoxia_tme_consensus", "tumor", "treg")
        hit("ms_ifn_beta_myelin_il17_consensus", "multiple sclerosis", "ifn")
        hit("ms_myelin_bcell_consensus", "myelin", "b cell")
        hit("ra_tnf_il6_il17_synovium_consensus", "rheumatoid", "tnf")
        hit("ra_synovial_macrophage_fibroblast_consensus", "synovial", "macrophage")
        hit("neuroblastoma_mycn_immune_cold_consensus", "neuroblastoma", "mycn")
        hit("alzheimer_microglia_complement_consensus", "alzheimer", "microglia")
        hit("diabetes_adipose_tnf_il6_consensus", "diabetes", "adipose")
        val penalty = (hits.size * 14).coerceAtMost(56)
        return penalty to hits.toList()
    }
}
