package com.immunesignal.app

object NullToNovelHypothesisEngineV30340 {
    const val REQUIRED_TOKEN: String = "V30340_NULL_TO_NOVEL_HYPOTHESIS_ENGINE"

    fun generate(
        truth: HumanPediatricMatrixTruthSnapshotV30339,
        evidenceRoles: List<HumanPediatricEvidenceRoleAssignmentV30340>
    ): List<GeneratedPediatricHypothesisV30339> {
        if (!truth.active) return emptyList()
        val base = truth.generatedHypotheses
        val hasSingleCell = evidenceRoles.any { it.sourceRole in setOf("HUMAN_SINGLE_CELL_COMPARTMENT_CONTEXT", "HUMAN_SINGLE_CELL_COMPARTMENT_ROUTE") }
        val hasMouseOnlyTme = evidenceRoles.any { it.sourceRole == "MODEL_ORGANISM_CONTEXT_ONLY" }
        val nullAware = listOf(
            GeneratedPediatricHypothesisV30339(
                id = "H5_REPLICATION_FIRST_HUMAN_SUBGROUP_SPLIT",
                rank = 5,
                hypothesis = "The immediate discovery target is not the known MYCN-high immune-cold claim, but a human-replicated subgroup split inside MYCN-amplified neuroblastoma: cytotoxic-low/GD2-B7H3-high versus cytotoxic-preserved tumors.",
                whyNew = "It uses the current null/non-significant GSE85047 result to reject a simple one-axis MYCN story and demands subgroup structure before mechanism claims.",
                requiredTest = "Attach GSE49710 or TARGET-NBL sample-level rows with MYCN/risk labels; test CD8/NK, GD2 biosynthesis, B7-H3/CD276, antigen-presentation, hypoxia/stroma modules in the same direction as GSE85047.",
                currentEvidenceState = truth.nullResultState,
                priority = "HIGHEST_NEXT_DISCOVERY_TEST"
            ),
            GeneratedPediatricHypothesisV30339(
                id = "H6_HUMAN_SC_COMPARTMENT_FALSIFIER",
                rank = 6,
                hypothesis = "If bulk GSE85047 remains null, the decisive falsifier is human single-cell compartment routing: MYCN-related immune exclusion must localize to tumor-neighboring T/NK, myeloid, stromal, endothelial or trajectory-phase compartments rather than whole-tumor bulk averages.",
                whyNew = if (hasSingleCell) "A human scRNA compartment route is visible as COMPARTMENT_ROUTE_READY_NOT_NUMERIC_DGE but not yet converted into expression rows." else "It specifies what data would rescue or falsify the bulk null without treating model-organism evidence as proof.",
                requiredTest = "Use EGAD00001009766 or another human pediatric scRNA/spatial matrix with cell-type labels and MYCN/risk metadata; compare compartment-resolved cytotoxic and suppressive modules.",
                currentEvidenceState = if (hasMouseOnlyTme) "MODEL_CONTEXT_PRESENT_BUT_HUMAN_COMPARTMENT_ROWS_REQUIRED" else "HUMAN_COMPARTMENT_ROWS_REQUIRED",
                priority = "MECHANISM_GATE"
            )
        )
        return (base + nullAware).distinctBy { it.id }.sortedBy { it.rank }
    }
}
