package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.16.0 — visible proof contract.
 *
 * This contract fixes Phantom Evidence Depth: a runtime may only count evidence
 * that can be displayed back to the user. A generic internal marker, a no-hit,
 * a local-memory route, or a "checked" token is not enough to close a final
 * research report. Counted evidence must equal displayed evidence.
 */
object ResearchProofContractV2160 {
    const val VERSION: String = "2.17.0-visible-proof-contract-with-evidence-details"
    const val REQUIRED_TOKEN: String = "V2170_COUNTED_DISPLAYED_EVIDENCE_INCLUDES_REVIEWABLE_DETAILS"
    const val LEGACY_REQUIRED_TOKEN_V2160: String = "V2160_COUNTED_EVIDENCE_MUST_BE_DISPLAYED"

    data class SourceHandle(
        val accession: String,
        val source: String,
        val rawMarker: String,
        val label: String
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("accession", accession)
            .put("source", source)
            .put("rawMarker", rawMarker)
            .put("label", label)
    }

    data class ProvenanceHandle(
        val label: String,
        val source: String,
        val rawMarker: String
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("label", label)
            .put("source", source)
            .put("rawMarker", rawMarker)
    }

    data class ContradictionHandle(
        val evidence: String,
        val source: String,
        val rawMarker: String
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("evidence", evidence)
            .put("source", source)
            .put("rawMarker", rawMarker)
    }

    data class MechanismHandle(
        val label: String,
        val source: String,
        val rawMarker: String
    ) {
        fun toJson(): JSONObject = JSONObject()
            .put("label", label)
            .put("source", source)
            .put("rawMarker", rawMarker)
    }

    data class Contract(
        val queryId: String,
        val sourceHandles: List<SourceHandle>,
        val provenanceHandles: List<ProvenanceHandle>,
        val contradictionHandles: List<ContradictionHandle>,
        val mechanismHandles: List<MechanismHandle>,
        val gapMarkers: List<String>
    ) {
        val hasVisibleSource: Boolean get() = sourceHandles.isNotEmpty()
        val hasVisibleProvenance: Boolean get() = provenanceHandles.isNotEmpty()
        val hasVisibleContradiction: Boolean get() = contradictionHandles.isNotEmpty()

        /** Strict v2.16 production closure: source + provenance + falsifier/contradiction must all be visible. */
        fun isClosed(): Boolean = hasVisibleSource && hasVisibleProvenance && hasVisibleContradiction

        fun visibleEvidenceCount(): Int =
            sourceHandles.size + provenanceHandles.size + contradictionHandles.size + mechanismHandles.size

        fun mandatoryVisibleEvidenceCount(): Int =
            sourceHandles.size + provenanceHandles.size + contradictionHandles.size

        fun displayedEvidenceLines(): List<String> {
            val lines = mutableListOf<String>()
            sourceHandles.forEachIndexed { index, handle ->
                val label = if (handle.label.isNotBlank() && handle.label != handle.accession) " — ${handle.label}" else ""
                lines += "SOURCE-%02d: %s%s (%s)".format(index + 1, handle.accession, label.take(140), handle.source)
            }
            provenanceHandles.forEachIndexed { index, handle ->
                lines += "PROVENANCE-%02d: %s (%s)".format(index + 1, handle.label.take(160), handle.source)
            }
            contradictionHandles.forEachIndexed { index, handle ->
                lines += "CONTRADICTION-%02d: %s (%s)".format(index + 1, handle.evidence.take(160), handle.source)
            }
            mechanismHandles.forEachIndexed { index, handle ->
                lines += "MECHANISM-%02d: %s (%s)".format(index + 1, handle.label.take(160), handle.source)
            }
            return lines
        }

        fun displayedEvidenceLineCount(): Int = displayedEvidenceLines().size

        fun countedEqualsDisplayed(): Boolean = visibleEvidenceCount() == displayedEvidenceLineCount()

        fun toJson(): JSONObject = JSONObject()
            .put("version", VERSION)
            .put("requiredToken", REQUIRED_TOKEN)
            .put("queryId", queryId)
            .put("closed", isClosed())
            .put("hasVisibleSource", hasVisibleSource)
            .put("hasVisibleProvenance", hasVisibleProvenance)
            .put("hasVisibleContradiction", hasVisibleContradiction)
            .put("visibleEvidenceCount", visibleEvidenceCount())
            .put("mandatoryVisibleEvidenceCount", mandatoryVisibleEvidenceCount())
            .put("displayedEvidenceLineCount", displayedEvidenceLineCount())
            .put("countedEqualsDisplayed", countedEqualsDisplayed())
            .put("visibleEvidenceAuditV2161", ResearchVisibleEvidenceAuditV2161.evaluate(this).toJson())
            .put("sourceHandles", JSONArray(sourceHandles.map { it.toJson() }))
            .put("provenanceHandles", JSONArray(provenanceHandles.map { it.toJson() }))
            .put("contradictionHandles", JSONArray(contradictionHandles.map { it.toJson() }))
            .put("mechanismHandles", JSONArray(mechanismHandles.map { it.toJson() }))
            .put("displayedEvidenceLines", JSONArray(displayedEvidenceLines()))
            .put("gapMarkers", JSONArray(gapMarkers.take(40)))
            .put("rule", "counted evidence must be displayed evidence; local memory/no-hit/planning markers cannot close REPORT_READY")
    }

    fun fromContract(contract: ResearchRunContractV2150): Contract = fromHandles(contract.topic, contract.evidenceHandles)

    fun fromHandles(queryId: String, handles: List<String>): Contract {
        val distinct = handles.distinct()
        val gaps = distinct.filter { ResearchEvidenceGateV2156.isNegativeOrPlanningMarker(it) }
        val sources = distinct.mapNotNull { toSourceHandle(it) }
        val provenance = distinct.mapNotNull { toProvenanceHandle(it) }
        val contradiction = distinct.mapNotNull { toContradictionHandle(it) }
        val mechanism = distinct.mapNotNull { toMechanismHandle(it) }
        return Contract(
            queryId = queryId.ifBlank { "research query" },
            sourceHandles = sources,
            provenanceHandles = provenance,
            contradictionHandles = contradiction,
            mechanismHandles = mechanism,
            gapMarkers = gaps
        )
    }

    private fun toSourceHandle(raw: String): SourceHandle? {
        if (!ResearchEvidenceGateV2156.isPositiveSourceHandle(raw)) return null
        val h = raw.lowercase()
        return when {
            h.startsWith("source_handle_closed_pubmed_") -> {
                val id = Regex("source_handle_closed_pubmed_(\\d+)", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1)
                    ?: raw.substringAfter("source_handle_closed_pubmed_").substringBefore("__").ifBlank { raw }
                SourceHandle(accession = id, source = "PubMed", rawMarker = raw, label = markerTitle(raw).ifBlank { "PubMed source handle $id" })
            }
            h.startsWith("dataset_verified_gds_") -> {
                val id = Regex("dataset_verified_gds_([A-Za-z0-9_-]+)", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1)
                    ?: raw.substringAfter("dataset_verified_gds_").substringBefore("__").ifBlank { raw }
                SourceHandle(accession = id, source = "NCBI GEO/GDS", rawMarker = raw, label = markerTitle(raw).ifBlank { "Dataset handle $id" })
            }
            else -> SourceHandle(accession = raw, source = "visible source marker", rawMarker = raw, label = markerTitle(raw).ifBlank { raw })
        }
    }

    private fun toProvenanceHandle(raw: String): ProvenanceHandle? {
        if (!ResearchEvidenceGateV2156.isPositiveProvenanceHandle(raw)) return null
        val h = raw.lowercase()
        val source = when {
            h.contains("pubmed_") -> "PubMed-linked metadata"
            h.contains("gds_") || h.contains("gse") -> "NCBI GEO/GDS provenance"
            h.contains("sample") -> "sample/comparator metadata"
            h.contains("provenance") -> "provenance metadata"
            else -> "visible provenance marker"
        }
        return ProvenanceHandle(label = markerTitle(raw).ifBlank { raw }, source = source, rawMarker = raw)
    }

    private fun toContradictionHandle(raw: String): ContradictionHandle? {
        if (!ResearchEvidenceGateV2156.isPositiveContradictionHandle(raw)) return null
        val h = raw.lowercase()
        val source = when {
            h.contains("pubmed_") -> "PubMed falsification/contradiction query"
            h.contains("wrong_") -> "diagnostic falsifier marker"
            h.contains("failed_") -> "failed-replication marker"
            else -> "visible contradiction marker"
        }
        return ContradictionHandle(evidence = markerTitle(raw).ifBlank { raw }, source = source, rawMarker = raw)
    }

    private fun toMechanismHandle(raw: String): MechanismHandle? {
        if (!ResearchEvidenceGateV2156.isPositiveMechanismHandle(raw)) return null
        val source = if (raw.lowercase().contains("pubmed_")) "PubMed mechanism query" else "visible mechanism marker"
        return MechanismHandle(label = markerTitle(raw).ifBlank { raw }, source = source, rawMarker = raw)
    }

    private fun markerTitle(raw: String): String {
        val encoded = raw.substringAfter("__title_", "")
        if (encoded.isBlank()) return ""
        return encoded.replace('_', ' ').trim().take(140)
    }
}
