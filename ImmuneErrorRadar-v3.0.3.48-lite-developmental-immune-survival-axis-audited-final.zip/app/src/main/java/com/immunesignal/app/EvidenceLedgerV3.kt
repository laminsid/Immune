package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

enum class EvidenceTypeV3 {
    SOURCE,
    DATASET,
    PROVENANCE,
    CONTRADICTION,
    FALSIFIER,
    MECHANISM,
    HYPOTHESIS_RANKING,
    CONTEXT
}

enum class SourceKindV3 {
    PUBMED,
    GEO,
    SRA,
    PMC,
    NEWS,
    POLICY,
    LOCAL_MEMORY,
    UNKNOWN
}

enum class ArticleTypeV3 {
    DATASET,
    COHORT,
    TRANSCRIPTOMICS,
    EXPERIMENTAL_STUDY,
    MECHANISTIC_REVIEW,
    REVIEW,
    OUTBREAK_NOTE,
    EDITORIAL,
    NEWS,
    POLICY_COMMENTARY,
    UNKNOWN
}

enum class EvidenceRoleV3 {
    SOURCE,
    DATASET,
    PROVENANCE,
    CONTRADICTION,
    FALSIFIER,
    CONTEXT,
    MECHANISM,
    HYPOTHESIS_RANKING
}

enum class QualityTierV3 {
    A,
    B,
    C,
    D;

    fun isAtLeast(minimum: QualityTierV3): Boolean = ordinal <= minimum.ordinal
}

data class EvidenceNodeV3(
    val id: String,
    val type: EvidenceTypeV3,
    val accession: String?,
    val title: String?,
    val source: SourceKindV3,
    val articleType: ArticleTypeV3,
    val role: EvidenceRoleV3,
    val qualityTier: QualityTierV3,
    val supports: List<String> = emptyList(),
    val contradicts: List<String> = emptyList(),
    val limitations: List<String> = emptyList(),
    val query: String = "",
    val dataQualityTier: QualityTierV3 = qualityTier,
    val topicalRelevance: Int = 100,
    val domainMatch: String = "PASS",
    val organismMatch: String = "UNKNOWN",
    val diseaseMatch: String = "PASS",
    val tissueMechanismMatch: String = "PASS",
    val countsAsSupport: Boolean = role != EvidenceRoleV3.CONTEXT,
    val biomedicalSemanticConfidence: Int = topicalRelevance,
    val biomedicalComparatorCandidate: String = "none",
    val biomedicalRouteDecision: String = "BIOMED_RELEVANCE_NOT_EVALUATED"
) {
    val sourceFamily: String
        get() = when (source) {
            SourceKindV3.PUBMED, SourceKindV3.PMC -> "pubmed"
            SourceKindV3.GEO, SourceKindV3.SRA -> "dataset"
            SourceKindV3.NEWS, SourceKindV3.POLICY -> "context"
            SourceKindV3.LOCAL_MEMORY -> "local"
            SourceKindV3.UNKNOWN -> "unknown"
        }

    fun isVisibleResearchEvidence(): Boolean = source != SourceKindV3.LOCAL_MEMORY && accession.orEmpty().isNotBlank()

    fun satisfiesResearchRole(requiredRole: EvidenceRoleV3, minimumTier: QualityTierV3 = QualityTierV3.B): Boolean {
        if (!isVisibleResearchEvidence()) return false
        if (!countsAsSupport) return false
        if (role != requiredRole) return false
        if (!qualityTier.isAtLeast(minimumTier)) return false
        if (requiredRole == EvidenceRoleV3.DATASET || requiredRole == EvidenceRoleV3.PROVENANCE) {
            return articleType in setOf(
                ArticleTypeV3.DATASET,
                ArticleTypeV3.COHORT,
                ArticleTypeV3.TRANSCRIPTOMICS,
                ArticleTypeV3.EXPERIMENTAL_STUDY
            ) || source in setOf(SourceKindV3.GEO, SourceKindV3.SRA)
        }
        if (requiredRole == EvidenceRoleV3.CONTRADICTION || requiredRole == EvidenceRoleV3.FALSIFIER) {
            return role == requiredRole && qualityTier.isAtLeast(minimumTier)
        }
        return true
    }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("type", type.name)
        .put("accession", accession ?: "")
        .put("title", title ?: "")
        .put("source", source.name)
        .put("articleType", articleType.name)
        .put("role", role.name)
        .put("qualityTier", qualityTier.name)
        .put("dataQualityTier", dataQualityTier.name)
        .put("topicalRelevance", topicalRelevance)
        .put("domainMatch", domainMatch)
        .put("organismMatch", organismMatch)
        .put("diseaseMatch", diseaseMatch)
        .put("tissueMechanismMatch", tissueMechanismMatch)
        .put("countsAsSupport", countsAsSupport)
        .put("biomedicalSemanticConfidence", biomedicalSemanticConfidence)
        .put("biomedicalComparatorCandidate", biomedicalComparatorCandidate)
        .put("biomedicalRouteDecision", biomedicalRouteDecision)
        .put("supports", JSONArray(supports))
        .put("contradicts", JSONArray(contradicts))
        .put("limitations", JSONArray(limitations))
        .put("query", query)
}

data class EvidenceLedgerSnapshotV3(
    val nodes: List<EvidenceNodeV3>,
    val objectiveOutcomes: List<ResearchObjectiveOutcomeV3>
) {
    val visibleEvidence: List<EvidenceNodeV3> = EvidenceLedgerDedupeV30326.dedupe(nodes.filter { it.isVisibleResearchEvidence() })
    val visibleEvidenceIds: List<String> = visibleEvidence.map { it.id }
    val executedObjectiveIds: List<String> = objectiveOutcomes.map { it.objective.id }
    val exhaustedObjectiveIds: List<String> = objectiveOutcomes.filter { it.exhausted }.map { it.objective.id }

    fun objectiveExecuted(prefix: String): Boolean = executedObjectiveIds.any { it.startsWith(prefix) }
    fun objectiveExhausted(prefix: String): Boolean = exhaustedObjectiveIds.any { it.startsWith(prefix) }

    fun hasSatisfyingRole(role: EvidenceRoleV3, minimumTier: QualityTierV3 = QualityTierV3.B): Boolean =
        nodes.any { it.satisfiesResearchRole(role, minimumTier) }

    fun countSatisfyingRoles(vararg roles: EvidenceRoleV3): Int =
        roles.count { hasSatisfyingRole(it) }

    fun distinctAccessions(): List<String> = visibleEvidence
        .mapNotNull { it.accession?.trim()?.uppercase() }
        .filter { it.isNotBlank() }
        .distinct()

    fun distinctSatisfyingAccessions(minimumTier: QualityTierV3 = QualityTierV3.B): List<String> = visibleEvidence
        .filter { node ->
            node.countsAsSupport &&
                node.role != EvidenceRoleV3.CONTEXT &&
                node.qualityTier.isAtLeast(minimumTier) &&
                node.accession?.isNotBlank() == true
        }
        .mapNotNull { it.accession?.trim()?.uppercase() }
        .distinct()

    fun tierCounts(): Map<QualityTierV3, Int> = visibleEvidence.groupingBy { it.qualityTier }.eachCount()

    fun criticalRoleAccessions(): Map<String, Set<EvidenceRoleV3>> {
        val criticalRoles = setOf(
            EvidenceRoleV3.SOURCE,
            EvidenceRoleV3.DATASET,
            EvidenceRoleV3.PROVENANCE,
            EvidenceRoleV3.CONTRADICTION,
            EvidenceRoleV3.FALSIFIER
        )
        val map = linkedMapOf<String, MutableSet<EvidenceRoleV3>>()
        // Use the raw ledger nodes for critical-role independence, not the deduped
        // display ledger. Dedupe is correct for counting/rendering, but it must not
        // hide a provenance/contradiction/source role collision that occurred before
        // dedupe. This preserves the V3 contract: one accession cannot satisfy
        // critical independent roles even when the final displayed ledger collapses
        // duplicate accessions to a single row.
        nodes.forEach { node ->
            val accession = node.accession?.trim()?.uppercase().orEmpty()
            if (accession.isBlank() || !node.countsAsSupport || node.role !in criticalRoles) return@forEach
            map.getOrPut(accession) { linkedSetOf() }.add(node.role)
        }
        return map.mapValues { it.value.toSet() }
    }

    fun hasCriticalRoleIndependence(): Boolean {
        val rolesByAccession = criticalRoleAccessions()
        return rolesByAccession.values.none { roles ->
            roles.contains(EvidenceRoleV3.SOURCE) &&
                (roles.contains(EvidenceRoleV3.PROVENANCE) || roles.contains(EvidenceRoleV3.CONTRADICTION) || roles.contains(EvidenceRoleV3.FALSIFIER))
        }
    }

    fun toJson(): JSONObject = JSONObject()
        .put("visibleEvidenceCount", visibleEvidence.size)
        .put("visibleEvidenceIds", JSONArray(visibleEvidenceIds))
        .put("distinctAccessions", JSONArray(distinctAccessions()))
        .put("criticalRoleAccessions", JSONObject(criticalRoleAccessions().mapValues { entry -> JSONArray(entry.value.map { it.name }) }))
        .put("criticalRoleIndependencePassed", hasCriticalRoleIndependence())
        .put("executedObjectiveIds", JSONArray(executedObjectiveIds))
        .put("exhaustedObjectiveIds", JSONArray(exhaustedObjectiveIds))
        .put("nodes", JSONArray(nodes.map { it.toJson() }))
}

class EvidenceLedgerV3 {
    private val nodes = linkedMapOf<String, EvidenceNodeV3>()
    private val outcomes = mutableListOf<ResearchObjectiveOutcomeV3>()

    fun record(outcome: ResearchObjectiveOutcomeV3) {
        outcomes += outcome
        outcome.nodes.forEach { node -> nodes[node.id] = node }
    }

    fun addNode(node: EvidenceNodeV3) {
        nodes[node.id] = node
    }

    fun clear() {
        nodes.clear()
        outcomes.clear()
    }

    fun snapshot(): EvidenceLedgerSnapshotV3 = EvidenceLedgerSnapshotV3(
        nodes = nodes.values.toList(),
        objectiveOutcomes = outcomes.toList()
    )

    fun visibleEvidence(): List<EvidenceNodeV3> = snapshot().visibleEvidence
}
