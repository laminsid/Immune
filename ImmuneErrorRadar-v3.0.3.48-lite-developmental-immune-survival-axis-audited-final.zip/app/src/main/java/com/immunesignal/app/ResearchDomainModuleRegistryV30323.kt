package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.23 stability governance: fixed disease/module routes used before any
 * dataset module score is allowed to run. This is a routing/readiness registry,
 * not biological proof and not a treatment layer.
 */
data class ResearchDomainModuleRouteV30323(
    val domainKey: String,
    val diseaseAliases: List<String>,
    val mechanismOrTissueTerms: List<String>,
    val capsuleHints: List<String>,
    val moduleRoutes: List<String>
) {
    fun toJson(): JSONObject = JSONObject()
        .put("domainKey", domainKey)
        .put("diseaseAliases", JSONArray(diseaseAliases))
        .put("mechanismOrTissueTerms", JSONArray(mechanismOrTissueTerms))
        .put("capsuleHints", JSONArray(capsuleHints))
        .put("moduleRoutes", JSONArray(moduleRoutes))
}

object ResearchDomainModuleRegistryV30323 {
    const val REQUIRED_TOKEN: String = "V30323_DOMAIN_SPECIFIC_MODULE_REGISTRY_GATE"

    private val routes = listOf(
        ResearchDomainModuleRouteV30323(
            domainKey = "COVID",
            diseaseAliases = listOf("covid", "covid-19", "sars-cov-2", "sars cov 2", "long covid", "pasc", "coronavirus"),
            mechanismOrTissueTerms = listOf("ifn", "interferon", "t-cell", "t cell", "cd4", "cd8", "il-6", "il6", "tnf", "endothelial", "pbmc", "whole blood"),
            capsuleHints = listOf("covid", "sars", "postviral", "interferon", "tcell", "endothelial"),
            moduleRoutes = listOf("IFN timing", "T-cell balance", "IL-6/TNF endothelial")
        ),
        ResearchDomainModuleRouteV30323(
            domainKey = "RA",
            diseaseAliases = listOf("rheumatoid arthritis", "ra", "synovitis", "synovial"),
            mechanismOrTissueTerms = listOf("synovial macrophage", "macrophage", "t-cell", "t cell", "cytokine", "tnf", "il-6", "il6", "il-17", "il17", "pad4", "citrullination", "acpa"),
            capsuleHints = listOf("rheumatoid", "synovial", "arthritis", "tnf", "citrullination"),
            moduleRoutes = listOf("synovial macrophage", "T-cell cytokine", "TNF", "IL-6", "IL-17", "PAD4-citrullination")
        ),
        ResearchDomainModuleRouteV30323(
            domainKey = "ALLERGY",
            diseaseAliases = listOf("allergy", "allergic", "allergic rhinitis", "asthma", "atopy", "atopic dermatitis"),
            mechanismOrTissueTerms = listOf("ige", "eosinophil", "mast cell", "il-4", "il4", "il-5", "il5", "il-13", "il13", "epithelial", "barrier", "type 2"),
            capsuleHints = listOf("allergy", "allergic", "type2", "type_2", "ige", "eosinophil", "mast", "epithelial"),
            moduleRoutes = listOf("IgE", "eosinophil", "mast cell", "IL-4", "IL-5", "IL-13", "epithelial barrier")
        ),
        ResearchDomainModuleRouteV30323(
            domainKey = "MS",
            diseaseAliases = listOf("multiple sclerosis", "ms", "experimental autoimmune encephalomyelitis", "eae"),
            mechanismOrTissueTerms = listOf("myelin", "microglia", "b-cell", "b cell", "t-cell", "t cell", "il-17", "il17", "complement", "ifn-beta", "ifn beta", "cns"),
            capsuleHints = listOf("multiple_sclerosis", "myelin", "microglia", "cns", "il17", "ifn_beta"),
            moduleRoutes = listOf("myelin", "microglia", "B-cell/T-cell", "IL-17", "complement", "IFN-beta")
        ),
        ResearchDomainModuleRouteV30323(
            domainKey = "CANCER",
            diseaseAliases = listOf("cancer", "tumor", "tumour", "carcinoma", "oncology", "malignancy", "neoplasm", "leukemia", "leukaemia", "aml", "lymphoma", "melanoma", "neuroblastoma", "mycn", "gd2", "pediatric", "paediatric", "childhood"),
            mechanismOrTissueTerms = listOf("cd8", "exhaustion", "macrophage", "tam", "myeloid", "treg", "checkpoint", "pd-1", "pd1", "pd-l1", "pdl1", "ctla4", "lag3", "ifn-gamma", "ifng", "antigen presentation", "tumor microenvironment", "tumour microenvironment", "tme", "immune hot", "immune cold", "hypoxia", "emt", "mycn", "gd2", "nk cell", "tigit", "nectin2", "neural crest", "pediatric", "childhood"),
            capsuleHints = listOf("cancer", "tumor", "tumour", "tme", "checkpoint", "macrophage", "tam", "treg", "leukemia", "aml", "melanoma", "neuroblastoma", "mycn", "gd2", "immune_exclusion"),
            moduleRoutes = listOf("CD8 exhaustion/checkpoint escape", "TAM/Treg suppressive niche", "IFN-gamma inflamed vs excluded TME", "hypoxia/EMT immune exclusion", "tumor microenvironment", "pediatric neuroblastoma MYCN immune exclusion", "GD2/NK/TIGIT axis")
        )
    )

    fun routeForTopic(topic: String): ResearchDomainModuleRouteV30323? {
        val lower = normalize(topic)
        return routes.firstOrNull { route ->
            when (route.domainKey) {
                "COVID" -> listOf("covid", "sars-cov-2", "sars cov 2", "pasc", "long covid").any { lower.contains(it) }
                "RA" -> route.diseaseAliases.any { alias -> alias == "ra" && Regex("\\bra\\b").containsMatchIn(lower) || alias != "ra" && lower.contains(alias) }
                "ALLERGY" -> route.diseaseAliases.any { lower.contains(it) } || listOf("ige", "eosinophil", "mast cell", "type 2").any { lower.contains(it) }
                "MS" -> route.diseaseAliases.any { alias -> alias == "ms" && Regex("\\bms\\b").containsMatchIn(lower) || alias != "ms" && lower.contains(alias) }
                "CANCER" -> route.diseaseAliases.any { lower.contains(it) }
                else -> false
            }
        }
    }

    fun allRoutes(): List<ResearchDomainModuleRouteV30323> = routes

    fun toJson(): JSONObject = JSONObject()
        .put("requiredToken", REQUIRED_TOKEN)
        .put("routes", JSONArray(routes.map { it.toJson() }))

    fun normalize(value: String): String = value.lowercase()
        .replace('_', ' ')
        .replace('-', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()
}
