package com.immunesignal.app

import org.json.JSONObject

/**
 * v2.14.6 — Bounded proof-pass scheduler.
 *
 * Fixes the v2.14.5 regression where the no-instant-report gate could cycle
 * indefinitely (e.g. Deepening pass 221). The agent is allowed to work, but
 * every foreground run must be a finite batch with a checkpoint-ready output.
 */
object GTIMBoundedProofPassSchedulerV2146 {
    const val VERSION: String = "2.14.6-bounded-proof-pass-checkpoint"
    const val REQUIRED_TOKEN: String = "V2146_BOUNDED_PROOF_PASS_SCHEDULER_NO_INFINITE_DEEPENING_LOOP"
    const val LOOP_RULE: String = "no infinite deepening loop; each foreground run closes after a bounded proof-pass batch"
    const val USER_RULE: String = "Start begins a finite batch; Pause holds it; Continue resumes it; Stop saves the current checkpoint"
    const val DEFAULT_MAX_PASSES: Int = 5

    fun maxPasses(): Int = DEFAULT_MAX_PASSES

    fun passNumber(zeroBasedIndex: Int): Int = zeroBasedIndex.coerceIn(0, DEFAULT_MAX_PASSES - 1) + 1

    fun isFinalPass(zeroBasedIndex: Int): Boolean = passNumber(zeroBasedIndex) >= DEFAULT_MAX_PASSES

    fun clampPercent(percent: Int): Int = percent.coerceIn(0, 100)

    fun stageLine(passNumber: Int, label: String): String =
        "Proof batch pass ${passNumber.coerceIn(1, DEFAULT_MAX_PASSES)}/$DEFAULT_MAX_PASSES — $label"

    fun annotate(report: JSONObject, currentPass: Int, completed: Boolean, stoppedByUser: Boolean): JSONObject {
        val pass = currentPass.coerceIn(1, DEFAULT_MAX_PASSES)
        report.put("boundedProofPassSchedulerV2146", JSONObject()
            .put("version", VERSION)
            .put("requiredToken", REQUIRED_TOKEN)
            .put("loopRule", LOOP_RULE)
            .put("userRule", USER_RULE)
            .put("maxPasses", DEFAULT_MAX_PASSES)
            .put("currentPass", pass)
            .put("completed", completed)
            .put("stoppedByUser", stoppedByUser)
            .put("copyExportUnlockedWhen", "stopped_or_bounded_batch_completed")
            .put("finalReport", false)
            .put("claimLimit", "research checkpoint only; not proof, diagnosis, treatment, dosing, or clinical advice"))
        return report
    }
}
