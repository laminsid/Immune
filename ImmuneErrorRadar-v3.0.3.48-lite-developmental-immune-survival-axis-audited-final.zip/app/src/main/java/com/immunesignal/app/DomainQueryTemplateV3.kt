package com.immunesignal.app

/**
 * v3.0.3.13 — hybrid domain query construction.
 * Replaces raw prompt + blind suffixes with compact, domain-aware PubMed/GEO
 * templates. The templates intentionally stay short; precision comes from the
 * biomedical frame, not from appending every word the user typed.
 */
object DomainQueryTemplateV3 {
    val VERSION: String = ResearchEngineV3ReleaseIdentity.VERSION_NAME
    // legacy audit marker only: 3.0.3.20-final-unified-metadata-probe-runtime
    const val REQUIRED_TOKEN: String = "V30313_HYBRID_TEMPLATE_FAST_LANE_DYNAMIC_DEFAULT_LANE"
    const val LEGACY_REQUIRED_TOKEN_V30312: String = "V30312_DOMAIN_QUERY_TEMPLATE_NO_RAW_PROMPT_SUFFIXES"

    fun sourceQueries(topic: String): List<String> {
        val frame = BiomedicalTopicFrameV3.from(topic)
        return sanitizeAll(topic, when (frame.domain) {
            ResearchDomainV3.COVID -> listOf(
                "SARS-CoV-2 COVID-19 immune dysregulation PubMed",
                "long COVID complement immune dysregulation systematic review PubMed",
                "SARS-CoV-2 PBMC transcriptome immune profiling PubMed"
            )
            ResearchDomainV3.ALLERGY_TYPE2 -> listOf(
                "allergy IgE eosinophil mast cell type 2 inflammation PubMed",
                "atopic dermatitis allergic rhinitis asthma IL-4 IL-5 IL-13 eosinophil PubMed",
                "allergic asthma type 2 inflammation biomarker cohort PubMed"
            )
            ResearchDomainV3.DEPRESSION_KYNURENINE -> listOf(
                "depression kynurenine tryptophan IDO1 KMO PubMed",
                "major depressive disorder kynurenine pathway neuroimmune inflammation PubMed",
                "major depressive disorder quinolinic acid kynurenic acid microglia PubMed",
                "depression kynurenine cytokine neuroimmune cohort PubMed",
                "treatment resistant depression peripheral biomarkers kynurenine inflammation PubMed"
            )
            ResearchDomainV3.CANCER -> CancerHypothesisDiscoveryV30324.sourceQueries(topic)
            ResearchDomainV3.EBOLA -> listOf(
                "Ebola Bundibugyo immune dysregulation PubMed",
                "Bundibugyo Ebola cytokine host response cohort PubMed",
                "filovirus transcriptome immune response comparator PubMed"
            )
            ResearchDomainV3.COMPARATIVE -> comparativeQueries(frame, "PubMed")
            ResearchDomainV3.GENERAL_IMMUNE -> DynamicBiomedicalQueryBuilderV3.sourceQueries(frame)
        })
    }

    fun datasetQueries(topic: String): List<String> {
        val frame = BiomedicalTopicFrameV3.from(topic)
        return sanitizeAll(topic, when (frame.domain) {
            ResearchDomainV3.COVID -> listOf(
                "SARS-CoV-2 PBMC transcriptome GEO healthy controls",
                "COVID-19 immune profiling GSE healthy controls",
                "long COVID transcriptome GEO cohort"
            )
            ResearchDomainV3.ALLERGY_TYPE2 -> listOf(
                "allergic rhinitis eosinophil transcriptome GEO",
                "asthma type 2 inflammation RNA-seq GEO",
                "atopic dermatitis IL-4 IL-13 transcriptome GSE"
            )
            ResearchDomainV3.DEPRESSION_KYNURENINE -> listOf(
                "major depressive disorder kynurenine GEO",
                "depression IDO1 PBMC transcriptome GEO",
                "MDD tryptophan metabolism RNA-seq GSE",
                "kynurenine pathway depression cohort GEO",
                "depression neuroimmune PBMC transcriptome GEO"
            )
            ResearchDomainV3.CANCER -> CancerHypothesisDiscoveryV30324.datasetQueries(topic)
            ResearchDomainV3.EBOLA -> listOf(
                "Ebola Bundibugyo transcriptome GEO",
                "filovirus host response RNA-seq GSE",
                "Bundibugyo Ebola PBMC transcriptome dataset"
            )
            ResearchDomainV3.COMPARATIVE -> comparativeQueries(frame, "GEO transcriptome")
            ResearchDomainV3.GENERAL_IMMUNE -> DynamicBiomedicalQueryBuilderV3.datasetQueries(frame)
        })
    }

    fun contradictionQueries(topic: String): List<String> {
        val frame = BiomedicalTopicFrameV3.from(topic)
        return sanitizeAll(topic, when (frame.domain) {
            ResearchDomainV3.COVID -> listOf(
                "COVID-19 immune signature no association healthy control PubMed",
                "SARS-CoV-2 transcriptome tissue specificity limitation comparator PubMed",
                "long COVID immune dysregulation negative control cohort PubMed"
            )
            ResearchDomainV3.ALLERGY_TYPE2 -> listOf(
                "allergy IgE eosinophil no association healthy control PubMed",
                "asthma type 2 inflammation negative control comparator cohort PubMed",
                "atopic dermatitis IL-4 IL-13 tissue specificity limitation PubMed"
            )
            ResearchDomainV3.DEPRESSION_KYNURENINE -> listOf(
                "depression kynurenine no association healthy control PubMed",
                "major depressive disorder tryptophan negative control comparator PubMed",
                "depression IDO1 KMO tissue specificity limitation cohort PubMed",
                "kynurenine pathway depression conflicting evidence cohort PubMed",
                "major depressive disorder peripheral kynurenine confounder PubMed"
            )
            ResearchDomainV3.CANCER -> CancerHypothesisDiscoveryV30324.contradictionQueries(topic)
            ResearchDomainV3.EBOLA -> listOf(
                "Bundibugyo Ebola tissue comparator limitation cohort falsification study PubMed",
                "Bundibugyo Ebola tissue specificity limitation comparator PubMed",
                "filovirus immune signature negative control PubMed",
                "Ebola host response no association healthy control PubMed"
            )
            ResearchDomainV3.COMPARATIVE -> comparativeQueries(frame, "negative control no association PubMed")
            ResearchDomainV3.GENERAL_IMMUNE -> DynamicBiomedicalQueryBuilderV3.contradictionQueries(frame)
        })
    }

    fun provenanceQueries(topic: String, evidenceId: String): List<String> {
        val frame = BiomedicalTopicFrameV3.from(topic)
        val accession = QuerySanitizerV3.noMalformedQuery(evidenceId)
        if (frame.domain == ResearchDomainV3.CANCER) {
            return sanitizeAll(topic, CancerHypothesisDiscoveryV30324.provenanceQueries(topic, evidenceId))
        }
        return sanitizeAll(topic, listOf(
            "$accession sample metadata comparator labels",
            "$accession phenotype healthy controls disease severity",
            "${frame.queryStem(8)} $accession sample provenance"
        ))
    }

    // legacy audit marker only: ComparativeDualRetrievalExecutorV30328.queries
    private fun comparativeQueries(frame: BiomedicalTopicFrameV3, suffix: String): List<String> =
        ComparativeDualLanePlannerV30332.build(frame.rawInput, suffix).queries(5)

    private fun sanitizeAll(topic: String, queries: List<String>): List<String> {
        val biologicalContextFuel = BiologicalContextContinuityLayerV30345.queryFuelForTopic(topic).take(8).joinToString(" ")
        val openDiscoveryFuel = FullMatrixOpenDiscoveryReadinessV30347.queryFuelForTopic(topic).take(6).joinToString(" ")
        val survivalAxisFuel = DevelopmentalImmuneSurvivalAxisV30348.queryFuelForTopic(topic).take(4).joinToString(" ")
        return queries
            .map { QuerySanitizerV3.noMalformedQuery("$it $biologicalContextFuel $openDiscoveryFuel $survivalAxisFuel") }
            .map { ContaminatedOntologyInputGateV30334.sanitizeQuery(topic, OntologyLeakageGuardV30333.sanitizeQuery(topic, it)) }
            .filter { it.isNotBlank() }
            .distinct()
            .take(5)
    }
}
