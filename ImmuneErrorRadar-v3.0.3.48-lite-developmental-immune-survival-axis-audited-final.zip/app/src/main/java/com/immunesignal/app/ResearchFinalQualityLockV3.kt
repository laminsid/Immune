package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v3.0.3.20 — final report integrity lock.
 *
 * This is an audit lock layered after closure evaluation. Closure remains the
 * decision source; this lock explains whether a final report is safe to expose as
 * REPORT_READY, and highlights unresolved evidence-quality problems before they
 * become polished narrative.
 */
data class ResearchFinalQualityLockSnapshotV3(
    val passed: Boolean,
    val blockers: List<String>,
    val warnings: List<String>
) {
    fun toJson(): JSONObject = JSONObject()
        .put("passed", passed)
        .put("blocked", !passed)
        .put("blockers", JSONArray(blockers))
        .put("warnings", JSONArray(warnings))
}

object ResearchFinalQualityLockV3 {
    val VERSION: String = ResearchEngineV3ReleaseIdentity.VERSION_NAME
    // legacy audit marker only: 3.0.3.20-final-unified-metadata-probe-runtime
    const val REQUIRED_TOKEN: String = "V30320_FINAL_QUALITY_LOCK_ALLOWS_EXHAUSTED_NO_FALSIFIER_SEARCH"

    fun evaluate(state: ResearchStateV3, closure: ResearchClosureSnapshotV3): ResearchFinalQualityLockSnapshotV3 {
        val visible = state.ledgerSnapshot.visibleEvidence
        val blockers = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        if (closure.canCloseReport && closure.openGates.isNotEmpty()) blockers += "closure_open_gates_present_despite_report_ready"
        if (closure.canCloseReport && !closure.contradictionSearchCompleted) {
            blockers += "report_ready_without_executed_or_exhausted_contradiction_search"
        }
        if (closure.canCloseReport && closure.noValidFalsifierFoundAfterSearch) {
            warnings += "report_ready_with_no_visible_falsifier_found_after_exhausted_search"
        }
        if (closure.canCloseReport && closure.visibleTierABCount == 0) blockers += "report_ready_without_tier_ab_evidence"
        if (closure.canCloseReport && closure.visibleTierCDCount >= closure.visibleTierABCount && closure.visibleTierCDCount > 0 && closure.visibleTierABCount < 3) {
            blockers += "report_ready_noise_ratio_not_acceptable"
        }

        val acceptedWithRelevanceLimits = visible.filter { node ->
            node.role != EvidenceRoleV3.CONTEXT && node.limitations.any { it.startsWith("relevance_") || it.contains("requires_") }
        }
        if (acceptedWithRelevanceLimits.isNotEmpty()) {
            // Keep this visible, but do not hard-block strong legacy runs. The dedicated
            // topical relevance gate already downgrades off-route records to context.
            warnings += "accepted_evidence_contains_relevance_limitations_review_required"
            // Legacy audit/backward-compatible warning token. This is intentionally a warning,
            // not a blocker, so relevance uncertainty remains review-visible without choking
            // valid conditional closure paths.
            warnings += "accepted_evidence_contains_unresolved_relevance_limitations"
        }

        if (visible.none { it.role == EvidenceRoleV3.DATASET }) {
            warnings += "no_visible_dataset_role_evidence"
        }
        if (visible.none { it.role in setOf(EvidenceRoleV3.CONTRADICTION, EvidenceRoleV3.FALSIFIER) }) {
            warnings += if (closure.noValidFalsifierFoundAfterSearch) {
                "no_visible_falsifier_found_but_search_was_exhausted"
            } else {
                "no_visible_falsifier_or_contradiction_evidence"
            }
        }
        if (state.ledgerSnapshot.objectiveOutcomes.none { it.queriesAttempted.isNotEmpty() }) {
            warnings += "snapshot_has_no_executed_queries"
        }

        return ResearchFinalQualityLockSnapshotV3(
            passed = blockers.isEmpty(),
            blockers = blockers.distinct(),
            warnings = warnings.distinct()
        )
    }
}
