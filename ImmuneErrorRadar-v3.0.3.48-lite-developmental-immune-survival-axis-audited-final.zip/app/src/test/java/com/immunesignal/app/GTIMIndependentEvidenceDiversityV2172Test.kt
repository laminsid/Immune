package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMIndependentEvidenceDiversityV2172Test {
    @Test
    fun onePubmedAccessionTripleCountCannotCloseFinalReportPolicy() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
            .withEvidenceHandle("source_handle_closed_pubmed_123456__title_filovirus_host_response")
            .withEvidenceHandle("metadata_probe_executed_pubmed_123456__title_filovirus_host_response")
            .withEvidenceHandle("contradiction_checked_pubmed_123456__title_filovirus_host_response")
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }

        assertTrue("The visible/reviewable gate still sees the three displayed categories", ResearchVisibleEvidenceAuditV2161.evaluate(contract).reportReadyEligible)
        assertFalse("The final policy must not triple-count one PMID as independent support", ResearchEvidenceDiversityAuditV2172.evaluate(contract).reportReadyEligible)
        assertFalse(ResearchExecutionPolicyV2154.reportCanClose(contract))
    }

    @Test
    fun distinctReviewableAccessionsCanCloseFinalReportPolicy() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
            .withEvidenceHandle("source_handle_closed_pubmed_123456__title_filovirus_host_response")
            .withEvidenceHandle("provenance_closed_gds_GSE99999__title_filovirus_expression_dataset")
            .withEvidenceHandle("contradiction_checked_pubmed_789012__title_species_model_limitation")
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }

        val diversity = ResearchEvidenceDiversityAuditV2172.evaluate(contract)
        assertTrue(diversity.hasIndependentEvidenceSupport)
        assertTrue(diversity.reportReadyEligible)
        assertTrue(ResearchExecutionPolicyV2154.reportCanClose(contract))
    }

    @Test
    fun userCardDowngradesReportReadyWhenIndependentEvidenceIsMissing() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
            .withStatus(ResearchRunStatusV2150.REPORT_READY)
            .withEvidenceHandle("source_handle_closed_pubmed_123456__title_filovirus_host_response")
            .withEvidenceHandle("metadata_probe_executed_pubmed_123456__title_filovirus_host_response")
            .withEvidenceHandle("contradiction_checked_pubmed_123456__title_filovirus_host_response")
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }

        val report = ResearchBriefBuilderV2150.buildReport(contract, "diversity_missing_test")
        val card = ResearchBriefBuilderV2150.renderUserCard(report).orEmpty()
        assertTrue(card.contains("CHECKPOINT_READY_INDEPENDENT_EVIDENCE_MISSING"))
        assertTrue(card.contains("insufficient_independent_reviewable_accessions"))
    }
}
