package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMImmuneDecisionReprogrammingV21317Test {
    @Test
    fun paradigmCardAddsToleranceAndDigitalImmunomicsWithoutProofPromotion() {
        val report = JSONObject().put("topic", "rheumatoid FOXP3 Treg tolerance research")
        val text = GTIMParadigmSurfaceCardV21317.renderLines(report).joinToString("\n")
        assertTrue(text.contains("Paradigm candidate card"))
        assertTrue(text.contains("tolerance"))
        assertTrue(text.contains("sandbox_design_preview=ALLOWED"))
        assertTrue(text.contains("validated_binding_or_efficacy_claim=BLOCKED"))
        assertFalse(text.contains("dosing recommendation"))
    }

    @Test
    fun aiImmunomicsLensIsPreviewOnlyForCancerAndViruses() {
        val report = JSONObject().put("topic", "cancer tumor microenvironment antibody design")
        val lens = GTIMDigitalImmunomicsLensV21317.toJson(report)
        assertTrue(lens.getBoolean("design_preview_allowed"))
        assertFalse(lens.getBoolean("validated_binding_or_efficacy_claim_allowed"))
        assertTrue(lens.getJSONArray("digital_immunomics_tasks").toString().contains("antigen_mapping"))
    }
}
