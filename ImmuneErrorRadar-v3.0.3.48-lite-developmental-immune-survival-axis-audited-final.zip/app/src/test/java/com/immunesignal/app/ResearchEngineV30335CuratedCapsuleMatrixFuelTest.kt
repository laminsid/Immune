package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30335CuratedCapsuleMatrixFuelTest {
    @Test
    fun rheumatoidArthritisRoutesToSynoviumAndNotCancer() {
        val route = SpecialistRouterV30335.route("RA synovium pannus TNF IL6 IL17A MMP3")

        assertTrue(route.active)
        assertEquals("ra_synovium", route.routeId)
        assertTrue(route.specialistRoute.contains("RA", ignoreCase = true))
        assertFalse(route.specialistRoute.contains("cancer", ignoreCase = true))
        assertFalse(route.primaryTissue.contains("tumor", ignoreCase = true))
    }

    @Test
    fun alzheimerKeepsMicrogliaComplementDiseaseAnchor() {
        val route = SpecialistRouterV30335.route("Alzheimer disease microglia complement C1QA TREM2 APOE")

        assertTrue(route.active)
        assertEquals("alzheimer_microglia_complement", route.routeId)
        assertTrue(route.diseaseId.contains("alzheimer", ignoreCase = true))
        assertTrue(route.cells.any { it.contains("microglia", ignoreCase = true) })
        assertTrue(route.markers.contains("C1QA"))
        assertTrue(route.markers.contains("TREM2"))
    }

    @Test
    fun allergyFindsTypeTwoAirwayRoute() {
        val route = SpecialistRouterV30335.route("allergic asthma atopy airway IL4 IL5 IL13 TSLP IL33")

        assertTrue(route.active)
        assertEquals("allergy_type2_airway", route.routeId)
        assertTrue(route.specialistRoute.contains("type-2", ignoreCase = true))
        assertTrue(route.markers.contains("IL13"))
    }

    @Test
    fun cancerFindsTmeCheckpointRoute() {
        val route = SpecialistRouterV30335.route("tumor immune microenvironment TME checkpoint PD-L1 CD8A GZMB")

        assertTrue(route.active)
        assertEquals("cancer_tme_checkpoint", route.routeId)
        assertTrue(route.specialistRoute.contains("checkpoint", ignoreCase = true))
        assertTrue(route.markers.contains("PDCD1"))
        assertTrue(route.markers.contains("CD274"))
    }

    @Test
    fun curatedLightMatrixPreventsRowsZeroForCoreDiseases() {
        val rows = CuratedLightMatrixFuelPackV30335.rowsFor("rheumatoid arthritis synovium TNF IL6 IL17A", "none")
        val labels = CuratedLightMatrixFuelPackV30335.groupLabelsFor("rheumatoid arthritis synovium TNF IL6 IL17A", "none")

        assertEquals(10, rows.size)
        assertEquals(5, rows.count { it.group == "active_ra" })
        assertEquals(5, rows.count { it.group == "healthy_control" })
        assertTrue(labels.first.contains("active_RA") || labels.first.contains("active_ra"))
        assertTrue(labels.second.contains("healthy_control"))
    }

    @Test
    fun covidCuratedPriorCanSeedHypothesisButCannotCertifyDiscoveryOrMechanismSupport() {
        val topic = "COVID interferon PBMC IFIT1 ISG15 CXCL10 severe vs healthy control"
        val rows = CuratedLightMatrixFuelPackV30335.rowsFor(topic, "none")
        val labels = CuratedLightMatrixFuelPackV30335.groupLabelsFor(topic, "none")
        val normalizedRows = rows.map { row -> row.copy(group = ComparatorGroupResolverV30330.normalizeLabel(row.group)) }
        val groupResolution = ComparatorGroupResolutionV30330(
            state = "COMPARATOR_GROUP_VALUES_RESOLVED_FROM_V30335_TEST",
            accession = "CURATED_COVID_IFN_PRIOR",
            caseLabels = labels.first.map { ComparatorGroupResolverV30330.normalizeLabel(it) },
            controlLabels = labels.second.map { ComparatorGroupResolverV30330.normalizeLabel(it) },
            unresolvedAxis = "covid_severity_vs_control",
            source = "v30335_curated_test"
        )
        val fuel = MatrixFuelSnapshotV30330(
            state = "MATRIX_FUEL_READY_FOR_CURATED_PRIOR_DGE",
            accession = "CURATED_COVID_IFN_PRIOR",
            rowCount = normalizedRows.size,
            caseRowCount = normalizedRows.count { row -> groupResolution.caseLabels.any { row.group == it } },
            controlRowCount = normalizedRows.count { row -> groupResolution.controlLabels.any { row.group == it } },
            source = "curated_light_matrix_prior_v30335_hypothesis_discovery_seed",
            groupResolution = groupResolution,
            warnings = listOf("v30335_curated_light_matrix_prior_executes_hypothesis_discovery_seed_not_certified_discovery"),
            certificationLevel = CuratedLightMatrixFuelPackV30335.CERTIFICATION_LEVEL,
            analysisMode = CuratedLightMatrixFuelPackV30335.ANALYSIS_MODE,
            scientificInterpretability = CuratedLightMatrixFuelPackV30335.INTERPRETABILITY,
            fuelOrigin = CuratedLightMatrixFuelPackV30335.FUEL_ORIGIN,
            verificationLevel = "CURATED_PRIOR_NOT_VERIFIED",
            signalValidity = "CURATED_PRIOR_HYPOTHESIS_SIGNAL_NOT_VERIFIED"
        )
        val signal = ProcessedExpressionSignalReportV30329(
            active = true,
            state = "CURATED_PRIOR_DGE_EXECUTED_HYPOTHESIS_DISCOVERY_SEED",
            dataset = "CURATED_COVID_IFN_PRIOR",
            moduleCount = 1,
            rawMatrixDgeExecuted = true,
            estimates = listOf(
                ModuleSignalEstimateV30329(
                    accession = "CURATED_COVID_IFN_PRIOR",
                    module = "curated_covid_ifn_isg_nfkb_module",
                    markers = listOf("IFIT1", "ISG15", "CXCL10"),
                    effectDirection = "case_enrichment_expected_curated_prior",
                    effectSize = 1.8,
                    confidenceInterval = "curated-prior-only",
                    pValueLabel = "review-only",
                    statisticState = "CURATED_PRIOR_DGE_REVIEW_ONLY",
                    rawMatrixDgeExecuted = true,
                    computedFrom = "CURATED_LIGHT_MATRIX_PRIOR",
                    supportState = "CURATED_PRIOR_RAW_MATRIX_SIGNAL_HYPOTHESIS_DISCOVERY_NOT_MECHANISM_SUPPORT"
                )
            ),
            nextAction = "Verify with ETL or replicated user-attested matrix before score >=8 or mechanism support.",
            matrixFuel = fuel
        )
        val gate = CertifiedMatrixFuelGateV30332.evaluate(signal)

        assertTrue(rows.isNotEmpty())
        assertFalse(fuel.certifiedForDiscovery)
        assertFalse(signal.hasMechanismSupport)
        assertEquals("RAW_MATRIX_DGE_EXECUTED_CURATED_PRIOR_HYPOTHESIS_DISCOVERY_NOT_CERTIFIED", gate.state)
        assertFalse(gate.certifiedForDiscovery)
        assertTrue(gate.nextAction.contains("score >=8", ignoreCase = true))
    }
    @Test
    fun allCoreCapsulesOpenRoutesAndCuratedMatrixRows() {
        val cases = listOf(
            "rheumatoid arthritis synovium pannus TNF IL6 IL17A" to "ra_synovium",
            "allergic asthma airway type-2 inflammation IL4 IL5 IL13" to "allergy_type2_airway",
            "Alzheimer disease brain microglia complement C1QA TREM2 APOE" to "alzheimer_microglia_complement",
            "cancer tumor immune microenvironment checkpoint PD-L1 CD8A" to "cancer_tme_checkpoint",
            "multiple sclerosis CNS myelin microglia IL17A interferon" to "multiple_sclerosis_cns",
            "COVID-19 severe PBMC interferon IFIT1 ISG15 CXCL10" to "covid_interferon_pbmc",
            "type 2 diabetes adipose insulin resistance TNF IL6" to "type2_diabetes_metabolic_inflammation",
            "lupus nephritis kidney biopsy type I interferon complement" to "lupus_nephritis_kidney_ifn",
            "IBD Crohn gut barrier IL23 intestinal mucosa" to "ibd_gut_barrier",
            "psoriasis skin plaque IL23 IL17 keratinocyte" to "psoriasis_skin_il23_il17",
            "sepsis septic shock neutrophil NETosis endothelium" to "sepsis_myeloid_endothelium",
            "obesity adipose inflammation macrophage leptin" to "obesity_metabolic_inflammation",
            "NASH liver fibrosis Kupffer TNF hepatic inflammation" to "liver_nash_inflammation",
            "kidney inflammation glomerulonephritis complement fibrosis" to "kidney_inflammation",
            "depression kynurenine IDO1 KMO neuroinflammation" to "depression_neuroinflammation"
        )

        cases.forEach { (topic, expectedRoute) ->
            val route = SpecialistRouterV30335.route(topic)
            val rows = CuratedLightMatrixFuelPackV30335.rowsFor(topic, "none")
            val labels = CuratedLightMatrixFuelPackV30335.groupLabelsFor(topic, "none")

            assertTrue("route inactive for $topic", route.active)
            assertEquals("wrong route for $topic", expectedRoute, route.routeId)
            assertEquals("curated matrix row count for $topic", 10, rows.size)
            assertTrue("case labels missing for $topic", labels.first.isNotEmpty())
            assertTrue("control labels missing for $topic", labels.second.isNotEmpty())
        }
    }

    @Test
    fun genericBloodPbmcInflammationDoesNotOpenSpecialistRoute() {
        val route = SpecialistRouterV30335.route("PBMC blood IL6 TNF generic inflammation cytokine")
        val rows = CuratedLightMatrixFuelPackV30335.rowsFor("PBMC blood IL6 TNF generic inflammation cytokine", "none")

        assertFalse(route.active)
        assertTrue(rows.isEmpty())
    }

    @Test
    fun explicitCuratedHypothesisSeedOpensButKeepsScoreCapAndCertificationBoundary() {
        val topic = "RA synovium pannus TNF IL6 IL17A MMP3 active vs healthy control"
        val route = SpecialistRouterV30335.route(topic)
        val rows = CuratedLightMatrixFuelPackV30335.rowsFor(topic, "none")
        val labels = CuratedLightMatrixFuelPackV30335.groupLabelsFor(topic, "none")
        val normalizedRows = rows.map { row -> row.copy(group = ComparatorGroupResolverV30330.normalizeLabel(row.group)) }
        val groupResolution = ComparatorGroupResolutionV30330(
            state = "COMPARATOR_GROUP_VALUES_RESOLVED_FROM_V30335_SEED_TEST",
            accession = "CURATED_RA_SYNOVIUM_PRIOR",
            caseLabels = labels.first.map { ComparatorGroupResolverV30330.normalizeLabel(it) },
            controlLabels = labels.second.map { ComparatorGroupResolverV30330.normalizeLabel(it) },
            unresolvedAxis = "ra_activity_vs_control",
            source = "v30335_curated_seed_test"
        )
        val fuel = MatrixFuelSnapshotV30330(
            state = "MATRIX_FUEL_READY_FOR_CURATED_PRIOR_DGE",
            accession = "CURATED_RA_SYNOVIUM_PRIOR",
            rowCount = normalizedRows.size,
            caseRowCount = normalizedRows.count { row -> groupResolution.caseLabels.any { row.group == it } },
            controlRowCount = normalizedRows.count { row -> groupResolution.controlLabels.any { row.group == it } },
            source = "curated_light_matrix_prior_v30335_hypothesis_discovery_seed",
            groupResolution = groupResolution,
            warnings = listOf("v30335_curated_light_matrix_prior_executes_hypothesis_discovery_seed_not_certified_discovery"),
            certificationLevel = CuratedLightMatrixFuelPackV30335.CERTIFICATION_LEVEL,
            analysisMode = CuratedLightMatrixFuelPackV30335.ANALYSIS_MODE,
            scientificInterpretability = CuratedLightMatrixFuelPackV30335.INTERPRETABILITY,
            fuelOrigin = CuratedLightMatrixFuelPackV30335.FUEL_ORIGIN,
            verificationLevel = "CURATED_PRIOR_NOT_VERIFIED",
            signalValidity = "CURATED_PRIOR_HYPOTHESIS_SIGNAL_NOT_VERIFIED"
        )
        val signal = ProcessedExpressionSignalReportV30329(
            active = true,
            state = "CURATED_PRIOR_DGE_EXECUTED_HYPOTHESIS_DISCOVERY_SEED",
            dataset = "CURATED_RA_SYNOVIUM_PRIOR",
            moduleCount = 1,
            rawMatrixDgeExecuted = true,
            estimates = listOf(
                ModuleSignalEstimateV30329(
                    accession = "CURATED_RA_SYNOVIUM_PRIOR",
                    module = route.moduleName,
                    markers = route.markers.take(6),
                    effectDirection = route.direction,
                    effectSize = 1.6,
                    confidenceInterval = "curated-prior-only",
                    pValueLabel = "review-only",
                    statisticState = "CURATED_PRIOR_DGE_REVIEW_ONLY",
                    rawMatrixDgeExecuted = true,
                    computedFrom = "CURATED_LIGHT_MATRIX_PRIOR",
                    supportState = "CURATED_PRIOR_RAW_MATRIX_SIGNAL_HYPOTHESIS_DISCOVERY_NOT_MECHANISM_SUPPORT"
                )
            ),
            nextAction = "Verify with ETL or replicated user-attested matrix before score >=8 or mechanism support.",
            matrixFuel = fuel
        )
        val gate = CertifiedMatrixFuelGateV30332.evaluate(signal)
        val seed = CuratedHypothesisDiscoverySeedBuilderV30335.evaluate(topic, route, signal, gate)

        assertTrue(seed.active)
        assertEquals("CURATED_PRIOR_HYPOTHESIS_DISCOVERY_SEED_OPENED_NOT_CERTIFIED", seed.state)
        assertEquals(7, seed.scoreCeiling)
        assertFalse(seed.mechanismSupportAllowed)
        assertFalse(seed.certifiedDiscoveryAllowed)
        assertTrue(seed.proposedHypothesis.contains("Rheumatoid", ignoreCase = true))
    }

    @Test
    fun concreteDatasetWithoutRowsPreservesPreviewOnlyContract() {
        val node = EvidenceNodeV3(
            id = "dataset-GSE146170-v30335-regression",
            type = EvidenceTypeV3.DATASET,
            accession = "GSE146170",
            title = "Allergic airway transcriptomics allergic patient vs healthy control",
            source = SourceKindV3.GEO,
            articleType = ArticleTypeV3.DATASET,
            role = EvidenceRoleV3.DATASET,
            qualityTier = QualityTierV3.A,
            supports = listOf("phenotype matched dataset"),
            query = "GSE146170 SOFT allergic healthy control"
        )
        val state = ResearchStateV3.initial(
            input = ResearchInputV3(topic = "allergy airway type2 immune mechanism allergic vs healthy control"),
            snapshot = EvidenceLedgerSnapshotV3(nodes = listOf(node), objectiveOutcomes = emptyList())
        )
        val report = ResearchReportCompilerV3().compile(
            state,
            ResearchClosureSnapshotV3(
                canCloseReport = false,
                openGates = listOf("raw_matrix_signal_pending"),
                visibleTierABCount = 1,
                visibleTierCDCount = 0,
                contradictionObjectiveExecuted = true,
                contradictionEvidenceFound = false,
                distinctAccessions = listOf("GSE146170"),
                contradictionObjectiveExhausted = true
            )
        )

        assertTrue(report.processedExpressionSignal.hasPreviewSupport)
        assertFalse(report.processedExpressionSignal.rawMatrixDgeExecuted)
        assertFalse(report.curatedHypothesisSeedV30335.active)
        assertFalse(report.processedExpressionSignal.hasMechanismSupport)
    }

}
