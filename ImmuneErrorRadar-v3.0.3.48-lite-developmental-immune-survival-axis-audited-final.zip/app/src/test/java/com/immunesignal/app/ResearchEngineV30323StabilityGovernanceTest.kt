package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30323StabilityGovernanceTest {
    @Test
    fun allergyTopicCannotScoreRenalIschemiaDataset() {
        val target = ResearchMetadataProbeTargetV3(
            accession = "GSE302163",
            title = "Renal ischemia reperfusion injury macrophage METosis single-cell study",
            softUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE302163&targ=gsm&form=text",
            state = "METADATA_PROBE_READY_GSE_SOFT_REVIEW_ONLY",
            comparatorStatus = "COMPARATOR_LABELS_REQUIRED_REVIEW_ONLY",
            processedExpressionRoute = "GREIN_OR_PROCESSED_EXPRESSION_ROUTE_CANDIDATE_REVIEW_ONLY",
            matrixStatus = "MATRIX_OR_PROCESSED_EXPRESSION_NOT_INGESTED",
            sampleMetadataStatus = "SOFT_METADATA_INGESTION_REQUIRED",
            expectedComparators = listOf("ischemia vs sham", "kidney macrophage"),
            routeQuestions = listOf("Does renal macrophage state match allergy IgE eosinophil route?"),
            nextAction = "Review renal ischemia metadata only.",
            boundary = "research-only"
        )
        val probe = ResearchMetadataProbeIngestionReportV3(
            active = true,
            state = "METADATA_PROBE_READY_REVIEW_ONLY",
            targets = listOf(target),
            primaryNextAction = target.nextAction,
            causalGap = "phenotype mismatch test",
            commercialReadinessNote = "none",
            boundary = "research-only"
        )
        val state = ResearchStateV3.initial(ResearchInputV3("allergy IgE eosinophil mast cell IL-4 IL-13 epithelial barrier"))
        val card = ResearchDatasetModuleScoreV3.evaluate(state, probe)
        assertFalse(card.active)
        assertEquals("BLOCKED_BY_DOMAIN_CAPSULE", card.decision)
        assertEquals("BLOCKED_BY_DOMAIN_CAPSULE", card.state)
        assertTrue(card.scoreGate.optString("blockedReason").contains("disease_alias_mismatch"))
    }

    @Test
    fun comparativeParserKeepsLeftRightFramesAndSharedAxis() {
        val parsed = ComparativeTwoFrameParserV30323.parse("rheumatoid arthritis vs multiple sclerosis IL-17 complement T cell transcriptome")
        assertTrue(parsed != null)
        val frame = parsed!!
        assertTrue(frame.leftFrame.rawInput.contains("rheumatoid", ignoreCase = true))
        assertTrue(frame.rightFrame.rawInput.contains("multiple sclerosis", ignoreCase = true))
        assertTrue(frame.sharedAxis.contains("IL-17", ignoreCase = true) || frame.sharedAxis.contains("complement", ignoreCase = true) || frame.sharedAxis.contains("T cell", ignoreCase = true))
        val queries = ComparativeTwoFrameParserV30323.queryTriplet("rheumatoid arthritis vs multiple sclerosis IL-17 complement T cell transcriptome", "GEO transcriptome")
        assertEquals(3, queries.size)
        assertTrue(queries[0].contains("rheumatoid", ignoreCase = true))
        assertTrue(queries[1].contains("multiple sclerosis", ignoreCase = true))
    }

    @Test
    fun runtimeBudgetCanPendModuleScoreAfterEvidenceReport() {
        val state = ResearchStateV3.initial(
            ResearchInputV3(
                topic = "SARS-CoV-2 COVID-19 immune dysregulation interferon timing",
                budget = ResearchBudgetV3(maxNetworkCalls = 0)
            )
        )
        val gate = ResearchRuntimeBudgetGateV30323.evaluate(state)
        val card = ResearchDatasetModuleScoreCardV3.pendingRuntimeBudget(gate)
        assertFalse(gate.moduleScoreAllowed)
        assertEquals("MODULE_SCORE_PENDING_RUNTIME_BUDGET", card.state)
        assertEquals("MODULE_SCORE_PENDING_RUNTIME_BUDGET", card.decision)
    }

    @Test
    fun rejectedIntentProducesNoGeneratedHypotheses() {
        val engine = ResearchEngineV3()
        val result = engine.run(ResearchInputV3("information"))
        val assessment = result.report.hypothesisAssessment
        assertEquals("INTENT_REJECTED_NO_HYPOTHESIS", assessment.hypothesisId)
        assertTrue(assessment.generatedHypotheses.isEmpty())
        assertTrue(assessment.summary.contains("No H1/H2"))
    }
    @Test
    fun rheumatoidTopicCannotBorrowDomainCapsuleForGenericGseScore() {
        val target = ResearchMetadataProbeTargetV3(
            accession = "GSE999999",
            title = "Generic peripheral blood transcriptome cohort",
            softUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE999999&targ=gsm&form=text",
            state = "METADATA_PROBE_READY_GSE_SOFT_REVIEW_ONLY",
            comparatorStatus = "COMPARATOR_LABELS_REQUIRED_REVIEW_ONLY",
            processedExpressionRoute = "GREIN_OR_PROCESSED_EXPRESSION_ROUTE_CANDIDATE_REVIEW_ONLY",
            matrixStatus = "MATRIX_OR_PROCESSED_EXPRESSION_NOT_INGESTED",
            sampleMetadataStatus = "SOFT_METADATA_INGESTION_REQUIRED",
            expectedComparators = listOf("case vs control"),
            routeQuestions = listOf("No rheumatoid synovial cytokine target match."),
            nextAction = "Do not score generic GSE from topic-only domain capsule fallback.",
            boundary = "research-only"
        )
        val probe = ResearchMetadataProbeIngestionReportV3(
            active = true,
            state = "METADATA_PROBE_READY_REVIEW_ONLY",
            targets = listOf(target),
            primaryNextAction = target.nextAction,
            causalGap = "generic dataset mismatch",
            commercialReadinessNote = "none",
            boundary = "research-only"
        )
        val state = ResearchStateV3.initial(ResearchInputV3("rheumatoid arthritis synovial macrophage TNF IL-6 IL-17"))
        val card = ResearchDatasetModuleScoreV3.evaluate(state, probe)
        assertFalse(card.active)
        assertEquals("BLOCKED_BY_DOMAIN_CAPSULE", card.decision)
        assertFalse(card.scoreGate.optBoolean("datasetEvidenceMatch", true))
        assertFalse(card.scoreGate.optBoolean("accessionCapsuleMatch", true))
        assertFalse(card.scoreGate.optBoolean("knownCuratedDatasetMatch", true))
    }

    @Test
    fun curatedCovidDatasetCanPassDomainCapsuleGateWithoutGenericFallback() {
        val target = ResearchMetadataProbeTargetV3(
            accession = "GSE152202",
            title = "SARS-CoV-2 PBMC transcriptome severe mild healthy control cohort",
            softUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE152202&targ=gsm&form=text",
            state = "METADATA_PROBE_READY_GSE_SOFT_REVIEW_ONLY",
            comparatorStatus = "COMPARATOR_LABELS_REQUIRED_REVIEW_ONLY",
            processedExpressionRoute = "GREIN_OR_PROCESSED_EXPRESSION_ROUTE_CANDIDATE_REVIEW_ONLY",
            matrixStatus = "MATRIX_OR_PROCESSED_EXPRESSION_NOT_INGESTED",
            sampleMetadataStatus = "SOFT_METADATA_INGESTION_REQUIRED",
            expectedComparators = listOf("severe COVID", "mild COVID", "healthy control"),
            routeQuestions = listOf("Does IFN timing and IL-6/TNF route fit COVID host response?"),
            nextAction = "Score COVID-specific module readiness only after metadata labels.",
            boundary = "research-only"
        )
        val gate = ResearchDatasetModuleScoreGatekeeperV30323.evaluate(
            topic = "COVID SARS-CoV-2 interferon timing IL-6 TNF endothelial immune dysregulation",
            target = target,
            capsule = GTIMLocalProcessedCapsuleStoreV21316.getCapsuleByAccession("GSE152202")
        )
        assertTrue(gate.allowed)
        assertTrue(gate.datasetEvidenceMatch)
        assertTrue(gate.accessionCapsuleMatch)
        assertTrue(gate.knownCuratedDatasetMatch)
    }

}
