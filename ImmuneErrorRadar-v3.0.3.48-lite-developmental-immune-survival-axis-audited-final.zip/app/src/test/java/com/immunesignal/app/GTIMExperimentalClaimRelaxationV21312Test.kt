package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMExperimentalClaimRelaxationV21312Test {
    @Test
    fun experimentalModeAllowsC2C3AndMedicalPreviewButNotPatientAction() {
        val report = JSONObject()
            .put("researchIntentDiscoveryRouterV21311", JSONObject()
                .put("lockedRoute", "depression_kynurenine_neuroimmune")
                .put("lockedSubtype", "nonviral_or_unspecified"))
            .put("finalUnifiedDiscoveryReadinessClosureV21310", JSONObject()
                .put("activeDomain", "depression_kynurenine_neuroimmune")
                .put("canonicalTarget", "GSE102556"))
            .put("evidenceLiftGateV2139", JSONObject()
                .put("c2Blockers", org.json.JSONArray(listOf("module_scores_preview_only"))))
        val relaxed = GTIMExperimentalClaimRelaxationV21312.toJson(report)
        assertEquals("FINAL_EXPERIMENTAL_CLAIM_RELAXATION_READY", relaxed.getString("state"))
        assertTrue(relaxed.getBoolean("c2PreviewAllowed"))
        assertTrue(relaxed.getBoolean("c3PreviewAllowed"))
        assertTrue(relaxed.getBoolean("therapeuticHypothesisPreviewAllowed"))
        assertTrue(relaxed.getBoolean("vaccineResponsePreviewAllowed"))
        assertTrue(relaxed.getBoolean("efficacyHypothesisPreviewAllowed"))
        assertFalse(relaxed.getBoolean("patientActionAllowed"))
        assertFalse(relaxed.getBoolean("dosingProtocolAllowed"))
        assertFalse(relaxed.getBoolean("clinicalImplementationAllowed"))
        assertFalse(relaxed.getBoolean("validatedProofClaimAllowed"))
    }
}
