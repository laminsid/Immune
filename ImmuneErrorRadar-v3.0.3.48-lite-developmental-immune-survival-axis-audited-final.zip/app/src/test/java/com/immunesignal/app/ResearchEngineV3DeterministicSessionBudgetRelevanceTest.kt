package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3DeterministicSessionBudgetRelevanceTest {
    @Test
    fun sessionSnapshotShowsAcceptedRejectedQueriesAndReplayKey() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = StaticEvidenceAdapterV3(
                mapOf(
                    "immune dysregulation pubmed" to listOf(
                        EvidenceSearchRecordV3("1001", "COVID-19 cytokine host response cohort", SourceKindV3.PUBMED, abstractText = "COVID-19 cytokine immune response cohort in patients."),
                        EvidenceSearchRecordV3("1002", "Parkinson unrelated review", SourceKindV3.PUBMED, abstractText = "Parkinson review without SARS-CoV-2 evidence.")
                    ),
                    "transcriptome geo" to listOf(
                        EvidenceSearchRecordV3("GSE9001", "COVID-19 PBMC transcriptome dataset", SourceKindV3.GEO, abstractText = "COVID-19 PBMC transcriptome dataset with healthy controls.")
                    ),
                    "tissue comparator limitation" to listOf(
                        EvidenceSearchRecordV3("3001", "COVID-19 tissue comparator limitation negative control cohort", SourceKindV3.PUBMED, abstractText = "COVID-19 negative control comparator study with tissue specificity limitation in human patients.")
                    )
                )
            ))
        ).run(ResearchInputV3("Covid", budget = ResearchBudgetV3(maxNetworkCalls = 14, maxEmptyQueries = 8)))

        val session = result.report.sessionSnapshot ?: error("session snapshot missing")
        assertTrue(session.normalizedQueryStem.contains("COVID", ignoreCase = true))
        assertTrue(session.queriesAttempted.isNotEmpty())
        assertTrue(session.acceptedEvidenceIds.isNotEmpty())
        assertTrue(session.rejectedEvidenceIds.isNotEmpty())
        assertTrue(session.replayKey.length >= 12)
    }

    @Test
    fun provenanceCannotConsumeContradictionReserve() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = StaticEvidenceAdapterV3(
                mapOf(
                    "immune dysregulation pubmed" to listOf(
                        EvidenceSearchRecordV3("1001", "COVID-19 cytokine host response cohort", SourceKindV3.PUBMED, abstractText = "COVID-19 cytokine immune response cohort in patients.")
                    ),
                    "transcriptome geo" to listOf(
                        EvidenceSearchRecordV3("GSE9001", "COVID-19 PBMC transcriptome dataset", SourceKindV3.GEO, abstractText = "COVID-19 PBMC transcriptome dataset with healthy controls.")
                    ),
                    "sample metadata" to listOf(
                        EvidenceSearchRecordV3("GSE9002", "COVID-19 sample metadata provenance", SourceKindV3.GEO, abstractText = "COVID-19 sample metadata provenance healthy controls.")
                    ),
                    "tissue comparator limitation" to listOf(
                        EvidenceSearchRecordV3("3001", "COVID-19 tissue comparator limitation negative control cohort", SourceKindV3.PUBMED, abstractText = "COVID-19 negative control comparator study with tissue specificity limitation in human patients.")
                    )
                )
            ))
        ).run(ResearchInputV3("Covid", budget = ResearchBudgetV3(maxNetworkCalls = 7, maxEmptyQueries = 8, contradictionQueryReserve = 3)))

        val executed = result.report.executedObjectives
        assertTrue(executed.any { it.startsWith("contradiction:") })
        val contradictionIndex = executed.indexOfFirst { it.startsWith("contradiction:") }
        val provenanceIndex = executed.indexOfFirst { it.startsWith("provenance:") }
        assertTrue(provenanceIndex < 0 || contradictionIndex < provenanceIndex)
    }

    @Test
    fun allergyReportRejectsCovidAndNeurologyDrift() {
        val covid = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "41452424",
                title = "Association between COVID-19 and New-Onset Autoimmune Diseases",
                source = SourceKindV3.PUBMED,
                abstractText = "COVID-19 autoimmune disease review with cytokine immune response."
            ),
            requestedRole = EvidenceRoleV3.SOURCE,
            topic = "Allergies",
            query = "allergy type 2 inflammation immune dysregulation PubMed"
        )
        val neuro = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "41696864",
                title = "Hippocampal Gene Expression in Mesial Temporal Lobe Epilepsy",
                source = SourceKindV3.PUBMED,
                abstractText = "Epilepsy hippocampal gene expression transcriptome study."
            ),
            requestedRole = EvidenceRoleV3.SOURCE,
            topic = "Allergies",
            query = "allergy type 2 inflammation immune dysregulation PubMed"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, covid.role)
        assertEquals(EvidenceRoleV3.CONTEXT, neuro.role)
        assertFalse(covid.satisfiesResearchRole(EvidenceRoleV3.SOURCE))
        assertFalse(neuro.satisfiesResearchRole(EvidenceRoleV3.SOURCE))
    }

    @Test
    fun contradictionRequiresTopicMatchAndRealFalsifierCue() {
        val weak = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "28089872",
                title = "Identification of airway mucosal type 2 inflammation by using clinical biomarkers in asthmatic patients",
                source = SourceKindV3.PUBMED,
                abstractText = "Asthma type 2 inflammation biomarker cohort in patients."
            ),
            requestedRole = EvidenceRoleV3.CONTRADICTION,
            topic = "Allergies",
            query = "allergy type 2 inflammation contradiction limitation negative control"
        )
        val strong = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "3001",
                title = "Allergic asthma type 2 inflammation negative control comparator limitation cohort",
                source = SourceKindV3.PUBMED,
                abstractText = "Allergic asthma cohort with healthy control comparator and negative control analysis showing no association in a tissue-specific subgroup."
            ),
            requestedRole = EvidenceRoleV3.CONTRADICTION,
            topic = "Allergies",
            query = "allergy type 2 inflammation contradiction limitation negative control"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, weak.role)
        assertFalse(weak.satisfiesResearchRole(EvidenceRoleV3.CONTRADICTION))
        assertEquals(EvidenceRoleV3.CONTRADICTION, strong.role)
        assertTrue(strong.satisfiesResearchRole(EvidenceRoleV3.CONTRADICTION))
    }
}
