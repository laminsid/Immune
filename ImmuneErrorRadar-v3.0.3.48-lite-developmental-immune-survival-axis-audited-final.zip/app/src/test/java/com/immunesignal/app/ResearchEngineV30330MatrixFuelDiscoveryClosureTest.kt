package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30330MatrixFuelDiscoveryClosureTest {
    @Test
    fun previewDoesNotCountAsMechanismSupportWithoutExplicitMatrixRows() {
        val state = stateWithDataset()
        val closure = closure()
        val report = ResearchReportCompilerV3().compile(state, closure)
        assertTrue(report.processedExpressionSignal.hasPreviewSupport)
        assertFalse(report.processedExpressionSignal.hasMechanismSupport)
        assertFalse(report.processedExpressionSignal.rawMatrixDgeExecuted)
        assertFalse(report.professionalDiscoveryReport.cards.first().state.contains("DISCOVERY_CANDIDATE"))
    }

    @Test
    fun explicitMatrixRowsWithoutVerifiedProvenanceStayReviewOnly() {
        val rows = listOf(
            ExpressionSampleRowV30329("case1", "allergic", mapOf("IL4" to 9.0, "IL5" to 8.0, "IL13" to 10.0)),
            ExpressionSampleRowV30329("case2", "allergic", mapOf("IL4" to 10.0, "IL5" to 9.0, "IL13" to 11.0)),
            ExpressionSampleRowV30329("case3", "allergic", mapOf("IL4" to 11.0, "IL5" to 10.0, "IL13" to 12.0)),
            ExpressionSampleRowV30329("ctrl1", "control", mapOf("IL4" to 2.0, "IL5" to 2.0, "IL13" to 3.0)),
            ExpressionSampleRowV30329("ctrl2", "control", mapOf("IL4" to 3.0, "IL5" to 3.0, "IL13" to 4.0)),
            ExpressionSampleRowV30329("ctrl3", "control", mapOf("IL4" to 4.0, "IL5" to 4.0, "IL13" to 5.0))
        )
        val state = stateWithDataset(rows)
        val closure = closure(canClose = true)
        val report = ResearchReportCompilerV3().compile(state, closure)
        assertTrue(report.processedExpressionSignal.rawMatrixDgeExecuted)
        assertFalse(report.processedExpressionSignal.hasMechanismSupport)
        assertTrue(report.processedExpressionSignal.matrixFuel?.rawRowsReady == true)
        assertFalse(report.processedExpressionSignal.matrixFuel?.certifiedForDiscovery == true)
    }

    @Test
    fun matrixCalculatorUsesCorrectedPValues() {
        val rows = listOf(
            ExpressionSampleRowV30329("case1", "case", mapOf("CD8A" to 10.0, "GZMB" to 9.0)),
            ExpressionSampleRowV30329("case2", "case", mapOf("CD8A" to 11.0, "GZMB" to 10.0)),
            ExpressionSampleRowV30329("case3", "case", mapOf("CD8A" to 12.0, "GZMB" to 11.0)),
            ExpressionSampleRowV30329("ctrl1", "control", mapOf("CD8A" to 2.0, "GZMB" to 1.0)),
            ExpressionSampleRowV30329("ctrl2", "control", mapOf("CD8A" to 3.0, "GZMB" to 2.0)),
            ExpressionSampleRowV30329("ctrl3", "control", mapOf("CD8A" to 4.0, "GZMB" to 3.0))
        )
        val result = ProcessedExpressionMatrixCalculatorV30329.calculate(rows, listOf("case"), listOf("control"), listOf("CD8A", "GZMB"))
        assertTrue(result.isNotEmpty())
        assertTrue(result.all { it.adjustedPValue >= it.pValue })
        assertTrue(result.all { it.degreesOfFreedom > 0.0 })
    }

    private fun stateWithDataset(rows: List<ExpressionSampleRowV30329> = emptyList()): ResearchStateV3 {
        val node = EvidenceNodeV3(
            id = "dataset-GSE146170",
            type = EvidenceTypeV3.DATASET,
            accession = "GSE146170",
            title = "Allergic airway transcriptomics allergic patient vs healthy control",
            source = SourceKindV3.GEO,
            articleType = ArticleTypeV3.DATASET,
            role = EvidenceRoleV3.DATASET,
            qualityTier = QualityTierV3.A,
            supports = listOf("phenotype matched dataset"),
            query = "GSE146170 SOFT allergic healthy control"
        )
        return ResearchStateV3.initial(
            input = ResearchInputV3(
                topic = "allergy airway type2 immune mechanism allergic vs healthy control",
                explicitMatrixRows = rows
            ),
            snapshot = EvidenceLedgerSnapshotV3(nodes = listOf(node), objectiveOutcomes = emptyList())
        )
    }

    private fun closure(canClose: Boolean = false): ResearchClosureSnapshotV3 = ResearchClosureSnapshotV3(
        canCloseReport = canClose,
        openGates = if (canClose) emptyList() else listOf("raw_matrix_signal_pending"),
        visibleTierABCount = 1,
        visibleTierCDCount = 0,
        contradictionObjectiveExecuted = true,
        contradictionEvidenceFound = false,
        distinctAccessions = listOf("GSE146170"),
        contradictionObjectiveExhausted = true
    )
}
