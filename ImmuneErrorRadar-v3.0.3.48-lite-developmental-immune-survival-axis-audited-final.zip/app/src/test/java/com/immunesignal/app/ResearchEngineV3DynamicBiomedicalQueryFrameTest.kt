package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3DynamicBiomedicalQueryFrameTest {
    @Test
    fun hantaVirusUsesAliasAcceleratedDynamicMeshStyleQueries() {
        val frame = BiomedicalTopicFrameV3.from("Hanta virus immune response")
        val queries = DomainQueryTemplateV3.sourceQueries("Hanta virus immune response")
        val joined = queries.joinToString(" ").lowercase()

        assertTrue(frame.domain == ResearchDomainV3.GENERAL_IMMUNE)
        assertTrue(joined.contains("hantavirus"))
        assertTrue(joined.contains("hfrs"))
        assertTrue(joined.contains("hantavirus pulmonary syndrome"))
        assertTrue(joined.contains("cytokine") || joined.contains("interferon"))
        assertTrue(joined.contains("endothelial") || joined.contains("vascular leakage"))
        assertTrue(joined.contains(" and "))
        assertFalse(joined.contains("hanta virus immune mechanism cohort pubmed"))
    }

    @Test
    fun lupusBuildsDynamicAutoimmuneQueryWithoutHandTemplate() {
        val frame = BiomedicalTopicFrameV3.from("Lupus interferon complement immune response")
        val queries = DomainQueryTemplateV3.sourceQueries("Lupus interferon complement immune response")
        val joined = queries.joinToString(" ").lowercase()

        assertTrue(frame.domain == ResearchDomainV3.GENERAL_IMMUNE)
        assertTrue(joined.contains("systemic lupus erythematosus"))
        assertTrue(joined.contains("sle"))
        assertTrue(joined.contains("interferon"))
        assertTrue(joined.contains("complement"))
        assertFalse(joined.contains("lupus interferon complement immune response immune mechanism cohort pubmed"))
    }

    @Test
    fun pfasExposureBuildsExposureImmuneQueryWithoutDiseaseTemplate() {
        val frame = BiomedicalTopicFrameV3.from("PFAS immune disruption antibody response")
        val queries = DomainQueryTemplateV3.sourceQueries("PFAS immune disruption antibody response")
        val joined = queries.joinToString(" ").lowercase()

        assertTrue(frame.domain == ResearchDomainV3.GENERAL_IMMUNE)
        assertTrue(joined.contains("pfas"))
        assertTrue(joined.contains("per- and polyfluoroalkyl substances"))
        assertTrue(joined.contains("immune disruption") || joined.contains("immunotoxicity"))
        assertTrue(joined.contains("antibody response") || joined.contains("vaccine response"))
    }

    @Test
    fun unknownGeneralImmuneTopicUsesDynamicFrameNotRawBlindSuffix() {
        val queries = DomainQueryTemplateV3.sourceQueries("novel viral infection cytokine PBMC transcriptome")
        val joined = queries.joinToString(" ").lowercase()

        assertTrue(joined.contains("viral infection"))
        assertTrue(joined.contains("cytokine"))
        assertTrue(joined.contains("pbmc") || joined.contains("transcriptome"))
        assertFalse(joined.contains("novel viral infection cytokine pbmc transcriptome immune mechanism cohort pubmed"))
    }

    @Test
    fun dynamicConceptsAreExposedInSessionSnapshot() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = StaticEvidenceAdapterV3(emptyMap()))
        ).run(ResearchInputV3("Hanta virus immune response"))
        val snapshot = result.report.sessionSnapshot?.toJson()
        val concepts = snapshot?.optJSONObject("genericBiomedicalConcepts")

        assertTrue(concepts != null)
        assertTrue(concepts!!.optJSONArray("diseaseOrExposureTerms").toString().lowercase().contains("hantavirus"))
        assertTrue(concepts.optJSONArray("mechanismTerms").toString().lowercase().contains("cytokine") || concepts.optJSONArray("mediatorTerms").toString().lowercase().contains("interferon"))
    }
}
