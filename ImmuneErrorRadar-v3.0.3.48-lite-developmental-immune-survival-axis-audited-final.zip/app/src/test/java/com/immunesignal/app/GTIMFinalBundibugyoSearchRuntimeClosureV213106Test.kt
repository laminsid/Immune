package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalBundibugyoSearchRuntimeClosureV213106Test {
    @Test
    fun bundibugyoLeavesCanonicalEmptyAndBlocksCovidFallback() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Ebola Bundibugyo BDBV immune host response"))
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "viral_interferon_cytokine"))
            .put("verifiedMetadataClosurePackV2132", JSONObject()
                .put("state", "VERIFIED_METADATA_CLOSURE_READY")
                .put("selectedClosedTarget", "GSE166552"))
            .put("finalDataClosureExecutionV2132", JSONObject()
                .put("readinessScore", 8)
                .put("selectedClosedTarget", "GSE166552"))
            .put("injectedMetadataSeedPackV21216", JSONObject()
                .put("candidateHandles", JSONArray(listOf("GSE166552", "GSE131907", "GSE45291"))))
        assertEquals("filovirus_viral_host_response", GTIMFinalBundibugyoSearchRuntimeClosureV213106.effectiveActiveDomain(report))
        assertEquals("viral_filovirus_bundibugyo", GTIMFinalBundibugyoSearchRuntimeClosureV213106.effectiveSubtype(report))
        assertEquals("", GTIMFinalBundibugyoSearchRuntimeClosureV213106.finalCanonicalTarget(report))
        assertEquals("", GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report))
        assertFalse(GTIMFinalBundibugyoSearchRuntimeClosureV213106.targetAllowed("GSE166552", "viral_filovirus_bundibugyo"))
        val closure = GTIMFinalBundibugyoSearchRuntimeClosureV213106.toJson(report, "TEST")
        assertTrue(closure.getJSONArray("blockedCovidTargets").toString().contains("GSE166552"))
    }

    @Test
    fun filovirusDoesNotUseCovidTargetAndPrefersGSE45291() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Ebola filovirus cytokine host response"))
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "viral_interferon_cytokine"))
            .put("verifiedMetadataClosurePackV2132", JSONObject()
                .put("state", "VERIFIED_METADATA_CLOSURE_READY")
                .put("selectedClosedTarget", "GSE166552"))
            .put("injectedMetadataSeedPackV21216", JSONObject()
                .put("candidateHandles", JSONArray(listOf("GSE166552", "GSE45291"))))
        assertEquals("viral_filovirus", GTIMFinalBundibugyoSearchRuntimeClosureV213106.effectiveSubtype(report))
        assertEquals("GSE45291", GTIMFinalBundibugyoSearchRuntimeClosureV213106.finalCanonicalTarget(report))
        assertEquals("GSE45291", GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report))
        assertFalse(GTIMFinalBundibugyoSearchRuntimeClosureV213106.targetAllowed("GSE166552", "viral_filovirus"))
    }

    @Test
    fun filovirusWithoutCompatibleCapsuleKeepsMatrixHandleEmptyAfterCanonicalLock() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Ebola Bundibugyo"))
            .put("candidateHandleLedgerV21215", JSONObject().put("selectedReviewTarget", "GSE166552"))
            .put("verifiedMetadataClosurePackV2132", JSONObject().put("selectedClosedTarget", "GSE166552"))
        report.put("canonicalFinalSurfaceGuardV2135", GTIMCanonicalFinalSurfaceGuardV2135.toJson(report))
        val matrix = GTIMMatrixShortcutResolverV2124.toJson(report)
        assertEquals("", GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report))
        assertEquals("", matrix.getString("handle"))
    }

    @Test
    fun runtimeFallbackMessageIsSafeAndExportFirst() {
        val msg = GTIMFinalBundibugyoSearchRuntimeClosureV213106.compactRuntimeFallback("UI_RENDER", IllegalStateException("boom"))
        assertTrue(msg.contains("Report saved safely"))
        assertTrue(msg.contains("Export PDF"))
    }
}
