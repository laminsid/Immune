package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMGeneralizedRouteCoherenceGuardV21314Test {
    @Test
    fun hantavirusSurfaceDoesNotBorrowCovidOrFilovirusRoute() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Hantavirus host response vascular injury research dossier"))
            .put("finalUnifiedDiscoveryReadinessClosureV21310", JSONObject()
                .put("activeDomain", "viral_interferon_cytokine")
                .put("activeSubtype", "viral_hantavirus")
                .put("canonicalTarget", ""))
        val lines = GTIMFinalSurfaceDomainCoherenceGuardV21313.sanitizeFirstSurfaceLines(
            report,
            listOf(
                "Study focus: viral interferon-cytokine host-response study",
                "Research route: current-topic route: COVID -> interferon/IL-6/TNF -> COVID; prior templates retrieval-only",
                "Next best action: Inspect GSE152202 as the canonical target",
                "Top research hypothesis: filovirus outcome may be stratified by endothelial injury"
            )
        ).joinToString("\n")

        assertTrue(lines.contains("Study focus: hantavirus host-response study"))
        assertTrue(lines.contains("active-domain route: hantavirus host-response"))
        assertFalse(lines.contains("COVID -> interferon/IL-6/TNF -> COVID"))
        assertFalse(lines.contains("Inspect GSE152202 as the canonical target"))
        assertFalse(lines.contains("filovirus outcome may be stratified"))
    }

    @Test
    fun allergySurfaceDemotesViralDatasetHandleGenerally() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Allergy type-2 IgE mast eosinophil barrier study"))
            .put("finalUnifiedDiscoveryReadinessClosureV21310", JSONObject()
                .put("activeDomain", "allergy_type2_barrier")
                .put("activeSubtype", "nonviral_or_unspecified")
                .put("canonicalTarget", "GSE146170"))
        val lines = GTIMFinalSurfaceDomainCoherenceGuardV21313.sanitizeFirstSurfaceLines(
            report,
            listOf(
                "Study focus: viral interferon-cytokine host-response study",
                "Candidate handle ledger State: selected_review_target=GSE152202",
                "Next best action: Inspect GSE152202 as the canonical target"
            )
        ).joinToString("\n")

        assertTrue(lines.contains("Study focus: allergy/type-2 microbiome-barrier study"))
        assertTrue(lines.contains("cross-domain for active_domain=allergy_type2_barrier"))
        assertFalse(lines.contains("Inspect GSE152202 as the canonical target"))
    }

    @Test
    fun dengueSurfaceDoesNotRenderFilovirusPrimaryRoute() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Dengue DENV vascular leak host response severity study"))
            .put("finalUnifiedDiscoveryReadinessClosureV21310", JSONObject()
                .put("activeDomain", "viral_interferon_cytokine")
                .put("activeSubtype", "viral_dengue")
                .put("canonicalTarget", ""))
        val lines = GTIMFinalSurfaceDomainCoherenceGuardV21313.sanitizeFirstSurfaceLines(
            report,
            listOf(
                "Study focus: filovirus host-response study",
                "Research route: active-domain route: filovirus → host-response/capsule/module execution",
                "Candidate handle ledger State: selected_review_target=GSE45291"
            )
        ).joinToString("\n")

        assertTrue(lines.contains("Study focus: dengue host-response study"))
        assertTrue(lines.contains("active-domain route: dengue host-response"))
        assertFalse(lines.contains("filovirus → host-response"))
        assertFalse(lines.contains("selected_review_target=GSE45291"))
    }
    @Test
    fun incompatibleCanonicalTargetIsNotAcceptedForActiveDomain() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "COVID post-viral interferon cytokine host response study"))
            .put("finalUnifiedDiscoveryReadinessClosureV21310", JSONObject()
                .put("activeDomain", "viral_interferon_cytokine")
                .put("activeSubtype", "viral_covid_postviral")
                .put("canonicalTarget", "GSE45291"))

        assertEquals("", GTIMFinalSurfaceDomainCoherenceGuardV21313.canonicalTarget(report))
        val line = GTIMFinalSurfaceDomainCoherenceGuardV21313.sanitizeFirstSurfaceLines(
            report,
            listOf("Next best action: Inspect GSE45291 as the canonical target; keep GSE45291 as appendix/history only until it proves topic compatibility.")
        ).joinToString("\n")

        assertTrue(line.contains("not_active_target") || line.contains("select a topic-compatible canonical target"))
        assertFalse(line.contains("superseded_by_canonical_target=GSE45291"))
    }

    @Test
    fun finalReleaseLockDoesNotFallbackToLegacySelectedTargetWhenCanonicalIsEmpty() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Bundibugyo Ebola BDBV host response research dossier"))
            .put("candidateHandleLedgerV21215", JSONObject().put("selectedReviewTarget", "GSE131907"))
            .put("finalBundibugyoSearchRuntimeClosureV213106", JSONObject()
                .put("activeDomain", "filovirus_viral_host_response")
                .put("activeSubtype", "viral_filovirus_bundibugyo")
                .put("canonicalTarget", ""))

        val lock = GTIMFinalReleaseLockV21219.toJson(report)

        assertEquals("", lock.optString("selectedReviewTarget"))
        assertTrue(lock.optJSONArray("hardGatesOpen").toString().contains("selected_review_target_missing"))
    }

    @Test
    fun studyCardKeepsCrossDomainLearningOutOfFirstSurface() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Bundibugyo Ebola BDBV host response research dossier"))
            .put("finalBundibugyoSearchRuntimeClosureV213106", JSONObject()
                .put("activeDomain", "filovirus_viral_host_response")
                .put("activeSubtype", "viral_filovirus_bundibugyo")
                .put("canonicalTarget", ""))
            .put("globalReportLearningV2124", JSONObject()
                .put("repeatedMechanisms", org.json.JSONArray(listOf("microbiome/barrier dysfunction", "IgE/mast-cell/eosinophil type-2 axis")))
                .put("repeatedBlockers", org.json.JSONArray(listOf("matrix/file evidence missing"))))

        val lines = GTIMStudyResultCardV2126.publicLines(report).joinToString("\n")

        assertTrue(lines.contains("active-domain learning only"))
        assertFalse(lines.contains("IgE/mast-cell/eosinophil"))
        assertFalse(lines.contains("microbiome/barrier dysfunction"))
    }

}
