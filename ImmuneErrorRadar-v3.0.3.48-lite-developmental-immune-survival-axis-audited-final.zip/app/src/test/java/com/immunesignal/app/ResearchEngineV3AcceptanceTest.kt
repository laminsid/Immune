package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3AcceptanceTest {
    @Test
    fun fixedTenTasksCannotCloseResearchByItself() {
        val emptySnapshot = EvidenceLedgerSnapshotV3(
            nodes = emptyList(),
            objectiveOutcomes = List(10) { index ->
                ResearchObjectiveOutcomeV3(
                    objective = ResearchObjectiveV3.RankHypotheses("Ebola Bundibugyo immune dysregulation"),
                    queriesAttempted = emptyList(),
                    nodes = emptyList(),
                    exhausted = false,
                    notes = listOf("legacy_fixed_task_$index")
                )
            }
        )
        val state = ResearchStateV3.initial(
            ResearchInputV3("Ebola Bundibugyo immune dysregulation"),
            emptySnapshot
        )
        val closure = ResearchClosurePolicyV3().evaluate(state)
        assertFalse(closure.canCloseReport)
        assertTrue(closure.openGates.contains("visible_source_evidence"))
        assertTrue(closure.openGates.contains("contradiction_objective_not_executed"))
    }

    @Test
    fun missingContradictionSpawnsContradictionObjective() {
        val result = engineWith(baseRecordsWithoutContradiction()).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result is ResearchResultV3.ReportReady)
        assertTrue(result.report.executedObjectives.any { it.startsWith("contradiction:") })
        assertTrue(result.closure.contradictionObjectiveExecuted)
        assertTrue(result.closure.contradictionObjectiveExhausted)
        assertFalse(result.closure.contradictionEvidenceFound)
        assertTrue(result.closure.noValidFalsifierFoundAfterSearch)
        assertFalse(result.closure.openGates.contains("visible_contradiction_falsification"))
    }

    @Test
    fun newsArticleCannotSatisfyDatasetEvidence() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "NEWS-1",
                title = "A Rare Ebola Virus Is Spreading in the DRC Here s What to Know",
                source = SourceKindV3.NEWS
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = "Ebola Bundibugyo immune dysregulation",
            query = "Ebola Bundibugyo transcriptome GEO"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertEquals(QualityTierV3.D, node.qualityTier)
        assertFalse(node.satisfiesResearchRole(EvidenceRoleV3.DATASET))
    }

    @Test
    fun onePubMedCannotTripleCountAsSourceProvenanceContradiction() {
        val sameAccession = "PMID:42213453"
        val nodes = listOf(
            node("source", sameAccession, EvidenceRoleV3.SOURCE, EvidenceTypeV3.SOURCE),
            node("provenance", sameAccession, EvidenceRoleV3.PROVENANCE, EvidenceTypeV3.PROVENANCE),
            node("contradiction", sameAccession, EvidenceRoleV3.CONTRADICTION, EvidenceTypeV3.CONTRADICTION)
        )
        val snapshot = EvidenceLedgerSnapshotV3(nodes = nodes, objectiveOutcomes = listOf(
            ResearchObjectiveOutcomeV3(
                objective = ResearchObjectiveV3.FindContradiction("Ebola Bundibugyo immune dysregulation", "H1_PRIMARY"),
                queriesAttempted = listOf("Bundibugyo species model limitation"),
                nodes = listOf(nodes.last()),
                exhausted = false
            )
        ))
        val state = ResearchStateV3.initial(ResearchInputV3("Ebola Bundibugyo immune dysregulation"), snapshot)
        val closure = ResearchClosurePolicyV3().evaluate(state)
        assertFalse(closure.canCloseReport)
        assertEquals(1, closure.distinctAccessions.size)
        assertTrue(closure.openGates.contains("minimum_independent_accessions"))
    }

    @Test
    fun displayedEvidenceEqualsLedgerEvidence() {
        val result = engineWith(baseRecordsWithContradiction()).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result.report.displayedEvidenceEqualsLedger())
        assertEquals(result.state.ledgerSnapshot.visibleEvidenceIds, result.report.countedEvidenceIds)
    }

    @Test
    fun checkpointShowsExecutedObjectivesNotSuggestionsOnly() {
        val result = engineWith(baseRecordsWithoutContradiction()).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result is ResearchResultV3.ReportReady)
        assertTrue(result.report.executedObjectives.any { it.startsWith("contradiction:") })
        val contradictionOutcome = result.state.ledgerSnapshot.objectiveOutcomes.first { it.objective is ResearchObjectiveV3.FindContradiction }
        assertTrue(contradictionOutcome.queriesAttempted.isNotEmpty())
        assertTrue(contradictionOutcome.exhausted)
        assertTrue(result.closure.noValidFalsifierFoundAfterSearch)
    }

    @Test
    fun reportReadyRequiresVisibleTierAorTierBResearchEvidence() {
        val weakAdapter = StaticEvidenceAdapterV3(
            mapOf(
                "immune dysregulation pubmed" to listOf(
                    EvidenceSearchRecordV3("NEWS-2", "A Rare Ebola Virus Is Spreading in the DRC Here s What to Know", SourceKindV3.NEWS)
                ),
                "transcriptome geo" to listOf(
                    EvidenceSearchRecordV3("NEWS-3", "Outbreak update: what to know about Ebola", SourceKindV3.NEWS)
                ),
                "tissue comparator limitation" to listOf(
                    EvidenceSearchRecordV3("NEWS-4", "Ebola outbreak commentary with general limitations", SourceKindV3.NEWS)
                )
            )
        )
        val result = engineWith(weakAdapter).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result is ResearchResultV3.CheckpointReady)
        assertTrue(result.closure.openGates.contains("no_visible_tier_a_or_b_research_evidence"))
        assertFalse(result.closure.canCloseReport)
    }

    @Test
    fun completeEvidenceCanCloseReportWithoutTimeGuard() {
        val result = engineWith(baseRecordsWithContradiction()).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result is ResearchResultV3.ReportReady)
        assertTrue(result.closure.contradictionObjectiveExecuted)
        assertTrue(result.closure.contradictionEvidenceFound)
        assertTrue(result.closure.distinctAccessions.size >= 2)
    }

    private fun engineWith(adapter: EvidenceAdapterV3): ResearchEngineV3 = ResearchEngineV3(
        executor = ResearchObjectiveExecutorV3(adapter = adapter)
    )

    private fun baseRecordsWithoutContradiction(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3("1001", "Bundibugyo Ebola host response mechanistic review", SourceKindV3.PUBMED)
            ),
            "transcriptome geo" to listOf(
                EvidenceSearchRecordV3("GSE2001", "Bundibugyo Ebola transcriptome GEO dataset cohort", SourceKindV3.GEO)
            ),
            "sample provenance" to listOf(
                EvidenceSearchRecordV3("GSE2002", "Bundibugyo Ebola sample provenance comparator labels cohort", SourceKindV3.GEO)
            )
        )
    )

    private fun baseRecordsWithContradiction(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3("1001", "Bundibugyo Ebola host response mechanistic review", SourceKindV3.PUBMED)
            ),
            "transcriptome geo" to listOf(
                EvidenceSearchRecordV3("GSE2001", "Bundibugyo Ebola transcriptome GEO dataset cohort", SourceKindV3.GEO)
            ),
            "sample provenance" to listOf(
                EvidenceSearchRecordV3("GSE2002", "Bundibugyo Ebola sample provenance comparator labels cohort", SourceKindV3.GEO)
            ),
            "tissue comparator limitation" to listOf(
                EvidenceSearchRecordV3("3001", "Bundibugyo Ebola tissue comparator limitation cohort falsification study", SourceKindV3.PUBMED)
            )
        )
    )

    private fun node(id: String, accession: String, role: EvidenceRoleV3, type: EvidenceTypeV3): EvidenceNodeV3 = EvidenceNodeV3(
        id = id,
        type = type,
        accession = accession,
        title = "Bundibugyo Ebola $id cohort evidence",
        source = SourceKindV3.PUBMED,
        articleType = ArticleTypeV3.COHORT,
        role = role,
        qualityTier = QualityTierV3.A,
        supports = if (role == EvidenceRoleV3.CONTRADICTION) emptyList() else listOf("Ebola Bundibugyo immune dysregulation"),
        contradicts = if (role == EvidenceRoleV3.CONTRADICTION) listOf("H1_PRIMARY") else emptyList()
    )
}

class ResearchEngineV3GapPlannerAcceptanceTest {
    @Test
    fun plannerTraceExplainsWhyContradictionWasSpawned() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = gapBaseRecordsWithoutContradiction())
        ).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result is ResearchResultV3.ReportReady)
        assertTrue(result.report.plannerTrace.any { it.contains("GAP_CONTRADICTION") })
        assertTrue(result.report.openGapDiagnostics.any { it.gateName == "no_valid_falsifier_found_after_exhausted_search" })
    }

    @Test
    fun gapDetectorReturnsSourceGapBeforeDatasetGapForEmptyLedger() {
        val state = ResearchStateV3.initial(ResearchInputV3("Ebola Bundibugyo immune dysregulation"))
        val gaps = ResearchGapDetectorV3.detect(state)
        assertTrue(gaps.isNotEmpty())
        assertEquals("GAP_SOURCE_EVIDENCE", gaps.first().id)
        assertTrue(gaps.any { it.id == "GAP_DATASET_OR_PROVENANCE" })
    }

    @Test
    fun engineReportNameDoesNotCollideWithLegacyResearchReportV3() {
        val legacy = ResearchReportV3.empty()
        val engineReport = ResearchEngineReportV3(
            topic = "Ebola Bundibugyo immune dysregulation",
            status = ResearchRunStatusV3.CHECKPOINT_READY,
            displayedEvidence = emptyList(),
            countedEvidenceIds = emptyList(),
            executedObjectives = emptyList(),
            openGates = listOf("visible_source_evidence"),
            closure = ResearchClosureSnapshotV3(
                canCloseReport = false,
                openGates = listOf("visible_source_evidence"),
                visibleTierABCount = 0,
                visibleTierCDCount = 0,
                contradictionObjectiveExecuted = false,
                contradictionEvidenceFound = false,
                distinctAccessions = emptyList()
            )
        )
        assertEquals("No cycle yet", legacy.cycleResult)
        assertEquals("Ebola Bundibugyo immune dysregulation", engineReport.topic)
    }

    @Test
    fun sameAccessionCannotSatisfyCriticalSourceProvenanceAndContradictionRoles() {
        val reused = "PMID:999"
        val dataset = "GSE-INDEPENDENT"
        val nodes = listOf(
            EvidenceNodeV3(
                id = "src",
                type = EvidenceTypeV3.SOURCE,
                accession = reused,
                title = "Bundibugyo Ebola source cohort",
                source = SourceKindV3.PUBMED,
                articleType = ArticleTypeV3.COHORT,
                role = EvidenceRoleV3.SOURCE,
                qualityTier = QualityTierV3.A,
                supports = listOf("Ebola Bundibugyo immune dysregulation")
            ),
            EvidenceNodeV3(
                id = "dataset",
                type = EvidenceTypeV3.DATASET,
                accession = dataset,
                title = "Bundibugyo Ebola transcriptome GEO dataset cohort",
                source = SourceKindV3.GEO,
                articleType = ArticleTypeV3.DATASET,
                role = EvidenceRoleV3.DATASET,
                qualityTier = QualityTierV3.A,
                supports = listOf("Ebola Bundibugyo immune dysregulation")
            ),
            EvidenceNodeV3(
                id = "prov",
                type = EvidenceTypeV3.PROVENANCE,
                accession = reused,
                title = "Bundibugyo Ebola provenance reused from same PMID",
                source = SourceKindV3.PUBMED,
                articleType = ArticleTypeV3.COHORT,
                role = EvidenceRoleV3.PROVENANCE,
                qualityTier = QualityTierV3.A,
                supports = listOf("Ebola Bundibugyo immune dysregulation")
            ),
            EvidenceNodeV3(
                id = "contra",
                type = EvidenceTypeV3.CONTRADICTION,
                accession = reused,
                title = "Bundibugyo Ebola contradiction reused from same PMID",
                source = SourceKindV3.PUBMED,
                articleType = ArticleTypeV3.COHORT,
                role = EvidenceRoleV3.CONTRADICTION,
                qualityTier = QualityTierV3.A,
                contradicts = listOf("H1_PRIMARY")
            )
        )
        val snapshot = EvidenceLedgerSnapshotV3(
            nodes = nodes,
            objectiveOutcomes = listOf(
                ResearchObjectiveOutcomeV3(
                    objective = ResearchObjectiveV3.FindContradiction("Ebola Bundibugyo immune dysregulation", "H1_PRIMARY"),
                    queriesAttempted = listOf("Bundibugyo contradiction query"),
                    nodes = listOf(nodes.last()),
                    exhausted = false
                ),
                ResearchObjectiveOutcomeV3(
                    objective = ResearchObjectiveV3.RankHypotheses("Ebola Bundibugyo immune dysregulation"),
                    queriesAttempted = emptyList(),
                    nodes = emptyList(),
                    exhausted = false
                )
            )
        )
        val state = ResearchStateV3.initial(ResearchInputV3("Ebola Bundibugyo immune dysregulation"), snapshot)
        val closure = ResearchClosurePolicyV3().evaluate(state)
        assertFalse(closure.criticalRoleIndependencePassed)
        assertFalse(closure.openGates.contains("critical_role_independence_violation"))
        assertTrue("role overlap is surfaced as metadata, not a hard closure gate", closure.openGates.none { it == "critical_role_independence_violation" })
    }

    private fun gapBaseRecordsWithoutContradiction(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3("1001", "Bundibugyo Ebola host response mechanistic review", SourceKindV3.PUBMED)
            ),
            "transcriptome geo" to listOf(
                EvidenceSearchRecordV3("GSE2001", "Bundibugyo Ebola transcriptome GEO dataset cohort", SourceKindV3.GEO)
            ),
            "sample provenance" to listOf(
                EvidenceSearchRecordV3("GSE2002", "Bundibugyo Ebola sample provenance comparator labels cohort", SourceKindV3.GEO)
            )
        )
    )
}
