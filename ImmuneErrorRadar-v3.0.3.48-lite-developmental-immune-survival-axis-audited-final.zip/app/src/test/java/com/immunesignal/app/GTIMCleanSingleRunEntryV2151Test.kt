package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMCleanSingleRunEntryV2151Test {
    @Test
    fun cleanEntryDisablesLegacyForegroundPaths() {
        val json = GTIMCleanSingleRunEntryV2151.toJson()
        assertTrue(json.getBoolean("cleanSingleRunEntryEnabled"))
        assertTrue(json.getBoolean("legacyHeartbeatDisabled"))
        assertTrue(json.getBoolean("legacyWatchdogDisabled"))
        assertTrue(json.getBoolean("legacyDeepeningUiDisabled"))
        assertTrue(json.getBoolean("foregroundReportJsonEncodingDisabled"))
        assertEquals(ProfessionalResearchOrchestratorV2150.VERSION, json.getString("runtimeRoute"))
    }

    @Test
    fun taskProgressStillClampsAndExportRequiresReadyState() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
        assertFalse(ResearchProgressReducerV2150.reduce(contract).reportAvailable)
        contract = contract.withStatus(ResearchRunStatusV2150.CHECKPOINT_READY)
        val ui = ResearchProgressReducerV2150.reduce(contract)
        assertTrue(ui.reportAvailable)
        assertTrue(ui.progressPercent in 0..100)
    }
}
