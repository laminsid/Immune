package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30320ClosureQualityTest {
    @Test
    fun exhaustedContradictionSearchCanCloseConditionallyWhenEvidenceIsOtherwiseStrong() {
        val source = node("src", "PMID:1", EvidenceRoleV3.SOURCE, EvidenceTypeV3.SOURCE, "SARS-CoV-2 COVID-19 immune dysregulation cohort")
        val dataset = node("ds", "GSE1", EvidenceRoleV3.DATASET, EvidenceTypeV3.DATASET, "SARS-CoV-2 PBMC transcriptome healthy controls")
        val provenance = node("prov", "GSE2", EvidenceRoleV3.PROVENANCE, EvidenceTypeV3.PROVENANCE, "COVID-19 sample provenance comparator labels")
        val snapshot = EvidenceLedgerSnapshotV3(
            nodes = listOf(source, dataset, provenance),
            objectiveOutcomes = listOf(
                ResearchObjectiveOutcomeV3(
                    objective = ResearchObjectiveV3.FindContradiction("SARS-CoV-2 COVID-19 immune dysregulation", "H1_PRIMARY"),
                    queriesAttempted = listOf("COVID-19 immune signature no association healthy control PubMed"),
                    nodes = emptyList(),
                    exhausted = true
                ),
                ResearchObjectiveOutcomeV3(
                    objective = ResearchObjectiveV3.RankHypotheses("SARS-CoV-2 COVID-19 immune dysregulation"),
                    queriesAttempted = emptyList(),
                    nodes = emptyList(),
                    exhausted = false
                )
            )
        )
        val state = ResearchStateV3.initial(
            ResearchInputV3(
                topic = "SARS-CoV-2 COVID-19 immune dysregulation",
                budget = ResearchBudgetV3(
                    minNetworkCallsForReport = 0,
                    minExecutedEvidenceObjectivesForReport = 0
                )
            ),
            snapshot
        )
        val closure = ResearchClosurePolicyV3().evaluate(state)
        assertTrue(closure.contradictionObjectiveExecuted)
        assertTrue(closure.contradictionObjectiveExhausted)
        assertTrue(closure.noValidFalsifierFoundAfterSearch)
        assertTrue(closure.canCloseReport)
        assertFalse(closure.openGates.contains("contradiction_search_not_exhausted"))
    }

    @Test
    fun allergyDatasetPhenotypeMismatchCannotBecomeTierAResearchDataset() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "GSE302163",
                title = "Renal ischemia-reperfusion injury and macrophage METosis transcriptome dataset",
                source = SourceKindV3.GEO
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = "allergy IgE eosinophil mast cell type 2 inflammation",
            query = "allergic rhinitis eosinophil transcriptome GEO"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertEquals(QualityTierV3.D, node.qualityTier)
        assertFalse(node.satisfiesResearchRole(EvidenceRoleV3.DATASET))
        assertTrue(node.limitations.any { it.startsWith("dataset_phenotype_mismatch") })
    }

    @Test
    fun hantaLongQueryKeepsOriginalFirstThenAddsShortFallbackFanout() {
        val seeds = listOf("(hantavirus OR Hanta virus OR Hantaan virus OR HFRS OR hantavirus pulmonary syndrome) AND (immune response OR cytokine OR interferon OR endothelial dysfunction)")
        val expanded = ResearchQueryFallbackFanoutV3.expand(seeds, EvidenceRoleV3.SOURCE, "Hantavirus immune response cytokine interferon")
        assertTrue(expanded.first().contains("hantavirus", ignoreCase = true))
        assertTrue(expanded.first().contains("immune response", ignoreCase = true))
        assertTrue(expanded.drop(1).any { it.contains("hantavirus cytokine", ignoreCase = true) })
        assertTrue(expanded.any { it.contains("HFRS cytokine", ignoreCase = true) })
        assertTrue(expanded.any { it.contains("Hantaan virus immune response", ignoreCase = true) })
        assertTrue(expanded.any { it.contains("hantavirus pulmonary syndrome endothelial dysfunction", ignoreCase = true) })
    }


    @Test
    fun commonPathQueriesAreSanitizedEvenWhenNoFanoutProfileMatches() {
        val expanded = ResearchQueryFallbackFanoutV3.expand(
            seeds = listOf("rare immune mechanism SARS-"),
            role = EvidenceRoleV3.SOURCE,
            topic = "rare immune mechanism outside curated profiles"
        )
        assertEquals(listOf("rare immune mechanism"), expanded)
    }

    @Test
    fun knownDomainsBeyondHantaReceiveShortFallbackFanout() {
        val covidSeed = "(COVID-19 OR SARS-CoV-2) AND immune dysregulation"
        val covid = ResearchQueryFallbackFanoutV3.expand(
            seeds = listOf(covidSeed),
            role = EvidenceRoleV3.SOURCE,
            topic = "COVID-19 immune dysregulation"
        )
        assertQueryListHasOriginalFirstThenFallback(
            expanded = covid,
            originalMustContain = listOf("COVID-19", "immune dysregulation"),
            fallbackMustContain = listOf("COVID-19", "immune dysregulation", "PubMed")
        )

        val allergySeed = "allergy IgE eosinophil type 2 inflammation"
        val allergy = ResearchQueryFallbackFanoutV3.expand(
            seeds = listOf(allergySeed),
            role = EvidenceRoleV3.DATASET,
            topic = "allergy IgE eosinophil mast cell type 2 inflammation"
        )
        assertQueryListHasOriginalFirstThenFallback(
            expanded = allergy,
            originalMustContain = listOf("allergy", "eosinophil", "type 2"),
            fallbackMustContain = listOf("allergic rhinitis", "eosinophil", "GEO")
        )

        val ebolaSeed = "Ebola host response"
        val ebola = ResearchQueryFallbackFanoutV3.expand(
            seeds = listOf(ebolaSeed),
            role = EvidenceRoleV3.CONTRADICTION,
            topic = "Ebola filovirus immune response"
        )
        assertQueryListHasOriginalFirstThenFallback(
            expanded = ebola,
            originalMustContain = listOf("Ebola", "host response"),
            fallbackMustContain = listOf("Ebola", "immune response", "limitation")
        )
    }



    @Test
    fun readinessGradeAddsConditionalLayerWithoutChangingReportReadyStatus() {
        val source = node("src-grade", "PMID:101", EvidenceRoleV3.SOURCE, EvidenceTypeV3.SOURCE, "SARS-CoV-2 COVID-19 immune dysregulation cohort")
        val dataset = node("ds-grade", "GSE101", EvidenceRoleV3.DATASET, EvidenceTypeV3.DATASET, "SARS-CoV-2 PBMC transcriptome healthy controls")
        val provenance = node("prov-grade", "GSE102", EvidenceRoleV3.PROVENANCE, EvidenceTypeV3.PROVENANCE, "COVID-19 sample provenance comparator labels")
        val snapshot = EvidenceLedgerSnapshotV3(
            nodes = listOf(source, dataset, provenance),
            objectiveOutcomes = listOf(
                ResearchObjectiveOutcomeV3(
                    objective = ResearchObjectiveV3.FindContradiction("SARS-CoV-2 COVID-19 immune dysregulation", "H1_PRIMARY"),
                    queriesAttempted = listOf("COVID-19 immune signature no association healthy control PubMed"),
                    nodes = emptyList(),
                    exhausted = true
                ),
                ResearchObjectiveOutcomeV3(
                    objective = ResearchObjectiveV3.RankHypotheses("SARS-CoV-2 COVID-19 immune dysregulation"),
                    queriesAttempted = emptyList(),
                    nodes = emptyList(),
                    exhausted = false
                )
            )
        )
        val state = ResearchStateV3.initial(
            ResearchInputV3(
                topic = "SARS-CoV-2 COVID-19 immune dysregulation",
                budget = ResearchBudgetV3(minNetworkCallsForReport = 0, minExecutedEvidenceObjectivesForReport = 0)
            ),
            snapshot
        )
        val closure = ResearchClosurePolicyV3().evaluate(state)
        val readiness = ResearchReadinessAssessmentV3.evaluate(state, closure)
        assertTrue(closure.canCloseReport)
        assertEquals(ReportReadinessGradeV3.REPORT_READY_CONDITIONAL, readiness.readinessGrade)
        assertTrue(readiness.supportQuality in setOf(SupportQualityGradeV3.DATASET_MATCHED, SupportQualityGradeV3.MULTI_ACCESSION_DATASET_SUPPORTED))
    }

    @Test
    fun depressionKynurenineDatasetQueriesAreAcquisitionOriented() {
        val queries = DomainQueryTemplateV3.datasetQueries("depression kynurenine pathway neuroimmune signaling major depressive disorder")
        val joined = queries.joinToString(" ").lowercase()
        assertTrue(joined.contains("major depressive disorder"))
        assertTrue(joined.contains("kynurenine"))
        assertTrue(joined.contains("pbmc") || joined.contains("rna-seq") || joined.contains("gse"))
        assertTrue(queries.size >= 4)
    }

    @Test
    fun contestedReviewSupportWithoutDatasetIsDatasetUnconfirmed() {
        val source = node(
            id = "review-src",
            accession = "PMID:REVIEW",
            role = EvidenceRoleV3.SOURCE,
            type = EvidenceTypeV3.SOURCE,
            title = "Major depressive disorder kynurenine pathway neuroimmune review cohort"
        )
        val contra = node(
            id = "contra-review",
            accession = "PMID:CONTEST",
            role = EvidenceRoleV3.CONTRADICTION,
            type = EvidenceTypeV3.CONTRADICTION,
            title = "Depression kynurenine pathway no association healthy control cohort",
            supports = emptyList(),
            contradicts = listOf("H1_PRIMARY")
        )
        val snapshot = EvidenceLedgerSnapshotV3(
            nodes = listOf(source, contra),
            objectiveOutcomes = listOf(
                ResearchObjectiveOutcomeV3(
                    objective = ResearchObjectiveV3.FindContradiction("depression kynurenine pathway", "H1_PRIMARY"),
                    queriesAttempted = listOf("depression kynurenine no association healthy control PubMed"),
                    nodes = listOf(contra),
                    exhausted = false
                ),
                ResearchObjectiveOutcomeV3(
                    objective = ResearchObjectiveV3.RankHypotheses("depression kynurenine pathway"),
                    queriesAttempted = emptyList(),
                    nodes = emptyList(),
                    exhausted = false
                )
            )
        )
        val state = ResearchStateV3.initial(
            ResearchInputV3(
                topic = "depression kynurenine pathway neuroimmune signaling",
                budget = ResearchBudgetV3(minNetworkCallsForReport = 0, minExecutedEvidenceObjectivesForReport = 0)
            ),
            snapshot
        )
        val closure = ResearchClosurePolicyV3().evaluate(state)
        val assessment = ResearchHypothesisScorerV3.score(state, closure)
        assertTrue(closure.openGates.contains("visible_dataset_or_provenance_evidence"))
        assertEquals(HypothesisDispositionV3.REVIEW_SUPPORTED_BUT_DATASET_UNCONFIRMED_AND_CONTESTED, assessment.disposition)
        assertEquals(ReportReadinessGradeV3.CHECKPOINT_DATASET_GAP, assessment.readinessGrade)
    }

    private fun assertQueryListHasOriginalFirstThenFallback(
        expanded: List<String>,
        originalMustContain: List<String>,
        fallbackMustContain: List<String>
    ) {
        assertTrue("expanded query list must not be empty", expanded.isNotEmpty())
        val first = expanded.first()
        originalMustContain.forEach { token ->
            assertTrue("original query should remain first and contain: $token in $first", first.contains(token, ignoreCase = true))
        }
        val fallbackIndex = expanded.indexOfFirst { candidate ->
            fallbackMustContain.all { token -> candidate.contains(token, ignoreCase = true) }
        }
        assertTrue("fallback query missing: ${fallbackMustContain.joinToString(" + ")} in ${expanded.joinToString(" | ")}", fallbackIndex >= 1)
        assertTrue("fallback must appear after original query", fallbackIndex > 0)
        assertTrue("all fanout queries should be sanitized and non-blank", expanded.all { it == QuerySanitizerV3.noMalformedQuery(it) && it.isNotBlank() })
    }

    @Test
    fun experimentalClaimRelaxationIsAbsentUnlessExplicitDebugSandboxGateIsEnabled() {
        assertFalse(GTIMExperimentalClaimRelaxationV21312.isEnabled())
        assertTrue(GTIMExperimentalClaimRelaxationV21312.publicLines(org.json.JSONObject()).isEmpty())
    }

    @Test
    fun contestingEvidenceWithoutSupportDoesNotReportVisibleSupport() {
        val contra = node(
            id = "contra-only",
            accession = "PMID:CONTRA",
            role = EvidenceRoleV3.CONTRADICTION,
            type = EvidenceTypeV3.CONTRADICTION,
            title = "Depression kynurenine pathway no association healthy control cohort",
            supports = emptyList(),
            contradicts = listOf("H1_PRIMARY")
        )
        val snapshot = EvidenceLedgerSnapshotV3(
            nodes = listOf(contra),
            objectiveOutcomes = listOf(
                ResearchObjectiveOutcomeV3(
                    objective = ResearchObjectiveV3.FindContradiction("depression kynurenine pathway", "H1_PRIMARY"),
                    queriesAttempted = listOf("depression kynurenine no association healthy control PubMed"),
                    nodes = listOf(contra),
                    exhausted = false
                )
            )
        )
        val state = ResearchStateV3.initial(ResearchInputV3("depression kynurenine pathway"), snapshot)
        val closure = ResearchClosurePolicyV3().evaluate(state)
        val assessment = ResearchHypothesisScorerV3.score(state, closure)
        assertEquals(HypothesisDispositionV3.INSUFFICIENT_SUPPORT_WITH_VISIBLE_CONTESTING_EVIDENCE, assessment.disposition)
        assertTrue(assessment.supportEvidenceIds.isEmpty())
        assertTrue(assessment.summary.contains("support is not yet established", ignoreCase = true))
    }

    private fun node(
        id: String,
        accession: String,
        role: EvidenceRoleV3,
        type: EvidenceTypeV3,
        title: String,
        supports: List<String> = listOf("H1_PRIMARY"),
        contradicts: List<String> = emptyList()
    ): EvidenceNodeV3 = EvidenceNodeV3(
        id = id,
        type = type,
        accession = accession,
        title = title,
        source = if (accession.startsWith("GSE")) SourceKindV3.GEO else SourceKindV3.PUBMED,
        articleType = when (role) {
            EvidenceRoleV3.DATASET, EvidenceRoleV3.PROVENANCE -> ArticleTypeV3.DATASET
            else -> ArticleTypeV3.COHORT
        },
        role = role,
        qualityTier = QualityTierV3.A,
        supports = supports,
        contradicts = contradicts
    )
}
