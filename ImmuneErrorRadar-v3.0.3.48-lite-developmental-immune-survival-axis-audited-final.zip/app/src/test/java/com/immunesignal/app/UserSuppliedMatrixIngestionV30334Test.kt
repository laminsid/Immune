package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UserSuppliedMatrixIngestionV30334Test {

    private val raCsv3x3 = """
        sample_id,group,TNF,IL6,IL17A,CD68
        ra1,active_ra,5.0,5.2,4.8,4.7
        ra2,active_ra,5.1,5.0,4.7,4.8
        ra3,active_ra,4.9,5.1,4.6,4.6
        c1,healthy_control,3.2,3.1,2.7,3.0
        c2,healthy_control,3.1,3.2,2.8,3.1
        c3,healthy_control,3.0,3.0,2.6,2.9
    """.trimIndent()

    private val raCsv5x5 = """
        sample_id,group,TNF,IL6,IL17A,CD68
        ra1,active_ra,5.0,5.2,4.8,4.7
        ra2,active_ra,5.1,5.0,4.7,4.8
        ra3,active_ra,4.9,5.1,4.6,4.6
        ra4,active_ra,5.2,5.3,4.9,4.9
        ra5,active_ra,5.0,5.1,4.7,4.8
        c1,healthy_control,3.2,3.1,2.7,3.0
        c2,healthy_control,3.1,3.2,2.8,3.1
        c3,healthy_control,3.0,3.0,2.6,2.9
        c4,healthy_control,3.3,3.1,2.9,3.2
        c5,healthy_control,3.1,3.0,2.7,3.0
    """.trimIndent()

    @Test
    fun parsesRowsGroupsAndMarkersWithV30334Name() {
        val m = UserSuppliedMatrixIngestorV30334.ingest(
            text = raCsv3x3,
            declaredCaseGroups = listOf("active_ra"),
            declaredControlGroups = listOf("healthy_control"),
            sourceLabel = "GEO GSE89408 processed matrix, downloaded 2026-06-04"
        )
        assertEquals(6, m.rows.size)
        assertEquals(3, m.caseRowCount)
        assertEquals(3, m.controlRowCount)
        assertTrue(m.markers.contains("TNF"))
        assertTrue(m.warnings.any { it.contains("underpowered_user_matrix") })
    }

    @Test
    fun sourceLabelCreatesUserAttestationNotDiscoveryCertification() {
        val m = UserSuppliedMatrixIngestorV30334.ingest(
            raCsv5x5, listOf("active_ra"), listOf("healthy_control"),
            sourceLabel = "GEO GSE89408 processed matrix, downloaded 2026-06-04"
        )
        assertTrue(m.attested)
        assertFalse(m.certifiable)
        assertTrue(m.provenanceReceipt.startsWith("user_attested_matrix|trust=USER_ATTESTED_WITH_DECLARED_SOURCE"))
        assertEquals("DECLARED_GEO_LIKE_SOURCE", m.verificationLevel)
        val input = m.toResearchInput("rheumatoid arthritis synovial inflammation")
        assertTrue(input.explicitMatrixProvenance.isNotBlank())
        assertEquals("DECLARED_GEO_LIKE_SOURCE", input.explicitMatrixVerificationLevel)
        assertEquals(10, input.explicitMatrixRows.size)
        assertTrue(input.explicitCaseLabels.contains("active_ra"))
    }

    @Test
    fun withoutSourceLabelStaysReviewOnlyNoAttestation() {
        val m = UserSuppliedMatrixIngestorV30334.ingest(
            raCsv5x5, listOf("active_ra"), listOf("healthy_control"), sourceLabel = ""
        )
        assertFalse(m.attested)
        assertEquals("", m.provenanceReceipt)
        assertEquals("", m.toResearchInput("ra").explicitMatrixProvenance)
    }

    @Test
    fun userAttestedMatrixDrivesFuelButNotDiscoveryCertified() {
        val m = UserSuppliedMatrixIngestorV30334.ingest(
            raCsv5x5, listOf("active_ra"), listOf("healthy_control"),
            sourceLabel = "GEO GSE89408 processed matrix, downloaded 2026-06-04"
        )
        val input = m.toResearchInput("rheumatoid arthritis synovial inflammation tnf il6 il17")
        val state = ResearchStateV3.initial(input)
        val metadata = ResearchMetadataProbeIngestionV3.evaluate(state)
        val datasetScore = ResearchDatasetModuleScoreV3.evaluate(state, metadata)
        val comparator = ComparatorVariableExtractorV30329.evaluate(state, metadata)
        val (rows, fuel) = MatrixFuelProviderV30331.collect(state, metadata, datasetScore, comparator)
        assertTrue(rows.isNotEmpty())
        assertTrue(fuel.caseRowCount >= 5)
        assertTrue(fuel.controlRowCount >= 5)
        assertEquals("USER_ATTESTED_WITH_DECLARED_SOURCE", fuel.certificationLevel)
        assertEquals("USER_ATTESTED_DGE", fuel.analysisMode)
        assertFalse(fuel.certifiedForDiscovery)
        val reality = SyntheticScaffoldDataGuardV30333.assess(fuel)
        assertEquals("USER_ATTESTED_DGE", reality.analysisMode)
        assertFalse(fuel.certifiedForDiscovery)
    }

    @Test
    fun reviewOnlyUserRowsDoNotFalseCertify() {
        val m = UserSuppliedMatrixIngestorV30334.ingest(
            raCsv5x5, listOf("active_ra"), listOf("healthy_control"), sourceLabel = ""
        )
        val input = m.toResearchInput("rheumatoid arthritis synovial inflammation tnf il6 il17")
        val state = ResearchStateV3.initial(input)
        val metadata = ResearchMetadataProbeIngestionV3.evaluate(state)
        val datasetScore = ResearchDatasetModuleScoreV3.evaluate(state, metadata)
        val comparator = ComparatorVariableExtractorV30329.evaluate(state, metadata)
        val (_, fuel) = MatrixFuelProviderV30331.collect(state, metadata, datasetScore, comparator)
        assertFalse(fuel.certifiedForDiscovery)
        assertFalse(fuel.certificationLevel == "CERTIFIED_USER_SUPPLIED_WITH_PROVENANCE")
    }

    @Test
    fun tooLargeMatrixIsRejectedBeforeParsing() {
        val huge = "sample_id,group,TNF\n" + (1..1005).joinToString("\n") { "s$it,active_ra,1.0" }
        val m = UserSuppliedMatrixIngestorV30334.ingest(huge, listOf("active_ra"), listOf("healthy_control"), "GSE test")
        assertTrue(m.rows.isEmpty())
        assertTrue(m.warnings.any { it.contains("row_count_exceeds") })
    }
}
