package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMRouteBlankSearchClosureV213102Test {
    @Test
    fun filovirusSubtypePrefersFilovirusTargetOverCovidTarget() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Ebola filovirus interferon cytokine host response"))
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "viral_interferon_cytokine"))
            .put("verifiedMetadataClosurePackV2132", JSONObject()
                .put("state", "VERIFIED_METADATA_CLOSURE_READY")
                .put("selectedClosedTarget", "GSE166552"))
            .put("finalDataClosureExecutionV2132", JSONObject()
                .put("readinessScore", 8)
                .put("selectedClosedTarget", "GSE166552"))
            .put("injectedMetadataSeedPackV21216", JSONObject()
                .put("candidateHandles", JSONArray(listOf("GSE166552", "GSE45291"))))

        assertEquals("filovirus_viral_host_response", GTIMActiveDomainConsistencyGuardV2134.activeDomainKey(report))
        assertEquals("viral_filovirus", GTIMActiveDomainConsistencyGuardV2134.activeSubtype(report))
        assertEquals("GSE45291", GTIMActiveDomainConsistencyGuardV2134.canonicalFinalTarget(report))
    }

    @Test
    fun emptyCanonicalTargetDoesNotReuseLegacyMatrixHandle() {
        val report = JSONObject()
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "metabolic_inflammation"))
            .put("candidateHandleLedgerV21215", JSONObject().put("selectedReviewTarget", "GSE102556"))
        report.put("canonicalFinalSurfaceGuardV2135", GTIMCanonicalFinalSurfaceGuardV2135.toJson(report))

        val matrix = GTIMMatrixShortcutResolverV2124.build(report)
        assertEquals("", matrix.handle)
        assertTrue(matrix.query.contains("immune", ignoreCase = true) || matrix.query.contains("metabolic", ignoreCase = true))
    }
}
