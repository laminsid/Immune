package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMNetworkSafeEvidenceAcquisitionV2171Test {
    @Test
    fun invalidJsonParsersReturnEmptyInsteadOfThrowing() {
        assertTrue(ResearchEvidenceAcquisitionV2170.parseIdListFromESearchJson("<html>maintenance</html>", 5).isEmpty())
        assertTrue(ResearchEvidenceAcquisitionV2170.pubMedRecordsFromSummaryJson("not-json").isEmpty())
        assertTrue(ResearchEvidenceAcquisitionV2170.gdsRecordsFromSummaryJson("not-json").isEmpty())
    }

    @Test
    fun userAgentIsSeparatedFromLegacyEngineRuntimeVersion() {
        assertEquals("2.17.2", ResearchEvidenceAcquisitionV2170.USER_AGENT_VERSION)
        assertTrue(ResearchEvidenceAcquisitionV2170.USER_AGENT_TOKEN.contains("evidence-acquisition-v2172"))
        assertFalse(ResearchEvidenceAcquisitionV2170.USER_AGENT_TOKEN.contains(EngineRuntimeStatus.ACTIVE_ENGINE_VERSION))
    }

    @Test
    fun visibleSourceAndProvenanceWithoutReviewableContradictionRemainCheckpointOnly() {
        val proof = ResearchProofContractV2160.fromHandles(
            "Ebola bundibugyo",
            listOf(
                "source_handle_closed_pubmed_123456__title_bundibugyo_host_response",
                "metadata_probe_executed_pubmed_123456__title_bundibugyo_host_response",
                "contradiction_probe_attempted_no_pubmed_hit_yet_not_evidence"
            )
        )
        assertFalse(proof.isClosed())
        assertFalse(ResearchVisibleEvidenceAuditV2161.evaluate(proof).reportReadyEligible)
    }

    @Test
    fun pubmedSummaryParserKeepsReviewableTitleAfterSafeJsonChange() {
        val json = """
            {
              "result": {
                "uids": ["123456"],
                "123456": {
                  "title": "Host immune response and tissue model limits in filovirus infection",
                  "fulljournalname": "Journal of Viral Immunology",
                  "pubdate": "2025"
                }
              }
            }
        """.trimIndent()
        val record = ResearchEvidenceAcquisitionV2170.pubMedRecordsFromSummaryJson(json).first()
        val proof = ResearchProofContractV2160.fromHandles(
            "filovirus",
            listOf(record.sourceMarker(), record.metadataMarker(), record.contradictionMarker())
        )
        assertTrue(ResearchVisibleEvidenceAuditV2161.evaluate(proof).reportReadyEligible)
        assertTrue(proof.displayedEvidenceLines().any { it.contains("Host immune response") })
    }
}
