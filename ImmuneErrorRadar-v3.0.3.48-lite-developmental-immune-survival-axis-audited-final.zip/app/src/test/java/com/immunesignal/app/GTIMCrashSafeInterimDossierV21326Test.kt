package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMCrashSafeInterimDossierV21326Test {
    @Test
    fun compactDossierClosesAtSixMinutesAndKeepsUsefulGlobalResearchRoutes() {
        val snapshot = RuntimeCrashSafetyAndTopicGuardV2740.capture("Allergy")
        val limits = GTIMDeepeningRunLimitsV2123(
            maxSearchMillis = 20L * 60L * 1000L,
            maxLearningMillis = 45L * 60L * 1000L,
            maxQueries = 40,
            maxResultsPerQuery = 50,
            fetchAbstracts = true,
            enableSelectiveAbstracts = true,
            maxAbstractsPerCycle = 20
        )
        val budget = GTIMMobileSearchRuntimeBudgetV21322.fromDeepeningLimits(limits)
        assertEquals(360_000L, budget.firstVisibleReportMillis)
        assertEquals(600_000L, budget.hardTimeoutMillis)
        // v2.14 keeps the 10-minute contract visible while Activity-level closeAtFirstVisibleReportV21326
        // still permits six-minute safe close before heavy REPORT_JSON_ENCODING on mobile.

        val plan = GTIMSameTopicDeepeningBridgeV2123.build(
            rawTopic = "Allergy",
            resolvedTopic = "Allergy",
            recentReportLines = emptyList()
        )
        val report = GTIMCrashSafeInterimDossierV21326.launchRecoveryReport(snapshot, budget, plan)
        val text = GTIMCrashSafeInterimDossierV21326.renderUserCard(report)

        assertTrue(text.contains("Crash-safe research dossier"))
        assertTrue(text.contains("Structural Immunity"))
        assertTrue(text.contains("Microbiome as endocrine-immune organ"))
        assertTrue(text.contains("NETosis/PANoptosis"))
        assertTrue(text.contains("no_diagnosis"))
        assertTrue(text.length <= GTIMCrashSafeInterimDossierV21326.MAX_UI_CHARS)
    }
}
