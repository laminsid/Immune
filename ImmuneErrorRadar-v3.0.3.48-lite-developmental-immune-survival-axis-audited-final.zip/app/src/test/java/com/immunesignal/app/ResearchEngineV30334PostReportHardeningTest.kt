package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30334PostReportHardeningTest {
    @Test
    fun finalIdentityWarningsDoNotLeakFromLegacyGuards() {
        assertTrue(ResearchEngineV30331FinalUnificationGuard.warnings().isEmpty())
        assertTrue(ResearchEngineV30332FinalUnificationGuard.warnings().isEmpty())
        assertTrue(ResearchEngineV30334FinalUnificationGuard.warnings().isEmpty())
    }

    @Test
    fun alzheimerDiabetesCompareWithoutVsBecomesTwoLanes() {
        val topic = "compare alzheimer disease neuroinflammation type diabetes metabolic inflammation as two separate lanes"
        val parts = ResearchTopicNormalizerV3.splitComparativeTerms(topic)
        assertEquals(2, parts.size)
        assertTrue(parts[0].lowercase().contains("alzheimer"))
        assertTrue(parts[1].lowercase().contains("diabetes"))
        val decision = ResearchIntentGateV3.evaluate(topic)
        assertTrue(decision.allowed)
        val plan = ComparativeDualLanePlannerV30332.build(topic, "GEO transcriptome")
        assertTrue(plan.leftQueries.any { it.contains("Alzheimer", ignoreCase = true) })
        assertTrue(plan.rightQueries.any { it.contains("diabetes", ignoreCase = true) })
    }

    @Test
    fun rheumatoidTumorAssociatedLeakageDoesNotBecomeCancerDomain() {
        val topic = "rheumatoid arthritis synovial inflammation TNF IL-6 IL-17 tumor-associated macrophage"
        assertTrue(ContaminatedOntologyInputGateV30334.contaminated(topic))
        val frame = BiomedicalTopicFrameV3.from(topic)
        assertFalse(frame.domain == ResearchDomainV3.CANCER)
        val q = DomainQueryTemplateV3.datasetQueries(topic).joinToString(" ").lowercase()
        assertFalse(q.contains("tumor-associated"))
        assertTrue(q.contains("rheumatoid") || q.contains("synovial") || q.contains("ra"))
    }

    @Test
    fun mouseNeuroblastomaTitleIsNotDisplayedAsHumanOrganism() {
        val frame = BiomedicalTopicFrameV3.from("pediatric neuroblastoma MYCN amplified CD8 T cell")
        val semantic = BiomedicalRelevanceLiteV30326.evaluate(
            frame,
            "Gene expression profile at single cell level of Mycn-nGEMM mouse neuroblastoma tumors and their tumor immune microenvironment",
            EvidenceRoleV3.DATASET,
            SourceKindV3.GEO
        )
        assertEquals("MOUSE", semantic.organismMatch)
    }
}
