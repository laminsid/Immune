package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30340HumanPediatricAlphaDiscoveryTest {
    @Test
    fun sourceRoleRegistrySeparatesMatrixFuelReplicationMouseAndCuratedSeeds() {
        assertEquals("MATRIX_FUEL", HumanPediatricDiscoveryV30340.overrideFor("GSE85047")?.sourceRole)
        assertEquals("HUMAN_REPLICATION_CANDIDATE", HumanPediatricDiscoveryV30340.overrideFor("GSE49710")?.sourceRole)
        assertEquals("HUMAN_REPLICATION_CANDIDATE", HumanPediatricDiscoveryV30340.overrideFor("TARGET-NBL")?.sourceRole)
        assertEquals("MODEL_ORGANISM_CONTEXT_ONLY", HumanPediatricDiscoveryV30340.overrideFor("GSE299403")?.sourceRole)
        assertEquals("HUMAN", HumanPediatricDiscoveryV30340.organismFor("EGAD00001009766", "childhood neuroblastoma", "MOUSE"))
        assertEquals("HUMAN", HumanPediatricDiscoveryV30340.organismFor("GSE115978", "melanoma ecosystems", "MOUSE"))
    }

    @Test
    fun alphaGuardKeepsTruthLocksButDisablesSoftReportBlockers() {
        val rows = PediatricOncologyExplicitMatrixV30337.rows()
        val computed = ProcessedExpressionMatrixCalculatorV30329.calculate(
            rows = rows,
            caseGroups = PediatricOncologyExplicitMatrixV30337.caseLabels,
            controlGroups = PediatricOncologyExplicitMatrixV30337.controlLabels,
            markers = PediatricOncologyExplicitMatrixV30337.markers
        )
        val fuel = MatrixFuelSnapshotV30330(
            state = "MATRIX_FUEL_READY_FOR_RAW_DGE_V30331",
            accession = "GSE85047",
            rowCount = rows.size,
            caseRowCount = 6,
            controlRowCount = 6,
            source = "pediatric_oncology_declared_source_gse85047_matrix_rows_v30337",
            groupResolution = ComparatorGroupResolutionV30330(
                state = "COMPARATOR_GROUP_VALUES_RESOLVED_V30337_PEDIATRIC_ONCOLOGY_DECLARED_MATRIX_LABELS",
                accession = "GSE85047",
                caseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                controlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels,
                unresolvedAxis = "mycn_amplified_vs_non_mycn",
                source = "test"
            ),
            warnings = emptyList(),
            certificationLevel = PediatricOncologyExplicitMatrixV30337.CERTIFICATION_LEVEL,
            analysisMode = "USER_ATTESTED_DGE",
            scientificInterpretability = "MODERATE_SINGLE_DATASET_RESEARCH_ONLY_NOT_INDEPENDENTLY_VERIFIED",
            fuelOrigin = PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN,
            verificationLevel = PediatricOncologyExplicitMatrixV30337.VERIFICATION_LEVEL,
            signalValidity = "USER_ATTESTED_SINGLE_DATASET_RESEARCH_ONLY_NOT_VERIFIED",
            matrixFuelSourceAccession = "GSE85047",
            dgeExecutedOnAccession = "GSE85047",
            retrievalEvidenceBestAccession = "GSE85047",
            moduleNameAccession = "GSE85047",
            organismPriorityState = "HUMAN_PEDIATRIC_DECLARED_MATRIX_PRIORITY_MOUSE_EVIDENCE_CONTEXT_ONLY",
            seedIndependenceState = "SEEDED_PEDONC_MECHANISM_NODES_CONTEXT_ONLY_NOT_INDEPENDENT_SUPPORT",
            nullResultState = "PENDING_DGE_STATISTICAL_NULL_LEDGER_EVALUATION"
        )
        val expression = ProcessedExpressionSignalReportV30329(
            active = true,
            state = "PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_EXECUTED_REVIEW_ONLY",
            dataset = "GSE85047",
            moduleCount = 1,
            rawMatrixDgeExecuted = true,
            estimates = listOf(
                ModuleSignalEstimateV30329(
                    accession = "GSE85047",
                    module = PediatricOncologyExplicitMatrixV30337.module().name,
                    markers = PediatricOncologyExplicitMatrixV30337.markers,
                    effectDirection = "case_downregulated_or_module_depleted",
                    effectSize = computed.map { it.effectSize }.average(),
                    confidenceInterval = "module_marker_range_95CI=[${computed.minOf { it.ciLow }}, ${computed.maxOf { it.ciHigh }}]",
                    pValueLabel = "marker_best_bonferroni_adjusted_p=${computed.minOf { it.adjustedPValue }}",
                    statisticState = "RAW_MATRIX_WELCH_T_DGE_WITH_BONFERRONI_MARKER_CORRECTION_V30333_CI_PVALUE_LEVELS_EXPLICIT",
                    rawMatrixDgeExecuted = true,
                    computedFrom = "sample_level_expression_rows:GSE85047",
                    supportState = "PEDIATRIC_ONCOLOGY_DIRECTIONAL_NULL_RAW_DGE_REVIEW_NOT_MECHANISM_SUPPORT",
                    markerResults = computed
                )
            ),
            nextAction = "review only",
            matrixFuel = fuel
        )
        val input = ResearchInputV3("in GSE85047 do MYCN-amplified neuroblastoma tumors show colder immune microenvironment")
        val state = ResearchStateV3.initial(input)
        val truth = HumanPediatricMatrixTruthV30339.evaluate(input.topic, state, expression)
        val closure = ResearchClosureSnapshotV3(
            canCloseReport = false,
            openGates = listOf("minimum_independent_accessions", "tier_c_d_noise_ratio_blocks_report_ready"),
            visibleTierABCount = 1,
            visibleTierCDCount = 4,
            contradictionObjectiveExecuted = false,
            contradictionEvidenceFound = false,
            distinctAccessions = listOf("GSE85047")
        )
        val snapshot = HumanPediatricDiscoveryV30340.evaluate(input.topic, state, closure, expression, truth)
        assertTrue(snapshot.active)
        assertTrue(snapshot.alphaGuardPolicy.disabledAsReportBlockers.contains("minimum_independent_accessions"))
        assertTrue(snapshot.alphaGuardPolicy.hypothesisGenerationAllowed)
        assertFalse(snapshot.alphaGuardPolicy.certifiedDiscoveryAllowed)
        assertTrue(snapshot.nullToNovelHypotheses.any { it.id == "H5_REPLICATION_FIRST_HUMAN_SUBGROUP_SPLIT" })
    }

    @Test
    fun genericCancerDoesNotReceivePediatricMatrixFuelOrHumanAlphaDiscovery() {
        assertFalse(PediatricOncologyExplicitMatrixV30337.isEligible("adult cancer tumor microenvironment melanoma cd8 checkpoint", "GSE115978"))
        val inactive = HumanPediatricDiscoveryV30340.evaluate(
            topic = "adult cancer tumor microenvironment melanoma cd8 checkpoint",
            state = ResearchStateV3.initial(ResearchInputV3("adult cancer tumor microenvironment melanoma cd8 checkpoint")),
            closure = ResearchClosureSnapshotV3(false, emptyList(), 0, 0, false, false, emptyList()),
            expressionSignal = ProcessedExpressionSignalReportV30329.inactive("no pediatric focus"),
            truth = HumanPediatricMatrixTruthSnapshotV30339.inactive()
        )
        assertFalse(inactive.active)
    }
}
