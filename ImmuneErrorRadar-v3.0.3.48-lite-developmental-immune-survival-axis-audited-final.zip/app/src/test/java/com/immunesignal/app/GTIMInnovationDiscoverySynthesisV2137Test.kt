package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

class GTIMInnovationDiscoverySynthesisV2137Test {
    @Test
    fun hypothesisMutationCreatesNonObviousDepressionSubgroupClaim() {
        val report = JSONObject()
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "depression_kynurenine_neuroimmune"))
            .put("verifiedMetadataClosurePackV2132", JSONObject()
                .put("state", "VERIFIED_METADATA_CLOSURE_READY")
                .put("selectedClosedTarget", "GSE102556"))
            .put("finalDataClosureExecutionV2132", JSONObject()
                .put("readinessScore", 10)
                .put("selectedClosedTarget", "GSE102556"))
        attachBaseDiscovery(report)
        val mutation = GTIMHypothesisMutationEngineV2137.toJson(report)
        val first = mutation.getJSONArray("mutatedHypotheses").getJSONObject(0)
        assertEquals("depression_kynurenine_neuroimmune", mutation.getString("activeDomain"))
        assertTrue(first.getString("claim").contains("brain-region") || first.getString("claim").contains("subgroups"))
        assertFalse(first.getString("claim").contains("treatment"))
    }

    @Test
    fun innovationSynthesisProducesC1PlusReplicationReadyCandidate() {
        val report = JSONObject()
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "allergy_type2_barrier"))
            .put("verifiedMetadataClosurePackV2132", JSONObject()
                .put("state", "VERIFIED_METADATA_CLOSURE_READY")
                .put("selectedClosedTarget", "GSE146170"))
            .put("finalDataClosureExecutionV2132", JSONObject()
                .put("readinessScore", 10)
                .put("selectedClosedTarget", "GSE146170"))
        attachBaseDiscovery(report)
        attachInnovation(report)
        val card = GTIMDiscoverySynthesisCardV2137.toJson(report)
        assertEquals("allergy_type2_barrier", card.getString("activeDomain"))
        assertEquals("GSE146170", card.getString("canonicalTarget"))
        assertTrue(card.getString("innovationLevel").startsWith("C1"))
        assertTrue(card.getString("newClaimCandidate").contains("type-2") || card.getString("newClaimCandidate").contains("threshold"))
    }

    @Test
    fun finalInnovationClosureKeepsClaimsCandidateOnly() {
        val report = JSONObject()
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "viral_interferon_cytokine"))
            .put("verifiedMetadataClosurePackV2132", JSONObject()
                .put("state", "VERIFIED_METADATA_CLOSURE_READY")
                .put("selectedClosedTarget", "GSE166552"))
            .put("finalDataClosureExecutionV2132", JSONObject()
                .put("readinessScore", 8)
                .put("selectedClosedTarget", "GSE166552"))
        attachBaseDiscovery(report)
        attachInnovation(report)
        report.put("finalDiscoveryExecutionClosureV2136", GTIMFinalDiscoveryExecutionClosureV2136.toJson(report))
        val closure = GTIMFinalInnovationDiscoveryClosureV2137.toJson(report)
        assertTrue(closure.getString("state").contains("FINAL_INNOVATION"))
        assertEquals(true, closure.getBoolean("claimPromotionAllowed"))
        assertTrue(closure.getString("strictnessPolicy").contains("C0_C1"))
    }

    private fun attachBaseDiscovery(report: JSONObject) {
        report.put("activeDomainConsistencyGuardV2134", GTIMActiveDomainConsistencyGuardV2134.toJson(report))
        report.put("canonicalFinalSurfaceGuardV2135", GTIMCanonicalFinalSurfaceGuardV2135.toJson(report))
        report.put("futureEvidenceLiteCorpusV2130", GTIMFutureEvidenceLiteCorpusV2130.toJson(report))
        report.put("processedCapsuleStoreV2135", GTIMProcessedCapsuleStoreV2135.toJson(report))
        report.put("immuneModuleSignalEngineV2135", GTIMImmuneModuleSignalEngineV2135.toJson(report))
        report.put("discoveryExecutionEnginesV2135", GTIMDiscoveryExecutionEnginesV2135.toJson(report))
        report.put("discoveryClaimLadderV2135", GTIMDiscoveryClaimLadderV2135.toJson(report))
        report.put("discoveryCandidateAssemblerV2135", GTIMDiscoveryCandidateAssemblerV2135.toJson(report))
    }

    private fun attachInnovation(report: JSONObject) {
        report.put("signalSurpriseEngineV2137", GTIMSignalSurpriseEngineV2137.toJson(report))
        report.put("cellTissueSpecificityEngineV2137", GTIMCellTissueSpecificityEngineV2137.toJson(report))
        report.put("immunePhaseEngineV2137", GTIMImmunePhaseEngineV2137.toJson(report))
        report.put("hypothesisMutationEngineV2137", GTIMHypothesisMutationEngineV2137.toJson(report))
        report.put("mechanismCompetitionArenaV2137", GTIMMechanismCompetitionArenaV2137.toJson(report))
        report.put("c2AutoReplicationEngineV2137", GTIMC2AutoReplicationEngineV2137.toJson(report))
        report.put("crossDiseaseImmuneConvergenceEngineV2137", GTIMCrossDiseaseImmuneConvergenceEngineV2137.toJson(report))
        report.put("drugVaccineMechanismTriangulationV2137", GTIMDrugVaccineMechanismTriangulationV2137.toJson(report))
        report.put("discoveryNoveltyMinerV2137", GTIMDiscoveryNoveltyMinerV2137.toJson(report))
        report.put("discoverySynthesisCardV2137", GTIMDiscoverySynthesisCardV2137.toJson(report))
    }
}
