package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMVersionPauseRuntimeV2162Test {
    @Test
    fun pauseLoopAutoCheckpointsAfterConfiguredTimeout() {
        val states = mutableListOf<ResearchRunStatusV2150>()
        val report = ProfessionalResearchOrchestratorV2150.run(
            topic = "Ebola bundibugyo",
            shouldPause = { true },
            shouldStop = { false },
            onState = { contract, _ -> states.add(contract.status) },
            policy = ResearchExecutionPolicyV2154.unitTestNoFastFinish().copy(maxPauseMillis = 1L)
        )

        assertTrue(states.contains(ResearchRunStatusV2150.CHECKPOINT_READY))
        assertEquals("CHECKPOINT_READY", report.optString("status"))
        val orchestrator = report.optJSONObject("professionalResearchOrchestratorV2150")
        assertTrue(orchestrator?.optBoolean("pauseTimeoutReached") == true)
        assertEquals(
            ProfessionalResearchOrchestratorV2150.PAUSE_TIMEOUT_TOKEN,
            orchestrator?.optString("pauseTimeoutTokenV2162")
        )
    }

    @Test
    fun buildGradleRuntimeVersionTokenIsAlignedWithReleaseName() {
        assertEquals("2.17.2-independent-evidence-policy", ResearchExecutionPolicyV2154.VERSION)
        assertEquals("2.17.2-independent-evidence-orchestrator", ProfessionalResearchOrchestratorV2150.VERSION)
    }
}
