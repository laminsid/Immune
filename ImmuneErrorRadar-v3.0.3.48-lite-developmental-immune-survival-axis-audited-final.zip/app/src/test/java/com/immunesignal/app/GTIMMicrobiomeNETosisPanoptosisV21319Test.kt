package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMMicrobiomeNETosisPanoptosisV21319Test {
    @Test
    fun microbiomeRoleCardDoesNotCreateTreatmentClaim() {
        val report = JSONObject().put("topic", "cancer checkpoint microbiome immunotherapy response research")
        val card = GTIMMicrobiomeRoleSurfaceCardV21319.toJson(report)
        val text = GTIMMicrobiomeRoleSurfaceCardV21319.renderLines(report).joinToString("\n")
        assertTrue(card.getString("state").contains("MICROBIOME_ROLE_CARD_READY"))
        assertTrue(text.contains("Microbiome role card"))
        assertTrue(text.contains("not validated predictor"))
        assertFalse(text.contains("treatment recommendation allowed"))
    }

    @Test
    fun cellDeathCardKeepsNETosisAndPANoptosisAsResearchLensOnly() {
        val report = JSONObject().put("topic", "sepsis organ failure NETosis PANoptosis thromboinflammation research")
        val card = GTIMCellDeathSurfaceCardV21319.toJson(report)
        val text = GTIMCellDeathSurfaceCardV21319.renderLines(report).joinToString("\n")
        assertTrue(card.getString("state").contains("CELL_DEATH_NETOSIS_PANOPTOSIS_CARD_READY"))
        assertTrue(text.contains("NETosis role"))
        assertTrue(text.contains("PANoptosis role"))
        assertTrue(text.contains("clinical prediction=BLOCKED"))
        assertTrue(text.contains("treatment recommendation=BLOCKED"))
    }

    @Test
    fun finalSurfaceIncludesMicrobiomeAndCellDeathCardsWithoutLegacyTree() {
        val report = JSONObject().put("topic", "hantavirus lung injury NETosis microbiome endothelial leak research")
        val text = GTIMFinalActiveDecisionSurfaceV21317.renderLines(report).joinToString("\n")
        assertTrue(text.contains("Microbiome role card"))
        assertTrue(text.contains("Cell-death / NETosis role card"))
        assertTrue(text.contains("C0/C1/C2/C3 sandbox preview allowed"))
        assertFalse(text.contains("Final Bundibugyo/BDBV search-runtime closure"))
    }
}
