package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMTerminalDiscoveryContinuationV21212Test {

    @Test
    fun dPlusCandidateHandleContinuesToTerminalDiscoveryInsteadOfStopping() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("normalizedTopic", "COVID post viral interferon IL-6 TNF")
                .put("rawInput", "COVID immune response"))
            .put("reportConsistencyGateV2121", JSONObject()
                .put("candidateLookupHandle", "GSE152202"))
            .put("matrixShortcutStatusLayerV2129", JSONObject()
                .put("state", "MATRIX_SHORTCUT_REVIEW_ONLY_ROUTE_QUEUED"))
        val technical = listOf(
            "Research topic: COVID post viral interferon IL-6 TNF",
            "Candidate lookup handle: GSE152202",
            "DGE readiness reason: DGE_NOT_READY_SOFT_MATRIX_AND_COMPARATOR_LEAD_REVIEW"
        )
        val continuation = GTIMTerminalDiscoveryContinuationV21212.toJson(report, technical)

        assertTrue(continuation.optString("state").contains("CONTINUE_AFTER_D_PLUS"))
        assertTrue(continuation.optString("resultContract").contains("D_or_D_plus_is_a_continuation_state_not_a_final_stop"))
        assertTrue(continuation.optJSONArray("continuationStages")!!.length() >= 6)
        assertFalse(continuation.optBoolean("claimUpgradeAllowed"))
    }

    @Test
    fun depressionKynurenineContinuationProducesEnzymeHypothesesNotMicrobiomeOnly() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("normalizedTopic", "depression kynurenine pathway IDO1 KMO neuroimmune")
                .put("rawInput", "depression kynurenine"))
        val continuation = GTIMTerminalDiscoveryContinuationV21212.toJson(report)
        val text = continuation.toString()

        assertTrue(text.contains("IDO1"))
        assertTrue(text.contains("KMO"))
        assertTrue(text.contains("tryptophan"))
        assertTrue(text.contains("microbiome route") || text.contains("microbiome"))
    }
}
