package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMEvidenceFirstRouteDiscoveryV21311Test {
    @Test
    fun ebolaBundibugyoInfersFilovirusBeforeDatasetSelection() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Ebola Bundibugyo BDBV cytokine host response"))
            .put("verifiedMetadataClosurePackV2132", JSONObject().put("selectedClosedTarget", "GSE166552"))
            .put("injectedMetadataSeedPackV21216", JSONObject().put("candidateHandles", JSONArray(listOf("GSE166552", "GSE45291"))))
        val inferred = GTIMRouteConfidenceGateV21311.infer(report)
        assertTrue(inferred.locked)
        assertEquals("filovirus_viral_host_response", inferred.lockedRoute)
        assertEquals("viral_filovirus_bundibugyo", inferred.lockedSubtype)
    }

    @Test
    fun availableCovidCapsuleDoesNotOverrideBundibugyoRoute() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "BDBV immune response"))
            .put("verifiedMetadataClosurePackV2132", JSONObject().put("selectedClosedTarget", "GSE166552"))
            .put("futureEvidenceLiteCorpusV2130", JSONObject().put("candidateHandles", JSONArray(listOf("GSE166552", "GSE152202"))))
        assertEquals("filovirus_viral_host_response", GTIMRouteConfidenceGateV21311.infer(report).lockedRoute)
        assertEquals("", GTIMCanonicalTargetAfterRouteLockV21311.canonicalTarget(report))
    }

    @Test
    fun weakCorrectRouteBeatsStrongWrongCapsule() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Ebola filovirus host response"))
            .put("verifiedMetadataClosurePackV2132", JSONObject().put("selectedClosedTarget", "GSE166552"))
            .put("injectedMetadataSeedPackV21216", JSONObject().put("candidateHandles", JSONArray(listOf("GSE166552"))))
        val inferred = GTIMRouteConfidenceGateV21311.infer(report)
        assertEquals("filovirus_viral_host_response", inferred.lockedRoute)
        assertEquals("viral_filovirus", inferred.lockedSubtype)
        assertEquals("", GTIMCanonicalTargetAfterRouteLockV21311.canonicalTarget(report))
    }

    @Test
    fun noCompatibleDatasetLeavesCanonicalTargetEmpty() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "unknown immune route without dataset"))
            .put("candidateHandleLedgerV21215", JSONObject().put("selectedReviewTarget", "GSE102556"))
        val inferred = GTIMRouteConfidenceGateV21311.infer(report)
        assertFalse(inferred.locked)
        assertEquals("", GTIMCanonicalTargetAfterRouteLockV21311.canonicalTarget(report))
        assertEquals("UNKNOWN_TOPIC_SAFE_FALLBACK_READY", GTIMUnknownTopicSafeFallbackV21311.toJson(report).getString("state"))
    }

    @Test
    fun covidRouteUsesCovidCapsuleOnlyAfterRouteLock() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "post-COVID immune persistence interferon IL-6 TNF"))
            .put("verifiedMetadataClosurePackV2132", JSONObject().put("selectedClosedTarget", "GSE166552"))
        val inferred = GTIMRouteConfidenceGateV21311.infer(report)
        assertEquals("viral_interferon_cytokine", inferred.lockedRoute)
        assertEquals("viral_covid_postviral", inferred.lockedSubtype)
        assertEquals("GSE166552", GTIMCanonicalTargetAfterRouteLockV21311.canonicalTarget(report))
    }

    @Test
    fun routeSelectionExplainsWhyItChoseThePath() {
        val report = JSONObject().put("topicCapture", JSONObject().put("rawInput", "depression kynurenine IDO1 KMO"))
            .put("verifiedMetadataClosurePackV2132", JSONObject().put("selectedClosedTarget", "GSE102556"))
        val json = GTIMRouteConfidenceGateV21311.toJson(report)
        assertTrue(json.getString("explanation").contains("depression_kynurenine_neuroimmune"))
        assertTrue(json.getString("policy").contains("semantic route fit"))
    }
}
