package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMLoopBreakerUiStateV2144Test {
    @Test
    fun blankStartIsCleanNoOpAndDoesNotExposeReportActions() {
        val blank = GTIMLoopBreakerUiStateV2144.blankInputCard()
        val state = GTIMLoopBreakerUiStateV2144.controlsCard("blank_input", reportAvailable = false)
        assertTrue(blank.contains("No run started"))
        assertTrue(blank.contains("never replays an old question"))
        assertFalse(state.getBoolean("copyExportEnabled"))
        assertFalse(state.getBoolean("blankInputShowsReport"))
        assertFalse(state.getBoolean("oldTopicReplay"))
    }
}
