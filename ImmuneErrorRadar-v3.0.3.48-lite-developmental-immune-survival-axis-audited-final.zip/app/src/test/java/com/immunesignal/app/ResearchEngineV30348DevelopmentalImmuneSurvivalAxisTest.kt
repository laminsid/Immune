package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30348DevelopmentalImmuneSurvivalAxisTest {
    @Test
    fun liteRowsInjectDevelopmentalImmuneFuelButBlockSurvivalClaims() {
        val state = ResearchStateV3.initial(
            ResearchInputV3(
                topic = "GSE85047 neuroblastoma MYCN ADRN MES CD8 NK TAM DLK1 CCL18 survival",
                explicitMatrixRows = PediatricOncologyExplicitMatrixV30337.rows(),
                explicitMatrixProvenance = PediatricOncologyExplicitMatrixV30337.SOURCE_ACCESSION,
                explicitCaseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                explicitControlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels
            )
        )
        val signal = ProcessedExpressionSignalReportV30329(
            active = true,
            state = "PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_EXECUTED_REVIEW_ONLY",
            dataset = "GSE85047",
            moduleCount = 1,
            rawMatrixDgeExecuted = true,
            estimates = emptyList(),
            nextAction = "attach full matrix and survival labels",
            matrixFuel = MatrixFuelSnapshotV30330(
                state = "MATRIX_FUEL_READY_FOR_RAW_DGE_V30331",
                accession = "GSE85047",
                rowCount = 12,
                caseRowCount = 6,
                controlRowCount = 6,
                source = "declared_source_lite_rows",
                groupResolution = ComparatorGroupResolutionV30330(
                    state = "COMPARATOR_GROUP_VALUES_RESOLVED_FROM_DECLARED_MYCN_LABELS",
                    accession = "GSE85047",
                    caseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                    controlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels,
                    unresolvedAxis = "MYCN_amplified_vs_non_amplified",
                    source = "declared_labels"
                ),
                warnings = emptyList(),
                matrixFuelSourceAccession = "GSE85047",
                dgeExecutedOnAccession = "GSE85047",
                retrievalEvidenceBestAccession = "GSE85047"
            )
        )
        val open = OpenDiscoveryReadinessControllerV30347.evaluate(state.input.topic, state, signal)
        val v48 = DevelopmentalImmuneSurvivalAxisV30348.evaluate(state.input.topic, state, signal, open)

        assertTrue(v48.active)
        assertEquals("SURVIVAL_AXIS_LITE_CONTINUATION_READY_FULL_COHORT_REQUIRED", v48.state)
        assertEquals("LITE_MATRIX_SURVIVAL_DISCOVERY_BLOCKED_FUEL_INJECTED", v48.matrixState)
        assertEquals("LITE_FUEL_ONLY_NO_SURVIVAL_CLAIM", v48.allowedClaimLabel)
        assertTrue(v48.liteContinuationFuel.any { it.contains("ADRN markers") })
        assertTrue(v48.liteContinuationFuel.any { it.contains("Effector function/barrier") })
        assertTrue(v48.requiredBeforeSurvivalClaim.any { it.contains("GSE85047") })
        assertTrue(v48.decouplingAxes.contains("target_visibility"))
    }

    @Test
    fun fullRowsWithSurvivalTopicAllowResearchOnlySurvivalAxisCandidate() {
        val rows = buildList {
            repeat(120) { idx -> add(ExpressionSampleRowV30329("MYCN_$idx", "case_mycn_amplified", mapOf("PHOX2B" to 6.1, "PRRX1" to 3.2, "CD8A" to 2.1, "CD68" to 5.2, "DLK1" to 6.4))) }
            repeat(163) { idx -> add(ExpressionSampleRowV30329("NON_$idx", "control_non_mycn", mapOf("PHOX2B" to 4.1, "PRRX1" to 4.4, "CD8A" to 4.7, "CD68" to 3.8, "DLK1" to 3.2))) }
        }
        val topic = "GSE85047 neuroblastoma ADRN MES CD8 NK TAM PFS OS survival MYCN"
        val state = ResearchStateV3.initial(
            ResearchInputV3(
                topic = topic,
                explicitMatrixRows = rows,
                explicitMatrixProvenance = "GSE85047",
                explicitCaseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                explicitControlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels
            )
        )
        val signal = ProcessedExpressionSignalReportV30329(
            active = true,
            state = "FULL_MATRIX_REVIEW_SIGNAL_READY",
            dataset = "GSE85047",
            moduleCount = 1,
            rawMatrixDgeExecuted = true,
            estimates = emptyList(),
            nextAction = "run survival axis",
            matrixFuel = MatrixFuelSnapshotV30330(
                state = "MATRIX_FUEL_READY_FOR_RAW_DGE",
                accession = "GSE85047",
                rowCount = 283,
                caseRowCount = 120,
                controlRowCount = 163,
                source = "explicit_full_matrix_rows",
                groupResolution = ComparatorGroupResolutionV30330(
                    state = "COMPARATOR_GROUP_VALUES_RESOLVED_FROM_DECLARED_MYCN_LABELS",
                    accession = "GSE85047",
                    caseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                    controlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels,
                    unresolvedAxis = "MYCN_amplified_vs_non_amplified",
                    source = "declared_labels"
                ),
                warnings = emptyList(),
                matrixFuelSourceAccession = "GSE85047",
                dgeExecutedOnAccession = "GSE85047",
                retrievalEvidenceBestAccession = "GSE85047"
            )
        )
        val open = OpenDiscoveryReadinessControllerV30347.evaluate(topic, state, signal)
        val v48 = DevelopmentalImmuneSurvivalAxisV30348.evaluate(topic, state, signal, open)

        assertEquals("SURVIVAL_LINKED_STATE_AXIS_READY_RESEARCH_ONLY", v48.state)
        assertEquals("FULL_COHORT_SURVIVAL_AXIS_READY_REVIEW_ONLY", v48.matrixState)
        assertEquals("SURVIVAL_LINKED_STATE_AXIS_CANDIDATE_RESEARCH_ONLY", v48.allowedClaimLabel)
        assertTrue(v48.primaryRun.contains("ADRN_MES_delta"))
        assertTrue(v48.blockedClaimLabel.contains("NO_DISCOVERY_OR_TREATMENT_CLAIM"))
        assertFalse(v48.requiredBeforeSurvivalClaim.any { it.startsWith("attach_GSE85047") })
    }
}
