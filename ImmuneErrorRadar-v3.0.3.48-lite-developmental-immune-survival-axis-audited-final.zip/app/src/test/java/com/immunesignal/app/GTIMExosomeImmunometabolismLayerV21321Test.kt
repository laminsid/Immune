package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMExosomeImmunometabolismLayerV21321Test {
    @Test
    fun exosomeAndImmunometabolismCardsStayResearchOnlyAndSurfaceLinked() {
        val report = JSONObject().put("topic", "cancer exosome liquid biopsy adipose immunometabolism research")
        val card = GTIMExosomeImmunometabolismSurfaceCardV21321.toJson(report)
        assertTrue(card.getString("state").contains("EXOSOME_IMMUNOMETABOLISM_SURFACE_CARD_READY"))
        assertFalse(card.getBoolean("diagnosis_claim_allowed"))
        assertFalse(card.getBoolean("treatment_claim_allowed"))
        assertFalse(card.getBoolean("diet_protocol_allowed"))
        val text = GTIMFinalActiveDecisionSurfaceV21317.renderLines(report).joinToString("\n")
        assertTrue(text.contains("Exosome / immunometabolism role card"))
        assertTrue(text.contains("diagnosis/treatment/diet protocol=BLOCKED") || text.contains("diet_protocol=BLOCKED"))
    }

    @Test
    fun finalExosomeImmunometabolismClosureBlocksDiagnosisTherapyDietAndClinicalClaims() {
        val report = JSONObject().put("topic", "diabetes adipose tissue macrophage exosome delivery")
        val closure = GTIMFinalExosomeImmunometabolismClosureV21321.toJson(report)
        assertTrue(closure.getString("state").contains("FINAL_EXOSOME_IMMUNOMETABOLISM_CLOSURE_READY"))
        assertTrue(closure.getBoolean("sandbox_preview_allowed"))
        assertFalse(closure.getBoolean("liquid_biopsy_diagnosis_allowed"))
        assertFalse(closure.getBoolean("exosome_therapy_claim_allowed"))
        assertFalse(closure.getBoolean("metabolic_treatment_claim_allowed"))
        assertFalse(closure.getBoolean("diet_protocol_allowed"))
        assertFalse(closure.getBoolean("clinical_implementation_allowed"))
    }
}
