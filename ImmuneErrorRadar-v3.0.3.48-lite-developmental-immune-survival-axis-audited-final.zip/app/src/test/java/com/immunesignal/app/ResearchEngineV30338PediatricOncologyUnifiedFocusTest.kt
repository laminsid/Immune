package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30338PediatricOncologyUnifiedFocusTest {
    @Test
    fun pediatricFocusRoutesNeuroblastomaMycnToExplicitMatrixAndTranslationLens() {
        val topic = "pediatric neuroblastoma MYCN amplified GD2 B7-H3 CAR-T tumor microenvironment"
        val route = SpecialistRouterV30335.route(topic, "GSE85047")
        assertEquals("pediatric_neuroblastoma_mycn_gd2_b7h3", route.routeId)
        assertTrue(PediatricOncologyExplicitMatrixV30337.isEligible(topic, "GSE85047"))
        assertTrue(PediatricOncologyUnifiedFocusV30338.isFocus(topic, "GSE85047"))
        assertTrue(PediatricOncologyUnifiedFocusV30338.modulesFor(topic, "GSE85047").any { it.name.contains("b7h3") })
        assertTrue(PediatricOncologyUnifiedFocusV30338.modulesFor(topic, "GSE85047").any { it.name.contains("dinutuximab") })
    }

    @Test
    fun embeddedMatrixHasDeclaredCaseControlRowsAndEnoughSamplesForDge() {
        val rows = PediatricOncologyExplicitMatrixV30337.rows()
        assertEquals(12, rows.size)
        assertEquals(6, rows.count { it.group == "case_mycn_amplified" })
        assertEquals(6, rows.count { it.group == "control_non_mycn" })
        assertTrue(rows.all { row -> PediatricOncologyExplicitMatrixV30337.markers.all { marker -> row.values.containsKey(marker) } })
    }

    @Test
    fun pediatricMatrixDoesNotLeakIntoLeukemiaOrSarcoma() {
        assertFalse(PediatricOncologyExplicitMatrixV30337.isEligible("pediatric leukemia aml relapse bone marrow gd2 absent"))
        assertFalse(PediatricOncologyExplicitMatrixV30337.isEligible("childhood sarcoma osteosarcoma checkpoint cd8 without neuroblastoma mycn"))
        assertTrue(PediatricOncologyExplicitMatrixV30337.isEligible("childhood neuroblastoma MYCN amplification GD2"))
    }

    @Test
    fun pediatricTranslationLensNeverCertifiesDiscoveryFromDeclaredSourceOnly() {
        val topic = "pediatric neuroblastoma MYCN amplified GD2 B7-H3"
        val fuel = MatrixFuelSnapshotV30330(
            state = "MATRIX_FUEL_READY_FOR_RAW_DGE_V30331",
            accession = "GSE85047",
            rowCount = 12,
            caseRowCount = 6,
            controlRowCount = 6,
            source = "pediatric_oncology_declared_source_gse85047_matrix_rows_v30337",
            groupResolution = ComparatorGroupResolutionV30330(
                state = "COMPARATOR_GROUP_VALUES_RESOLVED_V30337_PEDIATRIC_ONCOLOGY_DECLARED_MATRIX_LABELS",
                accession = "GSE85047",
                caseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                controlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels,
                unresolvedAxis = "mycn_amplified_vs_non_mycn",
                source = "test"
            ),
            warnings = listOf("declared_source_only"),
            certificationLevel = PediatricOncologyExplicitMatrixV30337.CERTIFICATION_LEVEL,
            analysisMode = "USER_ATTESTED_DGE",
            scientificInterpretability = "MODERATE_SINGLE_DATASET_RESEARCH_ONLY_NOT_INDEPENDENTLY_VERIFIED",
            fuelOrigin = PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN,
            verificationLevel = PediatricOncologyExplicitMatrixV30337.VERIFICATION_LEVEL
        )
        val expression = ProcessedExpressionSignalReportV30329(
            active = true,
            state = "PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_EXECUTED_REVIEW_ONLY",
            dataset = "GSE85047",
            moduleCount = 1,
            rawMatrixDgeExecuted = true,
            estimates = emptyList(),
            nextAction = "review only",
            matrixFuel = fuel
        )
        val gate = CertifiedMatrixFuelGateV30332.evaluate(expression)
        val lens = PediatricOncologyUnifiedFocusV30338.evaluate(topic, SpecialistRouterV30335.route(topic, "GSE85047"), expression, gate)
        assertTrue(lens.active)
        assertEquals("DECLARED_SOURCE_NEUROBLASTOMA_MYCN_DGE_EXECUTED", lens.dgeState)
        assertFalse(lens.certifiedForDiscovery)
        assertTrue(lens.axes.any { it.id.contains("B7H3") })
        assertTrue(lens.axes.any { it.id.contains("GD2") })
    }
}
