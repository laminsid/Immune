package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMProfessionalResearchOrchestratorV2140Test {
    @Test
    fun professionalOrchestratorProducesCompactDossierWithoutMonolithicEncoding() {
        val snapshot = RuntimeCrashSafetyAndTopicGuardV2740.capture("Allergy")
        val deepening = GTIMSameTopicDeepeningBridgeV2123.build("Allergy", "Allergy", emptyList())
        val budget = GTIMMobileSearchRuntimeBudgetV21322.fromDeepeningLimits(deepening.runLimits)
        val phases = mutableListOf<String>()
        val report = GTIMProfessionalResearchOrchestratorV2140.runMobilePass(
            snapshot = snapshot,
            budget = budget,
            sameTopicPlan = deepening,
            recentReportLines = emptyList()
        ) { phase -> phases += phase.stageId }
        assertEquals("2.14.0-professional-phased-agentic-orchestrator", report.getString("version"))
        assertTrue(report.toString().contains("V2140_PHASED_AGENT_ORCHESTRATOR_NO_MONOLITHIC_REPORT_JSON_ENCODING"))
        assertTrue(phases.contains("V2140_READ_QUESTION"))
        assertTrue(phases.contains("V2140_REPORT_OUTPUT"))
        assertTrue(report.getJSONArray("globalHypothesisCandidates").length() >= 3)
        assertTrue(GTIMProfessionalResearchOrchestratorV2140.renderUserCard(report)!!.contains("Professional agentic research dossier"))
    }
}
