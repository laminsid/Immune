package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30337PediatricOncologyExplicitMatrixFocusTest {
    private val topic = "pediatric neuroblastoma childhood cancer MYCN amplified immune exclusion GSE85047 CD8 NK GD2"

    @Test
    fun pediatricOncologyDeclaredSourceMatrixFillsRowsAndRunsRealDge() {
        val state = ResearchStateV3.initial(ResearchInputV3(topic))
        val metadata = ResearchMetadataProbeIngestionReportV3.inactive(topic)
        val moduleScore = pediatricDatasetModuleScore()
        val comparatorVariables = pediatricComparatorVariables()
        val mechanism = MechanismModuleSignalSnapshotV30328(
            active = true,
            state = "MODULE_SIGNAL_CANDIDATE_REVIEW_ONLY",
            dataset = "GSE85047",
            axis = "MYCN-amplified pediatric neuroblastoma immune-exclusion axis",
            module = "gse85047_neuroblastoma_mycn_probe_level_module_v30337",
            markers = PediatricOncologyExplicitMatrixV30337.markers,
            readiness = 85,
            nextAction = "Run declared-source matrix DGE review."
        )

        val (rows, fuel) = MatrixFuelProviderV30331.collect(state, metadata, moduleScore, comparatorVariables)
        val signal = ProcessedExpressionSignalExecutorV30329.evaluate(
            state = state,
            metadataProbe = metadata,
            datasetModuleScore = moduleScore,
            comparatorVariables = comparatorVariables,
            mechanismSignal = mechanism,
            matrixRows = rows,
            matrixFuel = fuel
        )
        val gate = CertifiedMatrixFuelGateV30332.evaluate(signal)

        assertEquals(12, rows.size)
        assertEquals(12, fuel.rowCount)
        assertEquals(6, fuel.caseRowCount)
        assertEquals(6, fuel.controlRowCount)
        assertEquals("USER_ATTESTED_DGE", fuel.analysisMode)
        assertEquals(PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN, fuel.fuelOrigin)
        assertTrue(fuel.rawRowsReady)
        assertFalse(fuel.certifiedForDiscovery)
        assertTrue(signal.rawMatrixDgeExecuted)
        assertEquals("PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_EXECUTED_REVIEW_ONLY", signal.state)
        assertTrue(signal.estimates.any { it.module == "gse85047_neuroblastoma_mycn_probe_level_module_v30337" })
        assertTrue(signal.estimates.any { it.markerResults.isNotEmpty() })
        assertFalse(signal.hasMechanismSupport)
        assertEquals("PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_REVIEW_ONLY_NOT_CERTIFIED", gate.state)
        assertFalse(gate.certifiedForDiscovery)
    }


    @Test
    fun gse85047MatrixDoesNotAttachToUnrelatedPediatricCancerWithoutNeuroblastomaAxis() {
        assertFalse(PediatricOncologyExplicitMatrixV30337.isEligible("pediatric leukemia aml immune relapse bone marrow"))
        assertFalse(PediatricOncologyExplicitMatrixV30337.isEligible("childhood sarcoma tumor microenvironment checkpoint cd8"))
        assertTrue(PediatricOncologyExplicitMatrixV30337.isEligible("pediatric neuroblastoma MYCN amplified tumor"))
    }

    @Test
    fun csvMirrorHasDeclaredCaseControlAndProbeMarkers() {
        val rows = PediatricOncologyExplicitMatrixV30337.rows()
        assertEquals("pediatric_oncology/gse85047_neuroblastoma_mycn_probe_matrix_v30337.csv", PediatricOncologyExplicitMatrixV30337.CSV_ASSET_PATH)
        assertEquals(20, PediatricOncologyExplicitMatrixV30337.markers.size)
        assertEquals(6, rows.count { it.group == "case_mycn_amplified" })
        assertEquals(6, rows.count { it.group == "control_non_mycn" })
        assertTrue(rows.all { row -> PediatricOncologyExplicitMatrixV30337.markers.all { marker -> row.values.containsKey(marker) } })
    }

    private fun pediatricComparatorVariables(): ComparatorVariableExtractionReportV30329 = ComparatorVariableExtractionReportV30329(
        active = true,
        state = "COMPARATOR_VARIABLES_READY_FOR_MATRIX_GROUPING",
        variables = listOf(
            ComparatorVariableV30329(
                accession = "GSE85047",
                caseControlAxis = "MYCN-amplified vs non-MYCN-amplified pediatric neuroblastoma",
                responderAxis = "none",
                subtypeAxis = "MYCN amplification",
                tissueCellAxis = "primary untreated neuroblastoma tumor",
                timepointAxis = "baseline_primary_tumor",
                confidence = 95,
                missing = emptyList(),
                sourceTrace = listOf("v30337_declared_source_matrix"),
                caseGroupLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                controlGroupLabels = PediatricOncologyExplicitMatrixV30337.controlLabels
            )
        ),
        bestAccession = "GSE85047",
        readiness = 95,
        nextAction = "Use declared MYCN case/control labels for DGE review."
    )

    private fun pediatricDatasetModuleScore(): ResearchDatasetModuleScoreCardV3 = ResearchDatasetModuleScoreCardV3(
        active = true,
        version = ResearchEngineV3ReleaseIdentity.VERSION_NAME,
        dataset = "GSE85047",
        state = "DATASET_MODULE_SCORE_READY_V30337_PEDIATRIC_ONCOLOGY",
        decision = "ALLOW_REVIEW_ONLY_DECLARED_SOURCE_DGE",
        moduleScore = 84,
        comparatorScore = 20,
        expressionScore = 20,
        immuneSignatureScore = 16,
        outcomeControlScore = 12,
        routeSpecificityScore = 12,
        causalLimitScore = 4,
        comparatorLabels = listOf(
            ResearchComparatorScoreV3("MYCN-amplified vs non-MYCN", "DECLARED_SOURCE_READY", 20, 20)
        ),
        immuneRoutes = listOf(
            ResearchImmuneRouteScoreV3(
                route = "gse85047_neuroblastoma_mycn_probe_level_module_v30337",
                status = "PROBE_LEVEL_DGE_ROUTE_READY_REVIEW_ONLY",
                markers = PediatricOncologyExplicitMatrixV30337.markers,
                points = 16,
                maxPoints = 20
            )
        ),
        capsuleId = "pediatric_oncology_gse85047_v30337",
        capsuleModules = listOf("gse85047_neuroblastoma_mycn_probe_level_module_v30337"),
        expressionRoute = "PEDIATRIC_NEUROBLASTOMA_GSE85047_DECLARED_SOURCE_PROBE_MATRIX_ROUTE",
        nextAction = "Run DGE and require ETL/platform mapping before gene-symbol mechanism claims.",
        blockedReason = "none",
        boundary = "Research-only declared-source pediatric oncology matrix route; not clinical or certified discovery."
    )
}
