package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30323HypothesisEvidenceUpgradeTest {
    @Test
    fun covidHypothesisShowsEvidenceUpgradePathNotJustRanking() {
        val target = ResearchMetadataProbeTargetV3(
            accession = "GSE152522",
            title = "SARS-CoV-2 PBMC transcriptome severe mild healthy control cohort",
            softUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE152522&targ=gsm&form=text",
            state = "METADATA_PROBE_READY_GSE152522_PROCESSED_EXPRESSION_ROUTE",
            comparatorStatus = "COMPARATOR_LABELS_REQUIRED_REVIEW_ONLY",
            processedExpressionRoute = "GREIN_OR_PROCESSED_EXPRESSION_ROUTE_CANDIDATE_REVIEW_ONLY",
            matrixStatus = "MATRIX_OR_PROCESSED_EXPRESSION_NOT_INGESTED",
            sampleMetadataStatus = "SOFT_METADATA_INGESTION_REQUIRED",
            expectedComparators = listOf("COVID severe vs mild/moderate", "COVID patient vs healthy control", "PBMC source", "acute vs post-acute recovery"),
            routeQuestions = listOf("Can sample IDs link severity labels to expression matrix?"),
            nextAction = "Lock comparator labels then verify processed expression route.",
            boundary = "research-only"
        )
        val metadata = ResearchMetadataProbeIngestionReportV3(
            active = true,
            state = "METADATA_PROBE_READY_GSE152522_PROCESSED_EXPRESSION_ROUTE",
            targets = listOf(target),
            primaryNextAction = target.nextAction,
            causalGap = "metadata only until sample labels and matrix linkage are reviewed",
            commercialReadinessNote = "review-only",
            boundary = "research-only"
        )
        val comparator = DatasetComparatorLabelExtractorV3.extract(metadata).first()
        val expression = ProcessedExpressionRouteVerifierV3.verify(metadata, listOf(comparator)).first()
        assertTrue(comparator.state.contains("READY") || comparator.state.contains("PARTIAL"))
        assertTrue(expression.state.contains("CANDIDATE"))
    }

    @Test
    fun dataGapFindingIsMarkedAsEvidenceReadinessNotBiologicalClaim() {
        val state = ResearchStateV3.initial(ResearchInputV3("alzheimer neuroinflammation vs diabetes adipose macrophage"))
        val closure = ResearchClosureSnapshotV3(
            canCloseReport = false,
            openGates = listOf("visible_source_evidence", "visible_dataset_or_provenance_evidence"),
            visibleTierABCount = 0,
            visibleTierCDCount = 0,
            contradictionObjectiveExecuted = true,
            contradictionEvidenceFound = false,
            distinctAccessions = emptyList(),
            criticalRoleIndependencePassed = true,
            contradictionObjectiveExhausted = true
        )
        val readiness = ResearchReadinessAssessmentV3.evaluate(state, closure)
        val plans = ResearchHypothesisEvidenceUpgradeEngineV3.planAll(
            hypotheses = listOf("Evidence gap finding: current evidence is insufficient; prioritize matched datasets."),
            state = state,
            closure = closure,
            readiness = readiness,
            metadataProbe = ResearchMetadataProbeIngestionReportV3.inactive(state.input.topic),
            datasetModuleScore = ResearchDatasetModuleScoreCardV3.inactive("no_dataset")
        )
        assertEquals("EVIDENCE_GAP_FINDING", plans.first().hypothesisType)
        assertTrue(plans.first().evidenceMeaning.contains("evidence readiness", ignoreCase = true))
        assertEquals(10, plans.first().evidenceTargetScore)
    }
}
