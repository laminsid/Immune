package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMBackgroundMetadataConsistencyV21215Test {
    @Test
    fun candidateLedgerDemotesCrossDomainSeedsAndKeepsCountersSeparate() {
        val report = JSONObject()
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "depression_kynurenine_neuroimmune"))
            .put("curatedMetadataSeedLibraryV21211", JSONObject()
                .put("localSeedMatches", JSONArray()
                    .put(JSONObject().put("handle", "GSE152202").put("topic_family", "viral_post_inflammatory"))
                    .put(JSONObject().put("handle", "GSE49454").put("topic_family", "depression_kynurenine_neuroimmune"))))
            .put("reportConsistencyGateV2121", JSONObject().put("verifiedMatrixFiles", 0))
        val ledger = GTIMCandidateHandleLedgerV21215.toJson(report)
        assertEquals("CANDIDATE_HANDLE_LEDGER_READY", ledger.getString("state"))
        assertTrue(ledger.getJSONArray("allCandidateHandles").toString().contains("GSE49454"))
        assertFalse(ledger.getJSONArray("allCandidateHandles").toString().contains("GSE152202"))
        assertTrue(ledger.getJSONArray("demotedCrossDomainSeeds").toString().contains("GSE152202"))
        assertEquals(0, ledger.getInt("verifiedCapsuleSourceCount"))
    }

    @Test
    fun softParserExtractsSampleComparatorAndProvenanceReadiness() {
        val soft = """
            !Sample_geo_accession = GSM1
            !Sample_title = depression case sample
            !Sample_source_name_ch1 = blood PBMC patient
            !Sample_organism_ch1 = Homo sapiens
            !Sample_characteristics_ch1 = group: control
            !Sample_platform_id = GPL111
            !Series_supplementary_file = matrix.txt.gz
            !Sample_relation = SRA: SRP123456
        """.trimIndent()
        val parsed = GTIMGeoSoftMetadataParserV21215.parse("GSE49454", soft)
        val mapping = GTIMGseSrpMappingWorkerV21215.parse("GSE49454", soft)
        assertEquals("METADATA_READY_FOR_REVIEW_ONLY_CAPSULE_CHECK", parsed.getString("softProbeState"))
        assertTrue(parsed.getString("comparatorLabelsStatus").contains("found"))
        assertTrue(parsed.getString("sampleProvenanceStatus").contains("found"))
        assertTrue(mapping.getJSONArray("mappingHandles").toString().contains("SRP123456"))
    }

    @Test
    fun utilityScoreIsCappedWithoutVerifiedCapsuleOrMetadataProbe() {
        val report = JSONObject()
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "viral_interferon_cytokine"))
            .put("candidateHandleLedgerV21215", JSONObject().put("verifiedCapsuleSourceCount", 0))
            .put("text", "human PBMC comparator control sample provenance contradiction GSE152202 matrix capsule")
        val utility = GTIMPublishedResearchUtilityScoreV21213.toJson(report)
        assertTrue(utility.getBoolean("hardCapApplied"))
        assertTrue(utility.getInt("score") <= 6)
        assertTrue(utility.getJSONArray("hardCapReasons").toString().contains("verified_capsule_source_count=0"))
    }

    @Test
    fun closureRequiresBackgroundWorkersAndRouteLinkage() {
        val report = JSONObject()
            .put("candidateHandleLedgerV21215", JSONObject()
                .put("candidateHandleCount", 1)
                .put("demotedCrossDomainSeeds", JSONArray())
                .put("topicCompatibleTargetSelected", false))
            .put("metadataProbeBackgroundWorkersV21215", JSONObject()
                .put("state", "BACKGROUND_METADATA_PROBE_RESULTS_READY")
                .put("executedSteps", JSONArray().put("GSE49454:soft_metadata_probe")))
        val closure = GTIMBackgroundMetadataConsistencyClosureV21215.toJson(report)
        assertEquals("BACKGROUND_METADATA_CONSISTENCY_READY", closure.getString("state"))
        assertTrue(closure.getString("oldRoutesStillLinked").contains("external_router"))
        assertTrue(closure.getBoolean("executedVsQueuedSeparated"))
    }
}
