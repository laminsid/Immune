package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMSingleRunResearchRuntimeResetV2150Test {
    @Test
    fun contractUsesTaskProgressAndNeverLoopCounters() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
        assertEquals(10, contract.totalTaskCount)
        assertEquals(0, contract.progressPercent)
        assertFalse(contract.foregroundReportJsonEncodingAllowed)
        contract = contract.withStatus(ResearchRunStatusV2150.RUNNING)
            .updateTask("T1_READ_QUESTION", ResearchTaskStatusV2150.RUNNING)
            .updateTask("T1_READ_QUESTION", ResearchTaskStatusV2150.DONE)
        assertEquals(10, contract.progressPercent)
        val ui = ResearchProgressReducerV2150.reduce(contract)
        assertEquals(10, ui.progressPercent)
        assertFalse(ui.reportAvailable)
    }

    @Test
    fun orchestratorDoesNotAutoFinishWithoutClosedProofGate() {
        val states = mutableListOf<ResearchRunContractV2150>()
        val report = ProfessionalResearchOrchestratorV2150.run(
            topic = "Ebola bundibugyo",
            shouldPause = { false },
            shouldStop = { false },
            onState = { contract, _ -> states += contract },
            policy = ResearchExecutionPolicyV2154.unitTestNoFastFinish()
        )
        val contract = report.getJSONObject("researchRunContractV2150")
        assertEquals("CHECKPOINT_READY", contract.getString("status"))
        assertTrue(contract.getInt("progressPercent") in 0..100)
        assertFalse(contract.getBoolean("foregroundReportJsonEncodingAllowed"))
        // WAITING_FOR_PROOF is still emitted as a transient state, but v2.15.5 must not stay there forever.
        assertTrue(report.getJSONObject("professionalResearchOrchestratorV2150").getBoolean("noInfiniteProofWait"))
        assertTrue(states.none { it.completedTaskCount > it.totalTaskCount })
        assertTrue(report.getJSONObject("professionalResearchOrchestratorV2150").getBoolean("noDeepeningPassCounter"))
        assertTrue(report.getJSONObject("professionalResearchOrchestratorV2150").getBoolean("noFastFiveSecondReport"))
        assertFalse(report.getJSONObject("proofGatedRuntimeV2154").getBoolean("reportCanClose"))
        assertNotNull(ResearchBriefBuilderV2150.renderUserCard(report))
    }

    @Test
    fun orchestratorCanCloseOnlyWhenProofGateIsExplicitlySimulatedForUnitTest() {
        val report = ProfessionalResearchOrchestratorV2150.run(
            topic = "Ebola bundibugyo",
            shouldPause = { false },
            shouldStop = { false },
            onState = { _, _ -> },
            policy = ResearchExecutionPolicyV2154.unitTestWithClosedProof()
        )
        val contract = report.getJSONObject("researchRunContractV2150")
        assertEquals("REPORT_READY", contract.getString("status"))
        assertEquals(100, contract.getInt("progressPercent"))
    }
}
