package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3TopicNormalizerAndDomainGateTest {
    @Test
    fun longInstructionPromptIsCollapsedToBiomedicalQueryStem() {
        val raw = """
            Build a research-only dossier for depression linked to the kynurenine pathway.
            Primary focus:
            IDO1, TDO2, KMO, KYNU, ACMSD, tryptophan/kynurenine ratio, quinolinic acid, kynurenic acid, neuroimmune signaling, microglia activation, IL-6, TNF, IFN-γ, glutamate/NMDA signaling, and neurotransmission.
            Hard rules:
            Use injected/offline metadata seeds first.
            Reject or demote datasets whose disease/domain does not match depression/kynurenine.
        """.trimIndent()

        val profile = ResearchTopicNormalizerV3.profile(raw)
        val stem = profile.toQueryStem()

        assertEquals(ResearchDomainV3.DEPRESSION_KYNURENINE, profile.domain)
        assertTrue(stem.contains("depression"))
        assertTrue(stem.contains("kynurenine"))
        assertTrue(stem.length < 220)
        assertFalse(stem.contains("Hard rules", ignoreCase = true))
        assertFalse(stem.contains("Reject or demote", ignoreCase = true))
    }

    @Test
    fun allergySourceRejectsGeneralCovidAutoimmunePaper() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "41452424",
                title = "Association between COVID-19 and New-Onset Autoimmune Diseases: Updated Systematic Review and Meta-Analysis",
                source = SourceKindV3.PUBMED,
                abstractText = "COVID-19 autoimmune disease review with immune response, cytokine activation, and systemic inflammation in adults."
            ),
            requestedRole = EvidenceRoleV3.SOURCE,
            topic = "Allergies",
            query = "Allergies immune dysregulation PubMed"
        )

        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertTrue(node.limitations.contains("topic_specificity_failed"))
        assertFalse(node.satisfiesResearchRole(EvidenceRoleV3.SOURCE))
    }

    @Test
    fun gplPlatformCannotSatisfyDatasetGate() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "GPL96",
                title = "[HG-U133A] Affymetrix Human Genome U133A Array",
                source = SourceKindV3.GEO,
                abstractText = "Platform annotation record only."
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = "Allergies",
            query = "Allergies transcriptome GEO RNA-seq cohort"
        )

        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertTrue(node.limitations.contains("dataset_role_rejects_geo_platform_gpl_without_series_or_samples"))
        assertFalse(node.satisfiesResearchRole(EvidenceRoleV3.DATASET))
    }

    @Test
    fun contradictionObjectiveRunsBeforeOptionalProvenance() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = StaticEvidenceAdapterV3(
                mapOf(
                    "immune dysregulation pubmed" to listOf(
                        EvidenceSearchRecordV3("1001", "COVID-19 immune dysregulation cytokine cohort", SourceKindV3.PUBMED, abstractText = "COVID-19 cytokine immune response cohort.")
                    ),
                    "transcriptome geo" to listOf(
                        EvidenceSearchRecordV3("GSE2001", "COVID-19 PBMC transcriptome GEO dataset", SourceKindV3.GEO, abstractText = "COVID-19 PBMC transcriptome dataset with healthy controls.")
                    ),
                    "tissue comparator limitation" to listOf(
                        EvidenceSearchRecordV3("3001", "COVID-19 tissue comparator limitation study", SourceKindV3.PUBMED, abstractText = "COVID-19 immune signature negative control comparator and tissue limitation analysis.")
                    ),
                    "sample provenance" to listOf(
                        EvidenceSearchRecordV3("GSE2002", "COVID-19 sample provenance comparator labels", SourceKindV3.GEO, abstractText = "COVID-19 sample provenance healthy controls disease severity.")
                    )
                )
            ))
        ).run(ResearchInputV3("Covid", budget = ResearchBudgetV3(maxNetworkCalls = 12, maxEmptyQueries = 8)))

        val executed = result.report.executedObjectives
        val contradictionIndex = executed.indexOfFirst { it.startsWith("contradiction:") }
        val provenanceIndex = executed.indexOfFirst { it.startsWith("provenance:") }
        assertTrue(contradictionIndex >= 0)
        assertTrue(provenanceIndex < 0 || contradictionIndex < provenanceIndex)
    }
}
