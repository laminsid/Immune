package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMBoundedProofPassSchedulerV2146Test {
    @Test
    fun proofPassesAreBoundedAndUiDoesNotExposeInfiniteDeepeningLoop() {
        assertEquals(5, GTIMBoundedProofPassSchedulerV2146.maxPasses())
        assertEquals(1, GTIMBoundedProofPassSchedulerV2146.passNumber(0))
        assertEquals(5, GTIMBoundedProofPassSchedulerV2146.passNumber(221))
        assertTrue(GTIMBoundedProofPassSchedulerV2146.isFinalPass(4))

        val steps = GTIMNoInstantReportGateV2145.defaultSteps()
        assertEquals(5, steps.size)
        assertEquals("V2146_BATCH_CHECKPOINT_READY", steps.last().stageId)
        assertFalse(steps.any { it.label.contains("Deepening loop", ignoreCase = true) })
        assertFalse(steps.any { it.queued.contains("until user stops", ignoreCase = true) })

        val card = GTIMNoInstantReportGateV2145.workingUiCard("Ebola bundibugyo", steps.last(), 221)
        assertTrue(card.contains("Proof batch pass: 5/5"))
        assertTrue(card.contains("no endless loop"))
        assertFalse(card.contains("Deepening pass: 221"))
    }

    @Test
    fun boundedBatchCheckpointUnlocksCheckpointWithoutFinalProofClaim() {
        val report = JSONObject()
        GTIMBoundedProofPassSchedulerV2146.annotate(report, currentPass = 5, completed = true, stoppedByUser = false)
        val scheduler = report.getJSONObject("boundedProofPassSchedulerV2146")
        assertTrue(scheduler.getBoolean("completed"))
        assertFalse(scheduler.getBoolean("finalReport"))
        assertEquals(5, scheduler.getInt("currentPass"))
        assertEquals("research checkpoint only; not proof, diagnosis, treatment, dosing, or clinical advice", scheduler.getString("claimLimit"))
    }
}
