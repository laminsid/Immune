package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalSurfaceDomainCoherenceGuardV21313Test {
    private fun filovirusReport(): JSONObject = JSONObject()
        .put("topicCapture", JSONObject().put("rawInput", "Bundibugyo filovirus host response research dossier"))
        .put("candidateHandleLedgerV21215", JSONObject()
            .put("selectedReviewTarget", "GSE152202")
            .put("candidateHandleCount", 4)
            .put("candidateHandles", JSONArray(listOf("GSE152202", "GSE166552", "GSE45291"))))
        .put("canonicalFinalSurfaceGuardV2135", JSONObject()
            .put("activeDomain", "filovirus_viral_host_response")
            .put("canonicalTarget", "GSE45291"))
        .put("finalBundibugyoSearchRuntimeClosureV213106", JSONObject()
            .put("activeDomain", "filovirus_viral_host_response")
            .put("activeSubtype", "viral_filovirus")
            .put("canonicalTarget", "GSE45291"))
        .put("finalUnifiedDiscoveryReadinessClosureV21310", JSONObject()
            .put("activeDomain", "filovirus_viral_host_response")
            .put("activeSubtype", "viral_filovirus")
            .put("canonicalTarget", "GSE45291")
            .put("versionAligned", true))
        .put("finalRouteSearchHardeningClosureV213103", JSONObject()
            .put("activeDomain", "filovirus_viral_host_response")
            .put("activeSubtype", "viral_filovirus")
            .put("canonicalTarget", "GSE45291")
            .put("versionAligned", true))

    @Test
    fun filovirusFirstSurfaceDoesNotRenderCovidPrimaryRoute() {
        val report = filovirusReport()
        val lines = GTIMFinalSurfaceDomainCoherenceGuardV21313.sanitizeFirstSurfaceLines(
            report,
            listOf(
                "Study focus: viral interferon-cytokine host-response study",
                "Research route: current-topic route: COVID -> interferon/IL-6/TNF -> COVID; prior templates retrieval-only",
                "Candidate handle ledger State: selected_review_target=GSE152202",
                "Next best action: Inspect GSE152202 as the canonical target"
            )
        ).joinToString("\n")

        assertTrue(lines.contains("Study focus: filovirus host-response study"))
        assertTrue(lines.contains("active-domain route: filovirus"))
        assertTrue(lines.contains("superseded_by_canonical_target=GSE45291"))
        assertFalse(lines.contains("current-topic route: COVID -> interferon/IL-6/TNF -> COVID"))
        assertFalse(lines.contains("Next best action: Inspect GSE152202"))
    }

    @Test
    fun studyResultCardUsesActiveDomainStudyFocus() {
        val report = filovirusReport()
        val lines = GTIMStudyResultCardV2126.publicLines(
            report,
            listOf("Research topic: Bundibugyo filovirus host response", "Strongest exploratory route: current-topic route: COVID -> interferon -> COVID")
        ).joinToString("\n")

        assertTrue(lines.contains("Study focus: filovirus host-response study"))
        assertTrue(lines.contains("Domain lock: Active-domain hypothesis lock: filovirus_viral_host_response"))
        assertTrue(lines.contains("canonical target") || lines.contains("GSE45291"))
        assertFalse(lines.contains("Study focus: viral interferon-cytokine host-response study"))
    }

    @Test
    fun mobileSurfaceKeepsLegacyRailsAppendixOnly() {
        val report = filovirusReport()
        val output = GTIMMobileSafeFirstSurfaceV21313.render(report).joinToString("\n")

        assertTrue(output.contains("Final surface domain-coherence guard"))
        assertTrue(output.contains("canonical_target=GSE45291") || output.contains("canonical_target=GSE45291"))
        assertTrue(output.contains("Compatibility appendix policy"))
        assertFalse(output.contains("current-topic route: COVID -> interferon/IL-6/TNF -> COVID"))
    }
}
