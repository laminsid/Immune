package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMProofGatedRuntimeV2154Test {
    @Test
    fun localMemoryAloneCannotCloseProofGate() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
        contract = contract.updateTask("T1_READ_QUESTION", ResearchTaskStatusV2150.DONE)
            .updateTask("T2_LOCAL_MEMORY_MAP", ResearchTaskStatusV2150.DONE)
            .updateTask("T3_ROUTE_CANDIDATES", ResearchTaskStatusV2150.DONE)
        assertFalse(ResearchExecutionPolicyV2154.hasClosedProofGate(contract))
        assertFalse(ResearchExecutionPolicyV2154.reportCanClose(contract))
    }

    @Test
    fun proofGateClosesOnlyWithSourceProvenanceAndContradictionHandles() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
        contract = contract
            .withEvidenceHandle("source_handle_closed_pubmed_or_geo")
            .withEvidenceHandle("sample_id_linked_metadata_verified")
            .withEvidenceHandle("contradiction_checked_wrong_tissue_species")
        assertTrue(ResearchExecutionPolicyV2154.hasClosedProofGate(contract))
    }
}


class GTIMBoundedProofProbeV2155Test {
    @Test
    fun boundedProbeDisabledInUnitTestDoesNotCloseReportButDoesNotHang() {
        val report = ProfessionalResearchOrchestratorV2150.run(
            topic = "Ebola bundibugyo",
            shouldPause = { false },
            shouldStop = { false },
            onState = { _, _ -> },
            policy = ResearchExecutionPolicyV2154.unitTestNoFastFinish()
        )
        val contract = report.getJSONObject("researchRunContractV2150")
        assertTrue(contract.getInt("progressPercent") in 0..100)
        assertFalse(report.getJSONObject("proofGatedRuntimeV2154").getBoolean("reportCanClose"))
        assertTrue(report.getJSONObject("professionalResearchOrchestratorV2150").getBoolean("noInfiniteProofWait"))
    }
}
