package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3BudgetContinuationTest {
    @Test
    fun fivePubMedSourceRecordsDoNotExhaustObjectiveLoopBeforeContradictionAttempt() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = multiRecordSourceAdapter())
        ).run(
            ResearchInputV3(
                topic = "Covid",
                budget = ResearchBudgetV3(
                    maxNetworkCalls = 8,
                    maxEmptyQueries = 8,
                    maxRepeatedSourceFamily = 2,
                    maxObjectives = 8
                )
            )
        )

        val executed = result.report.executedObjectives
        assertTrue(executed.any { it.startsWith("source:") })
        assertTrue("The V3 loop must continue beyond source evidence when one query returns multiple PubMed records.", executed.any { it.startsWith("dataset:") })
        assertTrue("The V3 loop must execute contradiction/falsifier search instead of stopping after source evidence.", executed.any { it.startsWith("contradiction:") })
        assertTrue(result.closure.contradictionObjectiveExecuted)

        val sourceOutcome = result.state.ledgerSnapshot.objectiveOutcomes.first { it.objective is ResearchObjectiveV3.FindSourceEvidence }
        assertEquals(5, sourceOutcome.nodes.size)
        assertEquals("Source family exposure is counted per query, not per returned record.", 1, sourceOutcome.budgetDelta.sourceFamilyCounts["pubmed"])
    }

    private fun multiRecordSourceAdapter(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3("42075512", "Post-COVID-19 immune dysregulation review", SourceKindV3.PUBMED),
                EvidenceSearchRecordV3("42074180", "COVID-19 host response cohort review", SourceKindV3.PUBMED),
                EvidenceSearchRecordV3("42035205", "COVID-19 immunomodulation systematic review", SourceKindV3.PUBMED),
                EvidenceSearchRecordV3("41830448", "Sepsis and COVID immune response review", SourceKindV3.PUBMED),
                EvidenceSearchRecordV3("41751338", "Long COVID complement immune dysregulation review", SourceKindV3.PUBMED)
            )
        )
    )
}
