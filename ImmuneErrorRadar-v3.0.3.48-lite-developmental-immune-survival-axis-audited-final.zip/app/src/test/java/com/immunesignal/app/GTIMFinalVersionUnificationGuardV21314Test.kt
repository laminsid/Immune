package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalVersionUnificationGuardV21314Test {
    @Test
    fun activeReleaseIdentityIsUnifiedAtV21315() {
        val guard = GTIMFinalVersionUnificationGuardV21314.toJson(JSONObject())
        assertEquals("FINAL_VERSION_UNIFICATION_READY", guard.getString("state"))
        assertEquals("2.13.15-final-hypothesis-first-discovery-unified", RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME)
        assertEquals("v2.13.15-final-hypothesis-first-discovery-unified", EngineRuntimeStatus.ACTIVE_ENGINE_VERSION)
        assertEquals(192, RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE)
        assertEquals(192, ReleaseVersionLinkageGuard.VERSION_CODE)
        assertEquals("2.13.15", RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION)
        assertTrue(guard.getBoolean("runtimeAligned"))
        assertTrue(guard.getBoolean("finalSurfaceAligned"))
        assertTrue(guard.getBoolean("legacyVersionRequestsClosed"))
    }

    @Test
    fun versionGuardDoesNotCreateEvidenceClaim() {
        val guard = GTIMFinalVersionUnificationGuardV21314.toJson(JSONObject())
        assertEquals("final_version_unification_only_no_evidence_or_clinical_claim", guard.getString("claimLimit"))
        assertTrue(GTIMFinalVersionUnificationGuardV21314.publicLines(guard).joinToString("\n").contains("no mechanism"))
    }
}
