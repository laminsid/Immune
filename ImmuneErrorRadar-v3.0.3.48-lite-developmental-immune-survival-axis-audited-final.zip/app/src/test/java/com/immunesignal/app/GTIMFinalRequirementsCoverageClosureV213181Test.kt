package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalRequirementsCoverageClosureV213181Test {
    @Test
    fun coverageClosureListsPriorityDiseaseAndConceptCapsules() {
        val report = JSONObject().put("topic", "longevity trained immunity FOXP3 antibody design")
        val obj = GTIMFinalRequirementsCoverageClosureV213181.toJson(report)
        val diseases = obj.getJSONArray("priority_disease_capsules").toString()
        val concepts = obj.getJSONArray("concept_capsules").toString()
        assertTrue(diseases.contains("longevity_immune_age_core"))
        assertTrue(diseases.contains("hantavirus_endothelial_core"))
        assertTrue(diseases.contains("hiv_immune_activation_core"))
        assertTrue(concepts.contains("trained_innate_immunity_core"))
        assertTrue(concepts.contains("foxp3_treg_master_program"))
        assertTrue(concepts.contains("protein_language_model_design"))
        assertTrue(obj.getBoolean("c2_c3_sandbox_preview_allowed"))
        assertFalse(obj.getBoolean("validated_proof_allowed"))
        assertFalse(obj.getBoolean("treatment_dosing_clinical_action_allowed"))
    }

    @Test
    fun finalSurfaceEmitsFinalCoverageContractWithoutLegacyOwnership() {
        val report = JSONObject().put("topic", "cancer digital immunomics antibody design")
        val text = GTIMFinalActiveDecisionSurfaceV21317.renderLines(report).joinToString("\n")
        assertTrue(text.contains("Final requirements coverage closure"))
        assertTrue(text.contains("Primary hypothesis"))
        assertTrue(text.contains("Immune decision state"))
        assertTrue(text.contains("Capsule state"))
        assertTrue(text.contains("Concept/paradigm candidate"))
        assertTrue(text.contains("Best execution route"))
        assertTrue(text.contains("Falsifier"))
        assertTrue(text.contains("Claim boundary"))
        assertTrue(text.contains("legacy_surface_owner_allowed=false"))
        assertFalse(text.contains("validated proof allowed=true"))
        assertFalse(text.contains("dosing recommendation"))
    }

    @Test
    fun missingCapsuleStillCreatesAcquisitionTaskAndAllowsPreview() {
        val report = JSONObject().put("topic", "rare new immune syndrome unknown capsule")
        val obj = GTIMFinalRequirementsCoverageClosureV213181.toJson(report)
        assertTrue(obj.getBoolean("hypothesis_output_allowed"))
        assertTrue(obj.getBoolean("c2_c3_sandbox_preview_allowed"))
        assertTrue(obj.getString("capsule_outcome").contains("CAPSULE_MISSING") || obj.getString("capsule_outcome").contains("LOCAL_PROCESSED_CAPSULE_AVAILABLE"))
        assertFalse(obj.getBoolean("validated_proof_allowed"))
    }
}
