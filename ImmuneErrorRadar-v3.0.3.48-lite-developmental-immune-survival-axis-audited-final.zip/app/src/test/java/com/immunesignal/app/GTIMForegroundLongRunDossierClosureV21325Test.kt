package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMForegroundLongRunDossierClosureV21325Test {
    @Test
    fun sixMinuteInterimAndTenMinuteHardCeilingAreReportVisible() {
        val budget = GTIMMobileSearchRuntimeBudgetV21322.fromDeepeningLimits(
            GTIMDeepeningRunLimitsV2123(
                maxSearchMillis = 1_200_000L,
                maxLearningMillis = 2_700_000L,
                maxQueries = 99,
                maxResultsPerQuery = 99,
                fetchAbstracts = true,
                enableSelectiveAbstracts = true,
                maxAbstractsPerCycle = 99
            )
        )
        assertEquals(360_000L, budget.firstVisibleReportMillis)
        assertEquals(600_000L, budget.hardTimeoutMillis)
        assertEquals(420_000L, budget.searchMillis)
        assertEquals(90_000L, budget.learningMillis)

        val report = JSONObject()
            .put("mobileRuntimeBudgetV21322", GTIMMobileSearchRuntimeBudgetV21322.toJson(
                budget = budget,
                elapsedMillis = budget.firstVisibleReportMillis,
                status = "INTERIM_SIX_MINUTE_REPORT_STILL_RUNNING",
                lastSafeStage = "EXTERNAL_SEARCH"
            ))
            .put("agenticProgressPlanV21324", GTIMAgenticProgressPlanV21324.toJson(
                budget = budget,
                elapsedMillis = budget.firstVisibleReportMillis,
                lastSafeStage = "EXTERNAL_SEARCH"
            ))
        val closure = GTIMForegroundLongRunDossierClosureV21325.toJson(report, stillRunning = true)
        report.put("foregroundLongRunDossierClosureV21325", closure)
        val lines = GTIMForegroundLongRunDossierClosureV21325.renderLines(report).joinToString("\n")
        assertEquals("INTERIM_VISIBLE_SEARCH_CONTINUES", closure.optString("state"))
        assertTrue(lines.contains("First visible report: 360s"))
        assertTrue(lines.contains("hard ceiling: 600s"))
        assertTrue(lines.contains("no_evidence_upgrade"))
    }
}
