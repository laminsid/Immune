package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalDiscoveryExecutionClosureV2136Test {
    @Test
    fun futureCorpusUsesActiveDomainExactMatchNotReportTextAliases() {
        val report = JSONObject()
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "filovirus_viral_host_response"))
            .put("topicCapture", JSONObject().put("rawInput", "Ebola filovirus host response with stray depression kynurenine IDO1 KMO text from legacy appendix"))
        val future = GTIMFutureEvidenceLiteCorpusV2130.toJson(report)
        assertEquals("filovirus_viral_host_response", future.getString("domainKey"))
        assertEquals("filovirus_viral_host_response", future.getString("selectedDomain"))
        assertTrue(future.getBoolean("futureCorpusCompatible"))
        assertFalse(future.getJSONArray("primaryTargets").toString().contains("IDO1"))
    }

    @Test
    fun mismatchFutureCorpusRendersBackgroundOnly() {
        val obj = JSONObject()
            .put("domainKey", "allergy_type2_barrier")
            .put("selectedDomain", "depression_kynurenine_neuroimmune")
            .put("futureCorpusCompatible", false)
        val lines = GTIMFutureEvidenceLiteCorpusV2130.publicLines(obj).joinToString("\n")
        assertTrue(lines.contains("BACKGROUND_ONLY_DOMAIN_MISMATCH"))
        assertTrue(lines.contains("suppressed"))
        assertFalse(lines.contains("IDO1"))
    }

    @Test
    fun finalDiscoveryClosureUsesCanonicalTargetAndDetectsCleanCandidateSurface() {
        val report = JSONObject()
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "allergy_type2_barrier"))
            .put("verifiedMetadataClosurePackV2132", JSONObject()
                .put("state", "VERIFIED_METADATA_CLOSURE_READY")
                .put("selectedClosedTarget", "GSE146170"))
            .put("finalDataClosureExecutionV2132", JSONObject()
                .put("readinessScore", 10)
                .put("selectedClosedTarget", "GSE146170"))
        report.put("activeDomainConsistencyGuardV2134", GTIMActiveDomainConsistencyGuardV2134.toJson(report))
        report.put("canonicalFinalSurfaceGuardV2135", GTIMCanonicalFinalSurfaceGuardV2135.toJson(report))
        report.put("futureEvidenceLiteCorpusV2130", GTIMFutureEvidenceLiteCorpusV2130.toJson(report))
        report.put("futureHypothesisComposerV2130", GTIMFutureHypothesisComposerV2130.toJson(report))
        report.put("processedCapsuleStoreV2135", GTIMProcessedCapsuleStoreV2135.toJson(report))
        report.put("immuneModuleSignalEngineV2135", GTIMImmuneModuleSignalEngineV2135.toJson(report))
        report.put("discoveryExecutionEnginesV2135", GTIMDiscoveryExecutionEnginesV2135.toJson(report))
        report.put("discoveryClaimLadderV2135", GTIMDiscoveryClaimLadderV2135.toJson(report))
        report.put("discoveryCandidateAssemblerV2135", GTIMDiscoveryCandidateAssemblerV2135.toJson(report))
        report.put("matrixShortcutResolverV2124", GTIMMatrixShortcutResolverV2124.toJson(report))
        val closure = GTIMFinalDiscoveryExecutionClosureV2136.toJson(report)
        assertEquals("GSE146170", closure.getString("canonicalTarget"))
        assertEquals(0, closure.getJSONArray("staleSurfaceFindings").length())
        assertTrue(closure.getBoolean("discoveryCandidateReady"))
    }
}
