package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3IntentDomainQueryConstructionTest {
    private class CountingAdapter : EvidenceAdapterV3 {
        var calls: Int = 0
        override fun search(query: String, role: EvidenceRoleV3, state: ResearchStateV3): EvidenceSearchBatchV3 {
            calls += 1
            return EvidenceSearchBatchV3(query = query, records = emptyList(), networkCalls = 1)
        }
    }

    @Test
    fun genericInformationIsRejectedBeforeNetwork() {
        val adapter = CountingAdapter()
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = adapter)
        ).run(ResearchInputV3("Information"))

        assertEquals(0, adapter.calls)
        assertTrue(result is ResearchResultV3.CheckpointReady)
        assertTrue(result.report.openGates.any { it.startsWith("topic_rejected_by_intent_gate") })
        assertTrue(result.report.sessionSnapshot?.toJson()?.optJSONObject("intentGate")?.optBoolean("allowed") == false)
    }

    @Test
    fun preciseAllergyQueryUsesDomainTemplateInsteadOfImpossibleSuffixChain() {
        val queries = DomainQueryTemplateV3.sourceQueries("allergy type inflammation IgE eosinophil mast cell")
        val joined = queries.joinToString(" ").lowercase()

        assertTrue(joined.contains("ige"))
        assertTrue(joined.contains("eosinophil"))
        assertTrue(joined.contains("mast cell"))
        assertFalse(joined.contains("ige ige"))
        assertFalse(joined.contains("immunopathogenesis cytokine interferon cohort"))
    }

    @Test
    fun preciseCovidQueryDoesNotProduceMalformedSarsTail() {
        val stem = ResearchTopicNormalizerV3.normalize("COVID-19 SARS-CoV-2 immune dysregulation")
        val queries = DomainQueryTemplateV3.sourceQueries("COVID-19 SARS-CoV-2 immune dysregulation")
        val joined = (listOf(stem) + queries).joinToString(" ").lowercase()

        assertFalse(joined.contains("sars- "))
        assertFalse(joined.endsWith("sars-"))
        assertFalse(joined.contains("covid-19 sars-"))
        assertTrue(joined.contains("sars-cov-2"))
    }

    @Test
    fun depressionAloneCannotReportReadyWithoutMechanismAxis() {
        val adapter = StaticEvidenceAdapterV3(
            mapOf(
                "depression" to listOf(
                    EvidenceSearchRecordV3("41714591", "Gray and white matter microstructural alterations in major depressive disorder", SourceKindV3.PUBMED, abstractText = "Major depressive disorder cohort in patients."),
                    EvidenceSearchRecordV3("GSE242736", "Depression proteomics dataset", SourceKindV3.GEO, abstractText = "Depression dataset with samples and controls.")
                )
            )
        )
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = adapter)
        ).run(ResearchInputV3("Depression", budget = ResearchBudgetV3(maxNetworkCalls = 12, maxEmptyQueries = 8)))

        assertTrue(result is ResearchResultV3.CheckpointReady)
        assertTrue(result.report.openGates.contains("generic_topic_requires_mechanism_axis"))
    }

    @Test
    fun comparativeTopicCreatesBridgeQueriesInsteadOfOneRawString() {
        val queries = DomainQueryTemplateV3.sourceQueries("Covid vs depression immune comparison")
        val joined = queries.joinToString(" ").lowercase()

        assertTrue(joined.contains("covid"))
        assertTrue(joined.contains("depression"))
        assertTrue(joined.contains("immune comparison"))
        assertFalse(joined.contains("covid vs depression immune comparison immune dysregulation"))
    }
}
