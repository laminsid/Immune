package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalIntegratedDiscoveryClosureV213171Test {
    @Test
    fun integratedClosureConnectsCapsuleConceptAndSandboxPolicy() {
        val report = JSONObject().put("topic", "cancer tumor microenvironment antibody design")
        val closure = GTIMFinalIntegratedDiscoveryClosureV213171.toJson(report)
        val text = GTIMFinalIntegratedDiscoveryClosureV213171.renderLines(report).joinToString("\n")

        assertTrue(closure.getString("state").contains("FINAL_INTEGRATED"))
        assertTrue(closure.getString("sandbox_preview_policy").contains("C0_C1_C2_C3_ALLOWED"))
        assertTrue(text.contains("Final integrated immune-decision closure"))
        assertTrue(text.contains("Digital immunomics lens"))
        assertFalse(text.contains("dosing protocol"))
    }

    @Test
    fun activeSurfaceIncludesIntegratedClosureWithoutLegacyTree() {
        val report = JSONObject().put("topic", "hantavirus endothelial leak host response")
        val text = GTIMFinalActiveDecisionSurfaceV21317.renderLines(report).joinToString("\n")

        assertTrue(text.contains("Final integrated immune-decision closure"))
        assertTrue(text.contains("C0_C1_C2_C3_ALLOWED"))
        assertTrue(text.contains("Legacy policy"))
        assertFalse(text.contains("Final Bundibugyo/BDBV search-runtime closure"))
    }
}
