package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30329ProfessionalDiscoveryEngineTest {
    @Test
    fun comparatorExtractionUsesDynamicDatasetInsteadOfPlantedGseState() {
        val state = stateWithDataset("GSE146170", "Allergic airway transcriptomics patient vs healthy control blood/PBMC metadata")
        val metadata = ResearchMetadataProbeIngestionV3.evaluate(state)
        assertTrue(metadata.active)
        assertFalse(metadata.state.contains("GSE152522"))
        val comparator = ComparatorVariableExtractorV30329.evaluate(state, metadata)
        assertTrue(comparator.active)
        assertEquals("GSE146170", comparator.bestAccession)
        assertTrue(comparator.readiness >= 60)
    }

    @Test
    fun matrixCalculatorComputesEffectDirectionConfidenceIntervalAndPValue() {
        val rows = listOf(
            ExpressionSampleRowV30329("case1", "case", mapOf("CD8A" to 10.0, "GZMB" to 9.0)),
            ExpressionSampleRowV30329("case2", "case", mapOf("CD8A" to 11.0, "GZMB" to 10.0)),
            ExpressionSampleRowV30329("case3", "case", mapOf("CD8A" to 12.0, "GZMB" to 11.0)),
            ExpressionSampleRowV30329("ctrl1", "control", mapOf("CD8A" to 2.0, "GZMB" to 1.0)),
            ExpressionSampleRowV30329("ctrl2", "control", mapOf("CD8A" to 3.0, "GZMB" to 2.0)),
            ExpressionSampleRowV30329("ctrl3", "control", mapOf("CD8A" to 4.0, "GZMB" to 3.0))
        )
        val computed = ProcessedExpressionMatrixCalculatorV30329.calculate(rows, "case", "control", listOf("CD8A", "GZMB"))
        assertEquals(2, computed.size)
        assertTrue(computed.all { it.effectSize > 0.0 })
        assertTrue(computed.all { it.ciLow < it.ciHigh })
        assertTrue(computed.all { it.pValue < 0.10 })
    }

    @Test
    fun professionalDiscoveryCardCapsScoreWithoutMechanismSupport() {
        val state = stateWithDataset("GSE146170", "Allergic airway transcriptomics patient vs healthy control")
        val metadata = ResearchMetadataProbeIngestionV3.evaluate(state)
        val comparator = ComparatorVariableExtractorV30329.evaluate(state, metadata)
        val datasetScore = ResearchDatasetModuleScoreV3.evaluate(state, metadata)
        val mechanism = MechanismModuleSignalRunnerV30328.evaluate(state, metadata, datasetScore)
        val expression = ProcessedExpressionSignalExecutorV30329.evaluate(state, metadata, datasetScore, comparator, mechanism)
        val cross = CrossDatasetSignalLinkerV30329.evaluate(state, expression)
        val novelty = DiscoveryGapNoveltyV30329.evaluate(state, comparator, expression, cross)
        val falsifier = ExecutedFalsifierV30329.evaluate(state, ContradictionTruthStateBuilderV30328.evaluate(state), comparator, expression)
        val closure = ResearchClosureSnapshotV3(
            canCloseReport = false,
            openGates = listOf("mechanism_signal_pending"),
            visibleTierABCount = 1,
            visibleTierCDCount = 0,
            contradictionObjectiveExecuted = false,
            contradictionEvidenceFound = false,
            distinctAccessions = listOf("GSE146170")
        )
        val report = ProfessionalDiscoveryCardBuilderV30329.evaluate(state, closure, comparator, expression, novelty, falsifier, cross)
        assertTrue(report.active)
        assertTrue(report.cards.first().scoreCap <= 8)
        if (!expression.hasMechanismSupport) {
            assertTrue(report.cards.first().scoreCap <= 7)
        }
    }

    @Test
    fun compiledReportExposesDiscoveryEngineJsonSections() {
        val state = stateWithDataset("GSE146170", "Allergic airway transcriptomics patient vs healthy control")
        val closure = ResearchClosureSnapshotV3(
            canCloseReport = false,
            openGates = listOf("mechanism_signal_pending"),
            visibleTierABCount = 1,
            visibleTierCDCount = 0,
            contradictionObjectiveExecuted = false,
            contradictionEvidenceFound = false,
            distinctAccessions = listOf("GSE146170")
        )
        val report = ResearchReportCompilerV3().compile(state, closure).toJson()
        assertTrue(report.has("comparatorVariableExtraction"))
        assertTrue(report.has("processedExpressionSignal"))
        assertTrue(report.has("discoveryGapNovelty"))
        assertTrue(report.has("executedFalsifier"))
        assertTrue(report.has("professionalDiscoveryReport"))
        assertTrue(report.has("releaseReadinessContractV30329"))
    }

    private fun stateWithDataset(accession: String, title: String): ResearchStateV3 {
        val node = EvidenceNodeV3(
            id = "dataset-$accession",
            type = EvidenceTypeV3.DATASET,
            accession = accession,
            title = title,
            source = SourceKindV3.GEO,
            articleType = ArticleTypeV3.DATASET,
            role = EvidenceRoleV3.DATASET,
            qualityTier = QualityTierV3.A,
            supports = listOf("phenotype matched dataset"),
            query = "$accession SOFT metadata patient healthy control"
        )
        return ResearchStateV3.initial(
            ResearchInputV3("allergy airway immune mechanism patient vs healthy control"),
            EvidenceLedgerSnapshotV3(nodes = listOf(node), objectiveOutcomes = emptyList())
        )
    }
}
