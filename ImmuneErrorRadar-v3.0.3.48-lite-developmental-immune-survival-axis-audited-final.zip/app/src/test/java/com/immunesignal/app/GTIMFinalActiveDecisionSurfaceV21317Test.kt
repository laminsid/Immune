package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalActiveDecisionSurfaceV21317Test {
    @Test
    fun activeSurfaceEmitsHypothesisWithoutCanonicalTarget() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Bundibugyo Ebola BDBV host response research dossier"))
            .put("finalBundibugyoSearchRuntimeClosureV213106", JSONObject()
                .put("activeDomain", "filovirus_viral_host_response")
                .put("activeSubtype", "viral_filovirus_bundibugyo")
                .put("canonicalTarget", ""))

        val lines = GTIMFinalActiveDecisionSurfaceV21317.renderLines(report).joinToString("\n")
        assertTrue(lines.contains("Primary hypothesis:"))
        assertTrue(lines.contains("C0_ROUTE_HYPOTHESIS"))
        assertTrue(lines.contains("canonical_target=none"))
        assertFalse(lines.contains("Final Bundibugyo/BDBV search-runtime closure"))
    }

    @Test
    fun activeSurfaceDoesNotUseLegacyRenderTreeForAllergy() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "allergy type-2 IgE mast eosinophil barrier study"))
            .put("finalUnifiedDiscoveryReadinessClosureV21310", JSONObject()
                .put("activeDomain", "allergy_type2_barrier")
                .put("activeSubtype", "viral_generic")
                .put("canonicalTarget", "GSE146170"))

        val text = GTIMFinalActiveDecisionSurfaceV21317.renderText(report)
        assertTrue(text.contains("allergy_type2_or_barrier_microbiome"))
        assertTrue(text.contains("GSE146170"))
        assertTrue(text.contains("Gate split:"))
        assertFalse(text.contains("Final Bundibugyo/BDBV search-runtime closure"))
    }

    @Test
    fun globalBriefDelegatesToActiveSurfaceForFinalRuns() {
        val report = JSONObject()
            .put("hypothesisFirstDiscoveryEngineV21315", JSONObject()
                .put("activeDomain", "allergy_type2_barrier")
                .put("activeSubtype", "allergy_type2_or_barrier_microbiome")
                .put("canonicalTarget", "GSE146170")
                .put("primaryResult", "C1_DISCOVERY_CANDIDATE")
                .put("primaryHypothesis", "type-2 threshold instability may separate allergic severity")
                .put("hypothesisAllowed", true))

        val text = GlobalResearchGradeBriefV11061.renderPublicResearchBrief(report)
        assertTrue(text.contains("Final active decision surface"))
        assertTrue(text.contains("Primary hypothesis:"))
    }
}
