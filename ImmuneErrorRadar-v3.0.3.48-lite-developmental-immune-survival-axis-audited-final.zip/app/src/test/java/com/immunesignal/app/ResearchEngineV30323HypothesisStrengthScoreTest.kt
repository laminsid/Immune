package com.immunesignal.app

import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30323HypothesisStrengthScoreTest {
    @Test
    fun generatedHypothesesReceiveBoundedThreeToTenScores() {
        val ledger = EvidenceLedgerV3()
        ledger.addNode(
            EvidenceNodeV3(
                id = "pmid-covid-ifn",
                type = EvidenceTypeV3.SOURCE,
                accession = "PMID:33867315",
                title = "COVID immune response interferon IL-6 TNF review",
                source = SourceKindV3.PUBMED,
                articleType = ArticleTypeV3.REVIEW,
                role = EvidenceRoleV3.SOURCE,
                qualityTier = QualityTierV3.B
            )
        )
        ledger.addNode(
            EvidenceNodeV3(
                id = "gse152522",
                type = EvidenceTypeV3.DATASET,
                accession = "GSE152522",
                title = "SARS-CoV-2 PBMC transcriptome severe mild healthy control cohort",
                source = SourceKindV3.GEO,
                articleType = ArticleTypeV3.TRANSCRIPTOMICS,
                role = EvidenceRoleV3.DATASET,
                qualityTier = QualityTierV3.A
            )
        )
        ledger.addNode(
            EvidenceNodeV3(
                id = "gse166253",
                type = EvidenceTypeV3.DATASET,
                accession = "GSE166253",
                title = "COVID immune transcriptome retest-positive cohort",
                source = SourceKindV3.GEO,
                articleType = ArticleTypeV3.DATASET,
                role = EvidenceRoleV3.DATASET,
                qualityTier = QualityTierV3.A
            )
        )
        val state = ResearchStateV3.initial(
            ResearchInputV3("sars-cov-2 covid-19 immune dysregulation interferon pbmc healthy control severity comparator transcriptome"),
            ledger.snapshot()
        )
        val closure = ResearchClosureSnapshotV3(
            canCloseReport = true,
            openGates = emptyList(),
            visibleTierABCount = 3,
            visibleTierCDCount = 0,
            contradictionObjectiveExecuted = true,
            contradictionEvidenceFound = false,
            distinctAccessions = listOf("PMID:33867315", "GSE152522", "GSE166253"),
            criticalRoleIndependencePassed = true,
            contradictionObjectiveExhausted = true
        )
        val readiness = ResearchReadinessAssessmentV3.evaluate(state, closure)
        val generated = ResearchHypothesisGeneratorV3.generate(state, closure)
        val scores = ResearchHypothesisStrengthGraderV3.gradeAll(generated, state, closure, readiness, emptyList())
        assertTrue(scores.isNotEmpty())
        assertTrue(scores.all { it.score in 3..10 })
        assertTrue(scores.any { it.score >= 8 })
    }

    @Test
    fun weakHypothesesAreKeptButMarkedLowInsteadOfDeleted() {
        val state = ResearchStateV3.initial(ResearchInputV3("allergy IgE eosinophil mast cell"))
        val closure = ResearchClosureSnapshotV3(
            canCloseReport = false,
            openGates = listOf("visible_source_evidence", "visible_dataset_or_provenance_evidence"),
            visibleTierABCount = 0,
            visibleTierCDCount = 0,
            contradictionObjectiveExecuted = false,
            contradictionEvidenceFound = false,
            distinctAccessions = emptyList(),
            criticalRoleIndependencePassed = true,
            contradictionObjectiveExhausted = false
        )
        val readiness = ResearchReadinessAssessmentV3.evaluate(state, closure)
        val hypotheses = listOf("H1: Allergy route may involve IgE eosinophil mast cell activation; test with phenotype-matched asthma or atopy cohorts.")
        val scores = ResearchHypothesisStrengthGraderV3.gradeAll(hypotheses, state, closure, readiness, emptyList())
        assertTrue(scores.size == 1)
        assertTrue(scores.first().score in 3..6)
        assertTrue(scores.first().upgradeRequired.contains("dataset", ignoreCase = true))
    }
}
