package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMLocalProcessedCapsuleInjectionV21316Test {
    @Test
    fun allergyCanonicalTargetUsesLocalProcessedCapsuleWithoutProofPromotion() {
        val report = JSONObject()
            .put("topic", "allergy type-2 barrier")
            .put("finalSurfaceDomainCoherenceGuardV21313", JSONObject()
                .put("activeDomain", "allergy_type2_barrier")
                .put("canonicalTarget", "GSE146170"))
            .put("matrixShortcutResolverV2124", JSONObject().put("state", "MATRIX_MISSING"))

        val hypothesis = GTIMHypothesisFirstDiscoveryEngineV21315.toJson(report)
        val capsule = hypothesis.getJSONObject("localProcessedCapsuleLayerV21316")

        assertEquals("LOCAL_PROCESSED_CAPSULE_AVAILABLE", hypothesis.getString("matrixState"))
        assertEquals("GSE146170", capsule.getJSONObject("capsule").getString("accession"))
        assertTrue(hypothesis.getBoolean("c2PreviewAllowed"))
        assertTrue(hypothesis.getBoolean("c3PreviewAllowed"))
        assertFalse(hypothesis.getBoolean("validatedProofAllowed"))
        assertTrue(hypothesis.toString().contains("not_validated_proof"))
    }

    @Test
    fun priorityDiseaseDomainsHaveLightweightCapsules() {
        val families = GTIMLocalProcessedCapsuleStoreV21316.getPriorityCapsules().map { it.diseaseFamily }.toSet()
        assertTrue(families.contains("hard_chronic_inflammation"))
        assertTrue(families.contains("rheumatism_rheumatoid"))
        assertTrue(families.contains("allergy"))
        assertTrue(families.contains("cancer"))
        assertTrue(families.contains("ebola_filovirus"))
        assertTrue(families.contains("hiv_aids"))
        assertTrue(families.contains("covid_postviral"))
        assertTrue(families.contains("diabetes"))
        assertTrue(families.contains("hantavirus"))
    }

    @Test
    fun hantaWithoutCanonicalStillGetsDomainCapsulePreview() {
        val report = JSONObject().put("topic", "hantavirus endothelial inflammation")
        val surface = GTIMFinalActiveDecisionSurfaceV21317.renderLines(report).joinToString("\n")

        assertTrue(surface.contains("Local processed capsule card"))
        assertTrue(surface.contains("viral_hantavirus_host_response"))
        assertTrue(surface.contains("C1_DOMAIN_CAPSULE_SANDBOX_PREVIEW"))
        assertTrue(surface.contains("C2/C3 sandbox preview: ALLOWED"))
        assertFalse(surface.contains("validated discovery claim"))
    }

    @Test
    fun filovirusCapsuleDoesNotBecomeCovidDomain() {
        val capsule = GTIMLocalProcessedCapsuleStoreV21316.getCapsuleByAccession("GSE45291")
        assertEquals("filovirus_viral_host_response", capsule?.domain)
        assertFalse(GTIMGeneralizedRouteCoherenceGuardV21314.targetCompatibleWithActiveDomain("viral_interferon_cytokine", "GSE45291"))
    }

    @Test
    fun priorityDiseaseTopicsResolveToLocalCapsuleDomains() {
        val topics = mapOf(
            "hard chronic inflammation" to "inflammation_resolution",
            "rheumatism rheumatoid arthritis" to "rheumatoid_autoimmune_synovial_inflammation",
            "allergy type-2 barrier" to "allergy_type2_barrier",
            "cancer tumor microenvironment" to "oncology_tumor_microenvironment",
            "Ebola filovirus" to "filovirus_viral_host_response",
            "HIV AIDS immune activation" to "hiv_aids_immune_activation",
            "corona covid interferon" to "viral_interferon_cytokine",
            "diabetes metabolic inflammation" to "metabolic_inflammation",
            "hantavirus endothelial leak" to "viral_hantavirus_host_response"
        )
        topics.forEach { (topic, expectedDomain) ->
            val report = JSONObject().put("topic", topic)
            assertEquals(expectedDomain, GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report))
            val route = GTIMCapsuleInjectionRouterV21316.route(report)
            assertTrue(route.sandboxPreviewAllowed)
            assertTrue(route.executableCapsule != null)
        }
    }

}
