package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMCuratedSeedRoutingV21211Test {

    @Test
    fun viralGlobalAbstractDoesNotFallBackToAllergyType2Frame() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("normalizedTopic", "Ebola virus filovirus interferon cytokine storm")
                .put("rawInput", "Ebola virus immune response"))
            .put("matrixShortcutResolverV2124", JSONObject().put("state", "MATRIX_SHORTCUT_CANDIDATE_READY"))
        val noisyTechnical = listOf(
            "legacy template: allergy/type-2 microbiome-barrier study",
            "Research topic: Ebola virus immune response",
            "Strongest exploratory route: Ebola virus / filovirus exposure -> interferon timing/cytokine storm/endothelial injury"
        )

        val abstract = GTIMFinalGlobalStudyDossierGuardV2127.toJson(report, noisyTechnical)
            .optString("abstractLine")

        assertTrue(abstract.contains("viral interferon-cytokine host-response study"))
        assertFalse(abstract.contains("allergy/type-2 microbiome-barrier study"))
    }

    @Test
    fun depressionKynureninePrioritizesIdoKmoBeforeMicrobiomeFallback() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("normalizedTopic", "depression kynurenine pathway IDO1 KMO neuroimmune")
                .put("rawInput", "اكتئاب ومسار كينورينين"))
        val selector = GTIMDomainSpecificHypothesisSelectorV2129.toJson(report)
        val joined = selector.toString()

        assertTrue(joined.contains("kynurenine_enzyme_neuroimmune_route"))
        assertTrue(joined.contains("IDO1"))
        assertTrue(joined.contains("KMO"))
        assertFalse(selector.optString("biologicalToolClass").contains("microbiome_function_route"))
    }
}
