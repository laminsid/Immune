package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMInjectedMetadataExecutionV21216Test {
    @Test
    fun injectedPackCoversRepeatedBlockingHandlesWithoutEvidenceUpgrade() {
        val gse250 = GTIMInjectedMetadataSeedPackV21216.probeResultFor("GSE250594")!!
        val gse49454 = GTIMInjectedMetadataSeedPackV21216.probeResultFor("GSE49454")!!
        val gse152202 = GTIMInjectedMetadataSeedPackV21216.probeResultFor("GSE152202")!!
        assertTrue(gse250.optBoolean("executed"))
        assertTrue(gse49454.optBoolean("offlineInjected"))
        assertEquals("OFFLINE_INJECTED_METADATA_READY_REVIEW_ONLY", gse152202.optString("probeState"))
        assertTrue(gse49454.optString("softUrl").contains("GSE49454_family.soft.gz"))
        assertTrue(gse250.optString("claimLimit").contains("no_evidence_upgrade"))
        assertFalse(gse250.optString("sampleProvenanceStatus").contains("found", ignoreCase = true))
    }

    @Test
    fun finalClosureShowsManualSoftProbeNoLongerDefault() {
        val report = JSONObject()
            .put("injectedMetadataSeedPackV21216", JSONObject().put("matchedCount", 1))
            .put("metadataProbeBackgroundWorkersV21215", JSONObject()
                .put("executedSteps", org.json.JSONArray(listOf("GSE250594:soft_metadata_probe")))
                .put("probeResults", org.json.JSONArray(listOf(JSONObject().put("offlineInjected", true)))))
        val closure = GTIMInjectedMetadataFinalClosureV21216.toJson(report)
        assertEquals("FINAL_INJECTED_METADATA_EXECUTION_READY", closure.optString("state"))
        assertTrue(closure.optBoolean("manualSoftProbeNoLongerDefault"))
        assertTrue(closure.optString("routeLinkage").contains("curated_seed_injected_metadata_background_worker"))
    }
}
