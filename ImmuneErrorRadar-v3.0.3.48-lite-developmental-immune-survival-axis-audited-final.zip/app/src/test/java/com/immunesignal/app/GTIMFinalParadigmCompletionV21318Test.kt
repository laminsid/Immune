package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalParadigmCompletionV21318Test {
    @Test
    fun longevityTopicGetsLocalCapsuleAndImmuneAgeConcept() {
        val report = JSONObject().put("topic", "longevity immune age inflammaging research")
        val active = GTIMGeneralizedRouteCoherenceGuardV21314.effectiveActiveDomain(report)
        assertTrue(active == "immune_age_longevity")
        val capsule = GTIMCapsuleInjectionRouterV21316.route(report)
        assertTrue(capsule.sandboxPreviewAllowed)
        assertTrue(capsule.executableCapsule?.capsuleId == "longevity_immune_age_core")
        val paradigm = GTIMParadigmCandidateEngineV21317.toJson(report)
        assertTrue(paradigm.getString("concept_id").contains("immune_age") || paradigm.getJSONArray("connected_disease_domains").toString().contains("immune_age_longevity"))
    }

    @Test
    fun assumptionBreakerAndCrossDiseaseMapperDoNotCreateProofClaims() {
        val report = JSONObject().put("topic", "rheumatoid FOXP3 Treg tolerance research")
        val assumption = GTIMAssumptionBreakerEngineV21318.toJson(report)
        val cross = GTIMCrossDiseaseMechanismMapperV21318.toJson(report)
        assertTrue(assumption.getString("old_assumption_challenged").contains("immunosuppression") || assumption.getString("old_assumption_challenged").contains("autoimmunity"))
        assertTrue(cross.getJSONArray("connected_disease_domains").length() >= 2)
        assertFalse(assumption.toString().contains("validated_proof_allowed=true"))
        assertTrue(assumption.getString("claim_limit").contains("not_validated"))
        assertTrue(cross.getString("claim_limit").contains("not_causal_proof"))
    }

    @Test
    fun proteinBindingAndModalityLensStayPreviewOnly() {
        val report = JSONObject().put("topic", "Ebola antibody design escape mutation research")
        val binding = GTIMProteinInteractionBindingHypothesisV21318.toJson(report)
        val modality = GTIMTherapeuticModalityLensV21318.toJson(report)
        assertTrue(binding.has("target_antigen"))
        assertTrue(binding.has("epitope"))
        assertTrue(binding.has("escape_mutation_risk"))
        assertFalse(binding.getBoolean("validated_binding_or_efficacy_claim_allowed"))
        assertFalse(modality.getBoolean("validated_treatment_claim_allowed"))
        assertFalse(modality.getBoolean("dosing_or_patient_action_allowed"))
    }

    @Test
    fun finalSurfaceIncludesAssumptionCrossDiseaseModalityAndBindingClosures() {
        val report = JSONObject().put("topic", "cancer digital antibody design protein language model")
        val text = GTIMFinalActiveDecisionSurfaceV21317.renderLines(report).joinToString("\n")
        assertTrue(text.contains("Paradigm candidate card"))
        assertTrue(text.contains("Old assumption challenged"))
        assertTrue(text.contains("Cross-disease mechanism"))
        assertTrue(text.contains("Therapeutic/modality lens"))
        assertTrue(text.contains("Protein interaction/binding lens"))
        assertTrue(text.contains("validated_binding_or_efficacy_claim=BLOCKED"))
        assertFalse(text.contains("dosing recommendation"))
    }
}
