package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMVisibleProofContractV2160Test {
    private fun visibleClosedContract(): ResearchRunContractV2150 {
        return ResearchRunContractV2150.create("Ebola bundibugyo")
            .withEvidenceHandle("source_handle_closed_pubmed_111")
            .withEvidenceHandle("dataset_verified_gds_222")
            .withEvidenceHandle("metadata_probe_executed_pubmed_333")
            .withEvidenceHandle("sample_probe_executed_pubmed_334")
            .withEvidenceHandle("contradiction_checked_pubmed_444")
            .withEvidenceHandle("falsification_probe_executed_pubmed_445")
            .withEvidenceHandle("mechanism_linkage_probe_executed_pubmed_555")
    }

    @Test
    fun visibleProofContractRequiresDisplayedSourceProvenanceAndContradiction() {
        val contract = visibleClosedContract()
        val proof = ResearchProofContractV2160.fromContract(contract)
        assertTrue(proof.hasVisibleSource)
        assertTrue(proof.hasVisibleProvenance)
        assertTrue(proof.hasVisibleContradiction)
        assertTrue(proof.isClosed())
        assertTrue(ResearchExecutionPolicyV2154.hasClosedProofGate(contract))
    }

    @Test
    fun negativeMarkersDoNotBecomeVisibleEvidence() {
        val contract = ResearchRunContractV2150.create("unknown immune question")
            .withEvidenceHandle("metadata_probe_attempted_no_verified_dataset_yet_not_evidence")
            .withEvidenceHandle("contradiction_probe_attempted_no_pubmed_hit_yet_not_evidence")
            .withEvidenceHandle("candidate_source_handles_planned_not_evidence")
        val proof = ResearchProofContractV2160.fromContract(contract)
        assertEquals(0, proof.visibleEvidenceCount())
        assertFalse(proof.isClosed())
        assertFalse(ResearchExecutionPolicyV2154.hasClosedProofGate(contract))
    }

    @Test
    fun countedEvidenceMustEqualDisplayedEvidenceLines() {
        val proof = ResearchProofContractV2160.fromContract(visibleClosedContract())
        assertEquals(proof.visibleEvidenceCount(), proof.displayedEvidenceLineCount())
        assertTrue(proof.countedEqualsDisplayed())
    }

    @Test
    fun reportReadyRequiresVisibleProofContract() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
            .withEvidenceHandle("source_handle_closed_pubmed_111")
            .withEvidenceHandle("metadata_probe_executed_pubmed_333")
            // Missing contradiction handle: should remain open even when tasks are DONE.
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }
        assertFalse(ResearchExecutionPolicyV2154.reportCanClose(contract))
    }

    @Test
    fun userCardDisplaysEveryVisibleEvidenceItem() {
        var contract = visibleClosedContract().withStatus(ResearchRunStatusV2150.REPORT_READY)
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }
        val report = ResearchBriefBuilderV2150.buildReport(contract, "visible_contract_test")
        val card = ResearchBriefBuilderV2150.renderUserCard(report).orEmpty()
        val proof = ResearchProofContractV2160.fromContract(contract)
        proof.displayedEvidenceLines().forEach { line ->
            assertTrue("Missing displayed evidence line: $line", card.contains(line))
        }
    }
}

class GTIMResearchRuntimeV3SkeletonTest {
    @Test
    fun v3CheckpointWhenVisibleProofIsMissing() {
        val result = ResearchRuntimeV3.executeFromHandles(
            query = "unknown disease X",
            evidenceHandles = listOf("candidate_source_handles_planned_not_evidence"),
            elapsedMs = 70_000L
        )
        assertTrue(result is ResearchRuntimeV3.Result.CheckpointReady)
    }

    @Test
    fun v3ReportReadyOnlyWithVisibleEvidenceContract() {
        val result = ResearchRuntimeV3.executeFromHandles(
            query = "Ebola bundibugyo",
            evidenceHandles = listOf(
                "source_handle_closed_pubmed_111",
                "metadata_probe_executed_pubmed_222",
                "contradiction_checked_pubmed_333",
                "mechanism_linkage_probe_executed_pubmed_444"
            ),
            elapsedMs = 70_000L
        )
        assertTrue(result is ResearchRuntimeV3.Result.ReportReady)
        assertTrue(result.proof.visibleEvidenceCount() >= 3)
        assertEquals(result.proof.visibleEvidenceCount(), result.proof.displayedEvidenceLineCount())
    }
}
