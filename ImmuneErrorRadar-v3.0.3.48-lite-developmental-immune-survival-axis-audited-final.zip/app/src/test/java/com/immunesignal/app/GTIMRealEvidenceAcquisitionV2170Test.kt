package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMRealEvidenceAcquisitionV2170Test {
    @Test
    fun esearchParserExtractsPubmedIdsWithoutNetwork() {
        val json = """
            {"esearchresult":{"idlist":["123456","789012","345678"]}}
        """.trimIndent()
        val ids = ResearchEvidenceAcquisitionV2170.parseIdListFromESearchJson(json, 2)
        assertEquals(listOf("123456", "789012"), ids)
    }

    @Test
    fun pubmedSummaryParserCreatesReviewableMarkersWithTitles() {
        val json = """
            {
              "result": {
                "uids": ["123456"],
                "123456": {
                  "title": "Bundibugyo ebolavirus infection and host immune response",
                  "fulljournalname": "Journal of Viral Immunology",
                  "pubdate": "2024"
                }
              }
            }
        """.trimIndent()
        val record = ResearchEvidenceAcquisitionV2170.pubMedRecordsFromSummaryJson(json).first()
        assertEquals("123456", record.pmid)
        assertTrue(record.sourceMarker().startsWith("source_handle_closed_pubmed_123456__title_"))

        val proof = ResearchProofContractV2160.fromHandles(
            "Ebola bundibugyo",
            listOf(record.sourceMarker(), record.metadataMarker(), record.contradictionMarker())
        )
        assertTrue(proof.isClosed())
        assertTrue(ResearchVisibleEvidenceAuditV2161.evaluate(proof).reportReadyEligible)
        assertTrue(proof.displayedEvidenceLines().any { it.contains("Bundibugyo ebolavirus infection") })
    }

    @Test
    fun geoSummaryParserCreatesReviewableDatasetAndProvenanceMarkers() {
        val json = """
            {
              "result": {
                "uids": ["2001"],
                "2001": {
                  "accession": "GSE2001",
                  "title": "Immune transcriptome comparator dataset"
                }
              }
            }
        """.trimIndent()
        val record = ResearchEvidenceAcquisitionV2170.gdsRecordsFromSummaryJson(json).first()
        assertEquals("GSE2001", record.accession)
        val proof = ResearchProofContractV2160.fromHandles(
            "immune transcriptome",
            listOf(
                "source_handle_closed_pubmed_123456__title_pubmed_source",
                record.datasetMarker(),
                record.provenanceMarker(),
                "contradiction_checked_pubmed_789012__title_negative_control"
            )
        )
        assertTrue(proof.hasVisibleSource)
        assertTrue(proof.hasVisibleProvenance)
        assertTrue(ResearchVisibleEvidenceAuditV2161.evaluate(proof).reportReadyEligible)
    }

    @Test
    fun genericEvidenceStillCannotCloseV2170Report() {
        val proof = ResearchProofContractV2160.fromHandles(
            "Ebola bundibugyo",
            listOf(
                "source_handle_closed_pubmed_or_geo",
                "sample_id_linked_metadata_verified",
                "contradiction_checked_wrong_tissue_species"
            )
        )
        assertTrue(proof.isClosed())
        assertFalse(ResearchVisibleEvidenceAuditV2161.evaluate(proof).reportReadyEligible)
    }
}
