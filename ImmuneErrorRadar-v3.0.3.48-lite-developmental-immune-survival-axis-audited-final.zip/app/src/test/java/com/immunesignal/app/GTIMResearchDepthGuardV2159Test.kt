package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMResearchDepthGuardV2159Test {
    private fun closedContract(): ResearchRunContractV2150 {
        var contract = ResearchRunContractV2150.create("Ebola Bundibugyo immune dysregulation")
            .withEvidenceHandle("source_handle_closed_pubmed_111")
            .withEvidenceHandle("metadata_probe_executed_pubmed_222")
            .withEvidenceHandle("comparator_probe_executed_pubmed_223")
            .withEvidenceHandle("sample_probe_executed_pubmed_224")
            .withEvidenceHandle("contradiction_checked_pubmed_333")
            .withEvidenceHandle("mechanism_linkage_probe_executed_pubmed_444")
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }
        return contract.withStatus(ResearchRunStatusV2150.REPORT_READY)
    }

    @Test
    fun fastInteractiveClosureIsBlockedByDepthGuard() {
        val policy = ResearchExecutionPolicyV2154.interactive().copy(
            minInteractiveRunMillis = 60_000L,
            minPositiveEvidenceHandlesForReport = 6
        )
        val state = ResearchRunDepthGuardV2159.evaluate(closedContract(), elapsedMillis = 10_000L, policy = policy)
        assertTrue(state.fastClosePrevented)
        assertFalse(state.reportEligibleAfterDepth)
    }

    @Test
    fun interactiveClosureCanPassAfterMinimumDepth() {
        val policy = ResearchExecutionPolicyV2154.interactive().copy(
            minInteractiveRunMillis = 60_000L,
            minPositiveEvidenceHandlesForReport = 6
        )
        val state = ResearchRunDepthGuardV2159.evaluate(closedContract(), elapsedMillis = 65_000L, policy = policy)
        assertFalse(state.fastClosePrevented)
        assertTrue(state.reportEligibleAfterDepth)
    }

    @Test
    fun nonInteractiveUnitTestsAreNotDelayedByDepthGuard() {
        val policy = ResearchExecutionPolicyV2154.unitTestWithClosedProof().copy(
            enableResearchDepthGuard = true,
            minInteractiveRunMillis = 60_000L,
            minPositiveEvidenceHandlesForReport = 6
        )
        val state = ResearchRunDepthGuardV2159.evaluate(closedContract(), elapsedMillis = 1L, policy = policy)
        assertFalse(state.fastClosePrevented)
        assertTrue(state.reportEligibleAfterDepth)
    }
    @Test
    fun inactiveDepthGuardStillRequiresMandatoryProofGate() {
        var contract = ResearchRunContractV2150.create("Ebola Bundibugyo immune dysregulation")
            .withEvidenceHandle("candidate_source_handles_planned_not_evidence")
            .withEvidenceHandle("metadata_provenance_required_not_closed")
            .withEvidenceHandle("contradiction_falsification_required_not_closed")
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }
        val policy = ResearchExecutionPolicyV2154.unitTestNoFastFinish()
        val state = ResearchRunDepthGuardV2159.evaluate(contract, elapsedMillis = 1L, policy = policy)
        assertFalse(state.reportEligibleAfterDepth)
    }

}
