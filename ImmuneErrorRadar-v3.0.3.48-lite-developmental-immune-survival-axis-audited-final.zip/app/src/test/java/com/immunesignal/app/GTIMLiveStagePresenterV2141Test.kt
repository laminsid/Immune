package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMLiveStagePresenterV2141Test {
    @Test
    fun professionalPhasesProduceChangingTitlesAndPercentages() {
        val phases = GTIMProfessionalResearchOrchestratorV2140.phases()
        val states = phases.map { GTIMLiveStagePresenterV2141.fromProfessionalPhase(it, "Allergy") }
        assertEquals(7, states.size)
        assertTrue(states.first().headerTitle.contains("Read question"))
        assertTrue(states[1].headerTitle.contains("Local knowledge"))
        assertTrue(states[2].headerTitle.contains("Search/data plan"))
        assertTrue(states[3].headerTitle.contains("Filter/clean"))
        assertTrue(states[4].headerTitle.contains("Think"))
        assertTrue(states[5].headerTitle.contains("Link paths"))
        assertTrue(states.last().headerTitle.contains("Report"))
        assertTrue(states.zipWithNext().all { (a, b) -> b.percent > a.percent })
        assertTrue(states.all { it.subtitle.contains("%") && it.stageLine.contains("workflow progress") })
    }

    @Test
    fun presenterJsonKeepsClaimBoundary() {
        val state = GTIMLiveStagePresenterV2141.reportReady("Allergy")
        val json = GTIMLiveStagePresenterV2141.toJson(state)
        assertEquals("V2141_LIVE_STAGE_TITLES_AND_PERCENT_PROGRESS", json.getString("requiredToken"))
        assertEquals(100, json.getInt("percent"))
        assertTrue(json.getString("claimLimit").contains("not_evidence_strength"))
    }
}
