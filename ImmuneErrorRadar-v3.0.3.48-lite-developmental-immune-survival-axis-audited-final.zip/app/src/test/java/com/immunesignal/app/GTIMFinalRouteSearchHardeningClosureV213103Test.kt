package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalRouteSearchHardeningClosureV213103Test {
    @Test
    fun filovirusDoesNotAcceptCovidCanonicalTarget() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Ebola filovirus immune dysregulation"))
            .put("finalDataClosureExecutionV2132", JSONObject().put("selectedClosedTarget", "GSE166552").put("readinessScore", 8))
            .put("injectedMetadataSeedPackV21216", JSONObject().put("handles", JSONArray(listOf("GSE166552", "GSE45291"))))
            .put("staleSurfaceZeroExportGuardV2138", JSONObject().put("staleSurfaceItems", 0))
            .put("finalUnifiedDiscoveryReadinessClosureV21310", JSONObject().put("versionAligned", true))
        val canonical = GTIMActiveDomainConsistencyGuardV2134.canonicalFinalTarget(report)
        assertEquals("GSE45291", canonical)
        val hardening = GTIMFinalRouteSearchHardeningClosureV213103.toJson(report)
        assertTrue(hardening.getBoolean("filovirusCanonicalAllowed"))
    }

    @Test
    fun emptyCanonicalDoesNotKeepMatrixHandleActive() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "open metabolic inflammation route"))
            .put("canonicalFinalSurfaceGuardV2135", JSONObject().put("canonicalTarget", ""))
            .put("staleSurfaceZeroExportGuardV2138", JSONObject().put("staleSurfaceItems", 0))
            .put("finalUnifiedDiscoveryReadinessClosureV21310", JSONObject().put("versionAligned", true))
        val hardening = GTIMFinalRouteSearchHardeningClosureV213103.toJson(report)
        assertEquals("", hardening.getString("canonicalTarget"))
        assertTrue(hardening.getBoolean("emptyCanonicalSafe"))
        assertEquals("", hardening.getString("matrixShortcutHandle"))
    }

    @Test
    fun activeVersionIdentityIsCurrent() {
        assertEquals("v2.13.15-final-hypothesis-first-discovery-unified", EngineRuntimeStatus.ACTIVE_ENGINE_VERSION)
        assertEquals("2.13.15-final-hypothesis-first-discovery-unified", RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME)
        assertEquals(192, RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE)
        assertEquals(192, ReleaseVersionLinkageGuard.VERSION_CODE)
        assertEquals("2.13.15", RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION)
    }
}
