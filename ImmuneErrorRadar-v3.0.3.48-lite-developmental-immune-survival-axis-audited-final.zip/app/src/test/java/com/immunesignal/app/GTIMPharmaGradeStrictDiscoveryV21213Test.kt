package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMPharmaGradeStrictDiscoveryV21213Test {

    @Test
    fun depressionKynurenineBuildsTargetCardAndCompetingHypotheses() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("normalizedTopic", "depression kynurenine pathway IDO1 KMO neuroimmune")
                .put("rawInput", "depression kynurenine"))
            .put("domainSpecificHypothesisSelectorV2129", JSONObject()
                .put("domainKey", "depression_kynurenine_neuroimmune"))
            .put("reportConsistencyGateV2121", JSONObject()
                .put("candidateLookupHandle", "GSE000001"))
        val target = GTIMTargetValidationCardV21213.toJson(report)
        val variants = GTIMHypothesisVariantDiscriminatorV21213.toJson(report.put("targetValidationCardV21213", target))
        val strict = GTIMPharmaGradeStrictnessGateV21213.toJson(report.put("hypothesisVariantDiscriminatorV21213", variants))
        val text = target.toString() + variants.toString() + strict.toString()

        assertTrue(text.contains("IDO1"))
        assertTrue(text.contains("KMO"))
        assertTrue(text.contains("kynurenine/tryptophan"))
        assertTrue(variants.optJSONArray("variants")!!.length() >= 3)
        assertFalse(strict.optBoolean("claimPromotionAllowed"))
        assertTrue(strict.optString("state").contains("STRICT_PROMOTION_BLOCKED"))
    }

    @Test
    fun strictDiscoveryKeepsOldRoutesLinkedWhileRaisingPromotionGates() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("normalizedTopic", "COVID interferon IL-6 TNF GSE152202"))
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "viral_interferon_cytokine"))
            .put("reportConsistencyGateV2121", JSONObject()
                .put("candidateLookupHandle", "GSE152202")
                .put("topicCompatibleTargetSelected", false)
                .put("verifiedMatrixFiles", 0))
            .put("terminalDiscoveryContinuationV21212", JSONObject().put("state", "CONTINUE_AFTER_D_PLUS_WITH_REVIEW_TARGET"))
        val utility = GTIMPublishedResearchUtilityScoreV21213.toJson(report)
        val ladder = GTIMDrugDiscoveryTranslationLadderV21213.toJson(report.put("publishedResearchUtilityScoreV21213", utility))
        val negative = GTIMNegativeEvidenceMemoryV21213.toJson(report)
        val strict = GTIMPharmaGradeStrictnessGateV21213.toJson(report.put("negativeEvidenceMemoryV21213", negative))
        val text = ladder.toString() + strict.toString()

        assertTrue(text.contains("old_ETL_DGE_external_router_matrix_shortcut_routes_remain_linked"))
        assertTrue(text.contains("topic signal"))
        assertTrue(strict.optBoolean("discoveryMayContinue"))
        assertFalse(strict.optBoolean("claimPromotionAllowed"))
        assertTrue(strict.optJSONArray("missingHardGates")!!.length() >= 3)
    }
}
