package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMC2InnovationReadinessV2139Test {
    @Test
    fun executableReplicationMatrixTurnsC1IntoC2ReadyWorkWithoutPromotingProof() {
        val report = depressionReport()
        attachBase(report)
        attachInnovation(report)
        attachV2138(report)
        val matrix = GTIMExecutableReplicationMatrixV2139.toJson(report)
        assertEquals("GSE102556", matrix.getString("canonicalTarget"))
        assertTrue(matrix.getJSONArray("executionRows").length() > 0)
        assertTrue(matrix.getString("state").contains("REPLICATION_MATRIX"))
        assertEquals(true, matrix.getBoolean("c2PromotionBlocked"))
    }

    @Test
    fun evidenceLiftGateRelaxesC1ButKeepsC2Blocked() {
        val report = allergyReport()
        attachBase(report)
        attachInnovation(report)
        attachV2138(report)
        report.put("executableReplicationMatrixV2139", GTIMExecutableReplicationMatrixV2139.toJson(report))
        val lift = GTIMEvidenceLiftGateV2139.toJson(report)
        assertTrue(lift.getString("allowedOutputLevel").contains("C1"))
        assertEquals(false, lift.getBoolean("c2Blocked"))
        assertTrue(lift.getString("hardBoundary").contains("C2_C3"))
    }

    @Test
    fun finalC2ClosureLinksOldNewRoutesAndBlocksClaimPromotion() {
        val report = viralReport()
        attachBase(report)
        attachInnovation(report)
        attachV2138(report)
        attachV2139(report)
        val closure = GTIMFinalC2InnovationReadinessClosureV2139.toJson(report)
        assertTrue(closure.getString("state").contains("FINAL_C2_INNOVATION_READINESS"))
        assertTrue(closure.getBoolean("claimPromotionAllowed"))
        assertTrue(closure.getString("routeLinkage").contains("v2.13.9 executable replication matrix"))
    }

    private fun allergyReport(): JSONObject = JSONObject()
        .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "allergy_type2_barrier"))
        .put("verifiedMetadataClosurePackV2132", JSONObject().put("state", "VERIFIED_METADATA_CLOSURE_READY").put("selectedClosedTarget", "GSE146170"))
        .put("finalDataClosureExecutionV2132", JSONObject().put("readinessScore", 10).put("selectedClosedTarget", "GSE146170"))

    private fun depressionReport(): JSONObject = JSONObject()
        .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "depression_kynurenine_neuroimmune"))
        .put("verifiedMetadataClosurePackV2132", JSONObject().put("state", "VERIFIED_METADATA_CLOSURE_READY").put("selectedClosedTarget", "GSE102556"))
        .put("finalDataClosureExecutionV2132", JSONObject().put("readinessScore", 10).put("selectedClosedTarget", "GSE102556"))

    private fun viralReport(): JSONObject = JSONObject()
        .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "viral_interferon_cytokine"))
        .put("verifiedMetadataClosurePackV2132", JSONObject().put("state", "VERIFIED_METADATA_CLOSURE_READY").put("selectedClosedTarget", "GSE166552"))
        .put("finalDataClosureExecutionV2132", JSONObject().put("readinessScore", 8).put("selectedClosedTarget", "GSE166552"))

    private fun attachBase(report: JSONObject) {
        report.put("activeDomainConsistencyGuardV2134", GTIMActiveDomainConsistencyGuardV2134.toJson(report))
        report.put("canonicalFinalSurfaceGuardV2135", GTIMCanonicalFinalSurfaceGuardV2135.toJson(report))
        report.put("futureEvidenceLiteCorpusV2130", GTIMFutureEvidenceLiteCorpusV2130.toJson(report))
        report.put("processedCapsuleStoreV2135", GTIMProcessedCapsuleStoreV2135.toJson(report))
        report.put("immuneModuleSignalEngineV2135", GTIMImmuneModuleSignalEngineV2135.toJson(report))
        report.put("discoveryExecutionEnginesV2135", GTIMDiscoveryExecutionEnginesV2135.toJson(report))
        report.put("discoveryClaimLadderV2135", GTIMDiscoveryClaimLadderV2135.toJson(report))
        report.put("discoveryCandidateAssemblerV2135", GTIMDiscoveryCandidateAssemblerV2135.toJson(report))
    }

    private fun attachInnovation(report: JSONObject) {
        report.put("signalSurpriseEngineV2137", GTIMSignalSurpriseEngineV2137.toJson(report))
        report.put("cellTissueSpecificityEngineV2137", GTIMCellTissueSpecificityEngineV2137.toJson(report))
        report.put("immunePhaseEngineV2137", GTIMImmunePhaseEngineV2137.toJson(report))
        report.put("hypothesisMutationEngineV2137", GTIMHypothesisMutationEngineV2137.toJson(report))
        report.put("mechanismCompetitionArenaV2137", GTIMMechanismCompetitionArenaV2137.toJson(report))
        report.put("c2AutoReplicationEngineV2137", GTIMC2AutoReplicationEngineV2137.toJson(report))
        report.put("crossDiseaseImmuneConvergenceEngineV2137", GTIMCrossDiseaseImmuneConvergenceEngineV2137.toJson(report))
        report.put("drugVaccineMechanismTriangulationV2137", GTIMDrugVaccineMechanismTriangulationV2137.toJson(report))
        report.put("discoveryNoveltyMinerV2137", GTIMDiscoveryNoveltyMinerV2137.toJson(report))
        report.put("discoverySynthesisCardV2137", GTIMDiscoverySynthesisCardV2137.toJson(report))
        report.put("finalInnovationDiscoveryClosureV2137", GTIMFinalInnovationDiscoveryClosureV2137.toJson(report))
    }

    private fun attachV2138(report: JSONObject) {
        report.put("legacyCandidateSupersessionGuardV2138", GTIMLegacyCandidateSupersessionGuardV2138.toJson(report))
        report.put("staleSurfaceZeroExportGuardV2138", GTIMStaleSurfaceZeroExportGuardV2138.toJson(report))
        report.put("moduleScorePlaceholderEngineV2138", GTIMModuleScorePlaceholderEngineV2138.toJson(report))
        report.put("c1ToC2UpgradePathwayV2138", GTIMC1ToC2UpgradePathwayV2138.toJson(report))
        report.put("nonObviousExperimentDesignerV2138", GTIMNonObviousExperimentDesignerV2138.toJson(report))
        report.put("innovationPortfolioRankerV2138", GTIMInnovationPortfolioRankerV2138.toJson(report))
        report.put("finalInnovationExecutionClosureV2138", GTIMFinalInnovationExecutionClosureV2138.toJson(report))
    }

    private fun attachV2139(report: JSONObject) {
        report.put("executableReplicationMatrixV2139", GTIMExecutableReplicationMatrixV2139.toJson(report))
        report.put("evidenceLiftGateV2139", GTIMEvidenceLiftGateV2139.toJson(report))
        report.put("anomalyToInnovationBacklogV2139", GTIMAnomalyToInnovationBacklogV2139.toJson(report))
    }
}
