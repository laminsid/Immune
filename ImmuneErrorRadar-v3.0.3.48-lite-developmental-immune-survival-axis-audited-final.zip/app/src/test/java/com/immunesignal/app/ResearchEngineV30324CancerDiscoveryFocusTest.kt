package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30324CancerDiscoveryFocusTest {
    @Test
    fun cancerHypothesesAreMechanismSpecificAndEvidenceDirected() {
        val topic = "cancer tumor immune microenvironment cd8 macrophage treg checkpoint transcriptome"
        val state = ResearchStateV3.initial(ResearchInputV3(topic))
        val closure = ResearchClosureSnapshotV3(
            canCloseReport = false,
            openGates = listOf("visible_dataset_or_provenance_evidence"),
            visibleTierABCount = 0,
            visibleTierCDCount = 0,
            contradictionObjectiveExecuted = false,
            contradictionEvidenceFound = false,
            distinctAccessions = emptyList(),
            criticalRoleIndependencePassed = true,
            contradictionObjectiveExhausted = false
        )
        val hypotheses = ResearchHypothesisGeneratorV3.generate(state, closure)
        assertTrue(hypotheses.any { it.contains("CD8", ignoreCase = true) || it.contains("checkpoint", ignoreCase = true) })
        assertTrue(hypotheses.any { it.contains("comparator", ignoreCase = true) || it.contains("transcriptome", ignoreCase = true) })
        assertFalse(hypotheses.any { it.contains("clinical", ignoreCase = true) && it.contains("treatment", ignoreCase = true) })
    }

    @Test
    fun cancerProofQueriesTargetComparatorExpressionMechanismAndFalsifier() {
        val objective = ResearchObjectiveV3.ContinueHypothesisProof(
            topic = "melanoma cancer immunotherapy CD8 exhaustion macrophage Treg checkpoint",
            hypothesisId = "H1_PRIMARY"
        )
        val queries = objective.querySeeds().joinToString(" | ").lowercase()
        assertTrue(queries.contains("responder") || queries.contains("non-responder"))
        assertTrue(queries.contains("processed expression") || queries.contains("matrix"))
        assertTrue(queries.contains("mechanism") || queries.contains("validation"))
        assertTrue(queries.contains("falsifier") || queries.contains("negative control"))
    }

    @Test
    fun cancerMetadataProbeAddsTumorImmuneComparatorsAndExpressionRoute() {
        val topic = "cancer tumor immune microenvironment CD8 macrophage Treg checkpoint transcriptome"
        val ledger = EvidenceLedgerV3()
        ledger.addNode(EvidenceNodeV3(
            id = "gse115978",
            type = EvidenceTypeV3.DATASET,
            accession = "GSE115978",
            title = "Single-cell RNA-seq of melanoma ecosystems reveals sources of T cells exclusion linked to immunotherapy clinical outcomes",
            source = SourceKindV3.GEO,
            articleType = ArticleTypeV3.TRANSCRIPTOMICS,
            role = EvidenceRoleV3.DATASET,
            qualityTier = QualityTierV3.A
        ))
        val report = ResearchMetadataProbeIngestionV3.evaluate(ResearchStateV3.initial(ResearchInputV3(topic), ledger.snapshot()))
        assertEquals("METADATA_PROBE_READY_CANCER_TME_PROCESSED_EXPRESSION_ROUTE", report.state)
        val target = report.targets.first()
        assertTrue(target.expectedComparators.any { it.contains("responder", ignoreCase = true) })
        assertTrue(target.processedExpressionRoute.contains("CANCER_TME", ignoreCase = true))
    }

    @Test
    fun cancerHardGateBlocksGenericTumorIntrinsicDatasetWithoutTmeAxis() {
        val frame = BiomedicalTopicFrameV3.from("cancer tumor immune microenvironment cd8 macrophage transcriptome")
        val limitations = DatasetPhenotypeHardGateV3.limitationsFor(
            frame = frame,
            text = "GSE999999 cancer mutation landscape copy number methylation only cell line only dataset",
            source = SourceKindV3.GEO,
            requestedRole = EvidenceRoleV3.DATASET
        )
        assertTrue(limitations.any { it.contains("cancer_topic_requires_tumor_immune_microenvironment", ignoreCase = true) })
    }
}
