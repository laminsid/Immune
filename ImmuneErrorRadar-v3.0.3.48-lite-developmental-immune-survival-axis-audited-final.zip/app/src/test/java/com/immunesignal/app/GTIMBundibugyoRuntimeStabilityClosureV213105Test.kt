package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMBundibugyoRuntimeStabilityClosureV213105Test {
    @Test
    fun bundibugyoPromptNeverUsesCovidCanonicalTarget() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Ebola Bundibugyo BDBV interferon cytokine host response"))
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "viral_interferon_cytokine"))
            .put("verifiedMetadataClosurePackV2132", JSONObject()
                .put("state", "VERIFIED_METADATA_CLOSURE_READY")
                .put("selectedClosedTarget", "GSE166552"))
            .put("finalDataClosureExecutionV2132", JSONObject()
                .put("readinessScore", 8)
                .put("selectedClosedTarget", "GSE166552"))
            .put("injectedMetadataSeedPackV21216", JSONObject()
                .put("candidateHandles", JSONArray(listOf("GSE166552", "GSE131907", "GSE45291"))))

        assertEquals("filovirus_viral_host_response", GTIMBundibugyoRuntimeStabilityClosureV213105.forcedActiveDomain(report))
        assertEquals("viral_filovirus_bundibugyo", GTIMBundibugyoRuntimeStabilityClosureV213105.forcedSubtype(report))
        assertEquals("", GTIMBundibugyoRuntimeStabilityClosureV213105.canonicalTarget(report))
        assertEquals("", GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report))
        assertFalse(GTIMBundibugyoRuntimeStabilityClosureV213105.targetAllowedForSubtype("GSE166552", "viral_filovirus_bundibugyo"))
    }

    @Test
    fun filovirusPromptPrefersFilovirusTargetAndBlocksCovidFallback() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Ebola filovirus viral hemorrhagic fever host response"))
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "viral_interferon_cytokine"))
            .put("verifiedMetadataClosurePackV2132", JSONObject()
                .put("state", "VERIFIED_METADATA_CLOSURE_READY")
                .put("selectedClosedTarget", "GSE166552"))
            .put("injectedMetadataSeedPackV21216", JSONObject()
                .put("candidateHandles", JSONArray(listOf("GSE166552", "GSE45291"))))

        assertEquals("viral_filovirus", GTIMBundibugyoRuntimeStabilityClosureV213105.forcedSubtype(report))
        assertEquals("GSE45291", GTIMBundibugyoRuntimeStabilityClosureV213105.canonicalTarget(report))
        assertEquals("GSE45291", GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report))
        assertFalse(GTIMBundibugyoRuntimeStabilityClosureV213105.targetAllowedForSubtype("GSE166552", "viral_filovirus"))
    }

    @Test
    fun closureRecordsRuntimeSafeReportTransition() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Ebola Bundibugyo"))
            .put("verifiedMetadataClosurePackV2132", JSONObject().put("selectedClosedTarget", "GSE166552"))
        val closure = GTIMBundibugyoRuntimeStabilityClosureV213105.toJson(report, "UI_RENDER")
        assertEquals("viral_filovirus_bundibugyo", closure.getString("subtype"))
        assertTrue(closure.getBoolean("reportTransitionSafe"))
        assertTrue(closure.getJSONArray("blockedGenericTargets").toString().contains("GSE166552"))
    }
}
