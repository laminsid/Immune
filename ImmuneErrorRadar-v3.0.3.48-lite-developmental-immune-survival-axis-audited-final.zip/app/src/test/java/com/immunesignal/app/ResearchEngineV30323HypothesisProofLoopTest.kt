package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30323HypothesisProofLoopTest {
    @Test
    fun closureCannotCloseAfterRankingUntilHypothesisProofRuns() {
        val ledger = EvidenceLedgerV3()
        ledger.addNode(EvidenceNodeV3(
            id = "pmid-covid-ifn",
            type = EvidenceTypeV3.SOURCE,
            accession = "PMID:33867315",
            title = "COVID immune response interferon IL-6 TNF review",
            source = SourceKindV3.PUBMED,
            articleType = ArticleTypeV3.REVIEW,
            role = EvidenceRoleV3.SOURCE,
            qualityTier = QualityTierV3.B
        ))
        ledger.addNode(EvidenceNodeV3(
            id = "gse152522",
            type = EvidenceTypeV3.DATASET,
            accession = "GSE152522",
            title = "SARS-CoV-2 PBMC transcriptome severe mild healthy control cohort",
            source = SourceKindV3.GEO,
            articleType = ArticleTypeV3.TRANSCRIPTOMICS,
            role = EvidenceRoleV3.DATASET,
            qualityTier = QualityTierV3.A
        ))
        val topic = "sars-cov-2 covid-19 immune dysregulation interferon pbmc healthy control severity comparator transcriptome"
        ledger.record(ResearchObjectiveOutcomeV3(ResearchObjectiveV3.FindSourceEvidence(topic), listOf("source"), emptyList(), exhausted = false))
        ledger.record(ResearchObjectiveOutcomeV3(ResearchObjectiveV3.FindDatasetEvidence(topic), listOf("dataset"), emptyList(), exhausted = false))
        ledger.record(ResearchObjectiveOutcomeV3(ResearchObjectiveV3.FindContradiction(topic, "H1_PRIMARY"), listOf("negative control"), emptyList(), exhausted = true))
        ledger.record(ResearchObjectiveOutcomeV3(ResearchObjectiveV3.FindProvenance(topic, "GSE152522"), listOf("metadata"), emptyList(), exhausted = false))
        ledger.record(ResearchObjectiveOutcomeV3(ResearchObjectiveV3.RankHypotheses(topic), emptyList(), emptyList(), exhausted = false))
        val state = ResearchStateV3.initial(ResearchInputV3(topic), ledger.snapshot())
        val closure = ResearchClosurePolicyV3().evaluate(state)
        assertFalse(closure.canCloseReport)
        assertTrue(closure.openGates.contains("hypothesis_proof_continuation_not_executed"))
    }

    @Test
    fun plannerSchedulesProofContinuationAfterRankingBeforeCompile() {
        val ledger = EvidenceLedgerV3()
        val topic = "sars-cov-2 covid-19 immune dysregulation interferon pbmc healthy control severity comparator transcriptome"
        ledger.record(ResearchObjectiveOutcomeV3(ResearchObjectiveV3.RankHypotheses(topic), emptyList(), emptyList(), exhausted = false))
        val state = ResearchStateV3.initial(ResearchInputV3(topic), ledger.snapshot())
        val objective = ResearchPlannerV3().nextObjective(state)
        assertTrue(objective is ResearchObjectiveV3.ContinueHypothesisProof)
    }

    @Test
    fun proofContinuationSnapshotShowsPendingOrExecutedState() {
        val topic = "multiple sclerosis myelin interferon complement neuroimmune"
        val state = ResearchStateV3.initial(ResearchInputV3(topic))
        val snapshot = ResearchHypothesisProofContinuationV3.evaluate(state)
        assertTrue(snapshot.active)
        assertFalse(snapshot.executed)
        assertTrue(snapshot.state.contains("PENDING"))
    }
}
