package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3EvidenceDepthRuntimeGateTest {
    @Test
    fun pubMedEfetchAbstractParserExtractsPerPmidAbstracts() {
        val xml = """
            <PubmedArticleSet>
              <PubmedArticle>
                <MedlineCitation>
                  <PMID Version="1">123</PMID>
                  <Article>
                    <Abstract>
                      <AbstractText Label="BACKGROUND">SARS-CoV-2 infection induced interferon and cytokine immune signatures.</AbstractText>
                      <AbstractText Label="METHODS">PBMC RNA-seq compared patients with healthy controls.</AbstractText>
                    </Abstract>
                  </Article>
                </MedlineCitation>
              </PubmedArticle>
              <PubmedArticle>
                <MedlineCitation>
                  <PMID>456</PMID>
                  <Article><Abstract><AbstractText>Bundibugyo Ebola model limitation with negative control comparator.</AbstractText></Abstract></Article>
                </MedlineCitation>
              </PubmedArticle>
            </PubmedArticleSet>
        """.trimIndent()

        val parsed = ResearchEvidenceAcquisitionV2170.parseAbstractsFromPubMedXml(xml)
        assertEquals(2, parsed.size)
        assertTrue(parsed.getValue("123").contains("PBMC RNA-seq"))
        assertTrue(parsed.getValue("456").contains("negative control comparator"))
    }

    @Test
    fun sourceRoleRequiresImmuneMechanismCueNotJustTopicMention() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "42075512",
                title = "Post-COVID-19 Jaw Osteonecrosis: A Narrative Review.",
                source = SourceKindV3.PUBMED,
                abstractText = "This paper discusses dental outcomes after COVID-19 but does not provide immune mechanism evidence."
            ),
            requestedRole = EvidenceRoleV3.SOURCE,
            topic = "Covid",
            query = "Covid immune dysregulation PubMed"
        )

        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertTrue(node.limitations.contains("source_role_requires_topic_and_immune_mechanism_cue"))
        assertFalse(node.satisfiesResearchRole(EvidenceRoleV3.SOURCE))
    }

    @Test
    fun closureRequiresExternalQueryDepthNotOnlyPreloadedNodes() {
        val nodes = listOf(
            EvidenceNodeV3("s", EvidenceTypeV3.SOURCE, "PMID:1", "Covid immune cohort", SourceKindV3.PUBMED, ArticleTypeV3.COHORT, EvidenceRoleV3.SOURCE, QualityTierV3.A),
            EvidenceNodeV3("d", EvidenceTypeV3.DATASET, "GSE1", "Covid PBMC transcriptome GEO dataset", SourceKindV3.GEO, ArticleTypeV3.DATASET, EvidenceRoleV3.DATASET, QualityTierV3.A),
            EvidenceNodeV3("p", EvidenceTypeV3.PROVENANCE, "GSE2", "Covid PBMC sample provenance healthy controls", SourceKindV3.GEO, ArticleTypeV3.DATASET, EvidenceRoleV3.PROVENANCE, QualityTierV3.A),
            EvidenceNodeV3("c", EvidenceTypeV3.CONTRADICTION, "PMID:2", "Covid immune negative control comparator", SourceKindV3.PUBMED, ArticleTypeV3.COHORT, EvidenceRoleV3.CONTRADICTION, QualityTierV3.B, contradicts = listOf("primary_hypothesis"))
        )
        val outcomes = listOf(
            ResearchObjectiveOutcomeV3(ResearchObjectiveV3.FindSourceEvidence("Covid"), listOf("source query"), listOf(nodes[0]), false),
            ResearchObjectiveOutcomeV3(ResearchObjectiveV3.FindDatasetEvidence("Covid"), listOf("dataset query"), listOf(nodes[1]), false),
            ResearchObjectiveOutcomeV3(ResearchObjectiveV3.FindProvenance("Covid", "GSE1"), listOf("provenance query"), listOf(nodes[2]), false),
            ResearchObjectiveOutcomeV3(ResearchObjectiveV3.FindContradiction("Covid", "H1_PRIMARY"), listOf("contradiction query"), listOf(nodes[3]), false),
            ResearchObjectiveOutcomeV3(ResearchObjectiveV3.RankHypotheses("Covid"), emptyList(), emptyList(), false)
        )
        val state = ResearchStateV3.initial(ResearchInputV3("Covid"), EvidenceLedgerSnapshotV3(nodes, outcomes))
        val closure = ResearchClosurePolicyV3().evaluate(state)

        assertFalse(closure.canCloseReport)
        assertTrue(closure.openGates.contains("insufficient_external_query_depth_for_report"))
    }

    @Test
    fun interactiveFastReportReadyIsDowngradedToCheckpointForUi() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = staticCompleteAdapter())
        ).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result is ResearchResultV3.ReportReady)

        val json = ResearchEngineV3ActivityBridge.toActivityJson(
            result,
            elapsedMs = 93L,
            enforceInteractiveDepthGate = true
        )
        val v3 = json.getJSONObject("researchEngineV3")
        val closure = v3.getJSONObject("closure")

        assertEquals("CHECKPOINT_READY", json.getString("status"))
        assertFalse(closure.getBoolean("canCloseReport"))
        assertTrue(v3.getJSONArray("openGates").toString().contains("interactive_real_fetch_depth_not_demonstrated"))
        assertTrue(json.getJSONObject("researchEngineV3ActivityBridge").getBoolean("interactiveDepthGateApplied"))
    }

    private fun staticCompleteAdapter(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3(
                    "1001",
                    "Bundibugyo Ebola host response mechanistic review",
                    SourceKindV3.PUBMED,
                    abstractText = "Bundibugyo Ebola immune host response, cytokine pathways, and interferon mechanisms were reviewed."
                )
            ),
            "transcriptome geo" to listOf(
                EvidenceSearchRecordV3("GSE2001", "Bundibugyo Ebola transcriptome GEO dataset cohort", SourceKindV3.GEO)
            ),
            "sample provenance" to listOf(
                EvidenceSearchRecordV3("GSE2002", "Bundibugyo Ebola sample provenance comparator labels cohort", SourceKindV3.GEO)
            ),
            "tissue comparator limitation" to listOf(
                EvidenceSearchRecordV3(
                    "3001",
                    "Bundibugyo Ebola negative control comparator falsification study",
                    SourceKindV3.PUBMED,
                    abstractText = "A negative control comparator and tissue limitation analysis tested whether the primary immune signature generalized across models."
                )
            )
        )
    )
}
