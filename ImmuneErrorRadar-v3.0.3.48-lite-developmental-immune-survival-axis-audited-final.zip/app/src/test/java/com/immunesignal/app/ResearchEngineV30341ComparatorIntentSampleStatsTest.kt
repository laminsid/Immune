package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30341ComparatorIntentSampleStatsTest {
    @Test
    fun gse85047MycnWithinDiseaseComparatorIsAccepted() {
        val topic = "GSE85047 pediatric neuroblastoma MYCN amplified vs non MYCN CD8 NK immune cold GD2 B7-H3"
        val decision = ResearchIntentGateV3.evaluate(topic)
        assertTrue(decision.allowed)
        assertEquals("accepted_local_matrix_biomedical_frame", decision.reason)
    }

    @Test
    fun pediatricMatrixUsesPerSampleModuleScore() {
        val rows = PediatricOncologyExplicitMatrixV30337.rows()
        val result = ProcessedExpressionMatrixCalculatorV30329.calculatePerSampleModuleScore(
            rows = rows.map { it.copy(group = ComparatorGroupResolverV30330.normalizeLabel(it.group)) },
            caseGroups = PediatricOncologyExplicitMatrixV30337.caseLabels,
            controlGroups = PediatricOncologyExplicitMatrixV30337.controlLabels,
            markers = PediatricOncologyExplicitMatrixV30337.markers
        )
        assertEquals(1, result.size)
        assertEquals("PER_SAMPLE_MODULE_SCORE", result.first().marker)
        assertEquals("per_sample_module_score_welch_t", result.first().statisticFamily)
        assertEquals(6, result.first().nCase)
        assertEquals(6, result.first().nControl)
    }

    @Test
    fun proofAxisSelectorPrefersGse85047OverMousePreclinical() {
        val topic = "GSE85047 pediatric neuroblastoma MYCN amplified versus non MYCN CD8 NK"
        val routes = listOf(
            ResearchComparatorLabelRouteV3(
                accession = "GSE212658",
                state = "COMPARATOR_LABELS_READY_REVIEW_ONLY",
                caseControlAxis = "MYCN_amplified_vs_non_MYCN",
                severityOrSubtypeAxis = "high_risk_vs_low_risk",
                tissueOrCellAxis = "mouse_preclinical_tumor",
                timepointAxis = "missing",
                confidence = 95,
                missing = emptyList()
            ),
            ResearchComparatorLabelRouteV3(
                accession = "GSE85047",
                state = "COMPARATOR_LABELS_READY_REVIEW_ONLY",
                caseControlAxis = "MYCN_amplified_vs_non_MYCN",
                severityOrSubtypeAxis = "primary_neuroblastoma_tumor",
                tissueOrCellAxis = "human_tumor",
                timepointAxis = "untreated_primary",
                confidence = 80,
                missing = emptyList()
            )
        )
        val selected = PediatricProofAxisSelectorV30341.selectRoute(
            topic,
            routes,
            ResearchStateV3.initial(ResearchInputV3(topic))
        )
        assertNotNull(selected)
        assertEquals("GSE85047", selected?.accession)
        assertFalse(PediatricProofAxisSelectorV30341.sourceRole("GSE212658").contains("HUMAN_REPLICATION"))
    }
}
