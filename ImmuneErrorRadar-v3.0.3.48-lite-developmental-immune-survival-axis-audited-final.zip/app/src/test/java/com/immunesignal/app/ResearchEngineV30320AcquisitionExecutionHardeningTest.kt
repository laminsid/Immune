package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30320AcquisitionExecutionHardeningTest {
    @Test
    fun ncbiBooleanQueryKeepsParenthesesAndEncodesRetmaxAboveFive() {
        val policy = ResearchExecutionPolicyV2154.Policy(interactive = false, maxQueryChars = 900)
        val query = "(systemic lupus erythematosus OR lupus OR SLE) AND (type I interferon OR complement OR B cell) PubMed"
        val normalized = ResearchEvidenceAcquisitionV2170.normalizeQueryForESearchForTests(query, policy)
        assertTrue(normalized.contains("("))
        assertTrue(normalized.contains(" OR "))
        assertTrue(normalized.contains(" AND "))
        assertFalse(normalized.contains("PubMed"))

        val requestedRetMax = NcbiQueryExecutionGuardV3.pubMedRetMax()
        val url = ResearchEvidenceAcquisitionV2170.buildESearchUrlForTests("pubmed", query, requestedRetMax, policy)
        assertTrue("runtime retMax must remain above the old five-result cap", requestedRetMax > 5)
        assertTrue(url.contains("retmax=$requestedRetMax"))
        assertTrue(url.contains("%28"))
        assertTrue(url.contains("+AND+"))
        assertTrue(url.contains("%29"))
    }

    @Test
    fun lupusAndRheumatoidArthritisReceiveGenericAutoimmuneFallbackProfiles() {
        val lupus = ResearchQueryFallbackFanoutV3.expand(
            seeds = listOf("(systemic lupus erythematosus OR lupus OR SLE) AND (type I interferon OR complement) PubMed"),
            role = EvidenceRoleV3.DATASET,
            topic = "systemic lupus erythematosus sle autoimmunity type interferon complement B cell BAFF"
        )
        assertTrue(lupus.first().contains("systemic lupus", ignoreCase = true))
        assertTrue(lupus.drop(1).any { it.contains("SLE interferon signature", ignoreCase = true) && it.contains("GSE", ignoreCase = true) })
        assertTrue(lupus.drop(1).any { it.contains("lupus nephritis", ignoreCase = true) && it.contains("RNA-seq", ignoreCase = true) })

        val ra = ResearchQueryFallbackFanoutV3.expand(
            seeds = listOf("(rheumatoid arthritis OR RA) AND (synovial inflammation OR TNF OR IL-6) PubMed"),
            role = EvidenceRoleV3.DATASET,
            topic = "rheumatoid arthritis ra autoimmune synovial inflammation TNF IL-6 IL-17 macrophage"
        )
        assertTrue(ra.first().contains("rheumatoid arthritis", ignoreCase = true))
        assertTrue(ra.drop(1).any { it.contains("synovium transcriptome", ignoreCase = true) && it.contains("GEO", ignoreCase = true) })
        assertTrue(ra.drop(1).any { it.contains("single-cell", ignoreCase = true) && it.contains("GSE", ignoreCase = true) })
    }

    @Test
    fun broadAnimalMethylationGeoCannotSatisfyLupusDatasetRoute() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "GSE195869",
                title = "Comparative analysis of genome-scale, base-resolution DNA methylation profiles across 580 animal species",
                source = SourceKindV3.GEO
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = "systemic lupus erythematosus sle autoimmunity type interferon complement B cell BAFF immune complex cytokine",
            query = "systemic lupus erythematosus PBMC transcriptome GEO"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertEquals(QualityTierV3.D, node.qualityTier)
        assertFalse(node.satisfiesResearchRole(EvidenceRoleV3.DATASET))
        assertTrue(node.limitations.any { it.contains("dataset_phenotype_mismatch") || it.contains("relevance_topic_profile_mismatch") })
    }

    @Test
    fun phenotypeMatchedGenericAutoimmuneDatasetsCanSatisfyDatasetRoute() {
        val lupusNode = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "GSE-SLE-1",
                title = "Systemic lupus erythematosus PBMC transcriptome cohort with healthy controls and interferon signature",
                source = SourceKindV3.GEO,
                abstractText = "GEO dataset with SLE patients, PBMC samples, healthy controls, type I interferon and complement pathway expression profiling."
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = "systemic lupus erythematosus sle autoimmunity type interferon complement B cell BAFF immune complex cytokine",
            query = "systemic lupus erythematosus PBMC transcriptome GEO"
        )
        assertEquals(EvidenceRoleV3.DATASET, lupusNode.role)
        assertTrue(lupusNode.satisfiesResearchRole(EvidenceRoleV3.DATASET))

        val raNode = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "GSE-RA-1",
                title = "Rheumatoid arthritis synovium single-cell RNA-seq dataset with macrophage T cell and healthy control samples",
                source = SourceKindV3.GEO,
                abstractText = "GEO cohort dataset for RA synovial inflammation, TNF, IL-6, IL-17, macrophage and T cell transcriptome profiling."
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = "rheumatoid arthritis ra autoimmune synovial inflammation TNF IL-6 IL-17 macrophage",
            query = "rheumatoid arthritis synovium transcriptome GEO"
        )
        assertEquals(EvidenceRoleV3.DATASET, raNode.role)
        assertTrue(raNode.satisfiesResearchRole(EvidenceRoleV3.DATASET))
    }

    @Test
    fun performanceTriageDowngradesDuplicateCriticalRolesAndCapsContextNoise() {
        val source = testNode(
            id = "source-pmid-1",
            accession = "PMID:39417574",
            role = EvidenceRoleV3.SOURCE,
            type = EvidenceTypeV3.SOURCE,
            tier = QualityTierV3.A
        )
        val state = ResearchStateV3.initial(
            ResearchInputV3("depression kynurenine pathway"),
            EvidenceLedgerSnapshotV3(nodes = listOf(source), objectiveOutcomes = emptyList())
        )
        val duplicateContradiction = testNode(
            id = "contra-same-pmid",
            accession = "PMID:39417574",
            role = EvidenceRoleV3.CONTRADICTION,
            type = EvidenceTypeV3.CONTRADICTION,
            tier = QualityTierV3.B
        )
        val contextNoise = (1..12).map { idx ->
            testNode(
                id = "context-$idx",
                accession = "PMID:CTX$idx",
                role = EvidenceRoleV3.CONTEXT,
                type = EvidenceTypeV3.CONTEXT,
                tier = QualityTierV3.D
            )
        }
        val triaged = ResearchEvidenceTriageV3.apply(listOf(duplicateContradiction) + contextNoise, EvidenceRoleV3.CONTRADICTION, state)
        val duplicate = triaged.first { it.id == "contra-same-pmid" }
        assertEquals(EvidenceRoleV3.CONTEXT, duplicate.role)
        assertTrue(duplicate.limitations.contains("exclusive_role_overlap_downgraded_to_context"))
        assertTrue(triaged.count { it.role == EvidenceRoleV3.CONTEXT } <= ResearchEvidenceTriageV3.MAX_CONTEXT_NODES_PER_OBJECTIVE)
    }


    @Test
    fun sourceTitleFilterDemotesOffRouteCovidSideEffects() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "42194644",
                title = "Retrospective Evaluation of the Impact of the COVID-19 Pandemic on the Incidence of Alopecia Areata",
                source = SourceKindV3.PUBMED,
                abstractText = "A dermatology cohort describing alopecia trends during the pandemic without post-COVID interferon persistence or endothelial immune dysregulation evidence."
            ),
            requestedRole = EvidenceRoleV3.SOURCE,
            topic = "post-covid immune persistence interferon timing endothelial dysfunction cytokine inflammation",
            query = "SARS-CoV-2 COVID-19 immune dysregulation PubMed"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertEquals(QualityTierV3.D, node.qualityTier)
        assertTrue(node.limitations.contains("source_title_primary_topic_missing"))
    }

    private fun testNode(
        id: String,
        accession: String,
        role: EvidenceRoleV3,
        type: EvidenceTypeV3,
        tier: QualityTierV3
    ): EvidenceNodeV3 = EvidenceNodeV3(
        id = id,
        type = type,
        accession = accession,
        title = "Test evidence $id",
        source = if (accession.startsWith("GSE")) SourceKindV3.GEO else SourceKindV3.PUBMED,
        articleType = if (role == EvidenceRoleV3.CONTEXT) ArticleTypeV3.UNKNOWN else ArticleTypeV3.COHORT,
        role = role,
        qualityTier = tier
    )

}
