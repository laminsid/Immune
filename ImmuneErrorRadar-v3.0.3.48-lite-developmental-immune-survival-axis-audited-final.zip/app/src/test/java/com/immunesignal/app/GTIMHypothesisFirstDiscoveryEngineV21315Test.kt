package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMHypothesisFirstDiscoveryEngineV21315Test {
    @Test
    fun missingCanonicalStillEmitsC0Hypothesis() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Bundibugyo Ebola BDBV host response research dossier"))
            .put("finalBundibugyoSearchRuntimeClosureV213106", JSONObject()
                .put("activeDomain", "filovirus_viral_host_response")
                .put("activeSubtype", "viral_filovirus_bundibugyo")
                .put("canonicalTarget", ""))

        val hypothesis = GTIMHypothesisFirstDiscoveryEngineV21315.toJson(report)
        assertEquals("C0_ROUTE_HYPOTHESIS", hypothesis.getString("primaryResult"))
        assertTrue(hypothesis.getBoolean("hypothesisAllowed"))
        assertTrue(hypothesis.getBoolean("c2PreviewAllowed"))
        assertTrue(hypothesis.getBoolean("c3PreviewAllowed"))
        assertFalse(hypothesis.getBoolean("validatedProofAllowed"))
        assertTrue(hypothesis.getJSONArray("executionTasks").toString().contains("canonical_target_missing"))
        assertTrue(GTIMHypothesisFirstDiscoveryEngineV21315.publicLines(hypothesis).joinToString("\n").contains("Hypothesis:"))
    }

    @Test
    fun canonicalTargetUpgradesOnlyToC1NotEvidenceProof() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "allergy type-2 IgE mast eosinophil barrier study"))
            .put("finalUnifiedDiscoveryReadinessClosureV21310", JSONObject()
                .put("activeDomain", "allergy_type2_barrier")
                .put("activeSubtype", "viral_generic")
                .put("canonicalTarget", "GSE146170"))

        val hypothesis = GTIMHypothesisFirstDiscoveryEngineV21315.toJson(report)
        assertTrue(hypothesis.getString("primaryResult").startsWith("C1"))
        assertEquals("allergy_type2_or_barrier_microbiome", hypothesis.getString("activeSubtype"))
        assertTrue(hypothesis.getBoolean("c2PreviewAllowed"))
        assertTrue(hypothesis.getBoolean("c3PreviewAllowed"))
        assertFalse(hypothesis.getBoolean("validatedProofAllowed"))
        assertEquals(false, hypothesis.getBoolean("clinicalClaimAllowed"))
    }

    @Test
    fun domainScopedRendererHidesBundibugyoClosureForAllergy() {
        assertFalse(GTIMDomainScopedClosureRendererV21315.canRenderFirstSurface(
            "finalBundibugyoSearchRuntimeClosureV213106",
            "allergy_type2_barrier"
        ))
        assertTrue(GTIMDomainScopedClosureRendererV21315.canRenderFirstSurface(
            "finalBundibugyoSearchRuntimeClosureV213106",
            "filovirus_viral_host_response"
        ))
    }


    @Test
    fun legacyFirewallBlocksOldRenderTreeOnHypothesisFirstSurface() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "allergy type-2 barrier study"))
            .put("hypothesisFirstDiscoveryEngineV21315", JSONObject())
            .put("finalBundibugyoSearchRuntimeClosureV213106", JSONObject()
                .put("activeDomain", "filovirus_viral_host_response")
                .put("canonicalTarget", "GSE45291"))

        assertTrue(GTIMLegacyLeakFirewallV21316.shouldUseHypothesisFirstSurface(report))
        val lines = GTIMMobileSafeFirstSurfaceV21313.render(report)
        val joined = lines.joinToString("\n")
        assertFalse(joined.contains("Final Bundibugyo/BDBV search-runtime closure"))
        assertTrue(joined.contains("Legacy leak firewall"))
        assertTrue(joined.contains("Study Result Card"))
    }

    @Test
    fun studyResultCardDoesNotRebuildLegacyRenderLinesForFinalSurface() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("rawInput", "Bundibugyo Ebola BDBV host response research dossier"))
            .put("hypothesisFirstDiscoveryEngineV21315", JSONObject())
            .put("legacyLeakFirewallV21316", JSONObject())

        val card = GTIMStudyResultCardV2126.build(report, emptyList())
        assertTrue(card.status.contains("C0") || card.status.contains("hypothesis", ignoreCase = true))
    }

}
