package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMRuntimeCleanupV2156Test {
    @Test
    fun negativeProbeMarkersDoNotCloseProofGate() {
        val contract = ResearchRunContractV2150.create("Ebola bundibugyo")
            .withEvidenceHandle("metadata_probe_attempted_no_verified_dataset_yet_not_evidence")
            .withEvidenceHandle("comparator_probe_attempted_no_clear_sample_link_yet_not_evidence")
            .withEvidenceHandle("contradiction_probe_attempted_no_pubmed_hit_yet_not_evidence")
            .withEvidenceHandle("proof_gate_open_t7_contradiction_falsification_bounded_probe_done")
        assertFalse(ResearchExecutionPolicyV2154.hasClosedProofGate(contract))
        assertFalse(ResearchExecutionPolicyV2154.reportCanClose(contract))
        val gate = ResearchEvidenceGateV2156.gateState(contract.evidenceHandles)
        assertFalse(gate.closed)
        assertTrue(gate.negativeOrGapCount >= 3)
    }

    @Test
    fun positiveHandlesCloseOnlyTheMinimumRequiredGate() {
        val contract = ResearchRunContractV2150.create("Ebola bundibugyo")
            .withEvidenceHandle("source_handle_closed_pubmed_123456")
            .withEvidenceHandle("metadata_probe_executed_pubmed_234567")
            .withEvidenceHandle("contradiction_checked_pubmed_345678")
        assertTrue(ResearchExecutionPolicyV2154.hasClosedProofGate(contract))
        val gate = ResearchEvidenceGateV2156.gateState(contract.evidenceHandles)
        assertTrue(gate.hasSource)
        assertTrue(gate.hasProvenance)
        assertTrue(gate.hasContradiction)
        assertTrue(gate.closed)
    }

    @Test
    fun legacyContradictionMarkersRemainPositiveWhenTheyAreDiagnostic() {
        val contract = ResearchRunContractV2150.create("Ebola bundibugyo")
            .withEvidenceHandle("source_handle_closed_pubmed_or_geo")
            .withEvidenceHandle("sample_id_linked_metadata_verified")
            .withEvidenceHandle("contradiction_checked_wrong_tissue_species")
        assertTrue(ResearchExecutionPolicyV2154.hasClosedProofGate(contract))
        assertTrue(ResearchEvidenceGateV2156.gateState(contract.evidenceHandles).hasContradiction)
    }

    @Test
    fun stoppedRunExportsCheckpointWithoutPretendingFinalReport() {
        val report = ProfessionalResearchOrchestratorV2150.run(
            topic = "Ebola bundibugyo",
            shouldPause = { false },
            shouldStop = { true },
            onState = { _, _ -> },
            policy = ResearchExecutionPolicyV2154.unitTestNoFastFinish()
        )
        val contract = report.getJSONObject("researchRunContractV2150")
        assertTrue(contract.getString("status") == "STOPPED" || contract.getString("status") == "FAILED_SAFE")
        assertFalse(report.getJSONObject("proofGatedRuntimeV2154").getBoolean("reportCanClose"))
    }
}
