package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3ActivityBridgeTest {
    @Test
    fun activityBridgeWrapsV3ReportForUiAndExportWithoutNetwork() {
        val result = engineWith(staticCompleteAdapter()).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )

        val json = ResearchEngineV3ActivityBridge.toActivityJson(result, elapsedMs = 1234L)
        assertTrue(json.has("researchEngineV3"))
        assertTrue(json.has("researchEngineV3ActivityBridge"))
        assertTrue(json.has("researchRunContractV2150"))
        assertEquals("ResearchEngineV3", json.getJSONObject("researchEngineV3ActivityBridge").getString("activeEngine"))
        assertTrue(json.getJSONObject("researchEngineV3ActivityBridge").getBoolean("legacyProfessionalOrchestratorBypassed"))
        assertTrue(json.getJSONObject("researchEngineV3ActivityBridge").getBoolean("networkRunsOnDispatcherIO"))
        assertFalse(json.getJSONObject("researchEngineV3ActivityBridge").getBoolean("fallbackToV2150OnFailure"))

        val card = ResearchEngineV3ActivityBridge.renderUserCard(json)
        assertNotNull(card)
        assertTrue(card!!.contains("Research Engine V3"))
        assertTrue(card.contains("gap-driven loop"))
        assertTrue(card.contains("Legacy v2.15 task queue bypassed: true"))
    }

    @Test
    fun activityBridgeShowsExecutedExhaustedContradictionSearchForConditionalReportReady() {
        val result = engineWith(staticNoContradictionAdapter()).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        val json = ResearchEngineV3ActivityBridge.toActivityJson(result, elapsedMs = 700L)
        val v3 = json.getJSONObject("researchEngineV3")
        val closure = v3.getJSONObject("closure")
        val card = ResearchEngineV3ActivityBridge.renderUserCard(json).orEmpty()

        assertEquals("REPORT_READY", json.getString("status"))
        assertTrue(closure.getBoolean("contradictionObjectiveExecuted"))
        assertTrue(closure.getBoolean("contradictionObjectiveExhausted"))
        assertTrue(closure.getBoolean("noValidFalsifierFoundAfterSearch"))
        assertTrue(card.contains("Contradiction search executed/exhausted/found: true/true/false"))
        assertTrue(card.contains("Conditional closure"))
    }

    private fun engineWith(adapter: EvidenceAdapterV3): ResearchEngineV3 = ResearchEngineV3(
        executor = ResearchObjectiveExecutorV3(adapter = adapter)
    )

    private fun staticCompleteAdapter(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3("1001", "Bundibugyo Ebola host response mechanistic review", SourceKindV3.PUBMED)
            ),
            "transcriptome geo" to listOf(
                EvidenceSearchRecordV3("GSE2001", "Bundibugyo Ebola transcriptome GEO dataset cohort", SourceKindV3.GEO)
            ),
            "sample provenance" to listOf(
                EvidenceSearchRecordV3("GSE2002", "Bundibugyo Ebola sample provenance comparator labels cohort", SourceKindV3.GEO)
            ),
            "tissue comparator limitation" to listOf(
                EvidenceSearchRecordV3("3001", "Bundibugyo Ebola tissue comparator limitation cohort falsification study", SourceKindV3.PUBMED)
            )
        )
    )

    private fun staticNoContradictionAdapter(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3("1001", "Bundibugyo Ebola host response mechanistic review", SourceKindV3.PUBMED)
            ),
            "transcriptome geo" to listOf(
                EvidenceSearchRecordV3("GSE2001", "Bundibugyo Ebola transcriptome GEO dataset cohort", SourceKindV3.GEO)
            ),
            "sample provenance" to listOf(
                EvidenceSearchRecordV3("GSE2002", "Bundibugyo Ebola sample provenance comparator labels cohort", SourceKindV3.GEO)
            )
        )
    )
}
