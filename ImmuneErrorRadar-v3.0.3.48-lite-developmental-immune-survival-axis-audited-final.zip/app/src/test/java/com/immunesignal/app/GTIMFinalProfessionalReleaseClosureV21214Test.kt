package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalProfessionalReleaseClosureV21214Test {

    @Test
    fun finalClosureLinksOldAndNewRoutesWithoutAllowingClaims() {
        val report = baseReport("viral_interferon_cytokine", "COVID interferon IL-6 TNF", "GSE152202")
        report.put("reportProfessionalSurfaceSanityV21214", GTIMReportProfessionalSurfaceSanityV21214.toJson(report))
        report.put("finalProfessionalReleaseClosureV21214", GTIMFinalProfessionalReleaseClosureV21214.toJson(report))
        val closure = report.getJSONObject("finalProfessionalReleaseClosureV21214")

        assertEquals("FINAL_PROFESSIONAL_RESEARCH_RELEASE_READY", closure.optString("closureState"))
        assertEquals("OLD_AND_NEW_ROUTES_LINKED", closure.optString("routeLinkageState"))
        assertTrue(closure.optBoolean("discoveryContinuationRequired"))
        assertFalse(closure.optBoolean("claimPromotionAllowed"))
        assertFalse(closure.optBoolean("evidencePromotionAllowed"))
        assertTrue(closure.toString().contains("technical trace remains appendix-only"))
    }

    @Test
    fun surfaceSanityBlocksAllergyLeakInViralFirstSurface() {
        val report = baseReport("viral_interferon_cytokine", "Ebola virus interferon cytokine response", "GSE131907")
        report.put("finalGlobalStudyDossierV2127", JSONObject()
            .put("studyFocus", "allergy/type-2 microbiome-barrier study"))
        val surface = GTIMReportProfessionalSurfaceSanityV21214.toJson(report)

        assertEquals("PROFESSIONAL_SURFACE_NEEDS_REVIEW", surface.optString("surfaceState"))
        assertTrue(surface.optString("abstractRouteContamination").contains("allergy_type2_surface_leak"))
        assertTrue(surface.optBoolean("candidateVsVerifiedCapsuleSeparated"))
    }

    private fun baseReport(domain: String, route: String, handle: String): JSONObject {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("normalizedTopic", route).put("rawInput", route))
            .put("studyFocusNormalizerV21282", JSONObject().put("route", route).put("studyFocus", route))
            .put("externalRouterV211310", JSONObject().put("handle", handle))
            .put("matrixShortcutResolverV2124", JSONObject().put("shortcutHandle", handle))
            .put("matrixShortcutStatusLayerV2129", JSONObject().put("status", "QUEUED_PROCESSED_EXPRESSION_REVIEW"))
            .put("functionalRepairDossierV2120", JSONObject().put("repair", "research-only repair function"))
            .put("studyGradeFunctionalSolutionV2121", JSONObject().put("hypothesis", "research-only hypothesis"))
            .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", domain))
            .put("relaxedResearchLeadBridgeV2122", JSONObject().put("state", "D_PLUS_ACTIONABLE_LEAD"))
            .put("globalReportLearningV2124", JSONObject().put("state", "GLOBAL_LEARNING_ACTIVE"))
            .put("unifiedRouteReleaseContractV2125", JSONObject().put("state", "ROUTES_LINKED"))
            .put("studyResultCardV2126", JSONObject().put("studyFocus", route))
            .put("finalWorldStudyDossierV2128", JSONObject().put("state", "FINAL_WORLD_STUDY_DOSSIER_READY"))
            .put("finalResearchValueBoosterV212101", JSONObject().put("researchValueStatus", "usable lead"))
            .put("curatedMetadataSeedLibraryV21211", JSONObject().put("state", "CURATED_SEED_LOOKUP_READY"))
            .put("terminalDiscoveryContinuationV21212", JSONObject().put("state", "CONTINUE_AFTER_D_PLUS_WITH_REVIEW_TARGET"))
            .put("targetValidationCardV21213", JSONObject().put("state", "EXTERNAL_REVIEW_TARGET_SELECTED_NOT_EVIDENCE_YET"))
            .put("hypothesisVariantDiscriminatorV21213", JSONObject().put("state", "COMPETING_HYPOTHESES_REQUIRED"))
            .put("pharmaGradeStrictnessGateV21213", JSONObject()
                .put("state", "STRICT_PROMOTION_BLOCKED_DISCOVERY_CONTINUES")
                .put("discoveryMayContinue", true)
                .put("claimPromotionAllowed", false))
            .put("reportConsistencyGateV2121", JSONObject()
                .put("candidateLookupHandle", handle)
                .put("topicCompatibleTargetSelected", false)
                .put("verifiedMatrixFiles", 0))
        return report
    }
}
