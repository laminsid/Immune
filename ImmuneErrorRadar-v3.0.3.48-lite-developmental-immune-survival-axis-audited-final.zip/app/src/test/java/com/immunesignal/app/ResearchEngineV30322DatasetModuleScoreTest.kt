package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30322DatasetModuleScoreTest {
    @Test
    fun gse152522MetadataProbeProducesModuleScoreCardWithoutBroadSearch() {
        val target = ResearchMetadataProbeTargetV3(
            accession = "GSE152522",
            title = "Imbalance of regulatory and cytotoxic SARS-CoV-2-reactive CD4+ T cells in COVID-19",
            softUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE152522&targ=gsm&form=text",
            state = "METADATA_PROBE_READY_GSE152522_PROCESSED_EXPRESSION_ROUTE",
            comparatorStatus = "COMPARATOR_LABELS_REQUIRED_REVIEW_ONLY",
            processedExpressionRoute = "GREIN_OR_PROCESSED_EXPRESSION_ROUTE_CANDIDATE_REVIEW_ONLY",
            matrixStatus = "MATRIX_OR_PROCESSED_EXPRESSION_NOT_INGESTED",
            sampleMetadataStatus = "SOFT_METADATA_INGESTION_REQUIRED",
            expectedComparators = listOf("COVID severe vs mild/moderate", "COVID patient vs healthy control", "acute vs post-acute/recovery if labelled"),
            routeQuestions = listOf("Does metadata separate severe, mild and healthy controls?"),
            nextAction = "GSE152522: ingest SOFT sample metadata and map comparator labels.",
            boundary = "research-only"
        )
        val probe = ResearchMetadataProbeIngestionReportV3(
            active = true,
            state = "METADATA_PROBE_READY_GSE152522_PROCESSED_EXPRESSION_ROUTE",
            targets = listOf(target),
            primaryNextAction = target.nextAction,
            causalGap = "IFN timing remains separable until labels and expression signals are ingested.",
            commercialReadinessNote = "Discovery-card only.",
            boundary = "research-only"
        )
        val state = ResearchStateV3.initial(ResearchInputV3("sars-cov-2 covid-19 immune dysregulation interferon timing"))
        val card = ResearchDatasetModuleScoreV3.evaluate(state, probe)
        assertTrue(card.active)
        assertEquals("GSE152522", card.dataset)
        assertEquals("covid_gse152522", card.capsuleId)
        assertTrue(card.moduleScore >= 70)
        assertTrue(card.nextAction.contains("do not run broad PubMed/GEO expansion"))
        assertTrue(card.toJson().toString().contains("V30322") || ResearchDatasetModuleScoreV3.REQUIRED_TOKEN.contains("V30322"))
    }
}
