package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMProfessionalOrchestratorHardLockV2142Test {
    @Test
    fun professionalOrchestratorIsDefaultAndLegacyJsonRouteIsNotReachableByDefault() {
        assertTrue(GTIMProfessionalOrchestratorHardLockV2142.shouldUseProfessionalOrchestrator(
            professionalEnabled = true,
            allowLegacyMonolithicFallback = false
        ))
        assertTrue(GTIMProfessionalOrchestratorHardLockV2142.shouldUseProfessionalOrchestrator(
            professionalEnabled = false,
            allowLegacyMonolithicFallback = false
        ))
        assertFalse(GTIMProfessionalOrchestratorHardLockV2142.toJson(
            professionalEnabled = true,
            allowLegacyMonolithicFallback = false
        ).getBoolean("legacyRouteReachableByDefault"))
        assertEquals(
            "GTIMProfessionalResearchOrchestratorV2140",
            GTIMProfessionalOrchestratorHardLockV2142.toJson(true, false).getString("defaultRoute")
        )
    }
}
