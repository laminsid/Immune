package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30346HumanDatasetSupportCalibrationTest {
    private val neuroTopic = "gse85047 pediatric neuroblastoma mycn amplified vs non immune cold tumor microenvironment cd8 nk cytotoxicity"

    @Test
    fun egadHumanSingleCellRouteCountsAsResearchSupportButNotNumericDgeCertification() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "EGAD00001009766",
                title = "Profiling of childhood neuroblastoma by single-cell mRNA sequencing with tumor infiltrated tissue metastasis blood samples",
                source = SourceKindV3.UNKNOWN,
                abstractText = "Human pediatric childhood neuroblastoma single-cell mRNA sequencing dataset with tumor and immune compartment labels."
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = neuroTopic,
            query = "EGAD00001009766 childhood neuroblastoma single-cell compartment MYCN"
        )
        assertEquals(EvidenceRoleV3.DATASET, node.role)
        assertEquals("HUMAN", node.organismMatch)
        assertTrue(node.countsAsSupport)
        assertTrue(node.limitations.contains("v30346_human_pediatric_dataset_route_counts_as_research_support_not_numeric_dge_certification"))
        assertEquals("HUMAN_SINGLE_CELL_COMPARTMENT_ROUTE", HumanPediatricDiscoveryV30340.overrideFor("EGAD00001009766")?.sourceRole)
        assertEquals("COMPARTMENT_ROUTE_READY_NOT_NUMERIC_DGE", HumanPediatricDiscoveryV30340.overrideFor("EGAD00001009766")?.rowState)
    }

    @Test
    fun gse49710HumanReplicationCandidateCountsAsSupportButStillNeedsRowsForUpgrade() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "GSE49710",
                title = "Primary neuroblastoma expression profiling human patients with MYCN status risk labels",
                source = SourceKindV3.GEO,
                abstractText = "Human primary neuroblastoma cohort expression profiling with MYCN amplification and risk comparator labels."
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = neuroTopic,
            query = "GSE49710 neuroblastoma MYCN human expression profiling"
        )
        assertEquals(EvidenceRoleV3.DATASET, node.role)
        assertEquals("HUMAN", node.organismMatch)
        assertTrue(node.countsAsSupport)
        val role = HumanPediatricDiscoveryV30340.overrideFor("GSE49710")
        assertEquals("HUMAN_REPLICATION_CANDIDATE", role?.sourceRole)
        assertEquals("ROWS_NOT_EMBEDDED_ETL_OR_USER_MATRIX_REQUIRED", role?.rowState)
    }

    @Test
    fun mouseAndPedoncRemainContextOnlyForHumanPediatricQuestion() {
        val mouse = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "GSE299403",
                title = "Gene expression profile at single cell level of Mycn-nGEMM mouse neuroblastoma tumors and tumor microenvironment",
                source = SourceKindV3.GEO,
                abstractText = "Genetically engineered mouse neuroblastoma model with murine tumor microenvironment cells."
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = neuroTopic,
            query = "GSE299403 Mycn mouse neuroblastoma"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, mouse.role)
        assertEquals("MOUSE", mouse.organismMatch)
        assertFalse(mouse.countsAsSupport)

        val pedonc = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "PEDONC_SOURCE_MYCN_TME_002",
                title = "Curated prior: MYCN-driven neuroblastoma has low T-cell content and macrophage context",
                source = SourceKindV3.LOCAL_MEMORY,
                abstractText = "Curated pediatric oncology prior only."
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = neuroTopic,
            query = "PEDONC_SOURCE MYCN TME"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, pedonc.role)
        assertFalse(pedonc.countsAsSupport)
    }

    @Test
    fun mouseAllergyDatasetIsNotSupportForHumanAllergyQuestion() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "GSE271274",
                title = "Postnatal allergic inhalation induces glial inflammation in the olfactory bulb",
                source = SourceKindV3.GEO,
                abstractText = "Mouse allergic inhalation model and murine olfactory bulb transcriptome, not a human patient asthma cohort."
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = "allergy asthma atopy type inflammation airway eosinophil mast cell th2 ilc2 il4 il5 il13",
            query = "GSE271274 allergy asthma mouse olfactory bulb"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertFalse(node.countsAsSupport)
        assertTrue(node.limitations.contains("v30346_model_organism_dataset_context_only_requires_human_replication"))
    }

    @Test
    fun queryBiasKeepsHumanReplicationTargetsAheadOfMouseContext() {
        val queries = listOf(
            "neuroblastoma Mycn mouse tumor microenvironment GSE299403",
            "neuroblastoma MYCN compartment EGAD00001009766",
            "neuroblastoma MYCN expression GSE49710 TARGET-NBL"
        )
        val (ordered, bias) = DossierLearningQueryBiasV30328.apply(
            topic = neuroTopic,
            queries = queries,
            snapshot = EvidenceLedgerSnapshotV3(emptyList(), emptyList())
        )
        assertTrue(bias.promotedSignals.contains("GSE49710"))
        assertTrue(bias.promotedSignals.contains("TARGET-NBL"))
        assertTrue(ordered.take(2).any { it.contains("GSE49710") || it.contains("TARGET-NBL") })
    }
}
