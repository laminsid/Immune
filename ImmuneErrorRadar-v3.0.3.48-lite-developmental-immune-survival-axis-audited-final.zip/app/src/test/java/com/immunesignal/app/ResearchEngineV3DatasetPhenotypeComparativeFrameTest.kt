package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3DatasetPhenotypeComparativeFrameTest {
    @Test
    fun allergyRejectsRenalIschemiaDatasetAsTierA() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "GSE302163",
                title = "Repurposing Zafirlukast Confers Renal Protection in Ischemia-Reperfusion Injury via Suppressing Macrophage METosis [RNA-seq]",
                source = SourceKindV3.GEO,
                abstractText = "Renal ischemia reperfusion injury dataset with kidney samples and controls."
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = "allergy type inflammation IgE eosinophil mast cell atopy asthma",
            query = "allergic rhinitis eosinophil transcriptome GEO"
        )

        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertEquals(QualityTierV3.D, node.qualityTier)
        assertTrue(node.limitations.contains("relevance_dataset_phenotype_mismatch"))
    }

    @Test
    fun allergyDatasetRequiresAllergyPhenotypeCue() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "GSE999001",
                title = "Allergic rhinitis eosinophil transcriptome dataset with healthy controls",
                source = SourceKindV3.GEO,
                abstractText = "GEO RNA-seq dataset with allergic rhinitis patients, eosinophil signatures, samples, and healthy controls."
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = "allergy type inflammation IgE eosinophil mast cell atopy asthma",
            query = "allergic rhinitis eosinophil transcriptome GEO"
        )

        assertEquals(EvidenceRoleV3.DATASET, node.role)
        assertTrue(node.qualityTier.isAtLeast(QualityTierV3.B))
        assertFalse(node.limitations.contains("relevance_dataset_phenotype_mismatch"))
    }

    @Test
    fun comparativeAllowsDiseaseVsMechanismWhenBridgeExists() {
        val decision = ResearchIntentGateV3.evaluate("inflammation vs allergies comparative")
        assertTrue(decision.allowed)
        val queries = DomainQueryTemplateV3.sourceQueries("inflammation vs allergies comparative")
            .joinToString(" ")
            .lowercase()
        assertTrue(queries.contains("inflammation"))
        assertTrue(queries.contains("allerg"))
        assertTrue(queries.contains("immune comparison"))
    }

    @Test
    fun longevityCovidMapsLongevityToImmunosenescence() {
        val decision = ResearchIntentGateV3.evaluate("longevity vs covid covid-19 comparative")
        assertTrue(decision.allowed)
        val queries = DomainQueryTemplateV3.sourceQueries("longevity vs covid covid-19 comparative")
            .joinToString(" ")
            .lowercase()
        assertTrue(queries.contains("biological aging") || queries.contains("longevity") || queries.contains("immunosenescence"))
        assertTrue(queries.contains("covid"))
        assertTrue(queries.contains("immune comparison"))
    }

    @Test
    fun metabolicDiseaseRejectedWithRefinementSuggestions() {
        val decision = ResearchIntentGateV3.evaluate("metabolic disease")
        assertFalse(decision.allowed)
        assertEquals("disease_only_topic_requires_mechanism_axis", decision.reason)
        assertTrue(decision.refinementSuggestions.any { it.contains("insulin resistance", ignoreCase = true) })
    }
}
