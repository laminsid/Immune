package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMThymicCyberneticLayerV21320Test {
    @Test
    fun thymicAndCyberneticCardsStayResearchOnlyAndSurfaceLinked() {
        val report = JSONObject()
            .put("topic", "longevity thymic rejuvenation immune age vagus nerve bioelectronic immune modulation")
            .put("activeDomain", "immune_age_longevity")
        val text = GTIMFinalActiveDecisionSurfaceV21317.renderLines(report).joinToString("\n")
        assertTrue(text.contains("Thymic rejuvenation / cybernetic immunology card"))
        assertTrue(text.contains("Final thymic rejuvenation + cybernetic immunology closure"))
        assertTrue(text.contains("FOXN1") || text.contains("naive_T_cell"))
        assertTrue(text.contains("vagus") || text.contains("closed_loop"))
        assertTrue(text.contains("sandbox preview allowed") || text.contains("C0/C1/C2/C3 sandbox preview allowed"))
        assertTrue(text.contains("no guaranteed rejuvenation"))
        assertTrue(text.contains("no instant cytokine-storm shutdown claim"))
        assertTrue(text.contains("no 100% safety claim"))
        assertFalse(text.contains("treatment recommendation allowed=true"))
        assertFalse(text.contains("device recommendation allowed=true"))
    }

    @Test
    fun closureBlocksDeviceTreatmentDosingAndClinicalImplementationClaims() {
        val closure = GTIMFinalThymicCyberneticClosureV21320.toJson(JSONObject().put("topic", "cybernetic immunology optogenetic switchable immunity"))
        assertTrue(closure.optBoolean("sandbox_preview_allowed"))
        assertFalse(closure.optBoolean("rejuvenation_proof_allowed"))
        assertFalse(closure.optBoolean("instant_cytokine_shutdown_claim_allowed"))
        assertFalse(closure.optBoolean("safety_100_percent_claim_allowed"))
        assertFalse(closure.optBoolean("device_or_patient_action_allowed"))
        assertFalse(closure.optBoolean("treatment_or_dosing_allowed"))
        assertFalse(closure.optBoolean("clinical_implementation_allowed"))
    }
}
