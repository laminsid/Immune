package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalMicrobiomeCellDeathDamageClosureV213192Test {
    @Test
    fun finalClosureConnectsMicrobiomeAndCellDeathLayersToSurface() {
        val report = JSONObject().put("topic", "cancer microbiome NETosis thromboinflammation immunotherapy research")
        val closure = GTIMFinalMicrobiomeCellDeathDamageClosureV213192.toJson(report)
        val text = GTIMFinalActiveDecisionSurfaceV21317.renderLines(report).joinToString("\n")
        assertTrue(closure.getBoolean("microbiome_role_card_present"))
        assertTrue(closure.getBoolean("cell_death_netosis_panoptosis_card_present"))
        assertTrue(text.contains("Final microbiome + cell-death immune-damage closure"))
        assertTrue(text.contains("Microbiome role card"))
        assertTrue(text.contains("Cell-death / NETosis role card"))
    }

    @Test
    fun finalClosureBlocksDiagnosisTreatmentAndProofClaims() {
        val report = JSONObject().put("topic", "sepsis organ failure NET biomarker anti-NET DNase hypothesis")
        val closure = GTIMFinalMicrobiomeCellDeathDamageClosureV213192.toJson(report)
        val text = GTIMFinalMicrobiomeCellDeathDamageClosureV213192.renderLines(report).joinToString("\n")
        assertFalse(closure.getBoolean("validated_proof_allowed"))
        assertFalse(closure.getBoolean("diagnosis_allowed"))
        assertFalse(closure.getBoolean("treatment_allowed"))
        assertFalse(closure.getBoolean("dosing_allowed"))
        assertTrue(text.contains("NET signal != diagnosis"))
        assertTrue(text.contains("DNase/anti-NET modality lens != treatment recommendation"))
    }

    @Test
    fun finalClosurePreservesC2C3SandboxPreviewPolicy() {
        val report = JSONObject().put("topic", "hantavirus lung injury PANoptosis NETosis microbiome research")
        val closure = GTIMFinalMicrobiomeCellDeathDamageClosureV213192.toJson(report)
        assertTrue(closure.getString("sandbox_preview_policy").contains("C0_C1_C2_C3_ALLOWED"))
        assertTrue(closure.getString("legacy_policy").contains("appendix"))
    }
}
