package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMRuntimeProgressStructuralImmunityV21324Test {
    @Test
    fun sixMinuteBudgetAndProgressPlanAreVisibleAndResearchOnly() {
        val budget = GTIMMobileSearchRuntimeBudgetV21322.fromDeepeningLimits(
            GTIMDeepeningRunLimitsV2123(
                maxSearchMillis = 1_200_000L,
                maxLearningMillis = 2_700_000L,
                maxQueries = 99,
                maxResultsPerQuery = 99,
                fetchAbstracts = true,
                enableSelectiveAbstracts = true,
                maxAbstractsPerCycle = 99
            )
        )

        assertEquals(360_000L, budget.firstVisibleReportMillis)
        assertEquals(600_000L, budget.hardTimeoutMillis)
        assertEquals(12, budget.maxQueries)
        assertEquals(24, budget.maxResultsPerQuery)
        assertEquals(5, budget.maxAbstractsPerCycle)

        val progress = GTIMAgenticProgressPlanV21324.toJson(
            budget = budget,
            elapsedMillis = 180_000L,
            lastSafeStage = "EXTERNAL_SEARCH"
        )
        assertTrue(progress.optInt("percent") in 25..35)
        assertEquals("EXTERNAL_SEARCH", progress.optString("lastSafeStage"))
        assertTrue(progress.optString("claimLimit").contains("not_evidence_strength"))
    }

    @Test
    fun structuralImmunityLayerStaysResearchOnlyAndSurfaceLinked() {
        val report = JSONObject().put("topic", "psoriasis fibroblast epithelial endothelial structural immunity single-cell tissue memory fibrosis")
        val cardText = GTIMStructuralImmunitySurfaceCardV21324.renderLines(report).joinToString("\n")
        val closure = GTIMFinalStructuralImmunityClosureV21324.toJson(report)
        val finalSurface = GTIMFinalActiveDecisionSurfaceV21317.renderText(report)

        assertTrue(cardText.contains("Structural immunity / non-immune cell immune-code card"))
        assertTrue(cardText.contains("fibroblast"))
        assertTrue(cardText.contains("single-cell") || cardText.contains("single_cell"))
        assertTrue(cardText.contains("tissue-targeted therapy proof"))
        assertEquals("FINAL_STRUCTURAL_IMMUNITY_CLOSURE_READY", closure.optString("state"))
        assertFalse(closure.optBoolean("tissue_therapy_claim_allowed"))
        assertFalse(closure.optBoolean("fibrosis_reversal_claim_allowed"))
        assertFalse(closure.optBoolean("clinical_implementation_allowed"))
        assertTrue(finalSurface.contains("Structural immunity / non-immune cell immune-code card"))
        assertTrue(finalSurface.contains("Final structural immunity + non-immune cell code closure"))
    }
}
