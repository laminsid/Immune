package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Test

class GTIMReviewableVisibleEvidenceV2161Test {
    @Test
    fun genericClosedMarkersDoNotBecomeReportReadyEligible() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
            .withEvidenceHandle("source_handle_closed_pubmed_or_geo")
            .withEvidenceHandle("sample_id_linked_metadata_verified")
            .withEvidenceHandle("contradiction_checked_wrong_tissue_species")
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }

        assertTrue("Legacy proof-gate compatibility remains available", ResearchExecutionPolicyV2154.hasClosedProofGate(contract))
        assertFalse("Production REPORT_READY must require reviewable accessions", ResearchExecutionPolicyV2154.reportCanClose(contract))
        val audit = ResearchVisibleEvidenceAuditV2161.evaluate(contract)
        assertFalse(audit.reportReadyEligible)
        assertTrue(audit.invalidReasons.contains("missing_reviewable_source_accession"))
    }

    @Test
    fun numericPubmedEvidenceCanBecomeReportReadyEligible() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
            .withEvidenceHandle("source_handle_closed_pubmed_111")
            .withEvidenceHandle("metadata_probe_executed_pubmed_222")
            .withEvidenceHandle("sample_probe_executed_pubmed_223")
            .withEvidenceHandle("contradiction_checked_pubmed_333")
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }

        val proof = ResearchProofContractV2160.fromContract(contract)
        val audit = ResearchVisibleEvidenceAuditV2161.evaluate(proof)
        assertTrue(proof.isClosed())
        assertTrue(audit.reportReadyEligible)
        assertTrue(ResearchExecutionPolicyV2154.reportCanClose(contract))
        assertEquals(proof.visibleEvidenceCount(), proof.displayedEvidenceLineCount())
    }

    @Test
    fun userCardDowngradesReportReadyWhenVisibleEvidenceIsNotReviewable() {
        var contract = ResearchRunContractV2150.create("Ebola bundibugyo")
            .withStatus(ResearchRunStatusV2150.REPORT_READY)
            .withEvidenceHandle("source_handle_closed_pubmed_or_geo")
            .withEvidenceHandle("sample_id_linked_metadata_verified")
            .withEvidenceHandle("contradiction_checked_wrong_tissue_species")
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }
        val report = ResearchBriefBuilderV2150.buildReport(contract, "reviewable_evidence_test")
        val card = ResearchBriefBuilderV2150.renderUserCard(report).orEmpty()
        assertTrue(card.contains("CHECKPOINT_READY_REVIEWABLE_EVIDENCE_MISSING"))
        assertTrue(card.contains("missing_reviewable_source_accession"))
    }

    @Test
    fun v3CheckpointWhenVisibleEvidenceIsDisplayedButNotReviewable() {
        val result = ResearchRuntimeV3.executeFromHandles(
            query = "Ebola bundibugyo",
            evidenceHandles = listOf(
                "source_handle_closed_pubmed_or_geo",
                "sample_id_linked_metadata_verified",
                "contradiction_checked_wrong_tissue_species"
            ),
            elapsedMs = 70_000L
        )
        assertTrue(result is ResearchRuntimeV3.Result.CheckpointReady)
    }
}
