package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30347FullMatrixOpenDiscoveryReadinessTest {
    @Test
    fun liteGse85047RowsKeepContinuationFuelButBlockOpenDiscovery() {
        val state = ResearchStateV3.initial(
            ResearchInputV3(
                topic = "gse85047 pediatric neuroblastoma mycn amplified immune cold cd8 nk",
                explicitMatrixRows = PediatricOncologyExplicitMatrixV30337.rows(),
                explicitMatrixProvenance = PediatricOncologyExplicitMatrixV30337.SOURCE_ACCESSION,
                explicitCaseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                explicitControlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels
            )
        )
        val signal = ProcessedExpressionSignalReportV30329(
            active = true,
            state = "PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_EXECUTED_REVIEW_ONLY",
            dataset = "GSE85047",
            moduleCount = 1,
            rawMatrixDgeExecuted = true,
            estimates = emptyList(),
            nextAction = "attach full matrix",
            matrixFuel = MatrixFuelSnapshotV30330(
                state = "MATRIX_FUEL_READY_FOR_RAW_DGE_V30331",
                accession = "GSE85047",
                rowCount = 12,
                caseRowCount = 6,
                controlRowCount = 6,
                source = "declared_source_lite_rows",
                groupResolution = ComparatorGroupResolutionV30330(
                    state = "COMPARATOR_GROUP_VALUES_RESOLVED_FROM_DECLARED_MYCN_LABELS",
                    accession = "GSE85047",
                    caseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                    controlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels,
                    unresolvedAxis = "MYCN_amplified_vs_non_amplified",
                    source = "declared_labels"
                ),
                warnings = emptyList(),
                matrixFuelSourceAccession = "GSE85047",
                dgeExecutedOnAccession = "GSE85047",
                retrievalEvidenceBestAccession = "GSE85047"
            )
        )

        val report = OpenDiscoveryReadinessControllerV30347.evaluate(state.input.topic, state, signal)

        assertTrue(report.active)
        assertEquals("OPEN_DISCOVERY_BLOCKED_LITE_CONTINUATION_ACTIVE", report.state)
        assertEquals("LIGHT_MATRIX_ONLY_DISCOVERY_BLOCKED_CONTINUATION_FUEL_READY", report.fullMatrixGate.state)
        assertFalse(report.fullMatrixGate.openDiscoveryAllowed)
        assertTrue(report.fullMatrixGate.liteContinuationFuelReady)
        assertTrue(report.fullMatrixGate.continuationFuel.any { it.contains("283") })
        assertEquals("SMOKE_TEST_SIGNAL_ONLY_NOT_SUBCOHORT_DISCOVERY", report.intraMycnSubcohort.state)
        assertEquals("WAITING_FOR_DATA_DERIVED_GENE_LIST_FROM_FULL_MATRIX", report.zeroLiteratureBridge.state)
        assertEquals("PARTNER_GENE_DISCOVERY_BLOCKED_LIGHT_MATRIX_ONLY", report.partnerGeneDiscovery.state)
        assertTrue(report.signatureReversal.contextGuard.contains("CMAP_CONTEXT_NOT_PEDIATRIC_NEUROBLASTOMA"))
    }

    @Test
    fun fullGse85047ScaleRowsUnlockOpenDiscoveryComputationButNotClinicalClaims() {
        val rows = buildList {
            repeat(120) { idx -> add(ExpressionSampleRowV30329("MYCN_$idx", "case_mycn_amplified", mapOf("MYCN" to 6.0, "CD8A" to 2.5, "NKG7" to 2.7, "GZMB" to 2.6))) }
            repeat(163) { idx -> add(ExpressionSampleRowV30329("NON_$idx", "control_non_mycn", mapOf("MYCN" to 3.0, "CD8A" to 4.7, "NKG7" to 4.9, "GZMB" to 4.8))) }
        }
        val state = ResearchStateV3.initial(
            ResearchInputV3(
                topic = "GSE85047 neuroblastoma MYCN immune cold",
                explicitMatrixRows = rows,
                explicitMatrixProvenance = "GSE85047",
                explicitCaseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                explicitControlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels
            )
        )
        val signal = ProcessedExpressionSignalReportV30329(
            active = true,
            state = "FULL_MATRIX_REVIEW_SIGNAL_READY",
            dataset = "GSE85047",
            moduleCount = 1,
            rawMatrixDgeExecuted = true,
            estimates = listOf(ModuleSignalEstimateV30329(
                accession = "GSE85047",
                module = "MYCN_CD8_NK",
                markers = listOf("MYCN", "CD8A", "NKG7", "GZMB"),
                effectDirection = "mycn_cold",
                effectSize = -1.5,
                confidenceInterval = "review_only",
                pValueLabel = "review_only",
                statisticState = "FULL_MATRIX_REVIEW_ONLY",
                rawMatrixDgeExecuted = true,
                computedFrom = "explicit_full_matrix_rows",
                supportState = "MECHANISM_SIGNAL_SUPPORTED_BY_RAW_MATRIX"
            )),
            nextAction = "run open discovery",
            matrixFuel = MatrixFuelSnapshotV30330(
                state = "MATRIX_FUEL_READY_FOR_RAW_DGE",
                accession = "GSE85047",
                rowCount = 283,
                caseRowCount = 120,
                controlRowCount = 163,
                source = "explicit_full_matrix_rows",
                groupResolution = ComparatorGroupResolutionV30330(
                    state = "COMPARATOR_GROUP_VALUES_RESOLVED_FROM_DECLARED_MYCN_LABELS",
                    accession = "GSE85047",
                    caseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                    controlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels,
                    unresolvedAxis = "MYCN_amplified_vs_non_amplified",
                    source = "declared_labels"
                ),
                warnings = emptyList(),
                matrixFuelSourceAccession = "GSE85047",
                dgeExecutedOnAccession = "GSE85047",
                retrievalEvidenceBestAccession = "GSE85047"
            )
        )

        val report = OpenDiscoveryReadinessControllerV30347.evaluate(state.input.topic, state, signal)

        assertEquals("OPEN_DISCOVERY_READY_RESEARCH_ONLY", report.state)
        assertTrue(report.fullMatrixGate.openDiscoveryAllowed)
        assertEquals("INTRA_MYCN_SUBCOHORT_MINER_READY", report.intraMycnSubcohort.state)
        assertEquals("PUBMED_GAP_SCAN_RATE_LIMITED_CACHED_READY", report.zeroLiteratureBridge.state)
        assertEquals("PARTNER_GENE_DISCOVERY_READY_FULL_MATRIX_REQUIRED", report.partnerGeneDiscovery.state)
        assertEquals("SIGNATURE_REVERSAL_REPURPOSING_HYPOTHESIS_RESEARCH_ONLY_NOT_TREATMENT_RECOMMENDATION", report.signatureReversal.allowedLabel)
    }
}
