package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMInnovationExecutionBridgeV2138Test {
    @Test
    fun staleSurfaceGuardSupersedesLegacyCandidateAndExportsZeroStaleItems() {
        val report = allergyReport()
        attachBase(report)
        report.put("matrixShortcutResolverV2124", JSONObject().put("handle", "GSE250594"))
        report.put("legacyCandidateSupersessionGuardV2138", GTIMLegacyCandidateSupersessionGuardV2138.toJson(report))
        val export = GTIMStaleSurfaceZeroExportGuardV2138.toJson(report)
        assertEquals("GSE146170", export.getString("canonicalTarget"))
        assertEquals(0, export.getInt("staleSurfaceItems"))
        assertTrue(export.getString("state").contains("STALE_SURFACE_ZERO"))
    }

    @Test
    fun moduleScorePlaceholdersBlockC2ButEnableExecutionBridge() {
        val report = depressionReport()
        attachBase(report)
        attachInnovation(report)
        report.put("moduleScorePlaceholderEngineV2138", GTIMModuleScorePlaceholderEngineV2138.toJson(report))
        val upgrade = GTIMC1ToC2UpgradePathwayV2138.toJson(report)
        assertTrue(report.getJSONObject("moduleScorePlaceholderEngineV2138").getJSONArray("moduleScoreRows").length() > 0)
        assertTrue(upgrade.getJSONArray("upgradeBlockers").toString().contains("negative_control_not_executed"))
        assertFalse(upgrade.getString("claimLimit").contains("proof"))
    }

    @Test
    fun finalInnovationExecutionBridgeKeepsClaimsCandidateOnly() {
        val report = viralReport()
        attachBase(report)
        attachInnovation(report)
        attachV2138(report)
        val closure = GTIMFinalInnovationExecutionClosureV2138.toJson(report)
        assertTrue(closure.getString("state").contains("FINAL_INNOVATION_EXECUTION"))
        assertEquals(true, closure.getBoolean("claimPromotionAllowed"))
        assertTrue(closure.getString("strictnessPolicy").contains("C2_C3"))
    }

    private fun allergyReport(): JSONObject = JSONObject()
        .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "allergy_type2_barrier"))
        .put("verifiedMetadataClosurePackV2132", JSONObject().put("state", "VERIFIED_METADATA_CLOSURE_READY").put("selectedClosedTarget", "GSE146170"))
        .put("finalDataClosureExecutionV2132", JSONObject().put("readinessScore", 10).put("selectedClosedTarget", "GSE146170"))

    private fun depressionReport(): JSONObject = JSONObject()
        .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "depression_kynurenine_neuroimmune"))
        .put("verifiedMetadataClosurePackV2132", JSONObject().put("state", "VERIFIED_METADATA_CLOSURE_READY").put("selectedClosedTarget", "GSE102556"))
        .put("finalDataClosureExecutionV2132", JSONObject().put("readinessScore", 10).put("selectedClosedTarget", "GSE102556"))

    private fun viralReport(): JSONObject = JSONObject()
        .put("domainSpecificHypothesisSelectorV2129", JSONObject().put("domainKey", "viral_interferon_cytokine"))
        .put("verifiedMetadataClosurePackV2132", JSONObject().put("state", "VERIFIED_METADATA_CLOSURE_READY").put("selectedClosedTarget", "GSE166552"))
        .put("finalDataClosureExecutionV2132", JSONObject().put("readinessScore", 8).put("selectedClosedTarget", "GSE166552"))

    private fun attachBase(report: JSONObject) {
        report.put("activeDomainConsistencyGuardV2134", GTIMActiveDomainConsistencyGuardV2134.toJson(report))
        report.put("canonicalFinalSurfaceGuardV2135", GTIMCanonicalFinalSurfaceGuardV2135.toJson(report))
        report.put("futureEvidenceLiteCorpusV2130", GTIMFutureEvidenceLiteCorpusV2130.toJson(report))
        report.put("processedCapsuleStoreV2135", GTIMProcessedCapsuleStoreV2135.toJson(report))
        report.put("immuneModuleSignalEngineV2135", GTIMImmuneModuleSignalEngineV2135.toJson(report))
        report.put("discoveryExecutionEnginesV2135", GTIMDiscoveryExecutionEnginesV2135.toJson(report))
        report.put("discoveryClaimLadderV2135", GTIMDiscoveryClaimLadderV2135.toJson(report))
        report.put("discoveryCandidateAssemblerV2135", GTIMDiscoveryCandidateAssemblerV2135.toJson(report))
    }

    private fun attachInnovation(report: JSONObject) {
        report.put("signalSurpriseEngineV2137", GTIMSignalSurpriseEngineV2137.toJson(report))
        report.put("cellTissueSpecificityEngineV2137", GTIMCellTissueSpecificityEngineV2137.toJson(report))
        report.put("immunePhaseEngineV2137", GTIMImmunePhaseEngineV2137.toJson(report))
        report.put("hypothesisMutationEngineV2137", GTIMHypothesisMutationEngineV2137.toJson(report))
        report.put("mechanismCompetitionArenaV2137", GTIMMechanismCompetitionArenaV2137.toJson(report))
        report.put("c2AutoReplicationEngineV2137", GTIMC2AutoReplicationEngineV2137.toJson(report))
        report.put("crossDiseaseImmuneConvergenceEngineV2137", GTIMCrossDiseaseImmuneConvergenceEngineV2137.toJson(report))
        report.put("drugVaccineMechanismTriangulationV2137", GTIMDrugVaccineMechanismTriangulationV2137.toJson(report))
        report.put("discoveryNoveltyMinerV2137", GTIMDiscoveryNoveltyMinerV2137.toJson(report))
        report.put("discoverySynthesisCardV2137", GTIMDiscoverySynthesisCardV2137.toJson(report))
        report.put("finalInnovationDiscoveryClosureV2137", GTIMFinalInnovationDiscoveryClosureV2137.toJson(report))
    }

    private fun attachV2138(report: JSONObject) {
        report.put("legacyCandidateSupersessionGuardV2138", GTIMLegacyCandidateSupersessionGuardV2138.toJson(report))
        report.put("staleSurfaceZeroExportGuardV2138", GTIMStaleSurfaceZeroExportGuardV2138.toJson(report))
        report.put("moduleScorePlaceholderEngineV2138", GTIMModuleScorePlaceholderEngineV2138.toJson(report))
        report.put("c1ToC2UpgradePathwayV2138", GTIMC1ToC2UpgradePathwayV2138.toJson(report))
        report.put("nonObviousExperimentDesignerV2138", GTIMNonObviousExperimentDesignerV2138.toJson(report))
        report.put("innovationPortfolioRankerV2138", GTIMInnovationPortfolioRankerV2138.toJson(report))
    }
}
