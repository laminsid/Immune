package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30339HumanPediatricMatrixTruthTest {
    @Test
    fun pediatricMatrixFuelTruthUsesGse85047AsDgeSourceNotMouseRetrievalDataset() {
        val fuel = MatrixFuelSnapshotV30330(
            state = "MATRIX_FUEL_READY_FOR_RAW_DGE_V30331",
            accession = "GSE85047",
            rowCount = 12,
            caseRowCount = 6,
            controlRowCount = 6,
            source = "pediatric_oncology_declared_source_gse85047_matrix_rows_v30337",
            groupResolution = ComparatorGroupResolutionV30330(
                state = "COMPARATOR_GROUP_VALUES_RESOLVED_V30337_PEDIATRIC_ONCOLOGY_DECLARED_MATRIX_LABELS",
                accession = "GSE299403",
                caseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                controlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels,
                unresolvedAxis = "mycn_amplified_vs_non_mycn",
                source = "test"
            ),
            warnings = listOf("v30339_matrix_source_truth_separates_gse85047_dge_fuel_from_retrieval_evidence_GSE299403"),
            certificationLevel = PediatricOncologyExplicitMatrixV30337.CERTIFICATION_LEVEL,
            analysisMode = "USER_ATTESTED_DGE",
            scientificInterpretability = "MODERATE_SINGLE_DATASET_RESEARCH_ONLY_NOT_INDEPENDENTLY_VERIFIED",
            fuelOrigin = PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN,
            verificationLevel = PediatricOncologyExplicitMatrixV30337.VERIFICATION_LEVEL,
            signalValidity = "USER_ATTESTED_SINGLE_DATASET_RESEARCH_ONLY_NOT_VERIFIED",
            matrixFuelSourceAccession = "GSE85047",
            dgeExecutedOnAccession = "GSE85047",
            retrievalEvidenceBestAccession = "GSE299403",
            moduleNameAccession = "GSE85047",
            organismPriorityState = "HUMAN_PEDIATRIC_DECLARED_MATRIX_PRIORITY_MOUSE_EVIDENCE_CONTEXT_ONLY",
            seedIndependenceState = "SEEDED_PEDONC_MECHANISM_NODES_CONTEXT_ONLY_NOT_INDEPENDENT_SUPPORT",
            nullResultState = "PENDING_DGE_STATISTICAL_NULL_LEDGER_EVALUATION"
        )
        assertEquals("GSE85047", fuel.matrixFuelSourceAccession)
        assertEquals("GSE85047", fuel.dgeExecutedOnAccession)
        assertEquals("GSE299403", fuel.retrievalEvidenceBestAccession)
        assertFalse(fuel.certifiedForDiscovery)
    }

    @Test
    fun humanPediatricTruthGeneratesNovelNullAwareHypothesesButBlocksUpgrade() {
        val topic = "in GSE85047 do MYCN-amplified neuroblastoma tumors show colder immune microenvironment"
        val rows = PediatricOncologyExplicitMatrixV30337.rows()
        val computed = ProcessedExpressionMatrixCalculatorV30329.calculate(
            rows = rows,
            caseGroups = PediatricOncologyExplicitMatrixV30337.caseLabels,
            controlGroups = PediatricOncologyExplicitMatrixV30337.controlLabels,
            markers = PediatricOncologyExplicitMatrixV30337.markers
        )
        val fuel = MatrixFuelSnapshotV30330(
            state = "MATRIX_FUEL_READY_FOR_RAW_DGE_V30331",
            accession = "GSE85047",
            rowCount = rows.size,
            caseRowCount = 6,
            controlRowCount = 6,
            source = "pediatric_oncology_declared_source_gse85047_matrix_rows_v30337",
            groupResolution = ComparatorGroupResolutionV30330(
                state = "COMPARATOR_GROUP_VALUES_RESOLVED_V30337_PEDIATRIC_ONCOLOGY_DECLARED_MATRIX_LABELS",
                accession = "GSE85047",
                caseLabels = PediatricOncologyExplicitMatrixV30337.caseLabels,
                controlLabels = PediatricOncologyExplicitMatrixV30337.controlLabels,
                unresolvedAxis = "mycn_amplified_vs_non_mycn",
                source = "test"
            ),
            warnings = emptyList(),
            certificationLevel = PediatricOncologyExplicitMatrixV30337.CERTIFICATION_LEVEL,
            analysisMode = "USER_ATTESTED_DGE",
            scientificInterpretability = "MODERATE_SINGLE_DATASET_RESEARCH_ONLY_NOT_INDEPENDENTLY_VERIFIED",
            fuelOrigin = PediatricOncologyExplicitMatrixV30337.FUEL_ORIGIN,
            verificationLevel = PediatricOncologyExplicitMatrixV30337.VERIFICATION_LEVEL,
            signalValidity = "USER_ATTESTED_SINGLE_DATASET_RESEARCH_ONLY_NOT_VERIFIED",
            matrixFuelSourceAccession = "GSE85047",
            dgeExecutedOnAccession = "GSE85047",
            retrievalEvidenceBestAccession = "GSE85047",
            moduleNameAccession = "GSE85047",
            organismPriorityState = "HUMAN_PEDIATRIC_DECLARED_MATRIX_PRIORITY_MOUSE_EVIDENCE_CONTEXT_ONLY",
            seedIndependenceState = "SEEDED_PEDONC_MECHANISM_NODES_CONTEXT_ONLY_NOT_INDEPENDENT_SUPPORT",
            nullResultState = "PENDING_DGE_STATISTICAL_NULL_LEDGER_EVALUATION"
        )
        val expression = ProcessedExpressionSignalReportV30329(
            active = true,
            state = "PEDIATRIC_ONCOLOGY_DECLARED_SOURCE_DGE_EXECUTED_REVIEW_ONLY",
            dataset = "GSE85047",
            moduleCount = 1,
            rawMatrixDgeExecuted = true,
            estimates = listOf(
                ModuleSignalEstimateV30329(
                    accession = "GSE85047",
                    module = PediatricOncologyExplicitMatrixV30337.module().name,
                    markers = PediatricOncologyExplicitMatrixV30337.markers,
                    effectDirection = "case_downregulated_or_module_depleted",
                    effectSize = computed.map { it.effectSize }.average(),
                    confidenceInterval = "module_marker_range_95CI=[${computed.minOf { it.ciLow }}, ${computed.maxOf { it.ciHigh }}]",
                    pValueLabel = "marker_best_bonferroni_adjusted_p=${computed.minOf { it.adjustedPValue }}",
                    statisticState = "RAW_MATRIX_WELCH_T_DGE_WITH_BONFERRONI_MARKER_CORRECTION_V30333_CI_PVALUE_LEVELS_EXPLICIT",
                    rawMatrixDgeExecuted = true,
                    computedFrom = "sample_level_expression_rows:GSE85047",
                    supportState = "PEDIATRIC_ONCOLOGY_DIRECTIONAL_NULL_RAW_DGE_REVIEW_NOT_MECHANISM_SUPPORT",
                    markerResults = computed
                )
            ),
            nextAction = "review only",
            matrixFuel = fuel
        )
        val truth = HumanPediatricMatrixTruthV30339.evaluate(topic, ResearchStateV3.initial(ResearchInputV3(topic)), expression)
        assertTrue(truth.active)
        assertEquals("MATRIX_SOURCE_TRUTH_CLEAN", truth.sourceTruthState)
        assertTrue(truth.nullResultState.contains("NULL") || truth.nullResultState.contains("UNSTABLE"))
        assertTrue(truth.generatedHypotheses.any { it.id == "H1_NULL_AWARE_MYCN_NOT_SUFFICIENT" })
        assertTrue(truth.upgradeBlockers.contains("matrix_not_certified_or_replicated"))
    }
}
