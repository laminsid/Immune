package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMAgenticControlPanelV2143Test {
    @Test
    fun controlPanelExposesStartPauseContinueStopWithoutVisibleCountdown() {
        val json = GTIMAgenticControlPanelV2143.toJson(
            state = "running",
            lastCheckpoint = "V2140_THINK_SYNTHESIS",
            topic = "Covid"
        )
        assertEquals("2.14.3-agentic-manual-controls-no-visible-duration", json.optString("version"))
        assertEquals("no_user_facing_countdown", json.optString("visibleDurationPolicy"))
        assertFalse(json.optBoolean("legacyMonolithicRouteDefault", true))
        val controls = json.optJSONArray("controls")!!.join(" ")
        assertTrue(controls.contains("Start"))
        assertTrue(controls.contains("Pause"))
        assertTrue(controls.contains("Continue"))
        assertTrue(controls.contains("Stop"))
    }

    @Test
    fun fastLocalPassesBecomeTopicSpecificForUploadedExamples() {
        fun run(topic: String): org.json.JSONObject {
            val plan = GTIMSameTopicDeepeningBridgeV2123.build(topic, topic, emptyList())
            return GTIMProfessionalResearchOrchestratorV2140.runMobilePass(
                snapshot = RuntimeCrashSafetyAndTopicGuardV2740.capture(topic),
                budget = GTIMMobileSearchRuntimeBudgetV21322.fromDeepeningLimits(plan.runLimits),
                sameTopicPlan = plan,
                recentReportLines = emptyList(),
                onPhase = {}
            )
        }
        val ebola = run("Ebola bundibugyo raw count matrix sample ID linkage case control metadata processed expression")
        val covid = run("Covid")
        val cancer = run("Cancer")
        val ebolaText = GTIMProfessionalResearchOrchestratorV2140.renderUserCard(ebola).orEmpty()
        val covidText = GTIMProfessionalResearchOrchestratorV2140.renderUserCard(covid).orEmpty()
        val cancerText = GTIMProfessionalResearchOrchestratorV2140.renderUserCard(cancer).orEmpty()
        assertTrue(ebolaText.contains("filovirus", ignoreCase = true))
        assertTrue(ebolaText.contains("sample", ignoreCase = true) || ebolaText.contains("metadata", ignoreCase = true))
        assertTrue(covidText.contains("mucosal", ignoreCase = true) || covidText.contains("interferon", ignoreCase = true))
        assertTrue(cancerText.contains("tumor", ignoreCase = true))
        assertTrue(cancerText.contains("checkpoint", ignoreCase = true) || cancerText.contains("Treg", ignoreCase = true))
    }
}
