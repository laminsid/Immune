package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3FinalHardeningTest {
    @Test
    fun checkpointObjectContainsExecutedContradictionQueriesNotJustNextAction() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = adapterWithoutContradiction())
        ).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result is ResearchResultV3.ReportReady)
        val contradictionOutcome = result.state.ledgerSnapshot.objectiveOutcomes.first { it.objective is ResearchObjectiveV3.FindContradiction }
        assertTrue(contradictionOutcome.queriesAttempted.any { it.contains("limitation") || it.contains("negative control") })
        assertTrue(contradictionOutcome.exhausted)
        assertTrue(result.closure.noValidFalsifierFoundAfterSearch)
    }

    @Test
    fun hypothesisAssessmentComesFromLedgerNotFixedTaskCompletion() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = adapterWithoutContradiction())
        ).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertEquals(HypothesisDispositionV3.CLOSURE_READY, result.report.hypothesisAssessment.disposition)
        assertTrue(result.report.hypothesisAssessment.supportEvidenceIds.isNotEmpty())
        assertTrue(result.report.hypothesisAssessment.contradictionEvidenceIds.isEmpty())
        assertTrue(result.closure.noValidFalsifierFoundAfterSearch)
        assertFalse(result.report.hypothesisAssessment.missingGates.contains("visible_contradiction_falsification"))
    }

    @Test
    fun reportReadyKeepsCheckpointNullButKeepsHypothesisAssessment() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = adapterWithContradiction())
        ).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result is ResearchResultV3.ReportReady)
        assertEquals(null, result.report.checkpoint)
        assertEquals(HypothesisDispositionV3.CLOSURE_READY, result.report.hypothesisAssessment.disposition)
        assertTrue(result.report.hypothesisAssessment.contradictionEvidenceIds.isNotEmpty())
    }

    @Test
    fun researchOnlyBoundaryIsAlwaysPresentInReportJson() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = adapterWithoutContradiction())
        ).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        val json = result.report.toJson()
        assertTrue(json.getString("researchOnlyBoundary").contains("Research-only checkpoint"))
        if (result is ResearchResultV3.CheckpointReady) {
            assertTrue(json.getJSONObject("checkpoint").getString("researchOnlyBoundary").contains("no clinical advice"))
        } else {
            assertTrue(json.getJSONObject("checkpoint").length() == 0)
        }
    }

    @Test
    fun budgetCanStopRunButExecutedTraceStillExplainsWhatHappened() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = StaticEvidenceAdapterV3(emptyMap()))
        ).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 2, maxEmptyQueries = 2, maxObjectives = 6)
            )
        )
        assertTrue(result is ResearchResultV3.CheckpointReady)
        val checkpoint = result.report.checkpoint
        assertNotNull(checkpoint)
        assertTrue(checkpoint!!.objectiveTraces.isNotEmpty())
        assertFalse(checkpoint.objectiveTraces.all { it.queriesAttempted.isEmpty() })
    }

    private fun adapterWithoutContradiction(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3("1001", "Bundibugyo Ebola host response mechanistic review", SourceKindV3.PUBMED)
            ),
            "transcriptome geo" to listOf(
                EvidenceSearchRecordV3("GSE2001", "Bundibugyo Ebola transcriptome GEO dataset cohort", SourceKindV3.GEO)
            ),
            "sample provenance" to listOf(
                EvidenceSearchRecordV3("GSE2002", "Bundibugyo Ebola sample provenance comparator labels cohort", SourceKindV3.GEO)
            )
        )
    )

    private fun adapterWithContradiction(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3("1001", "Bundibugyo Ebola host response mechanistic review", SourceKindV3.PUBMED)
            ),
            "transcriptome geo" to listOf(
                EvidenceSearchRecordV3("GSE2001", "Bundibugyo Ebola transcriptome GEO dataset cohort", SourceKindV3.GEO)
            ),
            "sample provenance" to listOf(
                EvidenceSearchRecordV3("GSE2002", "Bundibugyo Ebola sample provenance comparator labels cohort", SourceKindV3.GEO)
            ),
            "tissue comparator limitation" to listOf(
                EvidenceSearchRecordV3("3001", "Bundibugyo Ebola tissue comparator limitation cohort falsification study", SourceKindV3.PUBMED)
            )
        )
    )
}
