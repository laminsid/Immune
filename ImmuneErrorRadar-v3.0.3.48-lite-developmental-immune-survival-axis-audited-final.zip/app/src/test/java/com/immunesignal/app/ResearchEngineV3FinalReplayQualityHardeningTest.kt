package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3FinalReplayQualityHardeningTest {
    @Test
    fun snapshotContainsDecisionRowsQueriesByObjectiveAndReplayAudit() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = completeEbolaAdapter())
        ).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        val json = result.report.toJson()
        val snapshot = json.getJSONObject("sessionSnapshot")
        assertTrue(snapshot.getJSONArray("acceptedEvidence").length() > 0)
        assertTrue(snapshot.getJSONObject("queriesByObjective").length() > 0)
        assertTrue(snapshot.getJSONObject("replayAudit").getBoolean("networkRequired") == false)
        assertTrue(json.getJSONObject("replayAudit").getBoolean("canRebuildFromSnapshot"))
        assertTrue(json.getJSONObject("replayAudit").getString("stableReplayHash").length >= 16)
    }

    @Test
    fun finalQualityLockPassesOnlyWhenClosureIsClean() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = completeEbolaAdapter())
        ).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result is ResearchResultV3.ReportReady)
        val quality = result.report.toJson().getJSONObject("finalQualityLock")
        assertTrue(quality.getBoolean("passed"))
        assertEquals(0, quality.getJSONArray("blockers").length())
    }

    @Test
    fun finalQualityLockReportsConditionalWarningWhenContradictionSearchIsExhaustedWithoutFalsifier() {
        val result = ResearchEngineV3(
            executor = ResearchObjectiveExecutorV3(adapter = noContradictionAdapter())
        ).run(
            ResearchInputV3(
                topic = "Ebola Bundibugyo immune dysregulation",
                budget = ResearchBudgetV3(maxNetworkCalls = 8, maxEmptyQueries = 8)
            )
        )
        assertTrue(result is ResearchResultV3.ReportReady)
        val quality = result.report.toJson().getJSONObject("finalQualityLock")
        assertTrue(quality.getBoolean("passed"))
        assertTrue(quality.getJSONArray("warnings").toString().contains("report_ready_with_no_visible_falsifier_found_after_exhausted_search"))
    }

    @Test
    fun dynamicOutOfTemplateQueriesRemainExplicitForHantaLupusAndPfas() {
        val hanta = DomainQueryTemplateV3.sourceQueries("Hanta virus immune response").joinToString(" ").lowercase()
        val lupus = DomainQueryTemplateV3.sourceQueries("Lupus interferon complement immune response").joinToString(" ").lowercase()
        val pfas = DomainQueryTemplateV3.sourceQueries("PFAS immune disruption antibody response").joinToString(" ").lowercase()
        assertTrue(hanta.contains("hfrs") && hanta.contains("hantavirus pulmonary syndrome"))
        assertTrue(lupus.contains("systemic lupus erythematosus") && lupus.contains("sle"))
        assertTrue(pfas.contains("per- and polyfluoroalkyl substances") && pfas.contains("antibody response"))
        assertFalse(hanta.contains("hanta virus immune mechanism cohort pubmed"))
    }

    private fun completeEbolaAdapter(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3("1001", "Bundibugyo Ebola host response mechanistic review", SourceKindV3.PUBMED)
            ),
            "transcriptome geo" to listOf(
                EvidenceSearchRecordV3("GSE2001", "Bundibugyo Ebola transcriptome GEO dataset cohort", SourceKindV3.GEO)
            ),
            "sample provenance" to listOf(
                EvidenceSearchRecordV3("GSE2002", "Bundibugyo Ebola sample provenance comparator labels cohort", SourceKindV3.GEO)
            ),
            "tissue comparator limitation" to listOf(
                EvidenceSearchRecordV3("3001", "Bundibugyo Ebola tissue comparator limitation cohort falsification study", SourceKindV3.PUBMED)
            )
        )
    )

    private fun noContradictionAdapter(): EvidenceAdapterV3 = StaticEvidenceAdapterV3(
        mapOf(
            "immune dysregulation pubmed" to listOf(
                EvidenceSearchRecordV3("1001", "Bundibugyo Ebola host response mechanistic review", SourceKindV3.PUBMED)
            ),
            "transcriptome geo" to listOf(
                EvidenceSearchRecordV3("GSE2001", "Bundibugyo Ebola transcriptome GEO dataset cohort", SourceKindV3.GEO)
            ),
            "sample provenance" to listOf(
                EvidenceSearchRecordV3("GSE2002", "Bundibugyo Ebola sample provenance comparator labels cohort", SourceKindV3.GEO)
            )
        )
    )
}
