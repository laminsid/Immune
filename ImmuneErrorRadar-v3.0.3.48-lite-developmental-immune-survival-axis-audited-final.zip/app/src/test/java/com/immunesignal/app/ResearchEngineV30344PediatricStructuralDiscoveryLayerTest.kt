package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30344PediatricStructuralDiscoveryLayerTest {
    private fun snapshot(): HumanPediatricDiscoverySnapshotV30340 = HumanPediatricDiscoverySnapshotV30340(
        active = true,
        mode = HumanPediatricDiscoveryV30340.DISCOVERY_ALPHA_MODE,
        state = "PEDIATRIC_ALPHA_DISCOVERY_READY_TRUTH_LOCKED",
        sourceTruthFullyAligned = true,
        matrixFuelSource = "GSE85047",
        dgeOn = "GSE85047",
        retrievalEvidence = "GSE85047",
        organismPriority = "HUMAN_PEDIATRIC_DECLARED_MATRIX_PRIORITY_MOUSE_EVIDENCE_CONTEXT_ONLY",
        evidenceRoles = listOf(
            HumanPediatricEvidenceRoleAssignmentV30340(
                accession = "GSE85047",
                title = "GSE85047 neuroblastoma MYCN matrix",
                ledgerRole = "DATASET",
                organismBeforeOverride = "HUMAN",
                organismAfterOverride = "HUMAN",
                sourceRole = "MATRIX_FUEL",
                independentSupportAllowed = true,
                upgradeAllowed = false,
                warning = "review_only"
            ),
            HumanPediatricEvidenceRoleAssignmentV30340(
                accession = "EGAD00001009766",
                title = "childhood neuroblastoma single-cell mRNA sequencing",
                ledgerRole = "DATASET",
                organismBeforeOverride = "HUMAN",
                organismAfterOverride = "HUMAN",
                sourceRole = "HUMAN_SINGLE_CELL_COMPARTMENT_ROUTE",
                independentSupportAllowed = false,
                upgradeAllowed = false,
                warning = "compartment_route_not_numeric_dge"
            )
        ),
        alphaGuardPolicy = AlphaGuardPolicySnapshotV30340.inactive(),
        nullToNovelHypotheses = emptyList(),
        humanReplicationReady = false,
        nextAction = "test"
    )

    @Test
    fun structuralLayerProducesInteractionAndBlocksDiscoveryUpgrade() {
        val result = PediatricStructuralDiscoveryLayerV30344.evaluate(snapshot())
        assertTrue(result.active)
        assertEquals("PEDIATRIC_STRUCTURAL_DISCOVERY_READY_RESEARCH_ONLY", result.state)
        assertTrue(result.interactionEffectModifier.active)
        assertTrue(result.interactionEffectModifier.contrasts.isNotEmpty())
        assertTrue(result.interactionEffectModifier.contrasts.any { it.modifierAxis == "hypoxia_stroma_barrier_proxy" })
        assertTrue(result.moduleCoherenceDecoupling.active)
        assertFalse(result.discoveryLabelAllowed)
        assertTrue(result.requiredBeforeDiscovery.contains("FDR_CORRECTION_REQUIRED_FOR_INTERACTION_AND_DECOUPLING"))
        assertTrue(result.bestStructuralHypothesis.contains("second barrier axis"))
    }

    @Test
    fun egadIsCompartmentRouteNotNumericDge() {
        val role = HumanPediatricDiscoveryV30340.overrideFor("EGAD00001009766")
        assertEquals("HUMAN_SINGLE_CELL_COMPARTMENT_ROUTE", role?.sourceRole)
        assertEquals("COMPARTMENT_ROUTE_READY_NOT_NUMERIC_DGE", role?.rowState)
        val route = CompartmentSpecificHypothesisRouterV30344.evaluate(snapshot())
        assertEquals("COMPARTMENT_ROUTE_READY_NOT_NUMERIC_DGE", route.state)
        assertFalse(route.numericDgeAllowed)
        assertTrue(route.routeTriggers.contains("tumor_vs_immune_cells"))
    }

    @Test
    fun noveltyCountsStructureNotUnpublishedTextClaims() {
        val result = PediatricStructuralDiscoveryLayerV30344.evaluate(snapshot())
        val novelty = result.consensusContradictionNovelty
        assertTrue(novelty.active)
        assertTrue(novelty.textNoveltyAloneRejected)
        assertFalse(novelty.discoveryLabelAllowed)
        assertTrue(novelty.sourceRules.any { it.sourceType == "UNPUBLISHED_TEXT_CLAIM" && !it.visible && !it.countsAsDiscovery })
        assertTrue(novelty.sourceRules.any { it.sourceType == "DATA_DERIVED_INTERACTION" && it.visible && !it.countsAsDiscovery })
    }

    @Test
    fun humanPediatricDiscoveryJsonContainsStructuralLayer() {
        val json = snapshot().toJson()
        val structural = json.optJSONObject("pediatricStructuralDiscoveryV30344")
        assertTrue(structural != null)
        assertEquals("pediatric_structural_discovery_layer_v30344", structural?.optString("schema"))
        assertFalse(structural?.optBoolean("discoveryLabelAllowed", true) ?: true)
    }
}
