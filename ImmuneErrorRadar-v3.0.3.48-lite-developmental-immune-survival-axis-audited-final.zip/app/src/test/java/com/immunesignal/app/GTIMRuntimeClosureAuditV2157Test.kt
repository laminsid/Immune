package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMRuntimeClosureAuditV2157Test {
    @Test
    fun executionProgressDoesNotEqualEvidenceClosure() {
        var contract = ResearchRunContractV2150.create("Ebola Bundibugyo immune dysregulation")
        contract.tasks.forEach { task ->
            contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE)
        }
        contract = contract.withStatus(ResearchRunStatusV2150.CHECKPOINT_READY)
            .withEvidenceHandle("metadata_probe_attempted_no_verified_dataset_yet_not_evidence")
            .withEvidenceHandle("contradiction_probe_attempted_no_pubmed_hit_yet_not_evidence")
        val audit = ResearchRuntimeClosureAuditV2157.toJson(contract)
        assertEquals(100, audit.getInt("executionProgressPercent"))
        assertEquals(0, audit.getInt("evidenceClosurePercent"))
        assertFalse(audit.getBoolean("reportEligible"))
        assertTrue(audit.getJSONArray("openGates").length() >= 3)
    }

    @Test
    fun positiveMandatoryEvidenceHandlesMakeReportEligibleOnlyWhenStatusIsReportReady() {
        var contract = ResearchRunContractV2150.create("Ebola Bundibugyo")
            .withEvidenceHandle("source_handle_closed_pubmed_111")
            .withEvidenceHandle("metadata_probe_executed_pubmed_222")
            .withEvidenceHandle("contradiction_checked_pubmed_333")
        contract.tasks.forEach { task -> contract = contract.updateTask(task.id, ResearchTaskStatusV2150.DONE) }
        val checkpointAudit = ResearchRuntimeClosureAuditV2157.toJson(contract.withStatus(ResearchRunStatusV2150.CHECKPOINT_READY))
        assertEquals(100, checkpointAudit.getInt("evidenceClosurePercent"))
        assertFalse(checkpointAudit.getBoolean("reportEligible"))
        val reportAudit = ResearchRuntimeClosureAuditV2157.toJson(contract.withStatus(ResearchRunStatusV2150.REPORT_READY))
        assertTrue(reportAudit.getBoolean("reportEligible"))
    }

    @Test
    fun softRuntimeBudgetClosesAsCheckpointNotFinalReport() {
        val report = ProfessionalResearchOrchestratorV2150.run(
            topic = "Post-COVID immune persistence interferon endothelial transcriptomics",
            shouldPause = { false },
            shouldStop = { false },
            onState = { _, _ -> },
            policy = ResearchExecutionPolicyV2154.unitTestNoFastFinish().copy(maxSingleRunMillis = 1L)
        )
        val contract = report.getJSONObject("researchRunContractV2150")
        assertEquals("CHECKPOINT_READY", contract.getString("status"))
        assertTrue(report.getJSONObject("professionalResearchOrchestratorV2150").getBoolean("softBudgetReached"))
        assertFalse(report.getJSONObject("runtimeClosureAuditV2157").getBoolean("reportEligible"))
    }
}
