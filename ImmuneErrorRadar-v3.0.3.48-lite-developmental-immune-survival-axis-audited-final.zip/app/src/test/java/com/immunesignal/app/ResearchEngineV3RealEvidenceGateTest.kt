package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV3RealEvidenceGateTest {
    @Test
    fun covidDoesNotAcceptUnrelatedPubMedAsSource() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "41830448",
                title = "Current status of immunomodulatory therapies in adult sepsis patients: where do we stand?",
                source = SourceKindV3.PUBMED
            ),
            requestedRole = EvidenceRoleV3.SOURCE,
            topic = "Covid",
            query = "Covid immune dysregulation PubMed"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertEquals(QualityTierV3.D, node.qualityTier)
        assertFalse(node.satisfiesResearchRole(EvidenceRoleV3.SOURCE))
    }

    @Test
    fun pubMedArticleCannotCloseDatasetGateWithoutRepositoryEvidence() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "41916102",
                title = "Artificial intelligence and multi-omic empowered-tracing macrophage diagnostic implications in coronavirus",
                source = SourceKindV3.PUBMED
            ),
            requestedRole = EvidenceRoleV3.DATASET,
            topic = "Covid",
            query = "Covid RNA-seq cohort GEO comparator dataset"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertFalse(node.satisfiesResearchRole(EvidenceRoleV3.DATASET))
        assertTrue(node.limitations.contains("dataset_role_requires_geo_sra_or_explicit_dataset_handle"))
    }

    @Test
    fun contradictionRoleRequiresExplicitFalsifierCueNotJustRequestedRole() {
        val node = EvidenceClassifierV3.classify(
            record = EvidenceSearchRecordV3(
                accession = "41751338",
                title = "Complement System Dysregulation in the Immunopathogenesis of Long COVID: Systematic Evidence Synthesis",
                source = SourceKindV3.PUBMED
            ),
            requestedRole = EvidenceRoleV3.CONTRADICTION,
            topic = "Covid",
            query = "Covid tissue comparator limitation negative control healthy control"
        )
        assertEquals(EvidenceRoleV3.CONTEXT, node.role)
        assertFalse(node.satisfiesResearchRole(EvidenceRoleV3.CONTRADICTION))
        assertTrue(node.limitations.contains("contradiction_role_requires_explicit_falsifier_or_limitation_cue"))
    }

    @Test
    fun equalTierNoiseBlocksReportReady() {
        val nodes = listOf(
            EvidenceNodeV3("s1", EvidenceTypeV3.SOURCE, "PMID:1", "Covid cohort", SourceKindV3.PUBMED, ArticleTypeV3.COHORT, EvidenceRoleV3.SOURCE, QualityTierV3.A),
            EvidenceNodeV3("d1", EvidenceTypeV3.DATASET, "GSE1", "Covid dataset", SourceKindV3.GEO, ArticleTypeV3.DATASET, EvidenceRoleV3.DATASET, QualityTierV3.A),
            EvidenceNodeV3("c1", EvidenceTypeV3.CONTRADICTION, "PMID:2", "Covid comparator limitation", SourceKindV3.PUBMED, ArticleTypeV3.COHORT, EvidenceRoleV3.CONTRADICTION, QualityTierV3.B, contradicts = listOf("primary_hypothesis")),
            EvidenceNodeV3("x1", EvidenceTypeV3.CONTEXT, "PMID:3", "Unrelated context", SourceKindV3.PUBMED, ArticleTypeV3.UNKNOWN, EvidenceRoleV3.CONTEXT, QualityTierV3.D),
            EvidenceNodeV3("x2", EvidenceTypeV3.CONTEXT, "PMID:4", "Unrelated context", SourceKindV3.PUBMED, ArticleTypeV3.UNKNOWN, EvidenceRoleV3.CONTEXT, QualityTierV3.D),
            EvidenceNodeV3("x3", EvidenceTypeV3.CONTEXT, "PMID:5", "Unrelated context", SourceKindV3.PUBMED, ArticleTypeV3.UNKNOWN, EvidenceRoleV3.CONTEXT, QualityTierV3.D)
        )
        val outcomes = listOf(
            ResearchObjectiveOutcomeV3(ResearchObjectiveV3.FindContradiction("Covid", "H1_PRIMARY"), listOf("Covid comparator limitation"), listOf(nodes[2]), false),
            ResearchObjectiveOutcomeV3(ResearchObjectiveV3.RankHypotheses("Covid"), emptyList(), emptyList(), false)
        )
        val state = ResearchStateV3.initial(ResearchInputV3("Covid"), EvidenceLedgerSnapshotV3(nodes, outcomes))
        val closure = ResearchClosurePolicyV3().evaluate(state)
        assertFalse(closure.canCloseReport)
        assertTrue(closure.openGates.contains("tier_c_d_noise_ratio_blocks_report_ready"))
    }
}
