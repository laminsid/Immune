# v3.0.3.38 — Pediatric Oncology Unified B7-H3/GD2/Matrix Pack

## Added
- `PediatricOncologyUnifiedFocusV30338` translation lens.
- B7-H3/CD276 CAR-T pediatric solid tumor TME penetration axis.
- GD2/dinutuximab-beta chemo-immunotherapy ADCC axis.
- Single-cell/spatial TME compartment mapping axis.
- Pediatric neuroblastoma capsule in `CuratedDiseaseCapsuleStoreV30335`.
- Embedded pediatric oncology capsule asset and matrix CSV in the same ZIP.
- Report rendering block for `pediatricOncologyLensV30338`.
- v30338 audit and regression tests.

## Preserved
- v30334 user-attested matrix safety semantics.
- v30335 curated capsule/matrix seed routing.
- v30337 GSE85047 explicit matrix path.
- No certified discovery from declared-source single dataset alone.

## Scientific boundary
This version generates better pediatric oncology hypotheses. It does not make clinical claims or treatment recommendations.

## CI hotfix — legacy guard + pediatric matrix scope

- Suppressed legacy v30331/v30332/v30334 identity mismatch warnings for active v30335+ release lines so old guards do not leak warnings into the final identity surface.
- Unified the active runtime identity fields to v3.0.3.38 for VERSION_NAME, ENGINE_VERSION, SCHEMA_VERSION, VERSION_CODE, UNIFICATION_TOKEN, and public label semantics.
- Hardened `PediatricOncologyExplicitMatrixV30337.isEligible()` so the GSE85047 neuroblastoma MYCN matrix does not leak into leukemia, AML/ALL, sarcoma, osteosarcoma, Ewing, rhabdomyosarcoma, medulloblastoma, or glioma routes unless GSE85047 is explicitly requested.
- Preserved the Neuroblastoma/MYCN/GD2 path as the only automatic explicit matrix route.
