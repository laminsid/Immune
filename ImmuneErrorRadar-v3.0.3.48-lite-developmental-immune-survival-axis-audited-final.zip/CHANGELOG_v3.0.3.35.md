# v3.0.3.35 — Curated Capsule Matrix Fuel Pack

## Decision
This release injects curated biomedical prior fuel after the existing evidence, ontology, and matrix-safety gates. The curated layer is allowed to generate **hypothesis-discovery seeds** so the engine no longer falls back to `rows=0` on core disease questions, but it is **not** treated as certified discovery or mechanism support by itself.

## Added
- `DiseaseOrganOntologyPackV30335`
  - Major disease, outbreak, organ, tissue, cell, pathway, marker, comparator, and reject-rule capsules.
- `CuratedDiseaseCapsuleStoreV30335`
  - RA, allergy/asthma/type-2 inflammation, Alzheimer/microglia/complement, cancer/TME/checkpoint, MS, COVID/Long COVID, T2D, lupus nephritis, IBD, psoriasis, sepsis, obesity/metabolic inflammation, NASH/liver inflammation, kidney inflammation, and depression neuroinflammation.
- `SpecialistRouterV30335`
  - Routes user questions to specialist lanes before raw retrieval dominates:
    - RA/synovium
    - allergy/type-2 airway
    - Alzheimer/microglia/complement
    - cancer/TME/checkpoint
    - COVID/interferon/PBMC
    - liver/metabolic inflammation
    - gut/IBD/barrier
- `CuratedLightMatrixFuelPackV30335`
  - Small deterministic sample-level prior matrices for core disease lanes.
  - Prevents `rows=0` in known questions and enables a first DGE pass.

## Linked runtime paths
- `ResearchTopicNormalizerV3`
- `ComparatorGroupResolverV30331`
- `MatrixFuelProviderV30331`
- `DynamicModuleBuilderV30331`
- `DiseaseOntologyGateV30333`
- `ProcessedExpressionSignalExecutorV30329`
- `CertifiedMatrixFuelGateV30332`
- `ProfessionalDiscoveryCardBuilderV30329`
- `ResearchReportCompilerV3`
- `RuntimeModuleRegistry`
- `ReleaseReadinessContractV30329`

## Safety boundary
Curated matrix fuel has this origin:

`CURATED_LIGHT_MATRIX_PRIOR`

It may unlock:

- raw DGE execution on core questions
- module-level signal direction
- falsifiable hypothesis-discovery seed generation

It may **not** unlock by itself:

- `certifiedForDiscovery = true`
- mechanism support
- discovery score `>= 8`
- clinical, treatment, dosing, or patient-action claims

## Tests added
- RA routes to synovium and not cancer.
- Alzheimer keeps microglia/complement disease anchor.
- Allergy finds type-2 airway route.
- Cancer finds TME/checkpoint route.
- Curated matrix prevents `rows=0` for core diseases.
- COVID curated prior can seed a hypothesis but cannot certify discovery or mechanism support.

## Version identity
- `VERSION_NAME = 3.0.3.35-curated-capsule-matrix-fuel-pack`
- `ENGINE_VERSION = v3.0.3.35-curated-capsule-matrix-fuel-pack`
- `VERSION_CODE = 255`
- `SCHEMA_VERSION = 3.0.3.35-curated-capsule-matrix-fuel`

## Final closure patch in this package
- Split the original monolithic v30335 Kotlin file into focused files:
  - `DiseaseOntologyModelsV30335.kt`
  - `CuratedDiseaseCapsuleStoreV30335.kt`
  - `SpecialistRouterV30335.kt`
  - `CuratedLightMatrixFuelPackV30335.kt`
  - `CuratedHypothesisDiscoverySeedV30335.kt`
  - `ResearchEngineV30335CuratedCapsuleMatrixFuelGuard.kt`
- Added `CuratedHypothesisDiscoverySeedBuilderV30335` so curated prior output is explicit in the report as `curatedHypothesisSeedV30335`.
- Tightened specialist routing with route scoring instead of first-hit matching, reducing accidental capture from generic PBMC/blood/inflammation terms.
- Extended unit coverage so all 15 major disease capsules open specialist routes and curated matrix rows.
- Added a negative guard: generic PBMC/blood/inflammation alone must not open a specialist route.
- Added static audit `audit_research_engine_v30335_curated_capsule_matrix_seed.py` and linked it into the fast static-check runner.

## Final closure invariant
Curated matrix fuel is now discovery-opening only at the seed level:

- allowed: `CURATED_PRIOR_HYPOTHESIS_DISCOVERY_SEED_OPENED_NOT_CERTIFIED`
- blocked: mechanism support
- blocked: `certifiedForDiscovery = true`
- blocked: score `>= 8`
- required upgrade: ETL-verified or independently replicated user-attested matrix fuel
