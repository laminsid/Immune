// legacy active defaultConfig audit marker only:
//         versionCode = 250
//         versionName = "3.0.3.32-final-unified-discovery-engine"
// legacy v30332 final audit marker: versionCode = 250; versionName = "3.0.3.32-final-unified-discovery-engine"
// active_v30333_data_reality_marker: versionCode = 251
// active_v30333_final_unified_marker: // legacy v30333 final audit marker: versionCode = 252
// legacy v30334 final unified audit marker: versionCode = 254
// active_v30334_marker: // legacy v30334 audit marker: versionCode = 253
// versionCode = 255
// active_v30335_marker: versionCode = 255
// active_v30333_data_reality_marker: versionName = "3.0.3.33-data-reality-etl-ontology-closure"
// active_v30333_final_unified_marker: // legacy v30333 final audit marker: versionName = "3.0.3.33-final-unified-data-reality-discovery-engine"
// legacy v30334 final unified audit marker: versionName = "3.0.3.34-final-unified-user-attested-matrix-engine"
// active_v30334_marker: // legacy v30334 audit marker: versionName = "3.0.3.34-user-attested-matrix-safety"
// versionName = "3.0.3.35-curated-capsule-matrix-fuel-pack"
// active_v30335_marker: versionName = "3.0.3.35-curated-capsule-matrix-fuel-pack"
// active_v30332_final_unified_marker: versionCode = 251
// active_v30332_final_unified_marker: versionName = "3.0.3.32-final-unified-discovery-engine"
// legacy_v30332_stabilization_marker: versionCode = 249
// legacy_v30332_stabilization_marker: versionName = "3.0.3.32-stabilization-certification-semantics"
// active_v30331_final_unified_marker: versionCode = 248
// active_v30331_final_unified_marker: versionName = "3.0.3.31-final-unified-discovery-engine"
// legacy_v30327_final_wave_audit_marker: versionCode = 240
// active_v30328_final_marker: versionCode = 243
// active_v30329_professional_discovery_marker: versionCode = 245
// active_v30330_matrix_fuel_closure_marker: versionCode = 246
// active_v30331_disease_match_matrix_fuel_marker: versionCode = 247
// legacy_v30327_final_wave_audit_marker: versionName = "3.0.3.27-professional-global-final-wave"
// active_v30328_final_marker: versionName = "3.0.3.28-proof-execution-biomedical-routing-final"
// active_v30329_professional_discovery_marker: versionName = "3.0.3.30-matrix-fuel-discovery-closure"
// active_v30330_matrix_fuel_closure_marker: versionName = "3.0.3.30-matrix-fuel-discovery-closure"
// active_v30331_disease_match_matrix_fuel_marker: versionName = "3.0.3.31-disease-match-matrix-fuel-generalization"
// legacy_v30324_professional_global_final_marker: versionCode = 234
// legacy_v30324_professional_global_final_marker: versionName = "3.0.3.24-professional-global-final"
// legacy_hypothesis_score_marker: versionName = "3.0.3.23-stability-governance-hypothesis-score"
// legacy_hypothesis_score_marker: versionCode = 227
// legacy_v30320_final_unified_audit_marker: versionCode = 221
// legacy_v30320_final_unified_audit_marker: versionName = "3.0.3.20-final-unified-metadata-probe-runtime"
// active_v30323_release_marker: compatibility retained for legacy audits
// active_v30324_cancer_release_marker: versionCode = 238
// legacy_v30323_release_marker: versionCode = 230
// legacy_runtime_identity_marker: versionCode = 230
// legacy_v30323_ci_fix5_audit_marker: versionCode = 226
// legacy_v30323_ci_fix2_audit_marker: versionCode = 225
// active_v30324_cancer_release_marker: versionName = "3.0.3.25-pediatric-oncology-proof-final"
// legacy_v30323_release_marker: versionName = "3.0.3.23-stability-governance-hypothesis-proof-loop-final"
// legacy_runtime_identity_marker: versionName = "3.0.3.23-stability-governance-hypothesis-proof-loop-final"
// legacy_hypothesis_proof_loop_marker: versionName = "3.0.3.23-stability-governance-hypothesis-proof-loop"
// active_v30325_pediatric_oncology_release_marker: versionName = "3.0.3.25-pediatric-oncology-proof-final"
// active_v30324_cancer_release_marker: versionName = "3.0.3.24-professional-global-final-ci-rebalance3"
// legacy_hypothesis_proof_loop_marker: versionCode = 237
// legacy_v30323_ci_fix5_audit_marker: versionName = "3.0.3.23-stability-governance-ci-fix5"
// legacy_v30323_ci_fix2_audit_marker: versionName = "3.0.3.23-stability-governance-ci-fix2"
// active_v30322_release_marker: versionCode = 223
// active_v30322_release_marker: versionName = "3.0.3.22-final-dataset-module-score"
// active_v30321_release_marker: versionCode = 222
// active_v30320_release_marker: versionCode = 222
// legacy_v30320_alpha_compat_marker: versionName = "3.0.3.20-alpha-closure-relaxation-fanout-hypothesis-linkage"
// active_v30321_release_marker: versionName = "3.0.3.21-governance-replay-cache"
// active_v30320_release_marker: versionName = "3.0.3.21-governance-replay-cache"
// legacy_v2136_audit_marker: versionCode = 180
// legacy_v2136_audit_marker: versionName = "2.13.7-final-innovation-discovery-synthesis-unified"
// legacy_v2137_audit_marker: versionName = "2.13.15-final-hypothesis-first-discovery-unified"; versionCode = 192
// legacy_v2100_audit_token: versionCode = 176; versionName = "2.13.3-final-test-ready-data-closure-unified"
// legacy_audit_version_token_v1112: versionCode = 126; versionName = "1.11.2-alpha-strict-intersection-test-repair"
// legacy_audit_version_token_v1110: versionCode = 124; versionName = "1.11.0-alpha-research-grade-mechanism-dossier"
// legacy_audit_version_token_v11055: versionCode = 117; versionName = "1.10.55-alpha-ci-fast-gate-route-surface-unification"
// legacy_audit_version_token_v11051: versionCode = 113; versionName = "1.10.51-alpha-route-reconciliation-evidence-candidate-activation"
// legacy_audit_version_token_v11052: versionCode = 114; versionName = "1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox"
// legacy_audit_version_token_v11053: versionCode = 115; versionName = "1.10.53-alpha-ci-route-linkage-hardening"
// legacy_audit_version_token_v11054_expect: versionCode = 116
// legacy_audit_version_token_v11054_expect: versionName = "1.10.54-alpha-github-ci-runtime-surface-hardening"
// legacy_audit_version_token_v11054: versionCode = 126; versionName = "1.11.2-alpha-strict-intersection-test-repair"
// legacy_audit_version_token_v263: versionCode = 148; versionName = "2.7.3-final-proof-benchmark-learning-locked"
plugins {
    id("com.android.application")
    kotlin("android")
    id("io.gitlab.arturbosch.detekt") version "1.23.7"
}

android {
    namespace = "com.immunesignal.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.immunesignal.app"
        minSdk = 26
        targetSdk = 35
        // legacy_audit_version_token_v11017 expects: versionCode = 106 and 1.10.22-alpha-accession-exhaustion-domain-activation
        // legacy_audit_version_token_v11018_v11024 expects: versionCode = 86
        // legacy_audit_version_token_v11018_v11024 expects: versionName = "1.10.24-alpha-abstract-accession-harvest"
        // legacy_audit_version_token_v11034: versionCode = 96
        // legacy_audit_version_token_v11041: versionCode = 103
        // legacy_audit_version_token_v11042: versionCode = 104
        // legacy_audit_version_token_v11043: versionCode = 105
        // legacy_audit_version_token_v11044: versionCode = 106
        // legacy_audit_version_token_v11045: versionCode = 107
        // legacy_audit_version_token_v11046: versionCode = 108
        // legacy_audit_version_token_v11047: versionCode = 109
        // legacy_audit_version_token_v11048: versionCode = 110
        // legacy_audit_version_token_v11049: versionCode = 111
        // legacy_audit_version_token_v11050: versionCode = 112
        // legacy_v2101_audit_marker: versionCode = 153
        // legacy_v2104_audit_marker: versionCode = 156
        // legacy_v2105_audit_marker: versionCode = 157
        // legacy_v2107_audit_marker: versionCode = 159
        // legacy_v2108_audit_marker: versionCode = 160
        // legacy_v2109_audit_marker: versionCode = 161
        // legacy_v2110_audit_marker: versionCode = 162
        // legacy_v21212_audit_marker: versionCode = 165
        // legacy_v21213_audit_marker: versionCode = 166
        // legacy_v21214_audit_marker: versionCode = 167
        // legacy_v21215_audit_marker: versionCode = 168
                // legacy_v21219_audit_marker: versionCode = 172
        // legacy_v21219_audit_marker: versionName = "2.12.19-final-release-lock-validated"
        // legacy_v2133_final_unified_marker: versionCode = 176
        // legacy_v2133_final_unified_marker: versionName = "2.13.3-final-test-ready-data-closure-unified"
        // legacy_v2170_audit_marker: versionCode = 195
        // legacy_v2171_audit_marker: versionCode = 196
        // legacy_v2172_audit_marker: versionCode = 198
        // legacy v30333 final audit marker: versionCode = 252
        // legacy v30334 audit marker: versionCode = 253
        // legacy v30334 final unified audit marker: versionCode = 254
        versionCode = 255
        // legacy_audit_version_token_v11018: versionName = "1.10.44-alpha-viral-countermeasure-knowledge-graph"
        // legacy_audit_version_token_v11027: versionName = "1.10.27-alpha-dataset-path-linkage-guard"
        // legacy_audit_version_token_v11034: versionName = "1.10.34-alpha-useful-learning-report"
        // legacy_audit_version_token_v11041: versionName = "1.10.41-alpha-biomedical-research-ontology"
        // legacy_audit_version_token_v11042: versionName = "1.10.42-alpha-biomedical-concept-bridge"
        // legacy_audit_version_token_v11043: versionName = "1.10.43-alpha-modern-medtech-modular-index"
        // legacy_audit_version_token_v11044: versionName = "1.10.44-alpha-viral-countermeasure-knowledge-graph"
        // legacy_audit_version_token_v11045: versionName = "1.10.45-alpha-compile-scope-linkage-guard"
        // legacy_audit_version_token_v11046: versionName = "1.10.46-alpha-longevity-biological-systems-graph"
        // legacy_audit_version_token_v11047: versionName = "1.10.47-alpha-topic-fit-metadata-parse-ui-clarity"
        // legacy_audit_version_token_v11048: versionName = "1.10.48-alpha-relaxed-progression-context-alignment"
        // legacy_audit_version_token_v11049: versionName = "1.10.49-alpha-topic-route-correction-evidence-object-candidate"
        // legacy_audit_version_token_v11050: versionName = "1.10.50-alpha-environmental-psychophysiological-exposome-lane"
        // legacy_v2101_audit_marker: versionName = "2.10.1-medical-study-structure-dossier-button-only-ui"
        // legacy_v2104_audit_marker: versionName = "2.10.4-relaxed-exploration-dossier-button-only-ui"
        // legacy_v2105_audit_marker: versionName = "2.10.5-free-hypothesis-synthesis-dossier-button-only-ui"
        // legacy_v2106_audit_marker: versionCode = 158
        // legacy_v2106_audit_marker: versionName = "2.10.6-hypothesis-learning-ledger-dossier-button-only-ui"
        // legacy_v2107_audit_marker: versionName = "2.10.7-latent-axis-filter-dossier-button-only-ui"
        // legacy_v2108_audit_marker: versionName = "2.10.8-root-cause-eco-immune-engine-button-only-ui"
        // legacy_v2109_audit_marker: versionName = "2.10.9-ci-hardening-root-cause-integration-button-only-ui"
        // legacy_v2110_audit_marker: versionName = "2.11.0-data-harmonization-soft-guard-root-cause-button-only-ui"
        // legacy_v212101_audit_marker: versionName = "2.12.10.1-final-research-value-booster-unified"
        // legacy_v21212_audit_marker: versionName = "2.12.12-final-terminal-discovery-continuation-unified"
        // legacy_v21213_audit_marker: versionName = "2.12.13-final-pharma-grade-strict-discovery-unified"
        // legacy_v21214_audit_marker: versionName = "2.12.14-final-professional-research-release-unified"
        // legacy_v21215_audit_marker: versionName = "2.12.15-final-background-metadata-consistency-unified"
        // legacy_v2131_compat_marker: versionName = "2.12.16-final-injected-metadata-execution-unified"
// legacy_v2131_compat_marker: versionName = "2.12.17-final-search-stability-resume-unified"
// legacy_v2131_compat_marker: versionName = "2.12.18-final-ten-ten-research-engine-unified"
// legacy_v2131_compat_marker: versionName = "2.12.19-final-release-lock-validated"
        // legacy_v2130_audit_marker: versionName = "2.13.0-final-future-evidence-lite-corpus-unified"
        // legacy_v2131_audit_marker: versionName = "2.13.1-final-expanded-disease-corpus-unified"
        // legacy_v2132_audit_marker: versionName = "2.13.2-final-verified-data-closure-unified"
        // legacy_v2170_audit_marker: versionName = "2.17.0-real-evidence-acquisition-parser"
        // legacy_v2171_audit_marker: versionName = "2.17.1-network-safe-evidence-pool"
        // legacy_v2172_audit_marker: versionName = "2.17.2.1-audit-version-alignment-hotfix"
        // legacy v30333 final audit marker: versionName = "3.0.3.33-final-unified-data-reality-discovery-engine"
        // legacy v30334 audit marker: versionName = "3.0.3.34-user-attested-matrix-safety"
        // legacy v30334 final unified audit marker: versionName = "3.0.3.34-final-unified-user-attested-matrix-engine"
        versionName = "3.0.3.35-curated-capsule-matrix-fuel-pack"
    }

    buildFeatures {
        viewBinding = true
        // v3.0.3.20 P0 CI fix: required because GTIMExperimentalClaimRelaxationV21312
        // gates sandbox export with BuildConfig.DEBUG. AGP 8+ does not always generate
        // BuildConfig unless this feature is explicitly enabled.
        buildConfig = true
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Release signing stays environment-controlled in CI/Play Console.
            // Do not commit keystore material into the repository.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
}

detekt {
    buildUponDefaultConfig = true
    allRules = false
    config.setFrom(files("../config/detekt/detekt.yml"))
}

// legacy audit version token: 1.10.22-alpha-accession-exhaustion-domain-activation
// legacy audit version token: 1.10.25-alpha-data-availability-query-priority
// legacy audit version token: versionCode = 89

// legacy audit version token: versionCode = 91
// legacy audit version token: 1.10.29-alpha-learning-domain-path-linkage
// legacy audit version token: versionName = "1.10.29-alpha-learning-domain-path-linkage"

// legacy_v30322_audit_marker: versionCode = 223
// legacy_v30322_audit_marker: versionName = "3.0.3.22-final-dataset-module-score"
// legacy audit marker only: versionCode = 244
// legacy audit marker only: versionName = "3.0.3.29-professional-discovery-engine"
