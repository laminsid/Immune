package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.41: Biomedical Research Ontology.
 *
 * This is a scientist/lab-facing vocabulary and concept-router layer. It is intentionally
 * not a consumer diagnosis engine. Diagnostic, disease, drug, herb, nutrition, organ,
 * blood, pathogen, genetics, cell, chromosome, and mitochondrial terms are allowed as
 * research phenotypes and lookup keys so the autonomous researcher can connect topics
 * faster and avoid wasting cycles rebuilding basic biomedical context.
 *
 * Boundary: terms guide research linking, metadata extraction, accession lookup, and
 * contradiction/control search. They do not produce patient diagnosis, treatment, dose,
 * drug ranking, supplement advice, or clinical recommendation.
 */
data class BiomedicalResearchOntologyReport(
    val active: Boolean,
    val state: String,
    val selectedDomains: List<String>,
    val matchedTerms: List<String>,
    val queryExpansionKeys: List<String>,
    val diagnosticPhenotypeMode: String,
    val researchUse: List<String>,
    val guardrails: List<String>,
    val nextAction: String,
    val claimLimit: String = BiomedicalResearchOntologyV11041.CLAIM_LIMIT
) {
    companion object {
        fun empty() = BiomedicalResearchOntologyReport(
            active = false,
            state = "NOT_EVALUATED",
            selectedDomains = emptyList(),
            matchedTerms = emptyList(),
            queryExpansionKeys = emptyList(),
            diagnosticPhenotypeMode = "OFF",
            researchUse = emptyList(),
            guardrails = emptyList(),
            nextAction = "No biomedical ontology routing available."
        )
    }
}

object BiomedicalResearchOntologyV11041 {
    const val CLAIM_LIMIT: String = "biomedical_research_ontology_routing_only_not_patient_diagnosis"

    private data class DomainPack(
        val id: String,
        val label: String,
        val terms: List<String>,
        val expansionKeys: List<String>,
        val researchUse: List<String>,
        val disabledByDefault: Boolean = false
    )

    private val commonGuardrails = listOf(
        "research phenotype vocabulary only",
        "clinical/lab terms may link hypotheses and datasets but cannot diagnose a person",
        "drug terms are perturbation/control vocabulary only: no dose, no ranking, no recommendation",
        "herb/food/vitamin terms are exposure/nutrition vocabulary only: no supplement advice",
        "pathogen terms require accession, human/patient context, outcome, control/comparator, and time order before hypothesis upgrade",
        "disease terms require explicit cohort/condition labels before route strengthening"
    )

    private val packs = listOf(
        DomainPack(
            id = "ORGAN_SYSTEMS",
            label = "Body organs and organ-system context",
            terms = listOf(
                "heart", "cardiac", "myocardial", "قلب", "lung", "pulmonary", "respiratory", "رئة", "brain", "cns", "دماغ", "nervous system", "liver", "hepatic", "كبد", "kidney", "renal", "كلية", "stomach", "gastric", "معدة", "gut", "intestine", "bowel", "أمعاء", "skin", "epithelial", "جلد", "joint", "synovial", "مفصل", "muscle", "عضلة", "limb", "extremity", "أطراف", "spleen", "طحال", "thymus", "bone marrow", "نخاع العظم", "lymph node", "عقد لمفاوية", "barrier tissue", "blood-brain barrier"
            ),
            expansionKeys = listOf("organ", "tissue_source", "cell_type", "barrier", "histology", "single-cell", "RNA-seq", "GSE", "PRJNA"),
            researchUse = listOf("route tissue context", "organ-specific phenotype linking", "barrier/tissue injury discriminator")
        ),
        DomainPack(
            id = "BLOOD_HEMATOLOGY_VASCULAR",
            label = "Blood, hematology, vascular and immune-cell context",
            terms = listOf(
                "blood pressure", "ضغط الدم", "hypertension", "hypotension", "red blood cell", "rbc", "erythrocyte", "كريات حمراء", "white blood cell", "wbc", "leukocyte", "كريات بيضاء", "lymphocyte", "lymphopenia", "neutrophil", "monocyte", "eosinophil", "basophil", "platelet", "صفائح", "hemoglobin", "هيموغلوبين", "ferritin", "crp", "esr", "d-dimer", "coagulation", "complement", "c3", "c4", "ige", "igg", "igm", "iga", "b cell", "t cell", "nk cell", "mast cell"
            ),
            expansionKeys = listOf("hematology", "CBC", "immune cell", "flow cytometry", "cytokine", "CRP", "ESR", "complement", "control", "cohort"),
            researchUse = listOf("lab phenotype linking", "immune-cell compartment routing", "vascular/inflammatory marker context")
        ),
        DomainPack(
            id = "PATHOGENS_VIRUS_BACTERIA_PARASITE",
            label = "Viruses, bacteria, parasites and infection trigger context",
            terms = listOf(
                "virus", "فيروس", "viral", "EBV", "Epstein-Barr", "HHV-6", "CMV", "cytomegalovirus", "SARS-CoV-2", "COVID", "Long COVID", "influenza", "hantavirus", "Hanta", "hepatitis", "HIV", "HSV", "Herpesviridae", "bacteria", "بكتيريا", "bacterial", "staphylococcus", "streptococcus", "tuberculosis", "mycobacterium", "h pylori", "parasite", "طفيليات", "plasmodium", "malaria", "toxoplasma", "leishmania", "fungal", "candida"
            ),
            expansionKeys = listOf("pathogen", "viral load", "serology", "PCR", "reactivation", "molecular mimicry", "control", "longitudinal", "negative control"),
            researchUse = listOf("trigger candidate routing", "reactivation/mimicry route prior", "infection-vs-inflammation discriminator")
        ),
        DomainPack(
            id = "COMMON_DISEASES_AND_CLINICAL_PHENOTYPES",
            label = "Common diseases and clinical phenotypes",
            terms = listOf(
                "diabetes", "سكري", "obesity", "سمنة", "hypertension", "asthma", "ربو", "allergy", "حساسية", "eczema", "urticaria", "autoimmunity", "autoimmune", "SLE", "lupus", "ذئبة", "rheumatoid arthritis", "RA", "التهاب المفاصل", "multiple sclerosis", "MS", "التصلب المتعدد", "ME/CFS", "chronic fatigue", "IBD", "Crohn", "ulcerative colitis", "thyroiditis", "Hashimoto", "cardiovascular disease", "heart failure", "COPD", "chronic kidney disease", "cancer", "sepsis", "migraine", "depression", "sleep disorder", "fever", "fatigue", "pain", "flare", "relapse", "severity", "recovery"
            ),
            expansionKeys = listOf("diagnostic phenotype", "condition label", "case label", "severity", "recovery", "flare", "relapse", "outcome", "matched control"),
            researchUse = listOf("diagnostic phenotype linking for scientists", "cohort/condition label detection", "outcome and severity routing")
        ),
        DomainPack(
            id = "GENETICS_CELLS_CHROMOSOMES_MITOCHONDRIA",
            label = "Genes, cells, chromosomes, mitochondria and omics context",
            terms = listOf(
                "gene", "جين", "genetic", "genome", "genomics", "transcriptome", "transcriptomics", "RNA-seq", "single-cell", "scRNA-seq", "cell", "خلية", "chromosome", "كروموسوم", "mtDNA", "mitochondria", "ميتوكوندريا", "epigenetic", "methylation", "SNP", "variant", "allele", "HLA", "MHC", "TCR", "BCR", "antibody", "autoantibody", "cytokine", "interferon", "NF-kB", "JAK", "STAT", "NLRP3", "oxidative stress", "apoptosis", "senescence"
            ),
            expansionKeys = listOf("omics", "gene signature", "cell type", "pathway", "HLA", "variant", "mitochondrial", "transcriptome", "metadata", "accession"),
            researchUse = listOf("omics-axis routing", "gene/cell/pathway linking", "mechanism vocabulary with metadata gates")
        ),
        DomainPack(
            id = "MEDICATIONS_RESEARCH_PERTURBATIONS",
            label = "Medication and pharmacologic perturbation vocabulary",
            terms = listOf(
                "antihistamine", "مضاد الحساسية", "loratadine", "cetirizine", "fexofenadine", "Telfast", "antibiotic", "مضاد حيوي", "amoxicillin", "azithromycin", "doxycycline", "metformin", "insulin", "statin", "beta blocker", "ACE inhibitor", "ARB", "NSAID", "anti-inflammatory", "مضاد التهاب", "corticosteroid", "glucocorticoid", "prednisone", "rituximab", "anti-CD20", "JAK inhibitor", "baricitinib", "tofacitinib", "biologic", "immunosuppressant", "vaccine", "psychotropic", "psychedelic", "hallucinogen", "مهلوسة"
            ),
            expansionKeys = listOf("drug exposure", "perturbation", "treated cohort", "untreated control", "washout", "medication metadata", "no dose", "no treatment advice"),
            researchUse = listOf("drug exposure/control detection", "pharmacologic perturbation context", "confounder and artifact control")
        ),
        DomainPack(
            id = "HERBS_FOODS_NUTRITION_EXPOSURES",
            label = "Herbs, foods, vitamins and nutrition exposure vocabulary",
            terms = listOf(
                "wormwood", "شيح", "artemisia", "eucalyptus", "كاليبتوس", "honey", "عسل", "natural honey", "curcumin", "turmeric", "quercetin", "ashwagandha", "ginger", "garlic", "olive oil", "propolis", "vitamin d", "vitamin c", "vitamin b12", "folate", "vitamin a", "vitamin e", "zinc", "selenium", "iron", "magnesium", "omega-3", "fiber", "polyphenol", "nutrition", "diet", "microbiome"
            ),
            expansionKeys = listOf("nutrition exposure", "dietary compound", "vitamin status", "micronutrient", "microbiome", "oxidative stress", "NF-kB", "no supplement advice", "control"),
            researchUse = listOf("exposure vocabulary for nutrition/immunology studies", "micronutrient-immune axis routing", "noise-controlled natural compound research"),
            disabledByDefault = false
        ),
        DomainPack(
            id = "VITAMINS_AND_IMMUNE_FUNCTION",
            label = "Vitamins/minerals and immune-function context",
            terms = listOf(
                "vitamin d", "25(OH)D", "vitamin c", "ascorbic acid", "vitamin b12", "cobalamin", "folate", "vitamin a", "retinoic acid", "vitamin e", "tocopherol", "zinc", "selenium", "iron", "ferritin", "magnesium", "deficiency", "supplement", "micronutrient", "immune function", "barrier immunity", "antioxidant"
            ),
            expansionKeys = listOf("micronutrient", "deficiency", "immune function", "cohort", "serum level", "control", "no supplementation recommendation", "outcome label"),
            researchUse = listOf("nutrient status as exposure/phenotype", "immune-function modifier routing", "confounder tracking")
        )
    )

    fun evaluate(
        steering: ResearchSteeringProfile?,
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        evidencePrior: EvidencePriorSelectionReport,
        recentReports: List<String>
    ): BiomedicalResearchOntologyReport {
        val corpus = buildCorpus(steering, leadObjects, candidates, evidencePrior, recentReports)
        val scored = packs.mapNotNull { pack ->
            val hits = pack.terms.filter { corpus.contains(it.lowercase(Locale.US)) }.distinct().take(18)
            val priorBoost = if (evidencePrior.selectedRoute.contains(pack.id.substringBefore('_'), ignoreCase = true)) 4 else 0
            val score = hits.size * 5 + priorBoost - if (pack.disabledByDefault) 12 else 0
            if (score <= 0) null else Triple(pack, hits, score)
        }.sortedByDescending { it.third }

        val selected = if (scored.isEmpty()) {
            listOf(packs.first { it.id == "COMMON_DISEASES_AND_CLINICAL_PHENOTYPES" }, packs.first { it.id == "GENETICS_CELLS_CHROMOSOMES_MITOCHONDRIA" })
        } else {
            scored.take(4).map { it.first }
        }
        val matched = scored.flatMap { it.second }.distinct().take(36)
        val expansionKeys = selected.flatMap { it.expansionKeys }.distinct().take(42)
        val use = selected.flatMap { it.researchUse }.distinct().take(14)
        val diagnosticMode = if (selected.any { it.id == "COMMON_DISEASES_AND_CLINICAL_PHENOTYPES" }) {
            "DIAGNOSTIC_PHENOTYPE_VOCABULARY_ALLOWED_FOR_RESEARCH_LINKING"
        } else {
            "CLINICAL_TERMS_ALLOWED_AS_RESEARCH_CONTEXT_ONLY"
        }
        val state = when {
            scored.isEmpty() -> "ONTOLOGY_BASELINE_READY_NO_TOPIC_MATCH"
            selected.any { it.id == "PATHOGENS_VIRUS_BACTERIA_PARASITE" } -> "ONTOLOGY_PATHOGEN_AND_PHENOTYPE_ROUTING_READY"
            selected.any { it.id == "MEDICATIONS_RESEARCH_PERTURBATIONS" } -> "ONTOLOGY_PERTURBATION_CONTROL_ROUTING_READY"
            else -> "ONTOLOGY_RESEARCH_LINKING_READY"
        }
        return BiomedicalResearchOntologyReport(
            active = true,
            state = state,
            selectedDomains = selected.map { it.id },
            matchedTerms = matched,
            queryExpansionKeys = expansionKeys,
            diagnosticPhenotypeMode = diagnosticMode,
            researchUse = use,
            guardrails = commonGuardrails,
            nextAction = "Use ontology keys to expand accession lookup, metadata parsing, route classification, contradiction/control search, and lab phenotype linking; do not output patient diagnosis or treatment advice."
        )
    }

    private fun buildCorpus(
        steering: ResearchSteeringProfile?,
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        evidencePrior: EvidencePriorSelectionReport,
        recentReports: List<String>
    ): String {
        val parts = mutableListOf<String>()
        steering?.let { parts += listOf(it.topic, it.focus, it.variables.joinToString(" "), it.inferredAxes.joinToString(" ")) }
        parts += leadObjects.flatMap { listOf(it.source, it.title, it.snippet, it.domain, it.organism, it.omicsType, it.detectedAccessions.joinToString(" ")) }
        parts += candidates.flatMap { listOf(it.accession, it.source, it.sourceTitle, it.sourceUrl, it.organismHint, it.conditionLabelsHint, it.outcomeLabelsHint, it.triggerResponseOutcomeHint, it.timeCourseHint, it.sampleSizeHint, it.dataType, it.status, it.reasons.joinToString(" ")) }
        parts += listOf(evidencePrior.selectedPriorId, evidencePrior.selectedRoute, evidencePrior.queryTerms.joinToString(" "))
        parts += recentReports.takeLast(12)
        return parts.joinToString(" ").lowercase(Locale.US)
    }
}
