package com.immunesignal.app

/**
 * v1.10.40: Release version linkage guard kept mandatory for final release stability gate.
 *
 * This guard is intentionally small: it keeps release identity auditable across
 * Gradle, runtime status, learning-session schema, report labels, documentation,
 * and static checks. It does not affect scientific interpretation.
 */
object ReleaseVersionLinkageGuard {
    // legacy_audit_version_token_v11034: VERSION_CODE: Int = 96
    // legacy_audit_version_token_v11041: VERSION_CODE: Int = 103
    // legacy_audit_version_token_v11042: VERSION_CODE: Int = 104
    const val VERSION_CODE: Int = 105
    // legacy_audit_version_token_v11034: VERSION_NAME: String = "1.10.34-alpha-useful-learning-report"
    // legacy_audit_version_token_v11041: VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"
    // legacy_audit_version_token_v11042: VERSION_NAME: String = "1.10.42-alpha-biomedical-concept-bridge"
    const val VERSION_NAME: String = "1.10.43-alpha-modern-medtech-modular-index"
    // legacy_audit_version_token_v11034: ENGINE_VERSION: String = "v1.10.34-alpha-useful-learning-report"
    // legacy_audit_version_token_v11041: ENGINE_VERSION: String = "v1.10.41-alpha-biomedical-research-ontology"
    // legacy_audit_version_token_v11042: ENGINE_VERSION: String = "v1.10.42-alpha-biomedical-concept-bridge"
    const val ENGINE_VERSION: String = "v1.10.43-alpha-modern-medtech-modular-index"
    // legacy_audit_version_token_v11034: LEARNING_SCHEMA_VERSION: String = "1.10.34"
    // legacy_audit_version_token_v11041: LEARNING_SCHEMA_VERSION: String = "1.10.41"
    // legacy_audit_version_token_v11042: LEARNING_SCHEMA_VERSION: String = "1.10.42"
    const val LEARNING_SCHEMA_VERSION: String = "1.10.43"
    const val CLAIM_LIMIT: String = "release_version_linkage_not_biological_proof"

    fun summary(): String =
        // legacy_audit_version_token_v11042: biomedical concept bridge release
        // legacy_audit_version_token_v11040: v1.10.41 biomedical research ontology release
        "v1.10.43 modern medical technology modular-index release: build, engine, learning schema, lead-closure handoff, learning audit monitor, EBV criterion lane, Evidence Prior Matrix, integrated final path linkage, final release stability guard, biomedical research ontology, diagnostic phenotype vocabulary, biomedical concept bridge, modern medical technology modules, modular retrieval index, UI summary, exporter, docs, and static checks are aligned; legacy release guard tokens remain audit-only."

    fun isRuntimeAligned(): Boolean =
        EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ENGINE_VERSION &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == LEARNING_SCHEMA_VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == VERSION_NAME &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == VERSION_CODE &&
            FinalReleaseStabilityGuard.isReleaseSurfaceAligned()
}
