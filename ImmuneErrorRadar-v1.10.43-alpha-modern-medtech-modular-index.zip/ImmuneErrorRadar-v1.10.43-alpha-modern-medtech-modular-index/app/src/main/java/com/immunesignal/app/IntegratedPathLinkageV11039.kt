package com.immunesignal.app

/**
 * v1.10.39: final integrated path linkage.
 *
 * This guard joins the release-era routing layers into one decision surface:
 * dataset path coverage, learning/domain linkage, manual/weak lead linkage,
 * lead closure, metadata closure, unknown-route prior, EBV criterion lane, and
 * Evidence Prior Matrix. It is an integrity/reporting layer only.
 */
data class IntegratedPathLinkageReport(
    val active: Boolean,
    val state: String,
    val connectedLayers: List<String>,
    val consumedWarnings: List<String>,
    val openWarnings: List<String>,
    val finalDecision: String,
    val nextAction: String,
    val releaseLayerVersion: String = "v1.10.39-alpha-final-path-linkage-release",
    val claimLimit: String = IntegratedPathLinkageGuard.CLAIM_LIMIT
) {
    companion object {
        fun empty() = IntegratedPathLinkageReport(
            active = false,
            state = "NOT_EVALUATED",
            connectedLayers = emptyList(),
            consumedWarnings = emptyList(),
            openWarnings = emptyList(),
            finalDecision = "No final path linkage was evaluated.",
            nextAction = "Run a research cycle before final path linkage."
        )
    }
}

object IntegratedPathLinkageGuard {
    const val CLAIM_LIMIT: String = "integrated_path_linkage_not_biological_proof"

    fun evaluate(
        pathLinkage: DatasetForagingPathLinkageReport,
        learningDomain: LearningDomainPathLinkageReport,
        evidenceLead: EvidenceLeadPathLinkageReport,
        leadClosure: LeadClosureHandoffReport,
        metadataClosure: MetadataClosureReport,
        unknownRoute: UnknownRouteClassificationReport,
        ebv: EBVLeadVerificationReport,
        evidencePrior: EvidencePriorSelectionReport
    ): IntegratedPathLinkageReport {
        val connected = linkedSetOf<String>()
        if (pathLinkage.active) connected += "dataset_path_coverage"
        if (learningDomain.active) connected += "learning_domain_handoff"
        if (evidenceLead.active) connected += "manual_weak_lead_handoff"
        if (leadClosure.active) connected += "lead_closure_handoff"
        if (metadataClosure.active) connected += "metadata_closure"
        if (unknownRoute.active) connected += "unknown_route_prior"
        if (ebv.active) connected += "ebv_criterion_lane"
        if (evidencePrior.active) connected += "evidence_prior_matrix"

        val leadClosureConsumesPathWarning = leadClosure.active && metadataClosure.active && evidencePrior.active
        val consumed = mutableListOf<String>()
        val open = mutableListOf<String>()
        (pathLinkage.warnings + learningDomain.warnings + evidenceLead.warnings).distinct().forEach { warning ->
            val lower = warning.lowercase()
            val consumedByClosure = leadClosureConsumesPathWarning && (
                lower.contains("mature-domain probe") ||
                    lower.contains("path coverage") ||
                    lower.contains("breakthrough state") ||
                    lower.contains("final forager") ||
                    lower.contains("pass_coverage_gap")
                )
            if (consumedByClosure) consumed += warning else open += warning
        }

        val metadataBlocked = metadataClosure.missingFields.any { it in listOf("accession", "control_or_comparator", "time_order", "outcome_labels") }
        val state = when {
            open.isNotEmpty() -> "FINAL_PATH_LINKAGE_OPEN_WARNINGS"
            metadataBlocked -> "FINAL_PATHS_CONNECTED_METADATA_LOCKED"
            ebv.state == "EBV_CRITERION_READY_FOR_FALSIFICATION_REVIEW" -> "FINAL_PATHS_CONNECTED_EBV_READY_FOR_FALSIFICATION"
            evidencePrior.state.contains("READY_FOR_CONTRADICTION") -> "FINAL_PATHS_CONNECTED_READY_FOR_CONTRADICTION"
            connected.isNotEmpty() -> "FINAL_PATHS_CONNECTED"
            else -> "FINAL_PATHS_NOT_CONNECTED"
        }

        val decision = when (state) {
            "FINAL_PATH_LINKAGE_OPEN_WARNINGS" -> "Do not trust autonomous continuation until open path warnings are repaired."
            "FINAL_PATHS_CONNECTED_METADATA_LOCKED" -> "All active layers point to the same gate: close accession/control/time/outcome metadata before any broad search or claim."
            "FINAL_PATHS_CONNECTED_EBV_READY_FOR_FALSIFICATION" -> "EBV criterion lane is sufficiently closed for contradiction/negative-control review, but still not biological proof."
            "FINAL_PATHS_CONNECTED_READY_FOR_CONTRADICTION" -> "Evidence prior is ready for contradiction micro-probe; keep claims locked."
            "FINAL_PATHS_CONNECTED" -> "Active routing layers are connected; continue through the selected next gate only."
            else -> "No integrated path can be trusted yet."
        }

        val next = when {
            open.isNotEmpty() -> "Repair final path linkage: ${open.first()}"
            metadataClosure.active -> metadataClosure.nextAction
            ebv.active -> ebv.allowedNextAction
            evidencePrior.active -> evidencePrior.nextAction
            leadClosure.active -> leadClosure.forcedNextAction
            else -> "Run bounded lead/metadata closure before broad search."
        }

        return IntegratedPathLinkageReport(
            active = connected.isNotEmpty(),
            state = state,
            connectedLayers = connected.toList(),
            consumedWarnings = consumed.distinct(),
            openWarnings = open.distinct(),
            finalDecision = decision,
            nextAction = next
        )
    }
}
