#!/usr/bin/env bash
# legacy audit token: 1.10.34-alpha-useful-learning-report audit_release_version_linkage_v11031.py
set -euo pipefail
# Compatibility wrapper. current release: 1.10.43-alpha-modern-medtech-modular-index; legacy v1.10.41-alpha-biomedical-research-ontology; audits v11031/v11032/v11034/v11035/v11036/v11037/v11038/v11039/v11040/v11041/v11042/v11043
# Compatibility wrapper. Use run_static_checks_fast.sh for PRs and run_static_checks_full.sh for release gates.
exec bash scripts/run_static_checks_full.sh "$@"
# legacy release token: 1.10.42-alpha-biomedical-concept-bridge
