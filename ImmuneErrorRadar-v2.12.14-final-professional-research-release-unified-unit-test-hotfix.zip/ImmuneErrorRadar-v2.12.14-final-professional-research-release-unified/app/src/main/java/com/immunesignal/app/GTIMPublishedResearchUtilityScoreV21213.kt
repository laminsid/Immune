package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.13 — Published research utility score.
 *
 * Scores how reusable a paper/GSE/DOI/PMID/GEO handle is for GTIM evidence routing. This
 * is not biological evidence; it decides whether published material is useful as a seed.
 */
object GTIMPublishedResearchUtilityScoreV21213 {
    const val VERSION: String = "2.12.13-published-research-utility-score"
    const val CLAIM_LIMIT: String = "published_research_utility_seed_score_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val text = report.toString()
        val handles = handles(text)
        val topicFit = if (hasDomainRoute(report)) 2 else 1
        val humanSample = if (text.contains("human", true) || text.contains("PBMC", true) || text.contains("blood", true)) 2 else 0
        val comparator = if (text.contains("comparator", true) || text.contains("case/control", true) || text.contains("control", true) || text.contains("severity", true)) 2 else 0
        val dataAvailability = if (handles.length() > 0) 1 else 0
        val matrix = if (text.contains("matrix", true) || text.contains("processed-expression", true) || text.contains("capsule", true)) 1 else 0
        val sampleProvenance = if (text.contains("sample-to-source", true) || text.contains("sample linkage", true) || text.contains("provenance", true)) 1 else 0
        val contradiction = if (text.contains("contradiction", true) || text.contains("falsif", true)) 1 else 0
        val score = (topicFit + humanSample + comparator + dataAvailability + matrix + sampleProvenance + contradiction).coerceAtMost(10)
        return JSONObject()
            .put("version", VERSION)
            .put("state", state(score, handles.length()))
            .put("score", score)
            .put("maxScore", 10)
            .put("components", JSONObject()
                .put("topicFit", topicFit)
                .put("humanSampleRelevance", humanSample)
                .put("comparatorLabels", comparator)
                .put("dataHandleAvailability", dataAvailability)
                .put("matrixOrCapsuleHint", matrix)
                .put("sampleProvenance", sampleProvenance)
                .put("contradictionResistance", contradiction))
            .put("candidateHandles", handles)
            .put("decision", decision(score))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        return listOf(
            "Published research utility score",
            "Score: ${obj.optInt("score", 0)}/${obj.optInt("maxScore", 10)}; state=${obj.optString("state", "UNKNOWN")}; decision=${obj.optString("decision", "background literature only")}",
            "Use: scores reuse value of GSE/PMID/DOI/literature as a seed; it does not upgrade biological evidence.",
            "Boundary: published ≠ validated for this topic until topic-fit, comparator, sample linkage, capsule/matrix, and contradiction gates close."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "Published research utility score",
        "topicFit",
        "humanSampleRelevance",
        "comparatorLabels",
        "background_literature_only",
        CLAIM_LIMIT
    ))

    private fun hasDomainRoute(report: JSONObject): Boolean = report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainKey").orEmpty().isNotBlank()
        || report.toString().contains("domain_specific_route", true)

    private fun state(score: Int, handleCount: Int): String = when {
        score >= 8 -> "HIGH_UTILITY_SEED_REVIEW_TARGET_NOT_EVIDENCE"
        score >= 6 -> "MODERATE_UTILITY_SEED_NEEDS_METADATA_CLOSURE"
        score >= 4 && handleCount > 0 -> "WEAK_UTILITY_HANDLE_NEEDS_REVIEW"
        else -> "BACKGROUND_LITERATURE_ONLY"
    }

    private fun decision(score: Int): String = when {
        score >= 8 -> "promote_to_review_target_if_claim_guards_pass"
        score >= 6 -> "keep_as_metadata_seed_candidate"
        score >= 4 -> "hold_for_manual_review_only"
        else -> "background_literature_only"
    }

    private fun handles(text: String): JSONArray {
        val out = JSONArray()
        Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|SRR\\d+|PRJNA\\d+|PRJEB\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+|PMID:?\\d+|10\\.\\d{4,9}/[^\\s\\\"']+)\\b", RegexOption.IGNORE_CASE)
            .findAll(text).map { it.value.uppercase() }.distinct().take(12).forEach { out.put(it) }
        return out
    }
}
