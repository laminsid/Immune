package com.immunesignal.app

/**
 * GTIM v2.6.2 final integration release surface.
 *
 * This guard closes the gap around one unified Android/GTIM product version. It does not add new scientific claims;
 * it proves that the GTIM dossier is visible, bounded, CI-checkable, and Play-safe.
 */
data class GTIMReleaseSurfaceHardeningReportV252(
    val passed: Boolean,
    val status: String,
    val androidReleaseTrain: String,
    val gtimProductEngineVersion: String,
    val verifiedSurfaces: List<String>,
    val blockingIssues: List<String>,
    val playProtectPosture: String,
    val githubPosture: String,
    val scientificClaimPosture: String,
    val nextAction: String
)

object GTIMReleaseSurfaceHardeningV252 {
    const val GTIM_PRODUCT_ENGINE_VERSION: String = "2.6.2-alpha-learning-loop-activation"
    const val ANDROID_RELEASE_TRAIN_NOTE: String = "Unified release train: Android app, runtime engine, learning schema, and GTIM product surface are tracked as 2.6.2-alpha-learning-loop-activation."

    fun evaluate(
        dossier: GTIMDiscoveryDossierReportV250,
        routeIntegrity: GTIMRouteIntegrityReportV251
    ): GTIMReleaseSurfaceHardeningReportV252 {
        val surfaces = buildList {
            if (dossier.active) add("gtim_dossier_active")
            if (dossier.evidenceObjects.isNotEmpty()) add("evidence_objects_exported")
            if (dossier.mechanismCandidates.isNotEmpty()) add("mechanism_candidates_exported")
            if (dossier.conciseLines.isNotEmpty()) add("compact_ui_lines_available")
            if (dossier.claimGuardrails.any { it.contains("No diagnosis", ignoreCase = true) }) add("no_diagnosis_guardrail_visible")
            if (dossier.noveltyBoundary.contains("corpus", ignoreCase = true)) add("corpus_relative_novelty_visible")
            if (dossier.peerReviewDossierSections.any { it.contains("Falsifiability", ignoreCase = true) }) add("falsifiability_section_visible")
            if (routeIntegrity.passed) add("route_integrity_passed")
        }.distinct()

        val issues = mutableListOf<String>()
        if (!dossier.active) issues += "GTIM dossier is inactive"
        if (!routeIntegrity.passed) issues += "GTIM route integrity has not passed"
        if (dossier.claimGuardrails.none { it.contains("No diagnosis", ignoreCase = true) }) issues += "No-diagnosis guardrail is not visible"
        if (dossier.claimGuardrails.none { it.contains("treatment", ignoreCase = true) }) issues += "No-treatment guardrail is not visible"
        if (!dossier.noveltyBoundary.contains("corpus", ignoreCase = true)) issues += "Novelty boundary must be corpus-relative"
        if (dossier.mechanismCandidates.any { it.status.contains("CONFIRMED", ignoreCase = true) }) issues += "GTIM mechanism candidate status cannot claim confirmation"
        if (dossier.mechanismCandidates.any { it.confidenceIndex.score >= 90 }) issues += "GTIM confidence cannot reach 90+ without external validation"
        if (dossier.mechanismCandidates.any { candidate -> candidate.whatWouldFalsify.isEmpty() || candidate.labValidationPlan.recommendedExperiments.isEmpty() }) {
            issues += "Every GTIM mechanism candidate must include falsification and lab-validation plan"
        }

        val passed = issues.isEmpty() && surfaces.contains("route_integrity_passed") && surfaces.contains("compact_ui_lines_available")
        return GTIMReleaseSurfaceHardeningReportV252(
            passed = passed,
            status = if (passed) "GTIM_RELEASE_SURFACE_HARDENED" else "GTIM_RELEASE_SURFACE_REPAIR_REQUIRED",
            androidReleaseTrain = RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME,
            gtimProductEngineVersion = GTIM_PRODUCT_ENGINE_VERSION,
            verifiedSurfaces = surfaces,
            blockingIssues = issues.distinct(),
            playProtectPosture = "research-only UI, no new sensitive permissions, no background telemetry, no diagnosis/treatment/patient-prediction language, relaxed exploration stays claim-bounded",
            githubPosture = "fast static gate includes unified version linkage, relaxed-exploration policy, GTIM route integrity, JSON validation, Kotlin delimiter, and Play-safe manifest posture",
            scientificClaimPosture = "hypothesis-generation only; weak leads, text-mined leads, cross-species priors, and reference controls cannot become confirmed biological findings",
            nextAction = if (passed) "Proceed to GitHub compile/test gate; do not add new scientific layers before CI is green." else issues.firstOrNull() ?: "Inspect GTIM release surface."
        )
    }
}
