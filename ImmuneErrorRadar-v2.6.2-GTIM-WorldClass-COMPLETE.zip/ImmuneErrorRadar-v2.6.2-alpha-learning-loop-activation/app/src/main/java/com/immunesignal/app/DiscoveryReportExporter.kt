// legacy_v1113_v1114_audit_token: Research-Grade Mechanism Dossier v1.11.4
// legacy_v1113_v1114_audit_token: Metadata/Hyper-Drive Strategy Matrix v1.11.4
// legacy_audit_v11051: Route Reconciliation / EvidenceObjectCandidate v1.10.51; Post-PubMed strategies reconciled v1.10.51; Mature domain focus v1.10.32 reconciled by v1.10.51; Knowledge gap queue v1.10.32 reconciled by v1.10.51; Strong route fingerprint v1.10.32 reconciled by v1.10.51
package com.immunesignal.app

// legacy audit token: Exposome Topic Route
// legacy audit token: Exposome Topic Route / EvidenceObjectCandidate v1.10.50

// legacy audit token: Topic Route Correction / EvidenceObjectCandidate v1.10.49

// legacy_audit_token: Topic-Fit / Metadata Parse UI Clarity v1.10.47

// legacy audit token: Domain expertise activation v1.10.22

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// legacy audit token: source arbitration & domain expertise activation
// legacy audit token: Dataset parser, accession acquisition, source arbitration & domain expertise activation
// legacy audit token: Accession acquisition v1.10.22
// legacy_audit_version_token_v11029_exporter: Learning/domain path linkage v1.10.29
// legacy audit token: release guard v1.10.34
object DiscoveryReportExporter {
    // legacy audit token: Dataset path linkage v1.10.27
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US)


    fun exportText(context: Context, report: JSONObject, text: String): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "immune_discovery_${dateFormat.format(Date())}.txt")
        file.writeText(text.ifBlank { "No report content." })
        return file
    }



    private fun exportConcisePdfV11061(context: Context, report: JSONObject): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "immune_discovery_${dateFormat.format(Date())}.pdf")
        val pdf = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11.5f }
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; isFakeBoldText = true }
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        var y = 42f
        fun draw(text: String, p: Paint = paint) {
            val chunks = wrap(text, if (p == title) 48 else 90)
            for (chunk in chunks) {
                if (y > 805f) break
                page.canvas.drawText(chunk, 32f, y, p)
                y += if (p == title) 23f else 15.5f
            }
        }
        val lines = GlobalResearchGradeBriefV11061.renderLines(report)
        lines.forEachIndexed { index, value ->
            if (index == 0) draw(value, title) else draw(value)
            if (index in setOf(1, 4, 10, 15)) y += 5f
        }
        pdf.finishPage(page)
        file.outputStream().use { pdf.writeTo(it) }
        pdf.close()
        return file
    }
    fun export(context: Context, report: JSONObject): File {
        if (RuntimeFeatureFlags.ENABLE_GLOBAL_RESEARCH_GRADE_BRIEF_V11061) return exportConcisePdfV11061(context, report)
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "immune_discovery_${dateFormat.format(Date())}.pdf")
        val pdf = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f }
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; isFakeBoldText = true }
        var pageNum = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNum).create())
        var y = 36f

        fun newPage() {
            pdf.finishPage(page)
            pageNum += 1
            page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNum).create())
            y = 36f
        }

        fun line(text: String, p: Paint = paint) {
            val chunks = wrap(text, if (p == title) 52 else 88)
            for (chunk in chunks) {
                if (y > 805f) newPage()
                page.canvas.drawText(chunk, 32f, y, p)
                y += if (p == title) 22f else 15f
            }
        }

        line("Immune Error Radar — Research Autopilot Discovery Report", title)
        line("Generated: ${report.optString("createdAtText", "")}")
        line("Completed: ${report.optString("completedAtText", "")}")
        line("Stop reason: ${report.optString("stopReason", "completed")}")
        line("Boundary: research leads only. No diagnosis, treatment, drug ranking, or clinical recommendation.")
        val runtime = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val execution = report.optJSONObject("executionLockReport") ?: JSONObject()
        line("Active engine: ${runtime.optString("engineVersion", "unknown")}")
        line("Research state: ${runtime.optString("researchState", "UNKNOWN")}")
        line("Execution lock: ${execution.optString("status", "UNKNOWN")}")
        val executedQueryCount = (report.optJSONArray("queries") ?: JSONArray()).length()
        val plannedQueryBudget = runtime.optInt("effectiveMaxQueries", 0)
        val plannedResultBudget = runtime.optInt("effectiveResultsPerQuery", 0)
        if (executedQueryCount == 0) {
            line("Search executed: 0 • Planned budget: $plannedQueryBudget queries x $plannedResultBudget results • Status: NOT_EXECUTED_OR_BLOCKED")
        } else {
            line("Search executed: $executedQueryCount query path(s) • Planned budget: $plannedQueryBudget queries x $plannedResultBudget results")
        }
        line("Runtime failover applied: ${runtime.optBoolean("runtimeFailoverApplied", false)}")
        val foragerTop = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        line("Dataset-first forager: ${foragerTop.optString("state", "NOT_RUN")} • mode ${foragerTop.optString("evidenceMode", "unknown")}")
        val topScoreSep = foragerTop.optJSONObject("scoreSeparation") ?: JSONObject()
        line("Score separation: usability ${topScoreSep.optInt("datasetUsabilityScore", 0)}/100 • route-fit ${topScoreSep.optInt("routeFitScore", 0)}/100 • hypothesis ${topScoreSep.optInt("hypothesisConfidenceScore", 0)}/100 • ${topScoreSep.optString("scoreState", "NOT_EVALUATED")}")
        line("Direct sources attempted: ${arrayToString(foragerTop.optJSONArray("sourceFamiliesAttempted"))}")
        val topNoCandidateArr = foragerTop.optJSONArray("noCandidateLearningRecords")
        val topNoCandidate = topNoCandidateArr?.optJSONObject((topNoCandidateArr.length() - 1).coerceAtLeast(0))
        if (topNoCandidate != null) {
            line(noCandidateHeaderLine(topNoCandidate))
        }
        val exploratoryLeadCount = (foragerTop.optJSONArray("candidates") ?: JSONArray()).let { arr ->
            (0 until arr.length()).count { idx -> arr.optJSONObject(idx)?.optString("status") == "EXPLORATORY_LEAD_NEEDS_ACCESSION" }
        }
        if (exploratoryLeadCount > 0) {
            line("Exploratory leads captured: $exploratoryLeadCount • strictness lowered for capture only; claims remain locked.")
        }
        val creativeTop = foragerTop.optJSONObject("creativeHypothesisForgeReport") ?: JSONObject()
        if (creativeTop.optBoolean("active", false)) {
            val steeringAxesTop = creativeTop.optJSONArray("steeringAxesUsed") ?: JSONArray()
            line("Creative hypotheses generated: ${(creativeTop.optJSONArray("generated") ?: JSONArray()).length()} • ${creativeTop.optString("claimLimit", "creative_hypothesis_not_evidence")}")
            if (steeringAxesTop.length() > 0) line("Steering-aware axes: ${axisIds(steeringAxesTop)}")
            line("Creative test query: ${creativeTop.optString("selectedQuery", "").take(220)}")
        }
        y += 8f

        line("Short discovery summary", title)
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val v3 = report.optJSONObject("reportV3") ?: JSONObject()
        line("Cycle result: ${v3.optString("cycleResult", "No cycle result")}")
        line("Integrity lock: ${v3.optString("integrityStatus", "UNKNOWN")}")
        line("Hypothesis: ${v3.optString("hypothesis", "No active hypothesis")}")
        line("Supporting evidence: ${v3.optString("supportingEvidence", "No supporting evidence section")}")
        line("Counter-evidence / contradiction: ${v3.optString("counterEvidenceOrContradiction", "No contradiction section")}")
        line("What we do not believe yet: ${v3.optString("whatWeDoNotBelieveYet", "No unknowns section")}")
        line("Next autonomous move: ${v3.optString("nextAutonomousMove", "Run next cycle")}")
        line("New sources saved: ${delta.optInt("newSourcesSaved", 0)} • Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)} • DNA/RNA signals: ${delta.optInt("dnaRnaSignals", 0)} • Steered queries: ${delta.optInt("steeredQueriesGenerated", 0)} • Manual reports used: ${delta.optInt("manualReportSignalsUsed", 0)}")
        val steering = report.optJSONObject("activeSteeringProfile")
        if (steering != null) {
            line("Research steering", title)
            line("Variables: ${arrayToString(steering.optJSONArray("variables"))}")
            line("Focus: ${steering.optString("focusQuestion", "")}")
            line("Required: ${arrayToString(steering.optJSONArray("requiredTerms"))}")
            line("Excluded: ${arrayToString(steering.optJSONArray("excludedTerms"))}")
            line("Inferred axes: ${arrayToString(steering.optJSONArray("inferredAxes"))}")
        }
        line("New axis pairs:")
        writeArray(delta.optJSONArray("newAxisPairs")) { line("• $it") }
        line("Learning notes:")
        writeArray(delta.optJSONArray("learningNotes")) { line("• $it") }
        y += 8f

        line("Dataset parser, evidence-lead/manual-seed, mature-domain focus, pass coverage, learning-domain linkage, lead closure, learning audit monitor & release guard v1.10.36", title)
        val forager = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        line("Active: ${forager.optBoolean("active", false)} • State: ${forager.optString("state", "NOT_RUN")} • Mode: ${forager.optString("evidenceMode", "unknown")}")
        val onePageEvidence = forager.optJSONObject("onePageExecutiveEvidenceReport") ?: JSONObject()
        if (onePageEvidence.length() > 0) {
            line("One-page evidence decision v1.10.31: cycle=${onePageEvidence.optString("cycleValidity", "VALID_NO_EVIDENCE")} • evidence=${onePageEvidence.optString("evidenceFound", "none")} • bestLead=${onePageEvidence.optString("bestLead", "none")}")
            line("  Next: ${onePageEvidence.optString("nextAction", "none")}")
            line("  Do not believe yet: ${arrayToString(onePageEvidence.optJSONArray("doNotBelieveYet"))}")
        }
        val learningValue = forager.optJSONObject("learningValueScoreReport") ?: JSONObject()
        if (learningValue.optBoolean("active", false)) {
            line("Useful learning v1.10.34: ${learningValue.optString("state", "NOT_EVALUATED")} • value=${learningValue.optInt("score", 0)}/100 • evidence=${learningValue.optString("evidenceStatus", "none")}")
            line("  Learned: ${learningValue.optString("learnedSummary", "none")}")
            line("  Outcomes: ${arrayToString(learningValue.optJSONArray("usefulOutcomes"))}")
            line("  Next: ${learningValue.optString("nextAction", "none")}")
        }
        val topicMemory = forager.optJSONObject("topicMemoryLedgerReport") ?: JSONObject()
        if (topicMemory.optBoolean("active", false)) {
            val activeThread = topicMemory.optJSONObject("activeThread") ?: JSONObject()
            line("Topic memory v1.10.34: threads=${topicMemory.optInt("threadCount", 0)} • active=${activeThread.optString("topic", "none")} • axis=${activeThread.optString("immuneAxis", "none")}")
            line("  Next query: ${activeThread.optString("nextQuery", "none")}")
        }
        val leadQueue = forager.optJSONObject("leadInspectionQueueReport") ?: JSONObject()
        if (leadQueue.optBoolean("active", false)) {
            line("Lead inspection queue v1.10.34: ${leadQueue.optString("queueState", "NOT_EVALUATED")} • open=${leadQueue.optInt("openItems", 0)}")
            val leadItems = leadQueue.optJSONArray("items") ?: JSONArray()
            for (i in 0 until leadItems.length().coerceAtMost(3)) {
                val item = leadItems.optJSONObject(i) ?: continue
                line("• ${item.optString("label", "lead")} — ${item.optString("status", "LEAD_ONLY_NOT_EVIDENCE")} • missing=${arrayToString(item.optJSONArray("missing"))}")
                line("  Lookup: ${item.optString("nextLookup", "none")}")
            }
        }
        val progressNoEvidence = forager.optJSONObject("researchProgressWithoutEvidenceReport") ?: JSONObject()
        if (progressNoEvidence.optBoolean("active", false)) {
            line("Research progress without EvidenceObject v1.10.34: ${progressNoEvidence.optString("progressState", "NOT_EVALUATED")} • success=${arrayToString(progressNoEvidence.optJSONArray("successCategories"))}")
            line("  Blocked claims: ${arrayToString(progressNoEvidence.optJSONArray("blockedClaims"))}")
        }
        val handoff = forager.optJSONObject("leadClosureHandoffReport") ?: JSONObject()
        if (handoff.optBoolean("active", false)) {
            line("Lead closure handoff v1.10.35: ${handoff.optString("state", "NOT_EVALUATED")} • carried=${handoff.optInt("carriedLeadCount", 0)} • missing=${arrayToString(handoff.optJSONArray("missingFields"))}")
            line("  Forced next: ${handoff.optString("forcedNextAction", "none")}")
            line("  Pinned rules: ${arrayToString(handoff.optJSONArray("pinnedLearningRules"))}")
        }
        val metadataClosure = forager.optJSONObject("metadataClosureReport") ?: JSONObject()
        if (metadataClosure.optBoolean("active", false)) {
            line("Metadata closure v1.10.35: ${metadataClosure.optString("state", "NOT_EVALUATED")} • closed=${arrayToString(metadataClosure.optJSONArray("closedFields"))} • missing=${arrayToString(metadataClosure.optJSONArray("missingFields"))}")
        }
        val routePrior = forager.optJSONObject("unknownRouteClassificationReport") ?: JSONObject()
        if (routePrior.optBoolean("active", false)) {
            line("Unknown-route classifier v1.10.35: ${routePrior.optString("state", "NOT_EVALUATED")} • selected=${routePrior.optString("selectedRoute", "none")} • confidence=${routePrior.optInt("confidence", 0)}/100")
            line("  Rule: ${routePrior.optString("pinnedRule", "route prior only")}")
        }
        val ebvCriterion = forager.optJSONObject("ebvLeadVerificationReport") ?: JSONObject()
        if (ebvCriterion.optBoolean("active", false)) {
            line("EBV criterion lane v1.10.37: ${ebvCriterion.optString("state", "NOT_EVALUATED")} • target=${ebvCriterion.optString("targetLeadId", "none")} • claim=${ebvCriterion.optString("claimLimit", "ebv_criterion_lane_not_biological_proof")}")
            line("  Question: ${ebvCriterion.optString("criterionQuestion", "none")}")
            line("  Matched: ${arrayToString(ebvCriterion.optJSONArray("matchedTerms"))}")
            line("  Closed: ${arrayToString(ebvCriterion.optJSONArray("closedEvidence"))} • missing=${arrayToString(ebvCriterion.optJSONArray("missingEvidence"))}")
            line("  Next: ${ebvCriterion.optString("allowedNextAction", "none")}")
            line("  Invalidators: ${arrayToString(ebvCriterion.optJSONArray("invalidators"))}")
        }
        val evidencePrior = forager.optJSONObject("evidencePriorSelectionReport") ?: JSONObject()
        if (evidencePrior.optBoolean("active", false)) {
            line("Evidence Prior Matrix v1.10.38: ${evidencePrior.optString("state", "NOT_EVALUATED")} • selected=${evidencePrior.optString("selectedPriorId", "none")} • claim=${evidencePrior.optString("claimLimit", "evidence_prior_matrix_routing_only_not_biological_proof")}")
            val integrated = forager.optJSONObject("integratedPathLinkageReport") ?: JSONObject()
            line("Integrated path linkage v1.10.39: ${integrated.optString("state", "NOT_EVALUATED")} • openWarnings=${integrated.optJSONArray("openWarnings")?.length() ?: 0} • claim=${integrated.optString("claimLimit", "integrated_path_linkage_not_biological_proof")}")
            line("Final path decision: ${integrated.optString("finalDecision", "No final path decision available.")}")
            line("Release stability gate v1.10.40: ${FinalReleaseStabilityReport.fromRuntime().state} • claim=${FinalReleaseStabilityGuard.CLAIM_LIMIT}")
            line("  Release decision: ${FinalReleaseStabilityGuard.summary()}")
            line("  Reason: ${evidencePrior.optString("reason", "none")}")
            line("  Query keys: ${arrayToString(evidencePrior.optJSONArray("queryTerms"))}")
            line("  Required gates: ${arrayToString(evidencePrior.optJSONArray("requiredGates"))}")
            line("  Guards: ${arrayToString(evidencePrior.optJSONArray("noiseGuards"))}")
            line("  Forbidden claims: ${arrayToString(evidencePrior.optJSONArray("forbiddenClaims"))}")
            line("  Next: ${evidencePrior.optString("nextAction", "none")}")
        }
        val topicFit = forager.optJSONObject("topicFitMetadataParseReport") ?: JSONObject()
        if (topicFit.optBoolean("active", false)) {
            line("Open Exploration / Route Reconciliation v1.10.52: ${topicFit.optString("state", "NOT_EVALUATED")} • topic=${topicFit.optString("topicLabel", "unknown")} • route=${topicFit.optString("preferredLane", "none")} • claim=${topicFit.optString("claimLimit", "topic_fit_metadata_parse_ui_clarity_not_biological_proof")}")
            line("  Strictness: ${topicFit.optString("strictnessMode", "OPEN_EXPLORATION_NO_PATIENT_DIAGNOSIS")} • progressionAllowed=${topicFit.optBoolean("progressionAllowed", false)}")
            line("  Open exploration: ${topicFit.optString("openExplorationMode", "NOT_EVALUATED")} • diagnostic reasoning=${topicFit.optString("diagnosticReasoningMode", "NOT_EVALUATED")}")
            line("  Medical index terms: ${arrayToString(topicFit.optJSONArray("medicalIndexTerms"))}")
            line("  Dynamic nodes opened: ${arrayToString(topicFit.optJSONArray("dynamicNodesOpened"))}")
            line("  Exploratory link queries: ${arrayToString(topicFit.optJSONArray("exploratoryLinkQueries"))}")
            line("  Route correction: ${topicFit.optString("topicRouteCorrectionStatus", "NOT_EVALUATED")}")
            line("  Legacy reconciliation: ${topicFit.optString("legacyRouteReconciliationStatus", "NOT_EVALUATED")}")
            line("  Reconciled legacy focus: ${topicFit.optString("reconciledMatureDomainFocus", "none")}")
            line("  Reconciled query seed: ${topicFit.optString("reconciledQuerySeed", "none")}")
            line("  Comparator hunt queries: ${arrayToString(topicFit.optJSONArray("comparatorHuntQueries"))}")
            line("  Legacy suppression notes: ${arrayToString(topicFit.optJSONArray("legacySuppressionNotes"))}")
            line("  Learning: ${topicFit.optString("learningStatus", "unknown")} • Discovery: ${topicFit.optString("discoveryStatus", "unknown")} • Evidence: ${topicFit.optString("evidenceStatus", "unknown")}")
            line("  EvidenceObjectCandidate(s): ${topicFit.optInt("evidenceObjectCandidateCount", 0)} • Comparator hunt: ${topicFit.optString("comparatorHuntMode", "NOT_EVALUATED")}")
            line("  Context seeds: ${arrayToString(topicFit.optJSONArray("contextSeeds"))}")
            line("  Soft progression gates: ${arrayToString(topicFit.optJSONArray("softProgressionGates"))}")
            line("  Hard claim gates: ${arrayToString(topicFit.optJSONArray("hardClaimGates"))}")
            line("  Forced metadata / parsed / evidence objects / evidence candidates: ${topicFit.optInt("forcedMinimumMetadataCount", 0)} / ${topicFit.optInt("parsedMetadataCount", 0)} / ${topicFit.optInt("evidenceObjectCount", 0)} / ${topicFit.optInt("evidenceObjectCandidateCount", 0)}")
            line("  Suppressed stale prior: ${topicFit.optString("suppressedMatureDomain", "none")}")
            line("  Route-fit boost policy: ${topicFit.optString("routeFitBoostPolicy", "lookup priority only")}")
            line("  Invalidators: ${arrayToString(topicFit.optJSONArray("invalidators"))}")
            line("  Next: ${topicFit.optString("nextAction", "none")}")
        }
        val strategyMatrix = forager.optJSONObject("metadataClosureStrategyMatrixReport") ?: JSONObject()
        if (strategyMatrix.optBoolean("active", false)) {
            line("Metadata/Hyper-Drive Strategy Matrix v1.11.5: ${strategyMatrix.optString("state", "NOT_EVALUATED")} • lock=${strategyMatrix.optString("executionLock", "NOT_LOADED")} • mode=${strategyMatrix.optString("hardDataExtractionMode", "STANDARD_METADATA_CLOSURE")} • boost=${strategyMatrix.optInt("routeFitBoostScore", 0)}/95 • forcedTarget=${strategyMatrix.optInt("forcedRouteFitTarget", 0)} • hyperDrive=${strategyMatrix.optBoolean("hyperDriveModeActive", false)} • criticalUsabilityAnomaly=${strategyMatrix.optBoolean("criticalUsabilityAnomaly", false)} • aggressive=${strategyMatrix.optBoolean("aggressiveQueryStreamUnlocked", false)} • drillDown=${strategyMatrix.optBoolean("textMiningDrillDownForced", false)} • claim=${strategyMatrix.optString("claimLimit", "exploration_sandbox_not_biological_proof")}")
            line("  Targets: ${arrayToString(strategyMatrix.optJSONArray("detectedTargets"))}")
            val strictMatrix = strategyMatrix.optJSONArray("crossReferenceMatrix") ?: JSONArray()
            if (strictMatrix.length() > 0) {
                for (i in 0 until strictMatrix.length()) {
                    val rule = strictMatrix.optJSONObject(i) ?: JSONObject()
                    line("  Cross-reference ${rule.optString("ruleId", "unknown")}: verified=${rule.optBoolean("verified", false)} • floor=${rule.optInt("routeFitFloor", 0)} • families=${arrayToString(rule.optJSONArray("matchedFamilies"))}")
                    val programmatic = rule.optJSONArray("programmaticQueries") ?: JSONArray()
                    if (programmatic.length() > 0) line("    Programmatic query: ${programmatic.optString(0).take(220)}")
                }
            }
            val hyperStreams = strategyMatrix.optJSONArray("multiDimensionalAccessionSearchStreams") ?: JSONArray()
            if (hyperStreams.length() > 0) {
                val firstHyper = hyperStreams.optJSONObject(0) ?: JSONObject()
                line("  Hyper-Drive first stream: ${firstHyper.optString("sourceFamily", "unknown")} :: ${firstHyper.optString("query", "none").take(260)}")
            }
            line("  Programmatic commands: ${arrayToString(strategyMatrix.optJSONArray("programmaticCommandLog"))}")
            line("  Runtime data demand: ${arrayToString(strategyMatrix.optJSONArray("runtimeDataDemand"))}")
            line("  Control/comparator linkage queries: ${arrayToString(strategyMatrix.optJSONArray("controlComparatorLinkageQueries"))}")
            val matrixStreams = strategyMatrix.optJSONArray("queryStreams") ?: JSONArray()
            if (matrixStreams.length() > 0) {
                val firstStream = matrixStreams.optJSONObject(0) ?: JSONObject()
                line("  First query stream: ${firstStream.optString("sourceFamily", "unknown")} :: ${firstStream.optString("query", "none").take(240)}")
            }
            line("  Minimum probes: ${(strategyMatrix.optJSONArray("minimumMetadataProbes") ?: JSONArray()).length()} • Logic gates: ${(strategyMatrix.optJSONArray("leanRuntimeLogicGates") ?: JSONArray()).length()}")
            line("  Hard gates: ${arrayToString(strategyMatrix.optJSONArray("hardClaimGates"))}")
            line("  Next: ${strategyMatrix.optString("nextAction", "none")}")
        }
        val mechanismDossier = forager.optJSONObject("mechanismDiscoveryDossierReport") ?: JSONObject()
        if (mechanismDossier.optBoolean("active", false)) {
            line("Research-Grade Mechanism Dossier v2.5.9: ${mechanismDossier.optString("state", "NOT_EVALUATED")} • grade=${mechanismDossier.optString("evidenceGrade", "E")} • matrix=${mechanismDossier.optString("matrixAnalysisGate", "DGE_NOT_READY_METADATA_GAP")} • evidenceObject=${mechanismDossier.optString("evidenceObjectCreationGate", "EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION")} • claim=${mechanismDossier.optString("claimBoundary", "biomedical_research_data_engineering_only_not_clinical_claim")}")
            line("  Research question: ${mechanismDossier.optString("researchQuestion", "none").take(220)}")
            line("  Result mode: ${mechanismDossier.optString("researchResultMode", "STRICT_EVIDENCE_OBJECT_ONLY")} • bestLead=${mechanismDossier.optString("bestResearchLeadSummary", "none")}")
            val exploratoryLeads = mechanismDossier.optJSONArray("exploratoryResearchLeads") ?: JSONArray()
            if (exploratoryLeads.length() > 0) {
                val lead = exploratoryLeads.optJSONObject(0) ?: JSONObject()
                line("  Preliminary research lead: ${lead.optString("targetAxis", "none")} • confidence=${lead.optInt("confidence", 0)}/100 • tier=${lead.optString("evidenceTier", "unknown")} • status=${lead.optString("status", "unknown")}")
            }
            line("  Metadata extraction commands: ${arrayToString(mechanismDossier.optJSONArray("metadataExtractionCommands"))}")
            val validationCards = mechanismDossier.optJSONArray("accessionValidationCards") ?: JSONArray()
            if (validationCards.length() > 0) {
                val validation = validationCards.optJSONObject(0) ?: JSONObject()
                line("  First validation card: ${validation.optString("accessionId", "none")} • state=${validation.optString("validationState", "unknown")} • parser=${validation.optString("sourceSpecificParser", "unknown")} • gate=${validation.optString("evidenceObjectCreationGate", "unknown")}")
            }
            val comparatorExtract = mechanismDossier.optJSONArray("comparatorExtractionCards") ?: JSONArray()
            if (comparatorExtract.length() > 0) {
                val comp = comparatorExtract.optJSONObject(0) ?: JSONObject()
                line("  Comparator extraction: ${comp.optString("extractionState", "unknown")} • confidence=${comp.optInt("comparatorConfidence", 0)}/100 • gate=${comp.optString("evidenceObjectGate", "unknown")}")
            }
            val accessionCards = mechanismDossier.optJSONArray("accessionCandidates") ?: JSONArray()
            if (accessionCards.length() > 0) {
                val first = accessionCards.optJSONObject(0) ?: JSONObject()
                line("  First accession card: ${first.optString("accessionId", "none")} • repo=${first.optString("repository", "unknown")} • comparator=${first.optString("evidenceObjectGate", "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT")} • dge=${first.optString("dgeReadinessState", "DGE_NOT_READY_METADATA_GAP")}")
            }
            val routes = mechanismDossier.optJSONArray("mechanismRoutes") ?: JSONArray()
            if (routes.length() > 0) {
                val route = routes.optJSONObject(0) ?: JSONObject()
                line("  Mechanism route: ${route.optString("targetMolecularAxis", "none").take(200)}")
            }
            line("  Blocking gaps: ${arrayToString(mechanismDossier.optJSONArray("blockingGaps"))}")
            line("  Next: ${mechanismDossier.optString("nextDecisiveAction", "none").take(240)}")
        }
        val biomedical = forager.optJSONObject("biomedicalOntologyReport") ?: JSONObject()
        if (biomedical.optBoolean("active", false)) {
            line("Biomedical research ontology v1.10.41: ${biomedical.optString("state", "NOT_EVALUATED")} • diagnostic=${biomedical.optString("diagnosticPhenotypeMode", "OFF")} • claim=${biomedical.optString("claimLimit", "biomedical_research_ontology_routing_only_not_patient_diagnosis")}")
            line("  Domains: ${arrayToString(biomedical.optJSONArray("selectedDomains"))}")
            line("  Matched terms: ${arrayToString(biomedical.optJSONArray("matchedTerms"))}")
            line("  Query expansion keys: ${arrayToString(biomedical.optJSONArray("queryExpansionKeys"))}")
            line("  Research use: ${arrayToString(biomedical.optJSONArray("researchUse"))}")
            line("  Guardrails: ${arrayToString(biomedical.optJSONArray("guardrails"))}")
            line("  Next: ${biomedical.optString("nextAction", "none")}")
        }
        val viralCountermeasure = forager.optJSONObject("viralCountermeasureReport") ?: JSONObject()
        if (viralCountermeasure.optBoolean("active", false)) {
            line("Viral Countermeasure Intelligence v1.10.44: ${viralCountermeasure.optString("state", "NOT_EVALUATED")} • virus=${viralCountermeasure.optString("selectedVirusKey", "none")} • claim=${viralCountermeasure.optString("claimLimit", "viral_countermeasure_routing_only_not_wetlab_or_clinical_proof")}")
            line("  Lane: ${viralCountermeasure.optString("selectedLane", "none")}")
            line("  Evidence keys: ${arrayToString(viralCountermeasure.optJSONArray("evidenceKeysToClose"))}")
            line("  Forbidden claims: ${arrayToString(viralCountermeasure.optJSONArray("forbiddenClaims"))}")
            line("  Next: ${viralCountermeasure.optString("nextAction", "none")}")
        }
        val knowledgeGraph = forager.optJSONObject("biomedicalKnowledgeGraphLinkageReport") ?: JSONObject()
        if (knowledgeGraph.optBoolean("active", false)) {
            line("Biomedical Dictionary/Database Linkage v1.10.44: ${knowledgeGraph.optString("state", "NOT_EVALUATED")} • claim=${knowledgeGraph.optString("claimLimit", "biomedical_dictionary_database_linkage_not_biological_proof")}")
            line("  Partitions: ${arrayToString(knowledgeGraph.optJSONArray("selectedPartitions"))}")
            line("  Bridge edges: ${arrayToString(knowledgeGraph.optJSONArray("bridgeEdges"))}")
            line("  Update policy: ${knowledgeGraph.optString("updatePolicy", "none")}")
        }

        val conceptBridge = forager.optJSONObject("biomedicalConceptBridgeReport") ?: JSONObject()
        if (conceptBridge.optBoolean("active", false)) {
            line("Biomedical concept bridge v1.10.42: ${conceptBridge.optString("state", "NOT_EVALUATED")} • bridges=${arrayToString(conceptBridge.optJSONArray("selectedBridgeIds"))} • claim=${conceptBridge.optString("claimLimit", "biomedical_concept_bridge_routing_only_not_clinical_conclusion")}")
            line("  Matched concepts: ${arrayToString(conceptBridge.optJSONArray("matchedConcepts"))}")
            line("  Priority lookup terms: ${arrayToString(conceptBridge.optJSONArray("priorityLookupTerms"))}")
            line("  Evidence keys to close: ${arrayToString(conceptBridge.optJSONArray("evidenceKeysToClose"))}")
            line("  Invalidators: ${arrayToString(conceptBridge.optJSONArray("invalidators"))}")
            line("  Next: ${conceptBridge.optString("nextAction", "none")}")
        }
        val modernTech = forager.optJSONObject("modernMedicalTechnologyReport") ?: JSONObject()
        if (modernTech.optBoolean("active", false)) {
            line("Modern medical technology intelligence v1.10.43: ${modernTech.optString("state", "NOT_EVALUATED")} • modules=${arrayToString(modernTech.optJSONArray("selectedModuleIds"))} • claim=${modernTech.optString("claimLimit", "modern_medical_technology_routing_only_not_lab_or_clinical_proof")}")
            line("  Routing mode: ${modernTech.optString("routingMode", "OFF")}")
            line("  Matched technologies: ${arrayToString(modernTech.optJSONArray("matchedTechnologies"))}")
            line("  Priority lookup terms: ${arrayToString(modernTech.optJSONArray("priorityLookupTerms"))}")
            line("  Evidence keys to close: ${arrayToString(modernTech.optJSONArray("evidenceKeysToClose"))}")
            line("  Partition keys: ${arrayToString(modernTech.optJSONArray("partitionIndexKeys"))}")
            line("  Retrieval policy: ${modernTech.optString("retrievalPolicy", "none")}")
            line("  Invalidators: ${arrayToString(modernTech.optJSONArray("invalidators"))}")
            line("  Forbidden claims: ${arrayToString(modernTech.optJSONArray("forbiddenClaims"))}")
            line("  Next: ${modernTech.optString("nextAction", "none")}")
        }
        val learningAudit = LearningRulesUiSummary.buildCard(forager)
        if (learningAudit.monitorState != "NO_LEARNING_MONITOR_SIGNAL") {
            line("Learning audit monitor v1.10.36: ${learningAudit.monitorState} • claim=${learningAudit.claimLimit}")
            line("  Learned: ${learningAudit.learnedDetails.take(3).joinToString("; ")}")
            line("  Rules kept: ${learningAudit.pinnedRules.take(3).joinToString("; ")}")
            line("  Still missing: ${learningAudit.stillMissing.take(6).joinToString(", ")}")
            line("  Invalidate if: ${learningAudit.invalidators.take(3).joinToString("; ")}")
            line("  Next audit: ${learningAudit.nextAuditAction}")
        }
        val activityEvidence = forager.optJSONObject("evidenceActivitySeparationReport") ?: JSONObject()
        if (activityEvidence.length() > 0) {
            line("Activity ≠ Evidence v1.10.31: paths=${activityEvidence.optInt("executedPaths", 0)} • candidates=${activityEvidence.optInt("candidatesFound", 0)} • accessions=${activityEvidence.optInt("accessionsFound", 0)} • evidenceObjects=${activityEvidence.optInt("evidenceObjects", 0)} • learning=${activityEvidence.optInt("learningUpdates", 0)} • domainUpdated=${activityEvidence.optBoolean("domainExpertiseUpdated", false)} • scientificClaim=${activityEvidence.optString("scientificClaim", "none")}")
        }
        val breakthrough = forager.optJSONObject("evidenceDiscoveryBreakthroughReport") ?: JSONObject()
        if (breakthrough.optBoolean("active", false)) {
            line("Evidence discovery breakthrough v1.10.31: ${breakthrough.optString("state", "NOT_EVALUATED")} • best=${breakthrough.optString("bestLead", "none")} • status=${breakthrough.optString("bestLeadStatus", "none")} • nearMiss=${breakthrough.optInt("nearMissCount", 0)}")
            line("  Next: ${breakthrough.optString("nextAction", "none")}")
            if (topicFit.optString("suppressedMatureDomain", "none") != "none") {
                line("  Post-PubMed strategies reconciled v1.10.51: ${topicFit.optString("reconciledQuerySeed", "none")}")
                line("  Original stale strategies suppressed from governing view; see suppressed prior notes above.")
            } else {
                line("  Post-PubMed strategies: ${arrayToString(breakthrough.optJSONArray("postPubMedSearchStrategies"))}")
            }
        }
        val manualSeed = forager.optJSONObject("manualEvidenceSeedReport") ?: JSONObject()
        if (manualSeed.optBoolean("active", false)) {
            line("Manual evidence seed mode v1.10.31: ${manualSeed.optString("mode", "MANUAL_EVIDENCE_SEED_MODE")} • seeds=${manualSeed.optInt("seedsDetected", 0)} • claim=${manualSeed.optString("claimLimit", "lead_only_not_evidence")}")
            line("  Next: ${manualSeed.optString("nextAction", "none")}")
        }
        val relaxation = forager.optJSONObject("datasetLeadRelaxationReport") ?: JSONObject()
        if (relaxation.optBoolean("active", false)) {
            line("Dataset lead relaxation gate v1.10.31: ${relaxation.optString("state", "NOT_EVALUATED")} • relaxed=${relaxation.optInt("relaxedLeadCount", 0)} • leads=${arrayToString(relaxation.optJSONArray("leadAccessions"))}")
        }
        val leadLinkage = forager.optJSONObject("evidenceLeadPathLinkageReport") ?: JSONObject()
        if (leadLinkage.optBoolean("active", false)) {
            line("Evidence lead path linkage v1.10.31: ${leadLinkage.optString("state", "NOT_EVALUATED")} • manual=${leadLinkage.optBoolean("manualSeedLinkedToForager", false)} • weak=${leadLinkage.optBoolean("weakLeadLinkedToRelaxation", false)} • decision=${leadLinkage.optBoolean("breakthroughLinkedToDecision", false)} • consistency=${leadLinkage.optBoolean("consistencyGuardApplied", false)}")
            val warnings = leadLinkage.optJSONArray("warnings")
            if (warnings != null && warnings.length() > 0) line("  Linkage warnings: ${arrayToString(warnings)}")
        }
        val leadObjects = forager.optJSONArray("leadObjects")
        if (leadObjects != null && leadObjects.length() > 0) line("LeadObject ledger v1.10.31: leads=${leadObjects.length()} • claim=LEAD_ONLY_NOT_EVIDENCE")
        val focus = forager.optJSONObject("matureDomainFocusReport") ?: JSONObject()
        if (focus.optBoolean("active", false)) {
            if (topicFit.optString("suppressedMatureDomain", "none") != "none") {
                line("Mature domain focus v1.10.32 reconciled by v1.10.51: ${topicFit.optString("reconciledMatureDomainFocus", "none")}")
            } else {
                line("Mature domain focus v1.10.32: ${focus.optString("state", "NOT_EVALUATED")} • domain=${focus.optString("selectedDomain", "none")} • cyclesRemaining=${focus.optInt("cyclesRemaining", 0)}")
            }
        }
        val knowledgeGapQueue = forager.optJSONObject("knowledgeGapQueueReport") ?: JSONObject()
        if (knowledgeGapQueue.optBoolean("active", false)) {
            if (topicFit.optString("suppressedMatureDomain", "none") != "none") {
                line("Knowledge gap queue v1.10.32 reconciled by v1.10.51: open=${knowledgeGapQueue.optJSONArray("items")?.length() ?: 0} • next=${topicFit.optString("reconciledQuerySeed", "none")}")
            } else {
                line("Knowledge gap queue v1.10.32: ${knowledgeGapQueue.optString("queueState", "NOT_EVALUATED")} • open=${knowledgeGapQueue.optJSONArray("items")?.length() ?: 0} • next=${knowledgeGapQueue.optString("nextAction", "none")}")
            }
        }
        val semanticRoute = forager.optJSONObject("strongRouteFingerprintReport") ?: JSONObject()
        if (semanticRoute.optBoolean("active", false)) {
            if (topicFit.optString("suppressedMatureDomain", "none") != "none") {
                line("Strong route fingerprint v1.10.32 reconciled by v1.10.51: replay=${semanticRoute.optBoolean("replayRisk", false)} • governing=${topicFit.optString("preferredLane", "none")}")
            } else {
                line("Strong route fingerprint v1.10.32: replay=${semanticRoute.optBoolean("replayRisk", false)} • intent=${semanticRoute.optString("intent", "none")} • domain=${semanticRoute.optString("domain", "none")}")
            }
        }
        val leanRuntime = forager.optJSONObject("leanAgentRuntimeReport") ?: JSONObject()
        if (leanRuntime.optBoolean("active", false)) line("Lean agent runtime v1.10.33: ${leanRuntime.optString("state", "NOT_EVALUATED")} • card=${leanRuntime.optString("compactDecisionCard", "none")}")
        line("Sources attempted: ${arrayToString(forager.optJSONArray("sourceFamiliesAttempted"))}")
        val scoreSep = forager.optJSONObject("scoreSeparation") ?: JSONObject()
        line("Score separation: dataset usability ${scoreSep.optInt("datasetUsabilityScore", 0)}/100 | route fit ${scoreSep.optInt("routeFitScore", 0)}/100 | hypothesis confidence ${scoreSep.optInt("hypothesisConfidenceScore", 0)}/100 | upgrade allowed ${scoreSep.optBoolean("hypothesisUpgradeAllowed", false)}")
        line("Score state: ${scoreSep.optString("scoreState", "NOT_EVALUATED")} — ${scoreSep.optString("summary", "none")}")
        val accession = forager.optJSONObject("accessionAcquisitionReport") ?: JSONObject()
        if (accession.optBoolean("active", false)) {
            line("Accession acquisition v1.10.30: ${accession.optString("state", "NOT_EVALUATED")} • explicit ${arrayToString(accession.optJSONArray("explicitAccessions"))} • weak ${arrayToString(accession.optJSONArray("weakAccessions"))}")
            line("  Next: ${accession.optString("nextAction", "none")}")
            if (accession.optBoolean("compactReportRecommended", false)) line("  Compact-report gate: ON — no parsed accession/metadata object yet.")
            line("  Claim limit: ${accession.optString("claimLimit", "accession_acquisition_not_biological_proof")}")
        }
        val domainExpertise = forager.optJSONObject("domainExpertiseReport") ?: JSONObject()
        if (domainExpertise.optBoolean("active", false)) {
            line("Domain expertise activation v1.10.30: ${domainExpertise.optString("summary", "none")}")
            line("  Stable priors: ${domainExpertise.optInt("stablePriorCount", 0)} • Protected beliefs: ${domainExpertise.optInt("protectedBeliefCount", 0)} • Carried: ${domainExpertise.optInt("carriedForwardDomainCount", 0)} • Mature: ${domainExpertise.optInt("matureDomainCount", 0)}")
            line("  Continuity: ${domainExpertise.optString("continuityState", "unknown")} — ${domainExpertise.optString("continuitySummary", "none")}")
            val domainCards = domainExpertise.optJSONArray("cards") ?: JSONArray()
            for (i in 0 until domainCards.length().coerceAtMost(4)) {
                val card = domainCards.optJSONObject(i) ?: continue
                line("• ${card.optString("label")} — ${card.optString("expertiseState")} • ${card.optInt("expertiseScore", 0)}/100")
                line("  Vocabulary: ${arrayToString(card.optJSONArray("workingVocabulary"))}")
                line("  Gates: ${arrayToString(card.optJSONArray("falsificationGates"))}")
                line("  Prior exposure: ${card.optInt("priorExposureCount", 0)} • Continuity: ${card.optString("continuityAction", "none")}")
            }
            line("  Claim limit: ${domainExpertise.optString("claimLimit", "domain_expertise_memory_not_biological_proof")}")
            line("Abstract accession harvest v1.10.24: abstract/data-availability digests feed accession parsing only; claim limit abstract_accession_harvest_not_biological_proof")
            line("Data availability query priority v1.10.25: PUBMED_ACCESSION_MINING searches deposition/accession wording first; claim limit data_availability_query_priority_not_biological_proof")
            line("Release version linkage v1.10.30: active engine/build/schema labels unified; legacy tokens remain audit-only.")
        }
        val matureProbe = forager.optJSONObject("matureDomainEvidenceProbeReport") ?: JSONObject()
        if (matureProbe.optBoolean("active", false)) {
            line("Mature domain evidence probe v1.10.30: ${matureProbe.optString("state", "NOT_EVALUATED")} — ${matureProbe.optString("summary", "none")}")
            line("  Domains: ${arrayToString(matureProbe.optJSONArray("selectedDomains"))}")
            line("  Probe attempted: ${matureProbe.optBoolean("probeAttempted", false)} • relaxed priors: ${matureProbe.optBoolean("relaxedInterpretationAllowed", false)}")
            line("  Next: ${matureProbe.optString("nextAction", "none")}")
            line("  Claim limit: ${matureProbe.optString("claimLimit", "mature_domain_evidence_probe_not_biological_proof")}")
        }
        val pathLinkage = forager.optJSONObject("pathLinkageReport") ?: JSONObject()
        if (pathLinkage.optBoolean("active", false)) {
            line("Dataset path/pass linkage v1.10.30: ${pathLinkage.optString("state", "NOT_EVALUATED")} — ${pathLinkage.optString("handoffSummary", "none")}")
            line("  Core sources: ${arrayToString(pathLinkage.optJSONArray("coreSourcesAttempted"))} • adjacent: ${arrayToString(pathLinkage.optJSONArray("adjacentSourcesAttempted"))} • matureProbe=${pathLinkage.optBoolean("matureProbeAttempted", false)}")
            line("  Coverage: ${pathLinkage.optString("coverageState", "NOT_EVALUATED")} • corePaths=${pathLinkage.optInt("coreQueryPathCount", 0)} • adjacentPaths=${pathLinkage.optInt("adjacentQueryPathCount", 0)} • maturePaths=${pathLinkage.optInt("matureProbeQueryPathCount", 0)} • total=${pathLinkage.optInt("totalQueryPathCount", 0)}")
            val warnings = pathLinkage.optJSONArray("warnings") ?: JSONArray()
            if (warnings.length() > 0) line("  Warnings: ${arrayToString(warnings)}")
            line("  Next: ${pathLinkage.optString("nextAction", "none")}")
            line("  Claim limit: ${pathLinkage.optString("claimLimit", "dataset_path_linkage_not_biological_proof")}")
        }
        val learningDomain = forager.optJSONObject("learningDomainPathLinkageReport") ?: JSONObject()
        if (learningDomain.optBoolean("active", false)) {
            line("Learning/domain path linkage v1.10.30: ${learningDomain.optString("state", "NOT_EVALUATED")} — ${learningDomain.optString("handoffSummary", "none")}")
            line("  Learning matches=${learningDomain.optInt("learningRuleMatchCount", 0)} • domains=${learningDomain.optInt("domainTrackCount", 0)} • mature=${learningDomain.optInt("matureDomainCount", 0)} • protected=${learningDomain.optInt("protectedExpertiseCount", 0)}")
            line("  Linked: queryFeedback=${learningDomain.optBoolean("queryFeedbackLinked", false)} • learningRules=${learningDomain.optBoolean("learningRulesLinkedToQueries", false)} • domainVocab=${learningDomain.optBoolean("domainVocabularyLinkedToQueries", false)} • matureProbe=${learningDomain.optBoolean("matureProbeLinkedToDomainExpertise", false)}")
            val ldWarnings = learningDomain.optJSONArray("warnings") ?: JSONArray()
            if (ldWarnings.length() > 0) line("  Warnings: ${arrayToString(ldWarnings)}")
            line("  Next: ${learningDomain.optString("nextAction", "none")}")
            line("  Claim limit: ${learningDomain.optString("claimLimit", "learning_domain_path_linkage_not_biological_proof")}")
        }
        val routeFits = forager.optJSONArray("routeFitAssessments") ?: JSONArray()
        if (routeFits.length() == 0) line("Route-fit gate: not evaluated") else for (i in 0 until routeFits.length().coerceAtMost(5)) {
            val rf = routeFits.optJSONObject(i) ?: continue
            line("• Route-fit ${rf.optString("accession")}: ${rf.optString("status")} • ${rf.optInt("routeFitScore")}/100 • ${rf.optString("datasetRoute")} → ${rf.optString("targetRoute")}")
            line("  Allowed use: ${rf.optString("allowedUse")}")
        }
        line("Blocked learning reason: ${forager.optString("blockedLearningReason", "none")}")
        val noCandidateRecords = forager.optJSONArray("noCandidateLearningRecords") ?: JSONArray()
        if (noCandidateRecords.length() == 0) {
            line("No-candidate learning: none")
        } else {
            line("No-candidate learning:")
            for (i in 0 until noCandidateRecords.length().coerceAtMost(5)) {
                val rec = noCandidateRecords.optJSONObject(i) ?: continue
                line(noCandidateLearningDetailLine(rec))
            }
        }
        val creative = forager.optJSONObject("creativeHypothesisForgeReport") ?: JSONObject()
        if (creative.optBoolean("active", false)) {
            line("Creative Hypothesis Forge: ${creative.optString("state", "ACTIVE")} — ${creative.optString("summary", "")}")
            val axes = creative.optJSONArray("steeringAxesUsed") ?: JSONArray()
            if (axes.length() > 0) line("Steering axes used: ${axisIds(axes)}")
            val expanded = creative.optJSONObject("expandedThinking") ?: JSONObject()
            if (expanded.optBoolean("active", false)) line("Expanded thinking window: ${expanded.optString("mode")} — ${expanded.optString("claimLimit", "expanded_thinking_not_evidence")}")
            val generated = creative.optJSONArray("generated") ?: JSONArray()
            for (i in 0 until generated.length().coerceAtMost(3)) {
                val card = generated.optJSONObject(i) ?: continue
                line("• ${card.optString("label")} | test: ${card.optString("testQuery")}")
                line("  Kill: ${arrayToString(card.optJSONArray("whatWouldKill"))}")
            }
            line("Claim limit: ${creative.optString("claimLimit", "creative_hypothesis_not_evidence")}")
        }
        line("Next action: ${forager.optString("nextAction", "none")}")
        val foragePasses = forager.optJSONArray("passes") ?: JSONArray()
        if (foragePasses.length() == 0) line("Foraging passes: none") else for (i in 0 until foragePasses.length().coerceAtMost(4)) {
            val pass = foragePasses.optJSONObject(i) ?: continue
            line("• ${pass.optString("passId")} — ${pass.optString("status")}")
        }
        val parsed = forager.optJSONArray("parsedMetadata") ?: JSONArray()
        line("Parsed dataset metadata:")
        if (parsed.length() == 0) line("• No parsed metadata yet.") else for (i in 0 until parsed.length().coerceAtMost(5)) {
            val d = parsed.optJSONObject(i) ?: continue
            line("• ${d.optString("accession")} — ${d.optString("usabilityVerdict")} • metadata ${d.optInt("metadataQualityScore")}/100 • ${d.optString("organism")} • ${d.optString("assayType")}")
            line("  Outcome: ${arrayToString(d.optJSONArray("outcomeLabels"))} | Control: ${arrayToString(d.optJSONArray("controlLabels"))} | Contrast: ${arrayToString(d.optJSONArray("contrastiveSlots"))}")
        }
        val contrastive = forager.optJSONObject("contrastiveReport") ?: JSONObject()
        val cumulative = forager.optJSONObject("cumulativeEvidence") ?: JSONObject()
        line("Contrastive gate: ${contrastive.optString("gateStatus", "NOT_EVALUATED")} — ${contrastive.optString("summary", "none")}")
        line("Next contrastive question: ${contrastive.optString("nextContrastiveQuestion", "none")}")
        line("Cumulative evidence: ${cumulative.optInt("score", 0)}/100 ${cumulative.optString("state", "OFF")}")
        val memory = report.optJSONObject("persistentFailureMemory") ?: JSONObject()
        line("Persistent failure memory: ${memory.optString("summary", "none")}")
        y += 8f

        line("Evidence closure + post-search thinking + graph + momentum + linked spine v1.10.0", title)
        val closure = report.optJSONObject("evidenceClosureReport") ?: JSONObject()
        line("Evidence closure: ${closure.optString("mode", "NO_ACCESSION")} • economy ${closure.optString("searchEconomyState", "unknown")} • broad blocked=${closure.optBoolean("broadSearchBlocked", false)}")
        line("Closure summary: ${closure.optString("summary", "No closure report.")}")
        val closureCards = closure.optJSONArray("cards") ?: JSONArray()
        if (closureCards.length() == 0) line("Closure cards: none") else for (i in 0 until closureCards.length().coerceAtMost(3)) {
            val card = closureCards.optJSONObject(i) ?: continue
            line("• ${card.optString("accession")} — ${card.optString("decision")} • closure ${card.optInt("closureScore")}/100 • usability ${card.optInt("datasetUsabilityScore")}/100 • route-fit ${card.optInt("routeFitScore")}/100")
            line("  Missing: ${arrayToString(card.optJSONArray("missingFields"))}")
            line("  Next: ${card.optString("nextAction", "none")}")
        }
        val thinking = report.optJSONObject("postSearchThinkingReport") ?: JSONObject()
        line("Post-search thinking: ${thinking.optString("state", "NO_REPORT")} • should search again=${thinking.optBoolean("shouldSearchAgain", false)}")
        line("Synthesis: ${thinking.optString("synthesis", "No synthesis stored.")}")
        line("Linked points:")
        writeArray(thinking.optJSONArray("linkedPoints")) { line("• $it") }
        val hypotheses = thinking.optJSONArray("hypotheses") ?: JSONArray()
        if (hypotheses.length() == 0) line("Hypothesis cards: none") else for (i in 0 until hypotheses.length().coerceAtMost(3)) {
            val h = hypotheses.optJSONObject(i) ?: continue
            line("• ${h.optString("state")} ${h.optInt("confidence")}/100 — ${h.optString("label")}")
            line("  Discriminator: ${h.optString("discriminator", "none")}")
            line("  Next: ${h.optString("nextAction", "none")}")
        }
        line("Search gate: ${thinking.optString("nextSearchGate", closure.optString("queryBudgetDecision", "none"))}")
        val continuity = report.optJSONObject("thinkingContinuityReport") ?: JSONObject()
        line("Thinking continuity: ${continuity.optString("state", "NO_CONTINUITY")} • iteration ${continuity.optInt("iteration", 0)}")
        line("Continuity summary: ${continuity.optString("summary", "No continuity report.")}")
        line("Repeated gaps: ${arrayToString(continuity.optJSONArray("repeatedGaps"))}")
        line("Merged hypothesis line: ${continuity.optString("mergedHypothesisLine", "none")}")
        line("Next local question: ${continuity.optString("nextLocalQuestion", "none")}")
        line("Next search permission: ${continuity.optString("nextSearchPermission", "none")}")
        val graph = report.optJSONObject("hypothesisGraphReport") ?: JSONObject()
        if (graph.optBoolean("active", false)) {
            line("Hypothesis graph v1.9.8: ${graph.optString("state", "NO_GRAPH")} • iteration ${graph.optInt("graphIteration", 0)}")
            line("Graph summary: ${graph.optString("summary", "No graph summary.")}")
            line("Dominant hypothesis: ${graph.optString("dominantHypothesis", "none")}")
            line("Weakest link: ${graph.optString("weakestLink", "none")}")
            line("Graph kill switch: ${graph.optString("killSwitch", "none")}")
            line("Graph next move: ${graph.optString("nextReasoningMove", "none")}")
            line("Graph search decision: ${graph.optString("searchDecision", "none")}")
            val graphNodes = graph.optJSONArray("nodes") ?: JSONArray()
            if (graphNodes.length() == 0) line("Graph nodes: none") else for (i in 0 until graphNodes.length().coerceAtMost(5)) {
                val node = graphNodes.optJSONObject(i) ?: continue
                line("• ${node.optString("nodeType")} / ${node.optString("state")} / c=${node.optInt("confidence")}/100 — ${node.optString("label")}")
                line("  Missing: ${arrayToString(node.optJSONArray("missingEvidence"))}")
                line("  Next: ${node.optString("nextTest", "none")}")
            }
            val graphEdges = graph.optJSONArray("edges") ?: JSONArray()
            if (graphEdges.length() == 0) line("Graph edges: none") else for (i in 0 until graphEdges.length().coerceAtMost(5)) {
                val edge = graphEdges.optJSONObject(i) ?: continue
                line("• ${edge.optString("relation")} w=${edge.optInt("weight")}/100 — ${edge.optString("rationale")}")
            }
        }
        val momentum = report.optJSONObject("cognitiveMomentumReport") ?: JSONObject()
        if (momentum.optBoolean("active", false)) {
            line("Cognitive momentum v1.9.9: ${momentum.optString("state", "NO_MOMENTUM")} • momentum ${momentum.optInt("momentumScore", 0)}/100 • progress ${momentum.optInt("progressScore", 0)}/100 • penalty ${momentum.optInt("repetitionPenalty", 0)}/100")
            line("Momentum summary: ${momentum.optString("summary", "No momentum summary.")}")
            line("Closed keys: ${arrayToString(momentum.optJSONArray("closedEvidenceKeys"))}")
            line("Stalled keys: ${arrayToString(momentum.optJSONArray("stalledEvidenceKeys"))}")
            line("Graph delta: ${momentum.optString("graphDelta", "none")}")
            line("Decision lock: ${momentum.optString("decisionLock", "none")}")
            line("Next action: ${momentum.optString("nextAction", "none")}")
            line("Momentum search decision: ${momentum.optString("searchDecision", "none")}")
        }

        val spine = report.optJSONObject("linkedCognitionSpineReport") ?: JSONObject()
        if (spine.optBoolean("active", false)) {
            line("Linked cognition spine v1.10.0: ${spine.optString("state", "NO_SPINE")} • integrity ${spine.optInt("linkIntegrityScore", 0)}/100 • mode ${spine.optString("routeMode", "NO_ROUTE")}")
            line("Governing layer: ${spine.optString("governingLayer", "none")}")
            line("Connected layers: ${arrayToString(spine.optJSONArray("connectedLayers"))}")
            line("Disconnected layers: ${arrayToString(spine.optJSONArray("disconnectedLayers"))}")
            line("Open evidence keys: ${arrayToString(spine.optJSONArray("openEvidenceKeys"))}")
            line("Governing decision: ${spine.optString("governingDecision", "none")}")
            line("Spine next action: ${spine.optString("nextAction", "none")}")
            line("Spine search decision: ${spine.optString("searchDecision", "none")}")
            line("Spine query budget: ${spine.optString("queryBudget", "none")}")
            line("Handoff trace: ${arrayToString(spine.optJSONArray("handoffTrace"))}")
        }
        val thoughtPulse = report.optJSONObject("autonomousThoughtPulse") ?: JSONObject()
        if (thoughtPulse.length() > 0) {
            line("Autonomous thought pulse v1.9.7: ${thoughtPulse.optString("state", "not recorded")} • iteration ${thoughtPulse.optInt("thoughtIteration", 0)}")
            line("Pulse decision: ${thoughtPulse.optString("decision", "none")}")
            line("Pulse gaps: ${arrayToString(thoughtPulse.optJSONArray("unresolvedGaps"))}")
            line("Pulse unlock: ${thoughtPulse.optString("searchUnlockCondition", "none")}")
        }
        val threads = continuity.optJSONArray("openThreads") ?: JSONArray()
        if (threads.length() == 0) line("Open thought threads: none") else for (i in 0 until threads.length().coerceAtMost(3)) {
            val t = threads.optJSONObject(i) ?: continue
            line("• ${t.optString("state")} — ${t.optString("label")}")
            line("  Open: ${arrayToString(t.optJSONArray("openQuestions"))}")
            line("  Next: ${t.optString("nextDecision", "none")}")
        }
        val planStage = report.optJSONObject("cyclePlanStageReport") ?: JSONObject()
        if (planStage.optBoolean("active", false)) {
            line("Cycle plan stage v1.10.6: ${planStage.optString("state", "NOT_EVALUATED")} • owner ${planStage.optString("governingLayer", "none")} • directive ${planStage.optString("directiveMode", "unknown")}")
            line("Plan budget: selected=${planStage.optInt("selectedQueryCount", 0)}/${planStage.optInt("inputQueryCount", 0)} • maxQueries=${planStage.optInt("maxQueries", 0)} • results=${planStage.optInt("maxResultsPerQuery", 0)}")
            line("Selected queries: ${arrayToString(planStage.optJSONArray("selectedQueryIds"))}")
            line("Rejected queries: ${arrayToString(planStage.optJSONArray("rejectedQueryIds"))}")
            line("Plan warnings: ${arrayToString(planStage.optJSONArray("warnings"))}")
            line("Plan next phase: ${planStage.optString("nextPhase", "none")}")
        }
        val phaseAudit = report.optJSONObject("cyclePhaseAuditReport") ?: JSONObject()
        if (phaseAudit.optBoolean("active", false)) {
            line("Cycle phase audit v1.10.4: ${phaseAudit.optString("state", "NOT_EVALUATED")} • owner ${phaseAudit.optString("governingLayer", "none")} • mode ${phaseAudit.optString("searchMode", "unknown")}")
            line("Network budget: ${phaseAudit.optString("networkBudget", "unknown")} • runtime failover blocked=${phaseAudit.optBoolean("runtimeFailoverBlocked", false)}")
            line("Phase summary: ${phaseAudit.optString("summary", "No phase audit summary.")}")
            line("Lock violations: ${arrayToString(phaseAudit.optJSONArray("lockViolations"))}")
            val phaseItems = phaseAudit.optJSONArray("phases") ?: JSONArray()
            for (i in 0 until phaseItems.length().coerceAtMost(6)) {
                val item = phaseItems.optJSONObject(i) ?: continue
                line("• ${item.optString("phase")} — ${item.optString("status")} / owner=${item.optString("owner")} / decision=${item.optString("decision")}")
                line("  Evidence: ${arrayToString(item.optJSONArray("evidence"))}")
            }
            line("Phase next gate: ${phaseAudit.optString("nextGate", "none")}")
        }
        val maintenance = report.optJSONObject("pathMaintenanceReport") ?: JSONObject()
        if (maintenance.optBoolean("active", false)) {
            line("Path maintenance guard v1.10.7: ${maintenance.optString("state", "NOT_EVALUATED")} • owner ${maintenance.optString("governingLayer", "none")}")
            line("Linked stages: ${arrayToString(maintenance.optJSONArray("linkedStages"))}")
            line("Weak handoffs: ${arrayToString(maintenance.optJSONArray("weakHandoffs"))}")
            line("Repair target: ${maintenance.optString("repairTarget", "none")}")
        }
        val extendedThinking = report.optJSONObject("extendedThinkingBudgetReport") ?: JSONObject()
        if (extendedThinking.optBoolean("active", false)) {
            line("Extended thinking budget v1.10.16: ${extendedThinking.optString("mode", "NORMAL_THINKING_BUDGET")} • passes ${extendedThinking.optInt("passesExecuted", 0)}/${extendedThinking.optInt("minimumPassesRequired", 0)}")
            line("Thinking summary: ${extendedThinking.optString("summary", "No extended thinking summary.")}")
            line("Next thinking action: ${extendedThinking.optString("nextAction", "none")}")
            val passes = extendedThinking.optJSONArray("passSummaries") ?: JSONArray()
            for (i in 0 until passes.length().coerceAtMost(4)) line("• ${passes.optString(i)}")
        }
        line("Claim limit: ${thinking.optString("claimLimit", "post_search_thinking_not_biological_proof")} / ${continuity.optString("claimLimit", "thinking_continuity_not_biological_proof")} / ${thoughtPulse.optString("claimLimit", "autonomous_thought_pulse_not_biological_proof")} / ${spine.optString("claimLimit", "linked_cognition_spine_not_biological_proof")} / ${planStage.optString("claimLimit", "cycle_plan_stage_not_biological_proof")} / ${phaseAudit.optString("claimLimit", "cycle_phase_audit_not_biological_proof")} / ${maintenance.optString("claimLimit", "path_maintenance_guard_not_biological_proof")} / ${extendedThinking.optString("claimLimit", "extended_thinking_budget_not_biological_proof")}")
        y += 8f

        line("Learning OS — root cause, gates, readiness", title)
        val learningOs = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incident = learningOs.optJSONObject("incident") ?: JSONObject()
        val readiness = learningOs.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        line("Root causes: ${arrayToString(incident.optJSONArray("rootCauses"))}")
        line("Observed: ${arrayToString(incident.optJSONArray("observedSignals"))}")
        line("Hypothesis update gate: ${learningOs.optString("hypothesisUpdateGateStatus", "NO_EVIDENCE_OBJECT_NO_UPGRADE")}")
        line("Discovery readiness: ${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")}")
        line("Next learning action: ${learningOs.optString("nextLearningAction", "none")}")
        line("Execution enforced actions: ${arrayToString(execution.optJSONArray("enforcedActions"))}")
        val gates = learningOs.optJSONArray("preventiveGates") ?: JSONArray()
        if (gates.length() == 0) line("Preventive gates: none") else for (i in 0 until gates.length().coerceAtMost(5)) {
            val g = gates.optJSONObject(i) ?: continue
            line("• ${g.optString("gateId")} → ${g.optString("forcedNextIntent")}: ${g.optString("action")}")
        }
        val cooldowns = learningOs.optJSONArray("laneCooldowns") ?: JSONArray()
        if (cooldowns.length() > 0) {
            line("Lane cooldowns:")
            for (i in 0 until cooldowns.length().coerceAtMost(3)) {
                val c = cooldowns.optJSONObject(i) ?: continue
                line("• ${c.optString("laneName")} blocked ${c.optInt("cooldownCycles")} cycles because ${c.optString("lastFailureReason")}")
            }
        }
        y += 8f

        line("Research reasoning — why the next question changed", title)
        val reasoning = report.optJSONObject("reasoningReport") ?: JSONObject()
        line("Observation: ${reasoning.optString("observation", "No reasoning observation yet.")}")
        line("Meaning: ${reasoning.optString("interpretedMeaning", "No interpretation yet.")}")
        line("Generated questions:")
        writeArray(reasoning.optJSONArray("generatedQuestions")) { line("• $it") }
        line("Competing explanations:")
        writeArray(reasoning.optJSONArray("competingHypotheses")) { line("• $it") }
        line("Discriminator evidence needed:")
        writeArray(reasoning.optJSONArray("discriminatorEvidence")) { line("• $it") }
        line("Reframed search: ${reasoning.optString("reframedSearch", "none")}")
        line("Self-critique:")
        writeArray(reasoning.optJSONArray("selfCritique")) { line("• $it") }
        line("Next reasoned move: ${reasoning.optString("nextReasonedMove", "Run next autonomous cycle.")}")
        y += 8f

        line("Specialized reasoning — beyond generic AI", title)
        val specialist = report.optJSONObject("specializedReasoningReport") ?: JSONObject()
        line("State: ${specialist.optString("state", "NOT_EVALUATED")} • Score ${specialist.optInt("specialistScore", 0)}/100")
        line("Weakest link: ${specialist.optString("weakestLink", "none")}")
        line("Strongest improvement: ${specialist.optString("strongestImprovement", "none")}")
        line("Decisive next test: ${specialist.optString("decisiveNextTest", "none")}")
        line("Falsification demand: ${specialist.optString("falsificationDemand", "none")}")
        line("Axis discipline: ${specialist.optString("axisDiscipline", "none")}")
        line("Specialist verdict: ${specialist.optString("specialistVerdict", "none")}")
        line("General-model failure risks:")
        writeArray(specialist.optJSONArray("generalModelFailureRisks")) { line("• $it") }
        val specialistEvidenceGaps = specialist.optJSONArray("evidenceGaps") ?: JSONArray()
        if (specialistEvidenceGaps.length() == 0) line("Evidence gaps: none") else for (i in 0 until specialistEvidenceGaps.length().coerceAtMost(4)) {
            val gap = specialistEvidenceGaps.optJSONObject(i) ?: continue
            line("• Gap ${gap.optString("gapId")} — ${gap.optString("status")} severity ${gap.optInt("severity")}/100")
            line("  Action: ${gap.optString("requiredAction")}")
        }
        val tournament = specialist.optJSONArray("hypothesisTournament") ?: JSONArray()
        if (tournament.length() > 0) {
            line("Hypothesis tournament:")
            for (i in 0 until tournament.length().coerceAtMost(4)) {
                val card = tournament.optJSONObject(i) ?: continue
                line("• ${card.optString("status")} ${card.optInt("score")}/100 — ${card.optString("label")}")
                line("  Discriminator: ${card.optString("nextDiscriminator")}")
            }
        }
        val protocol = specialist.optJSONArray("nextCycleProtocol") ?: JSONArray()
        if (protocol.length() > 0) {
            line("Next-cycle protocol:")
            writeArray(protocol) { line("• $it") }
        }
        val expertMoves = specialist.optJSONArray("expertMoves") ?: JSONArray()
        if (expertMoves.length() == 0) line("Expert moves: none") else for (i in 0 until expertMoves.length().coerceAtMost(6)) {
            val move = expertMoves.optJSONObject(i) ?: continue
            line("• ${move.optString("name")} — ${move.optString("status")} ${move.optInt("score")}/100")
            line("  Finding: ${move.optString("finding")}")
            line("  Next: ${move.optString("nextAction")}")
        }
        line("Claim limit: ${specialist.optString("claimLimit", "specialized_reasoning_not_biological_proof")}")
        y += 8f

        line("Epistemic belief model", title)
        val belief = report.optJSONObject("epistemicBeliefReport") ?: JSONObject()
        line("State: ${belief.optString("state", "NOT_BUILT")} • Score ${belief.optInt("beliefScore", 0)}/100")
        line("Brief: ${belief.optString("visibleBrief", "No belief model yet.")}")
        line("Carried: ${belief.optInt("carriedForwardBeliefs", 0)} belief(s) • New: ${belief.optInt("newBeliefsThisCycle", 0)} • Weakened: ${belief.optInt("weakenedBeliefs", 0)} • Revise: ${belief.optInt("revisedBeliefs", 0)}")
        val transitionSummary = belief.optJSONObject("transitionSummary") ?: JSONObject()
        line("Strengthened belief: ${transitionSummary.optString("strengthenedBelief", "None this cycle.")}")
        line("Weakened belief: ${transitionSummary.optString("weakenedBelief", "None this cycle.")}")
        line("Dropped belief: ${transitionSummary.optString("droppedBelief", "None this cycle.")}")
        line("Belief abandonment test: ${transitionSummary.optString("abandonmentQuestion", "What evidence would make me abandon this belief?")}")
        line("Pruning rule: ${transitionSummary.optString("pruningRule", "Weak unused beliefs are not carried forward.")}")
        line("Next belief action: ${belief.optString("nextBeliefAction", "Use beliefs as mutable search priors only.")}")
        val beliefUpdates = belief.optJSONArray("updates") ?: JSONArray()
        if (beliefUpdates.length() == 0) line("Belief updates: none") else for (i in 0 until beliefUpdates.length().coerceAtMost(4)) {
            val update = beliefUpdates.optJSONObject(i) ?: continue
            line("• ${update.optString("updateType")} ${update.optString("previousStatus")} → ${update.optString("newStatus")} — ${update.optString("beliefId")}")
            line("  Next: ${update.optString("nextAction")}")
        }
        val beliefItems = belief.optJSONArray("beliefs") ?: JSONArray()
        if (beliefItems.length() > 0) {
            line("Top mutable beliefs:")
            for (i in 0 until beliefItems.length().coerceAtMost(5)) {
                val item = beliefItems.optJSONObject(i) ?: continue
                line("• ${item.optString("status")} c=${item.optInt("credibility")}/100 — ${item.optString("statement")}")
                line("  Abandon if: ${item.optString("abandonmentQuestion", "What evidence would make me abandon this belief?")}")
            }
        }
        line("Claim limit: ${belief.optString("claimLimit", "epistemic_beliefs_not_biological_proof")}")
        y += 8f

        line("Cognitive path integration", title)
        val cognitivePath = report.optJSONObject("cognitivePathIntegrationReport") ?: JSONObject()
        line("State: ${cognitivePath.optString("state", "NOT_BUILT")} • Score ${cognitivePath.optInt("integrationScore", 0)}/100")
        line("Route integrity: ${cognitivePath.optString("routeIntegrity", "NOT_EVALUATED")}")
        line("Brief: ${cognitivePath.optString("visibleBrief", "No linked path yet.")}")
        val pathDecision = cognitivePath.optJSONObject("decision") ?: JSONObject()
        line("Decision: ${pathDecision.optString("decisionType", "NO_DECISION")} • blocks upgrade=${pathDecision.optBoolean("blocksHypothesisUpgrade", true)}")
        line("Next linked action: ${pathDecision.optString("action", "Use linked path for next cycle.")}")
        val requiredEvidence = pathDecision.optJSONArray("requiredEvidence") ?: JSONArray()
        if (requiredEvidence.length() > 0) {
            line("Required evidence from linked path:")
            writeArray(requiredEvidence) { line("• $it") }
        }
        val pathLinks = cognitivePath.optJSONArray("links") ?: JSONArray()
        if (pathLinks.length() > 0) {
            line("Integrated links:")
            for (i in 0 until pathLinks.length().coerceAtMost(4)) {
                val link = pathLinks.optJSONObject(i) ?: continue
                line("• ${link.optString("relation")} ${link.optInt("strength")}/100: ${link.optString("fromId")} → ${link.optString("toId")}")
            }
        }
        line("Claim limit: ${cognitivePath.optString("claimLimit", "cognitive_path_integration_not_biological_proof")}")
        val nextCyclePlan = report.optJSONObject("cognitiveNextCyclePlan") ?: JSONObject()
        if (nextCyclePlan.optBoolean("active", false) || nextCyclePlan.optBoolean("directiveConsumed", false)) {
            line("Closed cognitive loop for next cycle", title)
            line("Summary: ${nextCyclePlan.optString("summary", "No next-cycle directive applied.")}")
            line("Directive: ${nextCyclePlan.optString("directiveId", "none")} • follow-up=${nextCyclePlan.optBoolean("addedFollowUpQuery", false)} • consumed=${nextCyclePlan.optBoolean("directiveConsumed", false)}")
            val consumptionReason = nextCyclePlan.optString("consumptionReason")
            if (consumptionReason.isNotBlank()) line("Consumption reason: $consumptionReason")
            val appliedTerms = nextCyclePlan.optJSONArray("appliedTerms") ?: JSONArray()
            if (appliedTerms.length() > 0) {
                line("Terms carried into next search:")
                writeArray(appliedTerms) { line("• $it") }
            }
            line("Claim limit: ${nextCyclePlan.optString("claimLimit", "next_cycle_routing_only_not_biological_proof")}")
        }
        val loopCalibration = report.optJSONObject("cognitiveLoopCalibrationReport") ?: JSONObject()
        if (loopCalibration.optBoolean("active", false)) {
            line("Cognitive loop calibration", title)
            line("Outcome: ${loopCalibration.optString("outcome", "MIXED_PROGRESS")} • Score ${loopCalibration.optInt("calibrationScore", 0)}/100")
            line("Brief: ${loopCalibration.optString("visibleBrief", "The previous linked path was evaluated.")}")
            line("Next calibration action: ${loopCalibration.optString("nextCalibrationAction", "Keep the next loop bounded.")}")
            val improved = loopCalibration.optJSONArray("improvedSignals") ?: JSONArray()
            if (improved.length() > 0) {
                line("Improved signals:")
                for (i in 0 until improved.length().coerceAtMost(4)) {
                    val item = improved.optJSONObject(i) ?: continue
                    line("• ${item.optString("name")} +${item.optInt("score")}: ${item.optString("reason")}")
                }
            }
            val stalled = loopCalibration.optJSONArray("stalledSignals") ?: JSONArray()
            if (stalled.length() > 0) {
                line("Stalled signals:")
                for (i in 0 until stalled.length().coerceAtMost(4)) {
                    val item = stalled.optJSONObject(i) ?: continue
                    line("• ${item.optString("name")} -${item.optInt("score")}: ${item.optString("reason")}")
                }
            }
            line("Claim limit: ${loopCalibration.optString("claimLimit", "cognitive_loop_calibration_not_biological_proof")}")
        }
        y += 8f

        val directiveLifecycle = report.optJSONObject("directiveLifecycleReport") ?: JSONObject()
        if (directiveLifecycle.optBoolean("active", false)) {
            line("Directive lifecycle v1.7", title)
            line("State: ${directiveLifecycle.optString("state", "NO_DIRECTIVE")} • applied=${directiveLifecycle.optBoolean("previousDirectiveApplied", false)} • improved=${directiveLifecycle.optBoolean("improved", false)}")
            line("Expected: ${directiveLifecycle.optString("expectedEffect", "none")}")
            line("Observed: ${directiveLifecycle.optString("observedEffect", "none")}")
            line("Next: ${directiveLifecycle.optString("nextAction", "Keep next directive bounded.")}")
        }
        val evidenceGain = report.optJSONObject("evidenceGainQueryRankerReport") ?: JSONObject()
        if (evidenceGain.optBoolean("active", false)) {
            line("Evidence-gain query ranking", title)
            line("Chosen: ${evidenceGain.optString("chosenQueryId", "none")} • ${evidenceGain.optInt("chosenScore", 0)}/100")
            line("Why: ${evidenceGain.optString("summary", "No query ranking summary.")}")
        }
        val causalReady = report.optJSONObject("causalReadinessReport") ?: JSONObject()
        if (causalReady.optBoolean("active", false)) {
            line("Causal readiness gate", title)
            line("State: ${causalReady.optString("state", "ASSOCIATION_ONLY")} • level ${causalReady.optInt("level", 0)}/5 • score ${causalReady.optInt("score", 0)}/100")
            line("Causal language allowed: ${causalReady.optBoolean("causalLanguageAllowed", false)} • Strong signal allowed: ${causalReady.optBoolean("strongSignalAllowed", false)}")
            line("Next: ${causalReady.optString("nextAction", "Close causal blockers.")}")
        }
        val peer = report.optJSONObject("miniPeerReviewReport") ?: JSONObject()
        if (peer.optBoolean("active", false)) {
            line("Mini peer review gate", title)
            line("Verdict: ${peer.optString("verdict", "HOLD")}")
            line("Strongest objection: ${peer.optString("strongestObjection", "none")}")
            line("Falsification test: ${peer.optString("falsificationTest", "Run negative-control search.")}")
        }
        val reflection = report.optJSONObject("reflectionLessonReport") ?: JSONObject()
        if (reflection.optBoolean("active", false)) {
            line("Reflection lesson", title)
            line("Lesson: ${reflection.optString("lesson", "none")}")
            line("Prevention: ${reflection.optString("prevention", "none")}")
        }
        val scientificIndex = report.optJSONObject("scientificKnowledgeIndexReport") ?: JSONObject()
        if (scientificIndex.optBoolean("active", false)) {
            line("Scientific term index v1.8", title)
            line("Summary: ${scientificIndex.optString("summary", "term index active")}")
            val terms = scientificIndex.optJSONArray("matchedTerms") ?: JSONArray()
            if (terms.length() > 0) {
                line("Prior terms used:")
                for (i in 0 until terms.length().coerceAtMost(6)) {
                    val term = terms.optJSONObject(i) ?: continue
                    line("• ${term.optString("label", term.optString("termId"))} — ${term.optString("domain", "biology")} importance ${term.optInt("importance", 0)}/100")
                    line("  Route impact: ${term.optString("routeImpact", "search prior")}")
                }
            }
            val warnings = scientificIndex.optJSONArray("falseFriendWarnings") ?: JSONArray()
            if (warnings.length() > 0) {
                line("False-friend warnings:")
                for (i in 0 until warnings.length().coerceAtMost(4)) line("• ${warnings.optString(i)}")
            }
            line("Claim limit: ${scientificIndex.optString("claimLimit", "scientific_index_guides_search_not_proof")}")
        }
        val scientificWeights = report.optJSONObject("scientificDiscoveryWeightReport") ?: JSONObject()
        if (scientificWeights.optBoolean("active", false)) {
            line("Weighted discovery intelligence v1.8.2", title)
            line("Summary: ${scientificWeights.optString("summary", "weighted routing active")}")
            line("Learning receipt: ${scientificWeights.optString("learningReceipt", "none")}")
            val topWeights = scientificWeights.optJSONArray("topWeights") ?: JSONArray()
            if (topWeights.length() > 0) {
                line("Top weighted terms:")
                for (i in 0 until topWeights.length().coerceAtMost(5)) {
                    val card = topWeights.optJSONObject(i) ?: continue
                    line("• ${card.optString("label", card.optString("termId"))} — weight ${card.optInt("routingWeight", 0)}/100; gap ${card.optInt("evidenceGapScore", 0)}/100; false-friend ${card.optInt("falseFriendRisk", 0)}/100")
                    line("  Action: ${card.optString("action", "MONITOR_ONLY")}")
                }
            }
            val delta = scientificWeights.optJSONArray("decisiveEvidenceDelta") ?: JSONArray()
            if (delta.length() > 0) line("Decisive evidence delta: ${(0 until delta.length().coerceAtMost(8)).joinToString(", ") { delta.optString(it) }}")
            val guards = scientificWeights.optJSONArray("riskGuards") ?: JSONArray()
            if (guards.length() > 0) {
                line("Risk guards:")
                for (i in 0 until guards.length().coerceAtMost(4)) line("• ${guards.optString(i)}")
            }
            line("Claim limit: ${scientificWeights.optString("claimLimit", "scientific_weighting_guides_routing_not_proof")}")
        }
        val scientificDecision = report.optJSONObject("scientificDiscoveryDecisionReport") ?: JSONObject()
        if (scientificDecision.optBoolean("active", false)) {
            line("Discovery decision memory v1.8.3", title)
            line("Summary: ${scientificDecision.optString("summary", "decision memory active")}")
            line("Selected move: ${scientificDecision.optString("selectedMove", "none")}")
            line("Reason: ${scientificDecision.optString("selectedReason", "none")}")
            line("Blocked move: ${scientificDecision.optString("blockedMove", "none")}")
            line("Blocked reason: ${scientificDecision.optString("blockedReason", "none")}")
            line("Next-cycle contract: ${scientificDecision.optString("nextCycleContract", "none")}")
            val success = scientificDecision.optJSONArray("successCriteria") ?: JSONArray()
            if (success.length() > 0) {
                line("Success criteria:")
                for (i in 0 until success.length().coerceAtMost(4)) line("• ${success.optString(i)}")
            }
            val failure = scientificDecision.optJSONArray("failureCriteria") ?: JSONArray()
            if (failure.length() > 0) {
                line("Failure criteria:")
                for (i in 0 until failure.length().coerceAtMost(4)) line("• ${failure.optString(i)}")
            }
            line("If it fails: ${scientificDecision.optString("changeIfFails", "none")}")
            line("Claim limit: ${scientificDecision.optString("claimLimit", "scientific_decision_memory_guides_routing_not_proof")}")
        }
        val scientificStress = report.optJSONObject("scientificDiscoveryStressTestReport") ?: JSONObject()
        if (scientificStress.optBoolean("active", false)) {
            line("Counterfactual discovery stress test v1.8.4", title)
            line("State: ${scientificStress.optString("stressState", "NOT_RUN")} • Selected scenario: ${scientificStress.optString("selectedScenario", "none")}")
            line("Summary: ${scientificStress.optString("reportLine", "stress test active")}")
            val scenarios = scientificStress.optJSONArray("scenarios") ?: JSONArray()
            if (scenarios.length() > 0) {
                line("Stress scenarios:")
                for (i in 0 until scenarios.length().coerceAtMost(3)) {
                    val scenario = scenarios.optJSONObject(i) ?: continue
                    line("• ${scenario.optString("label", scenario.optString("scenarioId"))} — risk ${scenario.optString("risk", "UNKNOWN")}")
                    line("  Pass: ${scenario.optString("passCondition", "none")}")
                    line("  Fail: ${scenario.optString("failCondition", "none")}")
                }
            }
            val branches = scientificStress.optJSONArray("branchActions") ?: JSONArray()
            if (branches.length() > 0) {
                line("Branch actions:")
                for (i in 0 until branches.length().coerceAtMost(5)) line("• ${branches.optString(i)}")
            }
            line("Null-result policy: ${scientificStress.optString("nullResultPolicy", "none")}")
            line("Contradiction policy: ${scientificStress.optString("contradictionPolicy", "none")}")
            val forced = scientificStress.optJSONArray("forcedEvidenceKeys") ?: JSONArray()
            if (forced.length() > 0) line("Forced evidence keys: ${(0 until forced.length().coerceAtMost(8)).joinToString(", ") { forced.optString(it) }}")
            line("Claim limit: ${scientificStress.optString("claimLimit", "counterfactual_stress_test_guides_routing_not_proof")}")
        }
        val scientificPolicy = report.optJSONObject("scientificDiscoveryExecutionPolicyReport") ?: JSONObject()
        if (scientificPolicy.optBoolean("active", false)) {
            line("Policy-enforced discovery control v1.8.5", title)
            line("State: ${scientificPolicy.optString("policyState", "NOT_RUN")} • Mode: ${scientificPolicy.optString("executionMode", "NO_POLICY")}")
            line("Summary: ${scientificPolicy.optString("reportLine", "policy active")}")
            val allowed = scientificPolicy.optJSONArray("allowedActions") ?: JSONArray()
            if (allowed.length() > 0) {
                line("Allowed next actions:")
                for (i in 0 until allowed.length().coerceAtMost(5)) line("• ${allowed.optString(i)}")
            }
            val blocked = scientificPolicy.optJSONArray("blockedActions") ?: JSONArray()
            if (blocked.length() > 0) {
                line("Blocked actions:")
                for (i in 0 until blocked.length().coerceAtMost(5)) line("• ${blocked.optString(i)}")
            }
            val replay = scientificPolicy.optJSONArray("queryReplayBlocks") ?: JSONArray()
            if (replay.length() > 0) {
                line("Query replay blocks:")
                for (i in 0 until replay.length().coerceAtMost(4)) line("• ${replay.optString(i)}")
            }
            line("Route cooldown policy: ${scientificPolicy.optString("routeCooldownPolicy", "none")}")
            line("Belief burial policy: ${scientificPolicy.optString("beliefBurialPolicy", "none")}")
            val forcedPolicy = scientificPolicy.optJSONArray("forcedEvidenceKeys") ?: JSONArray()
            if (forcedPolicy.length() > 0) line("Policy forced evidence: ${(0 until forcedPolicy.length().coerceAtMost(8)).joinToString(", ") { forcedPolicy.optString(it) }}")
            line("Claim limit: ${scientificPolicy.optString("claimLimit", "execution_policy_guides_routing_not_proof")}")
        }
        val outcomeVerifier = report.optJSONObject("scientificDiscoveryOutcomeVerifierReport") ?: JSONObject()
        if (outcomeVerifier.optBoolean("active", false)) {
            line("Outcome verification discovery memory v1.8.6", title)
            line("State: ${outcomeVerifier.optString("verifierState", "NOT_RUN")} • Score ${outcomeVerifier.optInt("outcomeScore", 0)}/100 • Applied=${outcomeVerifier.optBoolean("policyApplied", false)}")
            line("Summary: ${outcomeVerifier.optString("reportLine", "outcome verifier active")}")
            val resolved = outcomeVerifier.optJSONArray("resolvedEvidenceKeys") ?: JSONArray()
            if (resolved.length() > 0) line("Resolved evidence: ${(0 until resolved.length().coerceAtMost(8)).joinToString(", ") { resolved.optString(it) }}")
            val unmet = outcomeVerifier.optJSONArray("unmetEvidenceKeys") ?: JSONArray()
            if (unmet.length() > 0) line("Unmet evidence: ${(0 until unmet.length().coerceAtMost(8)).joinToString(", ") { unmet.optString(it) }}")
            val blockedReplay = outcomeVerifier.optJSONArray("blockedReplayKeys") ?: JSONArray()
            if (blockedReplay.length() > 0) {
                line("Verifier replay blocks:")
                for (i in 0 until blockedReplay.length().coerceAtMost(4)) line("• ${blockedReplay.optString(i)}")
            }
            line("Route adjustment: ${outcomeVerifier.optString("routeAdjustment", "none")}")
            line("Belief adjustment: ${outcomeVerifier.optString("beliefAdjustment", "none")}")
            line("Next policy adjustment: ${outcomeVerifier.optString("nextPolicyAdjustment", "none")}")
            line("Claim limit: ${outcomeVerifier.optString("claimLimit", "outcome_verification_guides_routing_not_proof")}")
        }
        val lineage = report.optJSONObject("scientificDiscoveryLineageReport") ?: JSONObject()
        if (lineage.optBoolean("active", false)) {
            line("Hypothesis lineage discovery graph v1.8.7", title)
            line("State: ${lineage.optString("lineageState", "NOT_RUN")} • Score ${lineage.optInt("graphCompletenessScore", 0)}/100 • Active hypotheses=${lineage.optInt("activeHypotheses", 0)}")
            line("Summary: ${lineage.optString("reportLine", "lineage graph active")}")
            line("Next lineage action: ${lineage.optString("nextLineageAction", "keep parent evidence explicit")}")
            val carry = lineage.optJSONArray("contradictionCarryForward") ?: JSONArray()
            if (carry.length() > 0) {
                line("Contradiction carry-forward:")
                for (i in 0 until carry.length().coerceAtMost(4)) line("• ${carry.optString(i)}")
            }
            val cards = lineage.optJSONArray("hypothesisLineages") ?: JSONArray()
            if (cards.length() > 0) {
                line("Lineage cards:")
                for (i in 0 until cards.length().coerceAtMost(3)) {
                    val card = cards.optJSONObject(i) ?: continue
                    line("• ${card.optString("lineageVerdict", "LINEAGE_PROVISIONAL")} — ${card.optString("label", "hypothesis").take(120)}")
                    line("  Action: ${card.optString("splitOrMergeAction", "keep guarded lineage")}")
                    line("  Next: ${card.optString("nextLineageTest", "resolve parent evidence")}")
                }
            }
            val forced = lineage.optJSONArray("forcedEvidenceKeys") ?: JSONArray()
            if (forced.length() > 0) line("Lineage forced evidence: ${(0 until forced.length().coerceAtMost(8)).joinToString(", ") { forced.optString(it) }}")
            line("Claim limit: ${lineage.optString("claimLimit", "hypothesis_lineage_guides_routing_not_proof")}")
        }
        val gapMiner = report.optJSONObject("scientificDiscoveryGapMinerReport") ?: JSONObject()
        if (gapMiner.optBoolean("active", false)) {
            line("Latent discovery gap miner v1.8.8", title)
            line("State: ${gapMiner.optString("minerState", "NOT_RUN")} • Opportunity ${gapMiner.optInt("opportunityScore", 0)}/100")
            line("Summary: ${gapMiner.optString("reportLine", "latent gap miner active")}")
            line("Next discovery probe: ${gapMiner.optString("nextDiscoveryProbe", "run a narrow probe")}")
            val opps = gapMiner.optJSONArray("latentOpportunities") ?: JSONArray()
            if (opps.length() > 0) {
                line("Latent opportunities:")
                for (i in 0 until opps.length().coerceAtMost(3)) {
                    val card = opps.optJSONObject(i) ?: continue
                    line("• ${card.optString("opportunityType", "OPPORTUNITY")} ${card.optInt("priority", 0)}/100 — ${card.optString("label", "latent opportunity").take(120)}")
                    line("  Probe: ${card.optString("probeQuery", "narrow probe required").take(160)}")
                }
            }
            val gapMinerMissingEvidence = gapMiner.optJSONArray("missingButHighValueEvidence") ?: JSONArray()
            if (gapMinerMissingEvidence.length() > 0) line("High-value missing evidence: ${(0 until gapMinerMissingEvidence.length().coerceAtMost(8)).joinToString(", ") { gapMinerMissingEvidence.optString(it) }}")
            val blocked = gapMiner.optJSONArray("blockedBy") ?: JSONArray()
            if (blocked.length() > 0) line("Gap-miner blockers: ${(0 until blocked.length().coerceAtMost(6)).joinToString(", ") { blocked.optString(it) }}")
            line("Claim limit: ${gapMiner.optString("claimLimit", "latent_discovery_gap_miner_guides_routing_not_proof")}")
        }
        val probePlan = report.optJSONObject("scientificDiscoveryProbePlanReport") ?: JSONObject()
        if (probePlan.optBoolean("active", false)) {
            line("Executable discovery probe plan v1.8.9", title)
            line("State: ${probePlan.optString("plannerState", "NOT_RUN")} • Budget ${probePlan.optInt("probeBudget", 0)}")
            line("Summary: ${probePlan.optString("reportLine", "probe plan active")}")
            line("Selected probe query: ${probePlan.optString("selectedProbeQuery", "bounded probe required")}")
            val pack = probePlan.optJSONArray("evidencePack") ?: JSONArray()
            if (pack.length() > 0) line("Evidence pack: ${(0 until pack.length().coerceAtMost(10)).joinToString(", ") { pack.optString(it) }}")
            val steps = probePlan.optJSONArray("probeSteps") ?: JSONArray()
            if (steps.length() > 0) {
                line("Probe steps:")
                for (i in 0 until steps.length().coerceAtMost(3)) {
                    val step = steps.optJSONObject(i) ?: continue
                    line("• ${step.optString("label", "probe").take(120)}")
                    line("  Query: ${step.optString("query", "").take(160)}")
                    line("  Route effect: ${step.optString("routeEffect", "guarded")}")
                }
            }
            line("If succeeds: ${probePlan.optString("ifProbeSucceeds", "inspect cautiously")}")
            line("If fails: ${probePlan.optString("ifProbeFails", "cool down route")}")
            line("Claim limit: ${probePlan.optString("claimLimit", "executable_probe_plan_guides_routing_not_proof")}")
        }
        val probeOutcomeLedger = report.optJSONObject("scientificDiscoveryProbeOutcomeLedgerReport") ?: JSONObject()
        if (probeOutcomeLedger.optBoolean("active", false)) {
            line("Probe outcome learning ledger v1.9.0", title)
            line("State: ${probeOutcomeLedger.optString("ledgerState", "NOT_RUN")} • Closure ${probeOutcomeLedger.optInt("evidenceClosureScore", 0)}/100")
            line("Previous probe: ${probeOutcomeLedger.optString("previousProbeId", "none")} • ${probeOutcomeLedger.optString("previousPlannerState", "unknown")}")
            line("Summary: ${probeOutcomeLedger.optString("reportLine", "probe outcome ledger active")}")
            val closed = probeOutcomeLedger.optJSONArray("closedEvidenceKeys") ?: JSONArray()
            if (closed.length() > 0) line("Closed evidence: ${(0 until closed.length().coerceAtMost(8)).joinToString(", ") { closed.optString(it) }}")
            val unresolved = probeOutcomeLedger.optJSONArray("unresolvedEvidenceKeys") ?: JSONArray()
            if (unresolved.length() > 0) line("Unresolved evidence: ${(0 until unresolved.length().coerceAtMost(8)).joinToString(", ") { unresolved.optString(it) }}")
            val replay = probeOutcomeLedger.optJSONArray("replayPenaltyKeys") ?: JSONArray()
            if (replay.length() > 0) line("Replay penalty keys: ${(0 until replay.length().coerceAtMost(8)).joinToString(", ") { replay.optString(it) }}")
            line("Route disposition: ${probeOutcomeLedger.optString("routeDisposition", "Keep route gated.")}")
            line("Belief disposition: ${probeOutcomeLedger.optString("beliefDisposition", "Keep belief mutable.")}")
            line("Next probe decision: ${probeOutcomeLedger.optString("nextProbeDecision", "Run bounded evidence closure.")}")
            line("Claim limit: ${probeOutcomeLedger.optString("claimLimit", "probe_outcome_learning_guides_routing_not_proof")}")
        }
        val metaStrategy = report.optJSONObject("scientificDiscoveryMetaStrategyReport") ?: JSONObject()
        if (metaStrategy.optBoolean("active", false)) {
            line("Meta-strategy governor v1.9.1", title)
            line("State: ${metaStrategy.optString("strategyState", "NOT_RUN")} • Score ${metaStrategy.optInt("governorScore", 0)}/100 • Mode ${metaStrategy.optString("explorationExploitationMode", "BALANCED_GUARDED")}")
            line("Selected strategy: ${metaStrategy.optString("selectedStrategy", "Run guarded evidence routing.")}")
            line("Blocked strategy: ${metaStrategy.optString("blockedStrategy", "No blocked strategy.")}")
            line("Continuation: ${metaStrategy.optString("continuationDecision", "Continue with bounded evidence closure.")}")
            line("Deep Think permission: ${metaStrategy.optString("deepThinkPermission", "DEEP_THINK_LOCKED")}")
            val forced = metaStrategy.optJSONArray("forcedEvidenceKeys") ?: JSONArray()
            if (forced.length() > 0) line("Forced evidence: ${(0 until forced.length().coerceAtMost(8)).joinToString(", ") { forced.optString(it) }}")
            val blocked = metaStrategy.optJSONArray("blockedMoves") ?: JSONArray()
            if (blocked.length() > 0) line("Blocked moves: ${(0 until blocked.length().coerceAtMost(6)).joinToString(", ") { blocked.optString(it) }}")
            line("Claim limit: ${metaStrategy.optString("claimLimit", "meta_strategy_governor_guides_routing_not_proof")}")
        }
        val qualityGate = report.optJSONObject("scientificDiscoveryQualityGateReport") ?: JSONObject()
        if (qualityGate.optBoolean("active", false)) {
            line("Discovery quality gate v1.9.2", title)
            line("State: ${qualityGate.optString("gateState", "NOT_RUN")} • Quality ${qualityGate.optInt("qualityScore", 0)}/100 • Allow execution: ${qualityGate.optBoolean("allowExecution", false)}")
            line("Decision: ${qualityGate.optString("executionDecision", "Run guarded evidence closure.")}")
            line("Route disposition: ${qualityGate.optString("routeDisposition", "INSPECT_ONLY")}")
            val required = qualityGate.optJSONArray("requiredBeforeRun") ?: JSONArray()
            if (required.length() > 0) line("Required before run: ${(0 until required.length().coerceAtMost(8)).joinToString(", ") { required.optString(it) }}")
            val blocked = qualityGate.optJSONArray("blockedBecause") ?: JSONArray()
            if (blocked.length() > 0) line("Blocked because: ${(0 until blocked.length().coerceAtMost(5)).joinToString(" | ") { blocked.optString(it).take(90) }}")
            val issues = qualityGate.optJSONArray("qualityIssues") ?: JSONArray()
            if (issues.length() > 0) {
                line("Quality issues:")
                for (i in 0 until issues.length().coerceAtMost(3)) {
                    val issue = issues.optJSONObject(i) ?: continue
                    line("• ${issue.optString("label", "quality issue").take(140)} → ${issue.optString("requiredBeforeRun", "evidence closure")}")
                }
            }
            line("Claim limit: ${qualityGate.optString("claimLimit", "discovery_quality_gate_routing_only_not_biological_proof")}")
        }
        val runbook = report.optJSONObject("scientificDiscoveryRunbookReport") ?: JSONObject()
        if (runbook.optBoolean("active", false)) {
            line("Executable quality runbook v1.9.3", title)
            line("State: ${runbook.optString("runbookState", "NOT_RUN")} • Mode: ${runbook.optString("selectedRunMode", "NO_RUNBOOK")} • Budget: ${runbook.optInt("executionBudget", 0)}")
            line("Primary query: ${runbook.optString("primaryQueryClause", "No runbook query.").take(420)}")
            line("Route decision: ${runbook.optString("routeDecision", "No route decision compiled.")}")
            val checklist = runbook.optJSONArray("evidenceChecklist") ?: JSONArray()
            if (checklist.length() > 0) line("Evidence checklist: ${(0 until checklist.length().coerceAtMost(8)).joinToString(", ") { checklist.optString(it) }}")
            val hardStops = runbook.optJSONArray("hardStops") ?: JSONArray()
            if (hardStops.length() > 0) line("Hard stops: ${(0 until hardStops.length().coerceAtMost(6)).joinToString(" | ") { hardStops.optString(it).take(90) }}")
            val replay = runbook.optJSONArray("blockedReplayKeys") ?: JSONArray()
            if (replay.length() > 0) line("Blocked replay keys: ${(0 until replay.length().coerceAtMost(6)).joinToString(", ") { replay.optString(it) }}")
            val steps = runbook.optJSONArray("runbookSteps") ?: JSONArray()
            if (steps.length() > 0) {
                line("Runbook steps:")
                for (i in 0 until steps.length().coerceAtMost(3)) {
                    val step = steps.optJSONObject(i) ?: continue
                    line("• ${step.optString("label", "runbook step")} → ${step.optString("action", "bounded action")}")
                }
            }
            line("Claim limit: ${runbook.optString("claimLimit", "executable_quality_runbook_routing_only_not_biological_proof")}")
        }
        val deepDiscovery = report.optJSONObject("deepDiscoveryReasoningReport") ?: JSONObject()
        if (deepDiscovery.optBoolean("active", false)) {
            line("Deep discovery reasoner v1.8", title)
            line("State: ${deepDiscovery.optString("state", "NOT_RUN")} • Intelligence ${deepDiscovery.optInt("intelligenceScore", 0)}/100")
            line("Summary: ${deepDiscovery.optString("summary", "No deep discovery summary.")}")
            val mechanisms = deepDiscovery.optJSONArray("mechanismHypotheses") ?: JSONArray()
            if (mechanisms.length() > 0) {
                line("Mechanism hypotheses:")
                for (i in 0 until mechanisms.length().coerceAtMost(3)) {
                    val mech = mechanisms.optJSONObject(i) ?: continue
                    line("• ${mech.optString("label", "mechanism")} — c=${mech.optInt("confidence", 0)}/100")
                    val chain = mech.optJSONArray("mechanismChain") ?: JSONArray()
                    if (chain.length() > 0) line("  Chain: ${(0 until chain.length().coerceAtMost(5)).joinToString(" → ") { chain.optString(it) }}")
                    line("  Risk: ${mech.optString("wrongGeneralizationRisk", "claim-safe boundary required")}")
                }
            }
            val tournament = deepDiscovery.optJSONArray("mechanismTournament") ?: JSONArray()
            if (tournament.length() > 0) {
                val top = tournament.optJSONObject(0) ?: JSONObject()
                line("Top competing explanation: ${top.optString("verdict", "INSPECT")} ${top.optInt("score", 0)}/100 — ${top.optString("explanation", "none")}")
                line("Discriminator: ${top.optString("discriminator", "Run decisive test.")}")
            }
            val decisive = deepDiscovery.optJSONObject("decisiveExperiment") ?: JSONObject()
            line("Decisive test: ${decisive.optString("decisiveQuestion", "Find dataset to separate mechanisms.")}")
            line("Next query: ${decisive.optString("nextQuery", "none")}")
            val novelty = deepDiscovery.optJSONObject("noveltyReport") ?: JSONObject()
            if (novelty.optBoolean("active", false)) line("Novelty: ${novelty.optString("classLabel", "NOT_EVALUATED")} ${novelty.optInt("score", 0)}/100")
            val contradiction = deepDiscovery.optJSONObject("contradictionPlan") ?: JSONObject()
            line("Strongest objection: ${contradiction.optString("strongestObjection", "none")}")
            val think = deepDiscovery.optJSONObject("deepThinkSession") ?: JSONObject()
            if (think.optBoolean("active", false)) {
                line("Deep Think session: ${think.optString("trigger", "TRIGGERED")} • ${think.optString("sessionVerdict", "THINK_THEN_ROUTE")}")
                line("Falsification path: ${think.optString("falsificationPath", "none")}")
            }
            line("Claim limit: ${deepDiscovery.optString("claimLimit", "deep_discovery_reasoning_not_biological_proof")}")
        }
        y += 8f

        line("Cumulative knowledge map", title)
        val knowledgeMap = report.optJSONObject("knowledgeMapReport") ?: JSONObject()
        line("State: ${knowledgeMap.optString("state", "NOT_BUILT")} • Structure ${knowledgeMap.optInt("mapStructureScore", knowledgeMap.optInt("mapScore", 0))}/100 • Evidence ${knowledgeMap.optInt("evidenceReadinessScore", 0)}/100 • Causal ${knowledgeMap.optInt("causalReadinessScore", 0)}/100")
        line("Upgrade: ${knowledgeMap.optString("upgradeStatus", "NOT_EVALUATED")} • Main blocker: ${knowledgeMap.optString("mainBlocker", "none")}")
        line("Brief: ${knowledgeMap.optString("visibleBrief", "No cumulative map yet.")}")
        line("Carried: ${knowledgeMap.optInt("carriedForwardNodes", 0)} node(s) • New nodes: ${knowledgeMap.optInt("newNodesThisCycle", 0)} • New links: ${knowledgeMap.optInt("newLinksThisCycle", 0)}")
        line("Next map action: ${knowledgeMap.optString("nextMapAction", "Run next search with accumulated context.")}")
        val mapGaps = knowledgeMap.optJSONArray("gaps") ?: JSONArray()
        if (mapGaps.length() == 0) line("Map gaps: none") else for (i in 0 until mapGaps.length().coerceAtMost(4)) {
            val gap = mapGaps.optJSONObject(i) ?: continue
            line("• ${gap.optString("gapId")} — severity ${gap.optInt("severity")}/100; blocks=${gap.optBoolean("blocksUpgrade")}")
            line("  Next: ${gap.optString("nextAction")}")
        }
        val mapEdges = knowledgeMap.optJSONArray("edges") ?: JSONArray()
        if (mapEdges.length() > 0) {
            line("Top map links:")
            for (i in 0 until mapEdges.length().coerceAtMost(5)) {
                val edge = mapEdges.optJSONObject(i) ?: continue
                line("• ${edge.optString("relation")} ${edge.optInt("weight")}/100: ${edge.optString("fromNode")} → ${edge.optString("toNode")}")
            }
        }
        line("Claim limit: ${knowledgeMap.optString("claimLimit", "knowledge_map_not_biological_proof")}")
        y += 8f

                line("Research lock summary", title)
        val summary = report.optJSONObject("researchStateSummary") ?: JSONObject()
        line("Discovery State: ${summary.optString("discoveryState", "Off")} • Bias Risk: ${summary.optString("biasRiskState", "Normal")}")
        line("Next Evidence: ${summary.optString("nextEvidence", "none")}")
        line("Discovery Action: ${summary.optString("discoveryAction", "none")}")
        line("Bias Alarm: ${summary.optString("biasAlarm", "Normal")}")
        y += 8f

        line("Global immune dataset intelligence", title)
        val global = report.optJSONObject("globalImmuneIntelligence") ?: JSONObject()
        line("Mode: ${global.optString("mode", "global_dataset_intelligence")}")
        line("Next dataset needed: ${global.optString("nextGlobalDatasetNeeded", "none")}")
        line("Global action: ${global.optString("globalDiscoveryAction", "none")}")
        line("Global bias alarm: ${global.optString("globalBiasAlarm", "Normal")}")
        val datasets = global.optJSONArray("datasetCandidates") ?: JSONArray()
        line("Dataset candidates:")
        if (datasets.length() == 0) line("• No dataset candidate yet.") else for (i in 0 until datasets.length().coerceAtMost(6)) {
            val d = datasets.optJSONObject(i) ?: continue
            line("• ${d.optString("datasetId")} — ${d.optString("condition")} / ${d.optString("dataType")} / quality ${d.optInt("qualityScore")}/100")
        }
        val globalHypotheses = global.optJSONArray("globalHypotheses") ?: JSONArray()
        line("Global hypothesis ledger:")
        if (globalHypotheses.length() == 0) line("• No global hypothesis lead yet.") else for (i in 0 until globalHypotheses.length().coerceAtMost(5)) {
            val h = globalHypotheses.optJSONObject(i) ?: continue
            line("• ${h.optString("status")} — ${h.optString("hypothesisId")} | Trust ${h.optInt("dataTrustScore")}/100 | Evidence ${ScoreFormat.oneDecimal(h.optDouble("evidenceScore10"))}/10")
            line("  Q: ${h.optString("question")}")
            line("  Need: ${h.optString("nextDatasetNeeded")}")
        }
        y += 8f

        line("Hypothesis objects — gates, states, falsification", title)
        val objects = report.optJSONArray("hypothesisObjects") ?: JSONArray()
        if (objects.length() == 0) {
            line("No locked hypothesis objects yet.")
        } else {
            for (i in 0 until objects.length()) {
                val h = objects.optJSONObject(i) ?: continue
                line("${i + 1}. ${h.optString("status")} / ${h.optString("discoveryState")} — ${h.optString("label")}")
                line("   Trust ${h.optInt("dataTrustScore")}/100 • Evidence ${ScoreFormat.oneDecimal(h.optDouble("evidenceScore10"))}/10 • Causality ${h.optInt("causalityScore")}/100 • Bias ${h.optString("biasRiskState")}")
                line("   Gate: ${h.optString("minimumDataPackStatus")} • Flip: ${h.optString("signalFlip")}")
                line("   Impact: ${h.optString("decisionImpact")}")
                line("   Next: ${h.optString("nextBestMeasurement")}")
            }
        }
        y += 8f

        line("Learning deltas + mistake risks", title)
        val deltas = report.optJSONArray("learningDeltaCards") ?: JSONArray()
        if (deltas.length() == 0) line("No delta cards yet.") else for (i in 0 until deltas.length()) {
            val d = deltas.optJSONObject(i) ?: continue
            line("• ${d.optString("deltaType")} — ${d.optString("hypothesisId")}: ${d.optString("decisionImpact")}")
        }
        val mistakes = report.optJSONArray("mistakeRiskCards") ?: JSONArray()
        if (mistakes.length() == 0) line("No mistake risks yet.") else for (i in 0 until mistakes.length()) {
            val m = mistakes.optJSONObject(i) ?: continue
            line("• Risk: ${m.optString("risk")}")
            line("  Gate: ${m.optString("preventionGate")}")
        }
        y += 8f

        line("Hypothesis ranking — Evidence & causal learning", title)
        val cards = report.optJSONArray("hypothesisRankCards") ?: JSONArray()
        if (cards.length() == 0) {
            line("No ranked hypotheses yet.")
        } else {
            for (i in 0 until cards.length()) {
                val c = cards.optJSONObject(i) ?: continue
                line("${i + 1}. ${c.optString("status")} — ${c.optString("label")}")
                line("   Overall ${c.optInt("overallScore")}/100 • Evidence ${c.optInt("evidenceQualityScore")}/100 • Causality ${c.optInt("causalityScore")}/100 • Repeatability ${c.optInt("personalRepeatability")}")
                line("   Negative control: ${c.optString("negativeControlStatus")}")
                line("   Next measurement: ${c.optString("nextBestMeasurement")}")
            }
        }
        y += 8f

        line("Emergent links", title)
        writeArray(report.optJSONArray("emergentLinks")) { line("• $it") }
        y += 8f

        line("Imported report signals", title)
        val imported = report.optJSONArray("importedReportSignals") ?: JSONArray()
        if (imported.length() == 0) {
            line("No imported report signals used.")
        } else {
            for (i in 0 until imported.length()) {
                val r = imported.optJSONObject(i) ?: continue
                line("• ${r.optString("title")} — axes: ${arrayToString(r.optJSONArray("matchedAxes"))}")
            }
        }
        y += 8f

        line("Dataset acquisition + parser candidates v1.4.3", title)
        val ds137 = report.optJSONArray("datasetCandidatesV137") ?: JSONArray()
        if (ds137.length() == 0) line("No dataset accession candidate yet.") else for (i in 0 until ds137.length().coerceAtMost(8)) {
            val d = ds137.optJSONObject(i) ?: continue
            line("• ${d.optString("accession")} — ${d.optString("source")} • usability ${d.optInt("usabilityScore")}/100 • ${d.optString("status")}")
            line("  ${d.optString("organismHint")} | ${d.optString("conditionLabelsHint")} | ${d.optString("outcomeLabelsHint")}")
        }
        y += 8f

        line("Route-fit gate details", title)
        val routeGateDetails = (report.optJSONObject("datasetForagingReport") ?: JSONObject()).optJSONArray("routeFitAssessments") ?: JSONArray()
        if (routeGateDetails.length() == 0) line("No route-fit assessment yet.") else for (i in 0 until routeGateDetails.length().coerceAtMost(8)) {
            val r = routeGateDetails.optJSONObject(i) ?: continue
            line("• ${r.optString("accession")} — ${r.optString("status")} • fit ${r.optInt("routeFitScore")}/100 • blocks upgrade ${r.optBoolean("blocksHypothesisUpgrade")}")
            line("  ${r.optString("datasetRoute")} → ${r.optString("targetRoute")}")
        }
        y += 8f

        line("Evidence objects", title)
        val evObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        if (evObjects.length() == 0) line("No evidence object yet.") else for (i in 0 until evObjects.length().coerceAtMost(8)) {
            val e = evObjects.optJSONObject(i) ?: continue
            line("• ${e.optString("decisionImpact")} • quality ${e.optInt("qualityScore")}/100 — ${e.optString("title")}")
            line("  Accessions: ${arrayToString(e.optJSONArray("accessionIds"))} | contradiction ${e.optBoolean("contradictsHypothesis")} | control ${e.optBoolean("hasNegativeControl")}")
        }
        y += 8f

        line("Top findings", title)
        val findings = report.optJSONArray("findings") ?: JSONArray()
        for (i in 0 until findings.length()) {
            val f = findings.optJSONObject(i) ?: continue
            line("${i + 1}. ${f.optString("title")}")
            line("   Source: ${f.optString("source")} ${f.optString("sourceId")} • ${f.optString("published")} • novelty ${f.optInt("noveltyScore")}/100")
            val ev = f.optJSONObject("evidence") ?: JSONObject()
            val ca = f.optJSONObject("causality") ?: JSONObject()
            val neg = f.optJSONObject("negativeControl") ?: JSONObject()
            val pp = f.optJSONObject("personalPattern") ?: JSONObject()
            line("   Evidence: ${ev.optInt("evidenceQualityScore")}/100 • ${ev.optString("speciesClass", "unknown")} • ${ev.optString("studyDesign", "unknown")}")
            line("   Causality: ${ca.optInt("causalityScore")}/100 • Negative control: ${neg.optString("status", "unknown")} • Local repeats: ${pp.optInt("repeatedObservationCount", 0)}")
            line("   Bridge: ${f.optString("bridgeSignal")}")
            line("   Why it matters: ${f.optString("whyItMatters")}")
            line("   URL: ${f.optString("url")}")
            y += 5f
        }

        line("Next research questions", title)
        writeArray(report.optJSONArray("nextQuestions")) { line("• $it") }
        y += 8f

        line("Limitations", title)
        writeArray(report.optJSONArray("limitations")) { line("• $it") }

        pdf.finishPage(page)
        file.outputStream().use { pdf.writeTo(it) }
        pdf.close()
        return file
    }

    private fun writeArray(array: JSONArray?, writer: (String) -> Unit) {
        if (array == null || array.length() == 0) {
            writer("No items.")
            return
        }
        for (i in 0 until array.length()) writer(array.optString(i))
    }

    private fun axisIds(arr: JSONArray?): String {
        if (arr == null || arr.length() == 0) return "none"
        val out = mutableListOf<String>()
        for (i in 0 until arr.length().coerceAtMost(5)) {
            val obj = arr.optJSONObject(i) ?: continue
            out += obj.optString("id", obj.optString("label", "axis"))
        }
        return out.joinToString(", ").ifBlank { "none" }
    }

    private fun arrayToString(array: JSONArray?): String {
        if (array == null || array.length() == 0) return "none"
        return (0 until array.length()).joinToString(", ") { array.optString(it) }
    }


    internal fun noCandidateLearningDetailLine(record: JSONObject): String {
        val source = record.optString("sourceFamily")
        val next = record.optString("nextPreferredSource")
        val missing = record.optString("missing")
        val status = record.optString("status")
        return if (next == "LEAD_OBJECT_SECONDARY_LOOKUP") {
            "• $source → follow-up LEAD_OBJECT_SECONDARY_LOOKUP | missing $missing | $status"
        } else {
            "• $source → next source $next | missing $missing | $status"
        }
    }


    internal fun noCandidateHeaderLine(record: JSONObject): String {
        val next = record.optString("nextPreferredSource")
        val reason = record.optString("reason")
        return if (next == "LEAD_OBJECT_SECONDARY_LOOKUP") {
            "Next lead follow-up: LEAD_OBJECT_SECONDARY_LOOKUP • reason $reason"
        } else {
            "Next source family: $next • reason $reason"
        }
    }

    private fun wrap(text: String, max: Int): List<String> {
        val words = text.replace('\n', ' ').split(" ")
        val out = mutableListOf<String>()
        var current = ""
        words.forEach { word ->
            if ((current.length + word.length + 1) > max) {
                if (current.isNotBlank()) out += current
                current = word
            } else {
                current = if (current.isBlank()) word else "$current $word"
            }
        }
        if (current.isNotBlank()) out += current
        return out.ifEmpty { listOf("") }
    }
}
