package com.immunesignal.app

/**
 * Claim-safe global product guard for unified GTIM v2.6.2.
 *
 * This is intentionally static and local-only: it does not add permissions, telemetry, SDKs,
 * background services, or patient-facing clinical decisions. It gives the UI/export layer a stable
 * language surface for Google Play review and scientific review.
 */
object GTIMClaimGuardV250 {
    const val ENGINE_IDENTITY: String = "GTIM-Engine v2.6.2 — Global Translational Immunology & Discovery Dossier Engine"
    const val CLAIM_BOUNDARY: String = "biomedical_research_data_engineering_only_not_diagnosis_not_treatment_not_patient_prediction"
    const val MISSION_STATEMENT: String = "Turn fragmented immunology evidence into corpus-relative, falsifiable mechanism dossiers for the next laboratory experiment."
    const val CORPUS_RELATIVE_NOVELTY_BOUNDARY: String = "Novelty is corpus-relative: the inspected evidence did not directly test the same mechanism path; this is not a universal historical novelty claim."

    val GLOBAL_USE_CASES: List<String> = listOf(
        "viral immunology and post-infectious immune dysregulation",
        "drug and immunomodulator response mapping",
        "antibiotic, microbiome, and host immune-response intersections",
        "allergy and hypersensitivity pathomechanism mapping",
        "exposure, longevity, metabolic, mitochondrial, and immune-aging research routes"
    )

    val DATA_SCARCITY_MITIGATION: List<String> = listOf(
        "Human accession/matrix evidence remains primary.",
        "Cross-species ortholog transfer is auxiliary plausibility evidence only.",
        "Reference control priors orient comparison; they do not confirm biological effects.",
        "NLP-mined cytokine/biomarker/cell-type mentions are weak leads until repository or experiment support appears.",
        "Knowledge-graph 2-hop/3-hop paths generate mechanism candidates, not findings."
    )

    val CLAIM_GUARDRAILS: List<String> = listOf(
        "No diagnosis, treatment advice, dose advice, supplement advice, or patient-specific recommendation.",
        "No DGE, fold-change, p-value, cytokine effect, or up/down-regulation claim without a real matrix analysis.",
        "Manual snippets and text-mined leads cannot become confirmed accessions.",
        "Cross-species and reference-control evidence cannot confirm a human mechanism.",
        "Every novel route must expose contradiction search, missing evidence, and falsification conditions."
    )

    val PEER_REVIEW_DOSSIER_SECTIONS: List<String> = listOf(
        "Executive Research Thesis",
        "Corpus-Relative Novelty Statement",
        "Evidence Object Map",
        "Connected Dots Map",
        "Mechanism Candidate Cascade",
        "Scientific Confidence Index S_c",
        "Contradiction and Null-Result Search",
        "Comparator and Matrix Readiness",
        "Falsifiability and Lab Validation Framework",
        "Claim Boundary and Next Evidence Needed"
    )

    fun sanitizeScientificClaim(text: String): String {
        val risky = listOf(
            "proves" to "proposes",
            "proven" to "supported as a candidate",
            "discovered" to "identified as a corpus-relative candidate",
            "diagnoses" to "does not diagnose; only organizes research evidence for",
            "treats" to "does not treat; only frames research questions around"
        )
        return risky.fold(text) { acc, (from, to) -> acc.replace(from, to, ignoreCase = true) }
    }
}
