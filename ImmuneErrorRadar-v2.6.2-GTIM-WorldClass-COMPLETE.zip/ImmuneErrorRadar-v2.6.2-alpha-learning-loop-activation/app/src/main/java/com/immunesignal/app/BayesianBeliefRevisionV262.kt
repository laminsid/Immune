package com.immunesignal.app

import kotlin.math.roundToInt

data class BayesianBeliefRevisionCardV262(
    val beliefId: String,
    val priorProbability: Double,
    val likelihoodRatio: Double,
    val posteriorProbability: Double,
    val posteriorConfidence: Int,
    val interpretation: String,
    val claimLimit: String = BayesianBeliefRevisionV262.CLAIM_LIMIT
)

/** v2.6.2: quantitative belief update preview; advisory only, not proof. */
object BayesianBeliefRevisionV262 {
    const val CLAIM_LIMIT = "bayesian_belief_revision_research_prior_only_not_biological_proof"

    fun revise(beliefs: List<EpistemicBelief>, evidenceObjects: List<EvidenceObject>): List<BayesianBeliefRevisionCardV262> {
        if (!RuntimeFeatureFlags.ENABLE_BAYESIAN_BELIEF_REVISION_V262) return emptyList()
        return beliefs.take(12).map { belief ->
            val prior = (belief.confidence.coerceIn(1, 99) / 100.0).coerceIn(0.01, 0.99)
            val support = belief.supportCount + evidenceObjects.count { it.linkedHypothesisId in belief.linkedNodes.joinToString(" ") }
            val contradiction = belief.contradictionCount + evidenceObjects.count { it.contradictsHypothesis && it.linkedHypothesisId in belief.linkedNodes.joinToString(" ") }
            val lr = ((support + 1.0) / (contradiction + 1.0)).coerceIn(0.20, 5.0)
            val posterior = ((prior * lr) / ((prior * lr) + (1.0 - prior))).coerceIn(0.0, 1.0)
            BayesianBeliefRevisionCardV262(
                beliefId = belief.beliefId,
                priorProbability = prior,
                likelihoodRatio = lr,
                posteriorProbability = posterior,
                posteriorConfidence = (posterior * 100.0).roundToInt().coerceIn(0, 100),
                interpretation = when {
                    contradiction > support -> "WEAKEN_PRIOR_AND_RUN_CONTRADICTION_CHECK"
                    posterior >= 0.70 -> "STRENGTHEN_RESEARCH_PRIOR_BUT_KEEP_EVIDENCE_GATES"
                    else -> "KEEP_MUTABLE_PRIOR_AND_SEEK_DISCRIMINATING_EVIDENCE"
                }
            )
        }
    }
}
