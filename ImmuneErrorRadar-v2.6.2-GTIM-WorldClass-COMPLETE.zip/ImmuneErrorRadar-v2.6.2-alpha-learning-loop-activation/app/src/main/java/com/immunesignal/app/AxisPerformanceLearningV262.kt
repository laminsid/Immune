package com.immunesignal.app

import org.json.JSONObject

data class AxisPerformanceRecordV262(
    val axis: String,
    val queriesAttempted: Int,
    val evidenceObjectsFound: Int,
    val accessionsClosed: Int,
    val successRate: Double,
    val nextQueryBudgetHint: String,
    val claimLimit: String = AxisPerformanceLearningV262.CLAIM_LIMIT
)

/**
 * v2.6.2: learns which axes actually produce evidence/accessions and returns
 * routing hints only. It never upgrades a biological claim.
 */
object AxisPerformanceLearningV262 {
    const val CLAIM_LIMIT = "axis_performance_routing_only_not_biological_proof"

    fun build(findings: List<ResearchFinding>, evidenceObjects: List<EvidenceObject>, recentReports: List<String>): List<AxisPerformanceRecordV262> {
        if (!RuntimeFeatureFlags.ENABLE_AXIS_PERFORMANCE_LEARNING) return emptyList()
        val axes = linkedSetOf<String>()
        findings.flatMapTo(axes) { it.matchedAxes }
        evidenceObjects.mapNotNullTo(axes) { it.linkedHypothesisId.substringAfter("axis:", "").takeIf { v -> v.isNotBlank() } }
        recentReports.take(6).forEach { line ->
            val report = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
            val arr = report.optJSONArray("findings") ?: return@forEach
            for (i in 0 until arr.length()) {
                val f = arr.optJSONObject(i) ?: continue
                val matched = f.optJSONArray("matchedAxes") ?: continue
                for (j in 0 until matched.length()) matched.optString(j).takeIf { it.isNotBlank() }?.let { axes += it }
            }
        }
        return axes.map { axis ->
            val queryAttempts = recentReports.take(6).sumOf { reportLine ->
                val report = runCatching { JSONObject(reportLine) }.getOrNull() ?: return@sumOf 0
                val queries = report.optJSONArray("queries") ?: return@sumOf 0
                var hits = 0
                for (i in 0 until queries.length()) {
                    val q = queries.optJSONObject(i)?.optString("query").orEmpty()
                    if (q.contains(axis.replace("_", " "), ignoreCase = true) || q.contains(axis, ignoreCase = true)) hits++
                }
                hits
            }.coerceAtLeast(findings.count { axis in it.matchedAxes })
            val evidenceHits = findings.count { axis in it.matchedAxes && it.evidence.evidenceQualityScore >= 50 } + evidenceObjects.count { it.linkedHypothesisId.contains(axis, ignoreCase = true) }
            val accessionHits = evidenceObjects.count { it.evidenceId.contains("GSE", true) || it.evidenceId.contains("PRJ", true) || it.evidenceId.contains("SRR", true) }
            val rate = evidenceHits.toDouble() / queryAttempts.coerceAtLeast(1).toDouble()
            AxisPerformanceRecordV262(
                axis = axis,
                queriesAttempted = queryAttempts,
                evidenceObjectsFound = evidenceHits,
                accessionsClosed = accessionHits,
                successRate = rate.coerceIn(0.0, 1.0),
                nextQueryBudgetHint = if (rate >= 0.30) "KEEP_OR_EXPAND_AXIS_BUDGET" else "DEPRIORITIZE_UNLESS_STRUCTURED_SEED_OR_GAP_TASK_EXISTS"
            )
        }.sortedWith(compareByDescending<AxisPerformanceRecordV262> { it.successRate }.thenByDescending { it.evidenceObjectsFound }).take(12)
    }
}
