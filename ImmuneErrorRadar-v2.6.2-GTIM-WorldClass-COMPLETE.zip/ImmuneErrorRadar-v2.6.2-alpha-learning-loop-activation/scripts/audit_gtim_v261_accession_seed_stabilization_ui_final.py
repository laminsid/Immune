#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path('.')
VERSION = '2.6.2-alpha-learning-loop-activation'
ENGINE = 'GTIM-Engine v2.6.2'

def read(path: str) -> str:
    p = ROOT / path
    if not p.exists():
        raise SystemExit(f'MISSING: {path}')
    return p.read_text(encoding='utf-8')

def require(path: str, tokens):
    text = read(path)
    missing = [t for t in tokens if t not in text]
    if missing:
        raise SystemExit(f'{path}: missing {missing}')
    return text

require('app/build.gradle.kts', ['versionCode = 138', f'versionName = "{VERSION}"', 'compileSdk = 35', 'targetSdk = 35'])
require('app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt', [f'RELEASE_TRAIN_VERSION_NAME: String = "{VERSION}"', 'RELEASE_TRAIN_VERSION_CODE: Int = 138', 'LEARNING_SESSION_SCHEMA_VERSION: String = "2.6.2"'])
require('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt', [f'ACTIVE_ENGINE_VERSION = "v{VERSION}"'])
require('app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt', ['VERSION_CODE: Int = 138', f'VERSION_NAME: String = "{VERSION}"', f'ENGINE_VERSION: String = "v{VERSION}"', 'LEARNING_SCHEMA_VERSION: String = "2.6.2"'])
require('app/src/main/java/com/immunesignal/app/GTIMClaimGuardV250.kt', [ENGINE, 'No diagnosis', 'No DGE', 'corpus-relative'])
require('app/src/main/java/com/immunesignal/app/GTIMAccessionSeedCaptureV260.kt', ['ACCESSION_SEED_CAPTURED_MATRIX_PENDING', 'ROUTE_UNRESOLVED_METADATA_PENDING', 'ACCESSION_SEED_NOT_EVIDENCE_OBJECT', 'Never classify a captured accession seed as OFF_ROUTE before repository metadata is parsed'])
require('app/src/main/java/com/immunesignal/app/GTIMDiscoveryDossierV250.kt', ['GRADE_2_REPOSITORY_HANDLE_SEED_NOT_EVIDENCE', 'GTIM_EO_SEED_', 'confidenceIndex('])
require('app/src/main/java/com/immunesignal/app/GlobalResearchGradeBriefV11061.kt', ['Captured accession seed:', 'Technical appendix: hidden from main brief', 'raw JSON, command trace, parser cards'])
require('app/src/test/java/com/immunesignal/app/GTIMAccessionSeedCaptureV260Test.kt', ['GSE152202', 'ACCESSION_SEED_CAPTURED_MATRIX_PENDING', 'ROUTE_UNRESOLVED_METADATA_PENDING'])
require('app/src/test/java/com/immunesignal/app/GTIMDiscoveryDossierV250Test.kt', [ENGINE, 'gtimProductEngineVersion.contains("2.6.2")'])

# prevent the exact Kotlin regression that broke compile in GTIMDiscoveryDossierV250.kt
for kt in (ROOT / 'app/src/main/java').rglob('*.kt'):
    text = kt.read_text(encoding='utf-8')
    if re.search(r'\):\s+[A-Za-z0-9_<>, ?]+\s*\{\s*\n\s*\):\s+[A-Za-z0-9_<>, ?]+\s*\{', text):
        raise SystemExit(f'{kt}: duplicate Kotlin function return signature detected')
    if '"($base) AND "$target""' in text:
        raise SystemExit(f'{kt}: unescaped contradiction query quote regression detected')

# Main brief should not expose internal module status lines as product UI.
brief = read('app/src/main/java/com/immunesignal/app/GlobalResearchGradeBriefV11061.kt')
for noisy in ['GTIM dossier status', 'Final integration closure status', 'Professor dashboard status', 'Visual knowledge graph status']:
    if noisy in brief:
        raise SystemExit(f'Brief exposes noisy internal line: {noisy}')

# Google Play posture: no broad sensitive permission expansion.
manifest = read('app/src/main/AndroidManifest.xml')
for forbidden in ['QUERY_ALL_PACKAGES', 'READ_SMS', 'READ_CONTACTS', 'ACCESS_FINE_LOCATION', 'CAMERA', 'RECORD_AUDIO']:
    if forbidden in manifest:
        raise SystemExit(f'Forbidden/sensitive permission present: {forbidden}')

print('GTIM v2.6.2 accession seed stabilization + UI final audit: PASS')
