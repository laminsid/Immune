#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1

echo "Full static checks v2.6.2: start"
python3 scripts/validate_json.py >/tmp/immune_validate_json_fast.log
cat /tmp/immune_validate_json_fast.log
python3 scripts/audit_kotlin_delimiters.py
python3 scripts/audit_kotlin_regex_escape_safety_v11033.py
python3 scripts/audit_github_workflow_pipefail_safety_v11033.py
python3 scripts/audit_kotlin_string_literals_fast.py
python3 scripts/audit_xml_parse_fast.py
python3 scripts/audit_release_hygiene_v1108.py
python3 scripts/audit_gtim_v262_learning_loop_activation.py
echo "Full static checks v2.6.2: PASS"
python3 scripts/audit_gtim_v262_comprehensive_validation_closure.py
