#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(rel, tokens):
    path = ROOT / rel
    if not path.exists():
        errors.append(f'missing file: {rel}')
        return
    text = path.read_text(errors='ignore')
    for token in tokens:
        if token not in text:
            errors.append(f'missing token in {rel}: {token}')

require('app/src/main/java/com/immunesignal/app/MetadataClosureStrategyMatrixV11056.kt', [
    'v1.10.60-alpha-github-ci-route-audit-unification',
    'MetadataClosureStrategyMatrixV11058',
    'hyperDriveModeActive',
    'hardDataExtractionMode',
    'criticalUsabilityAnomaly',
    'forcedRouteFitTarget',
    'multiDimensionalAccessionSearchStreams',
    'programmaticCommandLog',
    'runtimeDataDemand',
    'controlComparatorLinkageQueries',
    'HYPER_ALPHA_GEO_GDS_NEURO_VIRAL_DATA_AVAILABILITY',
    'HYPER_ALPHA_SRA_BIOPROJECT_NEURO_VIRAL_DATA_AVAILABILITY',
    'HYPER_BETA_GEO_GDS_EXPOSOME_MODULATOR_ACCESSION',
    'HYPER_BETA_SRA_BIOPROJECT_EXPOSOME_MODULATOR_ACCESSION',
    '(EBV OR HHV-6) AND (SLE OR "Systemic Lupus" OR "Multiple Sclerosis")',
    '("HPA-axis" OR "Cortisol/DHEA ratio" OR "Sleep deprivation")',
    'NEXT_JSON_DEMAND::accessions>0_or_log_HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION',
    'G8_HARD_TARGETING_ACCESSION_GENERATION',
    'G9_HARD_DATA_EXTRACTION_DEMAND_NO_FABRICATION',
])
require('app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt', [
    'hyperDriveModeActive',
    'hardDataExtractionMode',
    'criticalUsabilityAnomaly',
    'forcedRouteFitTarget',
    'multiDimensionalAccessionSearchStreams',
    'programmaticCommandLog',
    'runtimeDataDemand',
    'controlComparatorLinkageQueries',
])
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', [
    'MetadataClosureStrategyMatrixV11058.evaluate',
])
require('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt', [
    'Metadata Closure Strategy Matrix v1.10.60',
    'Hyper-Drive first stream',
    'Programmatic commands',
    'Runtime data demand',
    'Control/comparator linkage queries',
])
require('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt', [
    'MetadataClosureStrategyMatrixV11058',
    'HyperDriveHardDataExtractionV11058',
    'MultiDimensionalAccessionSearchStreamV11058',
    'HardTargetingAccessionGenerationV11058',
])
require('docs/METADATA_CLOSURE_HYPER_DRIVE_v1.10.58.md', [
    'Metadata Closure Hyper-Drive v1.10.58',
    'Stream Alpha',
    'Stream Beta',
    'GSE[0-9]*',
    'PRJNA[0-9]*',
    'No fabricated accession IDs',
])
require('docs/CHANGELOG_v1.10.58.md', [
    '1.10.58-alpha-hyper-drive-hard-data-extraction',
    'versionCode=120',
    'schema updated to `1.10.58`',
])
if errors:
    print('v1.10.58 hyper-drive hard data extraction audit failed')
    print('\n'.join(errors))
    raise SystemExit(1)
print('v1.10.58 hyper-drive hard data extraction audit: PASS')
