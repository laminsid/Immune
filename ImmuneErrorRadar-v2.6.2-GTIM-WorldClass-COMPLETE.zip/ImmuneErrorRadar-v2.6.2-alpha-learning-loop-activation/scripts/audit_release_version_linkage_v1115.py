from pathlib import Path
version='2.5.6-alpha-gtim-intent-discovery-evidence-split'
engine=f'v{version}'
checks={
    'app/build.gradle.kts': ['versionCode = 132', f'versionName = "{version}"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [f'RELEASE_TRAIN_VERSION_NAME: String = "{version}"', 'RELEASE_TRAIN_VERSION_CODE: Int = 132', 'LEARNING_SESSION_SCHEMA_VERSION: String = "2.5.6"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [f'ACTIVE_ENGINE_VERSION = "{engine}"'],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 132', f'VERSION_NAME: String = "{version}"', f'ENGINE_VERSION: String = "{engine}"', 'LEARNING_SCHEMA_VERSION: String = "2.5.6"'],
    'app/src/main/java/com/immunesignal/app/ResearchGradeMechanismDossierV1110.kt': [f'VERSION_LABEL: String = "{engine}"'],
    'docs/CHANGELOG_v1.11.5.md': [version, 'versionCode=132', 'schema `2.5.6`'],
}
missing=[]
for file,tokens in checks.items():
    p=Path(file)
    if not p.exists():
        missing.append(f'{file}: missing file')
        continue
    text=p.read_text(encoding='utf-8', errors='replace')
    for token in tokens:
        if token not in text:
            missing.append(f'{file}: missing {token}')
if missing:
    raise SystemExit('v2.5.6 release linkage audit failed:\n' + '\n'.join(missing))
print('v2.5.6 release linkage audit: PASS')
