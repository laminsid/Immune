package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.15.3 — Final C2/C3 preview-relaxed sandbox closure.
 *
 * This is the single first-surface owner for the final hypothesis-first release. It
 * deliberately does not call GlobalResearchGradeBriefV11061.renderLines(), legacy dossier
 * builders, or domain-specific runtime closures. Old rails stay available in JSON/export
 * appendix, while the visible result is built from the active-domain hypothesis contract,
 * target-state coherence guard, split gates, and final release lock only.
 */
object GTIMFinalActiveDecisionSurfaceV21317 {
    const val PATCH_VERSION: String = "2.13.15.3-final-c2c3-preview-relaxed-sandbox"
    const val STATE_READY: String = "FINAL_ACTIVE_DECISION_SURFACE_READY"
    const val CLAIM_LIMIT: String = "active_decision_surface_c2c3_preview_relaxed_no_legacy_first_surface_no_validated_proof"

    fun shouldOwnSurface(report: JSONObject): Boolean =
        RuntimeFeatureFlags.ENABLE_FINAL_ACTIVE_DECISION_SURFACE_V21317 && (
            GTIMLegacyLeakFirewallV21316.shouldUseHypothesisFirstSurface(report) ||
                report.has("hypothesisFirstDiscoveryEngineV21315") ||
                report.has("finalSurfaceDomainCoherenceGuardV21313") ||
                report.has("generalizedRouteCoherenceGuardV21314") ||
                report.has("finalActiveDecisionSurfaceV21317")
        )

    fun toJson(report: JSONObject): JSONObject {
        val hypothesis = report.optJSONObject("hypothesisFirstDiscoveryEngineV21315")
            ?: GTIMHypothesisFirstDiscoveryEngineV21315.toJson(report)
        val guard = report.optJSONObject("finalSurfaceDomainCoherenceGuardV21313")
            ?: GTIMFinalSurfaceDomainCoherenceGuardV21313.toJson(report)
        val scope = report.optJSONObject("domainScopedClosureRendererV21315")
            ?: GTIMDomainScopedClosureRendererV21315.toJson(report)
        val firewall = report.optJSONObject("legacyLeakFirewallV21316")
            ?: GTIMLegacyLeakFirewallV21316.toJson(report)
        val release = report.optJSONObject("finalReleaseLockV21219")
            ?: GTIMFinalReleaseLockV21219.toJson(report)
        val capsuleLayer = report.optJSONObject("localProcessedCapsuleLayerV21316")
            ?: hypothesis.optJSONObject("localProcessedCapsuleLayerV21316")
            ?: GTIMCapsuleSurfaceCardV21316.toJson(report)

        val active = hypothesis.optString("activeDomain").ifBlank { guard.optString("activeDomain", "unknown") }
        val subtype = hypothesis.optString("activeSubtype").ifBlank { scope.optString("activeSubtype", "unknown") }
        val canonical = hypothesis.optString("canonicalTarget").ifBlank { guard.optString("canonicalTarget", "") }
        val primary = hypothesis.optString("primaryResult", "C0_ROUTE_HYPOTHESIS")
        val executionTasks = hypothesis.optJSONArray("executionTasks") ?: hypothesis.optJSONArray("evidenceUpgradeBlockers") ?: JSONArray()
        val hypothesisBlockers = hypothesis.optJSONArray("hypothesisBlockers") ?: JSONArray()
        val clinicalBlockers = hypothesis.optJSONArray("clinicalClaimBlockers") ?: JSONArray()

        return JSONObject()
            .put("version", PATCH_VERSION)
            .put("state", STATE_READY)
            .put("firstSurfaceOwner", "GTIMFinalActiveDecisionSurfaceV21317")
            .put("activeDomain", active)
            .put("activeSubtype", subtype)
            .put("canonicalTarget", canonical)
            .put("primaryResult", primary)
            .put("studyFocus", hypothesis.optString("studyFocus").ifBlank { GTIMGeneralizedRouteCoherenceGuardV21314.studyFocusFor(active) })
            .put("primaryHypothesis", hypothesis.optString("primaryHypothesis"))
            .put("mechanismAxis", hypothesis.optString("mechanismAxis"))
            .put("whyPlausible", hypothesis.optString("whyPlausible"))
            .put("bestSearchOrExecutionTarget", hypothesis.optString("bestExecutionTarget", hypothesis.optString("bestSearchQuery")))
            .put("localProcessedCapsuleLayerV21316", capsuleLayer)
            .put("matrixState", hypothesis.optString("matrixState", capsuleLayer.optString("matrix_state", "CAPSULE_MISSING_ACQUISITION_TASK_CREATED")))
            .put("capsulePreviewStrength", hypothesis.optString("capsulePreviewStrength", capsuleLayer.optString("preview_strength", "C0_ROUTE_SANDBOX_PREVIEW_CAPSULE_MISSING")))
            .put("requiredDatasetProfile", hypothesis.optString("requiredDatasetProfile"))
            .put("falsifier", hypothesis.optString("falsifier"))
            .put("hypothesisBlockers", hypothesisBlockers)
            .put("executionTasks", executionTasks)
            .put("clinicalClaimBlockers", clinicalBlockers)
            .put("hypothesisOutputAllowed", hypothesis.optBoolean("hypothesisAllowed", hypothesisBlockers.length() == 0))
            .put("c2PreviewAllowed", true)
            .put("c3PreviewAllowed", true)
            .put("validatedProofAllowed", false)
            .put("clinicalClaimAllowed", false)
            .put("legacyFirstSurfaceBlocked", firewall.optBoolean("oldRenderTreeBlocked", true))
            .put("domainScopedRendering", scope.optString("closurePolicy", "global_core_everywhere_domain_specific_only_when_matching_active_domain"))
            .put("releaseLockState", release.optString("state", "FINAL_RELEASE_LOCK_READY_HYPOTHESIS_FIRST_EVIDENCE_GATES_SEPARATED"))
            .put("surfaceBudget", "compact_first_surface_no_legacy_tree")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun renderLines(report: JSONObject): List<String> {
        val obj = toJson(report)
        val active = obj.optString("activeDomain", "unknown")
        val canonical = obj.optString("canonicalTarget", "")
        val clinical = obj.optJSONArray("clinicalClaimBlockers")?.length() ?: 0
        val executionTasks = obj.optJSONArray("executionTasks")?.length() ?: 0
        val hypothesis = obj.optJSONArray("hypothesisBlockers")?.length() ?: 0
        val assumption = GTIMAssumptionBreakerEngineV21318.toJson(report)
        val cross = GTIMCrossDiseaseMechanismMapperV21318.toJson(report)
        val modality = GTIMTherapeuticModalityLensV21318.toJson(report)
        val binding = GTIMProteinInteractionBindingHypothesisV21318.toJson(report)
        val lines = listOf(
            "Immu DZ Global Research Dossier",
            "Final active decision surface",
            "Final surface domain-coherence guard: active_domain=$active; canonical_target=${canonical.ifBlank { "none" }}; legacy rails are appendix-only.",
            "State: ${obj.optString("state", STATE_READY)}; owner=${obj.optString("firstSurfaceOwner")}; active_domain=$active; subtype=${obj.optString("activeSubtype", "unknown")}; canonical_target=${canonical.ifBlank { "none" }}.",
            "Study Result Card: hypothesis-first active summary; legacy study-card tree is not rebuilt.",
            "Final requirements coverage closure: compact output contract active; legacy_surface_owner_allowed=false.",
            "Primary hypothesis: ${obj.optString("primaryHypothesis", "route-specific hypothesis not generated")}",
            "Immune decision state: active_domain=$active; hypothesis-first immune decision state visible.",
            "Capsule state: ${obj.optString("matrixState", "CAPSULE_MISSING_ACQUISITION_TASK_CREATED")}; ${obj.optString("capsulePreviewStrength", "C0_ROUTE_SANDBOX_PREVIEW")}",
            "Concept/paradigm candidate: Paradigm candidate card is active on the first surface.",
            "Best execution route: ${obj.optString("bestSearchOrExecutionTarget", "topic-compatible dataset/capsule search")}",
            "Falsifier: ${obj.optString("falsifier", "downgrade if comparator/module/replication/contradiction checks fail")}",
            "Claim boundary: research-only; validated proof, treatment, dosing, patient action, and clinical implementation are blocked.",
            "Paradigm candidate card",
            "Old assumption challenged: ${assumption.optString("old_assumption_challenged")}",
            "Cross-disease mechanism: ${cross.optString("shared_mechanism_axis")}; connected=${cross.optJSONArray("connected_disease_domains") ?: JSONArray()}",
            "Therapeutic/modality lens: ${modality.optJSONArray("modalities") ?: JSONArray()}; validated_treatment_claim=BLOCKED.",
            "Protein interaction/binding lens: target_antigen=${binding.optString("target_antigen")}; epitope=${binding.optString("epitope")}; validated_binding_or_efficacy_claim=BLOCKED.",
            "Exosome / immunometabolism role card: systemic nano-cargo and adipose immune-metabolic lenses are active; diagnosis/treatment/diet protocol=BLOCKED.",
            "Structural immunity / non-immune cell immune-code card: epithelial/endothelial/fibroblast/stromal tissue-state lenses are active; tissue-therapy/fibrosis-reversal/clinical implementation claims=BLOCKED.",
            "Primary result: ${obj.optString("primaryResult", "C0_ROUTE_HYPOTHESIS")}",
            "Study focus: ${obj.optString("studyFocus", GTIMGeneralizedRouteCoherenceGuardV21314.studyFocusFor(active))}",
            "Mechanism axis: ${obj.optString("mechanismAxis", "route-specific mechanism axis not generated")}",
            "Why plausible: ${obj.optString("whyPlausible", "active-domain priors support a bounded research hypothesis")}",
            *GTIMCapsuleSurfaceCardV21316.renderLines(report).toTypedArray(),
            *GTIMMicrobiomeRoleSurfaceCardV21319.renderLines(report).toTypedArray(),
            *GTIMCellDeathSurfaceCardV21319.renderLines(report).toTypedArray(),
            *GTIMExosomeImmunometabolismSurfaceCardV21321.renderLines(report).toTypedArray(),
            *GTIMStructuralImmunitySurfaceCardV21324.renderLines(report).toTypedArray(),
            *GTIMParadigmSurfaceCardV21317.renderLines(report).toTypedArray(),
            *GTIMFinalIntegratedDiscoveryClosureV213171.renderLines(report).toTypedArray(),
            *GTIMFinalRequirementsCoverageClosureV213181.renderLines(report).toTypedArray(),
            *GTIMFinalMicrobiomeCellDeathDamageClosureV213192.renderLines(report).toTypedArray(),
            *GTIMThymicCyberneticSurfaceCardV21320.renderLines(report).toTypedArray(),
            *GTIMFinalThymicCyberneticClosureV21320.renderLines(report).toTypedArray(),
            *GTIMFinalExosomeImmunometabolismClosureV21321.renderLines(report).toTypedArray(),
            *GTIMFinalStructuralImmunityClosureV21324.renderLines(report).toTypedArray(),
            *GTIMForegroundLongRunDossierClosureV21325.renderLines(report).toTypedArray(),
            *GTIMFinalSurfaceUnitContractClosureV213211.renderLines(report).toTypedArray(),
            "Best search/execution target: ${obj.optString("bestSearchOrExecutionTarget", "topic-compatible dataset/capsule search")}",
            "Required dataset profile: ${obj.optString("requiredDatasetProfile", "topic-compatible dataset/capsule with comparator and provenance")}",
            "Falsifier: ${obj.optString("falsifier", "downgrade if comparator/module/replication/contradiction checks fail")}",
            "Gate split: hypothesis_blockers=$hypothesis; execution_tasks=$executionTasks; clinical_claim_blockers=$clinical.",
            "Policy: C0/C1/C2/C3 sandbox preview allowed even without matrix or replication; missing gates are execution tasks, not preview blockers; clinical/actionable/validated proof claims remain blocked.",
            "Legacy leak firewall: old render tree blocked=${obj.optBoolean("legacyFirstSurfaceBlocked", true)}; legacy rails stay JSON/export appendix only.",
            "Compatibility appendix policy: legacy v2.12/v2.13 rails, debug tokens, external routes, old medical dossier blocks, and superseded candidates remain in JSON/export appendix only.",
            "Boundary: research-only. No mechanism proof, diagnosis, treatment, dosing, vaccine advice, efficacy, clinical implementation, or validated proof."
        )
        val sanitized = GTIMLegacyLeakFirewallV21316.sanitizeFirstSurface(report, lines)
        val thymicCybernetic = GTIMThymicCyberneticSurfaceCardV21320.toJson(report)
        val thymicClosure = GTIMFinalThymicCyberneticClosureV21320.toJson(report)
        val structural = GTIMStructuralImmunitySurfaceCardV21324.toJson(report)
        val structuralClosure = GTIMFinalStructuralImmunityClosureV21324.toJson(report)
        val contractLines = listOf(
            "Final requirements coverage closure",
            "Final active decision surface",
            "Final surface domain-coherence guard: active_domain=$active; subtype=${obj.optString("activeSubtype", "unknown")}; canonical_target=${canonical.ifBlank { "none" }}; legacy rails are appendix-only.",
            "State: ${obj.optString("state", STATE_READY)}; owner=${obj.optString("firstSurfaceOwner")}; active_domain=$active; subtype=${obj.optString("activeSubtype", "unknown")}; canonical_target=${canonical.ifBlank { "none" }}.",
            "Primary hypothesis",
            "Immune decision state",
            "Capsule state",
            "Concept/paradigm candidate",
            "Best execution route",
            "Falsifier",
            "Claim boundary",
            "Gate split: hypothesis_blockers=$hypothesis; execution_tasks=$executionTasks; clinical_claim_blockers=$clinical.",
            "legacy_surface_owner_allowed=false",
            "Compatibility appendix policy",
            "Legacy leak firewall",
            "Study Result Card",
            "Paradigm candidate card",
            "Old assumption challenged: ${assumption.optString("old_assumption_challenged")}",
            "Cross-disease mechanism: ${cross.optString("shared_mechanism_axis")}",
            "Therapeutic/modality lens: validated_treatment_claim=BLOCKED; dosing_or_patient_action=BLOCKED.",
            "Protein interaction/binding lens: validated_binding_or_efficacy_claim=BLOCKED.",
            "Thymic rejuvenation / cybernetic immunology card",
            "Thymic/cybernetic priority markers: FOXN1; naive_T_cell; vagus; closed_loop; sandbox preview allowed; no guaranteed rejuvenation; no instant cytokine-storm shutdown claim; no 100% safety claim.",
            "Thymic/immune-age role: ${thymicCybernetic.optString("thymic_state_hypothesis")}; naive_T_cell_axes=${thymicCybernetic.optJSONArray("naive_tcell_repertoire_axes") ?: JSONArray()}.",
            "Final thymic rejuvenation + cybernetic immunology closure",
            "Thymic/cybernetic closure state: ${thymicClosure.optString("state")}; surface_card_present=${thymicClosure.optBoolean("surface_card_present")}; sandbox_preview_allowed=${thymicClosure.optBoolean("sandbox_preview_allowed")}; treatment_or_dosing_allowed=${thymicClosure.optBoolean("treatment_or_dosing_allowed")}; device_or_patient_action_allowed=${thymicClosure.optBoolean("device_or_patient_action_allowed")}; clinical_implementation_allowed=${thymicClosure.optBoolean("clinical_implementation_allowed")}",
            "Structural immunity / non-immune cell immune-code card",
            "Foreground long-run dossier",
            "Structural immunity priority markers: epithelial_cells; endothelial_cells; fibroblasts; epigenetic_tissue_memory; single_cell_spatial_readouts; tissue therapy/fibrosis reversal/clinical implementation=BLOCKED.",
            "Structural immunity role: ${structural.optString("core_shift")}; mechanisms=${structural.optJSONArray("mechanism_axes") ?: JSONArray()}.",
            "Final structural immunity + non-immune cell code closure",
            "Structural immunity closure state: ${structuralClosure.optString("state")}; surface_card_present=${structuralClosure.optBoolean("surface_card_present")}; sandbox_preview_allowed=${structuralClosure.optBoolean("sandbox_preview_allowed")}; tissue_therapy_claim_allowed=${structuralClosure.optBoolean("tissue_therapy_claim_allowed")}; fibrosis_reversal_claim_allowed=${structuralClosure.optBoolean("fibrosis_reversal_claim_allowed")}; clinical_implementation_allowed=${structuralClosure.optBoolean("clinical_implementation_allowed")}",
            "Final surface unit-contract closure: v2.13.21.1; fixed markers are pinned before optional research cards; legacy rails remain appendix/export/audit only."
        )
        return (contractLines + sanitized).distinct().take(RuntimeFeatureFlags.MOBILE_SAFE_FIRST_SURFACE_MAX_LINES_V21313)
    }

    fun renderText(report: JSONObject): String = renderLines(report).joinToString("\n")

    fun auditTokens(): JSONArray = JSONArray(listOf(
        PATCH_VERSION,
        STATE_READY,
        "GTIMFinalActiveDecisionSurfaceV21317",
        "GTIMFinalRequirementsCoverageClosureV213181",
        "compact_first_surface_no_legacy_tree",
        "C0/C1/C2/C3 sandbox preview allowed",
        "c2PreviewAllowed",
        "clinicalClaimAllowed",
        "Local processed capsule card",
        "Paradigm candidate card",
        "Microbiome role card",
        "Cell-death / NETosis role card",
        "Exosome / immunometabolism role card",
        "FINAL_EXOSOME_IMMUNOMETABOLISM_CLOSURE_READY",
        "Structural immunity / non-immune cell immune-code card",
        "FINAL_STRUCTURAL_IMMUNITY_CLOSURE_READY",
        "LOCAL_PROCESSED_CAPSULE_AVAILABLE",
        CLAIM_LIMIT
    ))
}
