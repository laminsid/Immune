package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.24 — visible phase plan for long biomedical research runs.
 *
 * This is a UI/runtime contract, not a claim engine. It shows the user where the
 * agentic pass is: question capture, local knowledge, external search, cleaning,
 * reasoning, path linkage, and report output. Percent is progress of the foreground
 * pass, not scientific certainty.
 */
object GTIMAgenticProgressPlanV21324 {
    const val VERSION: String = "2.13.24-agentic-phase-progress-plan"
    const val CLAIM_LIMIT: String = "progress_percent_is_runtime_progress_not_evidence_strength"

    data class Phase(
        val key: String,
        val title: String,
        val startRatio: Double,
        val endRatio: Double,
        val executedLabel: String,
        val queuedLabel: String
    )

    private val phases: List<Phase> = listOf(
        Phase("READ_QUESTION", "Reading question", 0.00, 0.08, "question captured", "local knowledge synthesis"),
        Phase("LOCAL_KNOWLEDGE", "Collecting local scientific memory", 0.08, 0.22, "local route ontology and prior reports checked", "external source search"),
        Phase("EXTERNAL_SEARCH", "Searching and collecting data", 0.22, 0.55, "bounded external search batch started", "filtering and metadata cleanup"),
        Phase("FILTER_CLEAN", "Filtering and cleaning evidence handles", 0.55, 0.70, "candidate handles filtered", "reasoning and contradiction review"),
        Phase("THINK_SYNTHESIS", "Thinking and hypothesis synthesis", 0.70, 0.82, "research-only synthesis started", "path linkage"),
        Phase("PATH_LINKAGE", "Linking mechanisms and routes", 0.82, 0.92, "mechanism/pathway linkage started", "report rendering"),
        Phase("REPORT_OUTPUT", "Writing report", 0.92, 1.00, "partial/final dossier render started", "export/copy review")
    )

    fun phaseFor(elapsedMillis: Long, budget: GTIMMobileSearchBudgetV21322): Phase {
        val ratio = if (budget.hardTimeoutMillis <= 0L) 0.0 else elapsedMillis.toDouble() / budget.hardTimeoutMillis.toDouble()
        val bounded = ratio.coerceIn(0.0, 0.999)
        return phases.firstOrNull { bounded >= it.startRatio && bounded < it.endRatio } ?: phases.last()
    }

    fun percentFor(elapsedMillis: Long, budget: GTIMMobileSearchBudgetV21322): Int {
        if (budget.hardTimeoutMillis <= 0L) return 0
        return ((elapsedMillis.toDouble() / budget.hardTimeoutMillis.toDouble()) * 100.0).toInt().coerceIn(0, 99)
    }

    fun uiLine(elapsedMillis: Long, budget: GTIMMobileSearchBudgetV21322): String {
        val phase = phaseFor(elapsedMillis, budget)
        val percent = percentFor(elapsedMillis, budget)
        return "${phase.title} — $percent%"
    }

    fun uiBlock(topic: String, elapsedMillis: Long, budget: GTIMMobileSearchBudgetV21322, lastSafeStage: String): String {
        val phase = phaseFor(elapsedMillis, budget)
        val percent = percentFor(elapsedMillis, budget)
        val maxSeconds = budget.hardTimeoutMillis / 1000L
        val elapsedSeconds = elapsedMillis / 1000L
        return buildString {
            append("Topic: ").append(topic.take(100)).append("\n")
            append("Progress: ").append(percent).append("% — ").append(phase.title).append("\n")
            append("Elapsed: ").append(elapsedSeconds).append("/").append(maxSeconds).append("s\n")
            append("Visible report rule: first dossier at ").append(budget.firstVisibleReportMillis / 1000L).append("s, hard close at ").append(maxSeconds).append("s\n")
            append("Current stage: ").append(lastSafeStage).append("\n")
            append("Pipeline: 1 Read question → 2 Local knowledge → 3 Search/data → 4 Filter/clean → 5 Think → 6 Link paths → 7 Report\n")
            append("Executed so far: ").append(phase.executedLabel).append("\n")
            append("Next queued: ").append(phase.queuedLabel).append("\n")
            append("Boundary: progress percent is runtime progress, not evidence strength.")
        }
    }

    fun toJson(budget: GTIMMobileSearchBudgetV21322, elapsedMillis: Long, lastSafeStage: String): JSONObject {
        val phase = phaseFor(elapsedMillis, budget)
        return JSONObject()
            .put("version", VERSION)
            .put("phase", phase.key)
            .put("phaseTitle", phase.title)
            .put("percent", percentFor(elapsedMillis, budget))
            .put("elapsedMillis", elapsedMillis)
            .put("hardTimeoutMillis", budget.hardTimeoutMillis)
            .put("firstVisibleReportMillis", budget.firstVisibleReportMillis)
            .put("lastSafeStage", lastSafeStage)
            .put("pipeline", JSONArray(phases.map { it.title }))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun executedChecksFor(lastSafeStage: String, elapsedMillis: Long, budget: GTIMMobileSearchBudgetV21322): JSONArray {
        val phase = phaseFor(elapsedMillis, budget)
        val executed = mutableListOf("question captured", "foreground runtime budget applied", "six-minute visible report guarantee armed", phase.executedLabel)
        if (lastSafeStage.isNotBlank()) executed += "last safe stage: $lastSafeStage"
        if (elapsedMillis >= (budget.hardTimeoutMillis * 0.22).toLong()) executed += "local knowledge and route planning attempted"
        if (elapsedMillis >= (budget.hardTimeoutMillis * 0.55).toLong()) executed += "bounded source collection attempted"
        if (elapsedMillis >= (budget.hardTimeoutMillis * 0.70).toLong()) executed += "candidate filtering attempted"
        if (elapsedMillis >= (budget.hardTimeoutMillis * 0.82).toLong()) executed += "research-only synthesis attempted"
        return JSONArray(executed.distinct())
    }

    fun queuedChecksFor(lastSafeStage: String, elapsedMillis: Long, budget: GTIMMobileSearchBudgetV21322): JSONArray {
        val pending = mutableListOf<String>()
        if (elapsedMillis < (budget.hardTimeoutMillis * 0.22).toLong()) pending += "local knowledge synthesis"
        if (elapsedMillis < (budget.hardTimeoutMillis * 0.55).toLong()) pending += "remaining accession lookup and external source search"
        if (elapsedMillis < (budget.hardTimeoutMillis * 0.70).toLong()) pending += "metadata sweep and comparator/sample provenance"
        if (elapsedMillis < (budget.hardTimeoutMillis * 0.82).toLong()) pending += "contradiction search and weak-lead separation"
        if (elapsedMillis < (budget.hardTimeoutMillis * 0.92).toLong()) pending += "mechanism/pathway linkage"
        if (elapsedMillis < budget.firstVisibleReportMillis) pending += "six-minute interim dossier surface"
        pending += "final dossier synthesis/export review"
        pending += "queued checks are not evidence"
        return JSONArray(pending.distinct())
    }
}
