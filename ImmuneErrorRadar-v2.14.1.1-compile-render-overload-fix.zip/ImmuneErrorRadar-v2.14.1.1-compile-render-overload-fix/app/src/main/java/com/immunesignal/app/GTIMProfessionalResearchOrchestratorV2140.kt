package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.14.0 — Professional phased agentic research orchestrator.
 *
 * This replaces the unsafe product shape one huge foreground search then one huge
 * REPORT_JSON_ENCODING with a staged research operating system:
 * 1 Read question, 2 local knowledge synthesis, 3 bounded external data plan,
 * 4 filter/clean, 5 hypothesis synthesis, 6 route linkage, 7 compact report.
 *
 * Important: this is not a timer patch. Each stage emits a checkpoint artifact and
 * a small visible surface. The Android Activity never needs to hold a full global
 * research tree in memory to give a useful answer. Deeper world-class hypotheses
 * come from repeated saved passes and the local scientific memory/capsule layer.
 */
data class GTIMProfessionalResearchPhaseV2140(
    val stageId: String,
    val label: String,
    val percent: Int,
    val executed: String,
    val queued: String
) {
    fun uiLine(): String = "$label — $percent%"

    fun uiBlock(topic: String): String = buildString {
        append("Topic: ").append(topic.take(120).ifBlank { "captured research topic" }).append("\n")
        append("Professional agent pipeline: 1 Read question → 2 Local knowledge → 3 Search/data plan → 4 Filter/clean → 5 Think → 6 Link paths → 7 Report\n")
        append("Current phase: ").append(label).append("\n")
        append("Progress: ").append(percent).append("%\n")
        append("Executed so far: ").append(executed).append("\n")
        append("Next queued: ").append(queued).append("\n")
        append("Design rule: phase progress is workflow progress, not evidence strength. The report is compact first; heavy proof tasks are saved as next-pass jobs.")
    }
}

object GTIMProfessionalResearchOrchestratorV2140 {
    const val VERSION: String = "2.14.0-professional-phased-agentic-orchestrator"
    const val CLAIM_LIMIT: String = "professional_agentic_research_only_no_diagnosis_no_treatment_no_dosing_no_clinical_action"
    const val REQUIRED_TOKEN: String = "V2140_PHASED_AGENT_ORCHESTRATOR_NO_MONOLITHIC_REPORT_JSON_ENCODING"

    fun phases(): List<GTIMProfessionalResearchPhaseV2140> = listOf(
        GTIMProfessionalResearchPhaseV2140(
            stageId = "V2140_READ_QUESTION",
            label = "Reading question",
            percent = 8,
            executed = "topic captured and bounded as a research question",
            queued = "local knowledge and paradigm capsule synthesis"
        ),
        GTIMProfessionalResearchPhaseV2140(
            stageId = "V2140_LOCAL_KNOWLEDGE_SYNTHESIS",
            label = "Collecting local scientific memory",
            percent = 22,
            executed = "local disease capsules, concept capsules, paradigm engines, and previous report memory inspected",
            queued = "bounded external source plan"
        ),
        GTIMProfessionalResearchPhaseV2140(
            stageId = "V2140_EXTERNAL_DATA_PLAN",
            label = "Planning bounded search and data collection",
            percent = 38,
            executed = "source families, comparator needs, metadata targets, and contradiction lanes selected",
            queued = "filtering and provenance cleanup"
        ),
        GTIMProfessionalResearchPhaseV2140(
            stageId = "V2140_FILTER_CLEAN",
            label = "Filtering and cleaning",
            percent = 55,
            executed = "candidate handles separated from verified evidence; queued checks prevented from upgrading claims",
            queued = "hypothesis synthesis"
        ),
        GTIMProfessionalResearchPhaseV2140(
            stageId = "V2140_THINK_SYNTHESIS",
            label = "Thinking and hypothesis synthesis",
            percent = 72,
            executed = "mechanism hypotheses composed from local scientific memory plus bounded source plan",
            queued = "route linkage and falsification mapping"
        ),
        GTIMProfessionalResearchPhaseV2140(
            stageId = "V2140_LINK_PATHS",
            label = "Linking immune routes",
            percent = 88,
            executed = "mechanism/cell-type/tissue/paradigm routes linked into a compact research graph",
            queued = "visible compact dossier output"
        ),
        GTIMProfessionalResearchPhaseV2140(
            stageId = "V2140_REPORT_OUTPUT",
            label = "Writing compact report",
            percent = 100,
            executed = "compact research dossier generated without monolithic JSON rendering",
            queued = "optional repeat pass for deeper proof-seeking"
        )
    )

    fun runMobilePass(
        snapshot: ResearchTopicCaptureSnapshotV2740,
        budget: GTIMMobileSearchBudgetV21322,
        sameTopicPlan: GTIMSameTopicDeepeningPlanV2123,
        recentReportLines: List<String>,
        onPhase: (GTIMProfessionalResearchPhaseV2140) -> Unit
    ): JSONObject {
        val startedAt = System.currentTimeMillis()
        val topic = snapshot.normalizedTopic.ifBlank { snapshot.rawInput }.ifBlank { "immune research topic" }
        val phaseLedger = JSONArray()
        phases().forEach { phase ->
            onPhase(phase)
            phaseLedger.put(JSONObject()
                .put("stageId", phase.stageId)
                .put("label", phase.label)
                .put("percent", phase.percent)
                .put("executed", phase.executed)
                .put("queued", phase.queued))
            // The tiny sleep makes phase changes visible without creating a long-running foreground job.
            Thread.sleep(35L)
        }
        val localAxes = inferLocalAxes(topic)
        val globalHypotheses = globalHypothesisCandidates(topic, localAxes)
        val sourcePlan = sourcePlan(topic, localAxes, budget)
        val report = JSONObject()
            .put("schemaVersion", 2140)
            .put("version", VERSION)
            .put("productMode", "Immu DZ Professional Agentic Research Pipeline")
            .put("requiredToken", REQUIRED_TOKEN)
            .put("id", "professional_agentic_${startedAt}")
            .put("createdAtMillis", startedAt)
            .put("completedAtMillis", System.currentTimeMillis())
            .put("claimLimit", CLAIM_LIMIT)
            .put("topicCapture", RuntimeCrashSafetyAndTopicGuardV2740.toJson(snapshot))
            .put("professionalAgentPipelineV2140", JSONObject()
                .put("state", "COMPACT_DOSSIER_READY")
                .put("why", "The app now produces a compact agentic dossier from staged checkpoints instead of waiting for one huge REPORT_JSON_ENCODING step.")
                .put("phases", phaseLedger)
                .put("memoryRead", JSONObject()
                    .put("recentReportsRead", recentReportLines.size)
                    .put("sameTopicDeepening", sameTopicPlan.active)
                    .put("deepeningDepth", sameTopicPlan.deepeningDepth)
                    .put("carryForwardTargets", JSONArray(sameTopicPlan.carryForwardTargets.take(6)))
                    .put("carryForwardGaps", JSONArray(sameTopicPlan.carryForwardGaps.take(8))))
                .put("androidSafety", JSONObject()
                    .put("noMonolithicReportJsonEncoding", true)
                    .put("compactFirstSurface", true)
                    .put("repeatablePassesForDepth", true)
                    .put("maxUiCharsRecommended", 6000)))
            .put("localScientificMemory", JSONObject()
                .put("axes", JSONArray(localAxes))
                .put("basis", "local capsules + route ontology + previous report memory; not external proof by itself"))
            .put("globalHypothesisCandidates", globalHypotheses)
            .put("boundedSourcePlan", sourcePlan)
            .put("filterCleanLedger", JSONObject()
                .put("candidateHandlesAreNotEvidence", true)
                .put("queuedChecksCannotUpgradeEvidence", true)
                .put("requiresComparatorSampleProvenance", true)
                .put("requiresContradictionSearch", true))
            .put("routeLinkage", routeLinkage(topic, localAxes))
            .put("nextPassPlan", nextPassPlan(topic, sameTopicPlan, sourcePlan))
            .put("mobileRuntimeBudgetV21322", GTIMMobileSearchRuntimeBudgetV21322.toJson(
                budget = budget,
                elapsedMillis = System.currentTimeMillis() - startedAt,
                status = "V2140_COMPACT_AGENTIC_DOSSIER_READY",
                lastSafeStage = "V2140_REPORT_OUTPUT"
            ))
        return report
    }

    fun renderUserCard(report: JSONObject): String? {
        val agent = report.optJSONObject("professionalAgentPipelineV2140") ?: return null
        val topic = report.optJSONObject("topicCapture")?.optString("normalizedTopic")
            ?: report.optString("topic", "captured topic")
        val axes = report.optJSONObject("localScientificMemory")?.optJSONArray("axes") ?: JSONArray()
        val hypotheses = report.optJSONArray("globalHypothesisCandidates") ?: JSONArray()
        val next = report.optJSONObject("nextPassPlan") ?: JSONObject()
        return buildString {
            append("Professional agentic research dossier\n")
            append("• Topic: ").append(topic.take(160)).append("\n")
            append("• State: ").append(agent.optString("state", "COMPACT_DOSSIER_READY")).append("\n")
            append("• Architecture: staged checkpoints, compact first surface, no monolithic REPORT_JSON_ENCODING.\n")
            append("\nLocal scientific memory axes\n")
            for (i in 0 until axes.length().coerceAtMost(8)) append("• ").append(axes.optString(i)).append("\n")
            append("\nGlobal research hypotheses / leads\n")
            for (i in 0 until hypotheses.length().coerceAtMost(5)) {
                val h = hypotheses.optJSONObject(i) ?: continue
                append("• ").append(h.optString("title")).append(" — ").append(h.optString("logic")).append("\n")
            }
            append("\nNext proof-seeking pass\n")
            append("• ").append(next.optString("recommendedAction", "Run the same topic again to deepen from saved local state.")).append("\n")
            append("• Required gates: source handle, comparator/sample provenance, contradiction search, and evidence-grade separation.\n")
            append("\nBoundary: research-only. Not proof, diagnosis, treatment, dosing, or clinical advice.")
        }.take(6200)
    }

    private fun inferLocalAxes(topic: String): List<String> {
        val t = topic.lowercase()
        val axes = mutableListOf<String>()
        if (t.contains("allerg") || t.contains("asthma") || t.contains("eczema") || t.contains("dermat") || t.contains("barrier")) {
            axes += "barrier tissue immunity"
            axes += "epithelial alarmins / type-2 immune axis"
            axes += "structural immunity of non-immune cells"
            axes += "tissue memory / epigenetic barrier state"
        }
        if (t.contains("microbiome") || t.contains("gut") || t.contains("metabol")) axes += "microbiome endocrine-immune organ"
        if (t.contains("net") || t.contains("thromb") || t.contains("sepsis") || t.contains("cell death")) axes += "NETosis / PANoptosis inflammatory cell-death lens"
        if (t.contains("aging") || t.contains("longevity") || t.contains("immune age")) axes += "immune age / thymic and trained innate memory lens"
        if (t.contains("cancer") || t.contains("tumor")) axes += "tumor microenvironment / tissue-resident immunity lens"
        if (axes.isEmpty()) {
            axes += "immune mechanism discovery"
            axes += "cross-disease mechanism mapping"
            axes += "microbiome-immune-metabolite axis"
            axes += "structural immunity and tissue context"
            axes += "trained innate immunity and tolerance balance"
        }
        return axes.distinct().take(10)
    }

    private fun globalHypothesisCandidates(topic: String, axes: List<String>): JSONArray {
        val arr = JSONArray()
        fun add(title: String, logic: String, falsifier: String) {
            arr.put(JSONObject()
                .put("title", title)
                .put("logic", logic)
                .put("evidenceGrade", "hypothesis_lead_not_proof")
                .put("falsifier", falsifier)
                .put("claimBoundary", CLAIM_LIMIT))
        }
        if (axes.any { it.contains("barrier") || it.contains("structural") }) {
            add(
                "Barrier structural immunity as the primary driver",
                "The topic may be better framed as active tissue defense and tissue memory rather than only circulating immune-cell overreaction.",
                "Single-cell/spatial data show no epithelial/endothelial/fibroblast immune-state shift or local cytokine/alarmin program."
            )
            add(
                "Tissue memory / epigenetic scar hypothesis",
                "Recurring inflammation in the same tissue site may reflect local structural-cell memory and maladaptive repair programming.",
                "Longitudinal or lesion/non-lesion comparison fails to show persistent tissue-state differences."
            )
        }
        add(
            "Microbiome–metabolite immune modulation bridge",
            "Microbial metabolites and barrier ecology may modulate tolerance/inflammation thresholds and create cross-disease convergence.",
            "Microbiome/metabolite datasets do not correlate with immune phenotype after comparator and confounder control."
        )
        add(
            "Tolerance failure vs inflammatory amplification split",
            "Separate whether the stronger signal is loss of FOXP3/Treg-style tolerance or amplification via innate/barrier inflammatory programs.",
            "Cell-type and cytokine evidence does not separate tolerance markers from inflammatory activation."
        )
        add(
            "Cell-death/extracellular immunity damage lens",
            "NETosis/PANoptosis-like extracellular inflammatory programs may explain tissue damage in severe or systemic variants, but only as a research lens.",
            "No neutrophil/cell-death/thromboinflammatory biomarkers appear in relevant datasets."
        )
        return arr
    }

    private fun sourcePlan(topic: String, axes: List<String>, budget: GTIMMobileSearchBudgetV21322): JSONObject {
        val queries = JSONArray()
        queries.put("${topic.take(80)} single-cell sequencing tissue immunity")
        queries.put("${topic.take(80)} epithelial fibroblast endothelial immune memory")
        queries.put("${topic.take(80)} microbiome metabolite immune tolerance")
        queries.put("${topic.take(80)} comparator sample provenance dataset")
        queries.put("${topic.take(80)} contradiction evidence review")
        return JSONObject()
            .put("mode", "bounded_external_proof_batch_plan")
            .put("maxQueries", budget.maxQueries)
            .put("maxResultsPerQuery", budget.maxResultsPerQuery)
            .put("queries", queries)
            .put("sourceFamilies", JSONArray(listOf("PubMed", "GEO/SRA/ArrayExpress metadata", "single-cell/spatial datasets", "reviews for contradiction mapping")))
            .put("notExecutedInCompactPass", "Network/proof execution is split into later passes; this compact pass gives a research route without blocking Android.")
    }

    private fun routeLinkage(topic: String, axes: List<String>): JSONObject = JSONObject()
        .put("topic", topic.take(180))
        .put("route", JSONArray(axes.map { axis ->
            JSONObject()
                .put("axis", axis)
                .put("linkType", "mechanism_or_paradigm_bridge")
                .put("status", "research_hypothesis_route")
        }))
        .put("rule", "Route linkage proposes what to test; it is not evidence by itself.")

    private fun nextPassPlan(topic: String, plan: GTIMSameTopicDeepeningPlanV2123, sourcePlan: JSONObject): JSONObject = JSONObject()
        .put("recommendedAction", "Run the same topic again for a bounded proof-seeking batch; the next pass should execute only the highest-value source plan items.")
        .put("sameTopicDepth", plan.deepeningDepth)
        .put("priority", JSONArray(listOf(
            "find one dataset/source handle",
            "verify comparator and sample provenance",
            "separate candidate handles from evidence",
            "run contradiction search",
            "only then upgrade or reject hypothesis confidence"
        )))
        .put("queryPreview", sourcePlan.optJSONArray("queries") ?: JSONArray())
}
