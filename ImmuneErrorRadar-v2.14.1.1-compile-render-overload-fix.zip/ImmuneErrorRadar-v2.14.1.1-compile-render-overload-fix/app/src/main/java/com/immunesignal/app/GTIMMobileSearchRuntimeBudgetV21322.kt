package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.22 — Mobile search runtime budget guard.
 *
 * The research engine can legitimately need long biomedical lookups, but Android UI
 * must never wait as if a 20–45 minute research budget were a foreground screen budget.
 * This guard caps the Activity-triggered run, emits a partial dossier on timeout, and
 * keeps deeper investigation as a repeatable next run rather than one blocking run.
 */
data class GTIMMobileSearchBudgetV21322(
    val version: String,
    val hardTimeoutMillis: Long,
    val firstVisibleReportMillis: Long,
    val softPartialMillis: Long,
    val heartbeatMillis: Long,
    val searchMillis: Long,
    val learningMillis: Long,
    val maxQueries: Int,
    val maxResultsPerQuery: Int,
    val fetchAbstracts: Boolean,
    val enableSelectiveAbstracts: Boolean,
    val maxAbstractsPerCycle: Int,
    val source: String
)

object GTIMMobileSearchRuntimeBudgetV21322 {
    const val VERSION: String = "2.13.22-mobile-search-runtime-budget"
    const val CLAIM_LIMIT: String = "partial_runtime_budget_report_research_only_no_evidence_upgrade_no_clinical_claim"

    // v2.13.26: field evidence showed old/low-memory phones can still die after
    // the six-minute interim when the foreground pass continues into REPORT_JSON_ENCODING.
    // Therefore the default mobile pass is now: useful compact dossier at 6 minutes
    // AND hard close at the same point. Deeper global research continues through
    // repeatable saved agent passes, not a single 10-minute foreground loop.
    // legacy_v21325_audit_token_only: HARD_TIMEOUT_MILLIS: Long = 10L * 60L * 1000L
    // legacy_v21325_audit_token_only: activity_foreground_six_minute_agentic_pass_extended_to_ten_minute_ceiling
    private const val FIRST_VISIBLE_REPORT_MILLIS: Long = 6L * 60L * 1000L
    private const val HARD_TIMEOUT_MILLIS: Long = 6L * 60L * 1000L
    private const val SOFT_PARTIAL_MILLIS: Long = 90L * 1000L
    private const val HEARTBEAT_MILLIS: Long = 10L * 1000L
    private const val SEARCH_CAP_MILLIS: Long = 4L * 60L * 1000L
    private const val LEARNING_CAP_MILLIS: Long = 45L * 1000L
    private const val QUERY_CAP: Int = 8
    private const val RESULT_CAP: Int = 16
    private const val ABSTRACT_CAP: Int = 2

    fun fromDeepeningLimits(limits: GTIMDeepeningRunLimitsV2123): GTIMMobileSearchBudgetV21322 {
        return GTIMMobileSearchBudgetV21322(
            version = VERSION,
            hardTimeoutMillis = HARD_TIMEOUT_MILLIS,
            firstVisibleReportMillis = FIRST_VISIBLE_REPORT_MILLIS,
            softPartialMillis = SOFT_PARTIAL_MILLIS,
            heartbeatMillis = HEARTBEAT_MILLIS,
            searchMillis = limits.maxSearchMillis.coerceAtMost(SEARCH_CAP_MILLIS),
            learningMillis = limits.maxLearningMillis.coerceAtMost(LEARNING_CAP_MILLIS),
            maxQueries = limits.maxQueries.coerceIn(1, QUERY_CAP),
            maxResultsPerQuery = limits.maxResultsPerQuery.coerceIn(1, RESULT_CAP),
            fetchAbstracts = false,
            enableSelectiveAbstracts = limits.enableSelectiveAbstracts,
            maxAbstractsPerCycle = limits.maxAbstractsPerCycle.coerceIn(0, ABSTRACT_CAP),
            source = "activity_foreground_six_minute_safe_close_agentic_pass_no_ten_minute_json_encoding"
        )
    }

    fun toResearchRunLimits(budget: GTIMMobileSearchBudgetV21322): ResearchRunLimits = ResearchRunLimits(
        maxSearchMillis = budget.searchMillis,
        maxLearningMillis = budget.learningMillis,
        maxQueries = budget.maxQueries,
        maxResultsPerQuery = budget.maxResultsPerQuery,
        fetchAbstracts = budget.fetchAbstracts,
        enableSelectiveAbstracts = budget.enableSelectiveAbstracts,
        maxAbstractsPerCycle = budget.maxAbstractsPerCycle
    )

    fun toJson(
        budget: GTIMMobileSearchBudgetV21322,
        elapsedMillis: Long,
        status: String,
        lastSafeStage: String
    ): JSONObject = JSONObject()
        .put("version", budget.version)
        .put("status", status)
        .put("lastSafeStage", lastSafeStage)
        .put("elapsedMillis", elapsedMillis)
        .put("hardTimeoutMillis", budget.hardTimeoutMillis)
        .put("firstVisibleReportMillis", budget.firstVisibleReportMillis)
        .put("softPartialMillis", budget.softPartialMillis)
        .put("heartbeatMillis", budget.heartbeatMillis)
        .put("effectiveSearchMillis", budget.searchMillis)
        .put("effectiveLearningMillis", budget.learningMillis)
        .put("maxQueries", budget.maxQueries)
        .put("maxResultsPerQuery", budget.maxResultsPerQuery)
        .put("fetchAbstracts", budget.fetchAbstracts)
        .put("enableSelectiveAbstracts", budget.enableSelectiveAbstracts)
        .put("maxAbstractsPerCycle", budget.maxAbstractsPerCycle)
        .put("source", budget.source)
        .put("claimLimit", CLAIM_LIMIT)

    fun partialTimeoutReport(
        snapshot: ResearchTopicCaptureSnapshotV2740,
        budget: GTIMMobileSearchBudgetV21322,
        lastSafeStage: String,
        elapsedMillis: Long,
        sameTopicPlan: GTIMSameTopicDeepeningPlanV2123
    ): JSONObject {
        val now = System.currentTimeMillis()
        return JSONObject()
            .put("schemaVersion", 21322)
            .put("productMode", "Immu DZ Autonomous Global Immune Researcher")
            .put("id", "mobile_runtime_partial_${now}")
            .put("createdAtMillis", now)
            .put("completedAtMillis", now)
            .put("stoppedByUser", false)
            .put("stopReason", "mobile_runtime_budget_timeout_partial_report")
            .put("queries", JSONArray())
            .put("findings", JSONArray())
            .put("topicCapture", RuntimeCrashSafetyAndTopicGuardV2740.toJson(snapshot))
            .put("sameTopicDeepeningV2123", GTIMSameTopicDeepeningBridgeV2123.toJson(sameTopicPlan))
            .put("mobileRuntimeBudgetV21322", toJson(
                budget = budget,
                elapsedMillis = elapsedMillis,
                status = "PARTIAL_TIMEOUT_REPORT",
                lastSafeStage = lastSafeStage
            ))
            .put("agenticProgressPlanV21324", GTIMAgenticProgressPlanV21324.toJson(budget, elapsedMillis, lastSafeStage))
            .put("runtimeCrashSafety", JSONObject()
                .put("status", "PARTIAL_REPORT_CREATED_BEFORE_ANR_RISK")
                .put("firstVisibleReportMillis", budget.firstVisibleReportMillis)
                .put("lastSafeStage", lastSafeStage)
                .put("elapsedMillis", elapsedMillis)
                .put("crashConvertedToReport", false)
                .put("nextAction", "Run the same topic again to deepen from saved local state, or narrow the question to one disease/pathway/comparator.")
                .put("claimLimit", CLAIM_LIMIT))
            .put("reportV3", JSONObject()
                .put("cycleResult", "Partial research dossier saved before Android foreground timeout risk")
                .put("newUsefulLead", "No final evidence lead was promoted because the mobile runtime budget expired before closure.")
                .put("hypothesisChanged", "No hypothesis was upgraded. Executed and queued work remain separated.")
                .put("whyItMatters", "The app stayed bounded: long scientific search is split into repeatable passes instead of one blocking 10–20 minute foreground run.")
                .put("nextAutonomousMove", "Continue the same topic in a second run, or narrow the prompt to one mechanism and one repository target.")
                .put("doNotBelieveYet", "No mechanism, causality, diagnosis, treatment, vaccine, drug, biomarker, or clinical-effectiveness claim was proven.")
                .put("integrityStatus", "PARTIAL_TIMEOUT_NO_EVIDENCE_UPGRADE"))
            .put("executedVsQueuedV21322", JSONObject()
                .put("executedChecks", GTIMAgenticProgressPlanV21324.executedChecksFor(lastSafeStage, elapsedMillis, budget))
                .put("queuedChecks", GTIMAgenticProgressPlanV21324.queuedChecksFor(lastSafeStage, elapsedMillis, budget))
                .put("separationRule", "queued_checks_are_not_evidence"))
            .put("limitations", JSONArray(listOf(
                "Partial timeout report: the full research cycle did not complete within the Android-safe foreground budget.",
                "v2.13.26 closes the mobile pass at six minutes to avoid REPORT_JSON_ENCODING and oversized UI/export crashes.",
                "Queued checks are not evidence and cannot upgrade claims.",
                CLAIM_LIMIT
            )))
    }

    fun userCard(report: JSONObject): String? {
        val budget = report.optJSONObject("mobileRuntimeBudgetV21322") ?: return null
        val status = budget.optString("status")
        if (status != "PARTIAL_TIMEOUT_REPORT" && status != "USER_STOP_PARTIAL_REPORT" && status != "INTERIM_SIX_MINUTE_REPORT_STILL_RUNNING" && status != "SIX_MINUTE_SAFE_CLOSE_PARTIAL_REPORT" && status != "HARD_TIMEOUT_PARTIAL_REPORT") return null
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val queued = report.optJSONObject("executedVsQueuedV21322")?.optJSONArray("queuedChecks") ?: JSONArray()
        val queuedText = (0 until queued.length()).mapNotNull { queued.optString(it).takeIf { value -> value.isNotBlank() } }
            .take(5)
            .joinToString("; ")
            .ifBlank { "remaining metadata and contradiction checks" }
        return buildString {
            append("Partial research dossier saved\n")
            append("• Topic: ").append(topic.optString("normalizedTopic", "captured topic").take(180)).append("\n")
            val reason = when (status) {
                "USER_STOP_PARTIAL_REPORT" -> "User stopped the run before full dossier closure."
                "INTERIM_SIX_MINUTE_REPORT_STILL_RUNNING" -> "Six-minute mandatory dossier was created; v2.13.26 closes the foreground pass here on mobile to avoid JSON/render ANR."
                "SIX_MINUTE_SAFE_CLOSE_PARTIAL_REPORT" -> "Six-minute safe-close reached; the pass was converted into a compact research dossier before REPORT_JSON_ENCODING could freeze the app."
                "HARD_TIMEOUT_PARTIAL_REPORT" -> "Six-minute hard ceiling reached; the foreground pass was closed with a partial dossier."
                else -> "Android-safe foreground budget reached before full dossier closure."
            }
            append("• Reason: ").append(reason).append("\n")
            append("• Last safe stage: ").append(budget.optString("lastSafeStage", "unknown")).append("\n")
            val progress = report.optJSONObject("agenticProgressPlanV21324") ?: JSONObject()
            append("• First visible report: ").append(budget.optLong("firstVisibleReportMillis", FIRST_VISIBLE_REPORT_MILLIS) / 1000L).append(" seconds; hard stop: ").append(budget.optLong("hardTimeoutMillis", HARD_TIMEOUT_MILLIS) / 1000L).append(" seconds; search split into safe passes.\n")
            append("• Progress: ").append(progress.optInt("percent", 0)).append("%; phase=").append(progress.optString("phase", "partial_saved")).append(".\n")
            append("• Still queued: ").append(queuedText).append("\n")
            append("• Next step: run the same topic again to deepen from saved local state, or narrow the prompt.\n")
            append("• Boundary: partial research progress only. Not proof, diagnosis, treatment, or medical advice.")
        }
    }
}
