package com.immunesignal.app

/**
 * v2.14.1 — live stage title and percent contract.
 *
 * The professional agentic pipeline must be visible as a sequence of real stages,
 * not as a frozen "searching" screen. This presenter owns the title, subtitle,
 * stage line, and determinate progress percent shown in ResearchAutopilotActivity.
 * Percent is workflow progress only; it is not evidence strength.
 */
data class GTIMLiveStageStateV2141(
    val stageId: String,
    val stepLabel: String,
    val percent: Int,
    val headerTitle: String,
    val subtitle: String,
    val stageLine: String,
    val windowTitle: String
)

object GTIMLiveStagePresenterV2141 {
    const val VERSION: String = "2.14.1-live-stage-title-percent-presenter"
    const val REQUIRED_TOKEN: String = "V2141_LIVE_STAGE_TITLES_AND_PERCENT_PROGRESS"
    const val CLAIM_LIMIT: String = "stage_percent_is_workflow_progress_not_evidence_strength"

    private data class StageMeta(
        val order: Int,
        val total: Int = 7,
        val shortTitle: String,
        val subtitleAction: String
    )

    private val stageMetaById: Map<String, StageMeta> = mapOf(
        "V2140_READ_QUESTION" to StageMeta(1, shortTitle = "Read question", subtitleAction = "capturing the user question and locking the research topic"),
        "V2140_LOCAL_KNOWLEDGE_SYNTHESIS" to StageMeta(2, shortTitle = "Local knowledge", subtitleAction = "reading capsules, route memory, and previous reports"),
        "V2140_EXTERNAL_DATA_PLAN" to StageMeta(3, shortTitle = "Search/data plan", subtitleAction = "planning bounded source and dataset collection"),
        "V2140_FILTER_CLEAN" to StageMeta(4, shortTitle = "Filter/clean", subtitleAction = "separating candidate handles from usable evidence"),
        "V2140_THINK_SYNTHESIS" to StageMeta(5, shortTitle = "Think", subtitleAction = "building research-only hypotheses and falsifiers"),
        "V2140_LINK_PATHS" to StageMeta(6, shortTitle = "Link paths", subtitleAction = "connecting mechanisms, tissues, biomarkers, and routes"),
        "V2140_REPORT_OUTPUT" to StageMeta(7, shortTitle = "Report", subtitleAction = "writing the compact dossier and next-pass plan"),
        "READ_QUESTION" to StageMeta(1, shortTitle = "Read question", subtitleAction = "capturing the user question and locking the research topic"),
        "LOCAL_KNOWLEDGE" to StageMeta(2, shortTitle = "Local knowledge", subtitleAction = "reading local scientific memory"),
        "EXTERNAL_SEARCH" to StageMeta(3, shortTitle = "Search/data", subtitleAction = "collecting bounded source and data handles"),
        "FILTER_CLEAN" to StageMeta(4, shortTitle = "Filter/clean", subtitleAction = "cleaning candidate evidence handles"),
        "THINK_SYNTHESIS" to StageMeta(5, shortTitle = "Think", subtitleAction = "synthesizing hypotheses"),
        "PATH_LINKAGE" to StageMeta(6, shortTitle = "Link paths", subtitleAction = "linking mechanism routes"),
        "REPORT_OUTPUT" to StageMeta(7, shortTitle = "Report", subtitleAction = "writing the visible dossier")
    )

    fun idle(): GTIMLiveStageStateV2141 = state(
        stageId = "V2141_IDLE",
        label = "Ready",
        percent = 0,
        topic = "",
        meta = StageMeta(0, 7, "Ready", "enter one question to start a staged research pass")
    )

    fun finished(): GTIMLiveStageStateV2141 = state(
        stageId = "V2141_FINISHED",
        label = "Ready for next search",
        percent = 100,
        topic = "",
        meta = StageMeta(7, 7, "Ready", "previous pass is closed; run again to deepen from saved state")
    )

    fun searching(): GTIMLiveStageStateV2141 = state(
        stageId = "V2141_SEARCHING",
        label = "Starting staged research",
        percent = 3,
        topic = "",
        meta = StageMeta(1, 7, "Starting", "arming progress, watchdog, and compact dossier safety")
    )

    fun readingQuestion(topic: String): GTIMLiveStageStateV2141 = state(
        stageId = "V2140_READ_QUESTION",
        label = "Reading question",
        percent = 5,
        topic = topic,
        meta = stageMetaById.getValue("V2140_READ_QUESTION")
    )

    fun localKnowledge(topic: String): GTIMLiveStageStateV2141 = state(
        stageId = "V2140_LOCAL_KNOWLEDGE_SYNTHESIS",
        label = "Collecting local scientific memory",
        percent = 14,
        topic = topic,
        meta = stageMetaById.getValue("V2140_LOCAL_KNOWLEDGE_SYNTHESIS")
    )

    fun searchLaunch(topic: String, plan: GTIMSameTopicDeepeningPlanV2123): GTIMLiveStageStateV2141 {
        val label = if (plan.active) "Deepening saved topic" else "Starting bounded search"
        val subtitle = if (plan.active) "continuing pass #${plan.deepeningDepth} from saved local state" else "preparing bounded external lookup without monolithic rendering"
        return state(
            stageId = "V2141_SEARCH_LAUNCH",
            label = label,
            percent = 18,
            topic = topic,
            meta = StageMeta(2, 7, "Launch", subtitle)
        )
    }

    fun fromProfessionalPhase(phase: GTIMProfessionalResearchPhaseV2140, topic: String): GTIMLiveStageStateV2141 {
        val meta = stageMetaById[phase.stageId] ?: StageMeta(0, 7, phase.label, phase.queued)
        return state(
            stageId = phase.stageId,
            label = phase.label,
            percent = phase.percent,
            topic = topic,
            meta = meta
        )
    }

    fun fromRuntimeElapsed(
        topic: String,
        elapsedMillis: Long,
        budget: GTIMMobileSearchBudgetV21322,
        lastSafeStage: String
    ): GTIMLiveStageStateV2141 {
        val phase = GTIMAgenticProgressPlanV21324.phaseFor(elapsedMillis, budget)
        val percent = GTIMAgenticProgressPlanV21324.percentFor(elapsedMillis, budget)
        val meta = stageMetaById[phase.key] ?: StageMeta(0, 7, phase.title, phase.queuedLabel)
        return state(
            stageId = phase.key,
            label = phase.title,
            percent = percent,
            topic = topic,
            meta = meta,
            suffix = "Last safe stage: ${lastSafeStage.ifBlank { "starting" }}"
        )
    }

    fun reportReady(topic: String): GTIMLiveStageStateV2141 = state(
        stageId = "V2140_REPORT_OUTPUT",
        label = "Compact dossier ready",
        percent = 100,
        topic = topic,
        meta = StageMeta(7, 7, "Report ready", "copy/export is available; repeat the same topic to deepen")
    )

    fun partialSaved(topic: String, reason: String): GTIMLiveStageStateV2141 = state(
        stageId = "V2141_PARTIAL_SAVED",
        label = "Partial dossier saved",
        percent = 100,
        topic = topic,
        meta = StageMeta(7, 7, "Partial saved", reason)
    )

    private fun state(
        stageId: String,
        label: String,
        percent: Int,
        topic: String,
        meta: StageMeta,
        suffix: String = ""
    ): GTIMLiveStageStateV2141 {
        val boundedPercent = percent.coerceIn(0, 100)
        val stepPrefix = if (meta.order > 0) "${meta.order}/${meta.total}" else "0/${meta.total}"
        val topicPart = topic.take(70).ifBlank { "research topic" }
        val subtitle = "$boundedPercent% · $stepPrefix · ${meta.subtitleAction}"
        val line = buildString {
            append(stepPrefix).append(" — ").append(label).append(" — ").append(boundedPercent).append("%")
            append("\nTitle now: ").append(meta.shortTitle)
            append("\nTopic: ").append(topicPart)
            append("\nBoundary: workflow progress, not evidence strength.")
            if (suffix.isNotBlank()) append("\n").append(suffix)
        }
        return GTIMLiveStageStateV2141(
            stageId = stageId,
            stepLabel = meta.shortTitle,
            percent = boundedPercent,
            headerTitle = "Immu DZ · ${meta.shortTitle}",
            subtitle = subtitle,
            stageLine = line,
            windowTitle = "Immu DZ · ${meta.shortTitle} · $boundedPercent%"
        )
    }

    fun toJson(state: GTIMLiveStageStateV2141): org.json.JSONObject = org.json.JSONObject()
        .put("version", VERSION)
        .put("requiredToken", REQUIRED_TOKEN)
        .put("stageId", state.stageId)
        .put("stepLabel", state.stepLabel)
        .put("percent", state.percent)
        .put("headerTitle", state.headerTitle)
        .put("subtitle", state.subtitle)
        .put("windowTitle", state.windowTitle)
        .put("claimLimit", CLAIM_LIMIT)
}
