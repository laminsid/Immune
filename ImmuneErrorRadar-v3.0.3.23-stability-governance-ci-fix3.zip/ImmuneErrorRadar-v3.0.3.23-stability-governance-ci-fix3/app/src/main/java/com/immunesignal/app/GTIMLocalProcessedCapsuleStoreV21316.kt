package com.immunesignal.app

import android.content.Context
import org.json.JSONObject

/**
 * Small local processed-capsule library for high-priority hard diseases.
 *
 * The in-memory registry makes unit tests and offline report rendering deterministic.
 * The asset loader keeps the same schema ready for future signed/offline capsule packs.
 */
object GTIMLocalProcessedCapsuleStoreV21316 {
    const val VERSION: String = "2.13.16-local-processed-capsule-injection"
    const val ASSET_INDEX_PATH: String = "gtim_capsules/index.json"

    private val localCapsules: List<GTIMProcessedCapsuleV21316> by lazy {
        listOf(
            capsule(
                capsuleId = "allergy_gse146170",
                accession = "GSE146170",
                domain = "allergy_type2_barrier",
                diseaseFamily = "allergy",
                species = "human",
                tissue = "airway_or_barrier_immune_context",
                comparators = listOf("allergic", "control", "severity_or_phenotype_if_available"),
                modules = listOf(
                    module("type2_threshold", listOf("IL4", "IL5", "IL13", "FCER1A", "TPSAB1", "CLC"), "candidate_type2_axis_separation"),
                    module("epithelial_barrier", listOf("FLG", "CLDN1", "KRT5", "KRT14"), "candidate_barrier_shift")
                ),
                limitations = listOf("module_panels_defined_not_validated_scores", "external_review_still_required_for_scientific_claim")
            ),
            capsule(
                capsuleId = "filovirus_gse45291",
                accession = "GSE45291",
                domain = "filovirus_viral_host_response",
                diseaseFamily = "ebola_filovirus",
                species = "human_or_model_context_requires_review",
                tissue = "host_response_immune_context",
                comparators = listOf("filovirus_exposure", "baseline_control", "severity_or_survival_if_available"),
                modules = listOf(
                    module("filovirus_interferon_timing", listOf("IFNB1", "ISG15", "MX1", "OAS1", "IRF7"), "candidate_interferon_timing_or_antagonism"),
                    module("endothelial_coagulation_injury", listOf("VWF", "ICAM1", "SELE", "F3", "SERPINE1"), "candidate_vascular_or_coagulation_injury_axis"),
                    module("cytokine_amplification", listOf("IL6", "TNF", "IL1B", "CXCL8"), "candidate_inflammatory_amplification")
                ),
                limitations = listOf("filovirus_subtype_fit_must_be_reviewed", "BDBV_specificity_not_assumed", "capsule_is_not_efficacy_or_treatment_evidence")
            ),
            capsule(
                capsuleId = "covid_gse152202",
                accession = "GSE152202",
                domain = "viral_interferon_cytokine",
                diseaseFamily = "covid_postviral",
                species = "human",
                tissue = "blood_or_pbmc_context",
                comparators = listOf("severe_covid", "mild_covid", "healthy_or_recovery_control"),
                modules = listOf(
                    module("interferon_coordination", listOf("IFIT1", "IFI44L", "STAT1", "IRF7", "ISG15"), "candidate_uncoordinated_or_delayed_interferon_response"),
                    module("cytokine_amplification", listOf("IL6", "TNF", "IL1B", "CXCL10"), "candidate_severity_linked_inflammatory_amplification")
                ),
                limitations = listOf("COVID_route_not_reused_for_other_viruses_without_domain_match", "no_patient_or_treatment_claim")
            ),
            capsule(
                capsuleId = "covid_gse152522",
                accession = "GSE152522",
                domain = "covid_postviral_interferon_tcell_dysregulation",
                diseaseFamily = "covid_postviral",
                species = "human",
                tissue = "blood_or_pbmc_context",
                comparators = listOf("covid_severe", "covid_mild_or_moderate", "healthy_control", "acute_or_recovery_if_labelled"),
                modules = listOf(
                    module("ifn_timing_signature", listOf("IFIT1", "IFI44L", "ISG15", "MX1", "OAS1", "IRF7", "STAT1"), "candidate_interferon_timing_or_uncoordinated_response"),
                    module("tcell_regulatory_cytotoxic_balance", listOf("CD4", "FOXP3", "IL2RA", "GZMB", "PRF1", "NKG7"), "candidate_regulatory_vs_cytotoxic_t_cell_imbalance"),
                    module("cytokine_endothelial_stress", listOf("IL6", "TNF", "CXCL10", "ICAM1", "VWF", "SELE"), "candidate_inflammatory_endothelial_route")
                ),
                limitations = listOf("metadata_labels_required_before_scoring", "processed_expression_or_matrix_route_required", "module_score_is_research_readiness_not_mechanism_proof")
            ),
            domainCapsule("inflammation_resolution_core", "inflammation_resolution", "hard_chronic_inflammation", listOf("IL6", "TNF", "IL1B", "NFKB1", "CRP", "PTGS2"), "candidate_chronic_inflammatory_tone_or_failed_resolution"),
            domainCapsule("rheumatoid_synovial_core", "rheumatoid_autoimmune_synovial_inflammation", "rheumatism_rheumatoid", listOf("TNF", "IL6", "IL1B", "CXCL13", "MMP3", "CCL2"), "candidate_synovial_inflammation_or_tissue_damage_axis"),
            domainCapsule("cancer_tme_core", "oncology_tumor_microenvironment", "cancer", listOf("CD274", "CXCL9", "CXCL10", "GZMB", "FOXP3", "VEGFA"), "candidate_tumor_immune_exclusion_or_checkpoint_axis"),
            domainCapsule("hiv_immune_activation_core", "hiv_aids_immune_activation", "hiv_aids", listOf("ISG15", "MX1", "OAS1", "CCR5", "CXCL10", "PDCD1"), "candidate_chronic_immune_activation_or_exhaustion_axis"),
            domainCapsule("diabetes_inflammation_core", "metabolic_inflammation", "diabetes", listOf("IL6", "TNF", "ADIPOQ", "LEP", "SLC2A4", "NLRP3"), "candidate_metabolic_inflammation_or_insulin_resistance_axis"),
            domainCapsule("hantavirus_endothelial_core", "viral_hantavirus_host_response", "hantavirus", listOf("IFIT1", "ISG15", "MX1", "ICAM1", "VWF", "IL6"), "candidate_interferon_endothelial_leak_axis"),
            domainCapsule("longevity_immune_age_core", "immune_age_longevity", "longevity_immune_age", listOf("IL6", "TNF", "NLRP3", "CDKN2A", "FOXP3", "ISG15", "SIRT1", "MTOR"), "candidate_inflammaging_immune_age_or_resilience_axis")
        )
    }

    fun allCapsules(): List<GTIMProcessedCapsuleV21316> = localCapsules

    fun getCapsuleByAccession(accession: String): GTIMProcessedCapsuleV21316? {
        val normalized = accession.trim().uppercase()
        if (normalized.isBlank()) return null
        return localCapsules.firstOrNull { it.accession.uppercase() == normalized || it.capsuleId.uppercase() == normalized }
    }

    fun getBestCapsuleForDomain(domain: String): GTIMProcessedCapsuleV21316? {
        val normalized = domain.trim()
        if (normalized.isBlank()) return null
        return localCapsules.firstOrNull { it.domain == normalized }
            ?: localCapsules.firstOrNull { it.domain.contains(normalized, ignoreCase = true) || normalized.contains(it.domain, ignoreCase = true) }
    }

    fun getPriorityCapsules(): List<GTIMProcessedCapsuleV21316> = localCapsules.filter {
        it.diseaseFamily in setOf("hard_chronic_inflammation", "rheumatism_rheumatoid", "allergy", "cancer", "ebola_filovirus", "hiv_aids", "covid_postviral", "diabetes", "hantavirus", "longevity_immune_age")
    }

    fun tryLoadAssetCapsule(context: Context, assetPath: String): GTIMProcessedCapsuleV21316? = try {
        val raw = context.assets.open(assetPath).bufferedReader().use { it.readText() }
        GTIMProcessedCapsuleV21316.fromJson(JSONObject(raw))
    } catch (_: Exception) {
        null
    }

    fun toIndexJson(): JSONObject = JSONObject()
        .put("version", VERSION)
        .put("claim_limit", GTIMProcessedCapsuleV21316.CLAIM_LIMIT)
        .put("capsules", org.json.JSONArray(localCapsules.map { capsule ->
            JSONObject()
                .put("capsule_id", capsule.capsuleId)
                .put("accession", capsule.accession)
                .put("domain", capsule.domain)
                .put("disease_family", capsule.diseaseFamily)
                .put("asset", "gtim_capsules/${capsule.capsuleId}.json")
        }))

    private fun capsule(
        capsuleId: String,
        accession: String,
        domain: String,
        diseaseFamily: String,
        species: String,
        tissue: String,
        comparators: List<String>,
        modules: List<GTIMModuleDefinitionV21316>,
        limitations: List<String>
    ): GTIMProcessedCapsuleV21316 = GTIMProcessedCapsuleV21316(
        capsuleId = capsuleId,
        accession = accession,
        domain = domain,
        diseaseFamily = diseaseFamily,
        species = species,
        tissue = tissue,
        comparators = comparators,
        sampleGroupsReady = true,
        matrixReady = true,
        modules = modules,
        limitations = limitations
    )

    private fun domainCapsule(
        capsuleId: String,
        domain: String,
        diseaseFamily: String,
        markers: List<String>,
        direction: String
    ): GTIMProcessedCapsuleV21316 = capsule(
        capsuleId = capsuleId,
        accession = capsuleId.uppercase(),
        domain = domain,
        diseaseFamily = diseaseFamily,
        species = "review_required",
        tissue = "disease_relevant_immune_context",
        comparators = listOf("case", "control", "severity_or_activity_if_available"),
        modules = listOf(module("core_${domain}_module", markers, direction)),
        limitations = listOf("domain_capsule_not_dataset_proof", "requires_topic_specific_dataset_or_external_validation")
    )

    private fun module(name: String, markers: List<String>, direction: String): GTIMModuleDefinitionV21316 = GTIMModuleDefinitionV21316(
        name = name,
        markers = markers,
        direction = direction,
        executionState = "marker_panel_defined_ready_for_local_preview_not_scored",
        evidenceLevel = "capsule_ready_not_proof"
    )
}
