package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.13.14 — Experimental claim relaxation mode.
 *
 * Purpose: during app experiments, allow the report to surface C2/C3-style and
 * medical/therapeutic/vaccine/efficacy hypotheses as explicitly unvalidated sandbox
 * previews. This removes over-strict report suppression without turning the app into
 * clinical advice, dosing, or patient management software.
 */
object GTIMExperimentalClaimRelaxationV21312 {
    // legacy_v21314_active_compat: VERSION: String = "2.13.14-final-generalized-route-coherence-unified"
    const val VERSION: String = "2.13.15-final-hypothesis-first-discovery-unified"
    const val ENGINE_VERSION: String = "v2.13.15-final-hypothesis-first-discovery-unified"
    const val MODE: String = "EXPERIMENTAL_SANDBOX_PREVIEW"
    const val CLAIM_LIMIT: String = "experimental_preview_allowed_not_patient_action_not_validated_proof"

    fun isEnabled(): Boolean = BuildConfig.DEBUG && RuntimeFeatureFlags.ENABLE_EXPERIMENTAL_CLAIM_RELAXATION_SANDBOX_V30320_P0

    fun toJson(report: JSONObject): JSONObject {
        val lift = report.optJSONObject("evidenceLiftGateV2139") ?: JSONObject()
        val route = GTIMFinalSurfaceDomainCoherenceGuardV21313.activeDomain(report)
        val subtype = GTIMDomainScopedClosureRendererV21315.normalizedSubtype(route, GTIMFinalSurfaceDomainCoherenceGuardV21313.activeSubtype(report))
        val canonical = GTIMFinalSurfaceDomainCoherenceGuardV21313.canonicalTarget(report)
        val previewLevels = JSONArray(listOf(
            "C0_ROUTE_PREVIEW",
            "C1_DISCOVERY_CANDIDATE_PREVIEW",
            "C2_COMPUTATIONAL_REPLICATION_PREVIEW",
            "C3_CROSS_DATASET_ROBUSTNESS_PREVIEW",
            "MEDICAL_MECHANISM_PREVIEW",
            "THERAPEUTIC_HYPOTHESIS_PREVIEW",
            "VACCINE_RESPONSE_HYPOTHESIS_PREVIEW",
            "EFFICACY_HYPOTHESIS_PREVIEW"
        ))
        val openWarnings = JSONArray(listOf(
            "preview_labels_are_for_app_testing_not_validated_truth",
            "do_not_use_for_patient_action_or_medical_decision",
            "dosing_or_administration_instructions_are_not_generated",
            "clinical_implementation_requires_external_validation"
        ))
        return JSONObject()
            .put("enabled", true)
            .put("releaseGated", true)
            .put("debugOnly", true)
            .put("version", VERSION)
            .put("engineVersion", ENGINE_VERSION)
            .put("state", "FINAL_EXPERIMENTAL_CLAIM_RELAXATION_READY")
            .put("mode", MODE)
            .put("activeDomain", route)
            .put("activeSubtype", subtype)
            .put("canonicalTarget", canonical)
            .put("c2PreviewAllowed", true)
            .put("c3PreviewAllowed", true)
            .put("medicalMechanismPreviewAllowed", true)
            .put("therapeuticHypothesisPreviewAllowed", true)
            .put("vaccineResponsePreviewAllowed", true)
            .put("efficacyHypothesisPreviewAllowed", true)
            .put("patientActionAllowed", false)
            .put("dosingProtocolAllowed", false)
            .put("clinicalImplementationAllowed", false)
            .put("validatedProofClaimAllowed", false)
            .put("previewLevels", previewLevels)
            .put("openRequirements", lift.optJSONArray("c2Blockers") ?: JSONArray())
            .put("warnings", openWarnings)
            .put("strictnessPolicy", "hypothesis_first_relaxed_for_C0_C1_C2_C3_preview; strict_against_evidence_upgrade_without_execution_and_patient_action_dosing_clinical_implementation_validated_proof")
            .put("routeLinkage", "legacy rails -> active-domain route discovery -> hypothesis-first discovery -> experimental preview policy -> final release/test locks")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        if (!obj.optBoolean("enabled", false)) return emptyList()
        return listOf(
            "Experimental claim relaxation mode",
            "State: ${obj.optString("state", "UNKNOWN")}; mode=${obj.optString("mode", MODE)}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}",
            "Preview allowed: C2=${obj.optBoolean("c2PreviewAllowed", false)}, C3=${obj.optBoolean("c3PreviewAllowed", false)}, medical/therapeutic/vaccine/efficacy=${obj.optBoolean("medicalMechanismPreviewAllowed", false)}.",
            "Still not allowed: patient_action=${obj.optBoolean("patientActionAllowed", false)}, dosing_protocol=${obj.optBoolean("dosingProtocolAllowed", false)}, clinical_implementation=${obj.optBoolean("clinicalImplementationAllowed", false)}, validated_proof=${obj.optBoolean("validatedProofClaimAllowed", false)}.",
            "Strictness: ${obj.optString("strictnessPolicy", "experimental preview relaxed; patient action and validated proof guarded")}",
            "Boundary: this is an app-testing sandbox mode; C2/C3 and medical/therapeutic/vaccine/efficacy language is hypothesis-preview only, not actionable care or validated science."
        )
    }
}
