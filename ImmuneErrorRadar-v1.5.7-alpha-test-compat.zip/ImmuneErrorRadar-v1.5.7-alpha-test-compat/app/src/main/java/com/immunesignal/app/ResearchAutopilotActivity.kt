package com.immunesignal.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * v1.1: migrated from Activity to ComponentActivity.
 *
 * Previously a raw Thread ran the research cycle, which:
 * - leaked Activity context on rotation/destroy
 * - risked ANRs if save happened during destroy
 * - had no structured cancellation
 *
 * v1.1 uses lifecycleScope.launch so the cycle is automatically cancelled
 * when the Activity is destroyed, and runs on Dispatchers.IO. The Stop
 * button cancels the Job. The deprecated startActivityForResult is replaced
 * by registerForActivityResult(ActivityResultContracts.OpenDocument()).
 */
class ResearchAutopilotActivity : ComponentActivity() {
    private lateinit var outputText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var reportInput: EditText
    private lateinit var steeringVariablesInput: EditText
    private lateinit var steeringFocusInput: EditText
    private lateinit var steeringRequiredInput: EditText
    private lateinit var steeringExcludeInput: EditText
    private lateinit var activeSteeringText: TextView
    private lateinit var stageText: TextView
    private lateinit var learningStatusText: TextView
    private lateinit var thinkingSessionText: TextView
    private lateinit var thinkSessionButton: Button
    private lateinit var continueThinkingButton: Button
    private lateinit var pauseThinkingButton: Button
    private lateinit var skipThinkingButton: Button
    private lateinit var stopThinkingButton: Button
    private lateinit var runButton: Button
    private lateinit var stopButton: Button
    private lateinit var copyBriefButton: Button
    private lateinit var exportPdfButton: Button
    private var latestReport: JSONObject? = null
    @Volatile private var stopRequested: Boolean = false
    @Volatile private var running: Boolean = false
    private var researchJob: Job? = null
    private var thinkingJob: Job? = null
    private var learningSessionManager: LearningSessionManager? = null

    // v1.1: ActivityResultContracts replaces deprecated onActivityResult.
    // Registered before onStart per the contract requirement.
    private val openReportLauncher: ActivityResultLauncher<Array<String>> =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) importReportUri(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_research_autopilot)
        outputText = findViewById(R.id.autopilotOutputText)
        progress = findViewById(R.id.autopilotProgress)
        reportInput = findViewById(R.id.manualReportInput)
        steeringVariablesInput = findViewById(R.id.steeringVariablesInput)
        steeringFocusInput = findViewById(R.id.steeringFocusInput)
        steeringRequiredInput = findViewById(R.id.steeringRequiredInput)
        steeringExcludeInput = findViewById(R.id.steeringExcludeInput)
        activeSteeringText = findViewById(R.id.activeSteeringText)
        stageText = findViewById(R.id.autopilotStageText)
        learningStatusText = findViewById(R.id.autopilotLearningStatusText)
        thinkingSessionText = findViewById(R.id.thinkingSessionText)
        thinkSessionButton = findViewById(R.id.thinkSessionButton)
        continueThinkingButton = findViewById(R.id.continueThinkingButton)
        pauseThinkingButton = findViewById(R.id.pauseThinkingButton)
        skipThinkingButton = findViewById(R.id.skipThinkingButton)
        stopThinkingButton = findViewById(R.id.stopThinkingButton)
        runButton = findViewById(R.id.runAutopilotButton)
        stopButton = findViewById(R.id.stopAutopilotButton)
        copyBriefButton = findViewById(R.id.copyBriefReportButton)
        exportPdfButton = findViewById(R.id.exportDiscoveryPdfButton)

        runButton.setOnClickListener { runCycle() }
        stopButton.setOnClickListener { stopResearch() }
        thinkSessionButton.setOnClickListener { startThinkingSession(SessionType.INCREMENTAL) }
        continueThinkingButton.setOnClickListener { startThinkingSession(SessionType.RESUMED) }
        pauseThinkingButton.setOnClickListener { pauseThinkingSession() }
        skipThinkingButton.setOnClickListener { skipThinkingPhase() }
        stopThinkingButton.setOnClickListener { stopThinkingSession() }
        findViewById<Button>(R.id.saveSteeringButton).setOnClickListener { saveSteering() }
        findViewById<Button>(R.id.clearSteeringButton).setOnClickListener { clearSteering() }
        findViewById<Button>(R.id.importPastedReportButton).setOnClickListener { importPastedReport() }
        findViewById<Button>(R.id.importReportFileButton).setOnClickListener { openReportFile() }
        copyBriefButton.setOnClickListener { copyBriefReport() }
        exportPdfButton.setOnClickListener { exportPdf() }
        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
        updateRunningUi(false)
        refreshActiveSteering()
        renderLatestReports()
        if (!RuntimeFeatureFlags.ENABLE_LEARNING_SESSION_UI) {
            thinkSessionButton.isEnabled = false
            continueThinkingButton.isEnabled = false
            pauseThinkingButton.isEnabled = false
            skipThinkingButton.isEnabled = false
            stopThinkingButton.isEnabled = false
            thinkingSessionText.text = "Thinking sessions are disabled by runtime flag. Core research search remains available."
        }
    }

    override fun onDestroy() {
        // v1.1: ensure background work stops if user destroys the screen.
        researchJob?.cancel()
        researchJob = null
        thinkingJob?.cancel()
        thinkingJob = null
        latestReport = null
        super.onDestroy()
    }

    private fun runCycle() {
        if (running) {
            Toast.makeText(this, "Research is already running.", Toast.LENGTH_SHORT).show()
            return
        }
        learningSessionManager?.pauseSession()
        (learningSessionManager ?: LearningSessionManager(this).also { learningSessionManager = it })
            .markNewSearchBoundary("new_search_started_from_ui")
        thinkingJob?.cancel()
        thinkingJob = null
        stopRequested = false
        running = true
        updateRunningUi(true)
        val steering = ResearchKnowledgeStore(this).readActiveSteering()
        stageText.text = "1/3 Searching evidence lanes…"
        learningStatusText.text = "The engine is querying public research and dataset signals. Learning is saved only after evidence gates run."
        outputText.text = "Cycle started\n\n1. Searching public research + dataset accessions\n2. Judging evidence, contradiction, and controls\n3. Saving learning gates and next action\n" +
            (if (steering != null) "\nSteering active: ${steering.variables.joinToString(", ")}\nFocus: ${steering.focusQuestion.ifBlank { "connect variables and look for hidden bridges" }}\n" else "\nNo steering active. Autonomous mode chooses Explore + Deepen + Challenge lanes by itself.\n")
        // v1.1: lifecycleScope auto-cancels on Activity destroy. Dispatchers.IO
        // is appropriate for blocking HTTP. UI updates use withContext(Main).
        researchJob = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val report = ResearchAutopilot(this@ResearchAutopilotActivity).runCycle(
                    shouldStop = { stopRequested },
                    limits = ResearchRunLimits(
                        maxSearchMillis = 10L * 60L * 1000L,
                        maxLearningMillis = 15L * 60L * 1000L,
                        maxQueries = 6,
                        maxResultsPerQuery = 12,
                        fetchAbstracts = false,
                        enableSelectiveAbstracts = true,
                        maxAbstractsPerCycle = 3
                    )
                )
                val json = ResearchJsonCodec.reportToJson(report)
                ResearchKnowledgeStore(this@ResearchAutopilotActivity).saveReport(json)
                withContext(Dispatchers.Main) {
                    latestReport = json
                    running = false
                    updateRunningUi(false)
                    stageText.text = "3/3 Learning saved"
                    learningStatusText.text = learningStatusLine(json)
                    outputText.text = renderResearchBoard(json) + "\n\nFull details are available via Export report."
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    running = false
                    updateRunningUi(false)
                    stageText.text = "Cycle failed"
                    learningStatusText.text = "No learning was saved from this failed run."
                    outputText.text = "Research cycle failed.\n\n${e.message}\n\nCheck internet connection, NCBI availability, or import a text report and run again."
                }
            }
        }
    }

    private fun startThinkingSession(sessionType: SessionType) {
        if (!RuntimeFeatureFlags.ENABLE_LEARNING_SESSION_UI) {
            Toast.makeText(this, "Thinking sessions are disabled.", Toast.LENGTH_SHORT).show()
            return
        }
        if (thinkingJob?.isActive == true) {
            Toast.makeText(this, "Thinking session is already running.", Toast.LENGTH_SHORT).show()
            return
        }
        val manager = LearningSessionManager(this)
        learningSessionManager = manager
        val progressBroadcaster = ProgressBroadcaster()
        val executor = PhaseExecutor(this, manager, progressBroadcaster)
        val initialSession = manager.startSession(sessionType = sessionType, timeLimit = RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS)
        thinkingSessionText.text = ProgressTracker.generateUIReport(initialSession)

        progressBroadcaster.addListener(object : ProgressListener {
            override fun onProgressUpdate(progress: ProgressUpdate) {
                runOnUiThread {
                    learningSessionManager?.getCurrentSession()?.let { session ->
                        thinkingSessionText.text = ProgressTracker.generateUIReport(session)
                    }
                }
            }

            override fun onPhaseComplete(phaseName: String, findings: String) {
                runOnUiThread {
                    learningSessionManager?.getCurrentSession()?.let { session ->
                        thinkingSessionText.text = ProgressTracker.generateUIReport(session) + "\n\n$phaseName: $findings"
                    }
                }
            }

            override fun onSessionComplete(insights: LearningInsights) {
                runOnUiThread {
                    learningSessionManager?.getCurrentSession()?.let { session ->
                        thinkingSessionText.text = ProgressTracker.generateUIReport(session) +
                            "\n\nSession completed. Insights are checkpointed locally.\n" +
                            "Claim limit: learning_session_not_biological_proof." +
                            "\n" + renderSessionMetrics()
                    }
                }
            }
        })

        thinkingJob = lifecycleScope.launch(Dispatchers.Default) {
            val history = buildLearningReportHistory()
            executor.executeAllPhases(
                session = initialSession,
                reportHistory = history,
                onComplete = { /* UI receives progress through broadcaster. */ }
            )
        }
    }

    private fun pauseThinkingSession() {
        learningSessionManager?.pauseSession()
        thinkingJob?.cancel()
        thinkingJob = null
        val session = learningSessionManager?.getCurrentSession()
        thinkingSessionText.text = if (session != null) {
            ProgressTracker.generateUIReport(session) + "\n\nPaused. Checkpoint saved."
        } else {
            "No thinking session to pause."
        }
    }

    private fun skipThinkingPhase() {
        if (!RuntimeFeatureFlags.ENABLE_LEARNING_SESSION_UI) {
            Toast.makeText(this, "Thinking sessions are disabled.", Toast.LENGTH_SHORT).show()
            return
        }
        val manager = learningSessionManager ?: LearningSessionManager(this).also { learningSessionManager = it }
        val skippedSession = manager.skipCurrentOrNextPhase("user_skipped_phase_from_ui")
        if (skippedSession == null) {
            thinkingSessionText.text = "No thinking session or checkpoint available to skip. Run Think first."
            return
        }
        thinkingJob?.cancel()
        thinkingJob = null
        val pending = skippedSession.phases.any { it.status != PhaseStatus.COMPLETED }
        thinkingSessionText.text = ProgressTracker.generateUIReport(skippedSession) +
            "\n\nCurrent phase skipped and checkpoint saved." +
            if (pending) "\nContinuing from the next pending phase…" else "\nNo pending phases remain."
        if (pending && skippedSession.status != SessionStatus.COMPLETED) {
            startThinkingSession(SessionType.RESUMED)
        }
    }

    private fun stopThinkingSession() {
        thinkingJob?.cancel()
        thinkingJob = null
        learningSessionManager?.clearCheckpoint()
        thinkingSessionText.text = "Thinking session stopped. Checkpoint cleared."
    }

    private fun renderSessionMetrics(): String {
        val metrics = learningSessionManager?.getSessionMetrics() ?: return "Session metrics: not available yet."
        return buildString {
            append("Session metrics: progress=")
            append(metrics.progressPerPhase.values.average().takeIf { !it.isNaN() }?.toInt() ?: 0)
            append("%; checkpoints=")
            append(metrics.checkpointsCreated)
            append("; items=")
            append(metrics.itemsProcessed)
            append("/")
            append(metrics.totalItems)
            append("; errors=")
            append(metrics.errorCount)
            append("; resume-count=")
            append(metrics.resumeCount)
            append("; claim-limit=")
            append(metrics.claimLimit)
            learningSessionManager?.getCheckpointIntegrityReport()?.let { integrity ->
                append("\nCheckpoint integrity: ")
                append(if (integrity.optBoolean("ok", false)) "PASS" else "WATCH")
            }
            learningSessionManager?.getSessionReport()?.handoff?.let { handoff ->
                append("\n")
                append(handoff.compactSummary())
            }
            learningSessionManager?.getSessionHistorySummary(3)?.let { history ->
                append("\nRecent session history:\n")
                append(history)
            }
        }
    }

    private fun buildLearningReportHistory(): List<ResearchReportV3> {
        val latest = latestReport?.let { reportV3FromCycleJson(it) }
        val stored = ResearchKnowledgeStore(this).readLatestReports(12).mapNotNull { line ->
            runCatching { reportV3FromCycleJson(JSONObject(line)) }.getOrNull()
        }
        return (listOfNotNull(latest) + stored).distinctBy { it.hypothesis + it.newUsefulLead }.take(12)
    }

    private fun reportV3FromCycleJson(cycleJson: JSONObject): ResearchReportV3 {
        val v3 = cycleJson.optJSONObject("reportV3") ?: cycleJson
        return ResearchReportV3(
            cycleResult = v3.optString("cycleResult", "Imported cycle"),
            newUsefulLead = v3.optString("newUsefulLead", "No lead extracted"),
            hypothesisChanged = v3.optString("hypothesisChanged", "None"),
            whyItMatters = v3.optString("whyItMatters", "No explanation extracted"),
            nextAutonomousMove = v3.optString("nextAutonomousMove", "Run next research cycle"),
            doNotBelieveYet = v3.optString("doNotBelieveYet", "No hypothesis is proven."),
            technicalPointer = v3.optString("technicalPointer", "Imported from saved cycle JSON."),
            hypothesis = v3.optString("hypothesis", "No hypothesis evaluated yet."),
            supportingEvidence = v3.optString("supportingEvidence", "No supporting evidence evaluated yet."),
            counterEvidenceOrContradiction = v3.optString("counterEvidenceOrContradiction", "No contradiction search evaluated yet."),
            whatWeDoNotBelieveYet = v3.optString("whatWeDoNotBelieveYet", "No hypothesis is proven."),
            integrityStatus = v3.optString("integrityStatus", "UNVALIDATED")
        )
    }




    private fun saveSteering() {
        val variables = steeringVariablesInput.text.toString().trim()
        if (variables.length < 2) {
            Toast.makeText(this, "Enter at least one research variable.", Toast.LENGTH_SHORT).show()
            return
        }
        val profile = ResearchKnowledgeStore(this).saveActiveSteering(
            variablesText = variables,
            focusQuestion = steeringFocusInput.text.toString(),
            requiredTermsText = steeringRequiredInput.text.toString(),
            excludedTermsText = steeringExcludeInput.text.toString()
        )
        refreshActiveSteering()
        learningStatusText.text = "Steering saved. The next cycle will still pass evidence and contradiction gates."
        outputText.text = "Research steering saved.\n\nVariables: ${profile.variables.joinToString(", ")}\nAxes: ${profile.inferredAxes.joinToString(", ").ifBlank { "none yet" }}\n\nPress Search + learn. Steering accelerates one idea without disabling autonomous exploration."
    }

    private fun clearSteering() {
        ResearchKnowledgeStore(this).clearActiveSteering()
        steeringVariablesInput.setText("")
        steeringFocusInput.setText("")
        steeringRequiredInput.setText("")
        steeringExcludeInput.setText("")
        refreshActiveSteering()
        learningStatusText.text = "Steering cleared. Autonomous research remains active."
        outputText.text = "Research steering cleared. Autonomous Researcher mode remains active and will choose its own search lanes."
    }

    private fun refreshActiveSteering() {
        val profile = ResearchKnowledgeStore(this).readActiveSteering()
        if (profile == null) {
            activeSteeringText.text = "Active steering: none. Autonomous Researcher mode is active; steering is optional if you want to accelerate a specific idea."
            return
        }
        activeSteeringText.text = "Active steering:\n" +
            "Variables: ${profile.variables.joinToString(", ")}\n" +
            "Focus: ${profile.focusQuestion.ifBlank { "connect variables and find non-obvious mechanisms" }}\n" +
            "Required: ${profile.requiredTerms.joinToString(", ").ifBlank { "none" }}\n" +
            "Excluded: ${profile.excludedTerms.joinToString(", ").ifBlank { "none" }}\n" +
            "Inferred axes: ${profile.inferredAxes.joinToString(", ").ifBlank { "none" }}"
    }

    private fun stopResearch() {
        if (!running) {
            Toast.makeText(this, "No active research cycle.", Toast.LENGTH_SHORT).show()
            return
        }
        stopRequested = true
        // v1.1: also cancel the coroutine for fast hard-stop on long-tail HTTP.
        researchJob?.cancel()
        stageText.text = "Stopping…"
        learningStatusText.text = "Stop requested. Current network request will finish or timeout."
        outputText.text = outputText.text.toString() + "\n\nStop requested. Current network request will finish or timeout, then the report will be closed."
    }

    private fun updateRunningUi(isRunning: Boolean) {
        progress.visibility = if (isRunning) View.VISIBLE else View.GONE
        if (!isRunning && stageText.text.toString().contains("Searching")) {
            stageText.text = "Idle — ready to search"
        }
        runButton.isEnabled = !isRunning
        stopButton.isEnabled = isRunning
        exportPdfButton.isEnabled = !isRunning
        copyBriefButton.isEnabled = !isRunning
    }

    private fun importPastedReport() {
        val text = reportInput.text.toString().trim()
        if (text.length < 20) {
            Toast.makeText(this, "Paste a longer report/note first.", Toast.LENGTH_SHORT).show()
            return
        }
        val signal = ResearchKnowledgeStore(this).saveImportedReport("Pasted report", text)
        reportInput.setText("")
        learningStatusText.text = "Imported note saved as optional evidence context."
        outputText.text = "Imported report saved.\n\nDetected axes: ${signal.matchedAxes.joinToString(", ").ifBlank { "none" }}\nKeywords: ${signal.extractedKeywords.joinToString(", ").ifBlank { "none" }}\n\nRun research cycle. The autonomous planner will use this as one optional clue, not as the only direction."
    }

    private fun openReportFile() {
        // v1.1: ActivityResultContracts.OpenDocument launcher.
        // The MIME type list is passed as the launcher's input.
        openReportLauncher.launch(arrayOf("text/plain", "text/csv", "application/json"))
    }

    private fun importReportUri(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (text.length < 20) {
                Toast.makeText(this, "File is empty or too short.", Toast.LENGTH_LONG).show()
                return
            }
            val signal = ResearchKnowledgeStore(this).saveImportedReport("Imported file", text)
            learningStatusText.text = "Imported file saved as optional evidence context."
            outputText.text = "Imported file saved.\n\nDetected axes: ${signal.matchedAxes.joinToString(", ").ifBlank { "none" }}\nKeywords: ${signal.extractedKeywords.joinToString(", ").ifBlank { "none" }}\nPreview: ${signal.preview}\n\nRun research cycle. The autonomous planner will use this file as one optional clue, not as the only direction."
        } catch (e: Exception) {
            Toast.makeText(this, "Could not import file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderLatestReports() {
        val latest = ResearchKnowledgeStore(this).readLatestReports(1).firstOrNull()
        if (latest != null) {
            latestReport = JSONObject(latest)
            stageText.text = "Latest learning loaded"
            learningStatusText.text = learningStatusLine(latestReport!!)
            outputText.text = renderResearchBoard(latestReport!!) + "\n\nFull details are available via Export report."
        } else {
            stageText.text = "Idle — ready to search"
            learningStatusText.text = "Learning loop: no current report loaded."
            outputText.text = "Research Autopilot is ready.\n\nActive engine: ${EngineRuntimeStatus.ACTIVE_ENGINE_VERSION}\nExecution guard: ON\n\nPrimary flow:\n• Search public research and dataset signals\n• Judge evidence, contradictions, and controls\n• Learn by writing incidents, gates, and next actions\n\nNo diagnosis, no treatment, no causality proof."
        }
    }

    private fun learningStatusLine(report: JSONObject): String {
        val runtime = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val exec = report.optJSONObject("executionLockReport") ?: JSONObject()
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incident = learning.optJSONObject("incident") ?: JSONObject()
        val causes = jsonArrayToList(incident.optJSONArray("rootCauses"))
        val state = runtime.optString("researchState", "UNKNOWN")
        val lock = exec.optString("status", "UNKNOWN")
        val forager = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val foragerState = forager.optString("state", "NOT_RUN")
        return "Search state: $state • Execution lock: $lock • Forager: $foragerState • Learned cause: ${causes.joinToString(", ").ifBlank { "none yet" }}"
    }

    private fun renderResearchBoard(report: JSONObject): String {
        val runtime = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val exec = report.optJSONObject("executionLockReport") ?: JSONObject()
        val v3 = report.optJSONObject("reportV3") ?: JSONObject()
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incident = learning.optJSONObject("incident") ?: JSONObject()
        val readiness = learning.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        val datasets = report.optJSONArray("datasetCandidatesV137") ?: JSONArray()
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        val gates = learning.optJSONArray("preventiveGates") ?: JSONArray()
        val cooldowns = learning.optJSONArray("laneCooldowns") ?: JSONArray()
        val rootCauses = jsonArrayToList(incident.optJSONArray("rootCauses"))
        val forcedQueries = jsonArrayToList(runtime.optJSONArray("forcedQueries"))
        val enforced = jsonArrayToList(exec.optJSONArray("enforcedActions"))
        val forager = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val foragerSources = jsonArrayToList(forager.optJSONArray("sourceFamiliesAttempted"))
        val foragerCandidates = forager.optJSONArray("candidates") ?: JSONArray()

        val lines = mutableListOf<String>()
        lines += "RESEARCH COMMAND BOARD"
        lines += "Active engine: ${runtime.optString("engineVersion", EngineRuntimeStatus.ACTIVE_ENGINE_VERSION)}"
        lines += "Execution lock: ${exec.optString("status", "UNKNOWN")}"
        lines += "Research state: ${runtime.optString("researchState", "UNKNOWN")}"
        lines += ""
        lines += "1) Search"
        lines += "• Effective search: ${runtime.optInt("effectiveMaxQueries", 0)} queries × ${runtime.optInt("effectiveResultsPerQuery", 0)} results"
        lines += "• Runtime failover: ${runtime.optBoolean("runtimeFailoverApplied", false)}"
        lines += "• Dataset-first forager: ${forager.optString("state", "NOT_RUN")} | sources: ${foragerSources.joinToString(", ").ifBlank { "none" }}"
        lines += "• New sources: ${delta.optInt("newSourcesSaved", 0)} | Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        if (forcedQueries.isNotEmpty()) {
            lines += "• Forced query path: ${forcedQueries.take(2).joinToString(" | ")}"
        }
        lines += ""
        lines += "2) Evidence"
        lines += "• Cycle: ${v3.optString("cycleResult", "Not evaluated")}" 
        lines += "• Dataset candidates: ${datasets.length()} | Direct forager candidates: ${foragerCandidates.length()} | Evidence objects: ${evidenceObjects.length()}"
        lines += "• Contradiction: ${v3.optString("counterEvidenceOrContradiction", "Not evaluated").take(160)}"
        lines += ""
        lines += "3) Learning"
        lines += "• Root cause: ${rootCauses.joinToString(", ").ifBlank { "none yet" }}"
        lines += "• Forager learning block: ${forager.optString("blockedLearningReason", "none")}"
        lines += "• Preventive gates: ${gates.length()} | Lane cooldowns: ${cooldowns.length()}"
        lines += "• Discovery readiness: ${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")}" 
        if (enforced.isNotEmpty()) lines += "• Enforced: ${enforced.take(2).joinToString(" | ")}" 
        lines += ""
        lines += "Next action"
        lines += "• ${v3.optString("nextAutonomousMove", "Run the next autonomous research cycle.")}" 
        lines += ""
        lines += "Boundary: research leads only. No diagnosis or treatment advice."
        return lines.joinToString("\n")
    }

    private fun renderBriefReport(report: JSONObject): String {
        val v3 = report.optJSONObject("reportV3")
        if (v3 != null && v3.optString("cycleResult").isNotBlank()) {
            return listOf(
                "AUTONOMOUS DISCOVERY REPORT",
                "Active engine: ${(report.optJSONObject("runtimeStatus") ?: JSONObject()).optString("engineVersion", "unknown")}",
                "Execution lock: ${(report.optJSONObject("executionLockReport") ?: JSONObject()).optString("status", "UNKNOWN")}",
                "Research state: ${(report.optJSONObject("runtimeStatus") ?: JSONObject()).optString("researchState", "UNKNOWN")}",
                "Cycle result: ${v3.optString("cycleResult")}",
                "Hypothesis: ${v3.optString("hypothesis", "No active hypothesis passed the evidence gates.")}",
                "Supporting evidence: ${v3.optString("supportingEvidence", v3.optString("newUsefulLead"))}",
                "Counter-evidence / contradiction: ${v3.optString("counterEvidenceOrContradiction", "No contradiction section available.")}",
                "What we do not believe yet: ${v3.optString("whatWeDoNotBelieveYet", v3.optString("doNotBelieveYet"))}",
                "Hypothesis changed: ${v3.optString("hypothesisChanged")}",
                "Why it matters: ${v3.optString("whyItMatters")}",
                "Next autonomous move: ${v3.optString("nextAutonomousMove")}",
                "Integrity lock: ${v3.optString("integrityStatus", "UNKNOWN")}"
            ).toMutableList().apply {
                val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
                val incident = learning.optJSONObject("incident") ?: JSONObject()
                val readiness = learning.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
                add("Learning OS: ${jsonArrayToList(incident.optJSONArray("rootCauses")).joinToString(", ").ifBlank { "no incident" }}")
                add("Discovery readiness: ${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")}")
                val gate = (learning.optJSONArray("preventiveGates") ?: JSONArray()).optJSONObject(0)
                if (gate != null) add("Preventive gate: ${gate.optString("gateId")} → ${gate.optString("forcedNextIntent")}")
                val reasoning = report.optJSONObject("reasoningReport") ?: JSONObject()
                val meaning = reasoning.optString("interpretedMeaning", "")
                val nextReasoned = reasoning.optString("nextReasonedMove", "")
                if (meaning.isNotBlank()) {
                    add("")
                    add("Reasoning:")
                    add("• $meaning")
                }
                if (nextReasoned.isNotBlank()) add("• Next reasoned move: $nextReasoned")
            }.joinToString("\n")
        }
        if ((report.optJSONArray("hypothesisObjects")?.length() ?: 0) > 0) {
            return ResearchReportTemplateV2.renderBrief(report)
        }
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val findings = report.optJSONArray("findings") ?: JSONArray()
        val top = findings.optJSONObject(0)
        val lines = mutableListOf<String>()
        lines += "SHORT DISCOVERY REPORT"
        lines += "Generated: ${report.optString("createdAtText", "")}"
        lines += "Stop reason: ${report.optString("stopReason", "completed")}"
        lines += "New sources: ${delta.optInt("newSourcesSaved", findings.length())} | Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        lines += "DNA/RNA signals: ${delta.optInt("dnaRnaSignals", 0)} | Manual reports used: ${delta.optInt("manualReportSignalsUsed", 0)}"
        lines += "Steered queries: ${delta.optInt("steeredQueriesGenerated", 0)}"
        val plan = report.optJSONObject("autonomousPlan") ?: JSONObject()
        lines += "Autonomous mode: ${plan.optString("strategy", "explore_deepen_challenge")}"
        val cards = report.optJSONArray("hypothesisRankCards") ?: JSONArray()
        val topCard = cards.optJSONObject(0)
        if (topCard != null) {
            lines += "Top hypothesis: ${topCard.optString("status")} • ${topCard.optInt("overallScore")}/100"
        }
        lines += ""
        lines += "Top new lead:"
        if (top != null) {
            lines += "• ${top.optString("title")}"
            lines += "• ${top.optString("bridgeSignal")}"
            lines += "• Novelty: ${top.optInt("noveltyScore")}/100"
            val ev = top.optJSONObject("evidence") ?: JSONObject()
            val ca = top.optJSONObject("causality") ?: JSONObject()
            lines += "• Evidence: ${ev.optInt("evidenceQualityScore", 0)}/100 ${ev.optString("speciesClass", "unknown")}/${ev.optString("studyDesign", "unknown")}"
            lines += "• Causality: ${ca.optInt("causalityScore", 0)}/100"
        } else {
            val skipped = delta.optInt("repeatedSourcesSkipped", 0)
            if (skipped > 0) {
                val plan = report.optJSONObject("autonomousPlan") ?: JSONObject()
                lines += "• No useful new source saved. $skipped PubMed IDs were already known."
                lines += "• Next autonomous strategy: ${plan.optString("nextStrategyIfNoUsefulSource", "rotate to dataset/omics/contradiction search")}."
            } else {
                lines += "• No useful new source saved. The autonomous planner will change lanes next cycle; optional steering/import can accelerate it."
            }
        }
        lines += ""
        lines += "Main emerging link:"
        val links = report.optJSONArray("emergentLinks")
        lines += "• " + (links?.optString(0) ?: "None")
        lines += ""
        lines += "Next question:"
        val qs = report.optJSONArray("nextQuestions")
        lines += "• " + (qs?.optString(0) ?: "Which public dataset has trigger, immune-response axis, and outcome labels?")
        return lines.joinToString("\n")
    }

    private fun renderReportPreview(report: JSONObject): String {
        val lines = mutableListOf<String>()
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val findings = report.optJSONArray("findings") ?: JSONArray()
        val summary = report.optJSONObject("researchStateSummary") ?: JSONObject()
        val v3 = report.optJSONObject("reportV3") ?: JSONObject()
        val pivot = report.optJSONObject("resilienceDecision") ?: JSONObject()
        val datasets = report.optJSONArray("datasetCandidatesV137") ?: JSONArray()
        lines += "Result"
        val runtime = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val execLock = report.optJSONObject("executionLockReport") ?: JSONObject()
        lines += "• Active engine: ${runtime.optString("engineVersion", "unknown")}"
        lines += "• Execution lock: ${execLock.optString("status", "UNKNOWN")}"
        lines += "• Research state: ${runtime.optString("researchState", "UNKNOWN")}"
        lines += "• Effective search: ${runtime.optInt("effectiveMaxQueries", 0)} queries × ${runtime.optInt("effectiveResultsPerQuery", 0)} PubMed IDs"
        lines += "• Runtime failover: ${runtime.optBoolean("runtimeFailoverApplied", false)}"
        val foragerPreview = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        lines += "• Dataset-first forager: ${foragerPreview.optString("state", "NOT_RUN")}"
        lines += "• Cycle: ${v3.optString("cycleResult", if (findings.length() > 0) "Useful delta" else "No useful delta")}"
        lines += "• Integrity lock: ${v3.optString("integrityStatus", "UNKNOWN")}"
        lines += "• Hypothesis: ${v3.optString("hypothesis", "No active hypothesis.")}"
        lines += "• Counter-evidence: ${v3.optString("counterEvidenceOrContradiction", "Not evaluated.")}"
        lines += "• New useful sources: ${delta.optInt("newSourcesSaved", findings.length())}"
        lines += "• Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incident = learning.optJSONObject("incident") ?: JSONObject()
        val readiness = learning.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        val rootCausesText = jsonArrayToList(incident.optJSONArray("rootCauses")).joinToString(", ").ifBlank { "none" }
        lines += "• Dataset candidates: ${datasets.length()}"
        lines += "• Evidence objects: ${evidenceObjects.length()}"
        lines += "• Learning root cause: $rootCausesText"
        lines += "• Discovery readiness: ${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")}"
        lines += "• Discovery state: ${summary.optString("discoveryState", "Off")}"
        lines += "• Bias risk: ${summary.optString("biasRiskState", "Normal")}"
        val pivotType = pivot.optString("pivotType", "NO_PIVOT")
        if (pivotType != "NO_PIVOT") lines += "• Pivot: $pivotType → ${pivot.optString("nextIntent", "change_strategy")}"
        val reasoning = report.optJSONObject("reasoningReport") ?: JSONObject()
        lines += ""
        lines += "Reasoning"
        lines += "• " + reasoning.optString("observation", "No reasoning observation yet.")
        lines += "• " + reasoning.optString("interpretedMeaning", "No interpretation yet.")
        lines += ""
        lines += "Action"
        lines += "• " + reasoning.optString("nextReasonedMove", v3.optString("nextAutonomousMove", "Run the next autonomous cycle."))
        return lines.joinToString("\n")
    }

    private fun renderReport(report: JSONObject): String {
        val lines = mutableListOf<String>()
        lines += "Research Autopilot Discovery Report"
        lines += "Generated: " + report.optString("createdAtText", "")
        lines += "Completed: " + report.optString("completedAtText", "")
        lines += "Stop reason: " + report.optString("stopReason", "completed")
        lines += "Search ms: " + report.optLong("searchDurationMillis") + " | Learning ms: " + report.optLong("learningDurationMillis")
        val runtimeFull = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val execFull = report.optJSONObject("executionLockReport") ?: JSONObject()
        lines += ""
        lines += "Active engine"
        lines += "• Version: ${runtimeFull.optString("engineVersion", "unknown")}"
        lines += "• State: ${runtimeFull.optString("researchState", "UNKNOWN")}"
        lines += "• Modules: ${jsonArrayToList(runtimeFull.optJSONArray("activeModules")).joinToString(", ").ifBlank { "none" }}"
        lines += "• Effective search: ${runtimeFull.optInt("effectiveMaxQueries", 0)} queries × ${runtimeFull.optInt("effectiveResultsPerQuery", 0)} PubMed IDs"
        lines += "• Runtime failover applied: ${runtimeFull.optBoolean("runtimeFailoverApplied", false)}"
        val foragerFull = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        lines += "• Dataset-first forager: ${foragerFull.optString("state", "NOT_RUN")} | ${jsonArrayToList(foragerFull.optJSONArray("sourceFamiliesAttempted")).joinToString(", ").ifBlank { "none" }}"
        lines += "• Execution lock: ${execFull.optString("status", "UNKNOWN")}"
        lines += "• Enforced actions: ${jsonArrayToList(execFull.optJSONArray("enforcedActions")).joinToString("; ").ifBlank { "none" }}"
        val steering = report.optJSONObject("activeSteeringProfile")
        lines += ""
        lines += "Research steering"
        if (steering == null) {
            lines += "• None used."
        } else {
            lines += "• Variables: " + jsonArrayToList(steering.optJSONArray("variables")).joinToString(", ").ifBlank { "none" }
            lines += "• Focus: " + steering.optString("focusQuestion", "")
            lines += "• Required: " + jsonArrayToList(steering.optJSONArray("requiredTerms")).joinToString(", ").ifBlank { "none" }
            lines += "• Excluded: " + jsonArrayToList(steering.optJSONArray("excludedTerms")).joinToString(", ").ifBlank { "none" }
            lines += "• Inferred axes: " + jsonArrayToList(steering.optJSONArray("inferredAxes")).joinToString(", ").ifBlank { "none" }
        }
        lines += ""
        lines += "Autonomous research plan"
        val plan = report.optJSONObject("autonomousPlan") ?: JSONObject()
        lines += "• Mode: ${plan.optString("mode", "autonomous_researcher")}"
        lines += "• Strategy: ${plan.optString("strategy", "explore_deepen_challenge")}"
        lines += "• Next if no useful source: ${plan.optString("nextStrategyIfNoUsefulSource", "rotate strategy")}" 
        val lanes = plan.optJSONArray("lanes") ?: JSONArray()
        if (lanes.length() == 0) {
            lines += "• No autonomous lanes recorded."
        } else {
            for (i in 0 until lanes.length()) {
                val lane = lanes.optJSONObject(i) ?: continue
                lines += "• ${lane.optString("laneType")}: ${lane.optString("label")}"
                lines += "  Reason: ${lane.optString("reason")}"
            }
        }
        lines += ""
        lines += "Knowledge delta"
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        lines += "• New sources saved: ${delta.optInt("newSourcesSaved", 0)}"
        lines += "• Repeated sources skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        lines += "• DNA/RNA signals: ${delta.optInt("dnaRnaSignals", 0)}"
        lines += "• Steered queries generated: ${delta.optInt("steeredQueriesGenerated", 0)}"
        lines += "• Manual report signals used: ${delta.optInt("manualReportSignalsUsed", 0)}"
        lines += "• New axis pairs:"
        appendArray(lines, delta.optJSONArray("newAxisPairs"))
        lines += "• Learning notes:"
        appendArray(lines, delta.optJSONArray("learningNotes"))
        lines += ""
        lines += "Dataset parser, ML-safe triage & route audit v1.4.5"
        val foragerSection = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        lines += "• Active: ${foragerSection.optBoolean("active", false)} | State: ${foragerSection.optString("state", "NOT_RUN")} | Mode: ${foragerSection.optString("evidenceMode", "unknown")}"
        lines += "• Sources attempted: ${jsonArrayToList(foragerSection.optJSONArray("sourceFamiliesAttempted")).joinToString(", ").ifBlank { "none" }}"
        val scoreSep = foragerSection.optJSONObject("scoreSeparation") ?: JSONObject()
        lines += "• Score separation: usability ${scoreSep.optInt("datasetUsabilityScore", 0)}/100 | route-fit ${scoreSep.optInt("routeFitScore", 0)}/100 | hypothesis ${scoreSep.optInt("hypothesisConfidenceScore", 0)}/100 | ${scoreSep.optString("scoreState", "NOT_EVALUATED")}"
        lines += "• Hypothesis upgrade allowed: ${scoreSep.optBoolean("hypothesisUpgradeAllowed", false)}"
        val triage = foragerSection.optJSONObject("triageReport") ?: JSONObject()
        lines += "• ML-safe triage: active=${triage.optBoolean("active", false)} | ${triage.optString("summary", "none")}"
        lines += "• Claim limit: ${triage.optString("claimLimit", "triage_only_not_biological_proof")}"
        appendObjectArray(lines, triage.optJSONArray("results"), listOf("accession", "action", "usefulnessScore", "routeFitPrediction", "likelyFailureModes", "mlConfidence"))
        val qFeedback = foragerSection.optJSONObject("queryFeedbackPlan") ?: JSONObject()
        lines += "• Query feedback: active=${qFeedback.optBoolean("active", false)} | ${qFeedback.optString("summary", "none")}"
        appendObjectArray(lines, qFeedback.optJSONArray("improvements"), listOf("addedTerms", "reasoning", "expectedImprovement"))
        val fLedger = foragerSection.optJSONObject("failurePatternReport") ?: JSONObject()
        lines += "• Failure-pattern ledger: ${fLedger.optString("summary", "none")}"
        appendObjectArray(lines, fLedger.optJSONArray("newlyRecorded"), listOf("rootCause", "route", "occurrenceCount", "suggestedAction", "claimLimit"))
        val freshness = foragerSection.optJSONObject("freshnessReport") ?: JSONObject()
        lines += "• Freshness weighting: active=${freshness.optBoolean("active", false)} | average=${freshness.optInt("averageFreshness", 0)}/100 | ${freshness.optString("summary", "none")}"
        appendObjectArray(lines, freshness.optJSONArray("topScores"), listOf("sourceId", "publishYear", "boostInRanking", "reason", "claimLimit"))
        lines += "• Route-fit gate:"
        appendObjectArray(lines, foragerSection.optJSONArray("routeFitAssessments"), listOf("accession", "status", "routeFitScore", "datasetRoute", "targetRoute", "allowedUse"))
        lines += "• Blocked learning reason: ${foragerSection.optString("blockedLearningReason", "none")}"
        lines += "• Next action: ${foragerSection.optString("nextAction", "none")}"
        lines += "• Passes:"
        appendObjectArray(lines, foragerSection.optJSONArray("passes"), listOf("passId", "status"))
        val contrastive = foragerSection.optJSONObject("contrastiveReport") ?: JSONObject()
        val cumulative = foragerSection.optJSONObject("cumulativeEvidence") ?: JSONObject()
        lines += "• Parser metadata:"
        appendObjectArray(lines, foragerSection.optJSONArray("parsedMetadata"), listOf("accession", "usabilityVerdict", "metadataQualityScore", "organism", "assayType"))
        lines += "• Contrastive gate: ${contrastive.optString("gateStatus", "NOT_EVALUATED")} — ${contrastive.optString("summary", "none")}"
        lines += "• Next contrastive question: ${contrastive.optString("nextContrastiveQuestion", "none")}"
        lines += "• Cumulative evidence: ${cumulative.optInt("score", 0)}/100 ${cumulative.optString("state", "OFF")}"
        lines += ""
        lines += "Persistent failure memory"
        val memorySection = report.optJSONObject("persistentFailureMemory") ?: JSONObject()
        lines += "• ${memorySection.optString("summary", "No persistent failure memory.")}"
        appendObjectArray(lines, memorySection.optJSONArray("records"), listOf("sourceFamily", "rootCause", "cooldownCyclesRemaining", "timesFailed", "forcedNextSource"))
        lines += ""
        lines += "Learning OS — incident, gates, regression"
        val learningOs = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incidentOs = learningOs.optJSONObject("incident") ?: JSONObject()
        val readinessOs = learningOs.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        val rootCausesOsText = jsonArrayToList(incidentOs.optJSONArray("rootCauses")).joinToString(", ").ifBlank { "none" }
        val observedSignalsText = jsonArrayToList(incidentOs.optJSONArray("observedSignals")).joinToString(", ").ifBlank { "none" }
        lines += "• Root causes: $rootCausesOsText"
        lines += "• Observed signals: $observedSignalsText"
        lines += "• Hypothesis update gate: ${learningOs.optString("hypothesisUpdateGateStatus", "NO_EVIDENCE_OBJECT_NO_UPGRADE")}"
        lines += "• Discovery readiness: ${readinessOs.optInt("score", 0)}/100 ${readinessOs.optString("state", "OFF")}"
        lines += "• Next learning action: ${learningOs.optString("nextLearningAction", "none")}"
        lines += "• Preventive gates:"
        appendObjectArray(lines, learningOs.optJSONArray("preventiveGates"), listOf("gateId", "rootCause", "forcedNextIntent", "action"))
        lines += "• Lane cooldowns:"
        appendObjectArray(lines, learningOs.optJSONArray("laneCooldowns"), listOf("laneName", "failureCount", "cooldownCycles", "lastFailureReason"))
        lines += "• Regression vectors:"
        appendObjectArray(lines, learningOs.optJSONArray("regressionVectors"), listOf("caseId", "expectedRootCause", "expectedGate", "expectedNextAction"))
        lines += ""
        lines += "Research lock summary"
        val summary = report.optJSONObject("researchStateSummary") ?: JSONObject()
        lines += "• Discovery State: ${summary.optString("discoveryState", "Off")}"
        lines += "• Bias Risk State: ${summary.optString("biasRiskState", "Normal")}"
        lines += "• Next Evidence: ${summary.optString("nextEvidence", "none")}"
        lines += "• Discovery Action: ${summary.optString("discoveryAction", "none")}"
        lines += "• Bias Alarm: ${summary.optString("biasAlarm", "Normal")}" 
        lines += ""
        lines += "Hypothesis objects"
        val objects = report.optJSONArray("hypothesisObjects") ?: JSONArray()
        if (objects.length() == 0) {
            lines += "• No locked hypothesis objects yet."
        } else {
            for (i in 0 until objects.length()) {
                val h = objects.optJSONObject(i) ?: continue
                lines += "${i + 1}. ${h.optString("status")} / ${h.optString("discoveryState")} — ${h.optString("label")}" 
                lines += "   Trust ${h.optInt("dataTrustScore")}/100 | Evidence ${ScoreFormat.oneDecimal(h.optDouble("evidenceScore10"))}/10 | Causality ${h.optInt("causalityScore")}/100 | Bias ${h.optString("biasRiskState")}" 
                lines += "   Gate ${h.optString("minimumDataPackStatus")} | Flip ${h.optString("signalFlip")}" 
                lines += "   Next measurement: ${h.optString("nextBestMeasurement")}" 
                val missingDataText = jsonArrayToList(h.optJSONArray("missingData")).joinToString(", ").ifBlank { "none" }
                lines += "   Missing data: $missingDataText"
            }
        }
        lines += ""
        lines += "Learning delta cards"
        appendObjectArray(lines, report.optJSONArray("learningDeltaCards"), listOf("deltaType", "hypothesisId", "decisionImpact", "nextAction"))
        lines += ""
        lines += "Top mistake risks"
        appendObjectArray(lines, report.optJSONArray("mistakeRiskCards"), listOf("risk", "preventionGate"))
        lines += ""
        lines += "Hypothesis ranking"
        val cards = report.optJSONArray("hypothesisRankCards") ?: JSONArray()
        if (cards.length() == 0) {
            lines += "• No ranked hypotheses yet."
        } else {
            for (i in 0 until cards.length()) {
                val c = cards.optJSONObject(i) ?: continue
                lines += "${i + 1}. ${c.optString("status")} — ${c.optString("label")}"
                lines += "   Overall ${c.optInt("overallScore")}/100 | Evidence ${c.optInt("evidenceQualityScore")}/100 | Causality ${c.optInt("causalityScore")}/100 | Repeatability ${c.optInt("personalRepeatability")}"
                lines += "   Negative control: ${c.optString("negativeControlStatus")}"
                lines += "   Next measurement: ${c.optString("nextBestMeasurement")}"
                appendArray(lines, c.optJSONArray("whyRanked"))
            }
        }
        lines += ""
        lines += "Emergent links"
        appendArray(lines, report.optJSONArray("emergentLinks"))
        lines += ""
        lines += "Imported report signals"
        val imported = report.optJSONArray("importedReportSignals") ?: JSONArray()
        if (imported.length() == 0) {
            lines += "• None used."
        } else {
            for (i in 0 until imported.length()) {
                val r = imported.optJSONObject(i) ?: continue
                lines += "• ${r.optString("title")} → ${jsonArrayToList(r.optJSONArray("matchedAxes")).joinToString(", ")}".take(500)
            }
        }
        lines += ""
        lines += "Dataset acquisition + parser candidates v1.4.5"
        val ds137 = report.optJSONArray("datasetCandidatesV137") ?: JSONArray()
        if (ds137.length() == 0) {
            lines += "• No dataset accession candidate yet."
        } else {
            for (i in 0 until ds137.length()) {
                val d = ds137.optJSONObject(i) ?: continue
                lines += "${i + 1}. ${d.optString("accession")} • ${d.optString("source")} • usability ${d.optInt("usabilityScore")}/100 • ${d.optString("status")}"
                lines += "   ${d.optString("organismHint")} | ${d.optString("conditionLabelsHint")} | ${d.optString("outcomeLabelsHint")}"
            }
        }
        lines += ""
        lines += "Evidence objects"
        val evObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        if (evObjects.length() == 0) {
            lines += "• No evidence object yet."
        } else {
            for (i in 0 until evObjects.length()) {
                val e = evObjects.optJSONObject(i) ?: continue
                lines += "${i + 1}. ${e.optString("decisionImpact")} • quality ${e.optInt("qualityScore")}/100 • ${e.optString("title")}"
                lines += "   Accessions: ${jsonArrayToList(e.optJSONArray("accessionIds")).joinToString(", ").ifBlank { "none" }} | Contradicts: ${e.optBoolean("contradictsHypothesis")} | Control: ${e.optBoolean("hasNegativeControl")}"
            }
        }
        lines += ""
        lines += "Top findings"
        val findings = report.optJSONArray("findings") ?: JSONArray()
        if (findings.length() == 0) {
            lines += "• No new findings saved in this cycle."
        } else {
            for (i in 0 until findings.length()) {
                val f = findings.optJSONObject(i) ?: continue
                lines += "${i + 1}. " + f.optString("title")
                lines += "   " + f.optString("source") + " " + f.optString("sourceId") + " • " + f.optString("published") + " • novelty " + f.optInt("noveltyScore") + "/100"
                lines += "   Axes: " + jsonArrayToList(f.optJSONArray("matchedAxes")).joinToString(", ")
                val ev = f.optJSONObject("evidence") ?: JSONObject()
                val ca = f.optJSONObject("causality") ?: JSONObject()
                val neg = f.optJSONObject("negativeControl") ?: JSONObject()
                val pp = f.optJSONObject("personalPattern") ?: JSONObject()
                lines += "   Evidence: ${ev.optInt("evidenceQualityScore", 0)}/100 | ${ev.optString("speciesClass", "unknown")} | ${ev.optString("studyDesign", "unknown")}"
                lines += "   Causality: ${ca.optInt("causalityScore", 0)}/100 | Negative control: ${neg.optString("status", "unknown")}"
                lines += "   Personal pattern: ${pp.optInt("repeatedObservationCount", 0)} repeats | ${pp.optString("temporalSupport", "unknown")}"
                lines += "   " + f.optString("bridgeSignal")
                lines += "   " + f.optString("whyItMatters")
            }
        }
        lines += ""
        lines += "Next questions"
        appendArray(lines, report.optJSONArray("nextQuestions"))
        lines += ""
        lines += "Limitations"
        appendArray(lines, report.optJSONArray("limitations"))
        return lines.joinToString("\n")
    }

    private fun appendArray(lines: MutableList<String>, arr: JSONArray?) {
        if (arr == null || arr.length() == 0) {
            lines += "• None."
            return
        }
        for (i in 0 until arr.length()) lines += "• ${arr.optString(i)}"
    }

    private fun appendObjectArray(lines: MutableList<String>, arr: JSONArray?, keys: List<String>) {
        if (arr == null || arr.length() == 0) {
            lines += "• None."
            return
        }
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val rendered = keys.mapNotNull { key ->
                val value = obj.optString(key)
                if (value.isBlank()) null else "$key: $value"
            }.joinToString(" | ")
            lines += "• $rendered"
        }
    }

    private fun jsonArrayToList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    }

    private fun copyBriefReport() {
        val report = latestReport
        if (report == null) {
            Toast.makeText(this, "No report to copy yet.", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Immune Error Radar brief report", renderBriefReport(report)))
        Toast.makeText(this, "Brief report copied.", Toast.LENGTH_SHORT).show()
    }

    private fun exportPdf() {
        val report = latestReport
        if (report == null) {
            Toast.makeText(this, "Run a research cycle first.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val file = DiscoveryReportExporter.export(this, report)
            shareFile(file, "application/pdf", "Share discovery PDF")
        } catch (e: Exception) {
            runCatching {
                val fallback = DiscoveryReportExporter.exportText(this, report, renderBriefReport(report) + "\n\n" + renderReport(report))
                shareFile(fallback, "text/plain", "Share discovery text report")
                Toast.makeText(this, "PDF failed; exported TXT instead.", Toast.LENGTH_LONG).show()
            }.onFailure { err ->
                Toast.makeText(this, "Report export failed: ${err.message ?: e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun shareFile(file: File, mimeType: String, chooserTitle: String) {
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, chooserTitle))
    }
}
