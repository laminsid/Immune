package com.immunesignal.app

import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.min

class ResearchAutopilot(private val context: Context) {
    private data class DatasetForagingRunResult(
        val findings: List<ResearchFinding>,
        val report: DatasetForagingReport
    )

    private val store = ResearchKnowledgeStore(context)

    // v1.5.4: Foundation Knowledge OS is integrated but disabled by default.
    // One-line rollback/enable point: flip this flag without touching the v1.4.5/v1.5.0 cycle.
    private val enableFoundationKnowledgeOs: Boolean = RuntimeFeatureFlags.ENABLE_FOUNDATION_KNOWLEDGE_OS

    fun runCycle(
        shouldStop: () -> Boolean = { false },
        limits: ResearchRunLimits = ResearchRunLimits()
    ): ResearchCycleReport {
        val started = System.currentTimeMillis()
        val searchDeadline = started + limits.maxSearchMillis
        val seen = store.seenSourceIds()
        val seenAbstracts = seen.filter { it.startsWith("Abstract:") }.toSet()
        val seenAxisPairsBefore = store.seenAxisPairs()
        val importedSignals = store.readImportedSignals(20)
        val localRecords = LocalCaseStore(context).readLatest(40)
        val personalLedger = PersonalPatternLedger(localRecords, importedSignals)
        val steering = store.readActiveSteering()
        val recentReports = store.readLatestReports(20)
        val failureMemoryStore = PersistentFailureMemory(context)
        val failureMemoryBefore = failureMemoryStore.read()
        val failurePatternLedger = FailurePatternLedger(context)
        val inheritedPersistentPatternsV145 = failureMemoryBefore.records.map { record ->
            FailurePattern(
                id = "PERSISTENT:${record.rootCause}:${record.sourceFamily}",
                rootCause = record.rootCause,
                route = "unknown_route",
                hypothesisId = null,
                occurrenceCount = record.timesFailed,
                lastSeenMillis = record.lastAttemptedAtMillis,
                datasetAccessions = emptyList(),
                suggestedAction = "Inherited from persistent failure memory; force next source: ${record.forcedNextSource}."
            )
        }
        val recentFailurePatternsBefore = (failurePatternLedger.getRecent(hours = 168) + inheritedPersistentPatternsV145)
            .distinctBy { it.id }
        val stagnationPlan = AutonomousStagnationEngine.planFromRecentReports(recentReports, limits)
        val learningPivot = ResearchLearningLoopEngine.pivotFromRecentReports(recentReports)
        val appliedPivot = if (learningPivot.pivotType != "NO_PIVOT") learningPivot else stagnationPlan.pendingPivot
        val (effectiveMaxQueries, effectiveResultsPerQuery) = EngineRuntimeStatus.enforceQueryBudget(
            baseLimits = limits,
            appliedPivot = appliedPivot,
            stagnationPlan = stagnationPlan
        )
        val recentFindings = store.readRecentFindings(120)
        val autonomousPlan = AutonomousResearchPlanner().plan(
            latestReports = recentReports,
            recentFindings = recentFindings,
            importedSignals = importedSignals,
            steering = steering,
            seenAxisPairs = seenAxisPairsBefore
        )
        val plannedQueries = QueryPlanner().build(
            plan = autonomousPlan,
            steering = steering,
            pivot = appliedPivot,
            maxQueries = effectiveMaxQueries
        )
        val findings = mutableListOf<ResearchFinding>()
        val executedQueries = mutableListOf<ResearchQuery>()
        var repeatedSkipped = 0
        var stopped = false
        var stopReason = "completed"
        var runtimeFailoverApplied = false
        val initialResearchState = EngineRuntimeStatus.stateFor(appliedPivot, stagnationPlan.active)
        val hypothesisShards = HypothesisDecomposer.decompose(
            globalQuestion = "Which public datasets can map trigger-response-outcome immune patterns across allergy, autoimmunity, and viral response?"
        )
        var datasetForagingReport = DatasetForagingReport.empty()

        fun runQueryBatch(queryBatch: List<ResearchQuery>, retMax: Int) {
            for (query in queryBatch) {
                if (executedQueries.any { it.id == query.id }) continue
                if (shouldStop()) { stopped = true; stopReason = "stopped_by_user"; break }
                if (System.currentTimeMillis() >= searchDeadline) { stopped = true; stopReason = "search_limit_10_min_reached"; break }
                executedQueries += query
                val ids = runCatching { searchPubMed(query.query, retMax = retMax) }.getOrDefault(emptyList())
                val freshIds = mutableListOf<String>()
                for (pmid in ids) {
                    val key = "PubMed:$pmid"
                    if (seen.contains(key) || findings.any { it.source == "PubMed" && it.sourceId == pmid }) {
                        repeatedSkipped += 1
                        continue
                    }
                    freshIds += pmid
                }
                if (freshIds.isNotEmpty()) {
                    if (shouldStop()) { stopped = true; stopReason = "stopped_by_user"; break }
                    if (System.currentTimeMillis() >= searchDeadline) { stopped = true; stopReason = "search_limit_10_min_reached"; break }
                    val batch = runCatching { fetchPubMedSummariesBatch(freshIds.take(200), query, personalLedger, limits, seenAbstracts) }.getOrDefault(emptyList())
                    findings += batch
                }
                if (stopped) break
            }
        }

        val datasetFirstRequested = DirectDatasetSourceRouter.shouldRunDatasetFirst(
            recentReports = recentReports,
            researchState = initialResearchState,
            appliedPivot = appliedPivot,
            memory = failureMemoryBefore
        )
        if (datasetFirstRequested) {
            val forage = runDatasetFirstForaging(
                shards = hypothesisShards,
                memory = failureMemoryBefore,
                personalLedger = personalLedger,
                seen = seen,
                executedQueries = executedQueries,
                shouldStop = shouldStop,
                searchDeadline = searchDeadline
            )
            findings += forage.findings
            datasetForagingReport = forage.report
        }

        val postForagerQueriesBase = if (datasetFirstRequested) {
            DatasetQueryCompiler.compile(hypothesisShards, failureMemoryBefore).take(effectiveMaxQueries)
        } else {
            plannedQueries
        }
        val foundationBridgeV151 = FoundationKnowledgeIntegrationBridge(
            context = context,
            enableFoundationKnowledge = enableFoundationKnowledgeOs
        )
        val foundationAnalysisV151 = foundationBridgeV151.analyzeWithFoundation(
            queryText = postForagerQueriesBase.joinToString(" ") { it.query },
            extractedMetadata = ((steering?.variables ?: emptyList()) +
                hypothesisShards.flatMap { it.querySeeds + listOf(it.label, it.evidenceQuestion) } +
                postForagerQueriesBase.flatMap { it.query.split(" ").take(12) })
                .map { it.trim().lowercase(Locale.US) }
                .filter { it.isNotBlank() }
                .distinct()
                .take(80),
            datasetType = "unknown"
        )
        val queryFeedbackPlanV145 = QueryFeedbackPlanner.improveBatch(postForagerQueriesBase, recentFailurePatternsBefore)
        runQueryBatch(queryFeedbackPlanV145.improvedQueries, effectiveResultsPerQuery)

        // v1.3.8: same-cycle active learning failover. If the first pass is
        // clearly stuck, immediately execute the dataset/accession path instead
        // of only writing "pivot next time" in the report.
        if (!stopped && EngineRuntimeStatus.hardStagnationTriggered(
                newFindingsCount = findings.size,
                repeatedSkipped = repeatedSkipped,
                datasetCandidateCount = 0
            )
        ) {
            runtimeFailoverApplied = true
            val failoverPivot = EngineRuntimeStatus.runtimeFailoverPivot(repeatedSkipped)
            val failoverPlan = AutonomousStagnationEngine.StagnationPlan(
                level = 3,
                pendingPivot = failoverPivot,
                effectiveMaxQueries = maxOf(effectiveMaxQueries, 6),
                effectiveResultsPerQuery = maxOf(effectiveResultsPerQuery, 25),
                reason = failoverPivot.reason
            )
            val failoverQueries = listOf(
                ResearchQuery(
                    id = "q_runtime_dataset_accession",
                    label = "RUNTIME FAILOVER: dataset accession search",
                    query = "(GSE OR GEO OR SDY OR ImmPort OR PRJNA OR SRP OR SRA OR RNA-seq OR single-cell OR scRNA-seq) AND (immune response OR cytokine OR interferon OR allergy OR viral response) AND (outcome OR severity OR recovery OR longitudinal OR cohort)",
                    reason = "Hard stagnation was detected inside this cycle; execute DATASET_HUNT now."
                ),
                ResearchQuery(
                    id = "q_runtime_condition_outcome_labels",
                    label = "RUNTIME FAILOVER: condition/outcome labels",
                    query = "(condition labels OR phenotype labels OR outcome labels OR severity OR recovery) AND (immune profiling OR transcriptomic OR RNA-seq OR single-cell) AND (human OR patient OR cohort)",
                    reason = "Search for label structure rather than another broad PubMed neighborhood."
                )
            ) + AutonomousStagnationEngine.antiStagnationQueries(failoverPlan)
            runQueryBatch(failoverQueries.distinctBy { it.id }.take(failoverPlan.effectiveMaxQueries), failoverPlan.effectiveResultsPerQuery)
        }

        val searchFinished = System.currentTimeMillis()
        val learningDeadline = searchFinished + limits.maxLearningMillis
        val ranked = learnAndRank(
            findings = findings,
            importedSignals = importedSignals,
            steering = steering,
            shouldStop = shouldStop,
            deadlineMillis = learningDeadline
        )
        val completed = System.currentTimeMillis()
        if (!stopped && shouldStop()) { stopped = true; stopReason = "stopped_by_user" }
        if (!stopped && completed >= learningDeadline) { stopped = true; stopReason = "learning_limit_15_min_reached" }

        val newAxisPairs = computeNewAxisPairs(ranked, seenAxisPairsBefore)
        val dnaRnaSignals = ranked.count { it.matchedAxes.any { axis -> axis == "dna_genomic_axis" || axis == "rna_transcriptomic_axis" } }
        val freshnessReportV145 = EvidenceFreshnessScorer.report(ranked)
        val hypothesisCards = HypothesisRankingEngine.rank(ranked)
        val hypothesisObjects = HypothesisObjectFactory.build(hypothesisCards, ranked, importedSignals)
        val learningDeltaCards = LearningDeltaEngine.build(hypothesisObjects, store.readLatestReports(8))
        val mistakeRiskCards = ResearchMistakeLibrary.topRisks(hypothesisObjects, ranked)
        val baseResearchStateSummary = ResearchStateEngine.summarize(hypothesisObjects, mistakeRiskCards)
        val globalImmuneIntelligence = GlobalImmuneIntelligenceEngine.build(ranked, importedSignals, steering)
        val datasetCandidatesV133 = ranked
            .flatMap { DatasetCandidateExtractor.extractFromFinding(it) }
            .distinctBy { it.datasetId + it.sourceTitle }
            .sortedByDescending { it.priorityScore }
            .take(12)
        val datasetCandidatesV137 = (datasetForagingReport.candidates + DatasetAccessionResolver.fromFindings(ranked))
            .distinctBy { it.accession + ":" + it.sourceFindingId }
            .sortedByDescending { it.usabilityScore }
            .take(30)
        val routeFitAssessmentsV144 = RouteFitGate.evaluate(datasetCandidatesV137, ranked, hypothesisShards)
        val triageResultsV145 = MLDatasetTriageEngine.triage(datasetCandidatesV137, routeFitAssessmentsV144)
        val parseCandidateAccessionsV145 = triageResultsV145
            .filter { MLDatasetTriageEngine.shouldParse(it) }
            .map { it.accession }
            .toSet()
        val parseCandidatesV145 = datasetCandidatesV137.filter { it.accession in parseCandidateAccessionsV145 }
        val parsedMetadataV142 = DatasetParser.parse(parseCandidatesV145, ranked)
        val triageReportV145 = MLDatasetTriageEngine.report(triageResultsV145, parseCandidatesV145)
        val preliminaryForagerV142 = datasetForagingReport.copy(
            candidates = datasetCandidatesV137,
            parsedMetadata = parsedMetadataV142,
            contrastiveReport = ContrastiveEvidenceGate.evaluate(parsedMetadataV142),
            evidenceHypergraph = EvidenceHypergraphLite.build(parsedMetadataV142),
            cumulativeEvidence = CumulativeEvidenceScorer.score(emptyList(), parsedMetadataV142, routeFitAssessmentsV144),
            routeFitAssessments = routeFitAssessmentsV144,
            triageReport = triageReportV145,
            queryFeedbackPlan = queryFeedbackPlanV145,
            freshnessReport = freshnessReportV145
        )
        val evidenceObjects = EvidenceObjectFactory.build(ranked, datasetCandidatesV137, routeFitAssessmentsV144).take(32)
        datasetForagingReport = preliminaryForagerV142.copy(
            cumulativeEvidence = CumulativeEvidenceScorer.score(evidenceObjects, parsedMetadataV142, routeFitAssessmentsV144)
        )
        val discoveryReadiness = DiscoveryReadinessScorer.score(evidenceObjects, datasetCandidatesV137, routeFitAssessmentsV144)
        val scoreSeparationV144 = RouteFitGate.separation(
            candidates = datasetCandidatesV137,
            routeFits = routeFitAssessmentsV144,
            discoveryReadiness = discoveryReadiness,
            evidenceObjects = evidenceObjects
        )
        datasetForagingReport = datasetForagingReport.copy(scoreSeparation = scoreSeparationV144)
        val metadataOnlyRatio = if (ranked.isEmpty()) 0.0 else ranked.count { it.sanityFlags.contains("METADATA_ONLY") }.toDouble() / ranked.size.toDouble()
        val failedLane = autonomousPlan.lanes.firstOrNull()?.laneType ?: autonomousPlan.strategy
        val failureSignature = FailureSignature(
            newUsefulSources = ranked.size,
            repeatedSkipped = repeatedSkipped,
            metadataOnlyRatio = metadataOnlyRatio,
            sameLaneFailureCount = if (ranked.isEmpty() && repeatedSkipped >= 10) 2 else 0,
            abstractFetchFailures = ranked.count { it.sanityFlags.contains("ABSTRACT_FETCH_FAILED") },
            datasetCandidateCount = datasetCandidatesV133.size,
            hypothesisDeltaCount = learningDeltaCards.count { it.deltaType != "no_change" },
            failedLane = failedLane
        )
        val learningOsReport = ResearchLearningLoopEngine.build(
            signature = failureSignature,
            findings = ranked,
            datasets = datasetCandidatesV137,
            evidenceObjects = evidenceObjects,
            discoveryReadiness = discoveryReadiness
        )
        val failurePatternReportV145 = failurePatternLedger.recordCycle(
            triageResults = triageResultsV145,
            routeFits = routeFitAssessmentsV144,
            parsedMetadata = parsedMetadataV142,
            learningOsReport = learningOsReport,
            evidenceObjects = evidenceObjects
        )
        datasetForagingReport = datasetForagingReport.copy(
            failurePatternReport = failurePatternReportV145,
            queryFeedbackPlan = queryFeedbackPlanV145,
            freshnessReport = freshnessReportV145
        )
        val hardStagnationObserved = EngineRuntimeStatus.hardStagnationTriggered(
            newFindingsCount = ranked.size,
            repeatedSkipped = repeatedSkipped,
            datasetCandidateCount = datasetCandidatesV137.size
        )
        val runtimeStatus = ActiveResearchEngineStatus(
            engineVersion = EngineRuntimeStatus.ACTIVE_ENGINE_VERSION,
            activeModules = EngineRuntimeStatus.ACTIVE_MODULES,
            researchState = if (datasetForagingReport.active || runtimeFailoverApplied) "DATASET_HUNT" else initialResearchState,
            appliedPivotType = appliedPivot.pivotType,
            effectiveMaxQueries = effectiveMaxQueries,
            effectiveResultsPerQuery = effectiveResultsPerQuery,
            runtimeFailoverApplied = runtimeFailoverApplied,
            forcedQueries = executedQueries
                .filter { it.id.startsWith("q_pivot_") || it.id.startsWith("q_antistag_") || it.id.startsWith("q_runtime_") || it.id.startsWith("q_v142_") }
                .map { "${it.label}: ${it.query}" }
                .take(12),
            executedQueryIds = executedQueries.map { it.id }
        )
        val executionLockReport = EngineRuntimeStatus.buildExecutionLock(
            runtimeStatus = runtimeStatus,
            learningOsReport = learningOsReport,
            hardStagnationObserved = hardStagnationObserved,
            datasetForagingReport = datasetForagingReport
        )
        val persistentFailureMemoryAfter = failureMemoryStore.recordCycle(
            executedQueries = executedQueries,
            learningOsReport = learningOsReport,
            datasetForagingReport = datasetForagingReport,
            evidenceObjects = evidenceObjects
        )
        val researchStateSummary = ResearchStateEngine.actionableSummary(
            base = baseResearchStateSummary,
            datasetForagingReport = datasetForagingReport,
            learningOsReport = learningOsReport,
            runtimeStatus = runtimeStatus,
            discoveryReadiness = discoveryReadiness
        )
        val resilienceDecision = NoResultRecoveryEngine.decide(failureSignature)
        val queryEvolutionState = if (resilienceDecision.pivotType == "NO_PIVOT") null else AdaptiveQueryEvolution.evolve(
            seed = resilienceDecision.nextQuerySeed,
            pivot = resilienceDecision,
            activeAxes = ranked.flatMap { it.matchedAxes }.distinct().take(5)
        )
        val foundationKnowledgeNotesV151 = foundationAnalysisV151?.let { analysis ->
            listOf(
                "v1.5.6 Foundation Knowledge OS: axis=${analysis.primaryAxis ?: "unknown"}; action=${analysis.recommendedAction}; confidence=${analysis.confidenceLevel}; claim-limit=${analysis.claimLimit}.",
                "v1.5.6 Foundation Knowledge OS: ${analysis.actionExplanation.take(260)}"
            )
        } ?: listOf(
            "v1.5.6 Foundation Knowledge OS: integrated, disabled by default; it guides search only and never proves biology."
        )

        val reportV3 = ResearchReportV3Builder.build(
            findings = ranked,
            hypothesisObjects = hypothesisObjects,
            learningDeltas = learningDeltaCards,
            datasetCandidates = datasetCandidatesV133,
            pivot = resilienceDecision,
            repeatedSkipped = repeatedSkipped,
            global = globalImmuneIntelligence,
            evidenceObjects = evidenceObjects,
            learningOs = learningOsReport,
            discoveryReadiness = discoveryReadiness,
            datasetForagingReport = datasetForagingReport
        )
        val reasoningReport = ResearchReasoningEngine.reason(
            findings = ranked,
            hypothesisObjects = hypothesisObjects,
            datasetCandidates = datasetCandidatesV133,
            pivot = resilienceDecision,
            global = globalImmuneIntelligence,
            repeatedSkipped = repeatedSkipped,
            reportV3 = reportV3
        )

        return ResearchCycleReport(
            id = "cycle_$started",
            createdAtMillis = started,
            completedAtMillis = completed,
            stoppedByUser = stopped && stopReason == "stopped_by_user",
            stopReason = stopReason,
            searchDurationMillis = (searchFinished - started).coerceAtLeast(0),
            learningDurationMillis = (completed - searchFinished).coerceAtLeast(0),
            queries = executedQueries,
            findings = ranked,
            activeSteeringProfile = steering,
            importedReportSignals = importedSignals.take(8),
            hypothesisRankCards = hypothesisCards,
            emergentLinks = buildEmergentLinks(ranked, importedSignals, steering),
            nextQuestions = buildNextQuestions(ranked, importedSignals, steering, autonomousPlan),
            knowledgeDelta = KnowledgeDelta(
                newSourcesSaved = ranked.size,
                repeatedSourcesSkipped = repeatedSkipped,
                newAxisPairs = newAxisPairs,
                manualReportSignalsUsed = importedSignals.size,
                dnaRnaSignals = dnaRnaSignals,
                steeredQueriesGenerated = executedQueries.count { it.id.startsWith("q_steer_") },
                learningNotes = buildLearningNotes(
                    findings = ranked,
                    importedSignals = importedSignals,
                    newAxisPairs = newAxisPairs,
                    stopReason = stopReason,
                    steering = steering,
                    autonomousPlan = autonomousPlan,
                    stagnationPlan = stagnationPlan,
                    runtimeStatus = runtimeStatus,
                    executionLockReport = executionLockReport
                ) + listOf(
                    "v1.4.5 active engine: ${runtimeStatus.engineVersion}; state=${runtimeStatus.researchState}; execution lock=${executionLockReport.status}.",
                    "v1.4.5 dataset interpreter: active=${datasetForagingReport.active}; sources=${datasetForagingReport.sourceFamiliesAttempted.joinToString(", ").ifBlank { "none" }}; candidates=${datasetForagingReport.candidates.size}; parsed=${datasetForagingReport.parsedMetadata.size}; contrast=${datasetForagingReport.contrastiveReport.gateStatus}; cumulative=${datasetForagingReport.cumulativeEvidence.score}/100 ${datasetForagingReport.cumulativeEvidence.state}.",
                    "v1.4.4 route-fit gate: blocked=${datasetForagingReport.routeFitAssessments.count { it.blocksHypothesisUpgrade }}; score-state=${datasetForagingReport.scoreSeparation.scoreState}; route-fit=${datasetForagingReport.scoreSeparation.routeFitScore}/100; hypothesis-confidence=${datasetForagingReport.scoreSeparation.hypothesisConfidenceScore}/100.",
                    "v1.4.5 ML-safe triage: active=${datasetForagingReport.triageReport.active}; parsed=${datasetForagingReport.triageReport.parsedAccessions.size}; skipped=${datasetForagingReport.triageReport.skippedAccessions.size}; claim-limit=${datasetForagingReport.triageReport.claimLimit}.",
                    "v1.4.5 failure-pattern ledger: ${datasetForagingReport.failurePatternReport.summary}",
                    "v1.4.5 query feedback: ${datasetForagingReport.queryFeedbackPlan.summary}",
                    "v1.4.5 freshness weighting: average=${datasetForagingReport.freshnessReport.averageFreshness}/100; ${datasetForagingReport.freshnessReport.summary}",
                    *foundationKnowledgeNotesV151.toTypedArray(),
                    "v1.4.3 persistent failure memory: ${persistentFailureMemoryAfter.summary}",
                    "v1.3.7 Learning OS: ${learningOsReport.incident.rootCauses.joinToString(", ").ifBlank { "no incident" }}; next: ${learningOsReport.nextLearningAction}",
                    "Discovery readiness: ${discoveryReadiness.score}/100 ${discoveryReadiness.state}"
                )
            ),
            autonomousPlan = autonomousPlan,
            resilienceDecision = resilienceDecision,
            queryEvolutionState = queryEvolutionState,
            datasetCandidatesV133 = datasetCandidatesV133,
            datasetCandidatesV137 = datasetCandidatesV137,
            evidenceObjects = evidenceObjects,
            discoveryReadiness = discoveryReadiness,
            learningOsReport = learningOsReport,
            runtimeStatus = runtimeStatus,
            executionLockReport = executionLockReport,
            datasetForagingReport = datasetForagingReport,
            persistentFailureMemory = persistentFailureMemoryAfter,
            reportV3 = reportV3,
            reasoningReport = reasoningReport,
            hypothesisObjects = hypothesisObjects,
            learningDeltaCards = learningDeltaCards,
            mistakeRiskCards = mistakeRiskCards,
            researchStateSummary = researchStateSummary,
            globalImmuneIntelligence = globalImmuneIntelligence,
            limitations = listOf(
                "This is a private research-mining tool. It does not prove causality.",
                "DNA/RNA links are hypothesis leads only unless validated against curated datasets and repeated observations.",
                "Search avoids previously stored PubMed IDs, but similar scientific ideas may recur under new papers.",
                "Manual imported reports are treated as unverified research notes until source quality is checked.",
                "Research steering variables focus the search; they do not prove a causal relationship.",
                "Evidence quality, causality, and negative controls are ranking aids, not proof.",
                "Human evidence is separated from animal/cell-only evidence when metadata allows it.",
                "Global dataset candidates are leads for inspection; accession, license, sample size, and outcome labels must be verified before modeling.",
                "Antiviral-response notes describe research direction only; they do not predict protection against new variants.",
                "v1.3.3 no-result recovery changes research strategy after empty or repeated cycles; it does not claim discovery when no useful delta occurred.",
                "v1.3.4 research reasoning generates questions, competing explanations, discriminators, reframed search terms, and self-critique; it does not prove any hypothesis.",
                "v1.3.6 anti-stagnation applies the prior failed-cycle pivot in the next run and widens low-data PubMed retmax before normal lanes.",
                "v1.3.7 learning OS converts repeated failure into root-cause tags, preventive gates, lane cooldowns, and regression vectors; it does not claim discovery without evidence objects.",
                "v1.4.3 keeps dataset parsing active, closes legacy daily-scan runtime routes, and rewrites next evidence into executable dataset/control/contradiction actions; it still does not prove causality or clinical value.",
                "v1.4.4 separates dataset usability, route fit, and hypothesis confidence; off-route datasets cannot upgrade unrelated hypotheses.",
                "v1.4.5 ML-safe triage ranks dataset inspection only; it is triage_only_not_biological_proof and cannot prove mechanisms, diagnosis, treatment, or immune outcomes.",
                "v1.4.5 failure-pattern memory and query feedback learn from repeated search failures; they rank the next hunt and do not constitute biological proof.",
                "v1.5.6 Foundation Knowledge OS guides route selection, conflict resolution, and query planning; it is foundation_knowledge_not_evidence and never auto-updates JSON knowledge packs.",
                "v1.5.6 Learning Sessions are bounded, pausable research-review sessions; they create checkpointed insights and do not perform diagnosis, treatment, or biological proof.",
                "No medical advice, diagnosis, treatment, or drug selection is generated."
            )
        )
    }

    private fun buildQueries(importedSignals: List<ImportedReportSignal>, steering: ResearchSteeringProfile?, autonomousPlan: AutonomousResearchPlan): List<ResearchQuery> {
        val recentCases = LocalCaseStore(context).readLatest(15)
        val axisBoosts = inferAxisBoosts(recentCases, importedSignals) + (steering?.inferredAxes?.toSet() ?: emptySet())
        val globalCore = buildGlobalCoreQueries()
        val base = mutableListOf(
            ResearchQuery(
                "q_type2_stress_mast",
                "Type-2 + stress + mast-cell bridge",
                "(allergic rhinitis OR asthma OR allergy) AND (stress OR sleep OR psychoneuroimmunology) AND (mast cell OR IgE OR eosinophil)",
                "Looks for non-obvious links between psychological load, Type-2 allergy, and mast-cell/eosinophil activation."
            ),
            ResearchQuery(
                "q_ra_stress_cytokine",
                "RA + stress + inflammatory cytokines",
                "(rheumatoid arthritis) AND (stress OR sleep OR depression) AND (IL-6 OR TNF OR inflammation)",
                "Tests whether chronic stress/recovery debt may amplify autoimmune inflammatory axes."
            ),
            ResearchQuery(
                "q_back_inflammation_psych",
                "Back pain + inflammatory/psychological bridge",
                "(low back pain OR disc herniation OR intervertebral disc degeneration) AND (stress OR sleep OR fear avoidance OR inflammation)",
                "Searches for mechanical-neuroimmune bridges relevant to pain amplification and recovery failure."
            ),
            ResearchQuery(
                "q_allergy_aging_immunosenescence",
                "Allergy + aging / immunosenescence",
                "(allergy OR allergic rhinitis OR asthma OR IgE) AND (aging OR immunosenescence OR inflammaging OR longevity)",
                "Tests the non-linear hypothesis that allergic reactivity may represent preserved responsiveness in some contexts and inflammatory burden in others."
            ),
            ResearchQuery(
                "q_histamine_bp_autonomic",
                "Histamine + blood pressure + autonomic bridge",
                "(histamine OR mast cell OR allergy OR anaphylaxis) AND (blood pressure OR hypotension OR autonomic OR vasodilation)",
                "Looks for stress pressure-up vs histamine/vasodilation pressure-down mechanisms."
            ),
            ResearchQuery(
                "q_dna_epigenetic_allergy_aging",
                "DNA / epigenetic allergy-aging bridge",
                "(DNA methylation OR epigenetic OR genome OR SNP) AND (allergy OR asthma OR IgE) AND (aging OR immunosenescence OR inflammaging)",
                "Adds DNA/epigenetic mechanisms: methylation age, variants, and immune reactivity."
            ),
            ResearchQuery(
                "q_rna_transcriptomic_cross_immune",
                "RNA / transcriptomic cross-condition bridge",
                "(RNA-seq OR transcriptomic OR gene expression OR single-cell RNA) AND (allergy OR asthma) AND (rheumatoid arthritis OR autoimmunity OR cytokine storm)",
                "Searches RNA signatures that may bridge allergy, autoimmunity, and hyperinflammatory states."
            ),
            ResearchQuery(
                "q_mirna_mast_autonomic",
                "miRNA + mast-cell/autonomic bridge",
                "(microRNA OR miRNA OR noncoding RNA) AND (mast cell OR histamine OR allergy) AND (stress OR autonomic OR blood pressure)",
                "Looks for non-obvious RNA regulation between mast cells, stress, and vascular/autonomic behavior."
            ),
            ResearchQuery(
                "q_cytokine_regulatory_brake_genomics",
                "Hyperinflammation + genomic/RNA brake failure",
                "(cytokine storm OR hyperinflammation OR ARDS) AND (IL-10 OR regulatory T cells OR immune regulation) AND (genomics OR transcriptomics OR RNA-seq)",
                "Looks for regulatory-brake failure patterns with omics evidence."
            ),
            ResearchQuery(
                "q_gastric_acid_allergy_microbiome",
                "Gastric acid + allergy + microbiome bridge",
                "(gastric acid OR hypochlorhydria OR reflux OR GERD OR proton pump inhibitor OR H pylori) AND (allergy OR asthma OR IgE OR mast cell) AND (microbiome OR gut barrier OR gut-lung axis)",
                "Tests whether stomach-acid context, reflux, acid suppression, or gastritis-like factors connect to allergy through microbiome/gut-barrier or gut-lung pathways."
            ),
            ResearchQuery(
                "q_nutrition_muscle_immune_recovery",
                "Nutrition + muscle mass + immune recovery",
                "(protein intake OR diet diversity OR malnutrition OR sarcopenia OR muscle mass) AND (immune function OR inflammation OR recovery OR aging)",
                "Looks for nutrition/protein/muscle reserve as an immune-recovery and inflammaging modifier."
            ),
            ResearchQuery(
                "q_testosterone_immune_inflammation",
                "Testosterone + immune regulation",
                "(testosterone OR androgen OR hypogonadism) AND (immune function OR inflammation OR allergy OR autoimmunity OR cytokine)",
                "Tests whether testosterone/androgen context modulates inflammatory tone, allergy, autoimmunity, muscle reserve, or recovery."
            )
        )

        if (axisBoosts.contains("airway")) {
            base += ResearchQuery(
                "q_airway_stress_trigger",
                "Airway trigger timing",
                "(asthma OR allergic rhinitis OR sinusitis) AND (emotional stress OR panic OR breathing pattern) AND (exacerbation OR trigger)",
                "Added because stored/imported context contained airway/allergy or breathing-context signals."
            )
        }
        if (axisBoosts.contains("aging")) {
            base += ResearchQuery(
                "q_local_aging_allergy_bridge",
                "Local allergy-aging bridge",
                "(IgE OR eosinophil OR allergy) AND (inflammaging OR immunosenescence OR recovery OR frailty)",
                "Added because stored/imported context contained aging/autonomic/allergy bridge fields."
            )
        }
        if (axisBoosts.contains("autonomic")) {
            base += ResearchQuery(
                "q_local_autonomic_mast_bp",
                "Local autonomic-mast-cell BP bridge",
                "(mast cell OR histamine OR allergy) AND (autonomic OR blood pressure OR dizziness OR vasodilation)",
                "Added because stored/imported context contained BP, dizziness, flushing, or faintness during allergy context."
            )
        }
        if (axisBoosts.contains("gut_metabolic")) {
            base += ResearchQuery(
                "q_local_gut_metabolic_axis",
                "Local gut/nutrition/testosterone bridge",
                "(gastric acid OR reflux OR microbiome OR diet diversity OR protein intake OR muscle mass OR testosterone) AND (allergy OR immune regulation OR inflammation OR aging)",
                "Added because recent local/imported reports contained gut-acid, nutrition, muscle, or testosterone signals."
            )
        }
        if (axisBoosts.contains("genomics")) {
            base += ResearchQuery(
                "q_local_dna_rna_axis",
                "Local DNA/RNA immune bridge",
                "(epigenetics OR DNA methylation OR RNA-seq OR single-cell RNA OR miRNA) AND (immune regulation OR allergy OR inflammation OR aging)",
                "Added because recent local/imported reports contained DNA/RNA/genomic or transcriptomic signals."
            )
        }
        if (axisBoosts.contains("mechanical")) {
            base += ResearchQuery(
                "q_muscle_guarding_disc",
                "Muscle guarding / disc / stress loop",
                "(muscle guarding OR central sensitization) AND (low back pain OR disc) AND (stress OR sleep)",
                "Added because stored/imported context contained mechanical load or stress-amplified pain context."
            )
        }
        val steered = buildSteeredQueries(steering)
        val autonomous = AutonomousResearchPlanner().queries(autonomousPlan)
        return (steered + autonomous + globalCore + base).distinctBy { it.id }
    }

    private fun buildGlobalCoreQueries(): List<ResearchQuery> {
        return listOf(
            ResearchQuery(
                "q_global_antiviral_dataset",
                "Global antiviral response datasets",
                "(RNA-seq OR transcriptomic OR single-cell OR cohort OR dataset) AND (viral infection OR influenza OR RSV OR COVID OR hantavirus) AND (interferon OR viral load OR recovery OR severity)",
                "Finds public human immune datasets that separate protective antiviral response from deterioration or hyperinflammation."
            ),
            ResearchQuery(
                "q_global_trigger_response_outcome",
                "Trigger-response-outcome immune mapping",
                "(immune response OR cytokine OR interferon OR T cell OR antibody) AND (trigger OR exposure OR infection OR allergen) AND (outcome OR recovery OR severity) AND (dataset OR cohort)",
                "Looks for datasets that contain trigger, immune response axis, and outcome labels rather than isolated markers."
            ),
            ResearchQuery(
                "q_global_regulatory_brake_cross_condition",
                "Regulatory brake across conditions",
                "(IL-10 OR Treg OR regulatory T cells OR immune resolution) AND (allergy OR rheumatoid arthritis OR viral infection OR ARDS OR cytokine storm) AND (human OR patient OR cohort)",
                "Tests whether regulatory-brake failure bridges allergy, autoimmunity, and severe viral inflammation."
            ),
            ResearchQuery(
                "q_global_protection_damage_split",
                "Protection vs tissue damage split",
                "(interferon OR T cell OR antibody OR viral control) AND (tissue damage OR lung damage OR organ damage OR hyperinflammation) AND (human OR patient OR cohort)",
                "Separates useful pathogen control from damaging immune over-response."
            )
        )
    }

    private fun buildSteeredQueries(steering: ResearchSteeringProfile?): List<ResearchQuery> {
        if (steering == null || steering.variables.isEmpty()) return emptyList()
        // v0.9.1 privacy fix: sanitize user-supplied steering tokens BEFORE they
        // reach the outbound NCBI URL. This enforces the README claim that no
        // private case data is uploaded.
        val varSan = SteeringSanitizer.sanitize(steering.variables)
        val reqSan = SteeringSanitizer.sanitize(steering.requiredTerms)
        val excSan = SteeringSanitizer.sanitize(steering.excludedTerms)
        val variables = varSan.cleaned.take(8)
        val required = reqSan.cleaned.take(5)
        val focus = steering.focusQuestion.trim()
        val negative = excSan.cleaned.take(5).joinToString(" ") { "NOT " + pubmedTerm(it) }
        if (variables.isEmpty()) return emptyList()
        val out = mutableListOf<ResearchQuery>()

        val core = (variables + required).distinctBy { it.lowercase(Locale.US) }.take(10)
        if (core.isNotEmpty()) {
            val joined = core.joinToString(" AND ") { pubmedTerm(it) }
            out += ResearchQuery(
                id = "q_steer_core_${steering.profileId.takeLast(6)}",
                label = "Steered core variable search",
                query = listOf(joined, negative).filter { it.isNotBlank() }.joinToString(" "),
                reason = "User-directed research variables: ${variables.joinToString(", ")}. Focus: ${focus.ifBlank { "connect these variables and look for non-obvious mechanisms" }}"
            )
        }

        var pairIndex = 0
        for (i in 0 until variables.size) {
            for (j in i + 1 until variables.size) {
                if (pairIndex >= 8) break
                val a = variables[i]
                val b = variables[j]
                val contextTerms = required.joinToString(" OR ") { pubmedTerm(it) }
                val query = buildString {
                    append(pubmedTerm(a))
                    append(" AND ")
                    append(pubmedTerm(b))
                    if (contextTerms.isNotBlank()) append(" AND (").append(contextTerms).append(")")
                    if (negative.isNotBlank()) append(" ").append(negative)
                }
                out += ResearchQuery(
                    id = "q_steer_pair_${steering.profileId.takeLast(6)}_$pairIndex",
                    label = "Steered bridge: $a ↔ $b",
                    query = query,
                    reason = "User asked the engine to connect variables without code changes. Focus: ${focus.ifBlank { "find biological, causal, or hidden bridge mechanisms" }}"
                )
                pairIndex += 1
            }
        }
        return out
    }

    private fun pubmedTerm(term: String): String {
        val clean = term.trim().replace(Regex("\\s+"), " ").take(80)
        if (clean.isBlank()) return ""
        return if (clean.contains(" ")) "\"$clean\"" else clean
    }

    private fun inferAxisBoosts(records: List<String>, importedSignals: List<ImportedReportSignal>): Set<String> {
        val joined = (records.joinToString(" ") + " " + importedSignals.joinToString(" ") { it.matchedAxes.joinToString(" ") + " " + it.extractedKeywords.joinToString(" ") }).lowercase(Locale.US)
        val out = mutableSetOf<String>()
        if (joined.contains("allergylike\":true") || joined.contains("breathingdanger\":true") || joined.contains("type2_allergy_axis")) out += "airway"
        if (joined.contains("backordiscpain\":true") || joined.contains("mechanicalloadaxis") || joined.contains("psychomusculoskeletal_axis")) out += "mechanical"
        if (joined.contains("psychoneuroimmunestressaxis") || joined.contains("psychoneuroimmune_axis")) out += "stress"
        if (joined.contains("agingautonomicmap") || joined.contains("immunosenescenceaxis") || joined.contains("inflammagingaxis") || joined.contains("aging_immune_axis")) out += "aging"
        if (joined.contains("bloodpressureinstability") || joined.contains("dizzinessonstanding\":true") || joined.contains("faintnessduringallergy\":true") || joined.contains("autonomic_vascular_axis")) out += "autonomic"
        if (joined.contains("dna") || joined.contains("genomic") || joined.contains("epigenetic") || joined.contains("rna") || joined.contains("transcriptomic") || joined.contains("dna_genomic_axis") || joined.contains("rna_transcriptomic_axis")) out += "genomics"
        if (joined.contains("gutnutritionhormone") || joined.contains("gastric") || joined.contains("reflux") || joined.contains("microbiome") || joined.contains("protein") || joined.contains("musclemass") || joined.contains("testosterone") || joined.contains("gastric_acid_gut_axis") || joined.contains("testosterone_immune_axis")) out += "gut_metabolic"
        return out
    }


    private fun runDatasetFirstForaging(
        shards: List<TestableHypothesisShard>,
        memory: PersistentFailureMemorySnapshot,
        personalLedger: PersonalPatternLedger,
        seen: Set<String>,
        executedQueries: MutableList<ResearchQuery>,
        shouldStop: () -> Boolean,
        searchDeadline: Long
    ): DatasetForagingRunResult {
        val routes = DirectDatasetSourceRouter.routes(memory)
        val compiledQueries = DatasetQueryCompiler.compile(shards, memory).take(8)
        val findings = mutableListOf<ResearchFinding>()
        val candidates = mutableListOf<DatasetAccessionCandidate>()
        val attempts = mutableListOf<DatasetSourceAttempt>()

        fun canContinue(): Boolean = !shouldStop() && System.currentTimeMillis() < searchDeadline

        for (route in routes.take(4)) {
            if (!canContinue()) break
            val sourceQueries = when (route.sourceFamily) {
                "PUBMED_CONTRADICTION" -> compiledQueries.take(2).map { q ->
                    q.copy(
                        id = "q_v142_contrast_contradiction_${q.id.takeLast(16)}",
                        label = "v1.4.2 contrastive contradiction pass: ${q.label}",
                        query = "(${q.query}) AND (no association OR failed to replicate OR heterogeneity OR nonresponse OR harmful timing)",
                        reason = "Multi-pass evidence loop: contradiction/control check around a dataset shard."
                    )
                }
                "PUBMED_CONTROL" -> compiledQueries.take(2).map { q ->
                    q.copy(
                        id = "q_v142_control_${q.id.takeLast(16)}",
                        label = "v1.4.2 control pass: ${q.label}",
                        query = "(${q.query}) AND (negative control OR matched control OR control group OR baseline OR untreated)",
                        reason = "Multi-pass evidence loop: control-signal check around a dataset shard."
                    )
                }
                else -> compiledQueries.take(3).map { q ->
                    q.copy(
                        id = "q_v142_${route.sourceFamily.lowercase(Locale.US)}_${q.id.takeLast(20)}",
                        label = "DIRECT v1.4.2 ${route.sourceFamily}: ${q.label}",
                        query = q.query,
                        reason = route.reason + " " + q.reason
                    )
                }
            }

            for (query in sourceQueries) {
                if (!canContinue()) break
                if (executedQueries.any { it.id == query.id }) continue
                executedQueries += query
                if (route.ncbiDb == "pubmed") {
                    val ids = runCatching { searchPubMed(query.query, retMax = 10) }.getOrDefault(emptyList())
                    val fresh = ids.filter { id -> !seen.contains("PubMed:$id") && findings.none { it.source == "PubMed" && it.sourceId == id } }
                    val batch = if (fresh.isEmpty()) emptyList() else runCatching {
                        fetchPubMedSummariesBatch(fresh.take(20), query, personalLedger, ResearchRunLimits(maxResultsPerQuery = 10, maxAbstractsPerCycle = 1), emptySet())
                    }.getOrDefault(emptyList())
                    findings += batch
                    candidates += DatasetAccessionResolver.fromFindings(batch)
                    attempts += DatasetSourceAttempt(
                        sourceFamily = route.sourceFamily,
                        ncbiDb = route.ncbiDb,
                        query = query.query,
                        attempted = true,
                        idsFound = ids.size,
                        candidatesExtracted = DatasetAccessionResolver.fromFindings(batch).size,
                        status = if (batch.isEmpty()) "NO_FRESH_PUBMED_EVIDENCE" else "PUBMED_EVIDENCE_INSPECTED",
                        reason = route.reason
                    )
                } else {
                    val ids = runCatching { searchNcbiIds(route.ncbiDb, query.query, retMax = 12) }.getOrDefault(emptyList())
                    val fresh = ids.filter { id ->
                        val key1 = "NCBI_${route.sourceFamily}:$id"
                        !seen.contains(key1) && findings.none { it.sourceId == id && it.source.contains(route.sourceFamily) }
                    }
                    val batch = if (fresh.isEmpty()) emptyList() else runCatching {
                        fetchNcbiDatasetSummariesBatch(route, fresh.take(20), query, personalLedger)
                    }.getOrDefault(emptyList())
                    findings += batch
                    val extracted = DatasetAccessionResolver.fromFindings(batch)
                    candidates += extracted
                    attempts += DatasetSourceAttempt(
                        sourceFamily = route.sourceFamily,
                        ncbiDb = route.ncbiDb,
                        query = query.query,
                        attempted = true,
                        idsFound = ids.size,
                        candidatesExtracted = extracted.size,
                        status = when {
                            ids.isEmpty() -> "SOURCE_SEARCH_NO_IDS"
                            batch.isEmpty() -> "IDS_FOUND_BUT_NO_USABLE_METADATA"
                            extracted.isEmpty() -> "METADATA_FOUND_NO_ACCESSION"
                            else -> "DATASET_CANDIDATES_EXTRACTED"
                        },
                        reason = route.reason
                    )
                }
            }
        }

        val distinctCandidates = candidates
            .distinctBy { it.accession + ":" + it.sourceFindingId }
            .sortedByDescending { it.usabilityScore }
            .take(30)
        val parsedMetadata = DatasetParser.parse(distinctCandidates, findings)
        val contrastiveReport = ContrastiveEvidenceGate.evaluate(parsedMetadata)
        val evidenceHypergraph = EvidenceHypergraphLite.build(parsedMetadata)
        val cumulativeEvidence = CumulativeEvidenceScorer.score(emptyList(), parsedMetadata)
        val sourceFamilies = attempts.map { it.sourceFamily }.distinct()
        val pass1 = DatasetForagingPass(
            passId = "PASS1_DATASET_ACCESSION_HUNT",
            label = "Direct dataset accession hunt",
            status = if (attempts.any { it.idsFound > 0 }) "ATTEMPTED_WITH_SOURCE_RESPONSE" else "ATTEMPTED_NO_IDS",
            attempts = attempts.filter { it.ncbiDb != "pubmed" }
        )
        val pass2 = DatasetForagingPass(
            passId = "PASS2_METADATA_USABILITY_INSPECTION",
            label = "Metadata usability inspection",
            status = if (distinctCandidates.isEmpty()) "NO_CANDIDATE_TO_SCORE" else "CANDIDATES_SCORED_${distinctCandidates.size}",
            attempts = attempts.filter { it.candidatesExtracted > 0 }
        )
        val pass3 = DatasetForagingPass(
            passId = "PASS3_CONTRADICTION_CONTROL_CHECK",
            label = "Contradiction/control check around candidate shards",
            status = if (attempts.any { it.ncbiDb == "pubmed" && it.idsFound > 0 }) "SECONDARY_CHECK_ATTEMPTED" else "SECONDARY_CHECK_NO_IDS_OR_NOT_REACHED",
            attempts = attempts.filter { it.ncbiDb == "pubmed" }
        )
        val blockedReason = when {
            distinctCandidates.isNotEmpty() -> "Learning allowed only as dataset-candidate inspection; hypothesis upgrade still requires evidence object quality."
            attempts.any { it.idsFound > 0 } -> "Learning blocked: source returned IDs but no usable accession/metadata candidate survived."
            else -> "Learning blocked: direct dataset-source searches returned no usable evidence object."
        }
        return DatasetForagingRunResult(
            findings = findings.distinctBy { it.source + ":" + it.sourceId },
            report = DatasetForagingReport(
                active = true,
                state = if (distinctCandidates.isEmpty()) "DATASET_FORAGING_NO_CANDIDATE" else "DATASET_FORAGING_CANDIDATE_INSPECTION",
                evidenceMode = "DATASET_FIRST_MULTI_PASS",
                sourceFamiliesAttempted = sourceFamilies,
                hypothesisShards = shards,
                passes = listOf(pass1, pass2, pass3),
                candidates = distinctCandidates,
                parsedMetadata = parsedMetadata,
                contrastiveReport = contrastiveReport,
                evidenceHypergraph = evidenceHypergraph,
                cumulativeEvidence = cumulativeEvidence,
                blockedLearningReason = blockedReason,
                nextAction = if (distinctCandidates.isEmpty()) {
                    "Change evidence representation: search by outcome labels such as response/nonresponse, severity, recovery, and longitudinal labels before disease names."
                } else {
                    "Inspect the highest-scoring dataset candidate for condition labels, outcome labels, sample size, and license before any hypothesis upgrade."
                }
            )
        )
    }

    private fun learnAndRank(
        findings: List<ResearchFinding>,
        importedSignals: List<ImportedReportSignal>,
        steering: ResearchSteeringProfile?,
        shouldStop: () -> Boolean,
        deadlineMillis: Long
    ): List<ResearchFinding> {
        if (shouldStop() || System.currentTimeMillis() >= deadlineMillis) return findings.take(20)
        val importedAxes = importedSignals.flatMap { it.matchedAxes }.toSet()
        val steeringAxes = steering?.inferredAxes?.toSet() ?: emptySet()
        val steeringTerms = (steering?.variables.orEmpty() + steering?.requiredTerms.orEmpty()).map { it.lowercase(Locale.US) }
        return findings
            .distinctBy { it.source + it.sourceId }
            .map { finding ->
                val overlapBoost = finding.matchedAxes.count { importedAxes.contains(it) } * 5
                val steeringAxisBoost = finding.matchedAxes.count { steeringAxes.contains(it) } * 6
                val text = (finding.title + " " + finding.bridgeSignal + " " + finding.whyItMatters).lowercase(Locale.US)
                val steeringTermBoost = steeringTerms.count { it.isNotBlank() && text.contains(it) } * 3
                val omicsBoost = if (finding.matchedAxes.any { it == "dna_genomic_axis" || it == "rna_transcriptomic_axis" }) 10 else 0
                val evidenceBoost = (finding.evidence.evidenceQualityScore - 50).coerceIn(-20, 25) / 2
                val causalBoost = (finding.causality.causalityScore - 45).coerceIn(-20, 25) / 2
                val controlPenalty = if (finding.negativeControl.status == "weak_no_control_possible") 4 else 0
                finding.copy(noveltyScore = (finding.noveltyScore + overlapBoost + steeringAxisBoost + steeringTermBoost + omicsBoost + evidenceBoost + causalBoost - controlPenalty).coerceIn(0, 100))
            }
            .sortedWith(compareByDescending<ResearchFinding> { it.noveltyScore }.thenByDescending { it.matchedAxes.size })
            .take(24)
    }


    private fun searchNcbiIds(db: String, query: String, retMax: Int): List<String> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=$db&sort=relevance&retmode=json&retmax=$retMax&term=$encoded$ncbiCredentials"
        val text = httpGetWithRetry(url)
        val root = JSONObject(text)
        val arr = root.optJSONObject("esearchresult")?.optJSONArray("idlist") ?: return emptyList()
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    }

    private fun fetchNcbiDatasetSummariesBatch(
        route: DirectDatasetSourceRouter.SourceRoute,
        ids: List<String>,
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger
    ): List<ResearchFinding> {
        if (ids.isEmpty()) return emptyList()
        val joined = ids.joinToString(",")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=${route.ncbiDb}&retmode=json&id=$joined$ncbiCredentials"
        val text = runCatching { httpGetWithRetry(url) }.getOrNull() ?: return emptyList()
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return emptyList()
        val resultObj = root.optJSONObject("result") ?: return emptyList()
        return ids.mapNotNull { id ->
            val doc = resultObj.optJSONObject(id) ?: return@mapNotNull null
            buildFindingFromDatasetDoc(route, id, doc, query, personalLedger)
        }
    }

    private fun buildFindingFromDatasetDoc(
        route: DirectDatasetSourceRouter.SourceRoute,
        uid: String,
        doc: JSONObject,
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger
    ): ResearchFinding? {
        val docText = flattenJsonObject(doc).take(8000)
        val title = firstNonBlank(
            doc.optString("title"),
            doc.optString("exp_title"),
            doc.optString("study_title"),
            doc.optString("caption"),
            doc.optString("gds"),
            "Untitled dataset candidate"
        ).take(240)
        val accession = DatasetAccessionResolver.extract(docText + " " + uid, "NCBI_${route.sourceFamily}:$uid", title, "")
            .firstOrNull { it.accession != "DATASET_ACCESSION_UNRESOLVED" }
            ?.accession
            ?: firstNonBlank(doc.optString("accession"), doc.optString("bioproject"), uid)
        val datasetText = "$accession $title $docText"
        val queryRoute = RouteFitGate.inferDatasetRoute("${query.query} ${query.reason}")
        val datasetRoute = RouteFitGate.inferDatasetRoute(datasetText)
        val axes = matchAxes(datasetText)
        val evidence = SourceClassifier.classifySource(datasetText, listOf("Dataset", route.sourceFamily))
        val personal = personalLedger.assess(axes)
        val negativePreview = NegativeControlEngine.assess(axes, 0)
        val causality = CausalityScorer.score(datasetText, axes, evidence, personal, negativePreview.status)
        val negative = NegativeControlEngine.assess(axes, causality.causalityScore)
        val url = when {
            accession.startsWith("GSE") || accession.startsWith("GDS") || accession.startsWith("GSM") -> "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=$accession"
            accession.startsWith("PRJNA") -> "https://www.ncbi.nlm.nih.gov/bioproject/$accession"
            route.ncbiDb == "sra" -> "https://www.ncbi.nlm.nih.gov/sra/$uid"
            route.ncbiDb == "gds" -> "https://www.ncbi.nlm.nih.gov/gds/$uid"
            else -> "https://www.ncbi.nlm.nih.gov/${route.ncbiDb}/$uid"
        }
        val sourceName = when (route.sourceFamily) {
            "GEO_GDS" -> "NCBI_GEO_GDS"
            "SRA_PRJNA" -> "NCBI_SRA_PRJNA"
            else -> "NCBI_${route.sourceFamily}"
        }
        return ResearchFinding(
            source = sourceName,
            sourceId = accession,
            title = "$accession — $title".take(260),
            published = firstNonBlank(doc.optString("pdat"), doc.optString("pd"), doc.optString("created"), "dataset_metadata"),
            url = url,
            matchedAxes = axes,
            noveltyScore = (55 + axes.size * 8 + if (accession != uid) 12 else 0).coerceIn(0, 100),
            bridgeSignal = "Direct dataset-source candidate from ${route.sourceFamily}; dataset route $datasetRoute; target route $queryRoute; inspect metadata before hypothesis upgrade.",
            whyItMatters = "This source can break the PubMed-only loop by providing an accession/metadata object. Route-fit must be checked before using it for any hypothesis.",
            evidence = evidence,
            causality = causality,
            negativeControl = negative,
            personalPattern = personal,
            sanityFlags = listOf("DIRECT_DATASET_SOURCE", "METADATA_NEEDS_INSPECTION", "ROUTE_FIT_PENDING", "DATASET_ROUTE_$datasetRoute", "TARGET_ROUTE_$queryRoute").distinct()
        )
    }

    private fun flattenJsonObject(obj: JSONObject): String {
        val out = mutableListOf<String>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = obj.opt(key)
            if (value != null && value != JSONObject.NULL) out += "$key=$value"
        }
        return out.joinToString(" ")
    }

    private fun firstNonBlank(vararg values: String): String {
        return values.firstOrNull { it.isNotBlank() } ?: ""
    }

    private fun searchPubMed(query: String, retMax: Int): List<String> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&sort=pub+date&retmode=json&retmax=$retMax&term=$encoded$ncbiCredentials"
        val text = httpGetWithRetry(url)
        val root = JSONObject(text)
        val arr = root.optJSONObject("esearchresult")?.optJSONArray("idlist") ?: return emptyList()
        val ids = mutableListOf<String>()
        for (i in 0 until arr.length()) ids += arr.optString(i)
        return ids.filter { it.isNotBlank() }
    }

    /**
     * v0.9.1: Batched esummary. NCBI accepts up to 200 IDs in a single request.
     * v0.9.0 was issuing one request per pmid, which produced ~150 round-trips
     * per cycle and wasted ~2 minutes against NCBI's 3-req/sec ceiling.
     *
     * v1.0: Now also batch-fetches abstracts via efetch and uses them to
     * enrich evidence classification. Title-only classification is too
     * shallow for serious evidence triage; abstract text catches mechanism
     * keywords, study design, sample size hints, and limitations.
     */
    private fun fetchPubMedSummariesBatch(
        pmids: List<String>,
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger,
        limits: ResearchRunLimits,
        seenAbstracts: Set<String> = emptySet()
    ): List<ResearchFinding> {
        if (pmids.isEmpty()) return emptyList()
        val joined = pmids.joinToString(",")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id=$joined$ncbiCredentials"
        val text = runCatching { httpGetWithRetry(url) }.getOrNull() ?: return emptyList()
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return emptyList()
        val resultObj = root.optJSONObject("result") ?: return emptyList()
        // v1.3.3: metadata first, then selectively fetch top abstracts only.
        // This prevents 50–100MB cycles while still allowing the best candidates
        // to become mechanism/dataset leads.
        val firstPass = mutableListOf<ResearchFinding>()
        val docs = linkedMapOf<String, JSONObject>()
        for (pmid in pmids) {
            val doc = resultObj.optJSONObject(pmid) ?: continue
            docs[pmid] = doc
            val finding = buildFindingFromDoc(pmid, doc, query, personalLedger, "") ?: continue
            firstPass += finding
        }
        val abstracts = if (limits.fetchAbstracts || limits.enableSelectiveAbstracts) {
            val chosen = if (limits.fetchAbstracts) {
                firstPass.take(limits.maxAbstractsPerCycle).map { AbstractCandidateScore(it.sourceId, 100, listOf("forced abstract mode")) }
            } else {
                SelectiveAbstractFetcher.select(
                    firstPass,
                    alreadySeen = seenAbstracts,
                    threshold = limits.abstractEligibilityThreshold,
                    maxAbstracts = limits.maxAbstractsPerCycle
                )
            }
            if (chosen.isEmpty()) emptyMap() else runCatching { fetchPubMedAbstractsBatch(chosen.map { it.pmid }) }.getOrDefault(emptyMap())
        } else {
            emptyMap()
        }
        if (abstracts.isEmpty()) return firstPass
        return firstPass.map { finding ->
            val abstractText = abstracts[finding.sourceId]
            if (abstractText.isNullOrBlank()) finding
            else buildFindingFromDoc(finding.sourceId, docs[finding.sourceId] ?: return@map finding, query, personalLedger, abstractText) ?: finding
        }
    }

    /**
     * v1.0: Fetch abstract text for up to 200 pmids in a single efetch call.
     * Returns map of pmid -> abstract text. Returns empty map on any failure
     * (caller falls back gracefully to title-only classification).
     *
     * Uses retmode=text with rettype=abstract, then parses by PMID markers.
     * This is intentionally tolerant: NCBI's text format has minor variations
     * across journals.
     */
    private fun fetchPubMedAbstractsBatch(pmids: List<String>): Map<String, String> {
        if (pmids.isEmpty()) return emptyMap()
        val joined = pmids.joinToString(",")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&rettype=abstract&retmode=text&id=$joined$ncbiCredentials"
        val text = runCatching { httpGetWithRetry(url) }.getOrNull() ?: return emptyMap()
        return parseAbstractText(text)
    }

    /**
     * Parse PubMed efetch abstract text into pmid -> body map.
     *
     * Format example per record:
     *   N. Citation. Year;Vol(Iss):Pages.
     *
     *   Title
     *
     *   Authors
     *
     *   Affiliation
     *
     *   Abstract paragraph...
     *
     *   DOI: 10.xxxx/...
     *   PMID: 12345678 [Indexed for MEDLINE]
     *
     * Records are separated by blank lines. We split on lines that start
     * with a record number "1.", "2.", ... and look for the trailing PMID.
     */
    internal fun parseAbstractText(text: String): Map<String, String> {
        if (text.isBlank()) return emptyMap()
        val out = mutableMapOf<String, String>()
        val pmidPattern = Regex("""PMID:\s*(\d+)""")
        // Records start with a line like "1. " or "2. " at the beginning of a line
        // (after a blank line). Use a lookahead split.
        val records = text.split(Regex("(?=\\r?\\n\\d+:?\\s*[A-Z])"))
        for (record in records) {
            val match = pmidPattern.find(record) ?: continue
            val pmid = match.groupValues[1]
            // Cap each abstract at 4 KB so a single junk record can't blow up memory
            val body = record.trim().take(4096)
            if (body.isNotBlank()) out[pmid] = body
        }
        // Fallback: if the regex split produced one big blob (some journals
        // don't use numbered records), do a per-PMID linear scan.
        if (out.isEmpty()) {
            val matches = pmidPattern.findAll(text).toList()
            for ((idx, m) in matches.withIndex()) {
                val pmid = m.groupValues[1]
                val start = if (idx == 0) 0 else matches[idx - 1].range.last + 1
                val end = m.range.last + 1
                val body = text.substring(start, end).trim().take(4096)
                if (body.isNotBlank()) out[pmid] = body
            }
        }
        return out
    }

    private fun buildFindingFromDoc(
        pmid: String,
        doc: JSONObject,
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger,
        abstractText: String = ""
    ): ResearchFinding? {
        val title = doc.optString("title", "Untitled")
        val published = doc.optString("pubdate", "unknown")
        val pubTypeArray = doc.optJSONArray("pubtype")
        val pubTypes = if (pubTypeArray == null) emptyList() else (0 until pubTypeArray.length()).map { pubTypeArray.optString(it) }.filter { it.isNotBlank() }
        // v1.0: include abstract text in evidenceText so SourceClassifier and
        // CausalityScorer can use mechanism/study-design/temporal cues that
        // titles often hide.
        val evidenceText = title + " " + query.query + " " + query.reason + " " + pubTypes.joinToString(" ") + " " + abstractText
        val axes = matchAxes(evidenceText)
        var evidence = SourceClassifier.classifySource(evidenceText, pubTypes)
        // v1.1: statistical sanity gates promised in CANONICAL_SCORING_FORMULA_v0.9.1.md.
        val sanityFlags = mutableListOf<String>()
        if (abstractText.isBlank()) sanityFlags += "ABSTRACT_FETCH_FAILED"
        if (evidence.speciesClass == "unknown" && abstractText.isBlank()) {
            sanityFlags += "METADATA_ONLY"
            // Cap evidence quality at 45 to prevent metadata-only sources from
            // ranking with full-text-evidence sources.
            if (evidence.evidenceQualityScore > 45) {
                evidence = evidence.copy(evidenceQualityScore = 45)
            }
        }
        val personal = personalLedger.assess(axes)
        if (personal.repeatedObservationCount in 1..2) {
            sanityFlags += "LOW_POWER"
        }
        val negativePreview = NegativeControlEngine.assess(axes, 0)
        val causality = CausalityScorer.score(evidenceText, axes, evidence, personal, negativePreview.status)
        val negative = NegativeControlEngine.assess(axes, causality.causalityScore)
        val score = scoreNovelty(axes, title, query)
        return ResearchFinding(
            source = "PubMed",
            sourceId = pmid,
            title = title,
            published = published,
            url = "https://pubmed.ncbi.nlm.nih.gov/$pmid/",
            matchedAxes = axes,
            noveltyScore = score,
            bridgeSignal = bridgeSignal(axes),
            whyItMatters = whyItMatters(axes, query),
            evidence = evidence,
            causality = causality,
            negativeControl = negative,
            personalPattern = personal,
            sanityFlags = sanityFlags.distinct()
        )
    }

    private fun fetchPubMedSummary(pmid: String, query: ResearchQuery, personalLedger: PersonalPatternLedger): ResearchFinding? {
        // Kept for backward compatibility with any single-id callers.
        return fetchPubMedSummariesBatch(listOf(pmid), query, personalLedger, ResearchRunLimits(enableSelectiveAbstracts = false), emptySet()).firstOrNull()
    }

    private fun matchAxes(text: String): List<String> {
        // v1.1: delegate to the single-source-of-truth AxisMatcher to prevent
        // drift between this method and ResearchKnowledgeStore.inferAxes.
        return AxisMatcher.match(text)
    }

    private fun scoreNovelty(axes: List<String>, title: String, query: ResearchQuery): Int {
        var score = min(95, 20 + axes.size * 12)
        if (axes.contains("psychoneuroimmune_axis") && axes.contains("type2_allergy_axis")) score += 12
        if (axes.contains("psychoneuroimmune_axis") && axes.contains("tnf_il6_autoimmune_axis")) score += 10
        if (axes.contains("psychomusculoskeletal_axis") && axes.contains("psychoneuroimmune_axis")) score += 10
        if (axes.contains("regulatory_brake_axis") && axes.contains("hyperinflammatory_axis")) score += 10
        if (axes.contains("aging_immune_axis") && axes.contains("type2_allergy_axis")) score += 14
        if (axes.contains("autonomic_vascular_axis") && axes.contains("type2_allergy_axis")) score += 12
        if (axes.contains("autonomic_vascular_axis") && axes.contains("psychoneuroimmune_axis")) score += 8
        if (axes.contains("dna_genomic_axis") && axes.contains("aging_immune_axis")) score += 14
        if (axes.contains("gastric_acid_gut_axis") && axes.contains("type2_allergy_axis")) score += 16
        if (axes.contains("gut_barrier_microbiome_axis") && axes.contains("type2_allergy_axis")) score += 15
        if (axes.contains("nutrition_protein_axis") && axes.contains("muscle_mass_reserve_axis")) score += 12
        if (axes.contains("testosterone_immune_axis") && (axes.contains("tnf_il6_autoimmune_axis") || axes.contains("type2_allergy_axis"))) score += 14
        if (axes.contains("rna_transcriptomic_axis") && axes.contains("type2_allergy_axis")) score += 14
        if (axes.contains("rna_transcriptomic_axis") && axes.contains("tnf_il6_autoimmune_axis")) score += 12
        if (axes.contains("dna_genomic_axis") && axes.contains("type2_allergy_axis")) score += 10
        if (title.lowercase(Locale.US).contains("review")) score -= 5
        if (query.id.contains("cross") || query.id.contains("dna") || query.id.contains("rna") || query.id.contains("mirna")) score += 8
        return score.coerceIn(0, 100)
    }

    private fun bridgeSignal(axes: List<String>): String {
        val joined = axes.joinToString(" + ")
        return when {
            axes.size >= 3 -> "Cross-axis bridge candidate: $joined"
            axes.size == 2 -> "Two-axis bridge candidate: $joined"
            axes.size == 1 -> "Single-axis evidence: ${axes.first()}"
            else -> "Weak match; keep only as background lead"
        }
    }

    private fun whyItMatters(axes: List<String>, query: ResearchQuery): String {
        return when {
            axes.contains("gastric_acid_gut_axis") && axes.contains("type2_allergy_axis") -> "May connect stomach-acid/reflux/acid-suppression context with allergy through gut-barrier, microbiome, or airway reflux pathways."
            axes.contains("gut_barrier_microbiome_axis") && axes.contains("type2_allergy_axis") -> "May connect gut microbiome/barrier state with allergic or airway immune reactivity."
            axes.contains("nutrition_protein_axis") && axes.contains("muscle_mass_reserve_axis") -> "May connect protein/diet adequacy and muscle reserve with immune recovery and aging resilience."
            axes.contains("testosterone_immune_axis") -> "May test whether androgen/testosterone context modulates immune tone, inflammatory balance, muscle reserve, or recovery."
            axes.contains("dna_genomic_axis") && axes.contains("aging_immune_axis") -> "May connect DNA/epigenetic aging signals with immune responsiveness or inflammaging."
            axes.contains("rna_transcriptomic_axis") && axes.contains("type2_allergy_axis") -> "May reveal RNA expression patterns behind allergy reactivity beyond serum markers."
            axes.contains("rna_transcriptomic_axis") && axes.contains("tnf_il6_autoimmune_axis") -> "May help compare transcriptomic inflammatory states across RA-like and other immune axes."
            axes.contains("psychoneuroimmune_axis") && axes.contains("type2_allergy_axis") -> "May help test whether stress/sleep shifts airway or allergy reactivity rather than merely coinciding with symptoms."
            axes.contains("psychoneuroimmune_axis") && axes.contains("tnf_il6_autoimmune_axis") -> "May connect chronic stress/recovery debt with inflammatory-axis amplification in autoimmune-like patterns."
            axes.contains("psychomusculoskeletal_axis") && axes.contains("psychoneuroimmune_axis") -> "May explain pain persistence through stress, sleep, guarding, and sensitization without claiming structural causation."
            axes.contains("aging_immune_axis") && axes.contains("type2_allergy_axis") -> "May test whether allergic reactivity is preserved responsiveness in one context or inflammaging burden in another."
            axes.contains("autonomic_vascular_axis") && axes.contains("type2_allergy_axis") -> "May connect allergy/histamine-like episodes to blood-pressure instability or vasodilation patterns."
            axes.contains("regulatory_brake_axis") -> "May reveal a brake-failure mechanism shared across mild and severe over-response states."
            else -> "Relevant to query: ${query.label}. Needs full-text review and comparison against local case vectors."
        }
    }

    private fun buildEmergentLinks(findings: List<ResearchFinding>, importedSignals: List<ImportedReportSignal>, steering: ResearchSteeringProfile?): List<String> {
        val links = mutableListOf<String>()
        if (steering != null && steering.variables.isNotEmpty()) {
            links += "Steered research active: ${steering.variables.take(6).joinToString(" ↔ ")}. Treat links as hypotheses until repeated temporal/data evidence appears."
        }
        if (findings.any { it.matchedAxes.contains("interferon_antiviral_axis") && it.matchedAxes.contains("resolution_recovery_axis") }) links += "Global antiviral bridge: interferon timing plus recovery/resolution labels should be prioritized before any variant-resilience hypothesis."
        if (findings.any { it.matchedAxes.contains("interferon_antiviral_axis") && it.matchedAxes.contains("tissue_damage_axis") }) links += "Protection-vs-damage split detected: separate pathogen-control signals from tissue-injury signals."
        if (findings.any { it.matchedAxes.contains("tcell_activation_axis") || it.matchedAxes.contains("bcell_antibody_axis") }) links += "Adaptive immune response detected: model T-cell/B-cell memory separately from acute cytokine intensity."
        if (findings.any { it.matchedAxes.contains("psychoneuroimmune_axis") && it.matchedAxes.contains("type2_allergy_axis") }) links += "Stress/sleep may be treated as an amplifier axis for Type-2 airway/allergy signals, not as a standalone cause."
        if (findings.any { it.matchedAxes.contains("psychomusculoskeletal_axis") && it.matchedAxes.contains("psychoneuroimmune_axis") }) links += "Back/disc-like patterns should track mechanical load + sleep + fear/tension loops as a recovery-failure model."
        if (findings.any { it.matchedAxes.contains("regulatory_brake_axis") && it.matchedAxes.contains("hyperinflammatory_axis") }) links += "Regulatory-brake failure remains a bridge candidate from mild immune misfires to systemic runaway amplification."
        if (findings.any { it.matchedAxes.contains("aging_immune_axis") && it.matchedAxes.contains("type2_allergy_axis") }) links += "Allergy-aging link should be modeled as nonlinear: preserved responsiveness vs chronic inflammaging burden."
        if (findings.any { it.matchedAxes.contains("autonomic_vascular_axis") && it.matchedAxes.contains("type2_allergy_axis") }) links += "Autonomic-mast-cell vascular bridge candidate: stress pressure-up may compete with histamine pressure-down."
        if (findings.any { it.matchedAxes.contains("dna_genomic_axis") && it.matchedAxes.contains("aging_immune_axis") }) links += "DNA/epigenetic aging markers may be useful as a bridge between immune responsiveness and inflammaging load."
        if (findings.any { it.matchedAxes.contains("gastric_acid_gut_axis") && it.matchedAxes.contains("type2_allergy_axis") }) links += "Gut-acid/reflux/acid-suppression context should be tracked against allergy intensity, airway symptoms, and microbiome/gut-barrier findings."
        if (findings.any { it.matchedAxes.contains("testosterone_immune_axis") }) links += "Testosterone/androgen context should be modeled as immune-modulation and recovery/muscle-reserve hypothesis, not endocrine diagnosis."
        if (findings.any { it.matchedAxes.contains("rna_transcriptomic_axis") && (it.matchedAxes.contains("type2_allergy_axis") || it.matchedAxes.contains("tnf_il6_autoimmune_axis")) }) links += "RNA/transcriptomic signatures may expose hidden immune states that routine blood biomarkers miss."
        if (importedSignals.any { it.matchedAxes.contains("dna_genomic_axis") || it.matchedAxes.contains("rna_transcriptomic_axis") }) links += "Manual imported reports introduced DNA/RNA context; prioritize source-quality review before treating it as a confirmed mechanism."
        if (links.isEmpty()) links += "No strong new cross-axis bridge found in this cycle; broaden queries or inspect full texts manually."
        return links.distinct()
    }

    private fun buildNextQuestions(findings: List<ResearchFinding>, importedSignals: List<ImportedReportSignal>, steering: ResearchSteeringProfile?, autonomousPlan: AutonomousResearchPlan): List<String> {
        val questions = mutableListOf<String>()
        if (steering != null && steering.variables.isNotEmpty()) {
            questions += "For the steered variables (${steering.variables.take(6).joinToString(", ")}), what temporal order would falsify the assumed relationship?"
            questions += "Which steered variable is likely a trigger, amplifier, maintainer, marker, or coincidence?"
        }
        val nextLaneLabel = autonomousPlan.lanes.firstOrNull()?.label ?: "global trigger-response dataset discovery"
        questions += "Which autonomous lane should be deepened next: $nextLaneLabel?"
        questions += "Which public dataset has trigger, immune-response axis, and outcome labels rather than markers alone?"
        questions += "Does adding stress/sleep context improve separation beyond biomarkers alone?"
        questions += "Which axis changes first: Type-2, interferon antiviral, TNF/IL-6, regulatory brake, DNA/RNA expression, or tissue-damage context?"
        questions += "Does high allergy reactivity pair with low inflammaging and fast recovery, or with chronic inflammatory burden?"
        questions += "During stress/allergy episodes, does BP/pulse move upward, downward, or become unstable?"
        if (findings.any { it.matchedAxes.contains("dna_genomic_axis") }) questions += "Which DNA/epigenetic signals are repeated across allergy, aging, and inflammatory datasets?"
        if (findings.any { it.matchedAxes.contains("gastric_acid_gut_axis") }) questions += "Do reflux, low-acid suspicion, PPI/antacid context, or gastritis/H. pylori history cluster before allergy or airway flares?"
        if (findings.any { it.matchedAxes.contains("nutrition_protein_axis") || it.matchedAxes.contains("muscle_mass_reserve_axis") }) questions += "Does protein/diet diversity and muscle reserve predict faster recovery or lower inflammatory load?"
        if (findings.any { it.matchedAxes.contains("testosterone_immune_axis") }) questions += "Does testosterone/androgen context modify allergy, inflammatory tone, muscle reserve, or fatigue recovery in repeated observations?"
        if (findings.any { it.matchedAxes.contains("interferon_antiviral_axis") }) questions += "Do early interferon signatures separate recovery from hyperinflammatory deterioration across viral datasets?"
        if (findings.any { it.matchedAxes.contains("tissue_damage_axis") }) questions += "Which markers separate immune protection from host tissue damage?"
        if (findings.any { it.matchedAxes.contains("rna_transcriptomic_axis") }) questions += "Which RNA/transcriptomic genes recur across allergy, RA-like inflammation, antiviral response, and hyperinflammatory literature?"
        if (importedSignals.isNotEmpty()) questions += "Do imported personal reports support the same axis pairs as public sources, or do they contradict them?"
        if (findings.any { it.noveltyScore >= 70 }) questions += "Manually review high-novelty papers and add confirmed mechanisms to axis/rule JSON files."
        if (findings.any { it.evidence.speciesClass != "human" }) questions += "Which leads are human evidence vs animal/cell-only? Do not merge them in the same confidence bucket."
        if (findings.any { it.negativeControl.status.contains("control") }) questions += "Which top hypothesis survives reverse-time, shuffled-timeline, and unrelated-marker negative controls?"
        return questions.distinct()
    }

    private fun computeNewAxisPairs(findings: List<ResearchFinding>, seenPairs: Set<String>): List<String> {
        return findings.flatMap { finding ->
            val axes = finding.matchedAxes.sorted()
            axes.flatMapIndexed { idx, a -> axes.drop(idx + 1).map { b -> "$a + $b" } }
        }.distinct().filterNot { seenPairs.contains(it) }.take(20)
    }

    private fun buildLearningNotes(
        findings: List<ResearchFinding>,
        importedSignals: List<ImportedReportSignal>,
        newAxisPairs: List<String>,
        stopReason: String,
        steering: ResearchSteeringProfile?,
        autonomousPlan: AutonomousResearchPlan,
        stagnationPlan: AutonomousStagnationEngine.StagnationPlan? = null,
        runtimeStatus: ActiveResearchEngineStatus,
        executionLockReport: ExecutionLockReport
    ): List<String> {
        val notes = mutableListOf<String>()
        notes += "Search stop reason: $stopReason. Active engine ${runtimeStatus.engineVersion}; state ${runtimeStatus.researchState}; executed ${runtimeStatus.executedQueryIds.size} queries; PubMed retmax ${runtimeStatus.effectiveResultsPerQuery}."
        notes += "Execution lock: ${executionLockReport.status}; ${executionLockReport.enforcedActions.joinToString("; ")}."
        notes += "Autonomous researcher mode: the engine chooses Explore + Deepen + Challenge lanes by itself; research steering is optional acceleration."
        notes += "New source policy: previously stored PubMed IDs are skipped. If many sources are skipped, the next cycle rotates strategy instead of requiring user guidance."
        if (stagnationPlan != null && stagnationPlan.active) {
            notes += "v1.3.6 anti-stagnation active: applied previous pivot ${stagnationPlan.pendingPivot.pivotType}; effective queries ${stagnationPlan.effectiveMaxQueries}; PubMed retmax ${stagnationPlan.effectiveResultsPerQuery}."
            notes += "Anti-stagnation reason: ${stagnationPlan.reason}"
        }
        notes += "Autonomous plan: ${autonomousPlan.strategy}; next fallback: ${autonomousPlan.nextStrategyIfNoUsefulSource}"
        notes += "v1.2 lock policy: only findings that change a hypothesis rank, gate, state, next measurement, or bias warning enter the main report."
        notes += "v1.3 global policy: prioritize public datasets, immune-axis mapping, and trigger-response-outcome structure before any ML model."
        if (steering != null && steering.variables.isNotEmpty()) notes += "Research steering active: ${steering.variables.take(8).joinToString(", ")}; generated directed variable-bridge queries without changing code."
        if (newAxisPairs.isNotEmpty()) notes += "New axis pairs found: ${newAxisPairs.take(5).joinToString("; ")}."
        if (findings.any { it.matchedAxes.contains("dna_genomic_axis") }) notes += "DNA/genomic axis appeared; separate epigenetic-aging from inherited-variant evidence."
        if (findings.any { it.matchedAxes.contains("gastric_acid_gut_axis") }) notes += "Gut-acid axis appeared; separate reflux/GERD, low-acid suspicion, acid suppression, gastritis/H. pylori, and microbiome mechanisms."
        if (findings.any { it.matchedAxes.contains("testosterone_immune_axis") }) notes += "Testosterone axis appeared; treat as hormone-immune modulation hypothesis, not diagnosis or replacement advice."
        if (findings.any { it.matchedAxes.contains("interferon_antiviral_axis") }) notes += "Interferon/antiviral axis appeared; separate early pathogen-control from late inflammatory damage."
        if (findings.any { it.matchedAxes.contains("tcell_activation_axis") || it.matchedAxes.contains("bcell_antibody_axis") }) notes += "Adaptive antiviral axis appeared; track T-cell/B-cell evidence separately from cytokine intensity."
        if (findings.any { it.matchedAxes.contains("rna_transcriptomic_axis") }) notes += "RNA/transcriptomic axis appeared; prioritize expression signatures over single-marker assumptions."
        if (importedSignals.isNotEmpty()) notes += "Manual reports used: ${importedSignals.size}; treat them as private leads until source quality is checked."
        if (findings.isEmpty()) notes += "No useful new source found; the autonomous planner will rotate toward dataset, omics, or contradiction search in the next cycle."
        return notes.distinct()
    }

    private fun httpGet(urlText: String): String {
        val connection = (URL(urlText).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10000
            readTimeout = 15000
            setRequestProperty("User-Agent", "ImmuneErrorRadarPrivateResearch/1.3.3")
        }
        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            BufferedReader(InputStreamReader(stream)).use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    /**
     * v0.9.1: NCBI compliance & resilience.
     *
     * - Adds tool=&email= as required by NCBI E-utilities policy
     *   (https://www.ncbi.nlm.nih.gov/books/NBK25497/).
     * - Adds optional api_key= via local file `ncbi_api_key.txt`
     *   (raises rate limit from 3/sec to 10/sec).
     * - Adds 2 retries with exponential backoff on transient HTTP failures.
     */
    private val ncbiCredentials: String by lazy {
        val email = "private-research@immune-error-radar.local"
        val tool = "ImmuneErrorRadarPrivateResearch"
        val apiKey = runCatching {
            context.openFileInput("ncbi_api_key.txt").bufferedReader().use { it.readText().trim() }
        }.getOrNull()
        val keyParam = if (apiKey.isNullOrBlank()) "" else "&api_key=$apiKey"
        "&tool=$tool&email=$email$keyParam"
    }

    private fun httpGetWithRetry(urlText: String, attempts: Int = 3): String {
        var lastError: Exception? = null
        var backoffMillis = 350L
        repeat(attempts) { i ->
            try {
                return httpGet(urlText)
            } catch (e: Exception) {
                lastError = e
                if (i < attempts - 1) {
                    Thread.sleep(backoffMillis)
                    backoffMillis = (backoffMillis * 2).coerceAtMost(2500L)
                }
            }
        }
        throw lastError ?: RuntimeException("httpGetWithRetry exhausted attempts")
    }
}
