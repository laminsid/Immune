package com.immunesignal.app

/**
 * v1.4.0: Dataset-first autonomous foraging models.
 *
 * These models are intentionally evidence-acquisition primitives, not new
 * biological axes. They make the APK show whether it actually attempted direct
 * dataset families instead of only writing another PubMed pivot.
 */
data class TestableHypothesisShard(
    val shardId: String,
    val label: String,
    val evidenceQuestion: String,
    val querySeeds: List<String>
)

data class DatasetSourceAttempt(
    val sourceFamily: String,
    val ncbiDb: String,
    val query: String,
    val attempted: Boolean,
    val idsFound: Int,
    val candidatesExtracted: Int,
    val status: String,
    val reason: String
)

data class DatasetForagingPass(
    val passId: String,
    val label: String,
    val status: String,
    val attempts: List<DatasetSourceAttempt>
)

/** v1.4.4: separates dataset route relevance from raw dataset usability. */
data class DatasetRouteFitAssessment(
    val accession: String,
    val datasetRoute: String,
    val targetRoute: String,
    val routeFitScore: Int,
    val status: String,
    val allowedUse: String,
    val blocksHypothesisUpgrade: Boolean,
    val reasons: List<String>
)

/** v1.4.4: transparent score separation to avoid misleading single-score reports. */
data class DatasetScoreSeparation(
    val datasetUsabilityScore: Int,
    val routeFitScore: Int,
    val hypothesisConfidenceScore: Int,
    val hypothesisUpgradeAllowed: Boolean,
    val scoreState: String,
    val summary: String,
    val reasons: List<String>
) {
    companion object {
        fun empty() = DatasetScoreSeparation(
            datasetUsabilityScore = 0,
            routeFitScore = 0,
            hypothesisConfidenceScore = 0,
            hypothesisUpgradeAllowed = false,
            scoreState = "NOT_EVALUATED",
            summary = "Score separation was not evaluated in this cycle.",
            reasons = emptyList()
        )
    }
}

data class DatasetForagingReport(
    val active: Boolean,
    val state: String,
    val evidenceMode: String,
    val sourceFamiliesAttempted: List<String>,
    val hypothesisShards: List<TestableHypothesisShard>,
    val passes: List<DatasetForagingPass>,
    val candidates: List<DatasetAccessionCandidate>,
    val parsedMetadata: List<ParsedDatasetMetadata> = emptyList(),
    val contrastiveReport: ContrastiveEvidenceReport = ContrastiveEvidenceReport.empty(),
    val evidenceHypergraph: List<EvidenceHypergraphNode> = emptyList(),
    val cumulativeEvidence: CumulativeEvidenceReport = CumulativeEvidenceReport.empty(),
    val routeFitAssessments: List<DatasetRouteFitAssessment> = emptyList(),
    val scoreSeparation: DatasetScoreSeparation = DatasetScoreSeparation.empty(),
    val triageReport: DatasetTriageReport = DatasetTriageReport.empty(),
    val failurePatternReport: FailurePatternReport = FailurePatternReport.empty(),
    val queryFeedbackPlan: QueryFeedbackPlan = QueryFeedbackPlan.passthrough(emptyList(), "No query feedback evaluated."),
    val freshnessReport: FreshnessReport = FreshnessReport.empty(),
    val blockedLearningReason: String,
    val nextAction: String
) {
    companion object {
        fun empty() = DatasetForagingReport(
            active = false,
            state = "NOT_RUN",
            evidenceMode = "PUBMED_METADATA_ONLY",
            sourceFamiliesAttempted = emptyList(),
            hypothesisShards = emptyList(),
            passes = emptyList(),
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            contrastiveReport = ContrastiveEvidenceReport.empty(),
            evidenceHypergraph = emptyList(),
            cumulativeEvidence = CumulativeEvidenceReport.empty(),
            routeFitAssessments = emptyList(),
            scoreSeparation = DatasetScoreSeparation.empty(),
            triageReport = DatasetTriageReport.empty(),
            failurePatternReport = FailurePatternReport.empty(),
            queryFeedbackPlan = QueryFeedbackPlan.passthrough(emptyList(), "No query feedback evaluated."),
            freshnessReport = FreshnessReport.empty(),
            blockedLearningReason = "Dataset-first forager did not run in this cycle.",
            nextAction = "Run an autonomous research cycle."
        )
    }
}
