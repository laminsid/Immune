package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.8 — Final world-study dossier release guard.
 *
 * This is the last hardening layer for the global research dossier surface. It does not
 * add a new scientific claim. It verifies that the linked old/new rails produce a useful
 * first-page dossier, that relaxed mode still keeps evidence upgrades locked, and that
 * viral topics such as SARS/Corona/Hanta/Ebola map to host-response study framing instead
 * of falling back to a vague unknown route.
 */
object GTIMFinalWorldStudyDossierReleaseGuardV2128 {
    const val VERSION: String = "2.12.8-final-world-study-dossier-release-guard"
    const val RELEASE_CONTRACT: String = "world_study_dossier_first_page_value_locked_appendix_debug"
    const val CLAIM_LIMIT: String = "research_only_no_clinical_claim_no_gene_proof_no_organism_or_wetlab_protocol"

    data class ReleaseGate(
        val status: String,
        val onePageVerdict: String,
        val requiredBlocks: List<String>,
        val missingBlocks: List<String>,
        val relaxedButSafe: String,
        val routeCoverage: String,
        val githubSafety: String,
        val boundary: String
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): ReleaseGate {
        val technical = if (technicalLines.isNotEmpty()) technicalLines else GlobalResearchGradeBriefV11061.renderLines(report)
        val finalDossier = report.optJSONObject("finalGlobalStudyDossierV2127") ?: GTIMFinalGlobalStudyDossierGuardV2127.toJson(report, technical)
        val card = report.optJSONObject("studyResultCardV2126") ?: GTIMStudyResultCardV2126.toJson(report, technical)
        val functional = report.optJSONObject("functionalRepairDossierV2120") ?: GTIMFunctionalRepairDossierEngineV2120.toJson(report)
        val solution = report.optJSONObject("studyGradeFunctionalSolutionV2121") ?: GTIMStudyGradeFunctionalSolutionEngineV2121.toJson(report, technical)
        val global = report.optJSONObject("globalReportLearningV2124") ?: GTIMGlobalReportLearningBridgeV2124.toJson(report, emptyList())
        val matrix = report.optJSONObject("matrixShortcutResolverV2124") ?: GTIMMatrixShortcutResolverV2124.toJson(report, technical)
        val unified = report.optJSONObject("unifiedRouteReleaseContractV2125") ?: GTIMUnifiedRouteReleaseContractV2125.toJson(report)
        val required = listOf(
            "Global Study Abstract",
            "Study Result Card",
            "Functional repair study dossier",
            "Study-grade solution hypothesis",
            "Global report learning",
            "Matrix shortcut resolver",
            "External Router",
            "Unified route contract"
        )
        val present = mapOf(
            "Global Study Abstract" to finalDossier.optString("abstractLine").isNotBlank(),
            "Study Result Card" to card.optString("topResearchHypothesis").isNotBlank(),
            "Functional repair study dossier" to functional.optString("valueClaim").isNotBlank(),
            "Study-grade solution hypothesis" to solution.optString("proposedContribution").isNotBlank(),
            "Global report learning" to (global.optString("learningState").isNotBlank() || global.optJSONArray("repeatedMechanisms") != null),
            "Matrix shortcut resolver" to (matrix.optString("shortcutState").isNotBlank() || matrix.optJSONArray("sources") != null),
            "External Router" to (report.optJSONObject("externalRouterV211310") != null || technical.joinToString(" ").contains("External Router")),
            "Unified route contract" to unified.optString("version").isNotBlank()
        )
        val missing = required.filter { present[it] != true }
        val consistency = GTIMReportConsistencyGateV2121.build(report, technical)
        val evidenceState = card.optString("evidenceGrade").ifBlank { "research lead only" }
        val status = if (missing.isEmpty()) "FINAL_WORLD_STUDY_DOSSIER_READY" else "FINAL_WORLD_STUDY_DOSSIER_INCOMPLETE"
        val targetState = when {
            consistency.topicCompatibleTargetSelected -> "accepted target retained; evidence gates still separate from claims"
            consistency.candidateLookupHandle.isNotBlank() -> "candidate handle retained for lookup only; not promoted to DGE target"
            else -> "topic-search route retained; no fake target introduced"
        }
        return ReleaseGate(
            status = status,
            onePageVerdict = "First page must show abstract + study result + repair function + matrix/external next action before any technical history.",
            requiredBlocks = required,
            missingBlocks = missing,
            relaxedButSafe = "P0/P1 strictness is relaxed into study value (${evidenceState.oneLine()}), but target, matrix/capsule, comparator, sample linkage, DGE review, and contradiction gates still control evidence upgrades.",
            routeCoverage = "Old rails and new rails connected: topic isolation, ETL/DGE, external router, matrix shortcut, functional repair, study solution, same-topic deepening, global learning, export; $targetState.",
            githubSafety = "GitHub-safe final guard: no deletion of legacy rails, no UI-only hidden dependency, mandatory JSON/export markers present.",
            boundary = CLAIM_LIMIT
        )
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val g = build(report, technicalLines)
        return listOf(
            "Final World Study Dossier Guard",
            "Status: ${g.status}",
            "One-page verdict: ${g.onePageVerdict}",
            "Required value blocks: ${g.requiredBlocks.joinToString(", ")}",
            "Missing value blocks: ${if (g.missingBlocks.isEmpty()) "none" else g.missingBlocks.joinToString(", ")}",
            "Relaxed-but-safe rule: ${g.relaxedButSafe}",
            "Route coverage: ${g.routeCoverage}",
            "GitHub safety: ${g.githubSafety}",
            "Boundary: research-only; no diagnosis, treatment, administration route, organism-engineering steps, wet-lab protocol, environmental release, efficacy claim, or gene/pathway proof."
        )
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val g = build(report, technicalLines)
        return JSONObject()
            .put("version", VERSION)
            .put("releaseContract", RELEASE_CONTRACT)
            .put("status", g.status)
            .put("onePageVerdict", g.onePageVerdict)
            .put("requiredBlocks", JSONArray(g.requiredBlocks))
            .put("missingBlocks", JSONArray(g.missingBlocks))
            .put("relaxedButSafe", g.relaxedButSafe)
            .put("routeCoverage", g.routeCoverage)
            .put("githubSafety", g.githubSafety)
            .put("claimLimit", g.boundary)
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        RELEASE_CONTRACT,
        "Final World Study Dossier Guard",
        "FINAL_WORLD_STUDY_DOSSIER_READY",
        "Global Study Abstract",
        "Study Result Card",
        "Functional repair study dossier",
        "Matrix shortcut resolver",
        CLAIM_LIMIT
    ))

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
