#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
checks = {
    'app/build.gradle.kts': ['versionCode = 109', 'versionName = "1.10.47-alpha-topic-fit-metadata-parse-ui-clarity"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': ['RELEASE_TRAIN_VERSION_CODE: Int = 109', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.47"', '1.10.47-alpha-topic-fit-metadata-parse-ui-clarity'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['ACTIVE_ENGINE_VERSION = "v1.10.47-alpha-topic-fit-metadata-parse-ui-clarity"', 'TopicFitMetadataParseUiClarityV11047'],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 109', 'VERSION_NAME: String = "1.10.47-alpha-topic-fit-metadata-parse-ui-clarity"', 'LEARNING_SCHEMA_VERSION: String = "1.10.47"'],
    'scripts/run_static_checks_fast.sh': ['audit_v11047_topic_fit_metadata_parse_ui_clarity.py', 'audit_release_version_linkage_v11047.py'],
    'scripts/run_static_checks_full.sh': ['audit_v11047_topic_fit_metadata_parse_ui_clarity.py', 'audit_release_version_linkage_v11047.py'],
    'docs/CHANGELOG_v1.10.47.md': ['versionCode=109', '1.10.47-alpha-topic-fit-metadata-parse-ui-clarity'],
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'MISSING FILE {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'MISSING {token} in {rel}')
print('v1.10.47 release linkage audit: PASS')
