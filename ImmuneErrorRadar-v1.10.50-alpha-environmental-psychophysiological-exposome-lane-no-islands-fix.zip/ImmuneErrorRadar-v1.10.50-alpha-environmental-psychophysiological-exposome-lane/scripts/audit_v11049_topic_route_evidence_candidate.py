from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/TopicFitMetadataParseUiClarityV11047.kt': [
        'EvidenceObjectCandidateV11049',
        'userTopicText',
        'RNA_TRANSCRIPTOMIC_IMMUNE_STATE_LANE',
        'HERB_EXPOSURE_HPA_IMMUNE_MODULATION_LANE',
        'COMPARATOR_HUNT_MODE',
        'BLOCKED_BY_CONTROL',
        'topicRouteCorrectionStatus',
        'evidenceObjectCandidateCount',
        'no supplement advice',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': [
        'evidenceObjectCandidates',
        'evidenceObjectCandidateToJson',
        'comparatorHuntMode',
        'topicRouteCorrectionStatus',
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Topic Route Correction / EvidenceObjectCandidate v1.10.49',
        'EvidenceObjectCandidate(s)',
        'Comparator hunt',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Topic Route Correction v1.10.49',
        'EvidenceObjectCandidate(s)',
        'Comparator hunt',
    ],
    'docs/TOPIC_ROUTE_CORRECTION_EVIDENCE_OBJECT_CANDIDATE_v1.10.49.md': [
        'EvidenceObjectCandidateV11049',
        'RNA_TRANSCRIPTOMIC_IMMUNE_STATE_LANE',
        'HERB_EXPOSURE_HPA_IMMUNE_MODULATION_LANE',
    ],
}
missing = []
for file, tokens in checks.items():
    text = Path(file).read_text(encoding='utf-8') if Path(file).exists() else ''
    for token in tokens:
        if token not in text:
            missing.append(f'{file}: missing {token}')
if missing:
    raise SystemExit('\n'.join(missing))
print('v1.10.49 topic route/evidence candidate audit: PASS')
