from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
checks = {
    'app/build.gradle.kts': ['versionCode = 110', 'versionName = "1.10.48-alpha-relaxed-progression-context-alignment"'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': ['RELEASE_TRAIN_VERSION_CODE: Int = 110', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.48"', '1.10.48-alpha-relaxed-progression-context-alignment'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['ACTIVE_ENGINE_VERSION = "v1.10.48-alpha-relaxed-progression-context-alignment"', 'RelaxedProgressionContextAlignmentV11048'],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 110', 'VERSION_NAME: String = "1.10.48-alpha-relaxed-progression-context-alignment"', 'LEARNING_SCHEMA_VERSION: String = "1.10.48"'],
    'docs/CHANGELOG_v1.10.48.md': ['versionCode=110', '1.10.48-alpha-relaxed-progression-context-alignment'],
}
for rel, tokens in checks.items():
    text = (ROOT / rel).read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel}: missing token {token!r}')
print('v1.10.48 release linkage audit: PASS')
