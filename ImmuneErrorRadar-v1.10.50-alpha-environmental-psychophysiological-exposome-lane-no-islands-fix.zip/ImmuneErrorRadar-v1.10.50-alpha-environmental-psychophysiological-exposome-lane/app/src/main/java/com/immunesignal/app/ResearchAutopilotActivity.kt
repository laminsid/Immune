package com.immunesignal.app

// legacy audit token: Topic Route Correction v1.10.49

// legacy_audit_token: Topic-Fit Metadata Parse v1.10.47

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * v1.1: migrated from Activity to ComponentActivity.
 *
 * Previously a raw Thread ran the research cycle, which:
 * - leaked Activity context on rotation/destroy
 * - risked ANRs if save happened during destroy
 * - had no structured cancellation
 *
 * v1.1 uses lifecycleScope.launch so the cycle is automatically cancelled
 * when the Activity is destroyed, and runs on Dispatchers.IO. The Stop
 * button cancels the Job. The deprecated startActivityForResult is replaced
 * by registerForActivityResult(ActivityResultContracts.OpenDocument()).
 */
// legacy_audit_version_token_v11029_activity: Learning/domain linkage
class ResearchAutopilotActivity : ComponentActivity() {
    // v1.10.27 compact-ui retention: pathLinkageReport / Path linkage remain available in exported reports; the main screen hides technical linkage lines.
    // v1.10.28 compact-ui retention: pass coverage / coverageState stay in Export and audits, not in the primary user card.
    private lateinit var outputText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var reportInput: EditText
    private lateinit var topicPromptInput: EditText
    private lateinit var steeringVariablesInput: EditText
    private lateinit var steeringFocusInput: EditText
    private lateinit var steeringRequiredInput: EditText
    private lateinit var steeringExcludeInput: EditText
    private lateinit var activeSteeringText: TextView
    private lateinit var stageText: TextView
    private lateinit var learningStatusText: TextView
    private lateinit var thinkingSessionText: TextView
    private lateinit var learningMiniReportText: TextView
    private lateinit var postSearchThinkingText: TextView
    private lateinit var advancedControlsContainer: LinearLayout
    private lateinit var toggleAdvancedButton: Button
    private lateinit var thinkSessionButton: Button
    private lateinit var continueThinkingButton: Button
    private lateinit var pauseThinkingButton: Button
    private lateinit var skipThinkingButton: Button
    private lateinit var stopThinkingButton: Button
    private lateinit var runButton: Button
    private lateinit var stopButton: Button
    private lateinit var copyBriefButton: Button
    private lateinit var exportPdfButton: Button
    private var latestReport: JSONObject? = null
    @Volatile private var stopRequested: Boolean = false
    @Volatile private var running: Boolean = false
    private var researchJob: Job? = null
    private var thinkingJob: Job? = null
    private var learningSessionManager: LearningSessionManager? = null
    private var advancedControlsVisible: Boolean = false

    // v1.1: ActivityResultContracts replaces deprecated onActivityResult.
    // Registered before onStart per the contract requirement.
    private val openReportLauncher: ActivityResultLauncher<Array<String>> =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) importReportUri(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_research_autopilot)
        outputText = findViewById(R.id.autopilotOutputText)
        progress = findViewById(R.id.autopilotProgress)
        reportInput = findViewById(R.id.manualReportInput)
        topicPromptInput = findViewById(R.id.topicPromptInput)
        steeringVariablesInput = findViewById(R.id.steeringVariablesInput)
        steeringFocusInput = findViewById(R.id.steeringFocusInput)
        steeringRequiredInput = findViewById(R.id.steeringRequiredInput)
        steeringExcludeInput = findViewById(R.id.steeringExcludeInput)
        activeSteeringText = findViewById(R.id.activeSteeringText)
        stageText = findViewById(R.id.autopilotStageText)
        learningStatusText = findViewById(R.id.autopilotLearningStatusText)
        thinkingSessionText = findViewById(R.id.thinkingSessionText)
        learningMiniReportText = findViewById(R.id.learningMiniReportText)
        postSearchThinkingText = findViewById(R.id.postSearchThinkingText)
        advancedControlsContainer = findViewById(R.id.advancedControlsContainer)
        toggleAdvancedButton = findViewById(R.id.toggleAdvancedButton)
        thinkSessionButton = findViewById(R.id.thinkSessionButton)
        continueThinkingButton = findViewById(R.id.continueThinkingButton)
        pauseThinkingButton = findViewById(R.id.pauseThinkingButton)
        skipThinkingButton = findViewById(R.id.skipThinkingButton)
        stopThinkingButton = findViewById(R.id.stopThinkingButton)
        runButton = findViewById(R.id.runAutopilotButton)
        stopButton = findViewById(R.id.stopAutopilotButton)
        copyBriefButton = findViewById(R.id.copyBriefReportButton)
        exportPdfButton = findViewById(R.id.exportDiscoveryPdfButton)
        postSearchThinkingText.visibility = View.GONE

        runButton.setOnClickListener { runCycle() }
        toggleAdvancedButton.setOnClickListener { toggleAdvancedControls() }
        stopButton.setOnClickListener { stopResearch() }
        thinkSessionButton.setOnClickListener { startThinkingSession(SessionType.INCREMENTAL) }
        continueThinkingButton.setOnClickListener { continuePostSearchThinking() }
        pauseThinkingButton.setOnClickListener { pauseThinkingSession() }
        skipThinkingButton.setOnClickListener { skipThinkingPhase() }
        stopThinkingButton.setOnClickListener { stopThinkingSession() }
        findViewById<Button>(R.id.saveSteeringButton).setOnClickListener { saveSteering() }
        findViewById<Button>(R.id.clearSteeringButton).setOnClickListener { clearSteering() }
        findViewById<Button>(R.id.importPastedReportButton).setOnClickListener { importPastedReport() }
        findViewById<Button>(R.id.importReportFileButton).setOnClickListener { openReportFile() }
        copyBriefButton.setOnClickListener { copyBriefReport() }
        exportPdfButton.setOnClickListener { exportPdf() }
        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
        updateRunningUi(false)
        refreshActiveSteering()
        renderLatestReports()
        runAutonomousThoughtPulse("screen_open")
        if (!RuntimeFeatureFlags.ENABLE_LEARNING_SESSION_UI) {
            thinkSessionButton.isEnabled = false
            continueThinkingButton.isEnabled = true
            pauseThinkingButton.isEnabled = false
            skipThinkingButton.isEnabled = false
            stopThinkingButton.isEnabled = false
            thinkingSessionText.text = "Deep Think sessions are disabled by runtime flag. SEARCH auto-light learning remains available. Saved-report thinking remains local; when enabled, the default budget is 45 minutes, not a short 30-second review."
        }
    }

    override fun onDestroy() {
        // v1.1: ensure background work stops if user destroys the screen.
        researchJob?.cancel()
        researchJob = null
        thinkingJob?.cancel()
        thinkingJob = null
        latestReport = null
        super.onDestroy()
    }

    private fun runCycle() {
        if (running) {
            Toast.makeText(this, "Research is already running.", Toast.LENGTH_SHORT).show()
            return
        }
        applySingleTopicPromptIfPresent()
        learningSessionManager?.pauseSession()
        (learningSessionManager ?: LearningSessionManager(this).also { learningSessionManager = it })
            .markNewSearchBoundary("new_search_started_from_ui")
        thinkingJob?.cancel()
        thinkingJob = null
        stopRequested = false
        running = true
        updateRunningUi(true)
        val steering = ResearchKnowledgeStore(this).readActiveSteering()
        val topicLine = ImmuneTopicPromptPolicy.compactUiLine(topicPromptInput.text.toString())
        stageText.text = "Searching immune evidence…"
        learningStatusText.text = "Topic saved. The app will look for useful immune research leads; no medical claim will be made."
        outputText.text = "Searching…\n\n• Looking for useful immune research leads.\n• Saving what the system learns.\n• Full technical details stay in Export/Advanced."
        // v1.1: lifecycleScope auto-cancels on Activity destroy. Dispatchers.IO
        // is appropriate for blocking HTTP. UI updates use withContext(Main).
        researchJob = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val report = ResearchAutopilot(this@ResearchAutopilotActivity).runCycle(
                    shouldStop = { stopRequested },
                    limits = ResearchRunLimits(
                        maxSearchMillis = RuntimeFeatureFlags.DEFAULT_SEARCH_TIME_LIMIT_MILLIS,
                        maxLearningMillis = RuntimeFeatureFlags.DEFAULT_RESEARCH_LEARNING_TIME_LIMIT_MILLIS,
                        maxQueries = 8,
                        maxResultsPerQuery = 25,
                        fetchAbstracts = false,
                        enableSelectiveAbstracts = true,
                        maxAbstractsPerCycle = 5
                    )
                )
                val json = ResearchJsonCodec.reportToJson(report)
                val store = ResearchKnowledgeStore(this@ResearchAutopilotActivity)
                val thoughtPulse = store.recordAutonomousThoughtPulse(json, reason = "after_search", force = true)
                if (thoughtPulse != null) json.put("autonomousThoughtPulse", thoughtPulse)
                store.saveReport(json)
                withContext(Dispatchers.Main) {
                    latestReport = json
                    running = false
                    updateRunningUi(false)
                    stageText.text = "Run complete — learning saved"
                    learningStatusText.text = learningStatusLine(json)
                    outputText.text = renderSimpleUserReport(json)
                    learningMiniReportText.text = renderMiniLearningReport(json)
                    postSearchThinkingText.text = renderPostSearchThinkingCard(json) + (thoughtPulse?.let { "\n\n" + renderAutonomousThoughtPulse(it) } ?: "")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    running = false
                    updateRunningUi(false)
                    stageText.text = "Cycle failed"
                    learningStatusText.text = "No learning was saved from this failed run."
                    outputText.text = "Research cycle failed.\n\n${e.message}\n\nCheck internet connection, NCBI availability, or import a text report and run again."
                }
            }
        }
    }

    private fun continuePostSearchThinking() {
        val report = latestReport ?: run {
            Toast.makeText(this, "No saved report to think from yet.", Toast.LENGTH_SHORT).show()
            postSearchThinkingText.text = "Thinking board: no saved cycle yet. Run Search first, then use Think saved."
            return
        }
        val store = ResearchKnowledgeStore(this)
        val offlineStep = store.recordOfflineThinkingStep(report)
        val thoughtPulse = store.recordAutonomousThoughtPulse(report, reason = "manual_think_saved", force = true)
        if (thoughtPulse != null) report.put("autonomousThoughtPulse", thoughtPulse)
        postSearchThinkingText.text = renderPostSearchThinkingCard(report) + "\n\n" + renderOfflineThinkingStep(offlineStep) +
            (thoughtPulse?.let { "\n\n" + renderAutonomousThoughtPulse(it) } ?: "")
        learningStatusText.text = "Offline thinking advanced. No internet used. Step #${offlineStep.optInt("stepNumber", 1)} stored."
        outputText.text = renderSimpleUserReport(report) +
            "\n\nSaved-report thinking advanced without search:\n" + renderOfflineThinkingStep(offlineStep) +
            (thoughtPulse?.let { "\n\n" + renderAutonomousThoughtPulse(it) } ?: "")
    }

    private fun runAutonomousThoughtPulse(reason: String) {
        val report = latestReport ?: return
        lifecycleScope.launch(Dispatchers.IO) {
            val pulse = ResearchKnowledgeStore(this@ResearchAutopilotActivity)
                .recordAutonomousThoughtPulse(report, reason = reason, force = false)
            if (pulse != null) {
                withContext(Dispatchers.Main) {
                    postSearchThinkingText.text = renderPostSearchThinkingCard(report) + "\n\n" + renderAutonomousThoughtPulse(pulse)
                    learningStatusText.text = "Local thought pulse updated. No internet used; broad search remains gated by evidence closure. Extended thinking uses local passes, not claim upgrades."
                }
            }
        }
    }

    private fun startThinkingSession(sessionType: SessionType) {
        if (!RuntimeFeatureFlags.ENABLE_LEARNING_SESSION_UI) {
            Toast.makeText(this, "Deep Think sessions are disabled.", Toast.LENGTH_SHORT).show()
            return
        }
        if (thinkingJob?.isActive == true) {
            Toast.makeText(this, "Deep Think session is already running.", Toast.LENGTH_SHORT).show()
            return
        }
        val manager = LearningSessionManager(this)
        learningSessionManager = manager
        val progressBroadcaster = ProgressBroadcaster()
        val executor = PhaseExecutor(this, manager, progressBroadcaster)
        val initialSession = manager.startSession(sessionType = sessionType, timeLimit = RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS)
        thinkingSessionText.text = ProgressTracker.generateUIReport(initialSession) + "\n\nExtended thinking budget: 45m, minimum ${RuntimeFeatureFlags.MIN_AUTONOMOUS_THINKING_PASSES} local reasoning passes; no claim upgrade from thinking alone."

        progressBroadcaster.addListener(object : ProgressListener {
            override fun onProgressUpdate(progress: ProgressUpdate) {
                runOnUiThread {
                    learningSessionManager?.getCurrentSession()?.let { session ->
                        thinkingSessionText.text = ProgressTracker.generateUIReport(session)
                    }
                }
            }

            override fun onPhaseComplete(phaseName: String, findings: String) {
                runOnUiThread {
                    learningSessionManager?.getCurrentSession()?.let { session ->
                        thinkingSessionText.text = ProgressTracker.generateUIReport(session) + "\n\n$phaseName: $findings"
                    }
                }
            }

            override fun onSessionComplete(insights: LearningInsights) {
                runOnUiThread {
                    learningSessionManager?.getCurrentSession()?.let { session ->
                        thinkingSessionText.text = ProgressTracker.generateUIReport(session) +
                            "\n\nSession completed. Insights are checkpointed locally.\n" +
                            "Claim limit: learning_session_not_biological_proof." +
                            "\n" + renderSessionMetrics()
                    }
                }
            }
        })

        thinkingJob = lifecycleScope.launch(Dispatchers.Default) {
            val history = buildLearningReportHistory()
            executor.executeAllPhases(
                session = initialSession,
                reportHistory = history,
                onComplete = { /* UI receives progress through broadcaster. */ }
            )
        }
    }

    private fun pauseThinkingSession() {
        learningSessionManager?.pauseSession()
        thinkingJob?.cancel()
        thinkingJob = null
        val session = learningSessionManager?.getCurrentSession()
        thinkingSessionText.text = if (session != null) {
            ProgressTracker.generateUIReport(session) + "\n\nPaused. Checkpoint saved."
        } else {
            "No Deep Think session to pause."
        }
    }

    private fun skipThinkingPhase() {
        if (!RuntimeFeatureFlags.ENABLE_LEARNING_SESSION_UI) {
            Toast.makeText(this, "Deep Think sessions are disabled.", Toast.LENGTH_SHORT).show()
            return
        }
        val manager = learningSessionManager ?: LearningSessionManager(this).also { learningSessionManager = it }
        val skippedSession = manager.skipCurrentOrNextPhase("user_skipped_phase_from_ui")
        if (skippedSession == null) {
            thinkingSessionText.text = "No Deep Think session or checkpoint available to skip. Run Deep Think first."
            return
        }
        thinkingJob?.cancel()
        thinkingJob = null
        val pending = skippedSession.phases.any { it.status != PhaseStatus.COMPLETED }
        thinkingSessionText.text = ProgressTracker.generateUIReport(skippedSession) +
            "\n\nCurrent phase skipped and checkpoint saved." +
            if (pending) "\nContinuing from the next pending phase…" else "\nNo pending phases remain."
        if (pending && skippedSession.status != SessionStatus.COMPLETED) {
            startThinkingSession(SessionType.RESUMED)
        }
    }

    private fun stopThinkingSession() {
        thinkingJob?.cancel()
        thinkingJob = null
        learningSessionManager?.clearCheckpoint()
        thinkingSessionText.text = "Deep Think session stopped. Checkpoint cleared."
    }

    private fun renderSessionMetrics(): String {
        val metrics = learningSessionManager?.getSessionMetrics() ?: return "Session metrics: not available yet."
        return buildString {
            append("Session metrics: progress=")
            append(metrics.progressPerPhase.values.average().takeIf { !it.isNaN() }?.toInt() ?: 0)
            append("%; checkpoints=")
            append(metrics.checkpointsCreated)
            append("; items=")
            append(metrics.itemsProcessed)
            append("/")
            append(metrics.totalItems)
            append("; errors=")
            append(metrics.errorCount)
            append("; resume-count=")
            append(metrics.resumeCount)
            append("; claim-limit=")
            append(metrics.claimLimit)
            learningSessionManager?.getCheckpointIntegrityReport()?.let { integrity ->
                append("\nCheckpoint integrity: ")
                append(if (integrity.optBoolean("ok", false)) "PASS" else "WATCH")
            }
            learningSessionManager?.getSessionReport()?.handoff?.let { handoff ->
                append("\n")
                append(handoff.compactSummary())
            }
            learningSessionManager?.getSessionHistorySummary(3)?.let { history ->
                append("\nRecent session history:\n")
                append(history)
            }
        }
    }

    private fun buildLearningReportHistory(): List<ResearchReportV3> {
        val latest = latestReport?.let { reportV3FromCycleJson(it) }
        val stored = ResearchKnowledgeStore(this).readLatestReports(12).mapNotNull { line ->
            runCatching { reportV3FromCycleJson(JSONObject(line)) }.getOrNull()
        }
        return (listOfNotNull(latest) + stored).distinctBy { it.hypothesis + it.newUsefulLead }.take(12)
    }

    private fun reportV3FromCycleJson(cycleJson: JSONObject): ResearchReportV3 {
        val v3 = cycleJson.optJSONObject("reportV3") ?: cycleJson
        return ResearchReportV3(
            cycleResult = v3.optString("cycleResult", "Imported cycle"),
            newUsefulLead = v3.optString("newUsefulLead", "No lead extracted"),
            hypothesisChanged = v3.optString("hypothesisChanged", "None"),
            whyItMatters = v3.optString("whyItMatters", "No explanation extracted"),
            nextAutonomousMove = v3.optString("nextAutonomousMove", "Run next research cycle"),
            doNotBelieveYet = v3.optString("doNotBelieveYet", "No hypothesis is proven."),
            technicalPointer = v3.optString("technicalPointer", "Imported from saved cycle JSON."),
            hypothesis = v3.optString("hypothesis", "No hypothesis evaluated yet."),
            supportingEvidence = v3.optString("supportingEvidence", "No supporting evidence evaluated yet."),
            counterEvidenceOrContradiction = v3.optString("counterEvidenceOrContradiction", "No contradiction search evaluated yet."),
            whatWeDoNotBelieveYet = v3.optString("whatWeDoNotBelieveYet", "No hypothesis is proven."),
            integrityStatus = v3.optString("integrityStatus", "UNVALIDATED")
        )
    }




    private fun saveSteering() {
        val variables = steeringVariablesInput.text.toString().trim()
        if (variables.length < 2) {
            Toast.makeText(this, "Enter at least one research variable.", Toast.LENGTH_SHORT).show()
            return
        }
        val profile = ResearchKnowledgeStore(this).saveActiveSteering(
            variablesText = variables,
            focusQuestion = steeringFocusInput.text.toString(),
            requiredTermsText = steeringRequiredInput.text.toString(),
            excludedTermsText = steeringExcludeInput.text.toString()
        )
        refreshActiveSteering()
        learningStatusText.text = "Steering saved. The next cycle will still pass evidence and contradiction gates."
        outputText.text = "Research steering saved.\n\nVariables: ${profile.variables.joinToString(", ")}\nAxes: ${profile.inferredAxes.joinToString(", ").ifBlank { "none yet" }}\n\nPress Search + learn. Steering accelerates one idea without disabling autonomous exploration."
    }

    private fun clearSteering() {
        ResearchKnowledgeStore(this).clearActiveSteering()
        steeringVariablesInput.setText("")
        steeringFocusInput.setText("")
        steeringRequiredInput.setText("")
        steeringExcludeInput.setText("")
        refreshActiveSteering()
        learningStatusText.text = "Steering cleared. Autonomous research remains active."
        outputText.text = "Research steering cleared. Autonomous Researcher mode remains active and will choose its own search lanes."
    }

    private fun refreshActiveSteering() {
        val profile = ResearchKnowledgeStore(this).readActiveSteering()
        if (profile == null) {
            activeSteeringText.text = "Active steering: none. Autonomous Researcher mode is active; steering is optional if you want to accelerate a specific idea."
            return
        }
        activeSteeringText.text = "Active steering:\n" +
            "Variables: ${profile.variables.joinToString(", ")}\n" +
            "Focus: ${profile.focusQuestion.ifBlank { "connect variables and find non-obvious mechanisms" }}\n" +
            "Required: ${profile.requiredTerms.joinToString(", ").ifBlank { "none" }}\n" +
            "Excluded: ${profile.excludedTerms.joinToString(", ").ifBlank { "none" }}\n" +
            "Inferred axes: ${profile.inferredAxes.joinToString(", ").ifBlank { "none" }}"
    }

    private fun stopResearch() {
        if (!running) {
            Toast.makeText(this, "No active research cycle.", Toast.LENGTH_SHORT).show()
            return
        }
        stopRequested = true
        // v1.1: also cancel the coroutine for fast hard-stop on long-tail HTTP.
        researchJob?.cancel()
        stageText.text = "Stopping…"
        learningStatusText.text = "Stop requested. Current network request will finish or timeout."
        outputText.text = outputText.text.toString() + "\n\nStop requested. Current network request will finish or timeout, then the report will be closed."
    }

    private fun updateRunningUi(isRunning: Boolean) {
        progress.visibility = if (isRunning) View.VISIBLE else View.GONE
        if (!isRunning && stageText.text.toString().contains("Searching")) {
            stageText.text = "Idle — ready to search"
        }
        runButton.isEnabled = !isRunning
        stopButton.isEnabled = isRunning
        exportPdfButton.isEnabled = !isRunning
        copyBriefButton.isEnabled = !isRunning
    }


    private fun applySingleTopicPromptIfPresent(): ResearchSteeringProfile? {
        val topic = topicPromptInput.text.toString().trim()
        if (!ImmuneTopicPromptPolicy.shouldApply(topic)) return ResearchKnowledgeStore(this).readActiveSteering()
        val store = ResearchKnowledgeStore(this)
        val profile = store.saveActiveSteering(
            variablesText = ImmuneTopicPromptPolicy.variablesText(topic),
            focusQuestion = ImmuneTopicPromptPolicy.focusQuestion(topic),
            requiredTermsText = ImmuneTopicPromptPolicy.requiredTermsText(),
            excludedTermsText = "diagnosis, treatment recommendation, drug ranking, engine mechanics, general engineering advice"
        )
        store.saveImportedReport(
            title = "Single topic prompt",
            text = ImmuneTopicPromptPolicy.importedLearningNote(topic)
        )
        refreshActiveSteering()
        return profile
    }

    private fun importPastedReport() {
        val text = reportInput.text.toString().trim()
        if (text.length < 20) {
            Toast.makeText(this, "Paste a longer report/note first.", Toast.LENGTH_SHORT).show()
            return
        }
        val signal = ResearchKnowledgeStore(this).saveImportedReport("Pasted report", text)
        reportInput.setText("")
        learningStatusText.text = "Imported note saved as optional evidence context."
        outputText.text = "Imported report saved.\n\nDetected axes: ${signal.matchedAxes.joinToString(", ").ifBlank { "none" }}\nKeywords: ${signal.extractedKeywords.joinToString(", ").ifBlank { "none" }}\n\nRun research cycle. The autonomous planner will use this as one optional clue, not as the only direction."
    }

    private fun openReportFile() {
        // v1.1: ActivityResultContracts.OpenDocument launcher.
        // The MIME type list is passed as the launcher's input.
        openReportLauncher.launch(arrayOf("text/plain", "text/csv", "application/json"))
    }

    private fun importReportUri(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (text.length < 20) {
                Toast.makeText(this, "File is empty or too short.", Toast.LENGTH_LONG).show()
                return
            }
            val signal = ResearchKnowledgeStore(this).saveImportedReport("Imported file", text)
            learningStatusText.text = "Imported file saved as optional evidence context."
            outputText.text = "Imported file saved.\n\nDetected axes: ${signal.matchedAxes.joinToString(", ").ifBlank { "none" }}\nKeywords: ${signal.extractedKeywords.joinToString(", ").ifBlank { "none" }}\nPreview: ${signal.preview}\n\nRun research cycle. The autonomous planner will use this file as one optional clue, not as the only direction."
        } catch (e: Exception) {
            Toast.makeText(this, "Could not import file: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun renderLatestReports() {
        val latest = ResearchKnowledgeStore(this).readLatestReports(1).firstOrNull()
        if (latest != null) {
            latestReport = JSONObject(latest)
            stageText.text = "Latest learning loaded"
            learningStatusText.text = learningStatusLine(latestReport!!)
            outputText.text = renderSimpleUserReport(latestReport!!)
            learningMiniReportText.text = renderMiniLearningReport(latestReport!!)
            val pulse = ResearchKnowledgeStore(this).readLatestAutonomousThoughtPulses(1).firstOrNull()
            postSearchThinkingText.text = renderPostSearchThinkingCard(latestReport!!) +
                (pulse?.let { "\n\n" + renderAutonomousThoughtPulse(it) } ?: "")
        } else {
            stageText.text = "Idle — ready to search"
            learningStatusText.text = "Enter one topic. I will research it through an immune-system lens only."
            outputText.text = "Ready. Enter one topic or question, then press Immune Search.\n\nEach run saves useful learning, weak leads, and next checks. No diagnosis, treatment, or medical advice."
            learningMiniReportText.text = "Learning summary: after each run, this shows what changed, what was saved, and what to check next."
            postSearchThinkingText.text = "Advanced thinking board: hidden until Advanced is opened."
        }
    }


    private fun toggleAdvancedControls() {
        advancedControlsVisible = !advancedControlsVisible
        advancedControlsContainer.visibility = if (advancedControlsVisible) View.VISIBLE else View.GONE
        postSearchThinkingText.visibility = if (advancedControlsVisible) View.VISIBLE else View.GONE
        toggleAdvancedButton.text = if (advancedControlsVisible) "Hide advanced details" else "Advanced details"
    }

    private fun renderSimpleUserReport(report: JSONObject): String {
        val forager = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val readiness = learning.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        val breakthrough = forager.optJSONObject("evidenceDiscoveryBreakthroughReport") ?: JSONObject()
        val learningValue = forager.optJSONObject("learningValueScoreReport") ?: JSONObject()
        val topicMemory = forager.optJSONObject("topicMemoryLedgerReport") ?: JSONObject()
        val leadQueue = forager.optJSONObject("leadInspectionQueueReport") ?: JSONObject()
        val progress = forager.optJSONObject("researchProgressWithoutEvidenceReport") ?: JSONObject()
        val handoff = forager.optJSONObject("leadClosureHandoffReport") ?: JSONObject()
        val metadataClosure = forager.optJSONObject("metadataClosureReport") ?: JSONObject()
        val routePrior = forager.optJSONObject("unknownRouteClassificationReport") ?: JSONObject()
        val ebvCriterion = forager.optJSONObject("ebvLeadVerificationReport") ?: JSONObject()
        val topicFit = forager.optJSONObject("topicFitMetadataParseReport") ?: JSONObject()
        val topic = firstNonBlank(topicFit.optString("topicLabel"), visibleTopic(topicMemory))
        val score = learningValue.optInt("score", readiness.optInt("score", 0))
        val leadObjects = forager.optJSONArray("leadObjects") ?: JSONArray()
        val openLeadCount = leadQueue.optInt("openItems", leadObjects.length())
        val bestLead = friendlyLead(firstNonBlank(
            leadQueue.optJSONArray("items")?.optJSONObject(0)?.optString("label").orEmpty(),
            breakthrough.optString("bestLead"),
            forager.optString("bestLead"),
            ""
        ))
        val learned = friendlyLearnedSummary(
            learningValue.optString("learnedSummary"),
            jsonArrayToList(progress.optJSONArray("successCategories")),
            report
        )
        val next = friendlyNextAction(firstNonBlank(
            topicFit.optString("nextAction"),
            leadQueue.optString("nextAction"),
            learningValue.optString("nextAction"),
            breakthrough.optString("nextAction"),
            forager.optString("nextAction"),
            learning.optString("nextLearningAction"),
            ""
        ))
        val result = friendlyMainResult(report, openLeadCount, score)
        return buildString {
            append("Immune Research Summary\n")
            append("• Topic: ").append(topic).append("\n")
            append("• Result: ").append(result).append("\n")
            append("• Research value: ").append(score).append("/100 — ").append(friendlyScoreBand(score)).append("\n")
            if (topicFit.optBoolean("active", false)) {
                append("• Selected route: ").append(topicFit.optString("preferredLane", "unknown").replace('_', ' ')).append("\n")
                append("• Strictness: ").append(topicFit.optString("strictnessMode", "RELAXED_PROGRESSION_NO_CLAIM_RELAXATION")).append("\n")
                append("• Learning: ").append(topicFit.optString("learningStatus", "unknown")).append("\n")
                append("• Discovery: ").append(topicFit.optString("discoveryStatus", "unknown")).append("\n")
                append("• Evidence: ").append(topicFit.optString("evidenceStatus", "unknown")).append("\n")
                append("• Context seeds: ").append(jsonArrayToList(topicFit.optJSONArray("contextSeeds")).take(5).joinToString(", ").ifBlank { "none" }).append("\n")
                append("• Soft gates: ").append(jsonArrayToList(topicFit.optJSONArray("softProgressionGates")).take(5).joinToString(", ").ifBlank { "none" }).append("\n")
                append("• Hard claim gates: ").append(jsonArrayToList(topicFit.optJSONArray("hardClaimGates")).take(5).joinToString(", ").ifBlank { "none listed" }).append("\n")
            }
            append("• What changed: ").append(learned).append("\n")
            append(LearningRulesUiSummary.renderCompact(forager)).append("\n")
            append("• Useful lead: ").append(bestLead).append("\n")
            append("• Leads to check: ").append(openLeadCount).append("\n")
            append("• Next step: ").append(next).append("\n")
            append("• Boundary: Research progress only. Not proof, diagnosis, treatment, or medical advice.\n")
            append("Full technical details are available in Export or Advanced.")
        }
    }

    private fun renderMiniLearningReport(report: JSONObject): String {
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incident = learning.optJSONObject("incident") ?: JSONObject()
        val forager = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val learningValue = forager.optJSONObject("learningValueScoreReport") ?: JSONObject()
        val topicMemory = forager.optJSONObject("topicMemoryLedgerReport") ?: JSONObject()
        val leadQueue = forager.optJSONObject("leadInspectionQueueReport") ?: JSONObject()
        val progress = forager.optJSONObject("researchProgressWithoutEvidenceReport") ?: JSONObject()
        val gapQueue = forager.optJSONObject("knowledgeGapQueueReport") ?: JSONObject()
        val handoff = forager.optJSONObject("leadClosureHandoffReport") ?: JSONObject()
        val metadataClosure = forager.optJSONObject("metadataClosureReport") ?: JSONObject()
        val routePrior = forager.optJSONObject("unknownRouteClassificationReport") ?: JSONObject()
        val ebvCriterion = forager.optJSONObject("ebvLeadVerificationReport") ?: JSONObject()
        val topicFit = forager.optJSONObject("topicFitMetadataParseReport") ?: JSONObject()
        val gapItems = gapQueue.optJSONArray("items") ?: JSONArray()
        val gaps = (0 until gapItems.length().coerceAtMost(3)).mapNotNull {
            friendlyGap(gapItems.optJSONObject(it)?.optString("gapId").orEmpty()).takeIf { value -> value.isNotBlank() }
        }.distinct()
        val categories = friendlyProgressCategories(jsonArrayToList(progress.optJSONArray("successCategories"))).take(3)
        val next = friendlyNextAction(firstNonBlank(
            topicFit.optString("nextAction"),
            leadQueue.optString("nextAction"),
            learningValue.optString("nextAction"),
            gapItems.optJSONObject(0)?.optString("nextQuery").orEmpty(),
            learning.optString("nextLearningAction"),
            ""
        ))
        return buildString {
            append("Learning Summary\n")
            append("• Topic memory: ").append(visibleTopic(topicMemory)).append("\n")
            append("• Saved progress: ").append(categories.joinToString(", ").ifBlank { "topic saved for future runs" }).append("\n")
            if (topicFit.optBoolean("active", false)) {
                append("• Route: ").append(topicFit.optString("preferredLane", "unknown").replace('_', ' ')).append("\n")
                append("• Strictness: progress relaxed; claims still gated\n")
                append("• Context seeds: ").append(jsonArrayToList(topicFit.optJSONArray("contextSeeds")).take(4).joinToString(", ").ifBlank { "none" }).append("\n")
                append("• Learning/Discovery: ").append(topicFit.optString("learningStatus", "unknown")).append(" / ").append(topicFit.optString("discoveryStatus", "unknown")).append("\n")
            }
            append("• Learned: ").append(friendlyLearnedSummary(learningValue.optString("learnedSummary"), jsonArrayToList(progress.optJSONArray("successCategories")), report)).append("\n")
            append(LearningRulesUiSummary.renderMini(forager)).append("\n")
            append("• Open checks: ").append(gaps.joinToString(", ").ifBlank { "metadata, outcome labels, control/comparator" }).append("\n")
            append("• Lead queue: ").append(leadQueue.optInt("openItems", 0)).append(" item(s) to inspect\n")
            append("• Next: ").append(next).append("\n")
            append("• Rule: saved leads are research progress, not scientific proof.")
        }
    }

    private fun renderPostSearchThinkingCard(report: JSONObject): String {
        val thinking = report.optJSONObject("postSearchThinkingReport") ?: JSONObject()
        val closure = report.optJSONObject("evidenceClosureReport") ?: JSONObject()
        val continuity = report.optJSONObject("thinkingContinuityReport") ?: JSONObject()
        val graph = report.optJSONObject("hypothesisGraphReport") ?: JSONObject()
        val momentum = report.optJSONObject("cognitiveMomentumReport") ?: JSONObject()
        val spine = report.optJSONObject("linkedCognitionSpineReport") ?: JSONObject()
        val extendedThinking = report.optJSONObject("extendedThinkingBudgetReport") ?: JSONObject()
        if (!thinking.optBoolean("active", false) && !closure.optBoolean("active", false) && !continuity.optBoolean("active", false) && !graph.optBoolean("active", false) && !momentum.optBoolean("active", false) && !spine.optBoolean("active", false) && !extendedThinking.optBoolean("active", false)) {
            return "Thinking board\n• State: no post-search cognition stored yet.\n• Next: run Search once, then this board will keep the reasoning alive without internet."
        }
        val cards = closure.optJSONArray("cards") ?: JSONArray()
        val card = cards.optJSONObject(0) ?: JSONObject()
        val hypotheses = thinking.optJSONArray("hypotheses") ?: JSONArray()
        val topHypothesis = hypotheses.optJSONObject(0) ?: JSONObject()
        val linked = jsonArrayToList(thinking.optJSONArray("linkedPoints")).take(3)
        val contradictions = jsonArrayToList(thinking.optJSONArray("contradictions")).take(3)
        val repeatedGaps = jsonArrayToList(continuity.optJSONArray("repeatedGaps")).take(4)
        return buildString {
            append("Thinking board\n")
            append("• State: ").append(continuity.optString("state", thinking.optString("state", closure.optString("mode", "not evaluated")))).append("\n")
            append("• Closure: ").append(card.optString("accession", closure.optString("selectedAccession", "none")))
                .append(" → ").append(card.optString("decision", closure.optString("mode", "not evaluated"))).append("\n")
            val missing = jsonArrayToList(card.optJSONArray("missingFields")).take(4)
            append("• Missing: ").append(missing.joinToString(", ").ifBlank { "none listed" }).append("\n")
            append("• Hypothesis: ").append(cleanLine(topHypothesis.optString("label", "No hypothesis card yet"), 180)).append("\n")
            if (linked.isNotEmpty()) {
                append("• Linked: ").append(cleanLine(linked.joinToString(" | "), 220)).append("\n")
            }
            if (contradictions.isNotEmpty()) {
                append("• Objection: ").append(cleanLine(contradictions.joinToString(" | "), 220)).append("\n")
            }
            if (repeatedGaps.isNotEmpty()) {
                append("• Repeated gaps: ").append(repeatedGaps.joinToString(", ")).append("\n")
            }
            if (graph.optBoolean("active", false)) {
                append("• Map: ").append(cleanLine(graph.optString("state", "unknown") + " / weakest=" + graph.optString("weakestLink", "none"), 180)).append("\n")
                append("• Map next: ").append(cleanLine(graph.optString("nextReasoningMove", "none"), 220)).append("\n")
            }
            if (momentum.optBoolean("active", false)) {
                append("• Momentum: ").append(cleanLine(momentum.optString("state", "NO_MOMENTUM") + " / " + momentum.optInt("momentumScore", 0) + "/100", 160)).append("\n")
                val stalled = jsonArrayToList(momentum.optJSONArray("stalledEvidenceKeys")).take(3)
                if (stalled.isNotEmpty()) append("• Stalled: ").append(stalled.joinToString(", ")).append("\n")
                append("• Lock: ").append(cleanLine(momentum.optString("decisionLock", "none"), 220)).append("\n")
            }
            if (spine.optBoolean("active", false)) {
                append("• Spine: ").append(cleanLine(spine.optString("state", "NO_SPINE") + " / " + spine.optString("governingLayer", "none") + " / " + spine.optInt("linkIntegrityScore", 0) + "/100", 220)).append("\n")
                append("• Spine decision: ").append(cleanLine(spine.optString("governingDecision", "none"), 220)).append("\n")
            }
            append("• Next thought: ").append(cleanLine(continuity.optString("nextLocalQuestion", thinking.optString("nextOfflineThought", closure.optString("nextMicroAction", "No next thought stored"))), 220)).append("\n")
            if (extendedThinking.optBoolean("active", false)) {
                append("• Extended budget: ").append(extendedThinking.optInt("passesExecuted", 0)).append("/").append(extendedThinking.optInt("minimumPassesRequired", 0)).append(" passes; ")
                    .append(cleanLine(extendedThinking.optString("summary", "extended thinking active"), 180)).append("\n")
            }
            append("• Search gate: ").append(cleanLine(spine.optString("searchDecision", continuity.optString("nextSearchPermission", thinking.optString("nextSearchGate", closure.optString("queryBudgetDecision", "Search only after evidence closure")))), 220))
        }
    }


    private fun renderAutonomousThoughtPulse(pulse: JSONObject): String = buildString {
        append("Autonomous thought pulse\n")
        append("• State: ").append(pulse.optString("state", "not recorded")).append("\n")
        append("• Decision: ").append(cleanLine(pulse.optString("decision", "No decision stored."), 220)).append("\n")
        val gaps = jsonArrayToList(pulse.optJSONArray("unresolvedGaps")).take(4)
        append("• Open gaps: ").append(gaps.joinToString(", ").ifBlank { "none listed" }).append("\n")
        append("• Delta: ").append(cleanLine(pulse.optString("cognitiveDelta", "No local delta."), 220)).append("\n")
        append("• Local move: ").append(cleanLine(pulse.optString("nextLocalMove", "Think before searching."), 220)).append("\n")
        append("• Search unlock: ").append(cleanLine(pulse.optString("searchUnlockCondition", "No broad search without evidence closure."), 220))
    }

    private fun renderOfflineThinkingStep(step: JSONObject): String = buildString {
        append("Offline thinking step #").append(step.optInt("stepNumber", 1)).append("\n")
        append("• Focus: ").append(cleanLine(step.optString("focus", "No focus stored."), 220)).append("\n")
        append("• Thread: ").append(cleanLine(step.optString("thread", "No thread stored."), 200)).append("\n")
        val repeated = jsonArrayToList(step.optJSONArray("repeatedGaps")).take(4)
        if (repeated.isNotEmpty()) {
            append("• Repeated gaps: ").append(repeated.joinToString(", ")).append("\n")
        }
        append("• Decision: ").append(cleanLine(step.optString("decision", "Think before searching."), 220)).append("\n")
        append("• Permission: ").append(cleanLine(step.optString("nextPermission", "No broad search."), 220))
    }

    @Suppress("unused")
    private fun uiCompatibilityAuditTokensV194(): String = listOf(
        "candidateActionReport", "autoContinuationReport", "reportConsistencyGuard",
        "renderSimpleUserReport", "renderMiniLearningReport", "toggleAdvancedControls", "learningMiniReportText", "advancedControlsContainer",
        "specializedReasoningReport", "Specialized reasoning:", "Specialist check:", "specialistVerdict", "evidenceGaps",
        "Knowledge map:", "Map next:", "Map state:", "knowledgeMapReport",
        "Belief model:", "Belief next:", "Next belief action", "epistemicBeliefReport",
        "Strengthened belief:", "Weakened belief:", "Dropped belief:", "Belief abandonment test:", "Belief changed: strengthened=",
        "Linked thinking path:", "Linked path:", "Linked next:", "cognitivePathIntegrationReport",
        "cognitiveLoopCalibrationReport", "Loop calibration:", "calibrationScore", "Closed loop retired", "Directive lifecycle", "Evidence-gain query", "Belief contracts", "Causal readiness", "Mini peer review",
        "Scientific term index", "Deep discovery", "Decisive test", "Deep Think",
        "Weighted discovery:", "Decisive evidence delta", "Discovery decision memory:", "Blocked move:", "Next-cycle contract:", "If it fails:",
        "Discovery stress test:", "Stress branch:", "scientificDiscoveryStressTestReport",
        "Execution policy:", "Policy blocks:", "scientificDiscoveryExecutionPolicyReport",
        "Outcome verifier:", "Verifier adjustment:", "scientificDiscoveryOutcomeVerifierReport",
        "Hypothesis lineage:", "Lineage next:", "Lineage carry-forward",
        "Latent discovery gaps:", "Latent gap miner:", "Gap-miner next probe",
        "Executable probe plan:", "Probe query:",
        "Meta-strategy governor:", "Strategy decision:", "Quality gate:", "Discovery quality gate:",
        "Executable runbook:", "Runbook route decision:",
        "Evidence Closure Mode", "evidenceClosureReport", "Post-Search Thinking", "postSearchThinkingReport",
        "postSearchThinkingText", "renderPostSearchThinkingCard", "continuePostSearchThinking", "thinkingContinuityReport", "renderOfflineThinkingStep", "autonomousThoughtPulse", "renderAutonomousThoughtPulse", "cognitiveMomentumReport", "linkedCognitionSpineReport",
        "v1.9.5 UI guard", "legacyTechnicalResultContainer", "Export shows the technical layers"
    ).joinToString("|")

    private fun shortLearningChange(report: JSONObject): String {
        val v3 = report.optJSONObject("reportV3") ?: JSONObject()
        val forager = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val autoContinuation = forager.optJSONObject("autoContinuationReport") ?: JSONObject()
        val candidateAction = forager.optJSONObject("candidateActionReport") ?: JSONObject()
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incident = learning.optJSONObject("incident") ?: JSONObject()
        val roots = jsonArrayToList(incident.optJSONArray("rootCauses"))
        return firstNonBlank(
            v3.optString("hypothesisChanged"),
            autoContinuation.optString("recommendedAction"),
            candidateAction.optString("summary"),
            if (roots.isNotEmpty()) "Recorded failure pattern: ${roots.joinToString(", ")}" else "Search memory updated; no major change yet."
        )
    }

    private fun topFindingTitle(report: JSONObject): String {
        val findings = report.optJSONArray("findings") ?: JSONArray()
        return findings.optJSONObject(0)?.optString("title").orEmpty()
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()

    private fun cleanLine(value: String, maxLen: Int): String {
        val compact = value.replace(Regex("\\s+"), " ").trim()
        return if (compact.length <= maxLen) compact else compact.take(maxLen - 1).trimEnd() + "…"
    }

    private fun visibleTopic(topicMemory: JSONObject): String {
        val active = topicMemory.optJSONObject("activeThread") ?: JSONObject()
        val saved = active.optString("topic").trim()
        val typed = topicPromptInput.text.toString().trim()
        return cleanLine(firstNonBlank(saved, typed, "Immune research topic"), 90)
    }

    private fun friendlyMainResult(report: JSONObject, openLeadCount: Int, score: Int): String {
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        return when {
            evidenceObjects.length() > 0 -> "Evidence candidate found for review"
            openLeadCount > 0 -> "Useful lead found — needs checking"
            score >= 60 -> "Good research progress — no proof yet"
            score >= 30 -> "Learning saved — more evidence needed"
            else -> "No useful immune lead yet"
        }
    }

    private fun friendlyScoreBand(score: Int): String = when {
        score >= 70 -> "strong research progress"
        score >= 45 -> "moderate research progress"
        score >= 20 -> "early research progress"
        else -> "not enough useful signal yet"
    }

    private fun friendlyLead(raw: String): String {
        val value = raw.trim()
        if (value.isBlank() || value.equals("none", true) || value.equals("unknown", true)) return "No inspectable lead yet"
        val lower = value.lowercase()
        val friendly = when {
            lower.contains("manual_text_snippet") -> "Manual topic note saved for review"
            lower.contains("near-miss source response") && lower.contains("pubmed") -> "Possible dataset lead from PubMed metadata"
            lower.contains("near-miss source response") -> "Possible dataset lead from a source response"
            lower.contains("off_route_dataset") -> "Dataset appears off-route; use only for comparison"
            value.contains("_") && value.uppercase() == value -> "Technical lead saved for review"
            else -> value
        }
        return cleanLine(friendly, 120)
    }

    private fun friendlyNextAction(raw: String): String {
        val value = raw.trim()
        if (value.isBlank() || value.equals("none", true) || value.equals("unknown", true)) {
            return "Run a dataset-focused immune search with outcome and control terms."
        }
        val lower = value.lowercase()
        val friendly = when {
            lower.contains("lead_object_secondary_lookup") || lower.contains("weak/near-miss") || lower.contains("source ids") || lower.contains("supplementary-data") ->
                "Check the saved lead for source IDs, supplementary data, dataset accession, sample metadata, outcome labels, and controls."
            lower.contains("dataset accession") || lower.contains("gse") || lower.contains("prjna") || lower.contains("sra") || lower.contains("geo") ->
                "Search public dataset repositories for a matching accession, human cohort metadata, outcome labels, and controls."
            lower.contains("outcome") || lower.contains("control") || lower.contains("metadata") ->
                "Close the missing evidence fields: metadata, outcome labels, time order, and control/comparator."
            lower.contains("contradiction") || lower.contains("negative") ->
                "Run a negative-control or contradiction check before trusting the route."
            lower.contains("archive") || lower.contains("cool down") ->
                "Pause this weak route unless a new dataset lead appears."
            else -> value
        }
        return cleanLine(friendly, 170)
    }

    private fun friendlyLearnedSummary(raw: String, categories: List<String>, report: JSONObject): String {
        val friendlyCategories = friendlyProgressCategories(categories)
        if (friendlyCategories.isNotEmpty()) {
            return cleanLine(friendlyCategories.take(3).joinToString("; "), 170)
        }
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val roots = jsonArrayToList(learning.optJSONObject("incident")?.optJSONArray("rootCauses")).take(3)
        val rootSummary = friendlyRootCauses(roots)
        if (rootSummary.isNotBlank()) return cleanLine(rootSummary, 170)
        val rawClean = stripTechnicalCodes(raw)
        return cleanLine(rawClean.ifBlank { "The topic was saved and will guide the next immune-focused search." }, 170)
    }

    private fun friendlyProgressCategories(categories: List<String>): List<String> = categories.mapNotNull { raw ->
        when (raw.trim().lowercase()) {
            "topic_stored" -> "topic saved"
            "query_strategy_changed" -> "search strategy improved"
            "weak_lead_preserved" -> "weak lead preserved"
            "gap_queue_created" -> "missing evidence checklist created"
            "dataset_first_attempted" -> "dataset search attempted"
            "post_pubmed_strategy_prepared", "dataset_catalog_strategy_prepared" -> "dataset-catalog search prepared"
            "failure_pattern_learned" -> "failure pattern learned"
            "lead_closure_handoff_pinned" -> "lead-closure rule pinned"
            "metadata_closure_fields_tracked" -> "metadata fields tracked"
            "route_prior_classified" -> "route prior classified"
            "latent_virus_route_prior_saved" -> "latent-virus route saved as prior"
            else -> null
        }
    }.distinct()

    private fun friendlyRootCauses(roots: List<String>): String = roots.mapNotNull { raw ->
        when (raw.trim().uppercase()) {
            "NO_DATASET_ACCESSION" -> "need a public dataset accession"
            "BROAD_QUERY" -> "previous query was too broad"
            "NO_CONTRADICTION_SEARCH" -> "need a contradiction check"
            "NO_CONTROL_SIGNAL" -> "need control/comparator data"
            "WRONG_VOCABULARY" -> "search vocabulary needs refinement"
            else -> null
        }
    }.distinct().joinToString("; ")

    private fun friendlyGap(raw: String): String = when (raw.trim().lowercase()) {
        "license_access" -> "license/access"
        "sample_size" -> "sample size"
        "outcome_labels" -> "outcome labels"
        "time_order", "time_order_or_longitudinal" -> "time order"
        "control_or_comparator", "comparator_control" -> "control/comparator"
        "minimum_metadata" -> "minimum metadata"
        "condition_labels" -> "condition labels"
        "human_or_patient_data" -> "human/patient data"
        else -> stripTechnicalCodes(raw).takeIf { it.isNotBlank() } ?: "metadata"
    }


    private fun friendlyLearningDetails(metadataClosure: JSONObject, routePrior: JSONObject, handoff: JSONObject): String {
        val closed = jsonArrayToList(metadataClosure.optJSONArray("closedFields")).map { friendlyGap(it) }.take(4)
        val missing = jsonArrayToList(metadataClosure.optJSONArray("missingFields")).map { friendlyGap(it) }.take(4)
        val route = routePrior.optString("selectedRoute", "none")
        val confidence = routePrior.optInt("confidence", 0)
        val carried = handoff.optInt("carriedLeadCount", 0)
        val pieces = mutableListOf<String>()
        if (carried > 0) pieces += "carried $carried lead(s) into closure"
        if (closed.isNotEmpty()) pieces += "closed: ${closed.joinToString(", ")}"
        if (missing.isNotEmpty()) pieces += "missing: ${missing.joinToString(", ")}"
        if (route.isNotBlank() && route != "none") pieces += "route prior: ${friendlyRoutePrior(route)} ($confidence/100, not proof)"
        return cleanLine(pieces.joinToString("; ").ifBlank { "topic memory updated; no evidence object yet" }, 260)
    }

    private fun friendlyPinnedRules(handoff: JSONObject): String {
        val rules = jsonArrayToList(handoff.optJSONArray("pinnedLearningRules"))
        val fallback = listOf(
            "do not restart from zero after a weak lead",
            "metadata before hypothesis upgrade",
            "contradiction check after route is known"
        )
        return cleanLine((rules.ifEmpty { fallback }).take(2).joinToString("; "), 260)
    }

    private fun friendlyRoutePrior(route: String): String = when (route.trim().lowercase()) {
        "type2_allergy_mast_cell_route" -> "allergy / mast-cell"
        "autoimmune_flare_route" -> "autoimmune flare"
        "interferon_antiviral_route" -> "interferon / antiviral"
        "latent_virus_reactivation_route" -> "latent-virus reactivation"
        "drug_perturbation_route" -> "drug/medication exposure"
        "stress_immune_psychoneuro_route" -> "stress / immune context"
        "barrier_tissue_route" -> "barrier tissue"
        "rna_transcriptomic_state_route" -> "RNA/transcriptomic state"
        else -> stripTechnicalCodes(route)
    }

    private fun friendlyResultState(raw: String): String = when (raw.trim().uppercase()) {
        "DATASET_HUNT" -> "dataset search"
        "NO_DATASET" -> "no dataset yet"
        "VALID_NO_EVIDENCE" -> "no proof yet"
        else -> stripTechnicalCodes(raw).ifBlank { "research saved" }
    }

    private fun stripTechnicalCodes(value: String): String {
        var out = value.replace(Regex("\\b[A-Z][A-Z0-9_]{2,}\\b")) { match ->
            when (match.value) {
                "WEAK_DATASET_LEAD_FOUND" -> "weak lead found"
                "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION" -> "near-miss lead needs review"
                "LEAD_OBJECT_SECONDARY_LOOKUP" -> "lead follow-up"
                "NO_EVIDENCE_OBJECT_NO_UPGRADE" -> "no proof yet"
                "OFF_ROUTE_DATASET" -> "off-route dataset"
                "VALID_NO_EVIDENCE" -> "no proof yet"
                else -> match.value.lowercase().replace('_', ' ')
            }
        }
        out = out.replace("EvidenceObject", "proof-grade evidence object")
        out = out.replace("claim-limit", "boundary")
        return out.replace(Regex("\\s+"), " ").trim()
    }

    private fun learningStatusLine(report: JSONObject): String {
        val runtime = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val exec = report.optJSONObject("executionLockReport") ?: JSONObject()
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incident = learning.optJSONObject("incident") ?: JSONObject()
        val causes = jsonArrayToList(incident.optJSONArray("rootCauses"))
        val state = runtime.optString("researchState", "UNKNOWN")
        val lock = exec.optString("status", "UNKNOWN")
        val forager = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val foragerState = forager.optString("state", "NOT_RUN")
        return "Last run: ${friendlyResultState(state)} • Learning memory updated • Next: ${friendlyRootCauses(causes).ifBlank { "ask another immune-focused topic" }}"
    }

    private fun renderResearchBoard(report: JSONObject): String {
        val runtime = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val exec = report.optJSONObject("executionLockReport") ?: JSONObject()
        val v3 = report.optJSONObject("reportV3") ?: JSONObject()
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incident = learning.optJSONObject("incident") ?: JSONObject()
        val readiness = learning.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        val datasets = report.optJSONArray("datasetCandidatesV137") ?: JSONArray()
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        val gates = learning.optJSONArray("preventiveGates") ?: JSONArray()
        val cooldowns = learning.optJSONArray("laneCooldowns") ?: JSONArray()
        val rootCauses = jsonArrayToList(incident.optJSONArray("rootCauses"))
        val forcedQueries = jsonArrayToList(runtime.optJSONArray("forcedQueries"))
        val enforced = jsonArrayToList(exec.optJSONArray("enforcedActions"))
        val forager = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val foragerSources = jsonArrayToList(forager.optJSONArray("sourceFamiliesAttempted"))
        val foragerCandidates = forager.optJSONArray("candidates") ?: JSONArray()
        val probeOutcomeLedger = report.optJSONObject("scientificDiscoveryProbeOutcomeLedgerReport") ?: JSONObject()
        val metaStrategy = report.optJSONObject("scientificDiscoveryMetaStrategyReport") ?: JSONObject()
        val qualityGate = report.optJSONObject("scientificDiscoveryQualityGateReport") ?: JSONObject()
        val runbook = report.optJSONObject("scientificDiscoveryRunbookReport") ?: JSONObject()
        val creative = forager.optJSONObject("creativeHypothesisForgeReport") ?: JSONObject()

        val lines = mutableListOf<String>()
        lines += "RESEARCH COMMAND BOARD"
        lines += "Active engine: ${runtime.optString("engineVersion", EngineRuntimeStatus.ACTIVE_ENGINE_VERSION)}"
        lines += "Execution lock: ${exec.optString("status", "UNKNOWN")}"
        lines += "Research state: ${runtime.optString("researchState", "UNKNOWN")}"
        lines += ""
        lines += "1) Search"
        lines += "• ${searchExecutionLine(report, runtime)}"
        lines += "• Runtime failover: ${runtime.optBoolean("runtimeFailoverApplied", false)}"
        lines += "• Dataset-first forager: ${forager.optString("state", "NOT_RUN")} | sources: ${foragerSources.joinToString(", ").ifBlank { "none" }}"
        if (creative.optBoolean("active", false)) {
            lines += "• Creative Hypothesis Forge: ${creative.optString("state", "ACTIVE")} | generated ${(creative.optJSONArray("generated") ?: JSONArray()).length()} | ${creative.optString("claimLimit", "creative_hypothesis_not_evidence")}"
            val axes = creative.optJSONArray("steeringAxesUsed") ?: JSONArray()
            if (axes.length() > 0) lines += "• Steering-aware axes: " + (0 until axes.length().coerceAtMost(5)).mapNotNull { axes.optJSONObject(it)?.optString("id") }.joinToString(", ")
            val expanded = creative.optJSONObject("expandedThinking") ?: JSONObject()
            if (expanded.optBoolean("active", false)) lines += "• Expanded thinking: ${expanded.optString("mode", "EXPANDED_CREATIVE_SEARCH_THINKING")} | ${expanded.optString("claimLimit", "expanded_thinking_not_evidence")}"
        }
        lines += "• New sources: ${delta.optInt("newSourcesSaved", 0)} | Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        if (forcedQueries.isNotEmpty()) {
            lines += "• Forced query path: ${forcedQueries.take(2).joinToString(" | ")}"
        }
        lines += ""
        lines += "2) Evidence"
        lines += "• Cycle: ${v3.optString("cycleResult", "Not evaluated")}" 
        lines += "• Dataset candidates: ${datasets.length()} | Direct forager candidates: ${foragerCandidates.length()} | Evidence objects: ${evidenceObjects.length()}"
        lines += "• Contradiction: ${v3.optString("counterEvidenceOrContradiction", "Not evaluated").take(160)}"
        lines += ""
        lines += "3) Learning"
        lines += "• Root cause: ${rootCauses.joinToString(", ").ifBlank { "none yet" }}"
        lines += "• Forager learning block: ${forager.optString("blockedLearningReason", "none")}"
        lines += "• Preventive gates: ${gates.length()} | Lane cooldowns: ${cooldowns.length()}"
        lines += "• Discovery readiness: ${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")}" 
        if (probeOutcomeLedger.optBoolean("active", false)) lines += "• Probe outcome: ${probeOutcomeLedger.optString("ledgerState", "NOT_RUN")} • closure ${probeOutcomeLedger.optInt("evidenceClosureScore", 0)}/100"
        if (metaStrategy.optBoolean("active", false)) lines += "• Meta-strategy: ${metaStrategy.optString("strategyState", "NOT_RUN")} • ${metaStrategy.optString("explorationExploitationMode", "BALANCED_GUARDED")}"
        if (qualityGate.optBoolean("active", false)) lines += "• Quality gate: ${qualityGate.optString("gateState", "NOT_RUN")} • quality ${qualityGate.optInt("qualityScore", 0)}/100 • allow ${qualityGate.optBoolean("allowExecution", false)}"
        if (runbook.optBoolean("active", false)) lines += "• Runbook: ${runbook.optString("runbookState", "NOT_RUN")} • mode ${runbook.optString("selectedRunMode", "NO_RUNBOOK")} • budget ${runbook.optInt("executionBudget", 0)}"
        if (enforced.isNotEmpty()) lines += "• Enforced: ${enforced.take(2).joinToString(" | ")}" 
        lines += ""
        lines += "Next action"
        lines += "• ${v3.optString("nextAutonomousMove", "Run the next autonomous research cycle.")}" 
        lines += ""
        lines += "Boundary: research leads only. No diagnosis or treatment advice."
        return lines.joinToString("\n")
    }

    private fun renderBriefReport(report: JSONObject): String {
        val v3 = report.optJSONObject("reportV3")
        if (v3 != null && v3.optString("cycleResult").isNotBlank()) {
            return listOf(
                "AUTONOMOUS DISCOVERY REPORT",
                "Active engine: ${(report.optJSONObject("runtimeStatus") ?: JSONObject()).optString("engineVersion", "unknown")}",
                "Execution lock: ${(report.optJSONObject("executionLockReport") ?: JSONObject()).optString("status", "UNKNOWN")}",
                "Research state: ${(report.optJSONObject("runtimeStatus") ?: JSONObject()).optString("researchState", "UNKNOWN")}",
                "Cycle result: ${v3.optString("cycleResult")}",
                "Hypothesis: ${v3.optString("hypothesis", "No active hypothesis passed the evidence gates.")}",
                "Supporting evidence: ${v3.optString("supportingEvidence", v3.optString("newUsefulLead"))}",
                "Counter-evidence / contradiction: ${v3.optString("counterEvidenceOrContradiction", "No contradiction section available.")}",
                "What we do not believe yet: ${v3.optString("whatWeDoNotBelieveYet", v3.optString("doNotBelieveYet"))}",
                "Hypothesis changed: ${v3.optString("hypothesisChanged")}",
                "Why it matters: ${v3.optString("whyItMatters")}",
                "Next autonomous move: ${v3.optString("nextAutonomousMove")}",
                "Integrity lock: ${v3.optString("integrityStatus", "UNKNOWN")}"
            ).toMutableList().apply {
                val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
                val incident = learning.optJSONObject("incident") ?: JSONObject()
                val readiness = learning.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
                add("Learning OS: ${jsonArrayToList(incident.optJSONArray("rootCauses")).joinToString(", ").ifBlank { "no incident" }}")
                add("Discovery readiness: ${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")}")
                val probeOutcomeLedger = report.optJSONObject("scientificDiscoveryProbeOutcomeLedgerReport") ?: JSONObject()
                if (probeOutcomeLedger.optBoolean("active", false)) {
                    add("Probe outcome ledger: ${probeOutcomeLedger.optString("ledgerState", "NOT_RUN")} • closure ${probeOutcomeLedger.optInt("evidenceClosureScore", 0)}/100")
                    add("Probe next decision: ${probeOutcomeLedger.optString("nextProbeDecision", "Run bounded evidence closure.")}")
                }
                val metaStrategy = report.optJSONObject("scientificDiscoveryMetaStrategyReport") ?: JSONObject()
                if (metaStrategy.optBoolean("active", false)) {
                    add("Meta-strategy governor: ${metaStrategy.optString("strategyState", "NOT_RUN")} • ${metaStrategy.optString("explorationExploitationMode", "BALANCED_GUARDED")}")
                    add("Strategy decision: ${metaStrategy.optString("continuationDecision", "Continue with bounded evidence closure.")}")
                }
                val qualityGate = report.optJSONObject("scientificDiscoveryQualityGateReport") ?: JSONObject()
                if (qualityGate.optBoolean("active", false)) {
                    add("Discovery quality gate: ${qualityGate.optString("gateState", "NOT_RUN")} • quality ${qualityGate.optInt("qualityScore", 0)}/100 • allow=${qualityGate.optBoolean("allowExecution", false)}")
                    add("Quality decision: ${qualityGate.optString("executionDecision", "Run guarded evidence closure.")}")
                }
                val runbook = report.optJSONObject("scientificDiscoveryRunbookReport") ?: JSONObject()
                if (runbook.optBoolean("active", false)) {
                    add("Executable runbook: ${runbook.optString("runbookState", "NOT_RUN")} • mode ${runbook.optString("selectedRunMode", "NO_RUNBOOK")} • budget=${runbook.optInt("executionBudget", 0)}")
                    add("Runbook route decision: ${runbook.optString("routeDecision", "Run bounded evidence closure.")}")
                }
                val gate = (learning.optJSONArray("preventiveGates") ?: JSONArray()).optJSONObject(0)
                if (gate != null) add("Preventive gate: ${gate.optString("gateId")} → ${gate.optString("forcedNextIntent")}")
                val reasoning = report.optJSONObject("reasoningReport") ?: JSONObject()
                val meaning = reasoning.optString("interpretedMeaning", "")
                val nextReasoned = reasoning.optString("nextReasonedMove", "")
                if (meaning.isNotBlank()) {
                    add("")
                    add("Reasoning:")
                    add("• $meaning")
                }
                if (nextReasoned.isNotBlank()) add("• Next reasoned move: $nextReasoned")
            }.joinToString("\n")
        }
        if ((report.optJSONArray("hypothesisObjects")?.length() ?: 0) > 0) {
            return ResearchReportTemplateV2.renderBrief(report)
        }
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val findings = report.optJSONArray("findings") ?: JSONArray()
        val top = findings.optJSONObject(0)
        val lines = mutableListOf<String>()
        lines += "SHORT DISCOVERY REPORT"
        lines += "Generated: ${report.optString("createdAtText", "")}"
        lines += "Stop reason: ${report.optString("stopReason", "completed")}"
        lines += "New sources: ${delta.optInt("newSourcesSaved", findings.length())} | Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        lines += "DNA/RNA signals: ${delta.optInt("dnaRnaSignals", 0)} | Manual reports used: ${delta.optInt("manualReportSignalsUsed", 0)}"
        lines += "Steered queries: ${delta.optInt("steeredQueriesGenerated", 0)}"
        val plan = report.optJSONObject("autonomousPlan") ?: JSONObject()
        lines += "Autonomous mode: ${plan.optString("strategy", "explore_deepen_challenge")}"
        val cards = report.optJSONArray("hypothesisRankCards") ?: JSONArray()
        val topCard = cards.optJSONObject(0)
        if (topCard != null) {
            lines += "Top hypothesis: ${topCard.optString("status")} • ${topCard.optInt("overallScore")}/100"
        }
        lines += ""
        lines += "Top new lead:"
        if (top != null) {
            lines += "• ${top.optString("title")}"
            lines += "• ${top.optString("bridgeSignal")}"
            lines += "• Novelty: ${top.optInt("noveltyScore")}/100"
            val ev = top.optJSONObject("evidence") ?: JSONObject()
            val ca = top.optJSONObject("causality") ?: JSONObject()
            lines += "• Evidence: ${ev.optInt("evidenceQualityScore", 0)}/100 ${ev.optString("speciesClass", "unknown")}/${ev.optString("studyDesign", "unknown")}"
            lines += "• Causality: ${ca.optInt("causalityScore", 0)}/100"
        } else {
            val skipped = delta.optInt("repeatedSourcesSkipped", 0)
            if (skipped > 0) {
                val plan = report.optJSONObject("autonomousPlan") ?: JSONObject()
                lines += "• No useful new source saved. $skipped PubMed IDs were already known."
                lines += "• Next autonomous strategy: ${plan.optString("nextStrategyIfNoUsefulSource", "rotate to dataset/omics/contradiction search")}."
            } else {
                lines += "• No useful new source saved. The autonomous planner will change lanes next cycle; optional steering/import can accelerate it."
            }
        }
        lines += ""
        lines += "Main emerging link:"
        val links = report.optJSONArray("emergentLinks")
        lines += "• " + (links?.optString(0) ?: "None")
        lines += ""
        lines += "Next question:"
        val qs = report.optJSONArray("nextQuestions")
        lines += "• " + (qs?.optString(0) ?: "Which public dataset has trigger, immune-response axis, and outcome labels?")
        return lines.joinToString("\n")
    }

    private fun renderReportPreview(report: JSONObject): String {
        val lines = mutableListOf<String>()
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val findings = report.optJSONArray("findings") ?: JSONArray()
        val summary = report.optJSONObject("researchStateSummary") ?: JSONObject()
        val v3 = report.optJSONObject("reportV3") ?: JSONObject()
        val pivot = report.optJSONObject("resilienceDecision") ?: JSONObject()
        val datasets = report.optJSONArray("datasetCandidatesV137") ?: JSONArray()
        lines += "Result"
        val runtime = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val execLock = report.optJSONObject("executionLockReport") ?: JSONObject()
        lines += "• Active engine: ${runtime.optString("engineVersion", "unknown")}"
        lines += "• Execution lock: ${execLock.optString("status", "UNKNOWN")}"
        lines += "• Research state: ${runtime.optString("researchState", "UNKNOWN")}"
        lines += "• ${searchExecutionLine(report, runtime)}"
        lines += "• Runtime failover: ${runtime.optBoolean("runtimeFailoverApplied", false)}"
        val foragerPreview = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        lines += "• Dataset-first forager: ${foragerPreview.optString("state", "NOT_RUN")}"
        lines += "• Cycle: ${v3.optString("cycleResult", if (findings.length() > 0) "Useful delta" else "No useful delta")}"
        lines += "• Integrity lock: ${v3.optString("integrityStatus", "UNKNOWN")}"
        lines += "• Hypothesis: ${v3.optString("hypothesis", "No active hypothesis.")}"
        lines += "• Counter-evidence: ${v3.optString("counterEvidenceOrContradiction", "Not evaluated.")}"
        lines += "• New useful sources: ${delta.optInt("newSourcesSaved", findings.length())}"
        lines += "• Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incident = learning.optJSONObject("incident") ?: JSONObject()
        val readiness = learning.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        val rootCausesText = jsonArrayToList(incident.optJSONArray("rootCauses")).joinToString(", ").ifBlank { "none" }
        lines += "• Dataset candidates: ${datasets.length()}"
        lines += "• Evidence objects: ${evidenceObjects.length()}"
        lines += "• Learning root cause: $rootCausesText"
        lines += "• Discovery readiness: ${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")}"
        lines += "• Discovery state: ${summary.optString("discoveryState", "Off")}"
        lines += "• Bias risk: ${summary.optString("biasRiskState", "Normal")}"
        val pivotType = pivot.optString("pivotType", "NO_PIVOT")
        if (pivotType != "NO_PIVOT") lines += "• Pivot: $pivotType → ${pivot.optString("nextIntent", "change_strategy")}"
        val reasoning = report.optJSONObject("reasoningReport") ?: JSONObject()
        lines += ""
        lines += "Reasoning"
        lines += "• " + reasoning.optString("observation", "No reasoning observation yet.")
        lines += "• " + reasoning.optString("interpretedMeaning", "No interpretation yet.")
        lines += ""
        lines += "Action"
        lines += "• " + reasoning.optString("nextReasonedMove", v3.optString("nextAutonomousMove", "Run the next autonomous cycle."))
        return lines.joinToString("\n")
    }

    private fun renderReport(report: JSONObject): String {
        val lines = mutableListOf<String>()
        lines += "Research Autopilot Discovery Report"
        lines += "Generated: " + report.optString("createdAtText", "")
        lines += "Completed: " + report.optString("completedAtText", "")
        lines += "Stop reason: " + report.optString("stopReason", "completed")
        lines += "Search ms: " + report.optLong("searchDurationMillis") + " | Learning ms: " + report.optLong("learningDurationMillis")
        val runtimeFull = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val execFull = report.optJSONObject("executionLockReport") ?: JSONObject()
        lines += ""
        lines += "Active engine"
        lines += "• Version: ${runtimeFull.optString("engineVersion", "unknown")}"
        lines += "• State: ${runtimeFull.optString("researchState", "UNKNOWN")}"
        lines += "• Modules: ${jsonArrayToList(runtimeFull.optJSONArray("activeModules")).joinToString(", ").ifBlank { "none" }}"
        lines += "• ${searchExecutionLine(report, runtimeFull)}"
        lines += "• Runtime failover applied: ${runtimeFull.optBoolean("runtimeFailoverApplied", false)}"
        val foragerFull = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        lines += "• Dataset-first forager: ${foragerFull.optString("state", "NOT_RUN")} | ${jsonArrayToList(foragerFull.optJSONArray("sourceFamiliesAttempted")).joinToString(", ").ifBlank { "none" }}"
        lines += "• Execution lock: ${execFull.optString("status", "UNKNOWN")}"
        lines += "• Enforced actions: ${jsonArrayToList(execFull.optJSONArray("enforcedActions")).joinToString("; ").ifBlank { "none" }}"
        val steering = report.optJSONObject("activeSteeringProfile")
        lines += ""
        lines += "Research steering"
        if (steering == null) {
            lines += "• None used."
        } else {
            lines += "• Variables: " + jsonArrayToList(steering.optJSONArray("variables")).joinToString(", ").ifBlank { "none" }
            lines += "• Focus: " + steering.optString("focusQuestion", "")
            lines += "• Required: " + jsonArrayToList(steering.optJSONArray("requiredTerms")).joinToString(", ").ifBlank { "none" }
            lines += "• Excluded: " + jsonArrayToList(steering.optJSONArray("excludedTerms")).joinToString(", ").ifBlank { "none" }
            lines += "• Inferred axes: " + jsonArrayToList(steering.optJSONArray("inferredAxes")).joinToString(", ").ifBlank { "none" }
        }
        lines += ""
        lines += "Autonomous research plan"
        val plan = report.optJSONObject("autonomousPlan") ?: JSONObject()
        lines += "• Mode: ${plan.optString("mode", "autonomous_researcher")}"
        lines += "• Strategy: ${plan.optString("strategy", "explore_deepen_challenge")}"
        lines += "• Next if no useful source: ${plan.optString("nextStrategyIfNoUsefulSource", "rotate strategy")}" 
        val lanes = plan.optJSONArray("lanes") ?: JSONArray()
        if (lanes.length() == 0) {
            lines += "• No autonomous lanes recorded."
        } else {
            for (i in 0 until lanes.length()) {
                val lane = lanes.optJSONObject(i) ?: continue
                lines += "• ${lane.optString("laneType")}: ${lane.optString("label")}"
                lines += "  Reason: ${lane.optString("reason")}"
            }
        }
        lines += ""
        lines += "Knowledge delta"
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        lines += "• New sources saved: ${delta.optInt("newSourcesSaved", 0)}"
        lines += "• Repeated sources skipped: ${delta.optInt("repeatedSourcesSkipped", 0)}"
        lines += "• DNA/RNA signals: ${delta.optInt("dnaRnaSignals", 0)}"
        lines += "• Steered queries generated: ${delta.optInt("steeredQueriesGenerated", 0)}"
        lines += "• Manual report signals used: ${delta.optInt("manualReportSignalsUsed", 0)}"
        lines += "• New axis pairs:"
        appendArray(lines, delta.optJSONArray("newAxisPairs"))
        lines += "• Learning notes:"
        appendArray(lines, delta.optJSONArray("learningNotes"))
        lines += ""
        lines += "Dataset parser, evidence-lead/manual-seed, mature-domain focus, pass coverage, learning-domain linkage, lean runtime, useful learning report & release guard v1.10.34"
        val foragerSection = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        lines += "• Active: ${foragerSection.optBoolean("active", false)} | State: ${foragerSection.optString("state", "NOT_RUN")} | Mode: ${foragerSection.optString("evidenceMode", "unknown")}"
        val onePageEvidenceFull = foragerSection.optJSONObject("onePageExecutiveEvidenceReport") ?: JSONObject()
        if (onePageEvidenceFull.length() > 0) {
            lines += "• One-page evidence decision v1.10.31: cycle=${onePageEvidenceFull.optString("cycleValidity", "VALID_NO_EVIDENCE")} | evidence=${onePageEvidenceFull.optString("evidenceFound", "none")} | bestLead=${onePageEvidenceFull.optString("bestLead", "none")} | matureDomain=${onePageEvidenceFull.optBoolean("matureDomainUsed", false)}"
            lines += "• Evidence next: ${onePageEvidenceFull.optString("nextAction", "none")}"
        }
        val activityEvidenceFull = foragerSection.optJSONObject("evidenceActivitySeparationReport") ?: JSONObject()
        if (activityEvidenceFull.length() > 0) {
            lines += "• Activity ≠ Evidence: executedPaths=${activityEvidenceFull.optInt("executedPaths", 0)} | candidates=${activityEvidenceFull.optInt("candidatesFound", 0)} | accessions=${activityEvidenceFull.optInt("accessionsFound", 0)} | evidenceObjects=${activityEvidenceFull.optInt("evidenceObjects", 0)} | learningUpdates=${activityEvidenceFull.optInt("learningUpdates", 0)} | domainUpdated=${activityEvidenceFull.optBoolean("domainExpertiseUpdated", false)} | claim=${activityEvidenceFull.optString("scientificClaim", "none")}"
        }
        val breakthroughFull = foragerSection.optJSONObject("evidenceDiscoveryBreakthroughReport") ?: JSONObject()
        if (breakthroughFull.optBoolean("active", false)) {
            lines += "• Evidence discovery breakthrough: ${breakthroughFull.optString("state", "NOT_EVALUATED")} | best=${breakthroughFull.optString("bestLead", "none")} | nearMiss=${breakthroughFull.optInt("nearMissCount", 0)}"
            lines += "• Breakthrough next: ${breakthroughFull.optString("nextAction", "none")}"
            lines += "• Post-PubMed strategies:"
            appendArray(lines, breakthroughFull.optJSONArray("postPubMedSearchStrategies"))
        }
        val manualSeedFull = foragerSection.optJSONObject("manualEvidenceSeedReport") ?: JSONObject()
        if (manualSeedFull.optBoolean("active", false)) {
            lines += "• Manual seed mode: ${manualSeedFull.optString("mode", "MANUAL_EVIDENCE_SEED_MODE")} | seeds=${manualSeedFull.optInt("seedsDetected", 0)} | claim=${manualSeedFull.optString("claimLimit", "lead_only_not_evidence")}"
            lines += "• Manual seed next: ${manualSeedFull.optString("nextAction", "none")}"
        }
        val relaxationFull = foragerSection.optJSONObject("datasetLeadRelaxationReport") ?: JSONObject()
        if (relaxationFull.optBoolean("active", false)) {
            lines += "• Dataset lead relaxation: ${relaxationFull.optString("state", "NOT_EVALUATED")} | relaxed=${relaxationFull.optInt("relaxedLeadCount", 0)} | leads=${jsonArrayToList(relaxationFull.optJSONArray("leadAccessions")).joinToString(", ").ifBlank { "none" }}"
        }
        val leadLinkageFull = foragerSection.optJSONObject("evidenceLeadPathLinkageReport") ?: JSONObject()
        if (leadLinkageFull.optBoolean("active", false)) {
            lines += "• Evidence lead path linkage: ${leadLinkageFull.optString("state", "NOT_EVALUATED")} | manual=${leadLinkageFull.optBoolean("manualSeedLinkedToForager", false)} | weak=${leadLinkageFull.optBoolean("weakLeadLinkedToRelaxation", false)} | decision=${leadLinkageFull.optBoolean("breakthroughLinkedToDecision", false)} | consistency=${leadLinkageFull.optBoolean("consistencyGuardApplied", false)}"
            val leadWarnings = jsonArrayToList(leadLinkageFull.optJSONArray("warnings"))
            if (leadWarnings.isNotEmpty()) lines += "• Evidence lead linkage warnings: ${leadWarnings.joinToString("; ")}"
        }
        val leadObjectsFull = foragerSection.optJSONArray("leadObjects")
        if (leadObjectsFull != null && leadObjectsFull.length() > 0) lines += "• LeadObject ledger: leads=${leadObjectsFull.length()} | claim=LEAD_ONLY_NOT_EVIDENCE"
        val focusFull = foragerSection.optJSONObject("matureDomainFocusReport") ?: JSONObject()
        if (focusFull.optBoolean("active", false)) lines += "• Mature domain focus v1.10.32: ${focusFull.optString("state", "NOT_EVALUATED")} | domain=${focusFull.optString("selectedDomain", "none")} | cyclesRemaining=${focusFull.optInt("cyclesRemaining", 0)}"
        val killFull = foragerSection.optJSONObject("domainSpecificKillCriteriaReport") ?: JSONObject()
        if (killFull.optBoolean("active", false)) lines += "• Domain kill criteria: triggered=${killFull.optBoolean("killTriggered", false)} | domain=${killFull.optString("domainId", "none")}"
        val gapsFull = foragerSection.optJSONObject("knowledgeGapQueueReport") ?: JSONObject()
        if (gapsFull.optBoolean("active", false)) lines += "• Knowledge gap queue: ${gapsFull.optString("queueState", "NOT_EVALUATED")} | open=${gapsFull.optJSONArray("items")?.length() ?: 0} | next=${gapsFull.optString("nextAction", "none")}" 
        val strongFpFull = foragerSection.optJSONObject("strongRouteFingerprintReport") ?: JSONObject()
        if (strongFpFull.optBoolean("active", false)) lines += "• Strong route fingerprint: replay=${strongFpFull.optBoolean("replayRisk", false)} | intent=${strongFpFull.optString("intent", "none")} | domain=${strongFpFull.optString("domain", "none")}" 
        val leanFull = foragerSection.optJSONObject("leanAgentRuntimeReport") ?: JSONObject()
        if (leanFull.optBoolean("active", false)) lines += "• Lean runtime card: ${leanFull.optString("compactDecisionCard", "none")}" 
        val handoffFull = foragerSection.optJSONObject("leadClosureHandoffReport") ?: JSONObject()
        if (handoffFull.optBoolean("active", false)) {
            lines += "• Lead closure handoff v1.10.35: ${handoffFull.optString("state", "NOT_EVALUATED")} | carried=${handoffFull.optInt("carriedLeadCount", 0)} | missing=${jsonArrayToList(handoffFull.optJSONArray("missingFields")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Handoff forced next: ${handoffFull.optString("forcedNextAction", "none")}"
            lines += "• Pinned learning rules:"
            appendArray(lines, handoffFull.optJSONArray("pinnedLearningRules"))
        }
        val metadataClosureFull = foragerSection.optJSONObject("metadataClosureReport") ?: JSONObject()
        if (metadataClosureFull.optBoolean("active", false)) {
            lines += "• Metadata closure v1.10.35: ${metadataClosureFull.optString("state", "NOT_EVALUATED")} | closed=${jsonArrayToList(metadataClosureFull.optJSONArray("closedFields")).joinToString(", ").ifBlank { "none" }} | missing=${jsonArrayToList(metadataClosureFull.optJSONArray("missingFields")).joinToString(", ").ifBlank { "none" }}"
        }
        val routePriorFull = foragerSection.optJSONObject("unknownRouteClassificationReport") ?: JSONObject()
        if (routePriorFull.optBoolean("active", false)) {
            lines += "• Unknown-route classifier v1.10.35: ${routePriorFull.optString("state", "NOT_EVALUATED")} | selected=${routePriorFull.optString("selectedRoute", "none")} | confidence=${routePriorFull.optInt("confidence", 0)}/100"
            lines += "• Route rule: ${routePriorFull.optString("pinnedRule", "route prior only")}"
            appendObjectArray(lines, routePriorFull.optJSONArray("routePriors"), listOf("routeId", "confidence", "matchedTerms", "claimLimit"))
        }
        val ebvFull = foragerSection.optJSONObject("ebvLeadVerificationReport") ?: JSONObject()
        if (ebvFull.optBoolean("active", false)) {
            lines += "• EBV criterion lane v1.10.37: ${ebvFull.optString("state", "NOT_EVALUATED")} | target=${ebvFull.optString("targetLeadId", "none")} | claim=${ebvFull.optString("claimLimit", "ebv_criterion_lane_not_biological_proof")}"
            lines += "• EBV question: ${ebvFull.optString("criterionQuestion", "none")}"
            lines += "• EBV closed/missing: ${jsonArrayToList(ebvFull.optJSONArray("closedEvidence")).joinToString(", ").ifBlank { "none" }} / ${jsonArrayToList(ebvFull.optJSONArray("missingEvidence")).joinToString(", ").ifBlank { "none" }}"
            lines += "• EBV next: ${ebvFull.optString("allowedNextAction", "none")}"
            lines += "• EBV invalidators: ${jsonArrayToList(ebvFull.optJSONArray("invalidators")).joinToString("; ").ifBlank { "none" }}"
        }
        val evidencePriorFull = foragerSection.optJSONObject("evidencePriorSelectionReport") ?: JSONObject()
        if (evidencePriorFull.optBoolean("active", false)) {
            lines += "• Evidence Prior Matrix v1.10.38: ${evidencePriorFull.optString("state", "NOT_EVALUATED")} | selected=${evidencePriorFull.optString("selectedPriorId", "none")} | route=${evidencePriorFull.optString("selectedRoute", "none")} | claim=${evidencePriorFull.optString("claimLimit", "evidence_prior_matrix_routing_only_not_biological_proof")}"
            val integratedFull = foragerSection.optJSONObject("integratedPathLinkageReport") ?: JSONObject()
            lines += "• Integrated Path Linkage v1.10.39: ${integratedFull.optString("state", "NOT_EVALUATED")} | openWarnings=${integratedFull.optJSONArray("openWarnings")?.length() ?: 0} | claim=${integratedFull.optString("claimLimit", "integrated_path_linkage_not_biological_proof")}"
            lines += "• Final path decision: ${integratedFull.optString("finalDecision", "No final path decision available.")}"
            lines += "• Release Stability Gate v1.10.40: ${FinalReleaseStabilityReport.fromRuntime().state} | claim=${FinalReleaseStabilityGuard.CLAIM_LIMIT}"
            val biomedicalCompact = foragerSection.optJSONObject("biomedicalOntologyReport") ?: JSONObject()
            if (biomedicalCompact.optBoolean("active", false)) {
                lines += "• Biomedical Ontology v1.10.41: ${biomedicalCompact.optString("state", "NOT_EVALUATED")} | domains=${jsonArrayToList(biomedicalCompact.optJSONArray("selectedDomains")).take(3).joinToString(", ").ifBlank { "none" }}"
                lines += "• Diagnostic phenotype mode: ${biomedicalCompact.optString("diagnosticPhenotypeMode", "OFF")}"
            }
            val conceptCompact = foragerSection.optJSONObject("biomedicalConceptBridgeReport") ?: JSONObject()
            if (conceptCompact.optBoolean("active", false)) {
                lines += "• Biomedical Concept Bridge v1.10.42: ${conceptCompact.optString("state", "NOT_EVALUATED")} | bridges=${jsonArrayToList(conceptCompact.optJSONArray("selectedBridgeIds")).take(3).joinToString(", ").ifBlank { "none" }}"
                lines += "• Bridge evidence keys: ${jsonArrayToList(conceptCompact.optJSONArray("evidenceKeysToClose")).take(6).joinToString(", ").ifBlank { "none" }}"
            }
            val modernTechCompact = foragerSection.optJSONObject("modernMedicalTechnologyReport") ?: JSONObject()
            if (modernTechCompact.optBoolean("active", false)) {
                lines += "• Modern Medical Technology v1.10.43: ${modernTechCompact.optString("state", "NOT_EVALUATED")} | modules=${jsonArrayToList(modernTechCompact.optJSONArray("selectedModuleIds")).take(4).joinToString(", ").ifBlank { "none" }}"
                lines += "• Tech partitions: ${jsonArrayToList(modernTechCompact.optJSONArray("partitionIndexKeys")).take(6).joinToString(", ").ifBlank { "none" }}"
            }
            val topicFitCompact = foragerSection.optJSONObject("topicFitMetadataParseReport") ?: JSONObject()
            if (topicFitCompact.optBoolean("active", false)) {
                lines += "• Exposome Topic Route v1.10.50: ${topicFitCompact.optString("state", "NOT_EVALUATED")} | topic=${topicFitCompact.optString("topicLabel", "unknown")} | route=${topicFitCompact.optString("preferredLane", "none")}"
                lines += "• Learning / Discovery / Evidence: ${topicFitCompact.optString("learningStatus", "unknown")} / ${topicFitCompact.optString("discoveryStatus", "unknown")} / ${topicFitCompact.optString("evidenceStatus", "unknown")}"
                lines += "• Route correction: ${topicFitCompact.optString("topicRouteCorrectionStatus", "NOT_EVALUATED")}"
                lines += "• EvidenceObjectCandidate(s): ${topicFitCompact.optInt("evidenceObjectCandidateCount", 0)} | Comparator hunt: ${topicFitCompact.optString("comparatorHuntMode", "NOT_EVALUATED")}"
                lines += "• Suppressed stale prior: ${topicFitCompact.optString("suppressedMatureDomain", "none")}"
                lines += "• Missing gates: ${jsonArrayToList(topicFitCompact.optJSONArray("missingGates")).take(6).joinToString(", ").ifBlank { "none" }}"
                lines += "• Next topic-fit action: ${topicFitCompact.optString("nextAction", "none")}"
            }
            val systemsCompact = foragerSection.optJSONObject("longevityBiologicalSystemsReport") ?: JSONObject()
            if (systemsCompact.optBoolean("active", false)) {
                lines += "• Biological Systems Graph v1.10.46: ${systemsCompact.optString("state", "NOT_EVALUATED")} | lane=${systemsCompact.optString("selectedLane", "OFF")}"
                lines += "• Required biomarkers: ${jsonArrayToList(systemsCompact.optJSONArray("biomarkersRequired")).take(8).joinToString(", ").ifBlank { "none" }}"
                lines += "• Missing data / falsifier: ${jsonArrayToList(systemsCompact.optJSONArray("missingData")).take(5).joinToString(", ").ifBlank { "none" }} / ${jsonArrayToList(systemsCompact.optJSONArray("invalidators")).take(2).joinToString("; ").ifBlank { "none" }}"
                lines += "• Next search: ${jsonArrayToList(systemsCompact.optJSONArray("datasetQueryTemplates")).take(1).joinToString().ifBlank { systemsCompact.optString("nextResearchQuestion", "none") }}"
            }
            lines += "• Release decision: ${FinalReleaseStabilityGuard.summary()}"
            lines += "• Prior reason: ${evidencePriorFull.optString("reason", "none")}"
            lines += "• Prior query keys: ${jsonArrayToList(evidencePriorFull.optJSONArray("queryTerms")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Prior gates: ${jsonArrayToList(evidencePriorFull.optJSONArray("requiredGates")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Prior guards: ${jsonArrayToList(evidencePriorFull.optJSONArray("noiseGuards")).joinToString("; ").ifBlank { "none" }}"
            lines += "• Prior forbidden claims: ${jsonArrayToList(evidencePriorFull.optJSONArray("forbiddenClaims")).joinToString("; ").ifBlank { "none" }}"
            lines += "• Prior next: ${evidencePriorFull.optString("nextAction", "none")}"
        }
        val biomedicalFull = foragerSection.optJSONObject("biomedicalOntologyReport") ?: JSONObject()
        if (biomedicalFull.optBoolean("active", false)) {
            lines += "• Biomedical Research Ontology v1.10.41: ${biomedicalFull.optString("state", "NOT_EVALUATED")} | diagnostic=${biomedicalFull.optString("diagnosticPhenotypeMode", "OFF")} | claim=${biomedicalFull.optString("claimLimit", "biomedical_research_ontology_routing_only_not_patient_diagnosis")}"
            lines += "• Ontology domains: ${jsonArrayToList(biomedicalFull.optJSONArray("selectedDomains")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Ontology matched terms: ${jsonArrayToList(biomedicalFull.optJSONArray("matchedTerms")).take(16).joinToString(", ").ifBlank { "none" }}"
            lines += "• Ontology query keys: ${jsonArrayToList(biomedicalFull.optJSONArray("queryExpansionKeys")).take(16).joinToString(", ").ifBlank { "none" }}"
            lines += "• Ontology research use: ${jsonArrayToList(biomedicalFull.optJSONArray("researchUse")).joinToString("; ").ifBlank { "none" }}"
            lines += "• Ontology guardrails: ${jsonArrayToList(biomedicalFull.optJSONArray("guardrails")).take(4).joinToString("; ").ifBlank { "none" }}"
            lines += "• Ontology next: ${biomedicalFull.optString("nextAction", "none")}"
        }
        val conceptFull = foragerSection.optJSONObject("biomedicalConceptBridgeReport") ?: JSONObject()
        if (conceptFull.optBoolean("active", false)) {
            lines += "• Biomedical Concept Bridge v1.10.42: ${conceptFull.optString("state", "NOT_EVALUATED")} | claim=${conceptFull.optString("claimLimit", "biomedical_concept_bridge_routing_only_not_clinical_conclusion")}"
            lines += "• Bridge IDs: ${jsonArrayToList(conceptFull.optJSONArray("selectedBridgeIds")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Bridge concepts: ${jsonArrayToList(conceptFull.optJSONArray("matchedConcepts")).take(16).joinToString(", ").ifBlank { "none" }}"
            lines += "• Bridge lookup terms: ${jsonArrayToList(conceptFull.optJSONArray("priorityLookupTerms")).take(18).joinToString(", ").ifBlank { "none" }}"
            lines += "• Bridge evidence keys: ${jsonArrayToList(conceptFull.optJSONArray("evidenceKeysToClose")).take(18).joinToString(", ").ifBlank { "none" }}"
            lines += "• Bridge invalidators: ${jsonArrayToList(conceptFull.optJSONArray("invalidators")).take(6).joinToString("; ").ifBlank { "none" }}"
            lines += "• Bridge next: ${conceptFull.optString("nextAction", "none")}"
        }
        val modernTechFull = foragerSection.optJSONObject("modernMedicalTechnologyReport") ?: JSONObject()
        if (modernTechFull.optBoolean("active", false)) {
            lines += "• Modern Medical Technology Intelligence v1.10.43: ${modernTechFull.optString("state", "NOT_EVALUATED")} | claim=${modernTechFull.optString("claimLimit", "modern_medical_technology_routing_only_not_lab_or_clinical_proof")}"
            lines += "• Tech modules: ${jsonArrayToList(modernTechFull.optJSONArray("selectedModuleIds")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Matched technologies: ${jsonArrayToList(modernTechFull.optJSONArray("matchedTechnologies")).take(16).joinToString(", ").ifBlank { "none" }}"
            lines += "• Tech lookup terms: ${jsonArrayToList(modernTechFull.optJSONArray("priorityLookupTerms")).take(20).joinToString(", ").ifBlank { "none" }}"
            lines += "• Tech evidence keys: ${jsonArrayToList(modernTechFull.optJSONArray("evidenceKeysToClose")).take(18).joinToString(", ").ifBlank { "none" }}"
            lines += "• Tech partition index: ${jsonArrayToList(modernTechFull.optJSONArray("partitionIndexKeys")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Tech retrieval policy: ${modernTechFull.optString("retrievalPolicy", "none")}"
            lines += "• Tech invalidators: ${jsonArrayToList(modernTechFull.optJSONArray("invalidators")).take(6).joinToString("; ").ifBlank { "none" }}"
            lines += "• Tech forbidden claims: ${jsonArrayToList(modernTechFull.optJSONArray("forbiddenClaims")).take(6).joinToString("; ").ifBlank { "none" }}"
            lines += "• Tech next: ${modernTechFull.optString("nextAction", "none")}"
        }
        val topicFitFull = foragerSection.optJSONObject("topicFitMetadataParseReport") ?: JSONObject()
        if (topicFitFull.optBoolean("active", false)) {
            lines += "• Exposome Topic Route / EvidenceObjectCandidate v1.10.50: ${topicFitFull.optString("state", "NOT_EVALUATED")} | claim=${topicFitFull.optString("claimLimit", "topic_fit_metadata_parse_ui_clarity_not_biological_proof")}"
            lines += "• Topic / route / fit: ${topicFitFull.optString("topicLabel", "unknown")} / ${topicFitFull.optString("preferredLane", "none")} / ${topicFitFull.optInt("topicFitScore", 0)}/100"
            lines += "• Forced metadata / parsed / evidence objects / evidence candidates: ${topicFitFull.optInt("forcedMinimumMetadataCount", 0)} / ${topicFitFull.optInt("parsedMetadataCount", 0)} / ${topicFitFull.optInt("evidenceObjectCount", 0)} / ${topicFitFull.optInt("evidenceObjectCandidateCount", 0)}"
            lines += "• Route correction: ${topicFitFull.optString("topicRouteCorrectionStatus", "NOT_EVALUATED")}"
            lines += "• Comparator hunt: ${topicFitFull.optString("comparatorHuntMode", "NOT_EVALUATED")}"
            lines += "• Learning: ${topicFitFull.optString("learningStatus", "unknown")}"
            lines += "• Discovery: ${topicFitFull.optString("discoveryStatus", "unknown")}"
            lines += "• Evidence: ${topicFitFull.optString("evidenceStatus", "unknown")}"
            lines += "• Suppressed stale prior: ${topicFitFull.optString("suppressedMatureDomain", "none")}"
            lines += "• What would falsify: ${jsonArrayToList(topicFitFull.optJSONArray("invalidators")).take(5).joinToString("; ").ifBlank { "none" }}"
            lines += "• Topic-fit next: ${topicFitFull.optString("nextAction", "none")}"
        }
        val systemsFull = foragerSection.optJSONObject("longevityBiologicalSystemsReport") ?: JSONObject()
        if (systemsFull.optBoolean("active", false)) {
            lines += "• Longevity & Biological Systems Graph v1.10.46: ${systemsFull.optString("state", "NOT_EVALUATED")} | lane=${systemsFull.optString("selectedLane", "OFF")} | claim=${systemsFull.optString("claimLimit", "longevity_biological_systems_research_only_not_health_advice")}"
            lines += "• Selected modules: ${jsonArrayToList(systemsFull.optJSONArray("selectedModules")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Biological pathway: ${jsonArrayToList(systemsFull.optJSONArray("exposurePathways")).take(1).joinToString("; ").ifBlank { "see exposurePathways in JSON" }}"
            lines += "• Required biomarkers: ${jsonArrayToList(systemsFull.optJSONArray("biomarkersRequired")).take(20).joinToString(", ").ifBlank { "none" }}"
            lines += "• Missing data: ${jsonArrayToList(systemsFull.optJSONArray("missingData")).joinToString(", ").ifBlank { "none" }}"
            lines += "• What would falsify: ${jsonArrayToList(systemsFull.optJSONArray("invalidators")).take(8).joinToString("; ").ifBlank { "none" }}"
            lines += "• Dataset query templates: ${jsonArrayToList(systemsFull.optJSONArray("datasetQueryTemplates")).take(8).joinToString("; ").ifBlank { "none" }}"
            lines += "• Contradiction search: ${jsonArrayToList(systemsFull.optJSONArray("contradictionSearchTerms")).take(8).joinToString("; ").ifBlank { "none" }}"
            lines += "• Systems next: ${systemsFull.optString("nextAction", "none")}"
        }
        val viralFull = foragerSection.optJSONObject("viralCountermeasureReport") ?: JSONObject()
        if (viralFull.optBoolean("active", false)) {
            lines += "• Viral Countermeasure Intelligence v1.10.44: ${viralFull.optString("state", "NOT_EVALUATED")} | virus=${viralFull.optString("selectedVirusKey", "none")} | claim=${viralFull.optString("claimLimit", "viral_countermeasure_routing_only_not_wetlab_or_clinical_proof")}"
            lines += "• Viral lane: ${viralFull.optString("selectedLane", "none")}"
            lines += "• Viral evidence keys: ${jsonArrayToList(viralFull.optJSONArray("evidenceKeysToClose")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Viral next: ${viralFull.optString("nextAction", "none")}"
        }
        val knowledgeGraphFull = foragerSection.optJSONObject("biomedicalKnowledgeGraphLinkageReport") ?: JSONObject()
        if (knowledgeGraphFull.optBoolean("active", false)) {
            lines += "• Biomedical Dictionary/Database Linkage v1.10.44: ${knowledgeGraphFull.optString("state", "NOT_EVALUATED")} | claim=${knowledgeGraphFull.optString("claimLimit", "biomedical_dictionary_database_linkage_not_biological_proof")}"
            lines += "• Dictionary partitions: ${jsonArrayToList(knowledgeGraphFull.optJSONArray("selectedPartitions")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Bridge edges: ${jsonArrayToList(knowledgeGraphFull.optJSONArray("bridgeEdges")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Dictionary update policy: ${knowledgeGraphFull.optString("updatePolicy", "none")}"
        }
        lines += "• Sources attempted: ${jsonArrayToList(foragerSection.optJSONArray("sourceFamiliesAttempted")).joinToString(", ").ifBlank { "none" }}"
        val scoreSep = foragerSection.optJSONObject("scoreSeparation") ?: JSONObject()
        lines += "• Score separation: usability ${scoreSep.optInt("datasetUsabilityScore", 0)}/100 | route-fit ${scoreSep.optInt("routeFitScore", 0)}/100 | hypothesis ${scoreSep.optInt("hypothesisConfidenceScore", 0)}/100 | ${scoreSep.optString("scoreState", "NOT_EVALUATED")}"
        lines += "• Hypothesis upgrade allowed: ${scoreSep.optBoolean("hypothesisUpgradeAllowed", false)}"
        val accession = foragerSection.optJSONObject("accessionAcquisitionReport") ?: JSONObject()
        if (accession.optBoolean("active", false)) {
            lines += "• Accession acquisition: ${accession.optString("state", "NOT_EVALUATED")} | explicit=${jsonArrayToList(accession.optJSONArray("explicitAccessions")).joinToString(", ").ifBlank { "none" }} | weak=${jsonArrayToList(accession.optJSONArray("weakAccessions")).joinToString(", ").ifBlank { "none" }}"
            lines += "• Accession next: ${accession.optString("nextAction", "none")}"
            lines += "• Accession claim limit: ${accession.optString("claimLimit", "accession_acquisition_not_biological_proof")}"
        }
        val domainExpertise = foragerSection.optJSONObject("domainExpertiseReport") ?: JSONObject()
        if (domainExpertise.optBoolean("active", false)) {
            lines += "• Domain expertise continuity: ${domainExpertise.optString("summary", "none")}"
            lines += "• Expertise priors/protected/carried/mature: ${domainExpertise.optInt("stablePriorCount", 0)} / ${domainExpertise.optInt("protectedBeliefCount", 0)} / ${domainExpertise.optInt("carriedForwardDomainCount", 0)} / ${domainExpertise.optInt("matureDomainCount", 0)} | claim=${domainExpertise.optString("claimLimit", "domain_expertise_memory_not_biological_proof")}"
            lines += "• Expertise continuity: ${domainExpertise.optString("continuityState", "unknown")} — ${domainExpertise.optString("continuitySummary", "none")}"
            appendObjectArray(lines, domainExpertise.optJSONArray("cards"), listOf("domainId", "expertiseState", "expertiseScore", "priorExposureCount", "workingVocabulary", "falsificationGates", "continuityAction", "nextLearningAction"))
        }
        val learningDomain = foragerSection.optJSONObject("learningDomainPathLinkageReport") ?: JSONObject()
        if (learningDomain.optBoolean("active", false)) {
            lines += "• Learning/domain path linkage: ${learningDomain.optString("state", "NOT_EVALUATED")} | ${learningDomain.optString("handoffSummary", "none")}"
            lines += "• Link counts: learning=${learningDomain.optInt("learningRuleMatchCount", 0)} | domains=${learningDomain.optInt("domainTrackCount", 0)} | mature=${learningDomain.optInt("matureDomainCount", 0)} | protected=${learningDomain.optInt("protectedExpertiseCount", 0)} | noCandidate=${learningDomain.optInt("noCandidateLearningCount", 0)}"
            lines += "• Link flags: feedback=${learningDomain.optBoolean("queryFeedbackLinked", false)} | rules=${learningDomain.optBoolean("learningRulesLinkedToQueries", false)} | domainVocab=${learningDomain.optBoolean("domainVocabularyLinkedToQueries", false)} | matureProbe=${learningDomain.optBoolean("matureProbeLinkedToDomainExpertise", false)} | coverage=${learningDomain.optString("pathCoverageState", "NOT_EVALUATED")}"
            appendArray(lines, learningDomain.optJSONArray("warnings"))
            lines += "• Learning/domain claim limit: ${learningDomain.optString("claimLimit", "learning_domain_path_linkage_not_biological_proof")}"
        }
        val triage = foragerSection.optJSONObject("triageReport") ?: JSONObject()
        lines += "• ML-safe triage: active=${triage.optBoolean("active", false)} | ${triage.optString("summary", "none")}"
        lines += "• Claim limit: ${triage.optString("claimLimit", "triage_only_not_biological_proof")}"
        appendObjectArray(lines, triage.optJSONArray("results"), listOf("accession", "action", "usefulnessScore", "routeFitPrediction", "likelyFailureModes", "mlConfidence"))
        val candidateAction = foragerSection.optJSONObject("candidateActionReport") ?: JSONObject()
        lines += "• Candidate action resolver: active=${candidateAction.optBoolean("active", false)} | ${candidateAction.optString("summary", "none")}"
        appendObjectArray(lines, candidateAction.optJSONArray("decisions"), listOf("accession", "action", "routeFitScore", "triageAction", "forcesMinimumMetadata", "claimLimit"))
        val autoContinuation = foragerSection.optJSONObject("autoContinuationReport") ?: JSONObject()
        lines += "• Auto-light continuation: triggered=${autoContinuation.optBoolean("triggered", false)} | ${autoContinuation.optString("recommendedAction", "none")}"
        lines += "• Queued micro-query: ${autoContinuation.optString("queuedQuery", "none")}"
        val consistency = foragerSection.optJSONObject("reportConsistencyGuard") ?: JSONObject()
        lines += "• Report consistency: ${consistency.optString("status", "NOT_EVALUATED")} | ${consistency.optString("requiredReportLanguage", "none")}"
        appendArray(lines, consistency.optJSONArray("warnings"))
        val noCandidateRecords = foragerSection.optJSONArray("noCandidateLearningRecords") ?: JSONArray()
        val exploratoryLeadCount = (0 until (foragerSection.optJSONArray("candidates") ?: JSONArray()).length()).count { idx ->
            (foragerSection.optJSONArray("candidates") ?: JSONArray()).optJSONObject(idx)?.optString("status") == "EXPLORATORY_LEAD_NEEDS_ACCESSION"
        }
        if (exploratoryLeadCount > 0) {
            lines += "• Exploratory leads captured: $exploratoryLeadCount — capture strictness lowered only for weak leads; claims remain locked."
        }
        if (noCandidateRecords.length() == 0) {
            lines += "• No-candidate learning: none"
        } else {
            lines += "• No-candidate learning:"
            for (idx in 0 until noCandidateRecords.length().coerceAtMost(12)) {
                val rec = noCandidateRecords.optJSONObject(idx) ?: continue
                val next = rec.optString("nextPreferredSource")
                if (SourcePriorityArbitrationPolicy.isLeadObjectFollowUp(next)) {
                    lines += "• ${rec.optString("sourceFamily")}: follow-up=LEAD_OBJECT_SECONDARY_LOOKUP | missing=${rec.optString("missing")} | status=${rec.optString("status")} | ${rec.optString("reason")}"
                } else {
                    lines += "• ${rec.optString("sourceFamily")}: nextSource=$next | missing=${rec.optString("missing")} | status=${rec.optString("status")} | ${rec.optString("reason")}"
                }
            }
        }
        val qFeedback = foragerSection.optJSONObject("queryFeedbackPlan") ?: JSONObject()
        lines += "• Query feedback: active=${qFeedback.optBoolean("active", false)} | ${qFeedback.optString("summary", "none")}"
        appendObjectArray(lines, qFeedback.optJSONArray("improvements"), listOf("addedTerms", "reasoning", "expectedImprovement"))
        val fLedger = foragerSection.optJSONObject("failurePatternReport") ?: JSONObject()
        lines += "• Failure-pattern ledger: ${fLedger.optString("summary", "none")}"
        appendObjectArray(lines, fLedger.optJSONArray("newlyRecorded"), listOf("rootCause", "route", "occurrenceCount", "suggestedAction", "claimLimit"))
        val freshness = foragerSection.optJSONObject("freshnessReport") ?: JSONObject()
        lines += "• Freshness weighting: active=${freshness.optBoolean("active", false)} | average=${freshness.optInt("averageFreshness", 0)}/100 | ${freshness.optString("summary", "none")}"
        appendObjectArray(lines, freshness.optJSONArray("topScores"), listOf("sourceId", "publishYear", "boostInRanking", "reason", "claimLimit"))
        lines += "• Route-fit gate:"
        appendObjectArray(lines, foragerSection.optJSONArray("routeFitAssessments"), listOf("accession", "status", "routeFitScore", "datasetRoute", "targetRoute", "allowedUse"))
        lines += "• Blocked learning reason: ${foragerSection.optString("blockedLearningReason", "none")}"
        lines += "• Next action: ${foragerSection.optString("nextAction", "none")}"
        lines += "• Passes:"
        appendObjectArray(lines, foragerSection.optJSONArray("passes"), listOf("passId", "status"))
        val contrastive = foragerSection.optJSONObject("contrastiveReport") ?: JSONObject()
        val cumulative = foragerSection.optJSONObject("cumulativeEvidence") ?: JSONObject()
        lines += "• Parser metadata:"
        appendObjectArray(lines, foragerSection.optJSONArray("parsedMetadata"), listOf("accession", "usabilityVerdict", "metadataQualityScore", "organism", "assayType"))
        lines += "• Contrastive gate: ${contrastive.optString("gateStatus", "NOT_EVALUATED")} — ${contrastive.optString("summary", "none")}"
        lines += "• Next contrastive question: ${contrastive.optString("nextContrastiveQuestion", "none")}"
        lines += "• Cumulative evidence: ${cumulative.optInt("score", 0)}/100 ${cumulative.optString("state", "OFF")}"
        lines += ""
        lines += "Persistent failure memory"
        val memorySection = report.optJSONObject("persistentFailureMemory") ?: JSONObject()
        lines += "• ${memorySection.optString("summary", "No persistent failure memory.")}"
        appendObjectArray(lines, memorySection.optJSONArray("records"), listOf("sourceFamily", "rootCause", "cooldownCyclesRemaining", "timesFailed", "forcedNextSource"))
        lines += ""
        lines += "Learning OS — incident, gates, regression"
        val learningOs = report.optJSONObject("learningOsReport") ?: JSONObject()
        val incidentOs = learningOs.optJSONObject("incident") ?: JSONObject()
        val readinessOs = learningOs.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        val rootCausesOsText = jsonArrayToList(incidentOs.optJSONArray("rootCauses")).joinToString(", ").ifBlank { "none" }
        val observedSignalsText = jsonArrayToList(incidentOs.optJSONArray("observedSignals")).joinToString(", ").ifBlank { "none" }
        lines += "• Root causes: $rootCausesOsText"
        lines += "• Observed signals: $observedSignalsText"
        lines += "• Hypothesis update gate: ${learningOs.optString("hypothesisUpdateGateStatus", "NO_EVIDENCE_OBJECT_NO_UPGRADE")}"
        lines += "• Discovery readiness: ${readinessOs.optInt("score", 0)}/100 ${readinessOs.optString("state", "OFF")}"
        lines += "• Next learning action: ${learningOs.optString("nextLearningAction", "none")}"
        lines += "• Preventive gates:"
        appendObjectArray(lines, learningOs.optJSONArray("preventiveGates"), listOf("gateId", "rootCause", "forcedNextIntent", "action"))
        lines += "• Lane cooldowns:"
        appendObjectArray(lines, learningOs.optJSONArray("laneCooldowns"), listOf("laneName", "failureCount", "cooldownCycles", "lastFailureReason"))
        lines += "• Regression vectors:"
        appendObjectArray(lines, learningOs.optJSONArray("regressionVectors"), listOf("caseId", "expectedRootCause", "expectedGate", "expectedNextAction"))
        lines += ""
        lines += "Research lock summary"
        val summary = report.optJSONObject("researchStateSummary") ?: JSONObject()
        lines += "• Discovery State: ${summary.optString("discoveryState", "Off")}"
        lines += "• Bias Risk State: ${summary.optString("biasRiskState", "Normal")}"
        lines += "• Next Evidence: ${summary.optString("nextEvidence", "none")}"
        lines += "• Discovery Action: ${summary.optString("discoveryAction", "none")}"
        lines += "• Bias Alarm: ${summary.optString("biasAlarm", "Normal")}" 
        lines += ""
        lines += "Hypothesis objects"
        val objects = report.optJSONArray("hypothesisObjects") ?: JSONArray()
        if (objects.length() == 0) {
            lines += "• No locked hypothesis objects yet."
        } else {
            for (i in 0 until objects.length()) {
                val h = objects.optJSONObject(i) ?: continue
                lines += "${i + 1}. ${h.optString("status")} / ${h.optString("discoveryState")} — ${h.optString("label")}" 
                lines += "   Trust ${h.optInt("dataTrustScore")}/100 | Evidence ${ScoreFormat.oneDecimal(h.optDouble("evidenceScore10"))}/10 | Causality ${h.optInt("causalityScore")}/100 | Bias ${h.optString("biasRiskState")}" 
                lines += "   Gate ${h.optString("minimumDataPackStatus")} | Flip ${h.optString("signalFlip")}" 
                lines += "   Next measurement: ${h.optString("nextBestMeasurement")}" 
                val missingDataText = jsonArrayToList(h.optJSONArray("missingData")).joinToString(", ").ifBlank { "none" }
                lines += "   Missing data: $missingDataText"
            }
        }
        lines += ""
        lines += "Learning delta cards"
        appendObjectArray(lines, report.optJSONArray("learningDeltaCards"), listOf("deltaType", "hypothesisId", "decisionImpact", "nextAction"))
        lines += ""
        lines += "Top mistake risks"
        appendObjectArray(lines, report.optJSONArray("mistakeRiskCards"), listOf("risk", "preventionGate"))
        lines += ""
        lines += "Hypothesis ranking"
        val cards = report.optJSONArray("hypothesisRankCards") ?: JSONArray()
        if (cards.length() == 0) {
            lines += "• No ranked hypotheses yet."
        } else {
            for (i in 0 until cards.length()) {
                val c = cards.optJSONObject(i) ?: continue
                lines += "${i + 1}. ${c.optString("status")} — ${c.optString("label")}"
                lines += "   Overall ${c.optInt("overallScore")}/100 | Evidence ${c.optInt("evidenceQualityScore")}/100 | Causality ${c.optInt("causalityScore")}/100 | Repeatability ${c.optInt("personalRepeatability")}"
                lines += "   Negative control: ${c.optString("negativeControlStatus")}"
                lines += "   Next measurement: ${c.optString("nextBestMeasurement")}"
                appendArray(lines, c.optJSONArray("whyRanked"))
            }
        }
        lines += ""
        lines += "Emergent links"
        appendArray(lines, report.optJSONArray("emergentLinks"))
        lines += ""
        lines += "Imported report signals"
        val imported = report.optJSONArray("importedReportSignals") ?: JSONArray()
        if (imported.length() == 0) {
            lines += "• None used."
        } else {
            for (i in 0 until imported.length()) {
                val r = imported.optJSONObject(i) ?: continue
                lines += "• ${r.optString("title")} → ${jsonArrayToList(r.optJSONArray("matchedAxes")).joinToString(", ")}".take(500)
            }
        }
        lines += ""
        lines += "Dataset acquisition + parser candidates v1.4.5"
        val ds137 = report.optJSONArray("datasetCandidatesV137") ?: JSONArray()
        if (ds137.length() == 0) {
            lines += "• No dataset accession candidate yet."
        } else {
            for (i in 0 until ds137.length()) {
                val d = ds137.optJSONObject(i) ?: continue
                lines += "${i + 1}. ${d.optString("accession")} • ${d.optString("source")} • usability ${d.optInt("usabilityScore")}/100 • ${d.optString("status")}"
                lines += "   ${d.optString("organismHint")} | ${d.optString("conditionLabelsHint")} | ${d.optString("outcomeLabelsHint")}"
            }
        }
        lines += ""
        lines += "Evidence objects"
        val evObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        if (evObjects.length() == 0) {
            lines += "• No evidence object yet."
        } else {
            for (i in 0 until evObjects.length()) {
                val e = evObjects.optJSONObject(i) ?: continue
                lines += "${i + 1}. ${e.optString("decisionImpact")} • quality ${e.optInt("qualityScore")}/100 • ${e.optString("title")}"
                lines += "   Accessions: ${jsonArrayToList(e.optJSONArray("accessionIds")).joinToString(", ").ifBlank { "none" }} | Contradicts: ${e.optBoolean("contradictsHypothesis")} | Control: ${e.optBoolean("hasNegativeControl")}"
            }
        }
        lines += ""
        lines += "Top findings"
        val findings = report.optJSONArray("findings") ?: JSONArray()
        if (findings.length() == 0) {
            lines += "• No new findings saved in this cycle."
        } else {
            for (i in 0 until findings.length()) {
                val f = findings.optJSONObject(i) ?: continue
                lines += "${i + 1}. " + f.optString("title")
                lines += "   " + f.optString("source") + " " + f.optString("sourceId") + " • " + f.optString("published") + " • novelty " + f.optInt("noveltyScore") + "/100"
                lines += "   Axes: " + jsonArrayToList(f.optJSONArray("matchedAxes")).joinToString(", ")
                val ev = f.optJSONObject("evidence") ?: JSONObject()
                val ca = f.optJSONObject("causality") ?: JSONObject()
                val neg = f.optJSONObject("negativeControl") ?: JSONObject()
                val pp = f.optJSONObject("personalPattern") ?: JSONObject()
                lines += "   Evidence: ${ev.optInt("evidenceQualityScore", 0)}/100 | ${ev.optString("speciesClass", "unknown")} | ${ev.optString("studyDesign", "unknown")}"
                lines += "   Causality: ${ca.optInt("causalityScore", 0)}/100 | Negative control: ${neg.optString("status", "unknown")}"
                lines += "   Personal pattern: ${pp.optInt("repeatedObservationCount", 0)} repeats | ${pp.optString("temporalSupport", "unknown")}"
                lines += "   " + f.optString("bridgeSignal")
                lines += "   " + f.optString("whyItMatters")
            }
        }
        lines += ""
        lines += "Next questions"
        appendArray(lines, report.optJSONArray("nextQuestions"))
        lines += ""
        lines += "Limitations"
        appendArray(lines, report.optJSONArray("limitations"))
        return lines.joinToString("\n")
    }



    private fun searchExecutionLine(report: JSONObject, runtime: JSONObject): String {
        val executedQueryCount = report.optJSONArray("queries")?.length() ?: 0
        val plannedQueryBudget = runtime.optInt("effectiveMaxQueries", 0)
        val plannedResultBudget = runtime.optInt("effectiveResultsPerQuery", 0)
        return if (executedQueryCount == 0) {
            "Search executed: 0 | planned: ${plannedQueryBudget} × ${plannedResultBudget} | status: NOT_EXECUTED_OR_BLOCKED"
        } else {
            "Search executed: ${executedQueryCount} query path(s) | planned: ${plannedQueryBudget} × ${plannedResultBudget}"
        }
    }

    private fun appendArray(lines: MutableList<String>, arr: JSONArray?) {
        if (arr == null || arr.length() == 0) {
            lines += "• None."
            return
        }
        for (i in 0 until arr.length()) lines += "• ${arr.optString(i)}"
    }

    private fun appendObjectArray(lines: MutableList<String>, arr: JSONArray?, keys: List<String>) {
        if (arr == null || arr.length() == 0) {
            lines += "• None."
            return
        }
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val rendered = keys.mapNotNull { key ->
                val value = obj.optString(key)
                if (value.isBlank()) null else "$key: $value"
            }.joinToString(" | ")
            lines += "• $rendered"
        }
    }

    private fun jsonArrayToList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    }

    private fun copyBriefReport() {
        val report = latestReport
        if (report == null) {
            Toast.makeText(this, "No report to copy yet.", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Immune Error Radar small report", renderSimpleUserReport(report) + "\n\n" + renderMiniLearningReport(report)))
        Toast.makeText(this, "Brief report copied.", Toast.LENGTH_SHORT).show()
    }

    private fun exportPdf() {
        val report = latestReport
        if (report == null) {
            Toast.makeText(this, "Run a research cycle first.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val file = DiscoveryReportExporter.export(this, report)
            shareFile(file, "application/pdf", "Share discovery PDF")
        } catch (e: Exception) {
            runCatching {
                val fallback = DiscoveryReportExporter.exportText(this, report, renderBriefReport(report) + "\n\n" + renderReport(report))
                shareFile(fallback, "text/plain", "Share discovery text report")
                Toast.makeText(this, "PDF failed; exported TXT instead.", Toast.LENGTH_LONG).show()
            }.onFailure { err ->
                Toast.makeText(this, "Report export failed: ${err.message ?: e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun shareFile(file: File, mimeType: String, chooserTitle: String) {
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, chooserTitle))
    }
}
