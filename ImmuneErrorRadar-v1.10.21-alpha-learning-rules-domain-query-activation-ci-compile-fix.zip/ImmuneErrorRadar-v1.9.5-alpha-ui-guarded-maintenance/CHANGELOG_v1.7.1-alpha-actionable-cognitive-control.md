# ImmuneErrorRadar v1.7.1-alpha-actionable-cognitive-control

## Purpose

v1.7.0 made the cognitive-learning controls visible in reports. v1.7.1 makes those controls actionable by feeding them back into the next-cycle cognitive directive instead of leaving them as passive report sections.

## What changed

- `CognitiveNextCycleBridge.directiveFromReportJson(...)` now enriches the next directive from the existing v1.7 control reports:
  - `evidenceGainQueryRankerReport`
  - `causalReadinessReport`
  - `miniPeerReviewReport`
  - `beliefFalsificationContractReport`
  - `reflectionLessonReport`
- Added directive-control enrichment helpers:
  - `extractV17ControlTerms`
  - `extractV17RequiredEvidence`
  - `buildV17ControlReason`
  - `appendControlSuffix`
  - `evidenceKeyFromGap`
- The next directive now carries explicit control blockers such as:
  - `outcome_labels`
  - `time_order`
  - `comparator_control`
  - `minimum_metadata`
  - `human_or_patient_data`
  - `falsification_lane`
- Updated version unification:
  - `versionName = 1.7.1-alpha-actionable-cognitive-control`
  - active engine: `v1.7.1-alpha-actionable-cognitive-control`
  - report schema: `171`
- Added static audit coverage for the actionable-control bridge.

## Why this matters

Before this patch, v1.7 control reports could say “peer review says HOLD” or “causal readiness needs TIME_ORDER,” but the saved next directive was still mostly derived from the v1.6 cognitive path. Now the directive is enriched by those control gates, so the following cycle is pushed toward the highest-value missing evidence instead of simply repeating a narrative plan.

## Claim boundary

This remains a research-routing/control patch only. It does not prove biology, diagnosis, treatment, causality, drug ranking, immune protection, or clinical value.
