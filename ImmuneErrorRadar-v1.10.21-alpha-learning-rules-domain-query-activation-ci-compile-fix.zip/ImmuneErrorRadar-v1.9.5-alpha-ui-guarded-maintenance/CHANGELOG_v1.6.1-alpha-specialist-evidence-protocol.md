# v1.6.1-alpha-specialist-evidence-protocol

## Goal
Make specialized reasoning measurable and harder to fake with generic narrative.

## Added
- EvidenceGapCard matrix: minimum metadata, outcome labels, time order, controls, falsification lane.
- HypothesisTournamentCard: ranks live explanations by testability and discriminator needs.
- ReasoningAuditQuestion: explicit pass/fail checks for competing explanations, discriminators, gaps, falsification, decisive action, and overclaim risk.
- Specialist verdict and next-cycle protocol in JSON, PDF, and simplified UI.

## Safety
- No medical, diagnostic, treatment, or biological-proof claims.
- New protocol guides the next research hunt only.
- Evidence gates remain responsible for belief/hypothesis upgrades.
