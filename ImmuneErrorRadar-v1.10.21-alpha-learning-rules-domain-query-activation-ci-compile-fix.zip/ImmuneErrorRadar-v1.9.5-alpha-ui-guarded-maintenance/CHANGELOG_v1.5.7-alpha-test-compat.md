# ImmuneErrorRadar v1.5.7-alpha-test-compat

## Purpose
Fixes a unit-test regression introduced by later Learning Session schema evolution.

## Fixed
- `LearningSessionV154ReadinessTest.runtimeFlagsExposeStableSessionSchema` no longer pins the schema to exactly `1.5.4`.
- The test now verifies that the schema is semantically **at least** `1.5.4`, so future schema increments do not break older readiness tests.

## Version
- `versionName`: `1.5.7-alpha-test-compat`
- `versionCode`: `39`
- `LEARNING_SESSION_SCHEMA_VERSION`: `1.5.7`

## Compatibility
- No runtime behavior changes.
- No schema downgrade.
- No checkpoint format rollback.
- The fix is test-compatibility only and preserves v1.5.6 session handoff behavior.
