# ImmuneErrorRadar v1.5.8-alpha-auto-learning-continuation

## Purpose

This patch fixes the behavior observed in the 2026-05-11 11:52 discovery report: the normal SEARCH cycle already performs fast auto-light learning, so the Think button should not be required for basic learning. Think is now clarified as a bounded Deep Think review session only.

## Added

- `CandidateActionResolver.kt`
  - Single action resolver combining ML triage + route-fit + direct accession status.
  - Forces `PARSE_MINIMUM_METADATA` when a direct accession has strong route fit.
  - Prevents high route-fit candidates from stopping at LOW_PRIORITY triage.
- `MinimumMetadataParser.kt`
  - Guarantees selected candidates have a visible metadata object.
  - Fallback output is metadata-only and cannot upgrade hypotheses.
- `AutoContinuationTrigger.kt`
  - Queues micro-follow-up metadata searches when parsing/contrastive gates stall.
  - Does not start a 15-minute Think session automatically.
- `ReportConsistencyGuard.kt`
  - Detects inconsistent language such as high route-fit + no parsed metadata + upgrade allowed.
  - Forces report wording toward `BLOCKED_UNTIL_METADATA_PARSED`.

## Changed

- Normal SEARCH cycles now report auto-light learning as active.
- Deep Think UI copy now makes clear that SEARCH already learns lightly.
- Research reports now include:
  - Candidate action resolver summary.
  - Auto-light continuation recommendation.
  - Report consistency guard language.
- Dataset foraging JSON now exports:
  - `candidateActionReport`
  - `autoContinuationReport`
  - `reportConsistencyGuard`
- Version bumped to `1.5.8-alpha-auto-learning-continuation` / `versionCode 40`.

## Safety

- No biological claims added.
- No diagnosis/treatment logic added.
- No auto-upgrade of hypotheses.
- No automatic Foundation Knowledge update.
- Deep Think remains user-controlled.

## Core rule

```text
SEARCH = auto-light learning.
Deep Think = bounded review session.
Candidate action resolves triage/route conflicts.
Minimum metadata is required before any hypothesis upgrade language.
```
