#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
app = ROOT / "app/src/main/java/com/immunesignal/app"
models = app / "ResearchModels.kt"
autopilot = app / "ResearchAutopilot.kt"
required_files = [
    app / "ResearchCycleSearchStage.kt",
    app / "ResearchCyclePathMaintenanceGuard.kt",
    ROOT / "app/src/test/java/com/immunesignal/app/ResearchCycleSearchStageTest.kt",
    ROOT / "app/src/test/java/com/immunesignal/app/ResearchCyclePathMaintenanceGuardTest.kt",
]
missing = [str(p.relative_to(ROOT)) for p in required_files if not p.exists()]
if missing:
    raise SystemExit("Missing v1.10.7 files: " + ", ".join(missing))

ap = autopilot.read_text()
checks = {
    "runCycle delegates network batch to ResearchCycleSearchStage": "ResearchCycleSearchStage.executeBatch(" in ap,
    "runtime failover delegated to SearchStage": "ResearchCycleSearchStage.buildRuntimeFailoverPlan(" in ap,
    "legacy inline runtime failover comment removed": "same-cycle active learning failover" not in ap,
    "path maintenance report built": "ResearchCyclePathMaintenanceGuard.build(" in ap,
    "path maintenance passed to report": "pathMaintenanceReport = pathMaintenanceReportV207" in ap,
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise SystemExit("v1.10.7 audit failed: " + "; ".join(failed))

m = models.read_text()
model_checks = {
    "schemaVersion 213": '.put("schemaVersion", 213)' in m,
    "ResearchCycleReport contains pathMaintenanceReport": "val pathMaintenanceReport: ResearchCyclePathMaintenanceReport" in m,
    "JSON exports pathMaintenanceReport": 'put("pathMaintenanceReport", ResearchCyclePathMaintenanceGuard.toJson(report.pathMaintenanceReport))' in m,
}
failed = [name for name, ok in model_checks.items() if not ok]
if failed:
    raise SystemExit("v1.10.7 model audit failed: " + "; ".join(failed))

registry = (app / "RuntimeModuleRegistry.kt").read_text()
for name in ["ResearchCycleSearchStage", "ResearchCyclePathMaintenanceGuard"]:
    if name not in registry:
        raise SystemExit(f"RuntimeModuleRegistry missing {name}")

print("stage linkage maintenance v1.10.7 audit: PASS")
