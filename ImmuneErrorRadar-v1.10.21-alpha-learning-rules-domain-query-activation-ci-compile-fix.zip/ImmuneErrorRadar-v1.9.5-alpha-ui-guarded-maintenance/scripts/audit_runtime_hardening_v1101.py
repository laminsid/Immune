from pathlib import Path

root = Path(__file__).resolve().parents[1]
autopilot = (root / 'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
ncbi = (root / 'app/src/main/java/com/immunesignal/app/NcbiClient.kt').read_text() if (root / 'app/src/main/java/com/immunesignal/app/NcbiClient.kt').exists() else ''
axis = (root / 'app/src/main/java/com/immunesignal/app/AxisMatcher.kt').read_text()
store = (root / 'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt').read_text()
store_ops = (root / 'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStoreFileOps.kt').read_text() if (root / 'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStoreFileOps.kt').exists() else ''
build = (root / 'app/build.gradle.kts').read_text()
manifest = (root / 'app/src/main/AndroidManifest.xml').read_text()
layout = (root / 'app/src/main/res/layout/activity_research_autopilot.xml').read_text()
secure = (root / 'app/src/main/java/com/immunesignal/app/SecureNcbiCredentialStore.kt').read_text()

required_autopilot = [
    'suspend fun runCycle',
    'recordRuntimeIssue',
    'EngineRuntimeStatus.ACTIVE_ENGINE_VERSION',
    'recordRuntimeIssue',
    'executedQueryIds = mutableSetOf<String>()',
    'ABSTRACT_TRUNCATED',
    'SCORE_CALIBRATION_UNCALIBRATED_HEURISTIC',
]
for token in required_autopilot:
    if token not in autopilot:
        raise SystemExit(f'Missing runtime hardening token in ResearchAutopilot.kt: {token}')
for forbidden in ['Thread.sleep', 'private-research@immune-error-radar.local', 'ImmuneErrorRadarPrivateResearch/1.3.3', 'errorStream\n            BufferedReader(InputStreamReader(stream))']:
    if forbidden in autopilot:
        raise SystemExit(f'Forbidden obsolete runtime token still present: {forbidden}')
for token in ['CompiledAxisRule', 'Regex("(?<![A-Za-z0-9])', 'containsMatchIn']:
    if token not in axis:
        raise SystemExit(f'Missing AxisMatcher hardening token: {token}')
for token in ['readLastLines', 'withFileLock', 'appendOnly(fileName, line)', 'parseJsonLine', 'ResearchKnowledgeStoreFileOps']:
    if token not in store:
        raise SystemExit(f'Missing KnowledgeStore hardening token: {token}')
for token in ['bufferedReader(Charsets.UTF_8).useLines', 'readLastValidJsonLines', 'trimFile', 'appendOnly']:
    if token not in store_ops:
        raise SystemExit(f'Missing KnowledgeStoreFileOps hardening token: {token}')
for token in ['isMinifyEnabled = true', 'isShrinkResources = true', 'viewBinding = true', 'androidx.security:security-crypto', 'io.gitlab.arturbosch.detekt']:
    if token not in build:
        raise SystemExit(f'Missing Gradle hardening token: {token}')
for token in ['android:networkSecurityConfig="@xml/network_security_config"']:
    if token not in manifest:
        raise SystemExit(f'Missing manifest hardening token: {token}')
for token in ['Network notice: when Search is used', 'contentDescription']:
    if token not in layout:
        raise SystemExit(f'Missing UI privacy/accessibility token: {token}')
for token in ['EncryptedSharedPreferences', 'MasterKey', 'deleteFile(LEGACY_API_KEY_FILE)']:
    if token not in secure:
        raise SystemExit(f'Missing secure credential token: {token}')
for removed in ['ResultActivity.kt', 'ImmuneSignalEngine.kt', 'HypothesisEngine.kt']:
    if (root / 'app/src/main/java/com/immunesignal/app' / removed).exists():
        raise SystemExit(f'Dead code file still present: {removed}')
if (root / 'app/src/main/res/layout/activity_result.xml').exists():
    raise SystemExit('Legacy activity_result.xml still present')
print('runtime hardening v1.10.1/v1.10.8 audit: PASS')
