#!/usr/bin/env python3
from pathlib import Path

checks = {
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'DEFAULT_RESEARCH_LEARNING_TIME_LIMIT_MILLIS', '45L * 60L * 1000L',
        'PRIOR_FAST_THINKING_WINDOW_MILLIS', 'MIN_AUTONOMOUS_THINKING_PASSES'
    ],
    'app/src/main/java/com/immunesignal/app/ExtendedThinkingBudgetPolicy.kt': [
        'ExtendedThinkingBudgetPolicy', 'EXTENDED_LOCAL_THINKING_BUDGET',
        'do_not_stop_after_30_seconds_when_dataset_gap_is_open',
        'extended_thinking_budget_not_biological_proof', 'passesExecuted'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'extendedThinkingBudgetReport', 'ExtendedThinkingBudgetPolicy.toJson', 'schemaVersion", 213'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'extendedThinkingBudgetReportV11016', 'v1.10.16 extended thinking budget',
        'learning_limit_${limits.maxLearningMillis / (60L * 1000L)}_min_reached'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'DEFAULT_RESEARCH_LEARNING_TIME_LIMIT_MILLIS', 'maxQueries = 8', 'maxResultsPerQuery = 25',
        'Extended thinking budget: 45m', 'Think budget:'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Extended thinking budget v1.10.16', 'extendedThinkingBudgetReport'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.10.21-alpha-learning-rules-domain-query-activation', 'ExtendedThinkingBudgetPolicy'
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'ExtendedThinkingBudgetPolicy'
    ],
    'app/src/test/java/com/immunesignal/app/ExtendedThinkingBudgetV11016Test.kt': [
        'extendedBudgetUsesLongerSessionLimitAndLocalPasses', 'PRIOR_FAST_THINKING_WINDOW_MILLIS'
    ],
    'docs/EXTENDED_THINKING_BUDGET_v1.10.16.md': [
        '45 minutes', '4 visible local reasoning passes', 'extended_thinking_budget_not_biological_proof'
    ],
    'app/build.gradle.kts': ['1.10.21-alpha-learning-rules-domain-query-activation']
}
missing = []
for rel, needles in checks.items():
    text = Path(rel).read_text(encoding='utf-8')
    for needle in needles:
        if needle not in text:
            missing.append(f'{rel}: {needle}')
if missing:
    raise SystemExit('v1.10.16 extended thinking budget audit failed:\n' + '\n'.join(missing))
print('v1.10.16 extended thinking budget audit: PASS')
