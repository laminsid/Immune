# v1.5.9-alpha-simple-ui-learning-brief

Purpose: reduce UI complexity while preserving the research engine, auto-light learning, and deep review sessions.

## Changes

- Simplified the Research Autopilot main screen.
- Main result now shows only:
  - what was found,
  - what changed,
  - next action,
  - confidence/readiness,
  - what not to believe yet.
- Added a small visible learning report so the user can track whether the system is learning.
- Added an Advanced controls toggle.
- Moved Deep Think, steering, and import controls behind Advanced controls by default.
- Kept Search as the normal auto-light learning path.
- Kept Deep Think as optional deep review, not required for basic learning.
- Updated Copy brief to copy the simple result plus the small learning report.
- Added static-check tokens for the simplified UI and learning mini report.

## Safety / claims

- No diagnosis, treatment, drug ranking, or clinical recommendation.
- The small learning report only shows search-learning state.
- Learning guides the next hunt; it does not prove biology.
