# ImmuneErrorRadar v1.5.3-alpha-session-hardening

## Purpose
Hardens v1.5.2 Learning Sessions without changing the core v1.4.5 research cycle.

## Added
- `RuntimeFeatureFlags.kt` as one-line rollback/activation point.
- `LearningSessionIntegrityGuard.kt` for checkpoint normalization and validation.
- Persistent accumulated session time across pause/resume.
- Resume count tracking.
- Session history snapshot store with local-only audit summary.
- Checkpoint integrity report surfaced in the UI metrics block.
- v1.5.3 unit test for checkpoint normalization and completed-session resume blocking.

## Safety
- Foundation Knowledge OS remains disabled by default.
- Learning Sessions remain user-triggered only; no background thinking loop.
- Session history is bookkeeping only, not evidence or biological proof.
- No automatic patching of foundation JSON knowledge packs.
