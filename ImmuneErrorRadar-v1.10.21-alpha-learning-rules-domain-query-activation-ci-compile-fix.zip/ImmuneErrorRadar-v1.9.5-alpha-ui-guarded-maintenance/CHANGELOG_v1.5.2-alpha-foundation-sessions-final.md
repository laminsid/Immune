# ImmuneErrorRadar v1.5.2-alpha-foundation-sessions-final

## Purpose
Completes the non-breaking Foundation Knowledge OS + Learning Sessions integration on top of v1.5.1.

## Added / completed
- Added a UI-level **Skip phase** control for bounded learning sessions.
- Added `LearningSessionManager.skipCurrentOrNextPhase()` with checkpointed, non-evidential skipped phase records.
- Added `LearningSessionManager.markNewSearchBoundary()` so a new Search + learn cycle preserves paused thinking state instead of silently losing context.
- Added `SessionMetrics` and checkpoint metrics: time used, phase progress, checkpoints, processed items, errors, and session-level delta counters.
- Added session metrics rendering in the Research Autopilot UI.
- Updated active engine version to `v1.5.2-alpha-foundation-sessions-final`.
- Updated schema version to `152`.
- Kept Foundation Knowledge OS optional/disabled-by-default as a safe rollback boundary.

## Safety constraints preserved
- No medical, diagnostic, treatment, or drug-ranking claims.
- Foundation knowledge remains `foundation_knowledge_not_evidence`.
- ML remains triage/routing only.
- Learning sessions remain `learning_session_not_biological_proof`.
- No automatic mutation of foundation JSON packs.
