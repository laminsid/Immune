# ImmuneErrorRadar v1.6.7-alpha-cognitive-directive-retirement

This patch completes the closed cognitive loop by retiring next-cycle directives that are already satisfied or unusable, instead of letting them replay forever as inactive no-op plans.

## Changes
- `CognitiveNextCyclePlan` now carries `consumptionReason`, `routingFingerprint`, and `useLimit`.
- Already-covered directive terms now produce a consumed no-op plan.
- Empty/unusable directives are retired instead of retried indefinitely.
- `ResearchAutopilot` now marks a directive consumed whenever the plan says it was consumed, not only when a follow-up query was actively added.
- UI/PDF now show retired closed-loop directives, not only active ones.
- Added Kotlin string-literal static audit to catch accidental raw newline string breakages.
- Added tests for retired already-satisfied directives and JSON export metadata.

## Claim boundary
Directive retirement controls routing only. It does not prove biology, upgrade hypotheses, diagnose, recommend treatment, or edit foundation knowledge packs.
