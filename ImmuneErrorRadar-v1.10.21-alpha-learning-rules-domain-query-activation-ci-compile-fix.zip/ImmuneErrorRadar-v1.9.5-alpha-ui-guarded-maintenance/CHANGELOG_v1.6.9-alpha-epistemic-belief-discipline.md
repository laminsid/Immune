# ImmuneErrorRadar v1.6.9-alpha-epistemic-belief-discipline

This release strengthens the existing cognitive/belief loop without adding a parallel engine.

## What changed

- Added explicit belief transition reporting inside `EpistemicBeliefEngine`:
  - `strengthenedBelief`
  - `weakenedBelief`
  - `droppedBelief`
- Added `EpistemicBeliefTransitionSummary` to the JSON report.
- Added an `abandonmentQuestion` to every belief:
  - `What evidence would make me abandon this belief?`
- Added weak-belief pruning logic:
  - weak/unused prior beliefs are not carried forward unless they are supported, linked to the current cycle, or foundation-level priors.
- Updated the simple UI, mini learning report, and PDF exporter to show the belief transition lines clearly.
- Updated runtime module list with:
  - `BeliefTransitionSummary`
  - `BeliefAbandonmentQuestion`
  - `UnusedWeakBeliefPruner`
- Bumped runtime/schema/app version to v1.6.9.

## Boundary

This is still a research-routing and epistemic discipline layer only. It does not prove biology, causality, diagnosis, treatment, protection, or immune outcomes.
