# ImmuneErrorRadar v1.6.3-alpha-epistemic-belief-model

## Purpose
Turns the cumulative knowledge map into a mutable epistemic belief model: not only what the system has seen, but what it currently believes as research priors, why, what can weaken those beliefs, and when they must be revised or retired.

## Added
- `EpistemicBeliefEngine.kt`
- `EpistemicBelief`
- `EpistemicBeliefUpdate`
- `EpistemicBeliefReport`
- JSON export: `epistemicBeliefReport`
- UI summary: Belief model / Belief next
- PDF section: Epistemic belief model
- Unit test: `EpistemicBeliefModelV163Test.kt`

## Behavior
- Converts findings, hypotheses, route-fit assessments, evidence gaps, and map gaps into mutable beliefs.
- Carries prior beliefs forward from previous reports.
- Weakens beliefs when gaps or contradictions appear.
- Marks beliefs as `REVISE_REQUIRED` or `RETIRED` when credibility falls.
- Seeds foundation priors but never auto-updates JSON foundation packs.

## Safety Boundary
Epistemic beliefs are research priors only. They guide search and falsification. They do not prove biology, causality, diagnosis, treatment, or protection.
