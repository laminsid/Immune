# ImmuneErrorRadar v1.6.8-alpha-cognitive-loop-calibration

## Purpose
This release closes the cognitive loop one level further. v1.6.5-v1.6.7 could carry a bounded next-cycle directive forward and retire it safely. v1.6.8 now evaluates whether that directive actually improved the next cycle.

## Added
- `CognitiveLoopCalibrationEngine.kt`
- `CognitiveLoopCalibrationReport`
- `CognitiveLoopCalibrationSignal`
- JSON export field: `cognitiveLoopCalibrationReport`
- UI summary: `Loop calibration`
- PDF section: `Cognitive loop calibration`
- Knowledge ledger entry: `cognitive_loop_calibration`
- Unit test: `CognitiveLoopCalibrationV168Test.kt`

## What it calibrates
- Whether the prior directive changed a query.
- Whether metadata parsing advanced.
- Whether contrastive gate moved beyond `NOT_EVALUATED`.
- Whether cumulative evidence moved above zero.
- Whether the knowledge map gained nodes/links.
- Whether belief state changed rather than staying stale.
- Whether specialist reasoning named a decisive test.
- Whether Learning OS root causes remain active.

## Boundaries
- Calibration does not prove biology.
- Calibration does not upgrade hypotheses.
- Calibration does not diagnose or recommend treatment.
- Calibration can only dampen or reward future routing behavior.
