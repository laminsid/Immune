# Immune Error Radar v1.4.5-alpha — Learning Memory + ML-Safe Triage

v1.4.5 turns the route-fit cleanup into a learning loop. It does **not** add a biological classifier, diagnosis, treatment advice, drug ranking, or ML discovery claims.

## Added

- `FailurePatternLedger.kt` — local-only failure-pattern memory for repeated search failures such as `NO_OUTCOME_LABELS`, `ANIMAL_ONLY`, `NO_TIMECOURSE`, `METADATA_ONLY`, `OFF_ROUTE`, and `WRONG_SPECIES`.
- `QueryFeedbackPlanner.kt` — converts recent failure patterns into stronger next-query constraints such as `human`, `longitudinal`, `viral load`, `recovery`, `severity`, and `outcome`.
- `DatasetTriageEngine.kt` — ML-safe/rule-based dataset triage with `FailurePredictionModel` and `RouteEmbeddingScorer`; claim limit is always `triage_only_not_biological_proof`.
- `EvidenceFreshnessScorer.kt` — ranking-only freshness weighting using the current year dynamically, with small boost caps and protection for foundational studies.
- Report/JSON surfaces for triage, failure-pattern ledger, query feedback, and freshness weighting.
- Unit coverage for v1.4.5 triage, query feedback, and freshness safety claims.

## Changed

- Active engine version updated to `v1.4.5-alpha-ml-triage`.
- Dataset parsing now runs only on candidates selected by triage as `PARSE` or `PARSE_WITH_CAUTION`; low-priority/off-route candidates remain visible as research leads but do not consume parser cycles.
- Hypothesis ranking now uses a capped freshness-adjusted evidence score. Freshness can nudge ranking but cannot prove biology.
- Research report now states that ML/triage, query feedback, failure memory, and freshness weighting rank the hunt only.

## Safety boundary

The operating rule remains:

> ML ranks the hunt. Evidence gates the belief. Reports show the limits.

No medical advice, no diagnostic claim, no treatment recommendation, and no ML biological-discovery claim are generated.
