package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DatasetHuntSearchUnlockPolicyTest {
    @Test
    fun unlocksDatasetHuntWhenCognitiveLockHasNoEvidenceObject() {
        val decision = DatasetHuntSearchUnlockPolicy.evaluate(
            recentReports = listOf("NO_DATASET_ACCESSION NO_EVIDENCE_OBJECT_NO_UPGRADE dataset candidates: 0 evidence objects: 0"),
            researchState = "DATASET_HUNT",
            priorDirective = directive(owner = "linked_cognition_spine", mode = "THINK_FIRST_SINGLE_DISCRIMINATOR", blockDatasetFirst = true),
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertTrue(decision.allowDatasetAccessionSearch)
        assertTrue(decision.reason.startsWith("EVIDENCE_FIRST"))
    }

    @Test
    fun doesNotOverrideExplicitEvidenceClosureLock() {
        val decision = DatasetHuntSearchUnlockPolicy.evaluate(
            recentReports = listOf("NO_DATASET_ACCESSION"),
            researchState = "DATASET_HUNT",
            priorDirective = directive(owner = "evidence_closure", mode = "EVIDENCE_CLOSURE_NARROW_SEARCH", blockDatasetFirst = true),
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertFalse(decision.allowDatasetAccessionSearch)
    }


    @Test
    fun unlocksFromPersistentNoDatasetMemoryEvenWhenReportTextIsSparse() {
        val memory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord(
                    failedQueryHash = "h1",
                    sourceFamily = "broad_pubmed_mapping",
                    rootCause = "NO_DATASET_ACCESSION+BROAD_QUERY",
                    cooldownCyclesRemaining = 2,
                    lastAttemptedAtMillis = 1L,
                    timesFailed = 3,
                    forcedNextSource = "GEO_GDS"
                )
            ),
            summary = "dataset accession is still missing"
        )

        val decision = DatasetHuntSearchUnlockPolicy.evaluate(
            recentReports = listOf("previous cycle stalled"),
            researchState = "research_normal",
            priorDirective = directive(owner = "linked_cognition_spine", mode = "THINK_FIRST_SINGLE_DISCRIMINATOR", blockDatasetFirst = true),
            memory = memory
        )

        assertTrue(decision.allowDatasetAccessionSearch)
        assertTrue(decision.trace.any { it.contains("allow_accession_search_only") })
    }

    @Test
    fun doesNotUnlockWhenDirectiveAlreadyTargetsExplicitAccession() {
        val decision = DatasetHuntSearchUnlockPolicy.evaluate(
            recentReports = listOf("NO_DATASET_ACCESSION"),
            researchState = "DATASET_HUNT",
            priorDirective = directive(
                owner = "linked_cognition_spine",
                mode = "LINKED_SPINE_NARROW_SEARCH",
                blockDatasetFirst = true,
                queryText = "GSE250594 outcome labels metadata"
            ),
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertFalse(decision.allowDatasetAccessionSearch)
        assertTrue(decision.trace.any { it.contains("explicit_accession_present") })
    }

    @Test
    fun doesNotUnlockWhenDatasetEvidenceAlreadyExistsButMetadataIsIncomplete() {
        val decision = DatasetHuntSearchUnlockPolicy.evaluate(
            recentReports = listOf("DATASET_HUNT dataset candidates: 2 evidence objects: 1 missing outcome_labels minimum_metadata"),
            researchState = "DATASET_HUNT",
            priorDirective = directive(owner = "linked_cognition_spine", mode = "THINK_FIRST_SINGLE_DISCRIMINATOR", blockDatasetFirst = true),
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertFalse(decision.allowDatasetAccessionSearch)
        assertTrue(decision.trace.any { it.contains("blocked_by_existing_evidence") })
    }

    @Test
    fun evidenceFirstIntentStillUnlocksWhenCountsAreExplicitlyZero() {
        val decision = DatasetHuntSearchUnlockPolicy.evaluate(
            recentReports = listOf("EVIDENCE_FIRST_ACCESSION_SEARCH dataset candidates: 0 evidence objects: 0"),
            researchState = "research_normal",
            priorDirective = directive(owner = "linked_cognition_spine", mode = "THINK_FIRST_SINGLE_DISCRIMINATOR", blockDatasetFirst = true),
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertTrue(decision.allowDatasetAccessionSearch)
    }

    private fun directive(
        owner: String,
        mode: String,
        blockDatasetFirst: Boolean,
        queryText: String = "outcome labels metadata control comparator"
    ) = ResearchSearchDirective(
        active = true,
        mode = mode,
        governingLayer = owner,
        queries = listOf(
            ResearchQuery(
                id = "q_test_gap",
                label = "test",
                query = queryText,
                reason = "test"
            )
        ),
        reason = "THINK_FIRST: repair cognition handoff before network search.",
        maxQueries = 1,
        maxResultsPerQuery = 3,
        blockDatasetFirst = blockDatasetFirst,
        trace = listOf("test")
    )
}
