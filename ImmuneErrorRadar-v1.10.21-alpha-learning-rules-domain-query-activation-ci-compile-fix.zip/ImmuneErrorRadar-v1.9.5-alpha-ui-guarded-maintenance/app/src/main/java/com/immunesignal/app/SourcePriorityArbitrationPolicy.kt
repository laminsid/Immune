package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.19: Source Priority Arbitration.
 *
 * The exploration sandbox deliberately gives the researcher more freedom, but
 * DATASET_HUNT must still respect the acquisition hierarchy. While no accession
 * exists, direct accession-capable families win over creative continuation,
 * contradiction, control, and adjacent-domain expansion. This prevents the
 * system from spending the next bounded query on PUBMED_CONTROL while the
 * accession report already says SRA_PRJNA is the next missing source.
 */
object SourcePriorityArbitrationPolicy {
    const val CLAIM_LIMIT: String = "source_priority_arbitration_not_biological_proof"

    val coreAccessionFamilies: List<String> = listOf(
        "GEO_GDS",
        "SRA_PRJNA",
        "IMM_PORT_SDY",
        "PUBMED_ACCESSION_MINING"
    )

    val exploratoryAndSecondaryFamilies: List<String> = listOf(
        "PUBMED_ADJACENT_DOMAIN_MINING",
        "PUBMED_CONTRADICTION",
        "PUBMED_CONTROL"
    )

    fun arbitrateRoutes(
        routes: List<DirectDatasetSourceRouter.SourceRoute>,
        memory: PersistentFailureMemorySnapshot,
        accessionPressure: Boolean
    ): List<DirectDatasetSourceRouter.SourceRoute> {
        if (!accessionPressure && !memoryShowsNoAccessionPressure(memory)) return routes
        val archive = routes.filter { normalize(it.sourceFamily) == "ARCHIVE_OR_REFRAME_ROUTE" || it.ncbiDb == "offline" }
        val network = routes.filterNot { normalize(it.sourceFamily) == "ARCHIVE_OR_REFRAME_ROUTE" || it.ncbiDb == "offline" }
        val repairedCore = coreAccessionFamilies
            .mapNotNull { family -> network.firstOrNull { normalize(it.sourceFamily) == family } ?: DirectDatasetSourceRouter.routeForSourceFamily(family) }
            .mapIndexed { index, route ->
                route.copy(
                    priority = 220 - index,
                    reason = "v1.10.19 source-priority arbitration: accession-capable sources must complete before creative/contradiction/control routing while NO_ACCESSION is active. ${route.reason}"
                )
            }
        val secondary = network
            .filter { normalize(it.sourceFamily) !in coreAccessionFamilies }
            .sortedBy { secondaryRank(it.sourceFamily) }
        return (repairedCore + secondary + archive)
            .distinctBy { normalize(it.sourceFamily) }
    }

    fun nextSourceAfterNoCandidateSequence(attemptedFamilies: List<String>): String {
        val attempted = attemptedFamilies.map { normalize(it) }.filter { it.isNotBlank() }
        val attemptedSet = attempted.toSet()
        val secondaryTouched = attemptedSet.any { it in exploratoryAndSecondaryFamilies }
        val missingCore = coreAccessionFamilies.firstOrNull { it !in attemptedSet }
        if (secondaryTouched && missingCore != null) return missingCore
        val last = attempted.lastOrNull { it in coreAccessionFamilies + exploratoryAndSecondaryFamilies } ?: return coreAccessionFamilies.first()
        val order = coreAccessionFamilies + exploratoryAndSecondaryFamilies
        val start = order.indexOf(last).takeIf { it >= 0 } ?: 0
        for (step in 1..order.size) {
            val candidate = order[(start + step) % order.size]
            if (candidate !in attemptedSet) return candidate
        }
        return "ARCHIVE_OR_REFRAME_ROUTE"
    }

    fun summary(attemptedFamilies: List<String>, nextSource: String): String {
        val attempted = attemptedFamilies.map { normalize(it) }.distinct()
        val missingCore = coreAccessionFamilies.filter { it !in attempted }
        return "Source priority arbitration: accession-first routing active; attempted=${attempted.joinToString(",").ifBlank { "none" }}; missingCore=${missingCore.joinToString(",").ifBlank { "none" }}; next=$nextSource; creative/control routes cannot override accession sweep while NO_ACCESSION remains."
    }

    fun memoryShowsNoAccessionPressure(memory: PersistentFailureMemorySnapshot): Boolean = memory.records.any { record ->
        record.rootCause.contains("NO_DATASET_ACCESSION", ignoreCase = true) ||
            record.rootCause.contains("BROAD_QUERY", ignoreCase = true) ||
            record.forcedNextSource.contains("SRA_PRJNA", ignoreCase = true) ||
            record.forcedNextSource.contains("GEO_GDS", ignoreCase = true) ||
            record.forcedNextSource.contains("PUBMED_ACCESSION", ignoreCase = true)
    }

    private fun secondaryRank(sourceFamily: String): Int = when (normalize(sourceFamily)) {
        "PUBMED_ADJACENT_DOMAIN_MINING" -> 10
        "PUBMED_CONTRADICTION" -> 20
        "PUBMED_CONTROL" -> 30
        else -> 99
    }

    private fun normalize(value: String): String = value.trim().uppercase(Locale.US)
}
