package com.immunesignal.app

/**
 * v1.6.1: single rollback/activation point for optional research-intelligence layers.
 *
 * These flags keep the production research cycle backward-compatible. Foundation
 * knowledge remains disabled by default. Learning Sessions are user-initiated UI
 * tools, not background workers, and never run unless the user presses Think.
 */
object RuntimeFeatureFlags {
    const val ENABLE_FOUNDATION_KNOWLEDGE_OS: Boolean = false
    const val ENABLE_LEARNING_SESSION_UI: Boolean = true
    const val DEFAULT_SEARCH_TIME_LIMIT_MILLIS: Long = 20L * 60L * 1000L
    const val DEFAULT_RESEARCH_LEARNING_TIME_LIMIT_MILLIS: Long = 45L * 60L * 1000L
    const val DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS: Long = 45L * 60L * 1000L
    const val PRIOR_FAST_THINKING_WINDOW_MILLIS: Long = 30L * 1000L
    const val MIN_AUTONOMOUS_THINKING_PASSES: Int = 4
    const val MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES: Int = 3
    const val MIN_EXTENDED_ACCESSION_QUERY_PATHS: Int = 3
    const val ENABLE_AUTONOMOUS_EXPLORATION_SANDBOX: Boolean = true
    const val MIN_EXPLORATION_SANDBOX_QUERY_VARIANTS: Int = 6
    const val ENABLE_SOURCE_PRIORITY_ARBITRATION: Boolean = true
    const val ENABLE_DOMAIN_EXPERTISE_MEMORY: Boolean = true
    const val MIN_DOMAIN_EXPERTISE_SCORE_TO_REUSE: Int = 25
    const val MAX_DOMAIN_EXPERTISE_CARDS: Int = 6
    const val MIN_DOMAIN_EXPERTISE_MATURITY_EXPOSURES: Int = 3
    const val ENABLE_LEARNING_RULE_ENGINE: Boolean = true
    const val MIN_LEARNING_RULE_COVERAGE: Double = 0.60
    const val ENABLE_DOMAIN_EXPERTISE_QUERY_REUSE: Boolean = true
    const val ENABLE_ROUTE_FINGERPRINT_GUARD: Boolean = true
    const val ROUTE_FINGERPRINT_LOOKBACK: Int = 5
    const val MAX_EPISTEMIC_BELIEFS_PER_REPORT: Int = 60
    const val STRONG_SIGNAL_CAUSALITY_THRESHOLD: Int = 65
    const val STRONG_SIGNAL_EVIDENCE_THRESHOLD: Int = 65
    const val EVIDENCE_DECAY_PENALTY_AFTER_YEAR_3: Int = 3
    const val EVIDENCE_DECAY_PENALTY_AFTER_YEAR_7: Int = 8
    const val EVIDENCE_DECAY_PENALTY_AFTER_YEAR_12: Int = 15
    const val MAX_LEARNING_SESSION_HISTORY: Int = 20
    const val LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.21"

    const val FOUNDATION_CLAIM_LIMIT: String = "foundation_knowledge_not_evidence"
    const val LEARNING_SESSION_CLAIM_LIMIT: String = "learning_session_not_biological_proof"
    const val CHECKPOINT_CLAIM_LIMIT: String = "learning_session_checkpoint_not_evidence"
    const val SPECIALIZED_REASONING_CLAIM_LIMIT: String = "specialized_reasoning_not_biological_proof"
    const val EPISTEMIC_BELIEF_CLAIM_LIMIT: String = "epistemic_beliefs_not_biological_proof"
    const val COGNITIVE_PATH_CLAIM_LIMIT: String = "cognitive_path_integration_not_biological_proof"
}
