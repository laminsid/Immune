package com.immunesignal.app

/**
 * v1.10.15: Accession acquisition hardening.
 *
 * This layer deliberately does not add a biological model. It answers one
 * operational question before the report grows large: did this cycle acquire a
 * concrete dataset handle, a weak handle that needs metadata, or nothing worth
 * another broad search?
 */
data class AccessionAcquisitionReport(
    val active: Boolean,
    val state: String,
    val explicitAccessions: List<String>,
    val weakAccessions: List<String>,
    val unresolvedLeadCount: Int,
    val archiveRecommended: Boolean,
    val compactReportRecommended: Boolean,
    val nextAction: String,
    val reasons: List<String>,
    val claimLimit: String = "accession_acquisition_not_biological_proof"
) {
    companion object {
        fun empty() = AccessionAcquisitionReport(
            active = false,
            state = "NOT_EVALUATED",
            explicitAccessions = emptyList(),
            weakAccessions = emptyList(),
            unresolvedLeadCount = 0,
            archiveRecommended = false,
            compactReportRecommended = false,
            nextAction = "Run dataset accession acquisition before broad biological reasoning.",
            reasons = emptyList()
        )
    }
}

object AccessionAcquisitionHardening {
    private val explicitPrefixes = listOf(
        "GSE", "GSM", "GDS", "SDY", "PRJNA", "PRJEB", "PRJDB",
        "SRP", "SRA", "SRR", "SRX", "SRS", "ERP", "ERX", "ERR", "DRP", "DRX", "DRR",
        "E-MTAB", "E-GEOD", "E-MEXP", "EGAS", "SAMN", "SAMEA", "SAMD", "PHS"
    )

    fun isExplicitAccession(accession: String): Boolean {
        val normalized = accession.trim().uppercase()
        if (normalized.isBlank() || normalized == "DATASET_ACCESSION_UNRESOLVED") return false
        if (normalized.startsWith("NCBI_UID:") || normalized.startsWith("WEAK_NCBI_UID:")) return false
        return explicitPrefixes.any { normalized.startsWith(it) }
    }

    fun evaluate(
        candidates: List<DatasetAccessionCandidate>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        attempts: List<DatasetSourceAttempt>,
        noCandidateLearningRecords: List<NoCandidateLearningRecord>,
        memory: PersistentFailureMemorySnapshot = PersistentFailureMemorySnapshot.empty()
    ): AccessionAcquisitionReport {
        val explicit = candidates
            .map { it.accession }
            .filter { isExplicitAccession(it) }
            .distinct()
            .take(12)

        val weak = candidates
            .filter { candidate ->
                !isExplicitAccession(candidate.accession) &&
                    (candidate.status.contains("WEAK", ignoreCase = true) ||
                        candidate.status.contains("UNRESOLVED", ignoreCase = true) ||
                        candidate.status.contains("NEEDS_ACCESSION", ignoreCase = true))
            }
            .map { it.accession }
            .distinct()
            .take(12)

        val unresolvedCount = candidates.count { !isExplicitAccession(it.accession) }
        val attemptedDatasetFamilies = attempts.map { it.sourceFamily }.distinct()
        val directDatasetAttempted = attemptedDatasetFamilies.any { it == "GEO_GDS" || it == "SRA_PRJNA" || it == "IMM_PORT_SDY" }
        val networkAttempts = attempts.filterNot { it.ncbiDb == "offline" || it.sourceFamily == "ARCHIVE_OR_REFRAME_ROUTE" }
        val archiveOnlyAttempt = attempts.isNotEmpty() && networkAttempts.isEmpty()
        val allAttemptedNoCandidate = attempts.isNotEmpty() && attempts.all { it.candidatesExtracted == 0 }
        val sourceSweepArchiveAllowed = ExtendedAcquisitionSweepPolicy.archiveAllowed(
            sourceFamiliesAttempted = attemptedDatasetFamilies,
            executedQueryCount = networkAttempts.size
        )
        val repeatedNoAccession = memory.records.any { record ->
            record.rootCause.contains("NO_DATASET_ACCESSION", ignoreCase = true) && record.timesFailed >= 2
        }
        // v1.10.15: an offline ARCHIVE_OR_REFRAME marker must not be treated as a
        // completed acquisition attempt. If no real network/source-family attempt
        // left the device, the correct state is KEEP_ACQUIRING so the plan/search
        // stage can run one bounded recovery query instead of reporting Search: 0.
        val terminalArchive = !archiveOnlyAttempt && sourceSweepArchiveAllowed && (attemptedDatasetFamilies.contains("ARCHIVE_OR_REFRAME_ROUTE") ||
            (explicit.isEmpty() && weak.isEmpty() && allAttemptedNoCandidate && repeatedNoAccession))

        val state = when {
            explicit.isNotEmpty() -> "FOUND_ACCESSION"
            weak.isNotEmpty() || unresolvedCount > 0 || parsedMetadata.isNotEmpty() -> "FOUND_WEAK_ACCESSION_NEEDS_METADATA"
            terminalArchive -> "NO_ACCESSION_ARCHIVE_ROUTE"
            allAttemptedNoCandidate && !sourceSweepArchiveAllowed -> "NO_ACCESSION_CONTINUE_SOURCE_SWEEP"
            allAttemptedNoCandidate -> "NO_ACCESSION_KEEP_ACQUIRING"
            else -> "NOT_EVALUATED"
        }

        val next = when (state) {
            "FOUND_ACCESSION" -> "Parse minimum metadata for explicit accession(s): ${explicit.take(3).joinToString(", ")}; require outcome labels, comparator/control, and time order before any hypothesis upgrade."
            "FOUND_WEAK_ACCESSION_NEEDS_METADATA" -> "Do not upgrade biology. Convert weak/unresolved dataset lead into explicit GSE/SDY/PRJNA/SRP/E-MTAB accession or parse minimum metadata if source metadata is available."
            "NO_ACCESSION_ARCHIVE_ROUTE" -> "Archive or reframe this route before another search cycle; do not produce another broad discovery report without a new parent evidence source."
            "NO_ACCESSION_CONTINUE_SOURCE_SWEEP" -> ExtendedAcquisitionSweepPolicy.nextAction(attemptedDatasetFamilies, networkAttempts.size)
            "NO_ACCESSION_KEEP_ACQUIRING" -> "Run one accession-acquisition query only: GSE/GEO/SDY/ImmPort/PRJNA/SRP plus outcome/severity/recovery/longitudinal/control labels."
            else -> "Run dataset accession acquisition before broad biological reasoning."
        }

        val reasons = mutableListOf<String>()
        reasons += "Explicit accessions=${explicit.size}; weak/unresolved leads=${maxOf(weak.size, unresolvedCount)}."
        if (directDatasetAttempted) reasons += "Direct dataset families attempted: ${attemptedDatasetFamilies.joinToString(", ")}."
        if (archiveOnlyAttempt) reasons += "Archive/reframe was proposed before a real source-family query executed; trigger zero-query acquisition recovery."
        if (noCandidateLearningRecords.isNotEmpty()) reasons += "No-candidate records active: ${noCandidateLearningRecords.map { it.sourceFamily }.distinct().joinToString(", ")}."
        if (repeatedNoAccession) reasons += "Persistent memory shows repeated NO_DATASET_ACCESSION; broad report expansion should be suppressed."
        if (!sourceSweepArchiveAllowed && networkAttempts.isNotEmpty()) reasons += "v1.10.17 source sweep not complete; archive/reframe blocked until at least ${RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES} source families and ${RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_QUERY_PATHS} query paths are attempted."
        if (parsedMetadata.isEmpty()) reasons += "No parsed metadata object yet; report should stay compact until a dataset handle exists."

        return AccessionAcquisitionReport(
            active = true,
            state = state,
            explicitAccessions = explicit,
            weakAccessions = weak,
            unresolvedLeadCount = unresolvedCount,
            archiveRecommended = terminalArchive,
            compactReportRecommended = explicit.isEmpty() && parsedMetadata.isEmpty(),
            nextAction = next,
            reasons = reasons.distinct(),
            claimLimit = "accession_acquisition_not_biological_proof"
        )
    }

    fun routeFamiliesForNoAccession(memory: PersistentFailureMemorySnapshot): List<String> {
        val noAccessionPressure = memory.records.any { record ->
            record.rootCause.contains("NO_DATASET_ACCESSION", ignoreCase = true) ||
                record.rootCause.contains("BROAD_QUERY", ignoreCase = true)
        }
        if (!noAccessionPressure) return emptyList()
        return listOf("GEO_GDS", "SRA_PRJNA", "IMM_PORT_SDY", "PUBMED_ACCESSION_MINING")
    }
}
