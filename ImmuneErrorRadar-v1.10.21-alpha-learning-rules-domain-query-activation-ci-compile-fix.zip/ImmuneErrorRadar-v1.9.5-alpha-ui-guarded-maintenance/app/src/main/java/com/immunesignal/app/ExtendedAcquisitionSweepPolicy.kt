package com.immunesignal.app

/**
 * v1.10.17: Extended acquisition source sweep.
 * v1.10.18: source sweep can include adjacent-domain/drug perturbation mining.
 *
 * v1.10.16 correctly made the thinking passes visible, but a stalled cycle could
 * still stop after one fast source-family attempt (for example IMM_PORT_SDY) and
 * immediately emit archive/reframe language. This policy makes the extended
 * budget operational: before archive/reframe is allowed, the dataset hunt must
 * attempt a small, bounded sweep across distinct accession-capable source
 * families. It does not weaken claim limits and it does not prove biology.
 */
object ExtendedAcquisitionSweepPolicy {
    const val CLAIM_LIMIT: String = "extended_acquisition_sweep_not_biological_proof"

    private val acquisitionOrder = listOf(
        "GEO_GDS",
        "SRA_PRJNA",
        "IMM_PORT_SDY",
        "PUBMED_ACCESSION_MINING",
        "PUBMED_ADJACENT_DOMAIN_MINING"
    )

    fun expandRoutes(
        routes: List<DirectDatasetSourceRouter.SourceRoute>,
        memory: PersistentFailureMemorySnapshot,
        evidenceFirstBudget: Boolean
    ): List<DirectDatasetSourceRouter.SourceRoute> {
        val networkRoutes = routes.filterNot { isArchiveRoute(it) }
        val archiveRoutes = routes.filter { isArchiveRoute(it) }
        val shouldSweep = evidenceFirstBudget || hasNoAccessionPressure(memory) || networkRoutes.size < RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES
        if (!shouldSweep) return routes

        val out = networkRoutes.toMutableList()
        val present = out.map { normalize(it.sourceFamily) }.toMutableSet()
        val startFamily = out.firstOrNull()?.sourceFamily
            ?: forcedSource(memory)
            ?: acquisitionOrder.first()
        val orderedFamilies = continuationOrder(startFamily)
        for (family in orderedFamilies) {
            if (out.size >= RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES) break
            if (family in present) continue
            val route = DirectDatasetSourceRouter.routeForSourceFamily(family) ?: continue
            out += route.copy(
                priority = route.priority + 30,
                reason = "v1.10.17 extended acquisition sweep: do not archive after a thin/fast dataset hunt. Attempt ${route.sourceFamily} as part of the bounded accession-source sweep before archive/reframe. ${route.reason}"
            )
            present += family
        }
        return (out + archiveRoutes).distinctBy { it.sourceFamily }
    }

    fun archiveAllowed(sourceFamiliesAttempted: List<String>, executedQueryCount: Int): Boolean {
        val sourceCount = sourceFamiliesAttempted
            .map { normalize(it) }
            .filter { it in acquisitionOrder }
            .distinct()
            .size
        return sourceCount >= RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES &&
            executedQueryCount >= RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_QUERY_PATHS
    }

    fun nextAction(sourceFamiliesAttempted: List<String>, executedQueryCount: Int): String {
        val sourceCount = sourceFamiliesAttempted
            .map { normalize(it) }
            .filter { it in acquisitionOrder }
            .distinct()
            .size
        val next = nextMissingFamily(sourceFamiliesAttempted)
        return "Continue accession sweep before archive/reframe: attemptedSources=$sourceCount/${RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES}, executedQueries=$executedQueryCount/${RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_QUERY_PATHS}; next source family=${next ?: "none"}."
    }

    private fun hasNoAccessionPressure(memory: PersistentFailureMemorySnapshot): Boolean = memory.records.any { record ->
        record.rootCause.contains("NO_DATASET_ACCESSION", ignoreCase = true) ||
            record.rootCause.contains("BROAD_QUERY", ignoreCase = true)
    }

    private fun forcedSource(memory: PersistentFailureMemorySnapshot): String? = memory.records
        .asSequence()
        .map { normalize(it.forcedNextSource) }
        .firstOrNull { it in acquisitionOrder }

    private fun continuationOrder(startFamily: String): List<String> {
        val normalizedStart = normalize(startFamily)
        val startIndex = acquisitionOrder.indexOf(normalizedStart).takeIf { it >= 0 } ?: 0
        return (0 until acquisitionOrder.size).map { offset -> acquisitionOrder[(startIndex + offset) % acquisitionOrder.size] }
    }

    private fun nextMissingFamily(sourceFamiliesAttempted: List<String>): String? {
        val attempted = sourceFamiliesAttempted.map { normalize(it) }.toSet()
        return acquisitionOrder.firstOrNull { it !in attempted }
    }

    private fun isArchiveRoute(route: DirectDatasetSourceRouter.SourceRoute): Boolean = normalize(route.sourceFamily) == "ARCHIVE_OR_REFRAME_ROUTE" || route.ncbiDb == "offline"

    private fun normalize(value: String): String = value.trim().uppercase()
}
