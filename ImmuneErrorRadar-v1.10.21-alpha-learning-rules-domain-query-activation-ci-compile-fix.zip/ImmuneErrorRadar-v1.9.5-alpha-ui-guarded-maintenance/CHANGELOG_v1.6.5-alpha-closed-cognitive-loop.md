# ImmuneErrorRadar v1.6.5-alpha-closed-cognitive-loop

## Goal
Close the cognitive loop so the integrated path is not only reported, but also carried into the next Search cycle as a bounded routing directive.

## Added
- `CognitiveNextCycleBridge.kt`
- `CognitiveNextCycleDirective`
- `CognitiveNextCyclePlan`
- Persistent next-cycle directive storage in `ResearchKnowledgeStore`
- Next-cycle query injection from the prior integrated cognitive path
- JSON export field: `cognitiveNextCyclePlan`
- UI brief: closed-loop summary and carried-forward search terms
- PDF section: closed cognitive loop for next cycle
- Test: `CognitiveNextCycleBridgeV165Test.kt`

## Behavior
- The prior cycle's `CognitivePathIntegrationReport.decision` is saved as a next-cycle directive.
- The next Search cycle reads that directive and adds one bounded follow-up query.
- The first base query is annotated with the integrated path terms.
- Expired directives are ignored.
- The directive is routing-only and cannot upgrade hypotheses, prove biology, or auto-update foundation JSON.

## Safety
- Claim limit: `next_cycle_routing_only_not_biological_proof`
- Blocked claims are carried with the directive.
- No medical, diagnostic, treatment, or biological-proof claims are introduced.
