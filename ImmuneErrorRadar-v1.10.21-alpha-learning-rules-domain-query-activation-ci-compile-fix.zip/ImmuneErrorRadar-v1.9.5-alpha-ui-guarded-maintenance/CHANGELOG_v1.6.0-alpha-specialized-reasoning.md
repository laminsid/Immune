# v1.6.0-alpha-specialized-reasoning

## Goal
Improve the project from a fast search/triage engine into a more specialized research reasoning engine that can outperform generic AI behavior in this narrow task: disciplined immune-research hypothesis handling.

## Added
- `SpecializedReasoningEngine.kt`
- `SpecializedReasoningReport`
- `SpecialistReasoningMove`
- Specialist score/state for each cycle.
- Weakest-link diagnosis.
- Decisive next-test selection.
- Explicit falsification demand.
- Axis contamination discipline.
- Generic-AI failure-risk detection.
- Expert move cards: competing explanations, discriminator evidence, failure-to-query learning, axis guard, falsification pressure, specialist score.

## Integrated
- `ResearchAutopilot` now runs specialized reasoning after standard reasoning and report V3 generation.
- `ResearchCycleReport` now carries `specializedReasoningReport`.
- `ResearchJsonCodec` exports specialized reasoning JSON.
- `DiscoveryReportExporter` writes a new specialized reasoning section.
- `ResearchAutopilotActivity` shows a simple specialist check in the user UI and learning mini-report.
- `EngineRuntimeStatus` now reports `v1.6.0-alpha-specialized-reasoning`.

## Boundary
This layer improves research routing and reasoning discipline only. It does not prove biology, diagnosis, treatment value, immune outcome, or causality.
