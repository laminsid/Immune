package com.immunesignal.app

import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

data class RouteFingerprint(
    val queryHash: String,
    val sourceFamilies: Set<String>,
    val queryIds: List<String>,
    val repeatedWithinLookback: Boolean
)

data class RouteFingerprintReport(
    val active: Boolean,
    val summary: String,
    val fingerprint: RouteFingerprint?,
    val claimLimit: String = RouteFingerprintGuard.CLAIM_LIMIT
)

/** v1.10.21: prevents semantic route replay from pretending to be progress. */
object RouteFingerprintGuard {
    const val CLAIM_LIMIT = "route_fingerprint_not_biological_proof"

    fun evaluate(queries: List<ResearchQuery>, recentReports: List<String>): RouteFingerprintReport {
        if (!RuntimeFeatureFlags.ENABLE_ROUTE_FINGERPRINT_GUARD || queries.isEmpty()) {
            return RouteFingerprintReport(false, "Route fingerprint guard not evaluated or no queries executed.", null)
        }
        val sourceFamilies = queries.mapNotNull { query ->
            Regex("q_v\d+_([a-z0-9_]+?)_(source|shard|creative)").find(query.id)?.groupValues?.getOrNull(1)
        }.map { it.uppercase(Locale.US) }.toSet()
        val normalizedQuery = queries.joinToString(" ") { it.query.lowercase(Locale.US).replace(Regex("\s+"), " ").take(240) }
        val hash = sha256(normalizedQuery).take(16)
        val recentHashes = recentReports.take(RuntimeFeatureFlags.ROUTE_FINGERPRINT_LOOKBACK).mapNotNull { line ->
            val report = runCatching { JSONObject(line) }.getOrNull() ?: return@mapNotNull null
            val qs = report.optJSONArray("queries") ?: return@mapNotNull null
            val text = buildString {
                for (i in 0 until qs.length()) {
                    val q = qs.optJSONObject(i) ?: continue
                    append(q.optString("query").lowercase(Locale.US).replace(Regex("\s+"), " ").take(240))
                    append(' ')
                }
            }
            if (text.isBlank()) null else sha256(text).take(16)
        }.toSet()
        val repeated = hash in recentHashes
        val fp = RouteFingerprint(hash, sourceFamilies, queries.map { it.id }.take(8), repeated)
        val summary = if (repeated) {
            "Route fingerprint repeated within last ${RuntimeFeatureFlags.ROUTE_FINGERPRINT_LOOKBACK} reports; require source-family or evidence-key change before rewarding progress."
        } else {
            "Route fingerprint is new within lookback; store hash=$hash for replay control."
        }
        return RouteFingerprintReport(true, summary, fp)
    }

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray())
        .joinToString("") { "%02x".format(it) }
}
