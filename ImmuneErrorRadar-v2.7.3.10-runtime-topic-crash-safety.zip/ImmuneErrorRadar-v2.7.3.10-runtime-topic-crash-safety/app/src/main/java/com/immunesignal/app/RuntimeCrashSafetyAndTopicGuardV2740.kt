package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.7.4 runtime survival + topic binding guard.
 *
 * Fixes the observed field issue where repeated searches could start, lose the
 * user's raw topic, fall back to a dynamic internal route, and then crash during
 * second-pass lookup/report assembly. This layer is local-only: it records the
 * submitted topic, keeps it visible in the report JSON, and converts runtime
 * failures into recoverable debug reports instead of allowing the Activity to close.
 */
data class ResearchTopicCaptureSnapshotV2740(
    val rawInput: String,
    val normalizedTopic: String,
    val diseaseOrPhenotype: List<String>,
    val triggerOrExposure: List<String>,
    val pathwayOrMediator: List<String>,
    val comparatorWanted: List<String>,
    val assayOrDataType: List<String>,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val captureState: String = if (rawInput.isBlank()) "TOPIC_NOT_CAPTURED" else "TOPIC_CAPTURED"
)

object RuntimeCrashSafetyAndTopicGuardV2740 {
    const val CLAIM_LIMIT: String = "runtime_crash_safety_and_topic_binding_not_biological_proof"

    fun capture(rawInput: String): ResearchTopicCaptureSnapshotV2740 {
        val normalized = ImmuneTopicPromptPolicy.normalizeTopic(rawInput)
        val intent = GTIMResearchIntentParserV255.parse(normalized)
        return ResearchTopicCaptureSnapshotV2740(
            rawInput = rawInput.take(1200),
            normalizedTopic = normalized,
            diseaseOrPhenotype = intent.diseasePhenotype,
            triggerOrExposure = intent.triggerExposure,
            pathwayOrMediator = intent.pathway,
            comparatorWanted = intent.comparatorWanted,
            assayOrDataType = intent.assayType,
            captureState = if (normalized.isBlank()) "TOPIC_NOT_CAPTURED" else "TOPIC_CAPTURED"
        )
    }

    fun fallbackSteering(snapshot: ResearchTopicCaptureSnapshotV2740?): ResearchSteeringProfile? {
        if (snapshot == null || snapshot.normalizedTopic.isBlank()) return null
        return ResearchSteeringProfile(
            profileId = "topic_snapshot_${snapshot.createdAtMillis}",
            createdAtMillis = snapshot.createdAtMillis,
            variables = listOf(snapshot.normalizedTopic) + listOf(
                "immune response",
                "inflammation",
                "cytokine",
                "dataset",
                "human cohort",
                "control comparator"
            ),
            focusQuestion = ImmuneTopicPromptPolicy.focusQuestion(snapshot.normalizedTopic),
            requiredTerms = listOf("immune", "inflammation", "dataset", "human", "outcome", "control"),
            excludedTerms = listOf("diagnosis", "treatment recommendation", "drug ranking", "dose"),
            inferredAxes = inferSnapshotAxes(snapshot)
        )
    }

    fun routeText(snapshot: ResearchTopicCaptureSnapshotV2740?): String {
        if (snapshot == null || snapshot.normalizedTopic.isBlank()) return ""
        return listOf(
            "User submitted topic: ${snapshot.normalizedTopic}",
            "Disease/phenotype: ${snapshot.diseaseOrPhenotype.joinToString(", ")}",
            "Trigger/exposure: ${snapshot.triggerOrExposure.joinToString(", ")}",
            "Pathway/mediator: ${snapshot.pathwayOrMediator.joinToString(", ")}",
            "Comparator: ${snapshot.comparatorWanted.joinToString(", ")}",
            "Assay/data: ${snapshot.assayOrDataType.joinToString(", ")}"
        ).joinToString(" | ")
    }

    fun toJson(snapshot: ResearchTopicCaptureSnapshotV2740?): JSONObject {
        if (snapshot == null) return JSONObject()
        return JSONObject()
            .put("version", "v2.7.4")
            .put("captureState", snapshot.captureState)
            .put("rawInput", snapshot.rawInput)
            .put("normalizedTopic", snapshot.normalizedTopic)
            .put("userQueryCaptured", snapshot.normalizedTopic.isNotBlank())
            .put("createdAtMillis", snapshot.createdAtMillis)
            .put("diseaseOrPhenotype", JSONArray(snapshot.diseaseOrPhenotype))
            .put("triggerOrExposure", JSONArray(snapshot.triggerOrExposure))
            .put("pathwayOrMediator", JSONArray(snapshot.pathwayOrMediator))
            .put("comparatorWanted", JSONArray(snapshot.comparatorWanted))
            .put("assayOrDataType", JSONArray(snapshot.assayOrDataType))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun annotateReport(report: JSONObject, snapshot: ResearchTopicCaptureSnapshotV2740?): JSONObject {
        if (snapshot != null) {
            report.put("topicCapture", toJson(snapshot))
            report.put("runtimeCrashSafety", JSONObject()
                .put("status", "COMPLETED_OR_PARTIAL_WITH_TOPIC_BOUND")
                .put("lastSafeStage", "REPORT_JSON_CREATED")
                .put("crashConvertedToReport", false)
                .put("claimLimit", CLAIM_LIMIT)
            )
        }
        return report
    }

    fun failureReport(
        snapshot: ResearchTopicCaptureSnapshotV2740?,
        stage: String,
        throwable: Throwable,
        elapsedMillis: Long
    ): JSONObject {
        val safeMessage = (throwable.message ?: "no message").take(500)
        return JSONObject()
            .put("schemaVersion", 217)
            .put("productMode", "Immune Error Radar Autonomous Global Immune Researcher")
            .put("id", "runtime_failure_${System.currentTimeMillis()}")
            .put("createdAtMillis", System.currentTimeMillis())
            .put("completedAtMillis", System.currentTimeMillis())
            .put("stoppedByUser", false)
            .put("stopReason", "recoverable_runtime_failure")
            .put("queries", JSONArray())
            .put("findings", JSONArray())
            .put("topicCapture", toJson(snapshot))
            .put("runtimeCrashSafety", JSONObject()
                .put("status", "RECOVERABLE_FAILURE_REPORT_CREATED")
                .put("lastSafeStage", stage)
                .put("elapsedMillis", elapsedMillis)
                .put("errorType", throwable::class.java.simpleName)
                .put("errorMessage", safeMessage)
                .put("crashConvertedToReport", true)
                .put("nextAction", "Retry with one simpler topic, then export this debug report if the same stage fails again.")
                .put("claimLimit", CLAIM_LIMIT)
            )
            .put("reportV3", JSONObject()
                .put("cycleResult", "Search stopped safely before completion")
                .put("newUsefulLead", "No scientific lead was created because runtime failed before evidence closure.")
                .put("hypothesisChanged", "No hypothesis changed.")
                .put("whyItMatters", "The app preserved the user topic and error stage instead of closing silently.")
                .put("nextAutonomousMove", "Retry with a simpler query or inspect the runtimeCrashSafety block.")
                .put("doNotBelieveYet", "No mechanism, causality, diagnosis, treatment, or evidence conclusion was made.")
                .put("integrityStatus", "RECOVERABLE_FAILURE_NO_EVIDENCE_CLAIM")
            )
            .put("limitations", JSONArray(listOf("Runtime failed before a complete research report was assembled.", CLAIM_LIMIT)))
    }

    fun renderFailureCard(report: JSONObject): String? {
        val crash = report.optJSONObject("runtimeCrashSafety") ?: return null
        if (!crash.optBoolean("crashConvertedToReport", false)) return null
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        return buildString {
            append("Search stopped safely\n")
            append("• User query captured: ").append(if (topic.optBoolean("userQueryCaptured", false)) "YES" else "NO").append("\n")
            append("• Raw query: ").append(topic.optString("normalizedTopic", "not captured").ifBlank { "not captured" }).append("\n")
            append("• Last completed stage: ").append(crash.optString("lastSafeStage", "unknown")).append("\n")
            append("• Error type: ").append(crash.optString("errorType", "unknown")).append("\n")
            append("• What happened: internal research lookup/report assembly failed, but the app preserved a debug report instead of closing silently.\n")
            append("• Next step: ").append(crash.optString("nextAction", "Retry with one simpler query.")).append("\n")
            append("• Boundary: no evidence, diagnosis, treatment, or mechanism claim was made.")
        }
    }

    private fun inferSnapshotAxes(snapshot: ResearchTopicCaptureSnapshotV2740): List<String> {
        val lower = listOf(
            snapshot.normalizedTopic,
            snapshot.diseaseOrPhenotype.joinToString(" "),
            snapshot.triggerOrExposure.joinToString(" "),
            snapshot.pathwayOrMediator.joinToString(" ")
        ).joinToString(" ").lowercase(Locale.US)
        val axes = mutableListOf<String>()
        if (lower.contains("microbiome") || lower.contains("gut") || lower.contains("intestinal")) axes += "gut_microbiome_barrier_axis"
        if (lower.contains("interferon") || lower.contains("viral") || lower.contains("covid") || lower.contains("hanta")) axes += "antiviral_interferon_axis"
        if (lower.contains("allergy") || lower.contains("ige") || lower.contains("mast")) axes += "type2_allergy_axis"
        if (lower.contains("autoimmune") || lower.contains("sle") || lower.contains("rheumatoid") || lower.contains("arthritis")) axes += "autoimmune_inflammation_axis"
        if (lower.contains("il-6") || lower.contains("tnf") || lower.contains("crp") || lower.contains("inflammation")) axes += "inflammatory_cytokine_axis"
        if (lower.contains("pesticide") || lower.contains("pfas") || lower.contains("microplastic") || lower.contains("heavy metal")) axes += "environmental_exposome_axis"
        return axes.distinct().ifEmpty { listOf("immune_topic_axis") }
    }
}
