package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

data class ResearchEngineReportV3(
    val topic: String,
    val status: ResearchRunStatusV3,
    val displayedEvidence: List<EvidenceNodeV3>,
    val countedEvidenceIds: List<String>,
    val executedObjectives: List<String>,
    val openGates: List<String>,
    val closure: ResearchClosureSnapshotV3,
    val openGapDiagnostics: List<ResearchGapV3> = emptyList(),
    val plannerTrace: List<String> = emptyList(),
    val checkpoint: ResearchCheckpointV3? = null,
    val hypothesisAssessment: ResearchHypothesisAssessmentV3 = ResearchHypothesisAssessmentV3.empty(),
    val sessionSnapshot: ResearchSessionSnapshotV3? = null,
    val finalQualityLock: ResearchFinalQualityLockSnapshotV3 = ResearchFinalQualityLockSnapshotV3(true, emptyList(), emptyList()),
    val readinessAssessment: ResearchReadinessAssessmentV3 = ResearchReadinessAssessmentV3.evaluate(ResearchStateV3.initial(ResearchInputV3(topic)), closure),
    val metadataProbeIngestion: ResearchMetadataProbeIngestionReportV3 = ResearchMetadataProbeIngestionReportV3.inactive(topic),
    val datasetModuleScore: ResearchDatasetModuleScoreCardV3 = ResearchDatasetModuleScoreCardV3.inactive("metadata_probe_not_available"),
    val hypothesisProofContinuation: ResearchHypothesisProofContinuationSnapshotV3 = ResearchHypothesisProofContinuationV3.evaluate(ResearchStateV3.initial(ResearchInputV3(topic))),
    val dossierLearningReceipt: ResearchDossierLearningReceiptV30324 = ResearchDossierLearningBridgeV30324.evaluate(ResearchStateV3.initial(ResearchInputV3(topic)), closure),
    val professionalReleaseGuard: ResearchProfessionalReleaseGuardSnapshotV30324 = ResearchProfessionalReleaseGuardV30324.evaluate(
        ResearchStateV3.initial(ResearchInputV3(topic)),
        closure,
        metadataProbeIngestion,
        datasetModuleScore,
        hypothesisProofContinuation,
        dossierLearningReceipt
    ),
    val globalFinalReadiness: ResearchGlobalFinalReadinessSnapshotV30327 = ResearchGlobalFinalReadinessV30327.evaluate(
        state = ResearchStateV3.initial(ResearchInputV3(topic)),
        closure = closure,
        professionalReleaseGuard = professionalReleaseGuard,
        dossierLearningReceipt = dossierLearningReceipt,
        proofContinuation = hypothesisProofContinuation,
        adaptiveBudget = ResearchAdaptiveRuntimeBudgetV30327.snapshotForEffectiveBudget(topic, ResearchBudgetV3())
    ),
    val contradictionTruth: ContradictionTruthStateV30328 = ContradictionTruthStateBuilderV30328.evaluate(ResearchStateV3.initial(ResearchInputV3(topic))),
    val mechanismModuleSignal: MechanismModuleSignalSnapshotV30328 = MechanismModuleSignalRunnerV30328.evaluate(
        ResearchStateV3.initial(ResearchInputV3(topic)),
        metadataProbeIngestion,
        datasetModuleScore
    ),
    val comparatorVariableExtraction: ComparatorVariableExtractionReportV30329 = ComparatorVariableExtractorV30329.evaluate(
        ResearchStateV3.initial(ResearchInputV3(topic)),
        metadataProbeIngestion
    ),
    val processedExpressionSignal: ProcessedExpressionSignalReportV30329 = ProcessedExpressionSignalExecutorV30329.evaluate(
        ResearchStateV3.initial(ResearchInputV3(topic)),
        metadataProbeIngestion,
        datasetModuleScore,
        comparatorVariableExtraction,
        mechanismModuleSignal
    ),
    val certifiedMatrixFuelGate: CertifiedMatrixFuelGateSnapshotV30332 = CertifiedMatrixFuelGateV30332.evaluate(processedExpressionSignal),
    val curatedHypothesisSeedV30335: CuratedHypothesisDiscoverySeedV30335 = CuratedHypothesisDiscoverySeedBuilderV30335.evaluate(
        topic,
        SpecialistRouterV30335.route(topic),
        processedExpressionSignal,
        certifiedMatrixFuelGate
    ),
    val pediatricOncologyLensV30338: PediatricOncologyTranslationLensV30338 = PediatricOncologyUnifiedFocusV30338.evaluate(
        topic,
        SpecialistRouterV30335.route(topic),
        processedExpressionSignal,
        certifiedMatrixFuelGate
    ),
    val humanPediatricMatrixTruthV30339: HumanPediatricMatrixTruthSnapshotV30339 = HumanPediatricMatrixTruthV30339.evaluate(
        topic,
        ResearchStateV3.initial(ResearchInputV3(topic)),
        processedExpressionSignal
    ),
    val humanPediatricDiscoveryV30340: HumanPediatricDiscoverySnapshotV30340 = HumanPediatricDiscoveryV30340.evaluate(
        topic,
        ResearchStateV3.initial(ResearchInputV3(topic)),
        closure,
        processedExpressionSignal,
        humanPediatricMatrixTruthV30339
    ),
    val crossDatasetSignal: CrossDatasetSignalReportV30329 = CrossDatasetSignalLinkerV30329.evaluate(
        ResearchStateV3.initial(ResearchInputV3(topic)),
        processedExpressionSignal
    ),
    val discoveryGapNovelty: DiscoveryGapNoveltyReportV30329 = DiscoveryGapNoveltyV30329.evaluate(
        ResearchStateV3.initial(ResearchInputV3(topic)),
        comparatorVariableExtraction,
        processedExpressionSignal,
        crossDatasetSignal
    ),
    val executedFalsifier: ExecutedFalsifierReportV30329 = ExecutedFalsifierV30329.evaluate(
        ResearchStateV3.initial(ResearchInputV3(topic)),
        contradictionTruth,
        comparatorVariableExtraction,
        processedExpressionSignal
    ),
    val professionalDiscoveryReport: ProfessionalDiscoveryReportV30329 = ProfessionalDiscoveryCardBuilderV30329.evaluate(
        ResearchStateV3.initial(ResearchInputV3(topic)),
        closure,
        comparatorVariableExtraction,
        processedExpressionSignal,
        discoveryGapNovelty,
        executedFalsifier,
        crossDatasetSignal
    ),
    val releaseReadinessContractV30329: ReleaseReadinessContractSnapshotV30329 = ReleaseReadinessContractV30329.evaluate(
        comparatorVariableExtraction,
        processedExpressionSignal,
        discoveryGapNovelty,
        crossDatasetSignal,
        executedFalsifier,
        professionalDiscoveryReport
    ),
    val hypothesisProofExecution: HypothesisProofExecutionSnapshotV30328 = HypothesisProofExecutorV30328.evaluate(
        ResearchStateV3.initial(ResearchInputV3(topic)),
        hypothesisProofContinuation,
        mechanismModuleSignal
    ),
    val runtimeBudgetTelemetry: RuntimeBudgetTelemetrySnapshotV30328 = RuntimeBudgetTelemetryV30328.evaluate(
        ResearchStateV3.initial(ResearchInputV3(topic)),
        closure
    ),
    val releaseReadinessContract: ReleaseReadinessContractSnapshotV30328 = ReleaseReadinessContractV30328.evaluate(
        contradictionTruth,
        hypothesisProofExecution,
        mechanismModuleSignal,
        runtimeBudgetTelemetry
    ),
    val specialistRouteV30335: SpecialistRouteV30335 = SpecialistRouterV30335.route(topic),
    val curatedCapsuleStoreV30335: JSONObject = CuratedDiseaseCapsuleStoreV30335.toJson(),
    val replayAudit: JSONObject = JSONObject(),
    val researchOnlyBoundary: String = ResearchCheckpointV3.RESEARCH_ONLY_BOUNDARY
) {
    fun displayedEvidenceEqualsLedger(): Boolean = displayedEvidence.map { it.id } == countedEvidenceIds

    fun toJson(): JSONObject = JSONObject()
        .put("topic", topic)
        .put("status", status.name)
        .put("displayedEvidenceIds", JSONArray(displayedEvidence.map { it.id }))
        .put("countedEvidenceIds", JSONArray(countedEvidenceIds))
        .put("displayedEqualsLedger", displayedEvidenceEqualsLedger())
        .put("executedObjectives", JSONArray(executedObjectives))
        .put("openGates", JSONArray(openGates))
        .put("openGapDiagnostics", ResearchGapDetectorV3.toJson(openGapDiagnostics))
        .put("plannerTrace", JSONArray(plannerTrace))
        .put("checkpoint", checkpoint?.toJson() ?: JSONObject())
        .put("hypothesisAssessment", hypothesisAssessment.toJson())
        .put("sessionSnapshot", sessionSnapshot?.toJson() ?: JSONObject())
        .put("finalQualityLock", finalQualityLock.toJson())
        .put("readinessAssessment", readinessAssessment.toJson())
        .put("metadataProbeIngestion", metadataProbeIngestion.toJson())
        .put("specialistRouteV30335", specialistRouteV30335.toJson())
        .put("curatedCapsuleStoreV30335", curatedCapsuleStoreV30335)
        .put("datasetModuleScore", datasetModuleScore.toJson())
        .put("hypothesisProofContinuation", hypothesisProofContinuation.toJson())
        .put("dossierLearningReceipt", dossierLearningReceipt.toJson())
        .put("professionalReleaseGuard", professionalReleaseGuard.toJson())
        .put("globalFinalReadiness", globalFinalReadiness.toJson())
        .put("contradictionTruth", contradictionTruth.toJson())
        .put("mechanismModuleSignal", mechanismModuleSignal.toJson())
        .put("comparatorVariableExtraction", comparatorVariableExtraction.toJson())
        .put("processedExpressionSignal", processedExpressionSignal.toJson())
        .put("certifiedMatrixFuelGate", certifiedMatrixFuelGate.toJson())
        .put("curatedHypothesisSeedV30335", curatedHypothesisSeedV30335.toJson())
        .put("pediatricOncologyLensV30338", pediatricOncologyLensV30338.toJson())
        .put("humanPediatricMatrixTruthV30339", humanPediatricMatrixTruthV30339.toJson())
        .put("humanPediatricDiscoveryV30340", humanPediatricDiscoveryV30340.toJson())
        .put("crossDatasetSignal", crossDatasetSignal.toJson())
        .put("discoveryGapNovelty", discoveryGapNovelty.toJson())
        .put("executedFalsifier", executedFalsifier.toJson())
        .put("professionalDiscoveryReport", professionalDiscoveryReport.toJson())
        .put("releaseReadinessContractV30329", releaseReadinessContractV30329.toJson())
        .put("hypothesisProofExecution", hypothesisProofExecution.toJson())
        .put("runtimeBudgetTelemetry", runtimeBudgetTelemetry.toJson())
        .put("releaseReadinessContract", releaseReadinessContract.toJson())
        .put("reportReadinessGrade", readinessAssessment.readinessGrade.name)
        .put("supportQuality", readinessAssessment.supportQuality.name)
        .put("replayAudit", replayAudit)
        .put("researchOnlyBoundary", researchOnlyBoundary)
        .put("closure", closure.toJson())
        .put("evidence", JSONArray(displayedEvidence.map { it.toJson() }))
}

class ResearchReportCompilerV3 {
    fun compile(state: ResearchStateV3, closure: ResearchClosureSnapshotV3): ResearchEngineReportV3 {
        val visible = state.ledgerSnapshot.visibleEvidence
        val sessionSnapshot = ResearchSessionSnapshotV3.fromState(state)
        val qualityLock = ResearchFinalQualityLockV3.evaluate(state, closure)
        val baseEffectiveClosure = if (qualityLock.passed) {
            closure
        } else {
            closure.copy(
                canCloseReport = false,
                openGates = (closure.openGates + "final_quality_lock_blocked").distinct()
            )
        }
        val effectiveClosure = AlphaGuardPolicyV30340.relaxClosureForHypothesisLab(state.input.topic, baseEffectiveClosure)
        val metadataProbe = ResearchMetadataProbeIngestionV3.evaluate(state)
        val specialistRouteV30335 = SpecialistRouterV30335.route(state.input.topic)
        val runtimeBudgetGate = ResearchRuntimeBudgetGateV30323.evaluate(state)
        val datasetModuleScore = if (runtimeBudgetGate.moduleScoreAllowed) {
            ResearchDatasetModuleScoreV3.evaluate(state, metadataProbe)
        } else {
            ResearchDatasetModuleScoreCardV3.pendingRuntimeBudget(runtimeBudgetGate)
        }
        val hypothesisProofContinuation = ResearchHypothesisProofContinuationV3.evaluate(state)
        val contradictionTruth = ContradictionTruthStateBuilderV30328.evaluate(state)
        val mechanismModuleSignal = MechanismModuleSignalRunnerV30328.evaluate(state, metadataProbe, datasetModuleScore)
        val comparatorVariableExtraction = ComparatorVariableExtractorV30329.evaluate(state, metadataProbe)
        // legacy audit marker only: MatrixFuelProviderV30330.collect
        val (matrixRowsV30330, matrixFuelV30330) = MatrixFuelProviderV30331.collect(
            state = state,
            metadataProbe = metadataProbe,
            datasetModuleScore = datasetModuleScore,
            comparatorVariables = comparatorVariableExtraction
        )
        val processedExpressionSignal = ProcessedExpressionSignalExecutorV30329.evaluate(
            state = state,
            metadataProbe = metadataProbe,
            datasetModuleScore = datasetModuleScore,
            comparatorVariables = comparatorVariableExtraction,
            mechanismSignal = mechanismModuleSignal,
            matrixRows = matrixRowsV30330,
            matrixFuel = matrixFuelV30330
        )
        val certifiedMatrixFuelGate = CertifiedMatrixFuelGateV30332.evaluate(processedExpressionSignal)
        val curatedHypothesisSeedV30335 = CuratedHypothesisDiscoverySeedBuilderV30335.evaluate(
            topic = state.input.topic,
            route = specialistRouteV30335,
            expressionSignal = processedExpressionSignal,
            certifiedGate = certifiedMatrixFuelGate
        )
        val pediatricOncologyLensV30338 = PediatricOncologyUnifiedFocusV30338.evaluate(
            topic = state.input.topic,
            specialistRoute = specialistRouteV30335,
            expressionSignal = processedExpressionSignal,
            certifiedGate = certifiedMatrixFuelGate
        )
        val humanPediatricMatrixTruthV30339 = HumanPediatricMatrixTruthV30339.evaluate(
            topic = state.input.topic,
            state = state,
            expressionSignal = processedExpressionSignal
        )
        val humanPediatricDiscoveryV30340 = HumanPediatricDiscoveryV30340.evaluate(
            topic = state.input.topic,
            state = state,
            closure = effectiveClosure,
            expressionSignal = processedExpressionSignal,
            truth = humanPediatricMatrixTruthV30339
        )
        val crossDatasetSignal = CrossDatasetSignalLinkerV30329.evaluate(state, processedExpressionSignal)
        val discoveryGapNovelty = DiscoveryGapNoveltyV30329.evaluate(
            state = state,
            comparatorVariables = comparatorVariableExtraction,
            expressionSignal = processedExpressionSignal,
            crossDataset = crossDatasetSignal
        )
        val executedFalsifier = ExecutedFalsifierV30329.evaluate(
            state = state,
            contradictionTruth = contradictionTruth,
            comparatorVariables = comparatorVariableExtraction,
            expressionSignal = processedExpressionSignal
        )
        val hypothesisProofExecution = HypothesisProofExecutorV30328.evaluate(state, hypothesisProofContinuation, mechanismModuleSignal)
        val runtimeBudgetTelemetry = RuntimeBudgetTelemetryV30328.evaluate(state, effectiveClosure, processedExpressionSignal)
        val releaseReadinessContract = ReleaseReadinessContractV30328.evaluate(
            contradictionTruth,
            hypothesisProofExecution,
            mechanismModuleSignal,
            runtimeBudgetTelemetry
        )
        val preliminaryDossierLearningReceipt = ResearchDossierLearningBridgeV30324.evaluate(state, effectiveClosure)
        val professionalReleaseGuard = ResearchProfessionalReleaseGuardV30324.evaluate(
            state = state,
            closure = effectiveClosure,
            metadataProbe = metadataProbe,
            datasetModuleScore = datasetModuleScore,
            proofContinuation = hypothesisProofContinuation,
            dossierLearningReceipt = preliminaryDossierLearningReceipt
        )
        val releaseEffectiveClosure = if (professionalReleaseGuard.passed) {
            effectiveClosure
        } else {
            // Only truly severe professional guard failures should be able to block a
            // report. Review warnings stay visible but must not recreate the over-strict
            // closure loop that v3.0.3.23 fixed.
            val severe = professionalReleaseGuard.blockers.any {
                it == "non_mammalian_or_plant_evidence_counted_as_support" ||
                    it == "report_ready_without_supporting_evidence"
            }
            if (severe) {
                effectiveClosure.copy(
                    canCloseReport = false,
                    openGates = (effectiveClosure.openGates + "professional_release_guard_blocked").distinct()
                )
            } else {
                effectiveClosure
            }
        }
        val readiness = ResearchReadinessAssessmentV3.evaluate(state, releaseEffectiveClosure)
        val dossierLearningReceipt = ResearchDossierLearningBridgeV30324.evaluate(state, releaseEffectiveClosure)
        val globalFinalReadiness = ResearchGlobalFinalReadinessV30327.evaluate(
            state = state,
            closure = releaseEffectiveClosure,
            professionalReleaseGuard = professionalReleaseGuard,
            dossierLearningReceipt = dossierLearningReceipt,
            proofContinuation = hypothesisProofContinuation,
            adaptiveBudget = ResearchAdaptiveRuntimeBudgetV30327.snapshotForEffectiveBudget(state.input.topic, state.input.budget)
        )
        val professionalDiscoveryReport = ProfessionalDiscoveryCardBuilderV30329.evaluate(
            state = state,
            closure = releaseEffectiveClosure,
            comparatorVariables = comparatorVariableExtraction,
            expressionSignal = processedExpressionSignal,
            gapNovelty = discoveryGapNovelty,
            falsifier = executedFalsifier,
            crossDataset = crossDatasetSignal
        )
        val releaseReadinessContractV30329 = ReleaseReadinessContractV30329.evaluate(
            comparatorVariables = comparatorVariableExtraction,
            expressionSignal = processedExpressionSignal,
            gapNovelty = discoveryGapNovelty,
            crossDataset = crossDatasetSignal,
            falsifier = executedFalsifier,
            professionalDiscovery = professionalDiscoveryReport
        )
        val status = when {
            !qualityLock.passed -> ResearchRunStatusV3.CHECKPOINT_FINAL_QUALITY_BLOCKED
            !professionalReleaseGuard.passed && releaseEffectiveClosure.openGates.contains("professional_release_guard_blocked") -> ResearchRunStatusV3.CHECKPOINT_FINAL_QUALITY_BLOCKED
            readiness.readinessGrade == ReportReadinessGradeV3.EXPERIMENTAL_HYPOTHESIS_READY_NOT_VALIDATED -> ResearchRunStatusV3.CHECKPOINT_READY
            releaseEffectiveClosure.canCloseReport -> ResearchRunStatusV3.REPORT_READY
            else -> ResearchRunStatusV3.CHECKPOINT_READY
        }
        return ResearchEngineReportV3(
            topic = state.input.topic,
            status = status,
            displayedEvidence = visible,
            countedEvidenceIds = state.ledgerSnapshot.visibleEvidenceIds,
            executedObjectives = state.ledgerSnapshot.executedObjectiveIds,
            openGates = releaseEffectiveClosure.openGates,
            closure = releaseEffectiveClosure,
            openGapDiagnostics = ResearchGapDetectorV3.detect(state),
            plannerTrace = state.ledgerSnapshot.objectiveOutcomes.flatMap { outcome ->
                outcome.notes.filter { it.startsWith("planner_decision:") || it.startsWith("open_gap:") }
            },
            checkpoint = if (status == ResearchRunStatusV3.REPORT_READY) null else ResearchCheckpointCompilerV3.compile(state, releaseEffectiveClosure),
            hypothesisAssessment = ResearchHypothesisScorerV3.score(
                state = state.copy(status = status),
                closure = releaseEffectiveClosure,
                metadataProbe = metadataProbe,
                datasetModuleScore = datasetModuleScore
            ),
            sessionSnapshot = sessionSnapshot,
            finalQualityLock = qualityLock,
            readinessAssessment = readiness,
            metadataProbeIngestion = metadataProbe,
            datasetModuleScore = datasetModuleScore,
            hypothesisProofContinuation = hypothesisProofContinuation,
            dossierLearningReceipt = dossierLearningReceipt,
            professionalReleaseGuard = professionalReleaseGuard,
            globalFinalReadiness = globalFinalReadiness,
            contradictionTruth = contradictionTruth,
            mechanismModuleSignal = mechanismModuleSignal,
            comparatorVariableExtraction = comparatorVariableExtraction,
            processedExpressionSignal = processedExpressionSignal,
            certifiedMatrixFuelGate = certifiedMatrixFuelGate,
            curatedHypothesisSeedV30335 = curatedHypothesisSeedV30335,
            pediatricOncologyLensV30338 = pediatricOncologyLensV30338,
            humanPediatricMatrixTruthV30339 = humanPediatricMatrixTruthV30339,
            humanPediatricDiscoveryV30340 = humanPediatricDiscoveryV30340,
            crossDatasetSignal = crossDatasetSignal,
            discoveryGapNovelty = discoveryGapNovelty,
            executedFalsifier = executedFalsifier,
            professionalDiscoveryReport = professionalDiscoveryReport,
            releaseReadinessContractV30329 = releaseReadinessContractV30329,
            hypothesisProofExecution = hypothesisProofExecution,
            runtimeBudgetTelemetry = runtimeBudgetTelemetry,
            releaseReadinessContract = releaseReadinessContract,
            specialistRouteV30335 = specialistRouteV30335,
            curatedCapsuleStoreV30335 = CuratedDiseaseCapsuleStoreV30335.toJson(),
            replayAudit = ResearchSnapshotReplayV3.replayAudit(JSONObject()
                .put("sessionSnapshot", sessionSnapshot.toJson())
                .put("evidence", JSONArray(visible.map { it.toJson() }))
                .put("closure", releaseEffectiveClosure.toJson()))
        )
    }
}
