package com.immunesignal.app

/**
 * v1.10.33: Release version linkage guard kept mandatory for lean runtime release.
 *
 * This guard is intentionally small: it keeps release identity auditable across
 * Gradle, runtime status, learning-session schema, report labels, documentation,
 * and static checks. It does not affect scientific interpretation.
 */
object ReleaseVersionLinkageGuard {
    const val VERSION_CODE: Int = 95
    const val VERSION_NAME: String = "1.10.33-alpha-lean-agent-runtime"
    const val ENGINE_VERSION: String = "v1.10.33-alpha-lean-agent-runtime"
    const val LEARNING_SCHEMA_VERSION: String = "1.10.33"
    const val CLAIM_LIMIT: String = "release_version_linkage_not_biological_proof"

    fun summary(): String =
        "v1.10.33 release version linkage: build, engine, learning schema, evidence-lead/manual-seed, mature-domain focus, lean runtime reports, docs, and static checks are aligned; legacy tokens remain audit-only."

    fun isRuntimeAligned(): Boolean =
        EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ENGINE_VERSION &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == LEARNING_SCHEMA_VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == VERSION_NAME &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == VERSION_CODE
}
