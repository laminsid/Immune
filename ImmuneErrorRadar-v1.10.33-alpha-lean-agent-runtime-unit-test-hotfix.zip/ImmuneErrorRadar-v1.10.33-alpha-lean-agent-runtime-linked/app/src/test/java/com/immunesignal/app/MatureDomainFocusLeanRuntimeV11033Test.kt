package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MatureDomainFocusLeanRuntimeV11033Test {
    private fun histamineCard() = DomainExpertiseMemoryPolicy.DomainExpertiseCard(
        domainId = "antihistamine_histamine_mast_cell",
        label = "Histamine mast-cell",
        expertiseState = "MATURE_DOMAIN_PRIOR_NEEDS_FALSIFICATION",
        expertiseScore = 72,
        stableResearchPriors = listOf("search prior only"),
        workingVocabulary = listOf("histamine", "mast cell", "urticaria"),
        protectedFromReset = listOf("do not reset"),
        falsificationGates = listOf("control/comparator", "outcome labels", "human cohort"),
        nextLearningAction = "focused dataset probe",
        priorExposureCount = 3
    )

    private fun domainReport() = DomainExpertiseMemoryPolicy.DomainExpertiseReport(
        active = true,
        mode = DomainExpertiseMemoryPolicy.MODE,
        summary = "mature histamine domain",
        cards = listOf(histamineCard()),
        stablePriorCount = 1,
        protectedBeliefCount = 1,
        carriedForwardDomainCount = 1,
        matureDomainCount = 1,
        continuityState = "MATURE_DOMAIN_EXPERTISE_ACTIVE",
        continuitySummary = "test",
        nextAction = "focus"
    )

    @Test
    fun manualSeedCreatesLeadObjectBeforeEvidence() {
        val manual = EvidenceLeadAndManualSeedPolicy.fromManualTexts(listOf("Manual seed GSE333333 histamine mast cell cohort"))
        val attempt = EvidenceLeadAndManualSeedPolicy.manualSeedAttempt(manual)
        val leads = EvidenceLeadAndManualSeedPolicy.toLeadObjects(manual, manual.candidates.map { it.candidate }, listOfNotNull(attempt))

        assertTrue(leads.isNotEmpty())
        assertTrue(leads.any { it.detectedAccessions.contains("GSE333333") })
        assertTrue(leads.all { it.claimLimit == "lead_only_not_evidence" })
    }

    @Test
    fun matureDomainFocusPersistsAsRoutingPrior() {
        val focus = MatureDomainFocusModePolicy.evaluate(
            domainReport = domainReport(),
            attempts = emptyList(),
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            recentReports = emptyList()
        )

        assertTrue(focus.active)
        assertEquals("antihistamine_histamine_mast_cell", focus.selectedDomain)
        assertEquals(3, focus.focusCycleWindow)
        assertTrue(focus.querySeed.contains("histamine"))
        assertTrue(focus.claimLimit.contains("not_biological_proof"))
    }

    @Test
    fun domainSpecificKillCriteriaDoesNotArchiveGlobalResearch() {
        val focus = MatureDomainFocusModePolicy.evaluate(domainReport(), emptyList(), emptyList(), emptyList(), emptyList())
        val attempts = listOf(
            DatasetSourceAttempt(MatureDomainEvidenceProbePolicy.SOURCE_FAMILY, "pubmed", "unrelated query", true, 0, 0, "NO_IDS", "test"),
            DatasetSourceAttempt(MatureDomainEvidenceProbePolicy.SOURCE_FAMILY, "pubmed", "unrelated query 2", true, 0, 0, "NO_IDS", "test"),
            DatasetSourceAttempt(MatureDomainEvidenceProbePolicy.SOURCE_FAMILY, "pubmed", "unrelated query 3", true, 0, 0, "NO_IDS", "test")
        )
        val kill = MatureDomainFocusModePolicy.killCriteria(focus, attempts, emptyList(), emptyList())

        assertTrue(kill.active)
        assertTrue(kill.killTriggered)
        assertTrue(kill.nextAction.contains("Cool down this focus domain"))
        assertTrue(kill.nextAction.contains("do not archive global", ignoreCase = true))
    }

    @Test
    fun knowledgeGapQueueRoutesOpenOutcomeAndMetadataGaps() {
        val focus = MatureDomainFocusModePolicy.evaluate(domainReport(), emptyList(), emptyList(), emptyList(), emptyList())
        val gaps = MatureDomainFocusModePolicy.gapQueue(focus, emptyList(), emptyList(), emptyList())

        assertEquals("OPEN_GAPS_ROUTABLE", gaps.queueState)
        assertTrue(gaps.items.any { it.gapId == "outcome_labels" })
        assertTrue(gaps.items.first().nextQuery.isNotBlank())
    }

    @Test
    fun strongRouteFingerprintBlocksSemanticReplayShape() {
        val focus = MatureDomainFocusModePolicy.evaluate(domainReport(), emptyList(), emptyList(), emptyList(), emptyList())
        val gaps = MatureDomainFocusModePolicy.gapQueue(focus, emptyList(), emptyList(), emptyList())
        val query = ResearchQuery("q_test", "test", "histamine mast cell GSE outcome control cohort", "test")
        val attempt = DatasetSourceAttempt("GEO_DIRECT", "gds", query.query, true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test")
        val fp = MatureDomainFocusModePolicy.strongFingerprint(listOf(query), listOf(attempt), focus, gaps, emptyList())

        assertTrue(fp.active)
        assertEquals("mature_domain_focus_probe", fp.intent)
        assertEquals("antihistamine_histamine_mast_cell", fp.domain)
        assertTrue(fp.fingerprint.isNotBlank())
    }

    @Test
    fun leanRuntimeRunsOnlyNeededMicroAgentsAndHardGates() {
        val focus = MatureDomainFocusModePolicy.evaluate(domainReport(), emptyList(), emptyList(), emptyList(), emptyList())
        val gaps = MatureDomainFocusModePolicy.gapQueue(focus, emptyList(), emptyList(), emptyList())
        val runtime = LeanAgentRuntimePolicy.emit(
            leadObjects = emptyList(),
            focus = focus,
            gaps = gaps,
            fingerprint = StrongRouteFingerprintReport.empty(),
            finalState = "DATASET_FORAGING_CONTINUE_PROBE",
            nextAction = "continue focused probe"
        )

        assertTrue(runtime.active)
        assertTrue(runtime.microAgentsRun.contains("DomainExpertiseUpdater"))
        assertTrue(runtime.hardGatesApplied.contains("archive_allowed_gate"))
        assertTrue(runtime.compactDecisionCard.contains("DATASET_FORAGING_CONTINUE_PROBE"))
    }
}
