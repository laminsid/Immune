package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EvidenceLeadManualSeedV11031Test {
    @Test
    fun manualSeedCreatesLeadOnlyCandidate() {
        val report = EvidenceLeadAndManualSeedPolicy.fromManualTexts(
            listOf("PMID 12345678 reports data availability with GSE999999 for histamine mast cell cohort")
        )

        assertEquals("MANUAL_EVIDENCE_SEED_MODE", report.mode)
        assertTrue(report.candidates.any { it.seedValue == "GSE999999" })
        assertTrue(report.candidates.all { it.candidate.status == "LEAD_ONLY_NOT_EVIDENCE" })
        assertTrue(report.candidates.all { it.claimLimit == "lead_only_not_evidence" })
    }

    @Test
    fun weakDatasetLeadIsStoredButNotUpgraded() {
        val seed = EvidenceLeadAndManualSeedPolicy.fromManualTexts(listOf("Dataset accession PRJNA765432 needs metadata."))
        val relaxation = EvidenceLeadAndManualSeedPolicy.relax(seed.candidates.map { it.candidate })

        assertEquals("WEAK_LEADS_PRESERVED_NOT_UPGRADED", relaxation.state)
        assertEquals(1, relaxation.relaxedLeadCount)
        assertEquals("PRJNA765432", relaxation.leadAccessions.first())
        assertFalse(relaxation.reason.contains("EvidenceObject"))
    }

    @Test
    fun reportConsistencyPreventsArchiveProbeConflict() {
        val guarded = ReportConsistencyGuard.preventArchiveProbeConflict(
            foragerState = "DATASET_FORAGING_NO_ACCESSION_ARCHIVE_ROUTE",
            foragerNextAction = "Archive route.",
            nextProbeExists = true
        )

        assertEquals("DATASET_FORAGING_CONTINUE_PROBE", guarded.first)
        assertTrue(guarded.second.contains("continue_probe"))
    }

    @Test
    fun breakthroughKeepsNearMissSeparateFromEvidence() {
        val attempt = DatasetSourceAttempt(
            sourceFamily = "GEO_GDS",
            ncbiDb = "gds",
            query = "histamine mast cell GSE outcome control cohort",
            attempted = true,
            idsFound = 3,
            candidatesExtracted = 0,
            status = "METADATA_FOUND_NO_ACCESSION",
            reason = "test"
        )
        val accession = AccessionAcquisitionReport(
            active = true,
            state = "NO_ACCESSION_CONTINUE_SOURCE_SWEEP",
            explicitAccessions = emptyList(),
            weakAccessions = emptyList(),
            unresolvedLeadCount = 0,
            archiveRecommended = false,
            compactReportRecommended = true,
            nextAction = "continue",
            reasons = listOf("test")
        )
        val report = EvidenceLeadAndManualSeedPolicy.breakthrough(
            candidates = emptyList(),
            attempts = listOf(attempt),
            manualSeedReport = ManualEvidenceSeedReport.empty(),
            relaxationReport = DatasetLeadRelaxationReport.empty(),
            accessionReport = accession
        )

        assertEquals("NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION", report.state)
        assertEquals("none", report.bestLead)
        assertTrue(report.postPubMedSearchStrategies.any { it.contains("GEO direct term search") })
    }
    @Test
    fun manualSeedAttemptIsRecordedAsForagerAttempt() {
        val report = EvidenceLeadAndManualSeedPolicy.fromManualTexts(
            listOf("Manual seed GSE123456 should enter the forager path.")
        )
        val attempt = EvidenceLeadAndManualSeedPolicy.manualSeedAttempt(report)

        assertTrue(EvidenceLeadAndManualSeedPolicy.hasManualSeedSignal(listOf("PMID: 12345678 with GSE123456")))
        assertEquals("MANUAL_EVIDENCE_SEED_MODE", attempt?.sourceFamily)
        assertEquals("manual", attempt?.ncbiDb)
        assertEquals("MANUAL_SEED_CANDIDATES_IMPORTED", attempt?.status)
        assertEquals(1, attempt?.candidatesExtracted)
    }

    @Test
    fun evidenceLeadPathLinkageConnectsManualSeedRelaxationBreakthroughAndDecision() {
        val manual = EvidenceLeadAndManualSeedPolicy.fromManualTexts(listOf("GSE222222 histamine cohort"))
        val candidates = manual.candidates.map { it.candidate }
        val attempts = listOfNotNull(EvidenceLeadAndManualSeedPolicy.manualSeedAttempt(manual))
        val relaxation = EvidenceLeadAndManualSeedPolicy.relax(candidates)
        val breakthrough = EvidenceLeadAndManualSeedPolicy.breakthrough(
            candidates = candidates,
            attempts = attempts,
            manualSeedReport = manual,
            relaxationReport = relaxation,
            accessionReport = AccessionAcquisitionReport.empty()
        )
        val linkage = EvidenceLeadAndManualSeedPolicy.linkage(
            manualSeedReport = manual,
            relaxationReport = relaxation,
            breakthroughReport = breakthrough,
            attempts = attempts,
            candidates = candidates,
            finalForagerState = "DATASET_FORAGING_WEAK_DATASET_LEAD_FOUND",
            finalForagerNextAction = breakthrough.nextAction,
            guardedForagerState = "DATASET_FORAGING_WEAK_DATASET_LEAD_FOUND",
            guardedForagerNextAction = breakthrough.nextAction
        )

        assertEquals("EVIDENCE_LEAD_PATHS_CONNECTED", linkage.state)
        assertTrue(linkage.manualSeedLinkedToForager)
        assertTrue(linkage.weakLeadLinkedToRelaxation)
        assertTrue(linkage.breakthroughLinkedToDecision)
        assertTrue(linkage.consistencyGuardApplied)
        assertTrue(linkage.warnings.isEmpty())
    }

}
