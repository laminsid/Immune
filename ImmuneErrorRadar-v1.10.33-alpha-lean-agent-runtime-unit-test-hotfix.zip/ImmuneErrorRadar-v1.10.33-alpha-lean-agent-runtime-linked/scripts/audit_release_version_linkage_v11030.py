#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.30 file: {rel}')
    return p.read_text(errors='replace')

checks = {
    'app/build.gradle.kts': [
        'versionName = "1.10.33-alpha-lean-agent-runtime"',
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.10.33-alpha-lean-agent-runtime',
        'ReleaseVersionLinkageGuard',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.33"',
        'ENABLE_RELEASE_VERSION_LINKAGE_GUARD',
        'RELEASE_TRAIN_VERSION_NAME: String = "1.10.33-alpha-lean-agent-runtime"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 95',
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'ReleaseVersionLinkageGuard',
        'VERSION_CODE: Int = 95',
        'VERSION_NAME: String = "1.10.33-alpha-lean-agent-runtime"',
        'ENGINE_VERSION: String = "v1.10.33-alpha-lean-agent-runtime"',
        'LEARNING_SCHEMA_VERSION: String = "1.10.33"',
        'release_version_linkage_not_biological_proof',
        'isRuntimeAligned',
    ],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': [
        'StaticRuntimeModule("ReleaseVersionLinkageGuard", "integrity")',
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'release guard v1.10.33',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'Learning/Domain Path Linkage',
        'ReleaseVersionLinkageGuard.CLAIM_LIMIT',
        'ReleaseVersionLinkageGuard.CLAIM_LIMIT',
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'release guard v1.10.33',
    ],
    'docs/RELEASE_VERSION_LINKAGE_v1.10.30.md': [
        'v1.10.30',
        'Release Version Linkage',
        'GitHub safety checklist',
        'Dataset path/pass coverage linkage',
    ],
    'docs/CHANGELOG_v1.10.30.md': [
        '1.10.30-alpha-release-version-linkage-docs',
        'v1.10.29 learning/domain path linkage',
    ],
}

for rel, tokens in checks.items():
    text = read(rel)
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.30 token: {token}')

run_checks = read('scripts/run_static_checks.sh')
for token in [
    '1.10.33-alpha-lean-agent-runtime',
    'audit_release_version_linkage_v11031.py',
]:
    if token not in run_checks:
        raise SystemExit(f'run_static_checks.sh missing v1.10.30 token: {token}')

print('v1.10.30 release version linkage audit: PASS (current v1.10.33 compatible)')
