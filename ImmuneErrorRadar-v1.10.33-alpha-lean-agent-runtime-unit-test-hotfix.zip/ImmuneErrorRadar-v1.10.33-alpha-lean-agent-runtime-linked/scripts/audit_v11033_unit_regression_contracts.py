from pathlib import Path

root = Path('app/src/main/java/com/immunesignal/app')
linkage = (root / 'DatasetForagingPathLinkageGuard.kt').read_text(errors='replace')
focus = (root / 'MatureDomainFocusAndLeanRuntime.kt').read_text(errors='replace')

required_linkage = [
    'val matureProbeExposedInFinalState = foragerState.contains("MATURE_DOMAIN", ignoreCase = true)',
    'val matureProbeExposedInNextAction = foragerNextAction.contains("mature", ignoreCase = true)',
    'accessionReport.state == "NO_ACCESSION_ARCHIVE_ROUTE" && matureProbeReport.active && (!matureProbeExposedInFinalState || !matureProbeExposedInNextAction)',
]
for token in required_linkage:
    if token not in linkage:
        raise SystemExit(f'v1.10.33 regression contract missing in DatasetForagingPathLinkageGuard.kt: {token}')

intent_block = '''val intent = when {
            focus.active -> "mature_domain_focus_probe"
            gapQueue.items.any { it.gapId == "outcome_labels" } -> "outcome_label_probe"
            else -> "dataset_lead_foraging"
        }'''
if intent_block not in focus:
    raise SystemExit('v1.10.33 regression contract failed: mature-domain focus must take priority over outcome-gap intent in strongFingerprint().')

print('v1.10.33 unit regression contract audit: PASS')
