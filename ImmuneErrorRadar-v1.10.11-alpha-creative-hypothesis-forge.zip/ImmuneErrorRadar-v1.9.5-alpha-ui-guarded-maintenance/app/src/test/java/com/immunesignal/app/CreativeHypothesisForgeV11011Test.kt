package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CreativeHypothesisForgeV11011Test {
    private val shard = TestableHypothesisShard(
        shardId = "s1",
        label = "viral immune recovery route",
        evidenceQuestion = "Which human cohort separates recovery severity and response?",
        querySeeds = listOf("viral", "interferon", "recovery", "severity", "control")
    )

    @Test
    fun forgeDoesNotRunAfterSingleWeakFailure() {
        val report = CreativeHypothesisForge.build(
            sourceFamiliesAttempted = listOf("GEO_GDS"),
            noCandidateLearningRecords = listOf(record("GEO_GDS", "SRA_PRJNA")),
            shards = listOf(shard),
            candidates = emptyList()
        )
        assertFalse(report.active)
        assertEquals("creative_hypothesis_not_evidence", report.claimLimit)
    }

    @Test
    fun forgeGeneratesCreativeHypothesesAfterRepeatedNoCandidate() {
        val report = CreativeHypothesisForge.build(
            sourceFamiliesAttempted = listOf("IMM_PORT_SDY", "PUBMED_ACCESSION_MINING"),
            noCandidateLearningRecords = listOf(
                record("IMM_PORT_SDY", "PUBMED_CONTRADICTION"),
                record("PUBMED_ACCESSION_MINING", "PUBMED_CONTRADICTION")
            ),
            shards = listOf(shard),
            candidates = emptyList()
        )
        assertTrue(report.active)
        assertEquals("FORGE_AFTER_REPEATED_NO_CANDIDATE", report.state)
        assertTrue(report.generated.any { it.hypothesisId == "creative:outcome_pattern_first" })
        assertTrue(report.selectedQuery.contains("responder", ignoreCase = true))
        assertEquals("creative_hypothesis_not_evidence", report.generated.first().claimLimit)
    }

    @Test
    fun forgeDoesNotOverrideExistingCandidateEvidence() {
        val candidate = DatasetAccessionCandidate(
            accession = "GSE123",
            source = "GEO_GDS",
            organismHint = "human",
            conditionLabelsHint = "condition",
            outcomeLabelsHint = "outcome",
            triggerResponseOutcomeHint = "trigger-response-outcome",
            timeCourseHint = "longitudinal",
            sampleSizeHint = "unknown",
            dataType = "RNA-seq",
            usabilityScore = 70,
            status = "DATASET_CANDIDATE",
            sourceFindingId = "GSE123",
            sourceTitle = "dataset",
            sourceUrl = "https://example.test",
            reasons = listOf("test")
        )
        val report = CreativeHypothesisForge.build(
            sourceFamiliesAttempted = listOf("GEO_GDS", "SRA_PRJNA"),
            noCandidateLearningRecords = emptyList(),
            shards = listOf(shard),
            candidates = listOf(candidate)
        )
        assertFalse(report.active)
    }

    @Test
    fun terminalArchiveCanTriggerReframeHypothesis() {
        val report = CreativeHypothesisForge.build(
            sourceFamiliesAttempted = listOf("ARCHIVE_OR_REFRAME_ROUTE"),
            noCandidateLearningRecords = emptyList(),
            shards = listOf(shard),
            candidates = emptyList(),
            terminalArchiveRequested = true
        )
        assertTrue(report.active)
        assertEquals("FORGE_AFTER_SOURCE_EXHAUSTION", report.state)
        assertTrue(report.killCriteria.isNotEmpty())
    }

    private fun record(source: String, next: String) = NoCandidateLearningRecord(
        sourceFamily = source,
        queryId = "q_$source",
        status = "NO_CANDIDATE",
        missing = "accession_like_id",
        nextPreferredSource = next,
        reason = "test"
    )
}
