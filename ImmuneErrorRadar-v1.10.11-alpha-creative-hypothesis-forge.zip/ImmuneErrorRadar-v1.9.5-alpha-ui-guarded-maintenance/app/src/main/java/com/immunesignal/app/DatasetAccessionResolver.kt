package com.immunesignal.app

import java.util.Locale

/** v1.3.7: turns papers/metadata into concrete dataset-accession candidates. */
object DatasetAccessionResolver {
    private val accessionRegex = Regex(
        """\b(GSE\d+|GSM\d+|GDS\d+|SDY\d+|PRJNA\d+|SRP\d+|SRA\d+|SRR\d+|ERR\d+|DRR\d+|ERP\d+|DRP\d+|E-MTAB-\d+|EGAS\d+)\b""",
        RegexOption.IGNORE_CASE
    )
    private val sampleRegex = Regex("""\b(n\s*=\s*\d+|\d+\s+(patients|subjects|samples|donors|cases|controls))\b""", RegexOption.IGNORE_CASE)

    fun fromFindings(findings: List<ResearchFinding>): List<DatasetAccessionCandidate> {
        return findings
            .flatMap { finding -> fromFinding(finding) }
            .distinctBy { it.accession + ":" + it.sourceFindingId }
            .sortedByDescending { it.usabilityScore }
    }

    fun fromFinding(finding: ResearchFinding): List<DatasetAccessionCandidate> {
        val text = listOf(
            finding.sourceId,
            finding.url,
            finding.title,
            finding.bridgeSignal,
            finding.whyItMatters,
            finding.evidence.studyDesign,
            finding.evidence.sourceClass,
            finding.evidence.limitations.joinToString(" "),
            finding.sanityFlags.joinToString(" ")
        ).joinToString(" ")
        return extract(
            text = text,
            sourceFindingId = finding.source + ":" + finding.sourceId,
            sourceTitle = finding.title,
            sourceUrl = finding.url
        )
    }


    /**
     * v1.10.10: lower strictness only at the capture layer.
     *
     * PubMed contradiction/control/accession-mining records often do not expose
     * explicit GSE/SDY/PRJNA identifiers in summary metadata, but they can still
     * be useful as a bounded lead if they contain human/outcome/control/time or
     * reusable-data wording. These unresolved leads are deliberately returned as
     * DATASET_ACCESSION_UNRESOLVED, so they cannot upgrade hypotheses or become
     * EvidenceObjects; they only prevent the autonomous loop from throwing away
     * a potentially useful next inspection target.
     */
    fun fromExploratoryFindings(
        findings: List<ResearchFinding>,
        sourceFamily: String,
        query: ResearchQuery
    ): List<DatasetAccessionCandidate> {
        if (!sourceFamily.startsWith("PUBMED")) return emptyList()
        return findings
            .flatMap { finding ->
                val text = listOf(
                    sourceFamily,
                    query.query,
                    query.reason,
                    finding.sourceId,
                    finding.url,
                    finding.title,
                    finding.bridgeSignal,
                    finding.whyItMatters,
                    finding.evidence.studyDesign,
                    finding.evidence.sourceClass,
                    finding.evidence.limitations.joinToString(" "),
                    finding.sanityFlags.joinToString(" ")
                ).joinToString(" ")
                val extracted = extract(
                    text = text,
                    sourceFindingId = finding.source + ":" + finding.sourceId,
                    sourceTitle = finding.title,
                    sourceUrl = finding.url
                )
                extracted.filter { candidate ->
                    candidate.accession == "DATASET_ACCESSION_UNRESOLVED" && candidate.usabilityScore >= 35
                }.map { candidate ->
                    candidate.copy(
                        status = "EXPLORATORY_LEAD_NEEDS_ACCESSION",
                        reasons = (candidate.reasons + listOf(
                            "v1.10.10 exploratory capture: retained as a weak lead only; accession still unresolved.",
                            "Claim gate: cannot upgrade hypothesis, causality, or evidence object without explicit accession/metadata closure."
                        )).distinct()
                    )
                }
            }
            .distinctBy { it.accession + ":" + it.sourceFindingId }
            .sortedByDescending { it.usabilityScore }
            .take(8)
    }

    fun extract(
        text: String,
        sourceFindingId: String = "manual",
        sourceTitle: String = "",
        sourceUrl: String = ""
    ): List<DatasetAccessionCandidate> {
        val lower = text.lowercase(Locale.US)
        val explicit = accessionRegex.findAll(text)
            .map { it.value.uppercase(Locale.US).replace(" ", "") }
            .distinct()
            .toList()
        val hasDatasetSignal = listOf(
            "geo", "dataset", "rna-seq", "rnaseq", "transcriptomic", "single-cell", "scrna-seq",
            "immport", "sra", "sequence read archive", "cohort", "longitudinal", "time course",
            "phenotype labels", "sample metadata", "expression matrix", "supplementary data", "public data"
        ).any { lower.contains(it) }
        val hasExploratoryLeadSignal = listOf("human", "patient", "clinical", "cohort", "donor", "subjects").any { lower.contains(it) } &&
            listOf("immune", "inflammation", "cytokine", "transcriptomic", "rna-seq", "single-cell", "pbmc", "antibody", "interferon").any { lower.contains(it) } &&
            listOf("outcome", "severity", "recovery", "response", "nonresponse", "control", "comparator", "placebo", "baseline", "longitudinal", "follow-up").any { lower.contains(it) }
        val ids = when {
            explicit.isNotEmpty() -> explicit
            hasDatasetSignal || hasExploratoryLeadSignal -> listOf("DATASET_ACCESSION_UNRESOLVED")
            else -> emptyList()
        }
        return ids.map { accession ->
            val organism = inferOrganism(lower)
            val condition = inferConditionLabels(lower)
            val outcome = inferOutcomeLabels(lower)
            val tro = inferTriggerResponseOutcome(lower)
            val time = inferTimeCourse(lower)
            val sample = sampleRegex.find(text)?.value ?: "unknown"
            val dataType = inferDataType(lower)
            val score = DatasetCandidateScorer.score(
                accession = accession,
                organismHint = organism,
                conditionLabelsHint = condition,
                outcomeLabelsHint = outcome,
                triggerResponseOutcomeHint = tro,
                timeCourseHint = time,
                sampleSizeHint = sample,
                dataType = dataType
            )
            DatasetAccessionCandidate(
                accession = accession,
                source = inferSource(accession, lower),
                organismHint = organism,
                conditionLabelsHint = condition,
                outcomeLabelsHint = outcome,
                triggerResponseOutcomeHint = tro,
                timeCourseHint = time,
                sampleSizeHint = sample,
                dataType = dataType,
                usabilityScore = score.score,
                status = when {
                    accession == "DATASET_ACCESSION_UNRESOLVED" && score.score >= 35 -> "EXPLORATORY_LEAD_NEEDS_ACCESSION"
                    accession == "DATASET_ACCESSION_UNRESOLVED" -> "MENTIONED_BUT_UNRESOLVED"
                    score.score >= 70 -> "USABLE_LEAD_NEEDS_INSPECTION"
                    score.score >= 45 -> "PARTIAL_LEAD_NEEDS_METADATA"
                    else -> "WEAK_DATASET_LEAD"
                },
                sourceFindingId = sourceFindingId,
                sourceTitle = sourceTitle.take(240),
                sourceUrl = sourceUrl,
                reasons = score.reasons
            )
        }
    }

    private fun inferSource(accession: String, text: String): String = when {
        accession.startsWith("GSE") || accession.startsWith("GSM") || accession.startsWith("GDS") || text.contains("geo") -> "GEO/NCBI"
        accession.startsWith("SDY") || text.contains("immport") -> "ImmPort"
        accession.startsWith("PRJNA") || accession.startsWith("SRP") || accession.startsWith("SRA") || accession.startsWith("SRR") || accession.startsWith("ERR") || accession.startsWith("DRR") -> "NCBI/SRA"
        accession.startsWith("E-MTAB") -> "ArrayExpress"
        accession.startsWith("EGAS") -> "EGA"
        else -> "candidate_from_text"
    }

    private fun inferOrganism(text: String): String = when {
        listOf("human", "patient", "subjects", "donors", "cohort", "clinical").any { text.contains(it) } -> "human_candidate"
        listOf("mouse", "murine", "rat", "animal model").any { text.contains(it) } -> "animal_candidate"
        listOf("cell line", "in vitro", "pbmc", "organoid").any { text.contains(it) } -> "cell_or_mixed_candidate"
        else -> "unknown"
    }

    private fun inferConditionLabels(text: String): String = when {
        listOf("nickel", "contact dermatitis", "patch test", "anakinra", "epidermal", "skin").any { text.contains(it) } -> "allergy/contact-dermatitis/skin labels candidate"
        listOf("asthma", "allergy", "allergic", "ige", "eosinophil").any { text.contains(it) } -> "allergy/asthma condition labels candidate"
        listOf("rheumatoid", "autoimmune", "lupus", "arthritis").any { text.contains(it) } -> "autoimmunity condition labels candidate"
        listOf("viral", "influenza", "covid", "sars-cov", "rsv", "hantavirus").any { text.contains(it) } -> "viral-response condition labels candidate"
        listOf("case", "control", "condition", "phenotype", "disease").any { text.contains(it) } -> "generic condition labels candidate"
        else -> "unknown"
    }

    private fun inferOutcomeLabels(text: String): String = when {
        listOf("severity", "mild", "moderate", "severe", "outcome", "recovery", "mortality", "hospitalization", "viral load", "response").any { text.contains(it) } -> "outcome/response labels candidate"
        else -> "unknown"
    }

    private fun inferTriggerResponseOutcome(text: String): String = when {
        listOf("trigger", "exposure", "infection", "allergen", "challenge").any { text.contains(it) } &&
            listOf("response", "cytokine", "interferon", "antibody", "t cell", "immune").any { text.contains(it) } &&
            listOf("outcome", "severity", "recovery", "viral load").any { text.contains(it) } -> "trigger-response-outcome candidate"
        else -> "not established"
    }

    private fun inferTimeCourse(text: String): String = when {
        listOf("longitudinal", "time course", "time-course", "follow-up", "baseline", "post", "pre-").any { text.contains(it) } -> "time-course/longitudinal candidate"
        else -> "unknown"
    }

    private fun inferDataType(text: String): String = when {
        listOf("single-cell", "scrna", "single cell").any { text.contains(it) } -> "single-cell transcriptomics"
        listOf("rna-seq", "rnaseq", "transcriptomic", "gene expression").any { text.contains(it) } -> "RNA-seq/transcriptomic"
        listOf("cytokine", "proteomic", "immune profiling", "flow cytometry").any { text.contains(it) } -> "immune profiling/cytokine"
        listOf("methylation", "epigen").any { text.contains(it) } -> "epigenetic"
        else -> "unknown"
    }
}
