package com.immunesignal.app

/**
 * v2.7.9.0 brief surface split. v2.7.9.1 routes therapeutic protocol rendering through GTIMTherapeuticProtocolSurfaceV2791.
 *
 * Keeps GlobalResearchGradeBrief smaller by rendering the execution/ETL/treatment/
 * therapeutic block here. This is display-only; it must not change routing, ETL,
 * evidence upgrades, or Claim Guard decisions.
 */
object GTIMBriefExecutionSurfaceV2790 {
    const val VERSION: String = "2.7.9.0-brief-execution-surface-split"

    fun buildLines(
        matrixAuditCard: GTIMMatrixAuditCardReportV2745,
        matrixEtlBridge: GTIMMatrixEtlMetadataBridgeReportV2780,
        matrixEtlEvidencePacket: GTIMMatrixEtlEvidencePacketReportV2781,
        finalEtlExecutionUnifier: GTIMFinalEtlExecutionUnifierReportV2782,
        treatmentKnowledge: GTIMTreatmentKnowledgeReportV2772,
        treatmentExecutionBridge: GTIMTreatmentExecutionBridgeReportV2773,
        finalExecutionReadiness: GTIMFinalExecutionReadinessReportV2774,
        therapeuticReverseTranslation: GTIMTherapeuticReverseTranslationReportV2790,
        actualEtlExecution: GTIMActualEtlExecutionReportV2800,
        maxLine: Int = 420
    ): List<String> {
        val lines = mutableListOf<String>()
        lines += clip(GTIMMatrixAuditCardV2745.dgeExecutionBridgeLine(matrixAuditCard), maxLine)
        lines += clip(GTIMMatrixAuditCardV2745.dgeExecutionNextLine(matrixAuditCard), maxLine)
        lines += clip(matrixEtlBridge.summaryLine, maxLine)
        lines += clip(matrixEtlBridge.metadataLine, 360)
        lines += clip(GTIMMatrixEtlMetadataBridgeV2780.nextLine(matrixEtlBridge), maxLine)
        lines += clip(matrixEtlEvidencePacket.summaryLine, maxLine)
        lines += clip(matrixEtlEvidencePacket.fileProbeLine, maxLine)
        lines += clip(matrixEtlEvidencePacket.metadataEvidenceLine, maxLine)
        lines += clip(GTIMFinalEtlExecutionUnifierV2782.compactLine(finalEtlExecutionUnifier), 460)
        lines += clip(finalEtlExecutionUnifier.executionOrderLine, 460)
        lines += clip(finalEtlExecutionUnifier.stopRulesLine, maxLine)
        lines += GTIMActualEtlExecutionSurfaceV2800.buildLines(actualEtlExecution, maxLine)
        val therapeuticSafetyV2791 = GTIMTherapeuticProtocolSafetyGuardV2791.evaluate(
            report = therapeuticReverseTranslation,
            finalEtl = finalEtlExecutionUnifier
        )
        lines += GTIMTherapeuticProtocolSurfaceV2791.buildLines(
            report = therapeuticReverseTranslation,
            safety = therapeuticSafetyV2791
        )
        if (treatmentKnowledge.active) {
            lines += clip(GTIMTreatmentKnowledgeLayerV2772.compactLine(treatmentKnowledge), 280)
            lines += clip(treatmentKnowledge.reasoningMapLine, 300)
            lines += clip(treatmentKnowledge.resistanceLine, 260)
            lines += clip(treatmentKnowledge.immuneInteractionLine, 280)
            if (treatmentExecutionBridge.active) {
                lines += clip(GTIMTreatmentExecutionBridgeV2773.compactLine(treatmentExecutionBridge), 320)
                lines += clip(treatmentExecutionBridge.interventionDataGateLine, 300)
                lines += clip(treatmentExecutionBridge.resistanceEvidenceGateLine, 280)
                lines += clip(treatmentExecutionBridge.trialDatasetBridgeLine, 300)
                lines += clip(treatmentExecutionBridge.nextActionLine, 300)
                lines += clip(treatmentExecutionBridge.boundaryLine, 260)
            }
            if (treatmentKnowledge.matchedLanes.any { it.contains("CLINICAL_TRIAL") }) {
                lines += clip(treatmentKnowledge.clinicalTrialLine, 260)
            }
            if (treatmentKnowledge.matchedLanes.any { it.contains("VACCINE") }) {
                lines += clip(treatmentKnowledge.vaccineLine, 260)
            }
            lines += clip(treatmentKnowledge.nextEvidenceLine, 280)
            lines += clip(treatmentKnowledge.boundaryLine, 260)
        }
        lines += clip(GTIMFinalExecutionReadinessV2774.compactLine(finalExecutionReadiness), 340)
        lines += clip(finalExecutionReadiness.nextStepLine, 340)
        lines += clip(finalExecutionReadiness.lockLine, 320)
        return lines
    }

    private fun clip(value: String, max: Int): String {
        val oneLine = value.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1).trimEnd() + "…"
    }
}
