package com.immunesignal.app

import org.json.JSONObject

/**
 * v2.7.7.0 — DGE Readiness Execution Bridge.
 * v2.7.7.1 — Observed-signal separation hardening.
 *
 * This is an execution-readiness router, not a statistical engine. It translates a
 * dataset/accession lead into the next concrete bioinformatics gate: matrix file,
 * sample metadata, comparator labels, and sample-id linkage. It deliberately stays
 * review-only until real raw/count matrix material and machine-checkable sample
 * metadata are surfaced.
 */
data class GTIMDGEExecutionBridgeReportV2770(
    val active: Boolean,
    val accessionId: String,
    val executionState: String,
    val readinessScore: Int,
    val matrixFileCandidateState: String,
    val sampleMetadataState: String,
    val comparatorResolutionState: String,
    val sampleIdLinkageState: String,
    val executionMode: String,
    val nextExecutionStep: String,
    val blockingGates: List<String>,
    val summaryLine: String,
    val boundaryLine: String
)

object GTIMDGEExecutionBridgeV2770 {
    // compatibility audit token: 2.7.7.0-dge-readiness-execution-bridge
    const val VERSION: String = "2.7.7.1-observed-signal-separation"

    fun build(
        report: JSONObject,
        contract: GTIMRunDecisionContractV2740,
        pipeline: GTIMAccessionPipelineStateReportV2749,
        datasetResolution: GTIMDatasetObjectResolutionReportV2761,
        paperUnderstandingSummary: String = ""
    ): GTIMDGEExecutionBridgeReportV2770 {
        val target = datasetResolution.datasetObject.accessionId
        val hasAccession = GTIMAccessionIdValidityGuardV2753.isFullAccession(target) || pipeline.hasAnyHandle
        // v2.7.7.1: separate observed evidence from planning-only text.
        // Recovery queries often contain terms such as "raw counts" or "comparator" as
        // instructions for the next lookup. Those terms must not be read as if the matrix
        // file or comparator labels were already observed.
        val observedContext = normalize(listOf(
            pipeline.targetContext,
            paperUnderstandingSummary,
            report.toString().take(2400),
            datasetResolution.summaryLine,
            datasetResolution.metadataAudit.verifiedSlots.joinToString(" "),
            datasetResolution.metadataAudit.blockingGaps.joinToString(" "),
            datasetResolution.metadataAudit.matrixLinkStatus,
            datasetResolution.metadataAudit.comparatorStatus,
            datasetResolution.metadataAudit.metadataState.code,
            contract.rawQuery,
            contract.primaryAnchor.routeId
        ).joinToString(" "))
        val readinessStateContext = normalize(listOf(
            observedContext,
            datasetResolution.matrixDecision.matrixState,
            datasetResolution.matrixDecision.evidenceUpgradeState.code,
            datasetResolution.matrixDecision.researchValueState
        ).joinToString(" "))

        val hardMatrixCandidate = datasetResolution.metadataAudit.matrixLinkStatus.contains("FOUND", ignoreCase = true) ||
            datasetResolution.matrixDecision.matrixState.contains("MATRIX_LINK_UNVERIFIED", ignoreCase = true) ||
            hasPositiveMatrixSignal(observedContext)
        val softMatrixCandidate = !hardMatrixCandidate && (
            datasetResolution.metadataAudit.matrixLinkStatus.contains("SOFT_MATRIX", ignoreCase = true) ||
            datasetResolution.matrixDecision.matrixState.contains("SOFT_MATRIX", ignoreCase = true) ||
            hasSoftMatrixSignal(readinessStateContext)
        )
        val metadataCandidate = datasetResolution.metadataAudit.metadataState != GTIMDatasetObjectStageV2761.ACCESSION_HANDLE_ONLY ||
            containsAny(observedContext, "sample traits", "sample trait", "metadata table", "characteristics", "phenotype", "clinical")
        val comparatorMapped = datasetResolution.metadataAudit.comparatorStatus.contains("MAPPED", ignoreCase = true) ||
            hasPositiveComparatorSignal(observedContext)
        val softComparatorCandidate = !comparatorMapped && (
            datasetResolution.metadataAudit.comparatorStatus.contains("SOFT_COMPARATOR", ignoreCase = true) ||
            datasetResolution.matrixDecision.matrixState.contains("SOFT_COMPARATOR", ignoreCase = true) ||
            hasSoftComparatorSignal(readinessStateContext)
        )
        val sampleIdCandidate = hardMatrixCandidate && containsAny(
            observedContext,
            "gsm", "sample id", "sample_id", "sample ids", "sampleids", "barcode", "cell barcode",
            "matrix columns", "column names", "rownames", "colnames", "sample table"
        )

        val matrixState = when {
            hardMatrixCandidate -> "MATRIX_FILE_CANDIDATE_FOUND_REVIEW_ONLY"
            softMatrixCandidate -> "SOFT_MATRIX_CANDIDATE_NEEDS_DOWNLOAD"
            hasAccession -> "MATRIX_FILE_LOOKUP_REQUIRED"
            else -> "NO_ACCESSION_FOR_MATRIX_LOOKUP"
        }
        val metadataState = when {
            metadataCandidate && containsAny(observedContext, "sample traits", "metadata table", "characteristics", "phenotype") -> "SAMPLE_METADATA_TABLE_CANDIDATE"
            metadataCandidate -> "SAMPLE_METADATA_PROFILED_OR_PARTIAL"
            hasAccession -> "SAMPLE_METADATA_EXTRACTION_REQUIRED"
            else -> "NO_SAMPLE_METADATA_TARGET"
        }
        val comparatorState = when {
            comparatorMapped -> "COMPARATOR_LABELS_MAPPED_REVIEW_ONLY"
            softComparatorCandidate -> "SOFT_COMPARATOR_LABELS_NEED_STANDARDIZATION"
            metadataCandidate -> "COMPARATOR_EXTRACTION_REQUIRED"
            else -> "COMPARATOR_NOT_READY"
        }
        val sampleIdState = when {
            sampleIdCandidate -> "SAMPLE_ID_LINKAGE_CANDIDATE_REVIEW_ONLY"
            hardMatrixCandidate -> "SAMPLE_ID_LINKAGE_REQUIRED"
            softMatrixCandidate -> "SAMPLE_ID_LINKAGE_PENDING_MATRIX_DOWNLOAD"
            hasAccession -> "SAMPLE_ID_LINKAGE_NOT_STARTED"
            else -> "NO_SAMPLE_ID_LINKAGE_TARGET"
        }

        val executionState = when {
            hardMatrixCandidate && comparatorMapped && metadataCandidate && sampleIdCandidate -> "DGE_EXECUTION_READY_REVIEW_ONLY"
            hardMatrixCandidate && (comparatorMapped || softComparatorCandidate) && metadataCandidate -> "MATRIX_LOADED_METADATA_ENGINEERING_REQUIRED"
            softMatrixCandidate && (comparatorMapped || softComparatorCandidate || metadataCandidate) -> "DGE_EXECUTION_BRIDGE_READY_SOFT"
            hasAccession && metadataCandidate -> "METADATA_ENGINEERING_REQUIRED_BEFORE_DGE"
            hasAccession -> "ACCESSION_LOOKUP_TO_MATRIX_REQUIRED"
            else -> "NO_DGE_EXECUTION_TARGET"
        }

        val score = when (executionState) {
            "DGE_EXECUTION_READY_REVIEW_ONLY" -> 86
            "MATRIX_LOADED_METADATA_ENGINEERING_REQUIRED" -> 78
            "DGE_EXECUTION_BRIDGE_READY_SOFT" -> 72
            "METADATA_ENGINEERING_REQUIRED_BEFORE_DGE" -> 62
            "ACCESSION_LOOKUP_TO_MATRIX_REQUIRED" -> 48
            else -> 20
        }.coerceAtMost(datasetResolution.matrixDecision.readinessScore.coerceAtLeast(20) + 8).coerceIn(0, 88)

        val gates = mutableListOf<String>()
        if (!hasAccession) gates += "ACCESSION_REQUIRED:: feed a topic-compatible GSE/SRP/PRJNA/E-MTAB/SDY handle."
        if (!hardMatrixCandidate) gates += "MATRIX_DOWNLOAD_REQUIRED:: fetch GEO/SRA/ArrayExpress supplementary raw/count matrix or expression file."
        if (!metadataCandidate) gates += "SAMPLE_METADATA_REQUIRED:: extract sample traits, disease/severity/treatment/timepoint fields."
        if (!comparatorMapped) gates += "COMPARATOR_STANDARDIZATION_REQUIRED:: map case/control, matched healthy, baseline/follow-up, or treated/untreated labels."
        if (!sampleIdCandidate) gates += "SAMPLE_ID_LINKAGE_REQUIRED:: verify matrix columns/cell barcodes map to sample metadata rows."
        if (gates.isEmpty()) gates += "REVIEW_ONLY_DGE_GATE:: run controlled DGE and contradiction checks before any biological claim."

        val next = when {
            !hasAccession -> "Feed one topic-compatible accession or manual matrix URL/file seed, then rerun matrix audit."
            !hardMatrixCandidate -> "$target: download/locate supplementary raw counts, count matrix, h5/mtx/rds, or series matrix; do not claim DGE yet."
            !metadataCandidate -> "$target: parse sample metadata table and extract sample traits before comparator mapping."
            !comparatorMapped -> "$target: normalize comparator labels into case/control, severity, baseline/follow-up, or treated/untreated groups."
            !sampleIdCandidate -> "$target: check sample IDs/barcodes between matrix columns and metadata rows before DGE."
            else -> "$target: run review-only DGE with batch/comparator/contradiction checks; keep output bounded."
        }.replace(Regex("\\s+"), " ").trim()

        val boundary = "DGE bridge boundary: execution-readiness only; not biological proof, not diagnosis, not treatment guidance."
        val summary = "DGE execution bridge: state=$executionState | target=$target | readiness=$score/100 | matrix=$matrixState | metadata=$metadataState | comparator=$comparatorState | sample_linkage=$sampleIdState | signal_source=observed_only_v2771"
            .replace(Regex("\\s+"), " ")
            .trim()

        return GTIMDGEExecutionBridgeReportV2770(
            active = true,
            accessionId = target,
            executionState = executionState,
            readinessScore = score,
            matrixFileCandidateState = matrixState,
            sampleMetadataState = metadataState,
            comparatorResolutionState = comparatorState,
            sampleIdLinkageState = sampleIdState,
            executionMode = "REVIEW_ONLY_DGE_READINESS_BRIDGE",
            nextExecutionStep = next,
            blockingGates = gates.distinct().take(6),
            summaryLine = summary,
            boundaryLine = boundary
        )
    }

    fun nextLine(report: GTIMDGEExecutionBridgeReportV2770): String {
        return "DGE execution next: ${report.nextExecutionStep} | gates=${report.blockingGates.take(3).joinToString("; ")} | boundary=review-only."
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun hasPositiveMatrixSignal(text: String): Boolean {
        val positive = containsAny(
            text,
            "count matrix", "raw count", "raw counts", "expression matrix", "matrix file available",
            "matrix link found", "mtx", "h5", "rds", "supplementary file", "geo supplementary", "normalized matrix"
        )
        val negative = containsAny(
            text,
            "matrix file not ready", "matrix file not resolved", "matrix link not resolved", "matrix link is not verified",
            "missing raw count", "missing raw counts", "missing raw count matrix", "matrix missing", "no matrix file"
        )
        return positive && !negative
    }

    private fun hasSoftMatrixSignal(text: String): Boolean {
        val soft = containsAny(
            text,
            "rna seq", "rna-seq", "rnaseq", "transcriptomic", "transcriptomics", "microarray", "single cell",
            "single-cell", "scrna", "geo series", "series matrix", "data availability", "supplementary", "sample table",
            "fastq", "sra", "expression profiling", "gene expression"
        )
        val hardNegative = containsAny(text, "not a dataset", "no expression data", "no transcriptomic data", "data unavailable")
        return soft && !hardNegative
    }

    private fun hasPositiveComparatorSignal(text: String): Boolean {
        val positive = containsAny(text, "healthy control", "matched control", "control group", "controls", "healthy donor", "baseline", "recovered", "comparator", "case control", "case-control")
        val negative = containsAny(text, "missing comparator", "comparator missing", "comparator labels missing", "ambiguous comparator", "no comparator", "comparator labels are not")
        return positive && !negative
    }

    private fun hasSoftComparatorSignal(text: String): Boolean {
        val soft = containsAny(text, "patient", "patients", "infected", "disease", "severity", "severe", "mild", "moderate", "survivor", "non survivor", "responder", "non responder", "cohort", "clinical group", "treated", "untreated")
        val negative = containsAny(text, "missing comparator", "comparator missing", "no comparator", "without comparator")
        return soft && !negative
    }

    private fun normalize(value: String): String = value.lowercase()
        .replace('_', ' ')
        .replace('-', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun containsAny(text: String, vararg needles: String): Boolean = needles.any { text.contains(it, ignoreCase = true) }
}
