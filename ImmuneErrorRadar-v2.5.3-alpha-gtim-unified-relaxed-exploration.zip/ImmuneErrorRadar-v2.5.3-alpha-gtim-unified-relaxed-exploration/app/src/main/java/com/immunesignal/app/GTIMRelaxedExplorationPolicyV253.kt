package com.immunesignal.app

/**
 * GTIM v2.5.3 unified relaxed-exploration policy.
 *
 * This is not a claim-relaxation layer. It lowers the threshold for surfacing useful
 * research leads, source-metadata traces, and bounded mechanism candidates while keeping
 * diagnosis, treatment, DGE, fold-change, p-value, and confirmed-discovery claims blocked.
 */
object GTIMRelaxedExplorationPolicyV253 {
    const val UNIFIED_VERSION_NAME: String = "2.5.3-alpha-gtim-unified-relaxed-exploration"
    const val UNIFIED_ENGINE_VERSION: String = "v2.5.3-alpha-gtim-unified-relaxed-exploration"
    const val UNIFIED_VERSION_CODE: Int = 130
    const val UNIFIED_SCHEMA_VERSION: String = "2.5.3"

    const val MIN_ROUTE_FIT_FOR_EXPLORATORY_RULE: Int = 35
    const val MAX_SOURCE_METADATA_LEADS: Int = 6
    const val MAX_EXPLORATORY_RESEARCH_LEADS: Int = 8
    const val MIN_EXPLORATORY_CONFIDENCE: Int = 18
    const val MAX_EXPLORATORY_CONFIDENCE: Int = 74

    const val INCLUDE_SOURCE_OBJECTS_WITH_ACCESSION_ANCHORS: Boolean = true
    const val MAX_SOURCE_EVIDENCE_OBJECTS: Int = 8
    const val MAX_GTIM_EVIDENCE_OBJECTS: Int = 16
    const val MAX_GTIM_MECHANISM_CANDIDATES: Int = 8
    const val MIN_GTIM_CONFIDENCE_SCORE: Int = 8
    const val MAX_GTIM_CONFIDENCE_SCORE_NO_EXTERNAL_VALIDATION: Int = 88

    const val STRICTNESS_POSTURE: String =
        "relaxed_exploration_enabled_claim_confirmation_still_locked"

    val RELAXED_OUTPUTS_ALLOWED: List<String> = listOf(
        "weak textual leads",
        "source metadata traces",
        "repository-handle leads",
        "partial comparator hints",
        "matrix/file availability hints",
        "corpus-relative mechanism candidates",
        "falsifiable lab-validation plans"
    )

    val CLAIMS_STILL_BLOCKED: List<String> = listOf(
        "diagnosis",
        "treatment recommendation",
        "patient prediction",
        "confirmed discovery from weak lead",
        "DGE/fold-change/p-value without matrix analysis",
        "human mechanism confirmation from cross-species or text-mined evidence"
    )
}
