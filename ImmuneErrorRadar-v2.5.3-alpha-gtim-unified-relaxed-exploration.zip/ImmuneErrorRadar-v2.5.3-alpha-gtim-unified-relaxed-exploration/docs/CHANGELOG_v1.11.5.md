# v1.11.5-alpha-graded-exploratory-research-results

- versionCode=129
- schema updated to `1.11.5`
- Added `ExploratoryResearchLeadV1115`.
- Added `GRADED_EXPLORATORY_RESULTS` mode.
- Reports now show useful in-progress research leads when EvidenceObject is blocked.
- Preserves `HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION` and no clinical-claim guardrails.

## GTIM v2.5.0 production-directive integration patch

- Added `GTIMDiscoveryDossierV250`, `GTIMEvidenceModelsV250`, and `GTIMClaimGuardV250`.
- Integrated global translational immunology dossier output directly into `ResearchGradeMechanismDossierReportV1110.globalTranslationalDossier`.
- Extended JSON export, global research brief, runtime registry, and UI detail report to surface GTIM dossier state.
- Preserved accession/comparator/matrix/DGE gates: GTIM cannot upgrade weak text, cross-species, or reference-control evidence into proof.
- Added `audit_gtim_v250_play_scientific_surface.py` to guard Play-compatible permissions, target SDK 35, claim boundaries, JSON route linkage, and non-isolated GTIM wiring.
- Updated research-use and privacy-posture strings without adding new permissions.

## GTIM v2.5.1 route-integrity and CI-fast-gate hardening

- Added `GTIMRouteIntegrityGuardV251` and `GTIMRouteIntegrityReportV251` to verify that the GTIM global dossier remains connected to the existing mechanism dossier, accession/source metadata, JSON export, compact brief, UI, and runtime registry surfaces.
- Extended `GTIMDiscoveryDossierReportV250` with `routeIntegrity`, exported it through `DatasetForagingJson`, and surfaced it in `GlobalResearchGradeBriefV11061` and `ResearchAutopilotActivity`.
- Added regression assertions for accession-anchored and metadata-anchored GTIM routes.
- Added `audit_gtim_v251_route_integrity.py` and wired it into the bounded fast static gate.
- Rebuilt `run_static_checks_fast.sh` as a current-release bounded gate while preserving legacy audit-token compatibility for older validators.
- Guard outcome: GTIM remains a research hypothesis dossier layer, not a diagnosis/treatment/patient-prediction or weak-lead-confirmation layer.

## GTIM v2.5.2 release-surface hardening

- Added `GTIMReleaseSurfaceHardeningV252` and `GTIMReleaseSurfaceHardeningReportV252` to explicitly bridge the Android release train `v1.11.5` with the GTIM product engine surface `v2.5.2`.
- Exported `globalTranslationalDossier.releaseSurfaceHardening` through `DatasetForagingJson`.
- Surfaced GTIM release hardening state in `GlobalResearchGradeBriefV11061` and `ResearchAutopilotActivity`.
- Extended `GTIMDiscoveryDossierV250Test` to assert release hardening, product-engine version tracking, and hypothesis-only scientific posture.
- Added `audit_gtim_v252_release_surface_hardening.py` to the fast static gate.
- No new Android permissions, telemetry, clinical claims, diagnosis, treatment advice, or patient prediction behavior were added.


## GTIM v2.5.3 unified relaxed-exploration patch

- Unified the active Android release train, runtime engine, learning schema, and GTIM product surface under `2.5.3-alpha-gtim-unified-relaxed-exploration` with `versionCode=130` and schema `2.5.3`.
- Added `GTIMRelaxedExplorationPolicyV253` as the single policy surface for lowering discovery thresholds without lowering claim-confirmation gates.
- Lowered exploratory route threshold from 50 to 35, surfaced source-metadata leads even when accession anchors exist, and expanded bounded GTIM evidence/mechanism outputs.
- Kept all hard claim locks: no diagnosis, no treatment advice, no patient prediction, no DGE/fold-change/p-value without matrix analysis, no confirmed discovery from weak leads.
