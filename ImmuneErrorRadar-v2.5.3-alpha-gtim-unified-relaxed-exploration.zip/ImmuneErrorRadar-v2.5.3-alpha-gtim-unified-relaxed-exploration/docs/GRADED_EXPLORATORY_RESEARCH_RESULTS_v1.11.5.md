# Graded Exploratory Research Results v1.11.5

Legacy base version: `1.11.5-alpha-graded-exploratory-research-results`  
Current unified version: `2.5.3-alpha-gtim-unified-relaxed-exploration`

Purpose: stop the report from becoming dry and purely technical when accession/comparator/matrix gates are incomplete.

The engine now emits confidence-scored `ExploratoryResearchLeadV1115` cards when there is enough cross-family or source-metadata signal to be useful, even if EvidenceObject creation remains blocked.

Rules:
- A graded lead is not EvidenceObject.
- A graded lead is not proof.
- It may appear with weak or incomplete evidence if the report states confidence, tier, supporting signals, missing evidence, upgrade path, and failure modes.
- No accession IDs, sample labels, fold-changes, p-values, cytokine effects, diagnoses, treatments, patient predictions, or causal claims may be invented.

Output fields:
- `exploratoryResearchLeads`
- `researchResultMode = GRADED_EXPLORATORY_RESULTS`
- `bestResearchLeadSummary`
- confidence tier: B/C/D/E in-progress

Upgrade path:
`graded lead -> confirmed accession -> comparator/control -> sample metadata -> matrix availability -> contradiction/null-result search -> EvidenceObject review candidate`
