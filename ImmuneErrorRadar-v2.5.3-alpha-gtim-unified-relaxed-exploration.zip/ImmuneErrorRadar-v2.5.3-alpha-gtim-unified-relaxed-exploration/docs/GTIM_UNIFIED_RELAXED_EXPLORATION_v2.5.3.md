# GTIM v2.5.3 Unified Relaxed Exploration

Version: `2.5.3-alpha-gtim-unified-relaxed-exploration`  
Version code: `130`  
Schema: `2.5.3`

This patch unifies the Android app release train, runtime engine, learning schema, and GTIM product surface into one version identity.

## What was relaxed

- Exploratory route threshold lowered from 50 to 35.
- Source metadata leads are kept even when accession anchors exist.
- GTIM evidence objects can include weak text/source traces alongside accession evidence.
- More bounded mechanism candidates can be shown to the user for research planning.

## What remains locked

- No diagnosis.
- No treatment, dose, supplement, or patient-specific recommendation.
- No confirmed biological discovery from weak lead, manual snippet, cross-species prior, or text-mined evidence.
- No DGE, fold-change, p-value, cytokine direction, or up/down-regulation without real matrix analysis.
- Novelty remains corpus-relative only.

## Operating posture

The engine should show useful research leads earlier, but every lead must carry missing evidence, contradiction/null-result prompts, and falsification/lab-validation conditions.
