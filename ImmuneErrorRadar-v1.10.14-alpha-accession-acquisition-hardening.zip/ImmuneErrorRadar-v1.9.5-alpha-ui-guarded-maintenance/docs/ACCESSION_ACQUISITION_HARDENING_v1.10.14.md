# v1.10.14 — Accession Acquisition Hardening

Purpose: convert the latest no-dataset report lesson into code without adding new biology.

## Decision
The next cycle must answer one operational question before expanding reasoning:

- `FOUND_ACCESSION`
- `FOUND_WEAK_ACCESSION_NEEDS_METADATA`
- `NO_ACCESSION_ARCHIVE_ROUTE`

## What changed

- Added `AccessionAcquisitionHardening` with a compact state machine for dataset-handle acquisition.
- Added explicit JSON/PDF/UI visibility through `accessionAcquisitionReport`.
- Expanded accession grammar: GEO/GDS/GSM, SDY/ImmPort, PRJNA/PRJEB/PRJDB, SRP/SRR/SRX/SRS, ER*/DR*, E-MTAB/E-GEOD/E-MEXP, EGAS, BioSample IDs, and phs handles.
- Added accession-acquisition route ordering so repeated `NO_DATASET_ACCESSION` pressure prioritizes GEO/SRA/ImmPort/accession-mining before broad contradiction/control paths.
- Added compact-report guidance when no explicit accession or parsed metadata exists.
- Added v1.10.14 audit and unit tests.

## Hard locks preserved

- A weak/unresolved dataset handle cannot create an EvidenceObject.
- No causal, clinical, diagnostic, treatment, or biological proof language is allowed from accession acquisition.
- Explicit accession still requires minimum metadata, outcome labels, comparator/control, and time order before hypothesis upgrade.

## Claim limit

`accession_acquisition_not_biological_proof`
