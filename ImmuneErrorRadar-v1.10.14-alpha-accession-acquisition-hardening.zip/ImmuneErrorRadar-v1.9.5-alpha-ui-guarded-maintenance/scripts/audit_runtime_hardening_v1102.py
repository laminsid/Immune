from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def read(path):
    return (ROOT / path).read_text(encoding='utf-8')

def require(path, needle, message):
    text = read(path)
    if needle not in text:
        raise SystemExit(f'FAIL: {message}: missing {needle!r} in {path}')

def forbid(path, needle, message):
    text = read(path)
    if needle in text:
        raise SystemExit(f'FAIL: {message}: forbidden {needle!r} in {path}')

require('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt', 'v1.10.14-alpha-accession-acquisition-hardening', 'active engine version must be v1.10.5')
require('app/build.gradle.kts', 'versionName = "1.10.14-alpha-accession-acquisition-hardening"', 'gradle versionName must be v1.10.5')
require('app/build.gradle.kts', 'implementation("com.squareup.okhttp3:okhttp:4.12.0")', 'OkHttp dependency must be present')
require('app/src/main/java/com/immunesignal/app/NcbiClient.kt', 'class NcbiClient', 'NcbiClient must exist')
require('app/src/main/java/com/immunesignal/app/NcbiClient.kt', 'NcbiRateLimitException', '429 mapping must be typed')
require('app/src/main/java/com/immunesignal/app/NcbiClient.kt', 'NcbiHttpException', 'non-2xx mapping must be typed')
forbid('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'HttpURLConnection', 'ResearchAutopilot must not use raw HttpURLConnection')
forbid('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'Thread.sleep', 'ResearchAutopilot must not block retry with Thread.sleep')
forbid('app/src/main/java/com/immunesignal/app/FoundationKnowledgeLayer.kt', 'InputStreamReader', 'asset loading must use explicit UTF-8')
forbid('app/src/main/java/com/immunesignal/app/DeepDiscoveryReasonerV180.kt', 'InputStreamReader', 'scientific term asset loading must use explicit UTF-8')
require('app/src/test/java/com/immunesignal/app/NcbiClientErrorMappingTest.kt', 'maps429ToRateLimitException', '429 test must exist')
require('app/src/test/java/com/immunesignal/app/NcbiClientErrorMappingTest.kt', 'sendsDynamicUserAgentWithActiveEngineVersion', 'User-Agent version test must exist')
require('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt', 'interface RuntimeModule', 'typed runtime module registry must exist')
require('app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt', 'readLastLines(offlineThoughtFile', 'offline thinking reads must use tail reads')
require('app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt', 'fileName == offlineThoughtFile || fileName == autonomousThoughtPulseFile', 'offline ledgers must use append-only path')
require('app/src/test/java/com/immunesignal/app/KeywordBoundaryRegressionTest.kt', 'shipping sample metadata only', 'boundary regression test must exist')
print('runtime hardening v1.10.2/v1.10.4 audit: PASS')
