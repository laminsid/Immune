package com.immunesignal.app

object ResearchReportV3Builder {
    fun build(
        findings: List<ResearchFinding>,
        hypothesisObjects: List<HypothesisObject>,
        learningDeltas: List<LearningDeltaCard>,
        datasetCandidates: List<DatasetCandidateV133>,
        pivot: PivotDecision,
        repeatedSkipped: Int,
        global: GlobalImmuneIntelligenceReport
    ): ResearchReportV3 {
        val topFinding = findings.maxByOrNull { it.noveltyScore }
        val topDataset = datasetCandidates.maxByOrNull { it.priorityScore }
        val topDelta = learningDeltas.firstOrNull { it.deltaType != "no_change" }
        val topHypothesis = hypothesisObjects.maxByOrNull { it.evidenceScore10 + it.causalityScore / 20.0 }
        val cycleResult = when {
            topDataset != null && topDataset.priorityScore >= 60 -> "Dataset lead found"
            topDelta != null -> "Hypothesis changed"
            topFinding != null -> "Useful delta"
            pivot.pivotType != "NO_PIVOT" -> "No useful delta — strategy pivoted"
            repeatedSkipped > 0 -> "Stalled by repeated sources"
            else -> "No useful delta"
        }
        val lead = when {
            topDataset != null -> "${topDataset.datasetId}: ${topDataset.dataType}, ${topDataset.species}, ${topDataset.outcomeLabelsHint}."
            topFinding != null -> topFinding.title
            else -> "No new useful source saved in this cycle."
        }
        val changed = when {
            topDelta != null -> "${topDelta.hypothesisId}: ${topDelta.previousStatus} → ${topDelta.currentStatus} (${topDelta.deltaType})."
            topHypothesis != null -> "${topHypothesis.hypothesisId}: ${topHypothesis.status}, discovery ${topHypothesis.discoveryState}, bias ${topHypothesis.biasRiskState}."
            else -> "No hypothesis upgraded."
        }
        val why = when {
            topDataset != null -> topDataset.whyUseful
            topFinding != null -> topFinding.whyItMatters
            global.globalDiscoveryAction.isNotBlank() -> global.globalDiscoveryAction
            else -> "The cycle mainly informed search strategy rather than biology."
        }
        val next = when {
            topDataset != null -> topDataset.nextVerificationStep
            pivot.pivotType != "NO_PIVOT" -> "Pivot to ${pivot.nextIntent}: ${pivot.nextQuerySeed}".take(260)
            global.nextGlobalDatasetNeeded.isNotBlank() -> global.nextGlobalDatasetNeeded
            else -> "Run the next autonomous Explore/Deepen/Challenge cycle."
        }
        val caution = when {
            pivot.pivotType != "NO_PIVOT" -> "Do not treat this as failed research; it is a strategy-change signal. ${pivot.reason}"
            topFinding != null && topFinding.evidence.speciesClass != "human" -> "Do not generalize animal/cell-only evidence to humans."
            topFinding != null && topFinding.sanityFlags.contains("METADATA_ONLY") -> "Do not believe mechanism strength yet; abstract/full text was not reviewed."
            else -> "Do not treat any lead as causal until evidence, contradiction, and dataset gates pass."
        }
        return ResearchReportV3(cycleResult, lead, changed, why, next, caution, "Open Full Technical Report for locks, evidence, bias, and raw findings.")
    }
}
