package com.immunesignal.app

/**
 * Turns an empty or low-value cycle into a strategy pivot.
 * The engine learns from failure by changing search intent, not by asking the user.
 */
object NoResultRecoveryEngine {
    fun decide(signature: FailureSignature): PivotDecision {
        val noUseful = signature.newUsefulSources <= 0
        val repeatedHeavy = signature.repeatedSkipped >= 10
        val metadataHeavy = signature.metadataOnlyRatio >= 0.70
        val laneStalled = signature.sameLaneFailureCount >= 2
        if (!noUseful && !metadataHeavy && !laneStalled) return PivotDecision.none()

        return when {
            signature.datasetCandidateCount > 0 && noUseful -> PivotDecision(
                pivotType = "DATASET_TO_VERIFICATION",
                reason = "Dataset identifiers appeared but no useful source was saved; verify dataset metadata next.",
                nextIntent = "dataset_verification",
                nextQuerySeed = "sample count outcome labels longitudinal RNA-seq severity dataset",
                priority = 90
            )
            metadataHeavy -> PivotDecision(
                pivotType = "METADATA_TO_TOP_ABSTRACTS",
                reason = "Metadata-only evidence dominated the cycle; fetch top abstracts selectively next.",
                nextIntent = "selective_abstract_review",
                nextQuerySeed = "mechanism human cohort outcome cytokine transcriptomic",
                priority = 84
            )
            signature.failedLane.contains("mechanism", ignoreCase = true) || signature.failedLane.contains("DEEPEN", ignoreCase = true) -> PivotDecision(
                pivotType = "MECHANISM_TO_DATASET",
                reason = "Mechanism search stalled; switch to raw dataset hunting.",
                nextIntent = "dataset_hunting",
                nextQuerySeed = "GSE GEO ImmPort SDY RNA-seq single-cell longitudinal outcome",
                priority = 82
            )
            signature.failedLane.contains("challenge", ignoreCase = true) -> PivotDecision(
                pivotType = "STALLED_TO_CHALLENGE",
                reason = "Challenge lane stalled; invert the question and search contradictions across cohorts.",
                nextIntent = "contradiction_search",
                nextQuerySeed = "conflicting results heterogeneity no association severe outcome human cohort",
                priority = 78
            )
            repeatedHeavy -> PivotDecision(
                pivotType = "REPEAT_TO_NEW_AXIS_PAIR",
                reason = "Many known PubMed IDs repeated; rotate toward a less explored axis pair.",
                nextIntent = "new_axis_pair_explore",
                nextQuerySeed = "immune resolution regulatory brake tissue damage time course transcriptomic",
                priority = 76
            )
            else -> PivotDecision(
                pivotType = "GENERAL_TO_CONTRADICTION",
                reason = "General search produced no useful delta; search against the hypothesis next.",
                nextIntent = "contradiction_search",
                nextQuerySeed = "contradictory nonresponse heterogeneity harmful excessive delayed",
                priority = 70
            )
        }
    }
}
