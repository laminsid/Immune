package com.immunesignal.app

import java.security.MessageDigest
import java.util.Locale

/**
 * v1.10.31: first-lead breakthrough layer. Activity ≠ Evidence.
 *
 * Goal: capture weak dataset leads and manual seeds without upgrading any
 * biological claim. This layer changes routing and preservation only.
 */
data class ManualEvidenceSeedCandidate(
    val seedType: String,
    val seedValue: String,
    val sourceTextDigest: String,
    val candidate: DatasetAccessionCandidate,
    val nextLookupSource: String,
    val claimLimit: String = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
)

data class ManualEvidenceSeedReport(
    val active: Boolean,
    val mode: String,
    val seedsDetected: Int,
    val candidates: List<ManualEvidenceSeedCandidate>,
    val unsupportedSeeds: List<String>,
    val nextAction: String,
    val claimLimit: String = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = ManualEvidenceSeedReport(
            active = false,
            mode = "MANUAL_EVIDENCE_SEED_MODE_OFF",
            seedsDetected = 0,
            candidates = emptyList(),
            unsupportedSeeds = emptyList(),
            nextAction = "No manual evidence seed was supplied. Continue autonomous dataset discovery.",
            claimLimit = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
        )
    }
}

data class DatasetLeadRelaxationReport(
    val active: Boolean,
    val state: String,
    val relaxedLeadCount: Int,
    val leadAccessions: List<String>,
    val preservedStatuses: List<String>,
    val reason: String,
    val claimLimit: String = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = DatasetLeadRelaxationReport(
            active = false,
            state = "NOT_EVALUATED",
            relaxedLeadCount = 0,
            leadAccessions = emptyList(),
            preservedStatuses = emptyList(),
            reason = "Dataset lead relaxation gate was not evaluated.",
            claimLimit = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
        )
    }
}

data class EvidenceDiscoveryBreakthroughReport(
    val active: Boolean,
    val state: String,
    val bestLead: String,
    val bestLeadStatus: String,
    val nearMissCount: Int,
    val postPubMedSearchStrategies: List<String>,
    val nextAction: String,
    val claimLimit: String = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = EvidenceDiscoveryBreakthroughReport(
            active = false,
            state = "NOT_EVALUATED",
            bestLead = "none",
            bestLeadStatus = "none",
            nearMissCount = 0,
            postPubMedSearchStrategies = emptyList(),
            nextAction = "No first-lead breakthrough evaluation was run.",
            claimLimit = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
        )
    }
}

data class EvidenceActivitySeparationReport(
    val executedPaths: Int,
    val candidatesFound: Int,
    val accessionsFound: Int,
    val evidenceObjects: Int,
    val learningUpdates: Int,
    val domainExpertiseUpdated: Boolean,
    val scientificClaim: String,
    val claimLimit: String = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = EvidenceActivitySeparationReport(
            executedPaths = 0,
            candidatesFound = 0,
            accessionsFound = 0,
            evidenceObjects = 0,
            learningUpdates = 0,
            domainExpertiseUpdated = false,
            scientificClaim = "none",
            claimLimit = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
        )
    }
}

data class OnePageExecutiveEvidenceReport(
    val cycleValidity: String,
    val evidenceFound: String,
    val bestLead: String,
    val matureDomainUsed: Boolean,
    val nextAction: String,
    val doNotBelieveYet: List<String>,
    val claimLimit: String = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = OnePageExecutiveEvidenceReport(
            cycleValidity = "VALID_NO_EVIDENCE",
            evidenceFound = "none",
            bestLead = "none",
            matureDomainUsed = false,
            nextAction = "Run dataset-first discovery or supply a manual seed.",
            doNotBelieveYet = listOf("No biological claim is supported before an EvidenceObject exists."),
            claimLimit = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
        )
    }
}

data class EvidenceLeadPathLinkageReport(
    val active: Boolean,
    val state: String,
    val manualSeedLinkedToForager: Boolean,
    val weakLeadLinkedToRelaxation: Boolean,
    val breakthroughLinkedToDecision: Boolean,
    val consistencyGuardApplied: Boolean,
    val postPubMedStrategyLinked: Boolean,
    val warnings: List<String>,
    val nextAction: String,
    val claimLimit: String = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = EvidenceLeadPathLinkageReport(
            active = false,
            state = "NOT_EVALUATED",
            manualSeedLinkedToForager = false,
            weakLeadLinkedToRelaxation = false,
            breakthroughLinkedToDecision = false,
            consistencyGuardApplied = false,
            postPubMedStrategyLinked = false,
            warnings = emptyList(),
            nextAction = "Evidence lead path linkage was not evaluated.",
            claimLimit = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
        )
    }
}

object EvidenceLeadAndManualSeedPolicy {
    const val CLAIM_LIMIT = "lead_only_not_evidence"
    const val MANUAL_MODE = "MANUAL_EVIDENCE_SEED_MODE"
    private val accessionRegex = Regex("\\b(GSE\\d{2,}|PRJNA\\d+|SRP\\d+|SRR\\d+|E-MTAB-\\d+|SDY\\d+|phs\\d+(?:\\.v\\d+)?(?:\\.p\\d+)?|SAMN\\d+|EGAS\\d+)\\b", RegexOption.IGNORE_CASE)
    private val pmidRegex = Regex("\\bPMID[:\\s]*([0-9]{6,9})\\b|\\b([0-9]{7,9})\\b", RegexOption.IGNORE_CASE)
    private val doiRegex = Regex("\\b10\\.\\d{4,9}/[-._;()/:A-Z0-9]+\\b", RegexOption.IGNORE_CASE)
    private val pdfRegex = Regex("https?://\\S+\\.pdf\\b", RegexOption.IGNORE_CASE)
    private val explicitPmidRegex = Regex("\\bPMID[:\\s]*[0-9]{6,9}\\b", RegexOption.IGNORE_CASE)

    fun hasManualSeedSignal(texts: List<String>): Boolean = texts.any { raw ->
        val text = raw.take(20_000)
        accessionRegex.containsMatchIn(text) ||
            doiRegex.containsMatchIn(text) ||
            pdfRegex.containsMatchIn(text) ||
            explicitPmidRegex.containsMatchIn(text)
    }

    fun manualSeedAttempt(report: ManualEvidenceSeedReport): DatasetSourceAttempt? {
        if (!report.active) return null
        return DatasetSourceAttempt(
            sourceFamily = MANUAL_MODE,
            ncbiDb = "manual",
            query = report.candidates.joinToString(" | ") { "${it.seedType}:${it.seedValue}" }.ifBlank { "manual_seed_text_unresolved" }.take(500),
            attempted = true,
            idsFound = report.seedsDetected,
            candidatesExtracted = report.candidates.size,
            status = if (report.candidates.isNotEmpty()) "MANUAL_SEED_CANDIDATES_IMPORTED" else "MANUAL_SEED_NO_USABLE_CANDIDATE",
            reason = "v1.10.31 linkage: manual/imported seed is routed into attempts, candidates, relaxation, breakthrough, and report-consistency gates; claim remains LEAD_ONLY_NOT_EVIDENCE."
        )
    }

    fun fromManualTexts(texts: List<String>): ManualEvidenceSeedReport {
        val candidates = mutableListOf<ManualEvidenceSeedCandidate>()
        val unsupported = mutableListOf<String>()
        texts.filter { it.isNotBlank() }.take(20).forEachIndexed { index, raw ->
            val text = raw.take(20_000)
            val digest = sha256(text).take(16)
            val accessionMatches = accessionRegex.findAll(text).map { it.value.uppercase(Locale.US) }.distinct().take(8).toList()
            accessionMatches.forEach { accession ->
                candidates += ManualEvidenceSeedCandidate(
                    seedType = accessionType(accession),
                    seedValue = accession,
                    sourceTextDigest = digest,
                    candidate = leadCandidate(
                        accession = accession,
                        source = "MANUAL_EVIDENCE_SEED_MODE",
                        sourceFindingId = "manual_seed_${digest}_$accession",
                        title = "Manual seed candidate: $accession",
                        url = "manual-seed:$digest",
                        status = "LEAD_ONLY_NOT_EVIDENCE",
                        reason = "Manual seed supplied an accession-like handle. Preserve it for metadata lookup; do not upgrade any scientific claim."
                    ),
                    nextLookupSource = nextLookupSourceFor(accession)
                )
            }

            if (accessionMatches.isEmpty()) {
                val doi = doiRegex.find(text)?.value
                val pmid = pmidRegex.find(text)?.groupValues?.drop(1)?.firstOrNull { it.isNotBlank() }
                val pdf = pdfRegex.find(text)?.value
                when {
                    doi != null -> candidates += secondaryLookupSeed("DOI", doi, digest, index)
                    pmid != null -> candidates += secondaryLookupSeed("PMID", pmid, digest, index)
                    pdf != null -> candidates += secondaryLookupSeed("PDF", pdf.take(120), digest, index)
                    text.length >= 40 -> candidates += secondaryLookupSeed("TEXT_SNIPPET", text.take(120), digest, index)
                    else -> unsupported += text.take(120)
                }
            }
        }
        return ManualEvidenceSeedReport(
            active = candidates.isNotEmpty() || unsupported.isNotEmpty(),
            mode = if (candidates.isNotEmpty()) MANUAL_MODE else "MANUAL_EVIDENCE_SEED_MODE_NO_USABLE_SEED",
            seedsDetected = candidates.size,
            candidates = candidates.distinctBy { it.seedType + ":" + it.seedValue }.take(20),
            unsupportedSeeds = unsupported.distinct().take(10),
            nextAction = if (candidates.isNotEmpty()) {
                "Resolve manual seeds through secondary lookup, parse minimum metadata, and keep every candidate as LEAD_ONLY_NOT_EVIDENCE until dataset metadata/outcome/control fields are visible."
            } else {
                "Manual text did not include a usable PMID/DOI/accession/PDF/snippet seed; continue autonomous discovery."
            }
        )
    }


    fun toLeadObjects(
        manualSeedReport: ManualEvidenceSeedReport,
        candidates: List<DatasetAccessionCandidate>,
        attempts: List<DatasetSourceAttempt>
    ): List<LeadObject> {
        val candidateLeads = candidates.mapIndexed { index, candidate ->
            leadObjectFromCandidate(candidate, index)
        }
        val manualLeads = manualSeedReport.candidates.mapIndexed { index, seed ->
            LeadObject(
                leadId = "manual_${seed.sourceTextDigest}_$index",
                source = seed.seedType,
                sourceFamily = MANUAL_MODE,
                title = "Manual seed ${seed.seedType}: ${seed.seedValue}",
                snippet = seed.seedValue,
                detectedAccessions = if (seed.candidate.accession.startsWith("MANUAL_", true)) emptyList() else listOf(seed.candidate.accession),
                dataAvailabilityText = seed.nextLookupSource,
                organism = seed.candidate.organismHint,
                humanLikely = seed.candidate.organismHint.contains("human", true),
                omicsType = seed.candidate.dataType,
                domain = inferDomain(seed.seedValue + " " + seed.candidate.sourceTitle),
                outcomeLikely = !seed.candidate.outcomeLabelsHint.contains("unknown", true),
                controlLikely = seed.candidate.reasons.any { it.contains("control", true) || it.contains("comparator", true) },
                timeLikely = !seed.candidate.timeCourseHint.contains("unknown", true),
                licenseAccessLikely = seed.candidate.reasons.any { it.contains("access", true) || it.contains("license", true) },
                sampleSizeLikely = !seed.candidate.sampleSizeHint.contains("unknown", true),
                confidence = 35,
                claimLimit = CLAIM_LIMIT
            )
        }
        val attemptNearMissLeads = attempts.filter { it.idsFound > 0 && it.candidatesExtracted == 0 }.mapIndexed { index, attempt ->
            LeadObject(
                leadId = "near_miss_${sha256(attempt.sourceFamily + attempt.query).take(12)}_$index",
                source = attempt.ncbiDb,
                sourceFamily = attempt.sourceFamily,
                title = "Near-miss source response from ${attempt.sourceFamily}",
                snippet = attempt.query.take(240),
                detectedAccessions = emptyList(),
                dataAvailabilityText = attempt.reason.take(240),
                organism = "unknown",
                humanLikely = attempt.query.contains("human", true) || attempt.query.contains("patient", true),
                omicsType = inferOmics(attempt.query),
                domain = inferDomain(attempt.query),
                outcomeLikely = attempt.query.contains("outcome", true) || attempt.query.contains("severity", true),
                controlLikely = attempt.query.contains("control", true) || attempt.query.contains("comparator", true),
                timeLikely = attempt.query.contains("longitudinal", true) || attempt.query.contains("time", true),
                licenseAccessLikely = attempt.query.contains("data availability", true) || attempt.query.contains("open", true),
                sampleSizeLikely = attempt.query.contains("sample", true) || attempt.query.contains("cohort", true),
                confidence = 20,
                claimLimit = CLAIM_LIMIT
            )
        }
        return (manualLeads + candidateLeads + attemptNearMissLeads)
            .distinctBy { it.leadId + it.detectedAccessions.joinToString(",") + it.title }
            .take(50)
    }

    private fun leadObjectFromCandidate(candidate: DatasetAccessionCandidate, index: Int): LeadObject {
        val accession = candidate.accession.takeIf { it.isNotBlank() && !it.startsWith("MANUAL_", true) && it != "DATASET_ACCESSION_UNRESOLVED" }
        val text = candidate.sourceTitle + " " + candidate.conditionLabelsHint + " " + candidate.outcomeLabelsHint + " " + candidate.reasons.joinToString(" ")
        return LeadObject(
            leadId = "lead_${sha256(candidate.sourceFindingId + candidate.accession).take(14)}_$index",
            source = candidate.source,
            sourceFamily = candidate.source,
            title = candidate.sourceTitle,
            snippet = candidate.reasons.joinToString(" ").take(360),
            detectedAccessions = listOfNotNull(accession),
            dataAvailabilityText = candidate.reasons.firstOrNull { it.contains("data", true) || it.contains("availability", true) || it.contains("accession", true) }.orEmpty(),
            organism = candidate.organismHint,
            humanLikely = candidate.organismHint.contains("human", true) || text.contains("human", true) || text.contains("patient", true),
            omicsType = inferOmics(candidate.dataType + " " + text),
            domain = inferDomain(text),
            outcomeLikely = !candidate.outcomeLabelsHint.contains("unknown", true) || text.contains("outcome", true) || text.contains("severity", true),
            controlLikely = text.contains("control", true) || text.contains("comparator", true),
            timeLikely = !candidate.timeCourseHint.contains("unknown", true) || text.contains("longitudinal", true),
            licenseAccessLikely = text.contains("open", true) || text.contains("access", true) || text.contains("license", true),
            sampleSizeLikely = !candidate.sampleSizeHint.contains("unknown", true) || text.contains("sample", true),
            confidence = candidate.usabilityScore.coerceIn(10, 70),
            claimLimit = CLAIM_LIMIT
        )
    }

    private fun inferDomain(text: String): String {
        val t = text.lowercase(Locale.US)
        return when {
            t.contains("histamine") || t.contains("mast") || t.contains("urticaria") || t.contains("allergy") -> "antihistamine_histamine_mast_cell"
            t.contains("diabetes") || t.contains("glucose") || t.contains("insulin") -> "diabetes_metabolic_inflammation"
            t.contains("aging") || t.contains("ageing") || t.contains("immunosenescence") -> "aging_immunosenescence_inflammaging"
            t.contains("gastric") || t.contains("reflux") || t.contains("gut") || t.contains("microbiome") -> "gastric_acid_reflux_gut_barrier"
            t.contains("inflammation") || t.contains("cytokine") || t.contains("tnf") || t.contains("il-6") -> "inflammatory_disease_chronic_inflammation"
            else -> "unknown"
        }
    }

    private fun inferOmics(text: String): String {
        val t = text.lowercase(Locale.US)
        return when {
            t.contains("single-cell") || t.contains("scrna") -> "single_cell_rna_seq"
            t.contains("rna") || t.contains("transcript") -> "transcriptomics"
            t.contains("metabol") -> "metabolomics"
            t.contains("cytokine") -> "cytokine_panel"
            t.contains("proteom") -> "proteomics"
            else -> "unknown"
        }
    }

    fun relax(
        candidates: List<DatasetAccessionCandidate>,
        leadObjects: List<LeadObject> = emptyList()
    ): DatasetLeadRelaxationReport {
        val leadOnly = candidates.filter { candidate ->
            candidate.status == "LEAD_ONLY_NOT_EVIDENCE" ||
                candidate.status == "EXPLORATORY_LEAD_NEEDS_ACCESSION" ||
                candidate.status == "FOUND_WEAK_ACCESSION_NEEDS_METADATA" ||
                candidate.reasons.any { it.contains("manual seed", ignoreCase = true) || it.contains("weak", ignoreCase = true) }
        }
        val nearMissLeads = leadObjects.filter { lead ->
            lead.title.contains("Near-miss", ignoreCase = true) ||
                lead.sourceFamily == "MANUAL_EVIDENCE_SEED_MODE" ||
                lead.detectedAccessions.isNotEmpty()
        }
        val preservedAccessions = (leadOnly.map { it.accession } + nearMissLeads.flatMap { it.detectedAccessions })
            .filter { it.isNotBlank() && !it.equals("DATASET_ACCESSION_UNRESOLVED", ignoreCase = true) }
            .distinct()
            .take(20)
        val relaxedCount = leadOnly.size + nearMissLeads.size
        val statuses = (leadOnly.map { it.status } + nearMissLeads.map {
            if (it.title.contains("Near-miss", ignoreCase = true)) "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION" else "LEAD_ONLY_NOT_EVIDENCE"
        }).distinct()
        val state = when {
            relaxedCount == 0 -> "NO_WEAK_LEAD_TO_RELAX"
            leadOnly.isNotEmpty() && nearMissLeads.isEmpty() -> "WEAK_LEADS_PRESERVED_NOT_UPGRADED"
            else -> "WEAK_OR_NEAR_MISS_LEADS_PRESERVED_NOT_UPGRADED"
        }
        return DatasetLeadRelaxationReport(
            active = true,
            state = state,
            relaxedLeadCount = relaxedCount,
            leadAccessions = preservedAccessions,
            preservedStatuses = statuses,
            reason = if (relaxedCount > 0) {
                "Weak, manual, or near-miss dataset leads are stored for follow-up as LEAD_ONLY_NOT_EVIDENCE; strict evidence gates remain unchanged."
            } else {
                "No weak, manual, or near-miss dataset lead was present; normal evidence gates remain unchanged."
            }
        )
    }

    fun breakthrough(
        candidates: List<DatasetAccessionCandidate>,
        attempts: List<DatasetSourceAttempt>,
        manualSeedReport: ManualEvidenceSeedReport,
        relaxationReport: DatasetLeadRelaxationReport,
        accessionReport: AccessionAcquisitionReport,
        leadObjects: List<LeadObject> = emptyList()
    ): EvidenceDiscoveryBreakthroughReport {
        val weakLead = candidates.firstOrNull { it.status == "LEAD_ONLY_NOT_EVIDENCE" || it.status == "EXPLORATORY_LEAD_NEEDS_ACCESSION" }
        val bestLeadObject = leadObjects.firstOrNull { lead ->
            lead.detectedAccessions.isNotEmpty() || lead.title.contains("Near-miss", ignoreCase = true) || lead.sourceFamily == MANUAL_MODE
        }
        val nearMissAttempt = attempts.firstOrNull { it.idsFound > 0 && it.candidatesExtracted == 0 }
        val fallbackNearMissLeadLabel = nearMissAttempt?.let { "Near-miss source response from ${it.sourceFamily}" }
        val nearMissCount = attempts.count { it.idsFound > 0 && it.candidatesExtracted == 0 } + accessionReport.unresolvedLeadCount
        val postPubMedStrategies = postPubMedSearchStrategies(candidates, attempts)
        val state = when {
            manualSeedReport.candidates.isNotEmpty() || relaxationReport.relaxedLeadCount > 0 || weakLead != null -> "WEAK_DATASET_LEAD_FOUND"
            accessionReport.weakAccessions.isNotEmpty() -> "ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP"
            nearMissCount > 0 || bestLeadObject != null -> "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION"
            attempts.isNotEmpty() && candidates.isEmpty() -> "NO_PUBLIC_DATASET_AFTER_FULL_SWEEP"
            else -> "NO_PUBLIC_DATASET_AFTER_FULL_SWEEP"
        }
        val best = weakLead ?: candidates.firstOrNull()
        val bestLeadLabel = best?.accession
            ?: manualSeedReport.candidates.firstOrNull()?.seedValue
            ?: bestLeadObject?.title
            ?: fallbackNearMissLeadLabel
            ?: "none"
        val bestStatus = best?.status
            ?: manualSeedReport.candidates.firstOrNull()?.candidate?.status
            ?: bestLeadObject?.let { if (it.title.contains("Near-miss", ignoreCase = true)) "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION" else "LEAD_ONLY_NOT_EVIDENCE" }
            ?: fallbackNearMissLeadLabel?.let { "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION" }
            ?: "none"
        return EvidenceDiscoveryBreakthroughReport(
            active = true,
            state = state,
            bestLead = bestLeadLabel.take(160),
            bestLeadStatus = bestStatus,
            nearMissCount = nearMissCount,
            postPubMedSearchStrategies = postPubMedStrategies,
            nextAction = when (state) {
                "WEAK_DATASET_LEAD_FOUND" -> "Preserve the weak/near-miss lead, inspect source IDs or supplementary-data phrases, run secondary lookup/minimum metadata parsing, and do not create an EvidenceObject yet."
                "ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP" -> "Run secondary lookup on accession-like text from abstract/data-availability sections before archiving."
                "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION" -> "Inspect returned source IDs and supplementary-data phrases manually; a near miss exists but is not evidence."
                else -> "Switch to post-PubMed direct catalog strategies or request a manual PMID/DOI/GSE/PRJNA seed before another broad cycle."
            }
        )
    }

    fun activitySeparation(
        attempts: List<DatasetSourceAttempt>,
        candidates: List<DatasetAccessionCandidate>,
        evidenceObjects: List<EvidenceObject>,
        noCandidateRecords: List<NoCandidateLearningRecord>,
        domainReport: DomainExpertiseMemoryPolicy.DomainExpertiseReport
    ): EvidenceActivitySeparationReport = EvidenceActivitySeparationReport(
        executedPaths = attempts.count { it.attempted },
        candidatesFound = candidates.size,
        accessionsFound = candidates.count {
            it.accession.isNotBlank() &&
                !it.accession.startsWith("MANUAL_", ignoreCase = true) &&
                it.accession != "DATASET_ACCESSION_UNRESOLVED"
        },
        evidenceObjects = evidenceObjects.size,
        learningUpdates = noCandidateRecords.size,
        domainExpertiseUpdated = domainReport.active && domainReport.cards.isNotEmpty(),
        scientificClaim = if (evidenceObjects.isEmpty()) "none" else "evidence_object_present_requires_review"
    )

    fun executiveSummary(
        breakthrough: EvidenceDiscoveryBreakthroughReport,
        activity: EvidenceActivitySeparationReport,
        matureDomainUsed: Boolean,
        nextAction: String
    ): OnePageExecutiveEvidenceReport = OnePageExecutiveEvidenceReport(
        cycleValidity = if (activity.evidenceObjects == 0) "VALID_NO_EVIDENCE" else "VALID_EVIDENCE_OBJECT_REQUIRES_REVIEW",
        evidenceFound = if (activity.evidenceObjects == 0) "none" else activity.evidenceObjects.toString(),
        bestLead = breakthrough.bestLead,
        matureDomainUsed = matureDomainUsed,
        nextAction = nextAction,
        doNotBelieveYet = listOf(
            "Weak leads are not biological evidence.",
            "Manual seeds require secondary lookup and minimum metadata parsing.",
            "No belief probability is updated before an EvidenceObject exists."
        )
    )

    fun postPubMedSearchStrategies(candidates: List<DatasetAccessionCandidate>, attempts: List<DatasetSourceAttempt>): List<String> {
        val baseTerms = (candidates.flatMap { listOf(it.conditionLabelsHint, it.outcomeLabelsHint, it.dataType) } + attempts.map { it.query })
            .joinToString(" ")
            .lowercase(Locale.US)
        val focus = when {
            baseTerms.contains("histamine") || baseTerms.contains("mast") -> "histamine mast cell allergy urticaria RNA-seq GSE outcome control cohort"
            baseTerms.contains("diabetes") || baseTerms.contains("glucose") -> "diabetes inflammation cytokine RNA-seq GSE cohort outcome control"
            else -> "immune inflammation cohort RNA-seq GSE outcome control"
        }
        return listOf(
            "GEO direct term search: $focus",
            "NCBI BioProject direct query: $focus PRJNA",
            "ArrayExpress direct query: $focus E-MTAB",
            "ImmPort direct query: $focus SDY",
            "Dataset catalog search terms: dataset supplementary data accession cohort outcome control",
            "Supplementary-data phrase mining: data availability GSE PRJNA SRP E-MTAB SDY"
        )
    }

    fun linkage(
        manualSeedReport: ManualEvidenceSeedReport,
        relaxationReport: DatasetLeadRelaxationReport,
        breakthroughReport: EvidenceDiscoveryBreakthroughReport,
        attempts: List<DatasetSourceAttempt>,
        candidates: List<DatasetAccessionCandidate>,
        finalForagerState: String,
        finalForagerNextAction: String,
        guardedForagerState: String,
        guardedForagerNextAction: String
    ): EvidenceLeadPathLinkageReport {
        val warnings = mutableListOf<String>()
        val manualSeedAccessions = manualSeedReport.candidates.map { it.candidate.accession }.toSet()
        val finalAccessions = candidates.map { it.accession }.toSet()
        val manualSeedLinked = !manualSeedReport.active || (
            attempts.any { it.sourceFamily == MANUAL_MODE } && manualSeedAccessions.all { it in finalAccessions }
        )
        if (!manualSeedLinked) {
            warnings += "Manual seed mode is active but seed candidates are not visible in both attempts and final candidate list."
        }

        val weakLeadLinked = relaxationReport.relaxedLeadCount == 0 || breakthroughReport.state == "WEAK_DATASET_LEAD_FOUND"
        if (!weakLeadLinked) {
            warnings += "Relaxed weak leads exist but breakthrough state does not expose WEAK_DATASET_LEAD_FOUND."
        }

        val breakthroughLinked = when (breakthroughReport.state) {
            "WEAK_DATASET_LEAD_FOUND" -> guardedForagerState.contains("WEAK_DATASET_LEAD", ignoreCase = true) || guardedForagerNextAction.contains("weak lead", ignoreCase = true) || guardedForagerNextAction.contains("secondary lookup", ignoreCase = true)
            "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION" -> guardedForagerState.contains("NEAR_MISS", ignoreCase = true) || guardedForagerNextAction.contains("manual", ignoreCase = true)
            "ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP" -> guardedForagerState.contains("SECONDARY_LOOKUP", ignoreCase = true) || guardedForagerNextAction.contains("secondary lookup", ignoreCase = true)
            else -> true
        }
        if (!breakthroughLinked) {
            warnings += "Breakthrough state is not reflected in the final forager decision or next action."
        }

        val consistencyApplied = finalForagerState == guardedForagerState && finalForagerNextAction == guardedForagerNextAction ||
            guardedForagerState == "DATASET_FORAGING_CONTINUE_PROBE"
        if (!consistencyApplied) {
            warnings += "Report Consistency Guard produced an unexpected decision handoff."
        }

        val postPubMedLinked = breakthroughReport.postPubMedSearchStrategies.isNotEmpty() && (
            guardedForagerNextAction.contains("post-PubMed", ignoreCase = true) ||
                guardedForagerNextAction.contains("secondary lookup", ignoreCase = true) ||
                guardedForagerNextAction.contains("manual", ignoreCase = true) ||
                breakthroughReport.state != "NO_PUBLIC_DATASET_AFTER_FULL_SWEEP"
        )
        if (!postPubMedLinked) {
            warnings += "Post-PubMed strategies exist but are not reachable from the final next action."
        }

        val state = if (warnings.isEmpty()) "EVIDENCE_LEAD_PATHS_CONNECTED" else "EVIDENCE_LEAD_PATH_LINKAGE_GAP"
        return EvidenceLeadPathLinkageReport(
            active = true,
            state = state,
            manualSeedLinkedToForager = manualSeedLinked,
            weakLeadLinkedToRelaxation = weakLeadLinked,
            breakthroughLinkedToDecision = breakthroughLinked,
            consistencyGuardApplied = consistencyApplied,
            postPubMedStrategyLinked = postPubMedLinked,
            warnings = warnings.distinct(),
            nextAction = if (warnings.isEmpty()) {
                "Keep v1.10.31 as a connected routing layer: manual seeds, weak leads, relaxation, breakthrough, and consistency guard share the same forager decision."
            } else {
                "Fix v1.10.31 linkage warnings before treating the cycle as GitHub-ready."
            }
        )
    }

    private fun secondaryLookupSeed(type: String, value: String, digest: String, index: Int): ManualEvidenceSeedCandidate {
        val accession = "MANUAL_${type}_${digest}_$index"
        return ManualEvidenceSeedCandidate(
            seedType = type,
            seedValue = value,
            sourceTextDigest = digest,
            candidate = leadCandidate(
                accession = accession,
                source = "MANUAL_EVIDENCE_SEED_MODE",
                sourceFindingId = "manual_seed_${digest}_$index",
                title = "Manual $type seed requires secondary lookup",
                url = "manual-seed:$digest",
                status = "ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP",
                reason = "Manual seed supplied $type without a direct dataset accession. Run secondary lookup before any evidence upgrade."
            ),
            nextLookupSource = when (type) {
                "PMID" -> "PubMed summary + abstract/data-availability accession mining"
                "DOI" -> "publisher/supplementary-data lookup + accession mining"
                "PDF" -> "PDF/data-availability phrase mining"
                else -> "manual text accession mining"
            }
        )
    }

    private fun leadCandidate(
        accession: String,
        source: String,
        sourceFindingId: String,
        title: String,
        url: String,
        status: String,
        reason: String
    ): DatasetAccessionCandidate = DatasetAccessionCandidate(
        accession = accession,
        source = source,
        organismHint = "unknown",
        conditionLabelsHint = "manual_or_weak_lead_needs_metadata",
        outcomeLabelsHint = "unknown_outcome_labels",
        triggerResponseOutcomeHint = "unknown_trigger_response_outcome",
        timeCourseHint = "unknown_time_order",
        sampleSizeHint = "unknown_sample_size",
        dataType = "unknown_dataset_type",
        usabilityScore = 10,
        status = status,
        sourceFindingId = sourceFindingId,
        sourceTitle = title,
        sourceUrl = url,
        reasons = listOf(reason, "LEAD_ONLY_NOT_EVIDENCE")
    )

    private fun accessionType(value: String): String = when {
        value.startsWith("GSE", ignoreCase = true) -> "GSE"
        value.startsWith("PRJNA", ignoreCase = true) -> "PRJNA"
        value.startsWith("SRP", ignoreCase = true) || value.startsWith("SRR", ignoreCase = true) -> "SRA"
        value.startsWith("E-MTAB", ignoreCase = true) -> "ARRAYEXPRESS"
        value.startsWith("SDY", ignoreCase = true) -> "IMM_PORT"
        value.startsWith("PHS", ignoreCase = true) || value.startsWith("EGAS", ignoreCase = true) -> "CONTROLLED_ACCESS"
        else -> "ACCESSION_TEXT"
    }

    private fun nextLookupSourceFor(value: String): String = when (accessionType(value)) {
        "GSE" -> "GEO direct metadata parse"
        "PRJNA", "SRA" -> "NCBI BioProject/SRA metadata parse"
        "ARRAYEXPRESS" -> "ArrayExpress metadata parse"
        "IMM_PORT" -> "ImmPort study metadata parse"
        "CONTROLLED_ACCESS" -> "controlled-access metadata/license review"
        else -> "secondary accession lookup"
    }

    private fun sha256(text: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
