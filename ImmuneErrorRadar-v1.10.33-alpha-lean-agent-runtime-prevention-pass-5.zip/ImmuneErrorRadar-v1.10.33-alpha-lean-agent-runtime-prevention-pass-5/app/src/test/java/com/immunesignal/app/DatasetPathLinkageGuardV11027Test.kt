package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DatasetPathLinkageGuardV11027Test {
    private fun accessionArchiveReport() = AccessionAcquisitionReport(
        active = true,
        state = "NO_ACCESSION_ARCHIVE_ROUTE",
        explicitAccessions = emptyList(),
        weakAccessions = emptyList(),
        unresolvedLeadCount = 0,
        archiveRecommended = false,
        compactReportRecommended = true,
        nextAction = "Archive or reframe this route before another search cycle.",
        reasons = listOf("test")
    )

    private fun matureProbeReport() = MatureDomainEvidenceProbePolicy.Report(
        active = true,
        state = "MATURE_DOMAIN_PROBE_BEFORE_ARCHIVE",
        summary = "Core accession sources failed, but mature domain expertise exists.",
        selectedDomains = listOf("antihistamine_histamine_mast_cell"),
        querySeeds = listOf("histamine mast cell GSE data availability accession"),
        probeAttempted = true,
        relaxedInterpretationAllowed = true,
        nextAction = "Run 1–2 mature-domain accession/data-availability probes using the strongest domain vocabulary; keep all claims locked."
    )

    @Test
    fun linksMatureDomainProbeAcrossFinalStateAndNextAction() {
        val attempts = listOf(
            DatasetSourceAttempt("GEO_GDS", "gds", "q1", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
            DatasetSourceAttempt("SRA_PRJNA", "sra", "q2", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
            DatasetSourceAttempt("IMM_PORT_SDY", "pubmed", "q3", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
            DatasetSourceAttempt("PUBMED_ACCESSION_MINING", "pubmed", "q4", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
            DatasetSourceAttempt(MatureDomainEvidenceProbePolicy.SOURCE_FAMILY, "pubmed", "q5", true, 0, 0, "MATURE_DOMAIN_PROBE_NO_FRESH_EVIDENCE", "test")
        )
        val report = DatasetForagingPathLinkageGuard.evaluate(
            attempts = attempts,
            accessionReport = accessionArchiveReport(),
            matureProbeReport = matureProbeReport(),
            foragerState = "DATASET_FORAGING_MATURE_DOMAIN_EVIDENCE_PROBE",
            foragerNextAction = matureProbeReport().nextAction
        )

        assertEquals("CONNECTED_MATURE_DOMAIN_PROBE", report.state)
        assertEquals(4, report.attemptedCoreCount)
        assertTrue(report.matureProbeAttempted)
        assertTrue(report.warnings.isEmpty())
        assertTrue(report.nextAction.contains("mature-domain", ignoreCase = true))
    }

    @Test
    fun warnsWhenMatureProbeIsActiveButFinalStateIsArchive() {
        val report = DatasetForagingPathLinkageGuard.evaluate(
            attempts = listOf(
                DatasetSourceAttempt("GEO_GDS", "gds", "q1", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
                DatasetSourceAttempt("SRA_PRJNA", "sra", "q2", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
                DatasetSourceAttempt("IMM_PORT_SDY", "pubmed", "q3", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
                DatasetSourceAttempt("PUBMED_ACCESSION_MINING", "pubmed", "q4", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test")
            ),
            accessionReport = accessionArchiveReport(),
            matureProbeReport = matureProbeReport(),
            foragerState = "DATASET_FORAGING_NO_ACCESSION_ARCHIVE_ROUTE",
            foragerNextAction = "Archive route."
        )

        assertEquals("LINKAGE_WARNINGS", report.state)
        assertTrue(report.warnings.any { it.contains("Mature-domain", ignoreCase = true) })
    }

    @Test
    fun matureDomainProbeCanBeConsumedByNearMissManualInspectionLeadPath() {
        val attempts = listOf(
            DatasetSourceAttempt("GEO_GDS", "gds", "q1", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
            DatasetSourceAttempt("SRA_PRJNA", "sra", "q2", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
            DatasetSourceAttempt("IMM_PORT_SDY", "pubmed", "q3", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
            DatasetSourceAttempt("PUBMED_ACCESSION_MINING", "pubmed", "q4", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
            DatasetSourceAttempt(MatureDomainEvidenceProbePolicy.SOURCE_FAMILY, "pubmed", "q5", true, 0, 0, "MATURE_DOMAIN_PROBE_NO_FRESH_EVIDENCE", "test")
        )
        val report = DatasetForagingPathLinkageGuard.evaluate(
            attempts = attempts,
            accessionReport = accessionArchiveReport(),
            matureProbeReport = matureProbeReport(),
            foragerState = "DATASET_FORAGING_NEAR_MISS_MANUAL_INSPECTION",
            foragerNextAction = "Inspect returned source IDs and supplementary-data phrases manually; a near miss exists but is not evidence."
        )

        assertEquals("CONNECTED_MATURE_DOMAIN_TO_LEAD_INSPECTION", report.state)
        assertTrue(report.handoffSummary.contains("consumedByLead=true"))
        assertTrue(report.warnings.isEmpty())
    }

}
