package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.10.61: Global research-grade compact report.
 * Keeps the final report short, decision-grade, and reviewer-readable while demoting
 * verbose runtime traces to Advanced/technical export paths.
 */
object GlobalResearchGradeBriefV11061 {
    private const val CLAIM_BOUNDARY = "research_leads_only_not_biological_proof"

    fun render(report: JSONObject): String = renderLines(report).joinToString("\n")

    fun renderLines(report: JSONObject): List<String> {
        val runtime = report.optJSONObject("runtimeStatus") ?: JSONObject()
        val execution = report.optJSONObject("executionLockReport") ?: JSONObject()
        val v3 = report.optJSONObject("reportV3") ?: JSONObject()
        val forager = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val learning = report.optJSONObject("learningOsReport") ?: JSONObject()
        val readiness = learning.optJSONObject("discoveryReadiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        val matrix = forager.optJSONObject("metadataClosureStrategyMatrixReport") ?: JSONObject()
        val mechanism = forager.optJSONObject("mechanismDiscoveryDossierReport") ?: JSONObject()
        val score = forager.optJSONObject("scoreSeparation") ?: JSONObject()
        val accession = forager.optJSONObject("accessionAcquisitionReport") ?: JSONObject()
        val metadataClosure = forager.optJSONObject("metadataClosureReport") ?: JSONObject()
        val topicFit = forager.optJSONObject("topicFitMetadataParseReport") ?: JSONObject()
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        val queries = report.optJSONArray("queries") ?: JSONArray()
        val evidenceCount = evidenceObjects.length()
        val explicitAccessions = jsonArray(accession.optJSONArray("explicitAccessions"))
        val weakAccessions = jsonArray(accession.optJSONArray("weakAccessions"))
        val commands = jsonArray(matrix.optJSONArray("programmaticCommandLog"))
        val streams = jsonArray(matrix.optJSONArray("multiDimensionalAccessionSearchStreams"))
        val linkageQueries = jsonArray(matrix.optJSONArray("controlComparatorLinkageQueries"))
        val missingFields = jsonArray(metadataClosure.optJSONArray("missingFields"))
        val mechanismGaps = jsonArray(mechanism.optJSONArray("blockingGaps"))
        val accessionCards = jsonArray(mechanism.optJSONArray("accessionCandidates"))
        val mechanismRoutes = jsonArray(mechanism.optJSONArray("mechanismRoutes"))
        val hardGates = jsonArray(matrix.optJSONArray("hardClaimGates"))
        val topTargets = jsonArray(matrix.optJSONArray("detectedTargets")).take(6)
        val rootCauses = jsonArray((learning.optJSONObject("incident") ?: JSONObject()).optJSONArray("rootCauses")).take(4)
        val title = "Global Research-Grade Discovery Brief"
        val evidenceGrade = evidenceGrade(evidenceCount, explicitAccessions.size, score.optInt("routeFitScore", 0), score.optBoolean("hypothesisUpgradeAllowed", false))
        val selectedRoute = firstNonBlank(
            topicFit.optString("preferredLane"),
            accession.optString("state"),
            forager.optString("state"),
            "dataset-hunt"
        ).replace('_', ' ')
        val next = firstNonBlank(
            matrix.optString("nextAction"),
            v3.optString("nextAutonomousMove"),
            learning.optString("nextLearningAction"),
            "Run accession-specific metadata closure."
        )
        val result = firstNonBlank(
            v3.optString("cycleResult"),
            matrix.optString("state"),
            forager.optString("state"),
            "No discovery result reported."
        )
        val lines = mutableListOf<String>()
        lines += title
        lines += "Engine: ${runtime.optString("engineVersion", "unknown")} | Lock: ${execution.optString("status", "UNKNOWN")} | State: ${runtime.optString("researchState", "UNKNOWN")}"
        lines += "Decision: ${truncate(result, 140)}"
        lines += "Evidence grade: ${firstNonBlank(mechanism.optString("evidenceGrade"), evidenceGrade)} | evidenceObjects=$evidenceCount | accessions=${explicitAccessions.size} | accessionCards=${accessionCards.size} | weakHandles=${weakAccessions.size}"
        lines += "Scores: usability ${score.optInt("datasetUsabilityScore", 0)}/100 | route-fit ${score.optInt("routeFitScore", 0)}/100 | hypothesis ${score.optInt("hypothesisConfidenceScore", 0)}/100 | upgrade=${score.optBoolean("hypothesisUpgradeAllowed", false)}"
        lines += "Route: ${truncate(selectedRoute, 110)}"
        if (topTargets.isNotEmpty()) lines += "Target intersection: ${topTargets.joinToString(", ")}"
        if (matrix.optBoolean("hyperDriveModeActive", false) || matrix.optBoolean("aggressiveQueryStreamUnlocked", false)) {
            lines += "Foraging mode: Hyper-Drive accession search | forced route-fit target=${matrix.optInt("forcedRouteFitTarget", matrix.optInt("routeFitElevationFloor", 0))}/100 | anomaly=${matrix.optBoolean("criticalUsabilityAnomaly", false)}"
        }
        lines += "Primary finding: ${truncate(firstNonBlank(v3.optString("supportingEvidence"), v3.optString("newUsefulLead"), "No support survived evidence gates."), 170)}"
        lines += "Matrix gate: ${firstNonBlank(mechanism.optString("matrixAnalysisGate"), "DGE_NOT_READY_METADATA_GAP")} | Mechanism state: ${firstNonBlank(mechanism.optString("state"), "NOT_EVALUATED")}"
        if (mechanismRoutes.isNotEmpty()) lines += "Mechanism route: ${truncate(mechanismRoutes.first(), 150)}"
        lines += "Blocking gap: ${(mechanismGaps + missingFields).take(5).joinToString(", ").ifBlank { rootCauses.joinToString(", ").ifBlank { "no decisive blocker exposed" } }}"
        lines += "Contradiction status: ${truncate(firstNonBlank(v3.optString("counterEvidenceOrContradiction"), "Contradiction search pending."), 150)}"
        if (explicitAccessions.isNotEmpty()) {
            lines += "Accession IDs: ${explicitAccessions.take(8).joinToString(", ")}"
        } else {
            lines += "Accession IDs: none confirmed in this cycle; continue hard extraction without fabricating IDs."
        }
        if (streams.isNotEmpty()) lines += "Active query stream: ${truncate(streams.first(), 170)}"
        if (commands.isNotEmpty()) lines += "Command trace: ${truncate(commands.first(), 170)}"
        if (linkageQueries.isNotEmpty()) lines += "Comparator linkage: ${truncate(linkageQueries.first(), 170)}"
        lines += "Next discriminating action: ${truncate(firstNonBlank(mechanism.optString("nextDecisiveAction"), next), 190)}"
        val doNotBelieve = firstNonBlank(v3.optString("whatWeDoNotBelieveYet"), v3.optString("doNotBelieveYet"), "No biological claim is proven.")
        lines += "Do not believe yet: ${truncate(doNotBelieve, 180)}"
        if (hardGates.isNotEmpty()) lines += "Hard gates before upgrade: ${hardGates.take(6).joinToString(", ")}"
        lines += "Search footprint: queries=${queries.length()} | readiness=${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")}"
        lines += "Boundary: ${firstNonBlank(mechanism.optString("claimBoundary"), CLAIM_BOUNDARY)}; no diagnosis, treatment, dose, supplement, causal claim, DGE/fold-change/p-value, or patient prediction."
        lines += "Appendix policy: detailed runtime traces stay in Advanced/technical export, not the final brief."
        return lines.take(RuntimeFeatureFlags.GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061.coerceAtLeast(18))
    }

    private fun evidenceGrade(evidenceObjects: Int, accessions: Int, routeFit: Int, upgradeAllowed: Boolean): String = when {
        upgradeAllowed && evidenceObjects > 0 && accessions > 0 -> "B — evidence object ready for controlled review"
        evidenceObjects > 0 && accessions > 0 -> "C+ — evidence object present, claims still gated"
        accessions > 0 -> "C — accession found, metadata closure required"
        routeFit >= 85 -> "D+ — high-priority route, no confirmed accession yet"
        routeFit >= 50 -> "D — useful lead, decisive metadata missing"
        else -> "E — exploratory lead only"
    }

    private fun jsonArray(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { idx ->
            val value = array.opt(idx) ?: return@mapNotNull null
            when (value) {
                is JSONObject -> firstNonBlank(
                    value.optString("accessionId"),
                    value.optString("routeId"),
                    value.optString("targetMolecularAxis"),
                    value.optString("streamId"),
                    value.optString("query"),
                    value.optString("label"),
                    value.optString("gateId"),
                    value.toString()
                )
                else -> value.toString()
            }.takeIf { it.isNotBlank() }
        }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""

    private fun truncate(value: String, max: Int): String {
        val oneLine = value.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1).trimEnd() + "…"
    }
}
