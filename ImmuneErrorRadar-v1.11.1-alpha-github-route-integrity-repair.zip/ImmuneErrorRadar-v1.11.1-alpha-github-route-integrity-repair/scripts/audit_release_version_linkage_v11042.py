#!/usr/bin/env python3
from pathlib import Path
# v1.10.59_patch_note_fast_gate_owned_by_v11055: historical release audits no longer require old audits inside fast gate.
ROOT = Path('.')
checks = {
    'app/build.gradle.kts': ['versionCode = 104', 'versionName = "1.10.42-alpha-biomedical-concept-bridge"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.42-alpha-biomedical-concept-bridge', 'BiomedicalConceptBridge'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.10.42-alpha-biomedical-concept-bridge"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 104',
        'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.42"'
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 104',
        'VERSION_NAME: String = "1.10.42-alpha-biomedical-concept-bridge"',
        'ENGINE_VERSION: String = "v1.10.42-alpha-biomedical-concept-bridge"',
        'LEARNING_SCHEMA_VERSION: String = "1.10.42"',
        'biomedical concept bridge release'
    ],
    'scripts/run_static_checks_full.sh': ['audit_v11042_biomedical_concept_bridge.py', 'audit_release_version_linkage_v11042.py'],
    'scripts/run_static_checks.sh': ['1.10.42-alpha-biomedical-concept-bridge'],
    'docs/CHANGELOG_v1.10.42.md': ['v1.10.42-alpha-biomedical-concept-bridge', 'VersionCode: `104`'],
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.42 release file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.42 release token: {token}')
print('v1.10.42 release version linkage audit: PASS')
