#!/usr/bin/env python3
from pathlib import Path
# v1.10.59_patch_note_fast_gate_owned_by_v11055: historical release audits no longer require old audits inside fast gate.
ROOT = Path('.')
checks = {
    'app/build.gradle.kts': ['versionCode = 103', 'versionName = "1.10.41-alpha-biomedical-research-ontology"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.41-alpha-biomedical-research-ontology', 'IntegratedPathLinkageGuard'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 103', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.41"'
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 103', 'VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"',
        'ENGINE_VERSION: String = "v1.10.41-alpha-biomedical-research-ontology"', 'LEARNING_SCHEMA_VERSION: String = "1.10.41"',
        'integrated final path linkage'
    ],
    'scripts/run_static_checks_full.sh': ['audit_v11039_integrated_path_linkage.py', 'audit_release_version_linkage_v11039.py'],
    'scripts/run_static_checks.sh': ['1.10.41-alpha-biomedical-research-ontology'],
    'docs/CHANGELOG_v1.10.39.md': ['v1.10.39-alpha-final-path-linkage-release', 'VersionCode: `101`'],
    'docs/CHANGELOG_v1.10.40.md': ['v1.10.40-alpha-release-stability-gate', 'VersionCode: `102`']
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.39 release file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.39 release token: {token}')
print('v1.10.39 release version linkage audit: PASS')
