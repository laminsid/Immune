package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMResearchIntentParserV255Test {
    @Test
    fun structuredQuestionBuildsResearchIntentObject() {
        val text = """
            Disease / phenotype: Long COVID fatigue
            Trigger: EBV or HHV-6 reactivation after SARS-CoV-2
            Pathway: interferon signaling, IL-6/TNF, T-cell exhaustion, B-cell dysregulation
            Cell / tissue: PBMC, T cells, B cells, monocytes
            Comparator: Long COVID vs recovered controls vs healthy controls
            Assay: RNA-seq, scRNA-seq, cytokine profiling
            Repositories: GEO, SRA, ArrayExpress, ImmPort
            Contradiction: studies showing no EBV association or opposite cytokine direction
            Output: discovery brief, no raw JSON
        """.trimIndent()
        val intent = GTIMResearchIntentParserV255.parse(text)
        assertTrue(intent.active)
        assertEquals("STRUCTURED_INTAKE", intent.inputMode)
        assertTrue(intent.diseasePhenotype.any { it.contains("Long COVID") })
        assertTrue(intent.triggerExposure.any { it.contains("EBV") })
        assertTrue(intent.pathway.any { it.contains("IL-6") || it.contains("TNF") })
        assertTrue(intent.cellTissue.any { it.contains("PBMC") })
        assertTrue(intent.assayType.any { it.contains("RNA-seq") })
        assertTrue(intent.repositoryTargets.any { it.contains("GEO") })
        assertTrue(intent.comparatorWanted.isNotEmpty())
        assertTrue(intent.intentCompletenessScore >= 80)
    }

    @Test
    fun intentFeedsDataFeedPlannerAndDoesNotReturnZeroScores() {
        val intent = GTIMResearchIntentParserV255.parse(
            "EBV reactivation -> Long COVID fatigue -> interferon + IL-6/TNF -> PBMC/T cells/B cells -> Long COVID vs recovered vs healthy -> RNA-seq/scRNA-seq/cytokines GEO SRA ImmPort"
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        assertTrue(plan.active)
        assertEquals("GTIM_DATAFEED_PLAN_VISIBLE", plan.status)
        assertTrue(intent.intentCompletenessScore > 0)
        assertTrue(plan.dataFeedPlanScore > 0)
        assertTrue(plan.repositorySearchPlan.isNotEmpty())
        assertTrue(plan.querySeeds.any { it.contains("EBV") || it.contains("Long COVID") })
    }

    @Test
    fun candidateRouteDoesNotBecomeEvidenceObjectOrMatrix() {
        val intent = GTIMResearchIntentParserV255.parse("EBV Long COVID interferon PBMC RNA-seq healthy controls GEO")
        val split = GTIMDiscoveryEvidenceSplitV256.evaluate(
            intent = intent,
            plan = GTIMDataFeedPlannerV255.plan(intent),
            report = ResearchGradeMechanismDossierReportV1110.empty().copy(active = true, researchQuestion = intent.sourceText),
            evidenceObjects = emptyList(),
            mechanismCandidates = emptyList()
        )
        assertTrue(split.active)
        assertTrue(split.candidateRoutes.isNotEmpty())
        assertEquals("SEMANTIC_PRIOR_NOT_MATRIX", split.semanticMechanismPrior.status)
        assertEquals("LAB_PROTOCOL_DRAFT_NOT_VALIDATION", split.preliminaryLabProtocol.status)
        assertTrue(split.evidenceUpgradeStillLocked.any { it.contains("Candidate route") })
    }
}
