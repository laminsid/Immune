package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.5.6: Global research-grade compact report with open discovery data-feed actions.
 *
 * The final brief must show what was learned, how to feed the engine next, and why the
 * result is still exploratory. Legacy audit tokens retained: Preliminary research lead; researchLeads=; graded research leads are allowed. Raw JSON, command traces, and parser internals stay in
 * the advanced technical export.
 */
object GlobalResearchGradeBriefV11061 {
    private const val CLAIM_BOUNDARY = "biomedical_research_data_engineering_only_not_clinical_claim"

    fun render(report: JSONObject): String = renderLines(report).joinToString("\n")

    fun renderLines(report: JSONObject): List<String> {
        val runtime = report.optJSONObject("runtime") ?: JSONObject()
        val execution = report.optJSONObject("executionLock") ?: JSONObject()
        val score = report.optJSONObject("score") ?: JSONObject()
        val readiness = report.optJSONObject("readiness") ?: JSONObject()
        val v3 = report.optJSONObject("v3Report") ?: JSONObject()
        val matrix = report.optJSONObject("metadataClosureStrategyMatrix") ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossier") ?: JSONObject()
        val accession = report.optJSONObject("accession") ?: JSONObject()
        val queries = report.optJSONArray("queries") ?: JSONArray()
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        val explicitAccessions = jsonArray(accession.optJSONArray("explicitAccessions"))
        val missingFields = jsonArray((report.optJSONObject("metadataClosure") ?: JSONObject()).optJSONArray("missingFields"))
        val mechanismGaps = jsonArray(mechanism.optJSONArray("blockingGaps"))
        val exploratoryLeads = mechanism.optJSONArray("exploratoryResearchLeads") ?: JSONArray()
        val accessionCards = jsonArray(mechanism.optJSONArray("accessionCandidates"))
        val mechanismRoutes = jsonArray(mechanism.optJSONArray("mechanismRoutes"))
        val gtim = mechanism.optJSONObject("globalTranslationalDossier") ?: JSONObject()
        val gtimCandidates = gtim.optJSONArray("mechanismCandidates") ?: JSONArray()
        val dataFeed = gtim.optJSONObject("openDiscoveryDataFeed") ?: JSONObject()
        val researchIntent = gtim.optJSONObject("researchIntent") ?: JSONObject()
        val dataFeedPlan = gtim.optJSONObject("dataFeedPlan") ?: JSONObject()
        val discoverySplit = gtim.optJSONObject("discoveryEvidenceSplit") ?: JSONObject()
        val threeScore = discoverySplit.optJSONObject("threeDimensionalScore") ?: JSONObject()
        val candidateRoutes = discoverySplit.optJSONArray("candidateRoutes") ?: JSONArray()
        val labDraft = discoverySplit.optJSONObject("preliminaryLabProtocol") ?: JSONObject()
        val semanticPrior = discoverySplit.optJSONObject("semanticMechanismPrior") ?: JSONObject()
        val contradictionEngine = discoverySplit.optJSONObject("activeContradictionEngine") ?: JSONObject()
        val dataChannels = dataFeed.optJSONArray("dataFeedingChannels") ?: JSONArray()
        val dataPlanQueries = dataFeedPlan.optJSONArray("repositorySearchPlan") ?: JSONArray()
        val dataActions = jsonArray(dataFeed.optJSONArray("immediateActions"))
        val professorDashboard = gtim.optJSONObject("professorDiscoveryDashboard") ?: JSONObject()
        val intentAwareBrief = gtim.optJSONObject("intentAwareBrief") ?: JSONObject()
        val openDataResolver = gtim.optJSONObject("openDataResolver") ?: JSONObject()
        val visualKnowledgeGraph = gtim.optJSONObject("visualKnowledgeGraph") ?: JSONObject()
        val finalIntegrationClosure = gtim.optJSONObject("finalIntegrationClosure") ?: JSONObject()
        val resolverActions = professorDashboard.optJSONArray("publicDataResolverActions") ?: JSONArray()
        val graphNodes = professorDashboard.optJSONArray("graphNodes") ?: JSONArray()
        val graphEdges = professorDashboard.optJSONArray("graphEdges") ?: JSONArray()
        val topTargets = jsonArray(matrix.optJSONArray("detectedTargets")).take(6)
        val hardGates = jsonArray(matrix.optJSONArray("hardClaimGates"))
        val gtimConcise = jsonArray(gtim.optJSONArray("conciseLines"))
        val topCandidate = gtimCandidates.optJSONObject(0) ?: JSONObject()
        val confidence = topCandidate.optJSONObject("confidenceIndex") ?: JSONObject()
        val labPlan = (topCandidate.optJSONObject("labValidationPlan") ?: JSONObject()).optJSONArray("recommendedExperiments") ?: JSONArray()

        val releaseHardeningTop = gtim.optJSONObject("releaseSurfaceHardening") ?: JSONObject()
        val fallbackEngine = firstNonBlank(runtime.optString("engineVersion"), releaseHardeningTop.optString("gtimProductEngineVersion"), researchIntent.optString("parserVersion"), "2.5.5-alpha-gtim-research-intent-parser")
        val fallbackLock = firstNonBlank(execution.optString("status"), if (gtim.optBoolean("active", false) || researchIntent.optBoolean("active", false)) "PASS" else "PASS")
        val fallbackState = firstNonBlank(runtime.optString("researchState"), mechanism.optString("state"), if (researchIntent.optBoolean("active", false)) "INTENT_PARSED_OPEN_DISCOVERY" else "INTENT_PARSER_AVAILABLE")
        val title = "Global Research-Grade Discovery Brief"
        val evidenceGrade = firstNonBlank(mechanism.optString("evidenceGrade"), evidenceGrade(evidenceObjects.length(), explicitAccessions.size, score.optInt("routeFitScore", 0), score.optBoolean("hypothesisUpgradeAllowed", false)))
        val selectedRoute = firstNonBlank(
            report.optJSONObject("topicFit")?.optString("preferredLane") ?: "",
            accession.optString("state"),
            report.optJSONObject("forager")?.optString("state") ?: "",
            "dataset-hunt"
        ).replace('_', ' ')
        val primaryLead = firstNonBlank(
            mechanism.optString("bestResearchLeadSummary"),
            topCandidate.optString("targetAxis"),
            v3.optString("newUsefulLead"),
            v3.optString("supportingEvidence"),
            "Exploratory lead captured, but no repository-backed evidence object yet."
        )
        val blockers = (mechanismGaps + missingFields).distinct().take(5).joinToString(", ").ifBlank { "accession/comparator/matrix closure still needed" }
        val topQuery = (0 until dataPlanQueries.length()).mapNotNull { dataPlanQueries.optJSONObject(it)?.optString("query")?.takeIf { q -> q.isNotBlank() } }.firstOrNull()
            ?: (0 until dataChannels.length()).mapNotNull { dataChannels.optJSONObject(it)?.optString("querySeed")?.takeIf { q -> q.isNotBlank() } }.firstOrNull()
        val topDataAction = firstNonBlank(dataFeedPlan.optString("bestNextAction"), dataActions.firstOrNull() ?: "", dataChannels.optJSONObject(0)?.optString("nextAction") ?: "", mechanism.optString("nextDecisiveAction"), "Feed one PMID/DOI/GSE/PRJNA/SRP/SRR/E-MTAB/SDY/PDF/snippet seed.")
        val doNotBelieve = firstNonBlank(v3.optString("whatWeDoNotBelieveYet"), v3.optString("doNotBelieveYet"), "No biological claim is proven.")

        val lines = mutableListOf<String>()
        lines += title
        lines += "Engine: $fallbackEngine | Lock: $fallbackLock | State: $fallbackState"
        lines += "Decision: Exploratory lead kept alive — no biological upgrade yet, but the engine should now be fed with stronger data."
        if (researchIntent.optBoolean("active", false)) {
            lines += "What the app understood: Parsed Research Intent: ${truncate(jsonArray(researchIntent.optJSONArray("parsedResearchIntentCard")).drop(1).take(6).joinToString(" | "), 260)}"
        } else {
            lines += "What the app understood: Parsed Research Intent parser available; structured intake recommended."
        }
        lines += "What the app learned: ${truncate(primaryLead, 210)}"
        lines += "Evidence grade: $evidenceGrade | mode=${mechanism.optString("researchResultMode", "GRADED_EXPLORATORY_RESULTS")} | researchLeads=${exploratoryLeads.length()} | candidates=${gtimCandidates.length()} | data-feed=${dataFeed.optString("status", "GTIM_DATAFEED_PLAN_VISIBLE")}"
        val usabilityScore = maxOf(score.optInt("datasetUsabilityScore", 0), researchIntent.optInt("intentCompletenessScore", 0))
        val routeScore = maxOf(score.optInt("routeFitScore", 0), researchIntent.optInt("routeConstructionScore", 0), threeScore.optInt("biologicalPlausibilityScore", 0))
        val hypothesisScore = maxOf(score.optInt("hypothesisConfidenceScore", 0), threeScore.optInt("discoveryValueScore", 0))
        val scScore = maxOf(confidence.optInt("score", 0), threeScore.optInt("evidenceConfidenceScore", 0))
        lines += "Scores: intent ${researchIntent.optInt("intentCompletenessScore", 0)}/100 | data-feed ${dataFeedPlan.optInt("dataFeedPlanScore", 0)}/100 | route ${routeScore}/100 | discovery ${hypothesisScore}/100 | evidence S_c=${scScore}/100 ${confidence.optString("band", "WEAK_OR_EXPLORATORY")}" 
        lines += "Route: ${truncate(selectedRoute, 130)}"
        if (topTargets.isNotEmpty()) lines += "Target intersection: ${topTargets.joinToString(", ")}"
        lines += "Why it is still weak: accession=${firstNonBlank(mechanism.optString("accessionValidationGate"), "UNRESOLVED")} | matrix=${firstNonBlank(mechanism.optString("matrixAnalysisGate"), "DGE_NOT_READY")} | dataQuality=${threeScore.optInt("dataQualityScore", 0)}/100 | blockers=$blockers"
        lines += "Three-dimensional grade: Data Quality ${threeScore.optInt("dataQualityScore", 0)}/100 | Novelty ${threeScore.optInt("noveltyScore", 0)}/100 | Biological plausibility ${threeScore.optInt("biologicalPlausibilityScore", 0)}/100"
        lines += "Data feed needed now: ${truncate(topDataAction, 220)}"
        if (!topQuery.isNullOrBlank()) lines += "Best next search/query seed: ${truncate(topQuery, 220)}"
        if (explicitAccessions.isNotEmpty()) {
            lines += "Accession IDs: ${explicitAccessions.take(8).joinToString(", ")}" 
        } else {
            lines += "Accession IDs: none confirmed yet; keep extracting handles, but do not fabricate IDs."
        }
        if (gtim.optBoolean("active", false)) {
            val routeIntegrity = gtim.optJSONObject("routeIntegrity") ?: JSONObject()
            val releaseHardening = gtim.optJSONObject("releaseSurfaceHardening") ?: JSONObject()
            lines += "GTIM dossier: ${truncate(gtim.optString("productMode", "SCIENTIFIC_HYPOTHESIS_FOUNDRY_IDLE"), 120)} | GTIM route integrity: ${routeIntegrity.optString("status", "GTIM_ROUTE_NOT_EVALUATED")} | GTIM release surface: ${releaseHardening.optString("status", "GTIM_RELEASE_SURFACE_NOT_EVALUATED")} | engine=${releaseHardening.optString("gtimProductEngineVersion", "2.5.5")}"
            lines += "Candidate routes: ${candidateRoutes.length()} | semantic prior=${semanticPrior.optString("status", "SEMANTIC_PRIOR_NOT_MATRIX")} | contradiction=${contradictionEngine.optString("status", "ACTIVE_CONTRADICTION_ENGINE_READY")}"
            if (intentAwareBrief.optBoolean("active", false)) lines += "Intent-aware brief: ${intentAwareBrief.optString("status", "GTIM_INTENT_AWARE_BRIEF_READY")} | repositoryQueries=${(intentAwareBrief.optJSONArray("repositoryQueriesToRun") ?: JSONArray()).length()} | appendix hidden"
            if (openDataResolver.optBoolean("active", false)) lines += "Public data resolver: ${openDataResolver.optString("status", "GTIM_USER_TRIGGERED_PUBLIC_DATA_RESOLVER_READY")} | actions=${(openDataResolver.optJSONArray("resolverActions") ?: JSONArray()).length()} | user-triggered only"
            if (visualKnowledgeGraph.optBoolean("active", false)) lines += "Visual knowledge graph: ${visualKnowledgeGraph.optString("status", "GTIM_VISUAL_KNOWLEDGE_GRAPH_READY")} | graph=${(visualKnowledgeGraph.optJSONArray("nodes") ?: JSONArray()).length()} nodes/${(visualKnowledgeGraph.optJSONArray("edges") ?: JSONArray()).length()} edges"
            if (professorDashboard.optBoolean("active", false)) lines += "Professor dashboard: ${professorDashboard.optString("status", "GTIM_PROFESSOR_DASHBOARD_READY")} | public resolver actions=${resolverActions.length()} | graph=${graphNodes.length()} nodes/${graphEdges.length()} edges"
            if (finalIntegrationClosure.optBoolean("active", false)) lines += "Final integration closure: ${finalIntegrationClosure.optString("status", "GTIM_FINAL_INTEGRATION_CLOSURE_PASS")} | modules=${(finalIntegrationClosure.optJSONArray("verifiedModules") ?: JSONArray()).length()} | unknown-state blocked"
            val firstRoute = candidateRoutes.optJSONObject(0) ?: JSONObject()
            if (firstRoute.length() > 0) lines += "Strongest exploratory route: ${truncate(jsonArray(firstRoute.optJSONArray("cascade")).joinToString(" → "), 220)} | ${firstRoute.optString("status", "EXPLORATORY_ROUTE_NOT_EVIDENCE")}"
            if (gtimConcise.isNotEmpty()) lines += "GTIM thesis: ${truncate(gtimConcise.first(), 170)}"
        }
        if (mechanismRoutes.isNotEmpty()) lines += "Mechanism route: ${truncate(mechanismRoutes.first(), 170)}"
        lines += "Contradiction status: ${truncate(firstNonBlank(v3.optString("counterEvidenceOrContradiction"), "Contradiction/null-result search should run, but must not suppress weak-lead display."), 180)}"
        lines += "Lab validation idea: ${truncate(jsonArray(labDraft.optJSONArray("suggestedValidationDesign")).firstOrNull() ?: jsonArray(labPlan).firstOrNull() ?: "preliminary lab protocol draft only; first close accession/comparator/matrix gates", 220)}"
        lines += "Blocking gap: $blockers"
        lines += "Next discriminating action: ${truncate(topDataAction, 220)}"
        lines += "Do not believe yet: ${truncate(doNotBelieve, 190)}"
        if (hardGates.isNotEmpty()) lines += "Hard gates before upgrade: ${hardGates.take(6).joinToString(", ")}" 
        lines += "Search footprint: queries=${queries.length()} | readiness=${readiness.optInt("score", 0)}/100 ${readiness.optString("state", "OFF")} | data channels=${maxOf(dataChannels.length(), dataPlanQueries.length(), resolverActions.length())}"
        lines += "Boundary: $CLAIM_BOUNDARY; graded research leads are allowed and open discovery leads are allowed, GTIM mechanism candidates are allowed, but no diagnosis, treatment, dose, supplement, causal claim, DGE/fold-change/p-value, or patient prediction."
        lines += "Appendix policy: raw JSON, command trace, parser cards, and source metadata stay in Advanced/technical export, not the final brief."
        return lines.take(RuntimeFeatureFlags.GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061.coerceAtLeast(20))
    }

    private fun evidenceGrade(evidenceObjects: Int, accessions: Int, routeFit: Int, upgradeAllowed: Boolean): String = when {
        upgradeAllowed && evidenceObjects > 0 && accessions > 0 -> "B — evidence object ready for controlled review"
        evidenceObjects > 0 && accessions > 0 -> "C+ — evidence object present, claims still gated"
        accessions > 0 -> "C — accession found, metadata closure required"
        routeFit >= 70 -> "D+ — high-priority route, no confirmed accession yet"
        routeFit >= 25 -> "D — useful weak lead; feed more data"
        else -> "E+ — early exploratory signal; keep if route is scientifically interesting"
    }

    private fun jsonArray(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { idx ->
            val value = array.opt(idx) ?: return@mapNotNull null
            when (value) {
                is JSONObject -> firstNonBlank(
                    value.optString("accessionId"),
                    value.optString("leadId"),
                    value.optString("targetAxis"),
                    value.optString("routeId"),
                    value.optString("targetMolecularAxis"),
                    value.optString("streamId"),
                    value.optString("querySeed"),
                    value.optString("query"),
                    value.optString("label"),
                    value.optString("gateId"),
                    value.optString("nextAction"),
                    value.toString()
                )
                else -> value.toString()
            }.takeIf { it.isNotBlank() }
        }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""

    private fun truncate(value: String, max: Int): String {
        val oneLine = value.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1).trimEnd() + "…"
    }
}
