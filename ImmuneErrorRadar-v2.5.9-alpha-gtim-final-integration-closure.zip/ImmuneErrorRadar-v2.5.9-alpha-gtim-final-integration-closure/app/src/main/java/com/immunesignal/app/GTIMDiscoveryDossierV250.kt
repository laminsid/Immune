package com.immunesignal.app

import java.util.Locale
import kotlin.math.roundToInt

/**
 * GTIM v2.5.6 unified relaxed-exploration dossier adapter.
 *
 * It consumes the existing ResearchGradeMechanismDossierV1110 output and upgrades the final report
 * surface into a global translational-immunology hypothesis dossier. The adapter is wired into the
 * existing mechanism dossier JSON path; it is not a parallel island.
 */
object GTIMDiscoveryDossierV250 {
    fun fromMechanismDossier(report: ResearchGradeMechanismDossierReportV1110): GTIMDiscoveryDossierReportV250 {
        if (!report.active) return GTIMDiscoveryDossierReportV250.empty()

        val researchIntent = GTIMResearchIntentParserV255.parse(report.researchQuestion, report.bestResearchLeadSummary)
        val evidenceObjects = buildEvidenceObjects(report)
        val mechanismCandidates = buildMechanismCandidates(report, evidenceObjects)
        val dataFeedPlan = GTIMDataFeedPlannerV255.plan(researchIntent)
        val discoveryEvidenceSplit = GTIMDiscoveryEvidenceSplitV256.evaluate(researchIntent, dataFeedPlan, report, evidenceObjects, mechanismCandidates)
        val routeIntegrity = GTIMRouteIntegrityGuardV251.evaluate(report, evidenceObjects, mechanismCandidates)
        val mode = when {
            mechanismCandidates.any { it.confidenceIndex.score >= 76 } -> "LAB_VALIDATION_READY_DOSSIER"
            mechanismCandidates.any { it.confidenceIndex.score >= 61 } -> "STRONG_RESEARCH_CANDIDATE"
            mechanismCandidates.any { it.confidenceIndex.score >= 35 } -> "PLAUSIBLE_MECHANISM_CANDIDATE"
            mechanismCandidates.isNotEmpty() -> "EXPLORATORY_HYPOTHESIS_DOSSIER"
            evidenceObjects.isNotEmpty() -> "EVIDENCE_OBJECT_MAPPING_ONLY"
            else -> "SCIENTIFIC_HYPOTHESIS_FOUNDRY_IDLE"
        }
        val lines = conciseLines(report, evidenceObjects, mechanismCandidates, routeIntegrity, mode)
        val interim = GTIMDiscoveryDossierReportV250(
            active = true,
            engineIdentity = GTIMClaimGuardV250.ENGINE_IDENTITY,
            missionStatement = GTIMClaimGuardV250.MISSION_STATEMENT,
            productMode = mode,
            noveltyBoundary = GTIMClaimGuardV250.CORPUS_RELATIVE_NOVELTY_BOUNDARY,
            evidenceObjects = evidenceObjects,
            mechanismCandidates = mechanismCandidates,
            dataScarcityMitigation = GTIMClaimGuardV250.DATA_SCARCITY_MITIGATION,
            globalUseCases = GTIMClaimGuardV250.GLOBAL_USE_CASES,
            claimGuardrails = GTIMClaimGuardV250.CLAIM_GUARDRAILS,
            peerReviewDossierSections = GTIMClaimGuardV250.PEER_REVIEW_DOSSIER_SECTIONS,
            routeIntegrity = routeIntegrity,
            researchIntent = researchIntent,
            dataFeedPlan = dataFeedPlan,
            discoveryEvidenceSplit = discoveryEvidenceSplit,
            conciseLines = lines
        )
        val openDiscoveryDataFeed = GTIMOpenDiscoveryDataFeedingV254.evaluate(report, evidenceObjects, mechanismCandidates, routeIntegrity)
        val professorDashboard = GTIMProfessorDiscoveryDashboardV257.build(researchIntent, dataFeedPlan, discoveryEvidenceSplit, openDiscoveryDataFeed)
        val intentAwareBrief = GTIMIntentAwareBriefRendererV255.render(researchIntent, dataFeedPlan, discoveryEvidenceSplit, professorDashboard)
        val openDataResolver = GTIMOpenDataResolverV256.plan(dataFeedPlan, openDiscoveryDataFeed, professorDashboard)
        val visualKnowledgeGraph = GTIMVisualKnowledgeGraphV257.build(researchIntent, discoveryEvidenceSplit, professorDashboard)
        val interimWithDashboard = interim.copy(
            openDiscoveryDataFeed = openDiscoveryDataFeed,
            professorDiscoveryDashboard = professorDashboard,
            intentAwareBrief = intentAwareBrief,
            openDataResolver = openDataResolver,
            visualKnowledgeGraph = visualKnowledgeGraph
        )
        val releaseSurfaceHardening = GTIMReleaseSurfaceHardeningV252.evaluate(interimWithDashboard, routeIntegrity)
        val finalIntegrationClosure = GTIMFinalIntegrationClosureV259.evaluate(
            researchIntent = researchIntent,
            dataFeedPlan = dataFeedPlan,
            discoveryEvidenceSplit = discoveryEvidenceSplit,
            openDiscoveryDataFeed = openDiscoveryDataFeed,
            professorDashboard = professorDashboard,
            intentAwareBrief = intentAwareBrief,
            openDataResolver = openDataResolver,
            visualKnowledgeGraph = visualKnowledgeGraph,
            releaseSurfaceHardening = releaseSurfaceHardening
        )
        return interimWithDashboard.copy(
            releaseSurfaceHardening = releaseSurfaceHardening,
            finalIntegrationClosure = finalIntegrationClosure,
            conciseLines = lines + listOf(
                "Parsed Research Intent: ${researchIntent.inputMode} | completeness=${researchIntent.intentCompletenessScore}/100 | queryReadiness=${researchIntent.queryReadinessScore}/100",
                "Candidate routes: ${discoveryEvidenceSplit.candidateRoutes.size} | discoveryValue=${discoveryEvidenceSplit.threeDimensionalScore.discoveryValueScore}/100 | dataQuality=${discoveryEvidenceSplit.threeDimensionalScore.dataQualityScore}/100",
                "GTIM data feed: ${openDiscoveryDataFeed.status} | channels=${openDiscoveryDataFeed.dataFeedingChannels.size} | plan=${dataFeedPlan.status}",
                "Intent-aware brief: ${intentAwareBrief.status} | repositoryQueries=${intentAwareBrief.repositoryQueriesToRun.size}",
                "Public data resolver: ${openDataResolver.status} | actions=${openDataResolver.resolverActions.size}",
                "Visual knowledge graph: ${visualKnowledgeGraph.status} | nodes=${visualKnowledgeGraph.nodes.size} | edges=${visualKnowledgeGraph.edges.size}",
                "Professor dashboard: ${professorDashboard.status} | resolverActions=${professorDashboard.publicDataResolverActions.size} | graphNodes=${professorDashboard.graphNodes.size}",
                "Top data-feed action: ${openDiscoveryDataFeed.immediateActions.firstOrNull() ?: "feed a PMID/DOI/accession/PDF/snippet seed"}",
                "GTIM release surface: ${releaseSurfaceHardening.status} | engine=${releaseSurfaceHardening.gtimProductEngineVersion}",
                "GTIM final closure: ${finalIntegrationClosure.status} | passed=${finalIntegrationClosure.passed} | modules=${finalIntegrationClosure.verifiedModules.size}"
            )
        )
    }

    private fun buildEvidenceObjects(report: ResearchGradeMechanismDossierReportV1110): List<GTIMEvidenceObjectV250> {
        val accessionObjects = report.accessionCandidates.mapIndexed { index, card ->
            GTIMEvidenceObjectV250(
                objectId = "GTIM_EO_ACC_${safeId(card.accessionId)}_$index",
                sourceType = "repository_accession_candidate",
                repository = card.repository,
                accessionId = card.accessionId,
                speciesTier = speciesTier(card.organism, card.cohortType),
                assayOrPlatform = card.assayPlatform,
                tissueOrCellContext = card.tissueOrCellContext,
                comparatorState = if (card.controlComparatorLabels.isNotEmpty()) "COMPARATOR_SIGNALS_PARTIAL" else "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT",
                matrixState = card.matrixAvailability,
                evidenceStrength = evidenceStrength(card),
                dataScarcityRole = dataScarcityRole(card),
                blockingGaps = card.blockingGaps
            )
        }
        val sourceObjects = if (GTIMRelaxedExplorationPolicyV253.INCLUDE_SOURCE_OBJECTS_WITH_ACCESSION_ANCHORS || accessionObjects.isEmpty()) {
            report.sourceMetadataEnrichmentCards.take(GTIMRelaxedExplorationPolicyV253.MAX_SOURCE_EVIDENCE_OBJECTS).mapIndexed { index, card ->
                GTIMEvidenceObjectV250(
                    objectId = "GTIM_EO_SOURCE_${safeId(card.sourceId)}_$index",
                    sourceType = "source_metadata_or_text_mined_lead",
                    repository = card.sourceFamily,
                    accessionId = card.detectedAccessions.firstOrNull().orEmpty(),
                    speciesTier = "UNKNOWN_OR_TEXT_MINED",
                    assayOrPlatform = card.parser,
                    tissueOrCellContext = "unresolved_text_context",
                    comparatorState = if (card.comparatorTokens.isNotEmpty()) "COMPARATOR_TEXT_TOKENS_NEED_SAMPLE_TABLE" else "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT",
                    matrixState = if (card.matrixFileHints.isNotEmpty()) "MATRIX_HINTS_NEED_REPOSITORY_VALIDATION" else "MATRIX_NOT_ESTABLISHED",
                    evidenceStrength = if (card.detectedAccessions.isNotEmpty()) "GRADE_2_REPOSITORY_HANDLE_LEAD" else "GRADE_1_WEAK_TEXTUAL_LEAD",
                    dataScarcityRole = "TEXT_MINED_LEAD_ONLY_NOT_CONFIRMATION",
                    blockingGaps = listOf(card.accessionResolutionState, "sample_metadata_table", "validated_comparator", "matrix_availability")
                )
            }
        } else emptyList()
        return (accessionObjects + sourceObjects).take(GTIMRelaxedExplorationPolicyV253.MAX_GTIM_EVIDENCE_OBJECTS)
    }

    private fun buildMechanismCandidates(
        report: ResearchGradeMechanismDossierReportV1110,
        evidenceObjects: List<GTIMEvidenceObjectV250>
    ): List<GTIMMechanismCandidateV250> {
        val fromLeads = report.exploratoryResearchLeads.mapIndexed { index, lead ->
            mechanismFromLead("GTIM_MC_LEAD_$index", lead.targetAxis, lead.confidence, lead.supportingSignals, lead.missingEvidence, report, evidenceObjects)
        }
        val fromRoutes = report.mechanismRoutes.mapIndexed { index, route ->
            mechanismFromLead("GTIM_MC_ROUTE_$index", route.targetMolecularAxis, 48 + report.matrixReadinessScore / 3, route.requiredValidationFields, route.missingEvidence, report, evidenceObjects)
        }
        val fallback = if (fromLeads.isEmpty() && fromRoutes.isEmpty() && evidenceObjects.isNotEmpty()) {
            listOf(mechanismFromLead("GTIM_MC_EVIDENCE_OBJECT_0", evidenceObjects.first().assayOrPlatform, 32 + report.matrixReadinessScore / 4, listOf(evidenceObjects.first().objectId), evidenceObjects.first().blockingGaps, report, evidenceObjects))
        } else emptyList()
        return (fromLeads + fromRoutes + fallback)
            .distinctBy { it.candidateId + it.targetAxis }
            .sortedByDescending { it.confidenceIndex.score }
            .take(GTIMRelaxedExplorationPolicyV253.MAX_GTIM_MECHANISM_CANDIDATES)
    }

    private fun mechanismFromLead(
        id: String,
        axis: String,
        rawConfidence: Int,
        signals: List<String>,
        gaps: List<String>,
        report: ResearchGradeMechanismDossierReportV1110,
        evidenceObjects: List<GTIMEvidenceObjectV250>
    ): GTIMMechanismCandidateV250 {
        val confidence = confidenceIndex(rawConfidence, report, evidenceObjects, gaps)
        val cascade = cascadeFor(axis, signals)
        val dots = connectedDots(axis, signals, evidenceObjects)
        return GTIMMechanismCandidateV250(
            candidateId = id,
            status = when {
                confidence.score >= 76 -> "LAB_VALIDATION_READY_NO_CLINICAL_CLAIM"
                confidence.score >= 61 -> "STRONG_RESEARCH_CANDIDATE_NOT_PROOF"
                confidence.score >= 35 -> "PLAUSIBLE_MECHANISM_CANDIDATE"
                else -> "EXPLORATORY_LEAD_ONLY"
            },
            targetAxis = axis.ifBlank { "immune mechanism route under exploration" },
            mechanismCascade = cascade,
            connectedDots = dots,
            corpusRelativeNoveltyStatement = noveltyStatement(axis, signals),
            evidenceGrade = report.evidenceGrade,
            confidenceIndex = confidence,
            contradictionNullResultSearch = report.contradictionNullResultSearch.ifEmpty { contradictionFallback(axis) }.take(8),
            labValidationPlan = labValidationPlan(id, axis, gaps),
            whatWouldFalsify = falsificationConditions(axis, gaps)
        )
    }

    private fun confidenceIndex(
        rawConfidence: Int,
        report: ResearchGradeMechanismDossierReportV1110,
        evidenceObjects: List<GTIMEvidenceObjectV250>,
        gaps: List<String>
    ): GTIMConfidenceIndexV250 {
        val evidenceStrength = when {
            evidenceObjects.any { it.evidenceStrength.startsWith("GRADE_5") } -> 24
            evidenceObjects.any { it.evidenceStrength.startsWith("GRADE_4") } -> 20
            evidenceObjects.any { it.evidenceStrength.startsWith("GRADE_3") } -> 16
            evidenceObjects.any { it.evidenceStrength.startsWith("GRADE_2") } -> 10
            evidenceObjects.any { it.evidenceStrength.startsWith("GRADE_1") } -> 6
            else -> 0
        }
        val comparator = if (report.accessionValidationGate.contains("VALIDATED", true)) 14 else if (report.accessionValidationGate.contains("TEXT_FOUND", true)) 8 else 5
        val matrix = (report.matrixReadinessScore / 5).coerceIn(0, 18)
        val route = (rawConfidence / 6).coerceIn(0, 14)
        val contradiction = if (report.contradictionNullResultSearch.isNotEmpty()) 8 else 5
        val novelty = if (rawConfidence >= 60) 10 else 6
        val penalty = (gaps.distinct().size * 2).coerceIn(0, 16) + evidenceObjects.count { it.speciesTier != "HUMAN_PRIMARY" } * 2
        val score = (evidenceStrength + comparator + matrix + route + contradiction + novelty - penalty).coerceIn(GTIMRelaxedExplorationPolicyV253.MIN_GTIM_CONFIDENCE_SCORE, GTIMRelaxedExplorationPolicyV253.MAX_GTIM_CONFIDENCE_SCORE_NO_EXTERNAL_VALIDATION)
        return GTIMConfidenceIndexV250(
            score = score,
            band = confidenceBand(score),
            formula = "S_c = (E + C + M + R + N + X) - P; no 90+ without external validation",
            drivers = listOf(
                "E=$evidenceStrength evidence-object strength",
                "C=$comparator comparator/readiness contribution",
                "M=$matrix matrix-readiness contribution",
                "R=$route route/lead confidence contribution",
                "X=$contradiction contradiction-search contribution",
                "N=$novelty corpus-relative novelty plausibility"
            ),
            penalties = listOf("P=$penalty from metadata gaps, species transfer, unresolved comparators, matrix gaps") + gaps.distinct().take(6)
        )
    }

    private fun confidenceBand(score: Int): String = when {
        score >= 76 -> "LAB_VALIDATION_READY_DOSSIER"
        score >= 61 -> "STRONG_RESEARCH_CANDIDATE"
        score >= 35 -> "PLAUSIBLE_MECHANISM_CANDIDATE"
        score >= 15 -> "EXPLORATORY_HYPOTHESIS"
        else -> "WEAK_LEAD"
    }

    private fun cascadeFor(axis: String, signals: List<String>): List<String> {
        val text = (axis + " " + signals.joinToString(" ")).lowercase(Locale.US)
        val trigger = when {
            listOf("virus", "viral", "ebv", "covid", "hanta", "influenza", "hhv").any { text.contains(it) } -> "viral or post-infectious trigger"
            listOf("drug", "rituximab", "jak", "tnf", "il-6", "inhibitor").any { text.contains(it) } -> "drug or immunomodulator exposure"
            listOf("antibiotic", "microbiome", "bacterial").any { text.contains(it) } -> "antibiotic / microbiome perturbation"
            listOf("allergy", "ige", "mast", "eosinophil", "histamine").any { text.contains(it) } -> "allergy / hypersensitivity trigger"
            listOf("sleep", "stress", "cortisol", "hpa", "mitochondria", "aging", "metabolic").any { text.contains(it) } -> "exposure / longevity / stress physiology trigger"
            else -> "immune-system perturbation trigger"
        }
        return listOf(
            trigger,
            "receptor or pathway modulation to be resolved from accession metadata and pathway context",
            "immune cell-type involvement to be separated from bulk-expression or sample composition",
            "cytokine / biomarker direction requires matrix or assay validation",
            "tissue/system effect remains a mechanism candidate, not a clinical conclusion"
        )
    }

    private fun connectedDots(axis: String, signals: List<String>, evidenceObjects: List<GTIMEvidenceObjectV250>): List<GTIMConnectedDotV250> {
        val seeds = (listOf(axis) + signals + evidenceObjects.map { it.accessionId.ifBlank { it.repository } })
            .filter { it.isNotBlank() }
            .distinct()
            .take(5)
        return seeds.mapIndexed { index, seed ->
            GTIMConnectedDotV250(
                step = index + 1,
                nodeType = when {
                    seed.startsWith("GSE", true) || seed.startsWith("SR", true) || seed.startsWith("PRJ", true) || seed.startsWith("E-MTAB", true) -> "repository_accession_node"
                    seed.contains("IL-", true) || seed.contains("TNF", true) || seed.contains("IFN", true) -> "cytokine_or_biomarker_node"
                    seed.contains("control", true) || seed.contains("baseline", true) -> "comparator_node"
                    else -> "mechanism_bridge_node"
                },
                label = seed.take(140),
                supportLevel = if (index == 0) "primary_axis" else "indirect_support_or_bridge",
                rationale = "Included in the connected-dots map as part of the inspected corpus path; requires contradiction and matrix checks before strengthening."
            )
        }
    }

    private fun noveltyStatement(axis: String, signals: List<String>): String {
        val route = (listOf(axis) + signals.take(3)).filter { it.isNotBlank() }.joinToString(" → ").take(220)
        return GTIMClaimGuardV250.sanitizeScientificClaim(
            "Corpus-relative novelty candidate: the inspected corpus did not directly test this exact path ($route). Treat as an under-tested mechanism route until literature expansion and lab validation close."
        )
    }

    private fun labValidationPlan(id: String, axis: String, gaps: List<String>): GTIMLabValidationPlanV250 {
        val text = axis.lowercase(Locale.US)
        val experiments = mutableListOf<String>()
        experiments += "targeted qPCR or bulk RNA-seq re-analysis after comparator closure"
        experiments += "flow cytometry panel for implicated immune cell populations"
        experiments += "multiplex cytokine assay / ELISA for candidate cytokine direction"
        if (listOf("jak", "stat", "tnf", "il-6", "interferon", "ifn").any { text.contains(it) }) experiments += "pathway perturbation with inhibitor/agonist control"
        if (listOf("gene", "receptor", "pathway", "knockout").any { text.contains(it) }) experiments += "CRISPR knockout or siRNA knockdown of the bridge node"
        if (listOf("tissue", "barrier", "gut", "lung", "organoid").any { text.contains(it) }) experiments += "organoid or co-culture perturbation model"
        return GTIMLabValidationPlanV250(
            hypothesisId = id,
            recommendedExperiments = experiments.distinct().take(6),
            positiveControl = "known immune activation or perturbation control matched to the pathway under test",
            negativeControl = "matched healthy/baseline or unrelated-pathway perturbation control",
            expectedDirection = "candidate pathway and biomarker direction should move consistently with the proposed cascade after comparator and batch correction",
            falsificationCondition = "the candidate weakens if matched controls show no pathway movement, opposite biomarker direction, or the signal disappears after cell-composition/batch correction",
            minimumEvidenceBeforeWetLab = listOf("confirmed accession or curated dataset", "comparator labels", "matrix or assay availability", "tissue/cell context") + gaps.distinct().take(4)
        )
    }

    private fun falsificationConditions(axis: String, gaps: List<String>): List<String> = listOf(
        "matched comparator shows no association with the proposed cascade",
        "null-result or failed-replication literature dominates the route",
        "batch/platform or cell-composition correction removes the signal",
        "human evidence conflicts with cross-species or text-mined support",
        "repository metadata cannot establish matrix, comparator, or tissue/cell context"
    ) + gaps.distinct().take(4)

    private fun contradictionFallback(axis: String): List<String> = listOf(
        "$axis AND null result",
        "$axis AND no association",
        "$axis AND failed replication",
        "$axis AND batch effect",
        "$axis AND cell composition artifact"
    )

    private fun evidenceStrength(card: AccessionCandidateCardV1110): String = when {
        card.dgeReadinessState == "DGE_READY_FOR_CONTROLLED_REVIEW" -> "GRADE_5_MATRIX_READY_DATASET_NO_BIOLOGICAL_CLAIM"
        card.controlComparatorLabels.isNotEmpty() && card.matrixAvailability.startsWith("MATRIX_AVAILABLE") -> "GRADE_4_COMPARATOR_AND_MATRIX_CANDIDATE"
        card.metadataAvailability.contains("PARSED", true) || card.metadataAvailability.contains("PARTIAL", true) -> "GRADE_3_STRUCTURED_METADATA_CANDIDATE"
        card.accessionStatus == "CONFIRMED_ACCESSION" -> "GRADE_2_REPOSITORY_HANDLE_LEAD"
        else -> "GRADE_1_WEAK_TEXTUAL_LEAD"
    }

    private fun dataScarcityRole(card: AccessionCandidateCardV1110): String = when {
        card.cohortType.contains("animal", true) -> "CROSS_SPECIES_AUXILIARY_ONLY"
        card.metadataAvailability == "METADATA_FROM_LEAD_ONLY" -> "TEXT_MINED_OR_LEAD_OBJECT_ONLY"
        card.matrixAvailability == "MATRIX_NOT_ESTABLISHED" -> "REFERENCE_PRIOR_OR_METADATA_ONLY"
        else -> "PRIMARY_OR_REPOSITORY_BACKED_EVIDENCE_OBJECT"
    }

    private fun speciesTier(organism: String, cohortType: String): String = when {
        organism.contains("human", true) || organism.contains("patient", true) || cohortType.contains("human", true) -> "HUMAN_PRIMARY"
        organism.contains("mouse", true) || organism.contains("murine", true) || cohortType.contains("animal", true) -> "CROSS_SPECIES_AUXILIARY"
        cohortType.contains("cell", true) -> "IN_VITRO_MODEL"
        else -> "UNKNOWN_OR_TEXT_MINED"
    }

    private fun conciseLines(
        report: ResearchGradeMechanismDossierReportV1110,
        evidenceObjects: List<GTIMEvidenceObjectV250>,
        mechanismCandidates: List<GTIMMechanismCandidateV250>,
        routeIntegrity: GTIMRouteIntegrityReportV251,
        mode: String
    ): List<String> = listOf(
        GTIMClaimGuardV250.ENGINE_IDENTITY,
        "Mode: $mode | purpose=scientific hypothesis foundry",
        "Mission: ${GTIMClaimGuardV250.MISSION_STATEMENT}",
        "Novelty: ${GTIMClaimGuardV250.CORPUS_RELATIVE_NOVELTY_BOUNDARY}",
        "Evidence objects: ${evidenceObjects.size} | mechanism candidates=${mechanismCandidates.size} | matrix readiness=${report.matrixReadinessScore}/100",
        "Data-feed posture: open discovery enabled; feed PMID/DOI/GSE/PRJNA/SRP/SRR/E-MTAB/SDY/PDF/snippet to strengthen this lead",
        "Route integrity: ${routeIntegrity.status} | passed=${routeIntegrity.passed}",
        "Top candidate: ${mechanismCandidates.firstOrNull()?.targetAxis ?: "none"}",
        "S_c: ${mechanismCandidates.firstOrNull()?.confidenceIndex?.score ?: 0}/100 | ${mechanismCandidates.firstOrNull()?.confidenceIndex?.band ?: "NO_CANDIDATE"}",
        "Lab validation: ${mechanismCandidates.firstOrNull()?.labValidationPlan?.recommendedExperiments?.firstOrNull() ?: "not ready; close accession/comparator/matrix gates"}",
        "Claim boundary: ${GTIMClaimGuardV250.CLAIM_BOUNDARY}"
    )

    private fun safeId(value: String): String = value.ifBlank { "unknown" }
        .replace(Regex("[^A-Za-z0-9_\\-]+"), "_")
        .take(48)

    @Suppress("UNUSED_PARAMETER")
    private fun round(value: Double): Int = value.roundToInt()
}
