# v1.11.5-alpha-graded-exploratory-research-results

- versionCode=129
- schema updated to `1.11.5`
- Added `ExploratoryResearchLeadV1115`.
- Added `GRADED_EXPLORATORY_RESULTS` mode.
- Reports now show useful in-progress research leads when EvidenceObject is blocked.
- Preserves `HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION` and no clinical-claim guardrails.

## GTIM v2.5.0 production-directive integration patch

- Added `GTIMDiscoveryDossierV250`, `GTIMEvidenceModelsV250`, and `GTIMClaimGuardV250`.
- Integrated global translational immunology dossier output directly into `ResearchGradeMechanismDossierReportV1110.globalTranslationalDossier`.
- Extended JSON export, global research brief, runtime registry, and UI detail report to surface GTIM dossier state.
- Preserved accession/comparator/matrix/DGE gates: GTIM cannot upgrade weak text, cross-species, or reference-control evidence into proof.
- Added `audit_gtim_v250_play_scientific_surface.py` to guard Play-compatible permissions, target SDK 35, claim boundaries, JSON route linkage, and non-isolated GTIM wiring.
- Updated research-use and privacy-posture strings without adding new permissions.

## GTIM v2.5.1 route-integrity and CI-fast-gate hardening

- Added `GTIMRouteIntegrityGuardV251` and `GTIMRouteIntegrityReportV251` to verify that the GTIM global dossier remains connected to the existing mechanism dossier, accession/source metadata, JSON export, compact brief, UI, and runtime registry surfaces.
- Extended `GTIMDiscoveryDossierReportV250` with `routeIntegrity`, exported it through `DatasetForagingJson`, and surfaced it in `GlobalResearchGradeBriefV11061` and `ResearchAutopilotActivity`.
- Added regression assertions for accession-anchored and metadata-anchored GTIM routes.
- Added `audit_gtim_v251_route_integrity.py` and wired it into the bounded fast static gate.
- Rebuilt `run_static_checks_fast.sh` as a current-release bounded gate while preserving legacy audit-token compatibility for older validators.
- Guard outcome: GTIM remains a research hypothesis dossier layer, not a diagnosis/treatment/patient-prediction or weak-lead-confirmation layer.

## GTIM v2.5.2 release-surface hardening

- Added `GTIMReleaseSurfaceHardeningV252` and `GTIMReleaseSurfaceHardeningReportV252` to explicitly bridge the Android release train `v1.11.5` with the GTIM product engine surface `v2.5.2`.
- Exported `globalTranslationalDossier.releaseSurfaceHardening` through `DatasetForagingJson`.
- Surfaced GTIM release hardening state in `GlobalResearchGradeBriefV11061` and `ResearchAutopilotActivity`.
- Extended `GTIMDiscoveryDossierV250Test` to assert release hardening, product-engine version tracking, and hypothesis-only scientific posture.
- Added `audit_gtim_v252_release_surface_hardening.py` to the fast static gate.
- No new Android permissions, telemetry, clinical claims, diagnosis, treatment advice, or patient prediction behavior were added.


## GTIM v2.5.4 open-discovery-datafeed relaxed-exploration patch

- Unified the active Android release train, runtime engine, learning schema, and GTIM product surface under `2.5.4-alpha-gtim-open-discovery-datafeed` with `versionCode=130` and schema `2.5.4`.
- Added `GTIMRelaxedExplorationPolicyV253` as the single policy surface for lowering discovery thresholds without lowering claim-confirmation gates.
- Lowered exploratory route threshold from 50 to 35, surfaced source-metadata leads even when accession anchors exist, and expanded bounded GTIM evidence/mechanism outputs.
- Kept all hard claim locks: no diagnosis, no treatment advice, no patient prediction, no DGE/fold-change/p-value without matrix analysis, no confirmed discovery from weak leads.


## GTIM v2.5.4 open discovery datafeed patch

- Unified active version as `2.5.4-alpha-gtim-open-discovery-datafeed` with `versionCode=131` and schema `2.5.4`.
- Added `GTIMOpenDiscoveryDataFeedingV254` and data-feed JSON surface under `globalTranslationalDossier.openDiscoveryDataFeed`.
- Lowered exploratory display thresholds while keeping claim confirmation, DGE, diagnosis, treatment, and patient prediction locks intact.
- Added data-feeding channels for PMID/DOI/GSE/PRJNA/SRP/SRR/E-MTAB/SDY/PDF/snippet, GEO/GDS, SRA/BioProject, ArrayExpress/BioStudies, ImmPort/SDY, PubMed data-availability mining, comparator hunt, matrix-file hint hunt, and null/contradiction queue.
- Reworked `GlobalResearchGradeBriefV11061` so the final report shows what was learned and how to feed the engine next; raw JSON/command trace/parser internals stay in technical export.


## v2.5.6-alpha-gtim-intent-discovery-evidence-split
- versionCode=132
- schema `2.5.6`
- Added ResearchIntentObject, DataFeed Planner, candidate routes without accession, three-dimensional grading, semantic prior not matrix, active contradiction engine, and lab protocol draft not validation.


## 2.5.9-alpha-gtim-final-integration-closure
- Added `GTIMProfessorDiscoveryDashboardV257` as the final research-facing dashboard surface.
- Added user-triggered public data resolver actions without background scraping.
- Added graph-ready nodes and edges for later visual knowledge graph UI.
- Wired dashboard into GTIM dossier, JSON export, compact brief, runtime registry, and static audit.
- Kept evidence/clinical locks unchanged: no confirmed mechanism from weak leads, no DGE from semantic priors, no diagnosis/treatment/patient prediction.

## 2.5.9-alpha-gtim-final-integration-closure

- Added `GTIMFinalIntegrationClosureV259` as the final release contract.
- Fixed stale GTIM engine identity so reports show `GTIM-Engine v2.5.9`.
- Added `finalIntegrationClosure` to GTIM JSON/export and compact brief.
- Added intent-anchor route integrity status for structured questions before accession closure.
- Added final integration unit tests and v2.5.9 static audit.
- Kept discovery flexible, evidence upgrade strict, and clinical claims forbidden.
