package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class GTIMSeedKnowledgeAssetsV264Test {
    private fun asset(name: String): JSONObject = JSONObject(File("app/src/main/assets/$name").readText())

    @Test
    fun `immune disease seed has forty plus comparative diseases with safety fields`() {
        val json = asset("immune_disease_seed_v1.0.json")
        val diseases = json.getJSONArray("diseases")
        assertTrue("expected at least 44 diseases/lanes", diseases.length() >= 44)
        val ids = (0 until diseases.length()).map { diseases.getJSONObject(it).getString("id") }.toSet()
        listOf(
            "cancer_tumor_immune_evasion",
            "hiv_aids_chronic_viral_immunodeficiency",
            "fungal_th17_neutrophil_defense",
            "epidemic_pandemic_immune_response"
        ).forEach { assertTrue("missing $it", ids.contains(it)) }
        for (i in 0 until diseases.length()) {
            val d = diseases.getJSONObject(i)
            assertEquals("research_leads_only", d.getString("claim_limit"))
            assertTrue(d.getJSONArray("forbiddenConflations").length() > 0)
        }
    }

    @Test
    fun `bridge rules and therapy map stay claim bounded`() {
        val bridge = asset("disease_axis_bridge_rules_v1.0.json")
        assertEquals("comparative_pathway_research_leads_only_not_equivalence", bridge.getString("claim_limit"))
        assertTrue(bridge.getJSONArray("bridgeGroups").length() >= 6)
        val therapy = asset("therapy_target_map_v1.0.json")
        assertEquals("therapy_target_search_prior_not_treatment_advice", therapy.getString("claim_limit"))
        assertTrue(therapy.getJSONArray("targets").length() >= 6)
    }

    @Test
    fun `vocabulary master has more than two hundred terms`() {
        val vocab = asset("immune_vocabulary_master_v1.0.json")
        assertTrue(vocab.getInt("termCount") >= 200)
        assertEquals("search_vocabulary_not_evidence", vocab.getString("claimLimit"))
    }
}
