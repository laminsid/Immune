package com.immunesignal.app

import java.util.Locale

data class ComparativeDiseasePathwayCardV264(
    val id: String,
    val label: String,
    val sourceDisease: String,
    val targetDiseases: List<String>,
    val sharedAxes: List<String>,
    val differentiatorGates: List<String>,
    val requiredComparatorEvidence: List<String>,
    val querySeeds: List<String>,
    val upgradeBlockers: List<String>,
    val state: String = "COMPARATIVE_RESEARCH_PATH_ACTIVE",
    val claimLimit: String = GTIMComparativeDiseasePathwaysV264.CLAIM_LIMIT
)

data class DiseaseComparisonCycleClosureReportV264(
    val active: Boolean,
    val cards: List<ComparativeDiseasePathwayCardV264>,
    val mandatoryDomainsCovered: List<String>,
    val missingMandatoryDomains: List<String>,
    val closureState: String,
    val nextAction: String,
    val claimLimit: String = GTIMComparativeDiseasePathwaysV264.CLAIM_LIMIT
)

/**
 * v2.6.3: explicit comparative disease-path closure.
 *
 * This layer lets the learning loop compare diseases such as cancer, HIV/AIDS,
 * fungal disease, and epidemic/pandemic immune response without turning shared
 * pathways into diagnosis, equivalence, or treatment claims. It creates search
 * priors and comparator gates only.
 */
object GTIMComparativeDiseasePathwaysV264 {
    const val CLAIM_LIMIT = "comparative_disease_pathways_research_leads_only_not_diagnosis_or_treatment"

    private val mandatoryDomainIds = listOf(
        "cancer_tumor_immune_evasion",
        "hiv_aids_chronic_viral_immunodeficiency",
        "fungal_th17_neutrophil_defense",
        "epidemic_pandemic_immune_response"
    )

    private val cards = listOf(
        ComparativeDiseasePathwayCardV264(
            id = "cancer_hiv_exhaustion_bridge",
            label = "Cancer ↔ HIV/AIDS exhaustion comparison",
            sourceDisease = "cancer_tumor_immune_evasion",
            targetDiseases = listOf("hiv_aids_chronic_viral_immunodeficiency", "immunosenescence", "long_covid"),
            sharedAxes = listOf("T cell exhaustion", "PD-1/PD-L1", "chronic antigen exposure", "immune surveillance failure"),
            differentiatorGates = listOf("tumor antigen vs viral antigen", "CD4 depletion", "tumor microenvironment", "viral load/serology", "age baseline"),
            requiredComparatorEvidence = listOf("condition labels", "disease-specific source tissue", "control/comparator", "outcome/severity", "accession/source metadata"),
            querySeeds = listOf(
                "cancer HIV T cell exhaustion PD-1 PD-L1 CD4 viral load comparator RNA-seq",
                "tumor immune evasion chronic viral infection exhaustion signature human cohort control"
            ),
            upgradeBlockers = listOf("shared exhaustion marker alone", "single disease cohort without comparator", "no antigen/source context")
        ),
        ComparativeDiseasePathwayCardV264(
            id = "aids_fungal_opportunistic_bridge",
            label = "HIV/AIDS ↔ fungal opportunistic immunity comparison",
            sourceDisease = "hiv_aids_chronic_viral_immunodeficiency",
            targetDiseases = listOf("fungal_th17_neutrophil_defense", "cvid", "scid", "cgd"),
            sharedAxes = listOf("host immune deficit", "opportunistic infection risk", "Th17/IL-17", "neutrophil and mucosal-barrier defense"),
            differentiatorGates = listOf("CD4 count", "fungal culture/PCR", "neutrophil oxidative burst", "antibody deficiency", "mucosal tissue source"),
            requiredComparatorEvidence = listOf("host-risk label", "pathogen confirmation", "immune cell/function marker", "control/comparator", "severity/outcome"),
            querySeeds = listOf(
                "HIV AIDS Candida Aspergillus Th17 IL-17 neutrophil CD4 count comparator dataset",
                "opportunistic fungal infection immunodeficiency CARD9 Dectin-1 RNA-seq human control"
            ),
            upgradeBlockers = listOf("fungal term without host-risk context", "CD4 label without pathogen confirmation", "no immune readout")
        ),
        ComparativeDiseasePathwayCardV264(
            id = "epidemic_hyperinflammation_bridge",
            label = "Epidemic/pandemic ↔ hyperinflammatory syndrome comparison",
            sourceDisease = "epidemic_pandemic_immune_response",
            targetDiseases = listOf("hlh", "mas", "crs", "long_covid", "post_infection_autoimmunity"),
            sharedAxes = listOf("interferon timing", "cytokine severity", "macrophage activation", "endothelial injury", "post-infectious persistence"),
            differentiatorGates = listOf("pathogen/variant", "wave/date", "vaccination/prior infection", "severity grade", "ferritin/sCD25/IL-6 dynamics"),
            requiredComparatorEvidence = listOf("exposure timing", "pathogen label", "severity/outcome", "longitudinal sampling", "matched control group"),
            querySeeds = listOf(
                "pandemic outbreak interferon timing cytokine storm ferritin IL-6 severity longitudinal control",
                "post viral immune dysregulation epidemic cohort autoantibody T cell exhaustion comparator"
            ),
            upgradeBlockers = listOf("epidemic association without timing", "cytokine term without severity grade", "no pathogen/variant label")
        ),
        ComparativeDiseasePathwayCardV264(
            id = "autoimmune_oncology_checkpoint_bridge",
            label = "Autoimmune ↔ oncology checkpoint comparison",
            sourceDisease = "cancer_tumor_immune_evasion",
            targetDiseases = listOf("sle", "ra", "ibd", "psoriasis"),
            sharedAxes = listOf("checkpoint braking", "T cell activation", "B cell/autoantibody context", "TNF/IL-6/Th17 inflammation"),
            differentiatorGates = listOf("tumor comparator", "autoantibody specificity", "tissue target", "treatment-exposure metadata", "immune-related adverse-event separation"),
            requiredComparatorEvidence = listOf("disease-specific condition labels", "tissue/site", "control/comparator", "exposure metadata", "outcome labels"),
            querySeeds = listOf(
                "checkpoint inhibitor autoimmunity cancer immune-related adverse event comparator transcriptomic",
                "tumor immune evasion autoimmune Th17 TNF IL-6 PD-1 control dataset"
            ),
            upgradeBlockers = listOf("drug/exposure term used as advice", "same cytokine treated as same disease", "no tumor vs autoimmune separation")
        )
    )

    fun cardsForText(text: String): List<ComparativeDiseasePathwayCardV264> {
        val t = text.lowercase(Locale.US)
        val matched = cards.filter { card ->
            val haystack = (listOf(card.id, card.label, card.sourceDisease) + card.targetDiseases + card.sharedAxes + card.querySeeds)
                .joinToString(" ")
                .lowercase(Locale.US)
            haystack.split(' ', '/', '-', '↔').any { token -> token.length >= 4 && t.contains(token) }
        }
        return matched.ifEmpty {
            if (mandatoryDomainIds.any { t.contains(it.substringBefore('_')) } || listOf("cancer", "tumor", "hiv", "aids", "fungal", "candida", "aspergillus", "epidemic", "pandemic", "outbreak").any { t.contains(it) }) {
                cards.take(3)
            } else {
                emptyList()
            }
        }.distinctBy { it.id }.take(4)
    }

    fun closeCycle(text: String): DiseaseComparisonCycleClosureReportV264 {
        val selected = cardsForText(text)
        val covered = mandatoryDomainIds.filter { domain ->
            selected.any { it.sourceDisease == domain || it.targetDiseases.contains(domain) }
        }
        val missing = mandatoryDomainIds - covered.toSet()
        val state = when {
            selected.isEmpty() -> "NO_COMPARATIVE_DISEASE_PATH_TRIGGERED"
            missing.isEmpty() -> "COMPARATIVE_DISEASE_CYCLE_CLOSED"
            else -> "COMPARATIVE_DISEASE_CYCLE_PARTIAL"
        }
        val next = when (state) {
            "COMPARATIVE_DISEASE_CYCLE_CLOSED" -> "Run comparator-first accession search; keep all bridges as research leads until gates close."
            "COMPARATIVE_DISEASE_CYCLE_PARTIAL" -> "Add missing mandatory domain(s): ${missing.joinToString(", ")} before declaring the comparison cycle closed."
            else -> "No cancer/HIV-fungal/epidemic comparison requested; keep normal learning loop."
        }
        return DiseaseComparisonCycleClosureReportV264(
            active = selected.isNotEmpty(),
            cards = selected,
            mandatoryDomainsCovered = covered,
            missingMandatoryDomains = missing,
            closureState = state,
            nextAction = next
        )
    }

    fun querySeedsForText(text: String): List<String> = cardsForText(text)
        .flatMap { it.querySeeds }
        .distinct()
        .take(8)

    fun oneLine(report: DiseaseComparisonCycleClosureReportV264): String =
        "${report.closureState}; cards=${report.cards.size}; covered=${report.mandatoryDomainsCovered.size}/4; next=${report.nextAction.take(160)}"
}
