package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.12.12 — Terminal discovery continuation.
 *
 * A D/D+ result is no longer treated as the end of the research cycle. This layer turns
 * every useful-but-unverified lead into a bounded continuation chain: local curated seed,
 * external lookup, SOFT/metadata compatibility, processed-expression capsule, comparator
 * and sample-linkage extraction, contradiction search, then hypothesis ranking. It relaxes
 * discovery continuation only; claim/evidence upgrades remain locked by existing gates.
 */
object GTIMTerminalDiscoveryContinuationV21212 {
    const val VERSION: String = "2.12.12-terminal-discovery-continuation"
    const val CLAIM_LIMIT: String = "terminal_continuation_research_only_no_evidence_upgrade"
    const val CONTINUATION_MODE: String = "continue_until_no_new_handle_no_metadata_no_capsule_no_contradiction_signal"
    private val DATASET_HANDLE_RE: Regex = Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|SRR\\d+|PRJNA\\d+|PRJEB\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+)\\b", RegexOption.IGNORE_CASE)

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val technical = if (technicalLines.isNotEmpty()) technicalLines else GlobalResearchGradeBriefV11061.renderLines(report)
        val selector = report.optJSONObject("domainSpecificHypothesisSelectorV2129")
            ?: GTIMDomainSpecificHypothesisSelectorV2129.toJson(report, technical)
        val card = report.optJSONObject("studyResultCardV2126")
            ?: GTIMStudyResultCardV2126.toJson(report, technical)
        val curated = report.optJSONObject("curatedMetadataSeedLibraryV21211") ?: JSONObject()
        val matrix = report.optJSONObject("matrixShortcutStatusLayerV2129")
            ?: GTIMMatrixShortcutStatusLayerV2129.toJson(report, technical)
        val consistency = GTIMReportConsistencyGateV2121.build(report, technical)
        val ledger = report.optJSONObject("candidateHandleLedgerV21215") ?: GTIMCandidateHandleLedgerV21215.toJson(report)
        val metadataProbe = report.optJSONObject("metadataProbeBackgroundWorkersV21215") ?: JSONObject()
        val handles = collectHandles(report, curated, consistency, ledger)
        val domain = selector.optString("domainKey", "open_mechanism_first")
        val stagePlan = buildStages(domain, handles, curated, matrix, consistency, metadataProbe)
        val executedSteps = executedSteps(metadataProbe, handles)
        val queuedSteps = queuedSteps(metadataProbe, handles)
        val blockedSteps = blockedSteps(metadataProbe, handles)
        val terminalCriteria = JSONArray(listOf(
            "no local curated seed match and no external handle after expanded lookup",
            "SOFT/sample metadata cannot expose comparator labels or tissue/species context",
            "no raw/count matrix, processed-expression capsule, or external gene-list provenance is found",
            "candidate route fails topic-fit or independent contradiction check",
            "only generic template text remains after diversified target lexicon expansion"
        ))
        val state = when {
            consistency.topicCompatibleTargetSelected && consistency.verifiedMatrixFiles > 0 -> "CONTINUED_TO_REVIEW_CAPSULE_CANDIDATE"
            handles.isNotEmpty() -> "CONTINUE_AFTER_D_PLUS_WITH_REVIEW_TARGET"
            else -> "CONTINUE_AFTER_D_WITH_EXTERNAL_EXPANSION"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("continuationMode", CONTINUATION_MODE)
            .put("strictnessMode", "relaxed_discovery_hard_claims_locked")
            .put("domainKey", domain)
            .put("studyFocus", selector.optString("studyFocus", card.optString("topic", "current-topic research study")))
            .put("candidateHandles", JSONArray(handles))
            .put("candidateHandleCount", handles.size)
            .put("selectedReviewTarget", ledger.optString("selectedReviewTarget"))
            .put("verifiedCapsuleSourceCount", ledger.optInt("verifiedCapsuleSourceCount", consistency.verifiedMatrixFiles))
            .put("executedSteps", executedSteps)
            .put("queuedSteps", queuedSteps)
            .put("blockedSteps", blockedSteps)
            .put("claimUpgradeAllowed", false)
            .put("evidenceUpgradeRequires", JSONArray(listOf("topic-fit", "metadata", "comparator", "sample-linkage", "matrix/capsule", "contradiction-resistance")))
            .put("continuationStages", stagePlan)
            .put("researchHypothesisVariants", hypothesisVariants(domain, selector, handles))
            .put("nextQueries", nextQueries(domain, selector, handles))
            .put("terminalStopCriteria", terminalCriteria)
            .put("resultContract", "D_or_D_plus_is_a_continuation_state_not_a_final_stop")
            .put("nextAction", nextAction(state, handles, domain))
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val handles = jsonStrings(obj.optJSONArray("candidateHandles")).joinToString(", ").ifBlank { "none yet" }
        return listOf(
            "Terminal discovery continuation",
            "State: ${obj.optString("state", "UNKNOWN")}; mode=${obj.optString("continuationMode", CONTINUATION_MODE)}.",
            "D/D+ rule: useful lead is not a final stop; continue through curated seed → external lookup → SOFT metadata → processed capsule → comparator/sample linkage → contradiction check.",
            "Targets: candidate_handles=$handles; selected_review_target=${obj.optString("selectedReviewTarget", "none")}; verified_capsule_source_count=${obj.optInt("verifiedCapsuleSourceCount", 0)}; claim_upgrade_allowed=${obj.optBoolean("claimUpgradeAllowed", false)}.",
            "Execution: executed_steps=${obj.optJSONArray("executedSteps")?.length() ?: 0}; queued_steps=${obj.optJSONArray("queuedSteps")?.length() ?: 0}; blocked_steps=${obj.optJSONArray("blockedSteps")?.length() ?: 0}.",
            "Next: ${obj.optString("nextAction", "continue bounded evidence discovery").takeClean(300)}",
            "Boundary: continuation can create new hypotheses and lookup tasks, but cannot prove mechanism, gene/pathway signal, diagnosis, treatment, or efficacy."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        CONTINUATION_MODE,
        "D_or_D_plus_is_a_continuation_state_not_a_final_stop",
        "relaxed_discovery_hard_claims_locked",
        "curated seed → external lookup → SOFT metadata → processed capsule",
        "executedSteps",
        "queuedSteps",
        "blockedSteps",
        CLAIM_LIMIT
    ))

    private fun buildStages(
        domain: String,
        handles: List<String>,
        curated: JSONObject,
        matrix: JSONObject,
        consistency: GTIMReportConsistencyGateV2121.TargetConsistency,
        metadataProbe: JSONObject
    ): JSONArray {
        val localState = curated.optString("state", "NO_CURATED_SEED_LAYER")
        val matrixState = matrix.optString("state", matrix.optString("shortcutState", "MATRIX_SHORTCUT_REVIEW_ONLY_ROUTE_QUEUED"))
        val arr = JSONArray()
        fun stage(id: String, status: String, action: String, output: String) {
            arr.put(JSONObject()
                .put("stage", id)
                .put("status", status)
                .put("action", action)
                .put("expectedOutput", output)
                .put("claimLimit", "lookup_or_readiness_only_no_evidence_upgrade"))
        }
        stage("01_local_curated_seed", localState, "Use the offline curated seed library before new internet lookup.", "selected or rejected local seed with readiness reason")
        stage("02_external_lookup_expansion", if (handles.isNotEmpty()) "HANDLE_AVAILABLE" else "REQUIRED", "Run GEO/SRA/Europe PMC/OpenAlex targeted lookup if no local seed closes readiness.", "new important handles stored as pending curated seeds")
        val probeState = metadataProbe.optString("state", if (handles.isNotEmpty()) "READY_FOR_HANDLE_LIST" else "WAITING_FOR_HANDLE")
        stage("03_soft_metadata_probe", probeState, "Background workers automatically attempt SOFT/listing metadata and GSE→SRP mapping for each selected handle.", "executed/queued metadata compatibility, sample provenance, comparator labels, and mapping state")
        stage("04_processed_expression_capsule", matrixState, "Check GREIN/refine.bio/recount3/Expression Atlas/GEO2R for processed capsule before declaring matrix dead-end.", "review-only capsule candidate or negative capsule result")
        stage("05_comparator_sample_linkage", if (consistency.candidateLookupHandle.isNotBlank()) "REQUIRED_FOR_${consistency.candidateLookupHandle}" else "REQUIRED", "Extract comparator labels and sample-to-source provenance; keep DGE blocked until readable.", "case/control or severity/recovery labels plus sample linkage")
        stage("06_contradiction_resistance", "REQUIRED_BEFORE_UPGRADE", "Search no-association, failed replication, unrelated tissue/species, and reverse-timing contradictions.", "contradiction summary that can kill or keep the route")
        stage("07_hypothesis_generation", "ALLOWED_AS_RESEARCH_ONLY", "Generate 2–4 testable hypotheses from domain route, metadata readiness, and negative checks.", "new hypothesis variants with falsification triggers")
        return arr
    }

    private fun hypothesisVariants(domain: String, selector: JSONObject, handles: List<String>): JSONArray {
        val handleText = handles.firstOrNull()?.let { " using lookup handle $it" }.orEmpty()
        val variants = when (domain) {
            "depression_kynurenine_neuroimmune" -> listOf(
                "IDO1/KMO imbalance hypothesis: depression subgroup signal may concentrate in tryptophan-kynurenine enzyme/metabolite readouts$handleText.",
                "Neuroimmune-transmission hypothesis: inflammatory tone may interact with glutamate/NMDA or microglial stress before any microbiome claim.",
                "Microbiome branch hypothesis only if positive metadata shows gut/microbial/metabolite context; otherwise exit the microbiome route."
            )
            "viral_interferon_cytokine" -> listOf(
                "Interferon timing hypothesis: severity/recovery may separate by early/late interferon and IL-6/TNF modules$handleText.",
                "Endothelial/tissue injury hypothesis: host-response signature may be stronger than generic mucosal/barrier framing.",
                "Persistence hypothesis: recovered/post-viral groups may retain inflammatory or tissue-repair signals if comparator labels exist."
            )
            "allergy_type2_barrier" -> listOf(
                "Type-2 threshold hypothesis: IgE/mast/eosinophil and epithelial/barrier readouts may stratify allergic phenotypes$handleText.",
                "Tolerance instability hypothesis: barrier-support function is only useful if comparator labels and epithelial/type-2 markers are present."
            )
            else -> listOf(
                selector.optString("topResearchHypothesis", "Open mechanism-first hypothesis remains active and must be tested against metadata, comparator labels, and contradiction checks."),
                "Alternative route hypothesis: expand target lexicon before falling back to a generic microbiome/barrier route."
            )
        }
        return JSONArray(variants)
    }

    private fun nextQueries(domain: String, selector: JSONObject, handles: List<String>): JSONArray {
        val handle = handles.firstOrNull().orEmpty()
        val base = when (domain) {
            "depression_kynurenine_neuroimmune" -> listOf(
                "depression kynurenine IDO1 KMO transcriptome metabolomics human comparator GSE",
                "tryptophan kynurenine depression PBMC RNA-seq control comparator matrix",
                "depression neuroimmune glutamate NMDA kynurenine human cohort data availability"
            )
            "viral_interferon_cytokine" -> listOf(
                "viral interferon IL6 TNF severity recovery human transcriptome comparator GSE",
                "Ebola filovirus cytokine storm interferon human RNA-seq comparator matrix",
                "COVID post-viral interferon cytokine PBMC processed expression GSE"
            )
            "allergy_type2_barrier" -> listOf(
                "allergy IgE eosinophil mast epithelial barrier human transcriptome comparator GSE",
                "asthma eczema type 2 cytokine epithelial RNA-seq control matrix"
            )
            else -> listOf(selector.optString("nextBestActionHint", "immune phenotype human comparator transcriptome data availability GSE SRA matrix").ifBlank { "immune phenotype human comparator transcriptome data availability GSE SRA matrix" })
        }.toMutableList()
        if (handle.isNotBlank()) {
            base.add("$handle SOFT sample metadata comparator labels tissue species platform matrix")
            base.add("$handle GREIN refine.bio recount3 processed expression sample annotations")
        }
        return JSONArray(base.distinct().take(8))
    }

    private fun nextAction(state: String, handles: List<String>, domain: String): String = when {
        handles.isNotEmpty() -> "Continue with ${handles.take(3).joinToString(", ")}: run SOFT/listing metadata, processed-expression shortcut, comparator/sample-linkage extraction, contradiction search, then produce research-only hypothesis variants for $domain."
        state.contains("D_WITH_EXTERNAL", true) -> "No local handle is enough yet: expand external lookup using diversified target lexicon, store important handles as pending curated seeds, and keep running until handle/metadata/capsule/contradiction routes are exhausted."
        else -> "Proceed to review-only capsule checks and contradiction search; do not upgrade claims until all hard evidence gates close."
    }

    private fun collectHandles(
        report: JSONObject,
        curated: JSONObject,
        consistency: GTIMReportConsistencyGateV2121.TargetConsistency,
        ledger: JSONObject
    ): List<String> {
        val ledgerHandles = jsonStrings(ledger.optJSONArray("allCandidateHandles"))
        val selected = ledger.optString("selectedReviewTarget").takeIf { it.isNotBlank() }
        val textHandles = extractHandles(listOf(
            report.toString(),
            curated.toString(),
            consistency.acceptedTarget,
            consistency.candidateLookupHandle,
            selected.orEmpty()
        ).joinToString(" "))
        return (ledgerHandles + listOfNotNull(selected) + textHandles)
            .map { it.uppercase(Locale.US) }
            .filter { DATASET_HANDLE_RE.containsMatchIn(it) }
            .distinct()
            .take(12)
    }

    private fun executedSteps(metadataProbe: JSONObject, handles: List<String>): JSONArray {
        val existing = metadataProbe.optJSONArray("executedSteps")
        if (existing != null) return JSONArray(existing.toString())
        val results = metadataProbe.optJSONArray("probeResults") ?: JSONArray()
        val out = JSONArray()
        for (idx in 0 until results.length()) {
            val item = results.optJSONObject(idx) ?: continue
            val handle = item.optString("handle").ifBlank { handles.getOrNull(idx).orEmpty() }
            if (handle.isBlank()) continue
            if (item.optBoolean("executed", false) || item.optBoolean("offlineInjected", false)) {
                out.put("$handle:metadata_probe")
                out.put("$handle:gse_srp_mapping_readiness")
            }
        }
        return out
    }

    private fun queuedSteps(metadataProbe: JSONObject, handles: List<String>): JSONArray {
        val existing = metadataProbe.optJSONArray("queuedSteps")
        if (existing != null) return JSONArray(existing.toString())
        val executed = jsonStrings(executedSteps(metadataProbe, handles))
        val out = JSONArray()
        handles.take(6).forEach { handle ->
            if (executed.none { it.startsWith("$handle:") }) {
                out.put("$handle:retry_live_soft_metadata_probe_when_network_available")
                out.put("$handle:processed_expression_shortcut_review")
            }
        }
        return out
    }

    private fun blockedSteps(metadataProbe: JSONObject, handles: List<String>): JSONArray {
        val existing = metadataProbe.optJSONArray("blockedSteps")
        if (existing != null) return JSONArray(existing.toString())
        val out = JSONArray()
        if (handles.isEmpty()) {
            out.put("no_candidate_handle_available_for_terminal_metadata_continuation")
        }
        out.put("claim_promotion_blocked_until_topic_fit_comparator_sample_linkage_matrix_capsule_and_contradiction_gates_close")
        return out
    }

    private fun extractHandles(text: String): List<String> = DATASET_HANDLE_RE.findAll(text)
        .map { it.value.uppercase(Locale.US) }
        .distinct()
        .toList()

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx ->
        array.optString(idx).takeIf { it.isNotBlank() }
    }

    private fun String.takeClean(max: Int): String {
        val clean = replace(Regex("\\s+"), " ").trim()
        return if (clean.length <= max) clean else clean.take(max).trimEnd()
    }
}
