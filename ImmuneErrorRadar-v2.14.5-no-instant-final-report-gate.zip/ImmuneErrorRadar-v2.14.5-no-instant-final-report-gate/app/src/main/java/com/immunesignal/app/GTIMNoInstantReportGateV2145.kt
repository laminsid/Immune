package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.14.5 — No instant final-report gate.
 *
 * The professional orchestrator may build a compact local-memory route quickly.
 * That is useful, but it must not be presented as a completed research report.
 * A real mobile agent run stays in a working checkpoint state until the user
 * stops it, while Pause/Continue preserve the current stage.
 */
object GTIMNoInstantReportGateV2145 {
    const val VERSION: String = "2.14.5-no-instant-final-report-gate"
    const val REQUIRED_TOKEN: String = "V2145_NO_INSTANT_FINAL_REPORT_GATE_WORKING_CHECKPOINTS"
    const val USER_RULE: String = "Start/Pause/Continue/Stop own the run; no one-second final report."
    const val FINAL_REPORT_RULE: String = "final report requires explicit Stop or a later proof-executed pass, not the initial local-memory route plan"

    fun isWorkingCheckpoint(report: JSONObject): Boolean =
        report.optJSONObject("noInstantReportGateV2145")?.optString("state") == "WORKING_CHECKPOINT_NOT_FINAL"

    fun annotateWorkingCheckpoint(
        report: JSONObject,
        topic: String,
        currentStep: AgentWorkStep = defaultSteps().first(),
        passCount: Int = 0
    ): JSONObject {
        report.put("noInstantReportGateV2145", JSONObject()
            .put("version", VERSION)
            .put("requiredToken", REQUIRED_TOKEN)
            .put("state", "WORKING_CHECKPOINT_NOT_FINAL")
            .put("topic", topic.take(180))
            .put("userRule", USER_RULE)
            .put("finalReportRule", FINAL_REPORT_RULE)
            .put("compactRoutePlanIsFinalReport", false)
            .put("initialLocalMemoryPassCompleted", true)
            .put("externalProofExecutionStatus", "WORKING_OR_QUEUED_NOT_FINAL")
            .put("copyExportMeaning", "checkpoint_only_until_stop")
            .put("currentStageId", currentStep.stageId)
            .put("currentLabel", currentStep.label)
            .put("percent", currentStep.percent)
            .put("passCount", passCount)
            .put("executed", currentStep.executed)
            .put("queued", currentStep.queued)
            .put("workPlan", JSONArray(defaultSteps().map { it.toJson() })))
        return report
    }

    fun stoppedCheckpointReport(
        report: JSONObject,
        topic: String,
        lastStep: AgentWorkStep,
        passCount: Int,
        stoppedByUser: Boolean
    ): JSONObject {
        annotateWorkingCheckpoint(report, topic, lastStep, passCount)
        report.put("noInstantReportGateV2145", report.getJSONObject("noInstantReportGateV2145")
            .put("state", if (stoppedByUser) "STOPPED_CHECKPOINT_READY" else "CHECKPOINT_READY")
            .put("stoppedByUser", stoppedByUser)
            .put("finalReport", false)
            .put("reason", "The user stopped the agentic run. The saved output is a research checkpoint, not a completed evidence report."))
        return report
    }

    fun defaultSteps(): List<AgentWorkStep> = listOf(
        AgentWorkStep(
            stageId = "V2145_SOURCE_HANDLE_PASS",
            label = "Source-handle pass",
            percent = 28,
            executed = "compact local-memory route plan converted into source-handle targets",
            queued = "dataset/comparator provenance check"
        ),
        AgentWorkStep(
            stageId = "V2145_METADATA_PROVENANCE_PASS",
            label = "Metadata and provenance pass",
            percent = 42,
            executed = "topic-specific sample, cohort, tissue, species, and comparator gates reviewed as tasks",
            queued = "contradiction/falsification pass"
        ),
        AgentWorkStep(
            stageId = "V2145_CONTRADICTION_PASS",
            label = "Contradiction and falsification pass",
            percent = 57,
            executed = "wrong tissue/species/cohort and weak-lead separation added to the working ledger",
            queued = "mechanism-route refinement"
        ),
        AgentWorkStep(
            stageId = "V2145_ROUTE_REFINEMENT_PASS",
            label = "Mechanism route refinement",
            percent = 71,
            executed = "immune route candidates refined without upgrading evidence grade",
            queued = "next-pass source prioritization"
        ),
        AgentWorkStep(
            stageId = "V2145_NEXT_PASS_PRIORITY",
            label = "Next-pass priority ranking",
            percent = 84,
            executed = "highest-value proof tasks ranked for another saved pass",
            queued = "user may Stop to save checkpoint or Continue to keep deepening"
        ),
        AgentWorkStep(
            stageId = "V2145_DEEPENING_LOOP",
            label = "Deepening loop checkpoint",
            percent = 92,
            executed = "working checkpoint saved; agent remains active under Start/Pause/Continue/Stop control",
            queued = "continue cycling through proof tasks until user stops"
        )
    )

    fun step(index: Int): AgentWorkStep = defaultSteps()[index % defaultSteps().size]

    fun workingUiCard(topic: String, step: AgentWorkStep, passCount: Int): String = buildString {
        append("Agent working — no final report yet\n")
        append("• Topic: ").append(topic.take(160)).append("\n")
        append("• Current stage: ").append(step.label).append("\n")
        append("• Progress: ").append(step.percent).append("% workflow checkpoint\n")
        append("• Deepening pass: ").append(passCount).append("\n")
        append("• Executed: ").append(step.executed).append("\n")
        append("• Next queued: ").append(step.queued).append("\n")
        append("• Rule: no one-second completed report. Press Pause to hold, Continue to resume, or Stop to save/export the current checkpoint.\n")
        append("• Boundary: research-only; not proof, diagnosis, treatment, dosing, or clinical advice.")
    }

    fun renderUserCard(report: JSONObject): String? {
        val gate = report.optJSONObject("noInstantReportGateV2145") ?: return null
        val topic = gate.optString("topic", report.optJSONObject("topicCapture")?.optString("normalizedTopic", "research topic") ?: "research topic")
        val state = gate.optString("state", "WORKING_CHECKPOINT_NOT_FINAL")
        return buildString {
            append("Agentic research checkpoint\n")
            append("• Topic: ").append(topic.take(160)).append("\n")
            append("• State: ").append(state).append("\n")
            append("• Strategy: Start / Pause / Continue / Stop; no visible countdown and no one-second final report.\n")
            append("• Current stage: ").append(gate.optString("currentLabel", "working checkpoint")).append("\n")
            append("• Progress: ").append(gate.optInt("percent", 0)).append("% workflow checkpoint, not evidence strength.\n")
            append("• Executed: ").append(gate.optString("executed", "local route plan saved")).append("\n")
            append("• Queued: ").append(gate.optString("queued", "proof-seeking pass remains queued")).append("\n")
            append("• Final report: NO. This is a saved working checkpoint until Stop/proof execution closes more gates.\n")
            append("\nBoundary: research-only. Not proof, diagnosis, treatment, dosing, or clinical advice.")
        }.take(3600)
    }
}

data class AgentWorkStep(
    val stageId: String,
    val label: String,
    val percent: Int,
    val executed: String,
    val queued: String
) {
    fun toPhase(): GTIMProfessionalResearchPhaseV2140 = GTIMProfessionalResearchPhaseV2140(
        stageId = stageId,
        label = label,
        percent = percent,
        executed = executed,
        queued = queued
    )

    fun toJson(): JSONObject = JSONObject()
        .put("stageId", stageId)
        .put("label", label)
        .put("percent", percent)
        .put("executed", executed)
        .put("queued", queued)
}
