package com.immunesignal.app

/**
 * v2.7.4.1 — Single Run Contract Reset / Connector Patch
 *
 * Core rule:
 * - User-directed runs protect the primary question anchor and allow only bridge routes
 *   that explain the anchor without rewriting its identity.
 * - Autonomous discovery can connect distant domains freely, but every bridge remains
 *   explicitly labeled by evidence level/provenance/confidence.
 *
 * Design invariant:
 *   Shared biomarker != same disease identity.
 *   Shared biomarker may become a bridge only when the anchor is preserved.
 */

enum class GTIMRunModeV2740 {
    USER_DIRECTED_ANCHOR_PROTECTED,
    AUTONOMOUS_DISCOVERY_FREE_EXPLORATION
}

enum class GTIMInputModeV2740 {
    USER_QUERY,
    MANUAL_SEED,
    AUTONOMOUS_DISCOVERY,
    BENCHMARK_VALUE_HARNESS
}

enum class GTIMPrimaryAnchorV2740(val routeId: String) {
    COVID_RESPIRATORY_VIRAL("covid_interferon_cytokine_bridge"),
    ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL("allergy_type2_ige_mast_eosinophil"),
    HANTAVIRUS_ZOONOTIC_VIRAL("hantavirus_zoonotic_viral_immune_route"),
    EBOLA_HEMORRHAGIC_VIRAL("ebola_hemorrhagic_viral_host_response"),
    HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION("hiv_retroviral_cd4_immune_depletion"),
    GENERAL_FEVER_SYNDROME("general_fever_syndrome_differential"),
    OUTBREAK_OR_EPIDEMIC_SURVEILLANCE("outbreak_surveillance_pathogen_emergence"),

    DEPRESSION_NEUROIMMUNE("depression_neuroimmune_axis"),
    GUT_MICROBIOME_DEPRESSION("gut_microbiome_to_neuroinflammation"),
    ENDOCRINE_REPRODUCTIVE_DYSFUNCTION("endocrine_reproductive_immune_metabolic_axis"),
    YEAST_FUNGAL_ENDOCRINE_IMMUNE("yeast_fungal_to_endocrine_immune"),
    LONGEVITY_IMMUNOSENESCENCE("longevity_immunosenescence"),

    IBD_INFLAMMATORY_BOWEL_DISEASE("ibd_barrier_mucosal_inflammation_axis"),
    SLE_SYSTEMIC_AUTOIMMUNE("sle_ifn_autoantibody_systemic_axis"),
    MS_NEUROIMMUNE_DEMYELINATION("ms_neuroimmune_demyelination_axis"),
    RA_SYNOVIAL_AUTOIMMUNE("ra_synovial_autoimmune_inflammation_axis"),
    PSORIASIS_IL23_IL17_SKIN("psoriasis_il23_il17_skin_barrier_axis"),
    T1D_AUTOIMMUNE_BETA_CELL("t1d_autoimmune_beta_cell_axis"),

    AUTOIMMUNE_INFLAMMATORY("autoimmune_inflammatory_axis"),
    CANCER_IMMUNE("cancer_immune_axis"),
    UNKNOWN_AUTONOMOUS_DISCOVERY("autonomous_unknown_discovery")
}

enum class GTIMDiseaseFamilyV2740 {
    RESPIRATORY_VIRAL,
    HEMORRHAGIC_VIRAL,
    RETROVIRAL_IMMUNODEFICIENCY,
    VECTOR_BORNE_OR_ZOONOTIC,
    ALLERGIC_TYPE2,
    AUTOIMMUNE,
    INFLAMMATORY_BOWEL_DISEASE,
    SYSTEMIC_AUTOIMMUNE,
    NEUROIMMUNE,
    NEUROIMMUNE_DEMYELINATION,
    SKIN_BARRIER_AUTOIMMUNE,
    BETA_CELL_AUTOIMMUNE,
    AGING_IMMUNOSENESCENCE,
    CANCER_IMMUNE,
    ENDOCRINE_REPRODUCTIVE,
    FUNGAL_YEAST_EXPOSURE,
    GENERAL_FEVER_SYNDROME,
    OUTBREAK_OR_EPIDEMIC_SURVEILLANCE,
    UNKNOWN_AUTONOMOUS_DISCOVERY
}

enum class GTIMDomainV2740 {
    VIROLOGY,
    BACTERIOLOGY,
    MYCOLOGY_YEAST_FUNGAL,
    MICROBIOME,
    IMMUNOLOGY,
    CYTOKINE_SIGNALING,
    INTERFERON_ANTIVIRAL,
    TYPE2_IGE_MAST_EOSINOPHIL,
    BARRIER_IMMUNITY,
    MUCOSAL_IMMUNITY,
    NEUROINFLAMMATION,
    DEMYELINATION,
    ENDOCRINE,
    METABOLIC,
    THYROID_AXIS,
    REPRODUCTIVE_HORMONES,
    AUTOIMMUNITY,
    B_CELL_AUTOANTIBODY,
    SYNOVIAL_INFLAMMATION,
    SKIN_BARRIER,
    IL23_IL17_AXIS,
    BETA_CELL_AUTOIMMUNITY,
    OUTBREAK_SURVEILLANCE,
    OMICS_DATASET_HUNT,
    CLINICAL_SYNDROME_DIFFERENTIAL
}

enum class GTIMDiscoveryBridgeV2740(val routeId: String) {
    COVID_TO_INTERFERON_MEMORY("covid_interferon_cytokine_bridge"),
    VIRAL_TO_AUTOIMMUNE_FLARE("viral_infection_to_autoimmune_flare"),
    VIRAL_TO_GUT_MICROBIOME_DISRUPTION("viral_infection_to_gut_microbiome_disruption"),
    VIRAL_TO_NEUROINFLAMMATION_FATIGUE("viral_to_neuroinflammation_fatigue_axis"),
    ALLERGY_TO_BARRIER_IMMUNITY("allergy_type2_to_barrier_immunity"),
    ALLERGY_TO_MICROBIOME_BARRIER("allergy_microbiome_barrier_axis"),
    GUT_MICROBIOME_TO_NEUROINFLAMMATION("gut_microbiome_to_neuroinflammation"),
    MICROBIOME_TO_TRYPTOPHAN_SEROTONIN("microbiome_tryptophan_serotonin_pathway"),
    MICROBIOME_TO_HPA_STRESS_AXIS("microbiome_hpa_axis_stress_response"),
    YEAST_FUNGAL_TO_ENDOCRINE_IMMUNE("yeast_fungal_to_endocrine_immune"),
    FUNGAL_TO_BARRIER_DYSBIOSIS("fungal_exposure_to_barrier_dysbiosis"),
    METABOLIC_INFLAMMATION_TO_HORMONAL_AXIS("metabolic_inflammation_to_hormonal_axis"),
    MICROBIOME_TO_THYROID_AXIS("microbiome_to_thyroid_axis"),
    HEMORRHAGIC_VIRUS_TO_HOST_RESPONSE("hemorrhagic_viral_host_response"),
    RETROVIRAL_TO_CD4_IMMUNE_DEPLETION("retroviral_cd4_immune_depletion"),
    FEVER_TO_DIFFERENTIAL_INFECTIOUS_INFLAMMATORY("fever_syndrome_differential_infectious_inflammatory"),
    OUTBREAK_TO_PATHOGEN_EMERGENCE("outbreak_pathogen_emergence_surveillance"),

    IBD_TO_BARRIER_MICROBIOME("ibd_barrier_microbiome_axis"),
    IBD_TO_SYSTEMIC_INFLAMMATION("ibd_mucosal_to_systemic_inflammation_axis"),
    AUTOIMMUNE_TO_INTERFERON_AUTOANTIBODY("autoimmune_interferon_autoantibody_axis"),
    MS_TO_NEUROINFLAMMATION("ms_neuroimmune_demyelination_axis"),
    RA_TO_CITRULLINATION_SYNOVIUM("ra_citrullination_synovial_inflammation_axis"),
    PSORIASIS_TO_IL23_IL17_SKIN("psoriasis_il23_il17_skin_barrier_axis"),
    T1D_TO_BETA_CELL_AUTOIMMUNITY("t1d_autoimmune_beta_cell_axis"),

    AUTONOMOUS_CROSS_DOMAIN_WEAK_LEAD("autonomous_cross_domain_weak_lead")
}

enum class GTIMClaimModeV2740 {
    DIRECT_EVIDENCE_ALLOWED,
    ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
    AUTONOMOUS_EXPLORATORY_HYPOTHESIS,
    RESEARCH_DIRECTION_ONLY,
    LEAD_ONLY_NOT_EVIDENCE,
    NEEDS_DATASET_CONFIRMATION
}

enum class GTIMEvidenceLabelV2740 {
    CONFIRMED_EVIDENCE,
    PLAUSIBLE_MECHANISM,
    WEAK_LEAD,
    SPECULATIVE_BRIDGE,
    REJECTED_CONFLATION,
    NEEDS_DATASET_CONFIRMATION
}

data class GTIMEvidenceCapsV2740(
    val dataQualityMax: Int,
    val evidenceStrengthMax: Int,
    val routeConfidenceMax: Int,
    val causalityClaimAllowed: Boolean,
    val reason: String
) {
    init {
        require(dataQualityMax in 0..100)
        require(evidenceStrengthMax in 0..100)
        require(routeConfidenceMax in 0..100)
    }

    companion object {
        fun normal(reason: String = "accession-backed ready matrix and high-confidence anchor") = GTIMEvidenceCapsV2740(
            dataQualityMax = 100,
            evidenceStrengthMax = 100,
            routeConfidenceMax = 100,
            causalityClaimAllowed = true,
            reason = reason
        )

        fun exploratory(reason: String = "exploratory bridge; causality requires external confirmation") = GTIMEvidenceCapsV2740(
            dataQualityMax = 70,
            evidenceStrengthMax = 60,
            routeConfidenceMax = 75,
            causalityClaimAllowed = false,
            reason = reason
        )

        fun weakNoAccession(reason: String = "no accession-backed dataset; lead-only output") = GTIMEvidenceCapsV2740(
            dataQualityMax = 35,
            evidenceStrengthMax = 25,
            routeConfidenceMax = 60,
            causalityClaimAllowed = false,
            reason = reason
        )

        fun lowClassification(reason: String = "classification confidence below threshold") = GTIMEvidenceCapsV2740(
            dataQualityMax = 35,
            evidenceStrengthMax = 25,
            routeConfidenceMax = 45,
            causalityClaimAllowed = false,
            reason = reason
        )
    }
}

data class GTIMRunDecisionContractV2740(
    val rawQuery: String,
    val normalizedQuery: String,
    val inputMode: GTIMInputModeV2740,
    val runMode: GTIMRunModeV2740,
    val primaryAnchor: GTIMPrimaryAnchorV2740,
    val diseaseFamily: GTIMDiseaseFamilyV2740,
    val anchorConfidence: Int,
    val anchorReason: String,
    val anchorMustNotMutate: Boolean,
    val secondaryDomains: Set<GTIMDomainV2740>,
    val discoveryBridges: Set<GTIMDiscoveryBridgeV2740>,
    val exploratoryRoutes: Set<String>,
    val allowedRoutes: Set<String>,
    val blockedRoutes: Set<String>,
    val allowedSeeds: Set<String>,
    val blockedSeeds: Set<String>,
    val benchmarkTopic: String?,
    val forbiddenIdentityMutations: Set<String>,
    val forbiddenConflations: Set<String>,
    val evidenceCaps: GTIMEvidenceCapsV2740,
    val claimMode: GTIMClaimModeV2740,
    val bridgeRationale: String,
    val reason: String
) {
    init {
        require(anchorConfidence in 0..100)
        require(primaryAnchor.routeId in allowedRoutes || runMode == GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION) {
            "Primary anchor route must be allowed in user-directed runs."
        }
    }

    fun canUseRoute(routeId: String): Boolean {
        if (runMode == GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION) {
            return routeId !in blockedRoutes
        }
        return routeId in allowedRoutes && routeId !in blockedRoutes
    }

    fun canUseSeed(seedId: String): Boolean {
        if (runMode == GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION) {
            return seedId !in blockedSeeds
        }
        return seedId in allowedSeeds && seedId !in blockedSeeds
    }

    fun classifyBridge(routeId: String): GTIMEvidenceLabelV2740 {
        return when {
            routeId == primaryAnchor.routeId && evidenceCaps.causalityClaimAllowed -> GTIMEvidenceLabelV2740.CONFIRMED_EVIDENCE
            routeId == primaryAnchor.routeId -> GTIMEvidenceLabelV2740.PLAUSIBLE_MECHANISM
            routeId in exploratoryRoutes -> GTIMEvidenceLabelV2740.WEAK_LEAD
            runMode == GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION -> GTIMEvidenceLabelV2740.SPECULATIVE_BRIDGE
            else -> GTIMEvidenceLabelV2740.REJECTED_CONFLATION
        }
    }

    fun enforceNoIdentityMutation(candidateAnchor: GTIMPrimaryAnchorV2740): Boolean {
        if (runMode == GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION) return true
        return !anchorMustNotMutate || candidateAnchor == primaryAnchor
    }
}
