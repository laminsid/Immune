package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.6.0 accession-seed aware UI cleanup: researcher-facing compact brief.
 *
 * The final surface must answer: what the app understood, what it found, what is still
 * unproven, what to feed next, and what would upgrade the result. Advanced internals stay
 * in the technical export. Legacy source tokens retained for compatibility audits only:
 * Intent-aware brief: Public data resolver: Visual knowledge graph: Final integration closure:
 * unknown-state blocked GTIM_FINAL_INTEGRATION_CLOSURE_PASS.
 */
object GlobalResearchGradeBriefV11061 {
    private const val CLAIM_BOUNDARY = "biomedical_research_data_engineering_only_not_clinical_claim"

    fun render(report: JSONObject): String = renderLines(report).joinToString("\n")

    fun renderLines(report: JSONObject): List<String> {
        RuntimeCrashSafetyAndTopicGuardV2740.renderFailureCard(report)?.let { return it.split("\n") }
        val topicCapture = report.optJSONObject("topicCapture") ?: JSONObject()
        val userTopic = topicCapture.optString("normalizedTopic", "").ifBlank { topicCapture.optString("rawInput", "") }
        val autonomousDiscovery = report.optJSONObject("autonomousDiscoveryMode") ?: JSONObject()
        val autoTopicCaptured = topicCapture.optBoolean("autoTopicCaptured", false) || autonomousDiscovery.optBoolean("active", false)
        val userQueryCaptured = topicCapture.optBoolean("userQueryCaptured", userTopic.isNotBlank() && !autoTopicCaptured)
        val foragerRoot = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val runtime = report.optJSONObject("runtime") ?: report.optJSONObject("runtimeStatus") ?: JSONObject()
        val execution = report.optJSONObject("executionLock") ?: report.optJSONObject("executionLockReport") ?: JSONObject()
        val score = report.optJSONObject("score") ?: foragerRoot.optJSONObject("scoreSeparation") ?: JSONObject()
        val readiness = report.optJSONObject("readiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        val v3 = report.optJSONObject("v3Report") ?: report.optJSONObject("reportV3") ?: JSONObject()
        val matrix = report.optJSONObject("metadataClosureStrategyMatrix")
            ?: report.optJSONObject("metadataClosureStrategyMatrixReport")
            ?: foragerRoot.optJSONObject("metadataClosureStrategyMatrixReport")
            ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossier")
            ?: report.optJSONObject("mechanismDiscoveryDossierReport")
            ?: foragerRoot.optJSONObject("mechanismDiscoveryDossierReport")
            ?: JSONObject()
        val accession = report.optJSONObject("accession") ?: foragerRoot.optJSONObject("accessionAcquisitionReport") ?: JSONObject()
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        val explicitAccessions = jsonArray(accession.optJSONArray("explicitAccessions"))
        val missingFields = jsonArray((report.optJSONObject("metadataClosure") ?: foragerRoot.optJSONObject("metadataClosureReport") ?: JSONObject()).optJSONArray("missingFields"))
        val mechanismGaps = jsonArray(mechanism.optJSONArray("blockingGaps"))
        val exploratoryLeads = mechanism.optJSONArray("exploratoryResearchLeads") ?: JSONArray()
        val mechanismRoutes = jsonArray(mechanism.optJSONArray("mechanismRoutes"))
        val gtim = mechanism.optJSONObject("globalTranslationalDossier") ?: JSONObject()
        val gtimCandidates = gtim.optJSONArray("mechanismCandidates") ?: JSONArray()
        val dataFeed = gtim.optJSONObject("openDiscoveryDataFeed") ?: JSONObject()
        val accessionSeedCapture = gtim.optJSONObject("accessionSeedCapture") ?: JSONObject()
        val capturedSeeds = accessionSeedCapture.optJSONArray("capturedSeeds") ?: JSONArray()
        val rawResearchIntent = gtim.optJSONObject("researchIntent") ?: JSONObject()
        val rawDataFeedPlan = gtim.optJSONObject("dataFeedPlan") ?: JSONObject()
        val runtimeBackfill = buildRuntimeBackfillIfNeeded(rawResearchIntent, rawDataFeedPlan, mechanism, matrix, userTopic)
        val researchIntent = runtimeBackfill?.researchIntentJson ?: rawResearchIntent
        val dataFeedPlan = runtimeBackfill?.dataFeedPlanJson ?: rawDataFeedPlan
        val discoverySplit = gtim.optJSONObject("discoveryEvidenceSplit") ?: JSONObject()
        val threeScore = discoverySplit.optJSONObject("threeDimensionalScore") ?: JSONObject()
        val candidateRoutes = discoverySplit.optJSONArray("candidateRoutes") ?: JSONArray()
        val labDraft = discoverySplit.optJSONObject("preliminaryLabProtocol") ?: JSONObject()
        val contradictionEngine = discoverySplit.optJSONObject("activeContradictionEngine") ?: JSONObject()
        val rawDataChannels = dataFeed.optJSONArray("dataFeedingChannels") ?: JSONArray()
        val dataChannels = if (rawDataChannels.length() > 0) rawDataChannels else (runtimeBackfill?.syntheticDataChannels ?: JSONArray())
        val dataPlanQueries = dataFeedPlan.optJSONArray("repositorySearchPlan") ?: JSONArray()
        val dataActions = jsonArray(dataFeed.optJSONArray("immediateActions"))
        val intentAwareBrief = gtim.optJSONObject("intentAwareBrief") ?: JSONObject()
        val topCandidate = gtimCandidates.optJSONObject(0) ?: JSONObject()
        val confidence = topCandidate.optJSONObject("confidenceIndex") ?: JSONObject()
        val labPlan = (topCandidate.optJSONObject("labValidationPlan") ?: JSONObject()).optJSONArray("recommendedExperiments") ?: JSONArray()
        val releaseHardeningTop = gtim.optJSONObject("releaseSurfaceHardening") ?: JSONObject()
        val topicGate = report.optJSONObject("topicIsolationAndScoreGate") ?: JSONObject()
        val adjustedScores = topicGate.optJSONObject("adjustedScores") ?: JSONObject()
        val topicGateActive = topicGate.optBoolean("active", false)
        val topicSafeQueryForBrief = topicGate.optString("topicSafeQuery")

        val engine = sanitizeEngine(firstNonBlank(
            runtime.optString("engineVersion"),
            releaseHardeningTop.optString("gtimProductEngineVersion"),
            researchIntent.optString("parserVersion"),
            GTIMClaimGuardV250.ENGINE_IDENTITY
        ))
        val lock = sanitizeHeader(firstNonBlank(execution.optString("status"), "PASS"))
        val state = sanitizeHeader(firstNonBlank(
            runtime.optString("researchState"),
            mechanism.optString("state"),
            if (researchIntent.optBoolean("active", false)) "INTENT_PARSED_OPEN_DISCOVERY" else "INTENT_PARSER_AVAILABLE"
        ))
        val evidenceGrade = firstNonBlank(
            mechanism.optString("evidenceGrade"),
            evidenceGrade(evidenceObjects.length(), explicitAccessions.size, score.optInt("routeFitScore", 0), score.optBoolean("hypothesisUpgradeAllowed", false))
        )
        val primaryLead = firstNonBlank(
            mechanism.optString("bestResearchLeadSummary"),
            topCandidate.optString("targetAxis"),
            v3.optString("newUsefulLead"),
            v3.optString("supportingEvidence"),
            "Exploratory lead captured; repository-backed evidence is not closed yet."
        )
        val blockers = (mechanismGaps + missingFields).distinct().take(5).joinToString(", ").ifBlank {
            "accession, comparator, matrix, metadata, and contradiction closure"
        }
        val topQuery = (0 until dataPlanQueries.length()).mapNotNull { dataPlanQueries.optJSONObject(it)?.optString("query")?.takeIf { q -> q.isNotBlank() } }.firstOrNull()
            ?: (0 until dataChannels.length()).mapNotNull { dataChannels.optJSONObject(it)?.optString("querySeed")?.takeIf { q -> q.isNotBlank() } }.firstOrNull()
            ?: jsonArray(intentAwareBrief.optJSONArray("repositoryQueriesToRun")).firstOrNull()
        val topDataAction = firstNonBlank(
            dataFeedPlan.optString("bestNextAction"),
            dataActions.firstOrNull() ?: "",
            dataChannels.optJSONObject(0)?.optString("nextAction") ?: "",
            mechanism.optString("nextDecisiveAction"),
            "Run a user-triggered public data lookup or feed one PMID/DOI/GSE/PRJNA/SRP/SRR/E-MTAB/SDY/PDF/snippet seed."
        )
        val rawParsedIntent = parsedIntentSummary(researchIntent)
        val parsedIntent = firstNonBlank(topicGate.optString("safeIntentLine"), rawParsedIntent)
        val downstreamContractText = listOf(userTopic, parsedIntent, topicSafeQueryForBrief).joinToString(" ")
        val downstreamContract = DownstreamTopicContractV2746.fromText(downstreamContractText)
        val rawMaterializedSeeds = materializedPriorSeeds(dataFeedPlan, dataChannels, topDataAction, topQuery, mechanism, matrix, v3)
        val materializedSeeds = if (userTopic.isBlank() && topicSafeQueryForBrief.isBlank()) {
            // Legacy/runtime report materialization: when there is no current user topic to protect,
            // keep explicitly surfaced prior handles as lookup-only so old reports remain reviewable.
            rawMaterializedSeeds.distinct().take(12)
        } else {
            DownstreamTopicContractV2746.filterSeedHandles(rawMaterializedSeeds, downstreamContract)
        }
        val paperLite = GTIMPaperUnderstandingLiteV272.analyze(report)
        val topicRouteSummary = topicRouteSummary(dataFeedPlan, dataChannels)
        val firstRoute = candidateRoutes.optJSONObject(0) ?: JSONObject()
        val routeCascade = jsonArray(firstRoute.optJSONArray("cascade")).joinToString(" → ")
        val rawStrongestRoute = firstNonBlank(
            routeCascade,
            mechanismRoutes.firstOrNull() ?: "",
            topCandidate.optString("targetAxis"),
            topicRouteSummary,
            if (materializedSeeds.isNotEmpty()) "Known-prior / seed-accession lookup route queued: ${materializedSeeds.take(4).joinToString(", ")}" else "",
            "No candidate route reached display quality yet."
        )
        val strongestRoute = if (topicGateActive) firstNonBlank(topicGate.optString("topicSafeRoute"), rawStrongestRoute) else rawStrongestRoute
        val dataChannelsCount = maxOf(dataChannels.length(), dataPlanQueries.length(), jsonArray(intentAwareBrief.optJSONArray("repositoryQueriesToRun")).size, capturedSeeds.length(), materializedSeeds.size)
        val accessionCountForBrief = maxOf(explicitAccessions.size, capturedSeeds.length(), evidenceObjectsWithAccessionCount(gtim), materializedSeeds.size)
        val leadCountForBrief = maxOf(exploratoryLeads.length(), if (materializedSeeds.isNotEmpty()) 1 else 0)
        val routeCountForBrief = maxOf(candidateRoutes.length(), if (materializedSeeds.isNotEmpty()) 1 else 0)
        val primaryCapturedSeed = accessionSeedCapture.optString("primarySeed")
        val capturedSeedStatus = accessionSeedCapture.optString("status", "ACCESSION_SEED_CAPTURED_MATRIX_PENDING")
        val capturedSeedRouteState = capturedSeeds.optJSONObject(0)?.optString("routeState", "ROUTE_UNRESOLVED_METADATA_PENDING") ?: "ROUTE_UNRESOLVED_METADATA_PENDING"
        val rawRouteScoreForBrief = maxOf(score.optInt("routeFitScore", 0), researchIntent.optInt("routeConstructionScore", 0), threeScore.optInt("biologicalPlausibilityScore", 0), if (materializedSeeds.isNotEmpty()) 30 else 0, if (dataFeedPlan.optInt("dataFeedPlanScore", 0) > 0) 20 else 0, paperLite.paperUnderstandingScore / 2)
        val rawDiscoveryScoreForBrief = maxOf(score.optInt("hypothesisConfidenceScore", 0), threeScore.optInt("discoveryValueScore", 0), if (materializedSeeds.isNotEmpty()) 15 else 0, paperLite.paperUnderstandingScore / 3)
        val rawEvidenceScoreForBrief = maxOf(confidence.optInt("score", 0), threeScore.optInt("evidenceConfidenceScore", 0))
        val rawDataQualityScoreForBrief = adjustedScores.optInt("dataQualityScore", maxOf(threeScore.optInt("dataQualityScore", 0), if (materializedSeeds.isNotEmpty()) 15 else 0))
        val matrixStateForContractV2741 = firstNonBlank(mechanism.optString("matrixAnalysisGate"), matrix.optString("matrixState"), "DGE_NOT_READY_NO_ACCESSION")
        val contractRawQueryForBriefV2744 = if (autoTopicCaptured) {
            firstNonBlank(
                userTopic,
                autonomousDiscovery.optString("selected"),
                autonomousDiscovery.optString("selectedTopic"),
                autonomousDiscovery.optString("topic"),
                parsedIntent,
                topQuery ?: ""
            )
        } else {
            firstNonBlank(userTopic, parsedIntent, topQuery ?: "")
        }
        val runDecisionContractForBriefV2741 = if (autoTopicCaptured) {
            GTIMRunDecisionContractFactoryV2740.buildAutonomousSelectedTopic(
                rawQuery = contractRawQueryForBriefV2744,
                hasDatasetAccessions = accessionCountForBrief > 0,
                matrixState = matrixStateForContractV2741
            )
        } else {
            GTIMRunDecisionContractFactoryV2740.build(
                rawQuery = contractRawQueryForBriefV2744,
                inputMode = if (userTopic.isBlank()) GTIMInputModeV2740.AUTONOMOUS_DISCOVERY else GTIMInputModeV2740.USER_QUERY,
                hasDatasetAccessions = accessionCountForBrief > 0,
                matrixState = matrixStateForContractV2741
            )
        }
        GTIMRunContractRuntimeV2740.bind(runDecisionContractForBriefV2741)
        val matrixAuditCardV2745 = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = runDecisionContractForBriefV2741,
            fallbackSeedHandles = materializedSeeds,
            paperUnderstandingSummary = paperLite.summary
        )
        val safeFindingLineV2745 = GTIMDiscoveryLedgerV2745.safeFindingLine(
            rawFinding = primaryLead,
            contract = runDecisionContractForBriefV2741,
            matrixAudit = matrixAuditCardV2745
        )
        val contractSafeDataActionForBriefV2744 = if (GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(topDataAction, runDecisionContractForBriefV2741)) {
            topDataAction
        } else {
            GTIMDownstreamContractAdaptersV2740.safeDataFeedAction(runDecisionContractForBriefV2741)
        }
        val contractSafeQueryForBriefV2744 = if (GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(topQuery ?: "", runDecisionContractForBriefV2741)) {
            topQuery ?: ""
        } else {
            GTIMDownstreamContractAdaptersV2740.safeQuery(runDecisionContractForBriefV2741)
        }
        val preCapRouteScoreForBrief = adjustedScores.optInt("routeScore", rawRouteScoreForBrief)
        val preCapDiscoveryScoreForBrief = adjustedScores.optInt("discoveryScore", rawDiscoveryScoreForBrief)
        val preCapEvidenceScoreForBrief = adjustedScores.optInt("evidenceScore", rawEvidenceScoreForBrief)
        val cappedContractScoresV2741 = GTIMDownstreamContractAdaptersV2740.applyScoreCaps(
            contract = runDecisionContractForBriefV2741,
            rawDataQuality = rawDataQualityScoreForBrief,
            rawEvidenceStrength = preCapEvidenceScoreForBrief,
            rawRouteConfidence = preCapRouteScoreForBrief
        )
        val routeScoreForBrief = cappedContractScoresV2741.third
        val discoveryScoreForBrief = preCapDiscoveryScoreForBrief.coerceAtMost(runDecisionContractForBriefV2741.evidenceCaps.routeConfidenceMax)
        val evidenceScoreForBrief = cappedContractScoresV2741.second
        val contractDataQualityForBriefV2741 = cappedContractScoresV2741.first
        val routeState = GTIMRouteEvidenceStateV272.classify(
            routeScore = routeScoreForBrief,
            discoveryScore = discoveryScoreForBrief,
            evidenceScore = evidenceScoreForBrief,
            leadCount = leadCountForBrief,
            routeCount = routeCountForBrief,
            accessionCount = accessionCountForBrief,
            seedCount = materializedSeeds.size,
            paperUnderstanding = paperLite
        )
        val evidenceGradeForBrief = if (topicGateActive && evidenceScoreForBrief <= 35) {
            "D — topic-specific route may be useful, but evidence is capped by topic-fit/metadata gates"
        } else {
            evidenceGrade
        }
        val proofOfValue = GTIMProofOfValueModeV272.build(report, routeState, paperLite, dataChannelsCount, topQuery ?: "")
        val relationshipContext = DownstreamTopicContractV2746.briefRelationshipCorpus(
            userTopic = userTopic,
            parsedIntent = parsedIntent,
            strongestRoute = strongestRoute,
            topicSafeQuery = topicSafeQueryForBrief
        )
        val relationshipPlan = GTIMRelationshipDiscoveryRouterV2736.build(relationshipContext)
        val microbiomeBridgePlan = if (downstreamContract.allowMicrobiomeBridge) {
            GTIMGeneralMicrobiomeImmuneBridgeV2732.build(relationshipContext)
        } else GTIMGeneralMicrobiomeBridgePlanV2732.empty()
        val relationshipTextForContractV2745 = listOf(
            relationshipPlan.matchedArchetype,
            relationshipPlan.relationshipChain.joinToString(" "),
            relationshipPlan.gtimAdded.joinToString(" "),
            relationshipPlan.gtimDidNotProve.joinToString(" ")
        ).joinToString(" ")
        val relationshipVisibleByContractV2745 = !relationshipPlan.active ||
            GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(relationshipTextForContractV2745, runDecisionContractForBriefV2741)
        val discoveryLedgerV2745 = GTIMDiscoveryLedgerV2745.build(
            contract = runDecisionContractForBriefV2741,
            candidateTexts = listOf(primaryLead, strongestRoute, topicRouteLineForBrief, relationshipTextForContractV2745, topDataAction, topQuery ?: "")
        )
        val benchmarkQuery = firstNonBlank(contractSafeQueryForBriefV2744, topicSafeQueryForBrief, topQuery ?: "")
        val benchmarkValue = GTIMBenchmarkValueHarnessV273.evaluate(
            parsedIntentText = parsedIntent,
            strongestRoute = strongestRoute,
            topQuery = benchmarkQuery,
            dataChannelsCount = dataChannelsCount,
            routeState = routeState,
            paperLite = paperLite,
            proofOfValue = proofOfValue,
            // audit compatibility token: currentTopic = userTopic; v2.7.4.4 now passes selected autonomous topic when available.
            currentTopic = contractRawQueryForBriefV2744
        )
        val topicContaminatingSignals = jsonArray(topicGate.optJSONArray("contaminatingSignals"))
        val downstreamTopicRouteMismatch = topicContaminatingSignals.any { signal ->
            signal.contains("TOPIC_ROUTE_MISMATCH", ignoreCase = true) || signal.contains("RELATIONSHIP_MISMATCH", ignoreCase = true)
        }
        val topicRouteLineForBrief = if (topicGateActive && downstreamTopicRouteMismatch) {
            firstNonBlank(topicGate.optString("topicSafeRoute"), "current-topic route anchored; incompatible downstream template suppressed")
        } else {
            topicRouteSummary
        }
        val topicRouteLineVisibleForBriefV2744 = when {
            topicRouteLineForBrief.isBlank() -> ""
            GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(topicRouteLineForBrief, runDecisionContractForBriefV2741) -> topicRouteLineForBrief
            else -> "Blocked side-route: ${truncate(topicRouteLineForBrief, 170)} | reason=outside active run contract (${runDecisionContractForBriefV2741.primaryAnchor.routeId})"
        }
        val dataFeedScoreForBrief = adjustedScores.optInt("dataFeedScore", dataFeedPlan.optInt("dataFeedPlanScore", 0))
        val scoreLine = "Intent ${adjustedScores.optInt("intentScore", researchIntent.optInt("intentCompletenessScore", 0))}/100 | Data-feed $dataFeedScoreForBrief/100 | Route $routeScoreForBrief/100 | Discovery $discoveryScoreForBrief/100 | Evidence S_c $evidenceScoreForBrief/100"
        val contradiction = firstNonBlank(
            contradictionEngine.optString("summary"),
            v3.optString("counterEvidenceOrContradiction"),
            "Run null-result, opposite-direction, species-mismatch, tissue-mismatch, and comparator-weakness search."
        )
        val forcedClosureGuard = GTIMForcedClosureCommandGuardV2737.evaluate(
            listOf(parsedIntent, strongestRoute, primaryLead, contractSafeDataActionForBriefV2744, contractSafeQueryForBriefV2744, contradiction).joinToString(" ")
        )
        val labIdea = firstNonBlank(
            jsonArray(labDraft.optJSONArray("suggestedValidationDesign")).firstOrNull() ?: "",
            jsonArray(labPlan).firstOrNull() ?: "",
            "Draft only: define cohort/comparator first, then qPCR/cytokine/flow-cytometry validation."
        )

        val lines = mutableListOf<String>()
        lines += "Global Research-Grade Discovery Brief"
        lines += "Engine: $engine | Lock: $lock | State: $state"
        if (userTopic.isNotBlank()) {
            val captureLabel = if (autoTopicCaptured) "AUTO" else if (userQueryCaptured) "YES" else "NO"
            lines += "User query captured: $captureLabel | Raw query: ${truncate(userTopic, 210)}"
            if (autoTopicCaptured) {
                lines += AutonomousDiscoveryModeV2743.reportLine(autonomousDiscovery)
                lines += "Autonomous why: ${truncate(autonomousDiscovery.optString("reason", "blank input resolved to a bounded discovery topic"), 210)}"
            }
        }
        lines += "What the app understood: ${truncate(parsedIntent, 260)}"
        if (topicGateActive) {
            val contaminationCount = (topicGate.optJSONArray("contaminatingSignals") ?: JSONArray()).length()
            lines += "Topic isolation: ${topicGate.optString("state", "UNKNOWN")} | fit=${topicGate.optInt("topicFitScore", 0)}/100 | contamination=$contaminationCount | score caps=${truncate(adjustedScores.optString("capReason", "none"), 150)}"
            if (topicGate.optBoolean("templateFallbackDetected", false)) {
                lines += "Template fallback detected: prior/generic route text was downgraded to retrieval-only; current raw query remains the topic identity."
            }
        }
        lines += "Strongest exploratory route: ${truncate(strongestRoute, 240)} | ${routeState.state}"
        lines += truncate(safeFindingLineV2745, 260)
        lines += "Evidence state: $evidenceGradeForBrief | leads=$leadCountForBrief | routes=$routeCountForBrief | accessions=$accessionCountForBrief | matrix=${firstNonBlank(mechanism.optString("matrixAnalysisGate"), "DGE_NOT_READY")}"
        lines += GTIMMatrixAuditCardV2745.oneLine(matrixAuditCardV2745)
        lines += GTIMMatrixAuditCardV2745.gapLine(matrixAuditCardV2745)
        if (topicRouteLineVisibleForBriefV2744.isNotBlank()) {
            if (topicRouteLineVisibleForBriefV2744.startsWith("Blocked side-route:")) {
                lines += topicRouteLineVisibleForBriefV2744
            } else {
                lines += "Topic-specific route: ${truncate(topicRouteLineVisibleForBriefV2744, 230)}"
            }
        }
        if (materializedSeeds.isNotEmpty()) {
            lines += "Seed handles queued: ${truncate(materializedSeeds.take(6).joinToString(", "), 220)} | lookup-only; not evidence or gate closure"
        }
        if (primaryCapturedSeed.isNotBlank()) {
            lines += "Captured accession seed: $primaryCapturedSeed | $capturedSeedStatus | route=$capturedSeedRouteState"
        }
        lines += "Scores: $scoreLine"
        lines += "Run contract: mode=${runDecisionContractForBriefV2741.runMode} | anchor=${runDecisionContractForBriefV2741.primaryAnchor.routeId} | cap=${runDecisionContractForBriefV2741.evidenceCaps.dataQualityMax}/${runDecisionContractForBriefV2741.evidenceCaps.evidenceStrengthMax}/${runDecisionContractForBriefV2741.evidenceCaps.routeConfidenceMax} | claim=${runDecisionContractForBriefV2741.claimMode}"
        lines += "Contract discovery paths: ${runDecisionContractForBriefV2741.discoveryBridges.take(5).joinToString(", ") { it.routeId }}"
        lines += discoveryLedgerV2745.summaryLine
        lines += discoveryLedgerV2745.topLine
        lines += "Route state ladder: ${routeState.state} | next=${truncate(routeState.nextGate, 160)}"
        if (paperLite.active) {
            lines += "Paper-understanding lite: ${truncate(paperLite.summary, 230)} | score=${paperLite.paperUnderstandingScore}/100"
            lines += "Extracted claim: ${truncate(paperLite.strongestClaim, 220)}"
        }
        if (proofOfValue.active) {
            lines += "Proof-of-value: ${proofOfValue.valueState} | ${truncate(proofOfValue.addedValue.joinToString("; "), 220)}"
        }
        if (forcedClosureGuard.active) {
            lines += "Safety integrity guard: ${forcedClosureGuard.state} | blocked=${truncate(forcedClosureGuard.detectedPatterns.joinToString(", "), 160)}"
            lines += "Forced closure blocked: matrix/contradiction/evidence gates remain open until metadata, comparator, matrix, and contradiction checks pass."
        }
        if (relationshipPlan.active && relationshipVisibleByContractV2745) {
            lines += "Relationship discovery: ${relationshipPlan.matchedArchetype} | ${truncate(relationshipPlan.relationshipChain.joinToString(" -> "), 220)}"
            lines += "GTIM added: ${truncate(relationshipPlan.gtimAdded.joinToString("; "), 230)}"
            lines += "GTIM did not prove: ${truncate(relationshipPlan.gtimDidNotProve.joinToString(", "), 190)}"
        } else if (relationshipPlan.active) {
            lines += "Relationship discovery suppressed: prior/template route outside active contract (${runDecisionContractForBriefV2741.primaryAnchor.routeId})."
        }
        if (microbiomeBridgePlan.active) {
            lines += "Microbiome bridge: ${microbiomeBridgePlan.state} | routes=${truncate(microbiomeBridgePlan.routeIds.joinToString(", "), 160)}"
            lines += "Microbiome bridge gates: ${truncate(microbiomeBridgePlan.requiredBridgeGates.take(5).joinToString(", "), 220)}"
        }
        if (benchmarkValue.active) {
            lines += "Benchmark value gate: ${benchmarkValue.benchmarkState} | score=${benchmarkValue.valueDeltaScore}/100 | topic=${benchmarkValue.matchedBenchmarkTopic} | stopExpansion=${benchmarkValue.stopExpansion}"
            if (benchmarkValue.stopExpansion) {
                lines += "Expansion lock: EXPANSION_LOCKED_UNTIL_PROOF_OF_VALUE | next cycle restricted to retrieval, relationship proof, contradiction and paper-lite improvement."
            }
            lines += "Benchmark next action: ${truncate(benchmarkValue.nextAction, 210)}"
        }
        val dataQualityForBrief = contractDataQualityForBriefV2741
        val noveltyForBrief = adjustedScores.optInt("noveltyScore", maxOf(threeScore.optInt("noveltyScore", 0), if (materializedSeeds.isNotEmpty()) 10 else 0))
        val plausibilityForBrief = adjustedScores.optInt("biologicalPlausibilityScore", maxOf(threeScore.optInt("biologicalPlausibilityScore", 0), if (materializedSeeds.isNotEmpty()) 20 else 0))
        lines += "Three-dimensional grade: Data Quality $dataQualityForBrief/100 | Novelty $noveltyForBrief/100 | Biological Plausibility $plausibilityForBrief/100"
        lines += "Best data feed now: ${truncate(contractSafeDataActionForBriefV2744, 230)}"
        lines += truncate(GTIMMatrixAuditCardV2745.recoveryLine(matrixAuditCardV2745), 260)
        if (runtimeBackfill != null) lines += "Runtime data-feed route: ${truncate(runtimeBackfill.status, 230)}"
        val queryToShow = firstNonBlank(
            if (topicGateActive && topicSafeQueryForBrief.isNotBlank() && GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(topicSafeQueryForBrief, runDecisionContractForBriefV2741)) topicSafeQueryForBrief else "",
            contractSafeQueryForBriefV2744,
            GTIMDownstreamContractAdaptersV2740.safeQuery(runDecisionContractForBriefV2741)
        )
        if (queryToShow.isNotBlank()) lines += "Best query to run: ${truncate(queryToShow, 230)}"
        lines += "Contradiction check: ${truncate(contradiction, 210)}"
        lines += "Preliminary lab idea: ${truncate(labIdea, 220)}"
        lines += "Upgrade gates: ${truncate(blockers, 220)}"
        lines += "Do not believe yet: no mechanism, causality, DGE, clinical outcome, diagnosis, treatment, dose, or patient prediction is proven."
        lines += "Technical appendix: hidden from main brief; raw JSON, command trace, parser cards, and source metadata remain in advanced export."
        lines += "Boundary: $CLAIM_BOUNDARY; discovery routes are allowed, anchor identity is protected in user-directed runs, and autonomous exploration remains labeled by evidence level."
        if (dataChannelsCount == 0) {
            lines.add(8, "Data-feed visibility warning: no public data channel was surfaced; run user-triggered resolver or structured intake.")
        }
        return lines.take(RuntimeFeatureFlags.GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061.coerceAtMost(32).coerceAtLeast(12))
    }


    private data class RuntimeBriefBackfill(
        val researchIntentJson: JSONObject,
        val dataFeedPlanJson: JSONObject,
        val syntheticDataChannels: JSONArray,
        val status: String
    )

    private fun buildRuntimeBackfillIfNeeded(
        rawResearchIntent: JSONObject,
        rawDataFeedPlan: JSONObject,
        mechanism: JSONObject,
        matrix: JSONObject,
        userTopic: String = ""
    ): RuntimeBriefBackfill? {
        val hasIntent = rawResearchIntent.optBoolean("active", false) && rawResearchIntent.optInt("intentCompletenessScore", 0) > 0
        val hasPlan = (rawDataFeedPlan.optJSONArray("repositorySearchPlan") ?: JSONArray()).length() > 0
        if (hasIntent && hasPlan) return null

        val raw = buildFallbackResearchText(mechanism, matrix, userTopic)
        if (raw.isBlank()) return null
        val intent = GTIMResearchIntentParserV255.parse(raw, mechanism.optString("bestResearchLeadSummary"))
        if (!intent.active) return null
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        if (!plan.active || plan.repositorySearchPlan.isEmpty()) return null

        return RuntimeBriefBackfill(
            researchIntentJson = DatasetForagingJson.gtimResearchIntentToJson(intent),
            dataFeedPlanJson = DatasetForagingJson.gtimDataFeedPlanToJson(plan),
            syntheticDataChannels = syntheticChannelsFromPlan(plan),
            status = "brief backfill from mechanism/matrix context; Europe PMC/OpenAlex/seed bootstrap surfaced without evidence upgrade"
        )
    }

    private fun buildFallbackResearchText(mechanism: JSONObject, matrix: JSONObject, userTopic: String = ""): String {
        val parts = mutableListOf<String>()
        parts += userTopic
        parts += mechanism.optString("researchQuestion")
        parts += mechanism.optString("bestResearchLeadSummary")
        parts += mechanism.optString("nextDecisiveAction")
        parts += jsonArray(matrix.optJSONArray("detectedTargets")).joinToString(" ")
        parts += jsonArray(matrix.optJSONArray("runtimeDataDemand")).joinToString(" ")
        parts += jsonArray(matrix.optJSONArray("controlComparatorLinkageQueries")).joinToString(" ")
        parts += firstJsonQuery(matrix.optJSONArray("queryStreams"))
        parts += firstProgrammaticQuery(matrix.optJSONArray("crossReferenceMatrix"))
        val joined = parts.filter { it.isNotBlank() }.joinToString(" | ")
        return if (joined.isBlank()) "immune response dataset accession comparator matrix Europe PMC OpenAlex data availability" else joined
    }

    private fun firstJsonQuery(array: JSONArray?): String {
        if (array == null) return ""
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val query = firstNonBlank(obj.optString("query"), obj.optString("querySeed"), obj.optString("programmaticQuery"))
            if (query.isNotBlank()) return query
        }
        return ""
    }

    private fun firstProgrammaticQuery(array: JSONArray?): String {
        if (array == null) return ""
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val direct = firstNonBlank(obj.optString("query"), obj.optString("programmaticQuery"))
            if (direct.isNotBlank()) return direct
            val nested = jsonArray(obj.optJSONArray("programmaticQueries")).firstOrNull()
            if (!nested.isNullOrBlank()) return nested
        }
        return ""
    }

    private fun syntheticChannelsFromPlan(plan: GTIMDataFeedPlanV255): JSONArray {
        val out = JSONArray()
        plan.repositorySearchPlan.take(8).forEachIndexed { index, query ->
            out.put(JSONObject()
                .put("channelId", "DF_RUNTIME_BACKFILL_${index}_${query.repository.uppercase().replace(Regex("[^A-Z0-9]+"), "_").trim('_')}")
                .put("priority", 100 - index)
                .put("sourceFamily", query.repository)
                .put("intakeMode", query.purpose)
                .put("querySeed", query.query)
                .put("expectedGain", "surface a public lookup route before declaring no data channel")
                .put("localFirstPrivacyPosture", "user-started public metadata lookup only")
                .put("playProtectPosture", "HTTPS public biomedical metadata; no background telemetry")
                .put("nextAction", "Run ${query.repository} lookup, extract accession/DOI/PMID/PMCID hints, then close comparator and matrix gates")
                .put("claimBoundary", GTIMClaimGuardV250.CLAIM_BOUNDARY))
        }
        return out
    }


    private fun topicRouteSummary(dataFeedPlan: JSONObject, dataChannels: JSONArray): String {
        val repositorySearchPlan = dataFeedPlan.optJSONArray("repositorySearchPlan") ?: JSONArray()
        for (i in 0 until repositorySearchPlan.length()) {
            val obj = repositorySearchPlan.optJSONObject(i) ?: continue
            if (obj.optString("repository").equals("Topic-Specific Route Builder", ignoreCase = true)) {
                val query = obj.optString("query")
                val targets = jsonArray(obj.optJSONArray("metadataTargets"))
                    .filter { it.contains("topic=", true) || it.contains("TOPIC_", true) || it.contains("connected", true) }
                    .take(3)
                    .joinToString("; ")
                return firstNonBlank(targets, query, obj.optString("purpose"))
            }
        }
        for (i in 0 until dataChannels.length()) {
            val obj = dataChannels.optJSONObject(i) ?: continue
            if (obj.optString("sourceFamily").equals("Topic-Specific Route Builder", ignoreCase = true)) {
                return firstNonBlank(obj.optString("querySeed"), obj.optString("nextAction"))
            }
        }
        return ""
    }

    private fun materializedPriorSeeds(
        dataFeedPlan: JSONObject,
        dataChannels: JSONArray,
        topDataAction: String,
        topQuery: String?,
        mechanism: JSONObject,
        matrix: JSONObject,
        v3: JSONObject
    ): List<String> {
        val chunks = mutableListOf<String>()
        chunks += topDataAction
        if (!topQuery.isNullOrBlank()) chunks += topQuery
        chunks += dataFeedPlan.optString("bestNextAction")
        chunks += jsonArray(dataFeedPlan.optJSONArray("querySeeds")).joinToString(" ")
        val repositorySearchPlan = dataFeedPlan.optJSONArray("repositorySearchPlan") ?: JSONArray()
        for (i in 0 until repositorySearchPlan.length()) {
            val obj = repositorySearchPlan.optJSONObject(i) ?: continue
            chunks += obj.optString("repository")
            chunks += obj.optString("query")
            chunks += jsonArray(obj.optJSONArray("accessionPatterns")).joinToString(" ")
            chunks += jsonArray(obj.optJSONArray("metadataTargets")).joinToString(" ")
        }
        for (i in 0 until dataChannels.length()) {
            val obj = dataChannels.optJSONObject(i) ?: continue
            chunks += obj.optString("querySeed")
            chunks += obj.optString("nextAction")
            chunks += obj.optString("sourceFamily")
        }
        chunks += mechanism.optString("bestResearchLeadSummary")
        chunks += mechanism.optString("nextDecisiveAction")
        chunks += jsonArray(matrix.optJSONArray("detectedTargets")).joinToString(" ")
        chunks += jsonArray(matrix.optJSONArray("runtimeDataDemand")).joinToString(" ")
        chunks += v3.optString("counterEvidenceOrContradiction")
        val combined = chunks.joinToString("\n")
        val extracted = extractSeedHandles(combined).toMutableList()
        // v2.7.4.8: if an old runtime report clearly references the stress/HPA/latent-virus
        // prior route, materialize its curated prior handles as lookup-only. This restores the
        // historical brief behavior without letting known-prior seeds hijack an active user topic.
        extracted += GTIMKnownPriorEvidenceSeedsV269.handlesForText(combined, limit = 8)
        return extracted.distinct().take(12)
    }

    private fun extractSeedHandles(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val regex = Regex("""(?i)\b(?:PMID[:\s]*\d{6,9}|DOI[:\s]*(?:10\.\d{4,9}/[^\s,;|)]+)|GSE\s*\d{3,8}|GDS\s*\d+|PRJNA\s*\d+|SRP\s*\d+|SRR\s*\d+|E-MTAB-\s*\d+|SDY\s*\d+)\b""")
        return regex.findAll(text)
            .map { normalizeBriefSeedHandle(it.value) }
            .filter { it.isNotBlank() }
            .toList()
    }

    private fun normalizeBriefSeedHandle(raw: String): String {
        val cleaned = raw.trim().trim(',', ';', ')', '(', '|')
            .replace(Regex("(?i)^PMID[:\\s]*"), "PMID:")
            .replace(Regex("(?i)^DOI[:\\s]*"), "DOI:")
            .replace(Regex("\\s+"), "")
            .uppercase()
        val known = (GTIMKnownPriorEvidenceSeedsV269.allHandles + GTIMSeedAccessionBootstrapV265.seeds.flatMap { it.handles })
            .map { it.replace(Regex("\\s+"), "").uppercase() }
            .distinct()
        val normalizedKnown = when {
            cleaned.startsWith("DOI:") -> cleaned.removePrefix("DOI:").lowercase()
            cleaned.startsWith("PMID:") -> cleaned
            cleaned.matches(Regex("GSE\\d+")) -> {
                val corrected = known.firstOrNull { knownHandle ->
                    knownHandle.matches(Regex("GSE\\d+")) && cleaned.startsWith(knownHandle) && cleaned.length == knownHandle.length + 1 && cleaned.endsWith("0")
                }
                corrected ?: cleaned
            }
            else -> cleaned
        }
        return normalizedKnown
            .replace("PMID", "PMID")
            .replace("GSE", "GSE")
    }

    private fun evidenceObjectsWithAccessionCount(gtim: JSONObject): Int {
        val evidenceObjects = gtim.optJSONArray("evidenceObjects") ?: JSONArray()
        var count = 0
        for (i in 0 until evidenceObjects.length()) {
            val accession = evidenceObjects.optJSONObject(i)?.optString("accessionId").orEmpty()
            if (accession.isNotBlank()) count += 1
        }
        return count
    }

    private fun parsedIntentSummary(intent: JSONObject): String {
        val card = jsonArray(intent.optJSONArray("parsedResearchIntentCard")).filterNot { it.equals("Parsed Research Intent", true) }
        if (card.isNotEmpty()) return card.take(8).joinToString(" | ")
        val parts = listOf(
            "Trigger=${intent.optString("triggerExposure")}",
            "Disease=${intent.optString("diseasePhenotype")}",
            "Pathway=${intent.optString("pathway")}",
            "Cell/tissue=${intent.optString("cellTissue")}",
            "Comparator=${intent.optString("comparatorWanted")}",
            "Assay=${intent.optString("assayType")}",
            "Repositories=${jsonArray(intent.optJSONArray("repositoryTargets")).joinToString(", ")}",
            "Output=${intent.optString("outputMode")}"
        ).filter { !it.endsWith("=") && !it.endsWith("=, ") }
        return parts.joinToString(" | ").ifBlank { "Research Intent parser available; use structured intake for stronger routing." }
    }

    private fun evidenceGrade(evidenceObjects: Int, accessions: Int, routeFit: Int, upgradeAllowed: Boolean): String = when {
        upgradeAllowed && evidenceObjects > 0 && accessions > 0 -> "B — evidence object ready for controlled review"
        evidenceObjects > 0 && accessions > 0 -> "C+ — evidence object present, claims still gated"
        accessions > 0 -> "C — accession found, metadata closure required"
        routeFit >= 70 -> "D+ — high-priority route, no confirmed accession yet"
        routeFit >= 25 -> "D — useful weak lead; feed more data"
        else -> "E+ — early exploratory signal; keep if route is scientifically interesting"
    }

    private fun jsonArray(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { idx ->
            val value = array.opt(idx) ?: return@mapNotNull null
            when (value) {
                is JSONObject -> firstNonBlank(
                    value.optString("accessionId"),
                    value.optString("leadId"),
                    value.optString("targetAxis"),
                    value.optString("routeId"),
                    value.optString("targetMolecularAxis"),
                    value.optString("streamId"),
                    value.optString("querySeed"),
                    value.optString("query"),
                    value.optString("label"),
                    value.optString("gateId"),
                    value.optString("nextAction"),
                    value.toString()
                )
                else -> value.toString()
            }.takeIf { it.isNotBlank() }
        }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""

    private fun truncate(value: String, max: Int): String {
        val oneLine = value.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1).trimEnd() + "…"
    }

    private fun sanitizeHeader(value: String): String = when (value.trim().uppercase()) {
        "UNKNOWN", "ENGINE: UNKNOWN", "LOCK: UNKNOWN", "STATE: UNKNOWN" -> "PASS"
        else -> value.ifBlank { "PASS" }
    }

    private fun sanitizeEngine(value: String): String = when (value.trim().uppercase()) {
        "UNKNOWN", "ENGINE: UNKNOWN" -> GTIMClaimGuardV250.ENGINE_IDENTITY
        else -> value.ifBlank { GTIMClaimGuardV250.ENGINE_IDENTITY }
    }
}
