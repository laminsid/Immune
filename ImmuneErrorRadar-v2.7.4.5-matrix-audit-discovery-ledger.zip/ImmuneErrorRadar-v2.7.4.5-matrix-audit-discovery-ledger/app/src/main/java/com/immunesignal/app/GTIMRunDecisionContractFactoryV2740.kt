package com.immunesignal.app

/**
 * Contract-first classifier.
 * v2.7.4.1 fixes:
 * - BUG-02: IBD/Crohn/colitis/gut-barrier queries no longer fall into depression bridges.
 * - BUG-03: accession-backed DGE_READY runs can receive normal 100/100/100 caps.
 * - BUG-04: UNKNOWN + USER_QUERY is converted to autonomous free exploration instead of a fake protected anchor.
 * - P1: adds anchors for IBD, SLE, MS, RA, Psoriasis, and Type 1 diabetes.
 */
object GTIMRunDecisionContractFactoryV2740 {

    private val readyMatrixStates = setOf(
        "DGE_READY",
        "DGE_READY_WITH_ACCESSION",
        "DGE_READY_ACCESSION_BACKED",
        "READY",
        "ACCESSION_READY"
    )

    fun build(
        rawQuery: String,
        inputMode: GTIMInputModeV2740 = GTIMInputModeV2740.USER_QUERY,
        hasDatasetAccessions: Boolean = true,
        matrixState: String? = null
    ): GTIMRunDecisionContractV2740 {
        val normalized = normalize(rawQuery)
        val autonomousByInput = inputMode == GTIMInputModeV2740.AUTONOMOUS_DISCOVERY || normalized.isBlank()
        if (autonomousByInput) {
            return autonomousContract(rawQuery, normalized, inputMode, hasDatasetAccessions, matrixState)
        }

        // CI regression guard: a user can enter a directed text that explicitly says it has no
        // stable disease anchor. Do not protect UNKNOWN as if it were a real phenotype.
        if (looksExplicitlyUnanchored(normalized)) {
            return autonomousContract(rawQuery, normalized, inputMode, hasDatasetAccessions, matrixState).copy(
                anchorConfidence = 45,
                anchorReason = "Explicitly unanchored user query converted to autonomous exploration.",
                reason = "No protected disease anchor was trusted; broad discovery is allowed but evidence labels and caps remain mandatory."
            )
        }

        val detected = detectAnchor(normalized)

        // BUG-04 fix: a directed user query with no stable anchor must not become a fake protected UNKNOWN anchor.
        // It becomes autonomous exploration over the user's text, with low/exploratory claim limits.
        if (detected.anchor == GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY || detected.confidence < 60) {
            return autonomousContract(rawQuery, normalized, inputMode, hasDatasetAccessions, matrixState).copy(
                anchorConfidence = detected.confidence.coerceAtMost(50),
                anchorReason = "Low-confidence user query converted to autonomous exploration: ${detected.reason}",
                reason = "No protected anchor was trusted; broad discovery is allowed but all bridges must remain labeled and evidence-capped."
            )
        }

        val caps = capsFor(detected.confidence, hasDatasetAccessions, matrixState, detected.claimMode)
        val bridges = bridgesFor(detected.anchor)
        val domains = domainsFor(detected.anchor)
        val allowedRoutes = buildSet {
            add(detected.anchor.routeId)
            bridges.mapTo(this) { it.routeId }
        }
        val exploratoryRoutes = bridges.map { it.routeId }.toSet() - detected.anchor.routeId
        val forbidden = forbiddenConflationsFor(detected.anchor)
        val blocked = blockedRoutesFor(detected.anchor, forbidden)

        return GTIMRunDecisionContractV2740(
            rawQuery = rawQuery,
            normalizedQuery = normalized,
            inputMode = inputMode,
            runMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED,
            primaryAnchor = detected.anchor,
            diseaseFamily = detected.family,
            anchorConfidence = detected.confidence,
            anchorReason = detected.reason,
            anchorMustNotMutate = true,
            secondaryDomains = domains,
            discoveryBridges = bridges,
            exploratoryRoutes = exploratoryRoutes,
            allowedRoutes = allowedRoutes,
            blockedRoutes = blocked,
            allowedSeeds = seedsFor(detected.anchor),
            blockedSeeds = blocked,
            benchmarkTopic = benchmarkFor(detected.anchor),
            forbiddenIdentityMutations = forbidden,
            forbiddenConflations = forbidden,
            evidenceCaps = caps,
            claimMode = detected.claimMode,
            bridgeRationale = bridgeRationaleFor(detected.anchor),
            reason = "Protected anchor contract: ${detected.reason} Bridge discovery is allowed only around this anchor."
        )
    }

    /**
     * v2.7.4.4: second-stage contract for blank/autonomous runs after the selector
     * has chosen a concrete topic. Autonomous mode remains free to explore distant
     * bridges, but the visible brief/benchmark/data-feed should be anchored to the
     * selected topic instead of the blank AUTO input.
     */
    fun buildAutonomousSelectedTopic(
        rawQuery: String,
        hasDatasetAccessions: Boolean = true,
        matrixState: String? = null
    ): GTIMRunDecisionContractV2740 {
        val normalized = normalize(rawQuery)
        if (normalized.isBlank()) {
            return autonomousContract(rawQuery, normalized, GTIMInputModeV2740.AUTONOMOUS_DISCOVERY, hasDatasetAccessions, matrixState)
        }

        val detected = detectAnchor(normalized)
        if (detected.anchor == GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY || detected.confidence < 60) {
            return autonomousContract(rawQuery, normalized, GTIMInputModeV2740.AUTONOMOUS_DISCOVERY, hasDatasetAccessions, matrixState).copy(
                anchorConfidence = detected.confidence.coerceAtMost(50),
                anchorReason = "Autonomous selected topic remained low-confidence: ${detected.reason}",
                reason = "Selected topic could not be safely anchored; broad discovery remains allowed with evidence labels."
            )
        }

        val allBridges = GTIMDiscoveryBridgeV2740.values().toSet()
        val allRouteIds = allBridges.map { it.routeId }.toSet() + GTIMPrimaryAnchorV2740.values().map { it.routeId }.toSet()
        val topicBridges = bridgesFor(detected.anchor)
        val topicDomains = domainsFor(detected.anchor)
        val forbidden = forbiddenConflationsFor(detected.anchor)
        val caps = capsFor(detected.confidence, hasDatasetAccessions, matrixState, GTIMClaimModeV2740.AUTONOMOUS_EXPLORATORY_HYPOTHESIS)

        return GTIMRunDecisionContractV2740(
            rawQuery = rawQuery,
            normalizedQuery = normalized,
            inputMode = GTIMInputModeV2740.AUTONOMOUS_DISCOVERY,
            runMode = GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION,
            primaryAnchor = detected.anchor,
            diseaseFamily = detected.family,
            anchorConfidence = detected.confidence,
            anchorReason = "Autonomous selected-topic anchor: ${detected.reason}",
            anchorMustNotMutate = false,
            secondaryDomains = topicDomains,
            discoveryBridges = topicBridges,
            exploratoryRoutes = topicBridges.map { it.routeId }.toSet() - detected.anchor.routeId,
            allowedRoutes = allRouteIds,
            blockedRoutes = emptySet(),
            allowedSeeds = allRouteIds,
            blockedSeeds = emptySet(),
            benchmarkTopic = benchmarkFor(detected.anchor),
            forbiddenIdentityMutations = forbidden,
            forbiddenConflations = forbidden,
            evidenceCaps = caps,
            claimMode = GTIMClaimModeV2740.AUTONOMOUS_EXPLORATORY_HYPOTHESIS,
            bridgeRationale = "Autonomous selected-topic contract: ${bridgeRationaleFor(detected.anchor)} Cross-domain exploration is still allowed, but visible summary/benchmark/feed are centered on the selected topic.",
            reason = "Autonomous second-stage contract: blank input selected a topic, then rebuilt a topic-aware contract without locking exploration."
        )
    }

    private data class AnchorDetection(
        val anchor: GTIMPrimaryAnchorV2740,
        val family: GTIMDiseaseFamilyV2740,
        val confidence: Int,
        val claimMode: GTIMClaimModeV2740,
        val reason: String
    )

    private fun normalize(raw: String): String = raw
        .lowercase()
        .replace('أ', 'ا')
        .replace('إ', 'ا')
        .replace('آ', 'ا')
        .replace('ى', 'ي')
        .replace('ة', 'ه')
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun looksExplicitlyUnanchored(q: String): Boolean {
        return q.contains("without disease anchor") ||
            q.contains("no disease anchor") ||
            (q.contains("unclear") && q.contains("rare signal")) ||
            (q.contains("unknown") && q.contains("anchor"))
    }

    private fun detectAnchor(q: String): AnchorDetection {
        fun hasAny(vararg needles: String): Boolean = needles.any { q.contains(it) }
        fun hasDepression(): Boolean = hasAny("depression", "depressive", "mood disorder", "major depressive", "اكتئاب", "الاكتئاب")
        fun hasGutMicrobiomeDiscovery(): Boolean = hasAny("microbiome", "microbiota", "gut bacteria", "gut-brain", "gut brain", "bacteria", "بكتيريا", "ميكروبيوم") ||
            (hasAny("امعاء", "الامعاء") && hasDepression())
        fun hasIbd(): Boolean = hasAny("ibd", "inflammatory bowel", "crohn", "crohn's", "colitis", "ulcerative colitis", "mucosal inflammation", "intestinal barrier", "gut inflammation", "التهاب الامعاء", "كرون", "قولون تقرحي")

        return when {
            hasAny("covid", "sars-cov-2", "sars cov 2", "corona", "كورونا", "كوفيد") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL,
                GTIMDiseaseFamilyV2740.RESPIRATORY_VIRAL,
                92,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected Covid/SARS-CoV-2 respiratory viral anchor."
            )

            hasAny("allergy", "allergies", "allergic", "hypersensitivity", "atopy", "atopic", "allergen", "حساسيه", "الحساسيه", "حساسية", "الحساسية", "ige", "mast cell", "eosinophil", "eosinophils") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL,
                GTIMDiseaseFamilyV2740.ALLERGIC_TYPE2,
                91,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected allergy/type-2 immune anchor."
            )

            hasAny("hantavirus", "hanta", "هانتا") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL,
                GTIMDiseaseFamilyV2740.VECTOR_BORNE_OR_ZOONOTIC,
                90,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected hantavirus/zoonotic viral anchor."
            )

            hasAny("ebola", "ايبولا", "ابولا") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL,
                GTIMDiseaseFamilyV2740.HEMORRHAGIC_VIRAL,
                90,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected Ebola/hemorrhagic viral anchor."
            )

            hasAny("hiv", "aids", "sida", "سيدا", "الايدز", "الإيدز") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION,
                GTIMDiseaseFamilyV2740.RETROVIRAL_IMMUNODEFICIENCY,
                91,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected HIV/AIDS retroviral immunodeficiency anchor."
            )

            hasAny("epidemic", "pandemic", "outbreak", "epidemics", "وباء", "اوبئه", "الاوبئه", "جائحه", "تفشي") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE,
                GTIMDiseaseFamilyV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE,
                85,
                GTIMClaimModeV2740.RESEARCH_DIRECTION_ONLY,
                "Detected outbreak/epidemic surveillance frame, not one fixed disease."
            )

            hasAny("fever", "حمى", "الحمي", "حراره", "temperature") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.GENERAL_FEVER_SYNDROME,
                GTIMDiseaseFamilyV2740.GENERAL_FEVER_SYNDROME,
                82,
                GTIMClaimModeV2740.RESEARCH_DIRECTION_ONLY,
                "Detected fever syndrome frame; fever is a symptom/differential, not a single disease."
            )

            // BUG-02 fix: IBD/gut barrier queries must be classified before microbiome/depression bridges.
            hasIbd() -> AnchorDetection(
                GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE,
                GTIMDiseaseFamilyV2740.INFLAMMATORY_BOWEL_DISEASE,
                88,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected IBD/Crohn/colitis mucosal-barrier inflammatory anchor."
            )

            hasAny("sle", "systemic lupus", "lupus", "lupus erythematosus", "ذئبه", "الذئبه") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.SLE_SYSTEMIC_AUTOIMMUNE,
                GTIMDiseaseFamilyV2740.SYSTEMIC_AUTOIMMUNE,
                87,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected SLE/lupus systemic autoimmune anchor."
            )

            hasAny("multiple sclerosis", "ms ", " ms", "demyelination", "demyelinating", "تصلب متعدد") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.MS_NEUROIMMUNE_DEMYELINATION,
                GTIMDiseaseFamilyV2740.NEUROIMMUNE_DEMYELINATION,
                86,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected MS/neuroimmune demyelination anchor."
            )

            hasAny("rheumatoid arthritis", "ra ", " ra", "synovitis", "citrullination", "التهاب المفاصل الروماتويدي", "روماتويد") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.RA_SYNOVIAL_AUTOIMMUNE,
                GTIMDiseaseFamilyV2740.AUTOIMMUNE,
                86,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected rheumatoid arthritis/synovial autoimmune anchor."
            )

            hasAny("psoriasis", "psoriatic", "il-17", "il17", "il-23", "il23", "صدفيه", "الصدفيه") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.PSORIASIS_IL23_IL17_SKIN,
                GTIMDiseaseFamilyV2740.SKIN_BARRIER_AUTOIMMUNE,
                86,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected psoriasis/IL-23/IL-17 skin-barrier autoimmune anchor."
            )

            hasAny("type 1 diabetes", "t1d", "autoimmune diabetes", "beta cell", "β-cell", "سكري نوع اول", "السكري النوع الاول") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.T1D_AUTOIMMUNE_BETA_CELL,
                GTIMDiseaseFamilyV2740.BETA_CELL_AUTOIMMUNE,
                86,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected type 1 diabetes/beta-cell autoimmune anchor."
            )

            hasDepression() && hasGutMicrobiomeDiscovery() -> AnchorDetection(
                GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION,
                GTIMDiseaseFamilyV2740.NEUROIMMUNE,
                88,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected explicit gut microbiome to depression discovery question."
            )

            hasDepression() -> AnchorDetection(
                GTIMPrimaryAnchorV2740.DEPRESSION_NEUROIMMUNE,
                GTIMDiseaseFamilyV2740.NEUROIMMUNE,
                80,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected depression/neuroimmune anchor."
            )

            hasAny("pcos", "polycystic", "تكيس", "المبايض", "thyroid", "غده", "الغده", "خمول") && hasAny("yeast", "fungal", "fungus", "candida", "خميره", "فطري", "فطريات") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE,
                GTIMDiseaseFamilyV2740.FUNGAL_YEAST_EXPOSURE,
                84,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected yeast/fungal exposure to endocrine/reproductive discovery question."
            )

            hasAny("pcos", "polycystic", "تكيس", "المبايض", "thyroid", "غده", "الغده", "خمول") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.ENDOCRINE_REPRODUCTIVE_DYSFUNCTION,
                GTIMDiseaseFamilyV2740.ENDOCRINE_REPRODUCTIVE,
                78,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected endocrine/reproductive dysfunction anchor."
            )

            hasAny("aging", "ageing", "longevity", "senescence", "شيخوخه", "الشيخوخه", "العمر") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.LONGEVITY_IMMUNOSENESCENCE,
                GTIMDiseaseFamilyV2740.AGING_IMMUNOSENESCENCE,
                82,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected longevity/immunosenescence anchor."
            )

            hasAny("cancer", "tumor", "tumour", "oncology", "سرطان", "ورم") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.CANCER_IMMUNE,
                GTIMDiseaseFamilyV2740.CANCER_IMMUNE,
                76,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected cancer/immune anchor."
            )

            hasAny("autoimmune", "autoimmunity", "مناعه ذاتيه", "المناعه الذاتيه") -> AnchorDetection(
                GTIMPrimaryAnchorV2740.AUTOIMMUNE_INFLAMMATORY,
                GTIMDiseaseFamilyV2740.AUTOIMMUNE,
                72,
                GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                "Detected generic autoimmune inflammatory anchor."
            )

            else -> AnchorDetection(
                GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY,
                GTIMDiseaseFamilyV2740.UNKNOWN_AUTONOMOUS_DISCOVERY,
                45,
                GTIMClaimModeV2740.RESEARCH_DIRECTION_ONLY,
                "No stable primary anchor detected; convert to labeled autonomous exploration."
            )
        }
    }

    private fun capsFor(
        confidence: Int,
        hasDatasetAccessions: Boolean,
        matrixState: String?,
        claimMode: GTIMClaimModeV2740
    ): GTIMEvidenceCapsV2740 {
        val state = matrixState?.uppercase()?.trim()
        if (!hasDatasetAccessions && state == "DGE_NOT_READY_NO_ACCESSION") {
            return GTIMEvidenceCapsV2740.weakNoAccession()
        }
        if (confidence < 60) return GTIMEvidenceCapsV2740.lowClassification()

        // BUG-03 fix: strong evidence must be allowed to surface when the matrix is truly accession-backed and ready.
        if (hasDatasetAccessions && state != null && state in readyMatrixStates && confidence >= 80) {
            return GTIMEvidenceCapsV2740.normal()
        }

        if (claimMode == GTIMClaimModeV2740.RESEARCH_DIRECTION_ONLY) {
            return GTIMEvidenceCapsV2740.exploratory("syndrome/surveillance frame; no single-disease causality claim")
        }
        return GTIMEvidenceCapsV2740.exploratory()
    }

    private fun bridgesFor(anchor: GTIMPrimaryAnchorV2740): Set<GTIMDiscoveryBridgeV2740> = when (anchor) {
        GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> setOf(
            GTIMDiscoveryBridgeV2740.COVID_TO_INTERFERON_MEMORY,
            GTIMDiscoveryBridgeV2740.VIRAL_TO_AUTOIMMUNE_FLARE,
            GTIMDiscoveryBridgeV2740.VIRAL_TO_GUT_MICROBIOME_DISRUPTION,
            GTIMDiscoveryBridgeV2740.VIRAL_TO_NEUROINFLAMMATION_FATIGUE
        )
        GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> setOf(
            GTIMDiscoveryBridgeV2740.ALLERGY_TO_BARRIER_IMMUNITY,
            GTIMDiscoveryBridgeV2740.ALLERGY_TO_MICROBIOME_BARRIER
        )
        GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> setOf(
            GTIMDiscoveryBridgeV2740.VIRAL_TO_AUTOIMMUNE_FLARE,
            GTIMDiscoveryBridgeV2740.VIRAL_TO_NEUROINFLAMMATION_FATIGUE
        )
        GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> setOf(
            GTIMDiscoveryBridgeV2740.HEMORRHAGIC_VIRUS_TO_HOST_RESPONSE,
            GTIMDiscoveryBridgeV2740.VIRAL_TO_AUTOIMMUNE_FLARE
        )
        GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION -> setOf(
            GTIMDiscoveryBridgeV2740.RETROVIRAL_TO_CD4_IMMUNE_DEPLETION,
            GTIMDiscoveryBridgeV2740.MICROBIOME_TO_HPA_STRESS_AXIS
        )
        GTIMPrimaryAnchorV2740.GENERAL_FEVER_SYNDROME -> setOf(
            GTIMDiscoveryBridgeV2740.FEVER_TO_DIFFERENTIAL_INFECTIOUS_INFLAMMATORY
        )
        GTIMPrimaryAnchorV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE -> setOf(
            GTIMDiscoveryBridgeV2740.OUTBREAK_TO_PATHOGEN_EMERGENCE,
            GTIMDiscoveryBridgeV2740.FEVER_TO_DIFFERENTIAL_INFECTIOUS_INFLAMMATORY
        )
        GTIMPrimaryAnchorV2740.DEPRESSION_NEUROIMMUNE,
        GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> setOf(
            GTIMDiscoveryBridgeV2740.GUT_MICROBIOME_TO_NEUROINFLAMMATION,
            GTIMDiscoveryBridgeV2740.MICROBIOME_TO_TRYPTOPHAN_SEROTONIN,
            GTIMDiscoveryBridgeV2740.MICROBIOME_TO_HPA_STRESS_AXIS
        )
        GTIMPrimaryAnchorV2740.ENDOCRINE_REPRODUCTIVE_DYSFUNCTION,
        GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE -> setOf(
            GTIMDiscoveryBridgeV2740.YEAST_FUNGAL_TO_ENDOCRINE_IMMUNE,
            GTIMDiscoveryBridgeV2740.FUNGAL_TO_BARRIER_DYSBIOSIS,
            GTIMDiscoveryBridgeV2740.METABOLIC_INFLAMMATION_TO_HORMONAL_AXIS,
            GTIMDiscoveryBridgeV2740.MICROBIOME_TO_THYROID_AXIS
        )
        GTIMPrimaryAnchorV2740.LONGEVITY_IMMUNOSENESCENCE -> setOf(
            GTIMDiscoveryBridgeV2740.METABOLIC_INFLAMMATION_TO_HORMONAL_AXIS,
            GTIMDiscoveryBridgeV2740.MICROBIOME_TO_THYROID_AXIS
        )
        GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE -> setOf(
            GTIMDiscoveryBridgeV2740.IBD_TO_BARRIER_MICROBIOME,
            GTIMDiscoveryBridgeV2740.IBD_TO_SYSTEMIC_INFLAMMATION
        )
        GTIMPrimaryAnchorV2740.SLE_SYSTEMIC_AUTOIMMUNE -> setOf(
            GTIMDiscoveryBridgeV2740.AUTOIMMUNE_TO_INTERFERON_AUTOANTIBODY,
            GTIMDiscoveryBridgeV2740.VIRAL_TO_AUTOIMMUNE_FLARE
        )
        GTIMPrimaryAnchorV2740.MS_NEUROIMMUNE_DEMYELINATION -> setOf(
            GTIMDiscoveryBridgeV2740.MS_TO_NEUROINFLAMMATION,
            GTIMDiscoveryBridgeV2740.VIRAL_TO_NEUROINFLAMMATION_FATIGUE,
            GTIMDiscoveryBridgeV2740.GUT_MICROBIOME_TO_NEUROINFLAMMATION
        )
        GTIMPrimaryAnchorV2740.RA_SYNOVIAL_AUTOIMMUNE -> setOf(
            GTIMDiscoveryBridgeV2740.RA_TO_CITRULLINATION_SYNOVIUM,
            GTIMDiscoveryBridgeV2740.AUTOIMMUNE_TO_INTERFERON_AUTOANTIBODY,
            GTIMDiscoveryBridgeV2740.ALLERGY_TO_BARRIER_IMMUNITY
        )
        GTIMPrimaryAnchorV2740.PSORIASIS_IL23_IL17_SKIN -> setOf(
            GTIMDiscoveryBridgeV2740.PSORIASIS_TO_IL23_IL17_SKIN,
            GTIMDiscoveryBridgeV2740.ALLERGY_TO_BARRIER_IMMUNITY,
            GTIMDiscoveryBridgeV2740.IBD_TO_BARRIER_MICROBIOME
        )
        GTIMPrimaryAnchorV2740.T1D_AUTOIMMUNE_BETA_CELL -> setOf(
            GTIMDiscoveryBridgeV2740.T1D_TO_BETA_CELL_AUTOIMMUNITY,
            GTIMDiscoveryBridgeV2740.AUTOIMMUNE_TO_INTERFERON_AUTOANTIBODY,
            GTIMDiscoveryBridgeV2740.MICROBIOME_TO_HPA_STRESS_AXIS
        )
        GTIMPrimaryAnchorV2740.AUTOIMMUNE_INFLAMMATORY -> setOf(
            GTIMDiscoveryBridgeV2740.VIRAL_TO_AUTOIMMUNE_FLARE,
            GTIMDiscoveryBridgeV2740.AUTOIMMUNE_TO_INTERFERON_AUTOANTIBODY,
            GTIMDiscoveryBridgeV2740.ALLERGY_TO_BARRIER_IMMUNITY
        )
        GTIMPrimaryAnchorV2740.CANCER_IMMUNE -> setOf(
            GTIMDiscoveryBridgeV2740.AUTONOMOUS_CROSS_DOMAIN_WEAK_LEAD
        )
        GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY -> setOf(
            GTIMDiscoveryBridgeV2740.AUTONOMOUS_CROSS_DOMAIN_WEAK_LEAD
        )
    }

    private fun domainsFor(anchor: GTIMPrimaryAnchorV2740): Set<GTIMDomainV2740> = when (anchor) {
        GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> setOf(GTIMDomainV2740.VIROLOGY, GTIMDomainV2740.INTERFERON_ANTIVIRAL, GTIMDomainV2740.MICROBIOME, GTIMDomainV2740.NEUROINFLAMMATION, GTIMDomainV2740.AUTOIMMUNITY)
        GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> setOf(GTIMDomainV2740.TYPE2_IGE_MAST_EOSINOPHIL, GTIMDomainV2740.BARRIER_IMMUNITY, GTIMDomainV2740.MICROBIOME)
        GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> setOf(GTIMDomainV2740.VIROLOGY, GTIMDomainV2740.IMMUNOLOGY, GTIMDomainV2740.CLINICAL_SYNDROME_DIFFERENTIAL)
        GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> setOf(GTIMDomainV2740.VIROLOGY, GTIMDomainV2740.CYTOKINE_SIGNALING, GTIMDomainV2740.OUTBREAK_SURVEILLANCE)
        GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION -> setOf(GTIMDomainV2740.VIROLOGY, GTIMDomainV2740.IMMUNOLOGY, GTIMDomainV2740.MICROBIOME)
        GTIMPrimaryAnchorV2740.GENERAL_FEVER_SYNDROME -> setOf(GTIMDomainV2740.CLINICAL_SYNDROME_DIFFERENTIAL, GTIMDomainV2740.OUTBREAK_SURVEILLANCE, GTIMDomainV2740.IMMUNOLOGY)
        GTIMPrimaryAnchorV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE -> setOf(GTIMDomainV2740.OUTBREAK_SURVEILLANCE, GTIMDomainV2740.VIROLOGY, GTIMDomainV2740.BACTERIOLOGY, GTIMDomainV2740.OMICS_DATASET_HUNT)
        GTIMPrimaryAnchorV2740.DEPRESSION_NEUROIMMUNE,
        GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> setOf(GTIMDomainV2740.NEUROINFLAMMATION, GTIMDomainV2740.MICROBIOME, GTIMDomainV2740.METABOLIC, GTIMDomainV2740.IMMUNOLOGY)
        GTIMPrimaryAnchorV2740.ENDOCRINE_REPRODUCTIVE_DYSFUNCTION,
        GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE -> setOf(GTIMDomainV2740.ENDOCRINE, GTIMDomainV2740.REPRODUCTIVE_HORMONES, GTIMDomainV2740.MYCOLOGY_YEAST_FUNGAL, GTIMDomainV2740.MICROBIOME, GTIMDomainV2740.METABOLIC, GTIMDomainV2740.THYROID_AXIS)
        GTIMPrimaryAnchorV2740.LONGEVITY_IMMUNOSENESCENCE -> setOf(GTIMDomainV2740.IMMUNOLOGY, GTIMDomainV2740.METABOLIC, GTIMDomainV2740.MICROBIOME)
        GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE -> setOf(GTIMDomainV2740.MUCOSAL_IMMUNITY, GTIMDomainV2740.BARRIER_IMMUNITY, GTIMDomainV2740.MICROBIOME, GTIMDomainV2740.CYTOKINE_SIGNALING)
        GTIMPrimaryAnchorV2740.SLE_SYSTEMIC_AUTOIMMUNE -> setOf(GTIMDomainV2740.AUTOIMMUNITY, GTIMDomainV2740.INTERFERON_ANTIVIRAL, GTIMDomainV2740.B_CELL_AUTOANTIBODY, GTIMDomainV2740.CYTOKINE_SIGNALING)
        GTIMPrimaryAnchorV2740.MS_NEUROIMMUNE_DEMYELINATION -> setOf(GTIMDomainV2740.NEUROINFLAMMATION, GTIMDomainV2740.DEMYELINATION, GTIMDomainV2740.AUTOIMMUNITY, GTIMDomainV2740.MICROBIOME)
        GTIMPrimaryAnchorV2740.RA_SYNOVIAL_AUTOIMMUNE -> setOf(GTIMDomainV2740.AUTOIMMUNITY, GTIMDomainV2740.SYNOVIAL_INFLAMMATION, GTIMDomainV2740.B_CELL_AUTOANTIBODY, GTIMDomainV2740.CYTOKINE_SIGNALING)
        GTIMPrimaryAnchorV2740.PSORIASIS_IL23_IL17_SKIN -> setOf(GTIMDomainV2740.SKIN_BARRIER, GTIMDomainV2740.IL23_IL17_AXIS, GTIMDomainV2740.BARRIER_IMMUNITY, GTIMDomainV2740.MICROBIOME)
        GTIMPrimaryAnchorV2740.T1D_AUTOIMMUNE_BETA_CELL -> setOf(GTIMDomainV2740.BETA_CELL_AUTOIMMUNITY, GTIMDomainV2740.AUTOIMMUNITY, GTIMDomainV2740.METABOLIC, GTIMDomainV2740.MICROBIOME)
        GTIMPrimaryAnchorV2740.AUTOIMMUNE_INFLAMMATORY -> setOf(GTIMDomainV2740.AUTOIMMUNITY, GTIMDomainV2740.CYTOKINE_SIGNALING, GTIMDomainV2740.BARRIER_IMMUNITY)
        GTIMPrimaryAnchorV2740.CANCER_IMMUNE -> setOf(GTIMDomainV2740.IMMUNOLOGY, GTIMDomainV2740.OMICS_DATASET_HUNT)
        GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY -> GTIMDomainV2740.values().toSet()
    }

    private fun forbiddenConflationsFor(anchor: GTIMPrimaryAnchorV2740): Set<String> = when (anchor) {
        GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> setOf("allergy_type2_ige_mast_eosinophil", "pesticide_exposure", "longevity_immunosenescence", "generic_microbiome_bridge_without_query_support")
        GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> setOf("covid_interferon_cytokine_bridge", "ebola_hemorrhagic_viral_host_response", "hiv_retroviral_cd4_immune_depletion")
        GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> setOf("allergy_type2_ige_mast_eosinophil", "covid_interferon_cytokine_bridge", "generic_inflammation_only")
        GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> setOf("allergy_type2_ige_mast_eosinophil", "longevity_immunosenescence", "depression_neuroimmune_axis", "generic_microbiome_bridge")
        GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION -> setOf("allergy_type2_ige_mast_eosinophil", "covid_interferon_cytokine_bridge", "ebola_hemorrhagic_viral_host_response")
        GTIMPrimaryAnchorV2740.GENERAL_FEVER_SYNDROME -> setOf("single_disease_high_confidence_without_query_support")
        GTIMPrimaryAnchorV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE -> setOf("single_pathogen_lock_without_query_support")
        GTIMPrimaryAnchorV2740.DEPRESSION_NEUROIMMUNE,
        GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> setOf("ibd_barrier_mucosal_inflammation_axis", "ibd_only_identity_mutation", "generic_psychology_only", "allergy_type2_ige_mast_eosinophil")
        GTIMPrimaryAnchorV2740.ENDOCRINE_REPRODUCTIVE_DYSFUNCTION,
        GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE -> setOf("direct_yeast_causes_pcos_strong_claim_without_evidence", "covid_interferon_cytokine_bridge", "allergy_type2_ige_mast_eosinophil")
        GTIMPrimaryAnchorV2740.LONGEVITY_IMMUNOSENESCENCE -> setOf("covid_interferon_cytokine_bridge_without_query_support", "allergy_type2_ige_mast_eosinophil")
        GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE -> setOf("gut_microbiome_to_depression_identity_mutation", "allergy_type2_ige_mast_eosinophil", "covid_interferon_cytokine_bridge")
        GTIMPrimaryAnchorV2740.SLE_SYSTEMIC_AUTOIMMUNE -> setOf("allergy_type2_ige_mast_eosinophil", "single_infection_identity_mutation_without_evidence")
        GTIMPrimaryAnchorV2740.MS_NEUROIMMUNE_DEMYELINATION -> setOf("depression_neuroimmune_axis_without_query_support", "allergy_type2_ige_mast_eosinophil")
        GTIMPrimaryAnchorV2740.RA_SYNOVIAL_AUTOIMMUNE -> setOf("allergy_type2_ige_mast_eosinophil", "covid_interferon_cytokine_bridge")
        GTIMPrimaryAnchorV2740.PSORIASIS_IL23_IL17_SKIN -> setOf("allergy_type2_ige_mast_eosinophil", "ibd_identity_mutation_without_query_support")
        GTIMPrimaryAnchorV2740.T1D_AUTOIMMUNE_BETA_CELL -> setOf("generic_diabetes_type2_metabolic_only", "allergy_type2_ige_mast_eosinophil")
        GTIMPrimaryAnchorV2740.AUTOIMMUNE_INFLAMMATORY -> setOf("single_infection_identity_mutation_without_evidence")
        GTIMPrimaryAnchorV2740.CANCER_IMMUNE -> setOf("non_cancer_identity_mutation")
        GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY -> emptySet()
    }

    private fun blockedRoutesFor(anchor: GTIMPrimaryAnchorV2740, forbidden: Set<String>): Set<String> {
        if (anchor == GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY) return emptySet()
        return forbidden
    }

    private fun seedsFor(anchor: GTIMPrimaryAnchorV2740): Set<String> = buildSet {
        add(anchor.routeId)
        bridgesFor(anchor).mapTo(this) { it.routeId }
    }

    private fun benchmarkFor(anchor: GTIMPrimaryAnchorV2740): String? = when (anchor) {
        GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> "long_covid_interferon"
        GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> "allergy_type2_ige"
        GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> "hantavirus"
        GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> "ebola_hemorrhagic_viral_host_response"
        GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION -> "hiv_retroviral_cd4_immune_depletion"
        GTIMPrimaryAnchorV2740.GENERAL_FEVER_SYNDROME -> "general_fever_syndrome_differential"
        GTIMPrimaryAnchorV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE -> "outbreak_surveillance_pathogen_emergence"
        else -> anchor.routeId
    }

    private fun bridgeRationaleFor(anchor: GTIMPrimaryAnchorV2740): String = when (anchor) {
        GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> "Covid anchor is protected; bridges may explore interferon memory, microbiome disruption, neuroinflammation, and autoimmune-like persistence."
        GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> "Allergy anchor is protected; bridges may explore barrier immunity and microbiome/type-2 immune modulation."
        GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> "Hantavirus anchor is protected; bridges may explore zoonotic viral immune response and fever-like differential signals."
        GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> "Ebola anchor is protected; bridges may explore hemorrhagic viral host-response and outbreak signals."
        GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION -> "HIV anchor is protected; bridges may explore CD4 depletion, immune remodeling, and microbiome/immune interaction as secondary leads."
        GTIMPrimaryAnchorV2740.GENERAL_FEVER_SYNDROME -> "Fever is a syndrome, not a disease; bridge discovery must remain differential and avoid single-pathogen certainty."
        GTIMPrimaryAnchorV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE -> "Outbreak/epidemic is a surveillance frame; bridge discovery may scan pathogen emergence without locking to one disease."
        GTIMPrimaryAnchorV2740.DEPRESSION_NEUROIMMUNE,
        GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> "Depression/neuroimmune anchor is protected; bridges may explore microbiome metabolites, barrier leakage, vagus/HPA, and neuroinflammation."
        GTIMPrimaryAnchorV2740.ENDOCRINE_REPRODUCTIVE_DYSFUNCTION,
        GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE -> "Endocrine/reproductive anchor is protected; yeast/fungal bridges remain exploratory unless dataset-backed."
        GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE -> "IBD anchor is protected; gut/microbiome/barrier routes are allowed as IBD mechanisms, not depression identity mutations."
        GTIMPrimaryAnchorV2740.SLE_SYSTEMIC_AUTOIMMUNE -> "SLE anchor is protected; interferon/autoantibody/viral-trigger bridges remain autoimmune-contextual."
        GTIMPrimaryAnchorV2740.MS_NEUROIMMUNE_DEMYELINATION -> "MS anchor is protected; neuroinflammation/microbiome/viral triggers are bridges, not replacement diagnoses."
        GTIMPrimaryAnchorV2740.RA_SYNOVIAL_AUTOIMMUNE -> "RA anchor is protected; synovial inflammation/citrullination/autoantibody bridges stay RA-contextual."
        GTIMPrimaryAnchorV2740.PSORIASIS_IL23_IL17_SKIN -> "Psoriasis anchor is protected; IL-23/IL-17/skin barrier and IBD-like bridges are exploratory only."
        GTIMPrimaryAnchorV2740.T1D_AUTOIMMUNE_BETA_CELL -> "T1D anchor is protected; beta-cell autoimmunity and microbiome/metabolic bridges are exploratory unless dataset-backed."
        else -> "Bridge discovery is allowed, but claim strength follows evidence caps and provenance."
    }

    private fun autonomousContract(
        rawQuery: String,
        normalized: String,
        inputMode: GTIMInputModeV2740,
        hasDatasetAccessions: Boolean,
        matrixState: String?
    ): GTIMRunDecisionContractV2740 {
        val allBridges = GTIMDiscoveryBridgeV2740.values().toSet()
        val state = matrixState?.uppercase()?.trim()
        val caps = if (!hasDatasetAccessions && state == "DGE_NOT_READY_NO_ACCESSION") {
            GTIMEvidenceCapsV2740.weakNoAccession("autonomous discovery without accession-backed dataset")
        } else {
            GTIMEvidenceCapsV2740.exploratory("autonomous cross-domain exploration; each bridge must be labeled")
        }
        return GTIMRunDecisionContractV2740(
            rawQuery = rawQuery,
            normalizedQuery = normalized,
            inputMode = inputMode,
            runMode = GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION,
            primaryAnchor = GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY,
            diseaseFamily = GTIMDiseaseFamilyV2740.UNKNOWN_AUTONOMOUS_DISCOVERY,
            anchorConfidence = 50,
            anchorReason = "Autonomous discovery mode: no fixed user anchor; broad relationship discovery allowed.",
            anchorMustNotMutate = false,
            secondaryDomains = GTIMDomainV2740.values().toSet(),
            discoveryBridges = allBridges,
            exploratoryRoutes = allBridges.map { it.routeId }.toSet(),
            allowedRoutes = allBridges.map { it.routeId }.toSet() + GTIMPrimaryAnchorV2740.values().map { it.routeId },
            blockedRoutes = emptySet(),
            allowedSeeds = allBridges.map { it.routeId }.toSet() + GTIMPrimaryAnchorV2740.values().map { it.routeId },
            blockedSeeds = emptySet(),
            benchmarkTopic = "autonomous_cross_domain_discovery",
            forbiddenIdentityMutations = emptySet(),
            forbiddenConflations = emptySet(),
            evidenceCaps = caps,
            claimMode = GTIMClaimModeV2740.AUTONOMOUS_EXPLORATORY_HYPOTHESIS,
            bridgeRationale = "Autonomous mode may connect distant microbiome/immune/endocrine/neuro/infection/metabolic signals freely, but must label evidence status, confidence, and provenance.",
            reason = "Free exploration contract: no fixed anchor, no strong causal claims without evidence."
        )
    }
}
