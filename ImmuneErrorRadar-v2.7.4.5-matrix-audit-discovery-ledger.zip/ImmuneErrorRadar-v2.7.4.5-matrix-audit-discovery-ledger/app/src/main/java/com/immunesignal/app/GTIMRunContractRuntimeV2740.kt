package com.immunesignal.app

/**
 * v2.7.4.1 connector facade.
 *
 * This file exists to make the contract easy to wire into large legacy classes without
 * changing every method signature at once. The preferred path is explicit parameter passing;
 * this runtime holder is the safe transitional path for ResearchAutopilot -> routers -> brief.
 */
object GTIMRunContractRuntimeV2740 {
    private val activeContract = ThreadLocal<GTIMRunDecisionContractV2740?>()

    fun beginRun(
        rawQuery: String,
        inputMode: GTIMInputModeV2740 = if (rawQuery.isBlank()) {
            GTIMInputModeV2740.AUTONOMOUS_DISCOVERY
        } else {
            GTIMInputModeV2740.USER_QUERY
        },
        accessionCount: Int = 0,
        matrixState: String? = null
    ): GTIMRunDecisionContractV2740 {
        val contract = if (inputMode == GTIMInputModeV2740.AUTONOMOUS_DISCOVERY && rawQuery.isNotBlank()) {
            GTIMRunDecisionContractFactoryV2740.buildAutonomousSelectedTopic(
                rawQuery = rawQuery,
                hasDatasetAccessions = accessionCount > 0,
                matrixState = matrixState
            )
        } else {
            GTIMRunDecisionContractFactoryV2740.build(
                rawQuery = rawQuery,
                inputMode = inputMode,
                hasDatasetAccessions = accessionCount > 0,
                matrixState = matrixState
            )
        }
        activeContract.set(contract)
        return contract
    }

    fun bind(contract: GTIMRunDecisionContractV2740) {
        activeContract.set(contract)
    }

    fun current(): GTIMRunDecisionContractV2740? = activeContract.get()

    fun currentOrBuild(
        rawQuery: String,
        inputMode: GTIMInputModeV2740 = GTIMInputModeV2740.USER_QUERY,
        accessionCount: Int = 0,
        matrixState: String? = null
    ): GTIMRunDecisionContractV2740 {
        val existing = activeContract.get()
        if (existing != null) return existing
        return beginRun(rawQuery, inputMode, accessionCount, matrixState)
    }

    fun clear() {
        activeContract.remove()
    }

    fun filterRouteIds(
        candidateRouteIds: List<String>,
        sourceLayer: String,
        reason: String = "legacy route candidate"
    ): List<String> {
        val contract = current() ?: return candidateRouteIds.distinct()
        val candidates = candidateRouteIds.distinct().map {
            GTIMRouteGovernanceV2740.RouteCandidate(
                routeId = it,
                candidateAnchor = anchorFromRouteId(it),
                sourceLayer = sourceLayer,
                reason = reason
            )
        }
        return GTIMDownstreamContractAdaptersV2740
            .selectRoutesFromContract(contract, candidates)
            .filter { it.allowed }
            .map { it.routeId }
            .distinct()
    }

    fun filterSeedIds(proposedSeedIds: List<String>): List<String> {
        val contract = current() ?: return proposedSeedIds.distinct()
        return GTIMDownstreamContractAdaptersV2740.selectSeedsFromContract(contract, proposedSeedIds)
    }

    fun filterQueryTexts(proposedQueries: List<String>): List<String> {
        val contract = current() ?: return proposedQueries.filter { it.isNotBlank() }.distinct()
        return GTIMDownstreamContractAdaptersV2740.filterQueryTextWithContract(contract, proposedQueries)
    }

    fun capScores(rawDataQuality: Int, rawEvidenceStrength: Int, rawRouteConfidence: Int): Triple<Int, Int, Int> {
        val contract = current() ?: return Triple(
            rawDataQuality.coerceIn(0, 100),
            rawEvidenceStrength.coerceIn(0, 100),
            rawRouteConfidence.coerceIn(0, 100)
        )
        return GTIMDownstreamContractAdaptersV2740.applyScoreCaps(
            contract,
            rawDataQuality,
            rawEvidenceStrength,
            rawRouteConfidence
        )
    }

    fun benchmarkTopicOr(defaultTopic: String): String {
        val contract = current() ?: return defaultTopic
        return GTIMDownstreamContractAdaptersV2740.benchmarkFromContract(contract)
    }

    fun summaryOrEmpty(): String = current()?.let { GTIMDownstreamContractAdaptersV2740.uiSummary(it) } ?: ""

    private fun anchorFromRouteId(routeId: String): GTIMPrimaryAnchorV2740? {
        return GTIMPrimaryAnchorV2740.values().firstOrNull { it.routeId == routeId }
    }
}
