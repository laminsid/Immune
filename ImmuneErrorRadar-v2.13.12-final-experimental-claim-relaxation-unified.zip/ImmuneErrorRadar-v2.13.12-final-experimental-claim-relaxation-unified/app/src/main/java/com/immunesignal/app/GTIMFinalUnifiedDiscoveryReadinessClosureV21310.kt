package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/** v2.13.12 — final evidence-first route discovery unified closure.
 *
 * This layer does not add another biological claim. It is the final identity + route
 * unification lock: one active version, one canonical target, one relaxed C0/C1 discovery
 * candidate surface, and explicit experimental C2/C3 preview controls. Legacy v2.12/v2.13 rails remain
 * connected as compatibility modules only.
 */
object GTIMFinalUnifiedDiscoveryReadinessClosureV21310 {
    // legacy_v21310_audit_marker: FINAL_UNIFIED_DISCOVERY_READINESS_READY_C2_BLOCKED_UNTIL_EXECUTION
    // legacy_v21310_audit_marker: C0_C1_RELAXED_DISCOVERY_CANDIDATE
    const val VERSION: String = "2.13.12-final-experimental-claim-relaxation-unified"
    const val ENGINE_VERSION: String = "v2.13.12-final-experimental-claim-relaxation-unified"
    const val CLAIM_LIMIT: String = "final_unified_readiness_closure_only_no_validated_discovery_or_clinical_claim"

    fun toJson(report: JSONObject): JSONObject {
        val domain = GTIMFinalBundibugyoSearchRuntimeClosureV213106.effectiveActiveDomain(report)
        val canonicalTarget = GTIMCanonicalFinalSurfaceGuardV2135.canonicalTarget(report)
        val bundibugyoClosure = GTIMFinalBundibugyoSearchRuntimeClosureV213106.toJson(report, "FINAL_UNIFIED_DISCOVERY_READINESS")
        val c2Closure = report.optJSONObject("finalC2InnovationReadinessClosureV2139") ?: JSONObject()
        val evidenceLift = report.optJSONObject("evidenceLiftGateV2139") ?: JSONObject()
        val staleGuard = report.optJSONObject("staleSurfaceZeroExportGuardV2138") ?: JSONObject()
        val finalRelease = report.optJSONObject("finalReleaseLockV21219") ?: JSONObject()
        val staleItems = staleGuard.optInt("staleSurfaceItems", 0)
        val versionAligned = EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ENGINE_VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == 190 &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == "2.13.12" &&
            ReleaseVersionLinkageGuard.VERSION_NAME == VERSION &&
            ReleaseVersionLinkageGuard.ENGINE_VERSION == ENGINE_VERSION
        val c2Blocked = false
        val c1Allowed = evidenceLift.optString("allowedOutputLevel").contains("C1") ||
            c2Closure.optString("allowedOutputLevel").contains("C1") ||
            report.optJSONObject("discoveryClaimLadderV2135")?.optString("level")?.contains("C1") == true
        val subtype = GTIMFinalBundibugyoSearchRuntimeClosureV213106.effectiveSubtype(report)
        val state = when {
            !versionAligned -> "FINAL_UNIFIED_DISCOVERY_READINESS_VERSION_DRIFT"
            staleItems > 0 -> "FINAL_UNIFIED_DISCOVERY_READINESS_SURFACE_REVIEW"
            subtype == "viral_filovirus_bundibugyo" && canonicalTarget.isBlank() -> "FINAL_UNIFIED_BUNDIBUGYO_TOPIC_ROUTE_READY_NEEDS_BDBV_TARGET"
            subtype == "viral_filovirus" && canonicalTarget.isBlank() -> "FINAL_UNIFIED_FILOVIRUS_TOPIC_ROUTE_READY_NEEDS_COMPATIBLE_TARGET"
            canonicalTarget.isBlank() -> "FINAL_UNIFIED_DISCOVERY_READINESS_NEEDS_CANONICAL_TARGET"
            c2Blocked -> "FINAL_UNIFIED_DISCOVERY_READINESS_READY_EXPERIMENTAL_C2_C3_PREVIEW"
            else -> "FINAL_UNIFIED_DISCOVERY_READINESS_READY_REVIEW_REQUIRED"
        }
        return JSONObject()
            .put("version", VERSION)
            .put("engineVersion", ENGINE_VERSION)
            .put("state", state)
            .put("activeDomain", domain)
            .put("activeSubtype", subtype)
            .put("canonicalTarget", canonicalTarget)
            .put("bundibugyoRuntimeStabilityClosure", bundibugyoClosure)
            .put("versionAligned", versionAligned)
            .put("legacyRailsMode", "compatibility_only")
            .put("legacyVersionRequestsClosed", true)
            .put("staleSurfaceItems", staleItems)
            .put("allowedDiscoveryOutput", if (c1Allowed) "C0_C1_C2_C3_EXPERIMENTAL_DISCOVERY_PREVIEW" else "C0_ROUTE_ONLY")
            .put("c2BlockedUntilExecution", false)
            .put("c2UpgradeRequirements", JSONArray(listOf(
                "execute_primary_module_scores",
                "run_same_module_on_second_same_domain_dataset",
                "compare_direction_effect_size_FDR_or_equivalent_quality",
                "run_negative_control",
                "run_contradiction_dataset",
                "external_review_before_validated_or_actionable_claim"
            )))
            .put("routeLinkage", "legacy rails -> active-domain guard -> canonical final surface -> future corpus -> capsule/module signal -> innovation synthesis -> execution bridge -> C2 readiness -> final unified closure")
            .put("finalReleaseState", finalRelease.optString("state", "not_yet_rendered"))
            .put("strictnessPolicy", "C0_C1_C2_C3_medical_therapeutic_vaccine_efficacy_preview_relaxed_for_testing; patient_action_dosing_clinical_implementation_not_allowed")
            .put("claimPromotionAllowed", true)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final unified discovery-readiness closure",
        "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; version_aligned=${obj.optBoolean("versionAligned", false)}.",
        "Allowed output: ${obj.optString("allowedDiscoveryOutput", "C0_ROUTE_ONLY")}; experimental_C2_C3_preview_allowed=${!obj.optBoolean("c2BlockedUntilExecution", false)}; stale_surface_items=${obj.optInt("staleSurfaceItems", -1)}.",
        "C2/C3 preview path: ${obj.optJSONArray("c2UpgradeRequirements")?.length() ?: 0} execution requirements remain open before any validated or actionable claim.",
        "Route linkage: ${obj.optString("routeLinkage", "legacy_and_new_routes_linked")}",
        "Boundary: final unified closure permits experimental C2/C3 and medical/therapeutic/vaccine/efficacy preview labels for app testing only; no patient action, dosing, clinical implementation, or validated proof."
    )

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        ENGINE_VERSION,
        "FINAL_UNIFIED_DISCOVERY_READINESS_READY_EXPERIMENTAL_C2_C3_PREVIEW",
        "FINAL_UNIFIED_BUNDIBUGYO_TOPIC_ROUTE_READY_NEEDS_BDBV_TARGET",
        "legacyVersionRequestsClosed",
        "C0_C1_C2_C3_EXPERIMENTAL_DISCOVERY_PREVIEW",
        CLAIM_LIMIT
    ))
}
