package com.immunesignal.app

import org.json.JSONObject

object GTIMFinalEvidenceFirstRouteDiscoveryClosureV21311 {
    const val VERSION: String = "2.13.12-final-experimental-claim-relaxation-unified"
    const val ENGINE_VERSION: String = "v2.13.12-final-experimental-claim-relaxation-unified"

    fun toJson(report: JSONObject): JSONObject {
        val intent = GTIMRouteConfidenceGateV21311.infer(report)
        val canonical = GTIMCanonicalTargetAfterRouteLockV21311.canonicalTarget(report)
        val fallback = GTIMUnknownTopicSafeFallbackV21311.toJson(report)
        val memory = GTIMRouteLearningMemoryV21311.toJson(report)
        val versionAligned = EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ENGINE_VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == VERSION &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == "2.13.12"
        return JSONObject()
            .put("version", VERSION)
            .put("engineVersion", ENGINE_VERSION)
            .put("state", if (intent.locked) "FINAL_EVIDENCE_FIRST_ROUTE_DISCOVERY_READY" else "FINAL_TOPIC_LEVEL_DISCOVERY_ROUTE_NEEDS_EVIDENCE")
            .put("locked", intent.locked)
            .put("activeDomain", intent.lockedRoute)
            .put("activeSubtype", intent.lockedSubtype)
            .put("canonicalTarget", canonical)
            .put("confidence", intent.confidence)
            .put("routeExplanation", intent.explanation)
            .put("versionAligned", versionAligned)
            .put("unknownTopicFallback", fallback)
            .put("routeLearningMemory", memory)
            .put("routeLinkage", "legacy rails -> evidence-first entity/handle search -> route ranking -> confidence gate -> canonical target after route lock -> old active-domain/canonical/matrix/final locks")
            .put("policy", "do not add one-off rules for every misunderstood question; search/extract/rank route evidence first, then select only compatible targets")
            .put("strictness", "C0/C1/C2/C3 experimental route and discovery-preview generation relaxed; wrong-route targets remain strict; patient action/dosing/clinical implementation not allowed")
            .put("claimLimit", GTIMResearchIntentObjectContractV21311.CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> = listOf(
        "Final evidence-first route discovery closure",
        "State: ${obj.optString("state", "UNKNOWN")}; active_domain=${obj.optString("activeDomain", "unknown")}; subtype=${obj.optString("activeSubtype", "unknown")}; canonical_target=${obj.optString("canonicalTarget", "none")}; confidence=${obj.optDouble("confidence", 0.0)}.",
        "Route explanation: ${obj.optString("routeExplanation", "route evidence not available")}",
        "Policy: ${obj.optString("policy", "route evidence before dataset selection")}",
        "Strictness: ${obj.optString("strictness", "C0/C1 relaxed; validated/actionable claims guarded")}",
        "Boundary: route discovery and target selection can emit experimental preview labels only; no patient action, dosing, clinical implementation, or validated proof."
    )
}
