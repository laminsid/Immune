package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DatasetFirstForagerV140Test {
    @Test
    fun decomposesBroadMissionIntoTestableShards() {
        val shards = HypothesisDecomposer.decompose("Which public datasets can map trigger-response-outcome immune patterns?")
        assertTrue(shards.size >= 3)
        assertTrue(shards.any { it.shardId.contains("ALLERGY") })
        assertTrue(shards.all { it.evidenceQuestion.contains("Mission context") })
    }

    @Test
    fun datasetFirstRouterActivatesAfterNoDatasetFailure() {
        val recent = listOf("NO_DATASET_ACCESSION NO_EVIDENCE_OBJECT_NO_UPGRADE dataset candidates: 0")
        val active = DirectDatasetSourceRouter.shouldRunDatasetFirst(
            recentReports = recent,
            researchState = "RESEARCH_NORMAL",
            appliedPivot = PivotDecision.none(),
            memory = PersistentFailureMemorySnapshot.empty()
        )
        assertTrue(active)
    }


    @Test
    fun datasetFirstRouterNormalizesStateAndEvidenceFirstIntent() {
        val byState = DirectDatasetSourceRouter.shouldRunDatasetFirst(
            recentReports = emptyList(),
            researchState = " dataset_hunt ",
            appliedPivot = PivotDecision.none(),
            memory = PersistentFailureMemorySnapshot.empty()
        )
        val byEvidenceFirstIntent = DirectDatasetSourceRouter.shouldRunDatasetFirst(
            recentReports = listOf("EVIDENCE_FIRST_ACCESSION_SEARCH selected by dataset-hunt unlock"),
            researchState = "research_normal",
            appliedPivot = PivotDecision.none(),
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertTrue(byState)
        assertTrue(byEvidenceFirstIntent)
    }

    @Test
    fun routerKeepsCooldownEscapeWhenAllDirectFamiliesAreCoolingDown() {
        val memory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord("h1", "GEO_GDS", "NO_DATASET_ACCESSION", 2, 1L, 3, "GEO_GDS"),
                PersistentFailureRecord("h2", "SRA_PRJNA", "WRONG_VOCABULARY", 2, 1L, 3, "SRA_PRJNA"),
                PersistentFailureRecord("h3", "PUBMED_CONTRADICTION", "NO_CONTRADICTION_SEARCH", 2, 1L, 3, "PUBMED_CONTRADICTION"),
                PersistentFailureRecord("h4", "PUBMED_CONTROL", "NO_CONTROL_SIGNAL", 2, 1L, 3, "PUBMED_CONTROL")
            ),
            summary = "all direct routes are cooling down"
        )

        val routes = DirectDatasetSourceRouter.routes(memory)

        assertEquals(listOf("GEO_GDS_COOLDOWN_ESCAPE"), routes.map { it.sourceFamily })
    }

    @Test
    fun compilerCreatesNarrowDatasetQueries() {
        val queries = DatasetQueryCompiler.compile(
            HypothesisDecomposer.decompose("baseline mission"),
            PersistentFailureMemorySnapshot.empty()
        )
        assertTrue(queries.isNotEmpty())
        assertTrue(queries.any { it.query.contains("GSE") || it.query.contains("RNA-seq") || it.query.contains("single-cell") })
        assertTrue(queries.none { it.label.contains("daily", ignoreCase = true) })
    }



    @Test
    fun compilerFallsBackToAccessionQueriesWhenNoShardSeedsSurvive() {
        val memory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord(
                    failedQueryHash = "h0",
                    sourceFamily = "broad_pubmed_mapping",
                    rootCause = "NO_DATASET_ACCESSION",
                    cooldownCyclesRemaining = 2,
                    lastAttemptedAtMillis = 1L,
                    timesFailed = 3,
                    forcedNextSource = "GEO_GDS"
                )
            ),
            summary = "force dataset fallback"
        )
        val queries = DatasetQueryCompiler.compile(
            shards = emptyList(),
            memory = memory
        )

        assertTrue(queries.isNotEmpty())
        assertTrue(queries.all { it.id.startsWith("q_v142_fallback_dataset_accession_") })
        assertTrue(queries.any { it.query.contains("GSE") || it.query.contains("PRJNA") || it.query.contains("SRA") })
        assertTrue(queries.all { it.query.contains("outcome", ignoreCase = true) || it.query.contains("severity", ignoreCase = true) })
    }



    @Test
    fun compilerBuildsSourceAwareQueriesForGeoAndSraRoutes() {
        val shards = HypothesisDecomposer.decompose("trigger response outcome immune mapping")
        val geoQueries = DatasetQueryCompiler.compileForRoute(
            route = DirectDatasetSourceRouter.SourceRoute(
                sourceFamily = "GEO_GDS",
                ncbiDb = "gds",
                priority = 100,
                reason = "test GEO"
            ),
            shards = shards,
            memory = PersistentFailureMemorySnapshot.empty()
        )
        val sraQueries = DatasetQueryCompiler.compileForRoute(
            route = DirectDatasetSourceRouter.SourceRoute(
                sourceFamily = "SRA_PRJNA",
                ncbiDb = "sra",
                priority = 90,
                reason = "test SRA"
            ),
            shards = shards,
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertTrue(geoQueries.isNotEmpty())
        assertTrue(sraQueries.isNotEmpty())
        assertTrue(geoQueries.any { it.query.contains("GSE") || it.query.contains("GDS") || it.query.contains("GEO") })
        assertTrue(sraQueries.any { it.query.contains("PRJNA") || it.query.contains("SRP") || it.query.contains("SRA") })
        assertTrue(geoQueries.all { it.id.startsWith("q_v142_geo_gds_") })
        assertTrue(sraQueries.all { it.id.startsWith("q_v142_sra_prjna_") })
    }

    @Test
    fun compilerBuildsContradictionAndControlQueriesForPubMedRoutes() {
        val shards = HypothesisDecomposer.decompose("trigger response outcome immune mapping")
        val contradictionQueries = DatasetQueryCompiler.compileForRoute(
            route = DirectDatasetSourceRouter.SourceRoute(
                sourceFamily = "PUBMED_CONTRADICTION",
                ncbiDb = "pubmed",
                priority = 60,
                reason = "test contradiction"
            ),
            shards = shards,
            memory = PersistentFailureMemorySnapshot.empty()
        )
        val controlQueries = DatasetQueryCompiler.compileForRoute(
            route = DirectDatasetSourceRouter.SourceRoute(
                sourceFamily = "PUBMED_CONTROL",
                ncbiDb = "pubmed",
                priority = 55,
                reason = "test control"
            ),
            shards = shards,
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertTrue(contradictionQueries.any { it.query.contains("nonresponse", ignoreCase = true) || it.query.contains("failed replication", ignoreCase = true) })
        assertTrue(controlQueries.any { it.query.contains("control", ignoreCase = true) || it.query.contains("comparator", ignoreCase = true) })
    }

    @Test
    fun foragingReportDefaultsAreSafe() {
        val report = DatasetForagingReport.empty()
        assertEquals("NOT_RUN", report.state)
        assertEquals(false, report.active)
    }
}
