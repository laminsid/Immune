#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app/src/main/java/com/immunesignal/app'
TEST = ROOT / 'app/src/test/java/com/immunesignal/app'

required_files = [
    APP / 'DatasetHuntSearchUnlockPolicy.kt',
    TEST / 'DatasetHuntSearchUnlockPolicyTest.kt',
    TEST / 'LinkedCognitionSpineEvidenceFirstTest.kt',
    TEST / 'DatasetAccessionResolverV1108Test.kt',
]
missing = [str(p.relative_to(ROOT)) for p in required_files if not p.exists()]
if missing:
    raise SystemExit('Missing v1.10.8 dataset-hunt unlock files: ' + ', '.join(missing))

policy = (APP / 'DatasetHuntSearchUnlockPolicy.kt').read_text()
for needle in [
    'EVIDENCE_FIRST',
    'allowDatasetAccessionSearch',
    'no EvidenceObject/DatasetCandidate/Accession',
    'claim_upgrade_still_blocked',
    'normalizedState',
    'memoryRequestsDatasetEvidence',
    'evidencePresentPatterns',
    'blocked_by_existing_evidence',
]:
    if needle not in policy:
        raise SystemExit(f'Dataset unlock policy missing {needle!r}')

autopilot = (APP / 'ResearchAutopilot.kt').read_text()
for needle in [
    'DatasetHuntSearchUnlockPolicy.evaluate(',
    'datasetHuntUnlockDecisionV108.allowDatasetAccessionSearch',
    'evidenceFirstDirectiveRequestsDatasetV108',
    'routerRequestsDatasetFirstV108',
    'recentReports + listOf(priorSearchDirectiveV203.mode, priorSearchDirectiveV203.reason)',
    'EVIDENCE_FIRST_FORAGER_EXECUTED',
    'datasetFirstUnlockApplied = evidenceFirstForagerExecutedV108',
    'evidenceFirstForagerExecutedV108',
    'evidenceFirstBudget = evidenceFirstForagerModeV108',
    'dataset_hunt_unlock:evidence_first_forager_consumed_same_cycle_budget',
    'v1.10.8 dataset-hunt unlock:',
]:
    if needle not in autopilot:
        raise SystemExit(f'ResearchAutopilot missing dataset-hunt unlock wiring token {needle!r}')

resolver = (APP / 'ResearchSearchDirectiveResolver.kt').read_text()
for needle in [
    'EVIDENCE_FIRST_ACCESSION_SEARCH',
    'blockDatasetFirst = !evidenceFirst',
    'minOf(10, baseResultsPerQuery)',
]:
    if needle not in resolver:
        raise SystemExit(f'ResearchSearchDirectiveResolver missing evidence-first token {needle!r}')

phase = (APP / 'ResearchCyclePhaseAudit.kt').read_text()
for needle in [
    'datasetFirstUnlockApplied',
    'EVIDENCE_FIRST_DATASET_UNLOCK',
    '!datasetFirstUnlockApplied',
]:
    if needle not in phase:
        raise SystemExit(f'Cycle phase audit missing unlock-aware lock token {needle!r}')

plan = (APP / 'ResearchCyclePlanStage.kt').read_text()
for needle in [
    'return directive.queries.take(directive.maxQueries)',
    'No query leaves PLAN',
]:
    if needle not in plan:
        raise SystemExit(f'Plan stage missing directive-query fallback token {needle!r}')

activity = (APP / 'ResearchAutopilotActivity.kt').read_text()
compiler = (APP / 'DatasetQueryCompiler.kt').read_text()
exporter = (APP / 'DiscoveryReportExporter.kt').read_text()
router = (APP / 'DirectDatasetSourceRouter.kt').read_text()
test = (TEST / 'DatasetFirstForagerV140Test.kt').read_text()
if 'Effective search:' in activity or 'Effective search:' in exporter:
    raise SystemExit('Report UI/exporter must not claim Effective search when zero queries may have executed')
if 'normalizedState = researchState.trim().uppercase(Locale.US)' not in router:
    raise SystemExit('DirectDatasetSourceRouter must normalize researchState before DATASET_HUNT checks')
if 'evidence_first' not in router or 'accession_search' not in router:
    raise SystemExit('DirectDatasetSourceRouter must treat evidence-first accession intent as dataset-first runnable')
if 'datasetFirstRouterNormalizesStateAndEvidenceFirstIntent' not in test:
    raise SystemExit('Missing router normalization/evidence-first regression test')
if 'routerKeepsCooldownEscapeWhenAllDirectFamiliesAreCoolingDown' not in test:
    raise SystemExit('Missing cooldown escape regression test')
if "dataset-first unlock-aware lock wiring" not in (ROOT / 'scripts' / 'audit_search_directive_spine_v1103.py').read_text():
    raise SystemExit('Search directive spine audit still expects the obsolete pre-v1.10.8 dataset-first lock token')
for needle in [
    'searchExecutionLine(report, runtime)',
    'Search executed: 0 | planned:',
    'NOT_EXECUTED_OR_BLOCKED',
]:
    if needle not in activity:
        raise SystemExit(f'Report preview/full UI missing execution-consistency token {needle!r}')
for needle in [
    'Search executed: 0',
    'Planned budget:',
    'Direct sources attempted:',
]:
    if needle not in exporter:
        raise SystemExit(f'PDF exporter missing execution-consistency token {needle!r}')

unlock_test = (TEST / 'DatasetHuntSearchUnlockPolicyTest.kt').read_text()
for needle in [
    'unlocksDatasetHuntWhenCognitiveLockHasNoEvidenceObject',
    'doesNotOverrideExplicitEvidenceClosureLock',
    'unlocksFromPersistentNoDatasetMemoryEvenWhenReportTextIsSparse',
    'doesNotUnlockWhenDirectiveAlreadyTargetsExplicitAccession',
    'doesNotUnlockWhenDatasetEvidenceAlreadyExistsButMetadataIsIncomplete',
    'evidenceFirstIntentStillUnlocksWhenCountsAreExplicitlyZero',
]:
    if needle not in unlock_test:
        raise SystemExit(f'Dataset unlock regression test missing {needle!r}')

resolver_test = (TEST / 'ResearchSearchDirectiveResolverTest.kt').read_text()
for needle in [
    'evidenceFirstLinkedSpineAllowsDatasetFirstWithBoundedRetmax',
    'assertFalse(directive.blockDatasetFirst)',
    'assertEquals(10, directive.maxResultsPerQuery)',
]:
    if needle not in resolver_test:
        raise SystemExit(f'ResearchSearchDirectiveResolver regression test missing {needle!r}')

phase_test = (TEST / 'ResearchCyclePhaseAuditTest.kt').read_text()
for needle in [
    'allowsDatasetFirstWhenDatasetHuntUnlockApplied',
    'datasetFirstUnlockApplied = true',
    'EVIDENCE_FIRST_DATASET_UNLOCK',
]:
    if needle not in phase_test:
        raise SystemExit(f'ResearchCyclePhaseAudit regression test missing {needle!r}')


linked_spine = (APP / 'LinkedCognitionSpine.kt').read_text()
for needle in [
    'needsFirstEvidence -> "EVIDENCE_FIRST: run one bounded accession search before thinking; claims remain locked."',
    'MAX_1_ACCESSION_QUERY_RETMAX_10',
    'EVIDENCE_FIRST_ACCESSION_SEARCH',
]:
    if needle not in linked_spine:
        raise SystemExit(f'Linked cognition spine missing evidence-first token {needle!r}')

linked_test = (TEST / 'LinkedCognitionSpineEvidenceFirstTest.kt').read_text()
for needle in [
    'partialSpineWithNoEvidenceChoosesEvidenceFirstBeforeThinkFirst',
    'priorDirectiveKeepsEvidenceFirstModeAndQueryBudget',
    'EVIDENCE_FIRST_ACCESSION_SEARCH',
]:
    if needle not in linked_test:
        raise SystemExit(f'Linked cognition spine evidence-first regression test missing {needle!r}')



for needle in [
    'fallbackEvidenceQueries',
    'q_v142_fallback_dataset_accession_',
    'DATASET_HUNT must always emit at least one accession-oriented evidence query',
    'compileForRoute(',
    'geoAccessionQueries',
    'sraAccessionQueries',
    'pubmedContradictionQueries',
    'Source-aware dataset accession query'
]:
    if needle not in compiler:
        raise SystemExit(f'DatasetQueryCompiler source-aware/fallback guard missing: {needle}')

for needle in [
    'DatasetQueryCompiler.compileForRoute(route, shards, memory)',
    'val routeBudget = if (evidenceFirstBudget) 2 else 4',
    'val perRouteQueryBudget = if (evidenceFirstBudget) 1 else -1',
    '.take(if (perRouteQueryBudget > 0) perRouteQueryBudget else if (route.ncbiDb == "pubmed") 2 else 3)'
]:
    if needle not in autopilot:
        raise SystemExit(f'ResearchAutopilot must use source-aware DatasetQueryCompiler route queries: {needle}')

for needle in [
    'compilerFallsBackToAccessionQueriesWhenNoShardSeedsSurvive',
    'compilerBuildsSourceAwareQueriesForGeoAndSraRoutes',
    'compilerBuildsContradictionAndControlQueriesForPubMedRoutes'
]:
    if needle not in test:
        raise SystemExit(f'Dataset-first forager test must cover query compiler guard: {needle}')


accession_resolver = (APP / 'DatasetAccessionResolver.kt').read_text()
resolver_v1108_test = (TEST / 'DatasetAccessionResolverV1108Test.kt').read_text()
for needle in [
    'SRR\\d+',
    'ERR\\d+',
    'DRR\\d+',
    'accession.startsWith("SRR")',
    'accession.startsWith("ERR")',
    'accession.startsWith("DRR")',
]:
    if needle not in accession_resolver:
        raise SystemExit(f'DatasetAccessionResolver missing direct SRA/EGA run accession support: {needle!r}')
for needle in [
    'extractsSraRunAndEuropeanRunAccessions',
    'keepsGeoAndGdsAccessionsExplicit',
    'SRR987654',
    'ERR765432',
    'DRR543210',
]:
    if needle not in resolver_v1108_test:
        raise SystemExit(f'DatasetAccessionResolver regression test missing {needle!r}')
for needle in [
    'resolveDatasetAccessionFromDoc(',
    'study_acc',
    'run_acc',
    'route.ncbiDb == "gds" && uid.all { it.isDigit() } -> "GDS$uid"',
    'route.ncbiDb == "sra"',
]:
    if needle not in autopilot:
        raise SystemExit(f'ResearchAutopilot missing normalized direct-NCBI accession extraction token: {needle!r}')

if 'Search executed: 0; planned budget' not in autopilot:
    raise SystemExit('ResearchAutopilot learning notes must separate executed search from planned budget')


# v1.10.8 final hardening: never synthesize fake SRA<uid> from numeric Entrez UID.
if '"SRA$uid"' in autopilot or 'SRA$' + 'uid' in autopilot:
    raise SystemExit('SRA numeric UID must not be synthesized into a fake accession')
if 'DATASET_ACCESSION_UNRESOLVED' not in autopilot:
    raise SystemExit('ResearchAutopilot missing SRA numeric UID unresolved fallback')
if 'numericSraUidIsNotPromotedIntoFakeAccession' not in resolver_v1108_test:
    raise SystemExit('DatasetAccessionResolver regression test missing numeric SRA UID guard')

print('dataset hunt unlock/report consistency v1.10.8 audit: PASS')
