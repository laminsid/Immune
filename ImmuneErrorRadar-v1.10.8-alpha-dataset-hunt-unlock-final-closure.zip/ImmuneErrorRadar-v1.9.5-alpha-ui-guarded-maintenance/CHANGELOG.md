
## v1.10.8-alpha-dataset-hunt-unlock — Maintenance10

- Added strict evidence-first query budgeting to dataset-first foraging.
- Capped evidence-first forager runs to 2 source families and 1 query per route.
- Consumed the same-cycle evidence-first search directive after the bounded forager executes, preventing duplicate same-cycle network search.
- Extended v1.10.8 audit coverage for evidence-first budget enforcement.


## v1.10.8-alpha-dataset-hunt-unlock — Maintenance9

- Hardened direct NCBI dataset accession normalization for GEO/GDS and SRA routes.
- Added SRR/ERR/DRR support to `DatasetAccessionResolver`.
- Added regression coverage for SRA run accessions and GEO/GDS extraction.
- Extended v1.10.8 audit to guard direct-NCBI accession extraction and avoid numeric UID-only candidates.

## v1.10.8-alpha-dataset-hunt-unlock-maintenance8

- Added source-aware dataset query compilation for GEO/GDS, SRA/PRJNA, PubMed contradiction, and PubMed control routes.
- Wired `ResearchAutopilot.runDatasetFirstForaging` to use `DatasetQueryCompiler.compileForRoute(route, shards, memory)` per source family.
- Hardened evidence-first routing so prior directive mode/reason is passed into `DirectDatasetSourceRouter`, preventing sparse report text from losing `EVIDENCE_FIRST_ACCESSION_SEARCH`.
- Added regression tests for source-aware compiler behavior and updated the v1.10.8 audit.

## v1.10.8-alpha-dataset-hunt-unlock-maintenance7

- Hardened `DatasetQueryCompiler` with accession-oriented fallback queries when shard compilation yields no usable query.
- Updated learning notes to show `Search executed` versus planned budget instead of implying execution from the plan.
- Added regression coverage for empty-shard dataset query fallback.
- Strengthened v1.10.8 dataset-hunt unlock audit to prevent zero-query forager regressions.
## 1.10.8-alpha-dataset-hunt-unlock — maintenance pass 6

- Tightened `DatasetHuntSearchUnlockPolicy` so missing metadata/outcome fields cannot trigger a new accession hunt when dataset candidates or evidence objects already exist.
- Added an evidence-present guard for non-zero dataset/evidence/accession counts.
- Added regression tests proving evidence-first still unlocks when counts are zero, but not when existing evidence needs closure/inspection.
- Updated the v1.10.8 audit to prevent this safety regression from returning.

## 1.10.8-alpha-dataset-hunt-unlock — maintenance pass 5

- Unified the Research command board with the execution-consistency helper so zero-query cycles are explicitly labeled `NOT_EXECUTED_OR_BLOCKED`.
- Added `LinkedCognitionSpineEvidenceFirstTest` to lock the no-evidence spine behavior: `EVIDENCE_FIRST` must win over `THINK_FIRST` when the only safe next move is bounded accession search.
- Hardened the v1.10.8 audit to guard the linked-spine evidence-first path and prevent report wording regressions.

## 1.10.8-alpha-dataset-hunt-unlock — maintenance pass 4

- Fixed stale static audit expectation in `audit_search_directive_spine_v1103.py` after v1.10.8 replaced the old pre-unlock dataset-first lock condition.
- Hardened `DirectDatasetSourceRouter` against casing/spacing drift in `researchState`.
- Added evidence-first/accession-search intent routing so safe evidence acquisition remains executable while claims stay locked.
- Added regression tests for router normalization and cooldown escape preservation.

## 1.10.8-alpha-dataset-hunt-unlock — maintenance pass 3

- Hardened dataset-hunt unlock evaluation by normalizing research-state and directive-owner inputs.
- Allowed persistent no-dataset failure memory to trigger the safe evidence-first unlock when report text is sparse.
- Added explicit accession guard regression coverage so closure targets are never overridden.
- Added resolver and phase-audit regression tests for `EVIDENCE_FIRST_ACCESSION_SEARCH` and unlocked dataset-first foraging.
- Extended `audit_dataset_hunt_unlock_v1108.py` to lock the new safety and non-regression checks.

## 1.10.8-alpha-dataset-hunt-unlock — maintenance pass

- Added a dataset-hunt unlock policy so cognitive THINK_FIRST locks cannot block the only safe evidence-acquisition step when no EvidenceObject/DatasetCandidate/Accession exists.
- Added a regression audit for the unlock wiring, plan-stage directive fallback, lock-aware phase audit, and report execution wording.
- Updated UI/text report wording to distinguish executed search paths from planned search budget.
- Preserved hypothesis-upgrade, causal-language, and broad-search locks.


## 1.10.6-alpha-plan-stage-extraction

- Added `ResearchCyclePlanStage` as the first executable runCycle phase extraction.
- Final network handoff now uses `selectedSearchQueriesV206`, not the raw query-feedback batch.
- Added `cyclePlanStageReport` to JSON/PDF.
- Added regression tests and audit guard for plan-stage budget enforcement.

## v1.10.8 final hardening — numeric SRA UID safety

- Prevented numeric Entrez SRA UID fallback from being synthesized into fake `SRA<uid>` accessions.
- Kept unresolved SRA UID-only records as `DATASET_ACCESSION_UNRESOLVED` unless explicit accession-like metadata is present.
- Added regression test and audit guard for numeric SRA UID handling.

## v1.10.8-alpha-dataset-hunt-unlock — final closure

- Added release hygiene audit to prevent `.gradle`, build outputs, Python caches, APK/AAB artifacts, and local logs from entering source ZIPs.
- Wired the hygiene audit into static checks after the dataset-hunt unlock consistency audit.
- Removed local `.gradle/` cache state from the release tree.
- Preserved the evidence-first invariant: missing evidence unlocks bounded accession search only; existing evidence must be closed/inspected first.
