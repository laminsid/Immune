#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
checks = {
    'app/build.gradle.kts': ['versionCode = 103', 'versionName = "1.10.41-alpha-biomedical-research-ontology"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.41-alpha-biomedical-research-ontology', 'ImmuneEvidencePriorMatrix'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 103', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.41"'
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 103', 'VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"',
        'ENGINE_VERSION: String = "v1.10.41-alpha-biomedical-research-ontology"', 'LEARNING_SCHEMA_VERSION: String = "1.10.41"',
        'Evidence Prior Matrix'
    ],
    'scripts/run_static_checks_fast.sh': ['audit_v11038_evidence_prior_matrix.py', 'audit_release_version_linkage_v11038.py'],
    'scripts/run_static_checks_full.sh': ['audit_v11038_evidence_prior_matrix.py', 'audit_release_version_linkage_v11038.py'],
    'scripts/run_static_checks.sh': ['1.10.41-alpha-biomedical-research-ontology'],
    'docs/CHANGELOG_v1.10.38.md': ['1.10.38-alpha-evidence-prior-matrix', 'versionCode=100']
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.38 release file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.38 release token: {token}')
print('v1.10.38 release version linkage audit: PASS')
