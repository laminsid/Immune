#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
find . -type d -name __pycache__ -prune -exec rm -rf {} +
find . -name "*.pyc" -delete
python3 scripts/validate_json.py
python3 scripts/audit_kotlin_delimiters.py
python3 scripts/audit_kotlin_regex_escape_safety_v11033.py
python3 scripts/audit_github_workflow_pipefail_safety_v11033.py
python3 scripts/audit_discovery_exporter_local_names_v11033.py
python3 scripts/audit_v11033_unit_regression_contracts.py
python3 scripts/audit_v11033_single_prompt_ui_scope.py
python3 scripts/audit_v11033_learning_value_mode.py
python3 scripts/audit_v11034_useful_learning_report.py
python3 scripts/audit_v11034_english_compact_ui.py
python3 scripts/audit_release_version_linkage_v11030.py
python3 scripts/audit_release_version_linkage_v11031.py
python3 scripts/audit_release_version_linkage_v11032.py
python3 scripts/audit_release_version_linkage_v11034.py
python3 scripts/audit_v11035_lead_closure_handoff.py
python3 scripts/audit_v11036_learning_audit_monitor.py
python3 scripts/audit_release_version_linkage_v11036.py
python3 scripts/audit_v11037_ebv_criterion_lane.py
python3 scripts/audit_release_version_linkage_v11037.py
python3 scripts/audit_v11038_evidence_prior_matrix.py
python3 scripts/audit_release_version_linkage_v11038.py
python3 scripts/audit_v11039_integrated_path_linkage.py
python3 scripts/audit_release_version_linkage_v11039.py
python3 scripts/audit_v11040_release_stability_gate.py
python3 scripts/audit_release_version_linkage_v11040.py
python3 scripts/audit_v11041_biomedical_research_ontology.py
python3 scripts/audit_release_version_linkage_v11041.py
python3 scripts/audit_v11042_biomedical_concept_bridge.py
python3 scripts/audit_release_version_linkage_v11042.py
python3 scripts/audit_v11043_modern_medtech_modular_index.py
python3 scripts/audit_release_version_linkage_v11043.py
python3 scripts/audit_v11044_viral_countermeasure_knowledge_graph.py
python3 scripts/audit_release_version_linkage_v11044.py
python3 scripts/audit_v11045_compile_scope_guard.py
python3 scripts/audit_release_version_linkage_v11045.py
python3 scripts/audit_v11046_longevity_biological_systems_graph.py
python3 scripts/audit_release_version_linkage_v11046.py
python3 - <<'PY_AUDIT_STRINGS'
import pathlib
bad=[]
for path in pathlib.Path('app/src/main/java').rglob('*.kt'):
    for i,line in enumerate(path.read_text(errors='replace').splitlines(),1):
        if '"""' in line:
            continue
        cnt=0
        esc=False
        for ch in line:
            if esc:
                esc=False
                continue
            if ch == '\\':
                esc=True
                continue
            if ch == '"':
                cnt += 1
        if cnt % 2 == 1:
            bad.append(f'{path}:{i}: {line[:140]}')
if bad:
    raise SystemExit('Kotlin raw/newline string literal audit failed:\n' + '\n'.join(bad[:20]))
print('Kotlin string literal audit: PASS')
PY_AUDIT_STRINGS
python3 - <<'PY_XML'
import pathlib, xml.etree.ElementTree as ET
for p in pathlib.Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('XML parse: PASS')
PY_XML
