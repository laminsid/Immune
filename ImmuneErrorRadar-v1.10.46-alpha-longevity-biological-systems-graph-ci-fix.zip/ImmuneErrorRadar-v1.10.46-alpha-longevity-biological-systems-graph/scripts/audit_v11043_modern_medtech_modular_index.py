#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/ModernMedicalTechnologyIntelligenceV11043.kt': [
        'ModernMedicalTechnologyReport',
        'ModernTechnologyModuleCard',
        'ModernMedicalTechnologyIntelligenceV11043',
        'RNA_SINGLE_CELL_SPATIAL_OMICS',
        'NANO_DELIVERY_EXOSOME_LNP',
        'MULTI_OMICS_PROTEOMICS_METABOLOMICS_EPIGENOMICS',
        'ADVANCED_LAB_ASSAY_PLATFORMS',
        'ACCESSION_REPOSITORY_INDEX',
        'COMPUTATIONAL_MEDICINE_AI_BIOMARKER_DISCOVERY',
        'CELL_GENE_THERAPY_RESEARCH_CONTEXT',
        'modern_medical_technology_routing_only_not_lab_or_clinical_proof',
        'Load selected modules only',
        'scientific breakthrough confirmed',
    ],
    'app/src/main/assets/modern_medical_technology_modules_v1.10.43.json': [
        'RNA_SINGLE_CELL_SPATIAL_OMICS', 'NANO_DELIVERY_EXOSOME_LNP', 'ACCESSION_REPOSITORY_INDEX', 'modular_retrieval'
    ],
    'app/src/main/assets/biomedical_modular_index_v1.10.43.json': [
        'biomedical_research_ontology_v1.10.41.json', 'modern_medical_technology_modules_v1.10.43.json', 'retrievalPolicy'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': ['modernMedicalTechnologyReport: ModernMedicalTechnologyReport'],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['modernMedicalTechnologyReport', 'modernMedicalTechnologyToJson', 'modernTechnologyModuleCardToJson'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['ModernMedicalTechnologyIntelligenceV11043.evaluate', 'v1.10.43 modern medical technology intelligence'],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': ['Modern medical technology intelligence v1.10.43', 'partitionIndexKeys'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': ['Modern Medical Technology Intelligence v1.10.43', 'Tech partition index'],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': ['ModernMedicalTechnologyIntelligence', 'BiomedicalModularKnowledgeIndex', 'TechnologyModuleRetriever', 'NanoRnaOmicsVocabulary'],
    'app/src/main/java/com/immunesignal/app/FinalReleaseStabilityGuardV11040.kt': ['ModernMedicalTechnologyIntelligence', 'BiomedicalModularKnowledgeIndex'],
    'docs/MODERN_MEDICAL_TECHNOLOGY_INTELLIGENCE_v1.10.43.md': ['modular intelligence layer', 'RNA / single-cell', 'nanomedicine', 'VersionCode: `105`'],
    'docs/CHANGELOG_v1.10.43.md': ['1.10.43-alpha-modern-medtech-modular-index', 'VersionCode: `105`'],
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.43 modern medtech file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.43 modern medtech token: {token}')
print('v1.10.43 modern medical technology modular index audit: PASS')
