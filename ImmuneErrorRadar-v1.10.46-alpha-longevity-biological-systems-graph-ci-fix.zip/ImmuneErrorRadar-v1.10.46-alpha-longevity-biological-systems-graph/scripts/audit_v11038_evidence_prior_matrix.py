#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/ImmuneEvidencePriorMatrixV11038.kt': [
        'ImmuneEvidencePriorMatrix', 'EvidencePriorSelectionReport', 'No random.choice/context injection',
        'EBV_MOLECULAR_MIMICRY', 'NATURAL_COMPOUND_NOISE_CONTROL',
        'evidence_prior_matrix_routing_only_not_biological_proof', 'forbiddenClaims'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': ['evidencePriorSelectionReport', 'EvidencePriorSelectionReport.empty'],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['evidencePriorSelectionReport', 'evidencePriorSelectionToJson', 'blockedInjection'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ImmuneEvidencePriorMatrix.select', 'v1.10.38 evidence prior matrix', 'evidencePriorSelectionReportV11038'
    ],
    'app/src/main/java/com/immunesignal/app/LearningRulesUiSummaryV11036.kt': [
        'evidencePriorSelectionReport', 'Evidence Prior Matrix', 'random context injection is blocked'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': ['Evidence Prior Matrix v1.10.38', 'forbiddenClaims'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': ['Evidence Prior Matrix v1.10.38', 'Prior forbidden claims'],
    'app/src/test/java/com/immunesignal/app/ImmuneEvidencePriorMatrixV11038Test.kt': [
        'ImmuneEvidencePriorMatrixV11038Test', 'selectsEbvMolecularMimicryWithoutBreakthroughClaims',
        'naturalCompoundPriorIsNoiseGuarded'
    ],
    'docs/EVIDENCE_PRIOR_MATRIX_v1.10.38.md': ['Evidence Prior Matrix v1.10.38', 'not context injection', 'random context injection is blocked'],
    'docs/CHANGELOG_v1.10.38.md': ['1.10.38-alpha-evidence-prior-matrix', 'versionCode=100', 'ImmuneEvidencePriorMatrix']
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.38 evidence prior matrix file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.38 token: {token}')
print('v1.10.38 evidence prior matrix audit: PASS')
