#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
checks = {
    'app/build.gradle.kts': ['versionCode = 105', 'versionName = "1.10.43-alpha-modern-medtech-modular-index"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.43-alpha-modern-medtech-modular-index', 'ModernMedicalTechnologyIntelligence'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.10.43-alpha-modern-medtech-modular-index"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 105',
        'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.43"'
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 105',
        'VERSION_NAME: String = "1.10.43-alpha-modern-medtech-modular-index"',
        'ENGINE_VERSION: String = "v1.10.43-alpha-modern-medtech-modular-index"',
        'LEARNING_SCHEMA_VERSION: String = "1.10.43"',
        'modern medical technology modular-index release'
    ],
    'scripts/run_static_checks_fast.sh': ['audit_v11043_modern_medtech_modular_index.py', 'audit_release_version_linkage_v11043.py'],
    'scripts/run_static_checks_full.sh': ['audit_v11043_modern_medtech_modular_index.py', 'audit_release_version_linkage_v11043.py'],
    'scripts/run_static_checks.sh': ['1.10.43-alpha-modern-medtech-modular-index'],
    'docs/CHANGELOG_v1.10.43.md': ['1.10.43-alpha-modern-medtech-modular-index', 'VersionCode: `105`'],
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.43 release file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.43 release token: {token}')
print('v1.10.43 release version linkage audit: PASS')
