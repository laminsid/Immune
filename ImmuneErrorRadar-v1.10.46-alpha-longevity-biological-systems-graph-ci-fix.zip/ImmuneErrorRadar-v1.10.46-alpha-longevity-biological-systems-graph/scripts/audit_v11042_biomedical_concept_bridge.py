#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/BiomedicalConceptBridgeV11042.kt': [
        'BiomedicalConceptBridgeReport',
        'BiomedicalBridgeCard',
        'BiomedicalConceptBridgeV11042',
        'VIRUS_AUTOIMMUNITY_MIMICRY_BRIDGE',
        'ORGAN_BARRIER_IMMUNE_ENTRY_BRIDGE',
        'BLOOD_LAB_IMMUNE_ACTIVITY_BRIDGE',
        'MITOCHONDRIA_ENERGY_IMMUNE_BRIDGE',
        'DRUG_EXPOSURE_CONFOUNDER_BRIDGE',
        'NUTRITION_EXPOSURE_NOISE_BRIDGE',
        'biomedical_concept_bridge_routing_only_not_clinical_conclusion',
        'patient diagnosis',
        'treatment recommendation',
        'supplement recommendation',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': ['biomedicalConceptBridgeReport: BiomedicalConceptBridgeReport'],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['biomedicalConceptBridgeReport', 'biomedicalConceptBridgeToJson', 'biomedicalBridgeCardToJson'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['BiomedicalConceptBridgeV11042.evaluate', 'v1.10.42 biomedical concept bridge'],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': ['Biomedical concept bridge v1.10.42', 'evidenceKeysToClose'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': ['Biomedical Concept Bridge v1.10.42', 'Bridge evidence keys'],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': ['BiomedicalConceptBridge', 'OntologyBridgeGraph', 'ConceptBridgeNoiseGuard'],
    'app/src/main/java/com/immunesignal/app/FinalReleaseStabilityGuardV11040.kt': ['BiomedicalConceptBridge'],
    'docs/BIOMEDICAL_CONCEPT_BRIDGE_v1.10.42.md': ['scientist/lab-facing bridge graph', 'It cannot produce', 'VersionCode: `104`'],
    'docs/CHANGELOG_v1.10.42.md': ['v1.10.42-alpha-biomedical-concept-bridge', 'VersionCode: `104`'],
}
for rel, tokens in checks.items():
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f'missing v1.10.42 bridge file: {rel}')
    text = path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.42 bridge token: {token}')
print('v1.10.42 biomedical concept bridge audit: PASS')
