#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
files = {
    'app/src/main/java/com/immunesignal/app/LongevityBiologicalSystemsGraphV11046.kt': [
        'LongevityBiologicalSystemsGraphV11046',
        'CIRCADIAN_SLEEP_INTELLIGENCE',
        'METABOLIC_IMMUNE_LANE',
        'MITOCHONDRIAL_FATIGUE_LANE',
        'IMMUNE_AGING_IMMUNOSENESCENCE_LANE',
        'TOXIN_PLASTIC_ENVIRONMENT_EXPOSURE_LANE',
        'NUTRITION_MICRONUTRIENT_INTELLIGENCE',
        'HERBS_FOODS_EXPOSURE_CONTROL_LANE',
        'Exposure → Pathway → Biomarker → Dataset → Outcome → Contradiction',
        'HealthAdviceClaimGuardV11046',
        'no treatment recommendation',
        'contradiction search is mandatory'
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': ['longevityBiologicalSystemsReport'],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['longevityBiologicalSystemsReport', 'biomarkersRequired', 'contradictionSearchTerms', 'exposurePathways'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['LongevityBiologicalSystemsGraphV11046.evaluate', 'longevityBiologicalSystemsReportV11046', 'v1.10.46 longevity biological systems graph'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': ['Biological Systems Graph v1.10.46', 'Required biomarkers', 'Contradiction search'],
    'app/src/main/java/com/immunesignal/app/LearningRulesUiSummaryV11036.kt': ['BIOLOGICAL_SYSTEMS_CONTRADICTION_REQUIRED_NO_HEALTH_ADVICE', 'Lifestyle and longevity topics must map'],
    'app/src/main/java/com/immunesignal/app/ViralCountermeasureIntelligenceV11044.kt': ['longevity: LongevityBiologicalSystemsReport', 'KNOWLEDGE_GRAPH_LINKED_LONGEVITY_SYSTEMS_ROUTE'],
    'app/src/main/assets/longevity_biological_systems_modules_v1.10.46.json': ['"schemaVersion": "1.10.46"', '"pathwayTemplate"', '"mandatoryReportFields"']
}
for rel, tokens in files.items():
    text = (ROOT / rel).read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'MISSING {token} in {rel}')

source = (ROOT / 'app/src/main/java/com/immunesignal/app/LongevityBiologicalSystemsGraphV11046.kt').read_text(errors='replace')
for module in ['immune', 'viral', 'metabolic', 'cardiovascular', 'neurological', 'endocrine_hpa', 'mitochondrial', 'nutrition', 'drugs', 'herbs_exposures', 'longevity_biomarkers']:
    if f'"{module}"' not in source:
        raise SystemExit(f'MISSING knowledge module {module}')
for biomarker in ['CRP', 'IL-6', 'TNF-alpha', 'cortisol', 'glucose', 'HbA1c', 'HRV', 'blood pressure', 'VO2max', 'lipids', 'WBC/RBC', 'platelets']:
    if biomarker not in source:
        raise SystemExit(f'MISSING biomarker {biomarker}')
for forbidden in ['dose recommendation', 'supplement protocol', 'treatment recommendation', 'personal health advice']:
    if forbidden not in source:
        raise SystemExit(f'MISSING health-advice guard token {forbidden}')
print('v1.10.46 longevity biological systems graph audit: PASS')
