#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')
checks = {
    'app/build.gradle.kts': ['versionCode = 103', 'versionName = "1.10.41-alpha-biomedical-research-ontology"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.41-alpha-biomedical-research-ontology', 'EBVLeadVerificationPolicy'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 103', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.41"',
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 103', 'VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"',
        'ENGINE_VERSION: String = "v1.10.41-alpha-biomedical-research-ontology"', 'LEARNING_SCHEMA_VERSION: String = "1.10.41"',
        'EBV criterion lane',
    ],
    'scripts/run_static_checks_fast.sh': ['audit_v11037_ebv_criterion_lane.py', 'audit_release_version_linkage_v11037.py'],
    'scripts/run_static_checks_full.sh': ['audit_v11037_ebv_criterion_lane.py', 'audit_release_version_linkage_v11037.py'],
    'scripts/run_static_checks.sh': ['1.10.41-alpha-biomedical-research-ontology'],
    'docs/CHANGELOG_v1.10.37.md': ['1.10.37-alpha-ebv-criterion-lane', 'versionCode=99'],
}
for rel, tokens in checks.items():
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.37 release file: {rel}')
    text = p.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.37 release token: {token}')
print('v1.10.37 release version linkage audit: PASS')
