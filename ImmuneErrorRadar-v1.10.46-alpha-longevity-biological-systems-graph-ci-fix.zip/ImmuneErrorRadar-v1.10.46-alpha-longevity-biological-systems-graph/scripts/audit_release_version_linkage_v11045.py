#!/usr/bin/env python3
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
checks = {
 'app/build.gradle.kts': ['versionCode = 107', 'versionName = "1.10.45-alpha-compile-scope-linkage-guard"'],
 'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': ['RELEASE_TRAIN_VERSION_CODE: Int = 107', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.45"', '1.10.45-alpha-compile-scope-linkage-guard'],
 'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['ACTIVE_ENGINE_VERSION = "v1.10.45-alpha-compile-scope-linkage-guard"', 'active_compile_scope_guard_v11045'],
 'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': ['VERSION_CODE: Int = 107', 'VERSION_NAME: String = "1.10.45-alpha-compile-scope-linkage-guard"', 'LEARNING_SCHEMA_VERSION: String = "1.10.45"'],
 'scripts/run_static_checks_fast.sh': ['audit_v11045_compile_scope_guard.py', 'audit_release_version_linkage_v11045.py'],
 'scripts/run_static_checks_full.sh': ['audit_v11045_compile_scope_guard.py', 'audit_release_version_linkage_v11045.py'],
 'docs/CHANGELOG_v1.10.45.md': ['versionCode=107', '1.10.45-alpha-compile-scope-linkage-guard']
}
for rel, tokens in checks.items():
    text = (ROOT/rel).read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'MISSING {token} in {rel}')
print('v1.10.45 release linkage audit: PASS')
