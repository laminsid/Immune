#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.36 release file: {rel}')
    return p.read_text(errors='replace')

checks = {
    'app/build.gradle.kts': ['versionCode = 103', 'versionName = "1.10.41-alpha-biomedical-research-ontology"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.41-alpha-biomedical-research-ontology', 'LearningRulesUiSummary'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 103', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.41"',
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 103', 'VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"',
        'ENGINE_VERSION: String = "v1.10.41-alpha-biomedical-research-ontology"', 'LEARNING_SCHEMA_VERSION: String = "1.10.41"',
        'learning audit monitor',
    ],
    'scripts/run_static_checks_fast.sh': ['audit_v11036_learning_audit_monitor.py', 'audit_release_version_linkage_v11036.py'],
    'scripts/run_static_checks_full.sh': ['audit_v11036_learning_audit_monitor.py', 'audit_release_version_linkage_v11036.py'],
    'scripts/run_static_checks.sh': ['1.10.41-alpha-biomedical-research-ontology'],
    'docs/CHANGELOG_v1.10.36.md': ['1.10.36-alpha-learning-monitor-continuity', 'versionCode=98'],
}
for rel, tokens in checks.items():
    text = read(rel)
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.36 release token: {token}')
print('v1.10.36 release version linkage audit: PASS')
