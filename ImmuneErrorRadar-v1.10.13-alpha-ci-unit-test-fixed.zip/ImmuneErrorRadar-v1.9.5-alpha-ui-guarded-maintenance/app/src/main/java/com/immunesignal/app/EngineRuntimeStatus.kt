package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.4.5: learning memory, ML-safe triage, query feedback, freshness weighting, route-fit gate, and score separation.
 *
 * Earlier versions could write a correct pivot in the report without proving
 * that the next run actually executed the forced evidence path. This object is
 * intentionally small and explicit: it records which engine is active, which
 * modules are on, which research state was forced, which queries were actually
 * executed, and whether the execution lock passed.
 */
data class ActiveResearchEngineStatus(
    val engineVersion: String,
    val activeModules: List<String>,
    val researchState: String,
    val appliedPivotType: String,
    val effectiveMaxQueries: Int,
    val effectiveResultsPerQuery: Int,
    val runtimeFailoverApplied: Boolean,
    val forcedQueries: List<String>,
    val executedQueryIds: List<String>
)

data class ExecutionLockReport(
    val status: String,
    val failures: List<String>,
    val enforcedActions: List<String>
)

object EngineRuntimeStatus {
    // legacy_audit_version_token_v195: v1.9.5-alpha-ui-guarded-maintenance
    const val ACTIVE_ENGINE_VERSION = "v1.10.13-alpha-steering-aware-creative-thinking"

    val ACTIVE_MODULES = RuntimeModuleRegistry.activeModuleIds

    private val legacyActiveModules = listOf(
        "SmartReportIntegrityLock",
        "ScopeDisciplineLock",
        "AutonomousStagnationEngine",
        "EvidenceLearningOS",
        "DatasetAccessionResolver",
        "LaneCooldown",
        "ExecutionWiringGuard",
        "RuntimeDatasetHuntFailover",
        "DirectDatasetSourceRouter",
        "DatasetFirstForager",
        "PersistentFailureMemory",
        "HypothesisDecomposer",
        "MultiPassEvidenceLoop",
        "DatasetParser",
        "OutcomeLabelDetector",
        "ControlGroupDetector",
        "ContrastiveEvidenceGate",
        "CumulativeEvidenceScorer",
        "EvidenceHypergraphLite",
        "ResearchRouteAudit",
        "ActionableNextEvidence",
        "RouteFitGate",
        "ScoreSeparation",
        "FailurePatternLedger",
        "QueryFeedbackPlanner",
        "DatasetTriageEngine",
        "MLDatasetTriageEngine",
        "FailurePredictionModel",
        "RouteEmbeddingScorer",
        "EvidenceFreshnessScorer",
        "FoundationKnowledgeLayer",
        "AxisRankingEngine",
        "FoundationConflictResolver",
        "FoundationKnowledgeAccuracyLedger",
        "FoundationPatchSuggestionLedger",
        "LearningSessionManager",
        "PhaseExecutor",
        "ProgressTracker",
        "QuestionEvolver",
        "SessionMetrics",
        "RuntimeFeatureFlags",
        "LearningSessionIntegrityGuard",
        "SessionHistoryPersistence",
        "LearningSessionOutcomeBridge",
        "SessionHandoff",
        "CandidateActionResolver",
        "MinimumMetadataParser",
        "AutoContinuationTrigger",
        "ReportConsistencyGuard",
        "SpecializedReasoningEngine",
        "HypothesisFalsificationPressure",
        "NextDecisiveTestSelector",
        "GeneralModelFailureGuard",
        "CumulativeKnowledgeMapEngine",
        "KnowledgeMapReport",
        "EpistemicBeliefEngine",
        "EpistemicBeliefReport",
        "BeliefTransitionSummary",
        "BeliefAbandonmentQuestion",
        "UnusedWeakBeliefPruner",
        "MutableBeliefRevision",
        "MapGapTracker",
        "MapCarryForward",
        "EvidenceGapMatrix",
        "HypothesisTournament",
        "ReasoningAuditProtocol",
        "NextCycleProtocol",
        "CognitivePathIntegrationEngine",
        "CognitivePathIntegrationReport",
        "CognitiveNextCycleBridge",
        "CognitiveNextCycleDirective",
        "CognitiveLoopSingleUseGuard",
        "QueryInflationGuard",
        "CognitiveLoopCalibrationEngine",
        "DirectiveOutcomeCalibration",
        "IntegratedNextAction",
        "DirectiveLifecycleEngine",
        "DirectiveLifecycleReport",
        "EvidenceGainQueryRanker",
        "BeliefFalsificationContractEngine",
        "BeliefFalsificationContractReport",
        "MemoryConsolidationEngine",
        "CausalReadinessGate",
        "ReflectionLessonEngine",
        "MiniPeerReviewGate",
        "ReportSimplificationLayer",
        "ActionableCognitiveControlV171",
        "DirectiveControlContextEnricher",
        "WeightedDiscoveryIntelligenceV182",
        "ScientificKnowledgeIndexEngine",
        "ScientificTermIndexV181",
        "KnowledgeRoutedDiscoveryControlV181",
        "MechanismHypothesisEngine",
        "MechanismTournamentEngine",
        "DecisiveExperimentPlanner",
        "NoveltyAndNonObviousnessScorer",
        "DeepContradictionMiner",
        "CrossAxisBridgeReasoner",
        "DeepThinkSessionEngine",
        "DeepDiscoveryReasonerV180",
        "ScientificDiscoveryWeightEngine",
        "ScientificDiscoveryDecisionEngineV183",
        "ScientificDiscoveryDecisionMemoryV183",
        "ScientificDiscoveryStressTestEngineV184",
        "CounterfactualDiscoveryStressTestV184",
        "ScientificDiscoveryExecutionPolicyEngineV185",
        "PolicyEnforcedDiscoveryControlV185",
        "ScientificDiscoveryOutcomeVerifierEngineV186",
        "OutcomeVerificationDiscoveryMemoryV186",
        "ScientificDiscoveryLineageEngineV187",
        "HypothesisLineageDiscoveryGraphV187",
        "ScientificDiscoveryGapMinerEngineV188",
        "LatentDiscoveryGapMinerV188",
        "ScientificDiscoveryProbePlannerEngineV189",
        "ExecutableDiscoveryProbePlanV189",
        "ScientificDiscoveryProbeOutcomeLedgerEngineV190",
        "ProbeOutcomeLearningLedgerV190",
        "ScientificDiscoveryMetaStrategyGovernorEngineV191",
        "MetaStrategyGovernorV191",
        "ScientificDiscoveryQualityGateEngineV192",
        "DiscoveryQualityGateV192",
        "ExecutableQualityRunbookV193",
        "EvidenceClosureEngine",
        "AccessionClosureCard",
        "PostSearchThinkingEngine",
        "ThinkingContinuityEngine",
        "AutonomousThoughtPulseEngine",
        "HypothesisGraphCognitionV198",
        "CognitiveMomentumEngineV199",
        "LinkedCognitionSpineEngineV200",
        "RuntimeHardeningV1101",
        "RuntimeHardeningV1102",
        "NcbiClientOkHttp",
        "NcbiRateLimiter",
        "SecureNcbiCredentialStore",
        "AxisMatcherWordBoundary",
        "CognitionPathOrchestrator",
        "ProgressAuditGate",
        "OfflineThoughtLedger",
        "OfflineHypothesisLinker"
    )

    fun stateFor(appliedPivot: PivotDecision, stagnationActive: Boolean): String {
        val pivotText = (appliedPivot.pivotType + " " + appliedPivot.nextIntent + " " + appliedPivot.nextQuerySeed).lowercase()
        return when {
            pivotText.contains("dataset") || pivotText.contains("accession") -> "DATASET_HUNT"
            pivotText.contains("contradiction") || pivotText.contains("negative control") -> "CONTRADICTION_HUNT"
            stagnationActive -> "STAGNATION_RECOVERY"
            appliedPivot.pivotType != "NO_PIVOT" -> "FORCED_EVIDENCE_PATH"
            else -> "RESEARCH_NORMAL"
        }
    }

    fun enforceQueryBudget(
        baseLimits: ResearchRunLimits,
        appliedPivot: PivotDecision,
        stagnationPlan: AutonomousStagnationEngine.StagnationPlan
    ): Pair<Int, Int> {
        val forced = appliedPivot.pivotType != "NO_PIVOT" || stagnationPlan.active
        val maxQueries = maxOf(baseLimits.maxQueries, stagnationPlan.effectiveMaxQueries, if (forced) 6 else baseLimits.maxQueries)
        val retMax = maxOf(baseLimits.maxResultsPerQuery, stagnationPlan.effectiveResultsPerQuery, if (forced) 20 else baseLimits.maxResultsPerQuery)
        return maxQueries to retMax
    }

    fun hardStagnationTriggered(newFindingsCount: Int, repeatedSkipped: Int, datasetCandidateCount: Int): Boolean {
        return newFindingsCount <= 0 && repeatedSkipped >= 10 && datasetCandidateCount <= 0
    }

    fun runtimeFailoverPivot(repeatedSkipped: Int): PivotDecision {
        return ScopeDisciplineLock.sanitizePivot(
            PivotDecision(
                pivotType = "RUNTIME_STAGNATION_DATASET_HUNT",
                reason = "Hard stagnation triggered during this run: no fresh useful sources, repeated skipped=$repeatedSkipped, and no dataset candidate. Execute dataset/accession hunt now instead of only writing a future pivot.",
                nextIntent = "runtime_dataset_hunt",
                nextQuerySeed = "GSE OR GEO OR SDY OR ImmPort OR PRJNA OR SRP RNA-seq single-cell immune response outcome severity longitudinal negative control",
                priority = 99
            )
        )
    }

    fun buildExecutionLock(
        runtimeStatus: ActiveResearchEngineStatus,
        learningOsReport: LearningOsReport,
        hardStagnationObserved: Boolean,
        datasetForagingReport: DatasetForagingReport = DatasetForagingReport.empty()
    ): ExecutionLockReport {
        val failures = mutableListOf<String>()
        val enforced = mutableListOf<String>()

        if (runtimeStatus.engineVersion != ACTIVE_ENGINE_VERSION) {
            failures += "Active engine version mismatch."
        }
        if (runtimeStatus.activeModules.toSet().containsAll(ACTIVE_MODULES).not()) {
            failures += "Not all dataset-first execution modules are active."
        }

        if (runtimeStatus.appliedPivotType != "NO_PIVOT") {
            if (runtimeStatus.forcedQueries.isEmpty()) failures += "Forced pivot exists but no forced queries were generated."
            if (runtimeStatus.executedQueryIds.none { it.startsWith("q_pivot_") || it.startsWith("q_antistag_") || it.startsWith("q_runtime_") || it.startsWith("q_v140_") || it.startsWith("q_v142_") || it.startsWith("q_v196_") || it.startsWith("q_v197_") || it.startsWith("q_v199_") || it.startsWith("q_v200_") || it.startsWith("q_v201_") }) {
                failures += "Forced pivot exists but no forced query id was executed."
            }
            enforced += "Forced evidence path executed for ${runtimeStatus.appliedPivotType}."
        }

        if (datasetForagingReport.active) {
            enforced += "Dataset-first forager executed: ${datasetForagingReport.sourceFamiliesAttempted.joinToString(", ")}."
            if (datasetForagingReport.sourceFamiliesAttempted.isEmpty()) failures += "Dataset-first forager was active but no source family was attempted."
            if (datasetForagingReport.passes.isEmpty()) failures += "Dataset-first forager was active but no acquisition pass was recorded."
        }

        if (runtimeStatus.researchState == "DATASET_HUNT" && !datasetForagingReport.active) {
            failures += "Research state is DATASET_HUNT but dataset-first forager did not run."
        }

        if (hardStagnationObserved) {
            val causes = learningOsReport.incident.rootCauses
            if (causes.isEmpty()) failures += "Hard stagnation observed but no root cause was recorded."
            if (learningOsReport.preventiveGates.isEmpty()) failures += "Hard stagnation observed but no preventive gate was created."
            if (learningOsReport.regressionVectors.isEmpty()) failures += "Hard stagnation observed but no regression vector was created."
            if (learningOsReport.laneCooldowns.isEmpty()) failures += "Hard stagnation observed but no lane cooldown was created."
            enforced += "Hard stagnation converted to incident, gate, regression vector, and cooldown."
        }

        if (runtimeStatus.runtimeFailoverApplied) {
            enforced += "Runtime dataset hunt failover executed inside the same cycle."
        }

        return ExecutionLockReport(
            status = if (failures.isEmpty()) "PASS" else "FAIL",
            failures = failures,
            enforcedActions = enforced.ifEmpty { listOf("Normal research cycle; no forced execution needed.") }
        )
    }

    fun runtimeStatusToJson(item: ActiveResearchEngineStatus): JSONObject = JSONObject()
        .put("engineVersion", item.engineVersion)
        .put("activeModules", JSONArray(item.activeModules))
        .put("researchState", item.researchState)
        .put("appliedPivotType", item.appliedPivotType)
        .put("effectiveMaxQueries", item.effectiveMaxQueries)
        .put("effectiveResultsPerQuery", item.effectiveResultsPerQuery)
        .put("runtimeFailoverApplied", item.runtimeFailoverApplied)
        .put("forcedQueries", JSONArray(item.forcedQueries))
        .put("executedQueryIds", JSONArray(item.executedQueryIds))

    fun executionLockToJson(item: ExecutionLockReport): JSONObject = JSONObject()
        .put("status", item.status)
        .put("failures", JSONArray(item.failures))
        .put("enforcedActions", JSONArray(item.enforcedActions))
}
