package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.5.5: Phase Executor
 *
 * Executes bounded learning sessions in four independent phases.
 * Uses only existing report summaries + ledgers, so it stays non-breaking and
 * does not require changing the core ResearchAutopilot cycle.
 */
interface PhaseStrategy {
    fun execute(
        context: android.content.Context,
        reportHistory: List<ResearchReportV3>,
        onProgress: (progress: Int, findings: JSONObject?) -> Unit,
        shouldStop: () -> Boolean
    ): JSONObject?
}

class PhaseExecutor(
    private val context: android.content.Context,
    private val sessionManager: LearningSessionManager,
    private val progressBroadcaster: ProgressBroadcaster
) {

    suspend fun executeAllPhases(
        session: LearningSession,
        reportHistory: List<ResearchReportV3>,
        onComplete: (LearningInsights) -> Unit
    ) {
        var insights = LearningInsights()

        for (phase in sessionManager.getCurrentSession()?.phases ?: session.phases) {
            if (shouldPauseOrStop()) {
                sessionManager.pauseSession()
                break
            }
            if (phase.status == PhaseStatus.COMPLETED) continue

            val rawResult = when (phase.phaseName) {
                "FAILURE_ANALYSIS" -> executePhase1FailureAnalysis { shouldPauseOrStop() }
                "INTERACTION_DETECTION" -> executePhase2InteractionDetection(reportHistory) { shouldPauseOrStop() }
                "ROUTE_DISCOVERY" -> executePhase3RouteDiscovery(reportHistory) { shouldPauseOrStop() }
                "BLIND_SPOT_FINDING" -> executePhase4BlindSpotFinding(reportHistory) { shouldPauseOrStop() }
                else -> null
            }

            if (rawResult == null) {
                if (shouldPauseOrStop()) sessionManager.pauseSession()
                continue
            }

            val activeSession = sessionManager.getCurrentSession() ?: session
            val result = attachEvolvedQuestions(
                phaseName = phase.phaseName,
                sessionType = activeSession.sessionType,
                previousInsights = insights,
                result = rawResult
            )
            sessionManager.completePhase(phase.phaseName, result)
            insights = mergeInsight(phase.phaseName, result, insights)
        }

        val current = sessionManager.getCurrentSession()
        val allComplete = current?.phases?.all { it.status == PhaseStatus.COMPLETED } == true
        if (allComplete) {
            sessionManager.completeSession(insights)
            progressBroadcaster.broadcastSessionComplete(insights)
            onComplete(insights)
        }
    }

    private fun shouldPauseOrStop(): Boolean {
        val current = sessionManager.getCurrentSession() ?: return false
        return current.status == SessionStatus.PAUSED ||
            current.status == SessionStatus.FAILED ||
            !current.canContinue()
    }

    private fun mergeInsight(phaseName: String, result: JSONObject, current: LearningInsights): LearningInsights {
        val evolvedQuestions = strings(result.optJSONArray("questions"))
        val base = when (phaseName) {
            "FAILURE_ANALYSIS" -> current.copy(failurePatternClusters = jsonObjects(result.optJSONArray("clusters")))
            "INTERACTION_DETECTION" -> current.copy(hypothesisInteractions = jsonObjects(result.optJSONArray("interactions")))
            "ROUTE_DISCOVERY" -> current.copy(proposedRoutes = jsonObjects(result.optJSONArray("proposedRoutes")))
            "BLIND_SPOT_FINDING" -> current.copy(blindSpots = jsonObjects(result.optJSONArray("blindSpots")))
            else -> current
        }
        return base.copy(questions = (base.questions + evolvedQuestions).distinct().take(16))
    }

    private fun attachEvolvedQuestions(
        phaseName: String,
        sessionType: SessionType,
        previousInsights: LearningInsights,
        result: JSONObject
    ): JSONObject {
        val questions = QuestionEvolver.generateQuestions(sessionType, previousInsights)
            .filter { it.phase == phaseName }
            .sortedByDescending { it.importance }
        val textQuestions = JSONArray()
        val questionObjects = JSONArray()
        questions.forEach { question ->
            textQuestions.put(question.text)
            questionObjects.put(JSONObject().apply {
                put("questionId", question.questionId)
                put("text", question.text)
                put("phase", question.phase)
                put("category", question.category)
                put("importance", question.importance)
                put("relatesTo", JSONArray(question.relatesTo))
                put("claimLimit", "question_evolution_not_biological_proof")
            })
        }
        result.put("questions", textQuestions)
        result.put("questionObjects", questionObjects)
        result.put("questionContext", QuestionEvolver.generatePhaseSpecificContext(phaseName, sessionType))
        result.put("questionEvolution", JSONObject().apply {
            put("sessionType", sessionType.name)
            put("phaseName", phaseName)
            put("questionCount", questions.size)
            put("claimLimit", "question_evolution_not_biological_proof")
        })
        return result
    }

    // ========== PHASE 1: Failure Analysis ==========
    private fun executePhase1FailureAnalysis(shouldStop: () -> Boolean): JSONObject? {
        val phase = "FAILURE_ANALYSIS"
        sessionManager.updatePhaseProgress(phase, 10, 0, 1)
        broadcast(phase, "Reading failure-pattern ledger...")

        return runCatching {
            val failures = FailurePatternLedger(context).getRecent(hours = 24 * 14)
            val groupedByRoute = failures.groupBy { it.route }
            val clusters = JSONArray()
            var processed = 0
            val total = groupedByRoute.size.coerceAtLeast(1)

            for ((route, routeFailures) in groupedByRoute) {
                if (shouldStop()) return@runCatching null
                routeFailures.groupBy { it.rootCause }.forEach { (rootCause, causes) ->
                    if (causes.size >= 2) {
                        clusters.put(JSONObject().apply {
                            put("route", route)
                            put("rootCause", rootCause)
                            put("count", causes.size)
                            put("occurrences", JSONArray(causes.map { it.id }))
                            put("lastSeenMillis", causes.maxOf { it.lastSeenMillis })
                            put("insight", detectDeepInsight(rootCause, route, causes))
                            put("claimLimit", "failure_memory_not_biological_proof")
                        })
                    }
                }
                processed += 1
                sessionManager.updatePhaseProgress(phase, 10 + processed * 80 / total, processed, total)
            }

            sessionManager.updatePhaseProgress(phase, 100, total, total)
            progressBroadcaster.broadcastPhaseComplete(phase, "${clusters.length()} clusters from ${failures.size} recent failure patterns")
            JSONObject()
                .put("clusters", clusters)
                .put("totalPatterns", failures.size)
                .put("clusterCount", clusters.length())
                .put("claimLimit", "failure_memory_not_biological_proof")
        }.getOrElse { error ->
            sessionManager.updatePhaseProgress(phase, 0, error = error.message)
            null
        }
    }

    private fun detectDeepInsight(rootCause: String, route: String, failures: List<FailurePattern>): String {
        return when {
            failures.size >= 5 && rootCause == "NO_OUTCOME_LABELS" ->
                "Route '$route' repeatedly lacks outcome labels; improve future queries before parsing more similar datasets."
            rootCause == "OFF_ROUTE" ->
                "Route contamination detected; tighten route-fit requirements or downgrade similar candidates to analogy."
            rootCause == "ANIMAL_ONLY" ->
                "Mechanism plausibility may exist, but human confidence must remain capped until human data appears."
            rootCause == "NO_TIMECOURSE" ->
                "Timing is missing; add longitudinal/time-course terms before claiming process dynamics."
            else -> "Repeated failure pattern: ${failures.size}x $rootCause on $route."
        }
    }

    // ========== PHASE 2: Hypothesis Interaction Detection ==========
    private fun executePhase2InteractionDetection(
        reportHistory: List<ResearchReportV3>,
        shouldStop: () -> Boolean
    ): JSONObject? {
        val phase = "INTERACTION_DETECTION"
        sessionManager.updatePhaseProgress(phase, 10)
        broadcast(phase, "Comparing hypothesis summaries...")

        return runCatching {
            val signalsByReport = reportHistory.map { report -> extractSignals(report) }
            val allSignals = signalsByReport.flatten().distinctBy { it.id }
            if (allSignals.size < 2) {
                return@runCatching JSONObject()
                    .put("interactions", JSONArray())
                    .put("reason", "Need at least 2 distinct hypothesis signals for interaction detection")
                    .put("claimLimit", "pattern_hypothesis_not_discovery")
            }

            val interactions = JSONArray()
            val totalComparisons = (allSignals.size * (allSignals.size - 1) / 2).coerceAtLeast(1)
            var completed = 0

            for (i in allSignals.indices) {
                for (j in (i + 1) until allSignals.size) {
                    if (shouldStop()) return@runCatching null
                    val first = allSignals[i]
                    val second = allSignals[j]
                    val coOccurrence = signalsByReport.count { signals ->
                        signals.any { it.id == first.id } && signals.any { it.id == second.id }
                    }
                    val sharedRoute = first.route == second.route && first.route != "unknown"
                    val interactionScore = coOccurrence * 25 + if (sharedRoute) 20 else 0
                    if (coOccurrence >= 1 || sharedRoute) {
                        interactions.put(JSONObject().apply {
                            put("hypothesis1", first.id)
                            put("hypothesis2", second.id)
                            put("route1", first.route)
                            put("route2", second.route)
                            put("coOccurrence", coOccurrence)
                            put("interactionScore", interactionScore.coerceIn(0, 100))
                            put("type", when {
                                interactionScore >= 70 -> "candidate_synergy"
                                sharedRoute -> "same_route_watch"
                                else -> "weak_interaction_watch"
                            })
                            put("claimLimit", "pattern_hypothesis_not_discovery")
                        })
                    }
                    completed += 1
                    sessionManager.updatePhaseProgress(phase, 10 + completed * 80 / totalComparisons, completed, totalComparisons)
                }
            }

            sessionManager.updatePhaseProgress(phase, 100, totalComparisons, totalComparisons)
            progressBroadcaster.broadcastPhaseComplete(phase, "${interactions.length()} interaction candidates found")
            JSONObject()
                .put("interactions", interactions)
                .put("comparisonsMade", completed)
                .put("claimLimit", "pattern_hypothesis_not_discovery")
        }.getOrElse { error ->
            sessionManager.updatePhaseProgress(phase, 0, error = error.message)
            null
        }
    }

    // ========== PHASE 3: Route Discovery ==========
    private fun executePhase3RouteDiscovery(
        reportHistory: List<ResearchReportV3>,
        shouldStop: () -> Boolean
    ): JSONObject? {
        val phase = "ROUTE_DISCOVERY"
        sessionManager.updatePhaseProgress(phase, 15)
        broadcast(phase, "Proposing route refinements...")

        return runCatching {
            if (shouldStop()) return@runCatching null
            val text = reportHistory.joinToString("\n") { listOf(it.hypothesis, it.newUsefulLead, it.nextAutonomousMove, it.doNotBelieveYet).joinToString(" ") }
            val routes = JSONArray()
            fun addRoute(id: String, reason: String, requiredTerms: List<String>) {
                routes.put(JSONObject().apply {
                    put("routeId", id)
                    put("reason", reason)
                    put("requiredTerms", JSONArray(requiredTerms))
                    put("status", "PROPOSED")
                    put("claimLimit", "proposed_not_validated")
                })
            }
            if (text.contains("interferon", true) || text.contains("viral", true)) {
                addRoute(
                    "antiviral_interferon_timing_refined",
                    "Require viral load, time-course, and recovery/severity labels before upgrade.",
                    listOf("human", "viral load", "time-course", "interferon", "recovery", "severity", "outcome")
                )
            }
            if (text.contains("allergy", true) || text.contains("nickel", true) || text.contains("anakinra", true)) {
                addRoute(
                    "allergy_contact_dermatitis_il1_skin",
                    "Keep skin/allergy/IL-1 datasets separate from antiviral evidence unless explicit infection labels exist.",
                    listOf("skin", "allergen", "patch test", "IL-1", "control", "outcome")
                )
            }
            if (text.contains("stress", true) || text.contains("sleep", true) || text.contains("cortisol", true)) {
                addRoute(
                    "psychoneuroimmune_context_modifier",
                    "Treat stress/sleep/autonomic signals as context modifiers, not primary immune-cause proof.",
                    listOf("stress", "sleep", "time order", "immune marker", "context", "outcome")
                )
            }

            sessionManager.updatePhaseProgress(phase, 100, 1, 1)
            progressBroadcaster.broadcastPhaseComplete(phase, "${routes.length()} route proposals generated")
            JSONObject()
                .put("proposedRoutes", routes)
                .put("claimLimit", "proposed_not_validated")
        }.getOrElse { error ->
            sessionManager.updatePhaseProgress(phase, 0, error = error.message)
            null
        }
    }

    // ========== PHASE 4: Blind Spot Finding ==========
    private fun executePhase4BlindSpotFinding(
        reportHistory: List<ResearchReportV3>,
        shouldStop: () -> Boolean
    ): JSONObject? {
        val phase = "BLIND_SPOT_FINDING"
        sessionManager.updatePhaseProgress(phase, 20)
        broadcast(phase, "Checking blind spots and claim risks...")

        return runCatching {
            if (shouldStop()) return@runCatching null
            val blindSpots = JSONArray()
            val routeDistribution = reportHistory
                .flatMap { extractSignals(it) }
                .groupingBy { it.route }
                .eachCount()
            val dominant = routeDistribution.maxByOrNull { it.value }
            if (dominant != null && dominant.key != "unknown" && dominant.value >= (reportHistory.size * 0.7).toInt().coerceAtLeast(2)) {
                blindSpots.put(JSONObject().apply {
                    put("type", "route_bias")
                    put("description", "Route '${dominant.key}' dominates recent hypothesis summaries.")
                    put("riskLevel", "watch")
                    put("action", "Force at least one contrastive query outside the dominant route.")
                })
            }
            val combined = reportHistory.joinToString(" ") { it.hypothesis + " " + it.supportingEvidence + " " + it.doNotBelieveYet }
            if (combined.contains("inflammation", true) && !combined.contains("trigger", true)) {
                blindSpots.put(JSONObject().apply {
                    put("type", "generic_inflammation_overreach")
                    put("description", "Inflammation appears without enough trigger/outcome context.")
                    put("riskLevel", "high")
                    put("action", "Require trigger, time-course, tissue context, and outcome labels before route upgrade.")
                })
            }
            if (combined.contains("ML", true) && !combined.contains("triage", true)) {
                blindSpots.put(JSONObject().apply {
                    put("type", "ml_claim_drift")
                    put("description", "ML wording may drift beyond triage/routing.")
                    put("riskLevel", "high")
                    put("action", "Keep claim limit: ML ranks the hunt; evidence gates the belief.")
                })
            }

            sessionManager.updatePhaseProgress(phase, 100, 1, 1)
            progressBroadcaster.broadcastPhaseComplete(phase, "${blindSpots.length()} blind spots identified")
            JSONObject()
                .put("blindSpots", blindSpots)
                .put("claimLimit", "research_guidance_not_proof")
        }.getOrElse { error ->
            sessionManager.updatePhaseProgress(phase, 0, error = error.message)
            null
        }
    }

    private data class HypothesisSignal(
        val id: String,
        val label: String,
        val route: String,
        val score: Int
    )

    private fun extractSignals(report: ResearchReportV3): List<HypothesisSignal> {
        val raw = listOf(report.hypothesis, report.hypothesisChanged, report.newUsefulLead)
            .filter { it.isNotBlank() && it != "None" && it != "No hypothesis evaluated yet." }
        return raw.map { text ->
            HypothesisSignal(
                id = stableId(text),
                label = text.take(120),
                route = inferRoute(text),
                score = if (report.integrityStatus == "PASS") 60 else 40
            )
        }.distinctBy { it.id }
    }

    private fun inferRoute(text: String): String {
        val lower = text.lowercase()
        return when {
            listOf("viral", "interferon", "ifn", "antiviral", "infection").any { lower.contains(it) } -> "antiviral_interferon_timing"
            listOf("allergy", "allergen", "nickel", "skin", "anakinra", "ige", "type-2", "type 2").any { lower.contains(it) } -> "allergy_contact_dermatitis_il1_skin"
            listOf("stress", "sleep", "cortisol", "autonomic", "hpa").any { lower.contains(it) } -> "psychoneuroimmune_context"
            listOf("rna", "transcript", "single-cell", "scrna").any { lower.contains(it) } -> "rna_transcriptomic_state"
            listOf("inflammation", "il-6", "tnf", "cytokine").any { lower.contains(it) } -> "generic_inflammation_context"
            else -> "unknown"
        }
    }

    private fun stableId(text: String): String = text.lowercase()
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .take(80)
        .ifBlank { "hyp_${text.hashCode()}" }

    private fun jsonObjects(array: JSONArray?): List<JSONObject> {
        if (array == null) return emptyList()
        val out = mutableListOf<JSONObject>()
        repeat(array.length()) { idx -> array.optJSONObject(idx)?.let { out.add(it) } }
        return out
    }

    private fun strings(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        val out = mutableListOf<String>()
        repeat(array.length()) { idx ->
            val value = array.optString(idx, "").trim()
            if (value.isNotBlank()) out.add(value)
        }
        return out
    }

    private fun broadcast(phase: String, message: String) {
        progressBroadcaster.broadcastProgress(
            ProgressTracker.generateProgressUpdate(
                sessionManager.getCurrentSession() ?: return,
                currentTask = message,
                phaseFindings = mapOf(phase to message)
            )
        )
    }
}
