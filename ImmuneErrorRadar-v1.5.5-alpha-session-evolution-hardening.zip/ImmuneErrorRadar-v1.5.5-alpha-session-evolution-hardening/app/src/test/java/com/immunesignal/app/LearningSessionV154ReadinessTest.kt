package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningSessionV154ReadinessTest {
    @Test
    fun runtimeFlagsExposeStableSessionSchema() {
        assertEquals("1.5.4", RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION)
        assertTrue(RuntimeFeatureFlags.ENABLE_LEARNING_SESSION_UI)
        assertEquals("learning_session_not_biological_proof", RuntimeFeatureFlags.LEARNING_SESSION_CLAIM_LIMIT)
    }

    @Test
    fun uiReportUsesActualSessionTimeLimit() {
        val session = LearningSession(
            sessionId = "session_limit_test",
            sessionType = SessionType.INCREMENTAL,
            startedAt = 1000L,
            status = SessionStatus.PAUSED,
            timeLimit = 20L * 60L * 1000L,
            phases = LearningSessionIntegrityGuard.expectedPhaseNames.map { PhaseState(it, PhaseStatus.PENDING, 0) },
            checkpoint = SessionCheckpoint(null, null, LearningSessionIntegrityGuard.expectedPhaseNames, true, 2000L),
            claimLimits = emptyMap(),
            accumulatedTimeUsed = 0L
        )

        val report = ProgressTracker.generateUIReport(session)
        assertTrue(report.contains("Limit: 20m 0s"))
    }
}
