#!/usr/bin/env python3
from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = root / 'app/src/main/java/com/immunesignal/app/MainActivity.kt'
text = main.read_text(encoding='utf-8')
required = [
    'buildStableLauncher()',
    'setContentView(buildStableLauncher())',
    'Start GTIM Research',
    'Open Saved Reports',
    'Research leads only. Full technical details stay in Export.',
]
missing = [x for x in required if x not in text]
forbidden = [
    'setContentView(R.layout.activity_main)',
    'findViewById<TextView>(R.id.engineVersionText).text',
]
violations = [x for x in forbidden if x in text]
if missing or violations:
    raise SystemExit('Launcher safe-start audit failed. missing=%r violations=%r' % (missing, violations))
print('Launcher safe-start v2.6.3 audit: PASS')
