#!/usr/bin/env python3
from pathlib import Path

ROOT = Path('.')
VERSION = '2.6.8-final-unified-route-learning-closure'
ENGINE = 'GTIM-Engine v2.6.8'

def read(path):
    return (ROOT / path).read_text(errors='replace')

def require(path, tokens):
    text = read(path)
    missing = [t for t in tokens if t not in text]
    if missing:
        raise SystemExit(f'{path}: missing ' + ', '.join(missing))

require('app/build.gradle.kts', ['versionCode = 144', f'versionName = "{VERSION}"', 'compileSdk = 35', 'targetSdk = 35'])
require('app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt', [
    f'RELEASE_TRAIN_VERSION_NAME: String = "{VERSION}"',
    'RELEASE_TRAIN_VERSION_CODE: Int = 144',
    'LEARNING_SESSION_SCHEMA_VERSION: String = "2.6.8"',
    'MAX_HYPOTHESIS_RANK_CARDS',
    'ENABLE_LEARNING_LOOP_ACTIVATION_V262'
])
require('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt', [f'ACTIVE_ENGINE_VERSION = "v{VERSION}"'])
require('app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt', [
    'VERSION_CODE: Int = 144',
    f'VERSION_NAME: String = "{VERSION}"',
    f'ENGINE_VERSION: String = "v{VERSION}"',
    'LEARNING_SCHEMA_VERSION: String = "2.6.8"'
])
for file, tokens in {
    'app/src/main/java/com/immunesignal/app/AutonomousStagnationEngine.kt': ['realPivot', 'pivotType != "NO_PIVOT"'],
    'app/src/main/java/com/immunesignal/app/QueryPlanner.kt': ['stagnationPivot', 'ANTI_STAGNATION'],
    'app/src/main/java/com/immunesignal/app/HypothesisRankingEngine.kt': ['ResearchPolicyLock.STRONG_SIGNAL_CAUSALITY_THRESHOLD', 'MAX_HYPOTHESIS_RANK_CARDS'],
    'app/src/main/java/com/immunesignal/app/SourcePriorityArbitrationPolicy.kt': ['return (repairedCore + secondary + archive)', 'distinctBy'],
    'app/src/main/java/com/immunesignal/app/AdaptiveQueryEvolution.kt': ['if (current == "BROAD") "MECHANISM" else "CONTRADICTION"'],
    'app/src/main/java/com/immunesignal/app/LearningDeltaEngine.kt': ['stable_no_change', 'MAX_LEARNING_DELTA_CARDS'],
    'app/src/main/java/com/immunesignal/app/EpistemicBeliefEngine.kt': ['capBeliefs', 'MAX_EPISTEMIC_BELIEFS_PER_REPORT'],
    'app/src/main/java/com/immunesignal/app/LearningRuleEngine.kt': ['learning_rules_route_only_not_biological_proof', 'MIN_LEARNING_RULE_COVERAGE'],
    'app/src/main/java/com/immunesignal/app/DatasetQueryCompiler.kt': ['domainVocabulary', 'domainBoost'],
    'app/src/main/java/com/immunesignal/app/RouteFingerprintGuard.kt': ['ROUTE_FINGERPRINT_LOOKBACK', 'route_fingerprint_not_biological_proof'],
    'app/src/main/java/com/immunesignal/app/KnowledgeGapTaskScheduler.kt': ['KnowledgeGapTask', 'knowledge_gap_task_routing_only_not_biological_proof'],
    'app/src/main/java/com/immunesignal/app/DynamicPlausibilityGraphLearner.kt': ['PROPOSED_EDGE_NEEDS_VALIDATION'],
    'app/src/main/java/com/immunesignal/app/HypothesisSplitMergeAdvisor.kt': ['SPLIT_SUGGESTED', 'MERGE_CANDIDATE_REQUIRES_PARENT_EVIDENCE'],
    'app/src/main/java/com/immunesignal/app/ContradictionFinder.kt': ['ContradictionTemplate', 'diabetes_metabolic_inflammation'],
    'app/src/main/java/com/immunesignal/app/AxisPerformanceLearningV262.kt': ['AxisPerformanceRecordV262', 'axis_performance_routing_only_not_biological_proof'],
    'app/src/main/java/com/immunesignal/app/BayesianBeliefRevisionV262.kt': ['BayesianBeliefRevisionCardV262', 'posteriorProbability', 'bayesian_belief_revision_research_prior_only_not_biological_proof'],
    'app/src/main/java/com/immunesignal/app/EpistemicDistanceMeterV262.kt': ['EpistemicDistanceReportV262', 'epistemic_distance_progress_metric_not_biological_proof'],
    'app/src/main/java/com/immunesignal/app/LearningLoopActivationV262.kt': ['LearningLoopActivationReportV262', 'LearningLoopActivationV262.build', 'learning_loop_activation_routing_only_not_biological_proof'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['learningLoopActivationReportV262', 'v2.6.8 learning loop activation']
}.items():
    require(file, tokens)
require('app/src/main/assets/biological_plausibility_graph_v0.2.json', ['interferon_antiviral_axis', 'tcell_activation_axis'])
require('app/src/main/assets/learning_rules_v0.2.json', ['required_signals', 'confidence_policy'])
require('app/src/main/assets/contradiction_templates_v1.10.21.json', ['contradiction_templates_v1.10.21'])
require('app/src/test/java/com/immunesignal/app/LearningLoopActivationV262Test.kt', ['learningLoopActivationClosesRulesGapsEdgesAndDistance', 'bayesianBeliefRevisionStaysResearchPriorOnly'])
require('docs/GTIM_LEARNING_LOOP_ACTIVATION_v2.6.2.md', ['Learning Loop Activation v2.6.2', 'Discovery = flexible', 'Evidence upgrade = strict'])
manifest = read('app/src/main/AndroidManifest.xml')
for forbidden in ['QUERY_ALL_PACKAGES', 'READ_SMS', 'READ_CONTACTS', 'ACCESS_FINE_LOCATION', 'RECORD_AUDIO', 'CAMERA']:
    if forbidden in manifest:
        raise SystemExit(f'Forbidden Google Play-sensitive permission still present: {forbidden}')
print('GTIM v2.6.8 learning-loop continuity audit: PASS')
