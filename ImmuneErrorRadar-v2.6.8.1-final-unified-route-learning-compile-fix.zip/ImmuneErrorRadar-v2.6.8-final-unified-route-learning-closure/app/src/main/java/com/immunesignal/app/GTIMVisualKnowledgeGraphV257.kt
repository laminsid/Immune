package com.immunesignal.app

/** Graph-ready surface for future interactive visualization. */
data class GTIMVisualKnowledgeGraphReportV257(
    val active: Boolean,
    val version: String,
    val status: String,
    val nodes: List<GTIMGraphNodeV257>,
    val edges: List<GTIMGraphEdgeV257>,
    val views: List<String>,
    val edgeLegend: List<String>,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty() = GTIMVisualKnowledgeGraphReportV257(
            active = false,
            version = GTIMVisualKnowledgeGraphV257.VERSION,
            status = "GTIM_VISUAL_KNOWLEDGE_GRAPH_IDLE",
            nodes = emptyList(),
            edges = emptyList(),
            views = GTIMVisualKnowledgeGraphV257.VIEWS,
            edgeLegend = GTIMVisualKnowledgeGraphV257.EDGE_LEGEND
        )
    }
}

object GTIMVisualKnowledgeGraphV257 {
    const val VERSION: String = "2.6.8-final-unified-route-learning-closure"
    val VIEWS = listOf("Discovery view", "Evidence view", "Contradiction view", "Technical appendix")
    val EDGE_LEGEND = listOf("direct evidence", "indirect support", "plausible bridge", "speculative bridge", "contradiction", "missing evidence")

    fun build(
        intent: GTIMResearchIntentObjectV255,
        split: GTIMDiscoveryEvidenceSplitReportV256,
        dashboard: GTIMProfessorDiscoveryDashboardReportV257
    ): GTIMVisualKnowledgeGraphReportV257 {
        val nodes = dashboard.graphNodes.ifEmpty { fallbackNodes(intent, split) }
        val edges = dashboard.graphEdges.ifEmpty { fallbackEdges(nodes) }
        return GTIMVisualKnowledgeGraphReportV257(
            active = nodes.isNotEmpty(),
            version = VERSION,
            status = if (nodes.isNotEmpty()) "GTIM_VISUAL_KNOWLEDGE_GRAPH_READY" else "GTIM_VISUAL_KNOWLEDGE_GRAPH_WAITING_FOR_INTENT",
            nodes = nodes.take(24),
            edges = edges.take(24),
            views = VIEWS,
            edgeLegend = EDGE_LEGEND
        )
    }

    private fun fallbackNodes(intent: GTIMResearchIntentObjectV255, split: GTIMDiscoveryEvidenceSplitReportV256): List<GTIMGraphNodeV257> {
        val terms = mutableListOf<Pair<String, String>>()
        terms += intent.triggerExposure.take(4).map { "trigger" to it }
        terms += intent.diseasePhenotype.take(4).map { "phenotype" to it }
        terms += intent.pathway.take(6).map { "pathway" to it }
        terms += intent.cellTissue.take(5).map { "cell_tissue" to it }
        terms += split.candidateRoutes.firstOrNull()?.cascade.orEmpty().take(6).map { "route_node" to it }
        return terms.distinctBy { it.second.lowercase() }.mapIndexed { index, pair ->
            GTIMGraphNodeV257("GTIM_VIS_NODE_${index + 1}", pair.second, pair.first, "DISCOVERY_NODE_NOT_CONFIRMED_EVIDENCE")
        }
    }

    private fun fallbackEdges(nodes: List<GTIMGraphNodeV257>): List<GTIMGraphEdgeV257> =
        (0 until minOf(nodes.size - 1, 8)).map { idx ->
            GTIMGraphEdgeV257(nodes[idx].nodeId, nodes[idx + 1].nodeId, "graph_ready_visual_bridge", "PLAUSIBILITY_ONLY_NOT_EVIDENCE")
        }
}
