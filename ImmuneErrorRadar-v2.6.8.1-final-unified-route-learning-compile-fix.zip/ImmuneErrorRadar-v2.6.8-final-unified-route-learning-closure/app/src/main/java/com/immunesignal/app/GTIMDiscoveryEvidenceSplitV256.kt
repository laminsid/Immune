package com.immunesignal.app

/**
 * GTIM v2.5.6 Discovery/Evidence split.
 *
 * Lets discovery remain creative while evidence upgrade remains gated. Semantic priors are never
 * expression matrices, and lab protocols are drafts, not validation or medical instructions.
 */
data class GTIMThreeDimensionalScoreV256(
    val dataQualityScore: Int,
    val noveltyScore: Int,
    val biologicalPlausibilityScore: Int,
    val discoveryValueScore: Int,
    val evidenceConfidenceScore: Int,
    val interpretation: String, // Data Quality / Novelty / Biological Plausibility are separated,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMCandidateRouteV256(
    val routeId: String,
    val status: String,
    val cascade: List<String>,
    val routeConstructionScore: Int,
    val evidenceState: String,
    val missingEvidence: List<String>,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMSemanticMechanismPriorV256(
    val active: Boolean,
    val status: String,
    val priorType: String,
    val suggestedGenesOrPathways: List<String>,
    val usesAllowed: List<String>,
    val forbiddenUses: List<String>,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMContradictionEngineReportV256(
    val active: Boolean,
    val status: String,
    val supportQueries: List<String>,
    val contradictionQueries: List<String>,
    val nullResultTargets: List<String>,
    val interpretationRule: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMPreliminaryLabProtocolDraftV256(
    val active: Boolean,
    val status: String,
    val hypothesis: String,
    val suggestedValidationDesign: List<String>,
    val positiveControl: String,
    val negativeControl: String,
    val expectedDirection: String,
    val falsificationCondition: String,
    val minimumEvidenceBeforeClaim: List<String>,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMDiscoveryEvidenceSplitReportV256(
    val active: Boolean,
    val version: String,
    val state: String,
    val principle: String,
    val threeDimensionalScore: GTIMThreeDimensionalScoreV256,
    val candidateRoutes: List<GTIMCandidateRouteV256>,
    val semanticMechanismPrior: GTIMSemanticMechanismPriorV256,
    val activeContradictionEngine: GTIMContradictionEngineReportV256,
    val preliminaryLabProtocol: GTIMPreliminaryLabProtocolDraftV256,
    val discoveryAllowed: List<String>,
    val evidenceUpgradeStillLocked: List<String>,
    val playProtectPosture: String,
    val githubPosture: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty() = GTIMDiscoveryEvidenceSplitReportV256(
            active = false,
            version = GTIMDiscoveryEvidenceSplitV256.VERSION,
            state = "GTIM_DISCOVERY_EVIDENCE_SPLIT_IDLE",
            principle = GTIMDiscoveryEvidenceSplitV256.PRINCIPLE,
            threeDimensionalScore = GTIMThreeDimensionalScoreV256(0, 0, 0, 0, 0, "not evaluated"),
            candidateRoutes = emptyList(),
            semanticMechanismPrior = GTIMSemanticMechanismPriorV256(false, "SEMANTIC_PRIOR_NOT_EVALUATED", "SEMANTIC_PRIOR_NOT_MATRIX", emptyList(), emptyList(), listOf("fold-change", "p-value", "DGE result")),
            activeContradictionEngine = GTIMContradictionEngineReportV256(false, "CONTRADICTION_ENGINE_NOT_EVALUATED", emptyList(), emptyList(), emptyList(), "not evaluated"),
            preliminaryLabProtocol = GTIMPreliminaryLabProtocolDraftV256(false, "LAB_PROTOCOL_DRAFT_NOT_EVALUATED", "", emptyList(), "", "", "", "", emptyList()),
            discoveryAllowed = emptyList(),
            evidenceUpgradeStillLocked = GTIMRelaxedExplorationPolicyV253.CLAIMS_STILL_BLOCKED,
            playProtectPosture = "not evaluated",
            githubPosture = "not evaluated"
        )
    }
}

object GTIMDiscoveryEvidenceSplitV256 {
    const val VERSION: String = "2.6.8-final-unified-route-learning-closure"
    const val PRINCIPLE: String = "Discovery is flexible; evidence upgrade is strict; clinical claims are forbidden."

    fun evaluate(
        intent: GTIMResearchIntentObjectV255,
        plan: GTIMDataFeedPlanV255,
        report: ResearchGradeMechanismDossierReportV1110,
        evidenceObjects: List<GTIMEvidenceObjectV250>,
        mechanismCandidates: List<GTIMMechanismCandidateV250>
    ): GTIMDiscoveryEvidenceSplitReportV256 {
        if (!intent.active && !report.active) return GTIMDiscoveryEvidenceSplitReportV256.empty()
        val routes = candidateRoutes(intent, report, mechanismCandidates)
        val score = GTIMThreeDimensionalScoringV256.score(intent, plan, report, evidenceObjects, mechanismCandidates, routes)
        val semanticPrior = GTIMSemanticMechanismPriorEngineV256.build(intent, routes)
        val contradiction = GTIMActiveContradictionEngineV256.search(intent, plan, routes)
        val labDraft = GTIMPreliminaryLabProtocolGeneratorV256.draft(intent, routes, mechanismCandidates)
        return GTIMDiscoveryEvidenceSplitReportV256(
            active = true,
            version = VERSION,
            state = "DISCOVERY_LAYER_ACTIVE_EVIDENCE_LAYER_GATED",
            principle = PRINCIPLE,
            threeDimensionalScore = score,
            candidateRoutes = routes,
            semanticMechanismPrior = semanticPrior,
            activeContradictionEngine = contradiction,
            preliminaryLabProtocol = labDraft,
            discoveryAllowed = listOf(
                "candidate routes without accession",
                "repository query plans without confirmed matrix",
                "semantic mechanism priors as plausibility only",
                "contradiction/null-result search without suppressing weak-lead display",
                "preliminary lab protocol drafts for hypothesis design"
            ),
            evidenceUpgradeStillLocked = listOf(
                "Candidate route ≠ evidence object",
                "Research lead ≠ confirmed accession",
                "Text-mined signal ≠ matrix-ready dataset",
                "Open discovery route ≠ biological claim",
                "Semantic prior ≠ expression matrix",
                "Cross-species support ≠ human confirmation"
            ) + GTIMRelaxedExplorationPolicyV253.CLAIMS_STILL_BLOCKED,
            playProtectPosture = "No hidden background scraping, no patient data upload, no tracking, no clinical decision; public data lookup remains user-triggered.",
            githubPosture = "Discovery/evidence split is deterministic, JSON-visible, brief-visible, and covered by static audit."
        )
    }

    private fun candidateRoutes(
        intent: GTIMResearchIntentObjectV255,
        report: ResearchGradeMechanismDossierReportV1110,
        mechanismCandidates: List<GTIMMechanismCandidateV250>
    ): List<GTIMCandidateRouteV256> {
        val fromGtim = mechanismCandidates.mapIndexed { idx, candidate ->
            GTIMCandidateRouteV256(
                routeId = "GTIM_ROUTE_${idx + 1}",
                status = "EXPLORATORY_ROUTE_NOT_EVIDENCE",
                cascade = candidate.mechanismCascade.ifEmpty { listOf(candidate.targetAxis) },
                routeConstructionScore = candidate.confidenceIndex.score.coerceIn(5, 86),
                evidenceState = candidate.evidenceGrade,
                missingEvidence = candidate.whatWouldFalsify.ifEmpty { report.blockingGaps }.take(8)
            )
        }
        val fromIntent = if (fromGtim.isEmpty() && intent.active) buildIntentRoutes(intent, report) else emptyList()
        return (fromGtim + fromIntent).take(8)
    }

    private fun buildIntentRoutes(intent: GTIMResearchIntentObjectV255, report: ResearchGradeMechanismDossierReportV1110): List<GTIMCandidateRouteV256> {
        val triggers = intent.triggerExposure.ifEmpty { listOf("unknown trigger") }.take(3)
        val diseases = intent.diseasePhenotype.ifEmpty { listOf("target phenotype") }.take(3)
        val pathways = intent.pathway.ifEmpty { listOf("immune pathway") }.take(4)
        val cells = intent.cellTissue.ifEmpty { listOf("immune cell context") }.take(3)
        val routes = mutableListOf<GTIMCandidateRouteV256>()
        var idx = 1
        for (trigger in triggers) {
            val disease = diseases[(idx - 1) % diseases.size]
            val pathway = pathways[(idx - 1) % pathways.size]
            val cell = cells[(idx - 1) % cells.size]
            routes += GTIMCandidateRouteV256(
                routeId = "INTENT_ROUTE_$idx",
                status = "EXPLORATORY_ROUTE_NOT_EVIDENCE",
                cascade = listOf(trigger, pathway, cell, disease),
                routeConstructionScore = intent.routeConstructionScore.coerceAtLeast(25),
                evidenceState = "CANDIDATE_ROUTE_WITHOUT_EVIDENCE_OBJECT",
                missingEvidence = report.blockingGaps.ifEmpty { listOf("accession", "comparator", "matrix", "metadata", "contradiction closure") }.take(8)
            )
            idx += 1
        }
        return routes
    }

    private fun threeDimensionalScore(
        intent: GTIMResearchIntentObjectV255,
        plan: GTIMDataFeedPlanV255,
        report: ResearchGradeMechanismDossierReportV1110,
        evidenceObjects: List<GTIMEvidenceObjectV250>,
        mechanismCandidates: List<GTIMMechanismCandidateV250>,
        routes: List<GTIMCandidateRouteV256>
    ): GTIMThreeDimensionalScoreV256 {
        val dataQuality = (report.matrixReadinessScore + evidenceObjects.size * 8 + report.accessionCandidates.size * 15).coerceIn(0, 100)
        val novelty = (45 + routes.size * 6 + if (intent.active) intent.intentCompletenessScore / 5 else 0).coerceIn(0, 88)
        val plausibility = (intent.routeConstructionScore / 2 + routes.size * 8 + mechanismCandidates.size * 4).coerceIn(0, 86)
        val discoveryValue = ((novelty * 0.35) + (plausibility * 0.35) + (intent.intentCompletenessScore * 0.20) + (plan.dataFeedPlanScore * 0.10)).toInt().coerceIn(0, 90)
        val evidenceConfidence = (dataQuality * 0.65 + report.matrixReadinessScore * 0.35).toInt().coerceIn(0, 86)
        val interpretation = when {
            dataQuality < 20 && discoveryValue >= 55 -> "weak evidence, useful discovery route"
            dataQuality >= 60 -> "evidence route approaching controlled review"
            discoveryValue >= 45 -> "exploratory hypothesis worth feeding with stronger data"
            else -> "early exploratory lead; keep only if scientifically interesting"
        }
        return GTIMThreeDimensionalScoreV256(dataQuality, novelty, plausibility, discoveryValue, evidenceConfidence, interpretation)
    }

    private fun semanticPrior(intent: GTIMResearchIntentObjectV255, routes: List<GTIMCandidateRouteV256>): GTIMSemanticMechanismPriorV256 {
        val nodes = (intent.pathway + intent.cellTissue + routes.flatMap { it.cascade }).distinct().take(16)
        return GTIMSemanticMechanismPriorV256(
            active = nodes.isNotEmpty(),
            status = "SEMANTIC_PRIOR_NOT_MATRIX",
            priorType = "Pathway Prior Map",
            suggestedGenesOrPathways = nodes,
            usesAllowed = listOf("route plausibility", "dataset query guidance", "gene/pathway shortlist", "lab hypothesis design"),
            forbiddenUses = listOf("fold-change", "p-value", "DGE result", "confirmed expression matrix", "clinical claim")
        )
    }

    private fun contradictionReport(
        intent: GTIMResearchIntentObjectV255,
        plan: GTIMDataFeedPlanV255,
        routes: List<GTIMCandidateRouteV256>
    ): GTIMContradictionEngineReportV256 {
        val base = (intent.triggerExposure + intent.diseasePhenotype + intent.pathway).take(8).joinToString(" OR ").ifBlank { "immune mechanism" }
        val contradictionQueries = plan.contradictionTargets.take(6).map { target -> "($base) AND \"$target\"" }
        return GTIMContradictionEngineReportV256(
            active = true,
            status = "ACTIVE_CONTRADICTION_ENGINE_READY",
            supportQueries = routes.take(4).map { it.cascade.joinToString(" AND ") },
            contradictionQueries = contradictionQueries,
            nullResultTargets = plan.contradictionTargets.ifEmpty { listOf("null result", "no association", "opposite direction") },
            interpretationRule = "Attach opposing/null evidence to the route; do not suppress weak-lead display; do not upgrade while contradiction gaps are open."
        )
    }

    private fun labProtocol(
        intent: GTIMResearchIntentObjectV255,
        routes: List<GTIMCandidateRouteV256>,
        mechanismCandidates: List<GTIMMechanismCandidateV250>
    ): GTIMPreliminaryLabProtocolDraftV256 {
        val hypothesis = routes.firstOrNull()?.cascade?.joinToString(" → ")
            ?: mechanismCandidates.firstOrNull()?.targetAxis
            ?: "candidate immune mechanism"
        val cells = intent.cellTissue.ifEmpty { listOf("PBMC", "T cells", "B cells", "monocytes") }.take(4)
        val assays = intent.assayType.ifEmpty { listOf("qPCR", "flow cytometry", "cytokine panel", "RNA-seq/scRNA-seq") }.take(5)
        return GTIMPreliminaryLabProtocolDraftV256(
            active = true,
            status = "LAB_PROTOCOL_DRAFT_NOT_VALIDATION",
            hypothesis = hypothesis,
            suggestedValidationDesign = listOf(
                "Define cohort/groups from comparator intent: ${intent.comparatorWanted.joinToString(", ").ifBlank { "case vs matched/recovered/healthy controls" }}",
                "Use cell/tissue context: ${cells.joinToString(", ")}",
                "Run assays: ${assays.joinToString(", ")}",
                "Measure pathway markers: ${intent.pathway.take(6).joinToString(", ").ifBlank { "interferon/cytokine/cell-state markers" }}",
                "Pre-register falsification rule before interpreting any signal"
            ),
            positiveControl = "known stimulated immune-response or disease-relevant positive control defined by the lab",
            negativeControl = "healthy/matched baseline control and technical no-template/isotype controls where applicable",
            expectedDirection = "direction must be derived from real matrix/assay data; do not infer fold-change from semantic prior",
            falsificationCondition = "no reproducible difference across comparator groups, opposite biomarker direction, or failure under independent cohort/assay replication",
            minimumEvidenceBeforeClaim = listOf("accession or protocol source", "sample count", "biospecimen", "comparator", "matrix/assay data", "contradiction review")
        )
    }
}
