package com.immunesignal.app

/**
 * v2.6.8: final unified route-learning closure.
 *
 * Verifies that the exploratory route stack is connected from intent parsing through
 * planner, public lookup/seed bootstrap, comparative disease paths, exposome bridges,
 * and learning-loop activation. This is a routing/learning integrity check only; it
 * does not relax biological claim gates.
 */
data class GTIMUnifiedRouteLearningClosureReportV268(
    val active: Boolean,
    val versionName: String,
    val engineVersion: String,
    val learningSchemaVersion: String,
    val versionUnified: Boolean,
    val parserLinked: Boolean,
    val plannerLinked: Boolean,
    val europePmcLinked: Boolean,
    val openAlexLinked: Boolean,
    val seedBootstrapLinked: Boolean,
    val comparativeLinked: Boolean,
    val exposomeLinked: Boolean,
    val learningLoopLinked: Boolean,
    val claimGuardLinked: Boolean,
    val closureState: String,
    val nextAction: String,
    val claimLimit: String = GTIMUnifiedRouteLearningClosureV268.CLAIM_LIMIT
)

object GTIMUnifiedRouteLearningClosureV268 {
    const val VERSION: String = "2.6.8-final-unified-route-learning-closure"
    const val CLAIM_LIMIT: String = "route_learning_closure_integrity_only_not_biological_proof"

    fun verify(question: String): GTIMUnifiedRouteLearningClosureReportV268 {
        val intent = GTIMResearchIntentParserV255.parse(question)
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        val trace = GTIMExploratoryRouteLinkageV266.trace(question)
        val versionUnified = RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == ReleaseVersionLinkageGuard.VERSION_NAME &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == ReleaseVersionLinkageGuard.VERSION_CODE &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == ReleaseVersionLinkageGuard.LEARNING_SCHEMA_VERSION &&
            EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ReleaseVersionLinkageGuard.ENGINE_VERSION &&
            ReleaseVersionLinkageGuard.VERSION_NAME == VERSION
        val claimGuardLinked = GTIMClaimGuardV250.ENGINE_IDENTITY.contains("v2.6.8") &&
            GTIMClaimGuardV250.CLAIM_BOUNDARY.contains("not_diagnosis") &&
            GTIMClaimGuardV250.CLAIM_BOUNDARY.contains("not_treatment")
        val learningLinked = RuntimeFeatureFlags.ENABLE_LEARNING_LOOP_ACTIVATION_V262 &&
            LearningLoopActivationV262.CLAIM_LIMIT.contains("not_biological_proof")
        val ok = versionUnified && intent.active && plan.active && trace.active &&
            trace.europePmcLinked && trace.openAlexLinked && trace.seedBootstrapLinked &&
            trace.comparativeLinked && trace.exposomeLinked && learningLinked && claimGuardLinked
        return GTIMUnifiedRouteLearningClosureReportV268(
            active = ok,
            versionName = RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME,
            engineVersion = EngineRuntimeStatus.ACTIVE_ENGINE_VERSION,
            learningSchemaVersion = RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION,
            versionUnified = versionUnified,
            parserLinked = intent.active,
            plannerLinked = plan.active,
            europePmcLinked = trace.europePmcLinked,
            openAlexLinked = trace.openAlexLinked,
            seedBootstrapLinked = trace.seedBootstrapLinked,
            comparativeLinked = trace.comparativeLinked,
            exposomeLinked = trace.exposomeLinked,
            learningLoopLinked = learningLinked,
            claimGuardLinked = claimGuardLinked,
            closureState = if (ok) "UNIFIED_ROUTE_LEARNING_CYCLE_CLOSED" else "UNIFIED_ROUTE_LEARNING_CYCLE_INCOMPLETE",
            nextAction = if (ok) "Run GitHub Gradle test/build; route-learning closure is connected and version-unified." else "Repair version, route, learning-loop, or claim-guard linkage before final closure."
        )
    }
}
