package com.immunesignal.app

import java.util.Locale

/**
 * v1.11.5 graded exploratory research results + GTIM v2.5 global hypothesis dossier surface.
 * Keeps v1.11.0 dossier logic, rejects MANUAL_TEXT_SNIPPET pseudo-accessions as confirmed
 * accessions, adds validation/comparator/evidence-object gates, and now adapts the same path
 * into a global translational immunology discovery dossier without creating isolated islands.
 *
 * v1.11.0: Research-grade Mechanism Discovery Dossier Engine.
 * v1.11.5: emits graded research leads even when EvidenceObject is blocked, so
 * users receive useful in-progress biological research directions without false proof.
 *
 * This layer moves the system from accession foraging to translational evidence mapping.
 * It never performs diagnosis, patient prediction, treatment advice, drug/supplement
 * ranking, differential expression claims, fold-change claims, p-values, or clinical
 * utility claims. It only asks whether a captured GEO/SRA-style dataset is structurally
 * ready for controlled mechanism analysis. Never invent accession IDs, sample labels,
 * gene-expression results, fold-changes, p-values, cytokine effects, or predictions.
 */
data class AccessionCandidateCardV1110(
    val accessionId: String,
    val repository: String,
    val titleOrSnippet: String,
    val organism: String,
    val cohortType: String,
    val assayPlatform: String,
    val sampleCount: String,
    val sampleGroupLabels: List<String>,
    val controlComparatorLabels: List<String>,
    val caseLabels: List<String>,
    val timepoints: List<String>,
    val tissueOrCellContext: String,
    val matrixAvailability: String,
    val metadataAvailability: String,
    val dataAccessLicenseStatus: String,
    val blockingGaps: List<String>,
    val dgeReadinessState: String,
    val evidenceObjectGate: String,
    val accessionStatus: String = "CONFIRMED_ACCESSION",
    val sourceMetadataStatus: String = "SOURCE_METADATA_UNVERIFIED",
    val sampleIds: List<String> = emptyList(),
    val matrixFileHints: List<String> = emptyList(),
    val metadataFileHints: List<String> = emptyList(),
    val repositoryLookupQuery: String = "",
    val sourceSpecificParser: String = "GENERIC_ACCESSION_METADATA_PARSER",
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
)

data class ComparatorMappingCardV1110(
    val accessionId: String,
    val status: String,
    val healthyControl: List<String>,
    val matchedControl: List<String>,
    val baseline: List<String>,
    val placebo: List<String>,
    val responder: List<String>,
    val nonResponder: List<String>,
    val caseLabel: List<String>,
    val exposedUnexposed: List<String>,
    val negativeControl: List<String>,
    val unknown: List<String>,
    val gate: String,
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
)

data class SourceMetadataEnrichmentCardV1113(
    val sourceId: String,
    val sourceFamily: String,
    val sourceKind: String,
    val sourceStatus: String,
    val detectedAccessions: List<String>,
    val accessionResolutionState: String,
    val accessionPatternQuery: String,
    val comparatorTokens: List<String>,
    val matrixFileHints: List<String>,
    val metadataFileHints: List<String>,
    val sampleCountHints: List<String>,
    val parser: String,
    val nextAction: String,
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
)

data class AccessionValidationCardV1114(
    val accessionId: String,
    val repository: String,
    val validationState: String,
    val handleType: String,
    val sourceSpecificParser: String,
    val repositoryLookupQuery: String,
    val metadataExtractionCommand: String,
    val comparatorExtractionState: String,
    val matrixReadinessState: String,
    val evidenceObjectCreationGate: String,
    val blockingGaps: List<String>,
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
)

data class ComparatorExtractionCardV1114(
    val accessionId: String,
    val extractionState: String,
    val extractedLabels: List<String>,
    val controlSignals: List<String>,
    val caseSignals: List<String>,
    val baselineSignals: List<String>,
    val responderSignals: List<String>,
    val negativeControlSignals: List<String>,
    val comparatorConfidence: Int,
    val evidenceObjectGate: String,
    val nextAction: String,
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
)

data class ExploratoryResearchLeadV1115(
    val leadId: String,
    val status: String,
    val confidence: Int,
    val evidenceTier: String,
    val targetAxis: String,
    val biologicalRationale: String,
    val supportingSignals: List<String>,
    val missingEvidence: List<String>,
    val upgradePath: String,
    val nextQuery: String,
    val whyItMayFail: List<String>,
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
)

data class MechanismRouteProposalV1110(
    val routeId: String,
    val sourceRuleId: String,
    val targetMolecularAxis: String,
    val datasetReadiness: String,
    val requiredValidationFields: List<String>,
    val contradictionSearchTerms: List<String>,
    val missingEvidence: List<String>,
    val nextAccessionSpecificQuery: String,
    val whyThisRouteMayFail: List<String>,
    val forbiddenClaims: List<String>,
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
)

data class ResearchGradeMechanismDossierReportV1110(
    val active: Boolean,
    val state: String,
    val versionLabel: String,
    val researchQuestion: String,
    val accessionCandidates: List<AccessionCandidateCardV1110>,
    val sourceMetadataEnrichmentCards: List<SourceMetadataEnrichmentCardV1113>,
    val comparatorMap: List<ComparatorMappingCardV1110>,
    val accessionValidationCards: List<AccessionValidationCardV1114>,
    val comparatorExtractionCards: List<ComparatorExtractionCardV1114>,
    val exploratoryResearchLeads: List<ExploratoryResearchLeadV1115>,
    val researchResultMode: String,
    val bestResearchLeadSummary: String,
    val evidenceObjectCreationGate: String,
    val metadataExtractionCommands: List<String>,
    val accessionValidationGate: String,
    val matrixAnalysisGate: String,
    val matrixReadinessScore: Int,
    val evidenceGrade: String,
    val mechanismRoutes: List<MechanismRouteProposalV1110>,
    val contradictionNullResultSearch: List<String>,
    val blockingGaps: List<String>,
    val nextDecisiveAction: String,
    val doNotBelieveYet: List<String>,
    val hardIntegrityLocks: List<String>,
    val conciseDossierLines: List<String>,
    val globalTranslationalDossier: GTIMDiscoveryDossierReportV250 = GTIMDiscoveryDossierReportV250.empty(),
    val claimBoundary: String = ResearchGradeMechanismDossierV1110.CLAIM_BOUNDARY
) {
    companion object {
        fun empty() = ResearchGradeMechanismDossierReportV1110(
            active = false,
            state = "NOT_EVALUATED",
            versionLabel = ResearchGradeMechanismDossierV1110.VERSION_LABEL,
            researchQuestion = "No Hyper-Drive or accession-matrix readiness context was available.",
            accessionCandidates = emptyList(),
            sourceMetadataEnrichmentCards = emptyList(),
            comparatorMap = emptyList(),
            accessionValidationCards = emptyList(),
            comparatorExtractionCards = emptyList(),
            exploratoryResearchLeads = emptyList(),
            researchResultMode = "NO_EXPLORATORY_RESULT",
            bestResearchLeadSummary = "No graded research lead available.",
            evidenceObjectCreationGate = "EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION",
            metadataExtractionCommands = emptyList(),
            accessionValidationGate = "ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED",
            matrixAnalysisGate = "DGE_NOT_READY_METADATA_GAP",
            matrixReadinessScore = 0,
            evidenceGrade = "E — no accession candidate available",
            mechanismRoutes = emptyList(),
            contradictionNullResultSearch = emptyList(),
            blockingGaps = listOf("no accession candidate", "no matrix metadata", "no comparator map"),
            nextDecisiveAction = "Run Hyper-Drive accession search and create accession candidates before mechanism mapping.",
            doNotBelieveYet = ResearchGradeMechanismDossierV1110.DEFAULT_DO_NOT_BELIEVE,
            hardIntegrityLocks = ResearchGradeMechanismDossierV1110.DEFAULT_LOCKS,
            conciseDossierLines = emptyList()
        )
    }
}

object ResearchGradeMechanismDossierV1110 {
    const val VERSION_LABEL: String = "v2.6.8-final-unified-route-learning-closure"
    const val CLAIM_BOUNDARY: String = "biomedical_research_data_engineering_only_not_clinical_claim"

    private val accessionRegex = Regex("\\b(GSE\\d+|GSM\\d+|GPL\\d+|PRJNA\\d+|PRJEB\\d+|SRP\\d+|SRR\\d+|ERR\\d+|E-MTAB-\\d+|SDY\\d+)\\b", RegexOption.IGNORE_CASE)
    private val forbiddenClaims = listOf(
        "diagnosis",
        "treatment recommendation",
        "dose recommendation",
        "supplement recommendation",
        "drug ranking",
        "patient flare prediction",
        "causal claim",
        "clinical utility claim",
        "scientific breakthrough claim",
        "fold-change or p-value without matrix analysis"
    )

    fun evaluate(
        steering: ResearchSteeringProfile?,
        matrix: MetadataClosureStrategyMatrixReport,
        candidates: List<DatasetAccessionCandidate>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        leadObjects: List<LeadObject>,
        attempts: List<DatasetSourceAttempt>
    ): ResearchGradeMechanismDossierReportV1110 {
        if (!RuntimeFeatureFlags.ENABLE_RESEARCH_GRADE_MECHANISM_DOSSIER_V1110) {
            return ResearchGradeMechanismDossierReportV1110.empty().copy(
                state = "DISABLED_BY_FEATURE_FLAG",
                nextDecisiveAction = "Enable v1.11.0 mechanism dossier feature flag."
            )
        }

        val enrichmentCards = buildSourceMetadataEnrichmentCards(candidates, leadObjects, attempts)
        val accessionCards = buildAccessionCards(candidates, parsedMetadata, leadObjects, attempts)
            .filter { it.accessionStatus == "CONFIRMED_ACCESSION" }
        val comparatorCards = accessionCards.map { comparatorCard(it) }
        val accessionValidationCards = buildAccessionValidationCards(accessionCards, enrichmentCards)
        val comparatorExtractionCards = buildComparatorExtractionCards(accessionCards)
        val verifiedRules = matrix.crossReferenceMatrix.filter { it.verified }
        val exploratoryResearchLeads = buildExploratoryResearchLeads(accessionCards, enrichmentCards, verifiedRules, matrix)
        val evidenceObjectCreationGate = evidenceObjectCreationGate(accessionCards, comparatorExtractionCards)
        val metadataExtractionCommands = accessionValidationCards.map { it.metadataExtractionCommand }.filter { it.isNotBlank() }.distinct().take(8)
        val active = matrix.hyperDriveModeActive || accessionCards.isNotEmpty() || enrichmentCards.isNotEmpty() || verifiedRules.isNotEmpty()
        if (!active) {
            return ResearchGradeMechanismDossierReportV1110.empty().copy(
                state = "READY_NO_HYPERDRIVE_CONTEXT",
                researchQuestion = researchQuestion(steering, verifiedRules),
                nextDecisiveAction = "Capture an accession pattern through Hyper-Drive before Accession-to-Matrix readiness evaluation."
            )
        }

        val matrixGate = matrixGate(accessionCards)
        val accessionGate = accessionValidationGate(accessionCards, enrichmentCards)
        val readinessScore = matrixReadinessScore(accessionCards)
        val mechanismRoutes = buildRoutes(verifiedRules, accessionCards, matrix)
        val blockingGaps = accessionCards.flatMap { it.blockingGaps }.ifEmpty {
            enrichmentCards.map { it.accessionResolutionState }.ifEmpty { listOf("no accession candidate", "no matrix metadata", "no comparator map") }
        }.distinct().take(12)
        val contradictionQueries = contradictionQueries(mechanismRoutes, matrix)
        val evidenceGrade = evidenceGrade(accessionCards, mechanismRoutes, matrixGate, enrichmentCards)
        val hasResearchGradePromotionAnchor = accessionCards.isNotEmpty() || verifiedRules.isNotEmpty() || enrichmentCards.any { it.detectedAccessions.isNotEmpty() }
        val state = when {
            evidenceObjectCreationGate != "EVIDENCE_OBJECT_REVIEW_CANDIDATE_NO_CLAIM" && exploratoryResearchLeads.isNotEmpty() && hasResearchGradePromotionAnchor -> "GRADED_RESEARCH_LEADS_IN_PROGRESS"
            accessionCards.isEmpty() && enrichmentCards.isNotEmpty() -> "ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED"
            accessionCards.isEmpty() -> "HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION"
            accessionCards.any { it.dgeReadinessState == "DGE_READY_FOR_CONTROLLED_REVIEW" } -> "MATRIX_READY_FOR_REVIEW_NO_CLAIM"
            evidenceObjectCreationGate == "EVIDENCE_OBJECT_REVIEW_CANDIDATE_NO_CLAIM" -> "MATRIX_READY_FOR_REVIEW_NO_CLAIM"
            comparatorCards.any { it.gate == "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" } -> "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT"
            else -> "DGE_NOT_READY_METADATA_GAP"
        }
        val next = nextAction(state, accessionCards, mechanismRoutes, matrix)
        val lines = conciseLines(
            state = state,
            researchQuestion = researchQuestion(steering, verifiedRules),
            evidenceGrade = evidenceGrade,
            cards = accessionCards,
            enrichmentCards = enrichmentCards,
            matrixGate = matrixGate,
            accessionGate = accessionGate,
            readinessScore = readinessScore,
            routes = mechanismRoutes,
            blockers = blockingGaps,
            next = next,
            accessionValidationCards = accessionValidationCards,
            comparatorExtractionCards = comparatorExtractionCards,
            exploratoryResearchLeads = exploratoryResearchLeads,
            evidenceObjectCreationGate = evidenceObjectCreationGate
        )
        val baseReport = ResearchGradeMechanismDossierReportV1110(
            active = true,
            state = state,
            versionLabel = VERSION_LABEL,
            researchQuestion = researchQuestion(steering, verifiedRules),
            accessionCandidates = accessionCards,
            sourceMetadataEnrichmentCards = enrichmentCards,
            comparatorMap = comparatorCards,
            accessionValidationCards = accessionValidationCards,
            comparatorExtractionCards = comparatorExtractionCards,
            exploratoryResearchLeads = exploratoryResearchLeads,
            researchResultMode = if (exploratoryResearchLeads.isNotEmpty()) "GRADED_EXPLORATORY_RESULTS" else "RELAXED_EXPLORATION_NO_LEAD_YET",
            bestResearchLeadSummary = exploratoryResearchLeads.firstOrNull()?.let { "${it.targetAxis}: ${it.status} (${it.confidence}/100)" } ?: "No graded research lead available.",
            evidenceObjectCreationGate = evidenceObjectCreationGate,
            metadataExtractionCommands = metadataExtractionCommands,
            accessionValidationGate = accessionGate,
            matrixAnalysisGate = matrixGate,
            matrixReadinessScore = readinessScore,
            evidenceGrade = evidenceGrade,
            mechanismRoutes = mechanismRoutes,
            contradictionNullResultSearch = contradictionQueries,
            blockingGaps = blockingGaps,
            nextDecisiveAction = next,
            doNotBelieveYet = DEFAULT_DO_NOT_BELIEVE,
            hardIntegrityLocks = DEFAULT_LOCKS,
            conciseDossierLines = lines
        )
        return baseReport.copy(
            globalTranslationalDossier = GTIMDiscoveryDossierV250.fromMechanismDossier(baseReport)
        )
    }

    private fun buildSourceMetadataEnrichmentCards(
        candidates: List<DatasetAccessionCandidate>,
        leadObjects: List<LeadObject>,
        attempts: List<DatasetSourceAttempt>
    ): List<SourceMetadataEnrichmentCardV1113> {
        val candidateCards = candidates.map { candidate ->
            val text = listOf(candidate.accession, candidate.sourceTitle, candidate.sourceUrl, candidate.conditionLabelsHint, candidate.outcomeLabelsHint, candidate.triggerResponseOutcomeHint, candidate.timeCourseHint, candidate.dataType, candidate.reasons.joinToString(" ")).joinToString(" ")
            sourceMetadataCard(
                sourceId = candidate.sourceFindingId.ifBlank { candidate.accession.ifBlank { candidate.sourceTitle.take(64) } },
                sourceFamily = candidate.source,
                sourceKind = "DATASET_ACCESSION_CANDIDATE",
                sourceStatus = candidate.status,
                text = text
            )
        }
        val leadCards = leadObjects.map { lead ->
            sourceMetadataCard(
                sourceId = lead.leadId,
                sourceFamily = lead.sourceFamily,
                sourceKind = "LEAD_OBJECT",
                sourceStatus = if (lead.detectedAccessions.isNotEmpty()) "ACCESSION_TEXT_PRESENT" else "ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP",
                text = listOf(lead.detectedAccessions.joinToString(" "), lead.title, lead.snippet, lead.dataAvailabilityText, lead.organism, lead.omicsType, lead.domain).joinToString(" ")
            )
        }
        val attemptCards = attempts.mapIndexed { index, attempt ->
            sourceMetadataCard(
                sourceId = "attempt_${index}_${attempt.sourceFamily}",
                sourceFamily = attempt.sourceFamily,
                sourceKind = "SOURCE_ATTEMPT",
                sourceStatus = attempt.status,
                text = listOf(attempt.query, attempt.reason, attempt.ncbiDb).joinToString(" ")
            )
        }
        return (candidateCards + leadCards + attemptCards)
            .distinctBy { it.sourceId + "|" + it.sourceFamily }
            .take(24)
    }

    private fun sourceMetadataCard(
        sourceId: String,
        sourceFamily: String,
        sourceKind: String,
        sourceStatus: String,
        text: String
    ): SourceMetadataEnrichmentCardV1113 {
        val ids = extractAccessions(listOf(text))
        val comparatorTokens = extractComparatorTokens(text)
        val matrixHints = extractMatrixFileHints(text)
        val metadataHints = extractMetadataFileHints(text)
        val sampleHints = extractSampleCountHints(text)
        val parser = parserForSource(sourceFamily, ids.firstOrNull().orEmpty())
        val state = when {
            ids.isEmpty() -> "ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED"
            metadataHints.isEmpty() && comparatorTokens.isEmpty() -> "ACCESSION_FOUND_METADATA_ENRICHMENT_REQUIRED"
            matrixHints.isEmpty() -> "ACCESSION_FOUND_MATRIX_AVAILABILITY_UNRESOLVED"
            else -> "SOURCE_METADATA_ENRICHED_PARTIAL"
        }
        val query = accessionPatternQuery(text)
        val next = when (state) {
            "ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED" -> "Run secondary lookup with accession patterns and data-availability terms before creating AccessionCandidate."
            "ACCESSION_FOUND_METADATA_ENRICHMENT_REQUIRED" -> "Open repository metadata page and parse sample table, organism, platform, group labels, and data availability."
            "ACCESSION_FOUND_MATRIX_AVAILABILITY_UNRESOLVED" -> "Check Series Matrix, supplementary processed files, SRA runs, or count matrix availability."
            else -> "Attempt comparator map and matrix-readiness scoring; keep EvidenceObject gated until controls and matrix close."
        }
        return SourceMetadataEnrichmentCardV1113(
            sourceId = sourceId.ifBlank { "unknown_source" },
            sourceFamily = sourceFamily.ifBlank { "unknown" },
            sourceKind = sourceKind,
            sourceStatus = sourceStatus.ifBlank { "UNKNOWN" },
            detectedAccessions = ids,
            accessionResolutionState = state,
            accessionPatternQuery = query,
            comparatorTokens = comparatorTokens,
            matrixFileHints = matrixHints,
            metadataFileHints = metadataHints,
            sampleCountHints = sampleHints,
            parser = parser,
            nextAction = next
        )
    }

    private fun buildAccessionCards(
        candidates: List<DatasetAccessionCandidate>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        leadObjects: List<LeadObject>,
        attempts: List<DatasetSourceAttempt>
    ): List<AccessionCandidateCardV1110> {
        val byAccession = parsedMetadata.associateBy { normalizeAccession(it.accession) }
        val candidateCards = candidates.flatMap { candidate ->
            val ids = extractAccessions(listOf(candidate.accession, candidate.sourceTitle, candidate.sourceUrl, candidate.reasons.joinToString(" ")))
            ids.map { accession -> cardFromCandidate(accession, candidate, byAccession[normalizeAccession(accession)]) }
        }

        val leadCards = leadObjects.flatMap { lead ->
            val ids = extractAccessions(listOf(lead.detectedAccessions.joinToString(" "), lead.title, lead.snippet, lead.dataAvailabilityText))
            ids.map { accession -> cardFromLead(accession, lead) }
        }

        val attemptCards = attempts.flatMap { attempt ->
            extractAccessions(listOf(attempt.query, attempt.reason)).map { accession -> cardFromAttempt(accession, attempt) }
        }

        return (candidateCards + leadCards + attemptCards)
            .distinctBy { normalizeAccession(it.accessionId) + "|" + it.repository }
            .take(12)
    }

    private fun cardFromCandidate(accession: String, candidate: DatasetAccessionCandidate, metadata: ParsedDatasetMetadata?): AccessionCandidateCardV1110 {
        val groups = splitLabels(candidate.conditionLabelsHint) + (metadata?.conditionLabels ?: emptyList())
        val outcomes = splitLabels(candidate.outcomeLabelsHint) + (metadata?.outcomeLabels ?: emptyList())
        val controls = controlLabels(groups + (metadata?.controlLabels ?: emptyList()) + splitLabels(candidate.triggerResponseOutcomeHint))
        val cases = caseLabels(groups + outcomes)
        val timepoints = splitLabels(candidate.timeCourseHint) + (metadata?.timeCourseLabels ?: emptyList())
        val tissue = firstKnown(metadata?.tissueOrSource, candidate.triggerResponseOutcomeHint, "unknown")
        val platform = firstKnown(metadata?.assayType, candidate.dataType, "unknown")
        val matrixAvailability = matrixAvailability(candidate.dataType, metadata?.assayType, candidate.reasons.joinToString(" "))
        val metadataAvailability = if (metadata != null || groups.isNotEmpty() || outcomes.isNotEmpty()) "METADATA_PARTIAL_OR_PARSED" else "METADATA_UNKNOWN"
        val access = accessStatus(candidate.reasons.joinToString(" ") + " " + candidate.sourceUrl)
        val gaps = blockingGaps(
            accession = accession,
            organism = firstKnown(metadata?.organism, candidate.organismHint, "unknown"),
            groups = groups,
            controls = controls,
            cases = cases,
            timepoints = timepoints,
            tissue = tissue,
            platform = platform,
            sampleCount = candidate.sampleSizeHint,
            matrixAvailability = matrixAvailability,
            metadataAvailability = metadataAvailability,
            access = access,
            outcomes = outcomes
        )
        val dge = dgeReadiness(gaps)
        return AccessionCandidateCardV1110(
            accessionId = accession,
            repository = repositoryFor(accession, candidate.source),
            titleOrSnippet = candidate.sourceTitle.take(240),
            organism = firstKnown(metadata?.organism, candidate.organismHint, "unknown"),
            cohortType = cohortType(firstKnown(metadata?.organism, candidate.organismHint, "") + " " + groups.joinToString(" ")),
            assayPlatform = platform,
            sampleCount = candidate.sampleSizeHint.ifBlank { metadata?.sampleSizeStatus ?: "unknown" },
            sampleGroupLabels = groups.distinct().take(12),
            controlComparatorLabels = controls.distinct().take(12),
            caseLabels = cases.distinct().take(12),
            timepoints = timepoints.distinct().take(12),
            tissueOrCellContext = tissue,
            matrixAvailability = matrixAvailability,
            metadataAvailability = metadataAvailability,
            dataAccessLicenseStatus = access,
            blockingGaps = gaps,
            dgeReadinessState = dge,
            evidenceObjectGate = if (controls.isEmpty()) "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" else if (dge == "DGE_READY_FOR_CONTROLLED_REVIEW") "EVIDENCE_OBJECT_REVIEW_CANDIDATE_NO_CLAIM" else "EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS",
            accessionStatus = "CONFIRMED_ACCESSION",
            sourceMetadataStatus = if (metadataAvailability.contains("PARSED", true) || metadataAvailability.contains("PARTIAL", true)) "SOURCE_METADATA_ENRICHED_PARTIAL" else "SOURCE_METADATA_UNVERIFIED",
            sampleIds = extractSampleIds(candidate.reasons.joinToString(" ") + " " + candidate.sourceTitle),
            matrixFileHints = extractMatrixFileHints(candidate.reasons.joinToString(" ") + " " + candidate.dataType),
            metadataFileHints = extractMetadataFileHints(candidate.reasons.joinToString(" ") + " " + candidate.sourceTitle),
            repositoryLookupQuery = repositoryLookupQuery(accession, repositoryFor(accession, candidate.source)),
            sourceSpecificParser = parserForSource(candidate.source, accession)
        )
    }

    private fun cardFromLead(accession: String, lead: LeadObject): AccessionCandidateCardV1110 {
        val groups = splitLabels(lead.domain + " " + lead.snippet)
        val controls = controlLabels(groups + splitLabels(lead.snippet))
        val cases = caseLabels(groups)
        val timepoints = if (lead.timeLikely) listOf("time_order_or_followup_likely") else emptyList()
        val platform = firstKnown(lead.omicsType, "unknown")
        val matrixAvailability = matrixAvailability(lead.omicsType, lead.dataAvailabilityText, lead.snippet)
        val access = accessStatus(lead.dataAvailabilityText)
        val gaps = blockingGaps(accession, lead.organism, groups, controls, cases, timepoints, lead.domain, platform, "unknown", matrixAvailability, "METADATA_FROM_LEAD_ONLY", access, if (lead.outcomeLikely) listOf("outcome_likely") else emptyList())
        return AccessionCandidateCardV1110(
            accessionId = accession,
            repository = repositoryFor(accession, lead.sourceFamily),
            titleOrSnippet = (lead.title.ifBlank { lead.snippet }).take(240),
            organism = lead.organism.ifBlank { "unknown" },
            cohortType = cohortType(lead.organism + " " + lead.snippet),
            assayPlatform = platform,
            sampleCount = if (lead.sampleSizeLikely) "sample_size_likely_unparsed" else "unknown",
            sampleGroupLabels = groups.take(12),
            controlComparatorLabels = controls.take(12),
            caseLabels = cases.take(12),
            timepoints = timepoints,
            tissueOrCellContext = lead.domain.ifBlank { "unknown" },
            matrixAvailability = matrixAvailability,
            metadataAvailability = "METADATA_FROM_LEAD_ONLY",
            dataAccessLicenseStatus = access,
            blockingGaps = gaps,
            dgeReadinessState = dgeReadiness(gaps),
            evidenceObjectGate = if (controls.isEmpty()) "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" else "EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS",
            accessionStatus = "CONFIRMED_ACCESSION",
            sourceMetadataStatus = "SOURCE_METADATA_FROM_LEAD_ONLY",
            sampleIds = extractSampleIds(lead.snippet + " " + lead.dataAvailabilityText),
            matrixFileHints = extractMatrixFileHints(lead.snippet + " " + lead.dataAvailabilityText),
            metadataFileHints = extractMetadataFileHints(lead.snippet + " " + lead.dataAvailabilityText),
            repositoryLookupQuery = repositoryLookupQuery(accession, repositoryFor(accession, lead.sourceFamily)),
            sourceSpecificParser = parserForSource(lead.sourceFamily, accession)
        )
    }

    private fun cardFromAttempt(accession: String, attempt: DatasetSourceAttempt): AccessionCandidateCardV1110 {
        val controls = controlLabels(splitLabels(attempt.query))
        val cases = caseLabels(splitLabels(attempt.query))
        val gaps = blockingGaps(accession, "unknown", splitLabels(attempt.query), controls, cases, emptyList(), "unknown", "unknown", "unknown", "MATRIX_UNKNOWN_REQUIRES_REPOSITORY_INSPECTION", "METADATA_UNKNOWN", "ACCESS_UNKNOWN", emptyList())
        return AccessionCandidateCardV1110(
            accessionId = accession,
            repository = repositoryFor(accession, attempt.sourceFamily),
            titleOrSnippet = attempt.query.take(240),
            organism = "unknown",
            cohortType = "unknown",
            assayPlatform = "unknown",
            sampleCount = "unknown",
            sampleGroupLabels = splitLabels(attempt.query).take(12),
            controlComparatorLabels = controls.take(12),
            caseLabels = cases.take(12),
            timepoints = emptyList(),
            tissueOrCellContext = "unknown",
            matrixAvailability = "MATRIX_UNKNOWN_REQUIRES_REPOSITORY_INSPECTION",
            metadataAvailability = "METADATA_UNKNOWN",
            dataAccessLicenseStatus = "ACCESS_UNKNOWN",
            blockingGaps = gaps,
            dgeReadinessState = "DGE_NOT_READY_METADATA_GAP",
            evidenceObjectGate = if (controls.isEmpty()) "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" else "EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS",
            accessionStatus = "CONFIRMED_ACCESSION",
            sourceMetadataStatus = "SOURCE_METADATA_QUERY_ONLY",
            sampleIds = extractSampleIds(attempt.query),
            matrixFileHints = extractMatrixFileHints(attempt.query),
            metadataFileHints = extractMetadataFileHints(attempt.query),
            repositoryLookupQuery = repositoryLookupQuery(accession, repositoryFor(accession, attempt.sourceFamily)),
            sourceSpecificParser = parserForSource(attempt.sourceFamily, accession)
        )
    }

    private fun comparatorCard(card: AccessionCandidateCardV1110): ComparatorMappingCardV1110 {
        val labels = (card.sampleGroupLabels + card.controlComparatorLabels + card.caseLabels).map { it.lowercase(Locale.US) }
        fun pick(vararg keys: String): List<String> = labels.filter { label -> keys.any { key -> label.contains(key) } }.distinct().take(6)
        val healthy = pick("healthy")
        val matched = pick("matched")
        val baseline = pick("baseline", "pre")
        val placebo = pick("placebo")
        val responder = labels.filter { it.contains("responder") && !it.contains("non") }.distinct().take(6)
        val nonResponder = pick("non-responder", "nonresponder", "non responder")
        val case = pick("case", "patient", "sle", "lupus", "multiple sclerosis", "me/cfs", "rheumatoid")
        val exposed = pick("exposed", "unexposed", "treated", "untreated")
        val negative = pick("negative control", "unrelated marker", "null")
        val unknown = if (listOf(healthy, matched, baseline, placebo, responder, nonResponder, case, exposed, negative).all { it.isEmpty() }) listOf("unknown") else emptyList()
        val hasComparator = healthy.isNotEmpty() || matched.isNotEmpty() || baseline.isNotEmpty() || placebo.isNotEmpty() || nonResponder.isNotEmpty() || exposed.isNotEmpty() || negative.isNotEmpty()
        return ComparatorMappingCardV1110(
            accessionId = card.accessionId,
            status = if (hasComparator) "COMPARATOR_MAP_PARTIAL" else "COMPARATOR_UNKNOWN",
            healthyControl = healthy,
            matchedControl = matched,
            baseline = baseline,
            placebo = placebo,
            responder = responder,
            nonResponder = nonResponder,
            caseLabel = case,
            exposedUnexposed = exposed,
            negativeControl = negative,
            unknown = unknown,
            gate = if (hasComparator) "COMPARATOR_PARTIAL_NO_CLAIM" else "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT"
        )
    }

    private fun buildExploratoryResearchLeads(
        cards: List<AccessionCandidateCardV1110>,
        enrichmentCards: List<SourceMetadataEnrichmentCardV1113>,
        verifiedRules: List<MetadataClosureIntersectionRuleV11057>,
        matrix: MetadataClosureStrategyMatrixReport
    ): List<ExploratoryResearchLeadV1115> {
        if (!RuntimeFeatureFlags.ENABLE_GRADED_EXPLORATORY_RESULTS_V1115) return emptyList()
        val routeRules = verifiedRules.ifEmpty { matrix.crossReferenceMatrix.filter { it.routeFitFloor >= GTIMRelaxedExplorationPolicyV253.MIN_ROUTE_FIT_FOR_EXPLORATORY_RULE || it.programmaticQueries.isNotEmpty() || it.matchedTokens.isNotEmpty() } }
        val leadsFromRules = routeRules.mapIndexed { idx, rule ->
            val axis = when (rule.ruleId) {
                "R1_NEURO_VIRAL_BRIDGE" -> "EBV/HHV-6 ↔ SLE/MS/ME-CFS transcriptomic bridge"
                "R2_PSYCHEPHYSIOLOGICAL_EXPOSOME" -> "HPA/sleep strain ↔ IFN/IL-6/TNF cytokine transcriptomic bridge"
                else -> rule.label.ifBlank { "cross-family immune mechanism route" }
            }
            exploratoryLead(
                leadId = "ERL_RULE_${rule.ruleId}_$idx",
                baseConfidence = 45 + (rule.routeFitFloor / 4) + if (rule.programmaticQueries.isNotEmpty()) 8 else 0,
                axis = axis,
                signals = rule.matchedFamilies + rule.matchedTokens + rule.programmaticQueries.take(2),
                gaps = matrix.hardClaimGates.ifEmpty { listOf("confirmed accession", "control/comparator", "matrix availability") },
                nextQuery = rule.programmaticQueries.firstOrNull() ?: matrix.queryStreams.firstOrNull()?.query.orEmpty(),
                rationale = "Cross-family intersection is strong enough to produce a research lead, but it remains below EvidenceObject strength until accession, comparator and matrix metadata close."
            )
        }
        val leadsFromCards = cards.mapIndexed { idx, card ->
            exploratoryLead(
                leadId = "ERL_ACCESSION_${normalizeAccession(card.accessionId)}_$idx",
                baseConfidence = 50 + matrixReadinessScore(listOf(card)) / 3,
                axis = "${card.accessionId} ${card.assayPlatform} ${card.cohortType}".trim(),
                signals = listOf(card.accessionId, card.repository, card.assayPlatform, card.organism) + card.controlComparatorLabels + card.caseLabels + card.matrixFileHints,
                gaps = card.blockingGaps,
                nextQuery = card.repositoryLookupQuery,
                rationale = "Confirmed accession can be reported as a graded research lead even when DGE and EvidenceObject creation remain blocked."
            )
        }
        val leadsFromEnrichment = enrichmentCards.take(GTIMRelaxedExplorationPolicyV253.MAX_SOURCE_METADATA_LEADS).mapIndexed { idx, card ->
            val signalStrength = card.comparatorTokens.size * 6 + card.matrixFileHints.size * 8 + card.metadataFileHints.size * 5 + card.detectedAccessions.size * 15
            exploratoryLead(
                leadId = "ERL_SOURCE_${card.sourceId.take(32)}_$idx",
                baseConfidence = 30 + signalStrength,
                axis = card.detectedAccessions.firstOrNull() ?: card.sourceFamily,
                signals = card.detectedAccessions + card.comparatorTokens + card.matrixFileHints + card.metadataFileHints,
                gaps = listOf(card.accessionResolutionState, "control/comparator", "matrix availability", "sample metadata"),
                nextQuery = card.accessionPatternQuery,
                rationale = "Source text contains useful research signals, so the UI should show it as an in-progress lead rather than a dry technical block."
            )
        }
        return (leadsFromCards + leadsFromRules + leadsFromEnrichment)
            .distinctBy { it.leadId }
            .sortedByDescending { it.confidence }
            .take(GTIMRelaxedExplorationPolicyV253.MAX_EXPLORATORY_RESEARCH_LEADS)
    }

    private fun exploratoryLead(
        leadId: String,
        baseConfidence: Int,
        axis: String,
        signals: List<String>,
        gaps: List<String>,
        nextQuery: String,
        rationale: String
    ): ExploratoryResearchLeadV1115 {
        val confidence = baseConfidence.coerceIn(GTIMRelaxedExplorationPolicyV253.MIN_EXPLORATORY_CONFIDENCE, GTIMRelaxedExplorationPolicyV253.MAX_EXPLORATORY_CONFIDENCE)
        val tier = when {
            confidence >= 65 -> "RESEARCH_LEAD_TIER_B_IN_PROGRESS"
            confidence >= 50 -> "RESEARCH_LEAD_TIER_C_PRELIMINARY"
            confidence >= 35 -> "RESEARCH_LEAD_TIER_D_WEAK_BUT_USEFUL"
            else -> "RESEARCH_LEAD_TIER_E_TRACE_ONLY"
        }
        val missing = gaps.ifEmpty { listOf("confirmed accession", "comparator labels", "matrix availability", "contradiction search") }.distinct().take(8)
        return ExploratoryResearchLeadV1115(
            leadId = leadId,
            status = "IN_PROGRESS_NOT_EVIDENCE_OBJECT",
            confidence = confidence,
            evidenceTier = tier,
            targetAxis = axis.ifBlank { "immune mechanism route under exploration" },
            biologicalRationale = rationale,
            supportingSignals = signals.filter { it.isNotBlank() }.distinct().take(10),
            missingEvidence = missing,
            upgradePath = "Upgrade only after accession + comparator/control + sample metadata + matrix availability + contradiction/null-result search close.",
            nextQuery = nextQuery.ifBlank { "GEO/SRA accession-specific query with control comparator matrix metadata terms" },
            whyItMayFail = listOf(
                "signals may be metadata-only or off-route",
                "sample labels may not separate case/control or baseline",
                "matrix may be unavailable or raw-only",
                "batch effect, cell-composition shift, or null-result literature may explain the signal"
            )
        )
    }

    private fun buildRoutes(
        verifiedRules: List<MetadataClosureIntersectionRuleV11057>,
        cards: List<AccessionCandidateCardV1110>,
        matrix: MetadataClosureStrategyMatrixReport
    ): List<MechanismRouteProposalV1110> {
        return verifiedRules.map { rule ->
            val axis = when (rule.ruleId) {
                "R1_NEURO_VIRAL_BRIDGE" -> "Latent viral transcriptional activation / neuro-immune autoimmunity axis"
                "R2_PSYCHEPHYSIOLOGICAL_EXPOSOME" -> "HPA/sleep-strain cytokine modulation axis"
                else -> "Verified cross-family translational evidence axis"
            }
            val missing = cards.flatMap { it.blockingGaps }.distinct().ifEmpty { matrix.hardClaimGates }.take(10)
            MechanismRouteProposalV1110(
                routeId = "MR_${rule.ruleId}",
                sourceRuleId = rule.ruleId,
                targetMolecularAxis = axis,
                datasetReadiness = if (cards.any { it.dgeReadinessState == "DGE_READY_FOR_CONTROLLED_REVIEW" }) "DGE_READY_FOR_CONTROLLED_REVIEW_NO_CLAIM" else "DGE_NOT_READY_METADATA_GAP",
                requiredValidationFields = listOf(
                    "expression matrix availability",
                    "sample metadata availability",
                    "case/control or baseline comparator",
                    "tissue/cell context",
                    "time/order labels for longitudinal claims",
                    "batch/platform artifact warning",
                    "outcome labels",
                    "contradiction/null-result search"
                ),
                contradictionSearchTerms = contradictionTermsFor(rule),
                missingEvidence = missing,
                nextAccessionSpecificQuery = rule.programmaticQueries.firstOrNull() ?: matrix.queryStreams.firstOrNull()?.query.orEmpty(),
                whyThisRouteMayFail = listOf(
                    "accession resolves to metadata-only record without downloadable matrix",
                    "sample groups do not separate case/control or baseline",
                    "time order is absent or reversed",
                    "cell-composition or batch effects explain the signal better",
                    "null-result or negative-control literature breaks the mechanism route"
                ),
                forbiddenClaims = forbiddenClaims
            )
        }
    }

    private fun contradictionQueries(routes: List<MechanismRouteProposalV1110>, matrix: MetadataClosureStrategyMatrixReport): List<String> {
        val fromRoutes = routes.flatMap { route ->
            route.contradictionSearchTerms.map { term -> "${route.targetMolecularAxis} AND ($term) AND (null result OR no association OR failed replication OR batch effect OR cell composition)" }
        }
        val fallback = matrix.detectedTargets.take(6).joinToString(" OR ").ifBlank { "immune transcriptome" }
        return (fromRoutes + "($fallback) AND (negative control OR no association OR failed replication OR heterogeneity OR batch effect)")
            .distinct()
            .take(GTIMRelaxedExplorationPolicyV253.MAX_EXPLORATORY_RESEARCH_LEADS)
    }

    private fun buildAccessionValidationCards(
        cards: List<AccessionCandidateCardV1110>,
        enrichmentCards: List<SourceMetadataEnrichmentCardV1113>
    ): List<AccessionValidationCardV1114> {
        val fromCandidates = cards.map { card ->
            val state = when {
                card.accessionStatus != "CONFIRMED_ACCESSION" -> "ACCESSION_REJECTED_NOT_CONFIRMED"
                card.sourceSpecificParser == "GENERIC_ACCESSION_METADATA_PARSER" -> "ACCESSION_CONFIRMED_GENERIC_PARSER_REQUIRES_SOURCE_LOOKUP"
                card.metadataAvailability.contains("UNKNOWN", true) -> "ACCESSION_CONFIRMED_METADATA_EXTRACTION_REQUIRED"
                card.controlComparatorLabels.isEmpty() -> "ACCESSION_CONFIRMED_COMPARATOR_EXTRACTION_REQUIRED"
                !card.matrixAvailability.startsWith("MATRIX_AVAILABLE") -> "ACCESSION_CONFIRMED_MATRIX_VALIDATION_REQUIRED"
                else -> "ACCESSION_VALIDATED_FOR_REVIEW_NO_CLAIM"
            }
            AccessionValidationCardV1114(
                accessionId = card.accessionId,
                repository = card.repository,
                validationState = state,
                handleType = accessionHandleType(card.accessionId),
                sourceSpecificParser = card.sourceSpecificParser,
                repositoryLookupQuery = card.repositoryLookupQuery,
                metadataExtractionCommand = metadataExtractionCommand(card),
                comparatorExtractionState = if (card.controlComparatorLabels.isNotEmpty()) "COMPARATOR_SIGNALS_EXTRACTED_PARTIAL" else "COMPARATOR_EXTRACTION_REQUIRED",
                matrixReadinessState = card.matrixAvailability,
                evidenceObjectCreationGate = strictEvidenceObjectGate(card),
                blockingGaps = card.blockingGaps
            )
        }
        val unresolved = if (fromCandidates.isEmpty()) {
            enrichmentCards.take(6).map { card ->
                AccessionValidationCardV1114(
                    accessionId = card.detectedAccessions.firstOrNull() ?: card.sourceId,
                    repository = repositoryFor(card.detectedAccessions.firstOrNull().orEmpty(), card.sourceFamily),
                    validationState = card.accessionResolutionState,
                    handleType = if (card.detectedAccessions.isEmpty()) "UNRESOLVED_TEXT_HANDLE" else accessionHandleType(card.detectedAccessions.first()),
                    sourceSpecificParser = card.parser,
                    repositoryLookupQuery = card.accessionPatternQuery,
                    metadataExtractionCommand = "SECONDARY_LOOKUP::${card.sourceFamily}::${card.accessionPatternQuery}",
                    comparatorExtractionState = if (card.comparatorTokens.isEmpty()) "COMPARATOR_EXTRACTION_REQUIRED" else "COMPARATOR_TEXT_TOKENS_FOUND_NEEDS_SAMPLE_TABLE",
                    matrixReadinessState = if (card.matrixFileHints.isEmpty()) "MATRIX_NOT_ESTABLISHED" else "MATRIX_HINTS_FOUND_REPOSITORY_VALIDATION_REQUIRED",
                    evidenceObjectCreationGate = "EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION",
                    blockingGaps = listOf("confirmed_accession", "sample_metadata_table", "control_or_comparator", "expression_matrix_availability")
                )
            }
        } else emptyList()
        return (fromCandidates + unresolved).take(12)
    }

    private fun buildComparatorExtractionCards(cards: List<AccessionCandidateCardV1110>): List<ComparatorExtractionCardV1114> =
        cards.map { card ->
            val labels = (card.sampleGroupLabels + card.controlComparatorLabels + card.caseLabels + card.titleOrSnippet)
                .flatMap { splitLabels(it) }
                .distinct()
            val controls = controlLabels(labels)
            val cases = caseLabels(labels)
            val baseline = labels.filter { it.contains("baseline") || it.contains("pre-") || it == "pre" || it.contains("before") }.distinct().take(8)
            val responders = labels.filter { it.contains("responder") || it.contains("non-responder") || it.contains("nonresponder") }.distinct().take(8)
            val negatives = labels.filter { it.contains("negative control") || it.contains("unrelated") || it.contains("null") || it.contains("sham") }.distinct().take(8)
            val confidence = (controls.size * 18 + cases.size * 12 + baseline.size * 10 + responders.size * 8 + negatives.size * 12).coerceAtMost(100)
            val state = when {
                controls.isNotEmpty() && cases.isNotEmpty() -> "COMPARATOR_EXTRACTION_CASE_CONTROL_PARTIAL"
                controls.isNotEmpty() -> "COMPARATOR_EXTRACTION_CONTROL_ONLY"
                cases.isNotEmpty() -> "COMPARATOR_EXTRACTION_CASE_ONLY"
                else -> "COMPARATOR_EXTRACTION_REQUIRED"
            }
            val gate = when {
                controls.isNotEmpty() && cases.isNotEmpty() && card.matrixAvailability.startsWith("MATRIX_AVAILABLE") -> "EVIDENCE_OBJECT_REVIEW_CANDIDATE_NO_CLAIM"
                controls.isEmpty() -> "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT"
                cases.isEmpty() -> "CASE_LABEL_BLOCKED_NO_EVIDENCE_OBJECT"
                else -> "EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS"
            }
            ComparatorExtractionCardV1114(
                accessionId = card.accessionId,
                extractionState = state,
                extractedLabels = labels.take(20),
                controlSignals = controls.take(8),
                caseSignals = cases.take(8),
                baselineSignals = baseline,
                responderSignals = responders,
                negativeControlSignals = negatives,
                comparatorConfidence = confidence,
                evidenceObjectGate = gate,
                nextAction = when (gate) {
                    "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" -> "Parse sample table for healthy/matched/baseline/placebo/negative-control labels before EvidenceObject creation."
                    "CASE_LABEL_BLOCKED_NO_EVIDENCE_OBJECT" -> "Parse sample table for case/patient/disease/exposed labels and contrast definitions."
                    "EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS" -> "Validate series matrix/count matrix/raw run availability before EvidenceObject review."
                    else -> "Review metadata only; do not claim DGE until controlled analysis runs."
                }
            )
        }

    private fun strictEvidenceObjectGate(card: AccessionCandidateCardV1110): String = when {
        card.accessionStatus != "CONFIRMED_ACCESSION" -> "EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION"
        card.controlComparatorLabels.isEmpty() -> "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT"
        card.caseLabels.isEmpty() -> "CASE_LABEL_BLOCKED_NO_EVIDENCE_OBJECT"
        !card.matrixAvailability.startsWith("MATRIX_AVAILABLE") -> "EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS"
        !card.metadataAvailability.contains("PARSED", true) && !card.metadataAvailability.contains("PARTIAL", true) -> "EVIDENCE_OBJECT_BLOCKED_BY_METADATA_READINESS"
        card.sampleCount == "unknown" || card.sampleCount.isBlank() -> "EVIDENCE_OBJECT_BLOCKED_BY_SAMPLE_COUNT"
        else -> "EVIDENCE_OBJECT_REVIEW_CANDIDATE_NO_CLAIM"
    }

    private fun evidenceObjectCreationGate(cards: List<AccessionCandidateCardV1110>, comparatorCards: List<ComparatorExtractionCardV1114>): String = when {
        cards.isEmpty() -> "EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION"
        cards.any { strictEvidenceObjectGate(it) == "EVIDENCE_OBJECT_REVIEW_CANDIDATE_NO_CLAIM" } -> "EVIDENCE_OBJECT_REVIEW_CANDIDATE_NO_CLAIM"
        comparatorCards.any { it.evidenceObjectGate == "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" } -> "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT"
        comparatorCards.any { it.evidenceObjectGate == "CASE_LABEL_BLOCKED_NO_EVIDENCE_OBJECT" } -> "CASE_LABEL_BLOCKED_NO_EVIDENCE_OBJECT"
        cards.any { !it.matrixAvailability.startsWith("MATRIX_AVAILABLE") } -> "EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS"
        else -> cards.firstOrNull()?.let { strictEvidenceObjectGate(it) } ?: "EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION"
    }

    private fun accessionHandleType(accession: String): String = when {
        accession.startsWith("GSE", true) -> "GEO_SERIES"
        accession.startsWith("GSM", true) -> "GEO_SAMPLE"
        accession.startsWith("GPL", true) -> "GEO_PLATFORM"
        accession.startsWith("PRJ", true) -> "BIOPROJECT"
        accession.startsWith("SRP", true) -> "SRA_STUDY"
        accession.startsWith("SRR", true) || accession.startsWith("ERR", true) -> "SRA_RUN"
        accession.startsWith("E-MTAB", true) -> "ARRAYEXPRESS_EXPERIMENT"
        accession.startsWith("SDY", true) -> "IMMPORT_STUDY"
        else -> "UNKNOWN_HANDLE"
    }

    private fun metadataExtractionCommand(card: AccessionCandidateCardV1110): String = when (card.repository) {
        "GEO" -> "PARSE_GEO::${card.accessionId}::series_matrix|sample_metadata|supplementary_files|characteristics_ch1"
        "SRA/BioProject" -> "PARSE_SRA::${card.accessionId}::run_table|BioSample_attributes|library_strategy|sample_title"
        "ArrayExpress" -> "PARSE_ARRAYEXPRESS::${card.accessionId}::IDF|SDRF|factor_value|processed_data"
        "ImmPort" -> "PARSE_IMMPORT::${card.accessionId}::study_design|arms|biosamples|assessments"
        else -> "PARSE_GENERIC_ACCESSION::${card.accessionId}::metadata|groups|matrix|controls"
    }

    private fun evidenceGrade(
        cards: List<AccessionCandidateCardV1110>,
        routes: List<MechanismRouteProposalV1110>,
        gate: String,
        enrichmentCards: List<SourceMetadataEnrichmentCardV1113>
    ): String = when {
        cards.any { it.dgeReadinessState == "DGE_READY_FOR_CONTROLLED_REVIEW" } -> "B — dataset structurally ready for controlled matrix review, no biological claim"
        cards.any { it.controlComparatorLabels.isNotEmpty() && it.matrixAvailability.startsWith("MATRIX_AVAILABLE") } -> "C+ — accession/comparator structure present, matrix or metadata gaps remain"
        cards.isNotEmpty() -> "C — confirmed accession candidate present; graded research lead allowed, DGE blocked"
        enrichmentCards.any { it.detectedAccessions.isNotEmpty() } -> "C- — accession text found; preliminary research lead allowed, validation required"
        enrichmentCards.isNotEmpty() -> "D+ — weak research lead in progress; useful direction, accession unresolved"
        routes.isNotEmpty() -> "C- — verified mechanism route; preliminary research lead allowed, no accession card yet"
        else -> "E — exploratory only"
    }

    private fun accessionValidationGate(cards: List<AccessionCandidateCardV1110>, enrichmentCards: List<SourceMetadataEnrichmentCardV1113>): String = when {
        cards.any { it.dgeReadinessState == "DGE_READY_FOR_CONTROLLED_REVIEW" } -> "ACCESSION_VALIDATED_MATRIX_READY_NO_CLAIM"
        cards.isNotEmpty() -> "ACCESSION_VALIDATED_METADATA_ENRICHMENT_REQUIRED"
        enrichmentCards.any { it.detectedAccessions.isNotEmpty() } -> "ACCESSION_TEXT_FOUND_METADATA_LOOKUP_REQUIRED"
        else -> "ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED"
    }

    private fun matrixReadinessScore(cards: List<AccessionCandidateCardV1110>): Int {
        if (cards.isEmpty()) return 0
        return cards.maxOf { card ->
            var score = 0
            if (card.accessionStatus == "CONFIRMED_ACCESSION") score += 20
            if (card.metadataAvailability.contains("PARSED", true) || card.metadataAvailability.contains("PARTIAL", true)) score += 15
            if (card.sampleGroupLabels.isNotEmpty()) score += 10
            if (card.controlComparatorLabels.isNotEmpty()) score += 15
            if (card.caseLabels.isNotEmpty()) score += 10
            if (card.matrixAvailability.startsWith("MATRIX_AVAILABLE")) score += 15
            if (card.tissueOrCellContext != "unknown") score += 5
            if (card.timepoints.isNotEmpty()) score += 5
            if (card.sampleCount != "unknown") score += 5
            score.coerceIn(0, 100)
        }
    }

    private fun matrixGate(cards: List<AccessionCandidateCardV1110>): String = when {
        cards.any { it.dgeReadinessState == "DGE_READY_FOR_CONTROLLED_REVIEW" } -> "DGE_READY_FOR_CONTROLLED_REVIEW"
        cards.isEmpty() -> "DGE_NOT_READY_NO_ACCESSION"
        else -> "DGE_NOT_READY_METADATA_GAP"
    }

    private fun dgeReadiness(gaps: List<String>): String = if (gaps.isEmpty()) "DGE_READY_FOR_CONTROLLED_REVIEW" else "DGE_NOT_READY_METADATA_GAP"

    private fun blockingGaps(
        accession: String,
        organism: String,
        groups: List<String>,
        controls: List<String>,
        cases: List<String>,
        timepoints: List<String>,
        tissue: String,
        platform: String,
        sampleCount: String,
        matrixAvailability: String,
        metadataAvailability: String,
        access: String,
        outcomes: List<String>
    ): List<String> {
        val gaps = mutableListOf<String>()
        if (accession.isBlank() || accession == "unknown") gaps += "accession_id"
        if (!organism.contains("human", true) && !organism.contains("patient", true)) gaps += "human_or_patient_cohort"
        if (groups.isEmpty()) gaps += "sample_group_labels"
        if (controls.isEmpty()) gaps += "control_or_comparator"
        if (cases.isEmpty()) gaps += "case_labels"
        if (timepoints.isEmpty()) gaps += "time_order_or_longitudinal_labels"
        if (tissue.isBlank() || tissue == "unknown") gaps += "tissue_or_cell_context"
        if (platform.isBlank() || platform == "unknown") gaps += "assay_platform"
        if (sampleCount.isBlank() || sampleCount == "unknown" || sampleCount.contains("unknown", true)) gaps += "sample_count"
        if (!matrixAvailability.startsWith("MATRIX_AVAILABLE")) gaps += "expression_matrix_availability"
        if (!metadataAvailability.contains("PARSED", true) && !metadataAvailability.contains("PARTIAL", true)) gaps += "sample_metadata_availability"
        if (!access.contains("AVAILABLE", true) && !access.contains("OPEN", true)) gaps += "data_access_or_license_status"
        if (outcomes.isEmpty()) gaps += "outcome_labels"
        return gaps.distinct()
    }

    private fun matrixAvailability(dataType: String?, assayType: String?, text: String?): String {
        val corpus = listOfNotNull(dataType, assayType, text).joinToString(" ").lowercase(Locale.US)
        val omics = listOf("rna-seq", "rnaseq", "transcriptome", "gene expression", "microarray", "scrna", "single-cell").any { corpus.contains(it) }
        val matrix = listOf("expression matrix", "counts matrix", "raw counts", "series matrix", "supplementary file", "processed data").any { corpus.contains(it) }
        return when {
            omics && matrix -> "MATRIX_AVAILABLE_UNVERIFIED"
            omics -> "MATRIX_UNKNOWN_REQUIRES_REPOSITORY_INSPECTION"
            else -> "MATRIX_NOT_ESTABLISHED"
        }
    }

    private fun metadataAvailability(metadata: ParsedDatasetMetadata?): String = if (metadata != null) "METADATA_PARSED" else "METADATA_UNKNOWN"

    private fun accessStatus(text: String): String {
        val t = text.lowercase(Locale.US)
        return when {
            listOf("open", "available", "data availability", "geo", "sra", "supplementary", "download").any { t.contains(it) } -> "ACCESS_AVAILABLE_UNVERIFIED"
            listOf("restricted", "controlled access", "dbgap", "upon request").any { t.contains(it) } -> "ACCESS_RESTRICTED_OR_REQUEST_REQUIRED"
            else -> "ACCESS_UNKNOWN"
        }
    }

    private fun extractAccessions(chunks: List<String>): List<String> = chunks
        .flatMap { chunk -> accessionRegex.findAll(chunk).map { normalizeAccession(it.value) }.toList() }
        .filter { isRealRepositoryAccession(it) }
        .distinct()

    private fun isRealRepositoryAccession(value: String): Boolean = accessionRegex.matches(normalizeAccession(value))

    private fun splitLabels(text: String): List<String> = text
        .split(',', ';', '|', '/', '\n')
        .map { it.trim().lowercase(Locale.US) }
        .filter { it.length >= 3 && it !in setOf("unknown", "none", "null") }
        .distinct()
        .take(20)

    private fun controlLabels(labels: List<String>): List<String> = labels.filter { label ->
        listOf("healthy", "control", "baseline", "placebo", "non-responder", "nonresponder", "unexposed", "untreated", "negative").any { label.contains(it) }
    }.distinct()

    private fun caseLabels(labels: List<String>): List<String> = labels.filter { label ->
        listOf("case", "patient", "sle", "lupus", "multiple sclerosis", "me/cfs", "rheumatoid", "covid", "ebv", "hhv", "flare", "responder", "exposed", "treated").any { label.contains(it) }
    }.distinct()

    private fun repositoryFor(accession: String, fallback: String): String = when {
        accession.startsWith("GSE", true) || accession.startsWith("GSM", true) || accession.startsWith("GPL", true) -> "GEO"
        accession.startsWith("PRJ", true) || accession.startsWith("SRP", true) || accession.startsWith("SRR", true) || accession.startsWith("ERR", true) -> "SRA/BioProject"
        accession.startsWith("E-MTAB", true) -> "ArrayExpress"
        accession.startsWith("SDY", true) -> "ImmPort"
        else -> fallback.ifBlank { "unknown" }
    }

    private fun cohortType(text: String): String = when {
        text.contains("human", true) || text.contains("patient", true) -> "human_or_patient_cohort"
        text.contains("mouse", true) || text.contains("murine", true) -> "animal_model_not_primary_human"
        text.contains("cell", true) || text.contains("in vitro", true) -> "cell_or_in_vitro_model"
        else -> "unknown"
    }

    private fun extractSampleIds(text: String): List<String> = Regex("""\b(GSM\d+|SRR\d+|ERR\d+)\b""", RegexOption.IGNORE_CASE)
        .findAll(text)
        .map { normalizeAccession(it.value) }
        .distinct()
        .take(30)
        .toList()

    private fun extractSampleCountHints(text: String): List<String> = Regex("""\b(n\s*=\s*\d+|\d+\s+(samples|subjects|patients|controls|cases|donors|participants))\b""", setOf(RegexOption.IGNORE_CASE))
        .findAll(text)
        .map { it.value.trim() }
        .distinct()
        .take(10)
        .toList()

    private fun extractComparatorTokens(text: String): List<String> {
        val lower = text.lowercase(Locale.US)
        val tokens = listOf("healthy control", "matched control", "baseline", "placebo", "responder", "non-responder", "nonresponder", "case", "patient", "untreated", "treated", "exposed", "unexposed", "negative control")
        return tokens.filter { lower.contains(it) }
    }

    private fun extractMatrixFileHints(text: String): List<String> {
        val lower = text.lowercase(Locale.US)
        val tokens = listOf("series matrix", "expression matrix", "count matrix", "counts matrix", "raw counts", "processed data", "supplementary file", "fastq", "sra run", "raw data")
        return tokens.filter { lower.contains(it) }
    }

    private fun extractMetadataFileHints(text: String): List<String> {
        val lower = text.lowercase(Locale.US)
        val tokens = listOf("sample metadata", "phenotype", "clinical metadata", "characteristics", "sample table", "metadata", "data availability", "supplementary data")
        return tokens.filter { lower.contains(it) }
    }

    private fun accessionPatternQuery(text: String): String {
        val compact = text.replace(Regex("""\s+"""), " ").trim().take(160)
        val seed = compact.ifBlank { "immune transcriptome" }
        return "($seed) AND (GSE[0-9]* OR GSM[0-9]* OR PRJNA[0-9]* OR SRP[0-9]* OR SRR[0-9]* OR E-MTAB-[0-9]* OR SDY[0-9]*) AND (sample metadata OR phenotype OR series matrix OR count matrix OR supplementary data OR data availability)"
    }

    private fun repositoryLookupQuery(accession: String, repository: String): String = when (repository) {
        "GEO" -> "$accession GEO sample metadata series matrix supplementary file phenotype control case"
        "SRA/BioProject" -> "$accession SRA BioProject sample metadata SRR run table phenotype control case"
        "ArrayExpress" -> "$accession ArrayExpress sample metadata processed data factor value control case"
        "ImmPort" -> "$accession ImmPort study design arms cohorts control case"
        else -> "$accession sample metadata matrix comparator control case"
    }

    private fun parserForSource(sourceFamily: String, accession: String): String = when {
        accession.startsWith("GSE", true) || accession.startsWith("GSM", true) || sourceFamily.contains("GEO", true) -> "GEO_SERIES_SAMPLE_MATRIX_PARSER"
        accession.startsWith("PRJ", true) || accession.startsWith("SRP", true) || accession.startsWith("SRR", true) || sourceFamily.contains("SRA", true) || sourceFamily.contains("BIOPROJECT", true) -> "SRA_BIOPROJECT_RUN_TABLE_PARSER"
        accession.startsWith("E-MTAB", true) || sourceFamily.contains("ARRAY", true) -> "ARRAYEXPRESS_IDF_SDRF_PARSER"
        accession.startsWith("SDY", true) || sourceFamily.contains("IMM", true) -> "IMMPORT_STUDY_ARM_PARSER"
        else -> "GENERIC_ACCESSION_METADATA_PARSER"
    }

    private fun contradictionTermsFor(rule: MetadataClosureIntersectionRuleV11057): List<String> = when (rule.ruleId) {
        "R1_NEURO_VIRAL_BRIDGE" -> listOf("EBV no association SLE", "HHV-6 no association multiple sclerosis", "viral reactivation batch effect", "cell composition artifact", "negative control autoimmunity")
        "R2_PSYCHEPHYSIOLOGICAL_EXPOSOME" -> listOf("sleep deprivation cytokine no association", "cortisol DHEA null result", "IL-6 TNF-alpha batch effect", "curcumin ashwagandha placebo control", "HPA axis confounding")
        else -> listOf("no association", "failed replication", "negative control", "batch effect", "heterogeneity")
    }

    private fun researchQuestion(steering: ResearchSteeringProfile?, rules: List<MetadataClosureIntersectionRuleV11057>): String {
        val focus = steering?.focusQuestion?.takeIf { it.isNotBlank() }
        val ruleText = rules.joinToString("; ") { it.label }.takeIf { it.isNotBlank() }
        return firstKnown(focus, ruleText, "Which accession-level datasets are structurally ready to test the proposed immune mechanism route?")
    }

    private fun nextAction(state: String, cards: List<AccessionCandidateCardV1110>, routes: List<MechanismRouteProposalV1110>, matrix: MetadataClosureStrategyMatrixReport): String = when (state) {
        "GRADED_RESEARCH_LEADS_IN_PROGRESS" -> "Show graded research leads now, then upgrade only by closing accession, comparator, matrix, sample-count, and contradiction gaps."
        "ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED" -> "Run accession validation and comparator extraction: extract real GSE/GSM/PRJNA/SRP/SRR handles, then parse sample metadata, comparator labels, and matrix availability."
        "HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION" -> "Run accession-specific GEO/SRA search from Hyper-Drive streams; create AccessionCandidate only from real GSE/GSM/PRJNA/SRP/SRR handles."
        "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT" -> "Parse sample metadata for healthy/matched/baseline/placebo/responder/non-responder labels before creating EvidenceObject."
        "MATRIX_READY_FOR_REVIEW_NO_CLAIM" -> "Run controlled matrix-readiness review; keep all DGE/fold-change/p-value claims blocked until real analysis executes."
        else -> cards.firstOrNull()?.blockingGaps?.firstOrNull()?.let { "Close blocking gap: $it for ${cards.first().accessionId}." }
            ?: routes.firstOrNull()?.nextAccessionSpecificQuery?.let { "Execute accession-specific query: $it" }
            ?: matrix.nextAction
    }

    private fun conciseLines(
        state: String,
        researchQuestion: String,
        evidenceGrade: String,
        cards: List<AccessionCandidateCardV1110>,
        enrichmentCards: List<SourceMetadataEnrichmentCardV1113>,
        matrixGate: String,
        accessionGate: String,
        readinessScore: Int,
        routes: List<MechanismRouteProposalV1110>,
        blockers: List<String>,
        next: String,
        accessionValidationCards: List<AccessionValidationCardV1114> = emptyList(),
        comparatorExtractionCards: List<ComparatorExtractionCardV1114> = emptyList(),
        exploratoryResearchLeads: List<ExploratoryResearchLeadV1115> = emptyList(),
        evidenceObjectCreationGate: String = "EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION"
    ): List<String> = listOf(
        "Research-Grade Mechanism Discovery Dossier",
        "State: $state | Evidence grade: $evidenceGrade",
        "Research question: ${researchQuestion.take(180)}",
        "Accession candidates: ${cards.size} | source-enrichment=${enrichmentCards.size} | first=${cards.firstOrNull()?.accessionId ?: "none"}",
        "Accession gate: $accessionGate | readiness=$readinessScore/100",
        "Validation cards: ${accessionValidationCards.size} | first=${accessionValidationCards.firstOrNull()?.validationState ?: "none"}",
        "Comparator extraction: ${comparatorExtractionCards.firstOrNull()?.extractionState ?: "none"} | confidence=${comparatorExtractionCards.firstOrNull()?.comparatorConfidence ?: 0}/100",
        "Research lead: ${exploratoryResearchLeads.firstOrNull()?.targetAxis ?: "none"} | confidence=${exploratoryResearchLeads.firstOrNull()?.confidence ?: 0}/100 | mode=${if (exploratoryResearchLeads.isNotEmpty()) "graded/in-progress" else "none"}",
        "EvidenceObject gate: $evidenceObjectCreationGate",
        "Matrix gate: $matrixGate",
        "Mechanism route: ${routes.firstOrNull()?.targetMolecularAxis ?: "none verified"}",
        "Blocking gaps: ${blockers.take(6).joinToString(", ")}",
        "Next decisive action: ${next.take(220)}",
        "GTIM mode: corpus-relative mechanism hypothesis dossier; novelty is under-tested-route detection, not proof.",
        "Do not believe yet: no diagnosis, treatment, patient prediction, causal claim, clinical utility, DGE, fold-change, or p-value."
    )

    private fun normalizeAccession(value: String): String = value.trim().uppercase(Locale.US)
    private fun firstKnown(vararg values: String?): String = values.firstOrNull { !it.isNullOrBlank() && it != "unknown" } ?: "unknown"

    val DEFAULT_DO_NOT_BELIEVE = listOf(
        "Graded research leads are allowed even when EvidenceObject is blocked; they are in-progress hypotheses, not proof.",
        "No biological mechanism is proven by accession, metadata, or graded lead alone.",
        "No differential expression result exists until a real expression matrix, sample metadata, comparator structure, and analysis are available.",
        "No patient-level prediction, flare forecast, diagnosis, treatment, dose, or supplement recommendation is allowed.",
        "No fold-change, p-value, cytokine effect, or gene up-regulation may be invented.",
        "GTIM novelty is corpus-relative and must include contradiction/null-result search plus a falsification plan."
    )

    val DEFAULT_LOCKS = listOf(
        "HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION",
        "GRADED_EXPLORATORY_RESULTS_ALLOWED_WITH_CONFIDENCE_AND_GAPS",
        "DGE_NOT_READY_METADATA_GAP unless matrix + metadata + comparator + labels close",
        "COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT when comparator labels are absent",
        "Mechanism route proposal is not a biological conclusion",
        "Contradiction/null-result search required before route strengthening",
        "GTIM v2.5 dossier must remain connected to accession/comparator/matrix gates and never bypass them"
    )
}
