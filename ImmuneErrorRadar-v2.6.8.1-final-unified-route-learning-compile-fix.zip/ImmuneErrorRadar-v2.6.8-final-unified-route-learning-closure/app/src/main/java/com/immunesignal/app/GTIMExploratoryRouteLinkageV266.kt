package com.immunesignal.app

/**
 * v2.6.6: lightweight route-linkage precheck for exploratory mode.
 *
 * This does not execute network requests. It verifies that the same research question opens
 * parser -> planner -> resolver/source families -> seed accession bootstrap paths before the
 * runtime spends a cycle. Claim upgrade gates remain unchanged.
 */
data class GTIMExploratoryRouteLinkageTraceV266(
    val active: Boolean,
    val version: String,
    val parserLinked: Boolean,
    val plannerLinked: Boolean,
    val europePmcLinked: Boolean,
    val openAlexLinked: Boolean,
    val seedBootstrapLinked: Boolean,
    val comparativeLinked: Boolean,
    val exposomeLinked: Boolean,
    val directRouterLinked: Boolean,
    val resolverSupported: Boolean,
    val publicLookupActionCount: Int,
    val routeFamilies: List<String>,
    val nextAction: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

object GTIMExploratoryRouteLinkageV266 {
    const val VERSION: String = "2.6.8-final-unified-route-learning-closure"

    fun trace(question: String): GTIMExploratoryRouteLinkageTraceV266 {
        if (!RuntimeFeatureFlags.ENABLE_EXPLORATORY_ROUTE_LINKAGE_PRECHECK_V266) {
            return GTIMExploratoryRouteLinkageTraceV266(
                active = false,
                version = VERSION,
                parserLinked = false,
                plannerLinked = false,
                europePmcLinked = false,
                openAlexLinked = false,
                seedBootstrapLinked = false,
                comparativeLinked = false,
                exposomeLinked = false,
                directRouterLinked = false,
                resolverSupported = false,
                publicLookupActionCount = 0,
                routeFamilies = emptyList(),
                nextAction = "Exploratory route-linkage precheck disabled."
            )
        }
        val intent = GTIMResearchIntentParserV255.parse(question)
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        val accessionPressureMemory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord(
                    failedQueryHash = "exploratory_route_linkage_precheck",
                    sourceFamily = "PUBMED_ACCESSION_MINING",
                    rootCause = "NO_DATASET_ACCESSION+BROAD_QUERY",
                    cooldownCyclesRemaining = 0,
                    lastAttemptedAtMillis = 0L,
                    timesFailed = 1,
                    forcedNextSource = "EUROPE_PMC_DATA_AVAILABILITY"
                )
            ),
            summary = "Synthetic accession-pressure snapshot for route-linkage precheck only."
        )
        val routeFamilies = DirectDatasetSourceRouter.routes(accessionPressureMemory)
            .map { it.sourceFamily }
            .distinct()
        val repos = plan.repositorySearchPlan.map { it.repository }
        val europe = repos.any { it.equals("Europe PMC", ignoreCase = true) } || routeFamilies.contains("EUROPE_PMC_DATA_AVAILABILITY")
        val openAlex = repos.any { it.equals("OpenAlex", ignoreCase = true) } || routeFamilies.contains("OPENALEX_WORKS_DATASETS")
        val seed = repos.any { it.equals("Seed Accession Bootstrap", ignoreCase = true) } ||
            GTIMSeedAccessionBootstrapV265.queriesForText(question).isNotEmpty()
        val comparative = repos.any { it.equals("Comparative Disease Pathways", ignoreCase = true) } ||
            GTIMComparativeDiseasePathwaysV264.querySeedsForText(question).isNotEmpty()
        val exposome = repos.any { it.equals("Exposome Immune Bridges", ignoreCase = true) } ||
            GTIMExposomeImmuneBridgeV267.querySeedsForText(question).isNotEmpty()
        val lookupCount = listOf(europe, openAlex, seed).count { it }
        val resolver = GTIMOpenDataResolverV256.SUPPORTED_SOURCES.any { it.contains("Europe PMC") } &&
            GTIMOpenDataResolverV256.SUPPORTED_SOURCES.any { it.contains("OpenAlex") } &&
            GTIMOpenDataResolverV256.SUPPORTED_SOURCES.any { it.contains("Seed accession") }
        val ok = intent.active && plan.active && lookupCount >= RuntimeFeatureFlags.EXPLORATORY_MIN_PUBLIC_LOOKUP_ACTIONS_V266 && resolver
        return GTIMExploratoryRouteLinkageTraceV266(
            active = ok,
            version = VERSION,
            parserLinked = intent.active,
            plannerLinked = plan.active,
            europePmcLinked = europe,
            openAlexLinked = openAlex,
            seedBootstrapLinked = seed,
            comparativeLinked = comparative,
            exposomeLinked = exposome,
            directRouterLinked = routeFamilies.contains("EUROPE_PMC_DATA_AVAILABILITY") && routeFamilies.contains("OPENALEX_WORKS_DATASETS"),
            resolverSupported = resolver,
            publicLookupActionCount = lookupCount,
            routeFamilies = routeFamilies,
            nextAction = if (ok) {
                "Run user-triggered public lookup: Europe PMC/OpenAlex/seed bootstrap are linked to the planner and direct router; keep claims exploratory until accession/comparator/matrix gates close."
            } else {
                "Repair parser/planner/resolver/source-family linkage before declaring the cycle closed."
            }
        )
    }
}
