package com.immunesignal.app

/**
 * GTIM v2.5.5 DataFeed Planner.
 *
 * Turns a parsed research intent into a visible repository/search plan. This closes the gap where
 * the final brief previously said only "feed one seed" and did not expose usable data channels.
 */
data class GTIMRepositoryQueryV255(
    val repository: String,
    val priority: String,
    val purpose: String,
    val query: String,
    val accessionPatterns: List<String>,
    val metadataTargets: List<String>,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMDataFeedPlanV255(
    val active: Boolean,
    val plannerVersion: String,
    val status: String,
    val dataFeedPlanScore: Int,
    val repositorySearchPlan: List<GTIMRepositoryQueryV255>,
    val querySeeds: List<String>,
    val accessionPatterns: List<String>,
    val metadataTargets: List<String>,
    val comparatorTargets: List<String>,
    val matrixTargets: List<String>,
    val contradictionTargets: List<String>,
    val bestNextAction: String,
    val githubPosture: String,
    val playProtectPosture: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty() = GTIMDataFeedPlanV255(
            active = false,
            plannerVersion = GTIMDataFeedPlannerV255.VERSION,
            status = "GTIM_DATAFEED_PLAN_NOT_EVALUATED",
            dataFeedPlanScore = 0,
            repositorySearchPlan = emptyList(),
            querySeeds = emptyList(),
            accessionPatterns = GTIMDataFeedPlannerV255.ACCESSION_PATTERNS,
            metadataTargets = GTIMDataFeedPlannerV255.METADATA_TARGETS,
            comparatorTargets = emptyList(),
            matrixTargets = GTIMDataFeedPlannerV255.MATRIX_TARGETS,
            contradictionTargets = emptyList(),
            bestNextAction = "Parse research intent before building data-feed plan.",
            githubPosture = "not evaluated",
            playProtectPosture = "not evaluated"
        )
    }
}

object GTIMDataFeedPlannerV255 {
    const val VERSION: String = "2.6.8-final-unified-route-learning-closure"
    val ACCESSION_PATTERNS = listOf("GSE", "GDS", "PRJNA", "SRP", "SRR", "E-MTAB", "E-GEOD", "SDY", "PMID", "DOI")
    val METADATA_TARGETS = listOf("sample count", "organism", "biospecimen", "tissue/cell context", "condition labels", "outcome labels", "timepoints", "platform", "data availability")
    val MATRIX_TARGETS = listOf("Series Matrix File", "count matrix", "expression matrix", "supplementary processed files", "sample annotation table")

    fun plan(intent: GTIMResearchIntentObjectV255): GTIMDataFeedPlanV255 {
        if (!intent.active) return GTIMDataFeedPlanV255.empty()
        val core = coreTerms(intent)
        val comparator = intent.comparatorWanted.ifEmpty { listOf("healthy control", "matched control", "baseline", "case-control") }
        val assays = intent.assayType.ifEmpty { listOf("RNA-seq", "scRNA-seq", "microarray", "cytokine profiling") }
        val queryBase = buildQuery(core, assays)
        val repositories = normalizeRepositories(intent.repositoryTargets)
        val queries = mutableListOf<GTIMRepositoryQueryV255>()
        val comparativeCorpus = (intent.sourceText + " " + core.joinToString(" ") + " " + comparator.joinToString(" ")).trim()
        val comparativeClosure = GTIMComparativeDiseasePathwaysV264.closeCycle(comparativeCorpus)
        val comparativeSeeds = GTIMComparativeDiseasePathwaysV264.querySeedsForText(comparativeCorpus)
        val exposomeClosure = GTIMExposomeImmuneBridgeV267.closeCycle(comparativeCorpus)
        val exposomeSeeds = GTIMExposomeImmuneBridgeV267.querySeedsForText(comparativeCorpus)
        val bootstrapSeeds = GTIMSeedAccessionBootstrapV265.queriesForText(comparativeCorpus)

        if (comparativeSeeds.isNotEmpty()) {
            queries += repositoryQuery(
                repository = "Comparative Disease Pathways",
                priority = "comparison preflight",
                purpose = "cross-disease comparator-first route for cancer/HIV-fungal/epidemic immune patterns",
                query = comparativeSeeds.take(3).joinToString(" | "),
                patterns = ACCESSION_PATTERNS,
                targets = METADATA_TARGETS + listOf(
                    "shared axes",
                    "differentiator gates",
                    "disease-specific antigen/pathogen/tissue context",
                    "no disease-equivalence claim",
                    comparativeClosure.closureState
                )
            )
        }

        if (exposomeSeeds.isNotEmpty()) {
            queries += repositoryQuery(
                repository = "Exposome Immune Bridges",
                priority = "exposure-metadata preflight",
                purpose = "bounded gut/endocrine/food-water-plastic exposure route; measured exposure required before any upgrade",
                query = exposomeSeeds.take(4).joinToString(" | "),
                patterns = ACCESSION_PATTERNS,
                targets = METADATA_TARGETS + listOf(
                    "measured exposure metadata",
                    "sample matrix/source route",
                    "dose/window or timepoint proxy",
                    "exposed/unexposed comparator",
                    "no exposure-attribution claim",
                    exposomeClosure.closureState
                )
            )
        }

        if (repositories.any { it.contains("GEO", true) }) {
            queries += repositoryQuery(
                repository = "GEO/GDS",
                priority = "high priority",
                purpose = "accession + matrix search",
                query = "$queryBase AND (GSE OR GDS OR \"Series Matrix File\")",
                patterns = listOf("GSE", "GDS", "GSM", "GPL"),
                targets = METADATA_TARGETS + MATRIX_TARGETS
            )
        }
        if (repositories.any { it.contains("SRA", true) || it.contains("BioProject", true) || it.contains("PRJNA", true) }) {
            queries += repositoryQuery(
                repository = "SRA/BioProject",
                priority = "high priority",
                purpose = "sequencing project lookup",
                query = "$queryBase AND (PRJNA OR SRP OR SRR OR BioProject) AND (${comparator.joinToString(" OR ")})",
                patterns = listOf("PRJNA", "SRP", "SRR"),
                targets = METADATA_TARGETS + listOf("run table", "library strategy", "BioSample attributes")
            )
        }
        if (repositories.any { it.contains("ArrayExpress", true) || it.contains("E-MTAB", true) }) {
            queries += repositoryQuery(
                repository = "ArrayExpress/BioStudies",
                priority = "secondary",
                purpose = "European archive accession lookup",
                query = "$queryBase AND (E-MTAB OR E-GEOD OR ArrayExpress) AND (${assays.joinToString(" OR ")})",
                patterns = listOf("E-MTAB", "E-GEOD"),
                targets = METADATA_TARGETS + MATRIX_TARGETS
            )
        }
        if (repositories.any { it.contains("ImmPort", true) || it.contains("SDY", true) }) {
            queries += repositoryQuery(
                repository = "ImmPort/SDY",
                priority = "secondary",
                purpose = "immune cohort / cytokine / cell subset lookup",
                query = "$queryBase AND (SDY OR ImmPort OR cytokine OR flow cytometry)",
                patterns = listOf("SDY"),
                targets = METADATA_TARGETS + listOf("immune assay panels", "cell subset annotations", "controlled-access status")
            )
        }
        if (RuntimeFeatureFlags.ENABLE_EUROPE_PMC_LOOKUP_V265 && repositories.any { it.contains("Europe PMC", true) || it.contains("PMC", true) || it.contains("PubMed", true) }) {
            queries += repositoryQuery(
                repository = "Europe PMC",
                priority = "high priority",
                purpose = "real public literature/data-availability lookup through Europe PMC REST",
                query = "$queryBase AND (\"Data Availability\" OR GSE OR PRJNA OR SRP OR E-MTAB OR SDY OR accession OR deposited)",
                patterns = listOf("PMID", "DOI", "PMCID", "GSE", "PRJNA", "SRP", "E-MTAB", "SDY"),
                targets = listOf("Europe PMC id", "PMID", "DOI", "PMCID", "abstract text", "data availability statement", "accession handles", "full text link hints") + METADATA_TARGETS
            )
        }
        if (RuntimeFeatureFlags.ENABLE_OPENALEX_LOOKUP_V265 && repositories.any { it.contains("OpenAlex", true) || it.contains("PubMed", true) || it.contains("Europe PMC", true) }) {
            queries += repositoryQuery(
                repository = "OpenAlex",
                priority = "secondary cross-index",
                purpose = "real public works lookup for DOI/open-access/cited-by/source metadata and discovery broadening",
                query = "$queryBase AND (dataset OR accession OR transcriptome OR cohort OR comparator OR data availability)",
                patterns = listOf("DOI", "OpenAlex Work", "PMID", "PMCID"),
                targets = listOf("OpenAlex work id", "DOI", "publication year", "open access status", "primary location", "abstract inverted index", "referenced works/citation context") + METADATA_TARGETS
            )
        }
        if (RuntimeFeatureFlags.ENABLE_SEED_ACCESSION_BOOTSTRAP_V265 && bootstrapSeeds.isNotEmpty()) {
            queries += repositoryQuery(
                repository = "Seed Accession Bootstrap",
                priority = "exploratory bootstrap",
                purpose = "preloaded accession/query handles for the most important axes; lookup only, never evidence",
                query = bootstrapSeeds.take(4).joinToString(" | "),
                patterns = ACCESSION_PATTERNS,
                targets = METADATA_TARGETS + MATRIX_TARGETS + listOf("seed handle resolver confirmation", GTIMSeedAccessionBootstrapV265.CLAIM_LIMIT)
            )
        }
        queries += repositoryQuery(
            repository = "PubMed Data Availability",
            priority = "high priority",
            purpose = "data availability mining",
            query = "$queryBase AND \"Data Availability\" AND (GSE OR PRJNA OR SRP OR E-MTAB OR SDY OR deposited)",
            patterns = listOf("PMID", "DOI", "GSE", "PRJNA", "SRP", "E-MTAB", "SDY"),
            targets = listOf("data availability statement", "accession handles", "cohort description", "methods", "null/negative findings")
        )
        queries += repositoryQuery(
            repository = "Contradiction / null-result search",
            priority = "contradiction search",
            purpose = "active contradiction and failed-replication hunt",
            query = "$queryBase AND (\"no association\" OR \"null result\" OR \"negative result\" OR \"failed replication\" OR \"opposite direction\")",
            patterns = listOf("PMID", "DOI"),
            targets = listOf("null result", "opposite biomarker direction", "failed replication", "species/tissue mismatch")
        )
        val capped = queries.distinctBy { it.repository + it.query }.take(16)
        val score = (intent.queryReadinessScore * 0.55 + capped.size * 5 + if (intent.comparatorWanted.isNotEmpty()) 15 else 0).toInt().coerceIn(0, 100)
        return GTIMDataFeedPlanV255(
            active = true,
            plannerVersion = VERSION,
            status = "GTIM_DATAFEED_PLAN_VISIBLE",
            dataFeedPlanScore = score.coerceAtLeast(if (RuntimeFeatureFlags.ENABLE_EXPLORATORY_RUNTIME_RELAXATION_V265) RuntimeFeatureFlags.EXPLORATORY_ROUTE_SURFACE_MIN_SCORE_V266 else 0),
            repositorySearchPlan = capped,
            querySeeds = (capped.map { it.query } + comparativeSeeds + exposomeSeeds + bootstrapSeeds).distinct().take(RuntimeFeatureFlags.EXPLORATORY_MAX_BOOTSTRAP_ACCESSION_SEEDS_V265),
            accessionPatterns = ACCESSION_PATTERNS,
            metadataTargets = METADATA_TARGETS,
            comparatorTargets = (comparator + comparativeClosure.cards.flatMap { it.requiredComparatorEvidence } + exposomeClosure.cards.flatMap { it.requiredComparatorEvidence }).distinct().take(18),
            matrixTargets = MATRIX_TARGETS,
            contradictionTargets = (listOf("null result", "no association", "opposite direction", "failed replication", "species mismatch", "tissue mismatch", "comparator weakness", "exposure measurement missing", "dose/window missing") + comparativeClosure.cards.flatMap { it.upgradeBlockers } + exposomeClosure.cards.flatMap { it.upgradeBlockers }).distinct().take(22),
            bestNextAction = if (comparativeSeeds.isNotEmpty()) {
                "Run comparative preflight first, then accession search: ${comparativeSeeds.first().take(220)}"
            } else if (exposomeSeeds.isNotEmpty()) {
                "Run exposome preflight first, then public lookup: ${exposomeSeeds.first().take(220)}"
            } else {
                capped.firstOrNull()?.let { "Run ${it.repository} query: ${it.query}" } ?: "Feed one PMID/DOI/GSE/PRJNA/SRP/SRR/E-MTAB/SDY/PDF/snippet seed."
            },
            githubPosture = "DataFeed planner is deterministic and audit-visible; no background job is required for GitHub CI.",
            playProtectPosture = "User-triggered public-data lookup plan only; no hidden scraping, no patient upload, no tracking, no clinical decision."
        )
    }

    private fun coreTerms(intent: GTIMResearchIntentObjectV255): List<String> =
        (intent.triggerExposure + intent.diseasePhenotype + intent.pathway + intent.cellTissue)
            .filter { it.isNotBlank() }
            .distinct()
            .ifEmpty { listOf("immune response", "human", "transcriptome") }

    private fun buildQuery(core: List<String>, assay: List<String>): String {
        val coreQuery = core.take(8).joinToString(" OR ") { quoteIfNeeded(it) }
        val assayQuery = assay.take(6).joinToString(" OR ") { quoteIfNeeded(it) }
        return "($coreQuery) AND ($assayQuery)"
    }

    private fun quoteIfNeeded(value: String): String = if (value.contains(" ") || value.contains("/")) "\"$value\"" else value

    private fun normalizeRepositories(repositories: List<String>): List<String> =
        if (repositories.isEmpty()) GTIMResearchIntentParserV255.DEFAULT_REPOSITORIES else repositories

    private fun repositoryQuery(
        repository: String,
        priority: String,
        purpose: String,
        query: String,
        patterns: List<String>,
        targets: List<String>
    ) = GTIMRepositoryQueryV255(
        repository = repository,
        priority = priority,
        purpose = purpose,
        query = query,
        accessionPatterns = patterns,
        metadataTargets = targets.distinct()
    )
}
