package com.immunesignal.app

import java.util.Locale

/**
 * GTIM v2.6.3 Accession Seed Capture.
 *
 * This layer breaks the old loop where the engine kept asking for a seed even after the user
 * pasted a concrete GSE/PRJNA/SRP/SDY/E-MTAB handle. A captured seed is not a biological proof and
 * not an EvidenceObject upgrade, but it must be visible as a primary repository handle and must
 * drive metadata/comparator/matrix closure next.
 */
data class GTIMCapturedAccessionSeedV260(
    val accessionId: String,
    val repository: String,
    val seedType: String,
    val status: String,
    val matrixState: String,
    val comparatorState: String,
    val routeState: String,
    val evidenceState: String,
    val nextAction: String,
    val repositoryLookupQuery: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMAccessionSeedCaptureReportV260(
    val active: Boolean,
    val version: String,
    val status: String,
    val capturedSeeds: List<GTIMCapturedAccessionSeedV260>,
    val primarySeed: String,
    val relaxedDiscoveryState: String,
    val accessionCountForBrief: Int,
    val dataFeedBoostActions: List<String>,
    val upgradePolicy: String,
    val routeFitPosture: String,
    val playProtectPosture: String,
    val githubPosture: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty(): GTIMAccessionSeedCaptureReportV260 = GTIMAccessionSeedCaptureReportV260(
            active = false,
            version = GTIMAccessionSeedCaptureV260.VERSION,
            status = "NO_ACCESSION_SEED_CAPTURED",
            capturedSeeds = emptyList(),
            primarySeed = "",
            relaxedDiscoveryState = "DISCOVERY_CONTINUES_WITHOUT_PRIMARY_SEED",
            accessionCountForBrief = 0,
            dataFeedBoostActions = emptyList(),
            upgradePolicy = GTIMAccessionSeedCaptureV260.UPGRADE_POLICY,
            routeFitPosture = "route fit not evaluated before metadata when no accession seed is present",
            playProtectPosture = GTIMAccessionSeedCaptureV260.PLAY_PROTECT_POSTURE,
            githubPosture = "seed capture idle"
        )
    }
}

object GTIMAccessionSeedCaptureV260 {
    const val VERSION: String = "2.6.8-final-unified-route-learning-closure"
    const val STATUS_CAPTURED: String = "ACCESSION_SEED_CAPTURED_MATRIX_PENDING"
    const val UPGRADE_POLICY: String = "Captured accession seed is a repository handle, not evidence. Upgrade only after metadata, comparator, matrix, and contradiction closure."
    const val PLAY_PROTECT_POSTURE: String = "User-supplied or user-triggered public repository handle parsing only; no hidden background scraping, no patient data upload, no tracking, no clinical decision."

    private val accessionRegex = Regex(
        """\b(GSE\s*\d+|GSM\s*\d+|GDS\s*\d+|GPL\s*\d+|SDY\s*\d+|PRJNA\s*\d+|PRJEB\s*\d+|PRJDB\s*\d+|SRP\s*\d+|SRA\s*\d+|SRR\s*\d+|SRX\s*\d+|SRS\s*\d+|ERR\s*\d+|ERX\s*\d+|ERP\s*\d+|DRR\s*\d+|DRX\s*\d+|DRP\s*\d+|E-MTAB-\s*\d+|E-GEOD-\s*\d+|E-MEXP-\s*\d+|EGAS\s*\d+|SAMN\s*\d+|SAMEA\s*\d+|SAMD\s*\d+|phs\s*\d+(?:\.v\d+\.p\d+)?)\b""",
        RegexOption.IGNORE_CASE
    )

    fun evaluate(report: ResearchGradeMechanismDossierReportV1110, intent: GTIMResearchIntentObjectV255): GTIMAccessionSeedCaptureReportV260 {
        val scanned = scanReport(report, intent)
        val seeds = scanned
            .map { normalizeAccession(it) }
            .filter { isRealRepositoryAccession(it) }
            .distinct()
            .map { seed -> capturedSeed(seed, report) }
            .sortedWith(compareByDescending<GTIMCapturedAccessionSeedV260> { priority(it.accessionId) }.thenBy { it.accessionId })
            .take(12)
        if (seeds.isEmpty()) return GTIMAccessionSeedCaptureReportV260.empty()
        val primary = seeds.first().accessionId
        return GTIMAccessionSeedCaptureReportV260(
            active = true,
            version = VERSION,
            status = STATUS_CAPTURED,
            capturedSeeds = seeds,
            primarySeed = primary,
            relaxedDiscoveryState = "ACCESSION_SEED_CAPTURED_KEEP_DISCOVERY_ALIVE",
            accessionCountForBrief = seeds.size,
            dataFeedBoostActions = listOf(
                "Open repository metadata for $primary and parse title, organism, platform, sample count, tissue/cell context, and sample table.",
                "Do not mark $primary as OFF_ROUTE until metadata is known; use ROUTE_UNRESOLVED_METADATA_PENDING.",
                "Close comparator labels before evidence upgrade: healthy/matched/baseline/placebo/responder/non-responder/case.",
                "Close matrix availability before DGE: Series Matrix/count matrix/supplementary processed file/SRA run table.",
                "Keep exploratory routes visible while evidence layer remains gated."
            ),
            upgradePolicy = UPGRADE_POLICY,
            routeFitPosture = "Never classify a captured accession seed as OFF_ROUTE before repository metadata is parsed; use ROUTE_UNRESOLVED_METADATA_PENDING.",
            playProtectPosture = PLAY_PROTECT_POSTURE,
            githubPosture = "GTIM v2.6.3 seed capture is JSON-visible, brief-visible, and audit-guarded; GSE input must not produce accessions=0."
        )
    }

    fun isRealRepositoryAccession(value: String): Boolean = accessionRegex.matches(value.trim())

    private fun scanReport(report: ResearchGradeMechanismDossierReportV1110, intent: GTIMResearchIntentObjectV255): List<String> {
        val chunks = mutableListOf<String>()
        chunks += intent.sourceText
        chunks += intent.parsedResearchIntentCard.joinToString(" ")
        chunks += report.researchQuestion
        chunks += report.bestResearchLeadSummary
        chunks += report.metadataExtractionCommands.joinToString(" ")
        chunks += report.blockingGaps.joinToString(" ")
        chunks += report.nextDecisiveAction
        chunks += report.conciseDossierLines.joinToString(" ")
        chunks += report.accessionCandidates.flatMap { card ->
            listOf(card.accessionId, card.titleOrSnippet, card.repositoryLookupQuery, card.metadataFileHints.joinToString(" "), card.matrixFileHints.joinToString(" "))
        }
        chunks += report.sourceMetadataEnrichmentCards.flatMap { card ->
            listOf(card.sourceId, card.sourceFamily, card.sourceKind, card.sourceStatus, card.detectedAccessions.joinToString(" "), card.accessionPatternQuery, card.nextAction)
        }
        chunks += report.accessionValidationCards.flatMap { card ->
            listOf(card.accessionId, card.repositoryLookupQuery, card.metadataExtractionCommand, card.blockingGaps.joinToString(" "))
        }
        chunks += report.exploratoryResearchLeads.flatMap { lead ->
            listOf(lead.leadId, lead.targetAxis, lead.supportingSignals.joinToString(" "), lead.nextQuery)
        }
        chunks += report.mechanismRoutes.flatMap { route ->
            listOf(route.routeId, route.targetMolecularAxis, route.nextAccessionSpecificQuery)
        }
        return accessionRegex.findAll(chunks.joinToString("\n"))
            .map { it.value }
            .toList()
    }

    private fun capturedSeed(seed: String, report: ResearchGradeMechanismDossierReportV1110): GTIMCapturedAccessionSeedV260 {
        val existing = report.accessionCandidates.firstOrNull { normalizeAccession(it.accessionId) == seed }
        val comparator = when {
            existing?.controlComparatorLabels?.isNotEmpty() == true -> "COMPARATOR_SIGNALS_PARTIAL"
            existing != null -> "COMPARATOR_PENDING_METADATA_PARSE"
            else -> "COMPARATOR_UNKNOWN_METADATA_PENDING"
        }
        val matrix = when {
            existing?.matrixAvailability?.startsWith("MATRIX_AVAILABLE", true) == true -> existing.matrixAvailability
            existing != null -> "MATRIX_PENDING_REPOSITORY_INSPECTION"
            else -> "MATRIX_UNKNOWN_REPOSITORY_LOOKUP_PENDING"
        }
        return GTIMCapturedAccessionSeedV260(
            accessionId = seed,
            repository = repositoryFor(seed),
            seedType = when {
                existing != null -> "ACCESSION_CARD_PRESENT"
                seed.startsWith("GSE", true) -> "PRIMARY_GEO_SERIES_SEED"
                seed.startsWith("PRJ", true) -> "PRIMARY_BIOPROJECT_SEED"
                seed.startsWith("SR", true) -> "PRIMARY_SRA_SEED"
                seed.startsWith("E-MTAB", true) || seed.startsWith("E-GEOD", true) -> "PRIMARY_ARRAYEXPRESS_SEED"
                seed.startsWith("SDY", true) -> "PRIMARY_IMMPORT_SEED"
                else -> "PRIMARY_REPOSITORY_SEED"
            },
            status = STATUS_CAPTURED,
            matrixState = matrix,
            comparatorState = comparator,
            routeState = "ROUTE_UNRESOLVED_METADATA_PENDING",
            evidenceState = "ACCESSION_SEED_NOT_EVIDENCE_OBJECT",
            nextAction = "Resolve metadata for $seed before route-fit, comparator, matrix, or DGE upgrade.",
            repositoryLookupQuery = lookupQuery(seed)
        )
    }

    private fun normalizeAccession(raw: String): String {
        val compact = raw.trim().uppercase(Locale.US).replace(Regex("\\s+"), "")
        return if (compact.startsWith("PHS")) compact.lowercase(Locale.US) else compact
    }

    private fun repositoryFor(seed: String): String = when {
        seed.startsWith("GSE", true) || seed.startsWith("GSM", true) || seed.startsWith("GDS", true) || seed.startsWith("GPL", true) -> "GEO"
        seed.startsWith("PRJ", true) -> "BioProject"
        seed.startsWith("SR", true) || seed.startsWith("ER", true) || seed.startsWith("DR", true) || seed.startsWith("SAM", true) -> "SRA/BioSample"
        seed.startsWith("E-MTAB", true) || seed.startsWith("E-GEOD", true) || seed.startsWith("E-MEXP", true) -> "ArrayExpress/BioStudies"
        seed.startsWith("SDY", true) -> "ImmPort"
        seed.startsWith("EGAS", true) || seed.startsWith("phs", true) -> "controlled_access_repository"
        else -> "public_repository"
    }

    private fun lookupQuery(seed: String): String = when {
        seed.startsWith("GSE", true) -> "GEO $seed Series Matrix sample metadata characteristics_ch1 control comparator supplementary files"
        seed.startsWith("PRJ", true) -> "BioProject $seed SRA run table BioSample attributes library_strategy phenotype comparator"
        seed.startsWith("SR", true) -> "SRA $seed run table BioSample attributes library_strategy phenotype comparator"
        seed.startsWith("E-MTAB", true) || seed.startsWith("E-GEOD", true) -> "ArrayExpress $seed IDF SDRF factor_value processed_data sample metadata"
        seed.startsWith("SDY", true) -> "ImmPort $seed study arms biosamples assessments immune assay comparator"
        else -> "$seed repository metadata sample table matrix comparator"
    }

    private fun priority(seed: String): Int = when {
        seed.startsWith("GSE", true) -> 100
        seed.startsWith("PRJ", true) -> 92
        seed.startsWith("SRP", true) -> 88
        seed.startsWith("SRR", true) -> 82
        seed.startsWith("E-MTAB", true) || seed.startsWith("E-GEOD", true) -> 78
        seed.startsWith("SDY", true) -> 74
        else -> 50
    }
}
