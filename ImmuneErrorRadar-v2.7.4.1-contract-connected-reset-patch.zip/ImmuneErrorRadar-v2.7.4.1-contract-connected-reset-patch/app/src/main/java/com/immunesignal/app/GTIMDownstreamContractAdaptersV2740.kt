package com.immunesignal.app

/**
 * Minimal adapters to connect existing downstream layers to the run contract.
 * Use these methods inside existing classes instead of local ifEmpty/defaultRoute/fallback logic.
 */
object GTIMDownstreamContractAdaptersV2740 {

    fun selectRoutesFromContract(
        contract: GTIMRunDecisionContractV2740,
        candidates: List<GTIMRouteGovernanceV2740.RouteCandidate>
    ): List<GTIMRouteGovernanceV2740.RouteDecision> {
        val evaluated = candidates.map { GTIMRouteGovernanceV2740.evaluate(contract, it) }
        val allowed = evaluated.filter { it.allowed }

        if (allowed.isNotEmpty()) return allowed

        // Stop dangerous fallbacks in user-directed mode.
        if (contract.runMode == GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED) {
            return listOf(
                GTIMRouteGovernanceV2740.RouteDecision(
                    decision = GTIMRouteGovernanceV2740.RouteDecisionType.ALLOW_PRIMARY_ANCHOR,
                    allowed = true,
                    routeId = contract.primaryAnchor.routeId,
                    label = GTIMEvidenceLabelV2740.PLAUSIBLE_MECHANISM,
                    claimMode = contract.claimMode,
                    confidenceCap = contract.evidenceCaps.routeConfidenceMax,
                    reason = "Fallback constrained to protected primary anchor only; no default/allergy/known-prior leakage."
                )
            )
        }

        // Autonomous mode may use broad exploration when no candidate survives.
        return listOf(
            GTIMRouteGovernanceV2740.RouteDecision(
                decision = GTIMRouteGovernanceV2740.RouteDecisionType.ALLOW_AUTONOMOUS_EXPLORATION,
                allowed = true,
                routeId = GTIMDiscoveryBridgeV2740.AUTONOMOUS_CROSS_DOMAIN_WEAK_LEAD.routeId,
                label = GTIMEvidenceLabelV2740.SPECULATIVE_BRIDGE,
                claimMode = GTIMClaimModeV2740.AUTONOMOUS_EXPLORATORY_HYPOTHESIS,
                confidenceCap = contract.evidenceCaps.routeConfidenceMax,
                reason = "Autonomous fallback: broad weak-lead exploration allowed and explicitly labeled."
            )
        )
    }

    fun selectSeedsFromContract(
        contract: GTIMRunDecisionContractV2740,
        proposedSeedIds: List<String>
    ): List<String> {
        val filtered = proposedSeedIds.filter { contract.canUseSeed(it) }.distinct()
        if (filtered.isNotEmpty()) return filtered

        return if (contract.runMode == GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED) {
            listOf(contract.primaryAnchor.routeId)
        } else {
            contract.allowedSeeds.take(12)
        }
    }

    fun benchmarkFromContract(contract: GTIMRunDecisionContractV2740): String {
        return contract.benchmarkTopic ?: contract.primaryAnchor.routeId
    }

    fun applyScoreCaps(
        contract: GTIMRunDecisionContractV2740,
        rawDataQuality: Int,
        rawEvidenceStrength: Int,
        rawRouteConfidence: Int
    ): Triple<Int, Int, Int> {
        val dq = rawDataQuality.coerceIn(0, contract.evidenceCaps.dataQualityMax)
        val ev = rawEvidenceStrength.coerceIn(0, contract.evidenceCaps.evidenceStrengthMax)
        val rc = rawRouteConfidence.coerceIn(0, contract.evidenceCaps.routeConfidenceMax)
        return Triple(dq, ev, rc)
    }

    fun uiSummary(contract: GTIMRunDecisionContractV2740): String {
        val main = when (contract.runMode) {
            GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED -> "Main question understood: ${contract.primaryAnchor.routeId}"
            GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION -> "Autonomous discovery: broad cross-domain exploration"
        }
        val paths = contract.discoveryBridges.take(5).joinToString(separator = "\n") { "- ${it.routeId}" }
        val warning = if (contract.evidenceCaps.causalityClaimAllowed) {
            "Claim strength: evidence-limited; causal claims require dataset support."
        } else {
            "Claim strength: exploratory only; not confirmed causality."
        }
        return "$main\n\nPossible discovery paths:\n$paths\n\n$warning\nEvidence cap: data=${contract.evidenceCaps.dataQualityMax}, evidence=${contract.evidenceCaps.evidenceStrengthMax}."
    }
}
