# GTIM v2.7.4.0 — Single Run Contract Reset

## Goal
Fix the root problem: early understanding/classification contamination.

The report is not the core contamination source. The problem happens earlier when the system turns shared immune terms into the wrong identity, e.g. treating Covid as allergy because both touch cytokines.

## Final rule

- User-directed run: protect the primary anchor, allow bridges around it.
- Autonomous discovery: allow broad cross-domain linking, but every bridge must be labeled.

```text
User question mode:
Protect the anchor, explore around it.

Autonomous discovery mode:
Explore freely, but label every claim.
```

## What this patch adds

### New files

- `GTIMRunDecisionContractV2740.kt`
- `GTIMRunDecisionContractFactoryV2740.kt`
- `GTIMRouteGovernanceV2740.kt`
- `GTIMDownstreamContractAdaptersV2740.kt`
- `GTIMRunDecisionContractV2740Test.kt`
- `GTIMDiseaseAcceptanceV2740Test.kt`
- `audit_v2740_run_contract_reset.py`

### Core contract fields

- `runMode`
- `primaryAnchor`
- `diseaseFamily`
- `secondaryDomains`
- `discoveryBridges`
- `allowedRoutes`
- `blockedRoutes`
- `allowedSeeds`
- `blockedSeeds`
- `benchmarkTopic`
- `forbiddenIdentityMutations`
- `forbiddenConflations`
- `evidenceCaps`
- `claimMode`

## Required integration points

Wire the contract into these existing layers:

1. `GTIMTopicSpecificRouteBuilder`
2. `GTIMRelationshipDiscoveryRouter`
3. `GTIMGeneralMicrobiomeImmuneBridge`
4. `GTIMKnownPriorEvidenceSeeds`
5. `GTIMBenchmarkValueHarness`
6. `GTIMDataFeedPlanner`
7. `GlobalResearchGradeBrief`

### Replace dangerous fallbacks

Remove or guard these patterns:

```kotlin
routes.first()
ifEmpty { defaultRoute }
ifEmpty { allergyRoute }
ifEmpty { knownPriorSeeds }
```

Use:

```kotlin
GTIMDownstreamContractAdaptersV2740.selectRoutesFromContract(contract, candidates)
GTIMDownstreamContractAdaptersV2740.selectSeedsFromContract(contract, proposedSeeds)
GTIMDownstreamContractAdaptersV2740.benchmarkFromContract(contract)
GTIMDownstreamContractAdaptersV2740.applyScoreCaps(contract, dq, ev, rc)
```

## Acceptance tests covered

- Covid shows Covid/interferon bridge and blocks allergy/pesticide/longevity contamination.
- Allergy shows type-2/IgE/mast/eosinophil and blocks Covid/Ebola/HIV mutation.
- Hantavirus becomes zoonotic viral, not allergy/Covid/generic inflammation.
- Ebola becomes hemorrhagic viral host response, not allergy/longevity/depression.
- HIV/AIDS becomes retroviral/CD4 immune depletion, not allergy/Covid/Ebola.
- Fever is treated as a syndrome/differential, not a single disease.
- Epidemic/outbreak is treated as surveillance/pathogen-emergence frame, not one locked disease.
- Gut bacteria → depression is allowed as an explicit bridge.
- Yeast/fungal exposure → endocrine/PCOS/thyroid is allowed as exploratory bridge, not strong causality.
- Autonomous mode can connect freely but labels results as speculative/weak/mechanistic unless evidence upgrades them.

## Evidence caps

If accessions are missing and matrix is `DGE_NOT_READY_NO_ACCESSION`:

- Data Quality max = 35
- Evidence Strength max = 25
- Causality claim = false

This prevents false certainty while still producing useful discovery leads.

## UI summary target

The UI should show useful biological learning, not internal technical states:

```text
Main question understood:
Covid immune disruption

Possible discovery paths:
- interferon memory
- microbiome disruption
- neuroinflammation/fatigue
- autoimmune-like persistence

What is not proven:
Exploratory bridge only. Dataset confirmation required before causal claim.
```

## Non-negotiable rule

```text
Shared biomarker ≠ same disease identity.
Shared biomarker = possible bridge.
```
