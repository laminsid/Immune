# GTIM v2.7.4.1 — Contract Connection Patch

## Judgment
v2.7.4.0 had the correct architecture but was not connected into the execution path. v2.7.4.1 keeps the V2740 API names to avoid churn, but adds the missing connector facade and fixes the reported classifier/cap bugs.

## P0 integration points

1. `ResearchAutopilot.runCycle()`
   - Build one contract at the start of the run using `GTIMRunContractRuntimeV2740.beginRun(...)`.
   - Pass/filter route IDs through `GTIMRunContractRuntimeV2740.filterRouteIds(...)`.
   - Pass/filter seed IDs through `GTIMRunContractRuntimeV2740.filterSeedIds(...)`.
   - Clear runtime holder at the end of the run.

2. `GlobalResearchGradeBriefV11061.kt`
   - Apply `GTIMDownstreamContractAdaptersV2740.applyScoreCaps(...)` before final scores are rendered.
   - Add `GTIMDownstreamContractAdaptersV2740.uiSummary(contract)` to the user-facing summary.

3. `GTIMRelationshipDiscoveryRouterV2736.kt`
   - After building relationship candidates, pass them through `GTIMRouteGovernanceV2740.evaluate(...)` or the runtime facade.

4. `GTIMDataFeedPlannerV255.kt`
   - Filter proposed seeds through `GTIMRunContractRuntimeV2740.filterSeedIds(...)`.

## Fixed bugs

- BUG-02: `IBD gut inflammation barrier` is now `IBD_INFLAMMATORY_BOWEL_DISEASE`, not depression.
- BUG-03: `hasDatasetAccessions=true + DGE_READY + confidence>=80` returns `normal()` caps: `100/100/100`.
- BUG-04: UNKNOWN user query converts to `AUTONOMOUS_DISCOVERY_FREE_EXPLORATION`, not fake protected UNKNOWN.

## New anchors

- IBD / Crohn / colitis
- SLE / lupus
- MS / demyelination
- RA / rheumatoid arthritis
- Psoriasis / IL-23 / IL-17
- Type 1 diabetes / beta-cell autoimmunity

## Required acceptance checks

```bash
python3 scripts/audit_v2741_contract_connection.py
./gradlew testDebugUnitTest
```

## Stop-ship rule
The build must fail review if these files do not reference the contract runtime or adapters:

- `ResearchAutopilot*`
- `GlobalResearchGradeBrief*`
- `GTIMRelationshipDiscoveryRouter*`
- `GTIMDataFeedPlanner*`

The provided audit checks the patch package itself and reports integration snippet presence. In the full repo, extend the same grep rule to `app/src/main/java`.
