#!/usr/bin/env python3
"""Audit for v2.7.4.0 single-run contract reset integration.
Run from project root after copying patch files.
"""
from pathlib import Path
import sys

ROOT = Path.cwd()
SRC = ROOT / "app" / "src" / "main" / "java" / "com" / "immunesignal" / "app"
TEST = ROOT / "app" / "src" / "test" / "java" / "com" / "immunesignal" / "app"

required = [
    SRC / "GTIMRunDecisionContractV2740.kt",
    SRC / "GTIMRunDecisionContractFactoryV2740.kt",
    SRC / "GTIMRouteGovernanceV2740.kt",
    SRC / "GTIMDownstreamContractAdaptersV2740.kt",
    TEST / "GTIMRunDecisionContractV2740Test.kt",
    TEST / "GTIMDiseaseAcceptanceV2740Test.kt",
]

missing = [str(p) for p in required if not p.exists()]
if missing:
    print("FAIL: missing files")
    for p in missing:
        print(" -", p)
    sys.exit(1)

text = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in SRC.glob("*.kt"))
required_symbols = [
    "GTIMRunDecisionContractV2740",
    "USER_DIRECTED_ANCHOR_PROTECTED",
    "AUTONOMOUS_DISCOVERY_FREE_EXPLORATION",
    "forbiddenConflations",
    "forbiddenIdentityMutations",
    "applyScoreCaps",
    "REJECT_IDENTITY_MUTATION",
]
missing_symbols = [s for s in required_symbols if s not in text]
if missing_symbols:
    print("FAIL: missing symbols")
    for s in missing_symbols:
        print(" -", s)
    sys.exit(1)

# Heuristic warning only: existing dangerous fallbacks should be replaced or guarded by the contract.
danger_patterns = [
    "routes.first()",
    "ifEmpty { defaultRoute",
    "ifEmpty { allergyRoute",
    "ifEmpty { knownPriorSeeds",
]
existing = []
for p in SRC.glob("*.kt"):
    body = p.read_text(encoding="utf-8", errors="ignore")
    for pat in danger_patterns:
        if pat in body and "V2740" not in p.name:
            existing.append((p.name, pat))

print("PASS: v2.7.4.0 contract reset files present")
if existing:
    print("WARN: dangerous fallback patterns still present; gate them through GTIMDownstreamContractAdaptersV2740:")
    for name, pat in existing:
        print(f" - {name}: {pat}")
