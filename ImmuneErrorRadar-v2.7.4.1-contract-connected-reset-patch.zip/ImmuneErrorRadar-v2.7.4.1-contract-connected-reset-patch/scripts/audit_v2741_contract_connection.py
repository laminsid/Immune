#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "app/src/main/java/com/immunesignal/app"
TEST = ROOT / "app/src/test/java/com/immunesignal/app"
DOCS = ROOT / "docs"
INTEGRATION = ROOT / "integration"

checks = []

def require_file(path):
    if not path.exists():
        print(f"FAIL missing file: {path.relative_to(ROOT)}")
        sys.exit(1)
    return path.read_text(encoding="utf-8")

contract = require_file(SRC / "GTIMRunDecisionContractV2740.kt")
factory = require_file(SRC / "GTIMRunDecisionContractFactoryV2740.kt")
runtime = require_file(SRC / "GTIMRunContractRuntimeV2740.kt")
tests = "\n".join(p.read_text(encoding="utf-8") for p in TEST.glob("*V274*.kt"))
docs = "\n".join(p.read_text(encoding="utf-8") for p in DOCS.glob("*.md"))
integration = "\n".join(p.read_text(encoding="utf-8") for p in INTEGRATION.glob("*.txt"))

required_contract_tokens = [
    "IBD_INFLAMMATORY_BOWEL_DISEASE",
    "SLE_SYSTEMIC_AUTOIMMUNE",
    "MS_NEUROIMMUNE_DEMYELINATION",
    "RA_SYNOVIAL_AUTOIMMUNE",
    "PSORIASIS_IL23_IL17_SKIN",
    "T1D_AUTOIMMUNE_BETA_CELL",
    "Shared biomarker != same disease identity",
]

required_factory_tokens = [
    "hasIbd() -> AnchorDetection",
    "GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE",
    "detected.anchor == GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY || detected.confidence < 60",
    "GTIMEvidenceCapsV2740.normal()",
    "state in readyMatrixStates",
    "gut_microbiome_to_depression_identity_mutation",
]

required_runtime_tokens = [
    "object GTIMRunContractRuntimeV2740",
    "private val activeContract = ThreadLocal",
    "beginRun(",
    "filterRouteIds(",
    "filterSeedIds(",
    "capScores(",
]

required_test_tokens = [
    "ibdGutBarrierDoesNotBecomeDepression",
    "readyAccessionBackedMatrixCanReceiveNormalCaps",
    "unknownUserQueryBecomesAutonomousNotProtectedUnknown",
    "psoriasisGetsOwnAnchor",
    "sleMsRaAndT1dGetSpecificAutoimmuneAnchors",
    "runtimeFacadeFiltersForbiddenRoutesAndCapsScores",
]

required_integration_tokens = [
    "ResearchAutopilot.runCycle",
    "GlobalResearchGradeBriefV11061.kt",
    "GTIMRelationshipDiscoveryRouterV2736.kt",
    "GTIMDataFeedPlannerV255.kt",
    "GTIMRunContractRuntimeV2740.beginRun",
    "applyScoreCaps",
]

for label, text, tokens in [
    ("contract", contract, required_contract_tokens),
    ("factory", factory, required_factory_tokens),
    ("runtime", runtime, required_runtime_tokens),
    ("tests", tests, required_test_tokens),
    ("integration", integration + docs, required_integration_tokens),
]:
    for token in tokens:
        if token not in text:
            print(f"FAIL {label}: missing token {token!r}")
            sys.exit(1)

print("PASS v2.7.4.1 contract connection audit")
