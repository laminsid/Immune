# EBV Criterion Lane v1.10.37

v1.10.37 adds a narrow EBV verification lane for weak/off-route leads such as manual text snippets.

The lane is intentionally conservative:

- EBV, HHV-6, CMV, Herpesviridae, latent-virus, reactivation, and molecular-mimicry terms may open a verification lane.
- The lane never upgrades a biological hypothesis by itself.
- It requires accession/source ID, human/patient context, outcome labels, control/comparator, time order, and contradiction/negative-control search before any later EvidenceObject can be considered.
- The UI must label this as a criterion/falsification lane, not as a discovery or breakthrough.

## New runtime object

`EBVLeadVerificationReport` records:

- `state`
- `targetLeadId`
- `criterionQuestion`
- `matchedTerms`
- `closedEvidence`
- `missingEvidence`
- `allowedNextAction`
- `blockedClaims`
- `invalidators`
- `claimLimit = ebv_criterion_lane_not_biological_proof`

## Locked claim language

Forbidden until evidence gates close:

- EBV causality
- first scientific breakthrough
- molecular mimicry confirmed
- autoimmune mechanism confirmed
- diagnosis/treatment recommendation

## Intended next behavior

For `MANUAL_TEXT_SNIPPET_fe34ffd5...`, the system should preserve the lead, run EBV criterion secondary lookup, and archive/cool down if no accession/source metadata, controls, time order, or contradiction coverage appears.
