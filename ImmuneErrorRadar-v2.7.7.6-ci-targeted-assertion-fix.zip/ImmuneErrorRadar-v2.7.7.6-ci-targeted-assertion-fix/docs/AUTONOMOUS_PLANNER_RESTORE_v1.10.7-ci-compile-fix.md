# Autonomous Planner Restore — v1.10.7 CI compile fix

## Problem
A previous dead-code cleanup removed `AutonomousResearcher.kt`, but the file was not dead. It still defines compile-critical autonomous research types used by:

- `QueryPlanner.kt`
- `ResearchAutopilot.kt`
- `ResearchModels.kt`

GitHub CI failed with unresolved references to `AutonomousResearchPlan`, `AutonomousResearchPlanner`, `AutonomousResearchLane`, and lane fields such as `laneType`, `label`, and `id`.

## Fix
Restored `AutonomousResearcher.kt` as a bounded strategy-planner module. This restores the autonomous planning data types and query-lane generation without reverting runtime hardening, NCBI hardening, stage linkage, search locks, or cycle audit work.

## Guard
Added `scripts/audit_autonomous_planner_restore_v1107.py` and wired it into `scripts/run_static_checks.sh` so this compile-critical file cannot be removed silently again.

## Scope
This is a compile fix only. No research behavior was expanded and no new cognitive layer was added.
