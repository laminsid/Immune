# v1.6.6-alpha-cognitive-loop-continuity

Purpose: harden the closed cognitive loop so it carries learning forward without replaying the same directive or inflating queries.

Changes:
- Added single-use consumption semantics to `CognitiveNextCycleDirective`.
- `readActiveCognitiveNextCycleDirective()` now ignores expired or consumed directives.
- `markCognitiveNextCycleDirectiveConsumed()` persists consumed state and records a ledger event.
- Repeated routing fingerprints from already-consumed directives are suppressed instead of saved as new active directives.
- `CognitiveNextCycleBridge.applyToQueries()` no longer adds a follow-up query if all directive terms are already present in the current query batch.
- Added `suppressedReason` and `directiveConsumed` to `CognitiveNextCyclePlan` JSON.
- Fixed `stableDirectiveId()` construction to avoid fragile Kotlin string interpolation.
- Added regression tests for consumed directives, query inflation suppression, and routing-fingerprint replay detection.

Guarantee:
- The loop remains routing-only.
- No biology is proven.
- No hypothesis is upgraded.
- Foundation JSON packs are never auto-updated.
