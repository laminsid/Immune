# v1.10.11 — Creative Hypothesis Forge

This patch adds a bounded creative layer after repeated no-candidate source attempts.

## Rule

Creative hypothesis generation is allowed only for routing and test design. It is not evidence, not causal proof, and not a hypothesis upgrade.

## Trigger

The forge runs only when dataset/source acquisition repeatedly fails, when contradiction/control routes are reached without candidate evidence, or when the bounded source chain requests archive/reframe.

## Output

Each creative card includes a rationale, strengthening evidence, kill criteria, and one bounded test query.

## Lock

`creative_hypothesis_not_evidence` remains visible in JSON, PDF, UI, and the V3 summary.
