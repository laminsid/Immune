# Immune Error Radar v1.10.8 — dataset-hunt unlock maintenance 5

This pass keeps the v1.10.8 evidence-first unlock bounded while tightening the paths most likely to regress in CI or report UX.

## Repairs

- The Research command board now uses the same `searchExecutionLine(...)` helper as the full report view. It no longer renders a generic `Search executed: N` line without the explicit `NOT_EXECUTED_OR_BLOCKED` status when `N=0`.
- Added `LinkedCognitionSpineEvidenceFirstTest` to prove that a partial/no-evidence spine chooses `EVIDENCE_FIRST` before `THINK_FIRST` when the missing keys are accession/outcome/minimum-metadata keys.
- Added a regression check that `priorSearchDirective(...)` preserves `EVIDENCE_FIRST_ACCESSION_SEARCH` and emits one bounded query.
- Hardened `audit_dataset_hunt_unlock_v1108.py` so CI guards the linked-spine evidence-first path and the command-board execution-line helper.

## Invariant preserved

`EVIDENCE_FIRST` only unlocks one bounded evidence-acquisition lane. It does not unlock hypothesis upgrade, causal wording, clinical interpretation, broad search, or runtime failover.

## Expected next report behavior

Acceptable:

```text
Dataset-first forager: DATASET_FORAGING_...
Search executed: >0
Direct sources attempted: GEO_GDS / SRA_PRJNA / ...
```

Also acceptable:

```text
Dataset-first forager: DATASET_FORAGING_NO_CANDIDATE
Search executed: >0
Reason: source returned no usable accession/metadata
```

Regression to block:

```text
DATASET_HUNT
Dataset-first forager: NOT_RUN
Search executed: 0
THINK_FIRST blocks network
```
