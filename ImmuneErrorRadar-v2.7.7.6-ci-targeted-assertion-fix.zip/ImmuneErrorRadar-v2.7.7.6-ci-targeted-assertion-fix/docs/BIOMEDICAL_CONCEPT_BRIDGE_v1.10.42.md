# Biomedical Concept Bridge v1.10.42

`v1.10.42-alpha-biomedical-concept-bridge` adds a scientist/lab-facing bridge graph on top of the Biomedical Research Ontology.

## Purpose

The bridge graph converts ontology matches into explicit research bridge cards so the engine does not waste cycles reconnecting basic biomedical concepts.

It links:

- pathogen trigger ↔ molecular mimicry ↔ autoimmunity
- organ/barrier tissue ↔ local immune response ↔ tissue/cell metadata
- blood/lab phenotype ↔ immune activity ↔ control/comparator evidence
- mitochondria/metabolism ↔ fatigue/recovery phenotype ↔ omics accessions
- medication exposure ↔ perturbation/control/confounder metadata
- herbs/foods/vitamins ↔ exposure/noise/confounder metadata

## Claim boundary

The bridge graph is routing-only.

It cannot produce:

- patient diagnosis
- treatment recommendation
- drug ranking
- supplement recommendation
- causal claim
- confirmed mechanism
- scientific breakthrough claim

## Required evidence movement

Bridge cards force the next lookup toward:

- accession/source ID
- human/patient data
- condition labels
- outcome labels
- control/comparator
- time order
- contradiction or negative-control search

## Release identity

- VersionCode: `104`
- VersionName: `1.10.42-alpha-biomedical-concept-bridge`
- Active engine: `v1.10.42-alpha-biomedical-concept-bridge`
- Schema: `1.10.42`
