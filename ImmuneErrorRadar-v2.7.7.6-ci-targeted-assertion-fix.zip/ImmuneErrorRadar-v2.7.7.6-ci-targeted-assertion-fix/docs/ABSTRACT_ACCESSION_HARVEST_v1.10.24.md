# Abstract Accession Text Harvest v1.10.24

## Purpose

v1.10.23 gave `PUBMED_ACCESSION_MINING` a deeper PubMed and abstract window. v1.10.24 makes that window useful by harvesting a compact digest from abstract and data-availability text so accession IDs such as GSE, PRJNA, SRP, SDY, E-MTAB, EGAS, SAMN/SAMEA/SAMD, and phs can reach `DatasetAccessionResolver`.

## Rule

The harvester extracts only retrieval cues:

- explicit accession-like IDs
- data availability / deposited / supplementary-data sentences
- dataset, sample metadata, phenotype, outcome, control, comparator, longitudinal terms
- safe adjacent-domain vocabulary such as histamine, mast cell, diabetes, aging, reflux, gut barrier, or medication exposure

## Claim boundary

The digest is not biological proof. It cannot create treatment, dosage, drug ranking, diagnosis, causality, or hypothesis upgrade. It only improves accession retrieval and metadata inspection.

Claim limit: `abstract_accession_harvest_not_biological_proof`.
