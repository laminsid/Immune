# Changelog v1.10.45 — Compile Scope Linkage Guard

Release: `1.10.45-alpha-compile-scope-linkage-guard`
versionCode=107

## Fixed
- Fixed the GitHub compile failure in `BiomedicalResearchOntologyV11041.kt` caused by unresolved `ResearchSteeringProfile` fields `topic` and `focus`.
- Replaced invalid references with compile-valid fields: `profileId`, `focusQuestion`, `variables`, `requiredTerms`, `excludedTerms`, and `inferredAxes`.

## Added
- Added `audit_v11045_compile_scope_guard.py` to catch this class of source-scope linkage failure before GitHub compile.
- Added v1.10.45 release linkage audit.
- Added v1.10.44 and v1.10.45 audits into both fast and full static-check gates so the newest layers are actually checked.

## Scope
- No new biological claims.
- No change to patient-facing diagnosis/treatment behavior.
- This release is a build/linkage hardening patch over the viral countermeasure + biomedical knowledge graph stack.
