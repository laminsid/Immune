# v1.10.8 Maintenance 7 — Dataset query fallback + execution note hardening

This maintenance pass closes the remaining no-attempt edge case after the dataset-hunt unlock.

## Fixed

- `DatasetQueryCompiler` now emits accession-oriented fallback queries if shard compilation produces no usable query.
- The fallback is intentionally evidence-acquisition-only and includes dataset/accession vocabulary (`GSE`, `GEO`, `PRJNA`, `SRP`, `SRA`) plus outcome/control/time-order language.
- Learning notes now separate executed search from planned budget, matching the exporter/UI behavior.

## Regression coverage

- Added `compilerFallsBackToAccessionQueriesWhenNoShardSeedsSurvive`.
- Strengthened `audit_dataset_hunt_unlock_v1108.py` to guard the fallback and execution-note language.

## Invariant

`DATASET_HUNT` may fail to find evidence, but it should not silently produce zero source attempts because the query compiler emitted no query.
