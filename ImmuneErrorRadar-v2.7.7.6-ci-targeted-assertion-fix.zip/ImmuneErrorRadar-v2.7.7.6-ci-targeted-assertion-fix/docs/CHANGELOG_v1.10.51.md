# v1.10.51-alpha-route-reconciliation-evidence-candidate-activation

## Purpose
This patch fixes the post-v1.10.50 failure mode where the corrected topic route was selected internally, but legacy report cards could still print the stale mature-domain prior as if it were the governing focus.

## What changed
- Added `RouteReconciliationEvidenceCandidateV11051`.
- Reconciled legacy mature-domain focus, post-PubMed strategy text, knowledge-gap queue text, strong-route fingerprint text, UI compact report, PDF/export, JSON, and learning-summary lines to the corrected topic route.
- Added `legacyRouteReconciliationStatus`, `reconciledMatureDomainFocus`, `reconciledQuerySeed`, `comparatorHuntQueries`, and `legacySuppressionNotes` to `TopicFitMetadataParseReport`.
- Activated bounded `EvidenceObjectCandidateV11049` creation for parsed metadata that is useful for hypothesis generation but blocked by missing control/comparator or contradiction gates.
- Comparator Hunt now emits executable query seeds rather than only a generic next-action sentence.

## Guardrails
- No EvidenceObject is created by this patch.
- No hypothesis upgrade is allowed.
- No diagnosis, treatment, dose, drug ranking, supplement advice, or causal claim is allowed.
- Legacy priors may be retained as historical context but cannot print as governing focus when suppressed by topic-route correction.

## Acceptance
A report for `Rituximab` should show `DRUG_PERTURBATION_IMMUNE_CONTROL_LANE` as the governing route and should not show `antihistamine_histamine_mast_cell` as the active focus. It may show it only under suppressed stale prior/reconciliation notes.

Acceptance note: reconciled legacy focus must appear when a stale prior is suppressed.
