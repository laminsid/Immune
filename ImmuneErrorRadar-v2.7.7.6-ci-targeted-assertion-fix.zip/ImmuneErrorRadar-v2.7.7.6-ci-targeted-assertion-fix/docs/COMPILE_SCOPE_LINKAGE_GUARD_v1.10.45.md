# Compile Scope Linkage Guard v1.10.45

This guard prevents a repeated GitHub Kotlin compile failure where new lean-agent layers reference fields that do not exist on shared model classes.

## Current protected model
`ResearchSteeringProfile`

Allowed fields:
- `profileId`
- `createdAtMillis`
- `variables`
- `focusQuestion`
- `requiredTerms`
- `excludedTerms`
- `inferredAxes`

## Blocked known-bad references
- `it.topic`
- `it.focus`

## Why it matters
Static text audits can pass while Kotlin compilation fails if a new layer uses a field name from an older mental model rather than the actual data class. This guard makes that failure visible before GitHub Actions reaches `compileDebugKotlin`.
