# v1.10.31 — Evidence Lead & Manual Seed Layer

Release: `1.10.31-alpha-evidence-lead-and-manual-seed`

## Purpose

This release does not add biological proof or treatment logic. It fixes the operational failure where the engine can execute many valid paths but still throw away weak dataset leads before they become useful.

Core rule:

> Explore loosely. Store weak leads. Claim nothing.

## Added states

- `WEAK_DATASET_LEAD_FOUND`
- `NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION`
- `ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP`
- `NO_PUBLIC_DATASET_AFTER_FULL_SWEEP`

These states affect routing and reporting only. They do not create EvidenceObjects.

## Manual Evidence Injection Mode

Added `MANUAL_EVIDENCE_SEED_MODE` through imported/manual research notes. The seed parser preserves:

- PMID
- DOI
- GSE
- PRJNA
- SRP / SRR
- E-MTAB
- SDY
- PDF URL
- text snippet

Direct accessions are stored as candidate-level leads. DOI/PMID/PDF/snippet entries are stored as secondary-lookup tasks.

## Dataset Lead Relaxation Gate

Weak handles are preserved as:

- `LEAD_ONLY_NOT_EVIDENCE`

This is not an evidence upgrade. It only prevents useful leads from being discarded before metadata lookup.

## Post-PubMed Search Strategy

When PubMed accession mining fails or produces a near miss, the report now exposes next search strategies:

- GEO direct term search
- NCBI BioProject direct query
- ArrayExpress direct query
- ImmPort direct query
- dataset catalog search terms
- supplementary-data phrase mining

These are strategy outputs, not full API integrations.

## One-page decision report

The first decision layer now separates action from proof:

- cycle validity
- evidence found
- best lead
- mature-domain usage
- next action
- what not to believe yet

## Activity is not evidence

The report includes a permanent activity/evidence separation table:

- executed paths
- candidates found
- accessions found
- evidence objects
- learning updates
- domain expertise updated
- scientific claim

## Report Consistency Guard

If a next probe or weak lead exists and the engine tries to archive, archive is downgraded to `DATASET_FORAGING_CONTINUE_PROBE`.

## Evidence Lead Path Linkage Guard

Added `EvidenceLeadPathLinkageReport` so v1.10.31 is not a reporting island. The guard checks that:

- manual seeds force dataset-first routing when an explicit accession/PMID/DOI/PDF seed exists;
- `MANUAL_EVIDENCE_SEED_MODE` is recorded as a forager attempt, not just as a candidate list;
- weak leads flow through relaxation, breakthrough, final decision, and consistency guard;
- post-PubMed strategies remain reachable from next-action language;
- linkage gaps surface as warnings before GitHub/release acceptance.

## CI split

Static checks are split:

- `scripts/run_static_checks_fast.sh` for pull requests
- `scripts/run_static_checks_full.sh` for push/manual/release verification

The GitHub workflow now selects the fast gate for `pull_request` and the full gate for push/manual runs. `run_static_checks.sh` remains as a compatibility wrapper to the full gate.

## What did not change

- No Bayesian belief update is applied before an EvidenceObject exists.
- No Dynamic Plausibility Graph edge is validated from weak leads.
- No hypothesis split/merge engine was added.
- No diagnosis, treatment, dosing, or biological proof claims were added.
