# v1.10.27 — Dataset Path Linkage Guard

This release connects the dataset-foraging handoffs that were previously split across accession acquisition, source-priority routing, mature-domain probing, pass summaries, PDF/JSON export, and UI decision cards.

## Why

The engine had become capable of running core accession sources and mature-domain probes, but the report could still show mixed operational signals: a mature-domain probe might be available while the final state or next action still looked like terminal archive. v1.10.27 adds an explicit path-linkage report so those handoffs are auditable.

## What it does

- Separates core accession sources from adjacent-domain probes.
- Exposes whether the mature-domain probe was attempted.
- Adds `PASS4_MATURE_DOMAIN_EVIDENCE_PROBE` to the foraging passes.
- Ensures final `state` and `nextAction` favor the mature-domain probe when it is active.
- Adds `pathLinkageReport` to JSON, PDF/export, and the simple UI card.
- Registers `DatasetForagingPathLinkageGuard` in the runtime module registry.

## Safety

This is an integrity/wiring layer only. It does not prove biology, diagnose, recommend treatment, rank drugs, or upgrade a hypothesis. Claim limit: `dataset_path_linkage_not_biological_proof`.
