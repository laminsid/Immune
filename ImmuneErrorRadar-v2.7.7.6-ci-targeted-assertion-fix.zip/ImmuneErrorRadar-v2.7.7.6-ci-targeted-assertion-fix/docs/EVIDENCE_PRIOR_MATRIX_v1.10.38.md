# Evidence Prior Matrix v1.10.38

v1.10.38 adds an Immune Evidence Prior Matrix as a connected routing layer above v1.10.37. It is not context injection and it is not biological proof.

## Purpose

The matrix turns high-value immune research vocabulary into bounded lookup keys:

- EBV / EBNA1 / molecular mimicry
- SARS-CoV-2 / Long COVID / interferon timing
- SLE / interferon / anti-dsDNA / ANA
- MS / CNS barrier / EBV context
- CMV / immunosenescence
- drug perturbation controls
- natural-compound noise guard, disabled by default

## Rules

- Random context injection is blocked.
- Prior terms are lookup keys only.
- A selected prior cannot update belief probability.
- No EvidenceObject means no hypothesis upgrade.
- Drug terms are perturbation/control vocabulary only: no dose, no treatment, no ranking.
- Natural compound terms are disabled by default unless accession and control metadata are visible.

## Required gates

Every selected prior must remain blocked until the relevant gates are closed:

- accession or source ID
- human/patient data
- outcome labels
- control/comparator
- time order
- contradiction or negative-control review

## Claim boundary

Claim limit: `evidence_prior_matrix_routing_only_not_biological_proof`.

EBV can be selected as a falsifiable verification criterion for a weak lead such as `fe34ffd5...`, but it cannot be called a breakthrough unless accession-level metadata, route fit, controls, time order, outcomes, and contradiction checks close.

Implementation note: random context injection is blocked; selected priors only emit bounded lookup keys.
