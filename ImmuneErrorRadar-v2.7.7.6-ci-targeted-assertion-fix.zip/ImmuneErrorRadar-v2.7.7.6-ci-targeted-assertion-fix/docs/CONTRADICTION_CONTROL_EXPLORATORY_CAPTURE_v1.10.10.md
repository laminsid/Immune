# v1.10.10 — Contradiction/Control Execution + Exploratory Capture

## Decision

The previous v1.10.9 source-rotation patch worked: the engine executed `IMM_PORT_SDY` and `PUBMED_ACCESSION_MINING`, recorded no-candidate learning, and selected `PUBMED_CONTRADICTION` as the next family. The remaining issue is not lock failure; it is capture strictness and reporting precision.

## Changes

- Added `EXPLORATORY_LEAD_NEEDS_ACCESSION` as a weak capture state.
- Lowered strictness only at the capture layer: unresolved PubMed contradiction/control/accession-mining leads may be retained as `DATASET_ACCESSION_UNRESOLVED` when they contain human/outcome/control/time/reusable-data wording.
- Kept hypothesis upgrade, causal language, and EvidenceObject support locked for unresolved leads.
- Added terminal route handling: after all bounded source families fail, the router emits `ARCHIVE_OR_REFRAME_ROUTE` instead of looping through cooldown escapes.
- Updated cycle phase audit budget language: `directiveMaxQueries` is now separated from `queryPathsExecuted` and `budgetType=source_family_paths`.
- Updated report/UI wording to show exploratory leads explicitly.

## Safety rule

Exploratory capture is not evidence. It only preserves a weak inspection target. Any unresolved lead must still pass accession/metadata closure, outcome labels, controls/comparators, and time-order gates before belief strengthening.
