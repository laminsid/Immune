# Immune Error Radar v1.10.2-alpha-network-io-test-hardening

## Purpose

Continue the runtime-hardening phase after v1.10.1 by closing remaining operational gaps without adding another cognitive layer.

## Changes

- Moved NCBI networking out of `ResearchAutopilot` into `NcbiClient` backed by OkHttp.
- Centralized User-Agent, Accept headers, typed HTTP error mapping, 429 handling, retry backoff, and NCBI rate limiting.
- Added tests for HTTP 500, HTTP 429, and dynamic User-Agent behavior using MockWebServer.
- Added a typed `RuntimeModuleRegistry` and routed `EngineRuntimeStatus.ACTIVE_MODULES` through it.
- Reduced hot-path JSONL reads for offline thinking and autonomous thought pulses by using tail reads instead of full-file scans.
- Extended append-only behavior to offline thought and autonomous pulse ledgers.
- Added keyword-boundary regression tests for the PPI/shipping false-positive class.
- Lowered source/target bytecode from Java 17 to Java 11 while keeping the Gradle runtime compatible with current Android tooling.

## Claim boundary

This version improves runtime correctness, network compliance, file I/O behavior, and regression coverage. It does not add biological proof, diagnosis, treatment advice, or new scientific claims.
