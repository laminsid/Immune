# Immune Error Radar v0.7.0-alpha — Gut / Nutrition / Muscle / Testosterone Patch

## Added

- GutNutritionHormoneInput and GutNutritionHormoneMap.
- GutNutritionHormoneAxis.kt.
- New UI card for stomach acid, reflux/dyspepsia, PPI/antacid context, gastritis/H. pylori context, diet diversity, protein estimate, body weight, muscle mass reserve, strength training, appetite, testosterone, libido/drive, and morning energy.
- New vector axes:
  - gastricAcidDysregulationAxis
  - gutBarrierMicrobiomeAxis
  - nutritionProteinAxis
  - muscleMassReserveAxis
  - testosteroneImmuneModulationAxis
- New discovery axes in Research Autopilot:
  - gastric_acid_gut_axis
  - gut_barrier_microbiome_axis
  - nutrition_protein_axis
  - muscle_mass_reserve_axis
  - testosterone_immune_axis
- New assets and docs for gut/metabolic/hormone research.

## Safety boundary

All outputs are hypothesis-grade research notes. No digestive, nutritional, musculoskeletal, endocrine, or immune diagnosis. No treatment advice.
