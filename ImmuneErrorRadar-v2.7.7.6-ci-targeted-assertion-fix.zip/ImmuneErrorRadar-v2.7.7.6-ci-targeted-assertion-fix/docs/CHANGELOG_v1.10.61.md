# 1.10.61-alpha-global-research-brief-report

- versionCode=123
- versionName=`1.10.61-alpha-global-research-brief-report`
- schema updated to `1.10.61`
- Added global research-grade final brief renderer.
- Default PDF export now uses a concise, high-quality discovery brief instead of the long technical dump.
- Main UI simple report and copied/exported fallback text use the same concise renderer.
- Technical appendix remains available through advanced/internal render paths.
- Added static audits for report concision, route linkage, and release linkage.
