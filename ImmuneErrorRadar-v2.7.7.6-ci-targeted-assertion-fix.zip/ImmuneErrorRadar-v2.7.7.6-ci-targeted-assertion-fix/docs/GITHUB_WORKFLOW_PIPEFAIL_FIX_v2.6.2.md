# GitHub Workflow Pipefail Fix — v2.6.2

## Purpose
The Android GitHub workflow now avoids `find | sort | head` style command substitutions under `set -euo pipefail` when locating Gradle roots.

## Fix
The workflow writes Gradle settings candidates to a temporary file, sorts the file in-place, and reads the first candidate with `sed -n '1p'`.

## Why
This prevents false CI failures caused by pipefail/SIGPIPE behavior and satisfies `audit_github_workflow_pipefail_safety_v11033.py`.

## Scope
- `.github/workflows/android-debug.yml`
- No runtime behavior change.
- No Android permission change.
- No Google Play policy surface change.
