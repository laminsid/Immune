# Brief Compile Scope Fix v2.7.3.18

## Problem fixed
GitHub Actions failed at `:app:compileDebugKotlin` because `GlobalResearchGradeBriefV11061.kt` referenced `parsedIntent` while building `DownstreamTopicContractV2746` before `parsedIntent` had been declared.

## Fix
Moved:

- `rawParsedIntent = parsedIntentSummary(researchIntent)`
- `parsedIntent = firstNonBlank(topicGate.optString("safeIntentLine"), rawParsedIntent)`

above:

- `DownstreamTopicContractV2746.fromText(...)`

This preserves the downstream topic contract logic while removing the compile-scope error.

## Guard added
Added `scripts/audit_gtim_v2747_brief_compile_scope_fix.py` and wired it into `scripts/run_static_checks_fast.sh`.

The audit ensures:

1. `rawParsedIntent` exists.
2. `parsedIntent` exists exactly once.
3. `parsedIntent` is declared before `downstreamContract` uses it.

## Scope
No scientific route expansion was added. This is a compile-scope repair only.
