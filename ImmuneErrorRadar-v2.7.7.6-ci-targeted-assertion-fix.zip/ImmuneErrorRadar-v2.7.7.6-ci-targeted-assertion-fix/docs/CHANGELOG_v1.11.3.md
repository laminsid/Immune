# Changelog v1.11.4-alpha-accession-validation-comparator-extraction

Version: `1.11.4-alpha-accession-validation-comparator-extraction`  
versionCode=128  
schema updated to `1.11.4`

## Added

- Source metadata enrichment cards for weak/manual/off-route leads before EvidenceObject creation.
- Strict guard that prevents `MANUAL_TEXT_SNIPPET` placeholders from being treated as confirmed accession IDs.
- Accession validation gate: `ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED`, `ACCESSION_TEXT_FOUND_METADATA_LOOKUP_REQUIRED`, `ACCESSION_VALIDATED_METADATA_ENRICHMENT_REQUIRED`, and `ACCESSION_VALIDATED_MATRIX_READY_NO_CLAIM`.
- Matrix readiness score built from confirmed accession, metadata, comparator labels, case labels, matrix availability, tissue/cell context, timepoints, and sample count.
- Source-specific parser routing for GEO, SRA/BioProject, ArrayExpress, and ImmPort.
- Matrix and metadata file-hint extraction for `series matrix`, `count matrix`, `processed data`, `supplementary data`, `sample metadata`, `phenotype`, and related terms.

## Fixed

- Removed fallback behavior that allowed manual snippet identifiers to become accession candidates without a real GSE/GSM/PRJNA/SRP/SRR/E-MTAB/SDY handle.
- Keeps `COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT` active until comparator/control labels are extracted from metadata.
- Keeps `DGE_NOT_READY_METADATA_GAP` active until matrix availability and group metadata are structurally closed.

## Boundary

No diagnosis, treatment, supplement recommendation, patient prediction, causal claim, differential expression, fold-change, or p-value is generated.
