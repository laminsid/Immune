# v1.10.8 Final Closure — Dataset-Hunt Unlock Release Hygiene

## Purpose
This closure pass does not add a new biological feature. It hardens the source package so the dataset-hunt unlock can be tested cleanly in CI without local artifacts or stale caches masking the real result.

## Changes
- Added `scripts/audit_release_hygiene_v1108.py`.
- Wired the hygiene audit into `scripts/run_static_checks.sh` immediately after the dataset-hunt unlock audit.
- Removed local `.gradle/` cache artifacts from the packaged source tree.
- Kept the core invariant unchanged:
  - no evidence present → allow bounded dataset-accession foraging;
  - evidence present → close/inspect existing evidence first;
  - no hypothesis upgrade, causal claim, or medical interpretation from routing alone.

## Acceptance checks
- JSON assets parse.
- Kotlin delimiter audit passes.
- Dataset-hunt unlock/report consistency audit passes.
- Release hygiene audit passes.
- GitHub Actions remains the final Gradle compile/test gate.

## Expected report behavior
The next generated report should not show the old closed loop:

```text
DATASET_HUNT
Dataset-first forager: NOT_RUN
Search executed: 0
THINK_FIRST blocks network
```

Instead it should show either an attempted direct dataset hunt or a useful source-level failure reason.
