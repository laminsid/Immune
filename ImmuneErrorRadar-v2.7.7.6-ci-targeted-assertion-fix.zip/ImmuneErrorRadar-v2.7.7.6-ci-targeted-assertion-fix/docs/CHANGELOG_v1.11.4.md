# v1.11.4-alpha-accession-validation-comparator-extraction

- versionCode=128
- schema updated to `1.11.4`
- Adds explicit `AccessionValidationCardV1114` and `ComparatorExtractionCardV1114`.
- Adds `evidenceObjectCreationGate` and `metadataExtractionCommands` to the research-grade mechanism dossier JSON/export surface.
- Keeps `HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION`: no invented accession IDs, sample labels, DGE, fold-change, p-value, clinical claim, or prediction.
- EvidenceObject creation remains blocked unless a confirmed accession plus comparator/case labels plus matrix/metadata readiness exist.
