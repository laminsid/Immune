# Autonomous Researcher v1.3.2

## Purpose

The app must work as a private global immune researcher without requiring the user to enter variables every cycle. Research steering remains optional.

## Operating loop

1. Read prior reports, seen PubMed IDs, seen axis pairs, imported notes, and recent findings.
2. Build an autonomous plan with 3–4 lanes:
   - EXPLORE: new bridge or dataset territory.
   - DEEPEN: strengthen an existing/open frontier.
   - CHALLENGE: search contradictions, opposite mechanisms, or bias.
   - DATASET/EVOLVE: rotate strategy after exhausted broad searches.
3. Run low-data PubMed metadata queries.
4. Save only useful new sources.
5. Apply v1.2 locks before any hypothesis upgrade.
6. Report what changed and what the engine will try next.

## Rule

Autonomous curiosity is default. User steering is optional acceleration. Evidence locks are mandatory.

## What changed from v1.3.1

- The engine no longer tells the user to guide it after a weak cycle.
- If no useful source is found, the next cycle changes strategy.
- Reports include the autonomous plan and next strategy.
- The UI makes clear that steering is optional.

## Non-goals

- No PyTorch/PyG in APK.
- No ML claims.
- No diagnosis/treatment/prediction of protection.
