# Environmental & Psychophysiological Exposome Lane v1.10.50

This module expands ImmuneSignal Research beyond narrow biomedical terms into measurable exposure/context variables.

## Exposure families
1. Aeroallergen / irritant / environment: dust, pollen, mold, air quality, pollution, humidity, heat/cold, smell/odor/fragrance, weather.
2. Psychophysiological: stress, psychological pressure, depression, anxiety, burnout, trauma, HPA axis, cortisol, HRV.
3. Endocrine: cortisol, estrogen, progesterone, testosterone, thyroid, insulin, melatonin.
4. Digestive / food: gastric acidity, reflux, pH, enzymes, digestion, food exposure, meal timing, microbiome, barrier tissue.
5. Physical / light / radiation: light, UV, radiation, blue light, screen exposure, moon/lunar/seasonal context, circadian timing.
6. Toxin/substance: alcohol, smoking, tobacco, nicotine, drug/substance exposure.
7. Age/life stage: age, elderly/older adults, immunosenescence, CMV serostatus, T-cell subsets, comorbidity and medication context.

## Mapping rule
Exposure -> Pathway -> Biomarker -> Dataset -> Outcome -> Comparator -> Contradiction.

## Claim boundary
The lane never provides personal health advice, treatment, dose, supplement recommendation, behavioral prescription, or diagnosis. It only improves scientific routing, metadata parsing, and comparator-hunt strategy.

## Comparator requirements
The preferred comparators are matched control, baseline/pre-exposure, exposed vs unexposed, responder vs non-responder, placebo where applicable, untreated where applicable, and negative/unrelated-marker control.

## Runtime linkage lock

v1.10.50 is linked through four runtime surfaces:

1. `EnvironmentalPsychophysiologicalExposomeLaneV11050` owns lane selection, the asset name, and the Exposure → Pathway → Biomarker → Dataset → Outcome → Comparator → Contradiction template.
2. `ExposomeToLabMapperV11050` maps selected lanes to biomarkers and comparator targets.
3. `NoExposureAdviceGuardV11050` holds the no-advice/no-dose/no-personal-prescription guard.
4. `TopicFitMetadataParseUiClarityV11047` calls the v1.10.50 owner before stale mature-domain priors can replay.

The no-islands audit requires the asset lanes to appear in the Kotlin owner, topic-fit routing, docs, JSON/export surfaces, runtime registry, and static checks.
