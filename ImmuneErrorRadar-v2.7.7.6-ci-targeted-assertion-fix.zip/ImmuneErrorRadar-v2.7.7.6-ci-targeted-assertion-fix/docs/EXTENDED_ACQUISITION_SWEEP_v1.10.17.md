# Extended Acquisition Sweep v1.10.17

This patch fixes the fast-stop failure observed after v1.10.16: the cycle showed four local thinking passes, but still ended after one fast dataset-source attempt with no accession.

## Rule

No terminal archive/reframe is allowed for a no-accession dataset hunt until the engine has completed a minimum source-family sweep:

- at least 3 distinct accession-capable source families
- at least 3 query paths
- no hypothesis upgrade from the sweep itself
- claim limit: `extended_acquisition_sweep_not_biological_proof`

## New state

`NO_ACCESSION_CONTINUE_SOURCE_SWEEP` means the cycle found no accession, but it is not allowed to archive yet because source-family coverage is still too thin.

## Why this matters

A 45-minute thinking budget is not useful if the acquisition layer exits after one source. This patch makes the longer budget operational by requiring more bounded source coverage before archive/reframe.

## Not biological proof

The source sweep only improves acquisition discipline. It does not prove a mechanism, diagnosis, treatment, causal relation, or clinical value.

not biological proof
