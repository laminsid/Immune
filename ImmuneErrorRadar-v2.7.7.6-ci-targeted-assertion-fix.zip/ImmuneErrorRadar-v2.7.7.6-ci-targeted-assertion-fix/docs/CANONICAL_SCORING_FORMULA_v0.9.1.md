# Canonical Scoring Formula v0.9.1

This document is the **single source of truth** for every score the engine
produces. Both Kotlin (Android) and Python (research pipeline) implementations
MUST match this spec. Any divergence is a bug.

A change to any constant here REQUIRES a paired change in:
- `app/src/main/java/com/immunesignal/app/CausalityScorer.kt`
- `app/src/main/java/com/immunesignal/app/HypothesisRankingEngine.kt`
- `research/causality_scorer.py`
- `research/hypothesis_ranker.py`

A unit-test parity script is recommended in v1.0.

---

## 1. Causality score

```
causality = clamp_0_100(
      0.22 * temporality
    + 0.26 * biological_plausibility
    + 0.18 * measurable_marker
    + 0.18 * repeatability
    + 0.16 * evidence_quality
    + design_boost
    - contradiction_penalty
    - negative_control_penalty
)
```

### Sub-scores

**temporality**
- 55 if the source text contains any of: `before, after, preced, follow-up, longitudinal, prospective, time course, lag`
- 50 if study_design contains `cohort` or `trial`
- else 20

**measurable_marker**
- start = 15
- +8 per marker hit in: `ige, eosinophil, histamine, crp, il-6, tnf, il-10, blood pressure, heart rate, rna, gene expression, dna methylation, testosterone, protein, muscle mass`
- +8 if axes contains `autonomic_vascular_axis`
- +10 if axes contains `rna_transcriptomic_axis` or `dna_genomic_axis`
- clamp 0..100

**repeatability** (from PersonalPatternAssessment.repeatedObservationCount)
- count >= 3 -> 70
- count == 2 -> 48
- count == 1 -> 25
- else -> 10

**design_boost**
- randomized -> +10
- cohort -> +8
- case_control -> +3
- else -> 0

**contradiction_penalty**
- text contains `no association` or `not associated` -> 25
- text contains `conflicting, inconsistent, controversial` -> 18
- else 5

**negative_control_penalty (NEW in v0.9.1)**
- negative_control_status == `weak_no_control_possible` -> 0  (nothing to penalize)
- negative_control_status == `control_required_before_strong` -> 12
- negative_control_status == `watch_requires_controls` -> 6
- else 0

**evidence_quality** comes from SourceClassifier (see section 3).

---

## 2. Hypothesis ranking score

```
overall = clamp_0_100(
      0.32 * avg_evidence_quality
    + 0.34 * avg_causality
    + 0.18 * avg_novelty
    + 0.16 * min(60, max_repeatability * 12)
)
```

### Status thresholds

```
STRONG_SIGNAL    if overall >= 72
                 AND max_repeatability >= 3
                 AND negative_control_status NOT IN {control_required_before_strong}
WATCH            if overall >= 55
WEAK             if overall >= 35
NOISE_OR_UNKNOWN otherwise
```

NOTE: Python implementation must include novelty (was missing in v0.9.0).

---

## 3. Evidence quality score

```
evidence_quality = clamp_5_100(design_weight - species_penalty)
```

### design_weight

| design | weight |
|---|---|
| systematic_review_meta_analysis | 82 |
| human_randomized_trial | 88 |
| human_cohort | 74 |
| human_case_control | 66 |
| human_case_report_or_series | 48 |
| animal_study | 38 |
| cell_in_vitro | 30 |
| mechanistic_review | 42 |
| unknown_design | 35 |

### species_penalty

| species | penalty |
|---|---|
| human | 0 |
| mixed_human_animal | 8 |
| animal | 22 |
| cell_only | 28 |
| unknown | 15 |

### humanEvidence boolean (v0.9.1 fix)

```
humanEvidence = TRUE if
    speciesClass == "human"
 OR sourceClass starts with "human"
 OR sourceClass == "clinical_intervention"
 OR (sourceClass == "synthesis" AND speciesClass NOT IN {"animal", "cell_only"})
 OR sourceClass == "human_relevant_with_animal_context"
```

### sourceClass (v0.9.1 fix: mixed handled)

```
synthesis                          if design IN {systematic_review, meta_analysis}
clinical_intervention              if design IN {randomized, trial}
human_observational                if design IN {cohort, case_control}
human_relevant                     if speciesClass == "human"
human_relevant_with_animal_context if speciesClass == "mixed_human_animal"   <-- NEW
animal_model                       if speciesClass == "animal"
cell_or_in_vitro                   if speciesClass == "cell_only"
unknown_metadata                   else
```

---

## 4. Negative-control status

(unchanged from v0.9.0)

```
control_required_before_strong  if causalityPreview >= 70 AND axes.size >= 2
watch_requires_controls         if axes.size >= 2
weak_no_control_possible        else
```

---

## 5. Statistical sanity gates

A scoring engine MUST flag (not silently emit) the following:

| condition | flag | downstream effect |
|---|---|---|
| n < 14 in any correlation | `INSUFFICIENT_DATA` | block STRONG_SIGNAL upgrade |
| permutation count < 1000 in negative-control | `WEAK_PERMUTATION_TEST` | demote one tier |
| species == unknown AND no abstract fetched | `METADATA_ONLY` | cap evidence_quality at 45 |

These gates are PLANNED for v1.0; v0.9.1 documents them for parity testing.
