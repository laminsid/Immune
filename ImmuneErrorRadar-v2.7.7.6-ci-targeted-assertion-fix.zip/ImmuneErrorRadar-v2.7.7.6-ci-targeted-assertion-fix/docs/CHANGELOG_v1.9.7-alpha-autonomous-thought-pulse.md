# Immune Error Radar v1.9.7-alpha-autonomous-thought-pulse

## Purpose

This patch continues v1.9.6 by making post-search cognition operational, not just visible. The app now keeps a small local thought pulse alive from saved reports and uses the previous evidence gate to prevent accidental broad-search replay.

## Changes

- Added `AutonomousThoughtPulseEngine`.
  - Builds a local, no-internet thought pulse from the latest saved report.
  - Carries the current hypothesis, unresolved gaps, local next move, and search unlock condition.
  - Explicit claim limit: `autonomous_thought_pulse_not_biological_proof`.

- Added local thought pulse storage.
  - New JSONL file: `immune_autonomous_thought_pulses.jsonl`.
  - Pulses are also summarized into the existing knowledge ledger.
  - Duplicate screen-open pulses are suppressed for a short interval.

- Added automatic local thinking triggers.
  - On Research Autopilot screen open, the app runs a small local thought pulse if a saved report exists.
  - After a completed search, the app records a thought pulse.
  - After manual `Think saved`, the app records both an offline thought step and a pulse.

- Added prior-closure search lock.
  - If the latest report says broad search is blocked, the next search cycle is forced into a single accession-specific closure query.
  - Runtime failover is suppressed under this lock to avoid spending a broad cycle around the same unresolved evidence gap.

- Updated user-facing thinking board.
  - Shows autonomous thought pulse state, decision, open gaps, local move, and search unlock condition.

## Boundary

This patch does not add diagnosis, treatment, drug ranking, or biological proof. It only improves local reasoning continuity and search-budget discipline.
