# Immune Error Radar v1.10.8-alpha-dataset-hunt-unlock

## Purpose

This patch fixes the closed loop observed in v1.10.7 reports:

- Research state entered `DATASET_HUNT`.
- The report had no EvidenceObject, no DatasetCandidate, and no accession.
- A prior `THINK_FIRST` / linked cognition lock blocked network execution.
- The Dataset-first forager did not run, so the next cycle had nothing real to close.

## Rule

Absence of evidence blocks claims, not evidence acquisition.

When the system has no EvidenceObject/DatasetCandidate/Accession and the blocker is a cognitive lock, v1.10.8 allows one bounded dataset accession hunt while keeping all hypothesis upgrades, causal wording, and biological claims locked.

## Wiring changes

- Added `DatasetHuntSearchUnlockPolicy`.
- `ResearchAutopilot` now allows `DatasetFirstForager` under a cognitive lock only when the no-evidence gate is active.
- The unlock does not override explicit accession/evidence-closure locks.
- Runtime failover stays blocked during the unlock path to avoid broad replay.
- The PDF/UI now distinguishes executed query paths from planned query budget.
- PlanStage now falls back to directive-owned queries if rewrites drop the selected directive query.

## Expected report delta

A healthy no-evidence cycle should no longer show:

`DATASET_HUNT + Dataset-first forager: NOT_RUN + Search executed: 0 + THINK_FIRST blocks network`

It should show at least a bounded dataset-source attempt, or an explicit typed runtime/search failure.

## Claim boundary

This patch is routing-only. It does not prove biology, rank treatments, generate diagnosis, or upgrade a hypothesis without EvidenceObject and dataset route-fit gates.
