# Biomedical Research Ontology v1.10.41

`v1.10.41-alpha-biomedical-research-ontology` adds a scientist/lab-facing biomedical vocabulary layer.

## Purpose

The layer strengthens research linking so the app does not waste cycles rediscovering basic biomedical relationships. It supplies bounded vocabulary for:

- organ systems and tissues
- blood, hematology, vascular and immune-cell concepts
- viruses, bacteria, parasites, and infection triggers
- common diseases and diagnostic/clinical phenotypes
- genes, cells, chromosomes, mitochondria, omics and pathways
- medication exposure as research perturbation/control vocabulary
- herbs, foods, vitamins, minerals, and nutrition exposures

## Scientist / lab mode

Diagnostic terms are allowed as `diagnostic phenotype vocabulary` for research linking, cohort labels, metadata parsing, and hypothesis routing.

## Boundary

The layer does **not** diagnose a patient, recommend treatment, rank drugs, recommend doses, or promote supplements.

## Connected layers

- Evidence Prior Matrix
- EBV Criterion Lane
- Lead Closure Handoff
- Metadata Closure Agent
- Unknown Route Classifier
- Learning Audit Monitor
- Integrated Path Linkage
- Release Stability Gate

## Release

- VersionCode: `103`
- VersionName: `1.10.41-alpha-biomedical-research-ontology`
- Schema: `1.10.41`

Explicit boundary: this ontology does not diagnose a patient and does not recommend treatment.
