# v1.10.12 — Creative Continuation Execution

## Problem fixed
v1.10.11 generated Creative Hypothesis Forge cards, but those cards could remain report-only. The cycle could still end with `EMPTY_PLAN` after `EVIDENCE_FIRST_FORAGER_EXECUTED`, so the system appeared to stop searching/thinking even though it had a next source family and a creative test query.

## Patch
This version adds `CreativeContinuationPolicy` as a bounded bridge between Creative Hypothesis Forge and PLAN/SEARCH.

When all conditions are true:
- Dataset foraging ran.
- No `DatasetCandidate` exists.
- Creative Hypothesis Forge generated test cards.
- No-candidate learning recorded a next source family.
- The next source is not `ARCHIVE_OR_REFRAME_ROUTE`.

The system now emits one executable continuation directive:

`CREATIVE_CONTINUATION_TEST`

The query is capped to one path and three results. It remains routing-only and cannot upgrade hypotheses.

## Safety invariant
Creative continuation is not evidence.

Allowed:
- execute one bounded creative test query;
- continue source rotation into contradiction/control or accession-mining;
- preserve hypothesis kill criteria.

Blocked:
- evidence-object creation from creative hypothesis alone;
- hypothesis upgrade;
- causal language;
- medical/clinical claims.

Claim limit:

`creative_continuation_not_evidence`

## Expected report delta
The next report should no longer show creative hypotheses plus `EMPTY_PLAN` when a valid next source family exists. It should show:

- `v1.10.12 creative continuation: active=true`
- `mode=CREATIVE_CONTINUATION_TEST`
- `source=PUBMED_CONTRADICTION` or the current next source
- selected query count > 0 in PLAN
