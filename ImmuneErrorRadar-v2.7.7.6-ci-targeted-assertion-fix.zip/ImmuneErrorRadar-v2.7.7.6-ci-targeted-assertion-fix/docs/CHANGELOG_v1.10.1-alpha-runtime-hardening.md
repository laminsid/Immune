# Immune Error Radar v1.10.1-alpha-runtime-hardening

Purpose: harden the runtime layer before adding more cognition features.

## Critical fixes
- HTTP 4xx/5xx no longer return `errorStream` as if it were a successful response.
- HTTP 429 is represented as a dedicated NCBI rate-limit exception.
- `httpGet/httpGetWithRetry` are suspend-aware and use coroutine `delay()` instead of `Thread.sleep`.
- NCBI requests are rate-limited locally: ~3 req/s without API key, ~10 req/s with API key.
- User-Agent now includes `EngineRuntimeStatus.ACTIVE_ENGINE_VERSION` dynamically.
- NCBI contact email is no longer the old `.local` placeholder.
- Streams are read with explicit UTF-8 and null error streams are safe.

## High-priority hardening
- NCBI API key moved behind `EncryptedSharedPreferences` with one-time legacy file migration.
- `ResearchKnowledgeStore` now uses file locks, append-only ledger hot path, periodic trim, and last-N reads from the end of the file.
- JSONL parsing now validates via `JSONObject(line)` instead of `startsWith/endsWith`.
- Query execution now tracks IDs with a `MutableSet` instead of repeated linear scans.
- Runtime HTTP/JSON/rate-limit issues are recorded in execution diagnostics instead of being silently swallowed.

## Evidence quality fixes
- `AxisMatcher` now uses precompiled word-boundary regex rules to avoid false positives like `ppi` inside `shipping`.
- Abstract evidence is not appended when absent; findings receive `ABSTRACT_FETCH_FAILED` instead.
- Truncated abstracts now receive `ABSTRACT_TRUNCATED`.
- Heuristic scores are marked with `SCORE_CALIBRATION_UNCALIBRATED_HEURISTIC`.

## Build/release hardening
- Added release minify/shrink config and `proguard-rules.pro`.
- Added ViewBinding switch for staged UI migration.
- Added Detekt config with a forbidden `Thread.sleep` rule.
- Added network security config for HTTPS-only NCBI access.
- Updated CI Gradle version to 8.10.2.

## Cleanup
- Removed legacy `ResultActivity` and `activity_result.xml`.
- Removed dead personal-profile model files that were no longer referenced by the research autopilot.
- Added AxisMatcher boundary regression test.
- Added runtime hardening audit script.

## Known limits
- Full Gradle build was not run in the local sandbox because Gradle was not installed and DNS access to `services.gradle.org` failed. GitHub/Android CI remains the final compile gate.
