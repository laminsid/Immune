# v1.10.49-alpha-topic-route-correction-evidence-object-candidate

Purpose: fix the new failure mode revealed after v1.10.48. Relaxed progression successfully forced minimum metadata parsing, but topic/route selection still replayed stale mature-domain priors and no intermediate evidence object existed for high-quality parsed metadata that remained blocked by missing controls.

## Added
- Topic route correction from the real user topic extracted from `focusQuestion`, not from broad steering variables.
- Topic normalization for spelling/noise cases such as Ashawagandha → Ashwagandha.
- Specific lanes for RNA/transcriptomics, DNA/genetics, herb/exposure/HPA, and drug perturbation immune-control.
- Stale prior suppression when `antihistamine_histamine_mast_cell` replays against non-allergy topics.
- Comparator Hunt Mode for `control_or_comparator` closure: healthy/matched/placebo/responder-vs-nonresponder/baseline/exposed-vs-unexposed/negative-control labels.
- `EvidenceObjectCandidateV11049`, a bounded intermediate object for parsed metadata that is useful but still blocked by control/contradiction gates.

## Unchanged hard limits
- No diagnosis.
- No treatment, dose, ranking, supplement, or herb advice.
- No causal or strong-signal language without control/comparator + time/order + contradiction/null-result closure.
- No EvidenceObject creation from route-fit, context seeds, or metadata score alone.
