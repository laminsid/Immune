# Immune Error Radar v1.10.0-alpha-linked-cognition-spine

This patch links all post-search cognition paths into one governing decision spine.

## What changed
- Added `LinkedCognitionSpine.kt`.
- Added `LinkedCognitionSpineReport` to `ResearchCycleReport` and JSON export.
- Added prior-run spine lock before search. If the last run says `NO_BROAD_SEARCH` or `THINK_FIRST`, the next run is constrained to one closure query or no network query.
- Linked: evidence closure → post-search thinking → thinking continuity → hypothesis graph → cognitive momentum → quality gate/runbook.
- UI and PDF now expose the governing layer, route mode, disconnected layers, open evidence keys, search decision, and query budget.
- Knowledge ledger now records `linked_cognition_spine_v200`.

## Claim boundary
The spine is a routing and decision-control layer only. It does not prove biology, diagnosis, treatment value, mechanism, or causality.
