# Changelog v1.11.2-alpha-strict-intersection-test-repair

- Fixes the failing unit test `MetadataClosureStrictIntersectionV11057Test > psychophysiologicalExposomeUnlocksAggressiveQueryStream`.
- Root cause: `AGGRESSIVE_GEO_EXPOSOME_CYTOKINE_STREAM` emitted the Beta accession pattern `(GSM[0-9]* OR SRP[0-9]*)` but the test contract requires GEO aggressive streams to expose `GSE[0-9]*`.
- Repair: both aggressive and Hyper-Drive Beta streams now emit a broader, repository-safe accession pattern: `GSE[0-9]* OR GSM[0-9]* OR PRJNA[0-9]* OR SRP[0-9]*`.
- Preserves safety: this only repairs query-generation surface. It does not create EvidenceObjects, fold-changes, p-values, clinical claims, diagnosis, treatment advice, or patient prediction.
- Adds `audit_v1112_strict_intersection_test_repair.py` and `audit_release_version_linkage_v1112.py` to the bounded GitHub static gate.

Version: `1.11.2-alpha-strict-intersection-test-repair`  
versionCode=126  
schema updated to `1.11.2`
