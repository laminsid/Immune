# v1.10.56-alpha-metadata-closure-strategy-matrix

versionCode=118  
schema updated to `1.10.56`

## What changed

- Added `MetadataClosureStrategyMatrixV11056` as a connected orchestration/evidence-foraging layer.
- Converts `WEAK_DATASET_LEAD`, `OFF_ROUTE_USEFUL_DATASET`, `LEAD_ONLY_NOT_EVIDENCE`, and low-usability candidate states into `Minimum Metadata Probe` instead of `FAIL` / `NOT_RUN`.
- Adds a priority strategy matrix for EBV, HHV-6, SARS-CoV-2 / Long COVID, CMV, SLE, MS, ME/CFS, RA, interferon alpha/beta, IL-6, TNF-alpha, cortisol/DHEA, JAK inhibitors, rituximab, curcumin, ashwagandha, and quercetin.
- Elevates route-fit only for acquisition when a snippet contains priority target vocabulary plus transcriptome/accession vocabulary.
- Emits exact PubMed/GEO/SRA/ImmPort query streams, discovery hypotheses, minimum metadata probes, and Lean Agent Runtime logic gates.
- Preserves hard locks: no diagnosis, no treatment advice, no dosing, no causal upgrade, no supplement recommendation.
- Wires the report through `DatasetForagingReport`, JSON export, UI technical report, `ResearchReportV3Builder`, runtime registry, release guard, docs, and GitHub fast/static audits.

## Acceptance gates

- Weak/off-route candidate does not collapse to `FAIL` or `NOT_RUN`.
- Priority target + transcriptome/accession text forces full text-mining drill-down.
- Minimum metadata fields remain mandatory before interpretation.
- Contradiction/null-result/artifact search remains mandatory before EvidenceObject creation.
- Modulator terms are treated as control/exposure/confounder metadata only.
