# Changelog v1.10.37

Release: `1.10.37-alpha-ebv-criterion-lane`

- Updated release identity to `versionCode=99`, `versionName=1.10.37-alpha-ebv-criterion-lane`, `ACTIVE_ENGINE_VERSION=v1.10.37-alpha-ebv-criterion-lane`, and `LEARNING_SESSION_SCHEMA_VERSION=1.10.37`.
- Added `EBVLeadVerificationPolicy` and `EBVLeadVerificationReport`.
- Added an EBV/Herpesviridae/molecular-mimicry criterion lane for weak/off-route lead verification.
- Kept EBV as a falsifiable verification criterion only, not a preferred cause and not a breakthrough claim.
- Updated UI summary and exported reports to show EBV criterion state, missing evidence, allowed next action, blocked claims, and invalidators.
- Added `EBVLeadVerificationV11037Test`.
- Added v1.10.37 static audits and release-linkage audit.
