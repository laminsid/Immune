# v1.10.25 — Data-Availability Accession Query Priority

## Purpose

v1.10.23 increased the PubMed accession-mining window and v1.10.24 harvested
small abstract/data-availability digests. v1.10.25 makes the query itself match
that goal: `PUBMED_ACCESSION_MINING` now prioritizes deposition and accession
language before broad mechanism terms.

## Rule

During `PUBMED_ACCESSION_MINING`, generate queries around:

- `data availability`
- `deposited`
- `accession`
- `GEO/GSE`
- `SRA/PRJNA/SRP`
- `ArrayExpress/E-MTAB`
- `ImmPort/SDY`
- `dbGaP/phs`
- sample metadata / phenotype labels / outcome / control / time-course terms

Domain expertise vocabulary may be reused only as a small suffix, and only for
PubMed accession or adjacent-domain routes. Direct GEO/SRA/ImmPort routes remain
source-native and are not narrowed by domain vocabulary.

## Claim lock

`data_availability_query_priority_not_biological_proof`

This layer is retrieval-only. It does not prove biology, diagnosis, treatment,
dosage, drug ranking, causality, or clinical value.
