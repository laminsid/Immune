# Changelog v1.10.46 — Longevity Biological Systems Graph

Release: `1.10.46-alpha-longevity-biological-systems-graph`
versionCode=108
LEARNING_SESSION_SCHEMA_VERSION=1.10.46

## Added

- Added `LongevityBiologicalSystemsGraphV11046` as a connected research-routing layer.
- Added biological lanes for sleep/circadian, metabolic-immune, mitochondrial/fatigue, immune aging, toxin/plastic/environment, nutrition/micronutrients, and herbs/foods as exposure/noise/control.
- Added explicit `Exposure -> Pathway -> Biomarker -> Dataset -> Outcome -> Contradiction` mapping.
- Added strengthened biomarker dictionary and dataset query templates.
- Added contradiction/null-result search terms as mandatory route output.
- Added `HealthAdviceClaimGuardV11046` to prevent diagnosis, dose, supplement, treatment, and personal-health advice posture.
- Added `longevity_biological_systems_modules_v1.10.46.json` asset.

## Changed

- `DatasetForagingReport` now carries `longevityBiologicalSystemsReport`.
- JSON exporter now includes biological systems graph fields.
- `ResearchAutopilot` evaluates the new layer after ontology/concept/medtech/viral routing and before knowledge-graph linking.
- `BiomedicalKnowledgeGraphLinker` now indexes selected biological-system partitions and edges.
- `IntegratedPathLinkageGuard` now treats the systems graph as a connected final-path layer and preserves the contradiction-required lock.
- `LearningRulesUiSummary` and `ResearchAutopilotActivity` now expose selected lane, biomarkers, missing data, falsifiers, and next search.
- Runtime and release identity updated to v1.10.46 / versionCode 108.

## Validation

- Added targeted audit: `scripts/audit_v11046_longevity_biological_systems_graph.py`.
- Added release linkage audit: `scripts/audit_release_version_linkage_v11046.py`.
- Added unit test: `LongevityBiologicalSystemsGraphV11046Test.kt`.

## CI Patch — EBV criterion unit-test fix

- Tightened EBV control/comparator detection so weak text such as “no explicit comparator” does not close the `control_or_comparator` gate.
- Kept strong control signals such as `healthy control`, `negative control`, `control group`, and `comparator group` valid.
- Updated the compact learning summary so active EBV criterion priors are explicitly shown as `not proof`.
- This preserves the claim boundary: EBV remains a falsifiable verification criterion only, not biological evidence or a breakthrough claim.

