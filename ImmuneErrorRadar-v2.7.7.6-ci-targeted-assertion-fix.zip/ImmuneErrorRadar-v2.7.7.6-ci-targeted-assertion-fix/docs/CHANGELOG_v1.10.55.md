# v1.10.55-alpha-ci-fast-gate-route-surface-unification

Release date: 2026-05-16

## Purpose

This release continues the v1.10.54 GitHub hardening work by making the default static-check path bounded for push/pull-request CI while preserving the full release gate for manual verification.

## Changes

- Version unified to `1.10.55-alpha-ci-fast-gate-route-surface-unification`.
- `versionCode=117`.
- Learning schema updated to `1.10.55`.
- Added `CiFastGateRouteSurfaceUnificationV11055` as a runtime module.
- `scripts/run_static_checks.sh` now defaults to fast CI checks and only runs the full gate when `CI_RESEARCH_FULL_CHECKS=1` is set.
- `scripts/run_static_checks_fast.sh` now performs a bounded current-release gate focused on JSON parsing, Kotlin/XML safety, workflow safety, route/exposome linkage, open exploration, route reconciliation, and release linkage.
- Full release verification remains available through `scripts/run_static_checks_full.sh` and manual GitHub workflow dispatch.

## Claim boundary

This is a CI/runtime-surface hardening release only. It does not create biological proof, diagnosis, treatment advice, dose advice, drug ranking, or clinical recommendations.
