# Changelog v1.10.38

Release: `1.10.38-alpha-evidence-prior-matrix`

- Updated release identity to `versionCode=100`, `versionName=1.10.38-alpha-evidence-prior-matrix`, `ACTIVE_ENGINE_VERSION=v1.10.38-alpha-evidence-prior-matrix`, and `LEARNING_SESSION_SCHEMA_VERSION=1.10.38`.
- Added `ImmuneEvidencePriorMatrix` and `EvidencePriorSelectionReport`.
- Added bounded prior selection for EBV molecular mimicry, SARS-CoV-2 resolution failure, SLE interferon/autoantibody, MS/CNS barrier/EBV, CMV immunosenescence, drug perturbation controls, and natural-compound noise guard.
- Blocked random context injection and supplement/treatment drift.
- Connected the prior selector to lead closure, metadata closure, unknown-route classification, EBV criterion lane, Learning audit monitor, DiscoveryReportExporter, and technical report UI.
- Added `ImmuneEvidencePriorMatrixV11038Test`.
- Added v1.10.38 static and release-linkage audits.

No medical, diagnostic, treatment, drug-ranking, supplement, causality, or breakthrough claim is added.
