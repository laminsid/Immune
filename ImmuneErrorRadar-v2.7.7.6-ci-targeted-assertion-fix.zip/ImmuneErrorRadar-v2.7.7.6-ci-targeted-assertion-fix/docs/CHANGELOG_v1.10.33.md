# Changelog — v1.10.33

Release: `1.10.33-alpha-lean-agent-runtime`

- Updated release identity to `versionCode=95`, `versionName=1.10.33-alpha-lean-agent-runtime`, `ACTIVE_ENGINE_VERSION=v1.10.33-alpha-lean-agent-runtime`, and `LEARNING_SESSION_SCHEMA_VERSION=1.10.33`.
- Added `LeadObject` ledger model for weak/manual/near-miss leads.
- Added `LeanAgentRuntimePolicy` with deterministic micro-agent list, hard gates, state deltas, and compact decision card.
- Connected LeadObject ledger, mature-domain focus, knowledge gap queue, strong route fingerprint, and report consistency into `DatasetForagingReport` JSON/PDF/UI exports.
- Kept fast/full CI split and release linkage guard mandatory.

Runtime remains routing-only and claim-safe: `lean_agent_runtime_routing_only_not_biological_proof`.

## GitHub compile hotfix — DiscoveryReportExporter local declaration guard

- Fixed a Kotlin compile failure in `DiscoveryReportExporter.kt` caused by same-scope local declarations named `gaps` with different JSON types.
- Renamed the report-local variables to role-specific names:
  - `knowledgeGapQueue`
  - `specialistEvidenceGaps`
  - `gapMinerMissingEvidence`
- Added `scripts/audit_discovery_exporter_local_names_v11033.py` and wired it into fast/full static checks to prevent this class of GitHub Kotlin failure from returning.
- No scientific-claim behavior changed; this is a compile-stability and CI guard fix only.

## Report linkage hardening continuation

- Hardened `ReportConsistencyGuard.includePathLinkageWarnings` so a linkage state containing `WARNINGS` cannot be hidden even if the warning list is accidentally empty.
- Normalized impossible `PASS` + non-empty warning combinations to `CAUTION`.
- Forced merged linkage consistency reports to remain `active=true` when any path-linkage caution is injected.
- Added regression coverage for warning-state-without-warning-text and PASS-with-warning normalization.
- Extended `scripts/audit_v11033_unit_regression_contracts.py` so fast/full static checks enforce these report-consistency contracts.

## Lead-follow-up routing hardening after 11:00 report

- The 11:00 discovery report confirmed that v1.10.33 now links mature-domain probing into near-miss lead inspection, but it also exposed a routing quality issue: no-candidate learning still preferred the next broad source family even when a LeadObject/near-miss existed.
- Changed no-candidate follow-up routing so weak/near-miss/manual lead signals use `LEAD_OBJECT_SECONDARY_LOOKUP` before another broad source rotation.
- Extended `DatasetLeadRelaxationGate` so near-miss LeadObjects are preserved as lead-only follow-up work, not reported as `NO_WEAK_LEAD_TO_RELAX`.
- Extended breakthrough reporting so the best lead can surface the strongest near-miss LeadObject instead of showing `best=none` when candidates are still zero.
- Added regression coverage for near-miss LeadObject relaxation and breakthrough display while keeping the claim limit locked to `LEAD_ONLY_NOT_EVIDENCE`.
- Hardening cycle: removed stale near-miss test expectation that allowed `bestLead=none`; near-miss leads must now surface as a LeadObject follow-up while remaining `lead_only_not_evidence`.

## Prevention pass 2 — Lead follow-up wording/routing guard

- Hardened `QueryFeedbackPlanner.applyNoCandidateLearning` so `LEAD_OBJECT_SECONDARY_LOOKUP` is treated as a lead-object follow-up action, not as a broad "next source family" rotation.
- Added regression coverage to ensure near-miss follow-up summaries say `next action: LEAD_OBJECT_SECONDARY_LOOKUP` and avoid broad-source wording when a weak/near-miss lead exists.
- Extended `audit_v11033_unit_regression_contracts.py` to lock the LeadObject secondary lookup contract across QueryFeedbackPlanner and tests.
- No claim semantics changed: lead follow-up remains `query_ranking_only_not_biological_proof` / `lead_only_not_evidence` and cannot upgrade hypotheses.

## Prevention pass 3 — Export/header wording guard

- Hardened `DiscoveryReportExporter` top summary so `LEAD_OBJECT_SECONDARY_LOOKUP` is exported as `Next lead follow-up`, not as `Next source family`.
- Added `DiscoveryReportExporter.noCandidateHeaderLine(...)` as a small deterministic formatter so report-header wording is unit-testable without PDF rendering.
- Added regression coverage for both cases:
  - LeadObject follow-up remains a follow-up action.
  - True source-family rotation still uses `Next source family` wording.
- Extended `audit_v11033_unit_regression_contracts.py` to lock the exporter/header contract alongside QueryFeedback and LeadObject tests.
- No evidence semantics changed: near-miss/weak/manual leads still remain `LEAD_ONLY_NOT_EVIDENCE` and cannot upgrade hypotheses.

### Prevention pass 4 — LeadObject follow-up wording and routing guard

- Hardened all remaining `LEAD_OBJECT_SECONDARY_LOOKUP` paths so they are treated as lead follow-up, not broad source-family rotation.
- Updated `SourcePriorityArbitrationPolicy.summary` to print `leadFollowUp=LEAD_OBJECT_SECONDARY_LOOKUP` and `nextSource=not_applicable_until_lead_lookup_finishes` when a near-miss lead must be inspected first.
- Blocked `CreativeContinuationPolicy` from compiling a new creative continuation query while LeadObject secondary lookup is pending.
- Updated `PersistentFailureMemory` summary so LeadObject lookup appears as `next lead follow-up`, not `next forced source`.
- Updated PDF/report details and technical UI lines to show `follow-up=LEAD_OBJECT_SECONDARY_LOOKUP` instead of raw `nextPreferredSource` source-rotation wording.
- Added regression coverage for exporter detail lines, source-priority summary, and creative-continuation blocking.
- No scientific claim semantics changed: LeadObject follow-up remains routing-only and `lead_only_not_evidence`.

### Prevention pass 5 — near-miss fallback best-lead contract
- Fixed a unit-test regression where `EvidenceLeadAndManualSeedPolicy.breakthrough(...)` could produce `NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION` while `bestLead` stayed `none` when callers had not supplied prebuilt `LeadObject`s.
- Added a deterministic fallback from `DatasetSourceAttempt(idsFound>0, candidatesExtracted=0)` to `Near-miss source response from <sourceFamily>`.
- Preserved the scientific lock: the fallback lead remains `NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION` / `lead_only_not_evidence` and cannot create an `EvidenceObject` or hypothesis upgrade.
- Strengthened `audit_v11033_unit_regression_contracts.py` so the fallback contract cannot be removed silently.

## v1.10.33 prevention pass 6 — weak-lead handoff linkage hardening

- Fixed a report-discovered handoff defect where `DATASET_FORAGING_WEAK_DATASET_LEAD_FOUND` was not recognized as a linked lead-inspection terminal state by `DatasetForagingPathLinkageGuard`.
- `matureProbeConsumedByLeadPath` now treats weak dataset lead follow-up as a valid consumer of the mature-domain probe when the next action is lead/source-ID/supplementary-data inspection.
- `DatasetLeadRelaxationReport.leadAccessions` now preserves a displayable near-miss lead reference when no accession handle exists, avoiding `relaxed=1` with `leads=none` in reports.
- Added regression coverage for weak dataset lead follow-up handoff and near-miss relaxation display.
- Extended `audit_v11033_unit_regression_contracts.py` to lock the weak lead follow-up and display contracts.

Claim limit unchanged: `lead_only_not_evidence`. No EvidenceObject, hypothesis upgrade, biological proof, diagnosis, treatment, or causal/clinical claim is introduced.


## v1.10.33 UI Scope Hardening Pass
- Added one front-door topic/question input for immune-focused research runs.
- The prompt is automatically stored as steering + imported learning note, so each run can learn from the user topic without becoming a general-purpose answer engine.
- Added ImmuneTopicPromptPolicy: arbitrary topics are projected into immune-system research only; unrelated domains report no usable immune lead instead of producing general non-immune advice.
- Reduced visible UI technical text: main screen shows a short decision card and a compact learning receipt; detailed cognition/path layers remain in Advanced and Export.
- Fixed GitHub extraction preview broken-pipe risk by replacing `sort | head` under `pipefail` with temp-file + `sed` bounded previews.

## Single-prompt UI prevention pass

- Fixed Kotlin regex escape safety in `ImmuneTopicPromptPolicy.normalizeTopic` by using `Regex("\\\\s+")` instead of unsupported normal-string shorthand escapes.
- Added `audit_kotlin_regex_escape_safety_v11033.py` to catch future unsupported Kotlin string escapes such as `\s`, `\d`, or `\w` in normal strings.
- Kept the basic UI lighter by removing the engine-version line from the visible short report; version/runtime details remain available through Export/Advanced.
- Softened the visible learning receipt wording from technical `gaps/follow-up` labels to simpler Arabic UI labels while preserving the underlying report fields.
- Extended single-prompt scope audit to enforce escaped regex safety and prevent re-exposing technical runtime lines in the basic report.


## GitHub hardening pass — pipefail-safe workflow discovery

- Hardened `.github/workflows/android-debug.yml` against `set -euo pipefail` broken-pipe failures.
- Replaced early-closing discovery pipelines with temp-file based discovery for Gradle settings and project ZIP detection.
- Added `audit_github_workflow_pipefail_safety_v11033.py` and wired it into fast/full static checks.
- This pass changes CI reliability only; no scientific claim, evidence upgrade, or biological routing behavior is changed.

## Learning Value Mode hardening — single prompt usefulness

- Added `ImmuneLearningValueModePolicy` to separate scientific claim gates from research-usefulness gates.
- User topics and imported notes can now force a bounded dataset-first / weak-lead hunt when no EvidenceObject exists, even if the linked cognition spine would otherwise lock the cycle to one narrow query.
- `DatasetHuntSearchUnlockPolicy` now supports `learningValueModeActive`; it can unlock dataset-first for user-topic learning value while still blocking expansion if an actual EvidenceObject already exists.
- `ResearchAutopilot` now records a learning-value note and routes topic/imported immune leads into dataset-first foraging instead of letting them stall as `PUBMED_METADATA_ONLY` or one-query `ACCESSION_CLOSURE_ONLY` cycles.
- Added regression tests and audits to ensure rheumatoid arthritis / viral / hanta / corona-style prompts generate useful immune-lens routing value without claim upgrade.
- Claim gates remain unchanged: no EvidenceObject means no causal language, no biological proof, no diagnosis, no treatment recommendation, and no hypothesis upgrade.
