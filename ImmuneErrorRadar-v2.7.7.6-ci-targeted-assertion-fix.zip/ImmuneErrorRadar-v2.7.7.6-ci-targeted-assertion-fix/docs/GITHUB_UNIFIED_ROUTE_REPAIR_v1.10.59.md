# GitHub Unified Route Repair v1.10.59

## Scope

This release hardens the v1.10.58 Hyper-Drive layer for GitHub CI by repairing unsafe Kotlin string literals and adding static checks that catch embedded-quote query regressions.

## Fixed path

`MetadataClosureStrategyMatrixV11056.kt` remains the compatibility host for the strategy matrix and exposes aliases through:

- `MetadataClosureStrategyMatrixV11056`
- `MetadataClosureStrategyMatrixV11057`
- `MetadataClosureStrategyMatrixV11058`

The active release label is now:

`v1.10.59-alpha-github-unified-route-repair`

## Guard added

The release audit checks that Hyper-Drive query strings containing embedded quoted phrases use Kotlin triple-quoted strings:

- Stream Alpha: EBV / HHV-6 + SLE / Systemic Lupus / Multiple Sclerosis + RNA-Seq / Transcriptome + Data Availability.
- Stream Beta: HPA-axis / Cortisol-DHEA / Sleep deprivation + Interferon-alpha / IL-6 / TNF-alpha + Curcumin / Ashwagandha.

## Runtime behavior preserved

- Cross-family intersections still force route-fit target 95/100 for data-foraging priority.
- Weak/off-route leads still become Minimum Metadata Probe candidates.
- Hard-data demand still forbids fabricated accession IDs or EvidenceObjects.
