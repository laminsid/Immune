# CI Fast Gate + Route Surface Unification v1.10.55

## Decision

GitHub push and pull-request builds should not spend budget replaying every historical audit unless the run is explicitly a release gate. The default static-check script now runs the bounded fast gate. The full historical gate remains opt-in.

## Fast gate coverage

The fast gate checks:

- JSON syntax for all project JSON assets.
- Kotlin delimiter and regex/string escape safety.
- XML parse safety.
- GitHub workflow pipefail safety.
- Release-hygiene artifacts.
- v1.10.50 exposome no-island linkage.
- v1.10.51 route reconciliation and EvidenceObjectCandidate wiring.
- v1.10.52 open exploration and medical index wiring.
- v1.10.53 route-linkage hardening.
- v1.10.54 GitHub/runtime-surface hardening.
- v1.10.55 release linkage.

## Full gate

Run the full gate manually with:

```bash
CI_RESEARCH_FULL_CHECKS=1 bash scripts/run_static_checks.sh
```

or directly:

```bash
bash scripts/run_static_checks_full.sh
```

## Boundary

This patch changes CI and runtime-surface verification only. It does not relax evidence, diagnosis, treatment, dose, or drug-ranking restrictions.
