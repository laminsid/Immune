# v1.10.52 — Open Exploration + Medical Index + Diagnostic Reasoning Sandbox

This release relaxes exploration and linking while preserving medical-safety boundaries.

## Added
- Open Exploration Linking Mode: weak signals may open dynamic route nodes before evidence is sufficient.
- Diagnostic Reasoning Sandbox: shows differential route reasoning, supportive/contradictory signals, missing discriminators, and falsifiers. It is not a patient diagnosis.
- Stronger medical term index: EBV, COVID/Long COVID, SLE, IL-6, CRP/TNF-alpha, Sugar/Glucose/HbA1c, Salt/Sodium/BP, Stress/Cortisol/HPA.
- Sugar/Salt metabolic-electrolyte lane: connects glucose/insulin/HbA1c and sodium/BP/osmotic stress to immune, vascular, endocrine, kidney, and mitochondrial contexts.
- Dynamic node opener: new concepts may become route candidates and query seeds, then require comparator/time/outcome/contradiction gates before strengthening.

## Boundary
- The engine may expose how it reasons diagnostically.
- It must not produce a final patient diagnosis, treatment recommendation, dose, drug ranking, supplement advice, or emergency triage decision.
