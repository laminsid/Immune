# v1.10.57-alpha-strict-intersection-priority-elevation

- versionCode=119
- versionName=`1.10.57-alpha-strict-intersection-priority-elevation`
- schema updated to `1.10.57`

## Added

- Strict Multi-Family Intersection Rules inside the Metadata Closure Strategy Matrix.
- R1 Neuro-Viral Bridge: EBV/HHV-6 + SLE/MS/ME-CFS + transcriptome/RNA-seq forces route-fit floor >=85.
- R2 Psychophysiological Exposome: HPA-axis / Cortisol-DHEA / Sleep-deprivation + IFN-alpha / IL-6 / TNF-alpha unlocks aggressive GEO/SRA query streams.
- Cross-reference matrix emitted in JSON/report with verified state, matched families, matched tokens, accession patterns, and programmatic queries.
- Explicit accession-pattern query streams for GEO and SRA using `GSE[0-9]*`, `GSM[0-9]*`, `GPL[0-9]*`, `PRJNA[0-9]*`, `SRP[0-9]*`, and `SRR[0-9]*`.

## Preserved claim boundary

- Validation embargo bypass is limited to metadata-probe and query-priority routing only.
- No biological proof, diagnosis, causal claim, treatment recommendation, dose logic, or supplement recommendation is unlocked.
- EvidenceObject creation remains blocked until accession/source ID, human cohort, labels, comparator/control, time order, data availability, and contradiction gates close.
