# Changelog — v1.10.34

Release: `1.10.34-alpha-useful-learning-report`

- Updated release identity to `versionCode=96`, `versionName=1.10.34-alpha-useful-learning-report`, `ACTIVE_ENGINE_VERSION=v1.10.34-alpha-useful-learning-report`, and `LEARNING_SESSION_SCHEMA_VERSION=1.10.34`.
- Added **Learning Value Score** for useful research progress without EvidenceObject.
- Added **Topic Memory Ledger** so repeated or related topics do not start from zero.
- Added **Lead Inspection Queue** for weak, near-miss, and manual leads.
- Added **Research Progress without EvidenceObject** categories: topic stored, query strategy changed, weak lead preserved, gap queue created, dataset-first attempted, and failure pattern learned.
- Added **Useful Report Layers** to keep the main UI short while preserving the full technical appendix in Export/Advanced.
- Kept strict claim locks: no diagnosis, no treatment advice, no causal/biological proof, and no hypothesis upgrade without EvidenceObject.

## English compact UI hotfix

- Converted the primary visible Research Autopilot UI back to English-only.
- Replaced technical raw states such as `WEAK_DATASET_LEAD_FOUND`, `MANUAL_TEXT_SNIPPET`, `OFF_ROUTE_DATASET`, and root-cause codes with human-readable summaries in the main card.
- Kept technical runtime/version/path details in Export and Advanced only.
- Added `audit_v11034_english_compact_ui.py` to prevent Arabic/mixed-language strings and raw technical codes from returning to the visible summary.
- Updated full static-check UI anchors to the English compact report tokens.
