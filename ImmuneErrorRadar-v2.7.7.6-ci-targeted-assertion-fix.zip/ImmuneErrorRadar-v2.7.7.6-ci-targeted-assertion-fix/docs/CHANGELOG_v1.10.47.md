# v1.10.47-alpha-topic-fit-metadata-parse-ui-clarity

Version: `1.10.47-alpha-topic-fit-metadata-parse-ui-clarity`  
versionCode=109  
Release date: 2026-05-15

## Purpose

This release fixes the main behavioral gap observed after v1.10.46: the engine could correctly protect claims, but still remain stuck in a weak-lead / missing-metadata loop while stale mature-domain priors dominated unrelated user topics.

## Changes

- Added `TopicFitMetadataParseUiClarityV11047` as a small orchestration layer.
- Added topic-fit dominance before mature-domain prior reuse.
- Suppresses stale antihistamine / mast-cell mature-domain focus when the user topic is clearly Vaccine, Antibiotics, Longevity, Sleep, Fatigue, Long COVID, or Mitochondrial unless allergy/histamine terms are explicit.
- Added topic-specific lane mapping:
  - Vaccine → `VACCINE_IMMUNE_RESPONSE_LANE`.
  - Vaccine + age/CMV/T-cell context → `IMMUNE_AGING_VACCINE_RESPONSE_LANE`.
  - Antibiotics / microbiome → `DRUG_PERTURBATION_MICROBIOME_BARRIER_IMMUNE_LANE`.
  - Sleep / circadian → `CIRCADIAN_SLEEP_INTELLIGENCE`.
  - Fatigue / ME/CFS / Long COVID / mitochondria → `MITOCHONDRIAL_FATIGUE_LANE`.
  - Longevity / aging / CMV → `IMMUNE_AGING_IMMUNOSENESCENCE_LANE`.
- Added forced minimum metadata probe behavior in `CandidateActionResolver` when candidate sets exist but nothing is selected for parsing.
- The new forced path is labelled `OFF_ROUTE_MINIMUM_METADATA_PROBE` and remains claim-gated.
- Split UI/report status into Learning, Discovery, and Evidence so useful learning is not confused with scientific discovery.
- Added compact topic-fit card to the user report and full audit/export details to the technical report.
- Updated the public app label to `ImmuneSignal Research` while keeping the package/application ID unchanged (`com.immunesignal.app`).

## Guardrails

- No EvidenceObject is created by topic-fit correction alone.
- No biological, causal, clinical, diagnostic, treatment, supplement, drug-ranking, or dose claim is enabled.
- Forced metadata parsing only improves visibility; it does not upgrade hypotheses.
- Existing v1.10.46 Longevity & Biological Systems Graph remains active and connected.

## Acceptance checks

- `TopicFitMetadataParseUiClarityV11047` is registered and exported.
- `topicFitMetadataParseReport` is included in `DatasetForagingReport` and JSON export.
- Research UI displays topic, selected route, learning status, discovery status, evidence status, missing gates, invalidators, and next action.
- Discovery PDF/export contains the new v1.10.47 card.
- Static checks include the v1.10.47 topic-fit audit and release-linkage audit.
