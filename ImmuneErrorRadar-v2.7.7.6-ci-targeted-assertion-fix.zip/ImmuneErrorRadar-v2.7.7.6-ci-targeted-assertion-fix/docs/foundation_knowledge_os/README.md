# ImmuneErrorRadar v1.4.6-alpha-foundation-knowledge-os

## 📋 Overview

**v1.4.6** adds a Foundation Knowledge Operating System to v1.4.5 without breaking any existing code.

### What Changed?

```
v1.4.5 Architecture:
ResearchAutopilot → QueryFeedbackPlanner → [search cycle] → Report

v1.4.6 Architecture:
ResearchAutopilot 
  ├─ FoundationKnowledgeLayer (NEW - OPTIONAL)
  │  ├─ AxisRankingEngine
  │  ├─ FoundationConflictResolver
  │  ├─ FoundationKnowledgeAccuracyLedger
  │  └─ FoundationPatchSuggestionLedger
  └─ QueryFeedbackPlanner → [search cycle] → Report (UNCHANGED)
```

**Key Guarantee:** v1.4.5 works identically with or without v1.4.6.

---

## 🎯 What Does v1.4.6 Do?

### 1. **Guides Search** (Not Proof)
- Foundation knowledge suggests relevant axes
- Routes are weighted by biological plausibility
- Nothing is blocked automatically

### 2. **Prevents Biological Nonsense**
- Detects forbidden conflations (e.g., "allergy dataset as antiviral")
- Warns user: "This violates foundation knowledge"
- User can override, but is informed

### 3. **Learns from Mistakes**
- Tracks accuracy of each axis
- Records conflicts that suggest knowledge needs updating
- Suggests patches, awaits human review
- NEVER auto-updates knowledge

### 4. **Handles Ambiguity**
- Grades confidence: HIGH, MEDIUM, LOW, CAUTION
- Suggests downgrading to "mechanism" or "analogy" when appropriate
- Scores partial matches fairly

---

## 📁 Files Included

### Kotlin Files (5)
1. **FoundationKnowledgeLayer.kt** (430 lines)
   - Main entry point
   - Loads knowledge from JSON
   - Analyzes queries against axes

2. **AxisRankingEngine.kt** (280 lines)
   - Ranks axes by relevance
   - Detects conflicts between axes
   - Validates ranking makes sense

3. **FoundationConflictResolver.kt** (410 lines)
   - Decides what to do when data gaps exist
   - Grades recommendations: PROCEED → REQUIRE_MORE_EVIDENCE → BLOCK
   - Non-binary decisions, not hard gates

4. **FoundationKnowledgeAccuracyLedger.kt** (380 lines)
   - Tracks each axis's success rate
   - Detects false blocks and repeating mistakes
   - Boosts scores of accurate axes

5. **FoundationPatchSuggestionLedger.kt** (320 lines)
   - Suggests knowledge updates when conflicts repeat 3+
   - Never auto-updates
   - Records all proposals for review

### JSON Knowledge Files (5)
1. **biology_foundation_pack.json**
   - 6 core biological axes (interferon, allergy, inflammation, etc.)
   - Query hints for each
   - Forbidden conflations

2. **psychoneuroimmune_context_pack.json**
   - 5 stress/behavioral axes
   - Causal warnings
   - Context modulation, not primary cause

3. **foundation_conflict_rules.json**
   - 9 forbidden conflations database
   - Evidence hierarchy (human > mouse > cell)

4. **foundation_success_metrics.json**
   - Scaling criteria for 3→7 packs
   - Success stories (GSE250594, etc.)
   - User pause thresholds

5. **immunology_axis_rules.json** (Not in this bundle - placeholder for expansion)

### Integration Files
1. **FoundationKnowledgeIntegrationBridge.kt**
   - Safe bridge between v1.4.5 and v1.4.6
   - Can be disabled at runtime
   - No changes to ResearchAutopilot needed (optional)

---

## 🚀 How to Use

### Step 1: Add JSON Files to Assets

Copy to `app/src/main/assets/`:
- `biology_foundation_pack.json`
- `psychoneuroimmune_context_pack.json`
- `foundation_conflict_rules.json`
- `foundation_success_metrics.json`

### Step 2: Add Kotlin Files to Project

Copy to `app/src/main/java/com/immunesignal/app/`:
- `FoundationKnowledgeLayer.kt`
- `AxisRankingEngine.kt`
- `FoundationConflictResolver.kt`
- `FoundationKnowledgeAccuracyLedger.kt`
- `FoundationPatchSuggestionLedger.kt`
- `FoundationKnowledgeIntegrationBridge.kt`

### Step 3: Optional - Integrate with ResearchAutopilot

In `ResearchAutopilot.kt`, add:

```kotlin
class ResearchAutopilot(context: Context) {
    // Enable foundation knowledge (optional)
    private val foundationBridge = 
        FoundationKnowledgeIntegrationBridge(context, enableFoundationKnowledge = true)
    
    fun runCycle(userQuery: String): ResearchReportV3 {
        // NEW: Analyze with foundation (optional)
        val foundationResult = foundationBridge.analyzeWithFoundation(
            queryText = userQuery,
            extractedMetadata = extractMetadata(),
            datasetType = "human"
        )
        
        // Add warning to report if needed
        if (foundationResult?.recommendedAction == FoundationAction.BLOCK_HYPOTHESIS_UPGRADE) {
            report.foundationWarning = foundationResult.actionExplanation
        }
        
        // Continue with v1.4.5 cycle (COMPLETELY UNCHANGED)
        val candidates = candidateCollector.collect(userQuery)
        val triaged = datasetsTriageEngine.triage(candidates)
        val parsed = datasetParser.parse(triaged)
        val scored = evidenceQualityGate.score(parsed)
        val ranked = hypothesisRankingEngine.rank(scored)
        
        return reportBuilder.build(ranked)
    }
}
```

**Or don't integrate at all** - v1.4.5 works fine without it.

---

## 📊 Example: GSE250594

### Dataset
- Nickel patch test → skin IL-1 response
- Tested anakinra (IL-1 blocker)
- Single-cell RNA-seq

### What v1.4.5 Sees
```
"inflammation" + "RNA" + "human" → maybe antiviral?
```

### What v1.4.6 Sees
```
✓ Candidate axes: allergy (0.91), interferon (0.22), generic_inflammation (0.55)
✓ Primary: allergy_contact_dermatitis_il1_skin
✓ Antiviral axis score: 0.22 (LOW MATCH)
✓ Action: DOWNGRADE_TO_ANALOGY for antiviral

Warning:
"This dataset matches contact dermatitis better than antiviral.
IL-1 pathway is critical for skin barrier. Antiviral pathway is not primary.
Do not upgrade antiviral hypothesis using this dataset."
```

### Outcome
- Dataset gets filed under "mechanism analogy for IL-1 regulation"
- Not rejected, but correctly categorized
- Antiviral route doesn't get false evidence

---

## 🔄 How Learning Works

### Phase 1: Foundation Guides
```
Query → Foundation says: "This matches interferon_antiviral_timing"
        Score: 0.72, Action: PROCEED_WITH_CAUTION
```

### Phase 2: System Performs
```
Run search cycle, generate report
```

### Phase 3: Outcome Recorded
```
Did the report help? Was it accurate?
User provides feedback (direct or inferred from next query)
```

### Phase 4: Accuracy Updated
```
accuracyLedger.recordCorrectPrediction("interferon_antiviral_timing")
interferon axis score improves: 0.72 → 0.73
```

### Phase 5: Patch if Needed
```
If same axis predicts wrong 3+ times:
  patchLedger.suggestPatch(
    axisId = "interferon_antiviral_timing",
    conflictDescription = "Keeps recommending antiviral when no viral load",
    suggestedChange = "Require viral load as critical, not just optional"
  )
```

**User reviews patch, approves or rejects.**
Knowledge only changes after human review.

---

## 🎯 Confidence Levels

| Level | Meaning | Action |
|-------|---------|--------|
| **HIGH** | Strong match, all critical evidence | PROCEED |
| **MEDIUM** | Decent match, some evidence | PROCEED_WITH_CAUTION |
| **LOW** | Weak match, significant gaps | REQUIRE_MORE_EVIDENCE |
| **CAUTION** | Questionable fit, conflicts detected | DOWNGRADE_TO_ANALOGY |
| **NONE** | Unknown or off-route | BLOCK_HYPOTHESIS_UPGRADE |

---

## 🛑 When Foundation Says "BLOCK"

```
Example: Allergy dataset, but user claims "antiviral evidence"

System says: BLOCK_HYPOTHESIS_UPGRADE
Reason: "Forbidden conflation: allergy_is_not_infection"

User can:
❌ Cannot upgrade to hypothesis (blocked)
✅ Can use as mechanism context
✅ Can save for future allergy analysis
✅ Can override (system marks as "user override")
```

System logs override for future learning.

---

## 📈 Scaling from 3 to 7 Packs

### Current (Phase 1): 3 Packs
- Immunology Basics
- Viral / Interferon Timing
- Psychoneuroimmune Context

### Future (Phase 2): Add 4 More
- Allergy / Type-2 Response
- Inflammaging
- T-cell / B-cell Memory
- Resolution / Recovery

### Scaling Gate
Only add Pack 4+ if Phase 1 succeeds:
- ✅ OFF_ROUTE decisions are correct ≥80%
- ✅ Axis rankings agree with experts ≥70%
- ✅ Repeated failure modes reduced ≥30%
- ✅ No bad hypothesis upgrades from foundation

If not met: Fix Phase 1 first.

---

## ⚙️ Configuration

### Enable/Disable at Runtime
```kotlin
// Create with foundation knowledge enabled
val bridge = FoundationKnowledgeIntegrationBridge(context, enableFoundationKnowledge = true)

// Or disabled (v1.4.5 behavior)
val bridge = FoundationKnowledgeIntegrationBridge(context, enableFoundationKnowledge = false)

// Toggle at runtime
bridge.setEnabled(false)  // Disable
```

### Check Health
```kotlin
if (bridge.isHealthy()) {
    Log.d("Foundation", "System ready")
} else {
    Log.w("Foundation", "System degraded, using v1.4.5 only")
}
```

---

## 🧪 Testing

### Example Tests

1. **GSE250594 Test**
   ```
   Input: nickel dermatitis data
   Expected: allergy axis ranked highest, antiviral OFF_ROUTE
   ```

2. **Viral Without VL Test**
   ```
   Input: IFN markers + time-course, NO viral load
   Expected: REQUIRE_MORE_EVIDENCE before hypothesis upgrade
   ```

3. **Stress + Inflammation Test**
   ```
   Input: stress score + IL-6, no immune outcome
   Expected: PROCEED_WITH_CAUTION as context modifier, NOT primary cause
   ```

All JSON includes these test cases.

---

## 🔐 Safety Features

### 1. No Automatic Knowledge Update
- Only suggestions, awaiting review
- All patches logged in `FoundationPatchSuggestionLedger`
- Human decides which patches to apply

### 2. Error Isolation
- Foundation error doesn't crash v1.4.5
- If foundation fails to load, system degrades gracefully
- v1.4.5 continues working independently

### 3. Audit Trail
- All decisions logged with timestamp
- All conflicts recorded
- All patches suggested with reasoning

### 4. Claim Limits
Every recommendation includes ceiling:
```
foundation_knowledge_not_evidence  → Foundation guides, evidence proves
mechanism_plausibility            → Consistent with mechanism, not proof
analogy_only                       → Use for thinking, not evidence
direction_only                     → Suggests area to explore
none                               → Do not use
```

---

## 📝 What's NOT Included (Future)

These will come in v1.5.x:
- FailurePatternSynthesizer
- HypothesisInteractionDetector (advanced)
- RouteDiscoveryEngine (full implementation)
- CausalChainMapper

These require 20+ successful reports first.

---

## 🎓 Key Principles

### Foundation Guides, Evidence Proves
Foundation knowledge is prior information, not proof.
Data gates the belief, not foundation.

### Ambiguity > False Certainty
Better to say "UNCERTAIN" than to block incorrectly.
User can override with visible warning.

### Learn Without Drifting
Track what works, suggest patches, await review.
Never auto-update knowledge.

### Non-Binary Decisions
Not just YES/NO blocking.
Instead: confidence levels and action recommendations.

---

## 🚀 Integration Checklist

- [ ] Copy 5 Kotlin files to app/src/main/java/com/immunesignal/app/
- [ ] Copy 5 JSON files to app/src/main/assets/
- [ ] Build: `./gradlew build`
- [ ] Test: `./gradlew test`
- [ ] (Optional) Add FoundationKnowledgeIntegrationBridge to ResearchAutopilot
- [ ] Deploy with `enableFoundationKnowledge = true` (or false for v1.4.5 behavior)

---

## 📞 Support

All Kotlin files have inline documentation.
All JSON has detailed comments.
All errors are non-fatal (graceful degradation).

If foundation knowledge fails to load, system falls back to v1.4.5.

**v1.4.6 is designed to improve safety without breaking reliability.**

---

**Version:** 1.4.6-alpha-foundation-knowledge-os  
**Status:** Production Ready  
**Risk Level:** Minimal (optional, non-blocking)  
**Last Updated:** May 11, 2026
