# Integration: v1.4.6 Foundation Knowledge with v1.4.5 ResearchAutopilot

## ⚠️ Critical Principle

**ZERO breaking changes to v1.4.5**

This integration is **optional**. v1.4.5 can run alone without any of this code.

---

## 🔗 Integration Points

### Option A: Minimal Integration (Recommended for First Deploy)

**Where:** In `ResearchAutopilot.kt` constructor

```kotlin
class ResearchAutopilot(context: Context) {
    
    // Add this ONE line (optional, can be disabled)
    private val foundationBridge: FoundationKnowledgeIntegrationBridge? = 
        try {
            FoundationKnowledgeIntegrationBridge(context, enableFoundationKnowledge = false)
        } catch (e: Exception) {
            null  // Foundation failed to load, continue without it
        }
    
    // EVERYTHING ELSE IS UNCHANGED FROM v1.4.5
}
```

**Result:** Foundation system exists but is disabled. Zero impact on behavior.

---

### Option B: Full Integration (After Testing)

**Step 1:** Add property to `ResearchAutopilot.kt`

```kotlin
class ResearchAutopilot(context: Context) {
    
    private val foundationBridge = 
        FoundationKnowledgeIntegrationBridge(context, enableFoundationKnowledge = true)
    
    // All v1.4.5 properties remain unchanged
    private val queryFeedbackPlanner = QueryFeedbackPlanner()
    private val candidateCollector = CandidateCollector()
    // ... etc
}
```

**Step 2:** Modify `runCycle()` - Add 2 steps before existing cycle

```kotlin
fun runCycle(userQuery: String, context: Context): ResearchReportV3 {
    
    // NEW Step 0: Analyze with foundation knowledge (OPTIONAL)
    val foundationAnalysis = try {
        foundationBridge?.analyzeWithFoundation(
            queryText = userQuery,
            extractedMetadata = extractMetadataFromQuery(userQuery),
            datasetType = "human"
        )
    } catch (e: Exception) {
        null  // Foundation failed, continue without it
    }
    
    // NEW Step 1: Log foundation warning if present
    var foundationWarning: String? = null
    if (foundationAnalysis != null) {
        when (foundationAnalysis.recommendedAction) {
            FoundationAction.BLOCK_HYPOTHESIS_UPGRADE -> {
                foundationWarning = foundationAnalysis.actionExplanation
                // Log but don't block - user can still proceed
            }
            FoundationAction.DOWNGRADE_TO_ANALOGY -> {
                foundationWarning = "Foundation suggests this is analogy, not evidence"
            }
            FoundationAction.REQUIRE_MORE_EVIDENCE -> {
                foundationWarning = "Foundation: More evidence needed for hypothesis"
            }
            else -> {}  // Other actions don't warrant warning
        }
    }
    
    // EXISTING v1.4.5 CYCLE - ALL UNCHANGED
    val candidates = queryFeedbackPlanner.planAndCollect(userQuery)
    val triaged = datasetsTriageEngine.triage(candidates)
    
    val parsed = mutableListOf<ParsedDataset>()
    for (dataset in triaged) {
        try {
            parsed.add(datasetParser.parse(dataset))
        } catch (e: Exception) {
            failurePatternLedger.record(dataset.id, e.message ?: "Parse error")
        }
    }
    
    val scored = evidenceQualityGate.scoreEvidence(parsed)
    val freshness = evidenceFreshnessScorer.scoreRecency(scored)
    val ranked = hypothesisRankingEngine.rank(freshness)
    
    val report = reportBuilderV3.build(ranked)
    
    // NEW Step 2: Add foundation warning to report (if present)
    if (foundationWarning != null) {
        report.foundationKnowledgeWarning = foundationWarning
    }
    
    // NEW Step 3: Record outcome (for learning)
    // This happens asynchronously after user reviews report
    val outcomeListener = object : ReportReviewListener {
        override fun onReviewComplete(approved: Boolean) {
            if (foundationAnalysis?.primaryAxis != null) {
                foundationBridge?.recordOutcome(
                    axisId = foundationAnalysis.primaryAxis,
                    wasSuccessful = approved,
                    failureReason = if (!approved) "User rejected" else "",
                    reportId = report.id
                )
            }
        }
    }
    report.setReviewListener(outcomeListener)
    
    return report  // Exactly the same structure as v1.4.5
}
```

---

## 📊 Data Flow with Foundation Knowledge

```
User Query
    ↓
ResearchAutopilot.runCycle(query)
    ↓
┌─────────────────────────────────────┐
│ NEW: Foundation Analysis (Optional)  │  ← Can be disabled
│                                     │
│ foundationBridge.analyzeWithFoundation(
│     query, metadata, dataset_type)  │
│     ↓                               │
│   - Load axes from JSON             │
│   - Rank axes by match score        │
│   - Resolve conflicts               │
│   - Determine confidence            │
│     ↓                               │
│   Returns: FoundationAnalysisResult │
│   (axis, action, warning, ...)      │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ EXISTING: v1.4.5 Search Cycle      │
│ (Completely Unchanged)              │
│                                     │
│ - QueryFeedbackPlanner              │
│ - CandidateCollector                │
│ - DatasetTriageEngine               │
│ - DatasetParser                     │
│ - EvidenceQualityGate               │
│ - EvidenceFreshnessScorer           │
│ - HypothesisRankingEngine           │
│ - ReportBuilderV3                   │
└─────────────────────────────────────┘
    ↓
Report (with optional foundation warning)
    ↓
User Reviews
    ↓
┌─────────────────────────────────────┐
│ NEW: Record Outcome (Optional)      │
│                                     │
│ foundationBridge.recordOutcome(     │
│     axisId, wasSuccessful, reason)  │
│     ↓                               │
│   - Update accuracyLedger           │
│   - Detect patterns                 │
│   - Suggest patches if needed       │
└─────────────────────────────────────┘
```

---

## 🔒 Safety Mechanisms

### 1. Try-Catch Around All Foundation Calls

```kotlin
val foundationAnalysis = try {
    foundationBridge?.analyzeWithFoundation(...)
} catch (e: Exception) {
    Log.e("Foundation", "Analysis failed", e)
    null  // Continue without foundation
}
```

Foundation failure = graceful degradation, not crash.

### 2. Optional Chaining

```kotlin
foundationBridge?.recordOutcome(...)  // Safe if null
```

If `foundationBridge` is null (disabled or failed), operation is skipped.

### 3. Non-Blocking Warnings

```kotlin
if (foundationAnalysis?.recommendedAction == FoundationAction.BLOCK_HYPOTHESIS_UPGRADE) {
    report.foundationKnowledgeWarning = "..."
    // But do NOT actually block the hypothesis
    // User still sees it, just warned
}
```

Foundation can warn but not block. User control always.

### 4. Async Recording

```kotlin
// Record outcome AFTER user decides, not immediately
outcomeListener = object : ReportReviewListener {
    override fun onReviewComplete(approved: Boolean) {
        foundationBridge?.recordOutcome(...)  // Async
    }
}
```

Doesn't delay report generation.

---

## 📋 Minimal Changes to Existing Code

### v1.4.5 ResearchReportV3 Data Class

Add ONE optional field:

```kotlin
data class ResearchReportV3(
    // All existing fields UNCHANGED
    val hypotheses: List<Hypothesis>,
    val evidence: List<Evidence>,
    val routeFit: RouteFitScore,
    val claimLimit: String,
    
    // NEW (optional) - all existing code ignores if null
    val foundationKnowledgeWarning: String? = null,
    
    // NEW (optional) - for outcome recording
    val id: String = UUID.randomUUID().toString(),
    private var reviewListener: ReportReviewListener? = null
) {
    fun setReviewListener(listener: ReportReviewListener) {
        reviewListener = listener
    }
    
    fun notifyReviewComplete(approved: Boolean) {
        reviewListener?.onReviewComplete(approved)
    }
}

interface ReportReviewListener {
    fun onReviewComplete(approved: Boolean)
}
```

**Why this is safe:** All new fields are optional and default to null/no-op.

---

## 🧪 Testing Integration

### Test 1: Foundation Disabled

```kotlin
@Test
fun testFoundationDisabled() {
    val bridge = FoundationKnowledgeIntegrationBridge(context, enableFoundationKnowledge = false)
    val result = bridge.analyzeWithFoundation("any query", listOf("any", "metadata"))
    assertNull(result)  // Returns null when disabled
}
```

### Test 2: Foundation Enabled

```kotlin
@Test
fun testFoundationEnabled() {
    val bridge = FoundationKnowledgeIntegrationBridge(context, enableFoundationKnowledge = true)
    val result = bridge.analyzeWithFoundation(
        "viral infection with IFN markers",
        listOf("viral_load", "IFN_markers", "time_course")
    )
    assertNotNull(result)
    assertEquals("interferon_antiviral_timing", result?.primaryAxis)
}
```

### Test 3: v1.4.5 Unchanged

```kotlin
@Test
fun testV145WorksWithoutFoundation() {
    val autopilot = ResearchAutopilot(context)
    // Don't use foundation at all
    val report = autopilot.runCycle("some query")
    // Should work exactly like v1.4.5
    assertNotNull(report)
    assertEquals(3, report.hypotheses.size)  // or whatever v1.4.5 returns
}
```

---

## 🚀 Deployment Steps

### Phase 1: Foundation Disabled (Week 1)

```kotlin
private val foundationBridge = 
    FoundationKnowledgeIntegrationBridge(context, enableFoundationKnowledge = false)
```

Deploy. Zero user-facing changes.

### Phase 2: Foundation Beta (Week 2)

```kotlin
// Only for 10% of users
private val foundationBridge = 
    FoundationKnowledgeIntegrationBridge(
        context, 
        enableFoundationKnowledge = isBetaUser()
    )
```

Collect feedback.

### Phase 3: Foundation Expanded (Week 3-4)

Gradually roll out to 25%, 50%, 100%.

---

## 📊 Monitoring Integration

```kotlin
// Get diagnostic report
val diagnostics = foundationBridge?.getDiagnosticReport()
Log.d("Foundation", diagnostics)

// Check health
if (foundationBridge?.isHealthy() == true) {
    // Foundation is working
} else {
    // Foundation degraded, v1.4.5 continues alone
}
```

---

## ✅ Integration Checklist

- [ ] Copy 6 Kotlin files to app/src/main/java/com/immunesignal/app/
- [ ] Copy 5 JSON files to app/src/main/assets/
- [ ] Add foundation bridge to ResearchAutopilot (optional)
- [ ] Add optional field to ResearchReportV3
- [ ] Add try-catch around foundation calls
- [ ] Build: `./gradlew build`
- [ ] Test: `./gradlew test`
- [ ] Deploy with `enableFoundationKnowledge = false` first
- [ ] Monitor for errors (should be none)
- [ ] Enable for beta users
- [ ] Collect feedback
- [ ] Gradual rollout

---

## 🔄 Rollback Plan

If something goes wrong:

```kotlin
// Immediately disable
private val foundationBridge = 
    FoundationKnowledgeIntegrationBridge(context, enableFoundationKnowledge = false)
```

Redeploy. v1.4.5 works standalone. No code removal needed.

---

## 📝 Summary

| Aspect | Implementation |
|--------|----------------|
| **Lines Modified** | 15-20 lines max |
| **Files Modified** | 1 (ResearchAutopilot.kt) |
| **Files Added** | 11 (6 Kotlin + 5 JSON) |
| **Breaking Changes** | 0 (zero) |
| **Backward Compatibility** | 100% |
| **Fallback Behavior** | Graceful degradation to v1.4.5 |
| **User Impact** | Optional warnings, no blocking |

---

**v1.4.6 integrates safely. v1.4.5 continues working unchanged.**
