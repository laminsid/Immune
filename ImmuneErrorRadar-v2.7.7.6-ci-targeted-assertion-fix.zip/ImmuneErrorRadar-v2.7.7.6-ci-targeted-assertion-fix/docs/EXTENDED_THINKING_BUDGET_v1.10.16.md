# v1.10.16 — Extended Thinking Budget

Purpose: prevent stalled dataset-hunt cycles from looking like a 30-second stop. The app now exposes a longer checkpointed thinking budget and records explicit local reasoning passes before archive/reframe.

Changes:
- Default Deep Think session budget increased to 45 minutes.
- Research-cycle learning budget increased to 45 minutes.
- Search budget increased to 20 minutes from the UI path.
- UI search run now allows 8 query paths and 25 results per query, with up to 5 selective abstracts.
- Added `ExtendedThinkingBudgetPolicy` with at least 4 visible local reasoning passes.
- Added `extendedThinkingBudgetReport` to JSON/export/UI.
- Claim limit remains `extended_thinking_budget_not_biological_proof`.

Guardrails:
- Extra thinking cannot create biological proof.
- Extra thinking cannot upgrade hypotheses, causal language, diagnosis, treatment, or clinical advice.
- If no accession/dataset handle exists, the next action remains bounded accession/outcome/control/time closure or archive/reframe.
