# Changelog — v1.10.30

## Release: `1.10.30-alpha-release-version-linkage-docs`

### Unified

- Gradle `versionCode` updated to `92`.
- Gradle `versionName` updated to `1.10.30-alpha-release-version-linkage-docs`.
- Runtime `ACTIVE_ENGINE_VERSION` updated to `v1.10.30-alpha-release-version-linkage-docs`.
- `LEARNING_SESSION_SCHEMA_VERSION` updated to `1.10.30`.
- Report labels updated to v1.10.30 for the current integrated path.
- Added `ReleaseVersionLinkageGuard` and registered it in `RuntimeModuleRegistry`.
- Added static audit `audit_release_version_linkage_v11030.py`.
- Added documentation `RELEASE_VERSION_LINKAGE_v1.10.30.md`.

### Preserved

- v1.10.25 data-availability accession query priority.
- v1.10.26 mature-domain evidence probe.
- v1.10.27 dataset path linkage guard.
- v1.10.28 dataset pass coverage linkage.
- v1.10.29 learning/domain path linkage.
- Historical audit tokens retained as comments only, so legacy audits do not falsely fail.

### Claim boundary

This release changes release/linkage hygiene only. It does not create biological proof, diagnosis, treatment, dosage, drug ranking, or clinical recommendation.
