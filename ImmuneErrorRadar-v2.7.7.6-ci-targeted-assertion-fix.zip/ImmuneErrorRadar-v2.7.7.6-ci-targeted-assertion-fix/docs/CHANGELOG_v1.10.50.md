# v1.10.50-alpha-environmental-psychophysiological-exposome-lane

## Purpose
Open the research system to environmental, psychophysiological, hormonal, physical, substance/toxin, digestive, food, age, weather, light, smell, and irritant exposures without weakening scientific claim gates.

## Added lanes
- `ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE` for dust, pollen, air pollution, humidity, heat/cold, smell/odor/fragrance, and weather context.
- `PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE` for stress, psychological pressure, depression, anxiety, burnout, HPA axis, cortisol, HRV, and inflammatory markers.
- `ENDOCRINE_HORMONE_HPA_IMMUNE_LANE` for hormones such as cortisol, estrogen, progesterone, testosterone, thyroid, insulin, and melatonin.
- `DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE` for gastric acidity, enzymes, reflux, digestion, food exposure, meal timing, microbiome, and barrier tissue.
- `PHYSICAL_LIGHT_RADIATION_CIRCADIAN_IMMUNE_LANE` for light, UV/radiation, screens, moon/lunar/seasonal context, temperature, circadian timing, melatonin, and cortisol.
- `TOXIN_SUBSTANCE_EXPOSURE_IMMUNE_LANE` for alcohol, smoking, tobacco/nicotine, drugs/substance exposure, and related immune-context markers.
- `AGE_LIFE_STAGE_IMMUNE_CONTEXT_LANE` for age/life-stage context, immunosenescence, CMV serostatus, T-cell subsets, CRP, IL-6, TNF-alpha, comorbidity and medication context.

## Guardrails
These variables are exposure/context signals only. They may increase lookup priority, parsing priority, and comparator-hunt specificity. They must not create diagnosis, treatment, supplement advice, dose advice, behavioral instruction, or causal/scientific claims without EvidenceObject gates.

## Required evidence gates
- Exposure definition: timing, intensity, frequency, context, duration when available.
- Human/patient/cohort context.
- Outcome labels.
- Control/comparator: matched control, baseline, exposed vs unexposed, responder vs non-responder, placebo, negative control.
- Time-order or longitudinal/serial signal.
- Contradiction/null-result search before any strengthening.

## Why this patch exists
The system should learn from real-world modifiers such as dust, pollen, stress, hormones, light, weather, humidity, smell, smoking, alcohol, digestive acidity, food, depression, age, and environmental exposures. But these signals are noisy and must be routed as exposures, not treated as proof.

## No-islands linkage hardening

- Added explicit Kotlin owner `EnvironmentalPsychophysiologicalExposomeLaneV11050` so the exposome asset is not a documentation-only island.
- Added `ExposomeToLabMapperV11050` and `NoExposureAdviceGuardV11050` as runtime-linked modules used by topic-fit routing.
- Topic-fit routing now delegates exposome lane selection and context seeds through the v1.10.50 owner before older mature-domain priors can replay.
- Added `audit_v11050_no_isolated_exposome_paths.py` and wired it into `run_static_checks_full.sh`.
