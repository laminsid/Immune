# Immune Error Radar v1.9.9-alpha-cognitive-momentum

## Purpose
This patch makes the post-search cognition loop measurable. v1.9.8 created a hypothesis graph; v1.9.9 asks whether that graph actually moved or whether it repeated the same evidence blocker.

## Added
- `CognitiveMomentumReport` and `CognitiveMomentumEngine`.
- Momentum score: progress minus repeated blocker penalty.
- Closed evidence keys vs stalled evidence keys.
- Prior-cycle momentum lock: if the latest saved report says `NO_BROAD_SEARCH` or `THINK_FIRST`, the next Search run is constrained to one narrow evidence-closure query.
- Report JSON schema bumped to `199`.
- UI Thinking Board now shows Momentum state, score, stalled keys, and decision lock.
- PDF export now includes Cognitive Momentum v1.9.9.
- Knowledge ledger entry: `cognitive_momentum_v199`.

## Safety / claim boundary
- The momentum report is a routing and discipline layer only.
- It does not prove biology, diagnosis, treatment value, causality, or clinical usefulness.
- It is allowed to block broad search and force accession/gap closure.

## Operational impact
- If the same missing evidence key repeats, the engine must close it, archive/cool down the route, or think offline.
- Broad PubMed replay should not happen merely because the user pressed Search.
- A search cycle must earn its network cost by closing at least one evidence key or by producing a new parent evidence object.
