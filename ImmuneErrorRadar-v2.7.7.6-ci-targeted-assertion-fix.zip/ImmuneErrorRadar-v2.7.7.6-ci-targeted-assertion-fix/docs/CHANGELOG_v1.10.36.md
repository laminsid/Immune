# Changelog v1.10.36

Release identity: `1.10.36-alpha-learning-monitor-continuity`

- Updated release identity to `versionCode=98`, `versionName=1.10.36-alpha-learning-monitor-continuity`, `ACTIVE_ENGINE_VERSION=v1.10.36-alpha-learning-monitor-continuity`, and `LEARNING_SESSION_SCHEMA_VERSION=1.10.36`.
- Added `LearningRulesUiSummary` / `Learning audit monitor` as a compact user-facing monitor of what the system learned.
- The UI now shows learned details, pinned rules, saved route priors, missing evidence fields, invalidation criteria, and next audit action in one block.
- The PDF/technical exporter now includes `Learning audit monitor v1.10.36`.
- Added `LearningRulesUiSummaryV11036Test` to lock the user-facing learning monitor behavior.
- Kept v1.10.35 lead-closure handoff, metadata closure, unknown-route classifier, and EBV/HHV-6/CMV as route-prior-only logic.

No biological proof or clinical claim was added.
