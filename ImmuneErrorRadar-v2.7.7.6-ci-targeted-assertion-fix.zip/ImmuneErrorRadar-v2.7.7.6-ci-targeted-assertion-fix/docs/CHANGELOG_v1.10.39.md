# v1.10.39-alpha-final-path-linkage-release

VersionCode: `101`
Schema: `1.10.39`

## Added
- `IntegratedPathLinkageGuard` and `IntegratedPathLinkageReport`.
- Final path decision surface connecting lead closure, metadata closure, EBV criterion lane, Evidence Prior Matrix, learning/domain linkage, and dataset path coverage.
- UI and PDF/technical export lines for final path decision and open warning count.

## Fixed
- Manual/lead closure source-family paths are now counted as classified path coverage.
- Mature-domain probe warnings are consumed when the active path is explicitly held by lead/metadata closure.
- Release identity updated across Gradle, runtime, schema, docs, and static checks.

## Boundaries
- No biological proof or hypothesis upgrade.
- No EBV or molecular mimicry confirmation without EvidenceObject gates.
- No treatment, dose, drug ranking, or supplement recommendation.
