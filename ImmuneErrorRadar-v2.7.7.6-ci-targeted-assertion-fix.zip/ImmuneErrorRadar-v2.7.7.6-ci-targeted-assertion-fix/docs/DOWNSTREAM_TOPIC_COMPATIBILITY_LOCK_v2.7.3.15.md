# v2.7.3.15 — Downstream Topic Compatibility Lock

Purpose: fix the remaining post-input contamination where a correctly captured topic such as Covid or Allergies could still display pesticide/exposome/microbiome templates in downstream report layers.

## Changes

- Added semantic defaults in `GTIMResearchIntentParserV255` for:
  - Allergies / allergic / hypersensitivity / atopy → IgE, mast-cell, eosinophil, IL-4/IL-5/IL-13, type-2 route.
  - Covid / SARS-CoV-2 / PASC → interferon, IL-6/TNF, PBMC/blood/airway, recovered/healthy comparator.
  - Depression + bacteria/microbiome → gut-brain, tryptophan/kynurenine, IL-6/TNF/CRP, cohort comparator.
  - Longevity / aging → immunosenescence, inflammaging, IL-6/CRP, healthy-aging/frailty comparator.
- Reworked `GTIMRelationshipDiscoveryRouterV2736` so it no longer falls back to the first archetype when no compatible route exists.
- Added topic-compatible relationship archetypes:
  - `covid_interferon_cytokine_bridge`
  - `allergy_type2_ige_mast_cell_bridge`
- Tightened `GTIMGeneralMicrobiomeImmuneBridgeV2732` so it opens only for explicit microbiome/bridge or exposure+microbiome questions.
- Added benchmark topic lock in `GTIMBenchmarkValueHarnessV273`: the current user topic and parsed intent outrank polluted top queries.
- Strengthened `TopicIsolationAndScoreGateV2741`:
  - intent-level missing fields now cap topic fit and evidence/data-quality scores;
  - toxicant/pesticide downstream template mismatch is detected;
  - lookup-only / metadata-gap / missing comparator/assay paths remain capped.
- Updated `GlobalResearchGradeBriefV11061` to replace incompatible downstream route lines with a current-topic safe route line.

## Safety boundary

This patch improves routing, scoring honesty, and report topic fit. It does not make biological, clinical, diagnostic, treatment, or causality claims.

## Expected report behavior

- `Covid` should not show pesticide/gut relationship as GTIM-added relationship.
- `Allergies` should no longer parse as `not specified`; it should map to allergy/type-2/IgE/mast/eosinophil route.
- Blank-input autonomous discovery remains allowed, but remains visibly marked as AUTO.
- If disease/pathway/comparator/assay remain missing, scores are capped instead of inflated.

## New regression guard

- `DownstreamTopicCompatibilityV2744Test.kt`
- `audit_gtim_v2744_downstream_topic_compatibility.py`
