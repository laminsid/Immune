# GitHub CI Runtime Surface Hardening v1.10.54

This release is a CI/runtime integrity patch. It exists because recent rapid feature additions created a risk that labels, reports, static-check output, and release guards could disagree even when the scientific routing logic was connected.

## Contract

- Gradle, runtime flags, active engine, release guard, docs, and audits must point to the same current release.
- Legacy release labels may remain as audit tokens only.
- Each version-owner object must keep its own `VERSION_LABEL`; no owner may accidentally inherit the next release label.
- Static-check scripts must print PASS only after the final audit has run.
- Release ZIPs must not contain `.gradle`, `build`, APK/AAB/AAR, `__pycache__`, or `.pyc` artifacts.

## Claim boundary

This patch is not biological proof. It does not change evidence thresholds, diagnostic limits, treatment boundaries, dosage policy, or drug-ranking guards.
