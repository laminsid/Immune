# Autonomous Resilience Patch v1.3.3

This patch changes how the research engine behaves when it fails.

## Principle
No useful result must never end as “nothing.” It must produce a research decision:
- change search intent,
- search contradictions,
- search datasets,
- fetch only top abstracts,
- or verify dataset candidates.

## Cycle outputs
Short report V3:
1. Cycle result
2. New useful lead
3. Hypothesis changed
4. Why it matters
5. Next autonomous move
6. Do not believe yet

## Strict boundaries
- No medical, diagnostic, or treatment claims.
- No new biological axes in v1.3.3.
- No ML until curated global datasets are normalized and the lock system demonstrates value.
