# Dataset Hunt Unlock Maintenance 10 — v1.10.8

## Purpose
Prevent the evidence-first unlock from becoming too broad after the closed-loop fix.

## Fixes
- Added `evidenceFirstBudget` to the dataset-first forager.
- In evidence-first mode, the forager is capped to:
  - 2 source families maximum;
  - 1 query per route maximum.
- Once an evidence-first forager has executed, the same-cycle post-forager search directive is consumed and replaced with `EVIDENCE_FIRST_FORAGER_EXECUTED`.
- This avoids accidentally running both the direct dataset forager and an additional linked-spine query in the same cycle.

## Product invariant
Evidence-first mode should acquire a bounded accession lead, not reopen a broad network cycle.
