# v1.9.6-alpha — Thinking Continuity Patch

Purpose: keep reasoning alive after a search cycle ends. This patch does not add medical claims, diagnosis, treatment ranking, or biological proof. It adds a local continuity layer that links accession closure, hypotheses, objections, repeated blockers, and search permission across cycles.

## Added

- `ThinkingContinuityReport`: stores active thought state, iteration, repeated gaps, open thought threads, merged hypothesis line, next local question, and next search permission.
- `ThinkingContinuityEngine`: builds continuity from the latest cycle plus recent saved reports.
- Offline thought steps: pressing `Think saved` now records a new local thinking step instead of only re-rendering the same report.
- `immune_offline_thinking_steps.jsonl`: bounded local ledger for manual offline thinking steps.
- UI continuity lines in Decision card, Learning receipt, and Thinking board.
- PDF export section for continuity state, repeated gaps, open thought threads, and search permission.
- Project-health audit now accepts schema 196 and checks continuity wiring.

## Changed

- Report schema increased to `196`.
- Search permission is now explicitly gated by the continuity layer:
  - `NO_BROAD_SEARCH`
  - `NARROW_SEARCH_ALLOWED`
  - `THINK_FIRST`
- The report now distinguishes:
  - post-search thinking inside the current cycle
  - continuity thinking across saved cycles
  - manual offline thinking steps triggered without internet

## Guardrails

- Thinking continuity is `thinking_continuity_not_biological_proof`.
- Manual thinking steps are `manual_offline_thinking_not_biological_proof`.
- No medical, diagnostic, treatment, or causality claims are introduced.
- Broad search remains blocked when accession closure has unresolved outcome/control/time gaps.

## Validation performed locally

- JSON validation: PASS
- Kotlin delimiter audit: PASS
- Kotlin newline/string audit: PASS
- XML/layout ID audit through project health: PASS
- v1.9.5 project-health audit with schema-196 continuity checks: PASS
- CognitiveNextCycleBridge helper audit: PASS
- Isolated Kotlin compile for `PostSearchCognition.kt` with stubs: PASS

Full Android Gradle build was not run locally because the uploaded project does not include `gradlew`; GitHub/Android CI remains the final compile gate.
