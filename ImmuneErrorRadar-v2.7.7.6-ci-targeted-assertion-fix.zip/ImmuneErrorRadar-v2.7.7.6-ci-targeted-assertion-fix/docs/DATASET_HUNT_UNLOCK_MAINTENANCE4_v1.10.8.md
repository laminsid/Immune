# Immune Error Radar v1.10.8 — dataset-hunt unlock maintenance 4

This pass closes CI and routing regressions found after maintenance 3.

## Changes

- Updated `audit_search_directive_spine_v1103.py` so it validates the v1.10.8 unlock-aware dataset-first wiring instead of the obsolete `!priorUnifiedSearchLockV203` token.
- Hardened `DirectDatasetSourceRouter.shouldRunDatasetFirst` by normalizing `researchState` before DATASET_HUNT/STAGNATION checks.
- Added explicit evidence-first/accession-search intent recognition so the router cannot reject a safe evidence acquisition request because of casing or sparse runtime text.
- Added regression tests for normalized DATASET_HUNT routing and cooldown escape route preservation.

## Non-goals

- No biological claim upgrade.
- No broad search unlock.
- No evidence-closure override when a real accession target exists.
