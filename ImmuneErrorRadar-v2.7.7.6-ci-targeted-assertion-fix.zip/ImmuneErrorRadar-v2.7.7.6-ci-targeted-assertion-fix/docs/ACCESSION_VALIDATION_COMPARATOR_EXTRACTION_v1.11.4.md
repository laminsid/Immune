# Accession Validation Comparator Extraction v1.11.4

This patch turns source metadata enrichment into explicit validation and comparator extraction cards.

## New outputs

- `AccessionValidationCardV1114`
- `ComparatorExtractionCardV1114`
- `evidenceObjectCreationGate`
- `metadataExtractionCommands`

## Gates

- `ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED`
- `EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION`
- `COMPARATOR_BLOCKED_NO_EVIDENCE_OBJECT`
- `CASE_LABEL_BLOCKED_NO_EVIDENCE_OBJECT`
- `EVIDENCE_OBJECT_BLOCKED_BY_MATRIX_READINESS`
- `EVIDENCE_OBJECT_REVIEW_CANDIDATE_NO_CLAIM`

## Boundary

Research data engineering only. No diagnosis, treatment, dose, supplement advice, patient prediction, causal claim, clinical utility claim, DGE claim, fold-change, or p-value.
