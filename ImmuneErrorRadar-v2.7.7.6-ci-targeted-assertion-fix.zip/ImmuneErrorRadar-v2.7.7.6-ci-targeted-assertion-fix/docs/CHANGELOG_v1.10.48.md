# v1.10.48-alpha-relaxed-progression-context-alignment

Version: `1.10.48-alpha-relaxed-progression-context-alignment`  
versionCode=110  
App title: `ImmuneSignal Research` remains unchanged for Google Play continuity.

## Goal

lower strictness only for research progression, not for scientific claims.

The previous reports showed a repeated loop: weak leads existed, context existed, but parsing did not move fast enough toward minimum metadata. This release lets context-aligned weak/off-route candidates proceed to metadata inspection while keeping all proof/causal/treatment gates locked.

## Changes

- Added relaxed progression mode: `RELAXED_PROGRESSION_NO_CLAIM_RELAXATION`.
- Added controlled context seeds for Vaccine, Antibiotics, Longevity/Aging, Sleep/Circadian, Fatigue/Long COVID, EBV/CMV/HHV-6, HPA/cortisol, cytokines, and mitochondrial routes.
- Added soft progression gates distinct from hard claim gates.
- Updated `CandidateActionResolver` so context-aligned weak/off-route candidates can become `OFF_ROUTE_MINIMUM_METADATA_PROBE` instead of being dead-stopped.
- Lowered the off-route block threshold for metadata inspection while preserving hypothesis-upgrade blocks.
- Updated report UI/export to display strictness, context seeds, soft gates, and hard claim gates.
- Registered `RelaxedProgressionContextAlignmentV11048`, `ControlledContextSeedAligner`, and `SoftProgressionHardClaimGate` in runtime registry.

## Integrity limits

- No EvidenceObject is created by context alone.
- Context seed matching must not raise evidence confidence.
- Context seed matching must not raise route-fit into proof.
- No diagnosis, dose, treatment, supplement, herb, or drug recommendation.
- Contradiction/null-result search remains mandatory before strengthening a biological link.

## Acceptance checks

- v1.10.48 relaxed progression audit.
- v1.10.48 release linkage audit.
- JSON validation.
- Kotlin delimiter audit.
- XML parse.
- Release hygiene.

- no claim relaxation: context seeds are lookup signals only.
