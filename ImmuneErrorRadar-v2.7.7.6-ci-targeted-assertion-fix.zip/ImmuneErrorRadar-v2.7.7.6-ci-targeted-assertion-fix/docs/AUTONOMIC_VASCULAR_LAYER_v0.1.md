# AUTONOMIC VASCULAR LAYER v0.1

Purpose: explore stress/allergy/blood-pressure dynamics as competing forces.

Competing forces:
- Sympathetic pressure-up: stress, panic/rapid breathing, high resting pulse, higher BP.
- Histamine pressure-down: mast-cell/allergy signals, flushing, faintness during allergy, low BP.
- BP instability: dizziness on standing, faintness, cold hands/feet, high or low BP extremes.

This layer does not diagnose dysautonomia, mast cell disease, hypertension, hypotension, or anaphylaxis. It only records repeatable timing candidates.
