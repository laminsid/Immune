# Immune Error Radar v1.10.8 — dataset-hunt unlock maintenance 3

This pass hardens the v1.10.8 evidence-first unlock without changing its claim boundary.

## What changed

- `DatasetHuntSearchUnlockPolicy` now normalizes research state / directive owner before evaluating unlock eligibility.
- Persistent failure memory can now trigger the safe unlock even when the latest report text is sparse, as long as the memory still points to missing dataset accession evidence.
- Explicit accession targets such as `GSE`, `GDS`, `SDY`, `PRJNA`, `SRP`, `SRA`, `GSM`, or `ERP` still block the unlock and stay under closure control.
- `ResearchSearchDirectiveResolverTest` now verifies that `EVIDENCE_FIRST_ACCESSION_SEARCH` keeps the search bounded and sets `blockDatasetFirst=false`.
- `ResearchCyclePhaseAuditTest` now verifies that an unlocked dataset-first run is not reported as a lock violation.
- `audit_dataset_hunt_unlock_v1108.py` now guards all new regression points.

## Invariant preserved

The unlock only permits evidence acquisition. It does not permit hypothesis upgrade, causal language, clinical language, broad mechanism search, runtime failover, or biological proof claims.

## Desired next report signature

The next report should not repeat:

```text
DATASET_HUNT + Dataset-first forager: NOT_RUN + Search executed: 0
```

It should show either a real bounded dataset attempt or a typed failure explaining why the attempt could not produce candidates.
