# v1.10.58-alpha-hyper-drive-hard-data-extraction

versionCode=120  
versionName=`1.10.58-alpha-hyper-drive-hard-data-extraction`  
schema updated to `1.10.58`

## Delta

v1.10.58 upgrades v1.10.57 from strict-intersection priority elevation to Hyper-Drive hard data extraction.

## Added

- Hyper-Drive mode flag: `hyperDriveModeActive`.
- Hard data extraction mode: `AGGRESSIVE_DATA_FORAGING_MODE`.
- Critical usability anomaly detection when a verified cross-family intersection remains at usability `<=10/100`.
- Forced route-fit target `95/100` for verified R1/R2 intersections.
- Multi-Dimensional Accession Search Stream for GEO/GDS and SRA/BioProject.
- Programmatic command log for query execution, accession regex extraction, and control/comparator mapping.
- Runtime data demand contract:
  - `accessions>0` or explicit `HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION`.
  - `evidenceObjects>0` only after real accession metadata, control/comparator, time-order, outcome, and contradiction gates close.
- Control/comparator linkage query generation.

## Stream Alpha

`(EBV OR HHV-6) AND (SLE OR "Systemic Lupus" OR "Multiple Sclerosis") AND ("RNA-Seq" OR "Transcriptome") AND "Data Availability" AND (GSE[0-9]* OR PRJNA[0-9]*)`

## Stream Beta

`("HPA-axis" OR "Cortisol/DHEA ratio" OR "Sleep deprivation") AND ("Interferon-alpha" OR "IL-6" OR "TNF-alpha") AND ("Curcumin" OR "Ashwagandha") AND (GSM[0-9]* OR SRP[0-9]*)`

## Guard

No fabricated accession IDs. No fabricated evidence objects. Hyper-Drive raises retrieval priority and runtime pressure only; biological claims remain blocked until hard metadata and contradiction gates close.
