# Immune Error Radar v1.10.8 — execution report consistency pass

This maintenance pass completes the dataset-hunt unlock repair.

## Fixed

- The UI/text report no longer says `Effective search` when no query path executed.
- Report preview/full report now shows:
  - `Search executed: 0 | planned: ... | status: NOT_EXECUTED_OR_BLOCKED`, or
  - `Search executed: N query path(s) | planned: ...`.
- A static audit now prevents regressions where report surfaces confuse planned budget with executed search.

## Guard added

- `scripts/audit_dataset_hunt_unlock_v1108.py`
- wired into `scripts/run_static_checks.sh`

## Product rule

Planned search budget is not evidence of search execution.
The next report must distinguish:

1. planned budget,
2. actual executed query paths,
3. dataset forager state,
4. direct source families attempted.

This keeps the scientific/UX claim honest while preserving the dataset-hunt unlock.
