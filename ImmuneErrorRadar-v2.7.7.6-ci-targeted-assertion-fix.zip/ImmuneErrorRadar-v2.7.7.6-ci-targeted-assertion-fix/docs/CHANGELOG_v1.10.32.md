# Changelog — v1.10.32

Layer integrated into current release train `1.10.33-alpha-lean-agent-runtime`.

- Added mature-domain focus selection for 2–3 cycle domain depth.
- Added domain-specific kill criteria for histamine/mast-cell, diabetes/metabolic inflammation, and generic mature domains.
- Added domain expertise score upgrade as a search-prior score only.
- Added knowledge gap queue with priority, attempt count, cooldown, last source, next query, and status.
- Added stronger semantic route fingerprinting using intent/domain/source/blockers/axes/normalized terms/outcome.
- Connected focus/gaps/replay to report consistency and final next action.

No biological claim, probability update, treatment recommendation, or hypothesis upgrade was added.
