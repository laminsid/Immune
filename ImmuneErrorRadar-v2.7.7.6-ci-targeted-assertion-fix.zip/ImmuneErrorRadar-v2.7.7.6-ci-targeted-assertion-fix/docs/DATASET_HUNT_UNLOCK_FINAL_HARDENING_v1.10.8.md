# Dataset Hunt Unlock Final Hardening — v1.10.8

This final pass closes the last high-risk false-evidence path found during the dataset-hunt unlock stabilization.

## What changed

- The SRA/GDS dataset-hunt path still extracts explicit accessions from real metadata fields first.
- GDS numeric UIDs may be represented as `GDS<uid>` because GDS UID-style records are accepted as GDS dataset handles.
- SRA numeric Entrez UIDs are **not** promoted into fake `SRA<uid>` accessions.
- If an SRA esummary record has no explicit `PRJNA`, `SRP`, `SRR`, `ERR`, `DRR`, `study_acc`, `run_acc`, or accession-like field, the lead remains `DATASET_ACCESSION_UNRESOLVED`.

## Why this matters

A numeric Entrez UID is not equivalent to an explicit biological dataset accession. Treating it as `SRA<uid>` would make downstream gates count the lead as stronger than it is. This pass preserves the evidence-first unlock while preventing fake accession confidence.

## Regression guard

Added/extended checks:

- `DatasetAccessionResolverV1108Test.numericSraUidIsNotPromotedIntoFakeAccession`
- `scripts/audit_dataset_hunt_unlock_v1108.py` blocks any reintroduction of `"SRA$uid"` fallback.

## Claim boundary

This is routing/data-integrity hardening only. It does not create biological proof, causal language, clinical interpretation, or hypothesis upgrade permission.
