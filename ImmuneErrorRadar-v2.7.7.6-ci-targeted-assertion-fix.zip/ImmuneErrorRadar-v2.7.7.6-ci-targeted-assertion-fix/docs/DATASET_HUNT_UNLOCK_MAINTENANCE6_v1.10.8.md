# v1.10.8 maintenance pass 6 — evidence-present guard

## Purpose

This pass tightens the dataset-hunt unlock so it only opens the safe accession-search path when evidence is truly absent. Missing fields such as `outcome_labels` or `minimum_metadata` are not enough to start a new accession hunt if dataset candidates or evidence objects already exist.

## Guardrails added

- `DatasetHuntSearchUnlockPolicy` now blocks unlock when recent report text shows non-zero dataset/evidence/accession counts.
- The policy still allows `EVIDENCE_FIRST_ACCESSION_SEARCH` when counts are explicitly zero.
- The explicit accession guard remains unchanged: if a prior directive already targets `GSE/GDS/SDY/PRJNA/SRP/SRA/GSM/ERP...`, closure wins.
- The claim limit remains unchanged: the unlock can only route evidence acquisition; it cannot upgrade hypotheses or causal wording.

## Regression coverage

Added tests:

- `doesNotUnlockWhenDatasetEvidenceAlreadyExistsButMetadataIsIncomplete`
- `evidenceFirstIntentStillUnlocksWhenCountsAreExplicitlyZero`

Updated audit:

- `scripts/audit_dataset_hunt_unlock_v1108.py` now checks for the evidence-present guard and the new regression tests.
