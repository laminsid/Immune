# v2.7.3.13 — Blank-Input Autonomous Discovery Mode

## Purpose
When the search field is empty, the app no longer blocks the run or falls back to a generic route. It selects one bounded, high-value immune relationship-discovery topic from a local priority list, then passes that topic through the existing topic isolation, score cap, crash-safety, and report rendering gates.

## Scope
This mode runs only when the user input is blank. User-entered topics always override autonomous discovery.

## Added components
- `AutonomousDiscoveryModeV2743.kt`
- `AutonomousDiscoveryModeV2743Test.kt`
- `audit_gtim_v2743_autonomous_discovery_mode.py`

## Candidate topic pool
The first priority pool includes:
- Microbiome → tryptophan/kynurenine → IL-6/TNF → depression phenotype
- Long COVID → interferon/PBMC transcriptome route
- Pesticide exposure → gut barrier/LPS → IL-6/TNF/CRP route
- Longevity/aging → immunosenescence/inflammaging route
- EBV → SLE → interferon/B-cell route
- PFAS/BPA/phthalate/microplastic → endocrine-immune inflammation route
- Hantavirus → endothelial/interferon/cytokine severity route

## Safety and claim boundary
Autonomous discovery is routing-only. It may select a research direction, generate public lookup queries, and create weak leads. It may not claim causality, mechanism proof, diagnosis, treatment, dose, or patient-level prediction.

## UI behavior
If the field is blank, the UI now shows:
- `User query captured: AUTO — search box was blank`
- the selected topic
- why it was selected
- required dots/gates
- the no-proof boundary

## Report behavior
The JSON/report now includes:
- `autonomousDiscoveryMode.active`
- `inputMode = BLANK_INPUT_AUTONOMOUS_DISCOVERY`
- selected topic/candidate ID
- selection score
- required dots
- blocked claims

## Integration points
- `ResearchAutopilotActivity` resolves blank input before starting the engine.
- `RuntimeCrashSafetyAndTopicGuardV2740` stores auto-topic capture state.
- `ResearchAutopilot` injects autonomous direct queries before generic search.
- `GlobalResearchGradeBriefV11061` renders AUTO mode visibly.
- `TopicRunIsolationPolicyV2742` and `TopicIsolationAndScoreGateV2741` remain active, so autonomous topics do not contaminate later user-topic runs.

## Validation
Static validation passed:
- Kotlin delimiter audit
- Kotlin string literal audit
- Kotlin regex/string escape safety audit
- JSON validation
- Release hygiene audit
- v2.7.4.1 topic isolation audit
- v2.7.4.2 topic run isolation audit
- v2.7.4.3 autonomous discovery audit

Gradle could not run in the offline container because the wrapper could not resolve `services.gradle.org`; GitHub Actions/Android Studio remains the full build gate.
