# Domain Expertise Continuity v1.10.20

v1.10.20 deepens the v1.10.19 domain-expertise layer. The goal is to stop the autonomous researcher from treating every failed search as a full reset.

## Rule

The system may carry domain knowledge forward as a **research prior** only. It may not convert a domain prior into biological proof, treatment guidance, dosage advice, drug ranking, or clinical recommendation.

## What persists

For every domain track that appears repeatedly, the report now preserves:

- prior exposure count
- continuity state
- mature domain count
- working vocabulary
- stable research priors
- protected-from-reset beliefs
- falsification gates
- continuity action

## Mature domain behavior

After repeated exposure, a domain becomes a mature research prior. Mature tracks should be deepened before the system jumps to a new domain, unless explicit falsification gates fail.

Example domains:

- antihistamines / histamine / mast-cell axis
- inflammatory disease / chronic inflammation
- drug perturbation / medication exposure
- aging / immunosenescence / inflammaging
- diabetes / metabolic inflammation
- gastric acid / reflux / gut barrier

## Claim lock

All continuity output remains `domain_expertise_memory_not_biological_proof`.

The system may say: this domain is worth deeper search.

It may not say: this domain proves a mechanism, treatment, causal relationship, or clinical value.

This is not biological proof.
