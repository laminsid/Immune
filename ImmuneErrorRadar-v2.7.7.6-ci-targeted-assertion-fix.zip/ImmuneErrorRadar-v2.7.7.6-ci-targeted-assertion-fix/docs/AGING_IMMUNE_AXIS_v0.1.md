# AGING IMMUNE AXIS v0.1

Purpose: model aging-related immune hypotheses without claiming diagnosis or anti-aging effect.

Axes:
- Immunosenescence tendency: age, frequent infections, slow recovery, slow wound/skin repair.
- Inflammaging load: CRP, IL-6, TNF-alpha, ferritin, sleep debt, fatigue after stress.
- Immune responsiveness preservation: Type-2/allergy reactivity, IgE, eosinophils, seasonality, recovery.
- Resilience index: sleep/recovery quality, exercise recovery, low inflammatory load.

Key rule: high allergy is not automatically good or bad. It can represent preserved responsiveness in one context, chronic immune irritation in another, or noise when data is incomplete.
