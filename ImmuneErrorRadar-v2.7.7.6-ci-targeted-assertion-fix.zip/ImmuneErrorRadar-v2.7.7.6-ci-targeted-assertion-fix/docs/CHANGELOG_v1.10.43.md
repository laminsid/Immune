# Changelog v1.10.43

Release: `1.10.43-alpha-modern-medtech-modular-index`  
VersionCode: `105`

## Added

- `ModernMedicalTechnologyIntelligenceV11043`
- `ModernMedicalTechnologyReport`
- `ModernTechnologyModuleCard`
- `modern_medical_technology_modules_v1.10.43.json`
- `biomedical_modular_index_v1.10.43.json`
- v1.10.43 static audits

## Changed

- Dataset foraging report now carries `modernMedicalTechnologyReport`.
- JSON export includes selected technology modules, partition index keys, retrieval policy, evidence keys, invalidators, and forbidden claims.
- UI and PDF/technical reports expose the modern technology routing layer.
- Release version updated to `1.10.43-alpha-modern-medtech-modular-index`.

## Guardrails

- No random context injection.
- No whole-ontology query expansion.
- No diagnosis or treatment logic.
- No therapeutic, lab-validation, clinical-utility, causal, or breakthrough claim from technology-module routing alone.
