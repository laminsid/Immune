# Final Downstream Execution Lock — v2.7.3.17

## Purpose
This patch closes the remaining topic-contamination path after input capture and first-stage topic isolation were fixed. The previous reports showed that the app could capture `Covid` or `Allergies`, but downstream layers could still surface pesticide/gut/PFAS/heavy-metal/stress-prior templates.

## Added
- `DownstreamTopicContractV2746`: one current-run topic contract for downstream execution.
- Contract-filtered repository queries, query seeds, and displayed seed handles.
- No generic seed bootstrap fallback when no current-topic match exists.
- Brief rendering uses a locked relationship corpus and filters incompatible materialized seeds.
- Benchmark query uses topic-safe fallback if topQuery is incompatible.

## Protected cases
- Covid must stay on COVID/SARS-CoV-2/interferon/PBMC route unless the user explicitly asks another bridge.
- Allergies must stay on IgE/mast-cell/eosinophil/type-2 route.
- Blank autonomous microbiome-depression discovery remains allowed and still opens the microbiome-depression bridge.
- Pesticide/PFAS/heavy-metal routes open only when the current topic asks for them.
- Known stress/HPA prior seeds no longer leak into unrelated topics.

## Safety boundary
This patch only changes routing, query selection, seed visibility and score/report hygiene. It does not claim causality, diagnosis, treatment, patient-level prediction, or evidence upgrade.
