# Backlog v2 — ML Ideas Deferred Until Dataset Readiness

The following ideas are intentionally deferred:

- Random Forest baseline
- Permutation importance
- Contrastive prototype learning
- Graph neural networks / PyTorch Geometric
- Novelty detection models
- Micro-inference export models

## Why deferred

They require curated datasets with enough samples, stable feature dictionaries, outcome labels, and cross-condition comparators. Running ML before dataset readiness would create artificial precision and noise.

## Unlock conditions

ML can be reconsidered only when:

1. At least 20 curated public datasets are registered.
2. At least 5 human datasets include outcome/response labels.
3. Marker/gene normalization is stable.
4. At least 3 global hypotheses have dataset-backed evidence score >= 7/10.
5. Negative-control and contradiction logic is stable.
