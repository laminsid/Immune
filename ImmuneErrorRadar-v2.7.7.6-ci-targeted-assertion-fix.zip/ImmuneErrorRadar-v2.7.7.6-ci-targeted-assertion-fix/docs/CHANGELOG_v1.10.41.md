# v1.10.41-alpha-biomedical-research-ontology

VersionCode: `103`  
Schema: `1.10.41`

## Added

- `BiomedicalResearchOntologyV11041`
- `BiomedicalResearchOntologyReport`
- `biomedical_research_ontology_v1.10.41.json` asset
- Scientist/lab-facing diagnostic phenotype vocabulary mode
- Organ, blood, pathogen, disease, genetics/cell/chromosome/mitochondria, medication, herb, food, vitamin, and nutrition research terms
- UI/exporter visibility for Biomedical Research Ontology v1.10.41
- Static audits for ontology presence, release linkage, and claim-boundary wording

## Boundary

The ontology supports research linking, accession lookup, metadata parsing, route classification, and contradiction/control search. It does not output patient diagnosis, treatment recommendation, dose recommendation, drug ranking, or supplement advice.

## GitHub / Google Console

No new Android permissions, services, remote tracking, or Play-sensitive declarations were added.
