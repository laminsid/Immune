# v2.7.3.16 — Downstream Contamination Closure

## Purpose
Close the remaining downstream contamination that survived topic capture and topic isolation.

## Changes
- Removed default Known Prior seed fallback for unrelated topics.
- Removed default all-handle fallback from Known Prior handle extraction.
- Replaced broad token matching with axis-specific Known Prior matching.
- Prevented Exposome bridge activation from generic `gut`, `microbiome`, `water`, or `research lead` text.
- Removed bare `lead` as a heavy-metal trigger; only explicit contexts such as `lead exposure`, `blood lead`, or `lead poisoning` remain valid.
- Added topic-profile compatibility gating in `GTIMTopicSpecificRouteBuilderV270`.
- Required strong exposure terms before opening exposome/toxicant topic routes.
- Added adjusted Data-feed score capping in `TopicIsolationAndScoreGateV2741`.
- Updated `GlobalResearchGradeBriefV11061` to show the adjusted Data-feed score rather than the raw data-feed score.
- Reordered `GTIMDataFeedPlannerV255.bestNextAction` so current topic / relationship routes are preferred before older comparative or Known Prior routes.
- Registered v2.7.4.5 downstream contamination audit in the fast static gate.

## Expected effect
- Covid should not display pesticide/gut or toxicant routes unless the user explicitly asks for exposure/toxicant context.
- Allergies should stay on IgE / mast-cell / eosinophil / type-2 route.
- Blank autonomous discovery can still open microbiome/depression routes when selected, but this does not pollute the next user-triggered search.
- Repeated old PMID/DOI/GSE seed packs should not appear unless the current topic actually matches those priors.
- Scores should be lower when the result is lookup-only, lacks matrix/accession, or misses comparator/assay/cell fields.

## Claim boundary
This patch improves routing hygiene and reporting honesty. It does not upgrade any biomedical route into proof, causality, diagnosis, treatment, or patient-level prediction.
