# Changelog v1.10.44

- versionCode=106
- versionName=1.10.44-alpha-viral-countermeasure-knowledge-graph
- Added `ViralCountermeasureIntelligenceV11044`.
- Added `BiomedicalKnowledgeGraphLinkerV11044`.
- Added Hantavirus, SARS-CoV-2, EBV and CMV research profiles.
- Added antigen target priors, strain scope and countermeasure platform cards.
- Added lazy biomedical dictionary/database linkage and update policy.
- Connected JSON, UI summary, PDF/technical export, runtime registry and release guards.
- Maintains no diagnosis, no treatment recommendation, no wet-lab protocol, no viral-engineering instruction, and no efficacy claim boundaries.
