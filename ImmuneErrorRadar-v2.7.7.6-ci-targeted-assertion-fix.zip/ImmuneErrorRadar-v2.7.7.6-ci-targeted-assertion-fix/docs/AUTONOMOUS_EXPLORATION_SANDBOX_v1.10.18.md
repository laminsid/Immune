# Autonomous Exploration Sandbox v1.10.18

## Purpose

v1.10.17 prevented fast archive/reframe after one source-family attempt, but the research question could still remain too narrow: finding a single open dataset that combines neuroimmunology, time, multiple immune axes, outcomes, controls, and accession metadata is unlikely.

v1.10.18 adds a controlled exploration sandbox.

## Operating rule

Freedom in exploration. Strictness in claims.

The engine may broaden retrieval into adjacent domains and near-miss candidates, but it may not upgrade a claim without accession, metadata, outcome labels, controls/comparators, and time-order gates.

## Newly allowed exploration domains

- drug perturbation / medication exposure research metadata
- aging / immunosenescence / inflammaging
- diabetes / metabolic inflammation
- gastric-acid/reflux/gut-barrier context

## Safety lock

Drug terms are search context only. They do not permit treatment advice, dosage, drug ranking, clinical recommendation, or drug selection. Adjacent-domain results are research leads only.

## New route family

`PUBMED_ADJACENT_DOMAIN_MINING`

This route sits after accession mining and before contradiction/control. It can discover nearby public dataset leads when the exact question is too constrained.

## Near-miss handling

The resolver may retain weak leads as:

- `NEAR_MISS_DATASET_CANDIDATE`
- `PARTIAL_AXIS_MATCH_NEEDS_ACCESSION`
- `ACCESSION_FOUND_METADATA_WEAK`
- `EXPLORATORY_LEAD_NEEDS_ACCESSION`

These statuses prevent premature discard while preserving the evidence lock.
