# Immune Error Radar v1.3.8 — Execution Wiring + Active Learning Loop

## Problem fixed

Previous reports could say “No useful delta — strategy pivoted” while the app still restarted from a similar low-data PubMed path. This produced honest reports but weak learning.

## New rule

A pivot is not enough. The engine must prove execution.

```text
pivot declared → forced evidence path generated → forced query executed → execution lock PASS
```

## Hard stagnation condition

The app now treats this as an execution failure:

```text
new findings = 0
repeated skipped >= 10
dataset candidates = 0
```

When this happens during the same cycle, it immediately executes a runtime DATASET_HUNT path.

## Runtime DATASET_HUNT

Forced query families include:

- dataset/accession search: GEO/GSE/SDY/ImmPort/PRJNA/SRP/SRA/RNA-seq/single-cell
- condition/outcome label search
- contradiction / negative control / longitudinal outcome search

## Report fields

Every report now includes:

- `runtimeStatus.engineVersion`
- `runtimeStatus.activeModules`
- `runtimeStatus.researchState`
- `runtimeStatus.effectiveMaxQueries`
- `runtimeStatus.effectiveResultsPerQuery`
- `runtimeStatus.runtimeFailoverApplied`
- `runtimeStatus.forcedQueries`
- `runtimeStatus.executedQueryIds`
- `executionLockReport.status`
- `executionLockReport.failures`
- `executionLockReport.enforcedActions`

## Pass/fail logic

Execution lock fails if:

- active engine version is not v1.3.8
- required modules are not active
- a forced pivot exists but no forced queries were generated
- a forced pivot exists but no forced query was executed
- hard stagnation was observed but no incident/gate/regression/cooldown was created

## Boundary

This patch does not add new biological axes, diseases, diagnosis, treatment, prediction, Random Forest, or ML.
