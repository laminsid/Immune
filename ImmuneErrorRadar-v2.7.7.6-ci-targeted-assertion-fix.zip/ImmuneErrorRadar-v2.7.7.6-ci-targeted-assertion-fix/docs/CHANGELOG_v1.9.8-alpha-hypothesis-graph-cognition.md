# Immune Error Radar v1.9.8-alpha-hypothesis-graph-cognition

## Goal
Turn post-search cognition into a durable hypothesis map, not just another report section.

## Added
- `HypothesisGraphCognition.kt`
  - Builds graph nodes for accessions, hypotheses, evidence gaps, and objections.
  - Builds edges such as `ROUTE_SUPPORTS_ONLY_IF_CLOSED`, `GAP_BLOCKS_UPGRADE`, and `OBJECTION_CHALLENGES`.
  - Emits a `HypothesisGraphReport` with dominant hypothesis, weakest link, kill switch, next reasoning move, and search decision.
- `hypothesisGraphReport` in `ResearchCycleReport` and JSON export.
- UI summary lines in the decision card, learning receipt, and thinking board.
- PDF export section for graph nodes and edges.
- Knowledge ledger entry `hypothesis_graph_v198`.

## Decision behavior
- If evidence closure blocks broad search, the graph state becomes `GRAPH_CLOSE_BEFORE_SEARCH`.
- If repeated gaps pile up, the graph state becomes `GRAPH_REVISE_OR_ARCHIVE_PRESSURE`.
- If the quality gate allows execution, only a narrow test is authorized.
- Broad search remains blocked unless the graph has an explicit falsifiable node and gap closure condition.

## Claim boundary
The graph is a local reasoning and routing structure only. It does not prove biology, diagnosis, treatment value, or causality.
