# Accession Mining Intensity v1.10.23

## Purpose

v1.10.22 correctly blocked archive/reframe until `PUBMED_ACCESSION_MINING` is attempted, but PubMed accession mining still used the same thin retrieval window as contradiction/control. v1.10.23 gives accession-mining a deeper bounded window because dataset accessions often appear in abstracts, availability statements, or supplementary-data language rather than titles.

## Rules

- `PUBMED_ACCESSION_MINING`: retMax 25, abstract budget 5.
- `PUBMED_ADJACENT_DOMAIN_MINING`: retMax 15, abstract budget 2.
- `PUBMED_CONTRADICTION` and `PUBMED_CONTROL`: remain narrow at retMax 10, abstract budget 1.

## Claim boundary

This changes retrieval depth only. It is `accession_mining_intensity_not_biological_proof` and never proves biology, treatment value, causality, dosage, or drug ranking.

This layer provides no biological proof.
