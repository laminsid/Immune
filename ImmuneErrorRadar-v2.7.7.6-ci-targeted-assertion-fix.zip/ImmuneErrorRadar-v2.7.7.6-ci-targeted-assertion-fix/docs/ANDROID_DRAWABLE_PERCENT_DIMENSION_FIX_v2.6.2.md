# Android Drawable Percent Dimension Fix — v2.6.2

Fixes AAPT resource-linking failures caused by percent values in layer-list item inset/dimension attributes.

Affected drawables:
- `advanced_panel.xml`
- `hero_panel.xml`
- `result_amber.xml`
- `result_green.xml`
- `result_red.xml`

Android resource linking expects dimension values such as `dp` for `android:left/right/top/bottom/width/height`; percentage strings such as `93%` are invalid. The affected resources now use fixed `dp` item width/height and gravity for accent/highlight layers.

Regression guard:
- `scripts/audit_android_drawable_dimension_percent_guard_v262.py`
