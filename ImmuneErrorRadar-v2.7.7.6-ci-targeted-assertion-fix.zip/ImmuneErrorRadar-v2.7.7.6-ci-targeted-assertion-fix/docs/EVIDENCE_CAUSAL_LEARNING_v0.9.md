# Evidence & Causal Learning Engine v0.9

## Goal

Prevent the app from believing attractive but weak connections.

The engine now ranks findings by:

- source quality,
- human/animal/cell separation,
- study design,
- biological plausibility,
- measurable markers,
- repeatability,
- negative-control need,
- contradiction prompts.

## Core rule

A new source can increase curiosity, but only repeated, measurable, temporally ordered evidence can increase confidence.

## Kotlin modules

- `SourceClassifier.kt`
- `BiologicalPlausibilityGraph.kt`
- `CausalityScorer.kt`
- `NegativeControlEngine.kt`
- `PersonalPatternLedger.kt`
- `ContradictionFinder.kt`
- `HypothesisRankingEngine.kt`

## Python support

- `research/evidence_quality.py`
- `research/causality_scorer.py`
- `research/negative_controls.py`
- `research/personal_time_series.py`
- `research/hypothesis_ranker.py`

## Interpretation boundary

Scores are not proof. They are prioritization tools for what to inspect, measure, and falsify next.
