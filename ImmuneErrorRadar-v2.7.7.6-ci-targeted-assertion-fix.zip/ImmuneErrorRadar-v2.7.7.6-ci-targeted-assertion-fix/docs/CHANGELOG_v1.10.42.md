# v1.10.42-alpha-biomedical-concept-bridge

Schema: `1.10.42`
VersionCode: `104`

## Added

- `BiomedicalConceptBridgeV11042`
- `BiomedicalConceptBridgeReport`
- `BiomedicalBridgeCard`
- UI/exporter visibility for Biomedical Concept Bridge v1.10.42
- JSON export for `biomedicalConceptBridgeReport`
- Runtime module registration for `BiomedicalConceptBridge`, `OntologyBridgeGraph`, and `ConceptBridgeNoiseGuard`

## Behavior

The engine now turns biomedical ontology hits into explicit bridge cards with lookup terms, evidence keys, invalidators, and forbidden claims.

The bridge is a scientist/lab research router only. It does not diagnose, recommend treatment, rank drugs, suggest supplements, or confirm causality.
