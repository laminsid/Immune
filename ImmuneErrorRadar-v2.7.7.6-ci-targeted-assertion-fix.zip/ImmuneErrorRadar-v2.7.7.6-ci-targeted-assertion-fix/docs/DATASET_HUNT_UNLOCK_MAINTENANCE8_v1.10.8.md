# v1.10.8 Dataset Hunt Unlock — Maintenance 8

## Purpose

This pass hardens the evidence-acquisition path after the v1.10.8 unlock. The previous fixes made `DATASET_HUNT` executable again; this pass reduces the risk that an active forager still behaves like a generic PubMed replay.

## Changes

- Added source-aware dataset query compilation in `DatasetQueryCompiler.compileForRoute`.
- GEO/GDS routes now receive GEO/GSE/GDS-oriented accession and phenotype/outcome terms.
- SRA routes now receive PRJNA/SRP/SRA/BioProject/RNA-seq-oriented terms.
- PubMed contradiction/control routes now receive contradiction/control-specific terms instead of generic dataset terms.
- `ResearchAutopilot.runDatasetFirstForaging` now uses `compileForRoute(route, shards, memory)` per source route.
- `ResearchAutopilot` now includes the prior directive mode/reason in the router text so `EVIDENCE_FIRST_ACCESSION_SEARCH` cannot be lost when the research state text is sparse.

## Invariant

- No hypothesis upgrade is allowed from this patch.
- No causal or clinical language is enabled.
- Existing evidence/closure locks still win when a candidate/accession already exists.
- The patch only improves how the system tries to acquire dataset/accession evidence.

## Regression Coverage

- GEO/GDS and SRA source-aware query compilation.
- PubMed contradiction/control query compilation.
- Audit coverage for `compileForRoute`, source-aware query families, and Autopilot wiring.

## Expected Runtime Effect

A future no-evidence `DATASET_HUNT` report should show direct source attempts with route-appropriate queries instead of repeating a single generic search string across all source families.
