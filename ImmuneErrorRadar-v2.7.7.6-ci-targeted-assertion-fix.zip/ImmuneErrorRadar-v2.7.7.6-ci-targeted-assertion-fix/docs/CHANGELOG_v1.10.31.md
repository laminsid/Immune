# Changelog — v1.10.31

Release: `1.10.31-alpha-evidence-lead-and-manual-seed`

## Added

- Added `EvidenceLeadAndManualSeedPolicy`.
- Added `MANUAL_EVIDENCE_SEED_MODE` for manual/imported PMID, DOI, accession, PDF, and snippet seeds.
- Added weak lead preservation state `WEAK_DATASET_LEAD_FOUND`.
- Added near-miss state `NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION`.
- Added secondary lookup state `ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP`.
- Added terminal no-public-dataset state `NO_PUBLIC_DATASET_AFTER_FULL_SWEEP`.
- Added `DatasetLeadRelaxationReport` and `LEAD_ONLY_NOT_EVIDENCE` handling.
- Added one-page executive evidence decision report.
- Added activity/evidence separation report.
- Added post-PubMed search strategy output.
- Added `ReportConsistencyGuard.preventArchiveProbeConflict`.
- Added `EvidenceLeadPathLinkageReport` to verify manual seed → forager attempt → relaxation → breakthrough → final decision linkage.
- Added manual seed trigger wiring so explicit manual seed input can force dataset-first routing instead of waiting for the router.
- Added manual seed attempt recording through `MANUAL_EVIDENCE_SEED_MODE` inside `DatasetSourceAttempt`.
- Added regression tests in `EvidenceLeadManualSeedV11031Test`.
- Added fast/full static check split and GitHub workflow selection: PR = fast, push/manual = full.

## Updated

- `versionCode`: `93`
- `versionName`: `1.10.31-alpha-evidence-lead-and-manual-seed`
- `ACTIVE_ENGINE_VERSION`: `v1.10.31-alpha-evidence-lead-and-manual-seed`
- `LEARNING_SESSION_SCHEMA_VERSION`: `1.10.31`
- `ReleaseVersionLinkageGuard` remains mandatory.

## Claim boundary

All new outputs are bounded by `lead_only_not_evidence`. Weak leads change routing and preservation only; they never upgrade a hypothesis.
