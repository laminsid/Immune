# v1.10.3-alpha-search-directive-spine

## Purpose

This release closes a wiring gap left after runtime/network hardening. Evidence Closure, Cognitive Momentum, and Linked Cognition Spine already produced prior-cycle locks, but the pre-search path still evaluated them in scattered conditionals. v1.10.3 adds one resolver that decides who owns the next cycle before any network budget is spent.

## Added

- `ResearchSearchDirectiveResolver.kt`
  - priority order: Linked Cognition Spine → Evidence Closure → Cognitive Momentum → normal planner
  - output: `ResearchSearchDirective`
  - supports `OFFLINE_THINK_ONLY`, narrow search, same-cycle accession closure, and normal broad planner handoff
- `ResearchSearchDirectiveResolverTest.kt`
  - verifies linked spine overrides closure/momentum
  - verifies closure overrides momentum
  - verifies no lock leaves normal planner in control
- `scripts/audit_search_directive_spine_v1103.py`
  - prevents regression to scattered prior-lock conditions
  - checks version/schema consistency

## Changed

- `ResearchAutopilot.runCycle` now uses:
  - `priorSearchDirectiveV203` before dataset-first planning
  - `postForagerDirectiveV203` after dataset foraging
- Dataset-first and runtime failover are blocked by a single `priorUnifiedSearchLockV203` instead of several partially overlapping booleans.
- Learning notes now expose the governing search directive, max query budget, max result budget, and decision trace.

## Why it matters

The app no longer depends on the Search button or scattered booleans to decide whether broad search is allowed. A prior unresolved evidence gap now constrains the next cycle through one decision spine.

## Claim boundary

This is operational routing only. It does not prove biology, clinical value, diagnosis, treatment, or mechanism.
