# Dataset Hunt Unlock Maintenance 9 — v1.10.8

## Purpose
Close the remaining practical weakness in the evidence-first dataset hunt path: direct NCBI dataset results must become concrete accession candidates, not bare numeric UIDs or unresolved metadata-only leads.

## Fixes
- Expanded `DatasetAccessionResolver` to recognize SRA/EGA run-level accessions: `SRR`, `ERR`, and `DRR`.
- Added normalized direct-NCBI accession extraction inside `ResearchAutopilot`:
  - prefers explicit fields such as `accession`, `acc`, `geo_accession`, `bioproject`, `study_acc`, `exp_acc`, `run_acc`;
  - falls back to `GDS<uid>` for numeric GDS records;
  - avoids treating a bare numeric UID as the final accession when a better accession-like identifier is available.
- Added resolver regression tests for SRA run accessions and GEO/GDS accessions.
- Extended the v1.10.8 audit so this extraction support cannot silently regress.

## Product invariant
Dataset hunt may fail to find usable datasets, but it should not fail because it discarded or under-normalized accession identifiers that NCBI already returned.
