# Causal Origin Engine v0.1

Purpose: map candidate origins of symptoms/signals without asserting final causality.

## Driver families

- allergen/environment
- psychological stress/amplification
- sleep/recovery debt
- infection trigger
- mechanical/disc load
- neuromuscular guarding / pain amplification
- mixed/unknown

## Evidence ladder

1. Temporal evidence: did the factor occur before/around symptoms?
2. Biological plausibility: is there a plausible pathway?
3. Repeatability: does the same pattern repeat across entries?
4. Alternative explanations: infection, structural load, medication, allergy, autoimmune, etc.

## Guardrail

Stress is never treated as automatic root cause. It is only a trigger/amplifier/maintainer candidate unless repeated evidence supports stronger weighting.
