# Accession Exhaustion + Domain Query Activation v1.10.22

This patch fixes a decision contradiction observed after v1.10.21: the report could say PUBMED_ACCESSION_MINING was the next source while also recommending archive/reframe.

## Rules

- Do not allow terminal archive/reframe while any core accession source remains untried: GEO_GDS, SRA_PRJNA, IMM_PORT_SDY, PUBMED_ACCESSION_MINING.
- Keep source-priority arbitration accession-first during DATASET_HUNT/NO_ACCESSION.
- Activate domain expertise by injecting safe domain vocabulary into accession/adjacent-domain queries, not into every GEO/SRA/ImmPort query.
- Count domain exposure when a query actually contains domain terms. Domain expertise remains a research prior only.

## Claim lock

No diagnosis, treatment, dose, drug ranking, clinical recommendation, causal upgrade, or biological proof is created by this layer.
