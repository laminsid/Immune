# v1.10.4-alpha-cycle-phase-audit

This release closes the remaining runtime-lock wiring gap after v1.10.3.

## Why

v1.10.3 unified prior search locks, but same-cycle evidence closure could still be followed by runtime failover because failover only checked the prior lock. That meant a dataset candidate could demand narrow accession closure while a hard-stagnation branch reopened network spend in the same cycle.

## Changes

- Added `ResearchCyclePhaseAuditEngine`.
- Added `cyclePhaseAuditReport` to `ResearchCycleReport` JSON.
- Added `unifiedSearchLockAfterForagerV204` in `ResearchAutopilot`.
- Runtime failover is now blocked when the post-forager directive is active or blocks dataset-first.
- The report records Plan, Dataset Foraging, Search, Runtime Failover, Reason, and Persist phase ownership.
- The audit reports lock violations such as `RUNTIME_FAILOVER_RAN_DESPITE_ACTIVE_SEARCH_LOCK`.
- Added regression tests in `ResearchCyclePhaseAuditTest`.
- Added `scripts/audit_cycle_phase_v1104.py`.

## Claim boundary

This layer does not interpret biology. It verifies execution wiring and network-budget governance only.
