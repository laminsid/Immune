# Changelog v1.10.35

Release identity: `1.10.35-alpha-lead-closure-learning-rules`

- Updated release identity to `versionCode=97`, `versionName=1.10.35-alpha-lead-closure-learning-rules`, `ACTIVE_ENGINE_VERSION=v1.10.35-alpha-lead-closure-learning-rules`, and `LEARNING_SESSION_SCHEMA_VERSION=1.10.35`.
- Added `LeadClosureHandoffPolicy` to preserve weak/off-route leads across cycles.
- Added a lightweight `MetadataClosureAgent` path that tracks accession, human/patient context, sample size, condition labels, outcome labels, comparator/control, time order, tissue/cell context, license/access, and data-availability text.
- Added an `UnknownRouteClassifier` that classifies off-route leads into route priors only; EBV/HHV-6/CMV are retained only as latent-virus route priors, not evidence.
- Repaired mature-domain/lead handoff linkage so weak accession and metadata-closure states can satisfy the handoff instead of leaving path-linkage warnings unresolved.
- Improved the compact UI summary and learning report to show learned details and pinned rules.
- Added test coverage for handoff preservation, metadata closure, latent-virus prior safety, and path-linkage acceptance.

No diagnosis, treatment recommendation, drug ranking, causal claim, or biological proof is created by this release.
