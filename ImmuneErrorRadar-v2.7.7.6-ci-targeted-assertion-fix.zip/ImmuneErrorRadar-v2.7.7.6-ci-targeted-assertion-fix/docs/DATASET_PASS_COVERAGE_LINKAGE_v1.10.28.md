# v1.10.28 — Dataset Pass Coverage Linkage

This patch tightens the wiring introduced by v1.10.27. The previous linkage guard verified the final dataset-foraging state and mature-domain handoff, but pass summaries could still mix core PubMed accession mining with adjacent/contradiction/control checks.

## Change

- `PASS1_DATASET_ACCESSION_HUNT` now covers all core accession-capable source families, including `PUBMED_ACCESSION_MINING`.
- `PASS3_ADJACENT_CONTRADICTION_CONTROL_CHECK` is limited to adjacent-domain, contradiction, and control PubMed paths.
- `PASS4_MATURE_DOMAIN_EVIDENCE_PROBE` remains isolated for mature-domain probing.
- `DatasetForagingPathLinkageReport` now exposes `coreQueryPathCount`, `adjacentQueryPathCount`, `matureProbeQueryPathCount`, and `coverageState`.

## Claim boundary

This is a wiring and report-integrity patch only. It is `dataset_path_linkage_not_biological_proof` and cannot diagnose, treat, rank drugs, set dosage, or prove biology.
