package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AutonomousResilienceV133Test {
    @Test
    fun `no useful result creates pivot decision`() {
        val pivot = NoResultRecoveryEngine.decide(
            FailureSignature(
                newUsefulSources = 0,
                repeatedSkipped = 30,
                metadataOnlyRatio = 0.0,
                sameLaneFailureCount = 2,
                abstractFetchFailures = 0,
                datasetCandidateCount = 0,
                hypothesisDeltaCount = 0,
                failedLane = "EXPLORE"
            )
        )
        assertTrue(pivot.pivotType != "NO_PIVOT")
        assertTrue(pivot.nextIntent.isNotBlank())
    }

    @Test
    fun `metadata heavy cycle selects top abstracts pivot`() {
        val pivot = NoResultRecoveryEngine.decide(
            FailureSignature(
                newUsefulSources = 3,
                repeatedSkipped = 0,
                metadataOnlyRatio = 0.8,
                sameLaneFailureCount = 0,
                abstractFetchFailures = 3,
                datasetCandidateCount = 0,
                hypothesisDeltaCount = 0,
                failedLane = "MECHANISM"
            )
        )
        assertEquals("METADATA_TO_TOP_ABSTRACTS", pivot.pivotType)
    }

    @Test
    fun `query evolution moves dataset pivot to dataset stage`() {
        val state = AdaptiveQueryEvolution.evolve(
            seed = "interferon timing",
            pivot = PivotDecision("MECHANISM_TO_DATASET", "stalled", "dataset_hunting", "GSE GEO RNA-seq outcome", 80),
            activeAxes = listOf("interferon_antiviral_axis")
        )
        assertEquals("DATASET", state.nextStage)
        assertTrue(state.evolvedQuery.contains("GSE"))
    }

    @Test
    fun `dataset extractor recognizes geo accession and outcome hints`() {
        val candidates = DatasetCandidateExtractor.extract(
            "Human longitudinal RNA-seq cohort GSE157103 with severity outcome labels and n=126 patients",
            sourceTitle = "GSE viral severity dataset"
        )
        assertTrue(candidates.isNotEmpty())
        assertEquals("GSE157103", candidates.first().datasetId)
        assertTrue(candidates.first().priorityScore >= 60)
    }

    @Test
    fun `report v3 explains next move after pivot`() {
        val report = ResearchReportV3Builder.build(
            findings = emptyList(),
            hypothesisObjects = emptyList(),
            learningDeltas = emptyList(),
            datasetCandidates = emptyList(),
            pivot = PivotDecision("GENERAL_TO_CONTRADICTION", "no result", "contradiction_search", "conflicting results", 70),
            repeatedSkipped = 20,
            global = GlobalImmuneIntelligenceReport(
                mode = "global_dataset_intelligence",
                datasetCandidates = emptyList(),
                axisMap = emptyList(),
                triggerResponseEdges = emptyList(),
                globalHypotheses = emptyList(),
                antiviralResponseNotes = emptyList(),
                nextGlobalDatasetNeeded = "",
                globalDiscoveryAction = "",
                globalBiasAlarm = ""
            )
        )
        assertEquals("No useful delta — strategy pivoted", report.cycleResult)
        assertTrue(report.nextAutonomousMove.contains("contradiction_search"))
    }
}
