package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartReportIntegrityLockV135Test {
    @Test
    fun `report without four accountability fields is rejected as narrative polish`() {
        val report = ResearchReportV3(
            cycleResult = "Useful delta",
            newUsefulLead = "Promising title",
            hypothesisChanged = "None",
            whyItMatters = "Looks biologically relevant",
            nextAutonomousMove = "Continue",
            doNotBelieveYet = "No proof",
            technicalPointer = "details",
            hypothesis = "",
            supportingEvidence = "",
            counterEvidenceOrContradiction = "",
            whatWeDoNotBelieveYet = ""
        )

        val result = SmartReportIntegrityLock.validate(report)

        assertFalse(result.passed)
        assertTrue(result.failures.any { it.contains("hypothesis", ignoreCase = true) })
        assertTrue(result.failures.any { it.contains("supporting", ignoreCase = true) })
        assertTrue(result.failures.any { it.contains("counter", ignoreCase = true) })
    }

    @Test
    fun `report builder always emits hypothesis support contradiction and unknowns`() {
        val report = ResearchReportV3Builder.build(
            findings = emptyList(),
            hypothesisObjects = emptyList(),
            learningDeltas = emptyList(),
            datasetCandidates = emptyList(),
            pivot = PivotDecision("GENERAL_TO_CONTRADICTION", "no useful result", "contradiction_search", "conflicting results", 70),
            repeatedSkipped = 20,
            global = GlobalImmuneIntelligenceReport(
                mode = "test",
                datasetCandidates = emptyList(),
                axisMap = emptyList(),
                triggerResponseEdges = emptyList(),
                globalHypotheses = emptyList(),
                antiviralResponseNotes = emptyList(),
                nextGlobalDatasetNeeded = "",
                globalDiscoveryAction = "",
                globalBiasAlarm = ""
            )
        )

        assertEquals("PASS", report.integrityStatus)
        assertTrue(report.hypothesis.isNotBlank())
        assertTrue(report.supportingEvidence.isNotBlank())
        assertTrue(report.counterEvidenceOrContradiction.isNotBlank())
        assertTrue(report.whatWeDoNotBelieveYet.isNotBlank())
        assertTrue(report.whatWeDoNotBelieveYet.contains("Do not", ignoreCase = true))
    }

    @Test
    fun `scope lock rejects biological expansion and ml drift`() {
        val result = ScopeDisciplineLock.validatePlannedText(
            "Add new immune axis with random forest patient prediction"
        )

        assertFalse(result.passed)
        assertTrue(result.violations.any { it.contains("new immune axis") })
        assertTrue(result.violations.any { it.contains("random forest") })
    }

    @Test
    fun `repeated source recovery rotates evidence lane without new axis wording`() {
        val pivot = NoResultRecoveryEngine.decide(
            FailureSignature(
                newUsefulSources = 0,
                repeatedSkipped = 25,
                metadataOnlyRatio = 0.0,
                sameLaneFailureCount = 2,
                abstractFetchFailures = 0,
                datasetCandidateCount = 0,
                hypothesisDeltaCount = 0,
                failedLane = "EXPLORE"
            )
        )

        assertEquals("REPEAT_TO_EVIDENCE_LANE_ROTATION", pivot.pivotType)
        assertEquals("evidence_lane_rotation", pivot.nextIntent)
        assertFalse(pivot.reason.contains("new axis", ignoreCase = true))
        assertFalse(pivot.nextIntent.contains("new_axis", ignoreCase = true))
    }
}
