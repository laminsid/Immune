package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ImmuneTopicPromptPolicyV11033Test {
    @Test
    fun airplaneTopicIsProjectedIntoImmuneLensNotGeneralEngineering() {
        val topic = "محركات الطائرات وتأثير السفر الطويل"
        val focus = ImmuneTopicPromptPolicy.focusQuestion(topic)
        val note = ImmuneTopicPromptPolicy.importedLearningNote(topic)
        assertTrue(focus.contains("immune-system lens"))
        assertTrue(focus.contains("If the topic has no usable immune angle"))
        assertTrue(note.contains("Do not produce general-domain advice"))
        assertFalse(note.contains("repair turbine"))
    }

    @Test
    fun promptProducesSearchVariablesAndClaimLimit() {
        val variables = ImmuneTopicPromptPolicy.variablesText("sleep and allergy")
        assertTrue(variables.contains("sleep and allergy"))
        assertTrue(variables.contains("immune response"))
        assertTrue(variables.contains("outcome labels"))
        assertTrue(ImmuneTopicPromptPolicy.importedLearningNote("sleep").contains(ImmuneTopicPromptPolicy.CLAIM_LIMIT))
    }

    @Test
    fun normalizesWhitespaceWithoutUnsupportedRegexEscapes() {
        val clean = ImmuneTopicPromptPolicy.normalizeTopic("sleep\n\t allergy   stress")
        assertTrue(clean.contains("sleep allergy stress"))
        assertFalse(clean.contains("\n"))
    }

}
