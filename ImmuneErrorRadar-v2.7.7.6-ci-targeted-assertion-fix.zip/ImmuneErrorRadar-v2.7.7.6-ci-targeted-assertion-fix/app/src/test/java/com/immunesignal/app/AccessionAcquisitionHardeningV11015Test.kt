package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AccessionAcquisitionHardeningV11015Test {
    @Test
    fun extractsExpandedAccessionFamiliesWithoutBiologicalUpgrade() {
        val candidates = DatasetAccessionResolver.extract(
            text = "ArrayExpress E-MTAB-1234 BioProject PRJEB999 SRA SRX888 SAMN777 human RNA-seq outcome severity recovery longitudinal control metadata",
            sourceFindingId = "manual:v11015-expanded",
            sourceTitle = "expanded accession grammar"
        )
        val accessions = candidates.map { it.accession }.toSet()

        assertTrue(accessions.contains("E-MTAB-1234"))
        assertTrue(accessions.contains("PRJEB999"))
        assertTrue(accessions.contains("SRX888"))
        assertTrue(accessions.contains("SAMN777"))
        assertTrue(candidates.all { it.status == "FOUND_ACCESSION" || it.status == "FOUND_WEAK_ACCESSION_NEEDS_METADATA" })
    }

    @Test
    fun reportsFoundAccessionBeforeHypothesisUpgrade() {
        val candidate = DatasetAccessionResolver.extract(
            text = "GSE123456 human immune response outcome severity recovery longitudinal control RNA-seq metadata",
            sourceFindingId = "manual:v11015-found",
            sourceTitle = "explicit accession"
        ).first { it.accession == "GSE123456" }

        val report = AccessionAcquisitionHardening.evaluate(
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            attempts = emptyList(),
            noCandidateLearningRecords = emptyList()
        )

        assertEquals("FOUND_ACCESSION", report.state)
        assertTrue(report.explicitAccessions.contains("GSE123456"))
        assertFalse(report.archiveRecommended)
        assertTrue(report.nextAction.contains("Parse minimum metadata"))
    }

    @Test
    fun unresolvedLeadStaysWeakAndCompact() {
        val candidate = DatasetAccessionResolver.extract(
            text = "human cohort immune transcriptomic outcome severity recovery longitudinal control metadata public data no visible accession",
            sourceFindingId = "manual:v11015-weak",
            sourceTitle = "unresolved metadata lead"
        ).first()

        val report = AccessionAcquisitionHardening.evaluate(
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            attempts = emptyList(),
            noCandidateLearningRecords = emptyList()
        )

        assertEquals("FOUND_WEAK_ACCESSION_NEEDS_METADATA", report.state)
        assertTrue(report.compactReportRecommended)
        assertTrue(report.nextAction.contains("Do not upgrade biology"))
    }

    @Test
    fun repeatedNoAccessionCanArchiveRouteAfterMinimumSourceSweep() {
        val memory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord(
                    failedQueryHash = "h",
                    sourceFamily = "GEO_GDS",
                    rootCause = "NO_DATASET_ACCESSION+BROAD_QUERY",
                    cooldownCyclesRemaining = 5,
                    lastAttemptedAtMillis = 1L,
                    timesFailed = 3,
                    forcedNextSource = "SRA_PRJNA"
                )
            ),
            summary = "repeated no accession"
        )
        val report = AccessionAcquisitionHardening.evaluate(
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            attempts = listOf(
                DatasetSourceAttempt("GEO_GDS", "gds", "q1", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
                DatasetSourceAttempt("SRA_PRJNA", "sra", "q2", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
                DatasetSourceAttempt("IMM_PORT_SDY", "pubmed", "q3", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
                DatasetSourceAttempt("PUBMED_ACCESSION_MINING", "pubmed", "q4", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test")
            ),
            noCandidateLearningRecords = emptyList(),
            memory = memory
        )

        assertEquals("NO_ACCESSION_ARCHIVE_ROUTE", report.state)
        assertTrue(report.archiveRecommended)
        assertTrue(report.nextAction.contains("Archive or reframe"))
    }
}
