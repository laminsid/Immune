package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AutonomousStagnationEngineV136Test {
    @Test
    fun appliesPreviousPivotAfterRepeatedEmptyCycle() {
        val report = """
            {
              "knowledgeDelta": {"newSourcesSaved": 0, "repeatedSourcesSkipped": 20},
              "resilienceDecision": {
                "pivotType": "REPEAT_TO_EVIDENCE_LANE_ROTATION",
                "reason": "Many known IDs repeated.",
                "nextIntent": "evidence_lane_rotation",
                "nextQuerySeed": "immune response contradiction negative control longitudinal outcome dataset",
                "priority": 76
              },
              "queryEvolutionState": {
                "evolvedQuery": "immune response AND GSE AND negative control AND longitudinal outcome"
              }
            }
        """.trimIndent()

        val plan = AutonomousStagnationEngine.planFromRecentReports(
            recentReports = listOf(report),
            limits = ResearchRunLimits(maxQueries = 4, maxResultsPerQuery = 5)
        )

        assertTrue(plan.active)
        assertEquals(3, plan.level)
        assertEquals("ANTI_STAGNATION_DEEP_ROTATION", plan.pendingPivot.pivotType)
        assertTrue(plan.effectiveMaxQueries >= 6)
        assertTrue(plan.effectiveResultsPerQuery >= 25)
        assertTrue(plan.pendingPivot.nextQuerySeed.contains("GSE"))
    }

    @Test
    fun antiStagnationBuildsDatasetAndContradictionQueries() {
        val pivot = PivotDecision(
            pivotType = "ANTI_STAGNATION_DEEP_ROTATION",
            reason = "test",
            nextIntent = "anti_stagnation_dataset_contradiction",
            nextQuerySeed = "immune response",
            priority = 90
        )
        val plan = AutonomousStagnationEngine.StagnationPlan(
            level = 3,
            pendingPivot = pivot,
            effectiveMaxQueries = 6,
            effectiveResultsPerQuery = 25,
            reason = "test"
        )

        val queries = AutonomousStagnationEngine.antiStagnationQueries(plan)
        assertTrue(queries.any { it.query.contains("GSE") && it.query.contains("outcome") })
        assertTrue(queries.any { it.query.contains("failed to replicate") || it.query.contains("negative control") })
    }
}
