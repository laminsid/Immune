package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FoundationKnowledgeOsV151Test {
    @Test
    fun conflictResolverDowngradesLowMatchToAnalogy() {
        val axis = FoundationAxis(
            id = "interferon_antiviral_timing",
            coreMeaning = "IFN timing needs viral load and temporal/outcome context",
            requiredEvidence = listOf("viral_load", "time_course", "interferon_markers", "outcome_labels"),
            criticalEvidence = listOf("viral_load", "time_course"),
            forbiddenConflations = emptyList(),
            queryHints = listOf("viral", "interferon"),
            causalWarnings = emptyList(),
            datasetType = "human",
            specificity = 0.85f
        )
        val ranked = RankedAxis(
            axisId = axis.id,
            matchScore = 0.30f,
            specificityScore = 0.85f,
            evidenceCompletenessScore = 0.25f,
            priorSuccessScore = 0.5f,
            riskPenalty = 0f,
            finalScore = 0.35f,
            reason = "weak match",
            criticalEvidenceMissing = listOf("viral_load", "time_course"),
            presentEvidence = listOf("interferon_markers")
        )
        val result = FoundationConflictResolver().resolve(
            axis = axis,
            rankedAxis = ranked,
            presentEvidence = listOf("interferon_markers"),
            compensatingEvidence = emptyList(),
            detectedConflations = emptyList()
        )
        assertEquals(FoundationAction.DOWNGRADE_TO_ANALOGY, result.action)
        assertTrue(result.confidenceAdjustment <= -0.25f)
    }

    @Test
    fun axisRankingKeepsSpecificAxisAboveGenericWhenScoresAreHigher() {
        val allergy = RankedAxis(
            axisId = "allergy_contact_dermatitis_il1_skin",
            matchScore = 0.9f,
            specificityScore = 0.9f,
            evidenceCompletenessScore = 0.8f,
            priorSuccessScore = 0.5f,
            riskPenalty = 0f,
            finalScore = 0.79f,
            reason = "specific skin allergy match",
            criticalEvidenceMissing = emptyList(),
            presentEvidence = listOf("skin", "allergen", "control")
        )
        val generic = allergy.copy(
            axisId = "generic_inflammation_context",
            matchScore = 0.55f,
            specificityScore = 0.35f,
            evidenceCompletenessScore = 0.45f,
            finalScore = 0.44f,
            reason = "generic inflammation match"
        )
        val ranked = AxisRankingEngine().computeFinalRanking(listOf(generic, allergy))
        assertEquals("allergy_contact_dermatitis_il1_skin", ranked.first().axisId)
    }
}
