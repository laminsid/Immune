package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMProfessorDiscoveryDashboardV257Test {
    @Test
    fun dashboardBuildsResolverActionsAndGraphWithoutClinicalClaims() {
        val intent = GTIMResearchIntentParserV255.parse("""
            Disease / phenotype: Long COVID fatigue
            Trigger: EBV or HHV-6 reactivation
            Pathway: interferon, IL-6, TNF, T-cell exhaustion
            Cell / tissue: PBMC, T cells, B cells
            Comparator: Long COVID vs recovered vs healthy
            Assay: RNA-seq, scRNA-seq, cytokine profiling
            Repositories: GEO, SRA, ArrayExpress, ImmPort
            Contradiction: no association or opposite cytokine direction
            Output: discovery brief, no raw JSON
        """.trimIndent())
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        val split = GTIMDiscoveryEvidenceSplitV256.evaluate(
            intent = intent,
            plan = plan,
            report = ResearchGradeMechanismDossierReportV1110.empty().copy(active = true, researchQuestion = intent.sourceText),
            evidenceObjects = emptyList(),
            mechanismCandidates = emptyList()
        )
        val feed = GTIMOpenDiscoveryDataFeedReportV254.empty().copy(active = true, status = GTIMOpenDiscoveryDataFeedingV254.STATUS_PASS)
        val dashboard = GTIMProfessorDiscoveryDashboardV257.build(intent, plan, split, feed)
        assertEquals(GTIMProfessorDiscoveryDashboardV257.STATUS_READY, dashboard.status)
        assertTrue(dashboard.publicDataResolverActions.isNotEmpty())
        assertTrue(dashboard.graphNodes.isNotEmpty())
        assertTrue(dashboard.blockedMisuses.any { it.contains("No diagnosis") })
        assertTrue(dashboard.playProtectPosture.contains("no background scraping", ignoreCase = true))
    }
}
