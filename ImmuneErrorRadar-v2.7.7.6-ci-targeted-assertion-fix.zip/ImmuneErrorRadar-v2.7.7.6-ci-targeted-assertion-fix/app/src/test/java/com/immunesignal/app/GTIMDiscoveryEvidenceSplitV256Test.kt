package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMDiscoveryEvidenceSplitV256Test {
    @Test
    fun richQuestionDoesNotReturnZeroScoresWithoutAccession() {
        val intent = GTIMResearchIntentParserV255.parse(
            "EBV reactivation -> Long COVID fatigue -> interferon + IL-6/TNF -> PBMC/T cells/B cells -> Long COVID vs recovered vs healthy -> RNA-seq/scRNA-seq/cytokines GEO SRA ImmPort"
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        val report = ResearchGradeMechanismDossierReportV1110.empty().copy(
            active = true,
            researchQuestion = intent.sourceText,
            blockingGaps = listOf("accession", "comparator", "matrix", "metadata", "contradiction closure")
        )
        val split = GTIMDiscoveryEvidenceSplitV256.evaluate(intent, plan, report, emptyList(), emptyList())
        assertTrue(split.active)
        assertTrue(split.candidateRoutes.isNotEmpty())
        assertTrue(split.threeDimensionalScore.discoveryValueScore > 0)
        assertTrue(split.threeDimensionalScore.noveltyScore > 0)
        assertTrue(split.threeDimensionalScore.biologicalPlausibilityScore > 0)
    }

    @Test
    fun semanticPriorDoesNotBecomeMatrixAndLabDraftIsNotValidation() {
        val intent = GTIMResearchIntentParserV255.parse("EBV Long COVID interferon PBMC RNA-seq healthy controls GEO")
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        val split = GTIMDiscoveryEvidenceSplitV256.evaluate(
            intent,
            plan,
            ResearchGradeMechanismDossierReportV1110.empty().copy(active = true, researchQuestion = intent.sourceText),
            emptyList(),
            emptyList()
        )
        assertEquals("SEMANTIC_PRIOR_NOT_MATRIX", split.semanticMechanismPrior.status)
        assertTrue(split.semanticMechanismPrior.forbiddenUses.contains("DGE result"))
        assertEquals("LAB_PROTOCOL_DRAFT_NOT_VALIDATION", split.preliminaryLabProtocol.status)
        assertTrue(split.preliminaryLabProtocol.falsificationCondition.isNotBlank())
    }

    @Test
    fun contradictionEngineReturnsSupportAndOpposition() {
        val intent = GTIMResearchIntentParserV255.parse("EBV Long COVID interferon PBMC RNA-seq healthy controls GEO")
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        val split = GTIMDiscoveryEvidenceSplitV256.evaluate(
            intent,
            plan,
            ResearchGradeMechanismDossierReportV1110.empty().copy(active = true, researchQuestion = intent.sourceText),
            emptyList(),
            emptyList()
        )
        assertEquals("ACTIVE_CONTRADICTION_ENGINE_READY", split.activeContradictionEngine.status)
        assertTrue(split.activeContradictionEngine.contradictionQueries.isNotEmpty())
        assertTrue(split.activeContradictionEngine.nullResultTargets.isNotEmpty())
    }
}
