package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMResearchValueLayerV2765Test {

    @Test
    fun softLeadNowProducesReadableResearchValueLineWithoutEvidenceUpgrade() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))

        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202"),
            paperUnderstandingSummary = "GSE152202 SARS-CoV-2 patient cohort severe mild RNA-seq transcriptomics data availability sample traits"
        )

        assertEquals("GSE152202", card.targetId)
        assertEquals("ACTIONABLE_SOFT_ANALYSIS_LEAD", card.researchValueState)
        assertTrue(card.researchValueLine.contains("Research value: ACTIONABLE_SOFT_ANALYSIS_LEAD"))
        assertTrue(card.researchValueLine.contains("assay/data-availability signal"))
        assertTrue(card.researchValueLine.contains("patient/cohort contrast signal"))
        assertTrue(card.researchValueLine.contains("boundary=research lead"))
        assertFalse(card.evidenceUpgradeState == "EVIDENCE_CANDIDATE")
        assertFalse(card.datasetObjectState == "MATRIX_LINK_FOUND")
    }

    @Test
    fun accessionOnlyStillGetsUsefulLookupLeadInsteadOfDryNoResult() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Ebola")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE72056")))))

        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE72056"),
            paperUnderstandingSummary = "GSE72056 Ebola virus disease host response dataset handle"
        )

        assertEquals("GSE72056", card.targetId)
        assertTrue(card.researchValueState in setOf("DATASET_LOOKUP_LEAD", "ASSAY_DATA_AVAILABILITY_LEAD", "COHORT_CONTRAST_LEAD", "ACTIONABLE_SOFT_ANALYSIS_LEAD"))
        assertTrue(card.researchValueLine.contains("Research value:"))
        assertTrue(card.researchValueLine.contains("boundary=research lead"))
        assertFalse(card.matrixState == "DGE_NOT_READY_NO_ACCESSION")
    }

    @Test
    fun researchValueLineIsRenderedThroughMatrixAuditCardHelper() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))

        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202"),
            paperUnderstandingSummary = "GSE152202 SARS-CoV-2 patient cohort RNA-seq data availability sample traits"
        )

        val line = GTIMMatrixAuditCardV2745.researchValueLine(card)
        assertTrue(line.contains(card.researchValueState))
        assertTrue(line.contains("not biological proof or clinical claim"))
    }
}
