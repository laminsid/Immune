package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DatasetParserV142Test {
    @Test
    fun parserExtractsOutcomeControlAndContrastSlots() {
        val candidate = DatasetAccessionCandidate(
            accession = "GSE999999",
            source = "GEO/NCBI",
            organismHint = "human_candidate",
            conditionLabelsHint = "viral-response condition labels candidate",
            outcomeLabelsHint = "outcome/response labels candidate",
            triggerResponseOutcomeHint = "trigger-response-outcome candidate",
            timeCourseHint = "time-course/longitudinal candidate",
            sampleSizeHint = "42 patients",
            dataType = "RNA-seq/transcriptomic",
            usabilityScore = 85,
            status = "USABLE_LEAD_NEEDS_INSPECTION",
            sourceFindingId = "NCBI_GEO_GDS:GSE999999",
            sourceTitle = "Human viral response mild severe responder non-responder healthy control baseline follow-up RNA-seq",
            sourceUrl = "https://example.test/GSE999999",
            reasons = listOf("Explicit accession detected.")
        )

        val parsed = DatasetParser.parse(listOf(candidate), emptyList()).first()

        assertEquals("USABLE_FOR_TEST", parsed.usabilityVerdict)
        assertTrue(parsed.outcomeLabels.isNotEmpty())
        assertTrue(parsed.controlLabels.isNotEmpty())
        assertTrue(parsed.contrastiveSlots.any { it == "mild_vs_severe" || it == "responder_vs_nonresponder" })
    }

    @Test
    fun contrastiveGateBlocksWithoutMetadata() {
        val report = ContrastiveEvidenceGate.evaluate(emptyList())
        assertEquals("NOT_EVALUATED", report.gateStatus)
    }

    @Test
    fun cumulativeScoreStaysConservativeWithoutEvidenceObjects() {
        val cumulative = CumulativeEvidenceScorer.score(emptyList(), emptyList())
        assertEquals("OFF", cumulative.state)
        assertTrue(cumulative.downgrades.isNotEmpty())
    }

    @Test
    fun foragingReportDefaultsIncludeInterpreterFields() {
        val report = DatasetForagingReport.empty()
        assertTrue(report.parsedMetadata.isEmpty())
        assertEquals("NOT_EVALUATED", report.contrastiveReport.gateStatus)
        assertEquals("OFF", report.cumulativeEvidence.state)
    }
}
