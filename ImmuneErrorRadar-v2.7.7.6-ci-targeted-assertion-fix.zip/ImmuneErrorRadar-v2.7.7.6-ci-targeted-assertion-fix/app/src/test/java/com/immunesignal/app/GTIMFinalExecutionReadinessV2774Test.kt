package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalExecutionReadinessV2774Test {

    @Test
    fun finalReadinessSurfaceSummarizesDgeAndTreatmentWithoutClaims() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid vaccine clinical trial neutralizing antibody responder non-responder"))
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            "Covid vaccine clinical trial neutralizing antibody responder non-responder"
        )
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE166552"),
            paperUnderstandingSummary = "GSE166552 single-cell RNA-seq sample table patient cohort data availability comparator"
        )
        val treatment = GTIMTreatmentKnowledgeLayerV2772.evaluate(report, contract, card, card.dgeExecutionBridgeLine)
        val treatmentBridge = GTIMTreatmentExecutionBridgeV2773.build(contract, treatment, card)
        val final = GTIMFinalExecutionReadinessV2774.build(card, treatment, treatmentBridge)

        assertTrue(final.active)
        assertTrue(final.state.contains("REVIEW_ONLY"))
        assertTrue(final.readinessLine.contains("Final execution readiness:"))
        assertTrue(final.readinessLine.contains("v2.7.7.4-final-execution-readiness-closure") || final.readinessLine.contains("2.7.7.4-final-execution-readiness-closure"))
        assertTrue(final.nextStepLine.contains("Final next step:"))
        assertTrue(final.lockLine.contains("Final locks:"))
        assertTrue(final.lockLine.contains("no treatment advice"))
        assertTrue(final.lockLine.contains("no dosing"))
        assertTrue(final.lockLine.contains("no clinical management"))
        assertTrue(final.lockLine.contains("no efficacy claim"))
        assertFalse(final.readinessLine.contains("biological proof confirmed"))
    }

    @Test
    fun globalBriefRendersFinalReadinessClosure() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Tuberculosis antibiotic resistance MIC host immune response"))
        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("v2.7.7.4-final-execution-readiness-closure"))
        assertTrue(rendered.contains("Final execution readiness:"))
        assertTrue(rendered.contains("Final next step:"))
        assertTrue(rendered.contains("Final locks:"))
        assertTrue(rendered.contains("observed-only signals"))
        assertTrue(rendered.contains("no treatment advice"))
        assertFalse(rendered.contains("patient-specific treatment recommendation"))
    }
}
