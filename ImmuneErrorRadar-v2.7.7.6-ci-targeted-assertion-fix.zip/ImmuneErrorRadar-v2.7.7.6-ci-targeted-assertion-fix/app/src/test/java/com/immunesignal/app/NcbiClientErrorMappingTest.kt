package com.immunesignal.app

import kotlinx.coroutines.runBlocking
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class NcbiClientErrorMappingTest {
    @Test
    fun mapsHttp500ToTypedExceptionAndDoesNotReturnBodyAsSuccess() = runBlocking {
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(500).setBody("server failed"))
        server.start()
        try {
            val client = NcbiClient(contactEmail = "research@vraimony.com", apiKey = "test-key")
            try {
                client.getWithRetry(server.url("/eutils/test").toString(), attempts = 1)
                fail("HTTP 500 must not be returned as a successful body")
            } catch (e: NcbiHttpException) {
                assertTrue(e.message.orEmpty().contains("HTTP 500"))
            }
        } finally {
            server.shutdown()
        }
    }

    @Test
    fun maps429ToRateLimitException() = runBlocking {
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(429).setBody("slow down"))
        server.start()
        try {
            val client = NcbiClient(contactEmail = "research@vraimony.com", apiKey = "test-key")
            try {
                client.getWithRetry(server.url("/eutils/test").toString(), attempts = 1)
                fail("HTTP 429 must be treated as rate limit")
            } catch (e: NcbiRateLimitException) {
                assertTrue(e.message.orEmpty().contains("HTTP 429"))
            }
        } finally {
            server.shutdown()
        }
    }

    @Test
    fun sendsDynamicUserAgentWithActiveEngineVersion() = runBlocking {
        val server = MockWebServer()
        server.enqueue(MockResponse().setResponseCode(200).setBody("{}"))
        server.start()
        try {
            val client = NcbiClient(contactEmail = "research@vraimony.com", apiKey = "test-key")
            client.getWithRetry(server.url("/eutils/test").toString(), attempts = 1)
            val userAgent = server.takeRequest().getHeader("User-Agent").orEmpty()
            assertTrue(userAgent.contains(EngineRuntimeStatus.ACTIVE_ENGINE_VERSION))
            assertTrue(userAgent.contains("research@vraimony.com"))
        } finally {
            server.shutdown()
        }
    }
}
