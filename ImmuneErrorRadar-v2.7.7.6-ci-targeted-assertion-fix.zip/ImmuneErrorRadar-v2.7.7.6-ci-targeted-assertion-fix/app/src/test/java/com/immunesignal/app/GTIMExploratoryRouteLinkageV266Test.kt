package com.immunesignal.app

import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMExploratoryRouteLinkageV266Test {
    @Test
    fun exploratoryQuestionLinksParserPlannerSourcesSeedsAndResolver() {
        val trace = GTIMExploratoryRouteLinkageV266.trace(
            "Compare Long COVID EBV interferon with cancer HIV fungal and pandemic immune response using PBMC RNA-seq healthy controls Europe PMC OpenAlex GSE PRJNA data availability"
        )

        assertTrue(trace.active)
        assertTrue(trace.parserLinked)
        assertTrue(trace.plannerLinked)
        assertTrue(trace.europePmcLinked)
        assertTrue(trace.openAlexLinked)
        assertTrue(trace.seedBootstrapLinked)
        assertTrue(trace.comparativeLinked)
        assertTrue(trace.directRouterLinked)
        assertTrue(trace.resolverSupported)
        assertTrue(trace.publicLookupActionCount >= RuntimeFeatureFlags.EXPLORATORY_MIN_PUBLIC_LOOKUP_ACTIONS_V266)
        assertTrue(trace.nextAction.contains("user-triggered public lookup"))
        assertTrue(trace.claimBoundary.contains("not_diagnosis"))
    }
}
