package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningLoopActivationV262Test {
    private fun finding(): ResearchFinding = ResearchFinding(
        source = "PubMed",
        sourceId = "loop_v262",
        title = "Allergy histamine interferon tissue damage longitudinal recovery study",
        published = "2024",
        url = "https://example.test/loop",
        matchedAxes = listOf("interferon_antiviral_axis", "tissue_damage_axis", "type2_allergy_axis"),
        noveltyScore = 72,
        bridgeSignal = "interferon tissue damage histamine recovery bridge",
        whyItMatters = "fast recovery, histamine-like symptoms, high allergy reactivity, low inflammation, viral control",
        evidence = EvidenceAssessment(
            sourceClass = "human_observational",
            speciesClass = "human",
            studyDesign = "human_cohort_longitudinal",
            humanEvidence = true,
            evidenceQualityScore = 68,
            limitations = listOf("needs accession closure")
        ),
        causality = CausalityAssessment(
            causalityScore = 62,
            temporalityScore = 55,
            biologicalPlausibilityScore = 70,
            measurableMarkerScore = 65,
            repeatabilityScore = 45,
            contradictionPenalty = 5,
            rationale = listOf("test")
        ),
        negativeControl = NegativeControlAssessment(
            status = "watch_requires_controls",
            reverseTimeRisk = "medium",
            shuffledTimelineRisk = "medium",
            unrelatedMarkerRisk = "medium",
            notes = listOf("needs negative controls")
        ),
        personalPattern = PersonalPatternAssessment(
            repeatedObservationCount = 3,
            temporalSupport = "longitudinal",
            strongestLocalAxes = listOf("interferon_antiviral_axis"),
            nextBestMeasurement = "Close accession/comparator/matrix gates."
        )
    )

    @Test
    fun learningLoopActivationClosesRulesGapsEdgesAndDistance() {
        val findings = listOf(finding())
        val ruleMatches = LearningRuleEngine.evaluate(findings)
        val report = LearningLoopActivationV262.build(
            findings = findings,
            evidenceObjects = emptyList(),
            beliefReport = EpistemicBeliefReport.empty().copy(
                active = true,
                state = "BELIEF_MODEL_EXPANDING",
                newBeliefsThisCycle = 1,
                beliefs = listOf(
                    EpistemicBelief(
                        beliefId = "belief:loop_test",
                        statement = "Interferon/tissue/allergy route is a mutable prior.",
                        beliefType = "AXIS_PRIOR",
                        status = "ACTIVE_PRIOR",
                        confidence = 60,
                        credibility = 58,
                        supportCount = 1,
                        contradictionCount = 0,
                        linkedNodes = listOf("axis:interferon_antiviral_axis"),
                        requiredEvidenceToKeep = listOf("accession", "comparator"),
                        falsifiers = listOf("null_result"),
                        lastChangedReason = "test"
                    )
                )
            ),
            gapMiner = ScientificDiscoveryGapMinerReport.empty(),
            routeFingerprint = RouteFingerprintReport(true, "new", RouteFingerprint("abc", setOf("GEO_GDS"), listOf("q1"), false)),
            learningRuleMatches = ruleMatches,
            recentReports = emptyList()
        )
        assertTrue(report.active)
        assertTrue(report.proposedPlausibilityEdges.isNotEmpty())
        assertTrue(report.axisPerformanceRecords.isNotEmpty())
        assertTrue(report.epistemicDistance.distanceScore > 0.0)
        assertTrue(report.nextLoopAction.isNotBlank())
        assertEquals(LearningLoopActivationV262.CLAIM_LIMIT, report.claimLimit)
    }

    @Test
    fun bayesianBeliefRevisionStaysResearchPriorOnly() {
        val belief = EpistemicBelief(
            beliefId = "belief:bayes_test",
            statement = "A route may be useful as a research prior.",
            beliefType = "AXIS_PRIOR",
            status = "ACTIVE_PRIOR",
            confidence = 50,
            credibility = 50,
            supportCount = 2,
            contradictionCount = 1,
            linkedNodes = listOf("axis:test_axis"),
            requiredEvidenceToKeep = listOf("accession"),
            falsifiers = listOf("null_result"),
            lastChangedReason = "test"
        )
        val revisions = BayesianBeliefRevisionV262.revise(listOf(belief), emptyList())
        assertEquals(1, revisions.size)
        assertTrue(revisions.first().posteriorProbability in 0.0..1.0)
        assertEquals(BayesianBeliefRevisionV262.CLAIM_LIMIT, revisions.first().claimLimit)
    }
}
