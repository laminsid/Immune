package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CognitivePathIntegrationV164Test {
    private fun foragingWithHighRouteFitNoMetadata() = DatasetForagingReport.empty().copy(
        active = true,
        state = "DATASET_FORAGING_CANDIDATE_INSPECTION",
        candidates = listOf(
            DatasetAccessionCandidate(
                accession = "GSE_PATH",
                source = "GEO/NCBI",
                organismHint = "human_candidate",
                conditionLabelsHint = "viral infection interferon response",
                outcomeLabelsHint = "unknown",
                triggerResponseOutcomeHint = "interferon viral response",
                timeCourseHint = "unknown",
                sampleSizeHint = "unknown",
                dataType = "RNA-seq",
                usabilityScore = 66,
                status = "PARTIAL_LEAD_NEEDS_METADATA",
                sourceFindingId = "test",
                sourceTitle = "Human viral interferon RNA-seq candidate",
                sourceUrl = "https://example.test/GSE_PATH",
                reasons = emptyList()
            )
        ),
        parsedMetadata = emptyList(),
        routeFitAssessments = listOf(
            DatasetRouteFitAssessment(
                accession = "GSE_PATH",
                datasetRoute = "interferon_antiviral_timing",
                targetRoute = "interferon_antiviral_timing",
                routeFitScore = 91,
                status = "IN_ROUTE",
                allowedUse = "Inspect metadata before upgrade.",
                blocksHypothesisUpgrade = false,
                reasons = emptyList()
            )
        ),
        scoreSeparation = DatasetScoreSeparation(
            datasetUsabilityScore = 66,
            routeFitScore = 91,
            hypothesisConfidenceScore = 62,
            hypothesisUpgradeAllowed = false,
            scoreState = "CANDIDATE",
            summary = "High route fit but metadata missing.",
            reasons = listOf("minimum metadata required")
        )
    )

    @Test
    fun linksMapBeliefsSpecialistAndForagerIntoOneDecision() {
        val foraging = foragingWithHighRouteFitNoMetadata()
        val specialist = SpecializedReasoningReport.empty().copy(
            active = true,
            specialistScore = 62,
            state = "SPECIALIST_CAUTION",
            weakestLink = "High route-fit exists, but minimum metadata is still missing.",
            decisiveNextTest = "Parse minimum metadata and find outcome labels before any upgrade.",
            evidenceGaps = listOf(
                EvidenceGapCard(
                    gapId = "MINIMUM_METADATA",
                    status = "MISSING",
                    severity = 90,
                    whyItMatters = "No metadata means no condition/outcome inspection.",
                    requiredAction = "Parse minimum metadata and outcome labels."
                )
            ),
            specialistVerdict = "Evidence hunt only.",
            nextCycleProtocol = listOf("Parse metadata first.")
        )
        val map = KnowledgeMapReport.empty().copy(
            active = true,
            state = "MAP_WITH_BLOCKING_GAPS",
            mapScore = 61,
            gaps = listOf(
                KnowledgeMapGap(
                    gapId = "minimum_metadata_not_parsed",
                    affectedNodes = listOf("dataset:gse_path"),
                    severity = 92,
                    nextAction = "Parse minimum metadata before broad search.",
                    blocksUpgrade = true
                )
            ),
            nextMapAction = "Parse minimum metadata before broad search."
        )
        val belief = EpistemicBeliefReport.empty().copy(
            active = true,
            state = "BELIEF_MODEL_CAUTION",
            beliefScore = 58,
            weakenedBeliefs = 1,
            beliefs = listOf(
                EpistemicBelief(
                    beliefId = "belief:route:gse_path",
                    statement = "Route is plausible but must stay mutable until metadata is parsed.",
                    beliefType = "ROUTE_BELIEF",
                    status = "WEAKENED",
                    confidence = 66,
                    credibility = 45,
                    supportCount = 1,
                    contradictionCount = 0,
                    linkedNodes = listOf("dataset:gse_path"),
                    requiredEvidenceToKeep = listOf("minimum_metadata_parse", "outcome_labels"),
                    falsifiers = listOf("metadata_not_parsed"),
                    lastChangedReason = "Minimum metadata missing."
                )
            ),
            nextBeliefAction = "Collect minimum metadata before using this belief strongly."
        )

        val path = CognitivePathIntegrationEngine.integrate(
            knowledgeMapReport = map,
            epistemicBeliefReport = belief,
            specializedReasoningReport = specialist,
            datasetForagingReport = foraging,
            learningOsReport = LearningOsReport.empty()
        )

        assertTrue(path.active)
        assertTrue(path.links.any { it.relation == "map_updates_mutable_belief" })
        assertTrue(path.links.any { it.relation == "specialist_test_controls_next_search" })
        assertEquals("CONTINUE_EVIDENCE_HUNT", path.decision.decisionType)
        assertTrue(path.decision.blocksHypothesisUpgrade)
        assertTrue(path.decision.requiredEvidence.contains("minimum_metadata_parse") || path.decision.requiredEvidence.contains("minimum_metadata"))
        assertEquals("cognitive_path_integration_not_biological_proof", path.claimLimit)
    }
}
