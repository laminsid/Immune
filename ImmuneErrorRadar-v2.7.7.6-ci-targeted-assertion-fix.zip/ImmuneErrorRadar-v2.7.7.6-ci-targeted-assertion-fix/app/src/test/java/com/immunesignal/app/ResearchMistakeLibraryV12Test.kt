package com.immunesignal.app

import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchMistakeLibraryV12Test {
    @Test
    fun `low trust or evidence creates weak evidence risk`() {
        val obj = V12TestFixtures.objectCard(id = "weak", trust = 50, evidence10 = 6.0)
        val risks = ResearchMistakeLibrary.topRisks(listOf(obj), emptyList())
        assertTrue(risks.any { it.risk.contains("weak", ignoreCase = true) || it.risk.contains("metadata", ignoreCase = true) })
    }

    @Test
    fun `missing timing creates correlation causation risk`() {
        val obj = V12TestFixtures.objectCard(id = "timing", missing = listOf("timestamp"))
        val risks = ResearchMistakeLibrary.topRisks(listOf(obj), emptyList())
        assertTrue(risks.any { it.risk.contains("correlation", ignoreCase = true) })
    }

    @Test
    fun `animal finding creates animal cell risk`() {
        val finding = V12TestFixtures.finding(species = "animal")
        val risks = ResearchMistakeLibrary.topRisks(listOf(V12TestFixtures.objectCard()), listOf(finding))
        assertTrue(risks.any { it.risk.contains("animal/cell", ignoreCase = true) })
    }

    @Test
    fun `alert bias creates novelty mistaken for truth risk`() {
        val obj = V12TestFixtures.objectCard(id = "alert", bias = "Alert", missing = emptyList())
        val risks = ResearchMistakeLibrary.topRisks(listOf(obj), emptyList())
        assertTrue(risks.any { it.risk.contains("Novelty", ignoreCase = true) })
    }

    @Test
    fun `empty risk list still returns conservative default`() {
        val obj = V12TestFixtures.objectCard(id = "ok", trust = 80, evidence10 = 8.0, bias = "Normal", missing = emptyList())
        val risks = ResearchMistakeLibrary.topRisks(listOf(obj), emptyList())
        assertTrue(risks.isNotEmpty())
    }
}
