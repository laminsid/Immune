package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExtendedThinkingBudgetV11016Test {
    @Test
    fun extendedBudgetUsesLongerSessionLimitAndLocalPasses() {
        val report = ExtendedThinkingBudgetPolicy.evaluate(
            executedQueries = emptyList(),
            datasetForaging = DatasetForagingReport.empty().copy(active = true),
            learningOs = LearningOsReport.empty(),
            postSearchThinking = PostSearchThinkingReport.empty(),
            thinkingContinuity = ThinkingContinuityReport.empty(),
            hypothesisGraph = HypothesisGraphReport.empty(),
            cognitiveMomentum = CognitiveMomentumReport.empty().copy(state = "MOMENTUM_STALLED_CLOSE_OR_ARCHIVE"),
            linkedSpine = LinkedCognitionSpineReport.empty().copy(routeMode = "GRAPH_GAP_CLOSURE_ONLY"),
            maxLearningMillis = RuntimeFeatureFlags.DEFAULT_RESEARCH_LEARNING_TIME_LIMIT_MILLIS
        )

        assertTrue(report.active)
        assertEquals("EXTENDED_LOCAL_THINKING_BUDGET", report.mode)
        assertEquals(RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS, report.defaultSessionBudgetMillis)
        assertTrue(report.defaultSessionBudgetMillis > RuntimeFeatureFlags.PRIOR_FAST_THINKING_WINDOW_MILLIS)
        assertTrue(report.passesExecuted >= RuntimeFeatureFlags.MIN_AUTONOMOUS_THINKING_PASSES)
        assertTrue(report.claimLimit.endsWith("not_biological_proof"))
    }
}
