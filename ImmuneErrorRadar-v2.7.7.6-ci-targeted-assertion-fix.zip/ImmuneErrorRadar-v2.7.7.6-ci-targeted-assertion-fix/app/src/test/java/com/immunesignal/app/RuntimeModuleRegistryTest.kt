package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RuntimeModuleRegistryTest {
    @Test
    fun activeModuleListComesFromTypedRegistry() {
        assertTrue(EngineRuntimeStatus.ACTIVE_MODULES.contains("NcbiClientOkHttp"))
        assertTrue(EngineRuntimeStatus.ACTIVE_MODULES.contains("RuntimeHardeningV1102"))
        assertFalse(EngineRuntimeStatus.ACTIVE_MODULES.contains("ResultActivity"))
        assertTrue(RuntimeModuleRegistry.readinessSummary.startsWith("ready="))
    }
}
