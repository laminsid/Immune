package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

object V12TestFixtures {
    fun card(
        id: String = "autonomic_vascular_axis__psychoneuroimmune_axis",
        label: String = "stress histamine blood pressure",
        status: String = "WATCH",
        overall: Int = 60,
        evidence: Int = 65,
        causality: Int = 55,
        repeats: Int = 1,
        negative: String = "watch_requires_controls",
        next: String = "Measure systolic BP, diastolic BP, pulse, dizziness, stress score, sleep quality, symptom intensity, timestamp before during after episode.",
        why: List<String> = listOf("human evidence", "biological mechanism")
    ) = HypothesisRankCard(
        hypothesisId = id,
        label = label,
        status = status,
        overallScore = overall,
        evidenceQualityScore = evidence,
        causalityScore = causality,
        personalRepeatability = repeats,
        negativeControlStatus = negative,
        nextBestMeasurement = next,
        whyRanked = why
    )

    fun finding(
        axes: List<String> = listOf("psychoneuroimmune_axis", "autonomic_vascular_axis"),
        sourceId: String = "PMID1",
        species: String = "human",
        design: String = "human_cohort",
        flags: List<String> = emptyList(),
        title: String = "Human cohort stress allergy histamine systolic diastolic pulse dizziness before after sleep quality symptom intensity",
        why: String = "links stress, mast cells, histamine, blood pressure and measurable temporal markers"
    ) = ResearchFinding(
        source = "pubmed",
        sourceId = sourceId,
        title = title,
        published = "2026",
        url = "https://example.test/$sourceId",
        matchedAxes = axes,
        noveltyScore = 70,
        bridgeSignal = "stress histamine bp",
        whyItMatters = why,
        evidence = EvidenceAssessment(
            sourceClass = "clinical_observational",
            speciesClass = species,
            studyDesign = design,
            humanEvidence = species == "human",
            evidenceQualityScore = 70,
            limitations = emptyList()
        ),
        causality = CausalityAssessment(
            causalityScore = 55,
            temporalityScore = 15,
            biologicalPlausibilityScore = 18,
            measurableMarkerScore = 12,
            repeatabilityScore = 6,
            contradictionPenalty = 0,
            rationale = listOf("plausible")
        ),
        negativeControl = NegativeControlAssessment(
            status = "watch_requires_controls",
            reverseTimeRisk = "needs_reverse_time_test",
            shuffledTimelineRisk = "needs_shuffle_test",
            unrelatedMarkerRisk = "standard_check",
            notes = emptyList()
        ),
        personalPattern = PersonalPatternAssessment(
            repeatedObservationCount = 1,
            temporalSupport = "partial",
            strongestLocalAxes = axes,
            nextBestMeasurement = "systolic bp diastolic bp pulse dizziness timestamp"
        ),
        sanityFlags = flags
    )

    fun imported(preview: String = "timestamp stress score sleep quality symptom intensity systolic diastolic pulse dizziness") = ImportedReportSignal(
        reportId = "manual1",
        createdAtMillis = 1L,
        title = "manual report",
        matchedAxes = listOf("psychoneuroimmune_axis", "autonomic_vascular_axis"),
        extractedKeywords = preview.split(" "),
        preview = preview
    )

    fun objectCard(
        id: String = "hyp1",
        status: String = "WATCH",
        discovery: String = "Early",
        bias: String = "Watch",
        trust: Int = 62,
        evidence10: Double = 6.7,
        causality: Int = 55,
        missing: List<String> = listOf("timestamp")
    ) = HypothesisObject(
        hypothesisId = id,
        label = id,
        status = status,
        discoveryState = discovery,
        biasRiskState = bias,
        dataTrustScore = trust,
        evidenceScore10 = evidence10,
        causalityScore = causality,
        minimumDataPackStatus = if (missing.isEmpty()) "PASS" else "PARTIAL",
        missingData = missing,
        nextBestMeasurement = "next measurement",
        signalFlip = "no_major_flip",
        decisionImpact = "background",
        falsification = listOf("falsify")
    )

    fun previousReport(vararg pairs: Pair<String, String>): String {
        val arr = JSONArray()
        pairs.forEach { (id, status) ->
            arr.put(JSONObject().put("hypothesisId", id).put("status", status))
        }
        return JSONObject().put("hypothesisObjects", arr).toString()
    }
}
