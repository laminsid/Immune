package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MetadataClosureHyperDriveV11058Test {
    @Test
    fun verifiedNeuroViralIntersectionForcesHyperDriveAndRouteFit95() {
        val candidate = DatasetAccessionCandidate(
            accession = "MANUAL_TEXT_SNIPPET_1393bf01b3cd8b15_0",
            source = "MANUAL_EVIDENCE_SEED_MODE",
            organismHint = "human cohort",
            conditionLabelsHint = "EBV HHV-6 SLE Multiple Sclerosis",
            outcomeLabelsHint = "response nonresponse flare relapse",
            triggerResponseOutcomeHint = "RNA-Seq Transcriptome Data Availability",
            timeCourseHint = "longitudinal baseline follow-up",
            sampleSizeHint = "unknown",
            dataType = "RNA-Seq Transcriptome",
            usabilityScore = 10,
            status = "OFF_ROUTE_USEFUL_DATASET",
            sourceFindingId = "manual_1393bf01b3cd8b15_0",
            sourceTitle = "Manual snippet: EBV HHV-6 SLE MS RNA-Seq Transcriptome Data Availability",
            sourceUrl = "",
            reasons = listOf("WEAK_DATASET_LEAD", "OFF_ROUTE")
        )

        val report = MetadataClosureStrategyMatrixV11058.evaluate(
            steering = ResearchSteeringProfile(
                profileId = "v11058-hyper-alpha",
                createdAtMillis = 0L,
                variables = listOf("EBV", "HHV-6", "SLE", "Multiple Sclerosis", "RNA-Seq", "Transcriptome", "Data Availability"),
                focusQuestion = "EBV HHV-6 SLE Multiple Sclerosis RNA-Seq Transcriptome Data Availability GSE PRJNA",
                requiredTerms = listOf("GSE[0-9]*", "PRJNA[0-9]*"),
                excludedTerms = emptyList(),
                inferredAxes = listOf("neuro_viral_bridge")
            ),
            leadObjects = emptyList(),
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            attempts = emptyList(),
            topicFit = TopicFitMetadataParseReport.empty().copy(active = true, forcedMinimumMetadataCount = 1),
            metadataClosure = MetadataClosureReport.empty().copy(active = true, state = "METADATA_CLOSURE_INCOMPLETE"),
            recentReports = emptyList()
        )

        assertTrue(report.hyperDriveModeActive)
        assertTrue(report.criticalUsabilityAnomaly)
        assertEquals(95, report.forcedRouteFitTarget)
        assertTrue(report.routeFitBoostScore >= 95)
        assertTrue(report.queryStreams.any { it.streamId == "HYPER_ALPHA_GEO_GDS_NEURO_VIRAL_DATA_AVAILABILITY" && it.query.contains("Data Availability") })
        assertTrue(report.programmaticCommandLog.any { it.contains("EXECUTE_QUERY::source=GEO_GDS") })
        assertTrue(report.programmaticCommandLog.any { it.contains("EXTRACT_ACCESSIONS") && it.contains("PRJNA[0-9]*") })
        assertTrue(report.runtimeDataDemand.any { it.contains("accessions>0_or_log_HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION") })
        assertTrue(report.controlComparatorLinkageQueries.any { it.contains("healthy control") && it.contains("contrast_definition") })
    }

    @Test
    fun verifiedPsychophysiologicalIntersectionBuildsStreamBeta() {
        val report = MetadataClosureStrategyMatrixV11058.evaluate(
            steering = ResearchSteeringProfile(
                profileId = "v11058-hyper-beta",
                createdAtMillis = 0L,
                variables = listOf("HPA-axis", "Cortisol/DHEA ratio", "Sleep deprivation", "Interferon-alpha", "IL-6", "TNF-alpha", "Curcumin", "Ashwagandha"),
                focusQuestion = "HPA-axis Cortisol/DHEA ratio Sleep deprivation Interferon-alpha IL-6 TNF-alpha Curcumin Ashwagandha GSM SRP",
                requiredTerms = listOf("GSM[0-9]*", "SRP[0-9]*"),
                excludedTerms = emptyList(),
                inferredAxes = listOf("psychophysiological_exposome")
            ),
            leadObjects = emptyList(),
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            attempts = listOf(DatasetSourceAttempt("MANUAL_EVIDENCE_SEED_MODE", "manual", "HPA-axis IL-6 Curcumin GSM SRP", true, 0, 0, "EXPLORATORY", "test")),
            topicFit = TopicFitMetadataParseReport.empty().copy(active = true, forcedMinimumMetadataCount = 1),
            metadataClosure = MetadataClosureReport.empty().copy(active = true, state = "METADATA_CLOSURE_INCOMPLETE"),
            recentReports = emptyList()
        )

        assertTrue(report.hyperDriveModeActive)
        assertEquals(95, report.forcedRouteFitTarget)
        assertTrue(report.queryStreams.any { it.streamId == "HYPER_BETA_GEO_GDS_EXPOSOME_MODULATOR_ACCESSION" && it.query.contains("Curcumin") && it.query.contains("SRP[0-9]*") })
        assertTrue(report.queryStreams.any { it.streamId == "HYPER_BETA_SRA_BIOPROJECT_EXPOSOME_MODULATOR_ACCESSION" && it.query.contains("Ashwagandha") })
        assertTrue(report.leanRuntimeLogicGates.any { it.gateId == "G9_HARD_DATA_EXTRACTION_DEMAND_NO_FABRICATION" })
    }
}
