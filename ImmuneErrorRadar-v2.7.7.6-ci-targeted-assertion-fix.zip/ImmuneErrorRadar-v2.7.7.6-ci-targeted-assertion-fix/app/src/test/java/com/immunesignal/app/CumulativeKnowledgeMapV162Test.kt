package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CumulativeKnowledgeMapV162Test {
    private fun candidate() = DatasetAccessionCandidate(
        accession = "GSE_MAP",
        source = "GEO/NCBI",
        organismHint = "human_candidate",
        conditionLabelsHint = "viral infection interferon response",
        outcomeLabelsHint = "unknown",
        triggerResponseOutcomeHint = "interferon viral response",
        timeCourseHint = "unknown",
        sampleSizeHint = "unknown",
        dataType = "RNA-seq",
        usabilityScore = 66,
        status = "PARTIAL_LEAD_NEEDS_METADATA",
        sourceFindingId = "test",
        sourceTitle = "Human viral interferon RNA-seq candidate",
        sourceUrl = "https://example.test/GSE_MAP",
        reasons = emptyList()
    )

    @Test
    fun buildsCumulativeMapWithDatasetNodeAndBlockingGap() {
        val foraging = DatasetForagingReport.empty().copy(
            active = true,
            candidates = listOf(candidate()),
            parsedMetadata = emptyList(),
            contrastiveReport = ContrastiveEvidenceReport.empty(),
            routeFitAssessments = listOf(
                DatasetRouteFitAssessment(
                    accession = "GSE_MAP",
                    datasetRoute = "interferon_antiviral_timing",
                    targetRoute = "interferon_antiviral_timing",
                    routeFitScore = 91,
                    status = "IN_ROUTE",
                    allowedUse = "Inspect metadata before upgrade.",
                    blocksHypothesisUpgrade = false,
                    reasons = emptyList()
                )
            )
        )

        val map = CumulativeKnowledgeMapEngine.build(
            currentFindings = emptyList(),
            hypothesisObjects = emptyList(),
            evidenceObjects = emptyList(),
            datasetForagingReport = foraging,
            specializedReasoningReport = SpecializedReasoningReport.empty(),
            recentReportLines = emptyList()
        )

        assertTrue(map.active)
        assertTrue(map.nodes.any { it.nodeType == "DATASET" && it.label == "GSE_MAP" })
        assertTrue(map.edges.any { it.relation == "route_fit" })
        assertTrue(map.gaps.any { it.gapId == "minimum_metadata_not_parsed" && it.blocksUpgrade })
        assertEquals("knowledge_map_not_biological_proof", map.claimLimit)
    }

    @Test
    fun carriesForwardPriorMapInsteadOfStartingBlank() {
        val prior = """
            {"knowledgeMapReport":{"active":true,"mapScore":33,"state":"MAP_STARTED","carriedForwardNodes":0,"newNodesThisCycle":1,"newLinksThisCycle":0,"nodes":[{"nodeId":"axis:prior_axis","nodeType":"AXIS","label":"prior_axis","score":50,"occurrences":1,"evidenceIds":[],"status":"ACTIVE","summary":"prior"}],"edges":[],"gaps":[],"carriedForwardInsights":["prior insight"],"changedSincePrevious":[],"nextMapAction":"continue","visibleBrief":"prior brief","claimLimit":"knowledge_map_not_biological_proof"}}
        """.trimIndent()

        val map = CumulativeKnowledgeMapEngine.build(
            currentFindings = emptyList(),
            hypothesisObjects = emptyList(),
            evidenceObjects = emptyList(),
            datasetForagingReport = DatasetForagingReport.empty(),
            specializedReasoningReport = SpecializedReasoningReport.empty(),
            recentReportLines = listOf(prior)
        )

        assertTrue(map.carriedForwardNodes >= 1)
        assertTrue(map.nodes.any { it.nodeId == "axis:prior_axis" })
        assertTrue(map.changedSincePrevious.any { it.contains("Carried forward") })
    }
}
