package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DiscoveryReportExporterV11033Test {
    @Test
    fun exporterHeaderTreatsLeadObjectLookupAsFollowUpNotSourceFamily() {
        val line = DiscoveryReportExporter.noCandidateHeaderLine(
            JSONObject()
                .put("nextPreferredSource", "LEAD_OBJECT_SECONDARY_LOOKUP")
                .put("reason", "near-miss source IDs require secondary lookup")
        )

        assertTrue(line.contains("Next lead follow-up: LEAD_OBJECT_SECONDARY_LOOKUP"))
        assertFalse(line.contains("Next source family:"))
    }


    @Test
    fun exporterDetailTreatsLeadObjectLookupAsFollowUpNotNextSource() {
        val line = DiscoveryReportExporter.noCandidateLearningDetailLine(
            org.json.JSONObject()
                .put("sourceFamily", "MATURE_DOMAIN_EVIDENCE_PROBE")
                .put("nextPreferredSource", "LEAD_OBJECT_SECONDARY_LOOKUP")
                .put("missing", "accession_like_id")
                .put("status", "MATURE_DOMAIN_PROBE_NO_FRESH_EVIDENCE")
        )

        assertTrue(line.contains("follow-up LEAD_OBJECT_SECONDARY_LOOKUP"))
        assertFalse(line.contains("next source LEAD_OBJECT_SECONDARY_LOOKUP"))
    }

    @Test
    fun exporterHeaderKeepsSourceFamilyWordingForTrueSourceRotation() {
        val line = DiscoveryReportExporter.noCandidateHeaderLine(
            JSONObject()
                .put("nextPreferredSource", "PUBMED_ADJACENT_DOMAIN_MINING")
                .put("reason", "rotate after no candidate")
        )

        assertTrue(line.contains("Next source family: PUBMED_ADJACENT_DOMAIN_MINING"))
        assertFalse(line.contains("Next lead follow-up:"))
    }
}
