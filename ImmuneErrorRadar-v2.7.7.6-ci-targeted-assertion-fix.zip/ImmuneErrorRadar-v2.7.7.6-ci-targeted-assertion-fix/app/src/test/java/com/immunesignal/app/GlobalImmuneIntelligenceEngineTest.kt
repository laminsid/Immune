package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GlobalImmuneIntelligenceEngineTest {

    private fun finding(
        id: String,
        title: String,
        axes: List<String>,
        species: String = "human",
        design: String = "cohort"
    ): ResearchFinding {
        return ResearchFinding(
            source = "PubMed",
            sourceId = id,
            title = title,
            published = "2026",
            url = "https://pubmed.ncbi.nlm.nih.gov/$id/",
            matchedAxes = axes,
            noveltyScore = 80,
            bridgeSignal = "test bridge",
            whyItMatters = "test",
            evidence = EvidenceAssessment(
                sourceClass = "pubmed",
                speciesClass = species,
                studyDesign = design,
                humanEvidence = species == "human",
                evidenceQualityScore = if (species == "human") 75 else 45,
                limitations = emptyList()
            ),
            causality = CausalityAssessment(55, 10, 15, 10, 5, 0, emptyList()),
            negativeControl = NegativeControlAssessment("watch_requires_controls", "unknown", "unknown", "unknown", emptyList()),
            personalPattern = PersonalPatternAssessment(0, "not_applicable", emptyList(), "global dataset"),
            sanityFlags = emptyList()
        )
    }

    @Test
    fun `build creates antiviral global hypothesis from interferon dataset evidence`() {
        val report = GlobalImmuneIntelligenceEngine.build(
            findings = listOf(
                finding(
                    "1",
                    "Human RNA-seq cohort dataset of viral infection interferon timing recovery severity",
                    listOf("interferon_antiviral_axis", "rna_transcriptomic_axis", "resolution_recovery_axis")
                )
            ),
            importedSignals = emptyList(),
            steering = null
        )
        assertTrue(report.datasetCandidates.isNotEmpty())
        assertTrue(report.axisMap.any { it.axis == "interferon_antiviral_axis" })
        assertTrue(report.globalHypotheses.any { it.hypothesisId == "HYP_INTERFERON_TIMING_RESOLUTION_001" })
        assertTrue(report.antiviralResponseNotes.any { it.theme == "Interferon timing" })
    }

    @Test
    fun `animal heavy evidence produces bias warning`() {
        val report = GlobalImmuneIntelligenceEngine.build(
            findings = listOf(
                finding("2", "mouse RNA-seq viral interferon dataset", listOf("interferon_antiviral_axis", "rna_transcriptomic_axis"), species = "animal"),
                finding("3", "animal cytokine storm tissue damage dataset", listOf("hyperinflammatory_axis", "tissue_damage_axis"), species = "animal")
            ),
            importedSignals = emptyList(),
            steering = null
        )
        assertTrue(report.globalBiasAlarm.contains("animal", ignoreCase = true) || report.globalBiasAlarm.contains("cell", ignoreCase = true))
    }

    @Test
    fun `fallback hypothesis appears when no global signals exist`() {
        val report = GlobalImmuneIntelligenceEngine.build(
            findings = emptyList(),
            importedSignals = emptyList(),
            steering = null
        )
        assertEquals("HYP_GLOBAL_IMMUNE_MAPPING_BASELINE", report.globalHypotheses.first().hypothesisId)
    }
}
