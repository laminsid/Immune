package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for SourceClassifier including the v0.9.1 fixes:
 * - mixed_human_animal no longer falls through to unknown_metadata
 * - synthesis correctly reports humanEvidence=true
 *
 * Tests are deterministic and depend on no external state.
 */
class SourceClassifierTest {

    @Test
    fun `randomized human trial scores high evidence`() {
        val r = SourceClassifier.classifySource(
            "Randomized clinical trial of 1200 patients with allergic asthma",
            listOf("Randomized Controlled Trial")
        )
        assertEquals("human_randomized_trial", r.studyDesign)
        assertEquals("human", r.speciesClass)
        assertEquals("clinical_intervention", r.sourceClass)
        assertTrue(r.humanEvidence)
        // base 88 - species penalty 0
        assertEquals(88, r.evidenceQualityScore)
    }

    @Test
    fun `meta-analysis returns synthesis sourceClass and is treated as human evidence`() {
        // v0.9.1 fix: synthesis was previously returning humanEvidence=false
        val r = SourceClassifier.classifySource(
            "Systematic review and meta-analysis of IgE and asthma exacerbations",
            listOf("Meta-Analysis")
        )
        assertEquals("synthesis", r.sourceClass)
        assertTrue("synthesis of human studies must be human evidence", r.humanEvidence)
    }

    @Test
    fun `meta-analysis explicitly about animals does NOT count as human evidence`() {
        val r = SourceClassifier.classifySource(
            "Systematic review of murine cytokine models",
            listOf("Meta-Analysis")
        )
        assertEquals("synthesis", r.sourceClass)
        assertEquals("animal", r.speciesClass)
        assertFalse("meta-analysis of animal models is not human evidence", r.humanEvidence)
    }

    @Test
    fun `mixed_human_animal maps to human_relevant_with_animal_context`() {
        // v0.9.1 fix: previously fell through to unknown_metadata + double penalty
        val r = SourceClassifier.classifySource(
            "Translational study comparing patients and mouse models of inflammation",
            emptyList()
        )
        assertEquals("mixed_human_animal", r.speciesClass)
        assertEquals("human_relevant_with_animal_context", r.sourceClass)
        assertTrue(r.humanEvidence)
    }

    @Test
    fun `pure animal study does not count as human evidence`() {
        val r = SourceClassifier.classifySource(
            "Murine model of cytokine release",
            emptyList()
        )
        assertEquals("animal", r.speciesClass)
        assertFalse(r.humanEvidence)
    }

    @Test
    fun `cell line study scores low and is not human evidence`() {
        val r = SourceClassifier.classifySource(
            "In vitro cell line PBMC stimulation",
            emptyList()
        )
        assertEquals("cell_only", r.speciesClass)
        assertFalse(r.humanEvidence)
        assertTrue("cell line evidence quality must be low", r.evidenceQualityScore <= 35)
    }

    @Test
    fun `unknown design with no species hint stays low confidence`() {
        val r = SourceClassifier.classifySource(
            "An interesting observation about something",
            emptyList()
        )
        assertEquals("unknown_design", r.studyDesign)
        assertEquals("unknown", r.speciesClass)
        assertEquals("unknown_metadata", r.sourceClass)
        assertFalse(r.humanEvidence)
    }
}
