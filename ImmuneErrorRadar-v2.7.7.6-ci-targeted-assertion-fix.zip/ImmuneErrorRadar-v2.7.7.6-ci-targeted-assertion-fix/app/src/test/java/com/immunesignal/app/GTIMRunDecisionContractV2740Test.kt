package com.immunesignal.app

import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue

class GTIMRunDecisionContractV2740Test {

    @Test
    fun covidKeepsCovidAnchorButAllowsDiscoveryBridges() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Covid immune disruption and long fatigue")
        assertEquals(GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL, c.primaryAnchor)
        assertTrue(c.allowedRoutes.contains("covid_interferon_cytokine_bridge"))
        assertTrue(c.allowedRoutes.contains("viral_to_neuroinflammation_fatigue_axis"))
        assertFalse(c.allowedRoutes.contains("allergy_type2_ige_mast_eosinophil"))
        assertTrue(c.forbiddenConflations.contains("allergy_type2_ige_mast_eosinophil"))
    }

    @Test
    fun allergyDoesNotBecomeCovid() {
        val c = GTIMRunDecisionContractFactoryV2740.build("الحساسية و IgE mast cells")
        assertEquals(GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL, c.primaryAnchor)
        assertTrue(c.allowedRoutes.contains("allergy_type2_to_barrier_immunity"))
        assertTrue(c.forbiddenConflations.contains("covid_interferon_cytokine_bridge"))
        val decision = GTIMRouteGovernanceV2740.evaluate(
            c,
            GTIMRouteGovernanceV2740.RouteCandidate(
                routeId = "covid_interferon_cytokine_bridge",
                candidateAnchor = GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL,
                sourceLayer = "test",
                reason = "shared cytokines"
            )
        )
        assertFalse(decision.allowed)
        assertEquals(GTIMRouteGovernanceV2740.RouteDecisionType.REJECT_IDENTITY_MUTATION, decision.decision)
    }

    @Test
    fun microbiomeDepressionExplicitBridgeIsAllowed() {
        val c = GTIMRunDecisionContractFactoryV2740.build("كيف بكتيريا الأمعاء تسبب الاكتئاب")
        assertEquals(GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION, c.primaryAnchor)
        assertTrue(c.allowedRoutes.contains("gut_microbiome_to_neuroinflammation"))
        assertTrue(c.allowedRoutes.contains("microbiome_tryptophan_serotonin_pathway"))
        assertFalse(c.allowedRoutes.contains("allergy_type2_ige_mast_eosinophil"))
    }

    @Test
    fun yeastEndocrineDiscoveryIsExploratoryNotCausal() {
        val c = GTIMRunDecisionContractFactoryV2740.build("هل خميرة الخبز تسبب التكيس و خمول الغدة")
        assertEquals(GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE, c.primaryAnchor)
        assertTrue(c.allowedRoutes.contains("yeast_fungal_to_endocrine_immune"))
        assertFalse(c.evidenceCaps.causalityClaimAllowed)
        assertTrue(c.forbiddenConflations.contains("direct_yeast_causes_pcos_strong_claim_without_evidence"))
    }

    @Test
    fun autonomousDiscoveryCanConnectFreely() {
        val c = GTIMRunDecisionContractFactoryV2740.build(
            rawQuery = "",
            inputMode = GTIMInputModeV2740.AUTONOMOUS_DISCOVERY
        )
        assertEquals(GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION, c.runMode)
        assertTrue(c.allowedRoutes.contains("gut_microbiome_to_neuroinflammation"))
        assertTrue(c.allowedRoutes.contains("yeast_fungal_to_endocrine_immune"))
        val decision = GTIMRouteGovernanceV2740.evaluate(
            c,
            GTIMRouteGovernanceV2740.RouteCandidate(
                routeId = "any_new_cross_domain_route",
                candidateAnchor = GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL,
                sourceLayer = "autonomous",
                reason = "free exploration"
            )
        )
        assertTrue(decision.allowed)
        assertEquals(GTIMEvidenceLabelV2740.SPECULATIVE_BRIDGE, decision.label)
    }

    @Test
    fun noAccessionCapsEvidence() {
        val c = GTIMRunDecisionContractFactoryV2740.build(
            rawQuery = "Covid immune disruption",
            hasDatasetAccessions = false,
            matrixState = "DGE_NOT_READY_NO_ACCESSION"
        )
        assertEquals(35, c.evidenceCaps.dataQualityMax)
        assertEquals(25, c.evidenceCaps.evidenceStrengthMax)
        assertFalse(c.evidenceCaps.causalityClaimAllowed)
    }
}
