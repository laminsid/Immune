package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for HypothesisRankingEngine.
 *
 * Validates the negative-control hard gate for STRONG_SIGNAL — a finding
 * with high score AND high repeatability must still be downgraded to WATCH
 * if its negative-control status is "control_required_before_strong".
 */
class HypothesisRankingEngineTest {

    private fun finding(
        axis: String,
        evidence: Int,
        causality: Int,
        novelty: Int,
        repeated: Int,
        negStatus: String
    ) = ResearchFinding(
        source = "PubMed",
        sourceId = axis + "_" + evidence + "_" + causality + "_" + negStatus,
        title = "Test finding for $axis",
        published = "2026",
        url = "https://example.test",
        matchedAxes = listOf(axis),
        noveltyScore = novelty,
        bridgeSignal = axis,
        whyItMatters = "test",
        evidence = EvidenceAssessment(
            sourceClass = "human_observational",
            speciesClass = "human",
            studyDesign = "human_cohort",
            humanEvidence = true,
            evidenceQualityScore = evidence,
            limitations = listOf("test")
        ),
        causality = CausalityAssessment(
            causalityScore = causality,
            temporalityScore = 50,
            biologicalPlausibilityScore = 60,
            measurableMarkerScore = 40,
            repeatabilityScore = repeated * 12,
            contradictionPenalty = 5,
            rationale = listOf("test")
        ),
        negativeControl = NegativeControlAssessment(
            status = negStatus,
            reverseTimeRisk = "test",
            shuffledTimelineRisk = "test",
            unrelatedMarkerRisk = "test",
            notes = listOf("test")
        ),
        personalPattern = PersonalPatternAssessment(
            repeatedObservationCount = repeated,
            temporalSupport = "test",
            strongestLocalAxes = listOf(axis),
            nextBestMeasurement = "Add dated entries."
        )
    )

    @Test
    fun `high score with passing negative control yields STRONG_SIGNAL`() {
        val ranked = HypothesisRankingEngine.rank(listOf(
            finding("psychoneuroimmune_axis", 88, 78, 70, 4, "watch_requires_controls")
        ))
        assertEquals(1, ranked.size)
        assertEquals("STRONG_SIGNAL", ranked.first().status)
    }

    @Test
    fun `high score blocked by control_required_before_strong drops to WATCH`() {
        // Identical to the STRONG case except the negative-control status.
        // This proves the hard gate works in v0.9.1+.
        val ranked = HypothesisRankingEngine.rank(listOf(
            finding("psychoneuroimmune_axis", 88, 78, 70, 4, "control_required_before_strong")
        ))
        assertEquals("WATCH", ranked.first().status)
    }

    @Test
    fun `low score never reaches STRONG_SIGNAL even with high repeats`() {
        val ranked = HypothesisRankingEngine.rank(listOf(
            finding("psychoneuroimmune_axis", 30, 25, 10, 5, "watch_requires_controls")
        ))
        assertTrue(
            "low-score finding must not be STRONG_SIGNAL",
            ranked.first().status in listOf("WEAK", "NOISE_OR_UNKNOWN")
        )
    }

    @Test
    fun `findings sort by overallScore descending`() {
        val ranked = HypothesisRankingEngine.rank(listOf(
            finding("axis_a", 40, 30, 30, 1, "weak_no_control_possible"),
            finding("axis_b", 88, 78, 70, 4, "watch_requires_controls"),
            finding("axis_c", 60, 55, 50, 2, "watch_requires_controls")
        ))
        for (i in 1 until ranked.size) {
            assertTrue(
                "ranking must be monotonically decreasing",
                ranked[i - 1].overallScore >= ranked[i].overallScore
            )
        }
        assertEquals("axis_b", ranked.first().hypothesisId)
    }

    @Test
    fun `empty input yields empty output`() {
        val ranked = HypothesisRankingEngine.rank(emptyList())
        assertTrue(ranked.isEmpty())
    }
}
