package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Test

class LearningDeltaEngineV12Test {
    @Test
    fun `previous status uses newest report first not oldest duplicate`() {
        val current = listOf(V12TestFixtures.objectCard(id = "h1", status = "WATCH"))
        val newestFirst = listOf(
            V12TestFixtures.previousReport("h1" to "WEAK"),
            V12TestFixtures.previousReport("h1" to "STRONG_SIGNAL")
        )
        val deltas = LearningDeltaEngine.build(current, newestFirst)
        assertEquals("WEAK", deltas.first().previousStatus)
    }

    @Test
    fun `new hypothesis object is detected`() {
        val current = listOf(V12TestFixtures.objectCard(id = "new", status = "WATCH"))
        val deltas = LearningDeltaEngine.build(current, emptyList())
        assertEquals("new_hypothesis_object", deltas.first().deltaType)
    }

    @Test
    fun `rank change with signal flip preserves both signals`() {
        val obj = V12TestFixtures.objectCard(id = "h1", status = "STRONG_SIGNAL").copy(signalFlip = "upgrade_candidate")
        val deltas = LearningDeltaEngine.build(listOf(obj), listOf(V12TestFixtures.previousReport("h1" to "WATCH")))
        assertEquals("rank_changed_with_upgrade_candidate", deltas.first().deltaType)
    }

    @Test
    fun `signal flip without rank change is reported`() {
        val obj = V12TestFixtures.objectCard(id = "h1", status = "WATCH").copy(signalFlip = "quality_stop")
        val deltas = LearningDeltaEngine.build(listOf(obj), listOf(V12TestFixtures.previousReport("h1" to "WATCH")))
        assertEquals("quality_stop", deltas.first().deltaType)
    }
}
