package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CognitiveNextCycleBridgeV166Test {
    @Test
    fun consumedDirectiveDoesNotReplayIntoQueries() {
        val directive = CognitiveNextCycleDirective(
            directiveId = "d_once",
            createdAtMillis = System.currentTimeMillis(),
            sourceCycleId = "cycle_a",
            state = "CONSUMED",
            decisionType = "CONTINUE_EVIDENCE_HUNT",
            routeIntegrity = "HIGH_ROUTE_FIT_REQUIRES_MINIMUM_METADATA",
            action = "Run follow-up once only.",
            reason = "single-use guard",
            nextSearchTerms = listOf("outcome", "recovery"),
            requiredEvidence = listOf("outcome_labels"),
            blockedClaims = defaultBlockedClaims(),
            priority = 90,
            expiresAtMillis = System.currentTimeMillis() + 60_000,
            consumedCount = 1,
            useLimit = 1
        )
        val base = listOf(ResearchQuery("q", "Q", "baseline immune query", "baseline"))
        val (queries, plan) = CognitiveNextCycleBridge.applyToQueries(base, directive, maxQueries = 4)
        assertEquals(base, queries)
        assertTrue(!plan.active)
        assertTrue(plan.suppressedReason?.contains("consumed", ignoreCase = true) == true)
    }

    @Test
    fun alreadyCoveredTermsDoNotInflateQueryBatch() {
        val directive = CognitiveNextCycleDirective(
            directiveId = "d_covered",
            createdAtMillis = System.currentTimeMillis(),
            sourceCycleId = "cycle_b",
            state = "ACTIVE",
            decisionType = "CONTINUE_EVIDENCE_HUNT",
            routeIntegrity = "HIGH_ROUTE_FIT_REQUIRES_MINIMUM_METADATA",
            action = "Do not duplicate terms.",
            reason = "query already contains the required evidence terms",
            nextSearchTerms = listOf("outcome", "recovery"),
            requiredEvidence = listOf("outcome_labels"),
            blockedClaims = defaultBlockedClaims(),
            priority = 80,
            expiresAtMillis = System.currentTimeMillis() + 60_000,
            consumedCount = 0,
            useLimit = 1
        )
        val base = listOf(ResearchQuery("q", "Q", "human immune outcome recovery severity endpoint", "baseline"))
        val (queries, plan) = CognitiveNextCycleBridge.applyToQueries(base, directive, maxQueries = 4)
        assertEquals(base, queries)
        assertTrue(!plan.active)
        assertTrue(plan.directiveConsumed)
        assertTrue(plan.consumptionReason?.contains("retired", ignoreCase = true) == true)
        assertTrue(plan.suppressedReason?.contains("already covered", ignoreCase = true) == true)
    }

    @Test
    fun routingFingerprintIgnoresSourceCycleForReplayDetection() {
        val a = CognitiveNextCycleDirective(
            directiveId = "a",
            createdAtMillis = 1L,
            sourceCycleId = "cycle_1",
            state = "CONSUMED",
            decisionType = "CONTINUE_EVIDENCE_HUNT",
            routeIntegrity = "ROUTE",
            action = "action",
            reason = "reason",
            nextSearchTerms = listOf("RNA-seq", "outcome"),
            requiredEvidence = listOf("minimum_metadata"),
            blockedClaims = defaultBlockedClaims(),
            priority = 70,
            expiresAtMillis = Long.MAX_VALUE,
            consumedCount = 1,
            useLimit = 1
        )
        val b = a.copy(directiveId = "b", sourceCycleId = "cycle_2", consumedCount = 0, state = "ACTIVE")
        assertTrue(CognitiveNextCycleBridge.sameRoutingFingerprint(a, b))
    }

    @Test
    fun invalidDirectiveWithoutTermsIsRetired() {
        val directive = CognitiveNextCycleDirective(
            directiveId = "d_empty",
            createdAtMillis = System.currentTimeMillis(),
            sourceCycleId = "cycle_empty",
            state = "ACTIVE",
            decisionType = "CONTINUE_EVIDENCE_HUNT",
            routeIntegrity = "ROUTE",
            action = "No terms should not replay forever.",
            reason = "empty directive",
            nextSearchTerms = emptyList(),
            requiredEvidence = emptyList(),
            blockedClaims = defaultBlockedClaims(),
            priority = 50,
            expiresAtMillis = System.currentTimeMillis() + 60_000,
            consumedCount = 0,
            useLimit = 1
        )
        val base = listOf(ResearchQuery("q", "Q", "baseline immune query", "baseline"))
        val (queries, plan) = CognitiveNextCycleBridge.applyToQueries(base, directive, maxQueries = 4)
        assertEquals(base, queries)
        assertTrue(!plan.active)
        assertTrue(plan.directiveConsumed)
        assertEquals("retired_noop_or_already_satisfied", plan.consumptionReason)
    }

}
