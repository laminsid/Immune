package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMAccessionSeedCaptureV260Test {
    @Test
    fun gseSeedIsCapturedWithoutMatrixOrComparatorAndDoesNotBecomeEvidenceClaim() {
        val steering = ResearchSteeringProfile(
            profileId = "gse152202_seed_test",
            createdAtMillis = 0L,
            variables = listOf("GSE152202", "Long COVID", "EBV", "IL-6", "TNF"),
            focusQuestion = "Use GSE152202 as a GEO seed for EBV/HHV-6 Long COVID IL-6 TNF PBMC RNA-seq comparator lookup.",
            requiredTerms = listOf("GSE152202"),
            excludedTerms = emptyList(),
            inferredAxes = listOf("viral immune response")
        )

        val report = ResearchGradeMechanismDossierV1110.evaluate(
            steering = steering,
            matrix = MetadataClosureStrategyMatrixReport.empty().copy(hyperDriveModeActive = true),
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            leadObjects = emptyList(),
            attempts = emptyList()
        )

        val gtim = report.globalTranslationalDossier
        assertTrue(gtim.accessionSeedCapture.active)
        assertEquals("ACCESSION_SEED_CAPTURED_MATRIX_PENDING", gtim.accessionSeedCapture.status)
        assertEquals("GSE152202", gtim.accessionSeedCapture.primarySeed)
        assertTrue(gtim.accessionSeedCapture.accessionCountForBrief >= 1)
        assertTrue(gtim.evidenceObjects.any { it.accessionId == "GSE152202" && it.evidenceStrength.contains("SEED_NOT_EVIDENCE") })
        assertTrue(gtim.discoveryEvidenceSplit.candidateRoutes.isNotEmpty())
        assertTrue(gtim.accessionSeedCapture.capturedSeeds.first().routeState == "ROUTE_UNRESOLVED_METADATA_PENDING")
        assertTrue(gtim.accessionSeedCapture.upgradePolicy.contains("not evidence", ignoreCase = true))
    }
}
