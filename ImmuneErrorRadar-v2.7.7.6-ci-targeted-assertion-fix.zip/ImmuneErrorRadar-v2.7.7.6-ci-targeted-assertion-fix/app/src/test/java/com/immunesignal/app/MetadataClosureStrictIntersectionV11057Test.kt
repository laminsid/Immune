package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MetadataClosureStrictIntersectionV11057Test {
    @Test
    fun neuroViralBridgeForcesRouteFitFloorAndAccessionPatternStreams() {
        val candidate = DatasetAccessionCandidate(
            accession = "MANUAL_TEXT_SNIPPET_1393bf01b3cd8b15_0",
            source = "MANUAL_EVIDENCE_SEED_MODE",
            organismHint = "human cohort",
            conditionLabelsHint = "EBV reactivation SLE flare ME/CFS",
            outcomeLabelsHint = "response nonresponse fatigue severity",
            triggerResponseOutcomeHint = "transcriptome RNA-seq data availability",
            timeCourseHint = "longitudinal baseline follow-up",
            sampleSizeHint = "unknown",
            dataType = "transcriptome RNA-seq",
            usabilityScore = 10,
            status = "OFF_ROUTE_USEFUL_DATASET",
            sourceFindingId = "manual_1393bf01b3cd8b15_0",
            sourceTitle = "Manual snippet: EBV SLE ME/CFS transcriptome RNA-seq accession pattern hunt",
            sourceUrl = "",
            reasons = listOf("WEAK_DATASET_LEAD", "OFF_ROUTE")
        )

        val report = MetadataClosureStrategyMatrixV11057.evaluate(
            steering = ResearchSteeringProfile(
                profileId = "v11057-test",
                createdAtMillis = 0L,
                variables = listOf("EBV", "SLE", "ME/CFS", "transcriptome", "RNA-seq"),
                focusQuestion = "manual snippet EBV HHV-6 SLE MS ME/CFS transcriptome RNA-seq GSE PRJNA",
                requiredTerms = listOf("GSE[0-9]*", "PRJNA[0-9]*"),
                excludedTerms = emptyList(),
                inferredAxes = listOf("neuro_viral_bridge")
            ),
            leadObjects = emptyList(),
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            attempts = emptyList(),
            topicFit = TopicFitMetadataParseReport.empty().copy(active = true, forcedMinimumMetadataCount = 1),
            metadataClosure = MetadataClosureReport.empty().copy(active = true, state = "METADATA_CLOSURE_INCOMPLETE"),
            recentReports = emptyList()
        )

        val rule1 = report.crossReferenceMatrix.first { it.ruleId == "R1_NEURO_VIRAL_BRIDGE" }
        assertTrue(rule1.verified)
        assertEquals(95, rule1.routeFitFloor)
        assertTrue(report.routeFitBoostScore >= 95)
        assertTrue(report.validationEmbargoBypassScope.contains("METADATA_PROBE"))
        assertTrue(report.queryStreams.any { it.streamId == "GEO_STRICT_NEURO_VIRAL_ACCESSION_PATTERN" && it.query.contains("GSE[0-9]*") })
        assertTrue(report.queryStreams.any { it.streamId == "HYPER_ALPHA_GEO_GDS_NEURO_VIRAL_DATA_AVAILABILITY" && it.query.contains("Data Availability") })
        assertTrue(report.hyperDriveModeActive)
        assertTrue(report.criticalUsabilityAnomaly)
        assertTrue(report.queryStreams.any { it.streamId == "SRA_STRICT_NEURO_VIRAL_ACCESSION_PATTERN" && it.query.contains("PRJNA[0-9]*") })
        assertTrue(report.leanRuntimeLogicGates.any { it.gateId == "G6_NEURO_VIRAL_STRICT_INTERSECTION_ELEVATION" })
    }

    @Test
    fun psychophysiologicalExposomeUnlocksAggressiveQueryStream() {
        val report = MetadataClosureStrategyMatrixV11057.evaluate(
            steering = ResearchSteeringProfile(
                profileId = "v11057-exposome-test",
                createdAtMillis = 0L,
                variables = listOf("HPA-axis", "Cortisol/DHEA", "Sleep-deprivation", "IFN-alpha", "IL-6", "TNF-alpha"),
                focusQuestion = "HPA-axis Cortisol/DHEA Sleep-deprivation IFN-alpha IL-6 TNF-alpha transcriptome RNA-seq",
                requiredTerms = listOf("GSE[0-9]*", "PRJNA[0-9]*"),
                excludedTerms = emptyList(),
                inferredAxes = listOf("psychophysiological_exposome")
            ),
            leadObjects = emptyList(),
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            attempts = listOf(DatasetSourceAttempt("MANUAL_EVIDENCE_SEED_MODE", "manual", "HPA-axis IL-6 transcriptome GSE PRJNA", true, 0, 0, "EXPLORATORY", "test")),
            topicFit = TopicFitMetadataParseReport.empty().copy(active = true, forcedMinimumMetadataCount = 1),
            metadataClosure = MetadataClosureReport.empty().copy(active = true, state = "METADATA_CLOSURE_INCOMPLETE"),
            recentReports = emptyList()
        )

        val rule2 = report.crossReferenceMatrix.first { it.ruleId == "R2_PSYCHEPHYSIOLOGICAL_EXPOSOME" }
        assertTrue(rule2.verified)
        assertTrue(report.aggressiveQueryStreamUnlocked)
        assertTrue(report.queryStreams.any { it.streamId == "AGGRESSIVE_GEO_EXPOSOME_CYTOKINE_STREAM" && it.query.contains("GSE[0-9]*") })
        assertTrue(report.queryStreams.any { it.streamId == "AGGRESSIVE_SRA_EXPOSOME_CYTOKINE_STREAM" && it.query.contains("SRP[0-9]*") })
        assertTrue(report.queryStreams.any { it.streamId == "HYPER_BETA_GEO_GDS_EXPOSOME_MODULATOR_ACCESSION" && it.query.contains("Curcumin") })
        assertTrue(report.hyperDriveModeActive)
        assertTrue(report.leanRuntimeLogicGates.any { it.gateId == "G7_PSYCHEPHYSIOLOGICAL_EXPOSOME_AGGRESSIVE_STREAM" })
    }
}
