package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMUnifiedRouteLearningClosureV268Test {
    @Test
    fun fullExploratoryQuestionClosesUnifiedRouteLearningCycle() {
        val report = GTIMUnifiedRouteLearningClosureV268.verify(
            "Compare Long COVID EBV interferon with cancer HIV fungal pandemic response plus gut microbiome hormones pesticide residues antibiotics poultry heavy metals drinking water and microplastics BPA PFAS using Europe PMC OpenAlex GSE PRJNA comparator data availability"
        )

        assertTrue(report.active)
        assertEquals("UNIFIED_ROUTE_LEARNING_CYCLE_CLOSED", report.closureState)
        assertTrue(report.versionUnified)
        assertTrue(report.versionName.contains("2.7.3"))
        assertTrue(report.engineVersion.contains("2.7.3"))
        assertEquals("2.7.3", report.learningSchemaVersion)
        assertTrue(report.parserLinked)
        assertTrue(report.plannerLinked)
        assertTrue(report.europePmcLinked)
        assertTrue(report.openAlexLinked)
        assertTrue(report.seedBootstrapLinked)
        assertTrue(report.comparativeLinked)
        assertTrue(report.exposomeLinked)
        assertTrue(report.learningLoopLinked)
        assertTrue(report.claimGuardLinked)
        assertTrue(report.claimLimit.contains("not_biological_proof"))
    }
}
