package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GlobalResearchGradeBriefPriorSeedMaterializationV2687Test {
    @Test
    fun runtimeBriefMaterializesKnownPriorSeedsAsLookupHandlesNotEvidence() {
        val mechanism = JSONObject()
            .put("state", "DATASET_HUNT")
            .put("bestResearchLeadSummary", "Stress/sleep/HPA context may stratify latent-virus immune transcriptional states")
            .put("matrixAnalysisGate", "DGE_NOT_READY")
        val matrix = JSONObject()
            .put("detectedTargets", JSONArray(listOf("SARS-CoV-2_LONG_COVID", "SLE", "RA", "IL6_TNF", "RITUXIMAB_CONTROL")))
            .put("runtimeDataDemand", JSONArray(listOf("Europe PMC", "OpenAlex", "Data Availability", "GSE1665520")))
        val report = JSONObject()
            .put("runtime", JSONObject().put("engineVersion", "v2.7.3-final-proof-benchmark-learning-locked").put("researchState", "DATASET_HUNT"))
            .put("executionLock", JSONObject().put("status", "PASS"))
            .put("mechanismDiscoveryDossier", mechanism)
            .put("metadataClosureStrategyMatrix", matrix)
            .put("v3Report", JSONObject().put("counterEvidenceOrContradiction", "Route counter-signal: GSE1665520 is OFF_ROUTE_DATASET; dataset route unknown_route"))

        val lines = GlobalResearchGradeBriefV11061.renderLines(report)
        val text = lines.joinToString("\n")
        assertTrue(text.contains("Seed handles queued"))
        assertTrue(text.contains("PMID:22114171") || text.contains("22114171"))
        assertTrue(text.contains("GSE166552"))
        assertFalse(text.contains("accessions=0"))
        assertFalse(text.contains("routes=0"))
        assertTrue(text.contains("lookup-only; not evidence or gate closure"))
    }
}
