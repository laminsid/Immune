package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMFinalIntegrationClosureV259Test {
    @Test
    fun finalClosurePassesWhenAllGtimSurfacesAreConnected() {
        val intent = GTIMResearchIntentParserV255.parse(
            """
            Disease / phenotype: Long COVID fatigue
            Trigger: EBV or HHV-6 reactivation
            Pathway: interferon signaling, IL-6, TNF
            Cell / tissue: PBMC, T cells, B cells
            Comparator: Long COVID vs recovered controls vs healthy controls
            Assay: RNA-seq, scRNA-seq, cytokine profiling
            Repositories: GEO, SRA, ArrayExpress, ImmPort
            Contradiction: no association or opposite cytokine direction
            Output: discovery brief, no raw JSON
            """.trimIndent()
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        val report = ResearchGradeMechanismDossierReportV1110.empty().copy(active = true, researchQuestion = intent.sourceText)
        val split = GTIMDiscoveryEvidenceSplitV256.evaluate(intent, plan, report, emptyList(), emptyList())
        val routeIntegrity = GTIMRouteIntegrityReportV251(
            passed = true,
            status = "GTIM_ROUTE_CONNECTED_WITH_METADATA_ANCHOR",
            bridgePath = listOf("ResearchIntent", "DataFeedPlan", "CandidateRoutes"),
            connectedSurfaces = listOf("JSON", "Brief", "Dashboard"),
            requiredAnchors = listOf("parsed intent", "repository plan"),
            brokenLinks = emptyList(),
            weakLeadProtection = "candidate route remains non-evidence",
            playProtectPosture = "no hidden background scraping",
            githubCiPosture = "audit visible",
            nextRepairAction = "none"
        )
        val feed = GTIMOpenDiscoveryDataFeedingV254.evaluate(report, emptyList(), emptyList(), routeIntegrity)
        val dashboard = GTIMProfessorDiscoveryDashboardV257.build(intent, plan, split, feed)
        val brief = GTIMIntentAwareBriefRendererV255.render(intent, plan, split, dashboard)
        val resolver = GTIMOpenDataResolverV256.plan(plan, feed, dashboard)
        val graph = GTIMVisualKnowledgeGraphV257.build(intent, split, dashboard)
        val surface = GTIMReleaseSurfaceHardeningReportV252(
            passed = true,
            status = "GTIM_RELEASE_SURFACE_HARDENED",
            androidReleaseTrain = RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME,
            gtimProductEngineVersion = GTIMReleaseSurfaceHardeningV252.GTIM_PRODUCT_ENGINE_VERSION,
            verifiedSurfaces = listOf("JSON", "Brief", "Dashboard"),
            blockingIssues = emptyList(),
            playProtectPosture = "safe",
            githubPosture = "safe",
            scientificClaimPosture = "claim safe",
            nextAction = "none"
        )
        val closure = GTIMFinalIntegrationClosureV259.evaluate(intent, plan, split, feed, dashboard, brief, resolver, graph, surface)
        assertTrue(closure.passed)
        assertEquals(GTIMFinalIntegrationClosureV259.STATUS_PASS, closure.status)
        assertTrue(closure.verifiedModules.any { it.contains("GTIMResearchIntentParserV255") })
        assertTrue(closure.finalReportContract.any { it.contains("What the app understood") })
        assertTrue(closure.evidenceSafetyContract.any { it.contains("Semantic prior is never an expression matrix") })
        assertTrue(closure.nonUnknownRuntimeContract.any { it.contains("never `unknown`") })
    }

    @Test
    fun finalClosureFailsWhenDatafeedIsNotVisible() {
        val intent = GTIMResearchIntentObjectV255.empty()
        val closure = GTIMFinalIntegrationClosureV259.evaluate(
            researchIntent = intent,
            dataFeedPlan = GTIMDataFeedPlanV255.empty(),
            discoveryEvidenceSplit = GTIMDiscoveryEvidenceSplitReportV256.empty(),
            openDiscoveryDataFeed = GTIMOpenDiscoveryDataFeedReportV254.empty(),
            professorDashboard = GTIMProfessorDiscoveryDashboardReportV257.empty(),
            intentAwareBrief = GTIMIntentAwareBriefReportV255.empty(),
            openDataResolver = GTIMOpenDataResolverReportV256.empty(),
            visualKnowledgeGraph = GTIMVisualKnowledgeGraphReportV257.empty(),
            releaseSurfaceHardening = GTIMReleaseSurfaceHardeningReportV252(
                passed = false,
                status = "GTIM_RELEASE_SURFACE_REPAIR_REQUIRED",
                androidReleaseTrain = RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME,
                gtimProductEngineVersion = GTIMReleaseSurfaceHardeningV252.GTIM_PRODUCT_ENGINE_VERSION,
                verifiedSurfaces = emptyList(),
                blockingIssues = listOf("not evaluated"),
                playProtectPosture = "not evaluated",
                githubPosture = "not evaluated",
                scientificClaimPosture = "not evaluated",
                nextAction = "repair"
            )
        )
        assertTrue(!closure.passed)
        assertEquals(GTIMFinalIntegrationClosureV259.STATUS_REPAIR, closure.status)
        assertTrue(closure.remainingRisks.any { it.contains("data-feed", ignoreCase = true) })
    }
}
