package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMAccessionMatrixNegativeTokenHardeningV2763Test {

    @Test
    fun negativeMatrixGapTextDoesNotBecomeMatrixLinkFound() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_METADATA_GAP")
                .put("blockingGaps", JSONArray().put("MATRIX_FILE_NOT_READY:: raw/count expression matrix or supplementary matrix link is not verified"))
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202"),
            paperUnderstandingSummary = "GSE152202 SARS-CoV-2 PBMC patient sample metadata data availability"
        )
        assertEquals("GSE152202", card.targetId)
        assertFalse(card.datasetObjectState == "MATRIX_LINK_FOUND")
        assertFalse(card.evidenceUpgradeState == "EVIDENCE_CANDIDATE")
        assertTrue(card.blockingGaps.any { it.contains("MATRIX", ignoreCase = true) })
        assertFalse(card.matrixState == "DGE_NOT_READY_NO_ACCESSION")
    }

    @Test
    fun explicitRawCountsComparatorAndReadyTokensStillReachReviewOnly() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            rawQuery = "Covid",
            hasDatasetAccessions = true,
            matrixState = "DGE_READY"
        )
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_READY")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202"),
            paperUnderstandingSummary = "GSE152202 COVID healthy control comparator raw counts expression matrix DGE ready sample traits"
        )
        assertEquals("DGE_READY", card.matrixState)
        assertEquals("STRONG_SIGNAL_REVIEW_ONLY", card.evidenceUpgradeState)
    }

    @Test
    fun covidForeignFungalTermRequiresContractPermission() {
        val covid = GTIMRunDecisionContractFactoryV2740.build("Covid", GTIMInputModeV2740.USER_QUERY)
        val covidLead = GTIMNovelSignalCaptureV2756.capture("Covid endothelial candida signal", covid)
        assertTrue(covidLead.termSignals.any { it.term == "endothelial" && it.signalClass == GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION })
        assertTrue(covidLead.termSignals.any { it.term == "candida" && it.signalClass == GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE })

        val comparison = GTIMRunDecisionContractFactoryV2740.build("Allergy vs bacteria vs fungi", GTIMInputModeV2740.USER_QUERY)
        val comparisonLead = GTIMNovelSignalCaptureV2756.capture("allergy barrier candida fungal signal", comparison)
        assertFalse(comparisonLead.termSignals.any { it.term == "candida" && it.signalClass == GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE })
    }
}
