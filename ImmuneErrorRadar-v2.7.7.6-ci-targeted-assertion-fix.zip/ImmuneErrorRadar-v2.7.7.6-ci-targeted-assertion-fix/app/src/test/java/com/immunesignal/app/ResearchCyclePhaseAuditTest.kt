package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchCyclePhaseAuditTest {
    @Test
    fun blocksRuntimeFailoverUnderSameCycleClosureLock() {
        val prior = ResearchSearchDirective.none(baseMaxQueries = 4, baseResultsPerQuery = 10)
        val closure = ResearchSearchDirective(
            active = true,
            mode = "SAME_CYCLE_ACCESSION_CLOSURE",
            governingLayer = "evidence_closure_same_cycle",
            queries = listOf(query("q_v204_closure")),
            reason = "dataset candidate requires closure",
            maxQueries = 1,
            maxResultsPerQuery = 3,
            blockDatasetFirst = true,
            trace = listOf("test")
        )

        val report = ResearchCyclePhaseAuditEngine.build(
            priorDirective = prior,
            postForagerDirective = closure,
            datasetFirstRequested = true,
            runtimeFailoverAttempted = false,
            executedQueryIds = listOf("q_v204_closure"),
            findingsCount = 1,
            rankedCount = 1,
            runtimeDiagnostics = emptyList(),
            stopped = false,
            stopReason = "completed"
        )

        assertEquals("LOCKED_NARROW", report.state)
        assertTrue(report.runtimeFailoverBlocked)
        assertTrue(report.lockViolations.isEmpty())
        assertEquals("evidence_closure_same_cycle", report.governingLayer)
    }

    @Test
    fun reportsViolationWhenFailoverRunsUnderActiveLock() {
        val prior = ResearchSearchDirective.none(baseMaxQueries = 4, baseResultsPerQuery = 10)
        val closure = ResearchSearchDirective(
            active = true,
            mode = "SAME_CYCLE_ACCESSION_CLOSURE",
            governingLayer = "evidence_closure_same_cycle",
            queries = listOf(query("q_v204_closure")),
            reason = "dataset candidate requires closure",
            maxQueries = 1,
            maxResultsPerQuery = 3,
            blockDatasetFirst = true,
            trace = listOf("test")
        )

        val report = ResearchCyclePhaseAuditEngine.build(
            priorDirective = prior,
            postForagerDirective = closure,
            datasetFirstRequested = true,
            runtimeFailoverAttempted = true,
            executedQueryIds = listOf("q_v204_closure", "q_runtime_dataset_accession"),
            findingsCount = 0,
            rankedCount = 0,
            runtimeDiagnostics = emptyList(),
            stopped = false,
            stopReason = "completed"
        )

        assertEquals("LOCK_VIOLATION", report.state)
        assertTrue(report.lockViolations.any { it.contains("RUNTIME_FAILOVER_RAN_DESPITE_ACTIVE_SEARCH_LOCK") })
    }


    @Test
    fun allowsDatasetFirstWhenDatasetHuntUnlockApplied() {
        val prior = ResearchSearchDirective(
            active = true,
            mode = "THINK_FIRST_SINGLE_DISCRIMINATOR",
            governingLayer = "linked_cognition_spine",
            queries = listOf(query("q_v200_spine_lock_outcome_labels")),
            reason = "THINK_FIRST before network search",
            maxQueries = 1,
            maxResultsPerQuery = 3,
            blockDatasetFirst = true,
            trace = listOf("linked spine active")
        )
        val postForager = prior.copy(
            active = false,
            mode = "EVIDENCE_FIRST_FORAGER_EXECUTED",
            governingLayer = "dataset_hunt_unlock",
            queries = emptyList(),
            maxQueries = 0,
            maxResultsPerQuery = 0,
            blockDatasetFirst = false,
            trace = prior.trace + "dataset_hunt_unlock:allow_accession_search_only"
        )

        val report = ResearchCyclePhaseAuditEngine.build(
            priorDirective = prior,
            postForagerDirective = postForager,
            datasetFirstRequested = true,
            datasetFirstUnlockApplied = true,
            runtimeFailoverAttempted = false,
            executedQueryIds = listOf("q_v142_geo_gds"),
            findingsCount = 0,
            rankedCount = 0,
            runtimeDiagnostics = emptyList(),
            stopped = false,
            stopReason = "completed"
        )

        assertTrue(report.lockViolations.isEmpty())
        assertEquals(false, report.datasetFirstBlocked)
        assertTrue(report.phases.any { it.phase == "DATASET_FORAGING" && it.owner == "dataset_hunt_unlock" && it.decision == "EVIDENCE_FIRST_DATASET_UNLOCK" })
    }

    private fun query(id: String) = ResearchQuery(
        id = id,
        label = id,
        query = "GSE250594 outcome labels metadata",
        reason = "test closure query"
    )
}
