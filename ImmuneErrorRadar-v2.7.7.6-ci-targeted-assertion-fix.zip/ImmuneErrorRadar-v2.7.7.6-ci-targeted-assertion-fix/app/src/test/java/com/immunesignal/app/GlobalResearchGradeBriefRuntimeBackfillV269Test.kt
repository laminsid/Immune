package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GlobalResearchGradeBriefRuntimeBackfillV269Test {
    @Test
    fun briefBackfillsPublicDataChannelsWhenGtimJsonIsMissing() {
        val report = JSONObject()
            .put("runtime", JSONObject()
                .put("engineVersion", "v2.7.3-final-proof-benchmark-learning-locked")
                .put("researchState", "DATASET_HUNT"))
            .put("executionLock", JSONObject().put("status", "PASS"))
            .put("metadataClosureStrategyMatrixReport", JSONObject()
                .put("active", true)
                .put("detectedTargets", JSONArray(listOf("HHV-6", "SLE", "RA", "IL6_TNF", "RITUXIMAB_CONTROL")))
                .put("runtimeDataDemand", JSONArray(listOf("Need public accession lookup and comparator metadata")))
                .put("queryStreams", JSONArray().put(JSONObject()
                    .put("sourceFamily", "PUBMED_ACCESSION_MINING")
                    .put("query", "HHV-6 SLE RA IL6 TNF rituximab control data availability GSE PRJNA"))))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("active", true)
                .put("state", "DATASET_HUNT")
                .put("researchQuestion", "Stress sleep HPA latent virus immune transcriptional states HHV-6 SLE RA IL6 TNF rituximab control")
                .put("bestResearchLeadSummary", "Metadata Closure Strategy Matrix: Stress/sleep/HPA context may stratify latent-virus immune transcriptional states")
                .put("evidenceGrade", "E+ — early exploratory signal; keep if route is scientifically interesting")
                .put("matrixAnalysisGate", "DGE_NOT_READY")
                .put("blockingGaps", JSONArray(listOf("accession", "comparator", "matrix", "metadata")))
                .put("globalTranslationalDossier", JSONObject()))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertFalse(rendered.contains("no public data channel was surfaced"))
        assertTrue(rendered.contains("Runtime data-feed route"))
        assertTrue(rendered.contains("Europe PMC") || rendered.contains("OpenAlex") || rendered.contains("GEO/GDS"))
        assertTrue(rendered.contains("Best query to run"))
        assertFalse(rendered.contains("Intent 0/100"))
        assertFalse(rendered.contains("Data-feed 0/100"))
    }
}
