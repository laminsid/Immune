package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SourcePriorityDomainExpertiseV11019Test {
    @Test
    fun sourcePriorityReturnsMissingCoreBeforeControlAfterSecondaryTouched() {
        val next = SourcePriorityArbitrationPolicy.nextSourceAfterNoCandidateSequence(
            listOf("GEO_GDS", "PUBMED_ADJACENT_DOMAIN_MINING", "PUBMED_CONTRADICTION")
        )

        assertEquals("SRA_PRJNA", next)
        assertTrue(SourcePriorityArbitrationPolicy.CLAIM_LIMIT.endsWith("not_biological_proof"))
    }


    @Test
    fun sourcePriorityTreatsLeadObjectLookupAsFollowUpNotSourceRotation() {
        val summary = SourcePriorityArbitrationPolicy.summary(
            listOf("GEO_GDS", "SRA_PRJNA", "IMM_PORT_SDY", "PUBMED_ACCESSION_MINING"),
            "LEAD_OBJECT_SECONDARY_LOOKUP"
        )

        assertTrue(SourcePriorityArbitrationPolicy.isLeadObjectFollowUp("LEAD_OBJECT_SECONDARY_LOOKUP"))
        assertTrue(summary.contains("leadFollowUp=LEAD_OBJECT_SECONDARY_LOOKUP"))
        assertTrue(summary.contains("nextSource=not_applicable_until_lead_lookup_finishes"))
    }

    @Test
    fun domainExpertiseStabilizesAntihistamineAndInflammationWithoutClaims() {
        val attempts = listOf(
            DatasetSourceAttempt(
                sourceFamily = "PUBMED_ADJACENT_DOMAIN_MINING",
                ncbiDb = "pubmed",
                query = "human antihistamine histamine mast cell inflammatory disease transcriptome outcome dataset",
                attempted = true,
                idsFound = 3,
                candidatesExtracted = 0,
                status = "PUBMED_EVIDENCE_INSPECTED_NO_DATASET_LEAD",
                reason = "research-only adjacent-domain mining"
            )
        )
        val queries = listOf(
            ResearchQuery(
                id = "q_test_domain_expertise",
                label = "domain expertise test",
                query = attempts.first().query,
                reason = "no treatment, no dose, no clinical recommendation"
            )
        )

        val report = DomainExpertiseMemoryPolicy.build(
            attempts = attempts,
            queries = queries,
            candidates = emptyList(),
            parsedMetadata = emptyList()
        )

        assertTrue(report.active)
        assertTrue(report.cards.any { it.domainId == "antihistamine_histamine_mast_cell" })
        assertTrue(report.cards.any { it.domainId == "inflammatory_disease_chronic_inflammation" })
        assertTrue(report.cards.all { it.claimLimit == DomainExpertiseMemoryPolicy.CLAIM_LIMIT })
        assertTrue(report.summary.contains("research prior", ignoreCase = true))
    }
}
