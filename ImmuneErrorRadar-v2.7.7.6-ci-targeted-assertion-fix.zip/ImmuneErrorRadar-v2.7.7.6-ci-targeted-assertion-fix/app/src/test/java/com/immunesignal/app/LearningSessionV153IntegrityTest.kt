package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningSessionV153IntegrityTest {
    @Test
    fun integrityGuardAddsMissingPhasesAndPausesPersistedInProgressSession() {
        val partial = LearningSession(
            sessionId = "session_test",
            sessionType = SessionType.INCREMENTAL,
            startedAt = 1000L,
            status = SessionStatus.IN_PROGRESS,
            timeLimit = RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS,
            phases = listOf(
                PhaseState("FAILURE_ANALYSIS", PhaseStatus.COMPLETED, 100)
            ),
            checkpoint = SessionCheckpoint(
                lastPhaseCompleted = "FAILURE_ANALYSIS",
                lastDataProcessed = null,
                pendingPhases = emptyList(),
                canResume = true,
                savedAt = 2000L
            ),
            claimLimits = emptyMap(),
            accumulatedTimeUsed = 3000L
        )

        val normalized = LearningSessionIntegrityGuard.normalize(partial)

        assertEquals(SessionStatus.PAUSED, normalized.status)
        assertEquals(4, normalized.phases.size)
        assertTrue(normalized.checkpoint.canResume)
        assertTrue(normalized.checkpoint.pendingPhases.contains("INTERACTION_DETECTION"))
        assertEquals("memory_only_not_biological_proof", normalized.claimLimits["failures"])
    }

    @Test
    fun completedAllPhasesCannotResume() {
        val completedPhases = LearningSessionIntegrityGuard.expectedPhaseNames.map {
            PhaseState(it, PhaseStatus.COMPLETED, 100)
        }
        val session = LearningSession(
            sessionId = "session_done",
            sessionType = SessionType.INCREMENTAL,
            startedAt = 1000L,
            status = SessionStatus.PAUSED,
            timeLimit = RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS,
            phases = completedPhases,
            checkpoint = SessionCheckpoint(null, null, emptyList(), true, 2000L),
            claimLimits = emptyMap(),
            accumulatedTimeUsed = 5000L
        )

        val normalized = LearningSessionIntegrityGuard.normalize(session)
        val report = LearningSessionIntegrityGuard.validationReport(normalized)

        assertEquals(SessionStatus.COMPLETED, normalized.status)
        assertFalse(normalized.checkpoint.canResume)
        assertTrue(report.optBoolean("ok"))
    }
}
