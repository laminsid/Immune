package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AutoLearningContinuationV158Test {
    private fun nickelCandidate() = DatasetAccessionCandidate(
        accession = "GSE250594",
        source = "GEO/NCBI",
        organismHint = "human_candidate",
        conditionLabelsHint = "allergy/contact-dermatitis/skin labels candidate",
        outcomeLabelsHint = "unknown",
        triggerResponseOutcomeHint = "nickel patch test allergen response",
        timeCourseHint = "unknown",
        sampleSizeHint = "20 participants",
        dataType = "single-cell transcriptomics",
        usabilityScore = 62,
        status = "PARTIAL_LEAD_NEEDS_METADATA",
        sourceFindingId = "NCBI_GEO_GDS:GSE250594",
        sourceTitle = "GSE250594 — Single cell analysis of clinically resolved epidermal skin from nickel-challenged individuals treated with anakinra or placebo",
        sourceUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE250594",
        reasons = emptyList()
    )

    @Test
    fun highRouteFitDirectAccessionForcesMinimumMetadataParse() {
        val candidate = nickelCandidate()
        val triage = TriageResult(
            accession = candidate.accession,
            usefulnessScore = 54,
            routeFitPrediction = "IN_ROUTE",
            likelyFailureModes = listOf("NO_OUTCOME_LABELS", "METADATA_ONLY"),
            action = "LOW_PRIORITY",
            mlConfidence = 75,
            reason = "Cautious triage."
        )
        val routeFit = DatasetRouteFitAssessment(
            accession = candidate.accession,
            datasetRoute = "allergy_contact_dermatitis_il1_skin",
            targetRoute = "allergy_contact_dermatitis_il1_skin",
            routeFitScore = 92,
            status = "IN_ROUTE",
            allowedUse = "Allowed for dataset inspection.",
            blocksHypothesisUpgrade = false,
            reasons = emptyList()
        )

        val report = CandidateActionResolver.resolve(listOf(candidate), listOf(triage), listOf(routeFit))

        assertEquals(listOf("GSE250594"), report.minimumMetadataAccessions)
        assertEquals(CandidateAction.PARSE_MINIMUM_METADATA, report.decisions.first().action)
        assertTrue(report.decisions.first().forcesMinimumMetadata)
        assertEquals("candidate_action_not_biological_proof", report.claimLimit)
    }

    @Test
    fun minimumMetadataParserCreatesVisibleMetadataObject() {
        val candidate = nickelCandidate()
        val actionReport = CandidateActionResolver.resolve(
            candidates = listOf(candidate),
            triageResults = listOf(
                TriageResult(candidate.accession, 54, "IN_ROUTE", listOf("NO_OUTCOME_LABELS"), "LOW_PRIORITY", 70, "Cautious triage.")
            ),
            routeFits = listOf(
                DatasetRouteFitAssessment(candidate.accession, "allergy_contact_dermatitis_il1_skin", "allergy_contact_dermatitis_il1_skin", 92, "IN_ROUTE", "Allowed", false, emptyList())
            )
        )

        val parsed = MinimumMetadataParser.parse(listOf(candidate), emptyList(), actionReport)

        assertTrue(parsed.any { it.accession == "GSE250594" })
        assertTrue(parsed.first().metadataQualityScore > 0)
    }

    @Test
    fun autoContinuationTriggersWhenContrastiveGateNotEvaluated() {
        val report = AutoContinuationTrigger.evaluate(
            parsedMetadata = emptyList(),
            contrastiveReport = ContrastiveEvidenceReport.empty(),
            failurePatternReport = FailurePatternReport(
                active = true,
                patterns = listOf(
                    FailurePattern("NO_OUTCOME_LABELS:allergy", "NO_OUTCOME_LABELS", "allergy", null, 3, System.currentTimeMillis(), listOf("GSE250594"), "Add outcome terms.")
                ),
                newlyRecorded = emptyList(),
                summary = "repeated failure"
            ),
            queryFeedbackPlan = QueryFeedbackPlan(
                active = true,
                improvedQueries = emptyList(),
                improvements = listOf(ImprovedQuery("allergy RNA-seq", "allergy RNA-seq outcome recovery severity", listOf("outcome"), "learned", "better labels")),
                summary = "improved"
            ),
            triageReport = DatasetTriageReport(
                active = true,
                results = emptyList(),
                parsedAccessions = emptyList(),
                skippedAccessions = listOf("GSE250594"),
                summary = "none parsed"
            )
        )

        assertTrue(report.triggered)
        assertTrue(report.reasons.contains("contrastive_gate_not_evaluated"))
        assertEquals("auto_continuation_not_biological_proof", report.claimLimit)
    }
}
