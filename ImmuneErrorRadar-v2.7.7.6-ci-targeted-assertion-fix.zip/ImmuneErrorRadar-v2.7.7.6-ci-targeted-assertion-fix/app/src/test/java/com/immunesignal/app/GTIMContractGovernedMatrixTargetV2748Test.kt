package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMContractGovernedMatrixTargetV2748Test {

    @Test
    fun ebolaMatrixTargetSelectorRejectsKnownAllergySeedWhenEbolaCandidateExists() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Ebola EVD host response")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_METADATA_GAP")
                .put("researchQuestion", "Ebola EVD hemorrhagic viral host response GSE93798")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("primarySeed", "GSE250594")
                        .put("capturedSeeds", JSONArray().put("GSE250594").put("GSE93798")))))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE250594", "GSE93798"),
            paperUnderstandingSummary = "Ebola EVD GSE93798 inspected=20; design=cohort_or_longitudinal; model=human_or_patient_sample; dataset=GSE93798 | score=69/100"
        )
        assertEquals("GSE93798", card.targetId)
        assertFalse(card.nextDecisiveQuery.contains("allergy", ignoreCase = true))
    }

    @Test
    fun accessionHandleCapturedIsNotReportedAsNoAccession() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))
        val card = GTIMMatrixAuditCardV2745.build(report, contract, listOf("GSE152202"), "dataset=GSE152202")
        assertEquals("GSE152202", card.targetId)
        assertTrue(card.blockingGaps.any { it.contains("DATASET_OBJECT_NOT_RESOLVED", ignoreCase = true) || it.contains("METADATA_NOT_EXTRACTED", ignoreCase = true) || it.contains("MATRIX_FILE_NOT_READY", ignoreCase = true) })
        assertFalse(card.blockingGaps.any { it.startsWith("NO_ACCESSION_ID_CAPTURED") })
    }

    @Test
    fun canonicalRouteIdentityDoesNotSuppressAllowedCovidRoute() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val text = "Relationship discovery: covid_interferon_cytokine_bridge SARS-CoV-2 interferon IL-6 TNF PBMC"
        assertTrue(GTIMCanonicalRouteIdentityV2748.isAllowedRouteText(text, contract))
        assertTrue(GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(text, contract))
    }

    @Test
    fun whatItFoundUsesLedgerWhenPriorTitleIsNotAnchorCompatible() {
        val contract = GTIMRunDecisionContractFactoryV2740.buildAutonomousSelectedTopic(
            rawQuery = "gut bacteria depression tryptophan kynurenine IL-6 TNF human cohort dataset",
            hasDatasetAccessions = false,
            matrixState = "DGE_NOT_READY_NO_ACCESSION"
        )
        val card = GTIMMatrixAuditCardV2745.build(JSONObject(), contract, emptyList(), "")
        val line = GTIMDiscoveryLedgerV2745.safeFindingLine(
            rawFinding = "HPA/sleep strain IFN/IL-6/TNF cytokine transcriptomic bridge",
            contract = contract,
            matrixAudit = card
        )
        assertTrue(line.contains("suppressed", ignoreCase = true))
        assertTrue(line.contains("Matrix audit", ignoreCase = true))
    }

    @Test
    fun comparativeAllergyBacteriaFungiKeepsComparisonBridgesVisible() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Allergy vs bacteria vs fungi")
        assertEquals(GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL, contract.primaryAnchor)
        assertTrue(contract.discoveryBridges.any { it.routeId == "allergy_microbiome_barrier_axis" })
        assertTrue(contract.discoveryBridges.any { it.routeId == "fungal_exposure_to_barrier_dysbiosis" })
        assertTrue(contract.secondaryDomains.contains(GTIMDomainV2740.MICROBIOME))
        assertTrue(contract.secondaryDomains.contains(GTIMDomainV2740.MYCOLOGY_YEAST_FUNGAL))
    }
}
