package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMTreatmentExecutionBridgeV2773Test {

    @Test
    fun treatmentKnowledgeConnectsToDgeExecutionGatesWithoutAdvice() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            "Covid vaccine clinical trial neutralizing antibody responder non-responder IL-6"
        )
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid vaccine clinical trial neutralizing antibody"))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE166552"),
            paperUnderstandingSummary = "Single-cell RNA-seq GEO sample table patient cohort data availability comparator"
        )
        val treatment = GTIMTreatmentKnowledgeLayerV2772.evaluate(
            report = report,
            contract = contract,
            matrixAuditCard = card,
            dgeBridgeLine = card.dgeExecutionBridgeLine
        )
        val bridge = GTIMTreatmentExecutionBridgeV2773.build(contract, treatment, card)

        assertTrue(treatment.active)
        assertTrue(bridge.active)
        assertTrue(bridge.state.contains("REVIEW_ONLY"))
        assertTrue(bridge.translationalQuestionLine.contains("Treatment execution bridge:"))
        assertTrue(bridge.interventionDataGateLine.contains("Treatment data gates:"))
        assertTrue(bridge.resistanceEvidenceGateLine.contains("Resistance evidence gate:"))
        assertTrue(bridge.trialDatasetBridgeLine.contains("NCT/PMID/trial terms are lookup handles"))
        assertTrue(bridge.nextActionLine.contains("boundary=review-only"))
        assertTrue(bridge.boundaryLine.contains("no treatment advice"))
        assertTrue(bridge.boundaryLine.contains("no dosing"))
        assertFalse(bridge.compactUnsafe().contains("efficacy confirmed"))
    }

    @Test
    fun globalBriefRendersTreatmentExecutionBridgeLines() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Tuberculosis antibiotic resistance MIC host immune response"))
        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("v2.7.7.3-treatment-execution-bridge"))
        assertTrue(rendered.contains("Treatment knowledge layer:"))
        assertTrue(rendered.contains("Treatment execution bridge:"))
        assertTrue(rendered.contains("Treatment data gates:"))
        assertTrue(rendered.contains("Resistance evidence gate:"))
        assertTrue(rendered.contains("Treatment execution boundary:"))
        assertTrue(rendered.contains("no treatment advice"))
        assertFalse(rendered.contains("clinical management instruction allowed"))
    }

    private fun GTIMTreatmentExecutionBridgeReportV2773.compactUnsafe(): String {
        return GTIMTreatmentExecutionBridgeV2773.compactLine(this)
    }
}
