package com.immunesignal.app

import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue

class GTIMDiseaseAcceptanceV2740Test {

    @Test
    fun hantavirusGetsZoonoticViralAnchorNotAllergyOrCovid() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Hantavirus immune response and fever")
        assertEquals(GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL, c.primaryAnchor)
        assertEquals(GTIMDiseaseFamilyV2740.VECTOR_BORNE_OR_ZOONOTIC, c.diseaseFamily)
        assertFalse(c.allowedRoutes.contains("allergy_type2_ige_mast_eosinophil"))
        assertFalse(c.allowedRoutes.contains("covid_interferon_cytokine_bridge"))
        assertTrue(c.forbiddenConflations.contains("generic_inflammation_only"))
    }

    @Test
    fun ebolaGetsHemorrhagicViralHostResponse() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Ebola cytokine storm host response")
        assertEquals(GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL, c.primaryAnchor)
        assertEquals(GTIMDiseaseFamilyV2740.HEMORRHAGIC_VIRAL, c.diseaseFamily)
        assertTrue(c.allowedRoutes.contains("hemorrhagic_viral_host_response"))
        assertFalse(c.allowedRoutes.contains("allergy_type2_ige_mast_eosinophil"))
        assertFalse(c.allowedRoutes.contains("depression_neuroimmune_axis"))
    }

    @Test
    fun hivGetsRetroviralCd4Axis() {
        val c = GTIMRunDecisionContractFactoryV2740.build("HIV AIDS immune depletion CD4")
        assertEquals(GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION, c.primaryAnchor)
        assertEquals(GTIMDiseaseFamilyV2740.RETROVIRAL_IMMUNODEFICIENCY, c.diseaseFamily)
        assertTrue(c.allowedRoutes.contains("retroviral_cd4_immune_depletion"))
        assertFalse(c.allowedRoutes.contains("ebola_hemorrhagic_viral_host_response"))
        assertFalse(c.allowedRoutes.contains("allergy_type2_ige_mast_eosinophil"))
    }

    @Test
    fun feverIsSyndromeNotSingleDisease() {
        val c = GTIMRunDecisionContractFactoryV2740.build("unexplained fever immune markers")
        assertEquals(GTIMPrimaryAnchorV2740.GENERAL_FEVER_SYNDROME, c.primaryAnchor)
        assertEquals(GTIMDiseaseFamilyV2740.GENERAL_FEVER_SYNDROME, c.diseaseFamily)
        assertTrue(c.allowedRoutes.contains("fever_syndrome_differential_infectious_inflammatory"))
        assertTrue(c.forbiddenConflations.contains("single_disease_high_confidence_without_query_support"))
        assertFalse(c.evidenceCaps.causalityClaimAllowed)
    }

    @Test
    fun epidemicIsSurveillanceFrameNotDiseaseLock() {
        val c = GTIMRunDecisionContractFactoryV2740.build("new epidemic outbreak immune escape")
        assertEquals(GTIMPrimaryAnchorV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE, c.primaryAnchor)
        assertEquals(GTIMDiseaseFamilyV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE, c.diseaseFamily)
        assertTrue(c.allowedRoutes.contains("outbreak_pathogen_emergence_surveillance"))
        assertTrue(c.forbiddenConflations.contains("single_pathogen_lock_without_query_support"))
        assertFalse(c.evidenceCaps.causalityClaimAllowed)
    }
}
