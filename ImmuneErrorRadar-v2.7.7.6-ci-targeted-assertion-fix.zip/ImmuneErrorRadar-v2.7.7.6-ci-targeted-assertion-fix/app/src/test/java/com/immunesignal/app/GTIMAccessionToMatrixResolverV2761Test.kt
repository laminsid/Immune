package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMAccessionToMatrixResolverV2761Test {

    @Test
    fun covidAccessionBecomesResolvedDatasetObjectButNotDgeReadyWithoutMatrixLink() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202"),
            paperUnderstandingSummary = "GSE152202 SARS-CoV-2 PBMC patient sample metadata data availability"
        )
        assertEquals("GSE152202", card.targetId)
        assertTrue(card.datasetObjectState == "DATASET_OBJECT_RESOLVED" || card.datasetObjectState == "METADATA_TABLE_FOUND")
        assertFalse(card.accessionState == "NO_ACCESSION_ID_CAPTURED")
        assertFalse(card.matrixState == "DGE_NOT_READY_NO_ACCESSION")
        assertFalse(card.evidenceUpgradeState == "STRONG_SIGNAL_REVIEW_ONLY")
        assertTrue(GTIMMatrixAuditCardV2745.oneLine(card).contains("object="))
        assertTrue(GTIMMatrixAuditCardV2745.oneLine(card).contains("evidence_upgrade="))
    }

    @Test
    fun explicitComparatorAndMatrixReadyCanReachStrongSignalReviewOnly() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            rawQuery = "Covid",
            hasDatasetAccessions = true,
            matrixState = "DGE_READY"
        )
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_READY")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202"),
            paperUnderstandingSummary = "GSE152202 COVID case healthy control comparator raw counts expression matrix DGE ready sample traits"
        )
        assertEquals("DGE_READY", card.matrixState)
        assertEquals("DGE_READY", card.accessionState)
        assertEquals("STRONG_SIGNAL_REVIEW_ONLY", card.evidenceUpgradeState)
        assertTrue(card.dgeReadinessScore >= 80)
    }

    @Test
    fun metadataTableWithoutComparatorDoesNotBecomeStrongSignal() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Ebola")
        val card = GTIMMatrixAuditCardV2745.build(
            report = JSONObject(),
            contract = contract,
            fallbackSeedHandles = listOf("GSE131907"),
            paperUnderstandingSummary = "GSE131907 Ebola EVD human patient samples metadata phenotype blood PBMC"
        )
        assertEquals("GSE131907", card.targetId)
        assertTrue(card.matrixState.startsWith("DGE_NOT_READY"))
        assertFalse(card.evidenceUpgradeState == "STRONG_SIGNAL_REVIEW_ONLY")
        assertTrue(card.blockingGaps.joinToString(" ").contains("MATRIX", ignoreCase = true))
    }

    @Test
    fun resolverLineAppearsInGlobalBrief() {
        val report = JSONObject()
            .put("topicCapture", JSONObject().put("userQueryCaptured", true).put("rawInput", "Covid").put("normalizedTopic", "Covid"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))
        val rendered = GlobalResearchGradeBriefV11061.render(report)
        assertTrue(rendered.contains("Dataset object resolver:"))
        assertTrue(rendered.contains("Matrix evidence upgrade:"))
    }
}
