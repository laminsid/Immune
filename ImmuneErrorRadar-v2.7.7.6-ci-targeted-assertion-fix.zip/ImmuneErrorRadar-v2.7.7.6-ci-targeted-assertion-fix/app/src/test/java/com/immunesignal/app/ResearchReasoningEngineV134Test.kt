package com.immunesignal.app

import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchReasoningEngineV134Test {
    @Test
    fun `failed pivot creates reasoning questions and reframed search`() {
        val pivot = PivotDecision(
            pivotType = "MECHANISM_TO_DATASET",
            reason = "Mechanism stalled",
            nextIntent = "dataset_hunting",
            nextQuerySeed = "GSE GEO ImmPort RNA-seq outcome",
            priority = 80
        )
        val report = ResearchReasoningEngine.reason(
            findings = emptyList(),
            hypothesisObjects = emptyList(),
            datasetCandidates = emptyList(),
            pivot = pivot,
            global = GlobalImmuneIntelligenceReport(
                mode = "test",
                datasetCandidates = emptyList(),
                axisMap = emptyList(),
                triggerResponseEdges = emptyList(),
                globalHypotheses = emptyList(),
                antiviralResponseNotes = emptyList(),
                nextGlobalDatasetNeeded = "Find human RNA-seq dataset with outcome labels.",
                globalDiscoveryAction = "Dataset hunt.",
                globalBiasAlarm = "Watch"
            ),
            repeatedSkipped = 20,
            reportV3 = ResearchReportV3.empty()
        )
        assertTrue(report.observation.contains("pivot", ignoreCase = true))
        assertTrue(report.reframedSearch.contains("dataset", ignoreCase = true))
        assertTrue(report.generatedQuestions.isNotEmpty())
        assertTrue(report.selfCritique.any { it.contains("No discovery claim", ignoreCase = true) })
    }

    @Test
    fun `interferon axis creates competing explanations and discriminator evidence`() {
        val finding = V12TestFixtures.finding(
            axes = listOf("interferon_antiviral_axis", "tissue_damage_axis"),
            title = "Human viral response interferon timing tissue damage severity outcome"
        )
        val report = ResearchReasoningEngine.reason(
            findings = listOf(finding),
            hypothesisObjects = listOf(V12TestFixtures.objectCard(id = "HYP_INTERFERON")),
            datasetCandidates = emptyList(),
            pivot = PivotDecision.none(),
            global = GlobalImmuneIntelligenceReport(
                mode = "test",
                datasetCandidates = emptyList(),
                axisMap = listOf(ImmuneAxisSummary("interferon_antiviral_axis", 1, "antiviral timing", "test")),
                triggerResponseEdges = emptyList(),
                globalHypotheses = emptyList(),
                antiviralResponseNotes = emptyList(),
                nextGlobalDatasetNeeded = "",
                globalDiscoveryAction = "",
                globalBiasAlarm = "Normal"
            ),
            repeatedSkipped = 0,
            reportV3 = ResearchReportV3.empty()
        )
        assertTrue(report.competingHypotheses.any { it.contains("interferon", ignoreCase = true) })
        assertTrue(report.discriminatorEvidence.any { it.contains("time-course", ignoreCase = true) })
        assertTrue(report.nextReasonedMove.isNotBlank())
    }
}
