package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownstreamTopicCompatibilityV2744Test {
    @Test
    fun allergyPluralParsesAsType2AllergyRoute() {
        val intent = GTIMResearchIntentParserV255.parse("Allergies")
        assertTrue(intent.diseasePhenotype.any { it.contains("Allergic", ignoreCase = true) || it.contains("hypersensitivity", ignoreCase = true) })
        assertTrue(intent.pathway.any { it.contains("IgE", ignoreCase = true) || it.contains("IL-4", ignoreCase = true) || it.contains("mast", ignoreCase = true) })
        assertTrue(intent.cellTissue.any { it.contains("mast", ignoreCase = true) || it.contains("eosinophil", ignoreCase = true) })
        assertTrue(intent.comparatorWanted.any { it.contains("healthy", ignoreCase = true) || it.contains("control", ignoreCase = true) })
    }

    @Test
    fun covidDoesNotOpenPesticideRelationshipFallback() {
        val plan = GTIMRelationshipDiscoveryRouterV2736.build(
            "Raw query Covid Trigger COVID Disease COVID interferon IL-6 TNF PBMC"
        )
        assertTrue(plan.active)
        assertEquals("covid_interferon_cytokine_bridge", plan.matchedArchetype)
        assertFalse(plan.matchedArchetype.contains("pesticide", ignoreCase = true))
    }

    @Test
    fun genericImmuneTextDoesNotDefaultToFirstRelationshipArchetype() {
        val plan = GTIMRelationshipDiscoveryRouterV2736.build(
            "immune cytokine inflammation comparator research lead lookup only"
        )
        assertFalse(plan.active)
        assertEquals("none", plan.matchedArchetype)
    }

    @Test
    fun benchmarkLocksCovidBeforePollutedTopQuery() {
        val report = GTIMBenchmarkValueHarnessV273.evaluate(
            parsedIntentText = "Trigger: COVID | Disease / phenotype: COVID | Pathway: interferon",
            strongestRoute = "current-topic route: COVID -> interferon -> COVID",
            topQuery = "pesticide glyphosate gut microbiome barrier",
            dataChannelsCount = 1,
            routeState = GTIMRouteEvidenceStateReportV272(
                active = true,
                state = "PROMISING_ROUTE",
                reason = "test",
                nextGate = "lookup"
            ),
            paperLite = GTIMPaperUnderstandingLiteV272.empty(),
            proofOfValue = GTIMProofOfValueModeV272.empty(),
            currentTopic = "Covid"
        )
        assertEquals("long_covid_interferon", report.matchedBenchmarkTopic)
    }

    @Test
    fun scoreGateCapsWhenIntentCoreIsMissing() {
        val snapshot = RuntimeCrashSafetyAndTopicGuardV2740.capture("unknown immune idea")
        val gate = TopicIsolationAndScoreGateV2741.evaluate(
            JSONObject().put("briefText", "Disease / phenotype: not specified | Pathway: not specified | Comparator: not specified | Assay: not specified | lookup-only not evidence"),
            snapshot
        )
        val adjusted = gate.optJSONObject("adjustedScores") ?: JSONObject()
        assertTrue(gate.optInt("topicFitScore") <= 60)
        assertTrue(adjusted.optInt("evidenceScore") <= 35)
        assertTrue(adjusted.optInt("dataQualityScore") <= 45)
    }
}
