package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for SteeringSanitizer (v1.0).
 *
 * Validates the privacy contract: any token that looks like personal data
 * MUST be removed before steering inputs leave the device. False rejections
 * are acceptable; false acceptances are bugs.
 */
class SteeringSanitizerTest {

    @Test
    fun `numeric measurements are removed`() {
        val r = SteeringSanitizer.sanitize(listOf("testosterone 320 ng/dL", "histamine"))
        assertFalse(
            "numeric value with unit must be removed",
            r.cleaned.any { it.contains("320") }
        )
        assertTrue("clean medical term passes", r.cleaned.contains("histamine"))
    }

    @Test
    fun `dates and years are removed`() {
        val r = SteeringSanitizer.sanitize(listOf("post-COVID 2025", "asthma"))
        assertFalse(r.cleaned.any { it.contains("2025") })
        assertTrue(r.cleaned.contains("asthma"))
    }

    @Test
    fun `month names are removed`() {
        val r = SteeringSanitizer.sanitize(listOf("rash July", "eczema"))
        assertFalse(r.cleaned.any { it.lowercase().contains("july") })
        assertTrue(r.cleaned.contains("eczema"))
    }

    @Test
    fun `emails are removed`() {
        val r = SteeringSanitizer.sanitize(listOf("contact lamin@example.com about il-6"))
        assertFalse(r.cleaned.any { it.contains("@") })
    }

    @Test
    fun `urls are removed`() {
        val r = SteeringSanitizer.sanitize(listOf("see https://my.health/record"))
        assertFalse(r.cleaned.any { it.contains("http") })
    }

    @Test
    fun `possessive pronouns are removed`() {
        val r = SteeringSanitizer.sanitize(listOf("my eosinophils", "eosinophil"))
        // The possessive phrase should be removed, but the bare medical term must pass.
        assertFalse("possessive form must be removed", r.cleaned.any { it.lowercase().contains("my ") })
        assertTrue("bare medical term passes", r.cleaned.contains("eosinophil"))
    }

    @Test
    fun `safe medical terms pass through`() {
        val safeTerms = listOf("allergy", "asthma", "il-6", "eosinophil", "cytokine", "testosterone")
        val r = SteeringSanitizer.sanitize(safeTerms)
        for (t in safeTerms) {
            assertTrue("safe term '$t' must survive sanitization", r.cleaned.contains(t))
        }
    }

    @Test
    fun `proper-noun candidates are removed`() {
        val r = SteeringSanitizer.sanitize(listOf("Schmidt", "Berlin", "asthma"))
        assertFalse(r.cleaned.contains("Schmidt"))
        // Berlin is in the explicit location list
        assertFalse(r.cleaned.contains("Berlin"))
        assertTrue(r.cleaned.contains("asthma"))
    }

    @Test
    fun `over-long terms are dropped`() {
        val long = "a".repeat(120)
        val r = SteeringSanitizer.sanitize(listOf(long, "asthma"))
        assertFalse(r.cleaned.any { it.length > 80 })
    }

    @Test
    fun `duplicates are deduplicated case-insensitively`() {
        val r = SteeringSanitizer.sanitize(listOf("asthma", "Asthma", "ASTHMA"))
        assertTrue(r.cleaned.size == 1)
    }
}
