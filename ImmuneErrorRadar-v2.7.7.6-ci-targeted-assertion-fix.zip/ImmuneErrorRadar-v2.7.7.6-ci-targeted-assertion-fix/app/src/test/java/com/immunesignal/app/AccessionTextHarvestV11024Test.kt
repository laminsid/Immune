package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AccessionTextHarvestV11024Test {
    @Test
    fun digestKeepsDataAvailabilityAndAccessionText() {
        val text = """
            Background text without a dataset.
            Data availability: RNA-seq data were deposited in GEO under accession GSE123456.
            The cohort includes human patients with severity and recovery metadata.
        """.trimIndent()

        val digest = AccessionTextHarvestPolicy.digest(text)
        val flags = AccessionTextHarvestPolicy.flags(text)

        assertTrue(digest.contains("GSE123456", ignoreCase = true))
        assertTrue(digest.contains("Data availability", ignoreCase = true))
        assertTrue(flags.contains("ACCESSION_TEXT_SIGNAL"))
        assertTrue(flags.contains("DATA_AVAILABILITY_TEXT_SIGNAL"))
    }

    @Test
    fun resolverReadsEvidenceTextDigestForExplicitAccession() {
        val finding = ResearchFinding(
            source = "PubMed",
            sourceId = "123",
            title = "Human immune response study",
            published = "2026",
            url = "https://pubmed.ncbi.nlm.nih.gov/123/",
            matchedAxes = listOf("rna_transcriptomic_axis"),
            noveltyScore = 50,
            bridgeSignal = "dataset availability",
            whyItMatters = "tests accession extraction",
            evidence = EvidenceAssessment("human_study", "human", "cohort", true, 60, emptyList()),
            causality = CausalityAssessment(0, 0, 0, 0, 0, 0, emptyList()),
            negativeControl = NegativeControlAssessment("NOT_EVALUATED", "unknown", "unknown", "unknown", emptyList()),
            personalPattern = PersonalPatternAssessment(0, "none", emptyList(), "none"),
            sanityFlags = emptyList(),
            evidenceTextDigest = "Data availability: transcriptome data are in GEO accession GSE654321 with outcome severity labels."
        )

        val candidates = DatasetAccessionResolver.fromFinding(finding)

        assertEquals("GSE654321", candidates.first().accession)
        assertTrue(candidates.first().status.contains("ACCESSION", ignoreCase = true))
    }
}
