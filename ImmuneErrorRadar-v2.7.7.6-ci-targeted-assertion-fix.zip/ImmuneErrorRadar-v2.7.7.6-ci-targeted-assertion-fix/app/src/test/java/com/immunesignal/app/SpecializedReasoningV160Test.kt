package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpecializedReasoningV160Test {
    private fun nickelCandidate() = DatasetAccessionCandidate(
        accession = "GSE250594",
        source = "GEO/NCBI",
        organismHint = "human_candidate",
        conditionLabelsHint = "allergy/contact-dermatitis/skin labels candidate",
        outcomeLabelsHint = "unknown",
        triggerResponseOutcomeHint = "nickel patch test allergen response",
        timeCourseHint = "unknown",
        sampleSizeHint = "20 participants",
        dataType = "single-cell transcriptomics",
        usabilityScore = 62,
        status = "PARTIAL_LEAD_NEEDS_METADATA",
        sourceFindingId = "NCBI_GEO_GDS:GSE250594",
        sourceTitle = "GSE250594 — Single cell analysis of clinically resolved epidermal skin from nickel-challenged individuals treated with anakinra or placebo",
        sourceUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE250594",
        reasons = emptyList()
    )

    @Test
    fun highRouteFitWithoutMetadataTriggersSpecialistWarning() {
        val candidate = nickelCandidate()
        val foraging = DatasetForagingReport.empty().copy(
            active = true,
            candidates = listOf(candidate),
            routeFitAssessments = listOf(
                DatasetRouteFitAssessment(
                    accession = candidate.accession,
                    datasetRoute = "allergy_contact_dermatitis_il1_skin",
                    targetRoute = "allergy_contact_dermatitis_il1_skin",
                    routeFitScore = 92,
                    status = "IN_ROUTE",
                    allowedUse = "Allowed for dataset inspection.",
                    blocksHypothesisUpgrade = false,
                    reasons = emptyList()
                )
            ),
            scoreSeparation = DatasetScoreSeparation(
                datasetUsabilityScore = 62,
                routeFitScore = 92,
                hypothesisConfidenceScore = 67,
                hypothesisUpgradeAllowed = true,
                scoreState = "CANDIDATE",
                summary = "High route fit but metadata still needs inspection.",
                reasons = emptyList()
            )
        )

        val report = SpecializedReasoningEngine.evaluate(
            findings = emptyList(),
            hypothesisObjects = emptyList(),
            evidenceObjects = emptyList(),
            datasetForagingReport = foraging,
            learningOsReport = LearningOsReport.empty(),
            reasoningReport = ResearchReasoningReport.empty(),
            reportV3 = ResearchReportV3.empty()
        )

        assertTrue(report.active)
        assertEquals("specialized_reasoning_not_biological_proof", report.claimLimit)
        assertTrue(report.weakestLink.contains("metadata", ignoreCase = true))
        assertTrue(report.decisiveNextTest.contains("metadata", ignoreCase = true))
        assertTrue(report.generalModelFailureRisks.any { it.contains("Generic-AI risk") })
    }

    @Test
    fun expertMovesIncludeFalsificationAndAxisDiscipline() {
        val report = SpecializedReasoningEngine.evaluate(
            findings = emptyList(),
            hypothesisObjects = emptyList(),
            evidenceObjects = emptyList(),
            datasetForagingReport = DatasetForagingReport.empty(),
            learningOsReport = LearningOsReport.empty(),
            reasoningReport = ResearchReasoningReport.empty(),
            reportV3 = ResearchReportV3.empty()
        )

        val moveNames = report.expertMoves.map { it.name }
        assertTrue(moveNames.contains("Falsification pressure"))
        assertTrue(moveNames.contains("Axis contamination guard"))
        assertTrue(report.visibleBrief.contains("Specialized reasoning"))
    }
}
