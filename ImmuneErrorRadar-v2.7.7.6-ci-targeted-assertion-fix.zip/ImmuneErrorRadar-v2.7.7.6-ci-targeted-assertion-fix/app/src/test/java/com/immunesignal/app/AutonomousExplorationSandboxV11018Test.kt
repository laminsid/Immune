package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AutonomousExplorationSandboxV11018Test {
    @Test
    fun sandboxAddsAdjacentDomainsWithoutRelaxingClaims() {
        val route = DirectDatasetSourceRouter.routeForSourceFamily("PUBMED_ADJACENT_DOMAIN_MINING")!!
        val queries = AutonomousExplorationSandboxPolicy.queriesForRoute(
            route = route,
            memory = PersistentFailureMemorySnapshot(records = emptyList(), summary = "none")
        )
        val joined = queries.joinToString(" ") { it.query + " " + it.reason }

        assertTrue(queries.isNotEmpty())
        assertTrue(joined.contains("drug", ignoreCase = true) || joined.contains("medication", ignoreCase = true))
        assertTrue(joined.contains("aging", ignoreCase = true))
        assertTrue(joined.contains("diabetes", ignoreCase = true))
        assertTrue(joined.contains("reflux", ignoreCase = true) || joined.contains("gastric", ignoreCase = true))
        assertTrue(joined.contains("no treatment", ignoreCase = true))
        assertTrue(AutonomousExplorationSandboxPolicy.CLAIM_LIMIT.endsWith("not_biological_proof"))
    }

    @Test
    fun directRouterIncludesAdjacentDomainFamilyBeforeContradiction() {
        val families = listOf(
            "GEO_GDS",
            "SRA_PRJNA",
            "IMM_PORT_SDY",
            "PUBMED_ACCESSION_MINING",
            "PUBMED_ADJACENT_DOMAIN_MINING",
            "PUBMED_CONTRADICTION"
        )
        assertTrue(families.contains(DirectDatasetSourceRouter.nextSourceAfterNoCandidate("PUBMED_ACCESSION_MINING")))
        assertTrue(DirectDatasetSourceRouter.nextSourceAfterNoCandidate("PUBMED_ACCESSION_MINING") == "PUBMED_ADJACENT_DOMAIN_MINING")
        assertFalse(AutonomousExplorationSandboxPolicy.safetyGuards().joinToString(" ").contains("recommendation allowed", ignoreCase = true))
    }
}
