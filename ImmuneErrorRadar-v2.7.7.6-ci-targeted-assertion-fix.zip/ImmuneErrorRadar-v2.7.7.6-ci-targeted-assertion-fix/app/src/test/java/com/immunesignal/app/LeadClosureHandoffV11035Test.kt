package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LeadClosureHandoffV11035Test {
    private fun lead(
        title: String = "Manual EBV SLE transcriptomic snippet",
        snippet: String = "EBV HHV-6 CMV herpesvirus latent virus latency reactivation human cohort outcome control metadata",
        accession: List<String> = emptyList()
    ) = LeadObject(
        leadId = "lead1",
        source = "TEXT_SNIPPET",
        sourceFamily = EvidenceLeadAndManualSeedPolicy.MANUAL_MODE,
        title = title,
        snippet = snippet,
        detectedAccessions = accession,
        dataAvailabilityText = "supplementary data availability",
        organism = "human",
        humanLikely = true,
        omicsType = "transcriptomics",
        domain = "unknown",
        outcomeLikely = true,
        controlLikely = false,
        timeLikely = false,
        licenseAccessLikely = false,
        sampleSizeLikely = false,
        confidence = 50
    )

    @Test
    fun priorWeakLeadForcesClosureHandoffInsteadOfStartingFromZero() {
        val metadata = LeadClosureHandoffPolicy.metadataClosure(listOf(lead()), emptyList(), emptyList())
        val handoff = LeadClosureHandoffPolicy.evaluateHandoff(
            recentReports = listOf("Lead inspection queue v1.10.34: OPEN_LEADS_REQUIRE_SECONDARY_LOOKUP best=MANUAL_TEXT_SNIPPET_d81e"),
            leadObjects = listOf(lead()),
            breakthrough = EvidenceDiscoveryBreakthroughReport.empty().copy(active = true, state = "WEAK_DATASET_LEAD_FOUND", bestLead = "MANUAL_TEXT_SNIPPET_d81e"),
            metadataClosure = metadata
        )

        assertTrue(handoff.active)
        assertEquals("LEAD_CLOSURE_HANDOFF_ACTIVE", handoff.state)
        assertTrue(handoff.blockedActions.contains("BROAD_PUBMED_SEARCH"))
        assertTrue(handoff.forcedNextAction.contains("secondary", ignoreCase = true) || handoff.forcedNextAction.contains("metadata", ignoreCase = true))
    }

    @Test
    fun metadataClosureTracksExactMissingFields() {
        val report = LeadClosureHandoffPolicy.metadataClosure(listOf(lead(accession = listOf("GSE12345"))), emptyList(), emptyList())

        assertTrue(report.active)
        assertTrue(report.closedFields.contains("accession"))
        assertTrue(report.closedFields.contains("human_or_patient_data"))
        assertTrue(report.missingFields.contains("control_or_comparator"))
        assertTrue(report.missingFields.contains("time_order"))
    }

    @Test
    fun ebvIsSavedAsLatentVirusRoutePriorOnlyNotProof() {
        val report = LeadClosureHandoffPolicy.classifyUnknownRoute(
            leadObjects = listOf(lead()),
            candidates = emptyList(),
            routeFits = emptyList(),
            recentReports = emptyList()
        )

        assertTrue(report.active)
        assertEquals("ROUTE_PRIOR_ONLY_NOT_EVIDENCE", report.state)
        assertEquals("latent_virus_reactivation_route", report.selectedRoute)
        assertTrue(report.pinnedRule.contains("not proof", ignoreCase = true))
    }

    @Test
    fun pathLinkageAcceptsWeakAccessionMetadataClosureAsLeadPath() {
        val report = DatasetForagingPathLinkageGuard.evaluate(
            attempts = listOf(
                DatasetSourceAttempt("GEO_GDS", "gds", "q1", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
                DatasetSourceAttempt("SRA_PRJNA", "sra", "q2", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
                DatasetSourceAttempt("IMM_PORT_SDY", "pubmed", "q3", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
                DatasetSourceAttempt("PUBMED_ACCESSION_MINING", "pubmed", "q4", true, 2, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
                DatasetSourceAttempt(MatureDomainEvidenceProbePolicy.SOURCE_FAMILY, "pubmed", "q5", true, 1, 0, "MATURE_DOMAIN_PROBE_NO_FRESH_EVIDENCE", "test")
            ),
            accessionReport = AccessionAcquisitionReport(
                active = true,
                state = "FOUND_WEAK_ACCESSION_NEEDS_METADATA",
                explicitAccessions = emptyList(),
                weakAccessions = listOf("MANUAL_TEXT_SNIPPET_d81e"),
                unresolvedLeadCount = 1,
                archiveRecommended = false,
                compactReportRecommended = true,
                nextAction = "Convert weak lead into explicit accession or parse metadata.",
                reasons = listOf("test")
            ),
            matureProbeReport = MatureDomainEvidenceProbePolicy.Report(
                active = true,
                state = "MATURE_DOMAIN_PROBE_READY",
                summary = "ready",
                selectedDomains = listOf("antihistamine_histamine_mast_cell"),
                querySeeds = listOf("histamine mast cell accession"),
                probeAttempted = true,
                relaxedInterpretationAllowed = true,
                nextAction = "Run mature-domain probe."
            ),
            foragerState = "DATASET_FORAGING_WEAK_ACCESSION_NEEDS_METADATA",
            foragerNextAction = "Close minimum metadata for the weak lead before broad search."
        )

        assertEquals("CONNECTED_MATURE_DOMAIN_TO_LEAD_INSPECTION", report.state)
        assertTrue(report.warnings.isEmpty())
    }
}
