package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningMemoryMlTriageV145Test {
    @Test
    fun triageFlagsOffRouteDatasetAsClaimSafeLowPriority() {
        val candidate = DatasetAccessionCandidate(
            accession = "GSE250594",
            source = "GEO/NCBI",
            organismHint = "human participants",
            conditionLabelsHint = "nickel patch test skin contact dermatitis",
            outcomeLabelsHint = "response labels candidate",
            triggerResponseOutcomeHint = "allergen exposure response",
            timeCourseHint = "before and after challenge",
            sampleSizeHint = "20 participants",
            dataType = "single-cell transcriptomics",
            usabilityScore = 92,
            status = "USABLE_LEAD_NEEDS_INSPECTION",
            sourceFindingId = "NCBI_GEO_GDS:GSE250594",
            sourceTitle = "Single cell analysis of clinically resolved epidermal skin from nickel-challenged individuals treated with anakinra or placebo",
            sourceUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE250594",
            reasons = emptyList()
        )
        val routeFit = DatasetRouteFitAssessment(
            accession = "GSE250594",
            datasetRoute = "allergy_contact_dermatitis_il1_skin",
            targetRoute = "antiviral_interferon_timing",
            routeFitScore = 28,
            status = "OFF_ROUTE_DATASET",
            allowedUse = "Inspection only; do not use as support for the target hypothesis.",
            blocksHypothesisUpgrade = true,
            reasons = emptyList()
        )

        val result = DatasetTriageEngine.triage(candidate, routeFit)

        assertEquals("LOW_PRIORITY", result.action)
        assertTrue(result.likelyFailureModes.contains("OFF_ROUTE"))
        assertEquals("triage_only_not_biological_proof", result.claimLimit)
    }

    @Test
    fun queryFeedbackAddsTermsFromFailureMemory() {
        val failures = listOf(
            FailurePattern(
                id = "NO_OUTCOME_LABELS:antiviral_interferon_timing",
                rootCause = "NO_OUTCOME_LABELS",
                route = "antiviral_interferon_timing",
                hypothesisId = null,
                occurrenceCount = 3,
                lastSeenMillis = System.currentTimeMillis(),
                datasetAccessions = listOf("GSE_X"),
                suggestedAction = "Add outcome terms."
            ),
            FailurePattern(
                id = "ANIMAL_ONLY:antiviral_interferon_timing",
                rootCause = "ANIMAL_ONLY",
                route = "antiviral_interferon_timing",
                hypothesisId = null,
                occurrenceCount = 2,
                lastSeenMillis = System.currentTimeMillis(),
                datasetAccessions = listOf("PRJNA_X"),
                suggestedAction = "Require human terms."
            )
        )

        val improved = QueryFeedbackPlanner.improveQuery(
            previousQuery = "interferon RNA-seq viral response",
            recentFailures = failures,
            targetRoute = "antiviral_interferon_timing"
        )

        assertTrue(improved.improved.contains("outcome"))
        assertTrue(improved.improved.contains("recovery"))
        assertTrue(improved.improved.contains("human"))
        assertTrue(improved.improved.contains("viral load"))
    }


    @Test
    fun queryFeedbackTreatsLeadObjectLookupAsFollowUpNotBroadRotation() {
        val plan = QueryFeedbackPlanner.applyNoCandidateLearning(
            base = QueryFeedbackPlan.passthrough(emptyList()),
            records = listOf(
                NoCandidateLearningRecord(
                    sourceFamily = "MATURE_DOMAIN_EVIDENCE_PROBE",
                    queryId = "q_test",
                    status = "MATURE_DOMAIN_PROBE_NO_FRESH_EVIDENCE",
                    missing = "usable_dataset_metadata_or_accession",
                    nextPreferredSource = "LEAD_OBJECT_SECONDARY_LOOKUP",
                    reason = "near-miss source IDs require manual/secondary lookup"
                )
            )
        )

        assertTrue(plan.active)
        assertTrue(plan.summary.contains("next action: LEAD_OBJECT_SECONDARY_LOOKUP"))
        assertFalse(plan.summary.contains("next source family"))
        assertTrue(plan.improvements.first().reasoning.contains("LeadObject"))
        assertTrue(plan.improvements.first().expectedImprovement.contains("DatasetCandidate"))
    }

    @Test
    fun freshnessBoostIsSmallAndClaimSafe() {
        val finding = ResearchFinding(
            source = "PubMed",
            sourceId = "123",
            title = "Recent human immune transcriptomic cohort",
            published = "2026",
            url = "",
            matchedAxes = listOf("rna_transcriptomic_axis"),
            noveltyScore = 70,
            bridgeSignal = "Recent dataset candidate.",
            whyItMatters = "Ranks evidence hunt only.",
            evidence = EvidenceAssessment("human_relevant", "human", "cohort", true, 80, emptyList()),
            causality = CausalityAssessment(40, 10, 50, 50, 0, 0, emptyList()),
            negativeControl = NegativeControlAssessment("watch_requires_controls", "watch", "watch", "watch", emptyList()),
            personalPattern = PersonalPatternAssessment(0, "none", emptyList(), "Verify outcomes."),
            sanityFlags = emptyList()
        )

        val score = EvidenceFreshnessScorer.score(finding)

        assertTrue(score.boostInRanking in 0..5)
        assertEquals("ranking_weight_only_not_biological_proof", score.claimLimit)
    }
}
