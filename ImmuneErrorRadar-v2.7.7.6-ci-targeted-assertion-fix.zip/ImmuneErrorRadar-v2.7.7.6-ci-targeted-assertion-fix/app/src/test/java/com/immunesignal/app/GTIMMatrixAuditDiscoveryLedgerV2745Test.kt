package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMMatrixAuditDiscoveryLedgerV2745Test {

    @Test
    fun ebolaMatrixAuditExplainsMetadataGapWithoutAllergyTemplate() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            rawQuery = "Ebola EVD",
            hasDatasetAccessions = true,
            matrixState = "DGE_NOT_READY_METADATA_GAP"
        )
        val report = JSONObject()
            .put("datasetForagingReport", JSONObject()
                .put("mechanismDiscoveryDossierReport", JSONObject()
                    .put("matrixAnalysisGate", "DGE_NOT_READY_METADATA_GAP")
                    .put("globalTranslationalDossier", JSONObject()
                        .put("accessionSeedCapture", JSONObject().put("primarySeed", "GSE93798")))))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE93798"),
            paperUnderstandingSummary = "inspected=20; design=cohort_or_longitudinal; model=human_or_patient_sample; dataset=GSE93798 | score=69/100"
        )
        assertEquals("GSE93798", card.targetId)
        assertEquals("GEO", card.repository)
        assertTrue(card.blockingGaps.any { it.contains("COMPARATOR", ignoreCase = true) })
        assertTrue(card.nextDecisiveQuery.contains("Ebola", ignoreCase = true))
        assertFalse(card.nextDecisiveQuery.contains("allergy", ignoreCase = true))
    }

    @Test
    fun discoveryLedgerSuppressesLatentVirusTemplateForCovid() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val card = GTIMMatrixAuditCardV2745.build(JSONObject(), contract, listOf("GSE152202"), "dataset=GSE152202 | score=38/100")
        val line = GTIMDiscoveryLedgerV2745.safeFindingLine(
            rawFinding = "EBV/HHV-6 SLE/MS/ME-CFS transcriptomic bridge: IN_PROGRESS_NOT_EVIDENCE_OBJECT",
            contract = contract,
            matrixAudit = card
        )
        assertTrue(line.contains("suppressed", ignoreCase = true))
        assertTrue(line.contains("Matrix audit", ignoreCase = true))
    }

    @Test
    fun autonomousMicrobiomeDepressionLedgerAllowsSelectedBridgeButLabelsIt() {
        val contract = GTIMRunDecisionContractFactoryV2740.buildAutonomousSelectedTopic(
            rawQuery = "gut bacteria depression tryptophan kynurenine IL-6 TNF human cohort dataset",
            hasDatasetAccessions = false,
            matrixState = "DGE_NOT_READY_NO_ACCESSION"
        )
        val ledger = GTIMDiscoveryLedgerV2745.build(contract)
        assertTrue(ledger.summaryLine.contains("Discovery ledger"))
        assertTrue(ledger.entries.any { it.routeId == "gut_microbiome_to_neuroinflammation" })
        assertFalse(ledger.entries.any { it.routeId == "covid_interferon_cytokine_bridge" })
    }

    @Test
    fun globalBriefSeparatesMatrixAuditFromSuppressedPriorTemplate() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("normalizedTopic", "Covid")
                .put("userQueryCaptured", true))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("bestResearchLeadSummary", "EBV/HHV-6 SLE/MS/ME-CFS transcriptomic bridge: IN_PROGRESS_NOT_EVIDENCE_OBJECT")
                .put("matrixAnalysisGate", "DGE_NOT_READY_METADATA_GAP")
                .put("globalTranslationalDossier", JSONObject()
                    .put("researchIntent", JSONObject()
                        .put("active", true)
                        .put("intentCompletenessScore", 90)
                        .put("parsedResearchIntentCard", org.json.JSONArray().put("Trigger: COVID").put("Disease: COVID").put("Pathway: interferon")))
                    .put("dataFeedPlan", JSONObject()
                        .put("dataFeedPlanScore", 100))))
        val brief = GlobalResearchGradeBriefV11061.render(report)
        assertTrue(brief.contains("Matrix audit card"))
        assertTrue(brief.contains("prior/template finding suppressed", ignoreCase = true))
    }
}
