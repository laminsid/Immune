package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningSessionV156HandoffTest {
    @Test
    fun failurePatternCreatesQueryAdditionsWithoutBiologicalClaim() {
        val insights = LearningInsights(
            failurePatternClusters = listOf(
                JSONObject().put("rootCause", "NO_OUTCOME_LABELS").put("suggestedAction", "Require outcome labels before upgrade")
            ),
            proposedRoutes = listOf(JSONObject().put("routeId", "antiviral_interferon_timing")),
            blindSpots = listOf(JSONObject().put("warning", "Generic inflammation can masquerade as antiviral evidence")),
            questions = listOf("Does the next dataset include recovery or severity endpoints?")
        )

        val handoff = LearningSessionOutcomeBridge.buildHandoffFromInsights("test_session", insights)

        assertEquals("session_handoff_not_biological_proof", handoff.claimLimit)
        assertTrue(handoff.queryAdditions.contains("outcome"))
        assertTrue(handoff.queryAdditions.contains("recovery"))
        assertTrue(handoff.routeSuggestions.contains("antiviral_interferon_timing"))
        assertTrue(handoff.blockedClaims.any { it.contains("do not prove", ignoreCase = true) })
        assertTrue(handoff.recommendedNextSearch.contains("Use next search terms"))
    }

    @Test
    fun jsonExportKeepsHandoffSafeAndStructured() {
        val handoff = LearningSessionHandoff(
            sessionId = "s1",
            queryAdditions = listOf("human", "longitudinal"),
            routeSuggestions = listOf("resolution_recovery_axis"),
            safetyWarnings = listOf("No causal claim"),
            followUpQuestions = listOf("Which outcome changed first?"),
            blockedClaims = listOf("No diagnosis"),
            recommendedNextSearch = "Use next search terms: human longitudinal"
        )

        val json = handoff.toJson()
        assertEquals("s1", json.getString("sessionId"))
        assertEquals("session_handoff_not_biological_proof", json.getString("claimLimit"))
        assertEquals("human", json.getJSONArray("queryAdditions").getString(0))
        assertTrue(handoff.compactSummary().contains("claim-limit"))
    }
}
