package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MinimumDataPackGateV12Test {
    @Test
    fun `meal alone does not satisfy meal timing`() {
        val card = V12TestFixtures.card(
            id = "gastric_acid_gut_axis",
            next = "Track meal and reflux.",
            why = listOf("meal mentioned", "gastric reflux")
        )
        val assessment = MinimumDataPackGate.assess(card, listOf("gastric_acid_gut_axis"), emptyList(), emptyList())
        assertTrue("meal_timing must remain missing when only meal appears", assessment.missingData.contains("meal_timing"))
    }

    @Test
    fun `meal timing phrase satisfies meal timing`() {
        val card = V12TestFixtures.card(
            id = "gastric_acid_gut_axis",
            next = "Track meal timing, reflux or gastric symptoms, acid suppression context, timestamp, sleep quality, symptom intensity.",
            repeats = 3
        )
        val assessment = MinimumDataPackGate.assess(card, listOf("gastric_acid_gut_axis"), emptyList(), emptyList())
        assertFalse(assessment.missingData.contains("meal_timing"))
    }

    @Test
    fun `generic BP does not satisfy systolic and diastolic requirements`() {
        val card = V12TestFixtures.card(next = "Measure BP and dizziness with timestamp sleep quality symptom intensity.")
        val assessment = MinimumDataPackGate.assess(card, listOf("autonomic_vascular_axis"), emptyList(), emptyList())
        assertTrue(assessment.missingData.contains("systolic_bp"))
        assertTrue(assessment.missingData.contains("diastolic_bp"))
    }

    @Test
    fun `systolic and diastolic terms satisfy specific blood pressure requirements`() {
        val card = V12TestFixtures.card(next = "Measure systolic BP, diastolic BP, pulse, dizziness, timestamp, sleep quality, symptom intensity.", repeats = 3)
        val assessment = MinimumDataPackGate.assess(card, listOf("autonomic_vascular_axis"), emptyList(), emptyList())
        assertFalse(assessment.missingData.contains("systolic_bp"))
        assertFalse(assessment.missingData.contains("diastolic_bp"))
    }

    @Test
    fun `or requirement passes with one alternative marker`() {
        val card = V12TestFixtures.card(next = "IgE, allergy intensity, exposure context, timestamp, sleep quality, symptom intensity.", repeats = 3)
        val assessment = MinimumDataPackGate.assess(card, listOf("type2_allergy_axis"), emptyList(), emptyList())
        assertFalse(assessment.missingData.contains("IgE_or_eosinophils"))
    }
}
