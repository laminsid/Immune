package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SteeringAwareCreativeForgeV11013Test {
    @Test
    fun steeringAxesPrioritizeNeuroimmunologyAndKeepClaimsLocked() {
        val steering = ResearchSteeringProfile(
            profileId = "steer_v11013",
            createdAtMillis = 1L,
            variables = listOf("neuroimmunology", "stress", "sleep", "microbiome", "immunometabolism", "chronomedicine"),
            focusQuestion = "Connect stress sleep microbiome metabolism timing with immune recovery",
            requiredTerms = listOf("human", "longitudinal", "control", "responder"),
            excludedTerms = emptyList(),
            inferredAxes = listOf("psychoneuroimmune_axis", "gut_metabolic")
        )
        val report = CreativeHypothesisForge.build(
            sourceFamiliesAttempted = listOf("IMM_PORT_SDY", "PUBMED_ACCESSION_MINING"),
            noCandidateLearningRecords = listOf(
                noCandidate("IMM_PORT_SDY", "PUBMED_CONTRADICTION"),
                noCandidate("PUBMED_ACCESSION_MINING", "PUBMED_CONTRADICTION")
            ),
            shards = shards(),
            candidates = emptyList(),
            steering = steering
        )

        assertTrue(report.active)
        assertTrue(report.expandedThinking.active)
        assertEquals("expanded_thinking_not_evidence", report.expandedThinking.claimLimit)
        assertTrue(report.steeringAxesUsed.any { it.id == "neuroimmunology" })
        assertEquals("creative:steering:neuroimmunology", report.generated.first().hypothesisId)
        assertTrue(report.selectedQuery.contains("neuroimmune", ignoreCase = true))
        assertTrue(report.selectedQuery.contains("responder", ignoreCase = true))
        assertEquals("creative_steering_hypothesis_not_evidence", report.generated.first().claimLimit)
    }

    @Test
    fun defaultScientificAxesAppearEvenWhenUserSteeringIsMissing() {
        val report = CreativeHypothesisForge.build(
            sourceFamiliesAttempted = listOf("PUBMED_ACCESSION_MINING", "PUBMED_CONTRADICTION"),
            noCandidateLearningRecords = listOf(
                noCandidate("PUBMED_ACCESSION_MINING", "PUBMED_CONTRADICTION"),
                noCandidate("PUBMED_CONTRADICTION", "PUBMED_CONTROL")
            ),
            shards = shards(),
            candidates = emptyList()
        )

        assertTrue(report.active)
        assertTrue(report.steeringAxesUsed.map { it.id }.contains("neuroimmunology"))
        assertTrue(report.steeringAxesUsed.map { it.id }.contains("immunometabolism"))
        assertTrue(report.steeringAxesUsed.map { it.id }.contains("chronomedicine"))
    }

    private fun noCandidate(source: String, next: String) = NoCandidateLearningRecord(
        sourceFamily = source,
        queryId = "q_$source",
        status = "NO_CANDIDATE",
        missing = "accession_like_id",
        nextPreferredSource = next,
        reason = "test"
    )

    private fun shards() = listOf(
        TestableHypothesisShard(
            shardId = "s1",
            label = "stress sleep immune recovery",
            evidenceQuestion = "Which route explains recovery severity and responder status?",
            querySeeds = listOf("stress", "sleep", "recovery", "severity", "control", "longitudinal")
        )
    )
}
