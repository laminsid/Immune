package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AccessionMiningIntensityV11023Test {
    @Test
    fun accessionMiningGetsDeeperBoundedPubmedWindow() {
        val plan = AccessionMiningIntensityPolicy.planForSourceFamily("PUBMED_ACCESSION_MINING")

        assertTrue(plan.retMax >= 25)
        assertTrue(plan.abstractBudget >= 5)
        assertTrue(plan.summary.contains("accession-mining", ignoreCase = true))
        assertTrue(plan.claimLimit.contains("not_biological_proof"))
    }

    @Test
    fun contradictionAndControlRemainNarrow() {
        val contradiction = AccessionMiningIntensityPolicy.planForSourceFamily("PUBMED_CONTRADICTION")
        val control = AccessionMiningIntensityPolicy.planForSourceFamily("PUBMED_CONTROL")

        assertEquals(10, contradiction.retMax)
        assertEquals(1, contradiction.abstractBudget)
        assertEquals(10, control.retMax)
        assertEquals(1, control.abstractBudget)
    }
}
