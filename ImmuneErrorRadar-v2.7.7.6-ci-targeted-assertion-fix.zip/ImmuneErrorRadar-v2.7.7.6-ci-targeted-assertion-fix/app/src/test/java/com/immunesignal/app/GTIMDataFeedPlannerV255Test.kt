package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMDataFeedPlannerV255Test {
    @Test
    fun structuredIntentBuildsRepositoryQueryPlan() {
        val intent = GTIMResearchIntentParserV255.parse(
            """
            Disease / phenotype: Long COVID fatigue
            Trigger: EBV or HHV-6 reactivation
            Pathway: interferon signaling, IL-6, TNF
            Cell / tissue: PBMC, T cells, B cells
            Comparator: Long COVID vs recovered controls vs healthy controls
            Assay: RNA-seq, scRNA-seq, cytokine profiling
            Repositories: GEO, SRA, ArrayExpress, ImmPort
            Contradiction: no EBV association or opposite cytokine direction
            Output: discovery brief
            """.trimIndent()
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        assertTrue(plan.active)
        assertEquals("GTIM_DATAFEED_PLAN_VISIBLE", plan.status)
        assertTrue(plan.repositorySearchPlan.any { it.repository.contains("GEO") })
        assertTrue(plan.repositorySearchPlan.any { it.repository.contains("SRA") || it.repository.contains("BioProject") })
        assertTrue(plan.repositorySearchPlan.any { it.priority == "contradiction search" })
        assertTrue(plan.accessionPatterns.contains("GSE"))
        assertTrue(plan.comparatorTargets.isNotEmpty())
        assertTrue(plan.matrixTargets.any { it.contains("matrix", ignoreCase = true) })
        assertTrue(plan.dataFeedPlanScore > 0)
    }


    @Test
    fun plannerAddsComparativeDiseasePreflightForCancerHivFungalEpidemicQuestion() {
        val intent = GTIMResearchIntentParserV255.parse(
            "Compare cancer tumor immune evasion versus HIV AIDS and Candida fungal Th17 defense during pandemic cytokine severity; RNA-seq GEO SRA controls"
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        assertTrue(plan.active)
        assertTrue(plan.repositorySearchPlan.any { it.repository == "Comparative Disease Pathways" })
        assertTrue(plan.querySeeds.any { it.contains("cancer", ignoreCase = true) && it.contains("HIV", ignoreCase = true) })
        assertTrue(plan.comparatorTargets.any { it.contains("condition", ignoreCase = true) || it.contains("comparator", ignoreCase = true) })
        assertTrue(plan.contradictionTargets.any { it.contains("shared", ignoreCase = true) || it.contains("single disease", ignoreCase = true) || it.contains("epidemic", ignoreCase = true) })
        assertTrue(plan.bestNextAction.contains("comparative preflight", ignoreCase = true))
    }

    @Test
    fun plannerStaysUserTriggeredAndPlaySafe() {
        val intent = GTIMResearchIntentParserV255.parse("EBV Long COVID interferon PBMC RNA-seq healthy controls GEO SRA")
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        assertTrue(plan.playProtectPosture.contains("User-triggered", ignoreCase = true))
        assertTrue(plan.playProtectPosture.contains("no hidden", ignoreCase = true))
        assertTrue(plan.githubPosture.contains("deterministic", ignoreCase = true))
    }
}
