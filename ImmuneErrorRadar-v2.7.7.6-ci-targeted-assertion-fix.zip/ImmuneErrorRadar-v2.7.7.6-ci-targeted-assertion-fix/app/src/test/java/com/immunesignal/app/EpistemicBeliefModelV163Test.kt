package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EpistemicBeliefModelV163Test {
    private fun foragingWithHighRouteFitNoMetadata() = DatasetForagingReport.empty().copy(
        active = true,
        candidates = listOf(
            DatasetAccessionCandidate(
                accession = "GSE_BELIEF",
                source = "GEO/NCBI",
                organismHint = "human_candidate",
                conditionLabelsHint = "viral infection interferon response",
                outcomeLabelsHint = "unknown",
                triggerResponseOutcomeHint = "interferon viral response",
                timeCourseHint = "unknown",
                sampleSizeHint = "unknown",
                dataType = "RNA-seq",
                usabilityScore = 66,
                status = "PARTIAL_LEAD_NEEDS_METADATA",
                sourceFindingId = "test",
                sourceTitle = "Human viral interferon RNA-seq candidate",
                sourceUrl = "https://example.test/GSE_BELIEF",
                reasons = emptyList()
            )
        ),
        parsedMetadata = emptyList(),
        routeFitAssessments = listOf(
            DatasetRouteFitAssessment(
                accession = "GSE_BELIEF",
                datasetRoute = "interferon_antiviral_timing",
                targetRoute = "interferon_antiviral_timing",
                routeFitScore = 91,
                status = "IN_ROUTE",
                allowedUse = "Inspect metadata before upgrade.",
                blocksHypothesisUpgrade = false,
                reasons = emptyList()
            )
        )
    )

    @Test
    fun beliefModelTurnsMapIntoMutableBeliefs() {
        val map = CumulativeKnowledgeMapEngine.build(
            currentFindings = emptyList(),
            hypothesisObjects = emptyList(),
            evidenceObjects = emptyList(),
            datasetForagingReport = foragingWithHighRouteFitNoMetadata(),
            specializedReasoningReport = SpecializedReasoningReport.empty(),
            recentReportLines = emptyList()
        )

        val belief = EpistemicBeliefEngine.build(
            currentFindings = emptyList(),
            hypothesisObjects = emptyList(),
            evidenceObjects = emptyList(),
            datasetForagingReport = foragingWithHighRouteFitNoMetadata(),
            specializedReasoningReport = SpecializedReasoningReport.empty(),
            knowledgeMapReport = map,
            recentReportLines = emptyList()
        )

        assertTrue(belief.active)
        assertTrue(belief.beliefs.any { it.beliefType == "FOUNDATION_PRIOR" })
        assertTrue(belief.beliefs.any { it.beliefType == "ROUTE_BELIEF" && it.requiredEvidenceToKeep.contains("minimum_metadata_parse") })
        assertTrue(belief.beliefs.any { it.status == "REVISE_REQUIRED" || it.status == "WEAKENED" })
        assertEquals("epistemic_beliefs_not_biological_proof", belief.claimLimit)
    }

    @Test
    fun priorBeliefsCanLoseCredibilityInsteadOfRemainingStatic() {
        val prior = """
            {"epistemicBeliefReport":{"active":true,"state":"BELIEF_MODEL_ACTIVE","beliefScore":80,"carriedForwardBeliefs":0,"newBeliefsThisCycle":1,"weakenedBeliefs":0,"revisedBeliefs":0,"retiredBeliefs":0,"beliefs":[{"beliefId":"belief:route:gse_belief_interferon_antiviral_timing","statement":"prior route belief","beliefType":"ROUTE_BELIEF","status":"ACTIVE_PRIOR","confidence":90,"credibility":90,"supportCount":1,"contradictionCount":0,"linkedNodes":["dataset:gse_belief"],"requiredEvidenceToKeep":["minimum_metadata_parse"],"falsifiers":["metadata_not_parsed"],"lastChangedReason":"prior"}],"updates":[],"foundationBeliefs":[],"mutableBeliefWarnings":[],"nextBeliefAction":"continue","visibleBrief":"prior","claimLimit":"epistemic_beliefs_not_biological_proof"}}
        """.trimIndent()

        val map = KnowledgeMapReport.empty().copy(
            active = true,
            state = "MAP_WITH_BLOCKING_GAPS",
            gaps = listOf(
                KnowledgeMapGap(
                    gapId = "minimum_metadata_not_parsed",
                    affectedNodes = listOf("dataset:gse_belief"),
                    severity = 90,
                    nextAction = "Run minimum metadata parsing.",
                    blocksUpgrade = true
                )
            )
        )

        val belief = EpistemicBeliefEngine.build(
            currentFindings = emptyList(),
            hypothesisObjects = emptyList(),
            evidenceObjects = emptyList(),
            datasetForagingReport = foragingWithHighRouteFitNoMetadata(),
            specializedReasoningReport = SpecializedReasoningReport.empty(),
            knowledgeMapReport = map,
            recentReportLines = listOf(prior)
        )

        assertTrue(belief.carriedForwardBeliefs >= 1)
        assertTrue(belief.updates.any { it.updateType == "CREDIBILITY_LOSS" || it.updateType == "BELIEF_REQUIRES_REVISION" || it.newStatus == "WEAKENED" || it.newStatus == "REVISE_REQUIRED" })
        assertTrue(belief.mutableBeliefWarnings.any { it.contains("mutable", ignoreCase = true) || it.contains("credibility", ignoreCase = true) })
    }
}
