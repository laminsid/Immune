package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMTreatmentKnowledgeLayerV2772Test {

    @Test
    fun covidVaccineTrialTermsOpenTreatmentKnowledgeButNotAdvice() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid vaccine clinical trial IL-6 neutralizing antibody")
        val layer = GTIMTreatmentKnowledgeLayerV2772.evaluate(JSONObject(), contract)

        assertTrue(layer.active)
        assertTrue(layer.state.contains("REVIEW_ONLY"))
        assertTrue(layer.matchedLanes.any { it == "VACCINE_COUNTERMEASURE_REVIEW" })
        assertTrue(layer.matchedLanes.any { it == "CLINICAL_TRIAL_EVIDENCE_REVIEW" })
        assertTrue(layer.reasoningMapLine.contains("intervention class"))
        assertTrue(layer.nextEvidenceLine.contains("gates="))
        assertTrue(layer.boundaryLine.contains("no treatment advice"))
        assertTrue(layer.boundaryLine.contains("no dosing"))
        assertFalse(layer.boundaryLine.contains("efficacy confirmed"))
    }

    @Test
    fun allergyTermsOpenAntiAllergyLaneWithoutClinicalManagement() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Allergy IgE mast cell antihistamine anti-IgE eosinophil")
        val layer = GTIMTreatmentKnowledgeLayerV2772.evaluate(JSONObject(), contract)

        assertTrue(layer.active)
        assertTrue(layer.matchedLanes.contains("ANTI_ALLERGY_INTERVENTION_REVIEW"))
        assertTrue(layer.immuneInteractionLine.contains("anti-allergy") || layer.immuneInteractionLine.contains("allergy"))
        assertTrue(layer.nextEvidenceLine.contains("IgE") || layer.nextEvidenceLine.contains("mast"))
        assertFalse(layer.compactLineUnsafe().contains("take ", ignoreCase = true))
        assertTrue(layer.boundaryLine.contains("no clinical management"))
    }

    @Test
    fun antibioticResistanceTermsOpenAntimicrobialResistanceLane() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Tuberculosis antibiotic resistance MIC beta lactamase host immune response")
        val layer = GTIMTreatmentKnowledgeLayerV2772.evaluate(JSONObject(), contract)

        assertTrue(layer.active)
        assertTrue(layer.matchedLanes.contains("ANTIBIOTIC_ANTIMICROBIAL_RESISTANCE_REVIEW"))
        assertTrue(layer.resistanceLine.contains("MIC") || layer.resistanceLine.contains("beta-lactamase") || layer.resistanceLine.contains("resistance"))
        assertTrue(layer.nextEvidenceLine.contains("pathogen") || layer.nextEvidenceLine.contains("MIC"))
        assertTrue(layer.boundaryLine.contains("no treatment advice"))
    }

    @Test
    fun globalBriefRendersTreatmentKnowledgeLayer() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid vaccine clinical trial neutralizing antibody"))
        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("v2.7.7.2-treatment-knowledge-layer"))
        assertTrue(rendered.contains("Treatment knowledge layer:"))
        assertTrue(rendered.contains("Treatment reasoning map:"))
        assertTrue(rendered.contains("Treatment evidence next:"))
        assertTrue(rendered.contains("no treatment advice"))
        assertFalse(rendered.contains("DGE_EXECUTION_READY_REVIEW_ONLY | Treatment"))
    }

    private fun GTIMTreatmentKnowledgeReportV2772.compactLineUnsafe(): String {
        return GTIMTreatmentKnowledgeLayerV2772.compactLine(this)
    }
}
