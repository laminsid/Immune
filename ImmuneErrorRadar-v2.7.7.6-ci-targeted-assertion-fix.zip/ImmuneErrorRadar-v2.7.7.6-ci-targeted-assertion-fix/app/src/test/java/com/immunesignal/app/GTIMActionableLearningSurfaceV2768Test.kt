package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMActionableLearningSurfaceV2768Test {

    @Test
    fun actionableSoftLeadIsRenderedAsUsefulLearningWithoutEvidenceUpgrade() {
        val report = JSONObject()
            .put("runtime", JSONObject().put("engineVersion", "v2.7.3-final-proof-benchmark-learning-locked"))
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes")
                .put("normalizedTopic", "Diabetes"))
            .put("metadataClosureStrategyMatrixReport", JSONObject()
                .put("state", "DGE_NOT_READY_NO_ACCESSION")
                .put("blockingGaps", JSONArray()
                    .put("ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED")))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE117882")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("v2.7.6.8-actionable-learning-surface"))
        assertTrue(rendered.contains("Evidence state: D+ — actionable research lead in progress"))
        assertTrue(rendered.contains("Research value:"))
        assertTrue(rendered.contains("Learning now:"))
        assertTrue(rendered.contains("next_evidence="))
        assertTrue(rendered.contains("boundary=not DGE-ready, not a claim"))
        assertFalse(rendered.contains("accessions=1 | matrix=DGE_NOT_READY_NO_ACCESSION"))
        assertFalse(rendered.contains("STRONG_SIGNAL_REVIEW_ONLY"))
    }

    @Test
    fun matrixAuditCardHelperExposesLearningProgressLine() {
        val card = GTIMMatrixAuditCardReportV2745(
            active = true,
            targetId = "GSE166552",
            repository = "GEO",
            assayPlatform = "Single-cell RNA-seq",
            inspectedAbstractsCount = 1,
            extractedDesignModel = "not surfaced",
            matrixState = "DGE_NOT_READY_SOFT_MATRIX_AND_COMPARATOR_LEAD_REVIEW",
            dgeReadinessScore = 70,
            verifiedMetadataSlots = listOf("condition_anchor=covid_interferon_cytokine_bridge"),
            blockingGaps = listOf(
                "SOFT_MATRIX_LEAD_REVIEW:: assay/data-availability signal surfaced; fetch raw/count matrix before DGE.",
                "SOFT_COMPARATOR_LEAD_REVIEW:: condition contrast surfaced; standardize comparator labels before DGE."
            ),
            nextDecisiveQuery = "GSE166552 AND sample table comparator raw counts AND Covid",
            claimLockStatus = "HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION",
            summaryLine = "Matrix audit",
            accessionState = "METADATA_TRAITS_NOT_PARSED",
            accessionBridgeStatus = "ACCESSION_CAPTURED_CONTRACT_COMPATIBLE",
            datasetObjectState = "METADATA_TABLE_FOUND",
            metadataTraitState = "METADATA_TABLE_FOUND",
            matrixReadinessState = "DGE_NOT_READY_SOFT_MATRIX_AND_COMPARATOR_LEAD_REVIEW",
            evidenceUpgradeState = "METADATA_AUDIT_READY",
            datasetObjectSummary = "Dataset resolver: target=GSE166552",
            researchValueState = "ACTIONABLE_SOFT_ANALYSIS_LEAD",
            researchValueLine = "Research value: ACTIONABLE_SOFT_ANALYSIS_LEAD | boundary=research lead, not biological proof or clinical claim"
        )

        val line = GTIMMatrixAuditCardV2745.learningProgressLine(card)

        assertTrue(line.contains("Learning now:"))
        assertTrue(line.contains("assay/data-availability"))
        assertTrue(line.contains("next_evidence=fetch raw/count matrix"))
        assertTrue(line.contains("not DGE-ready"))
    }
}
