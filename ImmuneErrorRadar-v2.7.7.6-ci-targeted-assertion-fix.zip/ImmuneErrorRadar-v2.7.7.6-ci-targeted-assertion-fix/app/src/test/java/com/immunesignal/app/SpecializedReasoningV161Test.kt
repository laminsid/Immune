package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SpecializedReasoningV161Test {
    @Test
    fun specialistProtocolSurfacesEvidenceGapsAndVerdict() {
        val foraging = DatasetForagingReport.empty().copy(
            active = true,
            candidates = listOf(
                DatasetAccessionCandidate(
                    accession = "GSE_TEST",
                    source = "GEO/NCBI",
                    organismHint = "human_candidate",
                    conditionLabelsHint = "viral infection candidate",
                    outcomeLabelsHint = "unknown",
                    triggerResponseOutcomeHint = "interferon response",
                    timeCourseHint = "unknown",
                    sampleSizeHint = "unknown",
                    dataType = "RNA-seq",
                    usabilityScore = 65,
                    status = "PARTIAL_LEAD_NEEDS_METADATA",
                    sourceFindingId = "test",
                    sourceTitle = "Human viral interferon RNA-seq candidate",
                    sourceUrl = "https://example.test/GSE_TEST",
                    reasons = emptyList()
                )
            ),
            routeFitAssessments = listOf(
                DatasetRouteFitAssessment(
                    accession = "GSE_TEST",
                    datasetRoute = "interferon_antiviral_timing",
                    targetRoute = "interferon_antiviral_timing",
                    routeFitScore = 90,
                    status = "IN_ROUTE",
                    allowedUse = "Inspect metadata before upgrade.",
                    blocksHypothesisUpgrade = false,
                    reasons = emptyList()
                )
            ),
            scoreSeparation = DatasetScoreSeparation(
                datasetUsabilityScore = 65,
                routeFitScore = 90,
                hypothesisConfidenceScore = 62,
                hypothesisUpgradeAllowed = false,
                scoreState = "CANDIDATE",
                summary = "High route fit but metadata missing.",
                reasons = emptyList()
            )
        )

        val report = SpecializedReasoningEngine.evaluate(
            findings = emptyList(),
            hypothesisObjects = emptyList(),
            evidenceObjects = emptyList(),
            datasetForagingReport = foraging,
            learningOsReport = LearningOsReport.empty(),
            reasoningReport = ResearchReasoningReport.empty(),
            reportV3 = ResearchReportV3.empty()
        )

        assertTrue(report.evidenceGaps.any { it.gapId == "MINIMUM_METADATA" })
        assertTrue(report.reasoningAudit.isNotEmpty())
        assertTrue(report.nextCycleProtocol.isNotEmpty())
        assertTrue(report.specialistVerdict.contains("metadata", ignoreCase = true) || report.specialistVerdict.contains("evidence", ignoreCase = true))
        assertEquals("specialized_reasoning_not_biological_proof", report.claimLimit)
    }

    @Test
    fun hypothesisTournamentUsesStructuredHypothesisObjects() {
        val report = SpecializedReasoningEngine.evaluate(
            findings = emptyList(),
            hypothesisObjects = listOf(
                HypothesisObject(
                    hypothesisId = "HYP_TEST",
                    label = "interferon_antiviral_timing testable lead",
                    status = "WATCH",
                    discoveryState = "Early",
                    biasRiskState = "Alert",
                    dataTrustScore = 72,
                    evidenceScore10 = 6.0,
                    causalityScore = 55,
                    minimumDataPackStatus = "PARTIAL",
                    missingData = listOf("outcome_labels"),
                    nextBestMeasurement = "Find viral load plus recovery/severity outcome labels.",
                    signalFlip = "outcome labels found",
                    decisionImpact = "Keep as candidate only.",
                    falsification = listOf("no association", "reverse timing")
                )
            ),
            evidenceObjects = emptyList(),
            datasetForagingReport = DatasetForagingReport.empty(),
            learningOsReport = LearningOsReport.empty(),
            reasoningReport = ResearchReasoningReport.empty(),
            reportV3 = ResearchReportV3.empty()
        )

        assertTrue(report.hypothesisTournament.any { it.hypothesisId == "HYP_TEST" })
        assertTrue(report.hypothesisTournament.first().nextDiscriminator.contains("viral load", ignoreCase = true))
    }
}
