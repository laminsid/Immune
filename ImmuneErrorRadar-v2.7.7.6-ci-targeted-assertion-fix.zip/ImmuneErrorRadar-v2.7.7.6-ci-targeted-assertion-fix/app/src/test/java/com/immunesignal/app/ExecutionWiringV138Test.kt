package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExecutionWiringV138Test {
    @Test
    fun hardStagnationTriggersDatasetHunt() {
        assertTrue(
            EngineRuntimeStatus.hardStagnationTriggered(
                newFindingsCount = 0,
                repeatedSkipped = 20,
                datasetCandidateCount = 0
            )
        )
        val pivot = EngineRuntimeStatus.runtimeFailoverPivot(20)
        assertEquals("RUNTIME_STAGNATION_DATASET_HUNT", pivot.pivotType)
        assertTrue(pivot.nextQuerySeed.contains("GSE"))
        assertTrue(pivot.nextQuerySeed.contains("ImmPort"))
    }

    @Test
    fun forcedPivotRaisesQueryBudget() {
        val limits = ResearchRunLimits(maxQueries = 4, maxResultsPerQuery = 5)
        val pivot = PivotDecision(
            pivotType = "LEARNING_OS_FORCED_GATE",
            reason = "test",
            nextIntent = "dataset_accession_search",
            nextQuerySeed = "GSE immune response outcome",
            priority = 94
        )
        val budget = EngineRuntimeStatus.enforceQueryBudget(
            baseLimits = limits,
            appliedPivot = pivot,
            stagnationPlan = AutonomousStagnationEngine.StagnationPlan.none(limits)
        )
        assertTrue(budget.first >= 6)
        assertTrue(budget.second >= 20)
    }

    @Test
    fun executionLockFailsWhenForcedPivotDidNotExecuteForcedQuery() {
        val status = ActiveResearchEngineStatus(
            engineVersion = EngineRuntimeStatus.ACTIVE_ENGINE_VERSION,
            activeModules = EngineRuntimeStatus.ACTIVE_MODULES,
            researchState = "DATASET_HUNT",
            appliedPivotType = "LEARNING_OS_FORCED_GATE",
            effectiveMaxQueries = 6,
            effectiveResultsPerQuery = 20,
            runtimeFailoverApplied = false,
            forcedQueries = listOf("GSE immune response outcome"),
            executedQueryIds = listOf("q_normal")
        )
        val lock = EngineRuntimeStatus.buildExecutionLock(
            runtimeStatus = status,
            learningOsReport = LearningOsReport.empty(),
            hardStagnationObserved = false
        )
        assertEquals("FAIL", lock.status)
    }
}
