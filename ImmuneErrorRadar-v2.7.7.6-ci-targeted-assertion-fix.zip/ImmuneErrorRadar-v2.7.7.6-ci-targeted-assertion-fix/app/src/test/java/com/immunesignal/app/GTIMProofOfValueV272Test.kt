package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMProofOfValueV272Test {
    @Test
    fun paperUnderstandingExtractsDesignModelDatasetAndClaim() {
        val report = JSONObject()
            .put("findings", JSONArray().put(JSONObject()
                .put("title", "Human PBMC RNA-seq links interferon activation to hantavirus severity")
                .put("bridgeSignal", "human PBMC immune route")
                .put("whyItMatters", "data availability includes GSE123456")
                .put("evidenceTextDigest", "In 120 patients, RNA-seq showed increased interferon and cytokine activation associated with severe disease. Data availability: GSE123456. No association was seen for unrelated controls.")))
        val paper = GTIMPaperUnderstandingLiteV272.analyze(report)
        assertTrue(paper.active)
        assertTrue(paper.studyDesignSignals.contains("omics_dataset"))
        assertTrue(paper.modelContextSignals.contains("human_or_patient_sample"))
        assertTrue(paper.datasetAvailabilitySignals.any { it == "GSE123456" })
        assertTrue(paper.strongestClaim.contains("interferon", ignoreCase = true))
        assertTrue(paper.contradictionSignals.isNotEmpty())
    }

    @Test
    fun promisingRouteDoesNotPretendToBeStrongSignal() {
        val paper = GTIMPaperUnderstandingLiteV272.empty().copy(active = true, paperUnderstandingScore = 28)
        val state = GTIMRouteEvidenceStateV272.classify(
            routeScore = 22,
            discoveryScore = 15,
            evidenceScore = 0,
            leadCount = 1,
            routeCount = 1,
            accessionCount = 0,
            seedCount = 1,
            paperUnderstanding = paper
        )
        assertEquals("PROMISING_ROUTE", state.state)
        assertTrue(state.claimLimit.contains("not_evidence_upgrade"))
    }

    @Test
    fun proofOfValueReportsValueDeltaAndBenchmarkQuestions() {
        val paper = GTIMPaperUnderstandingLiteV272.empty().copy(active = true, paperUnderstandingScore = 40)
        val route = GTIMRouteEvidenceStateReportV272(true, "PROMISING_ROUTE", "seeded route", "close metadata")
        val pov = GTIMProofOfValueModeV272.build(JSONObject().put("findings", JSONArray().put(JSONObject())), route, paper, 2, "hantavirus PBMC RNA-seq")
        assertEquals("VALUE_DELTA_VISIBLE", pov.valueState)
        assertTrue(pov.benchmarkQuestions.any { it.contains("Hantavirus", ignoreCase = true) })
    }

    @Test
    fun finalClosureVerifiesVersionAndLearningLinks() {
        val closure = GTIMFinalProofValueClosureV272.verify("Hantavirus endothelial interferon PBMC RNA-seq")
        assertTrue(closure.versionUnified)
        assertTrue(closure.paperUnderstandingLinked)
        assertTrue(closure.promisingRouteLinked)
        assertTrue(closure.proofOfValueLinked)
    }
}
