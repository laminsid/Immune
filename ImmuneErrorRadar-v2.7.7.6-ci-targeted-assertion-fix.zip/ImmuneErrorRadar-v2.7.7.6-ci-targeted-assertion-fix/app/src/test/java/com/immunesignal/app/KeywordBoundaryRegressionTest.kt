package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KeywordBoundaryRegressionTest {
    @Test
    fun axisMatcherDoesNotMatchPpiInsideShipping() {
        assertFalse(AxisMatcher.match("shipping sample metadata only").contains("gastric_acid_gut_axis"))
    }

    @Test
    fun axisMatcherStillMatchesStandalonePpi() {
        assertTrue(AxisMatcher.match("PPI exposure and reflux history").contains("gastric_acid_gut_axis"))
    }
}
