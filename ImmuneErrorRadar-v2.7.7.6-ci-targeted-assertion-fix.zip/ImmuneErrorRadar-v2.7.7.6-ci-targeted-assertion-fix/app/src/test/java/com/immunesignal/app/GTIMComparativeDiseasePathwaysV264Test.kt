package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMComparativeDiseasePathwaysV264Test {
    @Test
    fun `cancer hiv fungal epidemic prompt activates comparative closure`() {
        val report = GTIMComparativeDiseasePathwaysV264.closeCycle(
            "compare cancer tumor immune evasion with HIV AIDS CD4 depletion, fungal Candida Th17 defense, and pandemic cytokine severity"
        )
        assertTrue(report.active)
        assertEquals("COMPARATIVE_DISEASE_CYCLE_CLOSED", report.closureState)
        assertEquals(4, report.mandatoryDomainsCovered.size)
        assertTrue(report.missingMandatoryDomains.isEmpty())
        assertTrue(report.cards.any { it.id == "cancer_hiv_exhaustion_bridge" })
        assertTrue(report.cards.any { it.id == "aids_fungal_opportunistic_bridge" })
        assertTrue(report.cards.any { it.id == "epidemic_hyperinflammation_bridge" })
    }

    @Test
    fun `plain autoimmune prompt does not force comparative disease paths`() {
        val report = GTIMComparativeDiseasePathwaysV264.closeCycle("SLE interferon autoantibody nephritis comparator")
        assertFalse(report.active)
        assertEquals("NO_COMPARATIVE_DISEASE_PATH_TRIGGERED", report.closureState)
    }

    @Test
    fun `query seeds are bounded and comparator oriented`() {
        val seeds = GTIMComparativeDiseasePathwaysV264.querySeedsForText("HIV AIDS fungal Candida opportunistic infection")
        assertTrue(seeds.isNotEmpty())
        assertTrue(seeds.size <= 8)
        assertTrue(seeds.joinToString(" ").contains("comparator", ignoreCase = true))
    }
}
