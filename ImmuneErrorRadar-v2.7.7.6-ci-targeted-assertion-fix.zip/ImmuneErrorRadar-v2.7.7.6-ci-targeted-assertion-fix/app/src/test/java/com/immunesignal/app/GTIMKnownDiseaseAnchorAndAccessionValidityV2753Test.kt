package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMKnownDiseaseAnchorAndAccessionValidityV2753Test {

    @Test
    fun genericDiabetesDoesNotFallToAutonomousUnknown() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Diabetes")
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED, c.runMode)
        assertEquals(GTIMPrimaryAnchorV2740.DIABETES_METABOLIC_INFLAMMATION, c.primaryAnchor)
        assertEquals("diabetes_metabolic_inflammation_axis", c.benchmarkTopic)
        assertFalse(c.discoveryBridges.any { it.routeId == "allergy_type2_to_barrier_immunity" })
        assertTrue(c.discoveryBridges.any { it.routeId == "insulin_resistance_inflammation_axis" })
    }

    @Test
    fun type2DiabetesUsesInsulinResistanceAnchor() {
        val c = GTIMRunDecisionContractFactoryV2740.build("type 2 diabetes insulin resistance inflammation")
        assertEquals(GTIMPrimaryAnchorV2740.T2D_INSULIN_RESISTANCE_INFLAMMATION, c.primaryAnchor)
        assertTrue(c.allowedRoutes.contains("type2_diabetes_insulin_resistance_inflammation_axis"))
        assertTrue(c.allowedRoutes.contains("gut_microbiome_metabolic_axis"))
    }

    @Test
    fun thyroidHashimotoAndAsthmaAreKnownAnchors() {
        val thyroid = GTIMRunDecisionContractFactoryV2740.build("Hashimoto thyroiditis")
        val asthma = GTIMRunDecisionContractFactoryV2740.build("Asthma airway inflammation")
        assertEquals(GTIMPrimaryAnchorV2740.THYROID_HASHIMOTO_AUTOIMMUNE, thyroid.primaryAnchor)
        assertEquals(GTIMPrimaryAnchorV2740.ASTHMA_TYPE2_AIRWAY, asthma.primaryAnchor)
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED, thyroid.runMode)
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED, asthma.runMode)
    }

    @Test
    fun pcosIsKnownAnchorButYeastPcosKeepsExploratoryFungalBridge() {
        val pcos = GTIMRunDecisionContractFactoryV2740.build("PCOS insulin resistance")
        val yeast = GTIMRunDecisionContractFactoryV2740.build("yeast fungal exposure PCOS thyroid")
        assertEquals(GTIMPrimaryAnchorV2740.PCOS_REPRODUCTIVE_METABOLIC, pcos.primaryAnchor)
        assertEquals(GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE, yeast.primaryAnchor)
    }

    @Test
    fun bareAccessionPrefixesAreRejected() {
        assertFalse(GTIMAccessionIdValidityGuardV2753.isFullAccession("GSE"))
        assertFalse(GTIMAccessionIdValidityGuardV2753.isFullAccession("SDY"))
        assertFalse(GTIMAccessionIdValidityGuardV2753.isFullAccession("PMID"))
        assertTrue(GTIMAccessionIdValidityGuardV2753.isFullAccession("GSE166552"))
        assertTrue(GTIMAccessionIdValidityGuardV2753.isFullAccession("SDY123"))
        assertTrue(GTIMAccessionIdValidityGuardV2753.isFullAccession("PMID:22114171"))
    }

    @Test
    fun matrixAuditDoesNotPromoteBareGseQueryToTarget() {
        val c = GTIMRunDecisionContractFactoryV2740.buildAutonomousSelectedTopic(
            rawQuery = "gut bacteria depression tryptophan kynurenine IL-6 TNF human cohort dataset",
            hasDatasetAccessions = false,
            matrixState = "DGE_NOT_READY_NO_ACCESSION"
        )
        val report = JSONObject()
            .put("query", "GSE OR PRJNA microbiome depression cohort dataset")
            .put("notes", "Need full accession lookup")
        val card = GTIMMatrixAuditCardV2745.build(report, c, emptyList(), "GSE OR PRJNA lookup only")
        assertEquals("NO_ACCESSION_ID_CAPTURED", card.targetId)
        assertFalse(card.targetId == "GSE")
    }
}
