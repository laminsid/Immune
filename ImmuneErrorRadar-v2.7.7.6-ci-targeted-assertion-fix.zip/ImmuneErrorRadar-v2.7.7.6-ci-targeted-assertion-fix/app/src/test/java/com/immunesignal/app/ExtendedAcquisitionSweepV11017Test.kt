package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExtendedAcquisitionSweepV11017Test {
    @Test
    fun oneFastSourceDoesNotPermitArchive() {
        val memory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord(
                    failedQueryHash = "h",
                    sourceFamily = "IMM_PORT_SDY",
                    rootCause = "NO_DATASET_ACCESSION+BROAD_QUERY",
                    cooldownCyclesRemaining = 1,
                    lastAttemptedAtMillis = 1L,
                    timesFailed = 3,
                    forcedNextSource = "PUBMED_ACCESSION_MINING"
                )
            ),
            summary = "no accession pressure"
        )
        val report = AccessionAcquisitionHardening.evaluate(
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            attempts = listOf(
                DatasetSourceAttempt("IMM_PORT_SDY", "pubmed", "q1", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test")
            ),
            noCandidateLearningRecords = emptyList(),
            memory = memory
        )

        assertEquals("NO_ACCESSION_CONTINUE_SOURCE_SWEEP", report.state)
        assertFalse(report.archiveRecommended)
        assertTrue(report.nextAction.contains("Continue accession sweep"))
    }

    @Test
    fun routeExpansionAddsDistinctAccessionFamiliesBeforeArchive() {
        val memory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord(
                    failedQueryHash = "h",
                    sourceFamily = "IMM_PORT_SDY",
                    rootCause = "NO_DATASET_ACCESSION+BROAD_QUERY",
                    cooldownCyclesRemaining = 1,
                    lastAttemptedAtMillis = 1L,
                    timesFailed = 3,
                    forcedNextSource = "IMM_PORT_SDY"
                )
            ),
            summary = "no accession pressure"
        )
        val base = listOf(DirectDatasetSourceRouter.routeForSourceFamily("IMM_PORT_SDY")!!)
        val expanded = ExtendedAcquisitionSweepPolicy.expandRoutes(base, memory, evidenceFirstBudget = true)
        val sourceFamilies = expanded.map { it.sourceFamily }

        assertTrue(sourceFamilies.contains("IMM_PORT_SDY"))
        assertTrue(sourceFamilies.contains("PUBMED_ACCESSION_MINING"))
        assertTrue(sourceFamilies.size >= RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES)
    }
}
