package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMAccessionPipelineStateV2749Test {

    @Test
    fun covidSeedHandlesBecomeAccessorPipelineStateNotNoAccession() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            rawQuery = "Covid",
            hasDatasetAccessions = true,
            matrixState = "DGE_NOT_READY_NO_ACCESSION"
        )
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202").put("GSE166552")))))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202", "GSE166552"),
            paperUnderstandingSummary = "Covid PBMC SARS-CoV-2 interferon dataset handle GSE152202 inspected=3"
        )
        assertEquals("GSE152202", card.targetId)
        assertFalse(card.accessionState == "NO_ACCESSION_ID_CAPTURED")
        assertFalse(card.matrixState == "DGE_NOT_READY_NO_ACCESSION")
        assertTrue(GTIMMatrixAuditCardV2745.oneLine(card).contains("accession_state="))
    }

    @Test
    fun ebolaMatrixTargetPrefersEbolaSeedOverAllergySeed() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Ebola")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("primarySeed", "GSE250594")
                        .put("capturedSeeds", JSONArray().put("GSE250594").put("GSE72056").put("GSE131907")))))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE250594", "GSE72056", "GSE131907"),
            paperUnderstandingSummary = "Ebola EVD filovirus hemorrhagic host response dataset GSE72056 inspected=20; model=human_or_patient_sample"
        )
        assertTrue(card.targetId == "GSE72056" || card.targetId == "GSE131907")
        assertFalse(card.targetId == "GSE250594")
        assertFalse(card.nextDecisiveQuery.contains("allergy", ignoreCase = true))
    }

    @Test
    fun accessionPipelineReportsDatasetObjectPendingRatherThanNoAccession() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val state = GTIMAccessionPipelineStateV2749.resolve(
            report = JSONObject(),
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202"),
            paperUnderstandingSummary = "GSE152202 SARS-CoV-2 PBMC interferon lookup-only"
        )
        assertEquals("GSE152202", state.targetId)
        assertTrue(state.hasAnyHandle)
        assertFalse(state.status == GTIMAccessionResolutionStatusV2749.NO_ACCESSION_ID_CAPTURED)
        assertTrue(state.bridgeStatus.contains("ACCESSION_CAPTURED"))
    }

    @Test
    fun canonicalRouteStillAllowsCovidDiscoveryLine() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val routeText = "Relationship discovery: SARS-CoV-2 interferon IL-6 TNF PBMC host-response matrix -> Long COVID phenotype"
        assertTrue(GTIMCanonicalRouteIdentityV2748.isAllowedRouteText(routeText, contract))
        assertTrue(GTIMCanonicalRouteIdentityV2748.isAnchorCompatibleText(routeText, contract))
    }
}
