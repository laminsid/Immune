package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CreativeContinuationPolicyV11012Test {
    @Test
    fun buildsOneBoundedContinuationQueryFromCreativeForgeAndNextSource() {
        val forge = CreativeHypothesisForge.build(
            sourceFamiliesAttempted = listOf("IMM_PORT_SDY", "PUBMED_ACCESSION_MINING"),
            noCandidateLearningRecords = listOf(
                noCandidate("IMM_PORT_SDY", "PUBMED_CONTRADICTION"),
                noCandidate("PUBMED_ACCESSION_MINING", "PUBMED_CONTRADICTION")
            ),
            shards = shards(),
            candidates = emptyList(),
            terminalArchiveRequested = false
        )
        val report = DatasetForagingReport.empty().copy(
            active = true,
            state = "DATASET_FORAGING_NO_CANDIDATE",
            sourceFamiliesAttempted = listOf("IMM_PORT_SDY", "PUBMED_ACCESSION_MINING"),
            hypothesisShards = shards(),
            noCandidateLearningRecords = listOf(
                noCandidate("IMM_PORT_SDY", "PUBMED_CONTRADICTION"),
                noCandidate("PUBMED_ACCESSION_MINING", "PUBMED_CONTRADICTION")
            ),
            creativeHypothesisForgeReport = forge,
            blockedLearningReason = "no candidate",
            nextAction = "next contradiction"
        )

        val plan = CreativeContinuationPolicy.build(report, shards(), PersistentFailureMemorySnapshot.empty())

        assertTrue(plan.active)
        assertEquals("CREATIVE_CONTINUATION_TEST", plan.mode)
        assertEquals("PUBMED_CONTRADICTION", plan.sourceFamily)
        assertEquals(1, plan.queries.size)
        assertEquals(1, plan.maxQueries)
        assertTrue(plan.queries.first().query.contains("nonresponse", ignoreCase = true))
        assertTrue(plan.reason.contains("routing", ignoreCase = true))
    }

    @Test
    fun doesNotContinueWhenDatasetCandidateAlreadyExists() {
        val candidate = DatasetAccessionCandidate(
            accession = "GSE12345",
            source = "GEO",
            organismHint = "human",
            conditionLabelsHint = "immune response",
            outcomeLabelsHint = "severity",
            triggerResponseOutcomeHint = "response",
            timeCourseHint = "longitudinal",
            sampleSizeHint = "n=10",
            dataType = "RNA-seq",
            usabilityScore = 70,
            status = "DATASET_CANDIDATE",
            sourceFindingId = "finding_1",
            sourceTitle = "test dataset",
            sourceUrl = "https://example.org/GSE12345",
            reasons = listOf("test")
        )
        val forge = CreativeHypothesisForge.build(
            sourceFamiliesAttempted = listOf("IMM_PORT_SDY", "PUBMED_ACCESSION_MINING"),
            noCandidateLearningRecords = listOf(noCandidate("PUBMED_ACCESSION_MINING", "PUBMED_CONTRADICTION")),
            shards = shards(),
            candidates = listOf(candidate),
            terminalArchiveRequested = false
        )
        val report = DatasetForagingReport.empty().copy(
            active = true,
            state = "DATASET_FORAGING_CANDIDATE_INSPECTION",
            candidates = listOf(candidate),
            creativeHypothesisForgeReport = forge,
            blockedLearningReason = "candidate exists",
            nextAction = "close evidence"
        )

        val plan = CreativeContinuationPolicy.build(report, shards(), PersistentFailureMemorySnapshot.empty())

        assertFalse(plan.active)
        assertTrue(plan.reason.contains("evidence closure", ignoreCase = true))
    }


    @Test
    fun blocksCreativeContinuationWhenLeadObjectLookupIsPending() {
        val forge = CreativeHypothesisForge.build(
            sourceFamiliesAttempted = listOf("GEO_GDS", "MATURE_DOMAIN_EVIDENCE_PROBE"),
            noCandidateLearningRecords = listOf(noCandidate("MATURE_DOMAIN_EVIDENCE_PROBE", "LEAD_OBJECT_SECONDARY_LOOKUP")),
            shards = shards(),
            candidates = emptyList(),
            terminalArchiveRequested = false
        )
        val report = DatasetForagingReport.empty().copy(
            active = true,
            state = "DATASET_FORAGING_NEAR_MISS_MANUAL_INSPECTION",
            sourceFamiliesAttempted = listOf("GEO_GDS", "MATURE_DOMAIN_EVIDENCE_PROBE"),
            hypothesisShards = shards(),
            noCandidateLearningRecords = listOf(noCandidate("MATURE_DOMAIN_EVIDENCE_PROBE", "LEAD_OBJECT_SECONDARY_LOOKUP")),
            creativeHypothesisForgeReport = forge,
            blockedLearningReason = "near miss lead exists",
            nextAction = "Inspect LeadObject first."
        )

        val plan = CreativeContinuationPolicy.build(report, shards(), PersistentFailureMemorySnapshot.empty())

        assertFalse(plan.active)
        assertTrue(plan.reason.contains("LeadObject secondary lookup", ignoreCase = true))
        assertTrue(plan.reason.contains("before creative continuation", ignoreCase = true))
    }

    private fun noCandidate(source: String, next: String) = NoCandidateLearningRecord(
        sourceFamily = source,
        queryId = "q_$source",
        status = "NO_FRESH_PUBMED_EVIDENCE",
        missing = "usable_dataset_metadata_or_accession",
        nextPreferredSource = next,
        reason = "$source returned no candidate"
    )

    private fun shards() = listOf(
        TestableHypothesisShard(
            shardId = "outcome_pattern",
            label = "Outcome pattern",
            evidenceQuestion = "Find outcome/control/time labels",
            querySeeds = listOf("human immune response severity recovery control")
        )
    )
}
