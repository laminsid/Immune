package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class GTIMKnownPriorEvidenceSeedsV269Test {
    private fun assetText(name: String): String {
        val candidates = listOf(
            File("app/src/main/assets/$name"),
            File("src/main/assets/$name"),
            File("../app/src/main/assets/$name"),
            File(System.getProperty("user.dir"), "app/src/main/assets/$name"),
            File(System.getProperty("user.dir"), "src/main/assets/$name")
        )
        val found = candidates.firstOrNull { it.isFile }
            ?: error("Missing asset $name. Tried: ${candidates.joinToString { it.path }}")
        return found.readText()
    }

    @Test
    fun knownPriorSeedsAreLookupOnlyAndDoNotForceGateClosure() {
        assertTrue(RuntimeFeatureFlags.ENABLE_KNOWN_PRIOR_EVIDENCE_SEEDS_V269)
        assertFalse(RuntimeFeatureFlags.KNOWN_PRIOR_SEEDS_CLOSE_CONTRADICTION_GATE_V269)
        assertFalse(RuntimeFeatureFlags.KNOWN_PRIOR_SEEDS_FORCE_MATRIX_READY_V269)
        assertEquals("known_prior_seed_lookup_only_not_gate_closure", GTIMKnownPriorEvidenceSeedsV269.CLAIM_LIMIT)
        assertTrue(GTIMKnownPriorEvidenceSeedsV269.allHandles.contains("22114171"))
        assertTrue(GTIMKnownPriorEvidenceSeedsV269.allHandles.contains("10.1073/pnas.1118355109"))
        assertTrue(GTIMKnownPriorEvidenceSeedsV269.allHandles.contains("GSE152202"))
        assertTrue(GTIMKnownPriorEvidenceSeedsV269.allHandles.contains("GSE166552"))
    }

    @Test
    fun plannerSurfacesKnownPriorSeedsBeforeGenericBootstrap() {
        val intent = GTIMResearchIntentParserV255.parse(
            "Stress sleep HPA cortisol glucocorticoid resistance EBV HHV-6 IL-6 TNF Long COVID GSE152202 GSE166552 Europe PMC OpenAlex"
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        assertTrue(plan.repositorySearchPlan.any { it.repository == "Known Prior Evidence Seeds" })
        assertTrue(plan.repositorySearchPlan.any { it.repository == "Europe PMC" })
        assertTrue(plan.repositorySearchPlan.any { it.repository == "OpenAlex" })
        assertTrue(plan.querySeeds.any { it.contains("22114171") || it.contains("22474371") })
        assertTrue(plan.querySeeds.any { it.contains("GSE152202") || it.contains("GSE166552") })
        assertTrue(plan.bestNextAction.contains("known-prior", ignoreCase = true))
    }

    @Test
    fun knownPriorAssetDocumentsCorrectionAndSafety() {
        val json = JSONObject(assetText("gtim_known_prior_evidence_seeds_v2.6.9.json"))
        assertEquals("known_prior_seed_lookup_only_not_gate_closure", json.getString("claim_limit"))
        assertTrue(json.getJSONObject("safety").getBoolean("doesNotCloseContradictionGate"))
        assertTrue(json.getJSONObject("safety").getBoolean("doesNotForceMatrixReady"))
        val literature = json.getJSONArray("literatureSeeds")
        val text = json.toString()
        assertTrue(literature.length() >= 2)
        assertTrue(text.contains("22114171"))
        assertTrue(text.contains("22474371"))
        assertTrue(text.contains("USER_PROVIDED_PMID:24591641"))
        assertTrue(text.contains("correctionNote"))
        assertTrue(text.contains("GSE152202"))
        assertTrue(text.contains("GSE166552"))
        assertTrue(text.contains("MATRIX_READY_CANDIDATE_ONLY_AFTER_GEO_METADATA_MATCH"))
    }
}
