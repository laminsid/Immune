package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ImmuneEvidencePriorMatrixV11038Test {
    private fun lead(snippet: String) = LeadObject(
        leadId = "MANUAL_TEXT_SNIPPET_fe34ffd5ef8adfb5_0",
        source = "TEXT_SNIPPET",
        sourceFamily = EvidenceLeadAndManualSeedPolicy.MANUAL_MODE,
        title = "Manual weak lead",
        snippet = snippet,
        detectedAccessions = emptyList(),
        dataAvailabilityText = "data availability accession pending",
        organism = "human",
        humanLikely = true,
        omicsType = "transcriptomics",
        domain = "unknown_route",
        outcomeLikely = true,
        controlLikely = false,
        timeLikely = false,
        licenseAccessLikely = true,
        sampleSizeLikely = true,
        confidence = 50
    )

    @Test
    fun selectsEbvMolecularMimicryWithoutBreakthroughClaims() {
        val lead = lead("EBV EBNA1 molecular mimicry cross-reactive autoantibody human cohort outcome")
        val metadata = LeadClosureHandoffPolicy.metadataClosure(listOf(lead), emptyList(), emptyList())
        val route = LeadClosureHandoffPolicy.classifyUnknownRoute(listOf(lead), emptyList(), emptyList(), listOf("EBV molecular mimicry"))
        val ebv = EBVLeadVerificationPolicy.evaluate(listOf(lead), emptyList(), metadata, route, listOf("EBV molecular mimicry"))
        val report = ImmuneEvidencePriorMatrix.select(
            steering = null,
            leadObjects = listOf(lead),
            candidates = emptyList(),
            metadataClosure = metadata,
            routeReport = route,
            ebvReport = ebv,
            recentReports = listOf("Induced molecular mimicry EBV")
        )

        assertTrue(report.active)
        assertTrue(report.selectedPriorId == "EBV_MOLECULAR_MIMICRY")
        assertTrue(report.blockedInjection)
        assertTrue(report.noiseGuards.any { it.contains("random", ignoreCase = true) })
        assertTrue(report.forbiddenClaims.any { it.contains("breakthrough", ignoreCase = true) })
        assertFalse(report.nextAction.contains("upgrade", ignoreCase = true))
    }

    @Test
    fun naturalCompoundPriorIsNoiseGuarded() {
        val lead = lead("curcumin quercetin NF-kB oxidative stress transcriptome")
        val metadata = LeadClosureHandoffPolicy.metadataClosure(listOf(lead), emptyList(), emptyList())
        val report = ImmuneEvidencePriorMatrix.select(
            steering = null,
            leadObjects = listOf(lead),
            candidates = emptyList(),
            metadataClosure = metadata,
            routeReport = UnknownRouteClassificationReport.empty(),
            ebvReport = EBVLeadVerificationReport.empty(),
            recentReports = emptyList()
        )

        assertTrue(report.active)
        assertTrue(report.state.contains("SUPPLEMENT_NOISE_GUARDED"))
        assertTrue(report.forbiddenClaims.any { it.contains("supplement", ignoreCase = true) })
        assertTrue(report.noiseGuards.any { it.contains("disabled by default", ignoreCase = true) })
    }

    @Test
    fun learningMonitorIncludesEvidencePriorMatrix() {
        val forager = JSONObject()
            .put("evidencePriorSelectionReport", JSONObject()
                .put("active", true)
                .put("state", "EVIDENCE_PRIOR_EBV_CRITERION_SELECTED")
                .put("selectedPriorId", "EBV_MOLECULAR_MIMICRY")
                .put("selectedRoute", "latent_virus_molecular_mimicry_route")
                .put("queryTerms", org.json.JSONArray(listOf("EBV", "EBNA1", "GSE")))
                .put("requiredGates", org.json.JSONArray(listOf("accession_or_source_id", "control_or_comparator")))
                .put("invalidators", org.json.JSONArray(listOf("No EBV term appears in metadata.")))
                .put("nextAction", "Use EBV prior only inside secondary lookup."))
        val text = LearningRulesUiSummary.renderCompact(forager)

        assertTrue(text.contains("Evidence Prior Matrix", ignoreCase = true) || text.contains("evidence prior", ignoreCase = true))
        assertTrue(text.contains("routing", ignoreCase = true) || text.contains("lookup", ignoreCase = true))
    }
}
