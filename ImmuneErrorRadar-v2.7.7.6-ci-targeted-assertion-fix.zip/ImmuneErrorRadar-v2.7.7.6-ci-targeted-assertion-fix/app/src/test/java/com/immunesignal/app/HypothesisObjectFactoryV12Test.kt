package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HypothesisObjectFactoryV12Test {
    @Test
    fun `negative control required before strong receives penalty not pass bonus`() {
        val card = V12TestFixtures.card(negative = "control_required_before_strong", repeats = 3, causality = 70)
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val score = EvidenceScore.estimate(card, listOf(V12TestFixtures.finding()), gate)
        assertTrue("score should be below a fake controls-passed score", score < 8.5)
    }

    @Test
    fun `weak no control possible is neutral not harsh penalty`() {
        val card = V12TestFixtures.card(negative = "weak_no_control_possible")
        val gate = MinimumDataPackAssessment("PARTIAL", listOf("timestamp"), "", emptyList())
        val score = EvidenceScore.estimate(card, listOf(V12TestFixtures.finding()), gate)
        assertTrue(score >= 5.0)
    }

    @Test
    fun `future passed controls can receive full negative-control evidence points`() {
        val card = V12TestFixtures.card(negative = "controls_passed", repeats = 3, causality = 70)
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val score = EvidenceScore.estimate(card, listOf(V12TestFixtures.finding()), gate)
        assertTrue(score >= 8.0)
    }

    @Test
    fun `data trust no longer double credits human share`() {
        val card = V12TestFixtures.card(evidence = 70)
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val trust = DataTrustScore.estimate(card, listOf(V12TestFixtures.finding(sourceId = "A")), gate)
        assertEquals("base evidence + one source-diversity bonus only", 72, trust)
    }

    @Test
    fun `factory builds a hypothesis object with states and gate fields`() {
        val card = V12TestFixtures.card(id = "autonomic_vascular_axis__psychoneuroimmune_axis", repeats = 3, status = "STRONG_SIGNAL", causality = 70, overall = 80)
        val finding = V12TestFixtures.finding(sourceId = "A")
        val objects = HypothesisObjectFactory.build(listOf(card), listOf(finding), listOf(V12TestFixtures.imported()))
        assertEquals(1, objects.size)
        assertEquals(card.hypothesisId, objects.first().hypothesisId)
        assertTrue(objects.first().nextBestMeasurement.isNotBlank())
    }
}
