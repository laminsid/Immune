package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CognitiveDirectiveRetirementV167Test {
    @Test
    fun coveredDirectiveExportsConsumptionMetadata() {
        val directive = CognitiveNextCycleDirective(
            directiveId = "d_export",
            createdAtMillis = System.currentTimeMillis(),
            sourceCycleId = "cycle_export",
            state = "ACTIVE",
            decisionType = "CONTINUE_EVIDENCE_HUNT",
            routeIntegrity = "HIGH_ROUTE_FIT_REQUIRES_MINIMUM_METADATA",
            action = "Retire when already satisfied.",
            reason = "all terms covered",
            nextSearchTerms = listOf("outcome", "severity"),
            requiredEvidence = listOf("outcome_labels"),
            blockedClaims = defaultBlockedClaims(),
            priority = 80,
            expiresAtMillis = System.currentTimeMillis() + 60_000,
            consumedCount = 0,
            useLimit = 1
        )
        val base = listOf(ResearchQuery("q", "Q", "human outcome severity recovery endpoint", "baseline"))
        val (_, plan) = CognitiveNextCycleBridge.applyToQueries(base, directive, maxQueries = 4)
        val json = ResearchJsonCodec.cognitiveNextCyclePlanToJson(plan)
        assertTrue(plan.directiveConsumed)
        assertEquals("retired_noop_or_already_satisfied", json.optString("consumptionReason"))
        assertTrue(json.optString("routingFingerprint").startsWith("route_"))
        assertEquals(1, json.optInt("useLimit"))
    }
}
