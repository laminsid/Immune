package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMTopicSpecificRouteBuilderV270Test {
    @Test
    fun hantavirusQuestionOpensDedicatedRouteAndDoesNotReuseStressOnlyRoute() {
        val plan = GTIMTopicSpecificRouteBuilderV270.build(
            "Hantavirus HFRS HCPS rodent exposure endothelial capillary leak interferon cytokine PBMC RNA-seq GEO controls"
        )

        assertTrue(plan.active)
        assertEquals("hantavirus_endothelial_interferon_cytokine_route", plan.primaryTopicId)
        assertTrue(plan.routeCascade.any { it.contains("hantavirus", ignoreCase = true) })
        assertTrue(plan.hypotheses.any { it.contains("endothelial", ignoreCase = true) })
        assertTrue(plan.querySeeds.any { it.contains("hantavirus", ignoreCase = true) && it.contains("GSE", ignoreCase = true) })
        assertTrue(plan.connectedDotEdges.any { it.contains("capillary", ignoreCase = true) })
        assertTrue(plan.claimLimit.contains("not_evidence", ignoreCase = true))
    }

    @Test
    fun topicShiftFromStressToHantavirusIsDetectedForLearningLoop() {
        val plan = GTIMTopicSpecificRouteBuilderV270.build(
            question = "Hantavirus Puumala HFRS endothelial interferon platelet RNA-seq",
            previousContext = "stress sleep HPA cortisol EBV HHV-6 IL-6 TNF"
        )

        assertTrue(plan.active)
        assertTrue(plan.topicShiftDetected)
        assertEquals("TOPIC_SHIFT_ROUTE_OPENED", plan.status)
        assertTrue(GTIMTopicSpecificRouteBuilderV270.learningOneLine(plan).contains("hantavirus", ignoreCase = true))
    }

    @Test
    fun dataFeedPlannerAddsTopicSpecificPreflightForHantavirus() {
        val intent = GTIMResearchIntentParserV255.parse(
            "Hantavirus HFRS HCPS rodent exposure endothelial injury interferon cytokine PBMC RNA-seq GEO SRA controls"
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)

        assertTrue(plan.active)
        assertTrue(plan.repositorySearchPlan.any { it.repository == "Topic-Specific Route Builder" })
        assertTrue(plan.bestNextAction.contains("topic-specific route", ignoreCase = true))
        assertTrue(plan.querySeeds.any { it.contains("hantavirus", ignoreCase = true) })
        assertTrue(plan.comparatorTargets.any { it.contains("HFRS", ignoreCase = true) || it.contains("severe", ignoreCase = true) })
        assertTrue(plan.contradictionTargets.any { it.contains("generic viral", ignoreCase = true) || it.contains("lineage", ignoreCase = true) })
    }

    @Test
    fun dynamicUnknownTopicStillGetsIndependentRoute() {
        val plan = GTIMTopicSpecificRouteBuilderV270.build("schistosomiasis granuloma eosinophil fibrosis transcriptome controls")

        assertTrue(plan.active)
        assertTrue(plan.primaryTopicId.startsWith("dynamic_topic_"))
        assertFalse(plan.querySeeds.isEmpty())
        assertTrue(plan.learningTasks.any { it.contains("new route", ignoreCase = true) || it.contains("metadata", ignoreCase = true) })
    }
}
