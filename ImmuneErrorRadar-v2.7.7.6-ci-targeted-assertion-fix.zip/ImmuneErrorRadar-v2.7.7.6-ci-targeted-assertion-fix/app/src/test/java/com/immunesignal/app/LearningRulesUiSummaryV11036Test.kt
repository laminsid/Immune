package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningRulesUiSummaryV11036Test {
    private fun foragerJson(): JSONObject = JSONObject()
        .put("leadClosureHandoffReport", JSONObject()
            .put("active", true)
            .put("state", "LEAD_CLOSURE_HANDOFF_ACTIVE")
            .put("carriedLeadCount", 1)
            .put("missingFields", JSONArray(listOf("accession", "outcome_labels", "control_or_comparator")))
            .put("forcedNextAction", "Run LEAD_OBJECT_SECONDARY_LOOKUP before any broad search")
            .put("pinnedLearningRules", JSONArray(listOf("A weak or off-route lead must be preserved across the next cycle."))))
        .put("metadataClosureReport", JSONObject()
            .put("active", true)
            .put("state", "METADATA_CLOSURE_NEEDS_SECONDARY_LOOKUP")
            .put("closedFields", JSONArray(listOf("human_or_patient_data")))
            .put("missingFields", JSONArray(listOf("accession", "outcome_labels", "control_or_comparator")))
            .put("nextAction", "Close missing metadata"))
        .put("unknownRouteClassificationReport", JSONObject()
            .put("active", true)
            .put("state", "ROUTE_PRIOR_ONLY_NOT_EVIDENCE")
            .put("selectedRoute", "latent_virus_reactivation_route")
            .put("confidence", 82)
            .put("routePriors", JSONArray(listOf(JSONObject()
                .put("routeId", "latent_virus_reactivation_route")
                .put("confidence", 82)
                .put("matchedTerms", JSONArray(listOf("EBV", "HHV-6")))))))
        .put("researchProgressWithoutEvidenceReport", JSONObject()
            .put("active", true)
            .put("successCategories", JSONArray(listOf("weak_lead_preserved", "route_prior_classified"))))
        .put("leadInspectionQueueReport", JSONObject()
            .put("active", true)
            .put("openItems", 1))

    @Test
    fun auditCardShowsLearnedRulesMissingFieldsAndInvalidators() {
        val card = LearningRulesUiSummary.buildCard(foragerJson())

        assertEquals("LEAD_RULES_PINNED_METADATA_OPEN", card.monitorState)
        assertTrue(card.learnedDetails.any { it.contains("weak lead", ignoreCase = true) || it.contains("carried", ignoreCase = true) })
        assertTrue(card.pinnedRules.any { it.contains("EvidenceObject") })
        assertTrue(card.stillMissing.contains("control/comparator"))
        assertTrue(card.invalidators.any { it.contains("EBV/HHV-6/CMV") })
    }

    @Test
    fun compactUiTextRemainsUserFacingAndBounded() {
        val text = LearningRulesUiSummary.renderCompact(foragerJson())

        assertTrue(text.contains("Learning audit monitor"))
        assertTrue(text.contains("Rules kept"))
        assertTrue(text.contains("Invalidate if"))
        assertTrue(text.contains("not proof", ignoreCase = true) || text.contains("EvidenceObject"))
    }
}
