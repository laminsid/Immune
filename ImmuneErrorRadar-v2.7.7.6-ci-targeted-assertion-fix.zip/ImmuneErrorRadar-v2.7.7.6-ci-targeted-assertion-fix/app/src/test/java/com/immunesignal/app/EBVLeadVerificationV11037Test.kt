package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EBVLeadVerificationV11037Test {
    private fun lead(
        snippet: String = "EBV Herpesviridae molecular mimicry human cohort outcome labels but no explicit accession or comparator",
        accessions: List<String> = emptyList()
    ) = LeadObject(
        leadId = "MANUAL_TEXT_SNIPPET_fe34ffd5ef8adfb5_0",
        source = "TEXT_SNIPPET",
        sourceFamily = EvidenceLeadAndManualSeedPolicy.MANUAL_MODE,
        title = "Manual EBV molecular mimicry weak lead",
        snippet = snippet,
        detectedAccessions = accessions,
        dataAvailabilityText = "data availability says accession pending",
        organism = "human",
        humanLikely = true,
        omicsType = "transcriptomics",
        domain = "unknown_route",
        outcomeLikely = true,
        controlLikely = false,
        timeLikely = false,
        licenseAccessLikely = true,
        sampleSizeLikely = true,
        confidence = 50
    )

    @Test
    fun ebvCriterionOpensButBlocksBreakthroughClaims() {
        val metadata = LeadClosureHandoffPolicy.metadataClosure(listOf(lead()), emptyList(), emptyList())
        val route = LeadClosureHandoffPolicy.classifyUnknownRoute(listOf(lead()), emptyList(), emptyList(), listOf("EBV molecular mimicry"))
        val report = EBVLeadVerificationPolicy.evaluate(
            leadObjects = listOf(lead()),
            candidates = emptyList(),
            metadataClosure = metadata,
            routeReport = route,
            recentReports = listOf("User research topic: EBV induced molecular mimicry")
        )

        assertTrue(report.active)
        assertEquals("MANUAL_TEXT_SNIPPET_fe34ffd5ef8adfb5_0", report.targetLeadId)
        assertTrue(report.state.startsWith("EBV_CRITERION"))
        assertTrue(report.matchedTerms.any { it.contains("ebv", ignoreCase = true) })
        assertTrue(report.missingEvidence.contains("control_or_comparator"))
        assertTrue(report.blockedClaims.any { it.contains("breakthrough", ignoreCase = true) })
        assertTrue(report.claimLimit.contains("not_biological_proof"))
    }

    @Test
    fun ebvCriterionCanReachFalsificationReviewOnlyAfterAllGatesClose() {
        val closed = MetadataClosureReport(
            active = true,
            state = "METADATA_CLOSURE_READY_FOR_CONTRADICTION",
            inspectedLeadCount = 1,
            requiredFields = LeadClosureHandoffPolicy.REQUIRED_METADATA_FIELDS,
            closedFields = LeadClosureHandoffPolicy.REQUIRED_METADATA_FIELDS,
            missingFields = emptyList(),
            nextAction = "Run contradiction/negative-control micro-probe."
        )
        val report = EBVLeadVerificationPolicy.evaluate(
            leadObjects = listOf(lead("GSE12345 EBV molecular mimicry human cohort outcome severity healthy control longitudinal no association")),
            candidates = emptyList(),
            metadataClosure = closed,
            routeReport = UnknownRouteClassificationReport.empty(),
            recentReports = listOf("failed replication negative control EBV molecular mimicry")
        )

        assertTrue(report.active)
        assertEquals("EBV_CRITERION_READY_FOR_FALSIFICATION_REVIEW", report.state)
        assertTrue(report.missingEvidence.isEmpty())
        assertTrue(report.allowedNextAction.contains("contradiction", ignoreCase = true))
    }

    @Test
    fun learningMonitorShowsEbvCriterionAsCriterionOnly() {
        val forager = JSONObject()
            .put("ebvLeadVerificationReport", JSONObject()
                .put("active", true)
                .put("state", "EBV_CRITERION_BLOCKED_MINIMUM_METADATA")
                .put("targetLeadId", "MANUAL_TEXT_SNIPPET_fe34ffd5ef8adfb5_0")
                .put("matchedTerms", JSONArray(listOf("ebv", "molecular mimicry")))
                .put("missingEvidence", JSONArray(listOf("control_or_comparator", "time_order")))
                .put("allowedNextAction", "Close EBV criterion metadata before claims.")
                .put("invalidators", JSONArray(listOf("No explicit EBV term appears in metadata."))))
        val text = LearningRulesUiSummary.renderCompact(forager)

        assertTrue(text.contains("EBV criterion", ignoreCase = true))
        assertTrue(text.contains("not biological evidence", ignoreCase = true) || text.contains("not proof", ignoreCase = true))
        assertTrue(text.contains("control/comparator"))
    }
}
