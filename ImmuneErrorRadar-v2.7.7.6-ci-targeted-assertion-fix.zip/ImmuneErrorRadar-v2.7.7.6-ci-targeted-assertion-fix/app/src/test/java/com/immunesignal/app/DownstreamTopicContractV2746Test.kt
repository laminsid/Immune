package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownstreamTopicContractV2746Test {
    @Test
    fun seedBootstrapDoesNotUseDefaultStressPackForAllergy() {
        val queries = GTIMSeedAccessionBootstrapV265.queriesForText("Allergies IgE mast cell eosinophil IL-4 IL-13 dataset comparator", limit = 12)
        val joined = queries.joinToString(" ").lowercase()
        assertTrue(joined.contains("allergy") || joined.contains("ige") || joined.contains("gse250594"))
        assertFalse(joined.contains("22114171"))
        assertFalse(joined.contains("10.1126/science.1211719"))
        assertFalse(joined.contains("gse117882"))
        assertFalse(joined.contains("pesticide"))
    }

    @Test
    fun covidContractKeepsCovidAndBlocksPesticideTemplates() {
        val contract = DownstreamTopicContractV2746.fromText("Covid SARS-CoV-2 interferon PBMC comparator")
        assertEquals("covid_interferon", contract.topicKey)
        assertTrue(DownstreamTopicContractV2746.allowsText("COVID SARS-CoV-2 interferon PBMC RNA-seq GSE", contract))
        assertFalse(DownstreamTopicContractV2746.allowsText("pesticide_gut_barrier_inflammation_bridge food pesticide residue LPS IL-6", contract))
        assertFalse(DownstreamTopicContractV2746.allowsText("allergy IgE mast cell route", contract))
    }

    @Test
    fun allergyContractBlocksCovidAndExposomeTemplates() {
        val contract = DownstreamTopicContractV2746.fromText("Allergies IgE mast cell eosinophil IL-4 IL-13")
        assertEquals("allergy_type2", contract.topicKey)
        assertTrue(DownstreamTopicContractV2746.allowsText("allergy allergic hypersensitivity IgE mast cell eosinophil IL-4 dataset", contract))
        assertFalse(DownstreamTopicContractV2746.allowsText("COVID SARS-CoV-2 interferon PBMC route", contract))
        assertFalse(DownstreamTopicContractV2746.allowsText("PFAS BPA phthalate endocrine immune inflammation route", contract))
    }

    @Test
    fun dataFeedPlannerDoesNotSurfacePesticideForCovidOrAllergy() {
        val covidPlan = GTIMDataFeedPlannerV255.plan(GTIMResearchIntentParserV255.parse("Covid"))
        val allergyPlan = GTIMDataFeedPlannerV255.plan(GTIMResearchIntentParserV255.parse("Allergies"))
        val covidText = (covidPlan.repositorySearchPlan.map { it.query } + covidPlan.querySeeds + covidPlan.bestNextAction).joinToString(" ").lowercase()
        val allergyText = (allergyPlan.repositorySearchPlan.map { it.query } + allergyPlan.querySeeds + allergyPlan.bestNextAction).joinToString(" ").lowercase()
        assertFalse(covidText.contains("pesticide_gut_barrier"))
        assertFalse(covidText.contains("pesticides_gut_immunity"))
        assertFalse(covidText.contains("pfas bpa"))
        assertFalse(allergyText.contains("pesticide_gut_barrier"))
        assertFalse(allergyText.contains("covid sars-cov-2"))
        assertTrue(allergyText.contains("ige") || allergyText.contains("mast"))
    }

    @Test
    fun autonomousMicrobiomeDepressionStillOpensUsefulBridge() {
        val text = "gut bacteria depression tryptophan kynurenine IL-6 TNF human cohort dataset"
        val contract = DownstreamTopicContractV2746.fromText(text)
        assertEquals("microbiome_depression", contract.topicKey)
        assertTrue(contract.allowMicrobiomeBridge)
        val relationship = GTIMRelationshipDiscoveryRouterV2736.build(DownstreamTopicContractV2746.briefRelationshipCorpus(text, text, "", text))
        assertTrue(relationship.active)
        assertEquals("microbiome_depression_il6_bridge", relationship.matchedArchetype)
    }
}
