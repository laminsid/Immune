package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LinkedCognitionSpineEvidenceFirstTest {
    @Test
    fun partialSpineWithNoEvidenceChoosesEvidenceFirstBeforeThinkFirst() {
        val qualityGate = ScientificDiscoveryQualityGateReport.empty().copy(
            active = true,
            allowExecution = false,
            requiredBeforeRun = listOf("no_saved_evidence_object", "outcome_labels", "minimum_metadata"),
            executionDecision = "Do not upgrade; acquire evidence first."
        )
        val runbook = ScientificDiscoveryRunbookReport.empty().copy(
            active = true,
            evidenceChecklist = listOf("outcome_labels", "time_order"),
            routeDecision = "Do not spend a broad cycle before a dataset accession search."
        )

        val report = LinkedCognitionSpineEngine.build(
            evidenceClosure = EvidenceClosureReport.empty(),
            postSearchThinking = PostSearchThinkingReport.empty(),
            thinkingContinuity = ThinkingContinuityReport.empty(),
            hypothesisGraph = HypothesisGraphReport.empty(),
            cognitiveMomentum = CognitiveMomentumReport.empty(),
            datasetForaging = DatasetForagingReport.empty(),
            qualityGate = qualityGate,
            runbook = runbook,
            executedQueries = emptyList(),
            priorSpineWasActive = true
        )

        assertTrue(report.active)
        assertTrue(report.searchDecision.startsWith("EVIDENCE_FIRST"))
        assertEquals("MAX_1_ACCESSION_QUERY_RETMAX_10", report.queryBudget)
        assertTrue(report.openEvidenceKeys.contains("outcome_labels"))
    }

    @Test
    fun priorDirectiveKeepsEvidenceFirstModeAndQueryBudget() {
        val latest = """
            {
              "linkedCognitionSpineReport": {
                "active": true,
                "searchDecision": "EVIDENCE_FIRST: run one bounded accession search before thinking; claims remain locked.",
                "routeMode": "GUARDED_RESEARCH",
                "openEvidenceKeys": ["outcome_labels", "minimum_metadata"],
                "governingDecision": "Acquire one dataset accession before thinking."
              },
              "scientificDiscoveryRunbookReport": {
                "primaryQueryClause": "GSE OR GEO outcome severity longitudinal control metadata"
              }
            }
        """.trimIndent()

        val directive = LinkedCognitionSpineEngine.priorSearchDirective(listOf(latest))

        assertTrue(directive.active)
        assertEquals("EVIDENCE_FIRST_ACCESSION_SEARCH", directive.mode)
        assertEquals(1, directive.queries.size)
        assertTrue(directive.queries.first().query.contains("outcome_labels") || directive.queries.first().query.contains("outcome"))
    }
}
