package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchCyclePathMaintenanceGuardTest {
    @Test
    fun connectedWhenPlanAuditAndDirectiveOwnerMatch() {
        val directive = directive(active = true, owner = "evidence_closure")
        val phaseSpine = ResearchCyclePhaseSpine.build()
        val plan = ResearchCyclePlanStageReport.empty().copy(
            active = true,
            governingLayer = "evidence_closure"
        )
        val audit = ResearchCyclePhaseAuditReport.empty().copy(
            active = true,
            lockViolations = emptyList()
        )

        val report = ResearchCyclePathMaintenanceGuard.build(directive, phaseSpine, plan, audit)

        assertEquals("CONNECTED", report.state)
        assertTrue(report.weakHandoffs.isEmpty())
        assertTrue(report.linkedStages.contains("directive_owner_consistent"))
    }

    @Test
    fun ownerMismatchBecomesRepairHandoff() {
        val report = ResearchCyclePathMaintenanceGuard.build(
            directive = directive(active = true, owner = "linked_cognition_spine"),
            phaseSpine = ResearchCyclePhaseSpine.build(),
            planStage = ResearchCyclePlanStageReport.empty().copy(active = true, governingLayer = "evidence_closure"),
            phaseAudit = ResearchCyclePhaseAuditReport.empty().copy(active = true)
        )

        assertEquals("REPAIR_HANDOFFS", report.state)
        assertTrue(report.weakHandoffs.any { it.startsWith("DIRECTIVE_OWNER_MISMATCH") })
    }

    private fun directive(active: Boolean, owner: String) = ResearchSearchDirective(
        active = active,
        mode = if (active) "EVIDENCE_CLOSURE_NARROW_SEARCH" else "BROAD_SEARCH_ALLOWED",
        governingLayer = owner,
        queries = emptyList(),
        reason = "test",
        maxQueries = if (active) 1 else 4,
        maxResultsPerQuery = if (active) 3 else 20,
        blockDatasetFirst = active,
        trace = listOf("test")
    )
}
