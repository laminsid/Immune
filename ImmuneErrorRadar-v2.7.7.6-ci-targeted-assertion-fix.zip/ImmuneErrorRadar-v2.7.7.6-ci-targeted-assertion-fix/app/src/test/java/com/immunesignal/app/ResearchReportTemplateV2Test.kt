package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchReportTemplateV2Test {
    @Test
    fun `brief formats evidence score with one decimal`() {
        val report = baseReport(7.399999999)
        val text = ResearchReportTemplateV2.renderBrief(report)
        assertTrue(text.contains("Evidence 7.4/10"))
        assertFalse(text.contains("7.399999999"))
    }

    @Test
    fun `brief includes discovery action and bias alarm`() {
        val text = ResearchReportTemplateV2.renderBrief(baseReport(6.0))
        assertTrue(text.contains("Discovery Action:"))
        assertTrue(text.contains("Bias Alarm:"))
    }

    @Test
    fun `brief handles missing hypothesis objects`() {
        val report = JSONObject()
            .put("researchStateSummary", JSONObject().put("discoveryState", "Off").put("biasRiskState", "Normal"))
            .put("knowledgeDelta", JSONObject())
            .put("hypothesisObjects", JSONArray())
        val text = ResearchReportTemplateV2.renderBrief(report)
        assertTrue(text.contains("No hypothesis object yet"))
    }

    @Test
    fun `score formatter uses one decimal`() {
        assertTrue(ScoreFormat.oneDecimal(8.0).contains("8.0"))
        assertTrue(ScoreFormat.oneDecimal(8.249).contains("8.2"))
    }

    private fun baseReport(evidence: Double): JSONObject {
        val summary = JSONObject()
            .put("discoveryState", "Early")
            .put("biasRiskState", "Watch")
            .put("nextEvidence", "next")
            .put("discoveryAction", "act")
            .put("biasAlarm", "alarm")
        val delta = JSONObject()
            .put("newSourcesSaved", 1)
            .put("repeatedSourcesSkipped", 2)
            .put("steeredQueriesGenerated", 3)
        val top = JSONObject()
            .put("status", "WATCH")
            .put("discoveryState", "Early")
            .put("label", "lead")
            .put("dataTrustScore", 60)
            .put("evidenceScore10", evidence)
            .put("causalityScore", 50)
            .put("minimumDataPackStatus", "PARTIAL")
            .put("signalFlip", "no_major_flip")
            .put("nextBestMeasurement", "measure")
        return JSONObject()
            .put("researchStateSummary", summary)
            .put("knowledgeDelta", delta)
            .put("hypothesisObjects", JSONArray().put(top))
    }
}
