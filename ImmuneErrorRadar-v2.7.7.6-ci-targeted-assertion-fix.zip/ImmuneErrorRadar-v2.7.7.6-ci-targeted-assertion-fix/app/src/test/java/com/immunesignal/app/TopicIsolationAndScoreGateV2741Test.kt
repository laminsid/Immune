package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TopicIsolationAndScoreGateV2741Test {
    @Test
    fun researchLeadDoesNotBecomeHeavyMetalExposure() {
        val intent = GTIMResearchIntentParserV255.parse(
            "Bacteria + depression research lead with IL-6 TNF cytokine comparator"
        )
        assertTrue(intent.diseasePhenotype.any { it.contains("Depression", ignoreCase = true) })
        assertTrue(intent.triggerExposure.any { it.contains("bacteria", ignoreCase = true) || it.contains("microbiome", ignoreCase = true) })
        assertFalse(intent.triggerExposure.any { it.contains("heavy-metal", ignoreCase = true) || it.contains("Water heavy", ignoreCase = true) })
    }

    @Test
    fun topicGateDetectsFallbackContaminationAndCapsEvidence() {
        val snapshot = RuntimeCrashSafetyAndTopicGuardV2740.capture("Bacteria + depression")
        val report = JSONObject()
            .put("datasetForagingReport", JSONObject()
                .put("scoreSeparation", JSONObject()
                    .put("routeFitScore", 86)
                    .put("hypothesisConfidenceScore", 83))
                .put("mechanismDiscoveryDossierReport", JSONObject()
                    .put("matrixAnalysisGate", "DGE_NOT_READY_METADATA_GAP")
                    .put("globalTranslationalDossier", JSONObject()
                        .put("researchIntent", JSONObject()
                            .put("intentCompletenessScore", 62)
                            .put("routeConstructionScore", 86))
                        .put("discoveryEvidenceSplit", JSONObject()
                            .put("threeDimensionalScore", JSONObject()
                                .put("dataQualityScore", 100)
                                .put("noveltyScore", 88)
                                .put("biologicalPlausibilityScore", 86)
                                .put("discoveryValueScore", 83)
                                .put("evidenceConfidenceScore", 86)))
                    )))
            .put("briefText", "Disease / phenotype: allergy | Trigger: Water heavy-metal immune axis | pesticide_gut_barrier_inflammation_bridge | lookup-only not evidence | GSE117882 PMID:22114171 10.1126/science.1211719")

        val gate = TopicIsolationAndScoreGateV2741.evaluate(report, snapshot)
        val adjusted = gate.optJSONObject("adjustedScores") ?: JSONObject()
        assertTrue(gate.optBoolean("templateFallbackDetected"))
        assertTrue((gate.optJSONArray("contaminatingSignals")?.length() ?: 0) >= 2)
        assertTrue(adjusted.optInt("evidenceScore") <= 25)
        assertTrue(adjusted.optInt("dataQualityScore") <= 40)
    }

    @Test
    fun routeContextUsesCurrentRawTopicBeforePriorMemory() {
        val snapshot = RuntimeCrashSafetyAndTopicGuardV2740.capture("Longevity")
        val context = TopicIsolationAndScoreGateV2741.searchRouteContext(
            snapshot,
            fallbackContext = "prior allergy Water heavy-metal immune axis pesticide route"
        )
        assertTrue(context.contains("USER_TOPIC=Longevity"))
        assertTrue(context.contains("Longevity", ignoreCase = true))
        assertFalse(context.contains("Water heavy-metal", ignoreCase = true))
    }
}
