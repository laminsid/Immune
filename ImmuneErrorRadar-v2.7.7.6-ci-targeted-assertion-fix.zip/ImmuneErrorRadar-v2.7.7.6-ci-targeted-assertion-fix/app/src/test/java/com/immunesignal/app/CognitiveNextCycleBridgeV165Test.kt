package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CognitiveNextCycleBridgeV165Test {
    @Test
    fun convertsIntegratedPathIntoBoundedFollowUpQuery() {
        val reportJson = JSONObject()
            .put("id", "cycle_test_165")
            .put(
                "cognitivePathIntegrationReport",
                JSONObject()
                    .put("active", true)
                    .put("state", "INTEGRATED_PATH_ACTIVE")
                    .put("routeIntegrity", "HIGH_ROUTE_FIT_REQUIRES_MINIMUM_METADATA")
                    .put("linkedWarnings", JSONArray(listOf("minimum metadata missing")))
                    .put(
                        "decision",
                        JSONObject()
                            .put("decisionType", "CONTINUE_EVIDENCE_HUNT")
                            .put("action", "Parse minimum metadata and outcome labels before any upgrade.")
                            .put("reason", "Map gap and specialist protocol agree on the next evidence.")
                            .put("blocksHypothesisUpgrade", true)
                            .put("nextSearchTerms", JSONArray(listOf("human", "RNA-seq", "GSE")))
                            .put("requiredEvidence", JSONArray(listOf("minimum_metadata", "outcome_labels", "time_course")))
                    )
            )

        val directive = CognitiveNextCycleBridge.directiveFromReportJson(reportJson)
        assertNotNull(directive)
        val base = listOf(
            ResearchQuery(
                id = "q_base",
                label = "Base query",
                query = "interferon response dataset",
                reason = "baseline"
            )
        )
        val (queries, plan) = CognitiveNextCycleBridge.applyToQueries(base, directive, maxQueries = 4)

        assertTrue(plan.active)
        assertTrue(plan.addedFollowUpQuery)
        assertTrue(queries.first().id.startsWith("q_cognitive_path_followup_"))
        assertTrue(queries.any { it.query.contains("sample metadata", ignoreCase = true) })
        assertTrue(queries.any { it.query.contains("outcome", ignoreCase = true) })
        assertEquals("next_cycle_routing_only_not_biological_proof", plan.claimLimit)
    }

    @Test
    fun expiredDirectiveDoesNotChangeQueries() {
        val expired = CognitiveNextCycleDirective(
            directiveId = "expired",
            createdAtMillis = 1L,
            sourceCycleId = "cycle_old",
            state = "ACTIVE",
            decisionType = "CONTINUE_EVIDENCE_HUNT",
            routeIntegrity = "TEST",
            action = "old action",
            reason = "old reason",
            nextSearchTerms = listOf("outcome"),
            requiredEvidence = listOf("outcome_labels"),
            blockedClaims = defaultBlockedClaims(),
            priority = 80,
            expiresAtMillis = 2L,
            consumedCount = 0
        )
        val base = listOf(ResearchQuery("q", "Q", "baseline", "baseline"))
        val (queries, plan) = CognitiveNextCycleBridge.applyToQueries(base, expired, maxQueries = 4)
        assertEquals(base, queries)
        assertTrue(!plan.active)
    }
}
