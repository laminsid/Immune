package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TopicRunIsolationPolicyV2742Test {
    @Test
    fun currentTopicSteeringOverridesStoredPriorTemplate() {
        val snapshot = RuntimeCrashSafetyAndTopicGuardV2740.capture("Longevity")
        val stored = ResearchSteeringProfile(
            profileId = "prior",
            createdAtMillis = 1L,
            variables = listOf("allergy", "Water heavy-metal immune axis"),
            focusQuestion = "prior allergy pesticide route",
            requiredTerms = listOf("allergy"),
            excludedTerms = emptyList(),
            inferredAxes = listOf("type2_allergy_axis")
        )
        val chosen = TopicRunIsolationPolicyV2742.chooseSteering(snapshot, stored)
        val text = listOf(chosen?.focusQuestion, chosen?.variables?.joinToString(" "), chosen?.inferredAxes?.joinToString(" ")).joinToString(" ")
        assertTrue(text.contains("Longevity", ignoreCase = true))
        assertFalse(text.contains("Water heavy-metal", ignoreCase = true))
    }

    @Test
    fun oldAllergyHeavyMetalReportsAreNotCarriedIntoDepressionRun() {
        val snapshot = RuntimeCrashSafetyAndTopicGuardV2740.capture("Bacteria + depression")
        val reports = listOf(
            "Disease / phenotype: allergy | Trigger: Water heavy-metal immune axis | pesticide_gut_barrier | GSE117882",
            "Bacteria depression microbiome IL-6 TNF tryptophan kynurenine human cohort comparator"
        )
        val scoped = TopicRunIsolationPolicyV2742.scopedRecentReports(reports, snapshot)
        assertTrue(scoped.size == 1)
        assertTrue(scoped.first().contains("depression", ignoreCase = true))
        assertFalse(scoped.first().contains("Water heavy-metal", ignoreCase = true))
    }

    @Test
    fun queryFilterKeepsCurrentTopicAndSuppressesUnrequestedPesticideTemplate() {
        val snapshot = RuntimeCrashSafetyAndTopicGuardV2740.capture("Depression")
        val queries = listOf(
            ResearchQuery("q_bad", "old pesticide", "pesticide gut barrier inflammation GSE PRJNA", "old template"),
            ResearchQuery("q_good", "depression", "depression IL-6 TNF microbiome human comparator", "current topic")
        )
        val filtered = TopicRunIsolationPolicyV2742.filterQueriesForCurrentTopic(queries, snapshot, maxQueries = 4)
        val text = filtered.joinToString(" ") { it.query }
        assertTrue(text.contains("Depression", ignoreCase = true))
        assertTrue(text.contains("depression", ignoreCase = true))
        assertFalse(text.contains("pesticide", ignoreCase = true))
    }
}
