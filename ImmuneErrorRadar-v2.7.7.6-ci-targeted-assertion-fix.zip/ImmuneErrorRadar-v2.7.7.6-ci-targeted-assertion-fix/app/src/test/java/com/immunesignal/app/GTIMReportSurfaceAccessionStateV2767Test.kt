package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMReportSurfaceAccessionStateV2767Test {

    @Test
    fun globalBriefEvidenceLineDoesNotSayNoAccessionWhenSeedHandlesAreQueued() {
        val report = JSONObject()
            .put("runtime", JSONObject().put("engineVersion", "v2.7.3-final-proof-benchmark-learning-locked"))
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid")
                .put("normalizedTopic", "Covid"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray()
                            .put("GSE152202")
                            .put("GSE166552")
                            .put("GSE152418")
                            .put("GSE157103")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("v2.7.6.7-report-surface-accession-state-fix"))
        assertTrue(rendered.contains("accessions=4"))
        assertFalse(rendered.contains("accessions=4 | matrix=DGE_NOT_READY_NO_ACCESSION"))
        assertTrue(rendered.contains("DGE_NOT_READY_SOFT_MATRIX") || rendered.contains("DGE_NOT_READY_ACCESSION_HANDLE_CAPTURED_MATRIX_UNRESOLVED"))
        assertTrue(rendered.contains("Research value:"))
    }
}
