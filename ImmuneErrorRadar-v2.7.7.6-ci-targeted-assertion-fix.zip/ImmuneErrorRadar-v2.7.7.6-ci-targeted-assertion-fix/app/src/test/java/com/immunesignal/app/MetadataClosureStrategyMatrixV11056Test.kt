package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MetadataClosureStrategyMatrixV11056Test {
    @Test
    fun weakOffRouteTranscriptomeSnippetForcesMinimumMetadataProbeNotFail() {
        val candidate = DatasetAccessionCandidate(
            accession = "DATASET_ACCESSION_UNRESOLVED",
            source = "PUBMED_ACCESSION_MINING",
            organismHint = "human cohort",
            conditionLabelsHint = "Long COVID ME/CFS EBV",
            outcomeLabelsHint = "fatigue severity",
            triggerResponseOutcomeHint = "sleep deprivation HPA axis cortisol",
            timeCourseHint = "longitudinal baseline follow-up",
            sampleSizeHint = "unknown sample size",
            dataType = "transcriptome RNA-seq",
            usabilityScore = 10,
            status = "OFF_ROUTE_USEFUL_DATASET",
            sourceFindingId = "PMID_TEST_1",
            sourceTitle = "Human transcriptome accession snippet mentions EBV, Long COVID, cortisol and GEO GSE data availability",
            sourceUrl = "",
            reasons = listOf("WEAK_DATASET_LEAD", "data availability text requires secondary lookup")
        )
        val report = MetadataClosureStrategyMatrixV11056.evaluate(
            steering = ResearchSteeringProfile(
                profileId = "test",
                createdAtMillis = 0L,
                variables = listOf("sleep deprivation", "HPA axis", "cortisol"),
                focusQuestion = "bridge EBV Long COVID ME/CFS human transcriptome accession metadata closure",
                requiredTerms = listOf("GSE", "RNA-seq", "control"),
                excludedTerms = emptyList(),
                inferredAxes = listOf("psychoneuroimmune", "viral reactivation")
            ),
            leadObjects = emptyList(),
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            attempts = listOf(
                DatasetSourceAttempt(
                    sourceFamily = "PUBMED_ACCESSION_MINING",
                    ncbiDb = "pubmed",
                    query = "EBV Long COVID transcriptome GSE accession",
                    attempted = true,
                    idsFound = 3,
                    candidatesExtracted = 1,
                    status = "EXPLORATORY_LEADS_CAPTURED",
                    reason = "test"
                )
            ),
            topicFit = TopicFitMetadataParseReport.empty().copy(
                active = true,
                preferredLane = "RNA_TRANSCRIPTOMIC_IMMUNE_STATE_LANE",
                forcedMinimumMetadataCount = 1
            ),
            metadataClosure = MetadataClosureReport.empty().copy(
                active = true,
                state = "METADATA_CLOSURE_NEEDS_SECONDARY_LOOKUP",
                inspectedLeadCount = 1,
                missingFields = listOf("accession", "control_or_comparator")
            ),
            recentReports = emptyList()
        )

        assertTrue(report.active)
        assertEquals("PASS_NO_FAIL_ON_WEAK_OR_OFF_ROUTE_LEAD", report.executionLock)
        assertTrue(report.textMiningDrillDownForced)
        assertTrue(report.minimumMetadataProbes.isNotEmpty())
        assertFalse(report.state.contains("FAIL"))
        assertFalse(report.state.contains("NOT_RUN"))
        assertTrue(report.queryStreams.any { it.streamId == "PUBMED_FULL_TEXT_ACCESSION_DRILLDOWN" })
        assertTrue(report.leanRuntimeLogicGates.any { it.gateId == "G1_WEAK_OR_OFF_ROUTE_NEVER_FAIL" && it.blocksFailOrNotRun })
        assertTrue(report.hardClaimGates.any { it.contains("no diagnosis") })
    }
}
