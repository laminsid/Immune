package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DataAvailabilityAccessionQueryV11025Test {
    @Test
    fun accessionMiningQueriesPrioritizeDataAvailabilityAndDomainVocabulary() {
        val route = DirectDatasetSourceRouter.routeForSourceFamily("PUBMED_ACCESSION_MINING")!!
        val queries = DatasetQueryCompiler.compileForRoute(
            route = route,
            shards = emptyList(),
            memory = PersistentFailureMemorySnapshot.empty(),
            domainVocabulary = listOf("histamine", "mast cell", "diabetes")
        )

        assertTrue(queries.any { it.id.startsWith("q_v142_pubmed_accession_mining_source_") })
        assertTrue(queries.first().query.contains("data availability", ignoreCase = true))
        assertTrue(queries.any { it.query.contains("deposited", ignoreCase = true) })
        assertTrue(queries.any { it.query.contains("histamine", ignoreCase = true) })
        assertTrue(queries.any { it.reason.contains(DataAvailabilityAccessionQueryPolicy.CLAIM_LIMIT) })
    }

    @Test
    fun dataAvailabilityPolicyDoesNotAffectDirectGeoOrSraRoutes() {
        val geo = DirectDatasetSourceRouter.routeForSourceFamily("GEO_GDS")!!
        val queries = DatasetQueryCompiler.compileForRoute(
            route = geo,
            shards = emptyList(),
            memory = PersistentFailureMemorySnapshot.empty(),
            domainVocabulary = listOf("histamine", "diabetes")
        )

        assertTrue(queries.any { it.id.startsWith("q_v142_geo_gds_source_") })
        assertFalse(queries.first().reason.contains(DataAvailabilityAccessionQueryPolicy.CLAIM_LIMIT))
        assertFalse(queries.first().query.contains("histamine", ignoreCase = true))
    }
}
