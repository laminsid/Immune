package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMDGEExecutionBridgeV2770Test {

    @Test
    fun softDatasetLeadSurfacesDgeExecutionBridgeWithoutEvidenceUpgrade() {
        val report = JSONObject()
            .put("runtime", JSONObject().put("engineVersion", "v2.7.3-final-proof-benchmark-learning-locked"))
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid")
                .put("normalizedTopic", "Covid"))
            .put("metadataClosureStrategyMatrixReport", JSONObject()
                .put("state", "DGE_NOT_READY_NO_ACCESSION")
                .put("blockingGaps", JSONArray()
                    .put("ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED")))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("v2.7.7.0-dge-readiness-execution-bridge"))
        assertTrue(rendered.contains("DGE execution bridge:"))
        assertTrue(rendered.contains("DGE_EXECUTION_BRIDGE_READY_SOFT") || rendered.contains("METADATA_ENGINEERING_REQUIRED_BEFORE_DGE"))
        assertTrue(rendered.contains("DGE execution next:"))
        assertTrue(rendered.contains("MATRIX_DOWNLOAD_REQUIRED"))
        assertTrue(rendered.contains("boundary=review-only"))
        assertFalse(rendered.contains("STRONG_SIGNAL_REVIEW_ONLY"))
        assertTrue(rendered.contains("not biological proof") || rendered.contains("boundary=review-only"))
    }

    @Test
    fun matrixAuditCardHelperCarriesExecutionBridgeLines() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))

        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202"),
            paperUnderstandingSummary = "GSE152202 SARS-CoV-2 patient cohort severe mild RNA-seq transcriptomics data availability sample traits"
        )

        val bridge = GTIMMatrixAuditCardV2745.dgeExecutionBridgeLine(card)
        val next = GTIMMatrixAuditCardV2745.dgeExecutionNextLine(card)

        assertTrue(bridge.contains("DGE execution bridge:"))
        assertTrue(bridge.contains("state="))
        assertTrue(bridge.contains("matrix="))
        assertTrue(bridge.contains("metadata="))
        assertTrue(bridge.contains("comparator="))
        assertTrue(next.contains("DGE execution next:"))
        assertTrue(next.contains("review-only"))
        assertFalse(card.evidenceUpgradeState == "STRONG_SIGNAL_REVIEW_ONLY")
    }
}
