package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SourceMetadataEnrichmentV1113Test {
    @Test
    fun manualSnippetDoesNotBecomeConfirmedAccessionCandidate() {
        val candidate = DatasetAccessionCandidate(
            accession = "MANUAL_TEXT_SNIPPET_7ac87b27e5ff827b_0",
            source = "MANUAL_EVIDENCE_SEED_MODE",
            organismHint = "human cohort",
            conditionLabelsHint = "SLE Long COVID IL-6 TNF-alpha",
            outcomeLabelsHint = "response nonresponse",
            triggerResponseOutcomeHint = "transcriptome RNA-seq data availability",
            timeCourseHint = "baseline follow-up",
            sampleSizeHint = "unknown",
            dataType = "RNA-seq transcriptome",
            usabilityScore = 10,
            status = "OFF_ROUTE_USEFUL_DATASET",
            sourceFindingId = "manual_7ac87b27e5ff827b_0",
            sourceTitle = "Manual text snippet without a real GEO or SRA accession",
            sourceUrl = "",
            reasons = listOf("WEAK_DATASET_LEAD", "OFF_ROUTE")
        )

        val report = ResearchGradeMechanismDossierV1110.evaluate(
            steering = null,
            matrix = MetadataClosureStrategyMatrixReport.empty().copy(hyperDriveModeActive = true),
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            leadObjects = emptyList(),
            attempts = emptyList()
        )

        assertEquals("ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED", report.state)
        assertEquals("ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED", report.accessionValidationGate)
        assertTrue(report.accessionCandidates.isEmpty())
        assertTrue(report.sourceMetadataEnrichmentCards.isNotEmpty())
        assertEquals("ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED", report.sourceMetadataEnrichmentCards.first().accessionResolutionState)
        assertTrue(report.sourceMetadataEnrichmentCards.first().accessionPatternQuery.contains("GSE[0-9]*"))
    }

    @Test
    fun realGeoAccessionCreatesCandidateWithSourceSpecificParser() {
        val candidate = DatasetAccessionCandidate(
            accession = "GSE12345",
            source = "GEO_GDS",
            organismHint = "human patients",
            conditionLabelsHint = "healthy control; SLE case; baseline",
            outcomeLabelsHint = "response nonresponse",
            triggerResponseOutcomeHint = "series matrix supplementary data sample metadata",
            timeCourseHint = "baseline follow-up",
            sampleSizeHint = "n=12",
            dataType = "RNA-seq transcriptome series matrix",
            usabilityScore = 55,
            status = "ACCESSION_TEXT_FOUND",
            sourceFindingId = "geo_gse12345",
            sourceTitle = "GSE12345 human SLE RNA-seq series matrix healthy control case",
            sourceUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE12345",
            reasons = listOf("data availability", "series matrix", "sample metadata", "healthy control", "case")
        )

        val report = ResearchGradeMechanismDossierV1110.evaluate(
            steering = null,
            matrix = MetadataClosureStrategyMatrixReport.empty().copy(hyperDriveModeActive = true),
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            leadObjects = emptyList(),
            attempts = emptyList()
        )

        assertTrue(report.accessionCandidates.isNotEmpty())
        val card = report.accessionCandidates.first()
        assertEquals("GSE12345", card.accessionId)
        assertEquals("CONFIRMED_ACCESSION", card.accessionStatus)
        assertEquals("GEO_SERIES_SAMPLE_MATRIX_PARSER", card.sourceSpecificParser)
        assertTrue(card.repositoryLookupQuery.contains("GSE12345 GEO sample metadata"))
        assertTrue(card.matrixFileHints.contains("series matrix"))
        assertTrue(report.matrixReadinessScore > 0)
    }
}
