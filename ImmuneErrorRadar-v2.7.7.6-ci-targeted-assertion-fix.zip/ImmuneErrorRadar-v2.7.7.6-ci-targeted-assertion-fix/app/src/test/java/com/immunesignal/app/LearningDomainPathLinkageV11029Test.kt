package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningDomainPathLinkageV11029Test {
    private fun domainReport() = DomainExpertiseMemoryPolicy.DomainExpertiseReport(
        active = true,
        mode = DomainExpertiseMemoryPolicy.MODE,
        summary = "Domain expertise memory stabilized 1 domain track.",
        cards = listOf(
            DomainExpertiseMemoryPolicy.DomainExpertiseCard(
                domainId = "antihistamine_histamine_mast_cell",
                label = "Antihistamines / histamine / mast-cell axis",
                expertiseState = "MATURE_DOMAIN_PRIOR_NEEDS_FALSIFICATION",
                expertiseScore = 79,
                stableResearchPriors = listOf("Histamine terms are search priors only."),
                workingVocabulary = listOf("histamine", "mast cell", "allergy"),
                protectedFromReset = listOf("Do not discard after one failed sweep."),
                falsificationGates = listOf("accession", "outcome labels"),
                nextLearningAction = "Run bounded data availability probe.",
                priorExposureCount = 4
            )
        ),
        stablePriorCount = 1,
        protectedBeliefCount = 1,
        carriedForwardDomainCount = 1,
        matureDomainCount = 1,
        continuityState = "MATURE_DOMAIN_EXPERTISE_ACTIVE",
        continuitySummary = "carried=1, mature=1",
        nextAction = "Deepen mature domain track before jumping domains."
    )

    private fun matureProbeReport() = MatureDomainEvidenceProbePolicy.Report(
        active = true,
        state = "MATURE_DOMAIN_PROBE_ATTEMPTED_KEEP_PRIORS",
        summary = "Mature domain probe is active.",
        selectedDomains = listOf("antihistamine_histamine_mast_cell"),
        querySeeds = listOf("histamine mast cell allergy GSE data availability accession"),
        probeAttempted = true,
        relaxedInterpretationAllowed = true,
        nextAction = "Continue mature-domain accession probe; claims remain locked."
    )

    private fun pathReport() = DatasetForagingPathLinkageReport(
        active = true,
        state = "CONNECTED_MATURE_DOMAIN_PROBE",
        coreSourcesAttempted = listOf("GEO_GDS", "SRA_PRJNA", "IMM_PORT_SDY", "PUBMED_ACCESSION_MINING"),
        adjacentSourcesAttempted = listOf("PUBMED_ADJACENT_DOMAIN_MINING"),
        matureProbeAttempted = true,
        attemptedCoreCount = 4,
        totalQueryPathCount = 6,
        coreQueryPathCount = 4,
        adjacentQueryPathCount = 1,
        matureProbeQueryPathCount = 1,
        coverageState = "PASS_COVERAGE_CONNECTED",
        warnings = emptyList(),
        handoffSummary = "core connected; mature connected",
        nextAction = "Continue mature-domain accession probe."
    )

    @Test
    fun connectsLearningDomainExpertiseAndMatureProbe() {
        val report = LearningDomainPathLinkageGuard.evaluate(
            executedQueries = listOf(
                ResearchQuery(
                    id = "q1",
                    label = "mature-domain data availability probe",
                    query = "histamine mast cell allergy GSE data availability accession outcome labels control",
                    reason = "test"
                )
            ),
            attempts = listOf(
                DatasetSourceAttempt(MatureDomainEvidenceProbePolicy.SOURCE_FAMILY, "pubmed", "histamine mast cell GSE accession", true, 0, 0, "MATURE_DOMAIN_PROBE_NO_FRESH_EVIDENCE", "test")
            ),
            learningRuleMatches = listOf(
                LearningRuleMatch(
                    ruleId = "allergy_aging_inverse_candidate",
                    coverage = 0.75,
                    matchedSignals = listOf("high_allergy_reactivity", "fast_recovery"),
                    missingSignals = listOf("low_inflammaging_load"),
                    interpretation = "routing only",
                    confidencePolicy = "hypothesis_only"
                )
            ),
            domainReport = domainReport(),
            matureProbeReport = matureProbeReport(),
            pathLinkageReport = pathReport(),
            noCandidateRecords = listOf(NoCandidateLearningRecord("PUBMED_ACCESSION_MINING", "q1", "NO_FRESH_PUBMED_EVIDENCE", "accession_like_id", "PUBMED_ADJACENT_DOMAIN_MINING", "test")),
            queryFeedbackPlan = QueryFeedbackPlan(active = true, improvedQueries = emptyList(), improvements = emptyList(), summary = "feedback linked"),
            failurePatternReport = FailurePatternReport.empty()
        )

        assertEquals("CONNECTED_LEARNING_DOMAIN_MATURE_PROBE", report.state)
        assertEquals(1, report.learningRuleMatchCount)
        assertEquals(1, report.matureDomainCount)
        assertTrue(report.domainVocabularyLinkedToQueries)
        assertTrue(report.learningRulesLinkedToQueries)
        assertTrue(report.queryFeedbackLinked)
        assertTrue(report.matureProbeLinkedToDomainExpertise)
        assertTrue(report.warnings.isEmpty())
    }

    @Test
    fun warnsWhenDomainExpertiseIsNotVisibleInQueries() {
        val report = LearningDomainPathLinkageGuard.evaluate(
            executedQueries = listOf(ResearchQuery("q2", "generic", "generic immune response dataset", "test")),
            attempts = emptyList(),
            learningRuleMatches = emptyList(),
            domainReport = domainReport(),
            matureProbeReport = MatureDomainEvidenceProbePolicy.Report.empty(),
            pathLinkageReport = pathReport(),
            noCandidateRecords = emptyList(),
            queryFeedbackPlan = QueryFeedbackPlan.passthrough(emptyList()),
            failurePatternReport = FailurePatternReport.empty()
        )

        assertEquals("LEARNING_DOMAIN_LINKAGE_WARNINGS", report.state)
        assertTrue(report.warnings.any { it.contains("Domain expertise exists", ignoreCase = true) })
    }
}
