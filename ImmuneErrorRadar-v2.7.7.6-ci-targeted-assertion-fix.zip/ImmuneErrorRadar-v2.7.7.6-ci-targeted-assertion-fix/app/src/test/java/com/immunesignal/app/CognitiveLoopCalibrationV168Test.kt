package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CognitiveLoopCalibrationV168Test {
    @Test
    fun calibratedLoopRewardsMetadataAndMapProgress() {
        val plan = CognitiveNextCyclePlan(
            active = true,
            directiveId = "directive_helped",
            appliedQueryCount = 1,
            addedFollowUpQuery = true,
            appliedTerms = listOf("outcome", "time-course"),
            blockedClaims = defaultBlockedClaims(),
            summary = "Applied bounded follow-up.",
            directiveConsumed = true,
            consumptionReason = "applied_once",
            routingFingerprint = "route_helped",
            useLimit = 1
        )
        val report = CognitiveLoopCalibrationEngine.calibrate(
            nextCyclePlan = plan,
            datasetForagingReport = DatasetForagingReport.empty().copy(
                active = true,
                candidates = listOf(sampleCandidate("GSE_TEST")),
                parsedMetadata = listOf(sampleParsedMetadata("GSE_TEST")),
                cumulativeEvidence = CumulativeEvidenceReport(score = 42, state = "CANDIDATE", upgrades = listOf("metadata parsed"), downgrades = emptyList(), rationale = listOf("usable metadata"))
            ),
            knowledgeMapReport = KnowledgeMapReport.empty().copy(active = true, newNodesThisCycle = 1, newLinksThisCycle = 1),
            epistemicBeliefReport = EpistemicBeliefReport.empty().copy(active = true, revisedBeliefs = 1),
            specializedReasoningReport = SpecializedReasoningReport.empty().copy(active = true, evidenceGaps = listOf(EvidenceGapCard("OUTCOME_LABELS", "OPEN", 80, "needed", "collect outcomes")), decisiveNextTest = "Collect outcome labels"),
            learningOsReport = LearningOsReport.empty()
        )
        assertTrue(report.active)
        assertEquals("DIRECTIVE_HELPED", report.outcome)
        assertTrue(report.calibrationScore >= 70)
        assertTrue(report.rewardSimilarDirective)
        assertTrue(!report.dampenSimilarDirective)
    }

    @Test
    fun calibratedLoopDampensStalledDirective() {
        val plan = CognitiveNextCyclePlan(
            active = false,
            directiveId = "directive_stalled",
            appliedQueryCount = 0,
            addedFollowUpQuery = false,
            appliedTerms = emptyList(),
            blockedClaims = defaultBlockedClaims(),
            summary = "No change.",
            suppressedReason = "already covered",
            directiveConsumed = false,
            routingFingerprint = "route_stalled",
            useLimit = 1
        )
        val report = CognitiveLoopCalibrationEngine.calibrate(
            nextCyclePlan = plan,
            datasetForagingReport = DatasetForagingReport.empty().copy(active = true, candidates = listOf(sampleCandidate("GSE_STALLED"))),
            knowledgeMapReport = KnowledgeMapReport.empty().copy(active = true),
            epistemicBeliefReport = EpistemicBeliefReport.empty().copy(active = true),
            specializedReasoningReport = SpecializedReasoningReport.empty().copy(active = true),
            learningOsReport = LearningOsReport.empty().copy(
                incident = ResearchIncidentReceipt(
                    incidentId = "i",
                    rootCauses = listOf("NO_OUTCOME_LABELS", "METADATA_ONLY"),
                    observedSignals = emptyList(),
                    failedLane = "dataset",
                    severity = "MEDIUM",
                    createdAtMillis = 1L
                )
            )
        )
        assertTrue(report.active)
        assertEquals("DIRECTIVE_DID_NOT_HELP_ENOUGH", report.outcome)
        assertTrue(report.dampenSimilarDirective)
        assertTrue(!report.rewardSimilarDirective)
    }

    private fun sampleCandidate(accession: String): DatasetAccessionCandidate = DatasetAccessionCandidate(
        accession = accession,
        source = "GEO_GDS",
        organismHint = "human",
        conditionLabelsHint = "infection recovery",
        outcomeLabelsHint = "recovery severity",
        triggerResponseOutcomeHint = "infection immune response outcome",
        timeCourseHint = "baseline day_7",
        sampleSizeHint = "unknown",
        dataType = "RNA-seq",
        usabilityScore = 70,
        status = "CANDIDATE",
        sourceFindingId = "finding_$accession",
        sourceTitle = "Human transcriptomic dataset with outcome labels",
        sourceUrl = "https://example.test/$accession",
        reasons = listOf("test candidate")
    )

    private fun sampleParsedMetadata(accession: String): ParsedDatasetMetadata = ParsedDatasetMetadata(
        accession = accession,
        sourceFamily = "GEO_GDS",
        organism = "human",
        sampleSizeStatus = "sample_size_unknown",
        conditionLabels = listOf("infection", "recovery"),
        outcomeLabels = listOf("recovery", "severity"),
        controlLabels = listOf("healthy_control"),
        timeCourseLabels = listOf("baseline", "day_7"),
        tissueOrSource = "blood",
        assayType = "RNA-seq",
        contrastiveSlots = listOf("recovery_vs_severity"),
        metadataQualityScore = 82,
        usabilityVerdict = "USABLE_FOR_TEST",
        evidenceObjectEligible = true,
        reasons = listOf("test metadata")
    )
}
