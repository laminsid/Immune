package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMDiseaseSymptomOntologyBootstrapV2755Test {

    @Test
    fun ontologyAssetsAndRuntimeProfilesExist() {
        assertTrue(GTIMDiseaseSymptomOntologyBootstrapV2755.diseaseProfiles.size >= 10)
        assertTrue(GTIMDiseaseSymptomOntologyBootstrapV2755.searchKeywordsFor(GTIMPrimaryAnchorV2740.DIABETES_METABOLIC_INFLAMMATION).isNotEmpty())
        assertFalse(GTIMDiseaseSymptomOntologyBootstrapV2755.canPromoteLearnedEdge(GTIMEvidenceLabelV2740.WEAK_LEAD, hasValidAccession = true, outsideContract = false))
        assertTrue(GTIMDiseaseSymptomOntologyBootstrapV2755.canPromoteLearnedEdge(GTIMEvidenceLabelV2740.CONFIRMED_EVIDENCE, hasValidAccession = true, outsideContract = false))
    }

    @Test
    fun knownPathogensDoNotFallToAutonomousUnknown() {
        val flu = GTIMRunDecisionContractFactoryV2740.build("Influenza H1N1 host response")
        val dengue = GTIMRunDecisionContractFactoryV2740.build("Dengue fever vascular leakage cytokines")
        val tb = GTIMRunDecisionContractFactoryV2740.build("Tuberculosis macrophage granuloma")
        assertEquals(GTIMPrimaryAnchorV2740.INFLUENZA_RESPIRATORY_VIRAL, flu.primaryAnchor)
        assertEquals(GTIMPrimaryAnchorV2740.DENGUE_VECTOR_BORNE_VIRAL, dengue.primaryAnchor)
        assertEquals(GTIMPrimaryAnchorV2740.TUBERCULOSIS_GRANULOMATOUS_IMMUNE, tb.primaryAnchor)
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED, flu.runMode)
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED, dengue.runMode)
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED, tb.runMode)
    }

    @Test
    fun symptomQueriesStaySyndromeExplorationNotDiagnosis() {
        val fatigue = GTIMRunDecisionContractFactoryV2740.build("fatigue low energy immune inflammation")
        val fever = GTIMRunDecisionContractFactoryV2740.build("fever cytokine differential")
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_SYNDROME_EXPLORATION, fatigue.runMode)
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_SYNDROME_EXPLORATION, fever.runMode)
        assertEquals(GTIMClaimModeV2740.RESEARCH_DIRECTION_ONLY, fatigue.claimMode)
        assertEquals(GTIMClaimModeV2740.RESEARCH_DIRECTION_ONLY, fever.claimMode)
    }

    @Test
    fun specialCasesPreservePreviousFixes() {
        val t2d = GTIMRunDecisionContractFactoryV2740.build("type 2 diabetes insulin resistance inflammation")
        val gutDepression = GTIMRunDecisionContractFactoryV2740.build("gut bacteria depression tryptophan kynurenine IL-6 TNF")
        val yeastPcos = GTIMRunDecisionContractFactoryV2740.build("yeast fungal exposure PCOS thyroid")
        assertEquals(GTIMPrimaryAnchorV2740.T2D_INSULIN_RESISTANCE_INFLAMMATION, t2d.primaryAnchor)
        assertEquals(GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION, gutDepression.primaryAnchor)
        assertEquals(GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE, yeastPcos.primaryAnchor)
    }

    @Test
    fun ontologyKeywordsFeedDownstreamQueryWithoutBreakingContract() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Dengue DENV cytokine")
        val query = GTIMDownstreamContractAdaptersV2740.safeQuery(c)
        assertTrue(query.contains("dengue", ignoreCase = true) || query.contains("DENV", ignoreCase = true))
        assertFalse(query.contains("allergy_type2_ige", ignoreCase = true))
    }
}
