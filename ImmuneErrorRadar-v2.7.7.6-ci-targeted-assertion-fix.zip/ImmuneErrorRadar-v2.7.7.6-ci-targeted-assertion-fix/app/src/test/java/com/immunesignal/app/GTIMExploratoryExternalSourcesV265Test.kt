package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class GTIMExploratoryExternalSourcesV265Test {
    private fun assetText(name: String): String {
        val candidates = listOf(
            File("app/src/main/assets/$name"),
            File("src/main/assets/$name"),
            File("../app/src/main/assets/$name"),
            File(System.getProperty("user.dir"), "app/src/main/assets/$name"),
            File(System.getProperty("user.dir"), "src/main/assets/$name")
        )
        val found = candidates.firstOrNull { it.isFile }
            ?: error("Missing asset $name. Tried: ${candidates.joinToString { it.path }}")
        return found.readText()
    }

    @Test
    fun exploratoryRuntimeThresholdsAreLoweredWithoutLoweringStrongSignalClaims() {
        assertEquals(1, RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES)
        assertEquals(1, RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_QUERY_PATHS)
        assertEquals(1, RuntimeFeatureFlags.MIN_RELAXED_DOMAIN_EXPOSURES)
        assertEquals(1, RuntimeFeatureFlags.MIN_EXPLORATION_SANDBOX_QUERY_VARIANTS)
        assertEquals(3, RuntimeFeatureFlags.MIN_DOMAIN_EXPERTISE_SCORE_TO_REUSE)
        assertEquals(1, RuntimeFeatureFlags.MIN_DOMAIN_EXPERTISE_MATURITY_EXPOSURES)
        assertEquals(0.25, RuntimeFeatureFlags.MIN_LEARNING_RULE_COVERAGE, 0.0001)
        assertEquals(5, RuntimeFeatureFlags.EXPLORATORY_MIN_ROUTE_FIT_FOR_RULE_V265)
        assertEquals(1, RuntimeFeatureFlags.EXPLORATORY_MIN_CONFIDENCE_V265)
        assertEquals(65, RuntimeFeatureFlags.STRONG_SIGNAL_CAUSALITY_THRESHOLD)
        assertEquals(65, RuntimeFeatureFlags.STRONG_SIGNAL_EVIDENCE_THRESHOLD)
        assertTrue(RuntimeFeatureFlags.ENABLE_EXPLORATORY_RUNTIME_RELAXATION_V265)
        assertTrue(RuntimeFeatureFlags.ENABLE_EXPLORATORY_ROUTE_LINKAGE_PRECHECK_V266)
    }

    @Test
    fun parserAndPlannerExposeEuropePmcOpenAlexAndSeedBootstrap() {
        val intent = GTIMResearchIntentParserV255.parse(
            "Long COVID EBV interferon PBMC RNA-seq healthy controls data availability Europe PMC OpenAlex GSE"
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        assertTrue(plan.repositorySearchPlan.any { it.repository == "Europe PMC" })
        assertTrue(plan.repositorySearchPlan.any { it.repository == "OpenAlex" })
        assertTrue(plan.repositorySearchPlan.any { it.repository == "Seed Accession Bootstrap" })
        assertTrue(plan.querySeeds.any { it.contains("GSE", ignoreCase = true) && it.contains("claim-limit", ignoreCase = true) })
    }

    @Test
    fun seedAccessionsAssetIsClaimBoundedAndContainsKeyAxes() {
        val json = JSONObject(assetText("gtim_seed_accessions_v2.6.5.json"))
        assertEquals("seed_accessions_for_lookup_only_not_evidence", json.getString("claim_limit"))
        val arr = json.getJSONArray("seedAccessions")
        assertTrue(arr.length() >= 8)
        val axes = (0 until arr.length()).map { arr.getJSONObject(it).getString("axis") }.toSet()
        assertTrue(axes.contains("viral_long_covid_interferon"))
        assertTrue(axes.contains("cancer_tcell_exhaustion_tumor_microenvironment"))
        assertTrue(axes.contains("hiv_aids_chronic_viral_immunodeficiency"))
        assertTrue(axes.contains("fungal_th17_neutrophil_defense"))
        assertTrue(axes.contains("epidemic_pandemic_immune_response"))
    }

    @Test
    fun networkSecurityConfigIncludesExternalResearchSources() {
        val candidates = listOf(
            File("app/src/main/res/xml/network_security_config.xml"),
            File("src/main/res/xml/network_security_config.xml"),
            File(System.getProperty("user.dir"), "app/src/main/res/xml/network_security_config.xml"),
            File(System.getProperty("user.dir"), "src/main/res/xml/network_security_config.xml")
        )
        val text = candidates.first { it.isFile }.readText()
        assertTrue(text.contains("www.ebi.ac.uk"))
        assertTrue(text.contains("europepmc.org"))
        assertTrue(text.contains("api.openalex.org"))
        assertTrue(text.contains("api.ncbi.nlm.nih.gov"))
        assertTrue(text.contains("api.crossref.org"))
        assertTrue(text.contains("cleartextTrafficPermitted=\"false\""))
    }
}
