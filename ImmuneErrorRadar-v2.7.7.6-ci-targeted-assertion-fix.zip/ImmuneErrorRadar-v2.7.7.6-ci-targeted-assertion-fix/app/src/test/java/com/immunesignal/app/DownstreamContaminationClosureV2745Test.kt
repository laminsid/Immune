package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownstreamContaminationClosureV2745Test {
    @Test
    fun knownPriorSeedsDoNotFallbackIntoUnrelatedTopics() {
        val seeds = GTIMKnownPriorEvidenceSeedsV269.queriesForText("Allergies IgE mast cell IL-4 IL-13 dataset comparator")
        assertTrue(seeds.isEmpty())
        val handles = GTIMKnownPriorEvidenceSeedsV269.handlesForText("Depression microbiome kynurenine IL-6 TNF cohort")
        assertTrue(handles.isEmpty())
    }

    @Test
    fun exposomeBridgeDoesNotOpenFromGenericGutOrResearchLeadText() {
        val plan = GTIMExposomeImmuneBridgeV267.closeCycle("gut bacteria depression research lead comparator lookup only")
        assertFalse(plan.active)
        assertEquals("NO_EXPOSOME_IMMUNE_PATH_TRIGGERED", plan.closureState)
    }

    @Test
    fun topicRouteBuilderDoesNotTreatResearchLeadAsHeavyMetal() {
        val plan = GTIMTopicSpecificRouteBuilderV270.build("Covid research lead lookup only interferon PBMC comparator")
        assertTrue(plan.active)
        assertEquals("covid_interferon_pasc_host_response_route", plan.primaryTopicId)
        assertFalse(plan.primaryTopicId.contains("exposome", ignoreCase = true))
    }

    @Test
    fun allergyRouteStaysAllergyNotExposome() {
        val plan = GTIMTopicSpecificRouteBuilderV270.build("Allergies IgE mast cell eosinophil IL-4 IL-13 comparator")
        assertTrue(plan.active)
        assertEquals("allergy_type2_ige_mast_eosinophil_route", plan.primaryTopicId)
    }

    @Test
    fun scoreGateCapsDataFeedWhenOnlyLookupNotEvidence() {
        val snapshot = RuntimeCrashSafetyAndTopicGuardV2740.capture("Allergies")
        val report = JSONObject()
            .put("datasetForagingReport", JSONObject()
                .put("mechanismDiscoveryDossierReport", JSONObject()
                    .put("globalTranslationalDossier", JSONObject()
                        .put("dataFeedPlan", JSONObject().put("dataFeedPlanScore", 100))
                        .put("researchIntent", JSONObject().put("intentCompletenessScore", 20))
                    )
                )
            )
            .put("briefText", "DGE_NOT_READY_NO_ACCESSION lookup-only not evidence Comparator: not specified Assay: not specified")
        val gate = TopicIsolationAndScoreGateV2741.evaluate(report, snapshot)
        val adjusted = gate.optJSONObject("adjustedScores") ?: JSONObject()
        assertTrue(adjusted.optInt("dataFeedScore") <= 60)
        assertTrue(adjusted.optInt("evidenceScore") <= 35)
    }
}
