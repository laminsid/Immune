package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AxisMatcherBoundaryTest {
    @Test
    fun ppiDoesNotMatchInsideShipping() {
        assertFalse(AxisMatcher.match("shipping delay and logistics").contains("gastric_acid_gut_axis"))
    }

    @Test
    fun ppiMatchesAsTerm() {
        assertTrue(AxisMatcher.match("PPI exposure and reflux history").contains("gastric_acid_gut_axis"))
    }

    @Test
    fun multiWordAndHyphenTermsStillMatch() {
        val axes = AxisMatcher.match("single-cell RNA-seq with t-cell activation")
        assertTrue(axes.contains("rna_transcriptomic_axis"))
        assertTrue(axes.contains("tcell_activation_axis"))
    }
}
