package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ImmuneLearningValueModePolicyV11033Test {
    @Test
    fun userTopicWithNoEvidenceActivatesLearningValueMode() {
        val active = ImmuneLearningValueModePolicy.shouldForceDatasetFirst(
            steering = ResearchSteeringProfile(
                profileId = "s1",
                createdAtMillis = 1L,
                variables = listOf("Rheumatoid arthritis", "immune response", "inflammation"),
                focusQuestion = ImmuneTopicPromptPolicy.focusQuestion("Rheumatoid arthritis"),
                requiredTerms = listOf("immune", "dataset", "outcome"),
                excludedTerms = emptyList(),
                inferredAxes = listOf("tnf_il6_autoimmune_axis")
            ),
            importedSignals = listOf(
                ImportedReportSignal(
                    reportId = "i1",
                    createdAtMillis = 1L,
                    title = "Single topic prompt",
                    matchedAxes = listOf("tnf_il6_autoimmune_axis"),
                    extractedKeywords = listOf("rheumatoid", "immune"),
                    preview = ImmuneTopicPromptPolicy.importedLearningNote("Rheumatoid arthritis")
                )
            ),
            importedRawTexts = listOf(ImmuneTopicPromptPolicy.importedLearningNote("Rheumatoid arthritis")),
            recentReports = listOf("NO_EVIDENCE_OBJECT_NO_UPGRADE dataset candidates: 0 evidence objects: 0")
        )

        assertTrue(active)
    }

    @Test
    fun nonImmuneGeneralTopicWithoutImmuneRouteDoesNotForceDatasetFirst() {
        val active = ImmuneLearningValueModePolicy.shouldForceDatasetFirst(
            steering = null,
            importedSignals = listOf(
                ImportedReportSignal(
                    reportId = "i2",
                    createdAtMillis = 1L,
                    title = "Single topic prompt",
                    matchedAxes = emptyList(),
                    extractedKeywords = listOf("turbine", "engine"),
                    preview = "User topic: aircraft engine mechanics only"
                )
            ),
            importedRawTexts = listOf("aircraft engine mechanics only"),
            recentReports = listOf("NO_EVIDENCE_OBJECT_NO_UPGRADE dataset candidates: 0 evidence objects: 0")
        )

        assertFalse(active)
    }
}
