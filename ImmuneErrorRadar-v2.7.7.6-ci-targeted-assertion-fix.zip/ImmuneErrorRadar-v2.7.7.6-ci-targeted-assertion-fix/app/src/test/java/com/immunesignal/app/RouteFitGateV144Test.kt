package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RouteFitGateV144Test {
    @Test
    fun offRouteNickelSkinDatasetDoesNotUpgradeAntiviralHypothesis() {
        val candidate = DatasetAccessionCandidate(
            accession = "GSE250594",
            source = "GEO/NCBI",
            organismHint = "human_candidate",
            conditionLabelsHint = "allergy/contact-dermatitis/skin labels candidate",
            outcomeLabelsHint = "outcome/response labels candidate",
            triggerResponseOutcomeHint = "trigger-response-outcome candidate",
            timeCourseHint = "unknown",
            sampleSizeHint = "20 participants",
            dataType = "single-cell transcriptomics",
            usabilityScore = 92,
            status = "USABLE_LEAD_NEEDS_INSPECTION",
            sourceFindingId = "NCBI_GEO_GDS:GSE250594",
            sourceTitle = "GSE250594 — Single cell analysis of clinically resolved epidermal skin from nickel-challenged individuals treated with either anakinra or placebo",
            sourceUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE250594",
            reasons = emptyList()
        )
        val finding = ResearchFinding(
            source = "NCBI_GEO_GDS",
            sourceId = "GSE250594",
            title = candidate.sourceTitle,
            published = "2026/04/28",
            url = candidate.sourceUrl,
            matchedAxes = listOf("type2_allergy_axis", "rna_transcriptomic_axis", "tcell_activation_axis"),
            noveltyScore = 80,
            bridgeSignal = "Direct dataset-source candidate from GEO_GDS; dataset route allergy_contact_dermatitis_il1_skin; target route antiviral_interferon_timing; inspect metadata before hypothesis upgrade.",
            whyItMatters = "Route-fit must be checked before using it for any hypothesis.",
            evidence = EvidenceAssessment("human_relevant", "human", "human_randomized_trial", true, 88, emptyList()),
            causality = CausalityAssessment(41, 10, 55, 50, 0, 0, emptyList()),
            negativeControl = NegativeControlAssessment("watch_requires_controls", "watch", "watch", "watch", emptyList()),
            personalPattern = PersonalPatternAssessment(0, "none", emptyList(), "Verify labels."),
            sanityFlags = listOf("DIRECT_DATASET_SOURCE", "ROUTE_FIT_PENDING")
        )

        val result = RouteFitGate.evaluate(listOf(candidate), listOf(finding), emptyList()).first()

        assertEquals("allergy_contact_dermatitis_il1_skin", result.datasetRoute)
        assertEquals("antiviral_interferon_timing", result.targetRoute)
        assertEquals("OFF_ROUTE_DATASET", result.status)
        assertTrue(result.blocksHypothesisUpgrade)
    }
}
