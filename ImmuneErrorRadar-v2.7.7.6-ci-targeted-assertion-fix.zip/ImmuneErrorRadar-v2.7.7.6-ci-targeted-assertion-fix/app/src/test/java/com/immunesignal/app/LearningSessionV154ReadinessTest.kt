package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningSessionV154ReadinessTest {
    @Test
    fun runtimeFlagsExposeStableSessionSchema() {
        assertSchemaAtLeast(RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION, 1, 5, 4)
        assertTrue(RuntimeFeatureFlags.ENABLE_LEARNING_SESSION_UI)
        assertEquals("learning_session_not_biological_proof", RuntimeFeatureFlags.LEARNING_SESSION_CLAIM_LIMIT)
    }

    private fun assertSchemaAtLeast(schema: String, minMajor: Int, minMinor: Int, minPatch: Int) {
        val parts = schema.split(".").map { it.toIntOrNull() ?: 0 }
        val normalized = listOf(
            parts.getOrElse(0) { 0 },
            parts.getOrElse(1) { 0 },
            parts.getOrElse(2) { 0 }
        )
        val isAtLeast = when {
            normalized[0] != minMajor -> normalized[0] > minMajor
            normalized[1] != minMinor -> normalized[1] > minMinor
            else -> normalized[2] >= minPatch
        }
        assertTrue("Schema version $schema must stay >= $minMajor.$minMinor.$minPatch", isAtLeast)
    }

    @Test
    fun uiReportUsesActualSessionTimeLimit() {
        val session = LearningSession(
            sessionId = "session_limit_test",
            sessionType = SessionType.INCREMENTAL,
            startedAt = 1000L,
            status = SessionStatus.PAUSED,
            timeLimit = 20L * 60L * 1000L,
            phases = LearningSessionIntegrityGuard.expectedPhaseNames.map { PhaseState(it, PhaseStatus.PENDING, 0) },
            checkpoint = SessionCheckpoint(null, null, LearningSessionIntegrityGuard.expectedPhaseNames, true, 2000L),
            claimLimits = emptyMap(),
            accumulatedTimeUsed = 0L
        )

        val report = ProgressTracker.generateUIReport(session)
        assertTrue(report.contains("Limit: 20m 0s"))
    }
}
