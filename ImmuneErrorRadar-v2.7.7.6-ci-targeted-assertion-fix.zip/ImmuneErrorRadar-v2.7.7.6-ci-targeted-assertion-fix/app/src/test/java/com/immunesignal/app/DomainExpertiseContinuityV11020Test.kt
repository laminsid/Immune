package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainExpertiseContinuityV11020Test {
    private fun priorReport(domainId: String): String = JSONObject()
        .put("datasetForagingReport", JSONObject()
            .put("domainExpertiseReport", JSONObject()
                .put("cards", JSONArray().put(JSONObject().put("domainId", domainId)))))
        .toString()

    @Test
    fun carriedDomainExpertiseMaturesBeforeJumpingDomains() {
        val attempts = listOf(
            DatasetSourceAttempt(
                sourceFamily = "PUBMED_ADJACENT_DOMAIN_MINING",
                ncbiDb = "pubmed",
                query = "histamine mast cell antihistamine immune transcriptome dataset no treatment",
                attempted = true,
                idsFound = 0,
                candidatesExtracted = 0,
                status = "NO_DATASET",
                reason = "research-only adjacent domain mining; no treatment, no dose, no clinical recommendation"
            )
        )
        val report = DomainExpertiseMemoryPolicy.build(
            attempts = attempts,
            queries = listOf(
                ResearchQuery(
                    id = "q_v11020_domain_continuity",
                    label = "domain continuity",
                    query = attempts.first().query,
                    reason = "no treatment, no dose, no clinical recommendation"
                )
            ),
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            recentReports = listOf(
                priorReport("antihistamine_histamine_mast_cell"),
                priorReport("antihistamine_histamine_mast_cell"),
                priorReport("antihistamine_histamine_mast_cell")
            )
        )

        val card = report.cards.first { it.domainId == "antihistamine_histamine_mast_cell" }
        assertEquals("MATURE_DOMAIN_EXPERTISE_ACTIVE", report.continuityState)
        assertTrue(report.matureDomainCount >= 1)
        assertTrue(card.priorExposureCount >= RuntimeFeatureFlags.MIN_DOMAIN_EXPERTISE_MATURITY_EXPOSURES)
        assertTrue(card.expertiseState.contains("MATURE"))
        assertTrue(card.continuityAction.contains("deepen", ignoreCase = true))
        assertTrue(report.claimLimit.endsWith("not_biological_proof"))
    }
}
