package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EvidenceAcquisitionV137Test {
    @Test
    fun resolvesExplicitDatasetAccessionAndScoresMetadata() {
        val candidates = DatasetAccessionResolver.extract(
            text = "Human asthma cohort RNA-seq GSE123456 with baseline and follow-up severity outcome labels after allergen challenge, n=120 patients.",
            sourceFindingId = "PubMed:1",
            sourceTitle = "test",
            sourceUrl = "https://example.test"
        )

        assertTrue(candidates.any { it.accession == "GSE123456" })
        val top = candidates.first { it.accession == "GSE123456" }
        assertTrue(top.usabilityScore >= 70)
        assertTrue(top.organismHint.startsWith("human"))
        assertFalse(top.outcomeLabelsHint == "unknown")
    }

    @Test
    fun repeatedNoDatasetFailureCreatesRootCauseGateAndRegressionVector() {
        val signature = FailureSignature(
            newUsefulSources = 0,
            repeatedSkipped = 20,
            metadataOnlyRatio = 0.0,
            sameLaneFailureCount = 3,
            abstractFetchFailures = 0,
            datasetCandidateCount = 0,
            hypothesisDeltaCount = 0,
            failedLane = "EXPLORE_BROAD"
        )
        val readiness = DiscoveryReadinessScorer.score(emptyList(), emptyList())
        val report = ResearchLearningLoopEngine.build(
            signature = signature,
            findings = emptyList(),
            datasets = emptyList(),
            evidenceObjects = emptyList(),
            discoveryReadiness = readiness
        )

        assertTrue(report.incident.rootCauses.contains("REPEATED_PMIDS"))
        assertTrue(report.incident.rootCauses.contains("NO_DATASET_ACCESSION"))
        assertTrue(report.preventiveGates.any { it.gateId == "LANE_COOLDOWN" })
        assertTrue(report.preventiveGates.any { it.gateId == "FORCE_DATASET_ACCESSION_SEARCH" })
        assertTrue(report.regressionVectors.isNotEmpty())
        assertEquals("NO_EVIDENCE_OBJECT_NO_UPGRADE", report.hypothesisUpdateGateStatus)
    }

    @Test
    fun queryPivotAloneDoesNotAllowHypothesisUpgrade() {
        val report = ResearchReportV3Builder.build(
            findings = emptyList(),
            hypothesisObjects = emptyList(),
            learningDeltas = listOf(
                LearningDeltaCard(
                    hypothesisId = "HYP_TEST",
                    deltaType = "status_change",
                    previousStatus = "WEAK",
                    currentStatus = "SUPPORTED",
                    signalFlip = "none",
                    decisionImpact = "query pivot only",
                    nextAction = "continue"
                )
            ),
            datasetCandidates = emptyList(),
            pivot = PivotDecision("GENERAL_TO_CONTRADICTION", "test", "contradiction_search", "failed to replicate", 70),
            repeatedSkipped = 20,
            global = GlobalImmuneIntelligenceReport(
                mode = "test",
                datasetCandidates = emptyList(),
                axisMap = emptyList(),
                triggerResponseEdges = emptyList(),
                globalHypotheses = emptyList(),
                antiviralResponseNotes = emptyList(),
                nextGlobalDatasetNeeded = "",
                globalDiscoveryAction = "",
                globalBiasAlarm = ""
            ),
            evidenceObjects = emptyList(),
            learningOs = LearningOsReport.empty(),
            discoveryReadiness = DiscoveryReadinessReport.empty()
        )

        assertTrue(report.hypothesisChanged.contains("No hypothesis upgraded"))
        assertFalse(report.hypothesisChanged.contains("WEAK → SUPPORTED"))
    }

    @Test
    fun previousLearningGateCreatesForcedNextPivot() {
        val learning = LearningOsReport(
            incident = ResearchIncidentReceipt("i1", listOf("NO_DATASET_ACCESSION"), listOf("new=0"), "EXPLORE", "HIGH", 1L),
            preventiveGates = listOf(
                PreventiveGateDecision(
                    gateId = "FORCE_DATASET_ACCESSION_SEARCH",
                    rootCause = "NO_DATASET_ACCESSION",
                    action = "Force dataset accession query before broad PubMed.",
                    forcedNextIntent = "dataset_accession_search",
                    forcedQuerySeed = "GSE OR SDY immune response outcome",
                    blocksHypothesisUpgrade = true
                )
            ),
            regressionVectors = emptyList(),
            laneCooldowns = emptyList(),
            discoveryReadiness = DiscoveryReadinessReport.empty(),
            hypothesisUpdateGateStatus = "NO_EVIDENCE_OBJECT_NO_UPGRADE",
            nextLearningAction = "Force dataset accession query."
        )
        val json = org.json.JSONObject().put("learningOsReport", ResearchLearningLoopEngine.learningOsToJson(learning)).toString()
        val pivot = ResearchLearningLoopEngine.pivotFromRecentReports(listOf(json))

        assertEquals("LEARNING_OS_FORCED_GATE", pivot.pivotType)
        assertEquals("dataset_accession_search", pivot.nextIntent)
        assertTrue(pivot.nextQuerySeed.contains("GSE"))
    }
}
