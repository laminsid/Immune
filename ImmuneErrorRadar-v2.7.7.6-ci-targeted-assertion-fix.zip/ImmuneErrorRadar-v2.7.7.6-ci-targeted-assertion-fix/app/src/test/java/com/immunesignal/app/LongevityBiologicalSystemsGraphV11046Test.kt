package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LongevityBiologicalSystemsGraphV11046Test {
    private fun lead(snippet: String) = LeadObject(
        leadId = "MANUAL_TEXT_SNIPPET_longevity_0",
        source = "TEXT_SNIPPET",
        sourceFamily = EvidenceLeadAndManualSeedPolicy.MANUAL_MODE,
        title = "Manual biological systems lead",
        snippet = snippet,
        detectedAccessions = emptyList(),
        dataAvailabilityText = "dataset accession pending",
        organism = "human",
        humanLikely = true,
        omicsType = "transcriptomics",
        domain = "biological_systems",
        outcomeLikely = true,
        controlLikely = false,
        timeLikely = false,
        licenseAccessLikely = true,
        sampleSizeLikely = true,
        confidence = 55
    )

    @Test
    fun mapsLifestyleExposureToBiomarkerDatasetOutcomeContradictionPath() {
        val lead = lead("sleep circadian screen light cortisol HRV CRP IL-6 immune inflammation cohort")
        val metadata = LeadClosureHandoffPolicy.metadataClosure(listOf(lead), emptyList(), emptyList())
        val ontology = BiomedicalResearchOntologyV11041.evaluate(null, listOf(lead), emptyList(), EvidencePriorSelectionReport.empty(), emptyList())
        val prior = ImmuneEvidencePriorMatrix.select(null, listOf(lead), emptyList(), metadata, UnknownRouteClassificationReport.empty(), EBVLeadVerificationReport.empty(), emptyList())
        val bridge = BiomedicalConceptBridgeV11042.evaluate(ontology, prior, EBVLeadVerificationReport.empty(), metadata, emptyList())
        val tech = ModernMedicalTechnologyIntelligenceV11043.evaluate(ontology, bridge, prior, EBVLeadVerificationReport.empty(), metadata, emptyList())
        val report = LongevityBiologicalSystemsGraphV11046.evaluate(
            steering = null,
            leadObjects = listOf(lead),
            candidates = emptyList(),
            ontology = ontology,
            conceptBridge = bridge,
            modernTech = tech,
            viral = ViralCountermeasureReport.empty(),
            evidencePrior = prior,
            metadataClosure = metadata,
            recentReports = emptyList()
        )

        assertTrue(report.active)
        assertTrue(report.selectedLane == "CIRCADIAN_SLEEP_INTELLIGENCE")
        assertTrue(report.exposurePathways.first().datasetTemplate.contains("sleep", ignoreCase = true))
        assertTrue(report.biomarkersRequired.any { it.equals("CRP", ignoreCase = true) })
        assertTrue(report.contradictionSearchTerms.any { it.contains("no association", ignoreCase = true) || it.contains("failed replication", ignoreCase = true) })
        assertTrue(report.missingData.contains("control_or_comparator"))
        assertTrue(report.guardrails.any { it.contains("no treatment", ignoreCase = true) })
    }

    @Test
    fun blocksHealthAdviceAndKeepsHerbsAsExposureOnly() {
        val lead = lead("honey wormwood eucalyptus curcumin quercetin natural compound immune cytokines")
        val metadata = LeadClosureHandoffPolicy.metadataClosure(listOf(lead), emptyList(), emptyList())
        val report = LongevityBiologicalSystemsGraphV11046.evaluate(
            steering = null,
            leadObjects = listOf(lead),
            candidates = emptyList(),
            ontology = BiomedicalResearchOntologyReport.empty(),
            conceptBridge = BiomedicalConceptBridgeReport.empty(),
            modernTech = ModernMedicalTechnologyReport.empty(),
            viral = ViralCountermeasureReport.empty(),
            evidencePrior = EvidencePriorSelectionReport.empty(),
            metadataClosure = metadata,
            recentReports = emptyList()
        )

        assertTrue(report.selectedLane == "HERBS_FOODS_EXPOSURE_CONTROL_LANE")
        assertTrue(report.exposurePathways.first().pathway.contains("noise", ignoreCase = true))
        assertTrue(report.invalidators.any { it.contains("control", ignoreCase = true) })
        assertFalse(HealthAdviceClaimGuardV11046.isResearchRoutingOnly("give a dose recommendation"))
    }

    @Test
    fun learningMonitorSurfacesSystemsGraphWithoutAdviceClaims() {
        val forager = JSONObject()
            .put("longevityBiologicalSystemsReport", JSONObject()
                .put("active", true)
                .put("state", "LONGEVITY_SYSTEMS_GRAPH_READY_CONTRADICTION_REQUIRED")
                .put("selectedLane", "METABOLIC_IMMUNE_LANE")
                .put("biomarkersRequired", org.json.JSONArray(listOf("glucose", "HbA1c", "CRP")))
                .put("missingData", org.json.JSONArray(listOf("control_or_comparator", "time_order")))
                .put("invalidators", org.json.JSONArray(listOf("No glucose/HbA1c/insulin/lipid field exists")))
                .put("nextAction", "Run dataset template plus contradiction/null-result query."))
        val text = LearningRulesUiSummary.renderCompact(forager)

        assertTrue(text.contains("BIOLOGICAL_SYSTEMS", ignoreCase = true) || text.contains("biological systems", ignoreCase = true))
        assertTrue(text.contains("contradiction", ignoreCase = true))
        assertFalse(text.contains("treatment recommendation", ignoreCase = true))
    }
}
