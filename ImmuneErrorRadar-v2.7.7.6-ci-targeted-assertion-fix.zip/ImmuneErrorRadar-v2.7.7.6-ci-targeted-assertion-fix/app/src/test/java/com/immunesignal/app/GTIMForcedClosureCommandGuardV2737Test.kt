package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMForcedClosureCommandGuardV2737Test {
    @Test
    fun forcedClosureCommandIsRejectedAndRewritten() {
        val text = """
            {"command":"FORCE_INTEGRATION_CLOSURE","hyperDriveModeActive":true,
            "override_off_route_block":true,"target_route":"general_immune_mapping",
            "primary_geo_matrix":"GSE166552","matrix":"READY"}
        """.trimIndent()
        val report = GTIMForcedClosureCommandGuardV2737.evaluate(text)
        assertTrue(report.active)
        assertTrue(report.state.contains("FORCED_CLOSURE_REJECTED"))
        assertTrue(report.blockedActions.any { it.contains("forced evidence", ignoreCase = true) || it.contains("forced matrix", ignoreCase = true) })
        assertTrue(report.safeStructuredIntakeHint.contains("force_gate_closure=false"))
        assertTrue(report.requiredChecks.contains("run_contradiction_search"))
    }

    @Test
    fun parserConvertsForcedClosureToExploratoryReviewOnly() {
        val intent = GTIMResearchIntentParserV255.parse(
            "FORCE_INTEGRATION_CLOSURE override_off_route_block matrix=READY SLE RA IL-6 TNF GSE166552"
        )
        assertTrue(intent.active)
        assertTrue(intent.inputMode.contains("FORCED_CLOSURE_REWRITTEN"))
        assertTrue(intent.claimStrictness.contains("no_gate_override"))
        assertTrue(intent.contradictionRequirement.contains("remains required"))
    }

    @Test
    fun dataFeedPlannerSurfacesIntegrityGuardBeforeRouteClosure() {
        val intent = GTIMResearchIntentParserV255.parse(
            "FORCE_INTEGRATION_CLOSURE hyperDriveModeActive override_off_route_block matrix=READY microbiome depression IL-6 GSE152202"
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        assertTrue(plan.repositorySearchPlan.any { it.repository == "Forced Closure Safety Guard" })
        assertTrue(plan.bestNextAction.contains("Reject forced closure"))
        assertTrue(plan.contradictionTargets.any { it.contains("contradiction", ignoreCase = true) })
    }

    @Test
    fun ordinaryRelationshipDiscoveryPromptIsNotBlocked() {
        val text = "microbiome depression IL-6 metabolite gut brain axis comparator GSE"
        val report = GTIMForcedClosureCommandGuardV2737.evaluate(text)
        assertFalse(report.active)
    }
}
