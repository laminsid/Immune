package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AutonomousDiscoveryModeV2743Test {
    @Test
    fun blankInputSelectsBoundedAutonomousTopic() {
        val decision = AutonomousDiscoveryModeV2743.resolve("   ", emptyList())
        assertTrue(decision.active)
        assertEquals("BLANK_INPUT_AUTONOMOUS_DISCOVERY", decision.inputMode)
        assertTrue(decision.selectedTopic.isNotBlank())
        assertTrue(decision.requiredDots.size >= 4)
        assertTrue(decision.blockedClaims.joinToString(" ").contains("No mechanism", ignoreCase = true))
    }

    @Test
    fun userInputDisablesAutonomousMode() {
        val decision = AutonomousDiscoveryModeV2743.resolve("Depression", emptyList())
        assertFalse(decision.active)
        assertEquals("USER_TOPIC", decision.inputMode)
        assertEquals("Depression", decision.selectedTopic)
    }

    @Test
    fun autonomousSnapshotProducesQueriesAndAutoCaptureState() {
        val decision = AutonomousDiscoveryModeV2743.resolve("", emptyList())
        val snapshot = RuntimeCrashSafetyAndTopicGuardV2740.captureResolved(
            rawInput = "",
            effectiveTopic = decision.selectedTopic,
            inputMode = decision.inputMode,
            autonomousDiscovery = decision.active,
            autonomousCandidateId = decision.selectedCandidateId
        )
        val queries = AutonomousDiscoveryModeV2743.autonomousQueries(AutonomousDiscoveryModeV2743.fromSnapshot(snapshot))
        assertTrue(snapshot.autonomousDiscovery)
        assertTrue(snapshot.captureState.contains("AUTO_TOPIC"))
        assertTrue(queries.isNotEmpty())
        assertTrue(queries.joinToString(" ") { it.reason }.contains(AutonomousDiscoveryModeV2743.CLAIM_LIMIT))
    }
}
