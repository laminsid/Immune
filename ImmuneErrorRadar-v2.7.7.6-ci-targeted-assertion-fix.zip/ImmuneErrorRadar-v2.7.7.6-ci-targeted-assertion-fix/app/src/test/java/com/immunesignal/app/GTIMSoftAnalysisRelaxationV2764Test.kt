package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMSoftAnalysisRelaxationV2764Test {

    @Test
    fun softAssayAndPatientContrastProduceUsefulMetadataReviewLead() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))

        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202"),
            paperUnderstandingSummary = "GSE152202 SARS-CoV-2 patient cohort severe mild RNA-seq transcriptomics data availability sample traits"
        )

        assertEquals("GSE152202", card.targetId)
        assertEquals("METADATA_TABLE_FOUND", card.datasetObjectState)
        assertEquals("METADATA_AUDIT_READY", card.evidenceUpgradeState)
        assertTrue(card.matrixState.contains("SOFT", ignoreCase = true))
        assertTrue(card.verifiedMetadataSlots.any { it.contains("soft_matrix_lead", ignoreCase = true) })
        assertTrue(card.verifiedMetadataSlots.any { it.contains("soft_comparator_lead", ignoreCase = true) })
        assertFalse(card.datasetObjectState == "MATRIX_LINK_FOUND")
        assertFalse(card.evidenceUpgradeState == "EVIDENCE_CANDIDATE")
    }

    @Test
    fun negativeGapStillDoesNotBecomeEvidenceCandidate() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_METADATA_GAP")
                .put("blockingGaps", JSONArray().put("MATRIX_FILE_NOT_READY:: raw/count expression matrix or supplementary matrix link is not verified"))
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE152202")))))
        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE152202"),
            paperUnderstandingSummary = "GSE152202 SARS-CoV-2 PBMC patient sample metadata data availability"
        )

        assertEquals("GSE152202", card.targetId)
        assertFalse(card.datasetObjectState == "MATRIX_LINK_FOUND")
        assertFalse(card.evidenceUpgradeState == "EVIDENCE_CANDIDATE")
        assertFalse(card.matrixState == "DGE_NOT_READY_NO_ACCESSION")
        assertTrue(card.evidenceUpgradeState == "METADATA_AUDIT_READY" || card.evidenceUpgradeState == "DATASET_OBJECT_PARTIAL")
    }

    @Test
    fun foreignFungalTermStaysVisibleButBlockedFromCovidPromotion() {
        val covid = GTIMRunDecisionContractFactoryV2740.build("Covid", GTIMInputModeV2740.USER_QUERY)
        val lead = GTIMNovelSignalCaptureV2756.capture("Covid endothelial candida signal", covid)

        assertEquals(GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION, lead.signalClass)
        assertTrue(lead.termSignals.any { it.term == "endothelial" && it.signalClass == GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION })
        assertTrue(lead.termSignals.any { it.term == "candida" && it.signalClass == GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE })
        assertFalse(lead.promoteToCore)
        assertTrue(GTIMNovelSignalCaptureV2756.reportLine(lead).contains("candida") || lead.learningEdgeJsonlForTest(covid).contains("candida"))
    }
}

private fun GTIMOutOfOntologyLeadV2756.learningEdgeJsonlForTest(contract: GTIMRunDecisionContractV2740): String =
    GTIMNovelSignalCaptureV2756.learningEdgeJsonl(this, contract)
