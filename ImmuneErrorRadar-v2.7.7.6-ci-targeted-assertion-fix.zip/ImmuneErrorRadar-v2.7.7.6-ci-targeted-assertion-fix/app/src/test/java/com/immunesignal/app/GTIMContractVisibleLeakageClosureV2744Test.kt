package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMContractVisibleLeakageClosureV2744Test {

    @Test
    fun allergiesUserQueryMustBeAnchorProtected() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Allergies")
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED, c.runMode)
        assertEquals(GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL, c.primaryAnchor)
        assertTrue(c.allowedRoutes.contains("allergy_type2_ige_mast_eosinophil"))
    }

    @Test
    fun covidReportMustNotOpenAllergyTopicSpecificRoute() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val leaked = "topic=allergy_type2_ige_mast_eosinophil_route; connected-dot learning edges"
        assertFalse(GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(leaked, c))
        assertTrue(GTIMDownstreamContractAdaptersV2740.safeDataFeedAction(c).contains("COVID", ignoreCase = true))
    }

    @Test
    fun ebolaReportMustNotBenchmarkAllergy() {
        val report = GTIMBenchmarkValueHarnessV273.evaluate(
            parsedIntentText = "Trigger: not specified | Disease / phenotype: not specified",
            strongestRoute = "current-topic route: current user topic -> immune mediator to resolve -> Ebola EVD",
            topQuery = "allergy allergic hypersensitivity IgE mast cell eosinophil IL-4 dataset comparator GSE",
            dataChannelsCount = 1,
            routeState = GTIMRouteEvidenceStateReportV272(
                active = true,
                state = "EVIDENCE_CANDIDATE",
                reason = "test",
                nextGate = "lookup"
            ),
            paperLite = GTIMPaperUnderstandingLiteV272.empty(),
            proofOfValue = GTIMProofOfValueModeV272.empty(),
            currentTopic = "Ebola EVD"
        )
        assertEquals("ebola_hemorrhagic_viral_host_response", report.matchedBenchmarkTopic)
    }

    @Test
    fun ebolaBestDataFeedMustNotRecommendAllergyRoute() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Ebola EVD")
        val leaked = "Open topic-specific route 'Allergy / IgE / mast-cell / type-2 route', run allergy allergic hypersensitivity IgE mast cell eosinophil dataset"
        assertFalse(GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(leaked, c))
        val safe = GTIMDownstreamContractAdaptersV2740.safeDataFeedAction(c)
        assertTrue(safe.contains("Ebola", ignoreCase = true))
        assertFalse(safe.contains("Allergy", ignoreCase = true))
    }

    @Test
    fun autonomousSelectedMicrobiomeDepressionMustRebuildTopicContract() {
        val c = GTIMRunDecisionContractFactoryV2740.buildAutonomousSelectedTopic(
            rawQuery = "gut bacteria depression tryptophan kynurenine IL-6 TNF human cohort dataset",
            hasDatasetAccessions = false,
            matrixState = "DGE_NOT_READY_NO_ACCESSION"
        )
        assertEquals(GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION, c.runMode)
        assertEquals(GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION, c.primaryAnchor)
        assertTrue(c.discoveryBridges.any { it.routeId == "gut_microbiome_to_neuroinflammation" })
        assertTrue(c.discoveryBridges.any { it.routeId == "microbiome_tryptophan_serotonin_pathway" })
        assertFalse(c.discoveryBridges.any { it.routeId == "covid_interferon_cytokine_bridge" })
    }
}
