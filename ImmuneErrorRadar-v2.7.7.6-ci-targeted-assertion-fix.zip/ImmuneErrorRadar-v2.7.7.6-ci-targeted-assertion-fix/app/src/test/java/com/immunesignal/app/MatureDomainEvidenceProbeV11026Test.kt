package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MatureDomainEvidenceProbeV11026Test {
    private fun maturePriorReport(): String = JSONObject()
        .put("datasetForagingReport", JSONObject()
            .put("domainExpertiseReport", JSONObject()
                .put("cards", JSONArray().put(JSONObject()
                    .put("domainId", "antihistamine_histamine_mast_cell")
                    .put("label", "Antihistamines / histamine / mast-cell axis")
                    .put("expertiseState", "MATURE_DOMAIN_PRIOR_NEEDS_FALSIFICATION")
                    .put("expertiseScore", 79)
                    .put("priorExposureCount", 4)
                    .put("workingVocabulary", JSONArray().put("histamine").put("mast cell").put("allergy"))))))
        .toString()

    @Test
    fun matureDomainProbeRunsBeforeTerminalArchiveAndKeepsClaimsLocked() {
        val reports = listOf(maturePriorReport())
        val queries = MatureDomainEvidenceProbePolicy.compileProbeQueries(reports)

        assertTrue(queries.isNotEmpty())
        assertTrue(queries.first().query.contains("data availability", ignoreCase = true))
        assertTrue(queries.first().query.contains("histamine", ignoreCase = true))
        assertTrue(queries.first().reason.contains("no diagnosis", ignoreCase = true))
        assertTrue(queries.first().reason.contains(MatureDomainEvidenceProbePolicy.CLAIM_LIMIT))
    }

    @Test
    fun accessionArchiveCanBeRelaxedWhenMatureDomainExists() {
        val report = AccessionAcquisitionHardening.evaluate(
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            attempts = listOf(
                DatasetSourceAttempt("GEO_GDS", "gds", "q1", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
                DatasetSourceAttempt("SRA_PRJNA", "sra", "q2", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
                DatasetSourceAttempt("IMM_PORT_SDY", "pubmed", "q3", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
                DatasetSourceAttempt("PUBMED_ACCESSION_MINING", "pubmed", "q4", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test")
            ),
            noCandidateLearningRecords = emptyList(),
            memory = PersistentFailureMemorySnapshot(
                records = listOf(PersistentFailureRecord("hash", "PUBMED_ACCESSION_MINING", "NO_DATASET_ACCESSION", 0, 1L, 2, "PUBMED_ACCESSION_MINING")),
                summary = "test"
            ),
            relaxedMatureDomainProbeAvailable = true
        )

        assertEquals("NO_ACCESSION_MATURE_DOMAIN_PROBE_BEFORE_ARCHIVE", report.state)
        assertFalse(report.archiveRecommended)
        assertTrue(report.nextAction.contains("mature", ignoreCase = true))
    }
}
