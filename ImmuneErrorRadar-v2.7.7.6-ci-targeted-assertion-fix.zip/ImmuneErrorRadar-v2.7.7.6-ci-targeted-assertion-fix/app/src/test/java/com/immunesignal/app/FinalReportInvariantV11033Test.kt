package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FinalReportInvariantV11033Test {
    private fun accessionArchiveReport() = AccessionAcquisitionReport(
        active = true,
        state = "NO_ACCESSION_MATURE_DOMAIN_PROBE_BEFORE_ARCHIVE",
        explicitAccessions = emptyList(),
        weakAccessions = emptyList(),
        unresolvedLeadCount = 0,
        archiveRecommended = false,
        compactReportRecommended = true,
        nextAction = "Do not terminally archive yet: mature domain expertise exists. Run a bounded mature-domain accession/data-availability probe and keep all claims locked.",
        reasons = listOf("final invariant test")
    )

    private fun matureProbeReport() = MatureDomainEvidenceProbePolicy.Report(
        active = true,
        state = "MATURE_DOMAIN_PROBE_ATTEMPTED_KEEP_PRIORS",
        summary = "Mature-domain probe attempted; preserve domain expertise as working research priors without claims.",
        selectedDomains = listOf("antihistamine_histamine_mast_cell"),
        querySeeds = listOf("histamine mast cell allergy urticaria RNA-seq GSE outcome control cohort"),
        probeAttempted = true,
        relaxedInterpretationAllowed = true,
        nextAction = "Do not discard the domain track; keep it as a working research prior, then either manually inspect likely repositories or cool down only this route."
    )

    private fun baseConsistencyPass() = ReportConsistencyGuardReport(
        active = true,
        status = "PASS",
        warnings = emptyList(),
        requiredReportLanguage = "Report state is internally consistent: route-fit, parsing, and upgrade language are aligned."
    )

    @Test
    fun latestReportWeakLeadMatureProbeScenarioHasNoLinkageWarning() {
        val attempts = listOf(
            DatasetSourceAttempt("GEO_GDS", "gds", "q1", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
            DatasetSourceAttempt("SRA_PRJNA", "sra", "q2", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
            DatasetSourceAttempt("IMM_PORT_SDY", "pubmed", "q3", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
            DatasetSourceAttempt("PUBMED_ACCESSION_MINING", "pubmed", "q4", true, 2, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
            DatasetSourceAttempt(MatureDomainEvidenceProbePolicy.SOURCE_FAMILY, "pubmed", "q5", true, 1, 0, "MATURE_DOMAIN_PROBE_NO_FRESH_EVIDENCE", "test")
        )
        val path = DatasetForagingPathLinkageGuard.evaluate(
            attempts = attempts,
            accessionReport = accessionArchiveReport(),
            matureProbeReport = matureProbeReport(),
            foragerState = "DATASET_FORAGING_WEAK_DATASET_LEAD_FOUND",
            foragerNextAction = "Preserve the weak/near-miss lead, inspect source IDs or supplementary-data phrases, run secondary lookup/minimum metadata parsing, and do not create an EvidenceObject yet."
        )
        val consistency = ReportConsistencyGuard.includePathLinkageWarnings(
            base = baseConsistencyPass(),
            pathLinkageReport = path,
            learningDomainPathLinkageReport = LearningDomainPathLinkageReport.empty()
        )

        assertEquals("CONNECTED_MATURE_DOMAIN_TO_LEAD_INSPECTION", path.state)
        assertTrue(path.handoffSummary.contains("consumedByLead=true"))
        assertTrue(path.warnings.isEmpty())
        assertEquals("PASS", consistency.status)
        assertTrue(consistency.warnings.isEmpty())
    }

    @Test
    fun latestReportLeadRelaxationMustExposeLeadReferenceWhenRelaxedCountIsPositive() {
        val lead = LeadObject(
            leadId = "lead:test:near-miss",
            source = "PUBMED_ACCESSION_MINING",
            sourceFamily = "PUBMED_ACCESSION_MINING",
            title = "Near-miss source response from PUBMED_ACCESSION_MINING",
            snippet = "IDs returned but no accession-level metadata candidate survived.",
            detectedAccessions = emptyList(),
            dataAvailabilityText = "none",
            organism = "human_likely",
            humanLikely = true,
            omicsType = "unknown",
            domain = "antihistamine_histamine_mast_cell",
            outcomeLikely = false,
            controlLikely = false,
            timeLikely = false,
            licenseAccessLikely = false,
            sampleSizeLikely = false,
            confidence = 35
        )
        val relaxation = EvidenceLeadAndManualSeedPolicy.relax(
            candidates = emptyList(),
            leadObjects = listOf(lead)
        )

        assertEquals("WEAK_OR_NEAR_MISS_LEADS_PRESERVED_NOT_UPGRADED", relaxation.state)
        assertEquals(1, relaxation.relaxedLeadCount)
        assertTrue(relaxation.leadAccessions.any { it.contains("Near-miss source response from PUBMED_ACCESSION_MINING") })
    }
}
