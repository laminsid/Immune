package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Test

class ResearchStateEngineV12Test {
    @Test
    fun `empty findings do not create metadata-heavy alert`() {
        val card = V12TestFixtures.card(repeats = 1, overall = 60)
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val states = ResearchStateEngine.classify(card, gate, emptyList())
        assertEquals("Normal", states.biasRiskState)
    }

    @Test
    fun `metadata heavy non-empty findings create alert`() {
        val card = V12TestFixtures.card(repeats = 1, overall = 60)
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val states = ResearchStateEngine.classify(card, gate, listOf(V12TestFixtures.finding(flags = listOf("METADATA_ONLY"))))
        assertEquals("Alert", states.biasRiskState)
    }

    @Test
    fun `blocked strong signal becomes severe bias`() {
        val card = V12TestFixtures.card(status = "STRONG_SIGNAL", repeats = 3)
        val gate = MinimumDataPackAssessment("BLOCKED", listOf("timestamp"), "", emptyList())
        val states = ResearchStateEngine.classify(card, gate, listOf(V12TestFixtures.finding()))
        assertEquals("Severe Bias", states.biasRiskState)
    }

    @Test
    fun `strong candidate requires strong status pass gate and causality`() {
        val card = V12TestFixtures.card(status = "STRONG_SIGNAL", causality = 70, overall = 85, repeats = 3)
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val states = ResearchStateEngine.classify(card, gate, listOf(V12TestFixtures.finding()))
        assertEquals("Strong Candidate", states.discoveryState)
    }

    @Test
    fun `summary picks strongest discovery and worst bias`() {
        val objects = listOf(
            V12TestFixtures.objectCard(id = "a", discovery = "Early", bias = "Normal"),
            V12TestFixtures.objectCard(id = "b", discovery = "Active", bias = "Alert")
        )
        val summary = ResearchStateEngine.summarize(objects, emptyList())
        assertEquals("Active", summary.discoveryState)
        assertEquals("Alert", summary.biasRiskState)
    }
}
