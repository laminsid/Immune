package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchCyclePhaseSpineTest {
    @Test
    fun phaseSpineDeclaresStableRunCycleBoundaries() {
        val report = ResearchCyclePhaseSpine.build()
        assertEquals("PHASE_BOUNDARIES_DECLARED", report.state)
        assertEquals(5, report.boundaryCount)
        assertEquals(
            listOf(
                ResearchCyclePhaseName.PLAN,
                ResearchCyclePhaseName.DATASET_FORAGING,
                ResearchCyclePhaseName.SEARCH,
                ResearchCyclePhaseName.REASON,
                ResearchCyclePhaseName.PERSIST
            ),
            report.boundaries.map { it.phase }
        )
        assertTrue(report.dominantInvariant.contains("Search locks"))
    }
}
