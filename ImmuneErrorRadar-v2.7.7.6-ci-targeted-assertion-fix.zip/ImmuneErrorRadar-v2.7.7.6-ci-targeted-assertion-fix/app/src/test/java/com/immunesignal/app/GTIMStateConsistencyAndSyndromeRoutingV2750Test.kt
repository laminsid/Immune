package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMStateConsistencyAndSyndromeRoutingV2750Test {

    @Test
    fun fatigueBecomesDirectedSyndromeNotAutonomousAllergyFallback() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Fatigue")
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_SYNDROME_EXPLORATION, c.runMode)
        assertEquals(GTIMPrimaryAnchorV2740.FATIGUE_SYNDROME_NEUROIMMUNE_METABOLIC, c.primaryAnchor)
        assertEquals("fatigue_syndrome_neuroimmune_metabolic", c.benchmarkTopic)
        assertFalse(c.discoveryBridges.any { it.routeId == "allergy_type2_to_barrier_immunity" })
        assertTrue(c.discoveryBridges.any { it.routeId == "mitochondrial_fatigue_axis" })
    }

    @Test
    fun dgeReadyCannotCoexistWithNotReadyMatrix() {
        val normalized = GTIMMatrixStateConsistencyGuardV2750.normalize(
            accessionState = "DGE_READY",
            rawMatrixState = "DGE_NOT_READY_ACCESSION_HANDLE_ONLY",
            rawReadinessScore = 55
        )
        assertFalse(normalized.accessionState == "DGE_READY")
        assertTrue(normalized.matrixState.startsWith("DGE_NOT_READY"))
        assertTrue(normalized.readinessScore <= 65)
        assertTrue(normalized.consistencyGap!!.contains("STATE_CONSISTENCY_DOWNGRADE"))
    }

    @Test
    fun hantaDoesNotDisplayEbolaOrAllergySeedsAsActiveQueue() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Hanta virus")
        val guard = GTIMDiseaseSpecificSeedPoolGuardV2750.filterActiveHandles(
            listOf("GSE250594", "GSE72056", "GSE131907", "PMID:22114171"),
            c
        )
        assertTrue(guard.activeHandles.isEmpty())
        assertTrue(guard.rejectedBackgroundHandles.contains("GSE250594"))
        assertTrue(guard.rejectedBackgroundHandles.contains("GSE72056"))
    }

    @Test
    fun microbiomeDepressionDoesNotSelectAllergySeedAsMatrixTarget() {
        val c = GTIMRunDecisionContractFactoryV2740.buildAutonomousSelectedTopic(
            rawQuery = "gut bacteria depression tryptophan kynurenine IL-6 TNF human cohort dataset",
            hasDatasetAccessions = false,
            matrixState = "DGE_NOT_READY_NO_ACCESSION"
        )
        val report = JSONObject()
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE250594")))))
        val card = GTIMMatrixAuditCardV2745.build(report, c, listOf("GSE250594"), "allergy mast cell seed GSE250594")
        assertEquals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", card.targetId)
        assertEquals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", card.accessionState)
        assertTrue(card.matrixState.contains("NO_TOPIC_COMPATIBLE_ACCESSION"))
    }

    @Test
    fun covidRelationshipRouteIsRenderedAsAllowedCanonicalRoute() {
        val c = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val text = "Relationship discovery: covid_interferon_cytokine_bridge SARS-CoV-2 interferon IL-6 TNF PBMC"
        assertTrue(GTIMCanonicalRouteIdentityV2748.isAllowedRouteText(text, c))
        assertTrue(GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(text, c))
    }
}
