package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DatasetPassCoverageLinkageV11028Test {
    private fun accessionArchiveReport() = AccessionAcquisitionReport(
        active = true,
        state = "NO_ACCESSION_ARCHIVE_ROUTE",
        explicitAccessions = emptyList(),
        weakAccessions = emptyList(),
        unresolvedLeadCount = 0,
        archiveRecommended = false,
        compactReportRecommended = true,
        nextAction = "Archive or reframe this route before another search cycle.",
        reasons = listOf("test")
    )

    private fun matureProbeReport(active: Boolean = true) = MatureDomainEvidenceProbePolicy.Report(
        active = active,
        state = if (active) "MATURE_DOMAIN_PROBE_ATTEMPTED_KEEP_PRIORS" else "NOT_ACTIVE",
        summary = "Mature domain probe attempted; preserve priors.",
        selectedDomains = if (active) listOf("antihistamine_histamine_mast_cell") else emptyList(),
        querySeeds = if (active) listOf("histamine mast cell GSE data availability accession") else emptyList(),
        probeAttempted = active,
        relaxedInterpretationAllowed = active,
        nextAction = if (active) "Do not discard the mature-domain track; keep it as a working research prior." else "Continue normal accession-first search."
    )

    @Test
    fun classifiesCoreAdjacentAndMatureQueryPathsSeparately() {
        val attempts = listOf(
            DatasetSourceAttempt("GEO_GDS", "gds", "q1", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
            DatasetSourceAttempt("SRA_PRJNA", "sra", "q2", true, 0, 0, "SOURCE_SEARCH_NO_IDS", "test"),
            DatasetSourceAttempt("IMM_PORT_SDY", "pubmed", "q3", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
            DatasetSourceAttempt("PUBMED_ACCESSION_MINING", "pubmed", "q4", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
            DatasetSourceAttempt("PUBMED_ADJACENT_DOMAIN_MINING", "pubmed", "q5", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test"),
            DatasetSourceAttempt(MatureDomainEvidenceProbePolicy.SOURCE_FAMILY, "pubmed", "q6", true, 0, 0, "MATURE_DOMAIN_PROBE_NO_FRESH_EVIDENCE", "test")
        )

        val report = DatasetForagingPathLinkageGuard.evaluate(
            attempts = attempts,
            accessionReport = accessionArchiveReport(),
            matureProbeReport = matureProbeReport(),
            foragerState = "DATASET_FORAGING_MATURE_DOMAIN_EVIDENCE_PROBE",
            foragerNextAction = matureProbeReport().nextAction
        )

        assertEquals("CONNECTED_MATURE_DOMAIN_PROBE", report.state)
        assertEquals("PASS_COVERAGE_CONNECTED", report.coverageState)
        assertEquals(4, report.coreQueryPathCount)
        assertEquals(1, report.adjacentQueryPathCount)
        assertEquals(1, report.matureProbeQueryPathCount)
        assertEquals(6, report.totalQueryPathCount)
        assertTrue(report.warnings.isEmpty())
    }

    @Test
    fun warnsWhenExecutedPathIsNotClassified() {
        val report = DatasetForagingPathLinkageGuard.evaluate(
            attempts = listOf(
                DatasetSourceAttempt("UNCLASSIFIED_SOURCE", "pubmed", "q", true, 0, 0, "NO_FRESH_PUBMED_EVIDENCE", "test")
            ),
            accessionReport = accessionArchiveReport(),
            matureProbeReport = matureProbeReport(active = false),
            foragerState = "DATASET_FORAGING_NO_CANDIDATE",
            foragerNextAction = "Continue."
        )

        assertEquals("PASS_COVERAGE_GAP", report.coverageState)
        assertTrue(report.warnings.any { it.contains("not classified", ignoreCase = true) })
    }
}
