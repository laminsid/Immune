package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMDGEObservedSignalSeparationV2771Test {

    @Test
    fun recoveryQueryTermsDoNotBecomeObservedMatrixCandidate() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid")
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Covid"))
            .put("metadataClosureStrategyMatrixReport", JSONObject()
                .put("state", "DGE_NOT_READY_NO_ACCESSION")
                .put("blockingGaps", JSONArray()
                    .put("ACCESSION_UNRESOLVED_SECONDARY_LOOKUP_REQUIRED")))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("matrixAnalysisGate", "DGE_NOT_READY_NO_ACCESSION")
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE166552")))))

        val card = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf("GSE166552"),
            paperUnderstandingSummary = "GSE166552 SARS-CoV-2 patient cohort RNA-seq transcriptomics data availability sample traits"
        )

        val bridge = GTIMMatrixAuditCardV2745.dgeExecutionBridgeLine(card)
        val next = GTIMMatrixAuditCardV2745.dgeExecutionNextLine(card)

        assertTrue(next.contains("raw counts") || next.contains("count matrix"))
        assertTrue(bridge.contains("signal_source=observed_only_v2771"))
        assertFalse(bridge.contains("matrix=MATRIX_FILE_CANDIDATE_FOUND_REVIEW_ONLY"))
        assertFalse(bridge.contains("state=DGE_EXECUTION_READY_REVIEW_ONLY"))
        assertTrue(
            bridge.contains("matrix=SOFT_MATRIX_CANDIDATE_NEEDS_DOWNLOAD") ||
                bridge.contains("matrix=MATRIX_FILE_LOOKUP_REQUIRED")
        )
        assertTrue(next.contains("MATRIX_DOWNLOAD_REQUIRED"))
        assertFalse(card.evidenceUpgradeState == "STRONG_SIGNAL_REVIEW_ONLY")
    }

    @Test
    fun reportSurfaceCarriesObservedSignalSeparationToken() {
        val report = JSONObject()
            .put("topicCapture", JSONObject()
                .put("userQueryCaptured", true)
                .put("rawInput", "Diabetes"))
            .put("mechanismDiscoveryDossierReport", JSONObject()
                .put("globalTranslationalDossier", JSONObject()
                    .put("accessionSeedCapture", JSONObject()
                        .put("capturedSeeds", JSONArray().put("GSE117882")))))

        val rendered = GlobalResearchGradeBriefV11061.render(report)

        assertTrue(rendered.contains("v2.7.7.1-observed-signal-separation"))
        assertTrue(rendered.contains("signal_source=observed_only_v2771"))
        assertFalse(rendered.contains("state=DGE_EXECUTION_READY_REVIEW_ONLY"))
    }
}
