package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DatasetAccessionResolverV1108Test {
    @Test
    fun extractsSraRunAndEuropeanRunAccessions() {
        val candidates = DatasetAccessionResolver.extract(
            text = "human immune RNA-seq outcome severity study SRP123456 run SRR987654 ERR765432 DRR543210 PRJNA222333",
            sourceFindingId = "manual:test",
            sourceTitle = "SRA direct metadata"
        )
        val accessions = candidates.map { it.accession }.toSet()

        assertTrue(accessions.contains("SRP123456"))
        assertTrue(accessions.contains("SRR987654"))
        assertTrue(accessions.contains("ERR765432"))
        assertTrue(accessions.contains("DRR543210"))
        assertTrue(accessions.contains("PRJNA222333"))
        assertEquals("NCBI/SRA", candidates.first { it.accession == "SRR987654" }.source)
    }


    @Test
    fun numericSraUidIsNotPromotedIntoFakeAccession() {
        val candidates = DatasetAccessionResolver.extract(
            text = "NCBI SRA UID 123456 human RNA-seq immune cohort outcome severity metadata",
            sourceFindingId = "manual:numeric-sra-uid",
            sourceTitle = "SRA numeric UID only"
        )
        val accessions = candidates.map { it.accession }.toSet()

        assertTrue(accessions.contains("DATASET_ACCESSION_UNRESOLVED"))
        assertTrue(accessions.none { it == "SRA123456" })
    }

    @Test
    fun keepsGeoAndGdsAccessionsExplicit() {
        val candidates = DatasetAccessionResolver.extract(
            text = "GEO dataset GSE250594 GDS1234 human patient cohort outcome recovery longitudinal metadata",
            sourceFindingId = "manual:geo",
            sourceTitle = "GEO metadata"
        )
        val accessions = candidates.map { it.accession }.toSet()

        assertTrue(accessions.contains("GSE250594"))
        assertTrue(accessions.contains("GDS1234"))
        assertEquals("GEO/NCBI", candidates.first { it.accession == "GSE250594" }.source)
    }
}
