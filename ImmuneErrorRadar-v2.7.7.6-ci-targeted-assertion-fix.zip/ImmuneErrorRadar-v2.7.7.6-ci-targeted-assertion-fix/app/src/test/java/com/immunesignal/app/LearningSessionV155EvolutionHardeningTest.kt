package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v1.5.5 static/runtime-light tests for learning-session evolution hardening.
 * These tests validate pure JVM-safe pieces only; Android persistence is covered
 * by static release guards because it needs Context.
 */
class LearningSessionV155EvolutionHardeningTest {
    @Test
    fun questionEvolverProvidesPhaseSpecificQuestions() {
        val questions = QuestionEvolver.generateQuestions(SessionType.INCREMENTAL, LearningInsights())
        assertTrue(questions.any { it.phase == "FAILURE_ANALYSIS" })
        assertTrue(questions.any { it.phase == "INTERACTION_DETECTION" })
        assertTrue(questions.any { it.phase == "ROUTE_DISCOVERY" })
        assertTrue(questions.any { it.phase == "BLIND_SPOT_FINDING" })
        assertTrue(questions.all { it.importance in 1..10 })
    }

    @Test
    fun progressJsonReportEscapesUnsafeText() {
        val session = LearningSession(
            sessionId = "session_test_v155",
            sessionType = SessionType.INCREMENTAL,
            startedAt = System.currentTimeMillis(),
            status = SessionStatus.PAUSED,
            timeLimit = RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS,
            phases = listOf(
                PhaseState(
                    phaseName = "FAILURE_ANALYSIS",
                    status = PhaseStatus.IN_PROGRESS,
                    progress = 35,
                    partialResults = JSONObject().put("note", "quote: \" and newline\n kept safe")
                )
            ),
            checkpoint = SessionCheckpoint(
                lastPhaseCompleted = null,
                lastDataProcessed = null,
                pendingPhases = listOf("FAILURE_ANALYSIS"),
                canResume = true,
                savedAt = System.currentTimeMillis()
            ),
            claimLimits = mapOf("session" to RuntimeFeatureFlags.LEARNING_SESSION_CLAIM_LIMIT)
        )
        val parsed = JSONObject(ProgressTracker.generateJSONReport(session))
        assertEquals("session_test_v155", parsed.getString("sessionId"))
        assertEquals(RuntimeFeatureFlags.LEARNING_SESSION_CLAIM_LIMIT, parsed.getString("claimLimit"))
        assertTrue(parsed.getJSONArray("phases").length() == 1)
    }

    @Test
    fun integrityGuardCompletesWhenAllPhasesCompleted() {
        val phases = LearningSessionIntegrityGuard.expectedPhaseNames.map { name ->
            PhaseState(phaseName = name, status = PhaseStatus.COMPLETED, progress = 100)
        }
        val normalized = LearningSessionIntegrityGuard.normalize(
            LearningSession(
                sessionId = "session_complete_v155",
                sessionType = SessionType.INCREMENTAL,
                startedAt = System.currentTimeMillis(),
                status = SessionStatus.PAUSED,
                timeLimit = RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS,
                phases = phases,
                checkpoint = SessionCheckpoint(
                    lastPhaseCompleted = "BLIND_SPOT_FINDING",
                    lastDataProcessed = "dataset_test",
                    pendingPhases = emptyList(),
                    canResume = true,
                    savedAt = System.currentTimeMillis()
                ),
                claimLimits = emptyMap()
            )
        )
        assertEquals(SessionStatus.COMPLETED, normalized.status)
        assertTrue(!normalized.checkpoint.canResume)
        assertTrue(normalized.checkpoint.pendingPhases.isEmpty())
    }
}
