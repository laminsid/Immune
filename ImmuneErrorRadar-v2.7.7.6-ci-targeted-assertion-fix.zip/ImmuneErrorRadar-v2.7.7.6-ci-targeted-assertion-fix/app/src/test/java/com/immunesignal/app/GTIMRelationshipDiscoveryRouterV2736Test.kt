package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMRelationshipDiscoveryRouterV2736Test {
    @Test
    fun microbiomeDepressionQuestionBuildsMediatorRelationshipChain() {
        val plan = GTIMRelationshipDiscoveryRouterV2736.build(
            "gut bacteria microbiome depression IL-6 TNF CRP metabolite gut-brain axis case control"
        )
        assertTrue(plan.active)
        assertEquals("microbiome_depression_il6_bridge", plan.matchedArchetype)
        assertTrue(plan.relationshipChain.joinToString(" ").contains("IL-6", ignoreCase = true))
        assertTrue(plan.mediatorCandidates.isNotEmpty())
        assertTrue(plan.supportingLeadQueries.any { it.contains("depression", ignoreCase = true) })
        assertTrue(plan.contradictionQueries.any { it.contains("no association", ignoreCase = true) || it.contains("null result", ignoreCase = true) })
        assertTrue(plan.gtimAdded.any { it.contains("relationship chain", ignoreCase = true) })
        assertTrue(plan.gtimDidNotProve.contains("causality"))
    }

    @Test
    fun dataFeedPlannerSurfacesRelationshipDiscoveryBridge() {
        val intent = GTIMResearchIntentParserV255.parse(
            "microbiome anxiety tryptophan kynurenine IL-6 TNF gut-brain axis metabolomics case control Europe PMC OpenAlex"
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        assertTrue(plan.repositorySearchPlan.any { it.repository == "Relationship Discovery Router" })
        assertTrue(plan.querySeeds.any { it.contains("kynurenine", ignoreCase = true) || it.contains("tryptophan", ignoreCase = true) })
        assertTrue(plan.comparatorTargets.any { it.contains("control", ignoreCase = true) })
        assertTrue(plan.contradictionTargets.any { it.contains("null result", ignoreCase = true) || it.contains("no association", ignoreCase = true) })
    }

    @Test
    fun briefShowsGtimAddedAndDidNotProveForRelationshipRoute() {
        val report = org.json.JSONObject()
            .put("runtime", org.json.JSONObject().put("engineVersion", "v2.7.3-final-proof-benchmark-learning-locked").put("researchState", "DATASET_HUNT"))
            .put("executionLock", org.json.JSONObject().put("status", "PASS"))
            .put("mechanismDiscoveryDossier", org.json.JSONObject()
                .put("bestResearchLeadSummary", "microbiome depression IL-6 gut-brain axis metabolite relationship route")
                .put("state", "DATASET_HUNT"))
        val brief = GlobalResearchGradeBriefV11061.render(report)
        assertTrue(brief.contains("Relationship discovery:"))
        assertTrue(brief.contains("GTIM added:"))
        assertTrue(brief.contains("GTIM did not prove:"))
    }
}
