package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AccessionValidationComparatorExtractionV1114Test {
    @Test
    fun confirmedAccessionProducesValidationAndComparatorExtractionCards() {
        val candidate = DatasetAccessionCandidate(
            accession = "GSE22222",
            source = "GEO_GDS",
            organismHint = "human patients",
            conditionLabelsHint = "healthy control; SLE case; baseline",
            outcomeLabelsHint = "response nonresponse",
            triggerResponseOutcomeHint = "series matrix sample metadata supplementary data",
            timeCourseHint = "baseline follow-up",
            sampleSizeHint = "n=24",
            dataType = "RNA-seq transcriptome series matrix",
            usabilityScore = 70,
            status = "ACCESSION_TEXT_FOUND",
            sourceFindingId = "geo_gse22222",
            sourceTitle = "GSE22222 human SLE RNA-seq healthy control case baseline series matrix",
            sourceUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE22222",
            reasons = listOf("data availability", "series matrix", "sample metadata", "healthy control", "SLE case", "baseline")
        )

        val report = ResearchGradeMechanismDossierV1110.evaluate(
            steering = null,
            matrix = MetadataClosureStrategyMatrixReport.empty().copy(hyperDriveModeActive = true),
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            leadObjects = emptyList(),
            attempts = emptyList()
        )

        assertTrue(report.accessionValidationCards.isNotEmpty())
        assertEquals("GEO_SERIES", report.accessionValidationCards.first().handleType)
        assertTrue(report.accessionValidationCards.first().metadataExtractionCommand.contains("PARSE_GEO::GSE22222"))
        assertTrue(report.comparatorExtractionCards.isNotEmpty())
        assertEquals("COMPARATOR_EXTRACTION_CASE_CONTROL_PARTIAL", report.comparatorExtractionCards.first().extractionState)
        assertTrue(report.comparatorExtractionCards.first().comparatorConfidence > 0)
        assertTrue(report.metadataExtractionCommands.first().contains("PARSE_GEO::GSE22222"))
    }

    @Test
    fun unresolvedManualTextKeepsEvidenceObjectBlockedNoConfirmedAccession() {
        val candidate = DatasetAccessionCandidate(
            accession = "MANUAL_TEXT_SNIPPET_no_accession_0",
            source = "MANUAL_EVIDENCE_SEED_MODE",
            organismHint = "human cohort",
            conditionLabelsHint = "EBV SLE transcriptome",
            outcomeLabelsHint = "response",
            triggerResponseOutcomeHint = "sleep deprivation IL-6 RNA-seq data availability",
            timeCourseHint = "baseline follow-up",
            sampleSizeHint = "unknown",
            dataType = "RNA-seq transcriptome",
            usabilityScore = 10,
            status = "OFF_ROUTE_USEFUL_DATASET",
            sourceFindingId = "manual_no_accession",
            sourceTitle = "Manual snippet without GSE or PRJNA handle",
            sourceUrl = "",
            reasons = listOf("OFF_ROUTE", "WEAK_DATASET_LEAD")
        )

        val report = ResearchGradeMechanismDossierV1110.evaluate(
            steering = null,
            matrix = MetadataClosureStrategyMatrixReport.empty().copy(hyperDriveModeActive = true),
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            leadObjects = emptyList(),
            attempts = emptyList()
        )

        assertTrue(report.accessionCandidates.isEmpty())
        assertEquals("EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION", report.evidenceObjectCreationGate)
        assertTrue(report.accessionValidationCards.isNotEmpty())
        assertEquals("UNRESOLVED_TEXT_HANDLE", report.accessionValidationCards.first().handleType)
    }
}
