package com.immunesignal.app

import org.junit.Assert.assertTrue
import org.junit.Test

class FalsificationBuilderV12Test {
    @Test
    fun `always includes temporal falsification`() {
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val points = FalsificationBuilder.forHypothesis(emptyList(), gate)
        assertTrue(points.any { it.contains("precede", ignoreCase = true) })
    }

    @Test
    fun `autonomic axis adds BP falsification`() {
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val points = FalsificationBuilder.forHypothesis(listOf("autonomic_vascular_axis"), gate)
        assertTrue(points.any { it.contains("BP/pulse") })
    }

    @Test
    fun `missing data appears in falsification list`() {
        val gate = MinimumDataPackAssessment("BLOCKED", listOf("timestamp", "sleep_quality"), "", emptyList())
        val points = FalsificationBuilder.forHypothesis(emptyList(), gate)
        assertTrue(points.any { it.contains("minimum data pack", ignoreCase = true) })
    }

    @Test
    fun `omics axes require curated dataset context`() {
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val points = FalsificationBuilder.forHypothesis(listOf("rna_transcriptomic_axis"), gate)
        assertTrue(points.any { it.contains("curated dataset", ignoreCase = true) })
    }
}
