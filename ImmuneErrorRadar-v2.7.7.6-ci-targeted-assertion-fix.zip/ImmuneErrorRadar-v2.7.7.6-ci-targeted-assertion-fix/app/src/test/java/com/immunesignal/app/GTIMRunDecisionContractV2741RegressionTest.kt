package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMRunDecisionContractV2741RegressionTest {

    @Test
    fun ibdGutBarrierDoesNotBecomeDepression() {
        val c = GTIMRunDecisionContractFactoryV2740.build("IBD gut inflammation barrier")
        assertEquals(GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED, c.runMode)
        assertEquals(GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE, c.primaryAnchor)
        assertTrue(c.allowedRoutes.contains("ibd_barrier_mucosal_inflammation_axis"))
        assertTrue(c.allowedRoutes.contains("ibd_barrier_microbiome_axis"))
        assertFalse(c.allowedRoutes.contains("depression_neuroimmune_axis"))
        assertTrue(c.forbiddenConflations.contains("gut_microbiome_to_depression_identity_mutation"))
    }

    @Test
    fun readyAccessionBackedMatrixCanReceiveNormalCaps() {
        val c = GTIMRunDecisionContractFactoryV2740.build(
            rawQuery = "Covid immune disruption",
            hasDatasetAccessions = true,
            matrixState = "DGE_READY"
        )
        assertEquals(100, c.evidenceCaps.dataQualityMax)
        assertEquals(100, c.evidenceCaps.evidenceStrengthMax)
        assertEquals(100, c.evidenceCaps.routeConfidenceMax)
        assertTrue(c.evidenceCaps.causalityClaimAllowed)
    }

    @Test
    fun unknownUserQueryBecomesAutonomousNotProtectedUnknown() {
        val c = GTIMRunDecisionContractFactoryV2740.build("unclear rare signal without disease anchor")
        assertEquals(GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION, c.runMode)
        assertEquals(GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY, c.primaryAnchor)
        assertFalse(c.anchorMustNotMutate)
        assertTrue(c.allowedRoutes.contains("gut_microbiome_to_neuroinflammation"))
    }

    @Test
    fun psoriasisGetsOwnAnchor() {
        val c = GTIMRunDecisionContractFactoryV2740.build("psoriasis plaque IL-17 skin barrier")
        assertEquals(GTIMPrimaryAnchorV2740.PSORIASIS_IL23_IL17_SKIN, c.primaryAnchor)
        assertTrue(c.allowedRoutes.contains("psoriasis_il23_il17_skin_barrier_axis"))
        assertFalse(c.allowedRoutes.contains("allergy_type2_ige_mast_eosinophil"))
    }

    @Test
    fun sleMsRaAndT1dGetSpecificAutoimmuneAnchors() {
        assertEquals(
            GTIMPrimaryAnchorV2740.SLE_SYSTEMIC_AUTOIMMUNE,
            GTIMRunDecisionContractFactoryV2740.build("SLE lupus interferon autoantibody").primaryAnchor
        )
        assertEquals(
            GTIMPrimaryAnchorV2740.MS_NEUROIMMUNE_DEMYELINATION,
            GTIMRunDecisionContractFactoryV2740.build("multiple sclerosis demyelination neuroinflammation").primaryAnchor
        )
        assertEquals(
            GTIMPrimaryAnchorV2740.RA_SYNOVIAL_AUTOIMMUNE,
            GTIMRunDecisionContractFactoryV2740.build("rheumatoid arthritis citrullination synovitis").primaryAnchor
        )
        assertEquals(
            GTIMPrimaryAnchorV2740.T1D_AUTOIMMUNE_BETA_CELL,
            GTIMRunDecisionContractFactoryV2740.build("type 1 diabetes beta cell autoimmunity").primaryAnchor
        )
    }

    @Test
    fun runtimeFacadeFiltersForbiddenRoutesAndCapsScores() {
        try {
            val c = GTIMRunContractRuntimeV2740.beginRun(
                rawQuery = "Covid immune disruption",
                accessionCount = 0,
                matrixState = "DGE_NOT_READY_NO_ACCESSION"
            )
            assertEquals(GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL, c.primaryAnchor)

            val filtered = GTIMRunContractRuntimeV2740.filterRouteIds(
                candidateRouteIds = listOf(
                    "covid_interferon_cytokine_bridge",
                    "allergy_type2_ige_mast_eosinophil",
                    "viral_to_neuroinflammation_fatigue_axis"
                ),
                sourceLayer = "test-router"
            )
            assertTrue(filtered.contains("covid_interferon_cytokine_bridge"))
            assertTrue(filtered.contains("viral_to_neuroinflammation_fatigue_axis"))
            assertFalse(filtered.contains("allergy_type2_ige_mast_eosinophil"))

            val capped = GTIMRunContractRuntimeV2740.capScores(100, 100, 100)
            assertEquals(35, capped.first)
            assertEquals(25, capped.second)
            assertEquals(60, capped.third)
        } finally {
            GTIMRunContractRuntimeV2740.clear()
        }
    }
}
