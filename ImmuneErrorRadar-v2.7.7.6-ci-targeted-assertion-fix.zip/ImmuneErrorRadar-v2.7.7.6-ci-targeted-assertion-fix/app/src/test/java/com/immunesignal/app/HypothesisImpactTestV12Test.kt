package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HypothesisImpactTestV12Test {
    @Test
    fun `strong card with pass gate becomes upgrade candidate`() {
        val card = V12TestFixtures.card(status = "STRONG_SIGNAL")
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val states = ResearchStates("Active", "Normal")
        val result = HypothesisImpactTest.evaluate(card, gate, states, listOf(V12TestFixtures.finding()))
        assertEquals("upgrade_candidate", result.signalFlip)
        assertTrue(result.changedMainBody)
    }

    @Test
    fun `blocked gate becomes quality stop`() {
        val card = V12TestFixtures.card(status = "WATCH")
        val gate = MinimumDataPackAssessment("BLOCKED", listOf("timestamp"), "", emptyList())
        val states = ResearchStates("Early", "Alert")
        val result = HypothesisImpactTest.evaluate(card, gate, states, emptyList())
        assertEquals("quality_stop", result.signalFlip)
    }

    @Test
    fun `severe bias downgrades before human evidence wording`() {
        val card = V12TestFixtures.card(evidence = 80)
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val states = ResearchStates("Active", "Severe Bias")
        val result = HypothesisImpactTest.evaluate(card, gate, states, listOf(V12TestFixtures.finding()))
        assertEquals("downgrade_for_bias", result.signalFlip)
    }

    @Test
    fun `low impact low score stays background`() {
        val card = V12TestFixtures.card(overall = 30, evidence = 40, causality = 25)
        val gate = MinimumDataPackAssessment("PASS", emptyList(), "", emptyList())
        val states = ResearchStates("Off", "Normal")
        val result = HypothesisImpactTest.evaluate(card, gate, states, emptyList())
        assertEquals("no_major_flip", result.signalFlip)
        assertFalse(result.changedMainBody)
    }
}
