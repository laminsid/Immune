package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UsefulLearningReportV11034Test {
    @Test
    fun learningValueCountsProgressWithoutEvidenceObject() {
        val forager = DatasetForagingReport.empty().copy(
            active = true,
            sourceFamiliesAttempted = listOf("GEO_GDS"),
            leadObjects = listOf(
                LeadObject(
                    leadId = "l1",
                    source = "manual",
                    sourceFamily = "MANUAL_EVIDENCE_SEED_MODE",
                    title = "Manual RA lead",
                    snippet = "rheumatoid arthritis cytokine cohort",
                    detectedAccessions = emptyList(),
                    dataAvailabilityText = "secondary lookup needed",
                    organism = "human",
                    humanLikely = true,
                    omicsType = "transcriptomics",
                    domain = "inflammatory_disease_chronic_inflammation",
                    outcomeLikely = false,
                    controlLikely = false,
                    timeLikely = false,
                    licenseAccessLikely = false,
                    sampleSizeLikely = false,
                    confidence = 35,
                    claimLimit = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
                )
            ),
            knowledgeGapQueueReport = KnowledgeGapQueueReport(
                active = true,
                queueState = "OPEN_GAPS_ROUTABLE",
                items = listOf(
                    KnowledgeGapQueueItem(
                        gapId = "outcome_labels",
                        priority = 100,
                        attemptCount = 0,
                        lastAttemptedSource = "none",
                        cooldown = 0,
                        nextQuery = "rheumatoid arthritis outcome control GSE",
                        status = "OPEN"
                    )
                ),
                nextAction = "Run gap query",
                claimLimit = MatureDomainFocusModePolicy.CLAIM_LIMIT
            )
        )
        val learning = LearningOsReport.empty().copy(
            incident = LearningOsReport.empty().incident.copy(rootCauses = listOf("NO_DATASET_ACCESSION")),
            preventiveGates = listOf(
                PreventiveGateDecision(
                    gateId = "FORCE_DATASET_ACCESSION_SEARCH",
                    rootCause = "NO_DATASET_ACCESSION",
                    action = "Force dataset accession query before broad search.",
                    forcedNextIntent = "dataset_accession_search",
                    forcedQuerySeed = "GSE immune outcome control",
                    blocksHypothesisUpgrade = true
                )
            )
        )
        val score = UsefulLearningReportPolicy.learningValueScore(
            steering = ResearchSteeringProfile(
                profileId = "s1",
                createdAtMillis = 1L,
                variables = listOf("Rheumatoid arthritis"),
                focusQuestion = ImmuneTopicPromptPolicy.focusQuestion("Rheumatoid arthritis"),
                requiredTerms = listOf("immune", "dataset", "outcome"),
                excludedTerms = emptyList(),
                inferredAxes = listOf("tnf_il6_autoimmune_axis")
            ),
            importedSignals = emptyList(),
            importedRawTexts = listOf(ImmuneTopicPromptPolicy.importedLearningNote("Rheumatoid arthritis")),
            forager = forager,
            learningOs = learning,
            discoveryReadiness = DiscoveryReadinessReport.empty()
        )

        assertTrue(score.score >= 35)
        assertTrue(score.usefulOutcomes.contains("topic_stored"))
        assertTrue(score.usefulOutcomes.contains("weak_lead_preserved"))
        assertEquals("no_evidence_object_no_upgrade", score.evidenceStatus)
    }

    @Test
    fun topicMemoryAndLeadQueueExposeNextResearchAction() {
        val forager = DatasetForagingReport.empty().copy(
            leadObjects = listOf(
                LeadObject(
                    leadId = "l2",
                    source = "PubMed",
                    sourceFamily = "PUBMED_ACCESSION_MINING",
                    title = "Near-miss source response from PUBMED_ACCESSION_MINING",
                    snippet = "covid interferon longitudinal outcome control",
                    detectedAccessions = emptyList(),
                    dataAvailabilityText = "inspect supplementary data phrases",
                    organism = "unknown",
                    humanLikely = true,
                    omicsType = "transcriptomics",
                    domain = "unknown",
                    outcomeLikely = true,
                    controlLikely = true,
                    timeLikely = true,
                    licenseAccessLikely = false,
                    sampleSizeLikely = false,
                    confidence = 25,
                    claimLimit = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
                )
            )
        )
        val topic = UsefulLearningReportPolicy.topicMemoryLedger(
            steering = null,
            importedSignals = listOf(
                ImportedReportSignal(
                    reportId = "i1",
                    createdAtMillis = 1L,
                    title = "Single topic prompt",
                    matchedAxes = listOf("interferon_antiviral_axis"),
                    extractedKeywords = listOf("corona"),
                    preview = ImmuneTopicPromptPolicy.importedLearningNote("corona")
                )
            ),
            importedRawTexts = emptyList(),
            forager = forager
        )
        val queue = UsefulLearningReportPolicy.leadInspectionQueue(forager)

        assertTrue(topic.active)
        assertEquals("interferon_antiviral_axis", topic.activeThread?.immuneAxis)
        assertTrue(queue.active)
        assertEquals("LEAD_OBJECT_SECONDARY_LOOKUP", queue.items.first().status)
        assertTrue(queue.items.first().nextLookup.contains("LEAD_OBJECT_SECONDARY_LOOKUP"))
    }
}
