package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchCycleSearchStageTest {
    @Test
    fun failoverIsBlockedWhenUnifiedSearchLockIsActive() {
        val plan = ResearchCycleSearchStage.buildRuntimeFailoverPlan(
            unifiedSearchLockAfterForager = true,
            stopped = false,
            newFindingsCount = 0,
            repeatedSkipped = 99,
            effectiveMaxQueries = 6,
            effectiveResultsPerQuery = 20
        )

        assertFalse(plan.shouldRun)
        assertTrue(plan.blockedByLock)
        assertEquals(0, plan.queries.size)
    }

    @Test
    fun failoverBuildsBoundedDatasetQueriesOnlyWhenHardStagnationIsOpen() {
        val plan = ResearchCycleSearchStage.buildRuntimeFailoverPlan(
            unifiedSearchLockAfterForager = false,
            stopped = false,
            newFindingsCount = 0,
            repeatedSkipped = 99,
            effectiveMaxQueries = 6,
            effectiveResultsPerQuery = 20
        )

        assertTrue(plan.shouldRun)
        assertFalse(plan.blockedByLock)
        assertTrue(plan.queries.any { it.id == "q_runtime_dataset_accession" })
        assertTrue(plan.maxQueries >= 6)
    }
}
