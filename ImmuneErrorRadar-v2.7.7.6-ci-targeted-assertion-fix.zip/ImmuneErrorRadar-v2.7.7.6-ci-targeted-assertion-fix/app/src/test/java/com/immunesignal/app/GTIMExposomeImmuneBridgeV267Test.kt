package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class GTIMExposomeImmuneBridgeV267Test {
    private fun assetText(name: String): String {
        val candidates = listOf(
            File("app/src/main/assets/$name"),
            File("src/main/assets/$name"),
            File("../app/src/main/assets/$name"),
            File(System.getProperty("user.dir"), "app/src/main/assets/$name"),
            File(System.getProperty("user.dir"), "src/main/assets/$name")
        )
        val found = candidates.firstOrNull { it.isFile }
            ?: error("Missing asset $name. Tried: ${candidates.joinToString { it.path }}")
        return found.readText()
    }

    @Test
    fun exposomeQuestionOpensGutHormonePesticideAntibioticHeavyMetalAndPlasticBridges() {
        val question = "Compare immune routes from gut digestive microbiome, hormones, pesticides on food, antibiotics in poultry livestock meat, heavy metals in drinking water, and microplastics BPA phthalates PFAS."
        val report = GTIMExposomeImmuneBridgeV267.closeCycle(question)

        assertTrue(report.active)
        assertEquals("EXPOSOME_IMMUNE_CYCLE_CLOSED", report.closureState)
        assertEquals(6, report.mandatoryDomainsCovered.size)
        assertTrue(report.claimLimit.contains("not_diagnosis"))
        assertTrue(report.cards.any { it.exposureDomain == "gut_digestive_microbiome_barrier" })
        assertTrue(report.cards.any { it.exposureDomain == "water_heavy_metal_immune_axis" })
        assertTrue(report.cards.any { it.exposureDomain == "plastic_microplastic_endocrine_immune_axis" })
    }

    @Test
    fun parserPlannerAndRouteTraceExposeExposomeBridge() {
        val intent = GTIMResearchIntentParserV255.parse(
            "Gut microbiome hormones pesticide residues antibiotics poultry heavy metals water plastics microplastics immune cytokine RNA-seq Europe PMC OpenAlex comparator"
        )
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        val trace = GTIMExploratoryRouteLinkageV266.trace(intent.sourceText)

        assertTrue(intent.triggerExposure.any { it.contains("microbiome", ignoreCase = true) || it.contains("pesticide", ignoreCase = true) || it.contains("heavy", ignoreCase = true) })
        assertTrue(plan.repositorySearchPlan.any { it.repository == "Exposome Immune Bridges" })
        assertTrue(plan.querySeeds.any { it.contains("microplastics", ignoreCase = true) || it.contains("pesticide", ignoreCase = true) })
        assertTrue(trace.exposomeLinked)
        assertTrue(trace.europePmcLinked)
        assertTrue(trace.openAlexLinked)
    }

    @Test
    fun exposomeAssetAndSeedAccessionsStayClaimBounded() {
        val exposome = JSONObject(assetText("gtim_exposome_immune_bridge_v2.6.7.json"))
        assertEquals("exposome_immune_bridges_research_leads_only_not_diagnosis_treatment_or_exposure_attribution", exposome.getString("claim_limit"))
        assertEquals(6, exposome.getJSONArray("mandatoryDomains").length())
        assertTrue(exposome.getJSONObject("safety").getBoolean("requiresMeasuredExposureBeforeUpgrade"))

        val seed = JSONObject(assetText("gtim_seed_accessions_v2.6.5.json"))
        val arr = seed.getJSONArray("seedAccessions")
        val axes = (0 until arr.length()).map { arr.getJSONObject(it).getString("axis") }.toSet()
        assertTrue(axes.contains("gut_digestive_microbiome_barrier"))
        assertTrue(axes.contains("endocrine_hormone_immune_axis"))
        assertTrue(axes.contains("food_pesticide_residue_immune_axis"))
        assertTrue(axes.contains("livestock_antibiotic_residue_microbiome_axis"))
        assertTrue(axes.contains("water_heavy_metal_immune_axis"))
        assertTrue(axes.contains("plastic_microplastic_endocrine_immune_axis"))
    }
}
