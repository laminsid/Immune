package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GradedExploratoryResearchResultsV1115Test {
    @Test
    fun weakIntersectingLeadProducesGradedResearchLeadWithoutEvidenceObject() {
        val rule = MetadataClosureIntersectionRuleV11057(
            ruleId = "R2_PSYCHEPHYSIOLOGICAL_EXPOSOME",
            label = "Psychophysiological exposome",
            verified = true,
            matchedFamilies = listOf("HPA_SLEEP", "CYTOKINE"),
            matchedTokens = listOf("sleep deprivation", "IL-6", "TNF-alpha"),
            routeFitFloor = 95,
            priorityAction = "UNLOCK_AGGRESSIVE_QUERY_STREAM",
            validationEmbargoBypassScope = "metadata_probe_query_priority_only",
            accessionPatterns = listOf("GSE[0-9]*", "SRP[0-9]*"),
            programmaticQueries = listOf("sleep deprivation IL-6 TNF-alpha RNA-seq GSE[0-9]*")
        )
        val report = ResearchGradeMechanismDossierV1110.evaluate(
            steering = null,
            matrix = MetadataClosureStrategyMatrixReport.empty().copy(
                hyperDriveModeActive = true,
                crossReferenceMatrix = listOf(rule),
                hardClaimGates = listOf("confirmed accession", "control/comparator", "matrix availability")
            ),
            candidates = emptyList(),
            parsedMetadata = emptyList(),
            leadObjects = emptyList(),
            attempts = emptyList()
        )

        assertEquals("GRADED_RESEARCH_LEADS_IN_PROGRESS", report.state)
        assertEquals("GRADED_EXPLORATORY_RESULTS", report.researchResultMode)
        assertTrue(report.exploratoryResearchLeads.isNotEmpty())
        assertTrue(report.exploratoryResearchLeads.first().confidence > 0)
        assertEquals("EVIDENCE_OBJECT_BLOCKED_NO_CONFIRMED_ACCESSION", report.evidenceObjectCreationGate)
        assertTrue(report.bestResearchLeadSummary.contains("HPA") || report.bestResearchLeadSummary.contains("sleep"))
    }

    @Test
    fun confirmedAccessionStillProducesResearchLeadWhenEvidenceObjectBlocked() {
        val candidate = DatasetAccessionCandidate(
            accession = "GSE33333",
            source = "GEO_GDS",
            organismHint = "human patients",
            conditionLabelsHint = "SLE case; baseline",
            outcomeLabelsHint = "response",
            triggerResponseOutcomeHint = "RNA-seq transcriptome sample metadata",
            timeCourseHint = "baseline follow-up",
            sampleSizeHint = "n=16",
            dataType = "RNA-seq transcriptome",
            usabilityScore = 55,
            status = "ACCESSION_TEXT_FOUND",
            sourceFindingId = "geo_gse33333",
            sourceTitle = "GSE33333 human SLE RNA-seq case baseline metadata",
            sourceUrl = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE33333",
            reasons = listOf("GSE33333", "sample metadata", "baseline", "case")
        )
        val report = ResearchGradeMechanismDossierV1110.evaluate(
            steering = null,
            matrix = MetadataClosureStrategyMatrixReport.empty().copy(hyperDriveModeActive = true),
            candidates = listOf(candidate),
            parsedMetadata = emptyList(),
            leadObjects = emptyList(),
            attempts = emptyList()
        )

        assertTrue(report.accessionCandidates.isNotEmpty())
        assertTrue(report.exploratoryResearchLeads.isNotEmpty())
        assertEquals("GRADED_EXPLORATORY_RESULTS", report.researchResultMode)
        assertTrue(report.exploratoryResearchLeads.first().supportingSignals.contains("GSE33333"))
        assertTrue(report.evidenceObjectCreationGate != "EVIDENCE_OBJECT_REVIEW_CANDIDATE_NO_CLAIM")
    }
}
