package com.immunesignal.app

import java.util.Locale

/**
 * v2.7.3.8: turns the benchmark stopExpansion warning into a functional runtime lock.
 *
 * It does not stop research or evidence retrieval. It prevents feature-expansion style query
 * drift after poor value-benchmark reports, and keeps the next cycle focused on retrieval,
 * relationship proof-of-value, contradiction, dataset/accession, and paper-lite improvement.
 */
data class GTIMExpansionLockReportV2738(
    val active: Boolean,
    val state: String,
    val reason: String,
    val allowedFocus: List<String>,
    val claimLimit: String = GTIMExpansionLockV2738.CLAIM_LIMIT
) {
    companion object {
        fun inactive() = GTIMExpansionLockReportV2738(
            active = false,
            state = "EXPANSION_LOCK_INACTIVE",
            reason = "No recent benchmark stop-expansion signal.",
            allowedFocus = GTIMExpansionLockV2738.ALLOWED_FOCUS
        )
    }
}

object GTIMExpansionLockV2738 {
    const val VERSION: String = "2.7.3.8-functional-benchmark-expansion-lock"
    const val CLAIM_LIMIT: String = "product_value_lock_only_not_scientific_evidence"

    val ALLOWED_FOCUS: List<String> = listOf(
        "dataset/accession retrieval",
        "relationship discovery proof-of-value",
        "contradiction/null-result search",
        "paper-understanding-lite extraction",
        "PubMed/Elicit/Consensus benchmark comparison"
    )

    fun evaluate(recentReports: List<String>): GTIMExpansionLockReportV2738 {
        if (!RuntimeFeatureFlags.ENABLE_EXPANSION_LOCK_V2738) return GTIMExpansionLockReportV2738.inactive()
        val recent = recentReports.take(5).joinToString("\n")
        if (recent.isBlank()) return GTIMExpansionLockReportV2738.inactive()
        val lowBenchmark = recent.contains("BENCHMARK_VALUE_NOT_PROVEN", ignoreCase = true) ||
            recent.contains("stopExpansion=true", ignoreCase = true) ||
            recent.contains("Stop feature expansion", ignoreCase = true)
        if (!lowBenchmark) return GTIMExpansionLockReportV2738.inactive()
        return GTIMExpansionLockReportV2738(
            active = true,
            state = "EXPANSION_LOCKED_UNTIL_PROOF_OF_VALUE",
            reason = "Recent benchmark report did not prove value; next cycle must focus on retrieval/paper-lite/relationship evidence instead of feature expansion.",
            allowedFocus = ALLOWED_FOCUS
        )
    }

    fun filterQueries(
        report: GTIMExpansionLockReportV2738,
        queries: List<ResearchQuery>,
        fallbackQueries: List<ResearchQuery>
    ): List<ResearchQuery> {
        if (!report.active) return queries
        val allowed = queries.filter { query ->
            val text = listOf(query.id, query.label, query.query, query.reason).joinToString(" ").lowercase(Locale.US)
            listOf(
                "accession", "dataset", "data availability", "gse", "prjna", "sra", "pmid", "doi",
                "contradiction", "null result", "no association", "relationship", "microbiome", "mediator",
                "paper", "abstract", "benchmark", "europe pmc", "openalex", "pubmed"
            ).any { text.contains(it) }
        }
        val base = if (allowed.isNotEmpty()) allowed else fallbackQueries
        return base.distinctBy { it.query.lowercase(Locale.US) }.take(6)
    }
}
