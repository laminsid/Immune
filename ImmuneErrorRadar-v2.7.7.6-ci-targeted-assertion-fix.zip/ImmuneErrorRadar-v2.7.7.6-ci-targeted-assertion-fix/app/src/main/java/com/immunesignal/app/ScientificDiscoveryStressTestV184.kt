package com.immunesignal.app

import java.util.Locale
import kotlin.math.max

/**
 * v1.8.4: counterfactual discovery stress-test layer.
 *
 * v1.8.3 creates a falsifiable decision-memory contract. This layer tests that
 * contract before the next run by simulating the most important evidence
 * branches: pass, fail, null result, contradiction, and false-friend trap. It
 * does not claim biology; it decides how the next cycle should react if each
 * branch occurs.
 */
data class DiscoveryStressScenario(
    val scenarioId: String,
    val label: String,
    val trigger: String,
    val expectedEvidence: List<String>,
    val passCondition: String,
    val failCondition: String,
    val ifPass: String,
    val ifFail: String,
    val routingEffect: String,
    val risk: String
)

data class ScientificDiscoveryStressTestReport(
    val active: Boolean,
    val version: String,
    val stressState: String,
    val selectedScenario: String,
    val scenarios: List<DiscoveryStressScenario>,
    val passSignals: List<String>,
    val failSignals: List<String>,
    val nullResultPolicy: String,
    val contradictionPolicy: String,
    val routeCooldownSignals: List<String>,
    val forcedNextTerms: List<String>,
    val forcedEvidenceKeys: List<String>,
    val branchActions: List<String>,
    val reportLine: String,
    val claimLimit: String = "counterfactual_stress_test_guides_routing_not_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryStressTestReport(
            active = false,
            version = "v1.8.4",
            stressState = "NOT_RUN",
            selectedScenario = "none",
            scenarios = emptyList(),
            passSignals = emptyList(),
            failSignals = emptyList(),
            nullResultPolicy = "Run a research cycle first.",
            contradictionPolicy = "No contradiction policy available.",
            routeCooldownSignals = emptyList(),
            forcedNextTerms = emptyList(),
            forcedEvidenceKeys = emptyList(),
            branchActions = emptyList(),
            reportLine = "Discovery stress test did not run.",
            claimLimit = "counterfactual_stress_test_guides_routing_not_proof"
        )
    }
}

object ScientificDiscoveryStressTestEngineV184 {
    fun stressTest(
        decisionMemory: ScientificDiscoveryDecisionReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        causalReadiness: CausalReadinessReport,
        miniPeerReview: MiniPeerReviewReport,
        datasetForaging: DatasetForagingReport
    ): ScientificDiscoveryStressTestReport {
        if (!decisionMemory.active && !scientificWeights.active && !deepDiscovery.active) return ScientificDiscoveryStressTestReport.empty()

        val parsed = datasetForaging.parsedMetadata
        val hasOutcome = parsed.any { it.outcomeLabels.isNotEmpty() }
        val hasControl = parsed.any { it.controlLabels.isNotEmpty() } || datasetForaging.contrastiveReport.gateStatus.contains("PASS", true)
        val hasTime = parsed.any { it.timeCourseLabels.isNotEmpty() }
        val highRouteFit = datasetForaging.routeFitAssessments.any { it.routeFitScore >= 80 }
        val lowUsability = datasetForaging.scoreSeparation.datasetUsabilityScore in 1..64
        val candidateOnly = datasetForaging.candidates.isNotEmpty() && parsed.isEmpty()
        val falseFriend = scientificWeights.downgradedFalseFriends.firstOrNull()
        val contradictionObjection = deepDiscovery.contradictionPlan.strongestObjection.takeIf { it.isNotBlank() && it != "none" }
            ?: miniPeerReview.strongestObjection.takeIf { it.isNotBlank() && it != "No hypothesis reviewed." }
            ?: "No hard contradiction yet; force negative-control search before upgrade."

        val scenarios = buildScenarios(
            decisionMemory = decisionMemory,
            scientificWeights = scientificWeights,
            deepDiscovery = deepDiscovery,
            hasOutcome = hasOutcome,
            hasControl = hasControl,
            hasTime = hasTime,
            highRouteFit = highRouteFit,
            lowUsability = lowUsability,
            candidateOnly = candidateOnly,
            falseFriend = falseFriend,
            contradictionObjection = contradictionObjection
        )
        val selected = selectScenario(scenarios, highRouteFit, hasOutcome, hasControl, hasTime, falseFriend, candidateOnly)
        val passSignals = buildPassSignals(decisionMemory, scientificWeights, deepDiscovery, causalReadiness, hasOutcome, hasControl, hasTime)
        val failSignals = buildFailSignals(decisionMemory, scientificWeights, causalReadiness, miniPeerReview, highRouteFit, candidateOnly)
        val forcedEvidence = normalizeEvidenceKeys(
            selected.expectedEvidence + decisionMemory.evidenceImpactKeys + scientificWeights.decisiveEvidenceDelta + passSignals + failSignals
        ).take(14)
        val forcedTerms = normalizeTerms(
            selected.expectedEvidence + decisionMemory.queryImpactTerms + scientificWeights.searchPriorityVector + deepDiscovery.decisiveExperiment.nextQuery.split(' ')
        ).take(36)
        val branchActions = buildBranchActions(selected, forcedEvidence, falseFriend, contradictionObjection, causalReadiness)
        val cooldownSignals = buildCooldownSignals(selected, failSignals, highRouteFit, candidateOnly)
        val state = when {
            falseFriend != null -> "FALSE_FRIEND_STRESS"
            highRouteFit && (!hasOutcome || !hasControl || !hasTime) -> "HIGH_ROUTE_FIT_STRESS"
            candidateOnly -> "METADATA_ONLY_STRESS"
            causalReadiness.level < 3 -> "CAUSAL_BLOCK_STRESS"
            else -> "BOUNDED_DISCOVERY_STRESS"
        }
        val nullPolicy = "If next cycle returns metadata/title-only or no outcome/control/time delta, keep the route as context prior, do not strengthen beliefs, and cool down similar broad queries for one cycle."
        val contradictionPolicy = "If contradiction/negative-control evidence is found, route to falsification first and downgrade mechanism language before any new hypothesis wording."
        val reportLine = "v1.8.4 stress test: $state; scenario=${selected.scenarioId}; pass=${passSignals.take(3).joinToString("/")}; fail=${failSignals.take(3).joinToString("/")}."

        return ScientificDiscoveryStressTestReport(
            active = true,
            version = "v1.8.4-counterfactual-stress-test",
            stressState = state,
            selectedScenario = selected.scenarioId,
            scenarios = scenarios.take(6),
            passSignals = passSignals.take(8),
            failSignals = failSignals.take(8),
            nullResultPolicy = nullPolicy,
            contradictionPolicy = contradictionPolicy,
            routeCooldownSignals = cooldownSignals.take(8),
            forcedNextTerms = forcedTerms,
            forcedEvidenceKeys = forcedEvidence,
            branchActions = branchActions.take(8),
            reportLine = reportLine.take(420),
            claimLimit = "counterfactual_stress_test_guides_routing_not_proof"
        )
    }

    private fun buildScenarios(
        decisionMemory: ScientificDiscoveryDecisionReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        hasOutcome: Boolean,
        hasControl: Boolean,
        hasTime: Boolean,
        highRouteFit: Boolean,
        lowUsability: Boolean,
        candidateOnly: Boolean,
        falseFriend: String?,
        contradictionObjection: String
    ): List<DiscoveryStressScenario> = buildList {
        add(
            DiscoveryStressScenario(
                scenarioId = "PASS_DECISIVE_EVIDENCE",
                label = "Pass: decisive evidence appears",
                trigger = decisionMemory.selectedMove.ifBlank { deepDiscovery.decisiveExperiment.decisiveQuestion },
                expectedEvidence = listOf("outcome_labels", "comparator_control", "time_order") + scientificWeights.decisiveEvidenceDelta,
                passCondition = "Dataset contains explicit outcome/recovery/severity plus comparator/control and interpretable time order.",
                failCondition = "Only route-fit, title, metadata, or generic marker evidence appears.",
                ifPass = "Allow cautious belief strengthening only inside the same tissue/route; keep claim limit visible.",
                ifFail = "Downgrade to context prior and force contradiction/control search next.",
                routingEffect = "Prefer dataset parsing and controlled-comparison queries over broad PubMed search.",
                risk = if (hasOutcome && hasControl && hasTime) "LOW" else "HIGH"
            )
        )
        if (highRouteFit || lowUsability) {
            add(
                DiscoveryStressScenario(
                    scenarioId = "HIGH_ROUTE_FIT_LOW_USABILITY_TRAP",
                    label = "Stress: high route-fit but weak usability",
                    trigger = "route-fit score is high while decisive labels remain incomplete",
                    expectedEvidence = listOf("minimum_metadata", "sample_size", "phenotype_granularity", "outcome_labels", "control_or_comparator"),
                    passCondition = "Usability rises through parsed sample/condition/outcome/control labels.",
                    failCondition = "Route-fit stays high but usability remains below inspection threshold.",
                    ifPass = "Continue same route with stricter evidence contract.",
                    ifFail = "Cool down route and block route-fit from driving belief updates.",
                    routingEffect = "Add metadata parser and sample/phenotype terms to next-cycle directive.",
                    risk = "HIGH"
                )
            )
        }
        if (candidateOnly) {
            add(
                DiscoveryStressScenario(
                    scenarioId = "METADATA_ONLY_NULL_RESULT",
                    label = "Stress: candidate is metadata/title-only",
                    trigger = "dataset candidate exists but parsed metadata is missing",
                    expectedEvidence = listOf("accession", "metadata", "sample_size", "condition_labels", "license", "assay_platform_quality"),
                    passCondition = "Minimum metadata parser returns usable condition/outcome/control fields.",
                    failCondition = "Only accession/title/source text is available after the next cycle.",
                    ifPass = "Move to controlled comparison inspection.",
                    ifFail = "Archive as weak lead and require a different dataset family.",
                    routingEffect = "Force accession metadata inspection rather than hypothesis language.",
                    risk = "MEDIUM"
                )
            )
        }
        if (falseFriend != null) {
            add(
                DiscoveryStressScenario(
                    scenarioId = "FALSE_FRIEND_GENERALIZATION",
                    label = "Stress: false-friend term may mislead routing",
                    trigger = falseFriend,
                    expectedEvidence = listOf("negative_control", "confounder_control", "specific_route", "tissue_context", "effect_direction"),
                    passCondition = "Control evidence shows the term is specific to the route and not generic inflammation/artifact.",
                    failCondition = "Term appears in generic or off-route context without discriminator evidence.",
                    ifPass = "Use term as bounded route hint only.",
                    ifFail = "Downgrade term to context-only prior and exclude from routing boost.",
                    routingEffect = "Add negative-control and confounder terms before route expansion.",
                    risk = "HIGH"
                )
            )
        }
        add(
            DiscoveryStressScenario(
                scenarioId = "CONTRADICTION_FIRST_BRANCH",
                label = "Stress: contradiction should be searched before upgrade",
                trigger = contradictionObjection,
                expectedEvidence = listOf("contradiction", "negative_control", "failed_replication", "effect_reversal", "unrelated_marker_control"),
                passCondition = "No contradiction appears after targeted negative-control search and control evidence improves.",
                failCondition = "Contradiction, null effect, artifact, or unrelated-marker control explains the signal better.",
                ifPass = "Keep as inspectable lead, not proof.",
                ifFail = "Retire or weaken mechanism and record mistake pattern.",
                routingEffect = "Force falsification lane alongside the decisive evidence lane.",
                risk = if (decisionMemory.failureCriteria.isNotEmpty()) "MEDIUM" else "LOW"
            )
        )
    }

    private fun selectScenario(
        scenarios: List<DiscoveryStressScenario>,
        highRouteFit: Boolean,
        hasOutcome: Boolean,
        hasControl: Boolean,
        hasTime: Boolean,
        falseFriend: String?,
        candidateOnly: Boolean
    ): DiscoveryStressScenario {
        val wanted = when {
            falseFriend != null -> "FALSE_FRIEND_GENERALIZATION"
            candidateOnly -> "METADATA_ONLY_NULL_RESULT"
            highRouteFit && (!hasOutcome || !hasControl || !hasTime) -> "HIGH_ROUTE_FIT_LOW_USABILITY_TRAP"
            else -> "PASS_DECISIVE_EVIDENCE"
        }
        return scenarios.firstOrNull { it.scenarioId == wanted } ?: scenarios.first()
    }

    private fun buildPassSignals(
        decisionMemory: ScientificDiscoveryDecisionReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        causalReadiness: CausalReadinessReport,
        hasOutcome: Boolean,
        hasControl: Boolean,
        hasTime: Boolean
    ): List<String> = buildList {
        if (!hasOutcome) add("outcome_labels_found") else add("outcome_labels_present")
        if (!hasControl) add("comparator_control_found") else add("comparator_control_present")
        if (!hasTime) add("time_order_found") else add("time_order_present")
        if (causalReadiness.level < 3) add("controlled_comparison_threshold_reached")
        addAll(decisionMemory.successCriteria.map { normalizeKey(it) })
        addAll(scientificWeights.decisiveEvidenceDelta.map { normalizeKey(it) })
        val expected = deepDiscovery.decisiveExperiment.expectedUpdate
        if (expected.isNotBlank() && expected != "none") add(normalizeKey(expected))
    }.filter { it.isNotBlank() }.distinct()

    private fun buildFailSignals(
        decisionMemory: ScientificDiscoveryDecisionReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        causalReadiness: CausalReadinessReport,
        miniPeerReview: MiniPeerReviewReport,
        highRouteFit: Boolean,
        candidateOnly: Boolean
    ): List<String> = buildList {
        if (highRouteFit) add("high_route_fit_without_decisive_labels")
        if (candidateOnly) add("metadata_title_only_stall")
        if (causalReadiness.level < 3) add("causal_readiness_below_controlled_comparison")
        if (miniPeerReview.verdict in setOf("HOLD", "REJECT")) add("peer_review_objection_unresolved")
        addAll(decisionMemory.failureCriteria.map { normalizeKey(it) })
        addAll(scientificWeights.riskGuards.map { normalizeKey(it) })
    }.filter { it.isNotBlank() }.distinct()

    private fun buildBranchActions(
        selected: DiscoveryStressScenario,
        forcedEvidence: List<String>,
        falseFriend: String?,
        contradictionObjection: String,
        causalReadiness: CausalReadinessReport
    ): List<String> = buildList {
        add("PASS -> ${selected.ifPass}")
        add("FAIL -> ${selected.ifFail}")
        add("NULL -> archive weak lead unless ${forcedEvidence.take(3).joinToString("+")} improves.")
        if (falseFriend != null) add("FALSE_FRIEND -> downgrade to context prior: ${falseFriend.take(120)}")
        add("CONTRADICTION -> ${contradictionObjection.take(160)}")
        if (causalReadiness.level < 3) add("CAUSAL_LOCK -> no causal language until controlled comparison is found.")
    }

    private fun buildCooldownSignals(selected: DiscoveryStressScenario, failSignals: List<String>, highRouteFit: Boolean, candidateOnly: Boolean): List<String> = buildList {
        if (highRouteFit) add("cooldown_high_route_fit_without_labels")
        if (candidateOnly) add("cooldown_metadata_only_candidate")
        if (selected.scenarioId.contains("FALSE_FRIEND")) add("cooldown_false_friend_route_boost")
        failSignals.take(4).forEach { add("cooldown_if_$it") }
    }.distinct()

    private fun normalizeEvidenceKeys(items: List<String>): List<String> = items.map { normalizeEvidenceKey(it) }.filter { it.isNotBlank() }.distinct()

    private fun normalizeEvidenceKey(text: String): String {
        val lower = text.lowercase(Locale.US)
        return when {
            lower.contains("outcome") || lower.contains("recovery") || lower.contains("severity") || lower.contains("endpoint") -> "outcome_labels"
            lower.contains("time") || lower.contains("longitudinal") || lower.contains("serial") || lower.contains("baseline") || lower.contains("follow") -> "time_order"
            lower.contains("control") || lower.contains("comparator") || lower.contains("placebo") || lower.contains("negative") -> "comparator_control"
            lower.contains("metadata") || lower.contains("accession") || lower.contains("license") || lower.contains("sample") -> "minimum_metadata"
            lower.contains("phenotype") || lower.contains("clinical") || lower.contains("patient") || lower.contains("human") -> "human_or_patient_phenotype"
            lower.contains("replication") || lower.contains("validation") || lower.contains("repeated") -> "replication_validation"
            lower.contains("confound") || lower.contains("artifact") || lower.contains("batch") || lower.contains("assay") -> "artifact_confounder_control"
            lower.contains("intervention") || lower.contains("perturb") || lower.contains("treat") -> "perturbation_intervention"
            lower.contains("contradiction") || lower.contains("falsification") || lower.contains("null") || lower.contains("failed") -> "falsification_contradiction"
            lower.contains("cell") || lower.contains("tissue") -> "tissue_cell_context"
            else -> normalizeKey(text).take(80)
        }
    }

    private fun normalizeTerms(items: List<String>): List<String> = items.flatMap { text ->
        text.lowercase(Locale.US)
            .replace("rna seq", "rna-seq")
            .replace("single cell", "single-cell")
            .split(Regex("[^a-z0-9_-]+"))
            .map { it.trim() }
            .filter { it.length >= 3 }
            .filter { it in allowedTerms || it.startsWith("gse") || it.startsWith("prjna") }
    }.distinct()

    private fun normalizeKey(text: String): String = text.lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .take(90)

    private val allowedTerms = setOf(
        "outcome", "recovery", "severity", "endpoint", "clinical", "phenotype", "human", "patient",
        "control", "comparator", "placebo", "negative", "healthy", "metadata", "accession", "sample", "license",
        "longitudinal", "serial", "baseline", "follow-up", "time-course", "temporal", "replication", "validation",
        "contradiction", "falsification", "null", "failed", "effect", "direction", "reversal", "confounder", "artifact",
        "batch", "assay", "rna-seq", "single-cell", "transcriptomic", "cell-type", "tissue", "interferon", "viral", "load",
        "mechanism", "perturbation", "intervention", "dataset", "geo", "sra", "immune", "allergy", "inflammation"
    )
}
