package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.44: Viral Countermeasure Intelligence + Biomedical Dictionary/Database Linkage.
 *
 * This is a scientist/laboratory-facing research intelligence layer. It reverse-engineers
 * discovery workflows (virus identity -> antigen target prior -> strain scope -> platform
 * mapping -> evidence gates -> contradiction) without exposing wet-lab protocols,
 * manufacturing steps, viral engineering, vaccine recipes, dosing, treatment, diagnosis,
 * or clinical recommendations.
 */
data class ViralIdentityCard(
    val virusKey: String,
    val label: String,
    val family: String,
    val genomeType: String,
    val reservoirOrTransmission: String,
    val diseaseContexts: List<String>,
    val immuneAxes: List<String>,
    val accessionTerms: List<String>
)

data class AntigenTargetPriorCard(
    val targetId: String,
    val label: String,
    val surfaceOrInternal: String,
    val lookupTerms: List<String>,
    val evidenceKeys: List<String>,
    val invalidators: List<String>
)

data class ViralStrainScopeCard(
    val scopeId: String,
    val strainsOrSpecies: List<String>,
    val scopeRule: String,
    val invalidators: List<String>
)

data class CountermeasurePlatformCard(
    val platformId: String,
    val label: String,
    val lookupTerms: List<String>,
    val evidenceKeys: List<String>,
    val forbiddenClaims: List<String>
)

data class ViralCountermeasureReport(
    val active: Boolean,
    val state: String,
    val selectedVirusKey: String,
    val identityCard: ViralIdentityCard?,
    val targetPriorCards: List<AntigenTargetPriorCard>,
    val strainScopeCard: ViralStrainScopeCard?,
    val platformCards: List<CountermeasurePlatformCard>,
    val selectedLane: String,
    val priorityLookupTerms: List<String>,
    val evidenceKeysToClose: List<String>,
    val contradictionTerms: List<String>,
    val dictionaryPartitions: List<String>,
    val forbiddenClaims: List<String>,
    val invalidators: List<String>,
    val nextAction: String,
    val claimLimit: String = ViralCountermeasureIntelligenceV11044.CLAIM_LIMIT
) {
    companion object {
        fun empty() = ViralCountermeasureReport(
            active = false,
            state = "NOT_EVALUATED",
            selectedVirusKey = "none",
            identityCard = null,
            targetPriorCards = emptyList(),
            strainScopeCard = null,
            platformCards = emptyList(),
            selectedLane = "OFF",
            priorityLookupTerms = emptyList(),
            evidenceKeysToClose = emptyList(),
            contradictionTerms = emptyList(),
            dictionaryPartitions = emptyList(),
            forbiddenClaims = emptyList(),
            invalidators = emptyList(),
            nextAction = "No viral countermeasure routing available."
        )
    }
}

data class BiomedicalKnowledgeGraphLinkageReport(
    val active: Boolean,
    val state: String,
    val selectedPartitions: List<String>,
    val linkedLayers: List<String>,
    val dictionaryUpdateCards: List<String>,
    val bridgeEdges: List<String>,
    val retrievalIndexKeys: List<String>,
    val cachePolicy: String,
    val updatePolicy: String,
    val unresolvedGaps: List<String>,
    val nextAction: String,
    val claimLimit: String = BiomedicalKnowledgeGraphLinkerV11044.CLAIM_LIMIT
) {
    companion object {
        fun empty() = BiomedicalKnowledgeGraphLinkageReport(
            active = false,
            state = "NOT_EVALUATED",
            selectedPartitions = emptyList(),
            linkedLayers = emptyList(),
            dictionaryUpdateCards = emptyList(),
            bridgeEdges = emptyList(),
            retrievalIndexKeys = emptyList(),
            cachePolicy = "No modular biomedical dictionary/database linkage evaluated.",
            updatePolicy = "No update plan available.",
            unresolvedGaps = emptyList(),
            nextAction = "Run ontology and module selection first."
        )
    }
}

object ViralCountermeasureIntelligenceV11044 {
    const val CLAIM_LIMIT: String = "viral_countermeasure_routing_only_not_wetlab_or_clinical_proof"

    private val forbiddenClaims = listOf(
        "vaccine design recipe",
        "wet-lab protocol",
        "viral engineering instruction",
        "pathogen enhancement instruction",
        "manufacturing parameters",
        "dose recommendation",
        "treatment recommendation",
        "diagnosis",
        "countermeasure efficacy confirmed",
        "scientific breakthrough confirmed"
    )

    private data class VirusProfile(
        val key: String,
        val label: String,
        val family: String,
        val genomeType: String,
        val reservoirOrTransmission: String,
        val triggers: List<String>,
        val diseaseContexts: List<String>,
        val immuneAxes: List<String>,
        val accessionTerms: List<String>,
        val antigenTargets: List<AntigenTargetPriorCard>,
        val strains: List<String>,
        val lane: String,
        val priority: Int
    )

    private val profiles = listOf(
        VirusProfile(
            key = "HANTAVIRUS_COUNTERMEASURE_PROFILE",
            label = "Hantavirus countermeasure research profile",
            family = "Hantaviridae",
            genomeType = "segmented negative-sense RNA",
            reservoirOrTransmission = "rodent reservoir / environmental exposure; limited human-to-human relevance for specific strains",
            triggers = listOf("hanta", "hantavirus", "hantaan", "andes", "sin nombre", "puumala", "seoul virus", "dobrava", "hfrs", "hps", "hemorrhagic fever with renal syndrome", "hantavirus pulmonary syndrome"),
            diseaseContexts = listOf("HPS", "HFRS", "vascular leakage", "renal involvement", "pulmonary involvement", "shock", "platelet changes"),
            immuneAxes = listOf("endothelial inflammation", "neutralizing antibody", "T-cell response", "cytokine response", "vascular permeability"),
            accessionTerms = listOf("Hantavirus", "Hantaan", "Andes", "Sin Nombre", "Puumala", "Seoul", "Dobrava", "S segment", "M segment", "L segment", "GSE", "PRJNA", "SRP", "GenBank"),
            antigenTargets = listOf(
                AntigenTargetPriorCard(
                    targetId = "HANTA_GN_GC_GLYCOPROTEIN_PRIOR",
                    label = "Gn/Gc glycoprotein target prior",
                    surfaceOrInternal = "surface glycoprotein prior",
                    lookupTerms = listOf("Gn", "Gc", "glycoprotein", "neutralizing antibody", "pseudovirus neutralization", "cross-protection"),
                    evidenceKeys = listOf("virus_strain", "sequence_accession", "antigen_target", "neutralization_readout", "strain_coverage", "control_or_comparator", "outcome_or_protection_label"),
                    invalidators = listOf("No strain-specific sequence/accession is present", "No neutralization/protection readout exists", "Signal is strain-specific and cannot generalize")
                ),
                AntigenTargetPriorCard(
                    targetId = "HANTA_NUCLEOCAPSID_N_PRIOR",
                    label = "Nucleocapsid N immunoreactivity prior",
                    surfaceOrInternal = "internal antigen / immune-readout prior",
                    lookupTerms = listOf("nucleocapsid", "N protein", "T-cell", "serology", "diagnostic antigen", "immune response"),
                    evidenceKeys = listOf("antigen_target", "assay_platform", "human_or_patient_data", "control_or_comparator", "time_order", "outcome_labels"),
                    invalidators = listOf("Only serology narrative exists", "No control/comparator is present", "No outcome or timing is available")
                )
            ),
            strains = listOf("Hantaan", "Andes", "Sin Nombre", "Puumala", "Seoul", "Dobrava-Belgrade"),
            lane = "HANTAVIRUS_PATHOGENESIS_ANTIGEN_STRAIN_LANE",
            priority = 110
        ),
        VirusProfile(
            key = "SARS_COV_2_PLATFORM_UPDATE_PROFILE",
            label = "SARS-CoV-2 platform-update research profile",
            family = "Coronaviridae",
            genomeType = "positive-sense RNA",
            reservoirOrTransmission = "respiratory human transmission / variant surveillance",
            triggers = listOf("sars-cov-2", "covid", "long covid", "spike", "variant", "omicron", "post-viral", "resolution failure"),
            diseaseContexts = listOf("acute infection", "Long COVID", "resolution failure", "variant immune escape"),
            immuneAxes = listOf("neutralizing antibody", "T-cell response", "interferon timing", "mucosal immunity", "immune escape"),
            accessionTerms = listOf("SARS-CoV-2", "Spike", "S protein", "variant", "GISAID", "GenBank", "SRA", "PRJNA", "GSE"),
            antigenTargets = listOf(
                AntigenTargetPriorCard("SCOV2_SPIKE_PRIOR", "Spike antigen update prior", "surface glycoprotein prior", listOf("Spike", "RBD", "neutralization", "variant", "immune escape"), listOf("sequence_accession", "variant_lineage", "antigen_target", "neutralization_readout", "clinical_or_surveillance_endpoint", "control_or_comparator"), listOf("No lineage/variant scope", "No neutralization or outcome endpoint", "No comparator"))
            ),
            strains = listOf("Omicron-lineage", "pre-Omicron", "emerging lineage"),
            lane = "SARS_COV_2_VARIANT_PLATFORM_UPDATE_LANE",
            priority = 90
        ),
        VirusProfile(
            key = "EBV_MOLECULAR_MIMICRY_COUNTERMEASURE_PROFILE",
            label = "EBV molecular-mimicry research profile",
            family = "Herpesviridae",
            genomeType = "double-stranded DNA",
            reservoirOrTransmission = "latent herpesvirus / B-cell persistence",
            triggers = listOf("ebv", "epstein-barr", "ebna1", "herpesviridae", "molecular mimicry", "multiple sclerosis", "ms", "sle"),
            diseaseContexts = listOf("MS", "SLE", "molecular mimicry", "B-cell response", "latent-virus reactivation"),
            immuneAxes = listOf("B-cell antibody axis", "molecular mimicry", "autoantibody", "T-cell response", "latent virus"),
            accessionTerms = listOf("EBV", "Epstein-Barr", "EBNA1", "Herpesviridae", "GSE", "PRJNA", "SRP", "PMID", "DOI"),
            antigenTargets = listOf(
                AntigenTargetPriorCard("EBV_EBNA1_MIMICRY_PRIOR", "EBNA1 molecular-mimicry prior", "latent nuclear antigen / mimicry prior", listOf("EBNA1", "molecular mimicry", "cross-reactive", "autoantibody", "B cell", "GlialCAM"), listOf("accession_or_source_id", "human_or_patient_data", "molecular_mimicry_context", "outcome_labels", "control_or_comparator", "time_order", "contradiction_search"), listOf("No EBV/EBNA1 term in source", "No human/control context", "No outcome/time-order evidence"))
            ),
            strains = listOf("EBV type 1", "EBV type 2", "Herpesviridae context"),
            lane = "EBV_MOLECULAR_MIMICRY_FALSIFIABLE_LANE",
            priority = 100
        ),
        VirusProfile(
            key = "CMV_IMMUNOSENESCENCE_PROFILE",
            label = "CMV immunosenescence research profile",
            family = "Herpesviridae",
            genomeType = "double-stranded DNA",
            reservoirOrTransmission = "latent herpesvirus / immune aging context",
            triggers = listOf("cmv", "cytomegalovirus", "immunosenescence", "immune aging", "t cell inflation"),
            diseaseContexts = listOf("immunosenescence", "T-cell inflation", "aging", "chronic inflammation"),
            immuneAxes = listOf("T-cell differentiation", "immune aging", "inflammaging", "serostatus"),
            accessionTerms = listOf("CMV", "cytomegalovirus", "serostatus", "GSE", "PRJNA", "SRP", "ImmPort", "SDY"),
            antigenTargets = listOf(
                AntigenTargetPriorCard("CMV_SEROSTATUS_T_CELL_PRIOR", "CMV serostatus / T-cell inflation prior", "latent-virus immune-context prior", listOf("CMV", "serostatus", "CD8", "T-cell inflation", "immunosenescence"), listOf("serostatus", "human_or_patient_data", "age_context", "control_or_comparator", "cell_type", "outcome_labels"), listOf("No serostatus or age context", "No control/comparator", "No immune phenotype endpoint"))
            ),
            strains = listOf("CMV serostatus context"),
            lane = "CMV_IMMUNOSENESCENCE_CONTEXT_LANE",
            priority = 70
        )
    )

    private val platformCards = listOf(
        CountermeasurePlatformCard("MRNA_LNP_RESEARCH_PLATFORM", "mRNA/LNP research platform", listOf("mRNA", "LNP", "lipid nanoparticle", "RNA delivery", "antigen expression"), listOf("platform", "payload_or_antigen", "immune_readout", "control_or_comparator", "safety_or_artifact_signal", "strain_scope"), forbiddenClaims),
        CountermeasurePlatformCard("PROTEIN_SUBUNIT_VLP_PLATFORM", "protein subunit / VLP research platform", listOf("protein subunit", "VLP", "virus-like particle", "glycoprotein", "adjuvant as metadata only"), listOf("antigen_target", "assay_platform", "neutralization_readout", "control_or_comparator", "strain_coverage"), forbiddenClaims),
        CountermeasurePlatformCard("INACTIVATED_VECTOR_DNA_PLATFORM", "inactivated/vector/DNA candidate literature platform", listOf("inactivated", "viral vector", "DNA vaccine", "candidate", "animal model"), listOf("platform", "model_system", "human_relevance", "control_or_comparator", "protection_or_outcome_label"), forbiddenClaims),
        CountermeasurePlatformCard("MONOCLONAL_NEUTRALIZATION_PLATFORM", "neutralizing antibody / monoclonal evidence platform", listOf("monoclonal antibody", "neutralizing antibody", "neutralization", "escape", "cross-neutralization"), listOf("antibody_target", "neutralization_readout", "strain_scope", "control_or_comparator", "replication_or_validation"), forbiddenClaims)
    )

    fun evaluate(
        steering: ResearchSteeringProfile?,
        leadObjects: List<LeadObject>,
        metadataClosure: MetadataClosureReport,
        evidencePrior: EvidencePriorSelectionReport,
        ontology: BiomedicalResearchOntologyReport,
        conceptBridge: BiomedicalConceptBridgeReport,
        modernTech: ModernMedicalTechnologyReport,
        recentReports: List<String>
    ): ViralCountermeasureReport {
        val corpus = buildCorpus(steering, leadObjects, metadataClosure, evidencePrior, ontology, conceptBridge, modernTech, recentReports)
        val selected = profiles.mapNotNull { profile ->
            val hits = profile.triggers.count { corpus.contains(it.lowercase(Locale.US)) }
            val priorBoost = if (evidencePrior.queryTerms.any { term -> profile.triggers.any { it.equals(term, ignoreCase = true) } }) 18 else 0
            val ontologyBoost = if (ontology.selectedDomains.any { it.contains("PATHOGENS", ignoreCase = true) || it.contains("VIRUS", ignoreCase = true) }) 10 else 0
            val accessionBoost = if (metadataClosure.missingFields.contains("accession")) 5 else 0
            val score = profile.priority + hits * 12 + priorBoost + ontologyBoost + accessionBoost
            if (hits == 0 && priorBoost == 0) null else profile to score
        }.sortedByDescending { it.second }.firstOrNull()?.first

        if (selected == null) {
            return ViralCountermeasureReport(
                active = true,
                state = "VIRAL_COUNTERMEASURE_BASELINE_READY_NO_VIRUS_SELECTED",
                selectedVirusKey = "none",
                identityCard = null,
                targetPriorCards = emptyList(),
                strainScopeCard = null,
                platformCards = emptyList(),
                selectedLane = "BASELINE_ACCESSION_AND_STRAIN_AWARENESS",
                priorityLookupTerms = listOf("virus", "strain", "sequence accession", "antigen", "neutralization", "control", "outcome", "time-course", "GSE", "PRJNA", "SRP"),
                evidenceKeysToClose = listOf("virus_or_pathogen_identity", "strain_scope", "accession", "antigen_target", "human_or_patient_data", "control_or_comparator", "time_order", "outcome_labels"),
                contradictionTerms = contradictionTerms(),
                dictionaryPartitions = listOf("pathogens", "accession_repositories", "assay_platforms", "evidence_gates"),
                forbiddenClaims = forbiddenClaims,
                invalidators = listOf("No virus/pathogen term selected by the current lead."),
                nextAction = "Keep viral countermeasure lane dormant; run pathogen identity lookup only if virus/pathogen vocabulary appears."
            )
        }

        val identity = ViralIdentityCard(selected.key, selected.label, selected.family, selected.genomeType, selected.reservoirOrTransmission, selected.diseaseContexts, selected.immuneAxes, selected.accessionTerms)
        val platformMatches = platformCards.filter { card -> card.lookupTerms.any { corpus.contains(it.lowercase(Locale.US)) } }.ifEmpty { platformCards.take(2) }
        val strainScope = ViralStrainScopeCard(
            scopeId = selected.key + "_STRAIN_SCOPE",
            strainsOrSpecies = selected.strains,
            scopeRule = "Do not generalize across strains/species until sequence/accession, antigen target, immune readout, and outcome/control gates are visible.",
            invalidators = listOf("No strain/species scope", "Only family-level vocabulary", "No sequence or accession handle")
        )
        val evidenceKeys = (selected.antigenTargets.flatMap { it.evidenceKeys } + platformMatches.flatMap { it.evidenceKeys } + listOf("sequence_accession", "strain_scope", "contradiction_search", "negative_control", "failed_replication_search")).distinct()
        val missingFirst = metadataClosure.missingFields.filter { it in evidenceKeys }
        val lookup = (selected.accessionTerms + selected.antigenTargets.flatMap { it.lookupTerms } + platformMatches.flatMap { it.lookupTerms } + listOf("GSE", "PRJNA", "SRP", "SRR", "GenBank", "control", "outcome", "longitudinal", "neutralization")).distinct().take(42)
        val state = when {
            selected.key.startsWith("HANTAVIRUS") -> "VIRAL_COUNTERMEASURE_HANTAVIRUS_PROFILE_SELECTED_METADATA_GATED"
            selected.key.startsWith("EBV") -> "VIRAL_COUNTERMEASURE_EBV_MIMICRY_PROFILE_SELECTED_METADATA_GATED"
            selected.key.startsWith("SARS") -> "VIRAL_COUNTERMEASURE_SARS_COV_2_VARIANT_PROFILE_SELECTED_METADATA_GATED"
            else -> "VIRAL_COUNTERMEASURE_PROFILE_SELECTED_METADATA_GATED"
        }
        return ViralCountermeasureReport(
            active = true,
            state = state,
            selectedVirusKey = selected.key,
            identityCard = identity,
            targetPriorCards = selected.antigenTargets,
            strainScopeCard = strainScope,
            platformCards = platformMatches,
            selectedLane = selected.lane,
            priorityLookupTerms = lookup,
            evidenceKeysToClose = (missingFirst + evidenceKeys).distinct().take(36),
            contradictionTerms = contradictionTerms(),
            dictionaryPartitions = listOf("pathogens", "viral_countermeasure", "antigen_targets", "strain_scope", "platform_mapping", "accession_repositories", "evidence_gates"),
            forbiddenClaims = forbiddenClaims,
            invalidators = (selected.antigenTargets.flatMap { it.invalidators } + strainScope.invalidators + platformMatches.flatMap { it.forbiddenClaims.take(1) }).distinct().take(12),
            nextAction = "Run accession-specific viral countermeasure lookup for ${selected.label}; close strain_scope + antigen_target + control/comparator + outcome/time-order before any countermeasure claim."
        )
    }

    private fun contradictionTerms(): List<String> = listOf(
        "no association", "failed replication", "heterogeneity", "negative control", "reverse timing", "unrelated marker control", "strain-specific only", "animal-only evidence", "in vitro only", "batch artifact"
    )

    private fun buildCorpus(
        steering: ResearchSteeringProfile?,
        leadObjects: List<LeadObject>,
        metadataClosure: MetadataClosureReport,
        evidencePrior: EvidencePriorSelectionReport,
        ontology: BiomedicalResearchOntologyReport,
        conceptBridge: BiomedicalConceptBridgeReport,
        modernTech: ModernMedicalTechnologyReport,
        recentReports: List<String>
    ): String = listOf(
        steering?.focusQuestion.orEmpty(),
        steering?.variables?.joinToString(" ").orEmpty(),
        leadObjects.joinToString(" ") { listOf(it.title, it.snippet, it.domain, it.omicsType, it.dataAvailabilityText, it.detectedAccessions.joinToString(" ")).joinToString(" ") },
        metadataClosure.closedFields.joinToString(" "),
        metadataClosure.missingFields.joinToString(" "),
        evidencePrior.selectedPriorId,
        evidencePrior.selectedRoute,
        evidencePrior.queryTerms.joinToString(" "),
        ontology.selectedDomains.joinToString(" "),
        ontology.matchedTerms.joinToString(" "),
        conceptBridge.selectedBridgeIds.joinToString(" "),
        conceptBridge.priorityLookupTerms.joinToString(" "),
        modernTech.selectedModuleIds.joinToString(" "),
        modernTech.priorityLookupTerms.joinToString(" "),
        recentReports.takeLast(8).joinToString(" ")
    ).joinToString(" ").lowercase(Locale.US)
}

object BiomedicalKnowledgeGraphLinkerV11044 {
    const val CLAIM_LIMIT: String = "biomedical_dictionary_database_linkage_not_biological_proof"

    fun link(
        ontology: BiomedicalResearchOntologyReport,
        conceptBridge: BiomedicalConceptBridgeReport,
        modernTech: ModernMedicalTechnologyReport,
        viral: ViralCountermeasureReport,
        metadataClosure: MetadataClosureReport,
        longevity: LongevityBiologicalSystemsReport = LongevityBiologicalSystemsReport.empty()
    ): BiomedicalKnowledgeGraphLinkageReport {
        val selectedPartitions = (
            ontology.selectedDomains.map { it.lowercase(Locale.US) } +
                conceptBridge.selectedBridgeIds.map { "bridge:" + it.lowercase(Locale.US) } +
                modernTech.partitionIndexKeys.map { "technology:" + it.lowercase(Locale.US) } +
                viral.dictionaryPartitions.map { "viral:" + it.lowercase(Locale.US) } +
                longevity.fastRetrievalPartitions.map { "systems:" + it.lowercase(Locale.US) } +
                listOf("accession_index", "metadata_closure", "evidence_gates")
        ).distinct().take(24)
        val linkedLayers = listOfNotNull(
            "BiomedicalResearchOntology".takeIf { ontology.active },
            "BiomedicalConceptBridge".takeIf { conceptBridge.active },
            "ModernMedicalTechnologyIntelligence".takeIf { modernTech.active },
            "ViralCountermeasureIntelligence".takeIf { viral.active },
            "LongevityBiologicalSystemsGraph".takeIf { longevity.active },
            "MetadataClosureAgent".takeIf { metadataClosure.active }
        )
        val dictionaryUpdates = buildList {
            if (viral.selectedVirusKey != "none") add("viral profile indexed: ${viral.selectedVirusKey}")
            if (longevity.selectedModules.isNotEmpty()) add("biological systems modules indexed: ${longevity.selectedModules.take(6).joinToString(",")}")
            if (modernTech.selectedModuleIds.isNotEmpty()) add("technology modules indexed: ${modernTech.selectedModuleIds.take(4).joinToString(",")}")
            if (conceptBridge.selectedBridgeIds.isNotEmpty()) add("concept bridges indexed: ${conceptBridge.selectedBridgeIds.take(4).joinToString(",")}")
            if (ontology.selectedDomains.isNotEmpty()) add("ontology domains indexed: ${ontology.selectedDomains.take(4).joinToString(",")}")
            add("metadata gaps pinned: ${metadataClosure.missingFields.take(6).joinToString(",").ifBlank { "none" }}")
        }
        val bridgeEdges = (
            conceptBridge.selectedBridgeIds.map { "ontology->$it" } +
                modernTech.selectedModuleIds.map { "technology->$it" } +
                viral.targetPriorCards.map { "viral_target->${it.targetId}" } +
                viral.platformCards.map { "platform->${it.platformId}" } +
                longevity.exposurePathways.map { "exposure_pathway->${it.pathway}" } +
                longevity.graphEdges.map { "systems_edge->${it.fromNode}->${it.toNode}" }
        ).distinct().take(24)
        val retrievalKeys = (
            ontology.queryExpansionKeys + conceptBridge.priorityLookupTerms + modernTech.priorityLookupTerms + viral.priorityLookupTerms + longevity.datasetQueryTemplates + longevity.contradictionSearchTerms + metadataClosure.missingFields
        ).distinct().take(60)
        val unresolved = (metadataClosure.missingFields + viral.evidenceKeysToClose.filter { it.contains("control", true) || it.contains("time", true) || it.contains("accession", true) } + longevity.missingData).distinct().take(16)
        val state = when {
            viral.selectedVirusKey.startsWith("HANTAVIRUS") -> "KNOWLEDGE_GRAPH_LINKED_HANTAVIRUS_COUNTERMEASURE_ROUTE"
            viral.selectedVirusKey != "none" -> "KNOWLEDGE_GRAPH_LINKED_VIRAL_COUNTERMEASURE_ROUTE"
            longevity.active && longevity.selectedLane != "OFF" -> "KNOWLEDGE_GRAPH_LINKED_LONGEVITY_SYSTEMS_ROUTE"
            modernTech.selectedModuleIds.isNotEmpty() -> "KNOWLEDGE_GRAPH_LINKED_TECH_ONTOLOGY_ROUTE"
            else -> "KNOWLEDGE_GRAPH_BASELINE_INDEX_READY"
        }
        return BiomedicalKnowledgeGraphLinkageReport(
            active = true,
            state = state,
            selectedPartitions = selectedPartitions,
            linkedLayers = linkedLayers,
            dictionaryUpdateCards = dictionaryUpdates,
            bridgeEdges = bridgeEdges,
            retrievalIndexKeys = retrievalKeys,
            cachePolicy = "Load only selected partitions; keep heavy dictionary modules lazy and keyed by lead, route, and missing evidence fields.",
            updatePolicy = "Append or refresh dictionary links only when a lead, module, bridge, or evidence gap changes; never use dictionary entries as proof.",
            unresolvedGaps = unresolved,
            nextAction = "Use linked dictionary and biological-systems partitions to generate the next accession-specific lookup; run contradiction/null-result search before any link strengthening."
        )
    }
}


object NoWetlabProtocolGuard {
    const val CLAIM_LIMIT: String = ViralCountermeasureIntelligenceV11044.CLAIM_LIMIT
    val forbiddenOperationalRequests: List<String> = listOf(
        "wet-lab protocol",
        "viral engineering instruction",
        "pathogen enhancement instruction",
        "vaccine manufacturing recipe",
        "dose or treatment recommendation"
    )

    fun isSafeResearchRoutingOnly(text: String): Boolean = forbiddenOperationalRequests.none {
        text.contains(it, ignoreCase = true)
    }
}
