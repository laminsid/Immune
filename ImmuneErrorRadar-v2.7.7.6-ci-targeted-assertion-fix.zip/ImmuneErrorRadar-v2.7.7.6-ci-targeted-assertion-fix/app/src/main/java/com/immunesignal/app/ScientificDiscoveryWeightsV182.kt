package com.immunesignal.app

import java.util.Locale
import kotlin.math.max

/**
 * v1.8.2: weighted scientific discovery intelligence.
 *
 * This layer does not add biological claims. It turns the local scientific
 * term index and deep-discovery reasoning into an explicit decision-weight
 * surface so the next cycle knows what is important, what is a false friend,
 * and which evidence gap should dominate routing.
 */
data class ScientificDecisionWeightCard(
    val termId: String,
    val label: String,
    val matched: Boolean,
    val importance: Int,
    val evidenceGapScore: Int,
    val falseFriendRisk: Int,
    val routingWeight: Int,
    val action: String,
    val requiredEvidence: List<String>,
    val queryTerms: List<String>,
    val why: String
)

data class ScientificDiscoveryWeightReport(
    val active: Boolean,
    val version: String,
    val topWeights: List<ScientificDecisionWeightCard>,
    val prioritizedTerms: List<String>,
    val downgradedFalseFriends: List<String>,
    val decisiveEvidenceDelta: List<String>,
    val searchPriorityVector: List<String>,
    val riskGuards: List<String>,
    val learningReceipt: String,
    val summary: String,
    val claimLimit: String = "scientific_weighting_guides_routing_not_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryWeightReport(
            active = false,
            version = "v1.8.2",
            topWeights = emptyList(),
            prioritizedTerms = emptyList(),
            downgradedFalseFriends = emptyList(),
            decisiveEvidenceDelta = emptyList(),
            searchPriorityVector = emptyList(),
            riskGuards = emptyList(),
            learningReceipt = "No weighted scientific discovery decision was produced.",
            summary = "Scientific discovery weighting did not run.",
            claimLimit = "scientific_weighting_guides_routing_not_proof"
        )
    }
}

object ScientificDiscoveryWeightEngine {
    fun weigh(
        scientificIndex: ScientificKnowledgeIndexReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        causalReadinessReport: CausalReadinessReport,
        miniPeerReviewReport: MiniPeerReviewReport,
        datasetForagingReport: DatasetForagingReport,
        evidenceGainReport: EvidenceGainQueryRankerReport
    ): ScientificDiscoveryWeightReport {
        if (!scientificIndex.active && !deepDiscovery.active) return ScientificDiscoveryWeightReport.empty()

        val parsed = datasetForagingReport.parsedMetadata
        val missingEvidence = (
            causalReadinessReport.blockers +
                miniPeerReviewReport.missingEvidence +
                deepDiscovery.decisiveExperiment.requiredDatasetFeatures +
                scientificIndex.evidenceRequirements
            ).map { normalizeEvidenceKey(it) }.filter { it.isNotBlank() }.distinct()

        val hasOutcome = parsed.any { it.outcomeLabels.isNotEmpty() }
        val hasControl = parsed.any { it.controlLabels.isNotEmpty() } || datasetForagingReport.contrastiveReport.gateStatus.contains("PASS", true)
        val hasTime = parsed.any { it.timeCourseLabels.isNotEmpty() } || missingEvidence.any { it.contains("time") || it.contains("longitudinal") }
        val hasMetadata = parsed.isNotEmpty()
        val hasRouteFit = datasetForagingReport.routeFitAssessments.any { it.routeFitScore >= 70 }
        val deepText = listOf(
            deepDiscovery.nextDiscoveryMove,
            deepDiscovery.decisiveExperiment.nextQuery,
            deepDiscovery.contradictionPlan.strongestObjection,
            deepDiscovery.deepThinkSession.nextQuery,
            evidenceGainReport.chosenQuery
        ).joinToString(" ").lowercase(Locale.US)

        val weightCards = scientificIndex.matchedTerms.map { term ->
            val required = term.evidenceRequired.map { normalizeEvidenceKey(it) }.filter { it.isNotBlank() }
            val gapHits = required.count { req ->
                req in missingEvidence ||
                    (req.contains("outcome") && !hasOutcome) ||
                    ((req.contains("control") || req.contains("comparator")) && !hasControl) ||
                    ((req.contains("time") || req.contains("baseline") || req.contains("follow")) && !hasTime) ||
                    ((req.contains("metadata") || req.contains("sample") || req.contains("phenotype")) && !hasMetadata)
            }
            val evidenceGapScore = ((gapHits * 100) / max(1, required.size)).coerceIn(0, 100)
            val falseFriendRisk = falseFriendRisk(term, hasOutcome, hasControl, hasTime, hasMetadata, hasRouteFit)
            val deepMatchBonus = if ((term.aliases + term.label + term.termId).any { deepText.contains(it.lowercase(Locale.US)) }) 12 else 0
            val matchedBonus = if (term.matched) 18 else -6
            val hardGateBonus = if (term.importance >= 96 && evidenceGapScore >= 40) 16 else 0
            val routingWeight = (term.importance + matchedBonus + deepMatchBonus + hardGateBonus + evidenceGapScore / 3 - falseFriendRisk / 2)
                .coerceIn(0, 100)
            val action = when {
                falseFriendRisk >= 70 -> "DOWNGRADE_FALSE_FRIEND"
                !term.matched && term.importance >= 94 -> "ADD_FOUNDATION_CONTROL_TERM"
                evidenceGapScore >= 70 -> "CLOSE_DECISIVE_EVIDENCE_GAP"
                routingWeight >= 80 -> "PRIORITIZE_NEXT_CYCLE"
                term.matched -> "KEEP_AS_CONTEXT_PRIOR"
                else -> "MONITOR_ONLY"
            }
            ScientificDecisionWeightCard(
                termId = term.termId,
                label = term.label,
                matched = term.matched,
                importance = term.importance,
                evidenceGapScore = evidenceGapScore,
                falseFriendRisk = falseFriendRisk,
                routingWeight = routingWeight,
                action = action,
                requiredEvidence = required.take(8),
                queryTerms = buildQueryTerms(term, required, missingEvidence, action).take(12),
                why = "importance=${term.importance}; matched=${term.matched}; evidenceGap=$evidenceGapScore; falseFriend=$falseFriendRisk; action=$action"
            )
        }.sortedWith(compareByDescending<ScientificDecisionWeightCard> { it.routingWeight }.thenByDescending { it.evidenceGapScore })

        val prioritized = weightCards
            .filter { it.action in setOf("PRIORITIZE_NEXT_CYCLE", "CLOSE_DECISIVE_EVIDENCE_GAP", "ADD_FOUNDATION_CONTROL_TERM") }
            .map { it.termId }
            .distinct()
            .take(10)
        val downgraded = weightCards
            .filter { it.action == "DOWNGRADE_FALSE_FRIEND" }
            .map { "${it.termId}: ${it.why}" }
            .take(8)
        val decisiveDelta = buildDecisiveEvidenceDelta(weightCards, deepDiscovery, causalReadinessReport, miniPeerReviewReport)
        val searchVector = buildSearchPriorityVector(weightCards, decisiveDelta, deepDiscovery, evidenceGainReport)
        val guards = buildRiskGuards(weightCards, scientificIndex.falseFriendWarnings, causalReadinessReport, miniPeerReviewReport)
        val top = weightCards.take(12)
        val receipt = buildString {
            append("Weighted discovery: top=")
            append(top.firstOrNull()?.termId ?: "none")
            append("; decisive=")
            append(decisiveDelta.take(3).joinToString("/").ifBlank { "none" })
            append("; guards=")
            append(guards.take(2).joinToString(" | ").ifBlank { "none" })
        }.take(280)
        return ScientificDiscoveryWeightReport(
            active = true,
            version = "v1.8.2-weighted-discovery-intelligence",
            topWeights = top,
            prioritizedTerms = prioritized,
            downgradedFalseFriends = downgraded,
            decisiveEvidenceDelta = decisiveDelta.take(12),
            searchPriorityVector = searchVector.take(18),
            riskGuards = guards.take(12),
            learningReceipt = receipt,
            summary = "Scientific weighting v1.8.2: prioritized=${prioritized.take(4).joinToString(", ").ifBlank { "none" }}; false-friend downgrades=${downgraded.size}; search-vector=${searchVector.take(5).joinToString(" ")}",
            claimLimit = "scientific_weighting_guides_routing_not_proof"
        )
    }

    private fun falseFriendRisk(term: ScientificTermCard, hasOutcome: Boolean, hasControl: Boolean, hasTime: Boolean, hasMetadata: Boolean, hasRouteFit: Boolean): Int {
        var risk = 0
        val id = term.termId.lowercase(Locale.US)
        if (term.matched && !hasOutcome && id !in setOf("outcome_labels", "controls_comparators", "longitudinal_time_order")) risk += 28
        if (hasRouteFit && !hasMetadata) risk += 24
        if (id.contains("rna") && (!hasControl || !hasMetadata)) risk += 18
        if ((id.contains("allergy") || id.contains("type2")) && !hasControl) risk += 16
        if ((id.contains("causal") || id.contains("trained") || id.contains("interferon")) && !hasTime) risk += 18
        if (term.falseFriendWarnings.isNotEmpty() && (!hasOutcome || !hasControl)) risk += 12
        return risk.coerceIn(0, 100)
    }

    private fun buildQueryTerms(term: ScientificTermCard, required: List<String>, missing: List<String>, action: String): List<String> {
        val base = mutableListOf<String>()
        base += term.queryHints.flatMap { tokenizeForSearch(it) }
        base += term.label.split(Regex("[^A-Za-z0-9]+"))
        base += required.intersect(missing.toSet()).flatMap { evidenceToSearchTokens(it) }
        if (action == "DOWNGRADE_FALSE_FRIEND") base += listOf("negative control", "comparator", "contradiction", "confounder")
        return base.map { it.trim().lowercase(Locale.US) }
            .filter { it.length >= 3 }
            .distinct()
            .take(12)
    }

    private fun buildDecisiveEvidenceDelta(
        cards: List<ScientificDecisionWeightCard>,
        deepDiscovery: DeepDiscoveryReasoningReport,
        causalReadinessReport: CausalReadinessReport,
        miniPeerReviewReport: MiniPeerReviewReport
    ): List<String> {
        val delta = mutableListOf<String>()
        delta += cards.filter { it.evidenceGapScore >= 60 }.flatMap { it.requiredEvidence }
        delta += causalReadinessReport.blockers.map { normalizeEvidenceKey(it) }
        delta += miniPeerReviewReport.missingEvidence.map { normalizeEvidenceKey(it) }
        delta += deepDiscovery.decisiveExperiment.requiredDatasetFeatures.map { normalizeEvidenceKey(it) }
        if (deepDiscovery.contradictionPlan.strongestObjection.isNotBlank() && deepDiscovery.contradictionPlan.strongestObjection != "none") delta += "contradiction_or_negative_control"
        return delta.filter { it.isNotBlank() }.distinct().take(14)
    }

    private fun buildSearchPriorityVector(
        cards: List<ScientificDecisionWeightCard>,
        decisiveDelta: List<String>,
        deepDiscovery: DeepDiscoveryReasoningReport,
        evidenceGainReport: EvidenceGainQueryRankerReport
    ): List<String> {
        val terms = mutableListOf<String>()
        terms += cards.take(8).flatMap { it.queryTerms }
        terms += decisiveDelta.flatMap { evidenceToSearchTokens(it) }
        terms += tokenizeForSearch(deepDiscovery.decisiveExperiment.nextQuery)
        terms += tokenizeForSearch(deepDiscovery.deepThinkSession.nextQuery)
        terms += tokenizeForSearch(evidenceGainReport.chosenQuery)
        return terms.map { it.lowercase(Locale.US) }
            .filter { it.length >= 3 }
            .distinct()
            .take(24)
    }

    private fun buildRiskGuards(
        cards: List<ScientificDecisionWeightCard>,
        falseFriendWarnings: List<String>,
        causalReadinessReport: CausalReadinessReport,
        miniPeerReviewReport: MiniPeerReviewReport
    ): List<String> {
        val guards = mutableListOf<String>()
        guards += cards.filter { it.falseFriendRisk >= 60 }.map { "Do not let ${it.label} route without ${it.requiredEvidence.take(3).joinToString("/")}." }
        guards += falseFriendWarnings.take(6)
        if (!causalReadinessReport.causalLanguageAllowed) guards += "Block causal language until controlled-comparison threshold is reached."
        if (miniPeerReviewReport.verdict in setOf("HOLD", "REJECT")) guards += "Mini peer review is ${miniPeerReviewReport.verdict}; keep discovery in inspection mode."
        return guards.distinct().take(14)
    }

    private fun normalizeEvidenceKey(raw: String): String = raw
        .trim()
        .lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]+"), "_")
        .replace(Regex("_+"), "_")
        .trim('_')
        .let { key ->
            when {
                key.contains("outcome") || key.contains("severity") || key.contains("recovery") || key.contains("endpoint") -> "outcome_labels"
                key.contains("control") || key.contains("comparator") || key.contains("placebo") || key.contains("negative") -> "control_or_comparator"
                key.contains("time") || key.contains("longitudinal") || key.contains("follow") || key.contains("baseline") || key.contains("pre_post") -> "time_order"
                key.contains("metadata") || key.contains("phenotype") || key.contains("sample") || key.contains("license") -> "minimum_metadata"
                key.contains("cell") || key.contains("tissue") -> "tissue_cell_context"
                key.contains("batch") || key.contains("assay") -> "assay_batch_control"
                key.contains("human") || key.contains("patient") -> "human_or_patient_data"
                else -> key
            }
        }

    private fun evidenceToSearchTokens(key: String): List<String> = when (normalizeEvidenceKey(key)) {
        "outcome_labels" -> listOf("outcome", "severity", "recovery", "endpoint", "clinical resolution")
        "control_or_comparator" -> listOf("control", "comparator", "placebo", "healthy control", "negative control")
        "time_order" -> listOf("longitudinal", "time-course", "serial", "follow-up", "pre post")
        "minimum_metadata" -> listOf("metadata", "phenotype", "sample size", "GSE", "GEO", "SRA")
        "tissue_cell_context" -> listOf("cell type", "tissue", "single-cell", "composition")
        "assay_batch_control" -> listOf("assay", "batch effect", "technical artifact", "normalization")
        "human_or_patient_data" -> listOf("human", "patient", "clinical cohort")
        else -> tokenizeForSearch(key)
    }

    private fun tokenizeForSearch(text: String): List<String> = text
        .replace("RNA-seq", "rna-seq", ignoreCase = true)
        .replace("single cell", "single-cell", ignoreCase = true)
        .split(Regex("[^A-Za-z0-9_-]+"))
        .map { it.trim().lowercase(Locale.US) }
        .filter { it.length >= 3 }
        .filterNot { it in setOf("the", "and", "for", "with", "without", "only", "none", "unknown", "not") }
        .distinct()
        .take(18)
}
