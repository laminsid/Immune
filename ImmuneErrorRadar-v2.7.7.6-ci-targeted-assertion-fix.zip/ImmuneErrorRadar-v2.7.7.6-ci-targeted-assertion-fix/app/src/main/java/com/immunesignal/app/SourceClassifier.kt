package com.immunesignal.app

import java.util.Locale

object SourceClassifier {
    fun classifySource(text: String, pubTypes: List<String> = emptyList()): EvidenceAssessment {
        val combined = (text + " " + pubTypes.joinToString(" ")).lowercase(Locale.US)
        val studyDesign = classifyStudyDesign(combined)
        val speciesClass = classifySpecies(combined)
        // v0.9.1 fix: mixed_human_animal was falling through to "unknown_metadata"
        // and being penalised twice. Now mapped to its own class so the human
        // signal is preserved even when an animal model is referenced.
        val sourceClass = when {
            studyDesign.contains("systematic_review") || studyDesign.contains("meta_analysis") -> "synthesis"
            studyDesign.contains("randomized") || studyDesign.contains("trial") -> "clinical_intervention"
            studyDesign.contains("cohort") || studyDesign.contains("case_control") -> "human_observational"
            speciesClass == "human" -> "human_relevant"
            speciesClass == "mixed_human_animal" -> "human_relevant_with_animal_context"
            speciesClass == "animal" -> "animal_model"
            speciesClass == "cell_only" -> "cell_or_in_vitro"
            else -> "unknown_metadata"
        }
        // v0.9.1 fix: a "synthesis" (meta-analysis / systematic review) of human
        // studies was previously returning humanEvidence=false because the
        // sourceClass string did not start with "human". Most syntheses in PubMed
        // are clinical; we accept them unless species was explicitly animal/cell.
        val humanEvidence = speciesClass == "human"
            || sourceClass.startsWith("human")
            || sourceClass == "clinical_intervention"
            || sourceClass == "human_relevant_with_animal_context"
            || (sourceClass == "synthesis" && speciesClass != "animal" && speciesClass != "cell_only")
        val base = when (studyDesign) {
            "systematic_review_meta_analysis" -> 82
            "human_randomized_trial" -> 88
            "human_cohort" -> 74
            "human_case_control" -> 66
            "human_case_report_or_series" -> 48
            "animal_study" -> 38
            "cell_in_vitro" -> 30
            "mechanistic_review" -> 42
            else -> 35
        }
        val speciesPenalty = when (speciesClass) {
            "human" -> 0
            "mixed_human_animal" -> 8
            "animal" -> 22
            "cell_only" -> 28
            else -> 15
        }
        val limitations = mutableListOf<String>()
        if (speciesClass != "human") limitations += "Human applicability is not established by this source alone."
        if (studyDesign.contains("review")) limitations += "Review/synthesis can guide mechanisms but does not add a new primary observation."
        if (studyDesign == "unknown_design") limitations += "Study design could not be identified from metadata/title."
        return EvidenceAssessment(
            sourceClass = sourceClass,
            speciesClass = speciesClass,
            studyDesign = studyDesign,
            humanEvidence = humanEvidence,
            evidenceQualityScore = (base - speciesPenalty).coerceIn(5, 100),
            limitations = limitations.ifEmpty { listOf("No major metadata limitation detected from title/pubtype.") }
        )
    }

    fun classifySpecies(text: String): String {
        val t = text.lowercase(Locale.US)
        val animalTerms = listOf("mouse", "mice", "murine", "rat", "rats", "animal model", "zebrafish", "canine", "porcine")
        val cellTerms = listOf("in vitro", "cell line", "cultured", "pbmc", "organoid", "cellular model")
        val humanTerms = listOf("human", "humans", "patient", "patients", "cohort", "clinical", "volunteer", "adult", "children")
        val hasHuman = humanTerms.any { t.contains(it) }
        val hasAnimal = animalTerms.any { t.contains(it) }
        val hasCell = cellTerms.any { t.contains(it) }
        return when {
            hasHuman && hasAnimal -> "mixed_human_animal"
            hasHuman -> "human"
            hasAnimal -> "animal"
            hasCell -> "cell_only"
            else -> "unknown"
        }
    }

    fun classifyStudyDesign(text: String): String {
        val t = text.lowercase(Locale.US)
        return when {
            t.contains("meta-analysis") || t.contains("systematic review") -> "systematic_review_meta_analysis"
            t.contains("randomized") || t.contains("randomised") || t.contains("clinical trial") -> "human_randomized_trial"
            t.contains("cohort") || t.contains("longitudinal") || t.contains("prospective") -> "human_cohort"
            t.contains("case-control") || t.contains("case control") -> "human_case_control"
            t.contains("case report") || t.contains("case series") -> "human_case_report_or_series"
            t.contains("mouse") || t.contains("mice") || t.contains("murine") || t.contains("rat") -> "animal_study"
            t.contains("in vitro") || t.contains("cell line") || t.contains("cultured") -> "cell_in_vitro"
            t.contains("review") -> "mechanistic_review"
            else -> "unknown_design"
        }
    }
}
