package com.immunesignal.app

/**
 * v2.7.6.4 — Term-level Novel Signal Capture Layer, soft rejected-term tracking
 *
 * The ontology is a routing guard, not a closed-world ceiling. This layer now separates
 * prior-template rejection from term-level novelty. A rejected template must not cause
 * biologically useful terms (e.g. kynurenine, SCFA, LPS, endothelial, adipokine) to be
 * rejected as a block. Promotion remains locked behind accession + matrix readiness.
 */
enum class GTIMNovelSignalClassV2756 {
    KNOWN_PRIOR_MATCH,
    KNOWN_PRIOR_EXTENSION,
    OUT_OF_ONTOLOGY_LEAD,
    REJECTED_PRIOR_TEMPLATE
}

data class GTIMNovelTermSignalV2759(
    val term: String,
    val signalClass: GTIMNovelSignalClassV2756,
    val reason: String
)

data class GTIMOutOfOntologyLeadV2756(
    val signalClass: GTIMNovelSignalClassV2756,
    val leadId: String,
    val summary: String,
    val matchedKnownTerms: List<String>,
    val novelTerms: List<String>,
    val safeQuery: String,
    val promoteToCore: Boolean,
    val reason: String,
    val termSignals: List<GTIMNovelTermSignalV2759> = emptyList(),
    val rejectedPriorTemplateDetected: Boolean = false
)

object GTIMNovelSignalCaptureV2756 {
    const val VERSION: String = "2.7.6.4-term-level-novel-signal-soft-review"
    const val CLAIM_BOUNDARY: String = "NOVEL_SIGNAL_CAPTURE_NOT_EVIDENCE_NOT_DIAGNOSIS"

    fun capture(
        rawText: String,
        contract: GTIMRunDecisionContractV2740,
        matrixAudit: GTIMMatrixAuditCardReportV2745? = null,
        extraContext: List<String> = emptyList()
    ): GTIMOutOfOntologyLeadV2756 {
        val corpus = normalize((listOf(rawText) + extraContext + listOf(contract.rawQuery, contract.primaryAnchor.routeId)).joinToString(" "))
        val known = knownTermsFor(contract).filter { token -> token.isNotBlank() && corpus.contains(normalize(token)) }.distinct().take(12)
        val priorTemplate = looksLikeRejectedPriorTemplate(corpus, contract)

        val termSignals = detectedCandidateTerms(corpus).map { term ->
            GTIMNovelTermSignalV2759(term, classifyTerm(term, contract, corpus), termReason(term, contract, corpus))
        }.distinctBy { normalize(it.term) }

        val nonRejectedSignals = termSignals.filter { it.signalClass != GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE }
        val novel = nonRejectedSignals
            .filter { it.signalClass != GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH }
            .map { it.term }
            .distinct()
            .take(12)

        val hasExtension = nonRejectedSignals.any { it.signalClass == GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION }
        val hasOutOfOntology = nonRejectedSignals.any { it.signalClass == GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD }
        val hasValidAccession = matrixAudit?.targetId?.let { GTIMAccessionIdValidityGuardV2753.isFullAccession(it) } ?: false
        val matrixReady = matrixAudit?.let { it.matrixState == "DGE_READY" && it.accessionState == "DGE_READY" } ?: false

        val signalClass = when {
            hasExtension -> GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION
            hasOutOfOntology -> GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD
            priorTemplate -> GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE
            known.isNotEmpty() -> GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH
            else -> GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH
        }
        val leadId = when (signalClass) {
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH -> "known_prior_${contract.primaryAnchor.routeId}"
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION -> "term_level_known_prior_extension_${contract.primaryAnchor.routeId}"
            GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD -> "term_level_out_of_ontology_${contract.primaryAnchor.routeId}"
            GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE -> "rejected_prior_template_${contract.primaryAnchor.routeId}"
        }
        val promote = signalClass != GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE && hasValidAccession && matrixReady
        val safeQuery = safeNovelQuery(contract, novel, known)
        val summary = when (signalClass) {
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH -> "Novel signal: known-prior match only; ontology route protected and no new edge promoted."
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION -> "Novel signal: term-level known-prior extension candidate; reject stale template separately, track useful terms."
            GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD -> "Novel signal: term-level out-of-ontology lead captured; keep separate from known templates until accession/matrix support exists."
            GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE -> "Novel signal: rejected prior-template; no useful term-level extension passed the active contract."
        }
        val reason = when (signalClass) {
            GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE -> "Old template terms conflict with active contract ${contract.primaryAnchor.routeId}; no accepted term-level signal remained."
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION -> "At least one term-level signal extends the active ontology route; prior-template rejection does not reject accepted terms."
            GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD -> "At least one term-level signal is not covered by the current ontology route; preserve for review."
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH -> "Candidate remained inside current ontology/contract boundaries."
        }
        return GTIMOutOfOntologyLeadV2756(
            signalClass = signalClass,
            leadId = leadId,
            summary = summary,
            matchedKnownTerms = known,
            novelTerms = novel,
            safeQuery = safeQuery,
            promoteToCore = promote,
            reason = reason,
            termSignals = termSignals,
            rejectedPriorTemplateDetected = priorTemplate
        )
    }

    fun reportLine(lead: GTIMOutOfOntologyLeadV2756): String {
        val novel = if (lead.novelTerms.isEmpty()) "none" else lead.novelTerms.take(6).joinToString(", ")
        val termClasses = summarizeTermSignals(lead.termSignals)
        val rejectedTemplate = if (lead.rejectedPriorTemplateDetected) " | rejected_template_detected=true" else ""
        return "Novel signal capture: class=${lead.signalClass} | lead=${lead.leadId} | novel=$novel | term_classes=$termClasses | promote_to_core=${lead.promoteToCore}$rejectedTemplate | $CLAIM_BOUNDARY"
    }

    fun learningEdgeJsonl(lead: GTIMOutOfOntologyLeadV2756, contract: GTIMRunDecisionContractV2740): String {
        val novel = lead.novelTerms.take(8).joinToString(";")
        val termClasses = lead.termSignals.take(10).joinToString(";") { "${sanitizeJson(it.term)}:${it.signalClass}" }
        return "{\"anchor\":\"${contract.primaryAnchor.routeId}\",\"lead_id\":\"${lead.leadId}\",\"signal_class\":\"${lead.signalClass}\",\"novel_terms\":\"${sanitizeJson(novel)}\",\"term_signals\":\"${sanitizeJson(termClasses)}\",\"rejected_prior_template_detected\":${lead.rejectedPriorTemplateDetected},\"promote_to_core\":${lead.promoteToCore},\"claim_boundary\":\"$CLAIM_BOUNDARY\"}"
    }

    private fun knownTermsFor(contract: GTIMRunDecisionContractV2740): List<String> {
        val ontology = GTIMDiseaseSymptomOntologyBootstrapV2755.searchKeywordsFor(contract.primaryAnchor)
        val bridges = contract.discoveryBridges.map { it.routeId.replace('_', ' ') }
        val anchor = listOf(contract.primaryAnchor.routeId.replace('_', ' '), contract.benchmarkTopic ?: "")
        return (ontology + bridges + anchor).flatMap { splitUsefulTerms(it) }.distinct()
    }

    private fun detectedCandidateTerms(text: String): List<String> {
        val candidateTerms = listOf(
            "kynurenine", "tryptophan", "serotonin", "indole", "short chain fatty acid", "scfa", "butyrate",
            "bile acid", "lipopolysaccharide", "lps", "microglia", "vagus", "hpa", "cortisol", "sleep",
            "mitochondrial", "lactate", "oxidative stress", "barrier permeability", "zonulin", "th17", "il-17",
            "neutrophil", "endothelial", "vascular leakage", "adipokine", "leptin", "adiponectin", "androgen",
            "thyroid peroxidase", "tpo", "molecular mimicry", "candida", "fungal", "yeast", "metabolite"
        )
        return candidateTerms.filter { term -> text.contains(normalize(term)) }.distinct()
    }

    private fun classifyTerm(term: String, contract: GTIMRunDecisionContractV2740, corpus: String): GTIMNovelSignalClassV2756 {
        val norm = normalize(term)
        if (isTermForbidden(norm, contract, corpus)) return GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE
        if (isKnownPriorExtension(norm, contract)) return GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION
        val knownNorm = knownTermsFor(contract).map { normalize(it) }.toSet()
        if (knownNorm.any { known -> known == norm || known.contains(norm) || norm.contains(known) }) {
            return GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH
        }
        return GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD
    }

    private fun termReason(term: String, contract: GTIMRunDecisionContractV2740, corpus: String): String {
        val norm = normalize(term)
        return when (classifyTerm(term, contract, corpus)) {
            GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE -> "term kept as rejected/foreign review lead; not merged into active route ${contract.primaryAnchor.routeId}"
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION -> "term extends active route ${contract.primaryAnchor.routeId} without becoming evidence"
            GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD -> "term is outside current ontology route and should be tracked separately"
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH -> "term is already covered by active ontology route"
        }
    }

    private fun isKnownPriorExtension(term: String, contract: GTIMRunDecisionContractV2740): Boolean {
        val anchor = contract.primaryAnchor
        val microbiomeMood = setOf("kynurenine", "tryptophan", "serotonin", "indole", "short chain fatty acid", "scfa", "butyrate", "lipopolysaccharide", "lps", "microglia", "vagus", "hpa", "cortisol", "sleep", "barrier permeability", "zonulin")
        val viralFatigueVascular = setOf("endothelial", "vascular leakage", "hpa", "sleep", "mitochondrial", "lactate", "oxidative stress", "microglia")
        val metabolic = setOf("adipokine", "leptin", "adiponectin", "mitochondrial", "lactate", "oxidative stress", "bile acid", "lps", "lipopolysaccharide", "scfa", "butyrate")
        val type2Barrier = setOf("barrier permeability", "zonulin", "th17", "il-17", "neutrophil", "candida", "fungal", "yeast")
        val endocrineFungal = setOf("androgen", "thyroid peroxidase", "tpo", "molecular mimicry", "candida", "fungal", "yeast", "metabolite")
        val hemorrhagicViral = setOf("endothelial", "vascular leakage", "neutrophil", "th17", "il-17", "oxidative stress")
        return when (anchor) {
            GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION,
            GTIMPrimaryAnchorV2740.DEPRESSION_NEUROIMMUNE -> term in microbiomeMood
            GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL,
            GTIMPrimaryAnchorV2740.FATIGUE_SYNDROME_NEUROIMMUNE_METABOLIC,
            GTIMPrimaryAnchorV2740.INFLUENZA_RESPIRATORY_VIRAL -> term in viralFatigueVascular
            GTIMPrimaryAnchorV2740.DIABETES_METABOLIC_INFLAMMATION,
            GTIMPrimaryAnchorV2740.T2D_INSULIN_RESISTANCE_INFLAMMATION,
            GTIMPrimaryAnchorV2740.OBESITY_METABOLIC_INFLAMMATION,
            GTIMPrimaryAnchorV2740.NAFLD_LIVER_METABOLIC_INFLAMMATION -> term in metabolic
            GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL,
            GTIMPrimaryAnchorV2740.ASTHMA_TYPE2_AIRWAY -> term in type2Barrier
            GTIMPrimaryAnchorV2740.PCOS_REPRODUCTIVE_METABOLIC,
            GTIMPrimaryAnchorV2740.THYROID_HASHIMOTO_AUTOIMMUNE,
            GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE -> term in endocrineFungal
            GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL,
            GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL,
            GTIMPrimaryAnchorV2740.DENGUE_VECTOR_BORNE_VIRAL -> term in hemorrhagicViral
            else -> false
        }
    }

    private fun isTermForbidden(term: String, contract: GTIMRunDecisionContractV2740, corpus: String): Boolean {
        val fungalTerm = term in setOf("candida", "fungal", "yeast")
        // v2.7.6.2: the candidate text itself must not authorize a foreign disease domain.
        // Candida/fungal terms are allowed only when the run contract or explicit user query
        // requested a fungal/mycology comparison/route.
        val contractText = normalize(
            listOf(
                contract.rawQuery,
                contract.primaryAnchor.routeId,
                contract.allowedRoutes.joinToString(" "),
                contract.discoveryBridges.joinToString(" ") { it.routeId },
                contract.secondaryDomains.joinToString(" ")
            ).joinToString(" ")
        )
        val fungalAllowedByContract = contract.primaryAnchor == GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE ||
            contract.secondaryDomains.contains(GTIMDomainV2740.MYCOLOGY_YEAST_FUNGAL) ||
            listOf("candida", "fungal", "fungi", "yeast", "mycology", "mycos", "خمير", "فطر").any { contractText.contains(normalize(it)) }
        // v2.7.6.4: keep this as a rejected review lead, not a hard-delete.
        // The term remains visible in termSignals/learning JSON but is blocked from active-route promotion.
        if (fungalTerm && !fungalAllowedByContract && contract.primaryAnchor in setOf(
                GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL,
                GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL,
                GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL,
                GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION
            )) return true
        return false
    }

    private fun safeNovelQuery(contract: GTIMRunDecisionContractV2740, novel: List<String>, known: List<String>): String {
        val base = GTIMDownstreamContractAdaptersV2740.safeQuery(contract)
        val additions = (novel.take(5) + known.take(4)).filter { it.isNotBlank() }.distinct().joinToString(" ")
        return listOf(base, additions, "human cohort comparator accession GSE PRJNA PMID").joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }

    private fun looksLikeRejectedPriorTemplate(text: String, contract: GTIMRunDecisionContractV2740): Boolean {
        val latentVirus = (text.contains("ebv") || text.contains("hhv 6") || text.contains("hhv6")) &&
            (text.contains("sle") || text.contains("ms") || text.contains("me cfs") || text.contains("mecfs"))
        if (latentVirus && contract.primaryAnchor !in setOf(
                GTIMPrimaryAnchorV2740.SLE_SYSTEMIC_AUTOIMMUNE,
                GTIMPrimaryAnchorV2740.MS_NEUROIMMUNE_DEMYELINATION,
                GTIMPrimaryAnchorV2740.FATIGUE_SYNDROME_NEUROIMMUNE_METABOLIC
            )) return true
        if (text.contains("allergy") && contract.forbiddenConflations.any { it.contains("allergy") }) return true
        return false
    }

    private fun summarizeTermSignals(signals: List<GTIMNovelTermSignalV2759>): String {
        if (signals.isEmpty()) return "none"
        return signals
            .groupBy { it.signalClass }
            .entries
            .joinToString("; ") { (klass, terms) ->
                val termList = terms.take(4).joinToString("+") { it.term }
                "$klass:$termList"
            }
            .take(180)
    }

    private fun splitUsefulTerms(text: String): List<String> = normalize(text)
        .split(" ")
        .map { it.trim() }
        .filter { it.length >= 4 && it !in setOf("dataset", "human", "cohort", "comparator", "route", "axis", "with", "and") }

    private fun sanitizeJson(value: String): String = value.replace("\\", "\\\\").replace("\"", "\\\"")

    private fun normalize(value: String): String = value.lowercase()
        .replace('_', ' ')
        .replace('-', ' ')
        .replace('/', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()
}
