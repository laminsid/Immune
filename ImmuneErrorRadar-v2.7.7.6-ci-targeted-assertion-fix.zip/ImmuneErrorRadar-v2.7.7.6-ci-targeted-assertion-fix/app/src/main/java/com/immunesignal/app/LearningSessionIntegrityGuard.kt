package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.5.6: local checkpoint integrity guard.
 *
 * It makes paused/resumed learning sessions resilient to partial writes, older
 * schema checkpoints, and app restarts. It does not interpret biology and does
 * not create evidence; it only normalizes session bookkeeping.
 */
object LearningSessionIntegrityGuard {
    val expectedPhaseNames: List<String> = listOf(
        "FAILURE_ANALYSIS",
        "INTERACTION_DETECTION",
        "ROUTE_DISCOVERY",
        "BLIND_SPOT_FINDING"
    )

    fun normalize(session: LearningSession): LearningSession {
        val byName = session.phases.associateBy { it.phaseName }
        val normalizedPhases = expectedPhaseNames.map { name ->
            byName[name] ?: PhaseState(
                phaseName = name,
                status = PhaseStatus.PENDING,
                progress = 0,
                totalItems = 1
            )
        }
        val completed = normalizedPhases.filter { it.status == PhaseStatus.COMPLETED }.map { it.phaseName }
        val pending = expectedPhaseNames.filter { it !in completed }
        val normalizedCheckpoint = session.checkpoint.copy(
            lastPhaseCompleted = completed.lastOrNull() ?: session.checkpoint.lastPhaseCompleted,
            pendingPhases = pending,
            canResume = pending.isNotEmpty() && session.status != SessionStatus.COMPLETED,
            savedAt = if (session.checkpoint.savedAt > 0) session.checkpoint.savedAt else System.currentTimeMillis()
        )
        val normalizedStatus = when {
            pending.isEmpty() -> SessionStatus.COMPLETED
            // A persisted IN_PROGRESS session means the app/process stopped while it
            // was active. Resume must be explicit, so load as PAUSED.
            session.status == SessionStatus.IN_PROGRESS -> SessionStatus.PAUSED
            else -> session.status
        }
        return session.copy(
            status = normalizedStatus,
            timeLimit = session.timeLimit.takeIf { it > 0 } ?: RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS,
            phases = normalizedPhases,
            checkpoint = normalizedCheckpoint,
            claimLimits = session.claimLimits.ifEmpty {
                mapOf(
                    "failures" to "memory_only_not_biological_proof",
                    "interactions" to "pattern_hypothesis_not_discovery",
                    "routes" to "proposed_not_validated",
                    "blindSpots" to "research_guidance_not_proof"
                )
            }
        )
    }

    fun validationReport(session: LearningSession): JSONObject {
        val phaseNames = session.phases.map { it.phaseName }
        val missing = expectedPhaseNames.filter { it !in phaseNames }
        val duplicateCount = phaseNames.size - phaseNames.toSet().size
        val invalidProgress = session.phases.filter { it.progress !in 0..100 }.map { it.phaseName }
        return JSONObject().apply {
            put("schema", "learning_session_integrity_v1.5.6")
            put("claimLimit", "checkpoint_integrity_not_biological_proof")
            put("sessionId", session.sessionId)
            put("missingPhases", JSONArray(missing))
            put("duplicatePhaseCount", duplicateCount)
            put("invalidProgressPhases", JSONArray(invalidProgress))
            put("canResume", session.checkpoint.canResume)
            put("status", session.status.name)
            put("ok", missing.isEmpty() && duplicateCount == 0 && invalidProgress.isEmpty())
        }
    }
}
