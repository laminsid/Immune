package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.7.4.3 Blank-input Autonomous Discovery Mode.
 *
 * This mode runs only when the search box is empty. It does not replace user-topic
 * search. It selects one bounded, high-value relationship-discovery question from
 * a local priority list, then hands it to the same topic isolation and score gates.
 * It is a research-routing feature only: it may connect dots and create leads, but
 * it cannot make biological proof, diagnosis, treatment, or patient-level claims.
 */
data class AutonomousDiscoveryCandidateV2743(
    val id: String,
    val topic: String,
    val label: String,
    val basePriority: Int,
    val axes: List<String>,
    val requiredDots: List<String>,
    val nextEvidenceNeeded: String,
    val reason: String
)

data class AutonomousDiscoveryDecisionV2743(
    val active: Boolean,
    val state: String,
    val inputMode: String,
    val selectedTopic: String,
    val selectedCandidateId: String,
    val selectedLabel: String,
    val selectionScore: Int,
    val reason: String,
    val axes: List<String>,
    val requiredDots: List<String>,
    val nextEvidenceNeeded: String,
    val competingCandidates: List<String>,
    val blockedClaims: List<String>,
    val claimLimit: String = AutonomousDiscoveryModeV2743.CLAIM_LIMIT
)

object AutonomousDiscoveryModeV2743 {
    const val VERSION: String = "2.7.4.3-blank-input-autonomous-discovery-mode"
    const val CLAIM_LIMIT: String = "blank_input_autonomous_discovery_is_routing_only_not_biological_proof"

    private val blockedClaimList = listOf(
        "No mechanism, causality, diagnosis, treatment, dose, or patient-level prediction is proven.",
        "Autonomous topic choice is a local research-priority guess, not a scientific conclusion.",
        "Evidence upgrade still requires accession/comparator/assay/metadata/contradiction gates."
    )

    val candidates: List<AutonomousDiscoveryCandidateV2743> = listOf(
        AutonomousDiscoveryCandidateV2743(
            id = "microbiome_depression_kynurenine_il6",
            topic = "gut bacteria depression tryptophan kynurenine IL-6 TNF human cohort dataset",
            label = "Microbiome → molecule/metabolite → cytokine → depression phenotype",
            basePriority = 96,
            axes = listOf("microbiome", "neuroimmune", "tryptophan_kynurenine", "IL-6", "TNF", "human_cohort"),
            requiredDots = listOf("microbe/community feature", "tryptophan or kynurenine mediator", "IL-6/TNF/CRP immune mediator", "depression or mood outcome", "case-control or longitudinal comparator"),
            nextEvidenceNeeded = "Find human cohort or case-control dataset with microbiome/metabolite + inflammatory mediator + depression outcome metadata.",
            reason = "High relationship-discovery value and clear testable bridge; useful for comparing GTIM against normal PubMed search."
        ),
        AutonomousDiscoveryCandidateV2743(
            id = "long_covid_interferon_pbmc",
            topic = "Long COVID interferon PBMC transcriptome comparator GSE human dataset",
            label = "Long COVID → interferon/PBMC transcriptional persistence",
            basePriority = 93,
            axes = listOf("SARS-CoV-2", "Long_COVID", "interferon", "PBMC", "transcriptome", "comparator"),
            requiredDots = listOf("Long COVID phenotype", "PBMC or immune cell transcriptome", "interferon module", "recovered or healthy comparator", "GSE/PRJNA accession"),
            nextEvidenceNeeded = "Find public PBMC/RNA-seq/scRNA-seq accession with Long COVID comparator and interferon module metadata.",
            reason = "Strong benchmark topic; good test of whether the engine adds dataset and comparator routing beyond generic literature search."
        ),
        AutonomousDiscoveryCandidateV2743(
            id = "pesticide_gut_barrier_il6",
            topic = "pesticides gut barrier LPS IL-6 TNF CRP inflammation human dataset",
            label = "Pesticide exposure → gut barrier/LPS → inflammatory cytokines",
            basePriority = 90,
            axes = listOf("exposome", "gut_barrier", "LPS", "IL-6", "TNF", "CRP"),
            requiredDots = listOf("exposure signal", "barrier or endotoxin mediator", "cytokine marker", "immune/inflammatory phenotype", "exposed vs control comparator"),
            nextEvidenceNeeded = "Find exposure/comparator dataset or review with accession-like handles and immune mediator readout.",
            reason = "High bridge value for environment → microbiome/barrier → immune mediator routes, while still requiring strict comparator gates."
        ),
        AutonomousDiscoveryCandidateV2743(
            id = "longevity_inflammaging_immunosenescence",
            topic = "longevity immunosenescence inflammaging IL-6 CRP senescence human cohort dataset",
            label = "Longevity/aging → immunosenescence/inflammaging → cytokine phenotype",
            basePriority = 88,
            axes = listOf("longevity", "immunosenescence", "inflammaging", "IL-6", "CRP", "human_cohort"),
            requiredDots = listOf("age/longevity phenotype", "immune aging marker", "inflammatory mediator", "young/old or healthy aging comparator", "cohort or public dataset"),
            nextEvidenceNeeded = "Find cohort/dataset with aging phenotype, immune cell or cytokine measurements, and comparator metadata.",
            reason = "Important domain for immune-route discovery, but must avoid anti-aging claims without evidence objects."
        ),
        AutonomousDiscoveryCandidateV2743(
            id = "ebv_sle_interferon_bcell",
            topic = "EBV SLE interferon B cell transcriptome comparator GSE human dataset",
            label = "EBV → interferon/B-cell axis → SLE autoimmune phenotype",
            basePriority = 86,
            axes = listOf("EBV", "SLE", "interferon", "B_cell", "autoimmunity", "transcriptome"),
            requiredDots = listOf("EBV/latent virus signal", "SLE phenotype", "interferon or B-cell axis", "case-control comparator", "public accession"),
            nextEvidenceNeeded = "Find public transcriptome or immune-profiling dataset linking EBV context, SLE, and comparator metadata.",
            reason = "Good candidate for latent-virus immune-route discovery and contradiction checks."
        ),
        AutonomousDiscoveryCandidateV2743(
            id = "pfas_plastic_endocrine_immune",
            topic = "PFAS BPA phthalate microplastic endocrine immune inflammation human dataset",
            label = "Plastic/PFAS/BPA exposure → endocrine mediator → immune inflammation",
            basePriority = 84,
            axes = listOf("PFAS", "BPA", "phthalate", "endocrine", "immune_inflammation", "human_dataset"),
            requiredDots = listOf("exposure marker", "endocrine or barrier mediator", "immune mediator", "phenotype/outcome", "exposed vs control comparator"),
            nextEvidenceNeeded = "Find exposure-biomarker dataset with immune mediator and comparator labels; keep claims exploratory.",
            reason = "Useful exposome bridge, but must be prevented from contaminating unrelated user-topic runs."
        ),
        AutonomousDiscoveryCandidateV2743(
            id = "hantavirus_endothelial_interferon",
            topic = "Hantavirus endothelial immune response interferon cytokine human dataset comparator",
            label = "Hantavirus → endothelial/innate immune response → cytokine severity route",
            basePriority = 82,
            axes = listOf("Hantavirus", "endothelial", "interferon", "cytokine", "severity", "comparator"),
            requiredDots = listOf("viral trigger", "endothelial or innate immune mediator", "severity phenotype", "case-control or severity comparator", "PMID/GSE/PRJNA handle"),
            nextEvidenceNeeded = "Find human or translational dataset with severity/comparator metadata and cytokine/interferon readout.",
            reason = "Valuable stress-test for emerging viral immune-route discovery, but evidence may be sparse."
        )
    )

    fun resolve(
        rawInput: String,
        recentReports: List<String>,
        importedSignals: List<ImportedReportSignal> = emptyList(),
        importedRawTexts: List<String> = emptyList()
    ): AutonomousDiscoveryDecisionV2743 {
        val normalized = ImmuneTopicPromptPolicy.normalizeTopic(rawInput)
        if (normalized.isNotBlank()) {
            return AutonomousDiscoveryDecisionV2743(
                active = false,
                state = "USER_TOPIC_MODE",
                inputMode = "USER_TOPIC",
                selectedTopic = normalized,
                selectedCandidateId = "user_topic",
                selectedLabel = "User supplied topic",
                selectionScore = 100,
                reason = "User provided a topic; autonomous blank-input discovery is disabled for this run.",
                axes = emptyList(),
                requiredDots = emptyList(),
                nextEvidenceNeeded = "Use the user's topic-specific gates.",
                competingCandidates = emptyList(),
                blockedClaims = blockedClaimList
            )
        }

        val memory = (recentReports + importedRawTexts + importedSignals.map { it.title + " " + it.preview + " " + it.extractedKeywords.joinToString(" ") })
            .joinToString(" ")
            .lowercase(Locale.US)

        val scored = candidates.map { candidate ->
            val candidateTerms = (candidate.id.split('_') + candidate.axes + candidate.topic.split(Regex("[^A-Za-z0-9+-]+")))
                .map { it.lowercase(Locale.US).trim('+', '-') }
                .filter { it.length >= 4 }
                .distinct()
            val overlap = candidateTerms.count { memory.contains(it) }
            val exactRecentPenalty = if (memory.contains(candidate.id.lowercase(Locale.US)) || memory.contains(candidate.topic.lowercase(Locale.US).take(48))) 34 else 0
            val gapBoost = when {
                memory.contains("metadata_gap") || memory.contains("dge_not_ready") || memory.contains("route_unresolved") -> 7
                memory.contains("contradiction") || memory.contains("comparator") -> 4
                else -> 0
            }
            val underExploredBoost = if (overlap == 0) 10 else 0
            val bridgeBoost = if (candidate.requiredDots.any { dot -> !memory.contains(dot.lowercase(Locale.US).take(18)) }) 3 else 0
            val score = (candidate.basePriority + underExploredBoost + gapBoost + bridgeBoost - exactRecentPenalty - overlap.coerceAtMost(8)).coerceIn(1, 100)
            candidate to score
        }.sortedWith(compareByDescending<Pair<AutonomousDiscoveryCandidateV2743, Int>> { it.second }.thenByDescending { it.first.basePriority })

        val selected = scored.first().first
        val score = scored.first().second
        return AutonomousDiscoveryDecisionV2743(
            active = true,
            state = "AUTO_TOPIC_SELECTED_FROM_BLANK_INPUT",
            inputMode = "BLANK_INPUT_AUTONOMOUS_DISCOVERY",
            selectedTopic = selected.topic,
            selectedCandidateId = selected.id,
            selectedLabel = selected.label,
            selectionScore = score,
            reason = selected.reason,
            axes = selected.axes,
            requiredDots = selected.requiredDots,
            nextEvidenceNeeded = selected.nextEvidenceNeeded,
            competingCandidates = scored.drop(1).take(4).map { "${it.first.id}:${it.second}" },
            blockedClaims = blockedClaimList
        )
    }


    fun fromSnapshot(snapshot: ResearchTopicCaptureSnapshotV2740?): AutonomousDiscoveryDecisionV2743 {
        if (snapshot == null || !snapshot.autonomousDiscovery || snapshot.normalizedTopic.isBlank()) {
            return resolve(snapshot?.rawInput.orEmpty(), emptyList())
        }
        val candidate = candidates.firstOrNull { it.id == snapshot.autonomousCandidateId }
            ?: candidates.firstOrNull { it.topic.equals(snapshot.normalizedTopic, ignoreCase = true) }
        return if (candidate != null) {
            AutonomousDiscoveryDecisionV2743(
                active = true,
                state = "AUTO_TOPIC_FROM_RUNTIME_SNAPSHOT",
                inputMode = "BLANK_INPUT_AUTONOMOUS_DISCOVERY",
                selectedTopic = snapshot.normalizedTopic,
                selectedCandidateId = candidate.id,
                selectedLabel = candidate.label,
                selectionScore = candidate.basePriority,
                reason = candidate.reason,
                axes = candidate.axes,
                requiredDots = candidate.requiredDots,
                nextEvidenceNeeded = candidate.nextEvidenceNeeded,
                competingCandidates = candidates.filterNot { it.id == candidate.id }.take(4).map { it.id },
                blockedClaims = blockedClaimList
            )
        } else {
            AutonomousDiscoveryDecisionV2743(
                active = true,
                state = "AUTO_TOPIC_FROM_RUNTIME_SNAPSHOT_UNREGISTERED",
                inputMode = "BLANK_INPUT_AUTONOMOUS_DISCOVERY",
                selectedTopic = snapshot.normalizedTopic,
                selectedCandidateId = snapshot.autonomousCandidateId.ifBlank { "runtime_snapshot_auto_topic" },
                selectedLabel = "Runtime autonomous discovery topic",
                selectionScore = 70,
                reason = "Autonomous topic was already resolved before engine start; continue with same topic identity.",
                axes = snapshot.diseaseOrPhenotype + snapshot.triggerOrExposure + snapshot.pathwayOrMediator,
                requiredDots = listOf("topic-specific evidence", "comparator", "assay", "metadata", "contradiction check"),
                nextEvidenceNeeded = "Find source handles and close metadata/comparator gates.",
                competingCandidates = emptyList(),
                blockedClaims = blockedClaimList
            )
        }
    }

    fun autonomousQueries(decision: AutonomousDiscoveryDecisionV2743, maxQueries: Int = 3): List<ResearchQuery> {
        if (!decision.active || decision.selectedTopic.isBlank()) return emptyList()
        val base = listOf(
            decision.selectedTopic,
            decision.selectedTopic + " PMID DOI GSE PRJNA data availability comparator",
            decision.axes.take(6).joinToString(" ") + " " + decision.requiredDots.take(4).joinToString(" ") + " human dataset"
        )
        return base
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase(Locale.US) }
            .take(maxQueries)
            .mapIndexed { index, query ->
                ResearchQuery(
                    id = "q_v2743_autonomous_blank_${decision.selectedCandidateId}_$index".replace(Regex("[^A-Za-z0-9_]+"), "_"),
                    label = "v2.7.4.3 autonomous blank-input discovery: ${decision.selectedLabel}",
                    query = query,
                    reason = "Selected only because the user search box was blank. Required dots: ${decision.requiredDots.take(4).joinToString("; ")}. Claim limit: $CLAIM_LIMIT."
                )
            }
    }

    fun toJson(decision: AutonomousDiscoveryDecisionV2743): JSONObject = JSONObject()
        .put("active", decision.active)
        .put("version", VERSION)
        .put("state", decision.state)
        .put("inputMode", decision.inputMode)
        .put("selectedTopic", decision.selectedTopic)
        .put("selectedCandidateId", decision.selectedCandidateId)
        .put("selectedLabel", decision.selectedLabel)
        .put("selectionScore", decision.selectionScore)
        .put("reason", decision.reason)
        .put("axes", JSONArray(decision.axes))
        .put("requiredDots", JSONArray(decision.requiredDots))
        .put("nextEvidenceNeeded", decision.nextEvidenceNeeded)
        .put("competingCandidates", JSONArray(decision.competingCandidates))
        .put("blockedClaims", JSONArray(decision.blockedClaims))
        .put("claimLimit", decision.claimLimit)

    fun annotate(report: JSONObject, decision: AutonomousDiscoveryDecisionV2743): JSONObject {
        report.put("autonomousDiscoveryMode", toJson(decision))
        return report
    }

    fun uiStartText(decision: AutonomousDiscoveryDecisionV2743): String {
        return if (decision.active) {
            "Autonomous discovery started\n\n" +
                "• User query captured: AUTO — search box was blank\n" +
                "• Selected topic: ${decision.selectedTopic.take(180)}\n" +
                "• Why this topic: ${decision.reason.take(220)}\n" +
                "• Required dots: ${decision.requiredDots.take(4).joinToString(" → ")}\n" +
                "• Boundary: routing and lead discovery only; no medical or biological proof claim."
        } else {
            "Searching…\n\n" +
                "• User query captured: YES\n" +
                "• Topic: ${decision.selectedTopic.take(160)}\n" +
                "• Looking for useful immune research leads.\n" +
                "• If lookup fails, the app will save a recoverable debug report instead of closing."
        }
    }

    fun reportLine(decisionJson: JSONObject): String {
        if (!decisionJson.optBoolean("active", false)) return "Search mode: user-topic search"
        return "Search mode: autonomous discovery from blank input | selected=${decisionJson.optString("selectedCandidateId", "unknown")} | score=${decisionJson.optInt("selectionScore", 0)}/100"
    }
}
