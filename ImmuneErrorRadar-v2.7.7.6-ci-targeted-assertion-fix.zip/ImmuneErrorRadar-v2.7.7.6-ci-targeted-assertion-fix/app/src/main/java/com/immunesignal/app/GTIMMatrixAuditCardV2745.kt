package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.7.4.5 — Matrix Audit Card
 *
 * Purpose: keep the hard data-engineering audit separate from biological discovery.
 * The card explains what was captured, what matrix gate failed, and which metadata
 * fields block statistical/DGE readiness. It never upgrades a biological claim.
 */
data class GTIMMatrixAuditCardReportV2745(
    val active: Boolean,
    val targetId: String,
    val repository: String,
    val assayPlatform: String,
    val inspectedAbstractsCount: Int,
    val extractedDesignModel: String,
    val matrixState: String,
    val dgeReadinessScore: Int,
    val verifiedMetadataSlots: List<String>,
    val blockingGaps: List<String>,
    val nextDecisiveQuery: String,
    val claimLockStatus: String,
    val summaryLine: String,
    val accessionState: String = "NO_ACCESSION_ID_CAPTURED",
    val accessionBridgeStatus: String = "ACCESSION_CAPTURE_MISSING",
    val datasetObjectState: String = "ACCESSION_HANDLE_ONLY",
    val metadataTraitState: String = "ACCESSION_HANDLE_ONLY",
    val matrixReadinessState: String = "DGE_NOT_READY_NO_ACCESSION",
    val evidenceUpgradeState: String = "LOOKUP_HANDLE_ONLY",
    val datasetObjectSummary: String = "dataset object not resolved",
    val researchValueState: String = "RESEARCH_VALUE_NOT_ASSIGNED",
    val researchValueLine: String = "Research value: not assigned.",
    val dgeExecutionState: String = "DGE_EXECUTION_NOT_EVALUATED",
    val dgeExecutionBridgeLine: String = "DGE execution bridge: not evaluated.",
    val dgeExecutionNextLine: String = "DGE execution next: not evaluated.",
    val dgeExecutionBoundaryLine: String = "DGE bridge boundary: execution-readiness only; not biological proof."
)

object GTIMMatrixAuditCardV2745 {
    // compatibility audit token: 2.7.6.5-matrix-audit-card-research-value-layer
    const val VERSION: String = "2.7.7.0-matrix-audit-card-dge-execution-bridge"
    private const val CLAIM_LOCK = "HARD_DATA_EXTRACTION_UNMET_NO_FABRICATION"

    fun build(
        report: JSONObject,
        contract: GTIMRunDecisionContractV2740,
        fallbackSeedHandles: List<String> = emptyList(),
        paperUnderstandingSummary: String = ""
    ): GTIMMatrixAuditCardReportV2745 {
        val foragerRoot = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossier")
            ?: report.optJSONObject("mechanismDiscoveryDossierReport")
            ?: foragerRoot.optJSONObject("mechanismDiscoveryDossierReport")
            ?: JSONObject()
        val matrix = report.optJSONObject("metadataClosureStrategyMatrix")
            ?: report.optJSONObject("metadataClosureStrategyMatrixReport")
            ?: foragerRoot.optJSONObject("metadataClosureStrategyMatrixReport")
            ?: JSONObject()
        val accession = report.optJSONObject("accession")
            ?: foragerRoot.optJSONObject("accessionAcquisitionReport")
            ?: JSONObject()
        val gtim = (mechanism.optJSONObject("globalTranslationalDossier") ?: JSONObject())
        val accessionSeedCapture = gtim.optJSONObject("accessionSeedCapture") ?: JSONObject()

        val explicit = jsonArray(accession.optJSONArray("explicitAccessions"))
        val capturedSeeds = jsonArray(accessionSeedCapture.optJSONArray("capturedSeeds"))
        val paper = paperUnderstandingSummary
        val pipelineState = GTIMAccessionPipelineStateV2749.resolve(
            report = report,
            contract = contract,
            fallbackSeedHandles = listOf(accessionSeedCapture.optString("primarySeed")) + explicit + capturedSeeds + fallbackSeedHandles,
            paperUnderstandingSummary = paper
        )
        val targetCandidate = pipelineState.target
        val target = pipelineState.targetId
        val datasetResolution = GTIMDatasetObjectResolverV2761.resolve(
            report = report,
            contract = contract,
            pipeline = pipelineState,
            paperUnderstandingSummary = paper
        )
        val dgeExecutionBridge = GTIMDGEExecutionBridgeV2770.build(
            report = report,
            contract = contract,
            pipeline = pipelineState,
            datasetResolution = datasetResolution,
            paperUnderstandingSummary = paper
        )
        val initialAccessionState = when (datasetResolution.matrixDecision.state) {
            GTIMDatasetObjectStageV2761.DGE_READY -> "DGE_READY"
            GTIMDatasetObjectStageV2761.MATRIX_LINK_FOUND -> "ACCESSION_HANDLE_CAPTURED_METADATA_PARTIAL"
            GTIMDatasetObjectStageV2761.COMPARATOR_MAPPED -> "COMPARATOR_LABELS_MISSING_OR_AMBIGUOUS"
            GTIMDatasetObjectStageV2761.METADATA_TABLE_FOUND -> "METADATA_TRAITS_NOT_PARSED"
            GTIMDatasetObjectStageV2761.DATASET_OBJECT_RESOLVED -> "ACCESSION_HANDLE_CAPTURED_DATASET_OBJECT_NOT_RESOLVED"
            GTIMDatasetObjectStageV2761.ACCESSION_HANDLE_ONLY -> pipelineState.status.code
        }

        val rawMatrixState = firstNonBlank(
            if (datasetResolution.matrixDecision.matrixState != "DGE_NOT_READY_NO_ACCESSION") datasetResolution.matrixDecision.matrixState else "",
            mechanism.optString("matrixAnalysisGate"),
            matrix.optString("matrixState"),
            matrix.optString("state"),
            when (initialAccessionState) {
                "NO_ACCESSION_ID_CAPTURED" -> "DGE_NOT_READY_NO_ACCESSION"
                "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" -> "DGE_NOT_READY_NO_TOPIC_COMPATIBLE_ACCESSION"
                "ACCESSION_HANDLE_CAPTURED_DATASET_OBJECT_NOT_RESOLVED", "DATASET_OBJECT_RESOLUTION_PENDING" -> "DGE_NOT_READY_ACCESSION_HANDLE_ONLY"
                else -> "DGE_NOT_READY_METADATA_GAP"
            }
        )
        val inspected = firstInt(
            mechanism.optInt("inspectedAbstractsCount", -1),
            matrix.optInt("inspectedAbstractsCount", -1),
            regexInt(paper, "inspected=([0-9]+)")
        )
        val rawScore = firstInt(
            matrix.optInt("dgeReadinessScore", -1),
            matrix.optInt("score", -1),
            regexInt(paper, "score=([0-9]+)"),
            datasetResolution.matrixDecision.readinessScore,
            when (initialAccessionState) {
                "NO_ACCESSION_ID_CAPTURED" -> 25
                "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" -> 35
                "ACCESSION_HANDLE_CAPTURED_DATASET_OBJECT_NOT_RESOLVED", "DATASET_OBJECT_RESOLUTION_PENDING" -> 45
                else -> 55
            }
        ).coerceIn(0, 100)
        val consistency = GTIMMatrixStateConsistencyGuardV2750.normalize(
            accessionState = initialAccessionState,
            rawMatrixState = rawMatrixState,
            rawReadinessScore = rawScore
        )
        val accessionState = consistency.accessionState
        val matrixState = consistency.matrixState
        val score = consistency.readinessScore

        val design = firstNonBlank(
            matrix.optString("extractedDesignModel"),
            regexGroup(paper, "design=([^;|]+)"),
            regexGroup(paper, "model=([^;|]+)"),
            "not surfaced"
        )
        val repository = repositoryFor(target)
        val assay = assayFor(paper, matrix, contract)
        val verified = (datasetResolution.metadataAudit.verifiedSlots + verifiedSlots(paper, matrix, contract)).distinct().take(8)
        val gaps = (listOfNotNull(consistency.consistencyGap) + datasetResolution.metadataAudit.blockingGaps + blockingGaps(matrixState, paper, matrix, mechanism, target, accessionState)).distinct().take(8)
        val query = firstNonBlank(datasetResolution.matrixDecision.nextDecisiveAction, nextQuery(target, contract, gaps))
        val summary = "Matrix audit: target=$target | repository=$repository | assay=$assay | accession_state=$accessionState | object=${datasetResolution.datasetObject.sourceState.code} | metadata=${datasetResolution.metadataAudit.metadataState.code} | evidence_upgrade=${datasetResolution.matrixDecision.evidenceUpgradeState.code} | bridge=${pipelineState.bridgeStatus} | matrix=$matrixState | selector=${pipelineState.reason} | gaps=${gaps.take(3).joinToString(", ")}"

        return GTIMMatrixAuditCardReportV2745(
            active = true,
            targetId = target,
            repository = repository,
            assayPlatform = assay,
            inspectedAbstractsCount = inspected.coerceAtLeast(0),
            extractedDesignModel = design.trim(),
            matrixState = matrixState,
            dgeReadinessScore = score,
            verifiedMetadataSlots = verified,
            blockingGaps = gaps,
            nextDecisiveQuery = query,
            claimLockStatus = "$CLAIM_LOCK | No biological conclusion or cross-topic template allowed from matrix audit.",
            summaryLine = summary,
            accessionState = accessionState,
            accessionBridgeStatus = pipelineState.bridgeStatus,
            datasetObjectState = datasetResolution.datasetObject.sourceState.code,
            metadataTraitState = datasetResolution.metadataAudit.metadataState.code,
            matrixReadinessState = datasetResolution.matrixDecision.state.code,
            evidenceUpgradeState = datasetResolution.matrixDecision.evidenceUpgradeState.code,
            datasetObjectSummary = datasetResolution.summaryLine,
            researchValueState = datasetResolution.matrixDecision.researchValueState,
            researchValueLine = datasetResolution.matrixDecision.researchValueSummary,
            dgeExecutionState = dgeExecutionBridge.executionState,
            dgeExecutionBridgeLine = dgeExecutionBridge.summaryLine,
            dgeExecutionNextLine = GTIMDGEExecutionBridgeV2770.nextLine(dgeExecutionBridge),
            dgeExecutionBoundaryLine = dgeExecutionBridge.boundaryLine
        )
    }

    fun oneLine(card: GTIMMatrixAuditCardReportV2745): String {
        return "Matrix audit card: target=${card.targetId} | ${card.repository} | ${card.assayPlatform} | readiness=${card.dgeReadinessScore}/100 | accession_state=${card.accessionState} | object=${card.datasetObjectState} | metadata=${card.metadataTraitState} | matrix=${card.matrixState} | evidence_upgrade=${card.evidenceUpgradeState}"
    }

    fun gapLine(card: GTIMMatrixAuditCardReportV2745): String {
        return "Matrix blocking gaps: ${card.blockingGaps.take(5).joinToString("; ")}"
    }

    fun researchValueLine(card: GTIMMatrixAuditCardReportV2745): String {
        return card.researchValueLine
    }

    fun recoveryLine(card: GTIMMatrixAuditCardReportV2745): String {
        return "Matrix recovery query: ${card.nextDecisiveQuery} | upgrade_gate=${card.evidenceUpgradeState} | lock=${card.claimLockStatus}"
    }

    fun dgeExecutionBridgeLine(card: GTIMMatrixAuditCardReportV2745): String {
        return card.dgeExecutionBridgeLine
    }

    fun dgeExecutionNextLine(card: GTIMMatrixAuditCardReportV2745): String {
        return card.dgeExecutionNextLine
    }

    fun learningProgressLine(card: GTIMMatrixAuditCardReportV2745): String {
        val learned = when {
            card.researchValueState.contains("ACTIONABLE_SOFT_ANALYSIS_LEAD", ignoreCase = true) ->
                "dataset lead has assay/data-availability signal plus patient/cohort contrast"
            card.researchValueState.contains("COMPARATOR_REVIEW_LEAD", ignoreCase = true) ->
                "dataset lead has comparator signal that needs label review"
            card.researchValueState.contains("ASSAY_DATA_AVAILABILITY_LEAD", ignoreCase = true) ->
                "assay/data-availability signal surfaced but matrix file is unverified"
            card.researchValueState.contains("COHORT_CONTRAST_LEAD", ignoreCase = true) ->
                "patient/cohort contrast signal surfaced but comparator labels need standardization"
            card.targetId != "NO_ACCESSION_ID_CAPTURED" && card.targetId != "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" ->
                "accession handle captured and queued for metadata/matrix follow-up"
            else ->
                "topic route is open but needs a topic-compatible accession or dataset seed"
        }
        val next = when {
            card.blockingGaps.any { it.contains("RAW", ignoreCase = true) || it.contains("MATRIX", ignoreCase = true) } ->
                "fetch raw/count matrix or supplementary expression file"
            card.blockingGaps.any { it.contains("COMPARATOR", ignoreCase = true) } ->
                "standardize case/control or matched healthy comparator labels"
            card.blockingGaps.any { it.contains("TEMPORAL", ignoreCase = true) } ->
                "extract timepoint or longitudinal ordering"
            card.blockingGaps.any { it.contains("CELL", ignoreCase = true) || it.contains("TISSUE", ignoreCase = true) } ->
                "extract tissue/cell context from sample traits"
            else ->
                "run the matrix recovery query and inspect sample table"
        }
        return "Learning now: $learned | next_evidence=$next | boundary=not DGE-ready, not a claim."
    }

    private fun verifiedSlots(
        paper: String,
        matrix: JSONObject,
        contract: GTIMRunDecisionContractV2740
    ): List<String> {
        val combined = listOf(paper, matrix.toString(), contract.primaryAnchor.routeId).joinToString(" ").lowercase()
        val slots = mutableListOf<String>()
        if (containsAny(combined, "human", "patient", "pbmc", "blood", "airway", "single-cell", "single cell")) slots += "organism_or_model=human_or_patient_sample"
        if (containsAny(combined, "pbmc", "blood", "airway", "epithelial", "gut", "intestinal", "mucosal", "skin", "synovial")) slots += "tissue_context=surfaced_partial"
        slots += "condition_anchor=${contract.primaryAnchor.routeId}"
        if (containsAny(combined, "case control", "case-control", "control", "healthy", "comparator", "recovered", "baseline")) slots += "comparator_tokens=present_unverified"
        return slots.distinct().take(5)
    }


    private fun accessionStateFor(
        target: String,
        matrix: JSONObject,
        mechanism: JSONObject,
        paper: String
    ): String {
        if (target == "NO_ACCESSION_ID_CAPTURED") return "NO_ACCESSION_ID_CAPTURED"
        val combined = listOf(matrix.toString(), mechanism.toString(), paper).joinToString(" ").lowercase()
        val hasDatasetObject = containsAny(combined, "sample", "gsm", "metadata", "sample traits", "data_availability_text", "dataset=")
        val hasMatrixToken = containsAny(combined, "counts", "count matrix", "raw count", "expression matrix", "matrix file", "supplementary file")
        val hasComparator = containsAny(combined, "control", "healthy", "comparator", "case", "baseline", "recovered")
        return when {
            !hasDatasetObject -> "ACCESSION_HANDLE_CAPTURED_DATASET_OBJECT_NOT_RESOLVED"
            !hasComparator -> "METADATA_NOT_EXTRACTED"
            !hasMatrixToken -> "MATRIX_FILE_NOT_READY"
            else -> "ACCESSION_HANDLE_CAPTURED_METADATA_PARTIAL"
        }
    }

    private fun blockingGaps(
        matrixState: String,
        paper: String,
        matrix: JSONObject,
        mechanism: JSONObject,
        target: String,
        accessionState: String
    ): List<String> {
        val existing = jsonArray(matrix.optJSONArray("blockingGaps")) + jsonArray(mechanism.optJSONArray("blockingGaps"))
        val combined = listOf(paper, matrix.toString(), mechanism.toString()).joinToString(" ").lowercase()
        val gaps = mutableListOf<String>()
        when (accessionState) {
            "NO_ACCESSION_ID_CAPTURED" -> gaps += "NO_ACCESSION_ID_CAPTURED:: no accession handle was captured for matrix readiness."
            "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" -> gaps += "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED:: accession handles were captured, but none matched the active run contract strongly enough for matrix audit."
            "ACCESSION_HANDLE_CAPTURED_DATASET_OBJECT_NOT_RESOLVED", "DATASET_OBJECT_RESOLUTION_PENDING" -> gaps += "DATASET_OBJECT_NOT_RESOLVED:: accession handle captured, but the dataset object/sample table/matrix file is not resolved yet."
            "METADATA_TRAITS_NOT_PARSED", "METADATA_NOT_EXTRACTED" -> gaps += "METADATA_NOT_EXTRACTED:: accession handle exists, but sample trait metadata has not been parsed."
            "COMPARATOR_LABELS_MISSING_OR_AMBIGUOUS" -> gaps += "AMBIGUOUS_COMPARATOR:: accession handle exists, but case/control or matched healthy comparator labels are ambiguous."
            "MATRIX_FILE_NOT_READY" -> gaps += "MATRIX_FILE_NOT_READY:: accession handle exists, but raw/count expression matrix readiness is not verified."
            "ACCESSION_HANDLE_CAPTURED_METADATA_PARTIAL" -> gaps += "METADATA_PARTIAL:: accession handle exists and partial metadata surfaced, but DGE readiness is not closed."
            "SOFT_MATRIX_LEAD_REVIEW", "DGE_NOT_READY_SOFT_MATRIX_LEAD_REVIEW", "DGE_NOT_READY_SOFT_MATRIX_AND_COMPARATOR_LEAD_REVIEW" -> gaps += "SOFT_MATRIX_LEAD_REVIEW:: assay/data-availability signal surfaced; fetch raw/count matrix before DGE."
            "SOFT_COMPARATOR_LEAD_REVIEW", "DGE_NOT_READY_SOFT_COMPARATOR_LEAD_REVIEW" -> gaps += "SOFT_COMPARATOR_LEAD_REVIEW:: condition contrast surfaced; standardize comparator labels before DGE."
        }
        if (!containsAny(combined, "case control", "case-control", "control", "healthy", "comparator", "recovered", "baseline")) {
            gaps += "MISSING_COMPARATOR_LABELS:: case/control or matched healthy-control labels are not standardized in surfaced metadata."
        }
        if (!containsAny(combined, "day", "timepoint", "longitudinal", "baseline", "post-onset", "follow-up")) {
            gaps += "MISSING_TEMPORAL_ORDER:: longitudinal/timepoint ordering is not machine-checkable from surfaced metadata."
        }
        if (!containsAny(combined, "pbmc", "blood", "airway", "epithelial", "gut", "intestinal", "mucosal", "skin", "synovial", "cell")) {
            gaps += "MISSING_CELL_TISSUE_CONTEXT:: tissue/cell context is absent or not extractable from surfaced metadata."
        }
        if (!containsAny(combined, "counts", "count matrix", "raw count", "expression matrix", "single-cell", "single cell", "rna-seq", "rnaseq", "microarray")) {
            gaps += "MISSING_RAW_COUNT_MATRIX:: raw/count or normalized matrix availability is not verified."
        }
        if (existing.isNotEmpty()) gaps += existing.map { "SOURCE_REPORTED_GAP:: $it" }
        return gaps.distinct().take(6).ifEmpty { listOf("MATRIX_READINESS_UNVERIFIED:: no blocking gap text surfaced; manual metadata inspection required.") }
    }

    private fun nextQuery(target: String, contract: GTIMRunDecisionContractV2740, gaps: List<String>): String {
        val anchor = GTIMDownstreamContractAdaptersV2740.safeQuery(contract)
        val gapTerms = when {
            gaps.any { it.contains("COMPARATOR", true) } -> "healthy control comparator"
            gaps.any { it.contains("TEMPORAL", true) } -> "longitudinal timepoints days post onset"
            gaps.any { it.contains("RAW_COUNT", true) } -> "raw count matrix expression matrix"
            else -> "metadata sample traits comparator"
        }
        val idPart = if (target == "NO_ACCESSION_ID_CAPTURED" || target == "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED") "topic-compatible accession dataset" else target
        return "$idPart AND $gapTerms AND ${anchor.take(120)}"
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun assayFor(paper: String, matrix: JSONObject, contract: GTIMRunDecisionContractV2740): String {
        val combined = listOf(paper, matrix.toString(), contract.primaryAnchor.routeId).joinToString(" ").lowercase()
        return when {
            containsAny(combined, "single-cell", "single cell", "scrna", "scrna-seq") -> "Single-cell RNA-seq"
            containsAny(combined, "rna-seq", "rnaseq", "transcriptomic", "transcriptomics") -> "Transcriptomics / RNA-seq"
            containsAny(combined, "microarray", "array") -> "Microarray / expression profiling"
            containsAny(combined, "cytokine", "elisa", "il-6", "tnf") -> "Cytokine / immune-marker panel"
            else -> "assay not surfaced"
        }
    }

    private fun repositoryFor(target: String): String = when {
        target.startsWith("GSE", true) || target.startsWith("GDS", true) -> "GEO"
        target.startsWith("PRJNA", true) -> "BioProject/SRA"
        target.startsWith("SRP", true) || target.startsWith("SRR", true) -> "SRA"
        target.startsWith("E-MTAB", true) -> "ArrayExpress"
        target.startsWith("SDY", true) -> "ImmPort"
        target.startsWith("PMID", true) -> "PubMed"
        target.startsWith("DOI", true) -> "DOI resolver"
        else -> "repository not surfaced"
    }

    private fun jsonArray(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { idx ->
            val v = array.opt(idx) ?: return@mapNotNull null
            when (v) {
                is JSONObject -> listOf("accessionId", "id", "handle", "query", "label", "gap", "reason")
                    .firstNotNullOfOrNull { key -> v.optString(key).takeIf { it.isNotBlank() } } ?: v.toString()
                else -> v.toString()
            }
        }.filter { it.isNotBlank() }
    }

    private fun looksLikeAccession(value: String): Boolean = value.matches(Regex("(?i)^(GSE|GDS|PRJNA|SRP|SRR|E-MTAB-|SDY|PMID:|DOI:).+"))

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""

    private fun firstInt(vararg values: Int): Int = values.firstOrNull { it >= 0 } ?: 0

    private fun regexInt(text: String, pattern: String): Int {
        return Regex(pattern, RegexOption.IGNORE_CASE).find(text)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: -1
    }

    private fun regexGroup(text: String, pattern: String): String {
        return Regex(pattern, RegexOption.IGNORE_CASE).find(text)?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }

    private fun containsAny(text: String, vararg needles: String): Boolean = needles.any { text.contains(it, ignoreCase = true) }
}
