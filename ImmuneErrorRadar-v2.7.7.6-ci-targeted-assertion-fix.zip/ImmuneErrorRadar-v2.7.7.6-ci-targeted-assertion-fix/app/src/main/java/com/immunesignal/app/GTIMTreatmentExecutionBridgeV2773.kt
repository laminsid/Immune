package com.immunesignal.app

/**
 * v2.7.7.3 — Treatment Execution Bridge.
 *
 * This bridge connects the treatment knowledge layer to the existing DGE/matrix
 * execution readiness path. It does not recommend drugs, dosing, or clinical
 * actions. Its only job is to translate treatment-related reasoning into the
 * next dataset gates needed for review-only research: intervention labels,
 * response/resistance labels, comparator groups, safety context, and matrix /
 * sample-metadata linkage.
 */
data class GTIMTreatmentExecutionBridgeReportV2773(
    val active: Boolean,
    val state: String,
    val targetId: String,
    val lanes: List<String>,
    val translationalQuestionLine: String,
    val interventionDataGateLine: String,
    val resistanceEvidenceGateLine: String,
    val trialDatasetBridgeLine: String,
    val nextActionLine: String,
    val boundaryLine: String
) {
    companion object {
        fun empty(): GTIMTreatmentExecutionBridgeReportV2773 = GTIMTreatmentExecutionBridgeReportV2773(
            active = false,
            state = "NOT_EVALUATED",
            targetId = "NO_TARGET",
            lanes = emptyList(),
            translationalQuestionLine = "Treatment execution bridge: not evaluated.",
            interventionDataGateLine = "Treatment data gates: not evaluated.",
            resistanceEvidenceGateLine = "Resistance evidence gate: not evaluated.",
            trialDatasetBridgeLine = "Trial/dataset bridge: not evaluated.",
            nextActionLine = "Treatment execution next: not evaluated.",
            boundaryLine = "Treatment execution boundary: research routing only; not treatment advice."
        )
    }
}

object GTIMTreatmentExecutionBridgeV2773 {
    const val VERSION: String = "2.7.7.3-treatment-execution-bridge"
    const val CLAIM_LIMIT: String = "treatment_execution_routing_only_not_treatment_advice"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        treatment: GTIMTreatmentKnowledgeReportV2772,
        matrixAuditCard: GTIMMatrixAuditCardReportV2745
    ): GTIMTreatmentExecutionBridgeReportV2773 {
        if (!treatment.active) return GTIMTreatmentExecutionBridgeReportV2773.empty()

        val lanes = treatment.matchedLanes.distinct().take(5)
        val target = matrixAuditCard.targetId.ifBlank { "NO_TARGET" }
        val dgeState = matrixAuditCard.dgeExecutionState
        val hasTarget = target != "NO_TARGET" && !target.contains("NO_ACCESSION", ignoreCase = true)
        val hasMatrixBridge = dgeState.contains("BRIDGE_READY", ignoreCase = true) ||
            dgeState.contains("METADATA_ENGINEERING", ignoreCase = true) ||
            dgeState.contains("MATRIX_LOADED", ignoreCase = true) ||
            dgeState.contains("ACCESSION_LOOKUP", ignoreCase = true)
        val hasComparatorGap = matrixAuditCard.blockingGaps.any {
            it.contains("COMPARATOR", ignoreCase = true) || it.contains("LABEL", ignoreCase = true)
        }
        val hasMatrixGap = matrixAuditCard.blockingGaps.any {
            it.contains("MATRIX", ignoreCase = true) || it.contains("RAW", ignoreCase = true) || it.contains("COUNT", ignoreCase = true)
        }

        val state = when {
            hasTarget && hasMatrixBridge && lanes.any { it.contains("CLINICAL_TRIAL") } -> "TRIAL_TO_DATASET_EXECUTION_BRIDGE_REVIEW_ONLY"
            hasTarget && hasMatrixBridge && lanes.any { it.contains("RESISTANCE") || it.contains("ANTIBIOTIC") } -> "RESISTANCE_TO_DATASET_EXECUTION_BRIDGE_REVIEW_ONLY"
            hasTarget && hasMatrixBridge -> "TREATMENT_TO_DGE_EXECUTION_BRIDGE_REVIEW_ONLY"
            hasTarget -> "TREATMENT_CONTEXT_NEEDS_MATRIX_EXECUTION_REVIEW_ONLY"
            else -> "TREATMENT_CONTEXT_NEEDS_DATASET_TARGET_REVIEW_ONLY"
        }

        val interventionGate = interventionGateFor(lanes)
        val responseGate = responseGateFor(lanes)
        val safetyGate = safetyGateFor(lanes)
        val comparatorGate = if (hasComparatorGap) {
            "comparator labels must be standardized before intervention interpretation"
        } else {
            "comparator labels still require reviewer confirmation"
        }
        val matrixGate = if (hasMatrixGap) {
            "raw/count matrix or expression file must be fetched before DGE"
        } else {
            "matrix/sample linkage must remain review-only until verified"
        }

        val anchor = contract.primaryAnchor.routeId
        val translational = "Treatment execution bridge: state=$state | target=$target | anchor=$anchor | lanes=${lanes.joinToString(",")} | dge=${matrixAuditCard.dgeExecutionState} | claim=$CLAIM_LIMIT"
        val dataGates = "Treatment data gates: $interventionGate + immune target/biomarker + $comparatorGate + $matrixGate + safety/adverse-event context."
        val resistance = "Resistance evidence gate: $responseGate; do not infer resistance or response from pathway words alone."
        val trialBridge = "Trial/dataset bridge: NCT/PMID/trial terms are lookup handles; pair intervention arms with topic-compatible GSE/SRP/PRJNA/E-MTAB/SDY matrix and sample metadata before any DGE interpretation."
        val next = nextActionFor(state, target, lanes, comparatorGate, matrixGate, safetyGate)
        val boundary = "Treatment execution boundary: research routing only; no treatment advice, no dosing, no clinical management, no efficacy claim, no patient-specific decision."

        return GTIMTreatmentExecutionBridgeReportV2773(
            active = true,
            state = state,
            targetId = target,
            lanes = lanes,
            translationalQuestionLine = normalizeLine(translational),
            interventionDataGateLine = normalizeLine(dataGates),
            resistanceEvidenceGateLine = normalizeLine(resistance),
            trialDatasetBridgeLine = normalizeLine(trialBridge),
            nextActionLine = normalizeLine(next),
            boundaryLine = boundary
        )
    }

    fun compactLine(report: GTIMTreatmentExecutionBridgeReportV2773): String {
        return if (!report.active) {
            "Treatment execution bridge: NOT_EVALUATED | boundary=not treatment advice."
        } else {
            report.translationalQuestionLine
        }
    }

    private fun interventionGateFor(lanes: List<String>): String = when {
        lanes.any { it.contains("VACCINE") } -> "antigen/platform/strain-scope intervention label"
        lanes.any { it.contains("CLINICAL_TRIAL") } -> "trial intervention arm + comparator arm"
        lanes.any { it.contains("ANTIBIOTIC") || it.contains("ANTIMICROBIAL") } -> "pathogen species + antimicrobial class + resistance mechanism"
        lanes.any { it.contains("ANTI_ALLERGY") } -> "allergen/exposure + anti-allergy intervention class"
        lanes.any { it.contains("ONCO") } -> "cancer type + immunotherapy class + response marker"
        else -> "drug/class name + immune target/pathway"
    }

    private fun responseGateFor(lanes: List<String>): String = when {
        lanes.any { it.contains("ANTIBIOTIC") || it.contains("ANTIMICROBIAL") } -> "requires susceptibility/AST/MIC or resistant-vs-susceptible labels"
        lanes.any { it.contains("ONCO") } -> "requires responder/non-responder or immune-adverse-event labels"
        lanes.any { it.contains("VACCINE") } -> "requires neutralization, T-cell readout, breakthrough, escape, or waning labels"
        lanes.any { it.contains("ANTI_ALLERGY") } -> "requires symptom/biomarker endpoint and responder/non-responder or exposure timing labels"
        else -> "requires treated-vs-untreated, baseline/follow-up, responder/non-responder, or safety labels"
    }

    private fun safetyGateFor(lanes: List<String>): String = when {
        lanes.any { it.contains("VACCINE") } -> "reactogenicity/safety and escape/waning check"
        lanes.any { it.contains("ANTIBIOTIC") || it.contains("ANTIMICROBIAL") } -> "microbiome disruption, host immune state, and treatment-failure context"
        lanes.any { it.contains("ONCO") } -> "immune-related adverse-event and tumor microenvironment context"
        else -> "adverse-event/safety and contradiction context"
    }

    private fun nextActionFor(
        state: String,
        target: String,
        lanes: List<String>,
        comparatorGate: String,
        matrixGate: String,
        safetyGate: String
    ): String {
        val laneSummary = lanes.joinToString(",").ifBlank { "treatment_lane" }
        return when {
            state.contains("NEEDS_DATASET_TARGET") -> "Treatment execution next: find a topic-compatible dataset accession before linking $laneSummary to intervention evidence gates | boundary=review-only."
            state.contains("NEEDS_MATRIX") -> "Treatment execution next: $target -> locate raw/count matrix and sample metadata, then map $laneSummary to intervention/response/safety labels | boundary=review-only."
            else -> "Treatment execution next: $target -> standardize intervention, comparator, response/resistance, and safety labels; $comparatorGate; $matrixGate; $safetyGate | boundary=review-only."
        }
    }

    private fun normalizeLine(value: String): String = value
        .replace(Regex("\\s+"), " ")
        .trim()
}
