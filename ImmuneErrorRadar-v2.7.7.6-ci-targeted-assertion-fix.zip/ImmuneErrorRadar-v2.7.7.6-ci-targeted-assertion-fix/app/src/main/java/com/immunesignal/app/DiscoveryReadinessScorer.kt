package com.immunesignal.app

object DiscoveryReadinessScorer {
    fun score(
        evidenceObjects: List<EvidenceObject>,
        datasets: List<DatasetAccessionCandidate>,
        routeFits: List<DatasetRouteFitAssessment> = emptyList()
    ): DiscoveryReadinessReport {
        val blockers = mutableListOf<String>()
        val strengths = mutableListOf<String>()
        var score = 0
        val blockedAccessions = routeFits.filter { it.blocksHypothesisUpgrade }.map { it.accession }.toSet()
        val inRouteAccessions = routeFits.filter { !it.blocksHypothesisUpgrade }.map { it.accession }.toSet()
        val hasRouteFitData = routeFits.isNotEmpty()
        val usableDataset = datasets.any {
            it.accession != "DATASET_ACCESSION_UNRESOLVED" &&
                it.usabilityScore >= 60 &&
                (!hasRouteFitData || inRouteAccessions.contains(it.accession))
        }
        val routeBlocked = hasRouteFitData && datasets.isNotEmpty() && datasets.all { blockedAccessions.contains(it.accession) }
        val condition = datasets.any { it.conditionLabelsHint != "unknown" }
        val outcome = datasets.any { it.outcomeLabelsHint != "unknown" }
        val contradiction = evidenceObjects.any { it.contradictsHypothesis }
        val negative = evidenceObjects.any { it.hasNegativeControl }
        val human = datasets.any { it.organismHint.startsWith("human") } || evidenceObjects.any { it.reasons.any { r -> r.contains("human", true) } }
        val longitudinal = evidenceObjects.any { it.hasLongitudinalSignal } || datasets.any { it.timeCourseHint != "unknown" }
        val causalSafe = evidenceObjects.any { it.causalClaimSafe }

        if (usableDataset) { score += 25; strengths += "Usable in-route dataset accession candidate exists." } else blockers += "No usable in-route dataset accession candidate yet."
        if (condition) { score += 12; strengths += "Condition labels hinted." } else blockers += "Condition labels missing or unknown."
        if (outcome) { score += 18; strengths += "Outcome/response labels hinted." } else blockers += "Outcome/response labels missing."
        if (contradiction) { score += 10; strengths += "Contradiction/counter-evidence search produced signal." } else blockers += "Explicit contradiction search still missing."
        if (negative) { score += 10; strengths += "Negative/control signal present." } else blockers += "Negative/control evidence missing."
        if (human) { score += 10; strengths += "Human/patient/cohort signal present." } else blockers += "Human evidence not established."
        if (longitudinal) { score += 8; strengths += "Temporal/longitudinal signal present." } else blockers += "Temporal/longitudinal structure missing."
        if (causalSafe) { score += 7; strengths += "At least one evidence object has cautious causal support." } else blockers += "Causal claim remains unsafe."
        if (routeBlocked) {
            score = minOf(score, 40)
            blockers += "Route-fit gate blocks upgrade: current dataset is useful but off-route for the target hypothesis."
        }

        val state = when {
            routeBlocked -> "OFF_ROUTE_DATASET"
            score >= 75 -> "TESTABLE_LEAD"
            score >= 60 -> "CANDIDATE"
            else -> "OFF"
        }
        return DiscoveryReadinessReport(score.coerceIn(0, 100), state, blockers.distinct(), strengths.distinct())
    }
}
