package com.immunesignal.app

/**
 * v1.5.0: Question Evolver
 *
 * Generates research questions that evolve based on session type and history.
 * Questions change between FRESH_ANALYSIS and INCREMENTAL sessions.
 */

data class ResearchQuestion(
    val questionId: String,
    val text: String,
    val phase: String,
    val category: String,
    val importance: Int,  // 1-10
    val relatesTo: List<String> = emptyList()  // hypothesis IDs or routes
)

object QuestionEvolver {
    
    fun generateQuestions(
        sessionType: SessionType,
        previousResults: LearningInsights? = null
    ): List<ResearchQuestion> {
        return when (sessionType) {
            SessionType.FRESH_ANALYSIS -> generateFreshAnalysisQuestions()
            SessionType.INCREMENTAL -> generateIncrementalQuestions(previousResults)
            SessionType.RESUMED -> generateResumedQuestions(previousResults)
        }
    }
    
    private fun generateFreshAnalysisQuestions(): List<ResearchQuestion> {
        return listOf(
            // FAILURE_ANALYSIS questions
            ResearchQuestion(
                questionId = "qa_failure_patterns",
                text = "What failure patterns repeat in our evidence hunts?",
                phase = "FAILURE_ANALYSIS",
                category = "PATTERN_DETECTION",
                importance = 10
            ),
            ResearchQuestion(
                questionId = "qa_failure_routes",
                text = "Which routes fail most systematically?",
                phase = "FAILURE_ANALYSIS",
                category = "ROUTE_QUALITY",
                importance = 9
            ),
            ResearchQuestion(
                questionId = "qa_failure_clustering",
                text = "Do failures cluster by root cause, or are they scattered?",
                phase = "FAILURE_ANALYSIS",
                category = "STRUCTURE",
                importance = 8
            ),
            
            // INTERACTION_DETECTION questions
            ResearchQuestion(
                questionId = "qa_synergy",
                text = "Do any two hypotheses work better together than alone?",
                phase = "INTERACTION_DETECTION",
                category = "SYNERGY",
                importance = 9
            ),
            ResearchQuestion(
                questionId = "qa_mechanism",
                text = "If interactions exist, what biological mechanism could explain them?",
                phase = "INTERACTION_DETECTION",
                category = "BIOLOGY",
                importance = 8
            ),
            ResearchQuestion(
                questionId = "qa_antagonism",
                text = "Are there hypotheses that work worse together?",
                phase = "INTERACTION_DETECTION",
                category = "CONFLICT",
                importance = 7
            ),
            
            // ROUTE_DISCOVERY questions
            ResearchQuestion(
                questionId = "qa_new_routes",
                text = "Do failure patterns suggest routes we haven't identified?",
                phase = "ROUTE_DISCOVERY",
                category = "ROUTE_DISCOVERY",
                importance = 8
            ),
            ResearchQuestion(
                questionId = "qa_route_refinement",
                text = "Should existing routes be refined based on failure data?",
                phase = "ROUTE_DISCOVERY",
                category = "IMPROVEMENT",
                importance = 7
            ),
            
            // BLIND_SPOT_FINDING questions
            ResearchQuestion(
                questionId = "qa_bias",
                text = "Where is our system biased toward one pathway?",
                phase = "BLIND_SPOT_FINDING",
                category = "BIAS",
                importance = 9
            ),
            ResearchQuestion(
                questionId = "qa_data_quality",
                text = "Are correlations from data structure, not biology?",
                phase = "BLIND_SPOT_FINDING",
                category = "DATA_QUALITY",
                importance = 8
            ),
            ResearchQuestion(
                questionId = "qa_false_certainty",
                text = "What could fool our system that we're not aware of?",
                phase = "BLIND_SPOT_FINDING",
                category = "ROBUSTNESS",
                importance = 9
            )
        )
    }
    
    private fun generateIncrementalQuestions(
        previousResults: LearningInsights?
    ): List<ResearchQuestion> {
        return listOf(
            // Same data, evolved questions
            
            ResearchQuestion(
                questionId = "qa_pattern_change",
                text = "Have the failure patterns CHANGED since last analysis?",
                phase = "FAILURE_ANALYSIS",
                category = "DELTA",
                importance = 10,
                relatesTo = listOf("PREVIOUS_RESULTS")
            ),
            ResearchQuestion(
                questionId = "qa_old_clusters",
                text = "Do the OLD failure clusters still exist or have they been resolved?",
                phase = "FAILURE_ANALYSIS",
                category = "PROGRESSION",
                importance = 9
            ),
            
            ResearchQuestion(
                questionId = "qa_interaction_stability",
                text = "Are the PREVIOUS interactions still valid or have they changed?",
                phase = "INTERACTION_DETECTION",
                category = "STABILITY",
                importance = 8,
                relatesTo = listOf("PREVIOUS_INTERACTIONS")
            ),
            ResearchQuestion(
                questionId = "qa_new_interactions",
                text = "Are there NEW interactions we missed before?",
                phase = "INTERACTION_DETECTION",
                category = "NEW_DISCOVERY",
                importance = 8
            ),
            
            ResearchQuestion(
                questionId = "qa_route_viability",
                text = "Do PROPOSED routes from last session seem viable now?",
                phase = "ROUTE_DISCOVERY",
                category = "VALIDATION",
                importance = 7,
                relatesTo = listOf("PREVIOUS_PROPOSALS")
            ),
            
            ResearchQuestion(
                questionId = "qa_bias_change",
                text = "Are we MORE biased or LESS biased than before?",
                phase = "BLIND_SPOT_FINDING",
                category = "PROGRESS",
                importance = 8
            ),
            ResearchQuestion(
                questionId = "qa_new_blinds",
                text = "Does NEW DATA reveal NEW blind spots we didn't have before?",
                phase = "BLIND_SPOT_FINDING",
                category = "NEW_RISK",
                importance = 8
            )
        )
    }
    
    private fun generateResumedQuestions(
        previousResults: LearningInsights?
    ): List<ResearchQuestion> {
        // When resuming from paused checkpoint
        return generateIncrementalQuestions(previousResults)
    }
    
    fun generatePhaseSpecificContext(
        phaseName: String,
        sessionType: SessionType
    ): String {
        return when (phaseName) {
            "FAILURE_ANALYSIS" -> {
                when (sessionType) {
                    SessionType.FRESH_ANALYSIS ->
                        "Analyzing failure patterns from scratch. This establishes baseline understanding."
                    SessionType.INCREMENTAL ->
                        "Comparing NEW failure patterns with PREVIOUS baselines. Focus on deltas."
                    SessionType.RESUMED ->
                        "Continuing analysis from last checkpoint. Same context as before."
                }
            }
            
            "INTERACTION_DETECTION" -> {
                when (sessionType) {
                    SessionType.FRESH_ANALYSIS ->
                        "Discovering which hypotheses strengthen or weaken each other."
                    SessionType.INCREMENTAL ->
                        "Checking if new evidence changes hypothesis relationships."
                    SessionType.RESUMED ->
                        "Resuming interaction analysis from checkpoint."
                }
            }
            
            "ROUTE_DISCOVERY" -> {
                when (sessionType) {
                    SessionType.FRESH_ANALYSIS ->
                        "Looking for new biological routes based on failure patterns."
                    SessionType.INCREMENTAL ->
                        "Validating proposed routes against new data."
                    SessionType.RESUMED ->
                        "Continuing route discovery from checkpoint."
                }
            }
            
            "BLIND_SPOT_FINDING" -> {
                when (sessionType) {
                    SessionType.FRESH_ANALYSIS ->
                        "Identifying system biases and potential weaknesses."
                    SessionType.INCREMENTAL ->
                        "Checking if we've fixed old blind spots or created new ones."
                    SessionType.RESUMED ->
                        "Continuing blind spot analysis from checkpoint."
                }
            }
            
            else -> "Analyzing research data..."
        }
    }
    
    fun generateSummaryQuestions(
        session: LearningSession,
        insights: LearningInsights
    ): List<String> {
        return listOf(
            "What was the most important finding from this session?",
            "What should be prioritized in the next research cycle?",
            "Which insights are confident enough to guide next decisions?",
            "What uncertainties remain?"
        )
    }
}

// Helper class to track question history
class QuestionHistory {
    private val askedQuestions = mutableListOf<ResearchQuestion>()
    private val answers = mutableMapOf<String, String>()
    
    fun addQuestion(question: ResearchQuestion) {
        askedQuestions.add(question)
    }
    
    fun answerQuestion(questionId: String, answer: String) {
        answers[questionId] = answer
    }
    
    fun getQuestionsAskedBefore(): List<String> {
        return askedQuestions.map { it.questionId }
    }
    
    fun getNewQuestions(
        allQuestions: List<ResearchQuestion>
    ): List<ResearchQuestion> {
        val askedIds = getQuestionsAskedBefore()
        return allQuestions.filter { it.questionId !in askedIds }
    }
}
