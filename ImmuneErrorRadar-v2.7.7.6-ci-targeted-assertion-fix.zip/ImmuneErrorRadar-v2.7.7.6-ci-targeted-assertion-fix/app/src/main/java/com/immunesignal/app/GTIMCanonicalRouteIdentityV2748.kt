package com.immunesignal.app

/**
 * v2.7.4.8 — Canonical Route Identity
 *
 * A single route/bridge identity normalizer used by renderers, matrix audit,
 * relationship discovery, benchmark, and data-feed guards. It prevents bugs where
 * a route is allowed under one display id but suppressed under another alias.
 */
object GTIMCanonicalRouteIdentityV2748 {
    const val VERSION: String = "2.7.4.8-canonical-route-identity"

    private val aliases: Map<String, String> = mapOf(
        "covid interferon cytokine bridge" to "covid_interferon_cytokine_bridge",
        "covid interferon" to "covid_interferon_cytokine_bridge",
        "long covid interferon" to "covid_interferon_cytokine_bridge",
        "sars cov 2 interferon" to "covid_interferon_cytokine_bridge",
        "allergy type2 ige mast eosinophil" to "allergy_type2_ige_mast_eosinophil",
        "allergy type 2 ige mast eosinophil" to "allergy_type2_ige_mast_eosinophil",
        "allergy type2 ige mast cell bridge" to "allergy_type2_ige_mast_eosinophil",
        "allergy type 2 ige mast cell bridge" to "allergy_type2_ige_mast_eosinophil",
        "allergy type2 to barrier immunity" to "allergy_type2_to_barrier_immunity",
        "allergy microbiome barrier axis" to "allergy_microbiome_barrier_axis",
        "ebola hemorrhagic viral host response" to "ebola_hemorrhagic_viral_host_response",
        "hemorrhagic viral host response" to "hemorrhagic_viral_host_response",
        "hiv retroviral cd4 immune depletion" to "hiv_retroviral_cd4_immune_depletion",
        "retroviral cd4 immune depletion" to "retroviral_cd4_immune_depletion",
        "hantavirus zoonotic viral immune route" to "hantavirus_zoonotic_viral_immune_route",
        "gut microbiome to neuroinflammation" to "gut_microbiome_to_neuroinflammation",
        "microbiome depression il6 bridge" to "gut_microbiome_to_neuroinflammation",
        "microbiome depression il 6 bridge" to "gut_microbiome_to_neuroinflammation",
        "microbiome tryptophan serotonin pathway" to "microbiome_tryptophan_serotonin_pathway",
        "microbiome hpa axis stress response" to "microbiome_hpa_axis_stress_response",
        "fungal exposure to barrier dysbiosis" to "fungal_exposure_to_barrier_dysbiosis",
        "yeast fungal to endocrine immune" to "yeast_fungal_to_endocrine_immune",
        "ibd barrier mucosal inflammation axis" to "ibd_barrier_mucosal_inflammation_axis",
        "ibd barrier microbiome axis" to "ibd_barrier_microbiome_axis",
        "fatigue syndrome neuroimmune metabolic" to "fatigue_syndrome_neuroimmune_metabolic",
        "post viral fatigue axis" to "post_viral_fatigue_axis",
        "mitochondrial fatigue axis" to "mitochondrial_fatigue_axis",
        "hpa sleep stress axis" to "hpa_sleep_stress_axis",
        "inflammatory fatigue axis" to "inflammatory_fatigue_axis",
        "metabolic immune fatigue axis" to "metabolic_immune_fatigue_axis",
        "diabetes metabolic inflammation" to "diabetes_metabolic_inflammation_axis",
        "diabetes metabolic inflammation axis" to "diabetes_metabolic_inflammation_axis",
        "type2 diabetes insulin resistance" to "type2_diabetes_insulin_resistance_inflammation_axis",
        "type 2 diabetes insulin resistance" to "type2_diabetes_insulin_resistance_inflammation_axis",
        "insulin resistance inflammation" to "insulin_resistance_inflammation_axis",
        "gut microbiome metabolic axis" to "gut_microbiome_metabolic_axis",
        "adipose inflammation axis" to "adipose_inflammation_axis",
        "thyroid hashimoto autoimmune" to "thyroid_hashimoto_autoimmune_axis",
        "pcos reproductive metabolic" to "pcos_reproductive_metabolic_axis",
        "pcos metabolic hormonal" to "pcos_metabolic_hormonal_axis",
        "asthma type2 airway" to "asthma_type2_airway_inflammation_axis",
        "asthma type 2 airway" to "asthma_type2_airway_inflammation_axis",
        "influenza antiviral host response" to "influenza_antiviral_host_response_axis",
        "influenza host response" to "influenza_antiviral_host_response_axis",
        "flu antiviral" to "influenza_antiviral_host_response_axis",
        "dengue immune vascular" to "dengue_vector_borne_immune_vascular_axis",
        "dengue vascular immune" to "dengue_vector_borne_immune_vascular_axis",
        "tuberculosis macrophage granuloma" to "tuberculosis_macrophage_granuloma_axis",
        "tb granuloma" to "tuberculosis_macrophage_granuloma_axis",
        "sepsis systemic inflammatory response" to "sepsis_systemic_inflammatory_response_axis",
        "alzheimer neuroimmune" to "alzheimer_neuroimmune_inflammation_axis",
        "parkinson neuroimmune" to "parkinson_neuroimmune_axis",
        "obesity metabolic inflammation" to "obesity_metabolic_inflammation_axis",
        "nafld liver metabolic inflammation" to "nafld_liver_metabolic_inflammation_axis",
        "endometriosis reproductive inflammation" to "endometriosis_reproductive_inflammation_axis",
    )

    private val routeIds: Set<String> = buildSet {
        addAll(GTIMPrimaryAnchorV2740.values().map { it.routeId })
        addAll(GTIMDiscoveryBridgeV2740.values().map { it.routeId })
        addAll(aliases.values)
    }

    fun canonicalize(value: String): String {
        val n = normalize(value)
        if (n.isBlank()) return ""
        routeIds.firstOrNull { normalize(it) == n }?.let { return it }
        aliases[n]?.let { return it }
        aliases.entries.firstOrNull { (alias, _) -> n.contains(alias) }?.let { return it.value }
        routeIds.firstOrNull { n.contains(normalize(it)) }?.let { return it }
        return n.replace(' ', '_')
    }

    fun extractRouteIds(text: String): Set<String> {
        val n = normalize(text)
        if (n.isBlank()) return emptySet()
        val direct = routeIds.filter { n.contains(normalize(it)) }.toMutableSet()
        aliases.forEach { (alias, routeId) ->
            if (n.contains(alias)) direct += routeId
        }
        if (containsAny(n, "covid", "sars cov 2", "long covid", "pasc") && containsAny(n, "interferon", "ifn", "il 6", "tnf", "pbmc")) direct += "covid_interferon_cytokine_bridge"
        if (containsAny(n, "allergy", "allergies", "allergic", "hypersensitivity", "ige", "mast cell", "eosinophil")) direct += "allergy_type2_ige_mast_eosinophil"
        if (containsAny(n, "ebola", "evd", "filovirus") && containsAny(n, "host response", "hemorrhagic", "pbmc", "blood", "cytokine", "transcript")) direct += "ebola_hemorrhagic_viral_host_response"
        if (containsAny(n, "microbiome", "microbiota", "gut bacteria", "gut brain", "tryptophan", "kynurenine") && containsAny(n, "depression", "mood", "neuroinflammation", "il 6", "tnf", "crp")) direct += "gut_microbiome_to_neuroinflammation"
        if (containsAny(n, "fungi", "fungal", "yeast", "candida", "mycology") && containsAny(n, "barrier", "th17", "neutrophil", "dysbiosis", "allergy")) direct += "fungal_exposure_to_barrier_dysbiosis"
        if (containsAny(n, "fatigue", "chronic fatigue", "me cfs", "mecfs") && containsAny(n, "post viral", "mitochondrial", "hpa", "sleep", "inflammatory", "metabolic", "il 6", "tnf")) direct += "fatigue_syndrome_neuroimmune_metabolic"
        if (containsAny(n, "diabetes", "diabetic", "glucose", "insulin", "hba1c", "glycemic", "hyperglycemia")) direct += "diabetes_metabolic_inflammation_axis"
        if (containsAny(n, "hashimoto", "thyroid", "thyroiditis", "hypothyroid")) direct += "thyroid_hashimoto_autoimmune_axis"
        if (containsAny(n, "pcos", "polycystic")) direct += "pcos_reproductive_metabolic_axis"
        if (containsAny(n, "asthma", "asthmatic", "airway hyperresponsiveness", "wheeze")) direct += "asthma_type2_airway_inflammation_axis"
        if (containsAny(n, "influenza", "flu", "h1n1", "h3n2")) direct += "influenza_antiviral_host_response_axis"
        if (containsAny(n, "dengue", "denv")) direct += "dengue_vector_borne_immune_vascular_axis"
        if (containsAny(n, "tuberculosis", "tb", "mycobacterium")) direct += "tuberculosis_macrophage_granuloma_axis"
        if (containsAny(n, "sepsis", "septic shock")) direct += "sepsis_systemic_inflammatory_response_axis"
        if (containsAny(n, "alzheimer", "dementia")) direct += "alzheimer_neuroimmune_inflammation_axis"
        if (containsAny(n, "parkinson")) direct += "parkinson_neuroimmune_axis"
        if (containsAny(n, "obesity", "obese")) direct += "obesity_metabolic_inflammation_axis"
        if (containsAny(n, "nafld", "fatty liver")) direct += "nafld_liver_metabolic_inflammation_axis"
        if (containsAny(n, "endometriosis")) direct += "endometriosis_reproductive_inflammation_axis"
        return direct.map { canonicalize(it) }.filter { it.isNotBlank() }.toSet()
    }

    fun isAllowedRouteText(text: String, contract: GTIMRunDecisionContractV2740): Boolean {
        val ids = extractRouteIds(text)
        if (ids.isEmpty()) return true
        return ids.all { contract.canUseRoute(it) || contract.allowedRoutes.contains(canonicalize(it)) }
    }

    fun isAnchorCompatibleText(text: String, contract: GTIMRunDecisionContractV2740): Boolean {
        val ids = extractRouteIds(text)
        if (ids.any { contract.canUseRoute(it) }) return true
        val n = normalize(text)
        val anchor = contract.primaryAnchor
        return when (anchor) {
            GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> containsAny(n, "covid", "sars cov 2", "long covid", "pasc", "interferon")
            GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> containsAny(n, "allergy", "allergies", "allergic", "hypersensitivity", "ige", "mast cell", "eosinophil")
            GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> containsAny(n, "ebola", "evd", "hemorrhagic", "filovirus")
            GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> containsAny(n, "microbiome", "gut bacteria", "tryptophan", "kynurenine", "depression", "mood")
            GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE -> containsAny(n, "ibd", "crohn", "colitis", "mucosal", "intestinal barrier")
            GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> containsAny(n, "hanta", "hantavirus", "hfrs", "hcps", "zoonotic")
            GTIMPrimaryAnchorV2740.FATIGUE_SYNDROME_NEUROIMMUNE_METABOLIC -> containsAny(n, "fatigue", "post viral", "mitochondrial", "hpa", "sleep", "inflammatory", "metabolic", "me cfs", "mecfs")
            GTIMPrimaryAnchorV2740.DIABETES_METABOLIC_INFLAMMATION,
            GTIMPrimaryAnchorV2740.T2D_INSULIN_RESISTANCE_INFLAMMATION -> containsAny(n, "diabetes", "diabetic", "glucose", "insulin", "hba1c", "glycemic", "hyperglycemia", "metabolic inflammation")
            GTIMPrimaryAnchorV2740.THYROID_HASHIMOTO_AUTOIMMUNE -> containsAny(n, "hashimoto", "thyroid", "thyroiditis", "hypothyroid", "tpo", "thyroglobulin")
            GTIMPrimaryAnchorV2740.PCOS_REPRODUCTIVE_METABOLIC -> containsAny(n, "pcos", "polycystic", "androgen", "ovary", "reproductive", "insulin resistance")
            GTIMPrimaryAnchorV2740.ASTHMA_TYPE2_AIRWAY -> containsAny(n, "asthma", "asthmatic", "airway", "wheeze", "type 2", "il 4", "il 5", "il 13")
            GTIMPrimaryAnchorV2740.INFLUENZA_RESPIRATORY_VIRAL -> containsAny(n, "influenza", "flu", "h1n1", "h3n2", "antiviral", "interferon", "respiratory")
            GTIMPrimaryAnchorV2740.DENGUE_VECTOR_BORNE_VIRAL -> containsAny(n, "dengue", "denv", "vascular", "thrombocytopenia", "fever")
            GTIMPrimaryAnchorV2740.TUBERCULOSIS_GRANULOMATOUS_IMMUNE -> containsAny(n, "tuberculosis", "tb", "mycobacterium", "granuloma", "macrophage")
            GTIMPrimaryAnchorV2740.SEPSIS_SYSTEMIC_INFLAMMATION -> containsAny(n, "sepsis", "septic", "systemic inflammation", "shock", "immune paralysis")
            GTIMPrimaryAnchorV2740.ALZHEIMER_NEUROIMMUNE -> containsAny(n, "alzheimer", "dementia", "microglia", "neuroinflammation")
            GTIMPrimaryAnchorV2740.PARKINSON_NEUROIMMUNE -> containsAny(n, "parkinson", "neuroinflammation", "microglia")
            GTIMPrimaryAnchorV2740.OBESITY_METABOLIC_INFLAMMATION -> containsAny(n, "obesity", "obese", "adipose", "metabolic inflammation")
            GTIMPrimaryAnchorV2740.NAFLD_LIVER_METABOLIC_INFLAMMATION -> containsAny(n, "nafld", "fatty liver", "liver inflammation")
            GTIMPrimaryAnchorV2740.ENDOMETRIOSIS_REPRODUCTIVE_INFLAMMATION -> containsAny(n, "endometriosis", "reproductive inflammation")
            else -> n.contains(normalize(anchor.routeId))
        }
    }

    fun normalize(value: String): String = value.lowercase()
        .replace('→', ' ')
        .replace('↔', ' ')
        .replace("/", " ")
        .replace("_", " ")
        .replace("-", " ")
        .replace(Regex("[^a-z0-9α-ωΑ-Ω]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun containsAny(text: String, vararg needles: String): Boolean = needles.any { text.contains(it) }
}
