package com.immunesignal.app

import java.util.Locale

object ScoreFormat {
    fun oneDecimal(value: Double): String = String.format(Locale.US, "%.1f", value)
}
