package com.immunesignal.app

import java.util.Locale

/**
 * v1.3.3 hard lock.
 *
 * This release improves autonomous research behavior only. It must not expand
 * biology scope, introduce health/diagnostic claims, or add ML models.
 */
data class ScopeDisciplineResult(
    val passed: Boolean,
    val violations: List<String>
)

object ScopeDisciplineLock {
    private val forbiddenPhrases = listOf(
        "diagnosis",
        "diagnostic",
        "treatment",
        "therapy recommendation",
        "medical advice",
        "symptom tracker",
        "personal health score",
        "random forest",
        "deep learning",
        "new disease module",
        "new immune axis",
        "new biology axis",
        "new axis pair",
        "patient prediction"
    )

    fun validatePlannedText(text: String): ScopeDisciplineResult {
        val lower = text.lowercase(Locale.US)
        val violations = forbiddenPhrases.filter { lower.contains(it) }
        return ScopeDisciplineResult(violations.isEmpty(), violations)
    }

    fun sanitizePivot(pivot: PivotDecision): PivotDecision {
        val text = listOf(pivot.pivotType, pivot.reason, pivot.nextIntent, pivot.nextQuerySeed).joinToString(" ")
        val result = validatePlannedText(text)
        if (result.passed) return pivot
        return PivotDecision(
            pivotType = "SCOPE_SAFE_VOCABULARY_ROTATION",
            reason = "Scope lock removed expansion wording. Rotate query vocabulary and evidence lane without adding biology axes.",
            nextIntent = "evidence_lane_rotation",
            nextQuerySeed = "immune response dataset contradiction negative control longitudinal outcome",
            priority = pivot.priority.coerceAtLeast(72)
        )
    }
}
