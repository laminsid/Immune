package com.immunesignal.app

import java.util.Locale

/**
 * v1.8.8: latent discovery gap miner. Token: latent_discovery_gap_miner.
 *
 * Previous v1.8 layers chose, stress-tested, enforced, verified, and traced a
 * discovery route. This layer looks for high-value unasked probes: dormant
 * hypotheses that should stay buried unless a new evidence key appears,
 * cross-axis bridge questions not yet tested, and white-space gaps where the
 * current lineage suggests a narrow falsifiable probe. It is a routing layer
 * only: no biological proof, diagnosis, treatment, or causal claim is created.
 */
data class LatentDiscoveryOpportunityCard(
    val opportunityId: String,
    val label: String,
    val opportunityType: String,
    val priority: Int,
    val whyItMatters: String,
    val missingEvidence: List<String>,
    val probeQuery: String,
    val promoteIf: List<String>,
    val killIf: List<String>,
    val linkedLineage: String
)

data class ScientificDiscoveryGapMinerReport(
    val active: Boolean,
    val version: String,
    val minerState: String,
    val opportunityScore: Int,
    val topOpportunity: String,
    val latentOpportunities: List<LatentDiscoveryOpportunityCard>,
    val dormantHypotheses: List<String>,
    val unaskedBridgeQuestions: List<String>,
    val missingButHighValueEvidence: List<String>,
    val blockedBy: List<String>,
    val forcedDirectiveTerms: List<String>,
    val forcedEvidenceKeys: List<String>,
    val nextDiscoveryProbe: String,
    val reportLine: String,
    val claimLimit: String = "latent_discovery_gap_miner_guides_routing_not_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryGapMinerReport(
            active = false,
            version = "v1.8.8",
            minerState = "NOT_RUN",
            opportunityScore = 0,
            topOpportunity = "none",
            latentOpportunities = emptyList(),
            dormantHypotheses = emptyList(),
            unaskedBridgeQuestions = emptyList(),
            missingButHighValueEvidence = emptyList(),
            blockedBy = emptyList(),
            forcedDirectiveTerms = emptyList(),
            forcedEvidenceKeys = emptyList(),
            nextDiscoveryProbe = "Run a cycle with lineage and outcome verification before mining latent gaps.",
            reportLine = "Latent discovery gap miner did not run.",
            claimLimit = "latent_discovery_gap_miner_guides_routing_not_proof"
        )
    }
}

object ScientificDiscoveryGapMinerEngineV188 {
    fun mine(
        knowledgeIndex: ScientificKnowledgeIndexReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        decisionMemory: ScientificDiscoveryDecisionReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport,
        lineage: ScientificDiscoveryLineageReport,
        datasetForaging: DatasetForagingReport,
        knowledgeMap: KnowledgeMapReport,
        epistemicBelief: EpistemicBeliefReport
    ): ScientificDiscoveryGapMinerReport {
        if (!knowledgeIndex.active && !deepDiscovery.active && !lineage.active && !outcomeVerifier.active) {
            return ScientificDiscoveryGapMinerReport.empty()
        }

        val baseEvidenceGaps = normalizeEvidence(
            outcomeVerifier.unmetEvidenceKeys +
                scientificWeights.decisiveEvidenceDelta +
                lineage.forcedEvidenceKeys +
                knowledgeMap.gaps.flatMap { listOf(it.gapId, it.nextAction) } +
                datasetForaging.scoreSeparation.reasons
        ).take(18)

        val dormant = buildDormantHypotheses(epistemicBelief, lineage).take(10)
        val unasked = buildUnaskedBridgeQuestions(deepDiscovery, knowledgeIndex, lineage, baseEvidenceGaps).take(10)
        val opportunities = buildOpportunities(
            baseEvidenceGaps = baseEvidenceGaps,
            dormant = dormant,
            unasked = unasked,
            knowledgeIndex = knowledgeIndex,
            deepDiscovery = deepDiscovery,
            decisionMemory = decisionMemory,
            outcomeVerifier = outcomeVerifier,
            lineage = lineage,
            datasetForaging = datasetForaging
        ).sortedWith(compareByDescending<LatentDiscoveryOpportunityCard> { it.priority }.thenBy { it.opportunityId }).take(12)

        val blocked = normalizeEvidence(
            outcomeVerifier.blockedReplayKeys +
                scientificWeights.downgradedFalseFriends +
                lineage.contradictionCarryForward +
                datasetForaging.cumulativeEvidence.downgrades +
                datasetForaging.scoreSeparation.reasons.filter { it.contains("missing", true) || it.contains("blocked", true) }
        ).take(12)

        val score = when {
            opportunities.isEmpty() -> 20
            baseEvidenceGaps.any { it in setOf("outcome_labels", "time_order", "comparator_control") } -> 78
            unasked.isNotEmpty() -> 70
            dormant.isNotEmpty() -> 58
            else -> 45
        }.coerceIn(0, 100)
        val state = when {
            opportunities.isEmpty() -> "NO_LATENT_OPPORTUNITY_READY"
            blocked.any { it.contains("false", true) || it.contains("contradiction", true) } -> "MINE_WITH_CONTRADICTION_FIRST"
            baseEvidenceGaps.any { it == "outcome_labels" } -> "MINE_OUTCOME_LABEL_WHITE_SPACE"
            unasked.isNotEmpty() -> "MINE_UNASKED_BRIDGE_PROBE"
            else -> "MINE_DORMANT_ROUTE_WITH_GUARDS"
        }
        val top = opportunities.firstOrNull()
        val forcedEvidence = normalizeEvidence(baseEvidenceGaps + opportunities.flatMap { it.missingEvidence } + blocked).take(20)
        val forcedTerms = normalizeTerms(
            opportunities.flatMap { compactTokens(it.probeQuery, 12) + compactTokens(it.label, 8) } +
                unasked.flatMap { compactTokens(it, 10) } +
                forcedEvidence.flatMap { evidenceToSearchTerms(it) }
        ).take(48)
        val nextProbe = top?.probeQuery ?: "Search for a narrow dataset probe that closes outcome/control/time before reusing the current route."
        val reportLine = "v1.8.8 latent gap miner: $state score=$score/100; opportunities=${opportunities.size}; top=${top?.label?.take(140) ?: "none"}; blockers=${blocked.take(2).joinToString(" | ").ifBlank { "none" }}."
        return ScientificDiscoveryGapMinerReport(
            active = true,
            version = "v1.8.8-latent-discovery-gap-miner",
            minerState = state,
            opportunityScore = score,
            topOpportunity = top?.label ?: "none",
            latentOpportunities = opportunities,
            dormantHypotheses = dormant,
            unaskedBridgeQuestions = unasked,
            missingButHighValueEvidence = forcedEvidence,
            blockedBy = blocked,
            forcedDirectiveTerms = forcedTerms,
            forcedEvidenceKeys = forcedEvidence,
            nextDiscoveryProbe = nextProbe.take(360),
            reportLine = reportLine.take(520),
            claimLimit = "latent_discovery_gap_miner_guides_routing_not_proof"
        )
    }

    private fun buildDormantHypotheses(epistemicBelief: EpistemicBeliefReport, lineage: ScientificDiscoveryLineageReport): List<String> = buildList {
        epistemicBelief.updates
            .filter { it.newStatus.contains("RETIRED", true) || it.updateType.contains("DROPPED", true) }
            .take(8)
            .forEach { add("Dormant belief ${it.beliefId}: ${it.reason.take(180)}") }
        lineage.hypothesisLineages
            .filter { it.lineageVerdict.contains("BROKEN", true) || it.splitOrMergeAction.contains("SPLIT", true) }
            .take(6)
            .forEach { add("Dormant lineage ${it.hypothesisId}: ${it.nextLineageTest.take(180)}") }
    }.distinctBy { it.lowercase(Locale.US) }

    private fun buildUnaskedBridgeQuestions(
        deepDiscovery: DeepDiscoveryReasoningReport,
        knowledgeIndex: ScientificKnowledgeIndexReport,
        lineage: ScientificDiscoveryLineageReport,
        baseEvidenceGaps: List<String>
    ): List<String> = buildList {
        deepDiscovery.crossAxisBridgeReport
            .filter { it.score >= 55 || it.bridgeType.contains("measurement", true) || it.bridgeType.contains("confounder", true) }
            .take(8)
            .forEach { bridge ->
                add("${bridge.bridgeQuestion} Require: ${(bridge.evidenceNeeded + baseEvidenceGaps).distinct().take(4).joinToString(", ")}")
            }
        if (knowledgeIndex.highPriorityMissingTerms.any { it.contains("outcome", true) || it.contains("control", true) }) {
            add("Which high-priority foundation term is still absent because outcome/control/time labels were not queried explicitly?")
        }
        lineage.mergeCandidates.take(4).forEach { add("Can route merge candidate '$it' survive a comparator/control/time-course discriminator?") }
    }.distinctBy { it.lowercase(Locale.US) }

    private fun buildOpportunities(
        baseEvidenceGaps: List<String>,
        dormant: List<String>,
        unasked: List<String>,
        knowledgeIndex: ScientificKnowledgeIndexReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        decisionMemory: ScientificDiscoveryDecisionReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport,
        lineage: ScientificDiscoveryLineageReport,
        datasetForaging: DatasetForagingReport
    ): List<LatentDiscoveryOpportunityCard> = buildList {
        val decisiveProbe = deepDiscovery.decisiveExperiment.nextQuery.ifBlank { decisionMemory.nextCycleContract }
        if (baseEvidenceGaps.isNotEmpty()) {
            add(
                LatentDiscoveryOpportunityCard(
                    opportunityId = "gap:${stableId(baseEvidenceGaps.joinToString("|"))}",
                    label = "Close high-value evidence gap before reusing the route",
                    opportunityType = "EVIDENCE_WHITE_SPACE",
                    priority = 92,
                    whyItMatters = "The current discovery route is still blocked by evidence keys that determine whether the lead is real or only metadata/route-fit.",
                    missingEvidence = baseEvidenceGaps.take(8),
                    probeQuery = decisiveProbe.ifBlank { "human dataset outcome recovery severity control comparator longitudinal time-course single-cell RNA-seq" },
                    promoteIf = listOf("outcome/control/time metadata is found", "lineage parent evidence becomes explicit", "same route survives negative-control terms"),
                    killIf = listOf("same blockers repeat for two cycles", "only title/metadata evidence appears", "contradiction explains the route with fewer assumptions"),
                    linkedLineage = lineage.lineageState
                )
            )
        }
        unasked.take(4).forEachIndexed { idx, q ->
            add(
                LatentDiscoveryOpportunityCard(
                    opportunityId = "bridge:${idx}_${stableId(q)}",
                    label = "Unasked bridge probe: ${q.take(90)}",
                    opportunityType = "UNASKED_BRIDGE_QUESTION",
                    priority = 84 - idx,
                    whyItMatters = "A cross-axis question may separate mechanism, confounder, measurement artifact, or false analogy before the next broad search.",
                    missingEvidence = normalizeEvidence(baseEvidenceGaps + "bridge_discriminator" + "control_or_comparator").take(8),
                    probeQuery = q,
                    promoteIf = listOf("bridge has a discriminator", "dataset includes comparator/control", "time order or cell-type context is available"),
                    killIf = listOf("axes are only co-mentioned", "no discriminator appears", "route becomes generic inflammation"),
                    linkedLineage = lineage.lineageState
                )
            )
        }
        if (dormant.isNotEmpty()) {
            add(
                LatentDiscoveryOpportunityCard(
                    opportunityId = "dormant:${stableId(dormant.first())}",
                    label = "Dormant hypothesis reactivation only if the original failure key closes",
                    opportunityType = "DORMANT_HYPOTHESIS_RECHECK",
                    priority = 72,
                    whyItMatters = "Archived or weakened beliefs should not vanish forever, but reactivation must require the exact evidence that previously failed.",
                    missingEvidence = normalizeEvidence(baseEvidenceGaps + outcomeVerifier.unmetEvidenceKeys + "new_parent_evidence").take(8),
                    probeQuery = "${dormant.first()} outcome recovery severity control time-course validation".take(260),
                    promoteIf = listOf("new parent evidence appears", "unmet evidence key closes", "replication or comparator exists"),
                    killIf = listOf("same archived reason repeats", "no new parent evidence", "false-friend term drives the route"),
                    linkedLineage = lineage.lineageState
                )
            )
        }
        val highMissing = knowledgeIndex.highPriorityMissingTerms.take(4)
        if (highMissing.isNotEmpty() && datasetForaging.parsedMetadata.isEmpty()) {
            add(
                LatentDiscoveryOpportunityCard(
                    opportunityId = "white_space:${stableId(highMissing.joinToString("|"))}",
                    label = "Route white-space map: ${highMissing.joinToString(", ").take(100)}",
                    opportunityType = "ROUTE_WHITE_SPACE_MAP",
                    priority = 66,
                    whyItMatters = "High-priority foundation terms are still missing from the evidence path; this can create blind search loops or missed controls.",
                    missingEvidence = normalizeEvidence(highMissing + "minimum_metadata" + "external_validation").take(8),
                    probeQuery = (highMissing.joinToString(" ") + " human dataset metadata outcome control time-course").take(260),
                    promoteIf = listOf("metadata object appears", "foundation term links to route evidence", "control/outcome labels are explicit"),
                    killIf = listOf("no dataset accessions appear", "term stays only conceptual", "route does not link to current lineage"),
                    linkedLineage = lineage.lineageState
                )
            )
        }
    }

    private fun normalizeEvidence(values: List<String>): List<String> = values
        .flatMap { it.split(',', ';', '|', '/', '\n') }
        .map { evidenceKey(it) }
        .filter { it.length >= 3 }
        .filterNot { it in setOf("none", "unknown", "not_evaluated") }
        .distinct()
        .take(24)

    private fun evidenceKey(raw: String): String {
        val text = raw.lowercase(Locale.US).replace("-", "_").replace(" ", "_")
        return when {
            text.contains("outcome") || text.contains("recovery") || text.contains("severity") || text.contains("endpoint") -> "outcome_labels"
            text.contains("time") || text.contains("longitudinal") || text.contains("serial") || text.contains("follow") -> "time_order"
            text.contains("control") || text.contains("comparator") || text.contains("placebo") -> "comparator_control"
            text.contains("metadata") || text.contains("sample") || text.contains("phenotype") || text.contains("license") -> "minimum_metadata"
            text.contains("cell") || text.contains("tissue") -> "tissue_cell_context"
            text.contains("replication") || text.contains("validation") -> "replication_external_validation"
            text.contains("lineage") || text.contains("parent") -> "parent_evidence"
            text.contains("bridge") || text.contains("discriminator") -> "bridge_discriminator"
            text.contains("false") || text.contains("artifact") || text.contains("batch") -> "false_friend_guard"
            text.contains("contradiction") || text.contains("negative") || text.contains("falsif") -> "falsification_lane"
            else -> text.replace(Regex("[^a-z0-9_]+"), "_").trim('_').take(80)
        }
    }

    private fun normalizeTerms(values: List<String>): List<String> = values
        .map { it.trim().lowercase(Locale.US) }
        .filter { it.length >= 3 }
        .filterNot { it in setOf("none", "unknown", "not_evaluated") }
        .distinct()
        .take(64)

    private fun compactTokens(text: String, limit: Int): List<String> {
        val allowed = setOf(
            "outcome", "recovery", "severity", "endpoint", "control", "comparator", "placebo", "longitudinal", "time-course", "serial", "follow-up",
            "human", "patient", "clinical", "single-cell", "rna-seq", "transcriptomic", "cell", "cell-type", "tissue", "metadata", "phenotype",
            "validation", "replication", "negative", "contradiction", "bridge", "discriminator", "interferon", "viral", "load", "ige", "eosinophil", "mast", "cytokine"
        )
        return text.lowercase(Locale.US)
            .replace("single cell", "single-cell")
            .replace("rna seq", "rna-seq")
            .split(Regex("[^a-z0-9_-]+"))
            .filter { it.length >= 3 }
            .filter { it in allowed || it.startsWith("gse") || it.startsWith("prjna") }
            .distinct()
            .take(limit)
    }

    private fun evidenceToSearchTerms(key: String): List<String> = when (evidenceKey(key)) {
        "outcome_labels" -> listOf("outcome", "recovery", "severity", "endpoint")
        "time_order" -> listOf("longitudinal", "time-course", "serial", "follow-up")
        "comparator_control" -> listOf("control", "comparator", "placebo", "healthy")
        "minimum_metadata" -> listOf("metadata", "phenotype", "sample", "GSE")
        "tissue_cell_context" -> listOf("cell-type", "tissue", "single-cell")
        "replication_external_validation" -> listOf("replication", "validation", "external cohort")
        "bridge_discriminator" -> listOf("bridge", "discriminator", "mechanism")
        "falsification_lane" -> listOf("negative control", "contradiction", "falsification")
        else -> listOf(key.replace("_", " "))
    }

    private fun stableId(text: String): String = kotlin.math.abs(text.lowercase(Locale.US).hashCode()).toString()
}
