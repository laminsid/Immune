package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.42: Biomedical Concept Bridge Graph.
 *
 * This layer sits on top of the biomedical ontology and turns term hits into explicit
 * research bridge cards. It is not a disease classifier and it is not treatment logic.
 * It exists to avoid wasting cycles reconnecting obvious biomedical relationships:
 * organ/tissue context, blood/lab phenotype, pathogen trigger, disease phenotype,
 * genetics/omics, medication exposure, nutrition/vitamin exposure, and falsification
 * gates are converted into a small auditable bridge plan.
 */
data class BiomedicalBridgeCard(
    val bridgeId: String,
    val label: String,
    val sourceDomains: List<String>,
    val linkedConcepts: List<String>,
    val lookupTerms: List<String>,
    val evidenceKeys: List<String>,
    val invalidators: List<String>,
    val forbiddenClaims: List<String>
)

data class BiomedicalConceptBridgeReport(
    val active: Boolean,
    val state: String,
    val selectedBridgeIds: List<String>,
    val bridgeCards: List<BiomedicalBridgeCard>,
    val matchedConcepts: List<String>,
    val priorityLookupTerms: List<String>,
    val evidenceKeysToClose: List<String>,
    val invalidators: List<String>,
    val nextAction: String,
    val claimLimit: String = BiomedicalConceptBridgeV11042.CLAIM_LIMIT
) {
    companion object {
        fun empty() = BiomedicalConceptBridgeReport(
            active = false,
            state = "NOT_EVALUATED",
            selectedBridgeIds = emptyList(),
            bridgeCards = emptyList(),
            matchedConcepts = emptyList(),
            priorityLookupTerms = emptyList(),
            evidenceKeysToClose = emptyList(),
            invalidators = emptyList(),
            nextAction = "No biomedical concept bridge was evaluated."
        )
    }
}

object BiomedicalConceptBridgeV11042 {
    const val CLAIM_LIMIT: String = "biomedical_concept_bridge_routing_only_not_clinical_conclusion"

    private data class BridgeRule(
        val id: String,
        val label: String,
        val requiredDomainAny: List<String>,
        val triggers: List<String>,
        val linkedConcepts: List<String>,
        val lookupTerms: List<String>,
        val evidenceKeys: List<String>,
        val invalidators: List<String>,
        val forbiddenClaims: List<String>,
        val priority: Int
    )

    private val baseForbiddenClaims = listOf(
        "patient diagnosis",
        "treatment recommendation",
        "drug ranking",
        "supplement recommendation",
        "causal claim",
        "confirmed mechanism",
        "scientific breakthrough"
    )

    private val rules = listOf(
        BridgeRule(
            id = "VIRUS_AUTOIMMUNITY_MIMICRY_BRIDGE",
            label = "Viral trigger / molecular mimicry / autoimmunity bridge",
            requiredDomainAny = listOf("PATHOGENS_VIRUS_BACTERIA_PARASITE", "COMMON_DISEASES_AND_CLINICAL_PHENOTYPES", "GENETICS_CELLS_CHROMOSOMES_MITOCHONDRIA"),
            triggers = listOf("ebv", "epstein", "herpesviridae", "molecular mimicry", "autoantibody", "sle", "multiple sclerosis", "ms", "hla", "b cell"),
            linkedConcepts = listOf("viral trigger", "autoantibody", "B-cell response", "HLA/MHC context", "molecular mimicry", "autoimmune phenotype"),
            lookupTerms = listOf("EBV", "EBNA1", "Herpesviridae", "molecular mimicry", "cross-reactive", "autoantibody", "HLA", "B cell", "GSE", "PRJNA", "SDY", "control", "longitudinal"),
            evidenceKeys = listOf("accession", "human_or_patient_data", "condition_labels", "outcome_labels", "control_or_comparator", "time_order", "contradiction_or_negative_control"),
            invalidators = listOf("No EBV/Herpesviridae term survives accession-level lookup", "No molecular-mimicry or cross-reactive context appears", "No control/comparator or time-order signal exists"),
            forbiddenClaims = baseForbiddenClaims + listOf("EBV causality confirmed", "molecular mimicry confirmed"),
            priority = 100
        ),
        BridgeRule(
            id = "ORGAN_BARRIER_IMMUNE_ENTRY_BRIDGE",
            label = "Organ / barrier tissue / immune-entry bridge",
            requiredDomainAny = listOf("ORGAN_SYSTEMS", "PATHOGENS_VIRUS_BACTERIA_PARASITE", "COMMON_DISEASES_AND_CLINICAL_PHENOTYPES"),
            triggers = listOf("barrier", "blood-brain barrier", "lung", "gut", "skin", "epithelial", "cns", "intestinal", "tissue"),
            linkedConcepts = listOf("organ context", "barrier tissue", "cell type", "local immune response", "tissue injury", "sample source"),
            lookupTerms = listOf("tissue_source", "cell_type", "barrier", "epithelial", "blood-brain barrier", "single-cell", "histology", "control", "outcome", "GSE"),
            evidenceKeys = listOf("tissue_or_cell_context", "condition_labels", "outcome_labels", "control_or_comparator", "sample_size"),
            invalidators = listOf("No tissue or cell-source metadata is visible", "Only generic inflammation terms appear", "No matched control or outcome label exists"),
            forbiddenClaims = baseForbiddenClaims + listOf("organ damage confirmed"),
            priority = 82
        ),
        BridgeRule(
            id = "BLOOD_LAB_IMMUNE_ACTIVITY_BRIDGE",
            label = "Blood / laboratory immune-activity bridge",
            requiredDomainAny = listOf("BLOOD_HEMATOLOGY_VASCULAR", "COMMON_DISEASES_AND_CLINICAL_PHENOTYPES"),
            triggers = listOf("wbc", "rbc", "lymphocyte", "neutrophil", "platelet", "crp", "esr", "complement", "ige", "igg", "blood pressure", "hypertension"),
            linkedConcepts = listOf("CBC/lab phenotype", "immune cell compartment", "inflammation marker", "vascular context", "complement/antibody signal"),
            lookupTerms = listOf("CBC", "WBC", "lymphocyte", "neutrophil", "CRP", "ESR", "complement", "IgE", "IgG", "flow cytometry", "control", "cohort"),
            evidenceKeys = listOf("lab_measurement_definition", "condition_labels", "outcome_labels", "control_or_comparator", "baseline_or_reference_range"),
            invalidators = listOf("Lab marker is not defined", "No baseline/control group is present", "Marker has no linked clinical or outcome label"),
            forbiddenClaims = baseForbiddenClaims + listOf("diagnosis from lab marker"),
            priority = 76
        ),
        BridgeRule(
            id = "MITOCHONDRIA_ENERGY_IMMUNE_BRIDGE",
            label = "Mitochondrial / fatigue / immune-metabolic bridge",
            requiredDomainAny = listOf("GENETICS_CELLS_CHROMOSOMES_MITOCHONDRIA", "COMMON_DISEASES_AND_CLINICAL_PHENOTYPES"),
            triggers = listOf("mitochondria", "mtdna", "fatigue", "me/cfs", "long covid", "metabolic", "oxidative stress", "energy"),
            linkedConcepts = listOf("mitochondrial context", "immune-metabolic phenotype", "fatigue/recovery outcome", "oxidative stress", "omics signature"),
            lookupTerms = listOf("mitochondria", "mtDNA", "oxidative stress", "ME/CFS", "fatigue", "Long COVID", "transcriptome", "metabolomics", "recovery", "severity", "control"),
            evidenceKeys = listOf("omics_accession", "human_or_patient_data", "fatigue_or_recovery_label", "control_or_comparator", "time_order"),
            invalidators = listOf("No mitochondrial or immune-metabolic metadata appears", "No fatigue/recovery outcome exists", "No comparator/control exists"),
            forbiddenClaims = baseForbiddenClaims + listOf("energy mechanism confirmed"),
            priority = 70
        ),
        BridgeRule(
            id = "DRUG_EXPOSURE_CONFOUNDER_BRIDGE",
            label = "Medication exposure / perturbation / confounder bridge",
            requiredDomainAny = listOf("MEDICATIONS_RESEARCH_PERTURBATIONS"),
            triggers = listOf("prednisone", "glucocorticoid", "rituximab", "jak inhibitor", "antihistamine", "antibiotic", "metformin", "insulin", "statin", "nsaid"),
            linkedConcepts = listOf("drug exposure", "treated cohort", "untreated control", "washout", "immune perturbation", "confounder"),
            lookupTerms = listOf("drug exposure", "treated cohort", "untreated control", "washout", "prednisone", "rituximab", "JAK inhibitor", "antihistamine", "metadata", "control"),
            evidenceKeys = listOf("medication_exposure_metadata", "treated_vs_untreated_control", "dose_or_exposure_as_metadata_only", "washout_or_timing", "outcome_labels"),
            invalidators = listOf("Drug exposure is absent from metadata", "No untreated/matched control exists", "Route becomes treatment advice instead of perturbation control"),
            forbiddenClaims = baseForbiddenClaims + listOf("dose recommendation", "drug efficacy claim"),
            priority = 66
        ),
        BridgeRule(
            id = "NUTRITION_EXPOSURE_NOISE_BRIDGE",
            label = "Nutrition / herb / vitamin exposure-noise bridge",
            requiredDomainAny = listOf("HERBS_FOODS_NUTRITION_EXPOSURES", "VITAMINS_AND_IMMUNE_FUNCTION"),
            triggers = listOf("vitamin", "zinc", "selenium", "honey", "curcumin", "quercetin", "ashwagandha", "eucalyptus", "artemisia", "microbiome", "nutrition"),
            linkedConcepts = listOf("dietary exposure", "micronutrient status", "natural compound", "microbiome context", "confounder/noise control"),
            lookupTerms = listOf("nutrition exposure", "vitamin status", "serum level", "micronutrient", "microbiome", "diet", "control", "cohort", "no supplement advice"),
            evidenceKeys = listOf("exposure_definition", "serum_or_intake_measurement", "control_or_comparator", "outcome_labels", "confounder_control"),
            invalidators = listOf("Only supplement narrative appears", "No exposure measurement is present", "No control/comparator exists"),
            forbiddenClaims = baseForbiddenClaims + listOf("supplement efficacy", "natural treatment recommendation"),
            priority = 48
        )
    )

    fun evaluate(
        ontology: BiomedicalResearchOntologyReport,
        evidencePrior: EvidencePriorSelectionReport,
        ebv: EBVLeadVerificationReport,
        metadataClosure: MetadataClosureReport,
        recentReports: List<String>
    ): BiomedicalConceptBridgeReport {
        if (!ontology.active) return BiomedicalConceptBridgeReport.empty()
        val corpus = buildCorpus(ontology, evidencePrior, ebv, metadataClosure, recentReports)
        val selectedDomains = ontology.selectedDomains.toSet()
        val scored = rules.mapNotNull { rule ->
            val domainHit = rule.requiredDomainAny.count { it in selectedDomains }
            val termHits = rule.triggers.filter { corpus.contains(it.lowercase(Locale.US)) }.distinct()
            val ebvBoost = if (rule.id == "VIRUS_AUTOIMMUNITY_MIMICRY_BRIDGE" && ebv.active) 18 else 0
            val priorBoost = if (evidencePrior.queryTerms.any { term -> rule.lookupTerms.any { it.equals(term, ignoreCase = true) } }) 10 else 0
            val metadataPenalty = if (metadataClosure.missingFields.contains("control_or_comparator")) -2 else 0
            val score = rule.priority + domainHit * 12 + termHits.size * 7 + ebvBoost + priorBoost + metadataPenalty
            if (domainHit == 0 && termHits.isEmpty()) null else Triple(rule, termHits, score)
        }.sortedByDescending { it.third }

        val chosen = scored.take(3)
        if (chosen.isEmpty()) {
            val keys = (ontology.queryExpansionKeys + evidencePrior.queryTerms).distinct().take(18)
            return BiomedicalConceptBridgeReport(
                active = true,
                state = "CONCEPT_BRIDGE_BASELINE_ONLY",
                selectedBridgeIds = emptyList(),
                bridgeCards = emptyList(),
                matchedConcepts = ontology.matchedTerms.take(16),
                priorityLookupTerms = keys,
                evidenceKeysToClose = listOf("accession", "condition_labels", "outcome_labels", "control_or_comparator", "time_order"),
                invalidators = listOf("No bridge-specific trigger survived ontology matching"),
                nextAction = "Use neutral ontology keys for secondary lookup; do not create biological conclusions."
            )
        }

        val cards = chosen.map { (rule, hits, _) ->
            BiomedicalBridgeCard(
                bridgeId = rule.id,
                label = rule.label,
                sourceDomains = rule.requiredDomainAny.filter { it in selectedDomains },
                linkedConcepts = rule.linkedConcepts,
                lookupTerms = rule.lookupTerms.take(14),
                evidenceKeys = rule.evidenceKeys,
                invalidators = rule.invalidators,
                forbiddenClaims = rule.forbiddenClaims.distinct()
            )
        }
        val evidenceKeys = cards.flatMap { it.evidenceKeys }.distinct().let { keys ->
            val missingFirst = metadataClosure.missingFields.filter { it in keys }
            (missingFirst + keys).distinct().take(24)
        }
        val state = when {
            cards.any { it.bridgeId == "VIRUS_AUTOIMMUNITY_MIMICRY_BRIDGE" } && ebv.active -> "CONCEPT_BRIDGE_EBV_MIMICRY_LINKED_FOR_VERIFICATION"
            metadataClosure.missingFields.any { it in evidenceKeys } -> "CONCEPT_BRIDGE_METADATA_OPEN"
            cards.any { it.bridgeId.contains("NOISE") || it.bridgeId.contains("CONFOUNDER") } -> "CONCEPT_BRIDGE_CONFOUNDER_CONTROL_READY"
            else -> "CONCEPT_BRIDGE_READY_FOR_FALSIFICATION"
        }
        return BiomedicalConceptBridgeReport(
            active = true,
            state = state,
            selectedBridgeIds = cards.map { it.bridgeId },
            bridgeCards = cards,
            matchedConcepts = (ontology.matchedTerms + chosen.flatMap { it.second }).distinct().take(30),
            priorityLookupTerms = cards.flatMap { it.lookupTerms }.distinct().take(32),
            evidenceKeysToClose = evidenceKeys,
            invalidators = cards.flatMap { it.invalidators }.distinct().take(16),
            nextAction = "Apply selected biomedical bridge cards to secondary lookup and metadata closure; close ${evidenceKeys.take(6).joinToString(", ")} before contradiction or hypothesis movement."
        )
    }

    private fun buildCorpus(
        ontology: BiomedicalResearchOntologyReport,
        evidencePrior: EvidencePriorSelectionReport,
        ebv: EBVLeadVerificationReport,
        metadataClosure: MetadataClosureReport,
        recentReports: List<String>
    ): String = listOf(
        ontology.selectedDomains.joinToString(" "),
        ontology.matchedTerms.joinToString(" "),
        ontology.queryExpansionKeys.joinToString(" "),
        ontology.researchUse.joinToString(" "),
        evidencePrior.selectedPriorId,
        evidencePrior.selectedRoute,
        evidencePrior.queryTerms.joinToString(" "),
        ebv.matchedTerms.joinToString(" "),
        ebv.closedEvidence.joinToString(" "),
        metadataClosure.closedFields.joinToString(" "),
        metadataClosure.missingFields.joinToString(" "),
        recentReports.takeLast(8).joinToString(" ")
    ).joinToString(" ").lowercase(Locale.US)
}
