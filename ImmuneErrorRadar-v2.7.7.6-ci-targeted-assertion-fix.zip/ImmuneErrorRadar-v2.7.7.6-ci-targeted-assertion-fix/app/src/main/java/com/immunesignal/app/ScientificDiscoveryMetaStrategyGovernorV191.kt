package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v1.9.1: meta-strategy governor. Token: meta_strategy_governor.
 *
 * v1.9.0 verifies the outcome of the previous executable probe. This governor
 * sits above the probe ledger and chooses the next research posture: continue,
 * close evidence, reroute, replicate narrowly, archive/dormant, or allow one
 * bounded Deep Think session. It guides routing only; it never proves biology,
 * diagnosis, treatment, causality, mechanism, or immune outcome.
 */
data class MetaStrategyMoveCard(
    val moveId: String,
    val label: String,
    val decision: String,
    val reason: String,
    val evidenceKeys: List<String>,
    val queryTerms: List<String>,
    val routeEffect: String
)

data class ScientificDiscoveryMetaStrategyReport(
    val active: Boolean,
    val version: String,
    val strategyState: String,
    val governorScore: Int,
    val selectedStrategy: String,
    val blockedStrategy: String,
    val continuationDecision: String,
    val routeBudget: Int,
    val deepThinkPermission: String,
    val explorationExploitationMode: String,
    val strategyMoves: List<MetaStrategyMoveCard>,
    val allowedMoves: List<String>,
    val blockedMoves: List<String>,
    val forcedDirectiveTerms: List<String>,
    val forcedEvidenceKeys: List<String>,
    val reportLine: String,
    val claimLimit: String = "meta_strategy_governor_guides_routing_not_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryMetaStrategyReport(
            active = false,
            version = "v1.9.1",
            strategyState = "NOT_RUN",
            governorScore = 0,
            selectedStrategy = "Run a normal guarded evidence cycle.",
            blockedStrategy = "No strategy blocked.",
            continuationDecision = "No meta-strategy decision available.",
            routeBudget = 1,
            deepThinkPermission = "DEEP_THINK_NOT_EVALUATED",
            explorationExploitationMode = "BALANCED_GUARDED",
            strategyMoves = emptyList(),
            allowedMoves = emptyList(),
            blockedMoves = emptyList(),
            forcedDirectiveTerms = emptyList(),
            forcedEvidenceKeys = emptyList(),
            reportLine = "Meta-strategy governor did not run.",
            claimLimit = "meta_strategy_governor_guides_routing_not_proof"
        )
    }
}

object ScientificDiscoveryMetaStrategyGovernorEngineV191 {
    fun govern(
        recentReportJsonLines: List<String>,
        probeOutcomeLedger: ScientificDiscoveryProbeOutcomeLedgerReport,
        currentProbePlan: ScientificDiscoveryProbePlanReport,
        gapMiner: ScientificDiscoveryGapMinerReport,
        lineage: ScientificDiscoveryLineageReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport,
        executionPolicy: ScientificDiscoveryExecutionPolicyReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        datasetForaging: DatasetForagingReport,
        learningOs: LearningOsReport,
        discoveryReadiness: DiscoveryReadinessReport
    ): ScientificDiscoveryMetaStrategyReport {
        if (!probeOutcomeLedger.active && !currentProbePlan.active && !gapMiner.active && !deepDiscovery.active && !scientificWeights.active) {
            return ScientificDiscoveryMetaStrategyReport.empty()
        }

        val repeatedGovernorSignals = countRecentMetaStrategySignals(recentReportJsonLines)
        val unresolved = normalizeEvidence(
            probeOutcomeLedger.unresolvedEvidenceKeys +
                outcomeVerifier.unmetEvidenceKeys +
                executionPolicy.forcedEvidenceKeys +
                gapMiner.forcedEvidenceKeys +
                currentProbePlan.evidencePack
        ).take(32)
        val replayPressure = normalizeEvidence(
            probeOutcomeLedger.replayPenaltyKeys +
                currentProbePlan.replayBlockKeys +
                executionPolicy.queryReplayBlocks +
                outcomeVerifier.blockedReplayKeys
        ).take(24)
        val routeFitHighButUnpaid = datasetForaging.scoreSeparation.routeFitScore >= 85 && datasetForaging.scoreSeparation.datasetUsabilityScore < 70
        val rewardedProbe = probeOutcomeLedger.evidenceClosureScore >= 70 && probeOutcomeLedger.killSignals.isEmpty()
        val failedProbe = probeOutcomeLedger.killSignals.isNotEmpty() || probeOutcomeLedger.evidenceClosureScore < 35 && probeOutcomeLedger.active
        val unresolvedCore = unresolved.any { it in coreEvidenceKeys }
        val dormantOpportunity = gapMiner.latentOpportunities.any { it.priority >= 75 } || gapMiner.topOpportunity.isNotBlank()
        val contradictionPressure = lineage.contradictionCarryForward.isNotEmpty() || deepDiscovery.contradictionPlan.contradictionQueries.isNotEmpty()
        val sameStallRepeats = repeatedGovernorSignals >= 1 || learningOs.incident.rootCauses.any { it.contains("NO_OUTCOME", true) || it.contains("METADATA", true) }

        val selectedState = when {
            failedProbe || replayPressure.isNotEmpty() && sameStallRepeats -> "STRATEGY_REROUTE_OR_ARCHIVE"
            rewardedProbe -> "STRATEGY_NARROW_REPLICATION"
            routeFitHighButUnpaid || unresolvedCore -> "STRATEGY_CLOSE_CORE_EVIDENCE"
            contradictionPressure -> "STRATEGY_OBJECTION_FIRST"
            dormantOpportunity -> "STRATEGY_EXPLORE_LATENT_PROBE"
            else -> "STRATEGY_GUARDED_CONTINUATION"
        }
        val deepThinkPermission = when {
            selectedState == "STRATEGY_REROUTE_OR_ARCHIVE" && sameStallRepeats -> "ALLOW_ONE_BOUNDED_DEEP_THINK_BEFORE_ARCHIVE"
            routeFitHighButUnpaid && unresolvedCore -> "ALLOW_ONLY_IF_CORE_EVIDENCE_STALLS_AGAIN"
            rewardedProbe -> "DEEP_THINK_NOT_NEEDED_RUN_REPLICATION"
            else -> "DEEP_THINK_LOCKED_UNTIL_STALL_OR_CONTRADICTION"
        }
        val routeBudget = when (selectedState) {
            "STRATEGY_REROUTE_OR_ARCHIVE" -> 1
            "STRATEGY_CLOSE_CORE_EVIDENCE" -> 1
            "STRATEGY_OBJECTION_FIRST" -> 1
            "STRATEGY_NARROW_REPLICATION" -> 2
            else -> 1
        }
        val selectedStrategy = when (selectedState) {
            "STRATEGY_REROUTE_OR_ARCHIVE" -> "Reroute away from the repeated probe; archive or cool down the current route unless new parent evidence appears."
            "STRATEGY_NARROW_REPLICATION" -> "Reward the previous probe only with a narrow replication/control probe; do not broaden the mechanism."
            "STRATEGY_CLOSE_CORE_EVIDENCE" -> "Close the core evidence pack first: outcome, time order, control/comparator, metadata, human/tissue context."
            "STRATEGY_OBJECTION_FIRST" -> "Run contradiction and negative-control queries before any route expansion."
            "STRATEGY_EXPLORE_LATENT_PROBE" -> "Explore the highest-value latent gap with a bounded probe and explicit kill criteria."
            else -> "Continue guarded evidence routing with forced evidence keys and no broad upgrade."
        }
        val blockedStrategy = when {
            routeFitHighButUnpaid -> "Blocked broad route expansion: high route-fit is unpaid because usability/outcome/control/time evidence is still insufficient."
            replayPressure.isNotEmpty() -> "Blocked replay of previous probe/query terms until unresolved evidence keys change."
            failedProbe -> "Blocked reuse of the failed probe route without new parent evidence."
            else -> "Blocked strong biological or causal upgrade without controlled comparison and repeatability."
        }
        val allowedMoves = when (selectedState) {
            "STRATEGY_NARROW_REPLICATION" -> listOf("narrow_replication_probe", "control_or_comparator_check", "external_validation_search")
            "STRATEGY_OBJECTION_FIRST" -> listOf("contradiction_mining", "negative_control_search", "artifact_confounder_check")
            "STRATEGY_REROUTE_OR_ARCHIVE" -> listOf("archive_or_cooldown_route", "parent_evidence_search", "bounded_deep_think_if_stall_repeats")
            "STRATEGY_EXPLORE_LATENT_PROBE" -> listOf("bounded_latent_probe", "pass_fail_kill_gate", "lineage_parent_check")
            else -> listOf("minimum_metadata_closure", "outcome_label_search", "time_order_search", "comparator_control_search")
        }
        val blockedMoves = listOf(
            "broad_hypothesis_upgrade",
            "metadata_only_discovery_claim",
            "route_fit_only_generalization"
        ) + replayPressure.take(5).map { "replay_block:$it" }

        val strategyMoves = buildMoves(
            selectedState = selectedState,
            unresolved = unresolved,
            replayPressure = replayPressure,
            probePlan = currentProbePlan,
            gapMiner = gapMiner,
            deepDiscovery = deepDiscovery,
            lineage = lineage,
            routeFitHighButUnpaid = routeFitHighButUnpaid
        )
        val forcedEvidence = normalizeEvidence(
            unresolved + replayPressure + strategyMoves.flatMap { it.evidenceKeys } + when (selectedState) {
                "STRATEGY_NARROW_REPLICATION" -> listOf("replication_external_validation", "comparator_control", "negative_control")
                "STRATEGY_OBJECTION_FIRST" -> listOf("falsification_lane", "negative_control", "artifact_confounder_control")
                "STRATEGY_REROUTE_OR_ARCHIVE" -> listOf("parent_evidence", "lineage_break_policy", "new_independent_dataset")
                else -> listOf("minimum_metadata", "outcome_labels", "time_order", "comparator_control")
            }
        ).take(32)
        val forcedTerms = normalizeTerms(
            compactTokens(selectedStrategy, 22) +
                compactTokens(blockedStrategy, 16) +
                strategyMoves.flatMap { it.queryTerms } +
                forcedEvidence.flatMap { evidenceToTerms(it) } +
                compactTokens(currentProbePlan.selectedProbeQuery, 18) +
                compactTokens(gapMiner.nextDiscoveryProbe, 14)
        ).take(72)
        val score = computeGovernorScore(
            selectedState = selectedState,
            unresolvedCount = unresolved.size,
            replayCount = replayPressure.size,
            closureScore = probeOutcomeLedger.evidenceClosureScore,
            routeFitHighButUnpaid = routeFitHighButUnpaid,
            sameStallRepeats = sameStallRepeats
        )
        val mode = when (selectedState) {
            "STRATEGY_NARROW_REPLICATION" -> "EXPLOIT_WITH_REPLICATION"
            "STRATEGY_EXPLORE_LATENT_PROBE" -> "EXPLORE_WITH_KILL_GATES"
            "STRATEGY_REROUTE_OR_ARCHIVE" -> "REROUTE_OR_ARCHIVE"
            "STRATEGY_OBJECTION_FIRST" -> "FALSIFICATION_FIRST"
            else -> "EVIDENCE_CLOSURE_FIRST"
        }
        val continuation = when (selectedState) {
            "STRATEGY_REROUTE_OR_ARCHIVE" -> "Stop replaying the current route; perform one parent-evidence or contradiction probe, then archive if the same core evidence remains missing."
            "STRATEGY_NARROW_REPLICATION" -> "Continue only as a replication/control probe; do not broaden axes until external validation appears."
            "STRATEGY_CLOSE_CORE_EVIDENCE" -> "Continue only if the next cycle targets the missing core evidence keys directly."
            "STRATEGY_OBJECTION_FIRST" -> "Continue by attacking the current explanation before gathering supportive evidence."
            else -> "Continue with a bounded probe and explicit pass/fail/kill contract."
        }
        val line = "v1.9.1 meta-strategy governor: $selectedState; score=$score/100; mode=$mode; budget=$routeBudget; deepThink=$deepThinkPermission; forced=${forcedEvidence.take(5).joinToString("/").ifBlank { "none" }}."
        return ScientificDiscoveryMetaStrategyReport(
            active = true,
            version = "v1.9.1-meta-strategy-governor",
            strategyState = selectedState,
            governorScore = score,
            selectedStrategy = selectedStrategy.take(320),
            blockedStrategy = blockedStrategy.take(320),
            continuationDecision = continuation.take(320),
            routeBudget = routeBudget,
            deepThinkPermission = deepThinkPermission,
            explorationExploitationMode = mode,
            strategyMoves = strategyMoves.take(5),
            allowedMoves = allowedMoves.take(10),
            blockedMoves = blockedMoves.distinct().take(14),
            forcedDirectiveTerms = forcedTerms,
            forcedEvidenceKeys = forcedEvidence,
            reportLine = line.take(560),
            claimLimit = "meta_strategy_governor_guides_routing_not_proof"
        )
    }

    private fun buildMoves(
        selectedState: String,
        unresolved: List<String>,
        replayPressure: List<String>,
        probePlan: ScientificDiscoveryProbePlanReport,
        gapMiner: ScientificDiscoveryGapMinerReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        lineage: ScientificDiscoveryLineageReport,
        routeFitHighButUnpaid: Boolean
    ): List<MetaStrategyMoveCard> {
        val moves = mutableListOf<MetaStrategyMoveCard>()
        val core = unresolved.filter { it in coreEvidenceKeys }.ifEmpty { listOf("minimum_metadata", "outcome_labels", "time_order", "comparator_control") }
        val mainQuery = when (selectedState) {
            "STRATEGY_OBJECTION_FIRST" -> deepDiscovery.contradictionPlan.contradictionQueries.firstOrNull().orEmpty()
            "STRATEGY_EXPLORE_LATENT_PROBE" -> gapMiner.nextDiscoveryProbe
            else -> probePlan.selectedProbeQuery
        }.ifBlank { "human immune response dataset outcome severity recovery control longitudinal metadata" }
        moves += MetaStrategyMoveCard(
            moveId = "meta_${stableId(selectedState + mainQuery)}",
            label = selectedState.lowercase(Locale.US).replace('_', ' '),
            decision = selectedState,
            reason = when (selectedState) {
                "STRATEGY_REROUTE_OR_ARCHIVE" -> "Probe outcome or replay penalty says the current path is not paying its evidence debt."
                "STRATEGY_NARROW_REPLICATION" -> "Previous probe closed enough evidence to justify replication, not broad generalization."
                "STRATEGY_OBJECTION_FIRST" -> "Contradiction or lineage carry-forward must be tested before supportive search."
                "STRATEGY_EXPLORE_LATENT_PROBE" -> "Gap miner found a dormant high-value question with explicit pass/fail criteria."
                else -> "Core evidence keys are still missing; evidence closure must precede discovery language."
            },
            evidenceKeys = normalizeEvidence(core + replayPressure.take(6)),
            queryTerms = normalizeTerms(compactTokens(mainQuery, 24) + core.flatMap { evidenceToTerms(it) }),
            routeEffect = if (routeFitHighButUnpaid) "route_fit_requires_evidence_payment" else "guarded_strategy_selection"
        )
        if (lineage.contradictionCarryForward.isNotEmpty()) {
            moves += MetaStrategyMoveCard(
                moveId = "meta_contradiction_${stableId(lineage.contradictionCarryForward.joinToString("|"))}",
                label = "carry-forward contradiction check",
                decision = "CHECK_CONTRADICTION_BEFORE_REUSE",
                reason = "Lineage graph carried unresolved contradiction; do not reuse the route without addressing it.",
                evidenceKeys = listOf("falsification_lane", "negative_control", "contradiction_carry_forward"),
                queryTerms = normalizeTerms(lineage.contradictionCarryForward.flatMap { compactTokens(it, 10) } + listOf("negative control", "contradiction", "artifact", "confounder")),
                routeEffect = "blocks_supportive_search_until_objection_checked"
            )
        }
        return moves
    }

    private fun countRecentMetaStrategySignals(lines: List<String>): Int = lines.take(5).count { line ->
        val root = runCatching { JSONObject(line) }.getOrNull() ?: return@count false
        val gov = root.optJSONObject("scientificDiscoveryMetaStrategyReport") ?: return@count false
        gov.optBoolean("active", false) && gov.optString("strategyState", "").contains("CLOSE", true)
    }

    private fun computeGovernorScore(selectedState: String, unresolvedCount: Int, replayCount: Int, closureScore: Int, routeFitHighButUnpaid: Boolean, sameStallRepeats: Boolean): Int {
        var score = 50
        if (selectedState == "STRATEGY_NARROW_REPLICATION") score += 20
        if (selectedState == "STRATEGY_CLOSE_CORE_EVIDENCE") score += 12
        if (selectedState == "STRATEGY_OBJECTION_FIRST") score += 10
        if (selectedState == "STRATEGY_REROUTE_OR_ARCHIVE") score += 8
        if (closureScore >= 70) score += 10
        if (unresolvedCount >= 4) score -= 8
        if (replayCount >= 3) score -= 8
        if (routeFitHighButUnpaid) score -= 6
        if (sameStallRepeats) score -= 5
        return score.coerceIn(5, 95)
    }

    private fun normalizeEvidence(values: List<String>): List<String> = values.map { evidenceKeyFromText(it) }.filter { it.length >= 3 }.distinctBy { it.lowercase(Locale.US) }
    private fun normalizeTerms(values: List<String>): List<String> = values.map { it.lowercase(Locale.US).replace(Regex("[^a-z0-9+_.-]+"), " ").trim() }.filter { it.length >= 3 && it !in stopWords }.distinct()
    private fun compactTokens(text: String, limit: Int): List<String> = text.lowercase(Locale.US).replace("rna seq", "rna-seq").replace("single cell", "single-cell").replace(Regex("[^a-z0-9+_.-]+"), " ").split(Regex("\\s+")).map { it.trim() }.filter { it.length >= 3 && it !in stopWords }.distinct().take(limit)
    private fun evidenceKeyFromText(text: String): String {
        val t = text.lowercase(Locale.US).replace("-", "_").replace(" ", "_")
        return when {
            t.contains("outcome") || t.contains("recovery") || t.contains("severity") || t.contains("endpoint") -> "outcome_labels"
            t.contains("time") || t.contains("longitudinal") || t.contains("serial") || t.contains("follow") || t.contains("temporal") -> "time_order"
            t.contains("control") || t.contains("comparator") || t.contains("placebo") || t.contains("negative") -> "comparator_control"
            t.contains("metadata") || t.contains("accession") || t.contains("license") || t.contains("sample") -> "minimum_metadata"
            t.contains("human") || t.contains("patient") || t.contains("clinical") -> "human_or_patient_data"
            t.contains("replication") || t.contains("validation") || t.contains("repeat") -> "replication_external_validation"
            t.contains("parent") || t.contains("lineage") -> "parent_evidence"
            t.contains("artifact") || t.contains("confound") || t.contains("batch") -> "artifact_confounder_control"
            t.contains("falsif") || t.contains("contradiction") -> "falsification_lane"
            else -> t.replace(Regex("[^a-z0-9_]+"), "_").trim('_').take(80).ifBlank { "unspecified_evidence" }
        }
    }
    private fun evidenceToTerms(key: String): List<String> = when (evidenceKeyFromText(key)) {
        "outcome_labels" -> listOf("outcome", "recovery", "severity", "endpoint")
        "time_order" -> listOf("longitudinal", "time-course", "serial", "follow-up")
        "comparator_control" -> listOf("control", "comparator", "placebo", "negative control")
        "minimum_metadata" -> listOf("metadata", "accession", "sample size", "license")
        "human_or_patient_data" -> listOf("human", "patient", "clinical", "cohort")
        "replication_external_validation" -> listOf("replication", "external validation", "independent cohort")
        "parent_evidence" -> listOf("parent evidence", "lineage", "source evidence")
        "artifact_confounder_control" -> listOf("artifact", "batch effect", "confounder")
        "falsification_lane" -> listOf("falsification", "contradiction", "negative control")
        else -> listOf(key.replace('_', ' '))
    }
    private fun stableId(text: String): String = text.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "_").trim('_').take(48).ifBlank { "strategy" }
    private val coreEvidenceKeys = setOf("minimum_metadata", "outcome_labels", "time_order", "comparator_control", "human_or_patient_data")
    private val stopWords = setOf("the", "and", "with", "without", "this", "that", "from", "into", "before", "after", "because", "probe", "route", "evidence", "required", "previous", "current", "cycle", "query", "data")
}
