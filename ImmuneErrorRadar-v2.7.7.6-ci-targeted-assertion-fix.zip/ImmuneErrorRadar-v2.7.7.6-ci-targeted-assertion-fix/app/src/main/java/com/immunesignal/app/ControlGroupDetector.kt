package com.immunesignal.app

import java.util.Locale

/** v1.4.2: detects control-group language without claiming causal proof. */
object ControlGroupDetector {
    private val labels = linkedMapOf(
        "healthy_control" to listOf("healthy control", "healthy donor", "controls", "control subjects"),
        "untreated_baseline" to listOf("untreated", "baseline", "pre-treatment", "pretreatment"),
        "matched_control" to listOf("matched control", "age matched", "sex matched", "case-control"),
        "negative_control" to listOf("negative control", "sham", "placebo"),
        "exposed_control" to listOf("exposed", "unexposed", "challenge", "mock infected")
    )

    fun detect(text: String): List<String> {
        val lower = text.lowercase(Locale.US)
        return labels.filter { (_, terms) -> terms.any { lower.contains(it) } }.keys.toList()
    }
}
