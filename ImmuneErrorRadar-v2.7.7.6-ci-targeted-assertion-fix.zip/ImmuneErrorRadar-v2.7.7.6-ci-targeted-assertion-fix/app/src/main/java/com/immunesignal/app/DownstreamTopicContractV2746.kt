package com.immunesignal.app

import java.util.Locale

/**
 * v2.7.4.6 Final downstream execution lock.
 *
 * Captures the current topic contract once, then lets downstream route builders,
 * seed bootstraps, benchmark labels and brief rendering decide whether a prior,
 * bridge or query is compatible with the current run. This is a routing safety
 * layer only; it never upgrades biological evidence.
 */
data class DownstreamTopicContractReportV2746(
    val active: Boolean,
    val version: String,
    val topicKey: String,
    val sourceTopic: String,
    val anchorTerms: List<String>,
    val allowedFamilies: List<String>,
    val blockedFamilies: List<String>,
    val allowExposomeBridge: Boolean,
    val allowMicrobiomeBridge: Boolean,
    val allowKnownPriorSeeds: Boolean,
    val allowGenericBootstrapFallback: Boolean,
    val claimLimit: String = DownstreamTopicContractV2746.CLAIM_LIMIT
)

object DownstreamTopicContractV2746 {
    const val VERSION: String = "2.7.4.6-final-downstream-execution-lock"
    const val CLAIM_LIMIT: String = "topic_contract_routing_only_not_evidence_not_causality"

    private val toxicantTerms = listOf(
        "pesticide", "pesticides", "glyphosate", "organophosphate", "pyrethroid",
        "pfas", "bpa", "phthalate", "phthalates", "microplastic", "microplastics", "plasticizer",
        "heavy metal", "heavy metals", "lead exposure", "blood lead", "lead poisoning", "arsenic", "cadmium", "mercury",
        "livestock antibiotic", "poultry antibiotic", "antibiotic residue", "antibiotic residues", "resistome"
    )
    private val stressPriorTerms = listOf("chronic stress", "stress hpa", "hpa", "cortisol", "glucocorticoid", "latent virus", "ebv", "hhv-6", "hhv6")
    private val microbiomeTerms = listOf("microbiome", "microbiota", "gut bacteria", "gut-brain", "gut brain", "dysbiosis", "tryptophan", "kynurenine", "scfa", "lps", "endotoxin")
    private val allergyTerms = listOf("allergy", "allergies", "allergic", "hypersensitivity", "atopy", "atopic", "ige", "mast cell", "eosinophil", "il-4", "il-5", "il-13")
    private val covidTerms = listOf("covid", "sars-cov-2", "sars cov 2", "long covid", "pasc", "post-viral", "interferon")
    private val longevityTerms = listOf("longevity", "aging", "ageing", "immunosenescence", "inflammaging", "senescence")

    fun fromIntent(intent: GTIMResearchIntentObjectV255): DownstreamTopicContractReportV2746 {
        val corpus = listOf(
            intent.sourceText,
            intent.diseasePhenotype.joinToString(" "),
            intent.triggerExposure.joinToString(" "),
            intent.pathway.joinToString(" "),
            intent.cellTissue.joinToString(" "),
            intent.assayType.joinToString(" "),
            intent.comparatorWanted.joinToString(" ")
        ).joinToString(" ")
        return fromText(corpus)
    }

    fun fromText(text: String): DownstreamTopicContractReportV2746 {
        val lower = text.lowercase(Locale.US)
        val key = when {
            containsAny(lower, "covid", "sars-cov-2", "sars cov 2", "long covid", "pasc") -> "covid_interferon"
            containsAny(lower, "allergy", "allergies", "allergic", "hypersensitivity", "atopy", "atopic", "allergen", "ige", "mast cell", "eosinophil") -> "allergy_type2"
            containsAny(lower, "depression", "major depressive", "mood") && containsAny(lower, "microbiome", "microbiota", "gut bacteria", "gut-brain", "gut brain", "tryptophan", "kynurenine", "bacteria") -> "microbiome_depression"
            containsAny(lower, "anxiety") && containsAny(lower, "microbiome", "microbiota", "gut bacteria", "tryptophan", "kynurenine", "bacteria") -> "microbiome_anxiety"
            containsAny(lower, "longevity", "aging", "ageing", "immunosenescence", "inflammaging") -> "longevity_aging"
            containsAny(lower, "hantavirus", "hanta", "hfrs", "hcps", "puumala", "sin nombre", "andes virus", "seoul virus") -> "hantavirus"
            containsAny(lower, "pesticide", "pesticides", "glyphosate", "organophosphate", "pyrethroid") -> "exposome_pesticide"
            containsAny(lower, "microplastic", "microplastics", "pfas", "bpa", "phthalate", "phthalates", "plasticizer") -> "exposome_plastic"
            containsAny(lower, "heavy metal", "heavy metals", "lead exposure", "blood lead", "lead poisoning", "arsenic", "cadmium", "mercury") -> "exposome_heavy_metal"
            containsAny(lower, "livestock", "poultry", "resistome", "antibiotic residue", "antibiotic residues") -> "exposome_livestock_antibiotic"
            containsAny(lower, "ebv", "sle", "lupus") -> "ebv_sle"
            containsAny(lower, "microbiome", "microbiota", "gut bacteria", "gut-brain", "gut brain", "dysbiosis") -> "microbiome_open"
            else -> "open_topic"
        }
        val anchors = anchorsFor(key, lower)
        val allowed = allowedFamiliesFor(key)
        val blocked = blockedFamiliesFor(key)
        return DownstreamTopicContractReportV2746(
            active = text.isNotBlank(),
            version = VERSION,
            topicKey = key,
            sourceTopic = text.take(500),
            anchorTerms = anchors,
            allowedFamilies = allowed,
            blockedFamilies = blocked,
            allowExposomeBridge = key.startsWith("exposome_") || (key == "microbiome_open" && containsAny(lower, "exposure", "exposed", "unexposed", "toxicant")),
            allowMicrobiomeBridge = key.startsWith("microbiome_") || key.startsWith("exposome_") && containsAny(lower, "microbiome", "gut bacteria", "gut barrier", "metabolite", "lps", "kynurenine"),
            allowKnownPriorSeeds = key in setOf("covid_interferon", "ebv_sle") || containsAny(lower, "chronic stress", "hpa", "cortisol", "glucocorticoid", "multiple sclerosis", "type 1 diabetes", "ibd", "inflammatory bowel"),
            allowGenericBootstrapFallback = false
        )
    }

    fun lockedCorpus(intent: GTIMResearchIntentObjectV255, contract: DownstreamTopicContractReportV2746 = fromIntent(intent)): String {
        val fields = listOf(
            "TOPIC_KEY=${contract.topicKey}",
            intent.sourceText,
            intent.diseasePhenotype.joinToString(" "),
            intent.triggerExposure.joinToString(" "),
            intent.pathway.joinToString(" "),
            intent.cellTissue.joinToString(" "),
            intent.assayType.joinToString(" "),
            intent.comparatorWanted.joinToString(" "),
            contract.anchorTerms.joinToString(" ")
        )
        return fields.filter { it.isNotBlank() }.joinToString(" | ")
    }

    fun briefRelationshipCorpus(userTopic: String, parsedIntent: String, strongestRoute: String, topicSafeQuery: String): String {
        val contract = fromText(listOf(userTopic, parsedIntent, topicSafeQuery).joinToString(" "))
        return listOf(
            "TOPIC_KEY=${contract.topicKey}",
            userTopic,
            parsedIntent,
            strongestRoute.takeIf { allowsText(it, contract) }.orEmpty(),
            topicSafeQuery,
            contract.anchorTerms.joinToString(" ")
        ).filter { it.isNotBlank() }.joinToString(" | ")
    }

    fun filterRepositoryQueries(
        queries: List<GTIMRepositoryQueryV255>,
        contract: DownstreamTopicContractReportV2746
    ): List<GTIMRepositoryQueryV255> {
        if (!contract.active) return queries
        val alwaysKeep = setOf("Topic-Specific Route Builder", "PubMed Data Availability", "Contradiction / null-result search", "Forced Closure Safety Guard", "Comparative Disease Pathways")
        return queries.filter { query ->
            query.repository in alwaysKeep || allowsText(query.repository + " " + query.purpose + " " + query.query + " " + query.metadataTargets.joinToString(" "), contract)
        }
    }

    fun filterQuerySeeds(seeds: List<String>, contract: DownstreamTopicContractReportV2746): List<String> {
        if (!contract.active) return seeds
        return seeds.filter { allowsText(it, contract) }.distinct()
    }

    fun filterSeedHandles(handles: List<String>, contract: DownstreamTopicContractReportV2746): List<String> {
        if (!contract.active) return handles.distinct()
        return handles.filter { handle ->
            val normalized = handle.replace(" ", "").lowercase(Locale.US)
            when (contract.topicKey) {
                "covid_interferon" -> normalized.contains("gse152202") || normalized.contains("gse166552") || normalized.contains("gse152418") || normalized.contains("gse157103") || normalized.contains("covid") || normalized.contains("sars")
                "allergy_type2" -> normalized.contains("gse250594") || normalized.contains("allergy") || normalized.contains("ige")
                "microbiome_depression", "microbiome_anxiety", "microbiome_open" -> normalized.contains("microbiome") || normalized.contains("gut") || normalized.contains("kynurenine") || normalized.contains("tryptophan") || normalized.contains("depression") || normalized.contains("anxiety")
                "longevity_aging" -> normalized.contains("aging") || normalized.contains("longevity") || normalized.contains("senescence")
                else -> allowsText(handle, contract)
            }
        }.distinct()
    }

    fun allowsText(text: String, contract: DownstreamTopicContractReportV2746): Boolean {
        if (!contract.active || text.isBlank()) return true
        val lower = text.lowercase(Locale.US)
        val toxicantHit = containsAny(lower, *toxicantTerms.toTypedArray()) || containsAny(lower, "exposome", "toxicant")
        val stressPriorHit = containsAny(lower, *stressPriorTerms.toTypedArray()) || containsAny(lower, "pmid 22114171", "10.1126/science.1211719", "pmid 22474371", "10.1073/pnas.1118355109")
        val pesticideHit = containsAny(lower, "pesticide", "pesticides", "glyphosate", "organophosphate", "pesticides_gut_immunity", "pesticide_gut_barrier")
        val plasticHit = containsAny(lower, "pfas", "bpa", "phthalate", "microplastic", "plastic_microplastic")
        val heavyMetalHit = containsAny(lower, "heavy metal", "water_heavy_metal", "lead poisoning", "blood lead", "lead exposure", "arsenic", "cadmium", "mercury")
        val allergyHit = containsAny(lower, *allergyTerms.toTypedArray())
        val covidHit = containsAny(lower, *covidTerms.toTypedArray())
        val microbiomeHit = containsAny(lower, *microbiomeTerms.toTypedArray())
        return when (contract.topicKey) {
            "covid_interferon" -> {
                if ((pesticideHit || plasticHit || heavyMetalHit) && !covidHit) return false
                if (allergyHit && !covidHit) return false
                if (microbiomeHit && !covidHit && !lower.contains("long covid")) return false
                true
            }
            "allergy_type2" -> {
                if ((pesticideHit || plasticHit || heavyMetalHit || stressPriorHit) && !allergyHit) return false
                if (covidHit && !allergyHit) return false
                if (microbiomeHit && !allergyHit && !lower.contains("allergen")) return false
                true
            }
            "microbiome_depression" -> {
                if ((pesticideHit || plasticHit || heavyMetalHit || stressPriorHit) && !containsAny(lower, "depression", "microbiome", "gut bacteria", "kynurenine", "tryptophan")) return false
                true
            }
            "microbiome_anxiety", "microbiome_open" -> {
                if ((pesticideHit || plasticHit || heavyMetalHit || stressPriorHit) && !microbiomeHit) return false
                true
            }
            "longevity_aging" -> {
                if (toxicantHit || stressPriorHit || allergyHit || covidHit) return containsAny(lower, *longevityTerms.toTypedArray())
                true
            }
            "exposome_pesticide" -> !plasticHit && !heavyMetalHit || pesticideHit
            "exposome_plastic" -> !pesticideHit && !heavyMetalHit || plasticHit
            "exposome_heavy_metal" -> !pesticideHit && !plasticHit || heavyMetalHit
            "exposome_livestock_antibiotic" -> containsAny(lower, "livestock", "poultry", "antibiotic", "resistome") || !toxicantHit
            else -> {
                if (stressPriorHit && !contract.allowKnownPriorSeeds) return false
                true
            }
        }
    }

    private fun anchorsFor(key: String, lower: String): List<String> {
        val base = when (key) {
            "covid_interferon" -> listOf("covid", "sars-cov-2", "long covid", "pasc", "interferon", "pbmc", "il-6", "tnf")
            "allergy_type2" -> listOf("allergy", "allergies", "allergic", "ige", "mast cell", "eosinophil", "il-4", "il-5", "il-13", "type 2")
            "microbiome_depression" -> listOf("microbiome", "gut bacteria", "depression", "tryptophan", "kynurenine", "il-6", "tnf")
            "microbiome_anxiety" -> listOf("microbiome", "anxiety", "tryptophan", "kynurenine", "gaba", "il-6")
            "longevity_aging" -> longevityTerms
            "hantavirus" -> listOf("hantavirus", "hfrs", "hcps", "endothelial", "interferon", "cytokine")
            "exposome_pesticide" -> listOf("pesticide", "glyphosate", "organophosphate", "exposed", "unexposed", "cytokine")
            "exposome_plastic" -> listOf("microplastic", "pfas", "bpa", "phthalate", "endocrine", "immune")
            "exposome_heavy_metal" -> listOf("heavy metal", "lead exposure", "blood lead", "arsenic", "cadmium", "mercury")
            "exposome_livestock_antibiotic" -> listOf("livestock", "poultry", "antibiotic", "resistome", "microbiome")
            "ebv_sle" -> listOf("ebv", "sle", "lupus", "interferon", "b-cell")
            else -> lower.split(Regex("[^a-z0-9+-]+"))
                .filter { it.length >= 4 && it !in setOf("immune", "human", "data", "dataset", "comparator", "research", "route") }
                .take(12)
        }
        return base.distinct()
    }

    private fun allowedFamiliesFor(key: String): List<String> = when (key) {
        "covid_interferon" -> listOf("topic", "covid", "interferon", "cytokine", "pbmc", "known_covid_matrix")
        "allergy_type2" -> listOf("topic", "allergy", "ige", "mast_cell", "eosinophil", "type2")
        "microbiome_depression" -> listOf("topic", "microbiome", "depression", "metabolite", "cytokine")
        "microbiome_anxiety" -> listOf("topic", "microbiome", "anxiety", "metabolite", "cytokine")
        "longevity_aging" -> listOf("topic", "longevity", "aging", "immunosenescence", "inflammaging")
        else -> listOf("topic", key)
    }

    private fun blockedFamiliesFor(key: String): List<String> = when (key) {
        "covid_interferon" -> listOf("pesticide", "plastic", "heavy_metal", "allergy_prior", "microbiome_depression_template")
        "allergy_type2" -> listOf("pesticide", "plastic", "heavy_metal", "stress_hpa_prior", "covid_template")
        "microbiome_depression" -> listOf("pesticide_template_unless_requested", "plastic_template_unless_requested", "stress_hpa_prior")
        "longevity_aging" -> listOf("pesticide", "plastic", "heavy_metal", "stress_hpa_prior", "covid_template", "allergy_template")
        else -> emptyList()
    }

    private fun containsAny(text: String, vararg needles: String): Boolean = needles.any { needle ->
        val n = needle.lowercase(Locale.US)
        if (n.contains(' ') || n.contains('-')) text.contains(n) else Regex("(^|[^a-z0-9])${Regex.escape(n)}([^a-z0-9]|$)").containsMatchIn(text)
    }
}
