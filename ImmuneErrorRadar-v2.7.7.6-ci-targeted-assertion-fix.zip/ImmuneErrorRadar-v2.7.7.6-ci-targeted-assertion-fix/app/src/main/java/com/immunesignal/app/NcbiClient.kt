package com.immunesignal.app

import java.io.IOException
import java.net.SocketTimeoutException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.util.concurrent.TimeUnit

class NcbiRateLimitException(message: String) : IOException(message)
class NcbiHttpException(val statusCode: Int, message: String) : IOException(message)

/**
 * NCBI HTTP client v1.10.2.
 *
 * The previous implementation used raw HttpURLConnection inside ResearchAutopilot.
 * This client centralizes User-Agent, rate limit, retry, timeout, and error mapping
 * so research logic cannot silently treat HTTP errors as successful evidence.
 */
class NcbiClient(
    private val contactEmail: String,
    private val apiKey: String?
) {
    private val limiter = NcbiRateLimiter(hasApiKey = !apiKey.isNullOrBlank())

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .callTimeout(25, TimeUnit.SECONDS)
        .addInterceptor(NcbiHeaderInterceptor(contactEmail))
        .build()

    suspend fun getWithRetry(urlText: String, attempts: Int = 3): String {
        var lastError: Exception? = null
        var backoffMillis = 350L
        repeat(attempts) { attemptIndex ->
            try {
                return get(urlText)
            } catch (error: Exception) {
                lastError = error
                val shouldRetry = error is NcbiRateLimitException || error is SocketTimeoutException || error is IOException
                if (attemptIndex < attempts - 1 && shouldRetry) {
                    delay(if (error is NcbiRateLimitException) backoffMillis.coerceAtLeast(1500L) else backoffMillis)
                    backoffMillis = (backoffMillis * 2).coerceAtMost(4000L)
                } else {
                    throw error
                }
            }
        }
        throw lastError ?: IOException("NCBI request failed without captured error")
    }

    private suspend fun get(urlText: String): String = withContext(Dispatchers.IO) {
        limiter.awaitPermit()
        val request = Request.Builder().url(urlText).get().build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            when {
                response.code == 429 -> throw NcbiRateLimitException("HTTP 429 from NCBI; retry after cooldown. Body=${body.take(180)}")
                !response.isSuccessful -> throw NcbiHttpException(response.code, "HTTP ${response.code} from NCBI. Body=${body.take(180)}")
                else -> body
            }
        }
    }
}

class NcbiRateLimiter(private val hasApiKey: Boolean) {
    private val lock = Any()
    private var lastRequestAtMillis: Long = 0L

    suspend fun awaitPermit() {
        val intervalMillis = if (hasApiKey) 110L else 360L
        var waitMillis = 0L
        synchronized(lock) {
            val now = System.currentTimeMillis()
            val earliest = lastRequestAtMillis + intervalMillis
            if (now < earliest) waitMillis = earliest - now
            lastRequestAtMillis = maxOf(now, earliest)
        }
        if (waitMillis > 0L) delay(waitMillis)
    }
}

private class NcbiHeaderInterceptor(private val contactEmail: String) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request().newBuilder()
            .header("User-Agent", "ImmuneErrorRadar/${EngineRuntimeStatus.ACTIVE_ENGINE_VERSION} (PrivateResearch; contact=$contactEmail)")
            .header("Accept", "application/json,text/plain;q=0.9,*/*;q=0.1")
            .build()
        return chain.proceed(request)
    }
}
