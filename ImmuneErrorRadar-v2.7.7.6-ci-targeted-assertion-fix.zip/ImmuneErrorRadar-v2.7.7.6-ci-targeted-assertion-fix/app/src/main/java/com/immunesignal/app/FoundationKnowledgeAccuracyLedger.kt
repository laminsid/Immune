package com.immunesignal.app

import android.content.Context
import org.json.JSONObject
import java.io.File

/**
 * FoundationKnowledgeAccuracyLedger: Tracks how well each axis predicts reality
 * 
 * Measurements:
 * - correctRoutePredictions: "This axis was suggested, route succeeded"
 * - incorrectRoutePredictions: "This axis was suggested, route failed"
 * - offRoutePreventions: "This axis correctly blocked a wrong route"
 * - falseBlocks: "This axis blocked data that later proved useful"
 * - unresolvedConflicts: "This axis created patterns we couldn't resolve"
 * 
 * Purpose: Detect when foundation knowledge needs updating
 */

class FoundationKnowledgeAccuracyLedger(
    private val context: Context,
    private val filename: String = "foundation_knowledge_accuracy_ledger.json"
) {

    private val accuracyRecords = mutableMapOf<String, FoundationAxisAccuracy>()
    private val file = File(context.filesDir, filename)

    init {
        loadFromStorage()
    }

    /**
     * Record a successful prediction
     * 
     * @param axisId: which axis made the prediction
     * @param wasHypothesisUpgrade: did we promote to hypothesis level?
     */
    fun recordCorrectPrediction(axisId: String, wasHypothesisUpgrade: Boolean = false) {
        val record = accuracyRecords.getOrPut(axisId) {
            FoundationAxisAccuracy(axisId = axisId)
        }

        record.totalUses++
        record.correctRoutePredictions++

        if (wasHypothesisUpgrade) {
            record.successfulHypothesisUpgrades++
        }

        record.confidenceLevel = calculateConfidence(record)
        saveToStorage()
    }

    /**
     * Record a failed prediction
     * 
     * @param axisId: which axis made the prediction
     * @param reasonForFailure: why did it fail?
     */
    fun recordIncorrectPrediction(axisId: String, reasonForFailure: String = "") {
        val record = accuracyRecords.getOrPut(axisId) {
            FoundationAxisAccuracy(axisId = axisId)
        }

        record.totalUses++
        record.incorrectRoutePredictions++

        if (reasonForFailure.isNotEmpty()) {
            record.failureReasons.add(reasonForFailure)
        }

        record.confidenceLevel = calculateConfidence(record)
        saveToStorage()
    }

    /**
     * Record successful off-route prevention
     * 
     * @param axisId: axis that correctly blocked this
     * @param blockedDatasetId: what dataset did it prevent us from pursuing?
     */
    fun recordOffRoutePrevention(axisId: String, blockedDatasetId: String = "") {
        val record = accuracyRecords.getOrPut(axisId) {
            FoundationAxisAccuracy(axisId = axisId)
        }

        record.offRoutePreventions++

        if (blockedDatasetId.isNotEmpty()) {
            record.successfulBlocks.add(blockedDatasetId)
        }

        record.confidenceLevel = calculateConfidence(record)
        saveToStorage()
    }

    /**
     * Record false positive: axis blocked useful data
     * 
     * @param axisId: which axis made the mistake
     * @param blockedDatasetId: what was wrongly rejected?
     */
    fun recordFalseBlock(axisId: String, blockedDatasetId: String = "") {
        val record = accuracyRecords.getOrPut(axisId) {
            FoundationAxisAccuracy(axisId = axisId)
        }

        record.falseBlocks++

        if (blockedDatasetId.isNotEmpty()) {
            record.wronglyBlockedDatasets.add(blockedDatasetId)
        }

        record.confidenceLevel = calculateConfidence(record)
        saveToStorage()
    }

    /**
     * Record unresolved conflict
     * 
     * @param axisId: axis involved in conflict
     * @param conflictDescription: what was the issue?
     */
    fun recordUnresolvedConflict(axisId: String, conflictDescription: String = "") {
        val record = accuracyRecords.getOrPut(axisId) {
            FoundationAxisAccuracy(axisId = axisId)
        }

        record.unresolvedConflicts++

        if (conflictDescription.isNotEmpty()) {
            record.conflictPatterns.add(conflictDescription)
        }

        record.confidenceLevel = calculateConfidence(record)
        saveToStorage()
    }

    /**
     * Get historical boost for an axis (used in ranking)
     * 
     * @return adjustment to add to axis score (positive if accurate, negative if inaccurate)
     */
    fun getAccuracyBoost(axisId: String): Float {
        val record = accuracyRecords[axisId] ?: return 0f

        // Boost based on success rate
        val successRate = if (record.totalUses > 0) {
            record.correctRoutePredictions.toFloat() / record.totalUses
        } else {
            0.5f  // Neutral for untested axes
        }

        // Bonus for successful blocks
        val blockBonus = if (record.totalUses > 0) {
            (record.offRoutePreventions.toFloat() / record.totalUses) * 0.10f
        } else {
            0f
        }

        // Penalty for false blocks
        val blockPenalty = if (record.totalUses > 0) {
            (record.falseBlocks.toFloat() / record.totalUses) * 0.10f
        } else {
            0f
        }

        return ((successRate - 0.5f) * 0.10f) + blockBonus - blockPenalty
    }

    /**
     * Get overall confidence in an axis
     */
    fun getAxisConfidence(axisId: String): String {
        return accuracyRecords[axisId]?.confidenceLevel ?: "UNPROVEN"
    }

    /**
     * Check if axis has too many false blocks
     */
    fun hasTooManyFalseBlocks(axisId: String, threshold: Int = 3): Boolean {
        val record = accuracyRecords[axisId] ?: return false
        return record.falseBlocks >= threshold
    }

    /**
     * Check if axis has recurring conflict patterns
     */
    fun hasRecurringConflictPatterns(axisId: String): List<String> {
        val record = accuracyRecords[axisId] ?: return emptyList()

        val patterns = record.conflictPatterns.groupingBy { it }.eachCount()
        return patterns.filter { it.value >= 2 }.keys.toList()
    }

    /**
     * Get detailed report of axis accuracy
     */
    fun getAxisReport(axisId: String): String {
        val record = accuracyRecords[axisId]
            ?: return "Axis $axisId has no recorded history"

        val sb = StringBuilder()
        sb.append("=== AXIS ACCURACY REPORT ===\n")
        sb.append("Axis: $axisId\n")
        sb.append("Total Uses: ${record.totalUses}\n")
        sb.append("Correct Predictions: ${record.correctRoutePredictions}\n")
        sb.append("Incorrect Predictions: ${record.incorrectRoutePredictions}\n")
        sb.append("Off-Route Preventions: ${record.offRoutePreventions}\n")
        sb.append("False Blocks: ${record.falseBlocks}\n")
        sb.append("Unresolved Conflicts: ${record.unresolvedConflicts}\n")
        sb.append("Confidence Level: ${record.confidenceLevel}\n")

        if (record.failureReasons.isNotEmpty()) {
            sb.append("\nCommon Failure Reasons:\n")
            record.failureReasons.take(3).forEach { reason ->
                sb.append("  - $reason\n")
            }
        }

        if (record.conflictPatterns.isNotEmpty()) {
            sb.append("\nRecurring Conflict Patterns:\n")
            val patterns = record.conflictPatterns.groupingBy { it }.eachCount()
            patterns.filter { it.value >= 2 }.forEach { (pattern, count) ->
                sb.append("  - $pattern (×$count)\n")
            }
        }

        val successRate = if (record.totalUses > 0) {
            String.format("%.1f%%", (record.correctRoutePredictions.toFloat() / record.totalUses) * 100)
        } else {
            "N/A"
        }

        sb.append("\nSuccess Rate: $successRate\n")
        sb.append("Last Updated: ${record.lastUpdatedMillis}\n")

        return sb.toString()
    }

    /**
     * Get all axes sorted by performance
     */
    fun getAccuracyRanking(): List<AxisAccuracyRank> {
        return accuracyRecords.values.map { record ->
            val successRate = if (record.totalUses > 0) {
                record.correctRoutePredictions.toFloat() / record.totalUses
            } else {
                0.5f
            }

            AxisAccuracyRank(
                axisId = record.axisId,
                totalUses = record.totalUses,
                successRate = successRate,
                confidenceLevel = record.confidenceLevel,
                performanceScore = successRate - (record.falseBlocks.toFloat() / record.totalUses.coerceAtLeast(1)) * 0.2f
            )
        }.sortedByDescending { it.performanceScore }
    }

    /**
     * Calculate confidence level from accuracy data
     */
    private fun calculateConfidence(record: FoundationAxisAccuracy): String {
        if (record.totalUses < 3) return "UNPROVEN"

        val successRate = record.correctRoutePredictions.toFloat() / record.totalUses
        val falseBlockRate = record.falseBlocks.toFloat() / record.totalUses

        return when {
            successRate >= 0.80f && falseBlockRate < 0.10f -> "HIGH"
            successRate >= 0.65f && falseBlockRate < 0.20f -> "MEDIUM"
            successRate >= 0.50f && falseBlockRate < 0.30f -> "MEDIUM"
            successRate < 0.40f || falseBlockRate > 0.30f -> "LOW"
            else -> "UNCERTAIN"
        }
    }

    /**
     * Save accuracy ledger to storage
     */
    fun saveToStorage() {
        try {
            val json = JSONObject()
            val axesArray = org.json.JSONArray()

            for (record in accuracyRecords.values) {
                val axisObj = JSONObject()
                axisObj.put("axisId", record.axisId)
                axisObj.put("totalUses", record.totalUses)
                axisObj.put("correctRoutePredictions", record.correctRoutePredictions)
                axisObj.put("incorrectRoutePredictions", record.incorrectRoutePredictions)
                axisObj.put("offRoutePreventions", record.offRoutePreventions)
                axisObj.put("falseBlocks", record.falseBlocks)
                axisObj.put("unresolvedConflicts", record.unresolvedConflicts)
                axisObj.put("confidenceLevel", record.confidenceLevel)
                axisObj.put("lastUpdatedMillis", record.lastUpdatedMillis)

                val failureReasonsArray = org.json.JSONArray(record.failureReasons)
                axisObj.put("failureReasons", failureReasonsArray)

                val conflictPatternsArray = org.json.JSONArray(record.conflictPatterns)
                axisObj.put("conflictPatterns", conflictPatternsArray)

                axesArray.put(axisObj)
            }

            json.put("axes", axesArray)
            json.put("lastSync", System.currentTimeMillis())

            file.writeText(json.toString(2))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Load accuracy ledger from storage
     */
    private fun loadFromStorage() {
        try {
            if (!file.exists()) return

            val json = JSONObject(file.readText())
            val axesArray = json.optJSONArray("axes") ?: return

            for (i in 0 until axesArray.length()) {
                val axisObj = axesArray.getJSONObject(i)

                val failureReasons = mutableListOf<String>()
                axisObj.optJSONArray("failureReasons")?.let {
                    for (j in 0 until it.length()) {
                        failureReasons.add(it.getString(j))
                    }
                }

                val conflictPatterns = mutableListOf<String>()
                axisObj.optJSONArray("conflictPatterns")?.let {
                    for (j in 0 until it.length()) {
                        conflictPatterns.add(it.getString(j))
                    }
                }

                val record = FoundationAxisAccuracy(
                    axisId = axisObj.getString("axisId"),
                    totalUses = axisObj.getInt("totalUses"),
                    correctRoutePredictions = axisObj.getInt("correctRoutePredictions"),
                    incorrectRoutePredictions = axisObj.getInt("incorrectRoutePredictions"),
                    offRoutePreventions = axisObj.getInt("offRoutePreventions"),
                    falseBlocks = axisObj.getInt("falseBlocks"),
                    unresolvedConflicts = axisObj.getInt("unresolvedConflicts"),
                    confidenceLevel = axisObj.getString("confidenceLevel"),
                    lastUpdatedMillis = axisObj.getLong("lastUpdatedMillis"),
                    failureReasons = failureReasons,
                    conflictPatterns = conflictPatterns
                )

                accuracyRecords[record.axisId] = record
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

// ============ DATA CLASSES ============

data class FoundationAxisAccuracy(
    val axisId: String,
    var totalUses: Int = 0,
    var correctRoutePredictions: Int = 0,
    var incorrectRoutePredictions: Int = 0,
    var offRoutePreventions: Int = 0,
    var falseBlocks: Int = 0,
    var unresolvedConflicts: Int = 0,
    var successfulHypothesisUpgrades: Int = 0,
    var confidenceLevel: String = "UNPROVEN",
    var lastUpdatedMillis: Long = System.currentTimeMillis(),
    val failureReasons: MutableList<String> = mutableListOf(),
    val successfulBlocks: MutableList<String> = mutableListOf(),
    val wronglyBlockedDatasets: MutableList<String> = mutableListOf(),
    val conflictPatterns: MutableList<String> = mutableListOf()
)

data class AxisAccuracyRank(
    val axisId: String,
    val totalUses: Int,
    val successRate: Float,
    val confidenceLevel: String,
    val performanceScore: Float
)
