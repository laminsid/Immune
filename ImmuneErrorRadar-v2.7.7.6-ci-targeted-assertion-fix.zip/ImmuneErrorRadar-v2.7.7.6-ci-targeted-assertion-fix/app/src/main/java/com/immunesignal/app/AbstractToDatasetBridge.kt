package com.immunesignal.app

object AbstractToDatasetBridge {
    const val DATASET_FOUND = "DATASET_FOUND"
    const val DATASET_MENTIONED_BUT_UNRESOLVED = "DATASET_MENTIONED_BUT_UNRESOLVED"
    const val NO_DATASET = "NO_DATASET"
    const val ABSTRACT_ONLY = "ABSTRACT_ONLY"

    fun classify(finding: ResearchFinding, candidates: List<DatasetAccessionCandidate>): String {
        val linked = candidates.filter { it.sourceFindingId == finding.source + ":" + finding.sourceId }
        if (linked.any { it.accession != "DATASET_ACCESSION_UNRESOLVED" }) return DATASET_FOUND
        if (linked.isNotEmpty()) return DATASET_MENTIONED_BUT_UNRESOLVED
        if (finding.sanityFlags.contains("METADATA_ONLY") || finding.sanityFlags.contains("ABSTRACT_FETCH_FAILED")) return ABSTRACT_ONLY
        return NO_DATASET
    }
}
