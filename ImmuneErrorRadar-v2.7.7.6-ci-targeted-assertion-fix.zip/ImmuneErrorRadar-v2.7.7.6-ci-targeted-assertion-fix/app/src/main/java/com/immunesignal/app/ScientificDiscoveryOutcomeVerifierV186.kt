package com.immunesignal.app

import java.util.Locale

/**
 * v1.8.6: post-execution discovery outcome verifier. Token: outcome_verification_discovery_memory.
 *
 * v1.8.5 enforced policy before the next cycle. This layer measures whether the
 * enforced policy actually moved evidence readiness, closed blockers, or merely
 * replayed the same weak route. It is a routing-calibration layer only: it cannot
 * prove biology, diagnosis, treatment, causality, or immune outcome.
 */
data class ScientificOutcomeVerificationSignal(
    val signalId: String,
    val direction: String,
    val weight: Int,
    val evidenceKey: String,
    val explanation: String
)

data class ScientificDiscoveryOutcomeVerifierReport(
    val active: Boolean,
    val version: String,
    val verifierState: String,
    val outcomeScore: Int,
    val policyApplied: Boolean,
    val policySucceeded: Boolean,
    val policyFailed: Boolean,
    val successSignals: List<ScientificOutcomeVerificationSignal>,
    val failureSignals: List<ScientificOutcomeVerificationSignal>,
    val unmetEvidenceKeys: List<String>,
    val resolvedEvidenceKeys: List<String>,
    val routeAdjustment: String,
    val beliefAdjustment: String,
    val nextPolicyAdjustment: String,
    val forcedNextEvidence: List<String>,
    val blockedReplayKeys: List<String>,
    val learningReceipt: String,
    val reportLine: String,
    val claimLimit: String = "outcome_verification_guides_routing_not_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryOutcomeVerifierReport(
            active = false,
            version = "v1.8.6",
            verifierState = "NOT_RUN",
            outcomeScore = 0,
            policyApplied = false,
            policySucceeded = false,
            policyFailed = false,
            successSignals = emptyList(),
            failureSignals = emptyList(),
            unmetEvidenceKeys = emptyList(),
            resolvedEvidenceKeys = emptyList(),
            routeAdjustment = "Run a policy-enforced cycle before outcome verification.",
            beliefAdjustment = "No belief adjustment from outcome verification.",
            nextPolicyAdjustment = "No policy adjustment available.",
            forcedNextEvidence = emptyList(),
            blockedReplayKeys = emptyList(),
            learningReceipt = "No outcome-verification receipt generated.",
            reportLine = "Outcome verifier did not run.",
            claimLimit = "outcome_verification_guides_routing_not_proof"
        )
    }
}

object ScientificDiscoveryOutcomeVerifierEngineV186 {
    fun verify(
        nextCyclePlan: CognitiveNextCyclePlan,
        loopCalibration: CognitiveLoopCalibrationReport,
        executionPolicy: ScientificDiscoveryExecutionPolicyReport,
        stressTest: ScientificDiscoveryStressTestReport,
        decisionMemory: ScientificDiscoveryDecisionReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        datasetForaging: DatasetForagingReport,
        learningOs: LearningOsReport,
        causalReadiness: CausalReadinessReport,
        miniPeerReview: MiniPeerReviewReport
    ): ScientificDiscoveryOutcomeVerifierReport {
        if (!executionPolicy.active && !stressTest.active && !decisionMemory.active && !scientificWeights.active) {
            return ScientificDiscoveryOutcomeVerifierReport.empty()
        }

        val required = normalizeEvidence(
            executionPolicy.forcedEvidenceKeys +
                stressTest.forcedEvidenceKeys +
                decisionMemory.evidenceImpactKeys +
                scientificWeights.decisiveEvidenceDelta +
                miniPeerReview.missingEvidence +
                causalReadiness.blockers
        ).ifEmpty { listOf("minimum_metadata", "outcome_labels", "comparator_control", "time_order") }

        val roots = learningOs.incident.rootCauses.map { it.uppercase(Locale.US) }.toSet()
        val success = mutableListOf<ScientificOutcomeVerificationSignal>()
        val fail = mutableListOf<ScientificOutcomeVerificationSignal>()

        fun addSuccess(id: String, weight: Int, key: String, explanation: String) {
            success += ScientificOutcomeVerificationSignal(id, "IMPROVED", weight.coerceIn(0, 100), key, explanation.take(240))
        }
        fun addFail(id: String, weight: Int, key: String, explanation: String) {
            fail += ScientificOutcomeVerificationSignal(id, "STALLED", weight.coerceIn(0, 100), key, explanation.take(240))
        }

        val parsed = datasetForaging.parsedMetadata
        val hasMetadata = parsed.isNotEmpty()
        val hasOutcome = parsed.any { it.outcomeLabels.isNotEmpty() } || roots.none { it.contains("NO_OUTCOME_LABELS") } && datasetForaging.scoreSeparation.datasetUsabilityScore >= 70
        val hasControl = parsed.any { it.controlLabels.isNotEmpty() } || causalReadiness.level >= 3
        val hasTime = parsed.any { it.timeCourseLabels.isNotEmpty() } || causalReadiness.level >= 2
        val hasHumanPhenotype = parsed.any { it.organism.contains("human", true) && (it.conditionLabels.isNotEmpty() || it.outcomeLabels.isNotEmpty()) }
        val hasContradictionChecked = datasetForaging.sourceFamiliesAttempted.any { it.contains("CONTRADICTION", true) } || stressTest.contradictionPolicy.isNotBlank()
        val hasReplayBlocked = executionPolicy.queryReplayBlocks.isNotEmpty() || nextCyclePlan.consumptionReason == "retired_noop_or_already_satisfied"
        val routeFitTrap = datasetForaging.scoreSeparation.routeFitScore >= 85 && datasetForaging.scoreSeparation.datasetUsabilityScore < 70
        val noOutcomeRoot = roots.any { it.contains("NO_OUTCOME_LABELS") }
        val metadataOnlyRoot = roots.any { it.contains("METADATA_ONLY") } || (datasetForaging.candidates.isNotEmpty() && parsed.isEmpty())

        if (hasMetadata) addSuccess("minimum_metadata_parsed", 18, "minimum_metadata", "At least one candidate reached parsed metadata instead of title/accession-only status.") else addFail("minimum_metadata_missing", 22, "minimum_metadata", "Policy required minimum metadata, but no parsed metadata object is available.")
        if (hasOutcome) addSuccess("outcome_labels_present", 20, "outcome_labels", "Outcome/recovery/severity labels are present or the NO_OUTCOME_LABELS root cause cleared.") else if (required.contains("outcome_labels") || noOutcomeRoot) addFail("outcome_labels_still_missing", 28, "outcome_labels", "Outcome/recovery/severity labels remain the dominant blocker.")
        if (hasControl) addSuccess("control_or_comparator_present", 18, "comparator_control", "Control/comparator readiness is present at metadata or causal-readiness level.") else if (required.contains("comparator_control")) addFail("control_or_comparator_missing", 22, "comparator_control", "Comparator/control evidence is still missing.")
        if (hasTime) addSuccess("time_order_present", 16, "time_order", "Longitudinal/time-order readiness improved.") else if (required.contains("time_order")) addFail("time_order_missing", 20, "time_order", "Temporal ordering remains missing.")
        if (hasHumanPhenotype) addSuccess("human_phenotype_context_present", 12, "human_or_patient_phenotype", "Human/patient phenotype context is present in parsed metadata.")
        if (hasContradictionChecked) addSuccess("contradiction_lane_checked", 10, "falsification_contradiction", "Contradiction/falsification source or policy was invoked.")
        if (hasReplayBlocked) addSuccess("replay_block_enforced", 8, "query_replay_block", "Replay-block or consumed-directive guard prevented silent route inflation.")
        if (routeFitTrap) addFail("route_fit_trap_persisted", 20, "route_cooldown_policy", "High route-fit persists while dataset usability remains below decisive threshold.")
        if (metadataOnlyRoot) addFail("metadata_only_stall_persisted", 18, "minimum_metadata", "Evidence is still metadata/title-heavy and cannot support discovery language.")
        if (loopCalibration.dampenSimilarDirective) addFail("directive_dampened", 12, "directive_calibration", "Cognitive loop calibration dampened a similar directive.")
        if (loopCalibration.rewardSimilarDirective) addSuccess("directive_rewarded", 12, "directive_calibration", "Cognitive loop calibration rewarded a similar directive.")

        val rawScore = 50 + success.sumOf { it.weight } - fail.sumOf { it.weight }
        val score = rawScore.coerceIn(0, 100)
        val applied = nextCyclePlan.active || nextCyclePlan.directiveConsumed || executionPolicy.policyActions.isNotEmpty()
        val succeeded = applied && score >= 70 && fail.none { it.weight >= 24 }
        val failed = applied && (score <= 45 || fail.any { it.signalId in setOf("outcome_labels_still_missing", "route_fit_trap_persisted") && it.weight >= 20 })
        val state = when {
            !applied -> "BOOTSTRAP_NOT_APPLIED"
            succeeded -> "POLICY_VALIDATED"
            failed -> "POLICY_FAILED_ADJUST_ROUTE"
            fail.isNotEmpty() && success.isNotEmpty() -> "MIXED_PARTIAL_PROGRESS"
            fail.isNotEmpty() -> "POLICY_STALLED"
            else -> "POLICY_MONITOR"
        }
        val unmet = required.filter { key -> !isResolved(key, success) }.distinct().take(12)
        val resolved = success.map { it.evidenceKey }.distinct().take(12)
        val blockedReplay = (executionPolicy.queryReplayBlocks + fail.map { "outcome_verifier_block_${it.evidenceKey}" }).distinct().take(12)
        val forcedNext = normalizeEvidence(unmet + fail.map { it.evidenceKey } + executionPolicy.forcedEvidenceKeys).take(12)
        val routeAdjustment = when {
            failed && routeFitTrap -> "Cool down the current route and force parser/control/outcome search before any similar route-fit query."
            failed -> "Do not replay the same policy unchanged; reroute through the first unmet decisive evidence key: ${unmet.firstOrNull() ?: "minimum_metadata"}."
            succeeded -> "Reward similar directive shape, but keep evidence gates and claim limits active."
            else -> "Keep policy active for one more cycle, but require a measurable evidence-key delta."
        }
        val beliefAdjustment = when {
            failed -> "Weaken or archive beliefs depending on unresolved keys: ${unmet.take(4).joinToString(", ").ifBlank { "none" }}."
            succeeded -> "Allow only bounded strengthening of beliefs directly linked to resolved evidence keys: ${resolved.take(4).joinToString(", ").ifBlank { "none" }}."
            else -> "Keep beliefs as mutable priors; do not strengthen without resolved evidence keys."
        }
        val nextPolicyAdjustment = when {
            unmet.contains("outcome_labels") -> "Force outcome/recovery/severity/endpoint labels before any broad mechanism route."
            unmet.contains("comparator_control") -> "Force comparator/control/negative-control terms before causal language."
            unmet.contains("time_order") -> "Force longitudinal/serial/follow-up/time-course terms before mechanism direction."
            failed -> "Escalate to falsification lane and route cooldown."
            else -> "Continue guarded execution with replay-blocks active."
        }
        val receipt = "Outcome verification v1.8.6: $state score=$score/100; resolved=${resolved.take(3).joinToString("/").ifBlank { "none" }}; unmet=${unmet.take(3).joinToString("/").ifBlank { "none" }}."
        return ScientificDiscoveryOutcomeVerifierReport(
            active = true,
            version = "v1.8.6-outcome-verification-discovery-memory",
            verifierState = state,
            outcomeScore = score,
            policyApplied = applied,
            policySucceeded = succeeded,
            policyFailed = failed,
            successSignals = success.sortedByDescending { it.weight }.take(10),
            failureSignals = fail.sortedByDescending { it.weight }.take(10),
            unmetEvidenceKeys = unmet,
            resolvedEvidenceKeys = resolved,
            routeAdjustment = routeAdjustment,
            beliefAdjustment = beliefAdjustment,
            nextPolicyAdjustment = nextPolicyAdjustment,
            forcedNextEvidence = forcedNext,
            blockedReplayKeys = blockedReplay,
            learningReceipt = receipt,
            reportLine = "$receipt Next adjustment: ${nextPolicyAdjustment.take(180)}",
            claimLimit = "outcome_verification_guides_routing_not_proof"
        )
    }

    private fun isResolved(key: String, success: List<ScientificOutcomeVerificationSignal>): Boolean {
        val normalized = normalizeKey(key)
        return success.any { normalizeKey(it.evidenceKey) == normalized || normalizeKey(it.signalId).contains(normalized) }
    }

    private fun normalizeEvidence(items: List<String>): List<String> = items.map { evidenceKey(it) }
        .filter { it.isNotBlank() && it != "none" && it != "unknown" }
        .distinct()

    private fun evidenceKey(text: String): String {
        val lower = text.lowercase(Locale.US)
        return when {
            lower.contains("outcome") || lower.contains("recovery") || lower.contains("severity") || lower.contains("endpoint") -> "outcome_labels"
            lower.contains("time") || lower.contains("longitudinal") || lower.contains("serial") || lower.contains("follow") || lower.contains("baseline") -> "time_order"
            lower.contains("control") || lower.contains("comparator") || lower.contains("placebo") || lower.contains("negative") -> "comparator_control"
            lower.contains("metadata") || lower.contains("sample") || lower.contains("accession") || lower.contains("license") -> "minimum_metadata"
            lower.contains("replication") || lower.contains("validation") || lower.contains("repeat") -> "replication_validation"
            lower.contains("contradiction") || lower.contains("falsification") || lower.contains("null") || lower.contains("failed") -> "falsification_contradiction"
            lower.contains("human") || lower.contains("patient") || lower.contains("clinical") || lower.contains("phenotype") -> "human_or_patient_phenotype"
            lower.contains("route") || lower.contains("cooldown") -> "route_cooldown_policy"
            lower.contains("replay") -> "query_replay_block"
            lower.contains("belief") || lower.contains("burial") || lower.contains("archive") -> "belief_burial_policy"
            lower.contains("artifact") || lower.contains("confound") || lower.contains("batch") || lower.contains("assay") -> "artifact_confounder_control"
            else -> normalizeKey(text).take(80)
        }
    }

    private fun normalizeKey(text: String): String = text.lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
}
