package com.immunesignal.app

/**
 * v1.10.5: First safe extraction boundary for ResearchAutopilot.runCycle.
 *
 * This does not move the heavy logic yet. It records explicit phase ownership and
 * handoff rules so future refactors can move one stage at a time without changing
 * behavior or weakening the search locks introduced in v1.10.3/v1.10.4.
 */
enum class ResearchCyclePhaseName {
    PLAN,
    DATASET_FORAGING,
    SEARCH,
    REASON,
    PERSIST
}

data class ResearchCyclePhaseBoundary(
    val phase: ResearchCyclePhaseName,
    val owner: String,
    val inputContract: List<String>,
    val outputContract: List<String>,
    val lockInvariant: String
)

data class ResearchCyclePhaseSpineReport(
    val state: String,
    val boundaryCount: Int,
    val dominantInvariant: String,
    val nextExtractionTarget: String,
    val boundaries: List<ResearchCyclePhaseBoundary>
) {
    val summary: String = "$state; boundaries=$boundaryCount; next=$nextExtractionTarget"
}

object ResearchCyclePhaseSpine {
    fun build(): ResearchCyclePhaseSpineReport {
        val boundaries = listOf(
            ResearchCyclePhaseBoundary(
                phase = ResearchCyclePhaseName.PLAN,
                owner = "ResearchSearchDirectiveResolver",
                inputContract = listOf("recentReports", "closureQueries", "linkedSpine", "momentum", "baseLimits"),
                outputContract = listOf("priorDirective", "queryBudget", "broadSearchLock"),
                lockInvariant = "A higher-priority prior lock must not be weakened by the normal planner."
            ),
            ResearchCyclePhaseBoundary(
                phase = ResearchCyclePhaseName.DATASET_FORAGING,
                owner = "DirectDatasetSourceRouter + DatasetFirstForager",
                inputContract = listOf("priorDirective", "hypothesisShards", "failureMemory", "seenIds"),
                outputContract = listOf("datasetForagingReport", "sameCycleClosureSignal"),
                lockInvariant = "Dataset-first foraging cannot run when the prior directive blocks broad search."
            ),
            ResearchCyclePhaseBoundary(
                phase = ResearchCyclePhaseName.SEARCH,
                owner = "ResearchSearchDirectiveResolver + NcbiClient",
                inputContract = listOf("postForagerDirective", "queryBatch", "rateLimit", "deadline"),
                outputContract = listOf("executedQueries", "findings", "runtimeDiagnostics"),
                lockInvariant = "Offline-only or narrow directives must not execute broad/failover queries."
            ),
            ResearchCyclePhaseBoundary(
                phase = ResearchCyclePhaseName.REASON,
                owner = "Evidence/Reasoning engines",
                inputContract = listOf("findings", "datasetMetadata", "evidenceObjects", "runtimeDiagnostics"),
                outputContract = listOf("learningOs", "graph", "momentum", "qualityGate", "runbook"),
                lockInvariant = "Reasoning may guide routing, but cannot upgrade biology without evidence closure."
            ),
            ResearchCyclePhaseBoundary(
                phase = ResearchCyclePhaseName.PERSIST,
                owner = "ResearchKnowledgeStore",
                inputContract = listOf("reportJson", "findings", "ledgers"),
                outputContract = listOf("jsonlRecords", "deduplicatedFindings", "nextCycleMemory"),
                lockInvariant = "Persistence must be append-first, bounded, and reject malformed JSONL lines visibly."
            )
        )
        return ResearchCyclePhaseSpineReport(
            state = "PHASE_BOUNDARIES_DECLARED",
            boundaryCount = boundaries.size,
            dominantInvariant = "Search locks govern phase handoff until evidence closure or explicit archive.",
            nextExtractionTarget = "Extract PLAN into a small class after CI confirms v1.10.5 store tests.",
            boundaries = boundaries
        )
    }
}
