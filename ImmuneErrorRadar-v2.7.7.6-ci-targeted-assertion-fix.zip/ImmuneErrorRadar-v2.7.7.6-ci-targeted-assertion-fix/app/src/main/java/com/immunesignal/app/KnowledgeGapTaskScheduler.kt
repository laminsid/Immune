package com.immunesignal.app

data class KnowledgeGapTask(
    val gapId: String,
    val priority: Int,
    val targetQuery: String,
    val maxAttemptsBeforeDeprioritize: Int = 3,
    val attemptsToDate: Int = 0,
    val claimLimit: String = KnowledgeGapTaskScheduler.CLAIM_LIMIT
)

/** v1.10.21: converts gap-miner opportunities into explicit future research tasks. */
object KnowledgeGapTaskScheduler {
    const val CLAIM_LIMIT = "knowledge_gap_task_routing_only_not_biological_proof"

    fun build(gapMiner: ScientificDiscoveryGapMinerReport): List<KnowledgeGapTask> {
        if (!gapMiner.active) return emptyList()
        return gapMiner.latentOpportunities.map { opportunity ->
            KnowledgeGapTask(
                gapId = opportunity.opportunityId,
                priority = opportunity.priority,
                targetQuery = opportunity.probeQuery,
                maxAttemptsBeforeDeprioritize = 3,
                attemptsToDate = 0
            )
        }.sortedByDescending { it.priority }.take(8)
    }
}
