package com.immunesignal.app

import java.io.IOException

/**
 * v1.10.7: extracted network-search execution stage.
 *
 * This is deliberately a small behavioral-preserving extraction from
 * ResearchAutopilot.runCycle. It owns PubMed query execution, duplicate
 * filtering, typed runtime diagnostics, deadline/stop handling, and runtime
 * failover query construction. It does not rank evidence and it does not make
 * biological claims.
 */
data class ResearchCycleSearchStageResult(
    val findings: List<ResearchFinding>,
    val executedQueries: List<ResearchQuery>,
    val executedQueryIds: Set<String>,
    val repeatedSkipped: Int,
    val runtimeDiagnostics: List<String>,
    val stopped: Boolean,
    val stopReason: String
)

data class ResearchCycleRuntimeFailoverPlan(
    val shouldRun: Boolean,
    val queries: List<ResearchQuery>,
    val maxQueries: Int,
    val resultsPerQuery: Int,
    val reason: String,
    val blockedByLock: Boolean
)

object ResearchCycleSearchStage {
    suspend fun executeBatch(
        queryBatch: List<ResearchQuery>,
        retMax: Int,
        seenSourceIds: Set<String>,
        existingFindings: List<ResearchFinding>,
        existingExecutedQueryIds: Set<String>,
        shouldStop: () -> Boolean,
        searchDeadlineMillis: Long,
        searchPubMed: suspend (query: String, retMax: Int) -> List<String>,
        fetchPubMedSummariesBatch: suspend (pmids: List<String>, query: ResearchQuery) -> List<ResearchFinding>
    ): ResearchCycleSearchStageResult {
        val findings = mutableListOf<ResearchFinding>()
        val executedQueries = mutableListOf<ResearchQuery>()
        val executedIds = existingExecutedQueryIds.toMutableSet()
        val diagnostics = mutableListOf<String>()
        var repeatedSkipped = 0
        var stopped = false
        var stopReason = "completed"

        fun recordRuntimeIssue(stage: String, error: Throwable) {
            diagnostics += runtimeIssue(stage, error)
        }

        val sourceIdsSeenThisPass = existingFindings
            .filter { it.source == "PubMed" }
            .map { it.sourceId }
            .toMutableSet()

        for (query in queryBatch) {
            if (!executedIds.add(query.id)) continue
            if (shouldStop()) {
                stopped = true
                stopReason = "stopped_by_user"
                break
            }
            if (System.currentTimeMillis() >= searchDeadlineMillis) {
                stopped = true
                stopReason = "search_limit_10_min_reached"
                break
            }

            executedQueries += query
            val ids = try {
                searchPubMed(query.query, retMax)
            } catch (e: Exception) {
                recordRuntimeIssue("searchPubMed:${query.id}", e)
                emptyList()
            }

            val freshIds = mutableListOf<String>()
            for (pmid in ids) {
                val key = "PubMed:$pmid"
                if (seenSourceIds.contains(key) || sourceIdsSeenThisPass.contains(pmid)) {
                    repeatedSkipped += 1
                    continue
                }
                freshIds += pmid
                sourceIdsSeenThisPass += pmid
            }

            if (freshIds.isNotEmpty()) {
                if (shouldStop()) {
                    stopped = true
                    stopReason = "stopped_by_user"
                    break
                }
                if (System.currentTimeMillis() >= searchDeadlineMillis) {
                    stopped = true
                    stopReason = "search_limit_10_min_reached"
                    break
                }
                val batch = try {
                    fetchPubMedSummariesBatch(freshIds.take(200), query)
                } catch (e: Exception) {
                    recordRuntimeIssue("fetchPubMedSummaries:${query.id}", e)
                    emptyList()
                }
                findings += batch
            }
            if (stopped) break
        }

        return ResearchCycleSearchStageResult(
            findings = findings,
            executedQueries = executedQueries,
            executedQueryIds = executedIds,
            repeatedSkipped = repeatedSkipped,
            runtimeDiagnostics = diagnostics,
            stopped = stopped,
            stopReason = stopReason
        )
    }

    fun buildRuntimeFailoverPlan(
        unifiedSearchLockAfterForager: Boolean,
        stopped: Boolean,
        newFindingsCount: Int,
        repeatedSkipped: Int,
        effectiveMaxQueries: Int,
        effectiveResultsPerQuery: Int
    ): ResearchCycleRuntimeFailoverPlan {
        if (unifiedSearchLockAfterForager) {
            return ResearchCycleRuntimeFailoverPlan(
                shouldRun = false,
                queries = emptyList(),
                maxQueries = 0,
                resultsPerQuery = 0,
                reason = "Blocked by active search directive / evidence-closure lock.",
                blockedByLock = true
            )
        }
        if (stopped || !EngineRuntimeStatus.hardStagnationTriggered(
                newFindingsCount = newFindingsCount,
                repeatedSkipped = repeatedSkipped,
                datasetCandidateCount = 0
            )
        ) {
            return ResearchCycleRuntimeFailoverPlan(
                shouldRun = false,
                queries = emptyList(),
                maxQueries = 0,
                resultsPerQuery = 0,
                reason = "Runtime failover not triggered.",
                blockedByLock = false
            )
        }

        val failoverPivot = EngineRuntimeStatus.runtimeFailoverPivot(repeatedSkipped)
        val failoverPlan = AutonomousStagnationEngine.StagnationPlan(
            level = 3,
            pendingPivot = failoverPivot,
            effectiveMaxQueries = maxOf(effectiveMaxQueries, 6),
            effectiveResultsPerQuery = maxOf(effectiveResultsPerQuery, 25),
            reason = failoverPivot.reason
        )
        val failoverQueries = listOf(
            ResearchQuery(
                id = "q_runtime_dataset_accession",
                label = "RUNTIME FAILOVER: dataset accession search",
                query = "(GSE OR GEO OR SDY OR ImmPort OR PRJNA OR SRP OR SRA OR RNA-seq OR single-cell OR scRNA-seq) AND (immune response OR cytokine OR interferon OR allergy OR viral response) AND (outcome OR severity OR recovery OR longitudinal OR cohort)",
                reason = "Hard stagnation was detected inside this cycle; execute DATASET_HUNT now."
            ),
            ResearchQuery(
                id = "q_runtime_condition_outcome_labels",
                label = "RUNTIME FAILOVER: condition/outcome labels",
                query = "(condition labels OR phenotype labels OR outcome labels OR severity OR recovery) AND (immune profiling OR transcriptomic OR RNA-seq OR single-cell) AND (human OR patient OR cohort)",
                reason = "Search for label structure rather than another broad PubMed neighborhood."
            )
        ) + AutonomousStagnationEngine.antiStagnationQueries(failoverPlan)

        return ResearchCycleRuntimeFailoverPlan(
            shouldRun = true,
            queries = failoverQueries.distinctBy { it.id }.take(failoverPlan.effectiveMaxQueries),
            maxQueries = failoverPlan.effectiveMaxQueries,
            resultsPerQuery = failoverPlan.effectiveResultsPerQuery,
            reason = failoverPlan.reason,
            blockedByLock = false
        )
    }

    fun runtimeIssue(stage: String, error: Throwable): String {
        val type = when (error) {
            is NcbiRateLimitException -> "NCBI_429_RATE_LIMIT"
            is IOException -> "IO_EXCEPTION"
            is org.json.JSONException -> "JSON_EXCEPTION"
            else -> error::class.java.simpleName.ifBlank { "UNKNOWN_EXCEPTION" }
        }
        val message = error.message?.take(180) ?: "no message"
        return "$stage:$type:$message"
    }
}
