package com.immunesignal.app

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * FoundationPatchSuggestionLedger: Intelligent suggestion system for foundation updates
 * 
 * Key Principle:
 * NEVER auto-update foundation knowledge
 * Instead: record conflicts, suggest patches, await human review
 * 
 * This prevents system from "learning" incorrect patterns and maintains safety
 */

enum class PatchStatus {
    PROPOSED,    // Awaiting review
    ACCEPTED,    // Approved and applied
    REJECTED,    // Reviewed and rejected
    WATCH        // Under observation before decision
}

class FoundationPatchSuggestionLedger(
    private val context: Context,
    private val filename: String = "foundation_patch_suggestions.json"
) {

    private val suggestions = mutableMapOf<String, FoundationPatchSuggestion>()
    private val file = File(context.filesDir, filename)

    init {
        loadFromStorage()
    }

    /**
     * Suggest a patch when data repeatedly conflicts with foundation
     * 
     * @param axisId: which axis needs updating
     * @param conflictDescription: what's the problem?
     * @param suggestedChange: what should we change?
     * @param supportingReports: dataset IDs showing the conflict
     */
    fun suggestPatch(
        axisId: String,
        conflictDescription: String,
        suggestedChange: String,
        supportingReports: List<String> = emptyList()
    ): String {  // Returns suggestion ID

        // Don't create duplicate suggestions for the same axis
        val existingKey = suggestions.keys.firstOrNull { key ->
            val existing = suggestions[key] ?: return@firstOrNull false
            existing.axisId == axisId && existing.status == PatchStatus.PROPOSED
        }

        if (existingKey != null) {
            // Update existing suggestion with new evidence
            val existing = suggestions[existingKey]!!
            existing.supportingReports.addAll(supportingReports)
            existing.lastUpdatedMillis = System.currentTimeMillis()

            // Escalate priority if more evidence
            if (existing.supportingReports.size >= 3) {
                existing.priority = "HIGH"
            }

            saveToStorage()
            return existingKey
        }

        // Create new suggestion
        val suggestionId = "patch_${UUID.randomUUID().toString().take(8)}"

        val suggestion = FoundationPatchSuggestion(
            id = suggestionId,
            axisId = axisId,
            reason = conflictDescription,
            observedConflict = conflictDescription,
            suggestedChange = suggestedChange,
            supportingReports = supportingReports.toMutableList(),
            requiredReview = true,
            status = PatchStatus.PROPOSED,
            priority = if (supportingReports.size >= 3) "HIGH" else "MEDIUM"
        )

        suggestions[suggestionId] = suggestion
        saveToStorage()

        return suggestionId
    }

    /**
     * Check if axis should be patched (3+ conflicting reports)
     */
    fun shouldConsiderPatch(axisId: String): Boolean {
        return suggestions.values.any { suggestion ->
            suggestion.axisId == axisId &&
            suggestion.status == PatchStatus.PROPOSED &&
            suggestion.supportingReports.size >= 3
        }
    }

    /**
     * Get all patch suggestions for an axis
     */
    fun getPatchSuggestions(axisId: String): List<FoundationPatchSuggestion> {
        return suggestions.values.filter { it.axisId == axisId }
    }

    /**
     * Get pending patches awaiting review
     */
    fun getPendingPatches(): List<FoundationPatchSuggestion> {
        return suggestions.values.filter { it.status == PatchStatus.PROPOSED }
            .sortedByDescending { it.priority }
    }

    /**
     * Get patch by ID
     */
    fun getPatch(patchId: String): FoundationPatchSuggestion? {
        return suggestions[patchId]
    }

    /**
     * Accept a patch (mark as approved, but don't auto-apply to JSON)
     */
    fun acceptPatch(patchId: String): Boolean {
        val patch = suggestions[patchId] ?: return false
        patch.status = PatchStatus.ACCEPTED
        patch.lastUpdatedMillis = System.currentTimeMillis()
        saveToStorage()
        return true
    }

    /**
     * Reject a patch with reason
     */
    fun rejectPatch(patchId: String, reason: String = ""): Boolean {
        val patch = suggestions[patchId] ?: return false
        patch.status = PatchStatus.REJECTED
        patch.rejectionReason = reason
        patch.lastUpdatedMillis = System.currentTimeMillis()
        saveToStorage()
        return true
    }

    /**
     * Mark patch as "under watch" - gathering more evidence
     */
    fun watchPatch(patchId: String): Boolean {
        val patch = suggestions[patchId] ?: return false
        patch.status = PatchStatus.WATCH
        patch.watchStartedMillis = System.currentTimeMillis()
        saveToStorage()
        return true
    }

    /**
     * Add supporting evidence to a patch
     */
    fun addEvidenceToPatch(patchId: String, reportId: String): Boolean {
        val patch = suggestions[patchId] ?: return false

        if (!patch.supportingReports.contains(reportId)) {
            patch.supportingReports.add(reportId)
            patch.lastUpdatedMillis = System.currentTimeMillis()

            // Escalate if enough evidence
            if (patch.supportingReports.size >= 3) {
                patch.priority = "HIGH"
            }

            saveToStorage()
        }

        return true
    }

    /**
     * Get penalty for an axis (used in ranking if patches suggest issues)
     */
    fun getPatchPenalty(axisId: String): Float {
        val patches = suggestions.values.filter { it.axisId == axisId }

        // Only apply penalty for patches with strong evidence
        val strongPatches = patches.filter { it.supportingReports.size >= 2 }

        return when (strongPatches.size) {
            0 -> 0f
            1 -> 0.05f
            2 -> 0.10f
            else -> 0.15f
        }
    }

    /**
     * Generate patch summary for user review
     */
    fun getPatchSummary(): String {
        val sb = StringBuilder()

        sb.append("=== FOUNDATION PATCH SUMMARY ===\n\n")

        val pending = getPendingPatches()
        if (pending.isEmpty()) {
            sb.append("No pending patches.\n")
            return sb.toString()
        }

        sb.append("Pending Patches: ${pending.size}\n\n")

        pending.forEach { patch ->
            sb.append("ID: ${patch.id}\n")
            sb.append("Axis: ${patch.axisId}\n")
            sb.append("Priority: ${patch.priority}\n")
            sb.append("Conflict: ${patch.observedConflict}\n")
            sb.append("Suggested Change: ${patch.suggestedChange}\n")
            sb.append("Supporting Evidence: ${patch.supportingReports.size} reports\n")
            sb.append("Status: ${patch.status}\n")
            sb.append("---\n")
        }

        return sb.toString()
    }

    /**
     * Get detailed report for a patch
     */
    fun getPatchReport(patchId: String): String {
        val patch = suggestions[patchId]
            ?: return "Patch $patchId not found"

        val sb = StringBuilder()

        sb.append("=== PATCH REPORT ===\n")
        sb.append("ID: ${patch.id}\n")
        sb.append("Axis: ${patch.axisId}\n")
        sb.append("Status: ${patch.status}\n")
        sb.append("Priority: ${patch.priority}\n\n")

        sb.append("Observed Conflict:\n")
        sb.append("${patch.observedConflict}\n\n")

        sb.append("Suggested Change:\n")
        sb.append("${patch.suggestedChange}\n\n")

        sb.append("Supporting Evidence:\n")
        patch.supportingReports.forEachIndexed { index, report ->
            sb.append("${index + 1}. $report\n")
        }

        sb.append("\nReview Status: ${if (patch.requiredReview) "AWAITING REVIEW" else "REVIEWED"}\n")

        if (patch.rejectionReason.isNotEmpty()) {
            sb.append("Rejection Reason: ${patch.rejectionReason}\n")
        }

        sb.append("Created: ${patch.createdMillis}\n")
        sb.append("Last Updated: ${patch.lastUpdatedMillis}\n")

        return sb.toString()
    }

    /**
     * Save suggestions to storage
     */
    fun saveToStorage() {
        try {
            val json = JSONObject()
            val suggestionsArray = org.json.JSONArray()

            for (suggestion in suggestions.values) {
                val patchObj = JSONObject()
                patchObj.put("id", suggestion.id)
                patchObj.put("axisId", suggestion.axisId)
                patchObj.put("reason", suggestion.reason)
                patchObj.put("observedConflict", suggestion.observedConflict)
                patchObj.put("suggestedChange", suggestion.suggestedChange)
                patchObj.put("status", suggestion.status.toString())
                patchObj.put("priority", suggestion.priority)
                patchObj.put("requiredReview", suggestion.requiredReview)
                patchObj.put("rejectionReason", suggestion.rejectionReason)
                patchObj.put("createdMillis", suggestion.createdMillis)
                patchObj.put("lastUpdatedMillis", suggestion.lastUpdatedMillis)
                patchObj.put("watchStartedMillis", suggestion.watchStartedMillis)

                val reportsArray = org.json.JSONArray(suggestion.supportingReports)
                patchObj.put("supportingReports", reportsArray)

                suggestionsArray.put(patchObj)
            }

            json.put("suggestions", suggestionsArray)
            json.put("lastSync", System.currentTimeMillis())

            file.writeText(json.toString(2))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Load suggestions from storage
     */
    private fun loadFromStorage() {
        try {
            if (!file.exists()) return

            val json = JSONObject(file.readText())
            val suggestionsArray = json.optJSONArray("suggestions") ?: return

            for (i in 0 until suggestionsArray.length()) {
                val patchObj = suggestionsArray.getJSONObject(i)

                val reports = mutableListOf<String>()
                patchObj.optJSONArray("supportingReports")?.let {
                    for (j in 0 until it.length()) {
                        reports.add(it.getString(j))
                    }
                }

                val suggestion = FoundationPatchSuggestion(
                    id = patchObj.getString("id"),
                    axisId = patchObj.getString("axisId"),
                    reason = patchObj.getString("reason"),
                    observedConflict = patchObj.getString("observedConflict"),
                    suggestedChange = patchObj.getString("suggestedChange"),
                    supportingReports = reports,
                    requiredReview = patchObj.getBoolean("requiredReview"),
                    status = PatchStatus.valueOf(patchObj.getString("status")),
                    priority = patchObj.optString("priority", "MEDIUM"),
                    rejectionReason = patchObj.optString("rejectionReason", ""),
                    createdMillis = patchObj.getLong("createdMillis"),
                    lastUpdatedMillis = patchObj.getLong("lastUpdatedMillis"),
                    watchStartedMillis = patchObj.optLong("watchStartedMillis", 0)
                )

                suggestions[suggestion.id] = suggestion
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

// ============ DATA CLASSES ============

data class FoundationPatchSuggestion(
    val id: String,
    val axisId: String,
    val reason: String,
    val observedConflict: String,
    val suggestedChange: String,
    val supportingReports: MutableList<String> = mutableListOf(),
    var requiredReview: Boolean = true,
    var status: PatchStatus = PatchStatus.PROPOSED,
    var priority: String = "MEDIUM",  // LOW, MEDIUM, HIGH
    var rejectionReason: String = "",
    val createdMillis: Long = System.currentTimeMillis(),
    var lastUpdatedMillis: Long = System.currentTimeMillis(),
    var watchStartedMillis: Long = 0
)
