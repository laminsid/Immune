package com.immunesignal.app

/** v1.5.8: auto-light continuation for SEARCH cycles, not a deep Think session. */
data class AutoContinuationReport(
    val active: Boolean,
    val triggered: Boolean,
    val reasons: List<String>,
    val recommendedAction: String,
    val queuedQuery: String?,
    val claimLimit: String = "auto_continuation_not_biological_proof"
) {
    companion object {
        fun empty() = AutoContinuationReport(
            active = false,
            triggered = false,
            reasons = emptyList(),
            recommendedAction = "Auto-light continuation was not evaluated in this cycle.",
            queuedQuery = null
        )
    }
}

object AutoContinuationTrigger {
    fun evaluate(
        parsedMetadata: List<ParsedDatasetMetadata>,
        contrastiveReport: ContrastiveEvidenceReport,
        failurePatternReport: FailurePatternReport,
        queryFeedbackPlan: QueryFeedbackPlan,
        triageReport: DatasetTriageReport
    ): AutoContinuationReport {
        val reasons = mutableListOf<String>()
        if (triageReport.active && parsedMetadata.isEmpty()) reasons += "parsed_metadata_zero"
        if (contrastiveReport.gateStatus == "NOT_EVALUATED") reasons += "contrastive_gate_not_evaluated"
        val repeatedFailure = failurePatternReport.patterns.any { it.occurrenceCount >= 3 }
        if (repeatedFailure) reasons += "repeated_failure_pattern_ge_3"
        if (queryFeedbackPlan.active && queryFeedbackPlan.improvements.isNotEmpty()) reasons += "query_feedback_available"
        val triggered = reasons.isNotEmpty()
        val queued = queryFeedbackPlan.improvements.firstOrNull()?.improved
        return AutoContinuationReport(
            active = true,
            triggered = triggered,
            reasons = reasons.distinct(),
            recommendedAction = if (triggered) {
                "Run the queued micro-follow-up metadata search in the next SEARCH cycle; do not start a 15-minute Think session unless the same stall repeats."
            } else {
                "No micro-continuation needed; continue normal autonomous search."
            },
            queuedQuery = queued
        )
    }
}
