package com.immunesignal.app

import org.json.JSONObject

/**
 * v2.7.2: value layer. It asks what GTIM added beyond a normal PubMed/OpenAlex
 * search result list: gates, route separation, paper-lite extraction, contradiction
 * targets, and next evidence actions. It does not claim scientific superiority.
 */
data class GTIMProofOfValueReportV272(
    val active: Boolean,
    val valueState: String,
    val addedValue: List<String>,
    val baselineRisk: String,
    val nextProofAction: String,
    val benchmarkQuestions: List<String>,
    val claimLimit: String = GTIMProofOfValueModeV272.CLAIM_LIMIT
)

object GTIMProofOfValueModeV272 {
    const val VERSION: String = "2.7.2-proof-of-value-mode"
    const val CLAIM_LIMIT: String = "product_value_triage_not_scientific_claim"

    fun build(
        report: JSONObject,
        routeState: GTIMRouteEvidenceStateReportV272,
        paper: GTIMPaperUnderstandingLiteReportV272,
        dataChannelCount: Int,
        topQuery: String
    ): GTIMProofOfValueReportV272 {
        if (!RuntimeFeatureFlags.ENABLE_PROOF_OF_VALUE_MODE_V272) return empty()
        val findingsCount = (report.optJSONArray("findings") ?: org.json.JSONArray()).length()
        val added = mutableListOf<String>()
        if (routeState.state == "PROMISING_ROUTE" || routeState.state == "EVIDENCE_CANDIDATE") added += "route state separated from evidence strength"
        if (paper.active && paper.paperUnderstandingScore > 0) added += "abstract-level design/model/dataset signals extracted"
        if (paper.contradictionSignals.isNotEmpty()) added += "contradiction/null-result language surfaced"
        if (dataChannelCount > 0) added += "next data-feed channel selected"
        if (topQuery.isNotBlank()) added += "next query made explicit"
        if (added.isEmpty() && findingsCount == 0) added += "no value beyond baseline yet; public lookup did not materialize usable signals"
        val state = when {
            added.any { it.contains("abstract-level") } && routeState.state in listOf("PROMISING_ROUTE", "EVIDENCE_CANDIDATE") -> "VALUE_DELTA_VISIBLE"
            added.any { it.contains("no value") } -> "NO_VALUE_DELTA_YET"
            else -> "ROUTING_VALUE_ONLY"
        }
        val risk = when (state) {
            "VALUE_DELTA_VISIBLE" -> "Still metadata/abstract-only; compare against PubMed/Elicit manually before product claims."
            "ROUTING_VALUE_ONLY" -> "GTIM may only be organizing search steps, not interpreting papers yet."
            else -> "If repeated on benchmark questions, stop feature expansion and improve retrieval/understanding."
        }
        return GTIMProofOfValueReportV272(
            active = true,
            valueState = state,
            addedValue = added.distinct().take(6),
            baselineRisk = risk,
            nextProofAction = "Run the five-question benchmark and record whether GTIM adds a gate, contradiction, dataset seed, or paper-lite signal beyond normal PubMed search.",
            benchmarkQuestions = benchmarkQuestions()
        )
    }

    fun benchmarkQuestions(): List<String> = listOf(
        "Hantavirus endothelial interferon cytokine route",
        "EBV and SLE type I interferon route",
        "Long COVID interferon PBMC transcriptome route",
        "Pesticides gut microbiome immune inflammation route",
        "Heavy metals water exposure inflammation PBMC route"
    )

    fun empty(): GTIMProofOfValueReportV272 = GTIMProofOfValueReportV272(
        active = false,
        valueState = "PROOF_OF_VALUE_DISABLED",
        addedValue = emptyList(),
        baselineRisk = "not evaluated",
        nextProofAction = "enable proof-of-value mode",
        benchmarkQuestions = benchmarkQuestions()
    )
}
