package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.10.7: maintenance linkage guard.
 *
 * This report is a repair-oriented wiring check. It connects phase spine,
 * plan-stage, search directive, and phase audit into one compact maintenance
 * view so future fixes can locate the broken handoff without reading the whole
 * 1,900-line ResearchAutopilot cycle.
 */
data class ResearchCyclePathMaintenanceReport(
    val active: Boolean,
    val version: String,
    val state: String,
    val linkedStages: List<String>,
    val weakHandoffs: List<String>,
    val governingLayer: String,
    val repairTarget: String,
    val summary: String,
    val claimLimit: String = "path_maintenance_guard_not_biological_proof"
) {
    companion object {
        fun empty() = ResearchCyclePathMaintenanceReport(
            active = false,
            version = "v1.10.7",
            state = "NOT_EVALUATED",
            linkedStages = emptyList(),
            weakHandoffs = emptyList(),
            governingLayer = "none",
            repairTarget = "No maintenance path evaluated.",
            summary = "Path maintenance guard was not evaluated."
        )
    }
}

object ResearchCyclePathMaintenanceGuard {
    fun build(
        directive: ResearchSearchDirective,
        phaseSpine: ResearchCyclePhaseSpineReport,
        planStage: ResearchCyclePlanStageReport,
        phaseAudit: ResearchCyclePhaseAuditReport
    ): ResearchCyclePathMaintenanceReport {
        val linked = mutableListOf<String>()
        val weak = mutableListOf<String>()

        if (phaseSpine.boundaryCount >= 5) linked += "phase_spine_boundaries"
        else weak += "PHASE_SPINE_MISSING_BOUNDARIES"

        if (planStage.active) linked += "plan_stage_to_search"
        else weak += "PLAN_STAGE_NOT_ACTIVE"

        if (phaseAudit.active) linked += "search_to_reason_audit"
        else weak += "PHASE_AUDIT_NOT_ACTIVE"

        if (planStage.governingLayer == directive.governingLayer || !directive.active) {
            linked += "directive_owner_consistent"
        } else {
            weak += "DIRECTIVE_OWNER_MISMATCH:${directive.governingLayer}->${planStage.governingLayer}"
        }

        if (phaseAudit.lockViolations.isEmpty()) linked += "lock_invariants_clean"
        else weak += "LOCK_VIOLATIONS:${phaseAudit.lockViolations.take(3).joinToString(",")}" 

        val state = when {
            weak.any { it.startsWith("LOCK_VIOLATIONS") } -> "REPAIR_LOCK_FIRST"
            weak.isNotEmpty() -> "REPAIR_HANDOFFS"
            else -> "CONNECTED"
        }
        val repairTarget = when {
            weak.isEmpty() -> "Next safe split: extract SEARCH execution fully from ResearchAutopilot, keeping the same directive contract."
            weak.any { it.contains("OWNER_MISMATCH") } -> "Fix directive owner mismatch before changing query planning."
            weak.any { it.contains("PLAN_STAGE") } -> "Repair PlanStage wiring before search refactor."
            else -> "Repair phase audit/spine wiring before further extraction."
        }
        return ResearchCyclePathMaintenanceReport(
            active = true,
            version = "v1.10.7",
            state = state,
            linkedStages = linked,
            weakHandoffs = weak,
            governingLayer = directive.governingLayer,
            repairTarget = repairTarget,
            summary = "Path maintenance $state: linked=${linked.size}; weak=${weak.size}; owner=${directive.governingLayer}."
        )
    }

    fun toJson(report: ResearchCyclePathMaintenanceReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("state", report.state)
        .put("linkedStages", JSONArray(report.linkedStages))
        .put("weakHandoffs", JSONArray(report.weakHandoffs))
        .put("governingLayer", report.governingLayer)
        .put("repairTarget", report.repairTarget)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)
}
