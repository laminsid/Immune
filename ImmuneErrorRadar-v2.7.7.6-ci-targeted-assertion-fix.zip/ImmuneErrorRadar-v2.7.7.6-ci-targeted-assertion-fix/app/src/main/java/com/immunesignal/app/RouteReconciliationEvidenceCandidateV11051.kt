package com.immunesignal.app

/**
 * v1.10.51: reconciles corrected topic routing with legacy report cards.
 *
 * The layer does not change evidence strength. It only prevents old mature-domain
 * priors and stale query templates from being presented as the governing route after
 * TopicFit has selected a corrected lane. It also emits executable comparator-hunt
 * query seeds and activates bounded EvidenceObjectCandidate records when parsed
 * metadata is useful but blocked by comparator/control or contradiction gates.
 */
object RouteReconciliationEvidenceCandidateV11051 {
    const val CLAIM_LIMIT: String = "route_reconciliation_evidence_candidate_not_biological_proof"
    const val VERSION_LABEL: String = "v1.10.51-alpha-route-reconciliation-evidence-candidate-activation"

    fun legacyRouteReconciliationStatus(
        topicLabel: String,
        preferredLane: String,
        suppressedMatureDomain: String
    ): String {
        return if (suppressedMatureDomain != "none") {
            "LEGACY_PRIOR_RECONCILED: topic=$topicLabel; governing=$preferredLane; suppressed=$suppressedMatureDomain"
        } else {
            "LEGACY_PRIOR_ALIGNED: topic=$topicLabel; governing=$preferredLane"
        }
    }

    fun reconciledMatureDomainFocus(
        topicLabel: String,
        preferredLane: String,
        suppressedMatureDomain: String
    ): String {
        return if (suppressedMatureDomain != "none") {
            "SUPPRESSED_STALE_PRIOR_ONLY: $suppressedMatureDomain -> governing route $preferredLane for topic $topicLabel"
        } else {
            "ALIGNED_WITH_GOVERNING_ROUTE: $preferredLane"
        }
    }

    fun legacySuppressionNotes(
        topicLabel: String,
        preferredLane: String,
        suppressedMatureDomain: String
    ): List<String> {
        val notes = mutableListOf<String>()
        notes += "Governing route is $preferredLane for topic $topicLabel."
        if (suppressedMatureDomain != "none") {
            notes += "Legacy mature-domain prior $suppressedMatureDomain must not print as focus, next query, or route owner."
            notes += "Legacy sections may show the prior only under Suppressed stale prior."
        }
        notes += "Post-PubMed strategies, knowledge-gap queries, and global-action text must use the reconciled query seed."
        notes += "This reconciliation is routing/report hygiene only, not biological proof."
        return notes
    }

    fun reconciledQuerySeed(topicLabel: String, preferredLane: String): String {
        val topic = topicLabel.ifBlank { "immune topic" }
        return when (preferredLane) {
            "METABOLIC_SUGAR_SALT_IMMUNE_CARDIO_LANE" -> "$topic sugar glucose HbA1c insulin salt sodium blood pressure CRP IL-6 human cohort baseline matched control exposed unexposed GSE PRJNA SDY"
            "DRUG_PERTURBATION_IMMUNE_CONTROL_LANE" -> "$topic immune response human cohort exposed unexposed baseline responder non-responder matched control untreated negative control GSE PRJNA SDY"
            "HERB_EXPOSURE_HPA_IMMUNE_MODULATION_LANE" -> "$topic exposure immune cytokine HPA cortisol placebo baseline exposed unexposed matched control GSE PRJNA SDY"
            "RNA_TRANSCRIPTOMIC_IMMUNE_STATE_LANE" -> "$topic RNA-seq single-cell transcriptome immune response human cohort baseline control responder non-responder GSE PRJNA"
            "GENETIC_EPIGENETIC_IMMUNE_VARIANT_LANE" -> "$topic genetic epigenetic immune cohort HLA methylation matched control replication GSE PRJNA dbGaP"
            "ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE" -> "$topic exposure dust pollen air quality IgE eosinophil exposed unexposed seasonal baseline matched control GSE"
            "PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE" -> "$topic stress HPA cortisol HRV IL-6 CRP human cohort baseline matched control longitudinal"
            "ENDOCRINE_HORMONE_HPA_IMMUNE_LANE" -> "$topic hormone endocrine immune cytokine cycle phase baseline matched control longitudinal cohort"
            "DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE" -> "$topic gastric food microbiome barrier immune cytokine baseline exposed unexposed matched control"
            "PHYSICAL_LIGHT_RADIATION_CIRCADIAN_IMMUNE_LANE" -> "$topic light radiation circadian melatonin cortisol immune response time-course matched control"
            "TOXIN_SUBSTANCE_EXPOSURE_IMMUNE_LANE" -> "$topic substance exposure immune inflammation baseline exposed unexposed negative control human cohort"
            "AGE_LIFE_STAGE_IMMUNE_CONTEXT_LANE" -> "$topic age life-stage immune response matched age control CMV T-cell subsets cytokine cohort"
            "VACCINE_IMMUNE_RESPONSE_LANE", "IMMUNE_AGING_VACCINE_RESPONSE_LANE" -> "$topic vaccine immune response antibody T-cell cytokine older adults matched control baseline nonresponse"
            "DRUG_PERTURBATION_MICROBIOME_BARRIER_IMMUNE_LANE" -> "$topic antibiotic microbiome barrier immune cytokine before after exposed unexposed matched control"
            "CIRCADIAN_SLEEP_INTELLIGENCE" -> "$topic sleep circadian cortisol HRV CRP IL-6 baseline matched control longitudinal"
            "MITOCHONDRIAL_FATIGUE_LANE" -> "$topic fatigue mitochondrial metabolomics Long COVID ME/CFS matched control baseline outcome GSE"
            "IMMUNE_AGING_IMMUNOSENESCENCE_LANE" -> "$topic immunosenescence CMV T-cell exhaustion CRP IL-6 TNF-alpha older adults matched control"
            "TYPE2_ALLERGY_MAST_CELL_LANE" -> "$topic allergy histamine mast cell IgE eosinophil control negative control heterogeneity GSE"
            else -> "$topic immune response human cohort dataset outcome labels control comparator time order GSE PRJNA SDY"
        }
    }

    fun comparatorHuntQueries(topicLabel: String, preferredLane: String, accessions: List<String>): List<String> {
        val seed = reconciledQuerySeed(topicLabel, preferredLane)
        val accessionPart = accessions.filter { it.isNotBlank() }.take(2)
        val base = mutableListOf<String>()
        base += "$seed healthy control matched control placebo responder non-responder negative control"
        base += "$seed baseline untreated exposed unexposed case_label contrast_definition same_subject matched_group"
        base += "$seed no association heterogeneity failed replication unrelated marker control"
        if (accessionPart.isNotEmpty()) {
            base += accessionPart.map { accession -> "$accession control comparator baseline negative control responder non-responder" }
        }
        return base.flattenIfNeeded().distinct().take(6)
    }

    private fun MutableList<String>.flattenIfNeeded(): List<String> = this

    fun candidateStatus(missingGates: List<String>): String {
        val missingControl = missingGates.any { it == "control_or_comparator" || it == "comparator_control" }
        val missingTime = missingGates.any { it == "time_order" || it == "timestamp" }
        val missingContradiction = missingGates.any { it == "contradiction_or_negative_control" }
        return when {
            missingControl && missingTime -> "BLOCKED_BY_CONTROL_AND_TIME_ORDER"
            missingControl -> "BLOCKED_BY_CONTROL_OR_COMPARATOR"
            missingTime -> "BLOCKED_BY_TIME_ORDER"
            missingContradiction -> "BLOCKED_BY_CONTRADICTION_SEARCH"
            else -> "CANDIDATE_READY_FOR_CONTRADICTION_CHECK"
        }
    }
}
