package com.immunesignal.app

object FalsificationBuilder {
    fun forHypothesis(axes: List<String>, gate: MinimumDataPackAssessment): List<String> {
        val out = mutableListOf<String>()
        out += "The proposed trigger does not precede the outcome in repeated timestamped observations."
        out += "The pattern disappears after reverse-time or shuffled-timeline negative controls."
        out += "Opposing human evidence is stronger than supporting evidence."
        if (gate.missingData.isNotEmpty()) out += "The minimum data pack remains incomplete: ${gate.missingData.take(3).joinToString(", ")}."
        if (axes.contains("autonomic_vascular_axis")) out += "BP/pulse readings do not change around the alleged allergy/stress episodes."
        if (axes.contains("type2_allergy_axis")) out += "Allergy intensity does not track exposure, sleep, stress, IgE/eosinophils, or repeat episodes."
        if (axes.contains("gastric_acid_gut_axis")) out += "Gastric/reflux timing does not precede or track allergy/airway symptoms."
        if (axes.contains("rna_transcriptomic_axis") || axes.contains("dna_genomic_axis")) out += "The omics signal cannot be mapped to a curated dataset, tissue, or repeated marker context."
        return out.distinct().take(8)
    }
}
