package com.immunesignal.app

/**
 * Router governance adapter.
 * Existing routers should pass candidate routes through this object before adding them to the run.
 */
object GTIMRouteGovernanceV2740 {

    data class RouteCandidate(
        val routeId: String,
        val candidateAnchor: GTIMPrimaryAnchorV2740? = null,
        val sourceLayer: String,
        val reason: String,
        val provenance: String? = null
    )

    enum class RouteDecisionType {
        ALLOW_PRIMARY_ANCHOR,
        ALLOW_EXPLORATORY_BRIDGE,
        ALLOW_AUTONOMOUS_EXPLORATION,
        REJECT_IDENTITY_MUTATION,
        REJECT_FORBIDDEN_CONFLATION,
        REJECT_OUTSIDE_CONTRACT
    }

    data class RouteDecision(
        val decision: RouteDecisionType,
        val allowed: Boolean,
        val routeId: String,
        val label: GTIMEvidenceLabelV2740,
        val claimMode: GTIMClaimModeV2740,
        val confidenceCap: Int,
        val reason: String
    )

    fun evaluate(
        contract: GTIMRunDecisionContractV2740,
        candidate: RouteCandidate
    ): RouteDecision {
        if (contract.runMode == GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION) {
            return RouteDecision(
                decision = RouteDecisionType.ALLOW_AUTONOMOUS_EXPLORATION,
                allowed = true,
                routeId = candidate.routeId,
                label = GTIMEvidenceLabelV2740.SPECULATIVE_BRIDGE,
                claimMode = GTIMClaimModeV2740.AUTONOMOUS_EXPLORATORY_HYPOTHESIS,
                confidenceCap = contract.evidenceCaps.routeConfidenceMax,
                reason = "Autonomous discovery allows cross-domain route; evidence label/provenance required."
            )
        }

        val candidateAnchor = candidate.candidateAnchor
        if (candidateAnchor != null && !contract.enforceNoIdentityMutation(candidateAnchor)) {
            return RouteDecision(
                decision = RouteDecisionType.REJECT_IDENTITY_MUTATION,
                allowed = false,
                routeId = candidate.routeId,
                label = GTIMEvidenceLabelV2740.REJECTED_CONFLATION,
                claimMode = contract.claimMode,
                confidenceCap = 0,
                reason = "Rejected: candidate route mutates primary anchor ${contract.primaryAnchor} into $candidateAnchor."
            )
        }

        if (candidate.routeId in contract.blockedRoutes || candidate.routeId in contract.forbiddenConflations) {
            return RouteDecision(
                decision = RouteDecisionType.REJECT_FORBIDDEN_CONFLATION,
                allowed = false,
                routeId = candidate.routeId,
                label = GTIMEvidenceLabelV2740.REJECTED_CONFLATION,
                claimMode = contract.claimMode,
                confidenceCap = 0,
                reason = "Rejected: route is a forbidden conflation for this anchor."
            )
        }

        if (candidate.routeId == contract.primaryAnchor.routeId) {
            return RouteDecision(
                decision = RouteDecisionType.ALLOW_PRIMARY_ANCHOR,
                allowed = true,
                routeId = candidate.routeId,
                label = GTIMEvidenceLabelV2740.PLAUSIBLE_MECHANISM,
                claimMode = contract.claimMode,
                confidenceCap = contract.evidenceCaps.routeConfidenceMax,
                reason = "Allowed: route matches protected primary anchor."
            )
        }

        if (candidate.routeId in contract.exploratoryRoutes || candidate.routeId in contract.allowedRoutes) {
            return RouteDecision(
                decision = RouteDecisionType.ALLOW_EXPLORATORY_BRIDGE,
                allowed = true,
                routeId = candidate.routeId,
                label = GTIMEvidenceLabelV2740.WEAK_LEAD,
                claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                confidenceCap = contract.evidenceCaps.routeConfidenceMax,
                reason = "Allowed: route connects to protected anchor as exploratory bridge; it must not rewrite identity."
            )
        }

        return RouteDecision(
            decision = RouteDecisionType.REJECT_OUTSIDE_CONTRACT,
            allowed = false,
            routeId = candidate.routeId,
            label = GTIMEvidenceLabelV2740.REJECTED_CONFLATION,
            claimMode = contract.claimMode,
            confidenceCap = 0,
            reason = "Rejected: route is outside the single-run decision contract."
        )
    }
}
