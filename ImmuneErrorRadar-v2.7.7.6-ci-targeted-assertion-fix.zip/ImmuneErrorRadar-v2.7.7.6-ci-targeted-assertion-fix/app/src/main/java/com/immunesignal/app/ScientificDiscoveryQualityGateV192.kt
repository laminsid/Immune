package com.immunesignal.app

import java.util.Locale

/**
 * v1.9.2: discovery quality gate. Token: discovery_quality_gate.
 *
 * v1.9.1 selects a meta-strategy. This gate decides whether that strategy is
 * execution-worthy before the next cycle consumes budget. It blocks low-quality
 * replay, metadata-only progress, route-fit-only expansion, and deep-think use
 * without a falsifiable evidence contract. It guides routing only; it never
 * proves biology, diagnosis, treatment, causality, mechanism, or immune outcome.
 */
data class DiscoveryQualityIssueCard(
    val issueId: String,
    val severity: Int,
    val label: String,
    val evidenceKey: String,
    val requiredBeforeRun: String,
    val routeEffect: String,
    val queryTerms: List<String>
)

data class ScientificDiscoveryQualityGateReport(
    val active: Boolean,
    val version: String,
    val gateState: String,
    val qualityScore: Int,
    val executionDecision: String,
    val allowExecution: Boolean,
    val selectedStrategy: String,
    val blockedBecause: List<String>,
    val qualityIssues: List<DiscoveryQualityIssueCard>,
    val requiredBeforeRun: List<String>,
    val forcedDirectiveTerms: List<String>,
    val forcedEvidenceKeys: List<String>,
    val routeDisposition: String,
    val reportLine: String,
    val claimLimit: String = "discovery_quality_gate_routing_only_not_biological_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryQualityGateReport(
            active = false,
            version = "v1.9.2",
            gateState = "NOT_RUN",
            qualityScore = 0,
            executionDecision = "No discovery quality decision available.",
            allowExecution = false,
            selectedStrategy = "none",
            blockedBecause = emptyList(),
            qualityIssues = emptyList(),
            requiredBeforeRun = emptyList(),
            forcedDirectiveTerms = emptyList(),
            forcedEvidenceKeys = emptyList(),
            routeDisposition = "NO_ROUTE_DECISION",
            reportLine = "Discovery quality gate did not run.",
            claimLimit = "discovery_quality_gate_routing_only_not_biological_proof"
        )
    }
}

object ScientificDiscoveryQualityGateEngineV192 {
    fun evaluate(
        metaStrategy: ScientificDiscoveryMetaStrategyReport,
        probeOutcomeLedger: ScientificDiscoveryProbeOutcomeLedgerReport,
        currentProbePlan: ScientificDiscoveryProbePlanReport,
        executionPolicy: ScientificDiscoveryExecutionPolicyReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport,
        causalReadiness: CausalReadinessReport,
        miniPeerReview: MiniPeerReviewReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        datasetForaging: DatasetForagingReport,
        discoveryReadiness: DiscoveryReadinessReport,
        learningOs: LearningOsReport
    ): ScientificDiscoveryQualityGateReport {
        if (!metaStrategy.active && !currentProbePlan.active && !probeOutcomeLedger.active && !executionPolicy.active && !scientificWeights.active) {
            return ScientificDiscoveryQualityGateReport.empty()
        }

        val issues = buildIssues(
            metaStrategy = metaStrategy,
            probeOutcomeLedger = probeOutcomeLedger,
            currentProbePlan = currentProbePlan,
            executionPolicy = executionPolicy,
            outcomeVerifier = outcomeVerifier,
            causalReadiness = causalReadiness,
            miniPeerReview = miniPeerReview,
            scientificWeights = scientificWeights,
            datasetForaging = datasetForaging,
            discoveryReadiness = discoveryReadiness,
            learningOs = learningOs
        )
        val unresolvedCore = normalizeEvidence(
            metaStrategy.forcedEvidenceKeys +
                probeOutcomeLedger.unresolvedEvidenceKeys +
                outcomeVerifier.unmetEvidenceKeys +
                executionPolicy.forcedEvidenceKeys +
                currentProbePlan.evidencePack +
                causalReadiness.blockers
        ).filter { it in coreEvidenceKeys || it.contains("outcome", true) || it.contains("control", true) || it.contains("time", true) || it.contains("metadata", true) }
        val routeFitOnly = datasetForaging.scoreSeparation.routeFitScore >= 85 && datasetForaging.scoreSeparation.datasetUsabilityScore < 70
        val metadataOnly = datasetForaging.candidates.isNotEmpty() && datasetForaging.parsedMetadata.isEmpty()
        val replayPenalty = probeOutcomeLedger.replayPenaltyKeys.isNotEmpty() || executionPolicy.queryReplayBlocks.isNotEmpty()
        val failedProbe = probeOutcomeLedger.killSignals.isNotEmpty() || (probeOutcomeLedger.active && probeOutcomeLedger.evidenceClosureScore < 35)
        val weakEvidenceReadiness = discoveryReadiness.score < 60 || discoveryReadiness.state.contains("CANDIDATE", true)
        val peerHold = miniPeerReview.verdict in setOf("HOLD", "REJECT")
        val scorePenalty = issues.sumOf { it.severity }.coerceAtMost(85)
        val scoreBonus = when {
            probeOutcomeLedger.evidenceClosureScore >= 75 && probeOutcomeLedger.killSignals.isEmpty() -> 18
            outcomeVerifier.policySucceeded -> 12
            else -> 0
        }
        val baseScore = 82 - scorePenalty + scoreBonus + (causalReadiness.level * 3)
        val qualityScore = baseScore.coerceIn(0, 100)
        val blockedReasons = issues.filter { it.severity >= 12 }.map { it.label }.distinct().take(10)
        val gateState = when {
            failedProbe || replayPenalty && blockedReasons.isNotEmpty() -> "QUALITY_BLOCK_REROUTE_REQUIRED"
            routeFitOnly || metadataOnly || unresolvedCore.isNotEmpty() || peerHold -> "QUALITY_HOLD_CLOSE_CORE_EVIDENCE"
            weakEvidenceReadiness -> "QUALITY_INSPECT_WITH_LIMITS"
            qualityScore >= 75 -> "QUALITY_PASS_BOUNDED_EXECUTION"
            else -> "QUALITY_GUARDED_EXECUTION"
        }
        val allowExecution = gateState in setOf("QUALITY_PASS_BOUNDED_EXECUTION", "QUALITY_GUARDED_EXECUTION", "QUALITY_INSPECT_WITH_LIMITS") && !failedProbe
        val executionDecision = when (gateState) {
            "QUALITY_BLOCK_REROUTE_REQUIRED" -> "Do not execute the same route. Reroute or archive until new parent evidence appears."
            "QUALITY_HOLD_CLOSE_CORE_EVIDENCE" -> "Hold broad execution. Run only the evidence-closure query required by the quality gate."
            "QUALITY_INSPECT_WITH_LIMITS" -> "Allow one bounded inspection step; no upgrade or broad mechanism language."
            "QUALITY_PASS_BOUNDED_EXECUTION" -> "Allow bounded execution of the selected strategy with pass/fail/kill gates."
            else -> "Allow guarded execution only if forced evidence keys are included."
        }
        val routeDisposition = when (gateState) {
            "QUALITY_BLOCK_REROUTE_REQUIRED" -> "REROUTE_OR_ARCHIVE"
            "QUALITY_HOLD_CLOSE_CORE_EVIDENCE" -> "EVIDENCE_CLOSURE_ONLY"
            "QUALITY_INSPECT_WITH_LIMITS" -> "INSPECT_ONLY"
            else -> "BOUNDED_EXECUTION"
        }
        val requiredBeforeRun = normalizeEvidence(
            issues.map { it.requiredBeforeRun } + unresolvedCore + when {
                routeFitOnly -> listOf("minimum_metadata", "outcome_labels", "comparator_control", "time_order")
                metadataOnly -> listOf("minimum_metadata", "sample_size", "condition_labels", "license_readiness")
                else -> emptyList()
            }
        ).take(20)
        val forcedEvidence = normalizeEvidence(
            requiredBeforeRun + metaStrategy.forcedEvidenceKeys + issues.map { it.evidenceKey } +
                if (!allowExecution) listOf("new_parent_evidence", "non_replay_query") else emptyList()
        ).take(32)
        val forcedTerms = normalizeTerms(
            forcedEvidence.flatMap { evidenceToTerms(it) } +
                issues.flatMap { it.queryTerms } +
                compactTokens(executionDecision, 24) +
                compactTokens(currentProbePlan.selectedProbeQuery, 24) +
                compactTokens(metaStrategy.selectedStrategy, 18)
        ).take(72)
        val line = "v1.9.2 discovery quality gate: $gateState; score=$qualityScore/100; allow=$allowExecution; required=${forcedEvidence.take(5).joinToString("/").ifBlank { "none" }}."
        return ScientificDiscoveryQualityGateReport(
            active = true,
            version = "v1.9.2-discovery-quality-gate",
            gateState = gateState,
            qualityScore = qualityScore,
            executionDecision = executionDecision.take(360),
            allowExecution = allowExecution,
            selectedStrategy = metaStrategy.selectedStrategy.take(280),
            blockedBecause = blockedReasons,
            qualityIssues = issues.sortedByDescending { it.severity }.take(8),
            requiredBeforeRun = requiredBeforeRun,
            forcedDirectiveTerms = forcedTerms,
            forcedEvidenceKeys = forcedEvidence,
            routeDisposition = routeDisposition,
            reportLine = line.take(560),
            claimLimit = "discovery_quality_gate_routing_only_not_biological_proof"
        )
    }

    private fun buildIssues(
        metaStrategy: ScientificDiscoveryMetaStrategyReport,
        probeOutcomeLedger: ScientificDiscoveryProbeOutcomeLedgerReport,
        currentProbePlan: ScientificDiscoveryProbePlanReport,
        executionPolicy: ScientificDiscoveryExecutionPolicyReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport,
        causalReadiness: CausalReadinessReport,
        miniPeerReview: MiniPeerReviewReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        datasetForaging: DatasetForagingReport,
        discoveryReadiness: DiscoveryReadinessReport,
        learningOs: LearningOsReport
    ): List<DiscoveryQualityIssueCard> {
        val issues = mutableListOf<DiscoveryQualityIssueCard>()
        fun add(id: String, severity: Int, label: String, key: String, required: String, effect: String, terms: List<String>) {
            issues += DiscoveryQualityIssueCard(id, severity.coerceIn(1, 30), label, key, required, effect, normalizeTerms(terms).take(16))
        }
        if (datasetForaging.scoreSeparation.routeFitScore >= 85 && datasetForaging.scoreSeparation.datasetUsabilityScore < 70) {
            add("route_fit_unpaid", 22, "High route-fit is not paid by dataset usability.", "minimum_metadata", "minimum_metadata", "hold_route_until_metadata", listOf("metadata", "sample size", "condition labels", "license", "GEO", "SRA"))
        }
        if (datasetForaging.candidates.isNotEmpty() && datasetForaging.parsedMetadata.isEmpty()) {
            add("metadata_not_parsed", 20, "Dataset candidate is still metadata/title-level.", "minimum_metadata", "minimum_metadata", "parser_required_before_next_claim", listOf("metadata", "parsed", "sample", "control", "outcome"))
        }
        val unresolved = normalizeEvidence(metaStrategy.forcedEvidenceKeys + probeOutcomeLedger.unresolvedEvidenceKeys + outcomeVerifier.unmetEvidenceKeys + currentProbePlan.evidencePack)
        listOf("outcome_labels", "time_order", "comparator_control").forEach { key ->
            if (unresolved.any { it.contains(key, true) || key.contains(it, true) }) {
                add("missing_$key", 18, "Core evidence key still unresolved: $key.", key, key, "evidence_closure_only", evidenceToTerms(key))
            }
        }
        if (probeOutcomeLedger.replayPenaltyKeys.isNotEmpty() || executionPolicy.queryReplayBlocks.isNotEmpty()) {
            add("replay_penalty_active", 18, "Replay penalty is active; same probe/query cannot be reused unchanged.", "non_replay_query", "non_replay_query", "block_same_query_replay", listOf("independent dataset", "different cohort", "new comparator", "not replay"))
        }
        if (probeOutcomeLedger.killSignals.isNotEmpty()) {
            add("probe_kill_signal", 25, "Previous probe produced kill signals.", "new_parent_evidence", "new_parent_evidence", "reroute_or_archive", listOf("new parent evidence", "alternative route", "archive", "reroute"))
        }
        if (causalReadiness.level < 3) {
            add("causal_readiness_low", 14, "Causal readiness is below controlled-comparison level.", "controlled_comparison", "comparator_control", "no_causal_language", listOf("controlled comparison", "negative control", "time order"))
        }
        if (miniPeerReview.verdict in setOf("HOLD", "REJECT")) {
            add("peer_review_hold", 16, "Mini peer review blocks broad execution: ${miniPeerReview.strongestObjection.take(90)}", "peer_objection", miniPeerReview.missingEvidence.firstOrNull() ?: "peer_objection", "objection_first", compactTokens(miniPeerReview.strongestObjection, 14))
        }
        if (scientificWeights.downgradedFalseFriends.isNotEmpty()) {
            add("false_friend_risk", 12, "Scientific false-friend terms need downgrade before routing.", "false_friend_guard", "false_friend_guard", "downgrade_false_friend", scientificWeights.downgradedFalseFriends.take(5))
        }
        if (learningOs.incident.rootCauses.any { it.contains("NO_OUTCOME", true) || it.contains("METADATA", true) }) {
            add("learning_os_repeated_gap", 14, "Learning OS still reports repeated evidence-gap root cause.", "failure_pattern_memory", "evidence_key_closure", "dampen_repeat_failure", learningOs.incident.rootCauses.flatMap { compactTokens(it, 5) })
        }
        if (discoveryReadiness.score < 50) {
            add("readiness_low", 12, "Discovery readiness is below execution quality threshold.", "evidence_readiness", "evidence_readiness", "inspect_or_hold", discoveryReadiness.blockers.flatMap { compactTokens(it, 5) })
        }
        return issues.distinctBy { it.issueId }
    }

    private val coreEvidenceKeys = setOf(
        "minimum_metadata", "outcome_labels", "time_order", "comparator_control", "controlled_comparison",
        "human_or_patient_data", "sample_size", "condition_labels", "negative_control", "metadata"
    )

    private fun normalizeEvidence(values: List<String>): List<String> = values
        .map { it.trim().lowercase(Locale.US).replace(Regex("[^a-z0-9_]+"), "_").trim('_') }
        .filter { it.isNotBlank() }
        .distinct()

    private fun normalizeTerms(values: List<String>): List<String> = values
        .flatMap { it.split(Regex("\\s+")) }
        .map { it.trim().lowercase(Locale.US).replace(Regex("[^a-z0-9_+-]"), "") }
        .filter { it.length >= 3 && it !in stopTerms }
        .distinct()

    private fun compactTokens(text: String, max: Int): List<String> = normalizeTerms(listOf(text)).take(max)

    private fun evidenceToTerms(key: String): List<String> = when {
        key.contains("outcome", true) -> listOf("outcome", "severity", "recovery", "response", "endpoint")
        key.contains("time", true) -> listOf("longitudinal", "time-course", "serial", "follow-up", "baseline")
        key.contains("control", true) || key.contains("comparator", true) -> listOf("control", "comparator", "placebo", "negative control")
        key.contains("metadata", true) -> listOf("metadata", "sample size", "condition labels", "license")
        key.contains("human", true) -> listOf("human", "patient", "cohort", "clinical phenotype")
        else -> compactTokens(key.replace('_', ' '), 6)
    }

    private val stopTerms = setOf("the", "and", "with", "for", "from", "that", "this", "into", "only", "before", "after", "because", "without", "route", "query")
}
