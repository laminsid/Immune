package com.immunesignal.app

/** v1.5.8: report consistency guard for route-fit / parsing / upgrade state. */
data class ReportConsistencyGuardReport(
    val active: Boolean,
    val status: String,
    val warnings: List<String>,
    val requiredReportLanguage: String,
    val claimLimit: String = "report_consistency_not_biological_proof"
) {
    companion object {
        fun empty() = ReportConsistencyGuardReport(
            active = false,
            status = "NOT_EVALUATED",
            warnings = emptyList(),
            requiredReportLanguage = "Report consistency guard was not evaluated in this cycle."
        )
    }

}

object ReportConsistencyGuard {
    fun evaluate(
        routeFits: List<DatasetRouteFitAssessment>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        scoreSeparation: DatasetScoreSeparation,
        candidateActionReport: CandidateActionReport
    ): ReportConsistencyGuardReport {
        val warnings = mutableListOf<String>()
        val maxRouteFit = routeFits.maxOfOrNull { it.routeFitScore } ?: 0
        if (maxRouteFit >= 85 && parsedMetadata.isEmpty()) {
            warnings += "High route-fit candidate exists but no parsed metadata is present; report must state MINIMUM_METADATA_REQUIRED."
        }
        if (scoreSeparation.hypothesisUpgradeAllowed && parsedMetadata.isEmpty()) {
            warnings += "Hypothesis upgrade cannot be treated as actionable while parsed metadata is empty."
        }
        if (candidateActionReport.minimumMetadataAccessions.isNotEmpty() && parsedMetadata.none { it.accession in candidateActionReport.minimumMetadataAccessions }) {
            warnings += "Minimum metadata was forced but no matching parsed metadata object is visible."
        }
        val status = if (warnings.isEmpty()) "PASS" else "CAUTION"
        val language = if (warnings.isEmpty()) {
            "Report state is internally consistent: route-fit, parsing, and upgrade language are aligned."
        } else {
            "Route fit may be high, but upgrade remains BLOCKED_UNTIL_METADATA_PARSED; auto-light learning should queue a micro-follow-up rather than claiming evidence."
        }
        return ReportConsistencyGuardReport(
            active = true,
            status = status,
            warnings = warnings.distinct(),
            requiredReportLanguage = language
        )
    }

    fun preventArchiveProbeConflict(
        foragerState: String,
        foragerNextAction: String,
        nextProbeExists: Boolean
    ): Pair<String, String> {
        val archiveRequested = foragerState.contains("ARCHIVE", ignoreCase = true) ||
            foragerNextAction.contains("archive", ignoreCase = true)
        return if (nextProbeExists && archiveRequested) {
            "DATASET_FORAGING_CONTINUE_PROBE" to
                "Continue probe: a next dataset lead/probe exists, so archive is downgraded to continue_probe by v1.10.31 Report Consistency Guard."
        } else {
            foragerState to foragerNextAction
        }
    }

    fun includePathLinkageWarnings(
        base: ReportConsistencyGuardReport,
        pathLinkageReport: DatasetForagingPathLinkageReport,
        learningDomainPathLinkageReport: LearningDomainPathLinkageReport = LearningDomainPathLinkageReport.empty()
    ): ReportConsistencyGuardReport {
        val extraWarnings = mutableListOf<String>()
        if (pathLinkageReport.warnings.isNotEmpty()) {
            extraWarnings += pathLinkageReport.warnings.map { "Dataset path linkage: $it" }
        }
        if (pathLinkageReport.state.contains("WARNINGS", ignoreCase = true) && pathLinkageReport.warnings.isEmpty()) {
            extraWarnings += "Dataset path linkage: state=${pathLinkageReport.state} reported a linkage warning state without explicit warning text."
        }
        if (learningDomainPathLinkageReport.warnings.isNotEmpty()) {
            extraWarnings += learningDomainPathLinkageReport.warnings.map { "Learning/domain linkage: $it" }
        }
        if (learningDomainPathLinkageReport.state.contains("WARNINGS", ignoreCase = true) && learningDomainPathLinkageReport.warnings.isEmpty()) {
            extraWarnings += "Learning/domain linkage: state=${learningDomainPathLinkageReport.state} reported a linkage warning state without explicit warning text."
        }
        val baseNeedsCaution = base.warnings.isNotEmpty() && base.status.equals("PASS", ignoreCase = true)
        if (extraWarnings.isEmpty() && !baseNeedsCaution) return base
        val mergedWarnings = (base.warnings + extraWarnings).distinct()
        return base.copy(
            active = true,
            status = "CAUTION",
            warnings = mergedWarnings,
            requiredReportLanguage = "Report consistency blocked: unresolved path-linkage warnings remain, so the next action must repair or explicitly consume the handoff before archive or autonomous continuation."
        )
    }

}
