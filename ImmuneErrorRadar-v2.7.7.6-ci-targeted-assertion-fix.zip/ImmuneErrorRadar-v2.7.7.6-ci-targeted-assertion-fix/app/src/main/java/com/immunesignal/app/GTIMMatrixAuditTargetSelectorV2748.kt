package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.7.4.8 — Contract-governed Matrix Audit Target Selector.
 *
 * The matrix card must not audit a stale/first accession if it belongs to a blocked
 * template. This selector scores every accession handle against the active contract,
 * context terms, blocked concepts, and known seed provenance.
 */
data class GTIMMatrixAuditTargetCandidateV2748(
    val id: String,
    val source: String,
    val context: String,
    val score: Int,
    val reason: String
)

object GTIMMatrixAuditTargetSelectorV2748 {
    const val VERSION: String = "2.7.4.8-contract-governed-matrix-target-selector"

    private val knownTopicSeedHints: Map<String, String> = mapOf(
        "GSE250594" to "allergy_type2_ige_mast_eosinophil",
        "GSE152202" to "covid_interferon_cytokine_bridge",
        "GSE166552" to "covid_interferon_cytokine_bridge",
        "GSE152418" to "covid_interferon_cytokine_bridge",
        "GSE157103" to "covid_interferon_cytokine_bridge",
        "GSE93798" to "ebola_hemorrhagic_viral_host_response",
        "GSE72056" to "ebola_hemorrhagic_viral_host_response",
        "GSE131907" to "ebola_hemorrhagic_viral_host_response",
        "GSE25628" to "ebola_hemorrhagic_viral_host_response"
    )

    fun select(
        report: JSONObject,
        contract: GTIMRunDecisionContractV2740,
        fallbackSeedHandles: List<String>,
        paperUnderstandingSummary: String
    ): GTIMMatrixAuditTargetCandidateV2748? = selectScored(report, contract, fallbackSeedHandles, paperUnderstandingSummary)

    private fun collectCandidatesScored(
        report: JSONObject,
        contract: GTIMRunDecisionContractV2740,
        fallbackSeedHandles: List<String>,
        paperUnderstandingSummary: String
    ): List<GTIMMatrixAuditTargetCandidateV2748> {
        val text = report.toString()
        val rootCandidates = mutableListOf<RawCandidate>()
        rootCandidates += extractFromJson(report, "report")
        fallbackSeedHandles.forEach { rootCandidates += RawCandidate(it, "fallbackSeedHandles", it) }
        extractAccessionRegex(text).forEach { rootCandidates += RawCandidate(it, "reportRegex", contextAround(text, it)) }
        extractAccessionRegex(paperUnderstandingSummary).forEach { rootCandidates += RawCandidate(it, "paperLite", paperUnderstandingSummary) }
        return rootCandidates
            .filter { looksLikeAccession(it.id) }
            .map { raw ->
                val score = scoreCandidate(raw, contract, text)
                GTIMMatrixAuditTargetCandidateV2748(
                    id = canonicalAccession(raw.id),
                    source = raw.source,
                    context = raw.context.take(360),
                    score = score,
                    reason = reasonFor(raw, contract, score)
                )
            }
            .groupBy { it.id }
            .mapNotNull { (_, candidates) -> candidates.maxByOrNull { it.score } }
    }

    fun selectScored(
        report: JSONObject,
        contract: GTIMRunDecisionContractV2740,
        fallbackSeedHandles: List<String>,
        paperUnderstandingSummary: String
    ): GTIMMatrixAuditTargetCandidateV2748? {
        val best = collectCandidatesScored(report, contract, fallbackSeedHandles, paperUnderstandingSummary)
            .maxWithOrNull(compareBy<GTIMMatrixAuditTargetCandidateV2748> { it.score }.thenBy { it.id.length })
        // v2.7.5.0: do not select a visible matrix target merely because a GSE/PMID exists.
        // It must be compatible with the active anchor or explicitly hinted to this topic.
        return best?.takeIf { it.score >= minimumAcceptScore(contract) }
    }

    private data class RawCandidate(val id: String, val source: String, val context: String)

    private fun extractFromJson(value: Any?, source: String): List<RawCandidate> {
        val out = mutableListOf<RawCandidate>()
        when (value) {
            is JSONObject -> {
                val keys = value.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val v = value.opt(key)
                    val asText = when (v) {
                        is JSONObject, is JSONArray -> ""
                        else -> v?.toString().orEmpty()
                    }
                    // v2.7.5.3: never promote a whole query like "GSE OR PRJNA" to a bare target "GSE".
                    GTIMAccessionIdValidityGuardV2753.extractFullAccessions(asText).forEach { acc ->
                        out += RawCandidate(acc, "$source.$key", value.toString().take(500))
                    }
                    out += extractFromJson(v, "$source.$key")
                }
            }
            is JSONArray -> {
                for (i in 0 until value.length()) out += extractFromJson(value.opt(i), "$source.$i")
            }
            is String -> {
                extractAccessionRegex(value).forEach { out += RawCandidate(it, source, value) }
            }
        }
        return out
    }

    private fun scoreCandidate(raw: RawCandidate, contract: GTIMRunDecisionContractV2740, fullReportText: String): Int {
        val id = canonicalAccession(raw.id)
        val context = listOf(raw.context, contract.rawQuery, contract.primaryAnchor.routeId).joinToString(" ")
        val reportContext = listOf(raw.context, fullReportText.take(1200)).joinToString(" ")
        val normalizedContext = GTIMCanonicalRouteIdentityV2748.normalize(context)
        var score = 10
        val hintedRoute = knownTopicSeedHints[id]
        val hintedCompatible = hintedRoute != null && GTIMDiseaseSpecificSeedPoolGuardV2750.isTopicRouteCompatible(hintedRoute, contract)
        if (hintedRoute != null && hintedCompatible) score += 140
        if (hintedRoute != null && !hintedCompatible) score -= 280
        if (GTIMCanonicalRouteIdentityV2748.isAnchorCompatibleText(context, contract)) score += 75
        if (GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(raw.context, contract)) score += 25 else score -= 110
        if (GTIMCanonicalRouteIdentityV2748.isAnchorCompatibleText(reportContext, contract)) score += 20
        if (raw.source.contains("primarySeed", true)) score += 12
        if (raw.source.contains("paperLite", true)) score += 18
        if (raw.source.contains("fallback", true)) score += 6
        when (contract.primaryAnchor) {
            GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> if (containsAny(normalizedContext, "ebola", "evd", "filovirus", "hemorrhagic")) score += 50
            GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> if (containsAny(normalizedContext, "covid", "sars cov 2", "long covid", "pasc")) score += 50
            GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> if (containsAny(normalizedContext, "allergy", "allergies", "ige", "mast cell", "eosinophil")) score += 50
            GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> if (containsAny(normalizedContext, "microbiome", "depression", "tryptophan", "kynurenine")) score += 50
            GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> if (containsAny(normalizedContext, "hanta", "hantavirus", "hfrs", "hcps", "zoonotic")) score += 50
            GTIMPrimaryAnchorV2740.FATIGUE_SYNDROME_NEUROIMMUNE_METABOLIC -> if (containsAny(normalizedContext, "fatigue", "post viral", "mitochondrial", "hpa", "sleep", "mecfs", "me cfs")) score += 50
            GTIMPrimaryAnchorV2740.DIABETES_METABOLIC_INFLAMMATION,
            GTIMPrimaryAnchorV2740.T2D_INSULIN_RESISTANCE_INFLAMMATION -> if (containsAny(normalizedContext, "diabetes", "diabetic", "glucose", "insulin", "hba1c", "glycemic", "metabolic")) score += 50
            GTIMPrimaryAnchorV2740.THYROID_HASHIMOTO_AUTOIMMUNE -> if (containsAny(normalizedContext, "hashimoto", "thyroid", "thyroiditis", "hypothyroid", "tpo")) score += 50
            GTIMPrimaryAnchorV2740.PCOS_REPRODUCTIVE_METABOLIC -> if (containsAny(normalizedContext, "pcos", "polycystic", "ovary", "androgen", "insulin resistance")) score += 50
            GTIMPrimaryAnchorV2740.ASTHMA_TYPE2_AIRWAY -> if (containsAny(normalizedContext, "asthma", "asthmatic", "airway", "wheeze", "type 2")) score += 50
            else -> Unit
        }
        return score
    }

    private fun reasonFor(raw: RawCandidate, contract: GTIMRunDecisionContractV2740, score: Int): String {
        val id = canonicalAccession(raw.id)
        val hinted = knownTopicSeedHints[id]
        return when {
            hinted != null && GTIMDiseaseSpecificSeedPoolGuardV2750.isTopicRouteCompatible(hinted, contract) -> "known topic-compatible seed for ${contract.primaryAnchor.routeId}; score=$score"
            hinted != null && !GTIMDiseaseSpecificSeedPoolGuardV2750.isTopicRouteCompatible(hinted, contract) -> "known seed route $hinted blocked by active contract ${contract.primaryAnchor.routeId}; score=$score"
            else -> "ranked by active contract compatibility, source=${raw.source}; score=$score"
        }
    }

    private fun minimumAcceptScore(contract: GTIMRunDecisionContractV2740): Int {
        return when (contract.primaryAnchor) {
            GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY -> 20
            GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION,
            GTIMPrimaryAnchorV2740.FATIGUE_SYNDROME_NEUROIMMUNE_METABOLIC,
            GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> 80
            else -> 60
        }
    }

    private fun contextAround(text: String, token: String): String {
        val idx = text.indexOf(token, ignoreCase = true)
        if (idx < 0) return text.take(240)
        val start = (idx - 160).coerceAtLeast(0)
        val end = (idx + token.length + 160).coerceAtMost(text.length)
        return text.substring(start, end)
    }

    private fun extractAccessionRegex(text: String): List<String> {
        return GTIMAccessionIdValidityGuardV2753.extractFullAccessions(text)
    }

    private fun looksLikeAccession(value: String): Boolean = GTIMAccessionIdValidityGuardV2753.isFullAccession(value)

    private fun canonicalAccession(value: String): String {
        return GTIMAccessionIdValidityGuardV2753.canonical(value)
    }

    private fun containsAny(text: String, vararg needles: String): Boolean = needles.any { text.contains(it) }
}
