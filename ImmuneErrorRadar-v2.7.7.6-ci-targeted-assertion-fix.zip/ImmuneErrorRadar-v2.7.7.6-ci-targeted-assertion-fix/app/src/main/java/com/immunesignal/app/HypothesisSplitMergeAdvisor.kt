package com.immunesignal.app

data class HypothesisSplitMergeSuggestion(
    val action: String,
    val rationale: String,
    val target: String,
    val claimLimit: String = HypothesisSplitMergeAdvisor.CLAIM_LIMIT
)

/** v1.10.21: advisory-only split/merge layer; no HypothesisObject mutation yet. */
object HypothesisSplitMergeAdvisor {
    const val CLAIM_LIMIT = "hypothesis_split_merge_advice_not_biological_proof"

    fun advise(lineage: ScientificDiscoveryLineageReport): List<HypothesisSplitMergeSuggestion> {
        if (!lineage.active) return emptyList()
        val out = mutableListOf<HypothesisSplitMergeSuggestion>()
        if (lineage.splitRequired) {
            out += HypothesisSplitMergeSuggestion(
                action = "SPLIT_SUGGESTED",
                rationale = "Lineage reports splitRequired; keep mechanism branches separate until parent evidence and contradiction are explicit.",
                target = lineage.hypothesisLineages.firstOrNull()?.hypothesisId ?: "active_hypotheses_${lineage.activeHypotheses}"
            )
        }
        lineage.mergeCandidates.take(3).forEach { candidate ->
            out += HypothesisSplitMergeSuggestion(
                action = "MERGE_CANDIDATE_REQUIRES_PARENT_EVIDENCE",
                rationale = "Merge candidate must share parent evidence and pass outcome/control/time checks before merging.",
                target = candidate
            )
        }
        return out
    }
}
