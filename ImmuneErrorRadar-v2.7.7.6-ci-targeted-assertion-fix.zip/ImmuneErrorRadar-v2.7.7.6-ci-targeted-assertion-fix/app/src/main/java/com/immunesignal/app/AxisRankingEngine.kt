package com.immunesignal.app

/**
 * AxisRankingEngine: Intelligent axis prioritization
 * 
 * Uses a sophisticated scoring system to determine which biological axis
 * best explains the research question/dataset.
 * 
 * Formula:
 * finalScore = 0.35*matchScore + 0.25*specificity + 0.25*completeness + 0.10*priorSuccess - 0.15*penalty
 * 
 * Key Principle:
 * Specificity beats generality
 * Evidence completeness beats keyword overlap
 * Human/time-course/outcome raise priority
 * Generic inflammation alone never wins
 */

class AxisRankingEngine(
    private val accuracyLedger: FoundationKnowledgeAccuracyLedger? = null,
    private val patchLedger: FoundationPatchSuggestionLedger? = null
) {

    /**
     * Compute final ranked axes with all factors considered
     */
    fun computeFinalRanking(
        axes: List<RankedAxis>,
        strengthenByDatasetQuality: Boolean = false
    ): List<RankedAxis> {

        if (axes.isEmpty()) return emptyList()

        // Boost scores based on historical accuracy if available
        val boostedAxes = axes.map { axis ->
            val historicalBoost = accuracyLedger?.getAccuracyBoost(axis.axisId) ?: 0f
            val patchPenalty = patchLedger?.getPatchPenalty(axis.axisId) ?: 0f

            axis.copy(
                finalScore = (axis.finalScore + historicalBoost - patchPenalty).coerceIn(0f, 1f)
            )
        }

        // Sort by final score
        return boostedAxes.sortedByDescending { it.finalScore }
    }

    /**
     * Select primary axis with confidence assessment
     */
    fun selectPrimaryAxis(rankedAxes: List<RankedAxis>): PrimaryAxisSelection {
        if (rankedAxes.isEmpty()) {
            return PrimaryAxisSelection(
                selectedAxis = null,
                confidence = "NONE",
                reason = "No axes matched the query",
                scoreGap = 1f
            )
        }

        val primary = rankedAxes.first()
        val secondary = if (rankedAxes.size > 1) rankedAxes[1] else null

        // Calculate confidence based on score gap
        val scoreGap = if (secondary != null) {
            primary.finalScore - secondary.finalScore
        } else {
            primary.finalScore
        }

        val confidence = when {
            scoreGap > 0.30f && primary.finalScore > 0.75f -> "HIGH"
            scoreGap > 0.15f && primary.finalScore > 0.60f -> "MEDIUM"
            scoreGap > 0.05f && primary.finalScore > 0.40f -> "LOW"
            else -> "UNCERTAIN"
        }

        return PrimaryAxisSelection(
            selectedAxis = primary,
            confidence = confidence,
            reason = buildSelectionReason(primary, secondary),
            scoreGap = scoreGap
        )
    }

    /**
     * Detect conflicting axes (multiple strong matches)
     */
    fun detectAxisConflicts(rankedAxes: List<RankedAxis>): AxisConflict? {
        if (rankedAxes.size < 2) return null

        val primary = rankedAxes[0]
        val secondary = rankedAxes[1]

        // Conflict if both have decent scores but differ significantly
        if (primary.finalScore > 0.50f && secondary.finalScore > 0.45f &&
            (primary.finalScore - secondary.finalScore) < 0.10f) {

            return AxisConflict(
                primaryAxis = primary.axisId,
                secondaryAxis = secondary.axisId,
                primaryScore = primary.finalScore,
                secondaryScore = secondary.finalScore,
                resolutionHint = buildConflictResolution(primary, secondary),
                severity = "MODERATE"
            )
        }

        return null
    }

    /**
     * Check for overfitting to generic axes (generic_inflammation, etc)
     */
    fun checkGenericInflationRisk(rankedAxes: List<RankedAxis>): GenericInflationRisk? {
        if (rankedAxes.isEmpty()) return null

        val primary = rankedAxes.first()

        // Generic axes should have high specificity penalty
        val isGeneric = listOf("generic_inflammation", "rna_transcriptomic_state")
            .contains(primary.axisId)

        if (isGeneric && primary.specificityScore < 0.5f) {
            return GenericInflationRisk(
                axisId = primary.axisId,
                riskLevel = "HIGH",
                recommendation = "Require more specific axis. Generic inflammation alone insufficient.",
                suggestedMinSpecificity = 0.65f
            )
        }

        return null
    }

    /**
     * Recommend axis switching if primary is weak
     */
    fun recommendAxisSwitch(
        currentAxis: RankedAxis,
        allRankedAxes: List<RankedAxis>,
        failureReason: String
    ): AxisSwitch? {

        if (allRankedAxes.size < 2) return null

        // Find next best axis
        val nextBest = allRankedAxes.filter { it.axisId != currentAxis.axisId }
            .sortedByDescending { it.finalScore }
            .firstOrNull() ?: return null

        // Only recommend if next is reasonably close
        if ((nextBest.finalScore - currentAxis.finalScore).coerceAtLeast(0f) > -0.15f) {
            return AxisSwitch(
                currentAxis = currentAxis.axisId,
                recommendedAxis = nextBest.axisId,
                reason = failureReason,
                scoreImprovement = nextBest.finalScore - currentAxis.finalScore,
                confidence = "MEDIUM"
            )
        }

        return null
    }

    /**
     * Build human-readable reason for selection
     */
    private fun buildSelectionReason(
        primary: RankedAxis,
        secondary: RankedAxis?
    ): String {
        val sb = StringBuilder()

        sb.append("Selected ${primary.axisId} ")
        sb.append("(score: ${String.format("%.2f", primary.finalScore)})")

        if (secondary != null) {
            val gap = primary.finalScore - secondary.finalScore
            sb.append(" over ${secondary.axisId} ")
            sb.append("(gap: ${String.format("%.2f", gap)})")
        }

        sb.append(". Evidence present: ${primary.presentEvidence.size}, ")
        sb.append("Missing: ${primary.criticalEvidenceMissing.size}")

        return sb.toString()
    }

    /**
     * Build conflict resolution hint
     */
    private fun buildConflictResolution(primary: RankedAxis, secondary: RankedAxis): String {
        val primaryCompleteness = primary.presentEvidence.size.toFloat() / 
            (primary.presentEvidence.size + primary.criticalEvidenceMissing.size)
        val secondaryCompleteness = secondary.presentEvidence.size.toFloat() / 
            (secondary.presentEvidence.size + secondary.criticalEvidenceMissing.size)

        return if (primaryCompleteness > secondaryCompleteness) {
            "Primary axis has better evidence completeness. Proceed with caution on both."
        } else if (secondaryCompleteness > primaryCompleteness) {
            "Secondary axis has better evidence fit. Consider switching axes."
        } else {
            "Both axes have similar evidence. Treat both as mechanisms, not primary hypothesis."
        }
    }

    /**
     * Validate ranking makes biological sense
     */
    fun validateRanking(rankedAxes: List<RankedAxis>): RankingValidation {
        if (rankedAxes.isEmpty()) {
            return RankingValidation(
                isValid = false,
                issues = listOf("No axes to rank"),
                warnings = emptyList()
            )
        }

        val issues = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        // Check for anomalies
        val primary = rankedAxes.first()

        if (primary.finalScore < 0.35f) {
            warnings.add("Primary axis score is low (${String.format("%.2f", primary.finalScore)}). Consider OFF_ROUTE.")
        }

        if (primary.specificityScore < 0.3f) {
            warnings.add("Primary axis low specificity. May be false match.")
        }

        // Check score distribution
        val scores = rankedAxes.map { it.finalScore }
        val avgScore = scores.average()
        val variance = scores.map { (it - avgScore) * (it - avgScore) }.average()

        if (variance < 0.01f && scores.size > 2) {
            warnings.add("All axes have very similar scores. Ranking unreliable.")
        }

        return RankingValidation(
            isValid = issues.isEmpty(),
            issues = issues,
            warnings = warnings
        )
    }

    /**
     * Get diagnostic info about ranking
     */
    fun getRankingDiagnostics(rankedAxes: List<RankedAxis>): String {
        val sb = StringBuilder()

        sb.append("=== RANKING DIAGNOSTICS ===\n")
        sb.append("Total axes evaluated: ${rankedAxes.size}\n\n")

        rankedAxes.take(5).forEachIndexed { index, axis ->
            sb.append("${index + 1}. ${axis.axisId}\n")
            sb.append("   Final Score: ${String.format("%.3f", axis.finalScore)}\n")
            sb.append("   Match: ${String.format("%.2f", axis.matchScore)} | ")
            sb.append("Specificity: ${String.format("%.2f", axis.specificityScore)} | ")
            sb.append("Completeness: ${String.format("%.2f", axis.evidenceCompletenessScore)}\n")
            sb.append("   Evidence Present: ${axis.presentEvidence.size} | ")
            sb.append("Missing: ${axis.criticalEvidenceMissing.size}\n")
            sb.append("   Reason: ${axis.reason}\n\n")
        }

        return sb.toString()
    }
}

// ============ DATA CLASSES ============

data class PrimaryAxisSelection(
    val selectedAxis: RankedAxis?,
    val confidence: String,      // HIGH, MEDIUM, LOW, UNCERTAIN, NONE
    val reason: String,
    val scoreGap: Float          // Distance to second place
)

data class AxisConflict(
    val primaryAxis: String,
    val secondaryAxis: String,
    val primaryScore: Float,
    val secondaryScore: Float,
    val resolutionHint: String,
    val severity: String         // LOW, MODERATE, HIGH
)

data class GenericInflationRisk(
    val axisId: String,
    val riskLevel: String,       // LOW, MEDIUM, HIGH
    val recommendation: String,
    val suggestedMinSpecificity: Float
)

data class AxisSwitch(
    val currentAxis: String,
    val recommendedAxis: String,
    val reason: String,
    val scoreImprovement: Float,
    val confidence: String       // HIGH, MEDIUM, LOW
)

data class RankingValidation(
    val isValid: Boolean,
    val issues: List<String>,
    val warnings: List<String>
)
