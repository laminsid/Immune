package com.immunesignal.app

data class ProposedPlausibilityEdge(
    val axes: Set<String>,
    val mechanism: String,
    val evidenceScore: Int,
    val state: String = "PROPOSED_EDGE_NEEDS_VALIDATION",
    val claimLimit: String = DynamicPlausibilityGraphLearner.CLAIM_LIMIT
)

/** v1.10.21: proposes graph edges but never writes them into the trusted graph automatically. */
object DynamicPlausibilityGraphLearner {
    const val CLAIM_LIMIT = "proposed_graph_edge_not_biological_proof"

    fun propose(findings: List<ResearchFinding>): List<ProposedPlausibilityEdge> = findings
        .filter { it.matchedAxes.size >= 2 && it.causality.causalityScore >= 50 }
        .map {
            ProposedPlausibilityEdge(
                axes = it.matchedAxes.take(3).toSet(),
                mechanism = it.bridgeSignal.ifBlank { it.title }.take(180),
                evidenceScore = it.evidence.evidenceQualityScore
            )
        }
        .distinctBy { it.axes.joinToString("|") }
        .take(8)
}
