package com.immunesignal.app

import org.json.JSONObject

data class EpistemicDistanceReportV262(
    val active: Boolean,
    val distanceScore: Double,
    val newBeliefs: Int,
    val strengthenedBeliefs: Int,
    val closedGaps: Int,
    val falsificationAttempts: Int,
    val summary: String,
    val claimLimit: String = EpistemicDistanceMeterV262.CLAIM_LIMIT
)

/** v2.6.3: measures real learning movement beyond accession-only progress. */
object EpistemicDistanceMeterV262 {
    const val CLAIM_LIMIT = "epistemic_distance_progress_metric_not_biological_proof"

    fun score(current: ResearchCycleReport? = null, previousReportJson: String? = null, beliefReport: EpistemicBeliefReport? = null, gapMiner: ScientificDiscoveryGapMinerReport? = null, miniPeerReview: MiniPeerReviewReport? = null): EpistemicDistanceReportV262 {
        if (!RuntimeFeatureFlags.ENABLE_EPISTEMIC_DISTANCE_METER_V262) return EpistemicDistanceReportV262(false, 0.0, 0, 0, 0, 0, "Epistemic distance meter disabled.")
        val belief = beliefReport ?: current?.epistemicBeliefReport ?: EpistemicBeliefReport.empty()
        val gaps = gapMiner ?: current?.scientificDiscoveryGapMinerReport ?: ScientificDiscoveryGapMinerReport.empty()
        val peer = miniPeerReview ?: current?.miniPeerReviewReport ?: MiniPeerReviewReport.empty()
        val prevGapIds = previousReportJson?.let { line ->
            val obj = runCatching { JSONObject(line) }.getOrNull() ?: return@let emptySet<String>()
            val miner = obj.optJSONObject("scientificDiscoveryGapMinerReport") ?: return@let emptySet<String>()
            val arr = miner.optJSONArray("latentOpportunities") ?: return@let emptySet<String>()
            buildSet {
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.optString("opportunityId")?.takeIf { it.isNotBlank() }?.let(::add)
            }
        } ?: emptySet()
        val currentGapIds = gaps.latentOpportunities.map { it.opportunityId }.toSet()
        val closed = prevGapIds.count { it !in currentGapIds }
        val strengthened = belief.beliefs.count { it.status == "ACTIVE_PRIOR" || it.status == "BELIEF_STRENGTHENED" }
        val falsification = listOf(peer.falsificationTest, peer.summary).count { it.isNotBlank() }
        val distance = belief.newBeliefsThisCycle * 2.0 + strengthened * 1.5 + closed * 3.0 + falsification * 2.5
        return EpistemicDistanceReportV262(
            active = true,
            distanceScore = distance,
            newBeliefs = belief.newBeliefsThisCycle,
            strengthenedBeliefs = strengthened,
            closedGaps = closed,
            falsificationAttempts = falsification,
            summary = "Epistemic distance=${"%.1f".format(distance)}; measures learning movement, not biological truth."
        )
    }
}
