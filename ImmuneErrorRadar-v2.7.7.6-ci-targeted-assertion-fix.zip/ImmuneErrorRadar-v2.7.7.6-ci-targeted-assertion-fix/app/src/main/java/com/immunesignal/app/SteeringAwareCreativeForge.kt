package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.13: converts scientific/user steering into explicit creative axes.
 * These axes are routing priors only. They never count as evidence and never
 * unlock hypothesis upgrades, causal language, or medical conclusions.
 */
data class SteeringAxis(
    val id: String,
    val label: String,
    val priority: Int,
    val rationale: String,
    val queryTerms: List<String>,
    val strengthenIf: List<String>,
    val killIf: List<String>,
    val evidenceKeys: List<String>,
    val claimLimit: String = "steering_axis_not_evidence"
)

data class ExpandedThinkingWindowReport(
    val active: Boolean,
    val mode: String,
    val reason: String,
    val maxHypotheses: Int,
    val allowedActions: List<String>,
    val blockedActions: List<String>,
    val claimLimit: String = "expanded_thinking_not_evidence"
) {
    companion object {
        fun empty() = ExpandedThinkingWindowReport(
            active = false,
            mode = "NORMAL_THINKING_WINDOW",
            reason = "Expanded thinking was not triggered.",
            maxHypotheses = 3,
            allowedActions = emptyList(),
            blockedActions = listOf("hypothesis_upgrade", "causal_language", "medical_claim"),
            claimLimit = "expanded_thinking_not_evidence"
        )
    }
}

object ExpandedThinkingWindowPolicy {
    fun evaluate(
        attemptedSourceFamilies: List<String>,
        noCandidateLearningRecords: List<NoCandidateLearningRecord>,
        steeringAxes: List<SteeringAxis>,
        terminalArchiveRequested: Boolean
    ): ExpandedThinkingWindowReport {
        val repeatedNoCandidate = noCandidateLearningRecords.map { it.sourceFamily }.distinct().size >= 2
        val advancedSearchReached = attemptedSourceFamilies.any {
            it == "PUBMED_ACCESSION_MINING" || it == "PUBMED_CONTRADICTION" || it == "PUBMED_CONTROL" || it == "ARCHIVE_OR_REFRAME_ROUTE"
        }
        val shouldExpand = repeatedNoCandidate || advancedSearchReached || terminalArchiveRequested || steeringAxes.isNotEmpty()
        if (!shouldExpand) return ExpandedThinkingWindowReport.empty()
        return ExpandedThinkingWindowReport(
            active = true,
            mode = "EXPANDED_CREATIVE_SEARCH_THINKING",
            reason = "Repeated no-candidate search or steering-axis pressure requires wider hypothesis generation, while evidence and claim gates remain locked.",
            maxHypotheses = 5,
            allowedActions = listOf(
                "generate_steering_aware_hypotheses",
                "rank_creative_routes",
                "produce_bounded_test_queries",
                "write_kill_criteria",
                "route_next_search"
            ),
            blockedActions = listOf(
                "hypothesis_upgrade_without_evidence_object",
                "causal_or_strong_signal_language",
                "medical_or_treatment_claim",
                "evidence_object_from_creative_hypothesis_only"
            ),
            claimLimit = "expanded_thinking_not_evidence"
        )
    }
}

object SteeringAxisResolver {
    fun resolve(
        steering: ResearchSteeringProfile?,
        shards: List<TestableHypothesisShard>,
        noCandidateLearningRecords: List<NoCandidateLearningRecord>
    ): List<SteeringAxis> {
        val steeringText = listOf(
            steering?.variables.orEmpty().joinToString(" "),
            steering?.requiredTerms.orEmpty().joinToString(" "),
            steering?.focusQuestion.orEmpty(),
            steering?.inferredAxes.orEmpty().joinToString(" "),
            shards.joinToString(" ") { it.label + " " + it.evidenceQuestion + " " + it.querySeeds.joinToString(" ") },
            noCandidateLearningRecords.joinToString(" ") { it.sourceFamily + " " + it.missing + " " + it.reason }
        ).joinToString(" ").lowercase(Locale.US)

        val axes = defaultAxes().map { axis ->
            val boost = when (axis.id) {
                "neuroimmunology" -> scoreBoost(steeringText, listOf("stress", "sleep", "neuro", "autonomic", "hpa", "gut-brain", "psychoneuro"))
                "immunometabolism" -> scoreBoost(steeringText, listOf("metabolism", "metabolic", "mitochond", "glycolysis", "energy", "immunometabolism"))
                "chronomedicine" -> scoreBoost(steeringText, listOf("time", "timing", "circadian", "day", "sampling", "chronomedicine", "time-course"))
                "exposome_microbiome" -> scoreBoost(steeringText, listOf("microbiome", "exposome", "environment", "gut", "dysbiosis", "tolerance", "allergy"))
                "in_silico_immunology" -> scoreBoost(steeringText, listOf("in silico", "simulation", "synthetic", "model", "computational", "ai"))
                else -> 0
            }
            axis.copy(priority = (axis.priority + boost).coerceIn(0, 120))
        }
        // Keep all five default scientific axes, but rank them by fit. This is deliberate:
        // user-provided scientific directions must compete inside the forge, not remain prose.
        return axes.sortedByDescending { it.priority }
    }

    private fun scoreBoost(text: String, terms: List<String>): Int = terms.count { text.contains(it) } * 6

    private fun defaultAxes(): List<SteeringAxis> = listOf(
        SteeringAxis(
            id = "neuroimmunology",
            label = "Neuroimmune recovery-modulation route",
            priority = 100,
            rationale = "Stress, sleep, autonomic tone, and gut-brain-immune regulation may explain why similar triggers produce different recovery trajectories.",
            queryTerms = listOf("human", "neuroimmune", "stress", "sleep", "HPA axis", "autonomic", "immune response", "responder", "nonresponder", "severity", "recovery", "longitudinal", "transcriptome", "cohort", "control", "comparator", "dataset", "accession"),
            strengthenIf = listOf("sleep/stress or autonomic labels", "human cohort", "recovery or severity outcome", "longitudinal sampling", "control/comparator group"),
            killIf = listOf("no neuro/stress/sleep/autonomic terms after contradiction/control search", "only generic cytokine markers", "no outcome or time-order labels"),
            evidenceKeys = listOf("outcome_labels", "time_order", "control_or_comparator", "minimum_metadata")
        ),
        SteeringAxis(
            id = "immunometabolism",
            label = "Immunometabolic early-signal route",
            priority = 92,
            rationale = "Metabolic reprogramming may precede cytokine-level changes and separate responder/non-responder immune trajectories.",
            queryTerms = listOf("human", "immunometabolism", "metabolic reprogramming", "mitochondrial", "glycolysis", "immune response", "responder", "nonresponder", "severity", "recovery", "longitudinal", "transcriptome", "metabolomics", "cohort", "control", "dataset", "accession"),
            strengthenIf = listOf("metabolomics or cellular metabolism assay", "responder/nonresponder labels", "clinical severity/recovery endpoint", "matched controls"),
            killIf = listOf("only pathway speculation", "no patient/cohort evidence", "no outcome labels"),
            evidenceKeys = listOf("outcome_labels", "control_or_comparator", "minimum_metadata")
        ),
        SteeringAxis(
            id = "chronomedicine",
            label = "Chronomedicine sampling-time contradiction route",
            priority = 88,
            rationale = "Time of day and circadian immune timing may explain contradictory immune-response results across cohorts.",
            queryTerms = listOf("circadian", "time of day", "sampling time", "immune response", "interferon", "T cell", "longitudinal", "time-course", "severity", "recovery", "human", "cohort", "control", "dataset", "accession"),
            strengthenIf = listOf("time-of-day or circadian labels", "serial samples", "baseline and recovery timepoints", "human cohort"),
            killIf = listOf("cross-sectional only", "no sampling-time metadata", "no comparator/control"),
            evidenceKeys = listOf("time_order", "minimum_metadata", "control_or_comparator")
        ),
        SteeringAxis(
            id = "exposome_microbiome",
            label = "Exposome/microbiome immune-brake route",
            priority = 84,
            rationale = "Environmental exposure and microbiome diversity may act as immune brakes that shift allergy/inflammation toward resolution or chronicity.",
            queryTerms = listOf("human", "microbiome", "exposome", "immune tolerance", "allergy", "inflammation resolution", "severity", "recovery", "longitudinal", "cohort", "control", "dataset", "accession"),
            strengthenIf = listOf("microbiome diversity labels", "environment/exposure metadata", "allergy or immune-tolerance cohort", "outcome/recovery labels"),
            killIf = listOf("environment-only without immune readout", "microbiome-only without outcome", "no longitudinal/control labels"),
            evidenceKeys = listOf("outcome_labels", "control_or_comparator", "time_order")
        ),
        SteeringAxis(
            id = "in_silico_immunology",
            label = "In-silico immunology hypothesis-simulation route",
            priority = 60,
            rationale = "Simulation and synthetic or computational immune models may generate hypotheses when human datasets are sparse, but cannot replace human evidence.",
            queryTerms = listOf("in silico immunology", "immune response simulation", "computational model", "responder", "nonresponder", "inflammation resolution", "hypothesis generation", "validation", "human dataset"),
            strengthenIf = listOf("model validated against human dataset", "explicit validation cohort", "clear prediction-to-test bridge"),
            killIf = listOf("simulation-only without validation", "no human dataset link", "no falsifiable prediction"),
            evidenceKeys = listOf("validation_dataset", "human_or_patient_data", "falsification_lane")
        )
    )
}
