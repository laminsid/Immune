package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.25: Data-availability accession query priority.
 *
 * v1.10.23 gave PUBMED_ACCESSION_MINING a deeper abstract window and v1.10.24
 * harvested accession/data-availability snippets from fetched abstracts. This
 * policy closes the loop by making accession-mining queries explicitly search
 * for data-availability/deposition language first, rather than spending the
 * deeper abstract budget on broad mechanism wording.
 *
 * Routing only: this does not prove biology, diagnosis, treatment response,
 * dosage, drug ranking, or causality.
 */
object DataAvailabilityAccessionQueryPolicy {
    const val CLAIM_LIMIT = "data_availability_query_priority_not_biological_proof"

    private val coreAvailabilityTerms = listOf(
        "data availability",
        "deposited",
        "accession",
        "GEO",
        "GSE",
        "SRA",
        "PRJNA",
        "SRP",
        "BioProject",
        "BioSample",
        "ArrayExpress",
        "E-MTAB",
        "ImmPort",
        "SDY",
        "dbGaP",
        "phs"
    )

    private val evidenceLabelTerms = listOf(
        "human",
        "patient",
        "cohort",
        "RNA-seq",
        "single-cell",
        "transcriptome",
        "sample metadata",
        "phenotype labels",
        "outcome",
        "severity",
        "recovery",
        "responder",
        "nonresponder",
        "longitudinal",
        "time-course",
        "control",
        "comparator"
    )

    fun queries(domainVocabulary: List<String> = emptyList()): List<String> {
        val domainTerms = domainVocabulary
            .map { sanitizeTerm(it) }
            .filter { it.length in 2..48 }
            .distinct()
            .take(RuntimeFeatureFlags.MAX_DATA_AVAILABILITY_DOMAIN_TERMS)
        val domainClause = if (domainTerms.isEmpty()) {
            ""
        } else {
            " (${domainTerms.joinToString(" OR ")})"
        }
        val labelClause = evidenceLabelTerms.take(RuntimeFeatureFlags.MAX_DATA_AVAILABILITY_LABEL_TERMS).joinToString(" ")
        return listOf(
            "\"data availability\" deposited accession GSE OR PRJNA OR SRP OR E-MTAB $labelClause$domainClause",
            "\"available under accession\" OR \"deposited in GEO\" human transcriptome outcome severity recovery control$domainClause",
            "GSE PRJNA SRP SDY E-MTAB accession sample metadata phenotype labels longitudinal comparator$domainClause",
            "\"Gene Expression Omnibus\" OR BioProject OR ArrayExpress immune cohort response nonresponse outcome$domainClause"
        ).map { normalizeSpaces(it) }
    }

    fun shouldUseForSourceFamily(sourceFamily: String): Boolean {
        return RuntimeFeatureFlags.ENABLE_DATA_AVAILABILITY_ACCESSION_QUERY_PRIORITY &&
            sourceFamily.trim().uppercase(Locale.US) == "PUBMED_ACCESSION_MINING"
    }

    fun reason(domainVocabulary: List<String> = emptyList()): String {
        val domainSummary = domainVocabulary
            .map { sanitizeTerm(it) }
            .filter { it.isNotBlank() }
            .distinct()
            .take(RuntimeFeatureFlags.MAX_DATA_AVAILABILITY_DOMAIN_TERMS)
            .joinToString(", ")
            .ifBlank { "none" }
        return "v1.10.25 data-availability accession priority: PubMed accession-mining must search deposition/accession language first, then parse abstracts through AccessionTextHarvestPolicy. Domain vocabulary reused: $domainSummary. Claim limit: $CLAIM_LIMIT."
    }

    fun summary(): String = "v1.10.25 data-availability accession query priority: accession-mining uses deposition/data-availability terms before broad mechanism language."

    private fun sanitizeTerm(term: String): String {
        return term
            .replace(Regex("[^A-Za-z0-9_+\\- /]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun normalizeSpaces(text: String): String = text.replace(Regex("\\s+"), " ").trim()
}
