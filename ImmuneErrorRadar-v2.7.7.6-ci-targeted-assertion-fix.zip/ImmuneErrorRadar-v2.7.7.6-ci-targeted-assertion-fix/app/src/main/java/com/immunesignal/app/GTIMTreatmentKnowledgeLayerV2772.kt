package com.immunesignal.app

import org.json.JSONObject

/**
 * v2.7.7.2 — Treatment Knowledge Layer.
 *
 * Research-only intervention context for the GTIM reasoning map. This layer adds
 * treatment-related vocabulary and decision gates (drugs, clinical trials,
 * vaccines, antibiotics/antimicrobials, anti-allergy classes, resistance and
 * immune-response interaction) without generating treatment advice, dosing,
 * clinical management, or efficacy claims.
 */
data class GTIMTreatmentKnowledgeReportV2772(
    val active: Boolean,
    val state: String,
    val matchedLanes: List<String>,
    val matchedSignals: List<String>,
    val reasoningMapLine: String,
    val resistanceLine: String,
    val clinicalTrialLine: String,
    val vaccineLine: String,
    val immuneInteractionLine: String,
    val nextEvidenceLine: String,
    val boundaryLine: String,
    val claimLimit: String = GTIMTreatmentKnowledgeLayerV2772.CLAIM_LIMIT
) {
    companion object {
        fun empty(): GTIMTreatmentKnowledgeReportV2772 = GTIMTreatmentKnowledgeReportV2772(
            active = false,
            state = "NOT_EVALUATED",
            matchedLanes = emptyList(),
            matchedSignals = emptyList(),
            reasoningMapLine = "Treatment reasoning map: not evaluated.",
            resistanceLine = "Resistance map: not evaluated.",
            clinicalTrialLine = "Clinical trial map: not evaluated.",
            vaccineLine = "Vaccine map: not evaluated.",
            immuneInteractionLine = "Immune-treatment interaction: not evaluated.",
            nextEvidenceLine = "Treatment evidence next: not evaluated.",
            boundaryLine = "Treatment layer boundary: research routing only; not treatment advice."
        )
    }
}

object GTIMTreatmentKnowledgeLayerV2772 {
    const val VERSION: String = "2.7.7.2-treatment-knowledge-layer"
    const val CLAIM_LIMIT: String = "treatment_knowledge_routing_only_not_treatment_advice_or_dosing"

    private val forbiddenClaims = listOf(
        "treatment recommendation",
        "dose recommendation",
        "clinical management instruction",
        "patient-specific advice",
        "drug efficacy confirmed",
        "vaccine efficacy confirmed",
        "antibiotic choice confirmed",
        "trial outcome confirmed"
    )

    private data class TreatmentLane(
        val id: String,
        val label: String,
        val triggers: List<String>,
        val mechanismAxis: String,
        val evidenceGates: List<String>,
        val resistanceOrFailureSignals: List<String>,
        val nextEvidence: String
    )

    private val lanes = listOf(
        TreatmentLane(
            id = "IMMUNE_MODULATOR_DRUG_CLASS_REVIEW",
            label = "immune-modulator drug class review",
            triggers = listOf("tnf", "il-6", "il6", "jak", "stat", "checkpoint", "pd-1", "pd-l1", "ctla-4", "biologic", "monoclonal", "anti cytokine", "anti-cytokine", "immunosuppress", "corticosteroid", "steroid", "dmard", "methotrexate", "tocilizumab", "adalimumab", "infliximab"),
            mechanismAxis = "drug class -> immune target -> biomarker shift -> comparator/outcome evidence",
            evidenceGates = listOf("drug_or_class_name", "target_pathway", "human_or_patient_context", "baseline_comparator", "biomarker_or_clinical_endpoint", "adverse_event_or_safety_context", "contradiction_search"),
            resistanceOrFailureSignals = listOf("non-responder", "loss of response", "neutralizing antibodies", "escape pathway", "compensatory cytokine", "toxicity", "flare"),
            nextEvidence = "collect drug/class name, target axis, responder/non-responder labels, biomarker endpoints and adverse-event context"
        ),
        TreatmentLane(
            id = "CLINICAL_TRIAL_EVIDENCE_REVIEW",
            label = "clinical-trial evidence review",
            triggers = listOf("clinical trial", "trial", "phase i", "phase ii", "phase iii", "phase 1", "phase 2", "phase 3", "randomized", "rct", "placebo", "endpoint", "nct", "clinicaltrials", "تجربة سريرية"),
            mechanismAxis = "trial design -> intervention arm -> comparator arm -> endpoint -> safety/contradiction",
            evidenceGates = listOf("trial_id_or_registry", "phase", "intervention_arm", "comparator_arm", "inclusion_context", "primary_endpoint", "sample_size", "safety_endpoint"),
            resistanceOrFailureSignals = listOf("failed primary endpoint", "underpowered", "subgroup-only signal", "dropout imbalance", "adverse event imbalance", "unblinded design"),
            nextEvidence = "capture NCT/registry ID, phase, arms, inclusion criteria, endpoints, sample size and safety signals"
        ),
        TreatmentLane(
            id = "VACCINE_COUNTERMEASURE_REVIEW",
            label = "vaccine/countermeasure review",
            triggers = listOf("vaccine", "vaccination", "immunization", "لقاح", "mRNA", "adjuvant", "antigen", "neutralizing", "booster", "variant", "strain", "platform", "immune escape"),
            mechanismAxis = "pathogen/antigen -> platform -> immune readout -> strain scope -> safety/escape evidence",
            evidenceGates = listOf("pathogen_or_antigen", "platform", "strain_or_variant_scope", "immune_readout", "neutralization_or_t_cell_endpoint", "comparator", "safety_context", "escape_or_waning_check"),
            resistanceOrFailureSignals = listOf("immune escape", "waning immunity", "variant mismatch", "antigenic drift", "non-neutralizing response", "reactogenicity", "breakthrough infection"),
            nextEvidence = "map antigen/platform, strain scope, neutralization/T-cell readout, comparator and escape/waning evidence"
        ),
        TreatmentLane(
            id = "ANTIBIOTIC_ANTIMICROBIAL_RESISTANCE_REVIEW",
            label = "antibiotic/antimicrobial resistance review",
            triggers = listOf("antibiotic", "antimicrobial", "antibacterial", "amr", "resistance", "resistant", "mdr", "xdr", "beta lactam", "carbapenem", "macrolide", "fluoroquinolone", "vancomycin", "culture", "mic", "مضاد حيوي", "مقاومة"),
            mechanismAxis = "pathogen -> antimicrobial class -> resistance mechanism -> susceptibility/clinical context -> immune interaction",
            evidenceGates = listOf("pathogen_species", "drug_class", "resistance_gene_or_mechanism", "culture_or_susceptibility_context", "MIC_or_AST_signal", "host_immune_context", "contradiction_search"),
            resistanceOrFailureSignals = listOf("resistance gene", "efflux pump", "beta-lactamase", "biofilm", "persister", "MIC shift", "treatment failure narrative", "microbiome disruption"),
            nextEvidence = "capture pathogen species, drug class, resistance gene/mechanism, AST/MIC context and host immune state"
        ),
        TreatmentLane(
            id = "ANTI_ALLERGY_INTERVENTION_REVIEW",
            label = "anti-allergy intervention review",
            triggers = listOf("allergy", "allergic", "asthma", "ige", "histamine", "antihistamine", "mast cell", "eosinophil", "omalizumab", "anti-ige", "leukotriene", "cromolyn", "desensitization", "immunotherapy", "مضاد حساسية", "حساسية"),
            mechanismAxis = "allergen/exposure -> IgE/mast/eosinophil axis -> intervention class -> symptom/biomarker endpoint",
            evidenceGates = listOf("allergen_or_exposure", "intervention_class", "IgE_or_mast_or_eosinophil_marker", "comparator", "endpoint", "time_order", "safety_context"),
            resistanceOrFailureSignals = listOf("persistent eosinophilia", "non-IgE phenotype", "steroid resistance", "poor adherence as metadata", "trigger persistence", "rebound symptoms"),
            nextEvidence = "map allergen/exposure, intervention class, IgE/mast/eosinophil markers, comparator and endpoint timing"
        ),
        TreatmentLane(
            id = "ONCO_IMMUNE_THERAPY_REVIEW",
            label = "cancer immunotherapy review",
            triggers = listOf("cancer", "tumor", "tumour", "oncology", "checkpoint", "pd-1", "pd-l1", "ctla-4", "car-t", "car t", "til", "tme", "neoantigen", "immune checkpoint"),
            mechanismAxis = "tumor immune context -> therapy class -> response/resistance marker -> safety/immune adverse-event check",
            evidenceGates = listOf("cancer_type", "therapy_class", "immune_marker", "responder_nonresponder_labels", "tumor_microenvironment_context", "safety_or_irAE_context", "contradiction_search"),
            resistanceOrFailureSignals = listOf("immune escape", "T-cell exhaustion", "antigen loss", "cold tumor", "myeloid suppression", "checkpoint resistance", "immune-related adverse events"),
            nextEvidence = "capture cancer type, therapy class, responder labels, TME markers, resistance marker and irAE/safety context"
        )
    )

    fun evaluate(
        report: JSONObject,
        contract: GTIMRunDecisionContractV2740,
        matrixAuditCard: GTIMMatrixAuditCardReportV2745? = null,
        dgeBridgeLine: String = ""
    ): GTIMTreatmentKnowledgeReportV2772 {
        val context = normalize(listOf(
            contract.rawQuery,
            contract.normalizedQuery,
            contract.primaryAnchor.routeId,
            contract.diseaseFamily.name,
            contract.secondaryDomains.joinToString(" ") { it.name },
            contract.discoveryBridges.joinToString(" ") { it.routeId },
            matrixAuditCard?.summaryLine.orEmpty(),
            matrixAuditCard?.researchValueLine.orEmpty(),
            matrixAuditCard?.blockingGaps?.joinToString(" ").orEmpty(),
            dgeBridgeLine,
            report.optJSONObject("topicCapture")?.toString().orEmpty(),
            report.optJSONObject("mechanismDiscoveryDossierReport")?.toString()?.take(1600).orEmpty(),
            report.optJSONObject("mechanismDiscoveryDossier")?.toString()?.take(1600).orEmpty()
        ).joinToString(" "))

        val matched = lanes.filter { lane -> lane.triggers.any { context.contains(normalize(it)) } }
        val diseaseContextOnly = matched.isEmpty() && looksLikeBiomedicalDiseaseContext(contract)
        val activeLanes = if (matched.isNotEmpty()) matched else if (diseaseContextOnly) listOf(defaultLaneFor(contract)) else emptyList()
        if (activeLanes.isEmpty()) return GTIMTreatmentKnowledgeReportV2772.empty()

        val matchedSignals = activeLanes.flatMap { lane -> lane.triggers.filter { context.contains(normalize(it)) }.take(4) }
            .distinct()
            .take(10)
        val laneIds = activeLanes.map { it.id }.distinct().take(4)
        val state = when {
            matched.isNotEmpty() -> "TREATMENT_KNOWLEDGE_CONTEXT_ACTIVE_REVIEW_ONLY"
            diseaseContextOnly -> "TREATMENT_KNOWLEDGE_BACKGROUND_CONTEXT_REVIEW_ONLY"
            else -> "NOT_EVALUATED"
        }
        val axis = activeLanes.joinToString(" + ") { it.mechanismAxis }.take(260)
        val evidenceGates = activeLanes.flatMap { it.evidenceGates }.distinct().take(8)
        val failureSignals = activeLanes.flatMap { it.resistanceOrFailureSignals }.distinct().take(8)
        val next = activeLanes.joinToString("; ") { it.nextEvidence }.take(260)

        val reasoningMap = "Treatment reasoning map: disease/trigger -> immune axis -> intervention class -> evidence gate -> resistance/safety/contradiction | lanes=${laneIds.joinToString(",")} | axis=$axis"
        val resistance = "Resistance map: ${failureSignals.joinToString(", ").ifBlank { "not surfaced" }} | boundary=resistance hypothesis only."
        val trial = if (laneIds.any { it.contains("CLINICAL_TRIAL") }) {
            "Clinical trial map: registry/phase/arms/endpoints/safety gates required before any interpretation."
        } else {
            "Clinical trial map: not primary; use trial registry only as evidence source if surfaced."
        }
        val vaccine = if (laneIds.any { it.contains("VACCINE") }) {
            "Vaccine map: antigen/platform/strain-scope/immune-readout gates required; no vaccine design or efficacy claim."
        } else {
            "Vaccine map: not primary for this run unless pathogen/vaccine terms are surfaced."
        }
        val immuneInteraction = "Immune-treatment interaction: ${activeLanes.map { it.label }.distinct().joinToString(", ")} -> monitor biomarkers, comparator labels, safety/adverse-event context and contradiction evidence."
        val nextLine = "Treatment evidence next: $next | gates=${evidenceGates.joinToString(",")}"
        val boundary = "Treatment layer boundary: research routing only; no treatment advice, no dosing, no clinical management, no efficacy claim; forbidden=${forbiddenClaims.take(4).joinToString(",")}."

        return GTIMTreatmentKnowledgeReportV2772(
            active = true,
            state = state,
            matchedLanes = laneIds,
            matchedSignals = matchedSignals,
            reasoningMapLine = reasoningMap.replace(Regex("\\s+"), " ").trim(),
            resistanceLine = resistance.replace(Regex("\\s+"), " ").trim(),
            clinicalTrialLine = trial,
            vaccineLine = vaccine,
            immuneInteractionLine = immuneInteraction.replace(Regex("\\s+"), " ").trim(),
            nextEvidenceLine = nextLine.replace(Regex("\\s+"), " ").trim(),
            boundaryLine = boundary
        )
    }

    fun compactLine(report: GTIMTreatmentKnowledgeReportV2772): String {
        return if (!report.active) {
            "Treatment knowledge layer: NOT_EVALUATED | boundary=not treatment advice."
        } else {
            "Treatment knowledge layer: state=${report.state} | lanes=${report.matchedLanes.joinToString(",")} | signals=${report.matchedSignals.take(6).joinToString(",").ifBlank { "background-disease-context" }} | claim=${report.claimLimit}"
                .replace(Regex("\\s+"), " ")
                .trim()
        }
    }

    private fun defaultLaneFor(contract: GTIMRunDecisionContractV2740): TreatmentLane = when (contract.diseaseFamily) {
        GTIMDiseaseFamilyV2740.ALLERGIC_TYPE2,
        GTIMDiseaseFamilyV2740.AIRWAY_TYPE2 -> lanes.first { it.id == "ANTI_ALLERGY_INTERVENTION_REVIEW" }
        GTIMDiseaseFamilyV2740.RESPIRATORY_VIRAL,
        GTIMDiseaseFamilyV2740.INFLUENZA_RESPIRATORY_VIRAL,
        GTIMDiseaseFamilyV2740.HEMORRHAGIC_VIRAL,
        GTIMDiseaseFamilyV2740.VECTOR_BORNE_OR_ZOONOTIC,
        GTIMDiseaseFamilyV2740.RETROVIRAL_IMMUNODEFICIENCY -> lanes.first { it.id == "VACCINE_COUNTERMEASURE_REVIEW" }
        GTIMDiseaseFamilyV2740.TUBERCULOSIS_GRANULOMATOUS_IMMUNE,
        GTIMDiseaseFamilyV2740.SEPSIS_SYSTEMIC_INFLAMMATION -> lanes.first { it.id == "ANTIBIOTIC_ANTIMICROBIAL_RESISTANCE_REVIEW" }
        GTIMDiseaseFamilyV2740.CANCER_IMMUNE -> lanes.first { it.id == "ONCO_IMMUNE_THERAPY_REVIEW" }
        else -> lanes.first { it.id == "IMMUNE_MODULATOR_DRUG_CLASS_REVIEW" }
    }

    private fun looksLikeBiomedicalDiseaseContext(contract: GTIMRunDecisionContractV2740): Boolean {
        return contract.primaryAnchor != GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY &&
            contract.anchorConfidence >= 60
    }

    private fun normalize(value: String): String = value.lowercase()
        .replace('_', ' ')
        .replace('-', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()
}
