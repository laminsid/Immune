package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.5.6: Learning Session Outcome Bridge
 *
 * Converts completed session insights into a safe handoff for the next research
 * cycle. It never changes hypotheses automatically, never upgrades evidence, and
 * never writes back into foundation knowledge packs. It only produces bounded
 * query/route guidance that can be shown to the user or used as optional steering.
 */
data class LearningSessionHandoff(
    val sessionId: String,
    val queryAdditions: List<String>,
    val routeSuggestions: List<String>,
    val safetyWarnings: List<String>,
    val followUpQuestions: List<String>,
    val blockedClaims: List<String>,
    val recommendedNextSearch: String,
    val claimLimit: String = "session_handoff_not_biological_proof"
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("sessionId", sessionId)
        put("queryAdditions", JSONArray(queryAdditions))
        put("routeSuggestions", JSONArray(routeSuggestions))
        put("safetyWarnings", JSONArray(safetyWarnings))
        put("followUpQuestions", JSONArray(followUpQuestions))
        put("blockedClaims", JSONArray(blockedClaims))
        put("recommendedNextSearch", recommendedNextSearch)
        put("claimLimit", claimLimit)
    }

    fun compactSummary(): String = buildString {
        append("Session handoff: ")
        append(if (queryAdditions.isNotEmpty()) "query terms=${queryAdditions.take(6).joinToString(", ")}" else "no query additions")
        if (routeSuggestions.isNotEmpty()) append("; routes=${routeSuggestions.take(3).joinToString(", ")}")
        if (safetyWarnings.isNotEmpty()) append("; warnings=${safetyWarnings.take(2).joinToString(" | ")}")
        append("; claim-limit=").append(claimLimit)
    }

    companion object {
        fun empty(sessionId: String = "none"): LearningSessionHandoff = LearningSessionHandoff(
            sessionId = sessionId,
            queryAdditions = emptyList(),
            routeSuggestions = emptyList(),
            safetyWarnings = emptyList(),
            followUpQuestions = emptyList(),
            blockedClaims = listOf("No biological claim is created by an empty handoff."),
            recommendedNextSearch = "No session handoff available yet. Run or resume a thinking session first."
        )
    }
}

object LearningSessionOutcomeBridge {
    private val rootCauseQueryTerms: Map<String, List<String>> = mapOf(
        "NO_OUTCOME_LABELS" to listOf("outcome", "recovery", "severity", "endpoint", "prognosis"),
        "NO_TIMECOURSE" to listOf("longitudinal", "time-course", "serial", "temporal", "follow-up"),
        "ANIMAL_ONLY" to listOf("human", "patient", "clinical", "cohort"),
        "WRONG_SPECIES" to listOf("human", "patient", "clinical", "cohort"),
        "OFF_ROUTE" to listOf("route-fit", "specific trigger", "controls", "outcome labels"),
        "METADATA_ONLY" to listOf("sample count", "phenotype", "condition labels", "raw data"),
        "NO_CONTROLS" to listOf("healthy control", "negative control", "exposed control", "case control")
    )

    fun buildHandoff(session: LearningSession, insights: LearningInsights): LearningSessionHandoff {
        return buildHandoffFromInsights(session.sessionId, insights)
    }

    fun buildHandoffFromInsights(sessionId: String, insights: LearningInsights): LearningSessionHandoff {
        val additions = linkedSetOf<String>()
        val routes = linkedSetOf<String>()
        val warnings = linkedSetOf<String>()
        val questions = linkedSetOf<String>()
        val blockedClaims = linkedSetOf(
            "Session insights do not prove biology.",
            "Session handoff cannot upgrade hypotheses without EvidenceQualityGate and RouteFitGate."
        )

        insights.failurePatternClusters.forEach { cluster ->
            val causeText = listOf(
                cluster.optString("rootCause", ""),
                cluster.optString("cause", ""),
                cluster.optString("failureMode", ""),
                cluster.optString("label", ""),
                cluster.optString("cluster", "")
            ).joinToString(" ").uppercase()
            rootCauseQueryTerms.forEach { (cause, terms) ->
                if (causeText.contains(cause)) additions += terms
            }
            textValue(cluster, "suggestedAction")?.let { questions += it }
            textValue(cluster, "nextAction")?.let { questions += it }
        }

        insights.proposedRoutes.forEach { route ->
            val routeId = firstNonBlank(
                route.optString("routeId", ""),
                route.optString("route", ""),
                route.optString("proposedRoute", ""),
                route.optString("axis", "")
            )
            if (routeId.isNotBlank()) routes += routeId
            textValue(route, "queryHint")?.let { additions += splitTerms(it) }
            textValue(route, "requiredEvidence")?.let { additions += splitTerms(it) }
        }

        insights.blindSpots.forEach { blindSpot ->
            val warning = firstNonBlank(
                blindSpot.optString("warning", ""),
                blindSpot.optString("risk", ""),
                blindSpot.optString("blindSpot", ""),
                blindSpot.optString("bias", ""),
                blindSpot.optString("description", "")
            )
            if (warning.isNotBlank()) warnings += warning.take(180)
        }

        insights.hypothesisInteractions.forEach { interaction ->
            val interactionType = interaction.optString("interactionType", "")
            if (interactionType.contains("synerg", ignoreCase = true)) {
                val hyp1 = interaction.optString("hyp1", interaction.optString("hypothesisA", ""))
                val hyp2 = interaction.optString("hyp2", interaction.optString("hypothesisB", ""))
                if (hyp1.isNotBlank() && hyp2.isNotBlank()) {
                    questions += "Test whether $hyp1 and $hyp2 remain linked after negative controls."
                }
            }
        }

        insights.questions.filter { it.isNotBlank() }.take(8).forEach { questions += it }

        val safeTerms = additions
            .flatMap { splitTerms(it) }
            .map { it.trim().lowercase() }
            .filter { it.length in 3..48 }
            .distinct()
            .take(16)

        val recommended = when {
            safeTerms.isNotEmpty() -> "Use next search terms: ${safeTerms.take(10).joinToString(" ")}"
            routes.isNotEmpty() -> "Inspect proposed route(s): ${routes.take(3).joinToString(", ")}; require evidence gates before upgrade."
            questions.isNotEmpty() -> "Use evolved question: ${questions.first().take(160)}"
            else -> "No actionable handoff. Keep next cycle in normal dataset-hunt mode."
        }

        return LearningSessionHandoff(
            sessionId = sessionId,
            queryAdditions = safeTerms,
            routeSuggestions = routes.take(8),
            safetyWarnings = warnings.take(8),
            followUpQuestions = questions.take(10),
            blockedClaims = blockedClaims.toList(),
            recommendedNextSearch = recommended
        )
    }

    private fun textValue(json: JSONObject, key: String): String? {
        val value = json.opt(key) ?: return null
        return when (value) {
            is JSONArray -> buildList {
                repeat(value.length()) { idx -> value.optString(idx, "").takeIf { it.isNotBlank() }?.let { add(it) } }
            }.joinToString(" ").ifBlank { null }
            else -> value.toString().takeIf { it.isNotBlank() }
        }
    }

    private fun splitTerms(text: String): List<String> {
        return text
            .replace("/", " ")
            .replace(";", " ")
            .replace(",", " ")
            .split(Regex("\\s+"))
            .map { raw -> raw.trim().trim { ch -> ch.code == 34 || ch == '\'' || ch == '[' || ch == ']' } }
            .filter { it.isNotBlank() }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""
}
