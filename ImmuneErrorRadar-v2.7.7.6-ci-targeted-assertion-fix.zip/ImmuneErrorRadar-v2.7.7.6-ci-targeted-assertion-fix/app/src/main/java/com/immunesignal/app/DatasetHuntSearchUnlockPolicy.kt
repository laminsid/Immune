package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.8: evidence-first unlock for DATASET_HUNT.
 *
 * This policy fixes the closed loop where a prior THINK_FIRST / linked-spine lock
 * prevents the only safe action that can create evidence: a bounded dataset
 * accession hunt. It never permits a hypothesis upgrade, broad mechanism search,
 * causal language, or clinical interpretation. It only decides whether DATASET_HUNT
 * may run the DatasetFirstForager even when a cognitive lock is active.
 */
data class DatasetHuntUnlockDecision(
    val allowDatasetAccessionSearch: Boolean,
    val reason: String,
    val trace: List<String>,
    val claimLimit: String = "dataset_hunt_unlock_routing_only_not_biological_proof"
) {
    companion object {
        fun blocked(reason: String, trace: List<String> = emptyList()) = DatasetHuntUnlockDecision(
            allowDatasetAccessionSearch = false,
            reason = reason,
            trace = trace
        )
    }
}

object DatasetHuntSearchUnlockPolicy {
    private val noEvidenceTokens = listOf(
        "no_dataset_accession",
        "no_evidence_object_no_upgrade",
        "no evidence object",
        "no_saved_evidence_object",
        "dataset candidates: 0",
        "datasetcandidates=0",
        "dataset candidate count=0",
        "evidence objects: 0",
        "evidenceobjects=0",
        "explicitaccessions=0",
        "explicit accessions: 0",
        "no_accession",
        "no parsed dataset",
        "no dataset candidate",
        "dataset_foraging_no_candidate",
        "no-candidate learning",
        "next source family",
        "evidence_first",
        "accession_search"
    )

    private val evidencePresentPatterns = listOf(
        Regex("""\bdataset candidates:\s*[1-9]\d*\b""", RegexOption.IGNORE_CASE),
        Regex("""\bdatasetcandidates\s*=\s*[1-9]\d*\b""", RegexOption.IGNORE_CASE),
        Regex("""\bdataset candidate count\s*=\s*[1-9]\d*\b""", RegexOption.IGNORE_CASE),
        Regex("""\bevidence objects:\s*[1-9]\d*\b""", RegexOption.IGNORE_CASE),
        Regex("""\bevidenceobjects\s*=\s*[1-9]\d*\b""", RegexOption.IGNORE_CASE),
        Regex("""\bexplicit accessions:\s*[1-9]\d*\b""", RegexOption.IGNORE_CASE),
        Regex("""\bexplicitaccessions\s*=\s*[1-9]\d*\b""", RegexOption.IGNORE_CASE)
    )

    fun evaluate(
        recentReports: List<String>,
        researchState: String,
        priorDirective: ResearchSearchDirective,
        memory: PersistentFailureMemorySnapshot,
        learningValueModeActive: Boolean = false
    ): DatasetHuntUnlockDecision {
        val normalizedState = researchState.trim().uppercase(Locale.US)
        val normalizedOwner = priorDirective.governingLayer.trim().lowercase(Locale.US)
        val text = (recentReports.take(6).joinToString(" ") + " " + normalizedState + " " + priorDirective.mode + " " + priorDirective.reason)
            .lowercase(Locale.US)
        val trace = mutableListOf<String>()
        trace += "dataset_hunt_unlock:start state=$normalizedState prior=${priorDirective.governingLayer}/${priorDirective.mode} active=${priorDirective.active} blockDatasetFirst=${priorDirective.blockDatasetFirst}"

        if (!priorDirective.active || !priorDirective.blockDatasetFirst) {
            return DatasetHuntUnlockDecision.blocked(
                reason = "No blocking cognitive directive needs an unlock.",
                trace = trace + "dataset_hunt_unlock:not_needed"
            )
        }

        val governingIsCognitive = normalizedOwner in setOf(
            "linked_cognition_spine",
            "cognitive_momentum",
            "hypothesis_graph",
            "quality_gate",
            "runbook"
        )
        if (!governingIsCognitive) {
            return DatasetHuntUnlockDecision.blocked(
                reason = "Dataset unlock does not override explicit accession/evidence-closure locks.",
                trace = trace + "dataset_hunt_unlock:blocked_by_non_cognitive_owner"
            )
        }

        val hasExplicitAccessionInDirective = priorDirective.queries.any { query ->
            Regex("\\b(GSE|GDS|SDY|PRJNA|SRP|SRA|GSM|ERP)\\d+\\b", RegexOption.IGNORE_CASE).containsMatchIn(query.query)
        }
        if (hasExplicitAccessionInDirective) {
            return DatasetHuntUnlockDecision.blocked(
                reason = "Prior directive already contains an explicit accession-like closure target.",
                trace = trace + "dataset_hunt_unlock:explicit_accession_present"
            )
        }

        val evidenceAlreadyPresent = evidencePresentPatterns.any { it.containsMatchIn(text) }
        val evidenceObjectAlreadyPresent = Regex("""\bevidence objects:\s*[1-9]\d*\b""", RegexOption.IGNORE_CASE).containsMatchIn(text) ||
            Regex("""\bevidenceobjects\s*=\s*[1-9]\d*\b""", RegexOption.IGNORE_CASE).containsMatchIn(text)
        if (evidenceAlreadyPresent && !learningValueModeActive) {
            return DatasetHuntUnlockDecision.blocked(
                reason = "Existing dataset/evidence count is non-zero; close or inspect that evidence instead of unlocking a new accession hunt.",
                trace = trace + "dataset_hunt_unlock:blocked_by_existing_evidence"
            )
        }
        if (evidenceObjectAlreadyPresent && learningValueModeActive) {
            return DatasetHuntUnlockDecision.blocked(
                reason = "Existing EvidenceObject is non-zero; close or inspect the evidence object before learning-value expansion.",
                trace = trace + "dataset_hunt_unlock:blocked_by_existing_evidence_object_even_in_learning_value_mode"
            )
        }

        val memoryRequestsDatasetEvidence = memory.records.any { record ->
            record.rootCause.equals("NO_DATASET_ACCESSION", ignoreCase = true) ||
                record.rootCause.contains("NO_DATASET_ACCESSION", ignoreCase = true) ||
                record.forcedNextSource.contains("GEO", ignoreCase = true) ||
                record.forcedNextSource.contains("GDS", ignoreCase = true) ||
                record.forcedNextSource.contains("SRA", ignoreCase = true) ||
                record.forcedNextSource.contains("PRJNA", ignoreCase = true) ||
                record.forcedNextSource.contains("IMM_PORT", ignoreCase = true) ||
                record.forcedNextSource.contains("SDY", ignoreCase = true) ||
                record.forcedNextSource.contains("ACCESSION", ignoreCase = true) ||
                record.forcedNextSource.contains("DATASET", ignoreCase = true)
        }
        val noEvidenceDemand = learningValueModeActive ||
            normalizedState == "DATASET_HUNT" ||
            noEvidenceTokens.any { token -> text.contains(token) } ||
            memoryRequestsDatasetEvidence
        if (!noEvidenceDemand) {
            return DatasetHuntUnlockDecision.blocked(
                reason = "No current no-evidence/DATASET_HUNT demand was detected.",
                trace = trace + "dataset_hunt_unlock:no_no_evidence_signal"
            )
        }

        return DatasetHuntUnlockDecision(
            allowDatasetAccessionSearch = true,
            reason = if (learningValueModeActive) {
                "LEARNING_VALUE_MODE: user topic/imported immune leads require dataset-first/weak-lead hunting even when cognition locks are active; keep hypothesis upgrades blocked."
            } else {
                "EVIDENCE_FIRST: no EvidenceObject/DatasetCandidate/Accession is available; allow one bounded dataset accession hunt while keeping hypothesis upgrades blocked."
            },
            trace = trace + listOf(
                if (learningValueModeActive) "dataset_hunt_unlock:learning_value_mode_forces_dataset_first" else "dataset_hunt_unlock:allow_accession_search_only",
                "dataset_hunt_unlock:claim_upgrade_still_blocked"
            )
        )
    }
}
