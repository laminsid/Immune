package com.immunesignal.app

/**
 * v1.3.3 hard lock.
 *
 * An intelligent report is accepted only when it exposes the four research
 * accountability fields: hypothesis, supporting evidence, counter-evidence,
 * and what the engine does not believe yet. This prevents narrative polish.
 */
data class SmartReportIntegrityResult(
    val passed: Boolean,
    val failures: List<String>
) {
    val status: String get() = if (passed) "PASS" else "FAIL"
}

object SmartReportIntegrityLock {
    fun validate(report: ResearchReportV3): SmartReportIntegrityResult {
        val failures = mutableListOf<String>()
        if (report.hypothesis.isBlank()) failures += "Missing hypothesis."
        if (report.supportingEvidence.isBlank()) failures += "Missing supporting evidence section."
        if (report.counterEvidenceOrContradiction.isBlank()) failures += "Missing counter-evidence / contradiction section."
        if (report.whatWeDoNotBelieveYet.isBlank()) failures += "Missing what-we-do-not-believe-yet section."
        if (report.nextAutonomousMove.isBlank()) failures += "Missing next autonomous move."
        return SmartReportIntegrityResult(failures.isEmpty(), failures)
    }

    fun enforce(report: ResearchReportV3): ResearchReportV3 {
        val result = validate(report)
        return report.copy(
            integrityStatus = result.status,
            integrityFailures = result.failures,
            cycleResult = if (result.passed) report.cycleResult else "Rejected by Smart Report Integrity Lock",
            technicalPointer = if (result.passed) {
                report.technicalPointer
            } else {
                "Report rejected as narrative polish: ${result.failures.joinToString("; ")}"
            }
        )
    }
}
