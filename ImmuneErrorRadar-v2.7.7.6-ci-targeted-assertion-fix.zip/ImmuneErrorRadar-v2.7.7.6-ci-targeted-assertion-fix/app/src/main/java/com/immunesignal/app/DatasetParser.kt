package com.immunesignal.app

import java.util.Locale

/**
 * v1.4.2: Parses dataset candidate metadata into testability fields.
 * This is a lightweight metadata parser, not a biological model.
 */
object DatasetParser {
    fun parse(
        candidates: List<DatasetAccessionCandidate>,
        findings: List<ResearchFinding>
    ): List<ParsedDatasetMetadata> {
        val findingById = findings.associateBy { it.source + ":" + it.sourceId }
        return candidates.map { candidate ->
            val linked = findingById[candidate.sourceFindingId]
            parseOne(candidate, linked)
        }.distinctBy { it.accession + ":" + it.sourceFamily }
            .sortedByDescending { it.metadataQualityScore }
    }

    private fun parseOne(candidate: DatasetAccessionCandidate, linked: ResearchFinding?): ParsedDatasetMetadata {
        val text = listOf(
            candidate.accession,
            candidate.source,
            candidate.sourceTitle,
            candidate.organismHint,
            candidate.conditionLabelsHint,
            candidate.outcomeLabelsHint,
            candidate.triggerResponseOutcomeHint,
            candidate.timeCourseHint,
            candidate.sampleSizeHint,
            candidate.dataType,
            candidate.reasons.joinToString(" "),
            linked?.title.orEmpty(),
            linked?.bridgeSignal.orEmpty(),
            linked?.whyItMatters.orEmpty(),
            linked?.evidence?.studyDesign.orEmpty(),
            linked?.evidence?.limitations?.joinToString(" ").orEmpty(),
            linked?.negativeControl?.status.orEmpty()
        ).joinToString(" ")
        val lower = text.lowercase(Locale.US)
        val conditionLabels = detectConditionLabels(lower, candidate.conditionLabelsHint)
        val outcomeLabels = OutcomeLabelDetector.detect(lower).ifEmpty {
            if (candidate.outcomeLabelsHint != "unknown") listOf(candidate.outcomeLabelsHint) else emptyList()
        }
        val controlLabels = ControlGroupDetector.detect(lower)
        val timeLabels = detectTimeLabels(lower, candidate.timeCourseHint)
        val contrastiveSlots = detectContrastiveSlots(conditionLabels, outcomeLabels, controlLabels, timeLabels, lower)
        val organism = when {
            candidate.organismHint.startsWith("human") || listOf("human", "patient", "donor", "clinical cohort").any { lower.contains(it) } -> "human"
            candidate.organismHint.startsWith("animal") || listOf("mouse", "murine", "rat", "animal model").any { lower.contains(it) } -> "animal_or_model"
            candidate.organismHint.startsWith("cell") || listOf("pbmc", "cell line", "in vitro", "organoid").any { lower.contains(it) } -> "cell_or_mixed"
            else -> "unknown"
        }
        val tissue = detectTissue(lower)
        val assay = if (candidate.dataType != "unknown") candidate.dataType else detectAssay(lower)
        val sampleStatus = when {
            candidate.sampleSizeHint != "unknown" -> candidate.sampleSizeHint
            Regex("\\b\\d+\\s+(samples|patients|subjects|donors|controls)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) -> "sample size hinted"
            else -> "unknown"
        }

        val reasons = mutableListOf<String>()
        var score = 0
        if (candidate.accession != "DATASET_ACCESSION_UNRESOLVED") { score += 18; reasons += "Explicit accession exists." } else reasons += "Accession unresolved."
        if (organism == "human") { score += 14; reasons += "Human/patient/cohort metadata detected." } else if (organism != "unknown") { score += 5; reasons += "Non-human or mixed model metadata detected; hypothesis generation only." }
        if (conditionLabels.isNotEmpty()) { score += 14; reasons += "Condition labels detected." } else reasons += "Condition labels missing."
        if (outcomeLabels.isNotEmpty()) { score += 18; reasons += "Outcome/response labels detected." } else reasons += "Outcome labels missing."
        if (controlLabels.isNotEmpty()) { score += 12; reasons += "Control-group language detected." } else reasons += "Control group not established."
        if (timeLabels.isNotEmpty()) { score += 10; reasons += "Time-course/longitudinal labels detected." }
        if (assay != "unknown") { score += 10; reasons += "Assay/data type detected: $assay." }
        if (sampleStatus != "unknown") { score += 6; reasons += "Sample-size hint detected." }
        if (contrastiveSlots.isNotEmpty()) { score += 8; reasons += "Contrastive comparison slot detected." }
        score = score.coerceIn(0, 100)

        val verdict = when {
            candidate.accession == "DATASET_ACCESSION_UNRESOLVED" -> "METADATA_INSUFFICIENT"
            organism == "human" && conditionLabels.isNotEmpty() && outcomeLabels.isNotEmpty() && (controlLabels.isNotEmpty() || timeLabels.isNotEmpty()) -> "USABLE_FOR_TEST"
            conditionLabels.isNotEmpty() && (outcomeLabels.isNotEmpty() || controlLabels.isNotEmpty() || timeLabels.isNotEmpty()) -> "USABLE_FOR_HYPOTHESIS_GENERATION_ONLY"
            score >= 45 -> "METADATA_INSUFFICIENT"
            else -> "NOT_USABLE"
        }
        return ParsedDatasetMetadata(
            accession = candidate.accession,
            sourceFamily = candidate.source,
            organism = organism,
            sampleSizeStatus = sampleStatus,
            conditionLabels = conditionLabels,
            outcomeLabels = outcomeLabels,
            controlLabels = controlLabels,
            timeCourseLabels = timeLabels,
            tissueOrSource = tissue,
            assayType = assay,
            contrastiveSlots = contrastiveSlots,
            metadataQualityScore = score,
            usabilityVerdict = verdict,
            evidenceObjectEligible = verdict == "USABLE_FOR_TEST" || verdict == "USABLE_FOR_HYPOTHESIS_GENERATION_ONLY",
            reasons = reasons.distinct()
        )
    }

    private fun detectConditionLabels(text: String, candidateHint: String): List<String> {
        val labels = mutableListOf<String>()
        if (listOf("allergy", "allergic", "asthma", "ige", "eosinophil").any { text.contains(it) }) labels += "allergy_type2"
        if (listOf("viral", "influenza", "covid", "sars-cov", "rsv", "infection", "interferon").any { text.contains(it) }) labels += "viral_response"
        if (listOf("autoimmune", "rheumatoid", "lupus", "arthritis", "ibd").any { text.contains(it) }) labels += "autoimmunity"
        if (listOf("case", "control", "phenotype", "condition", "disease").any { text.contains(it) }) labels += "generic_case_control"
        if (labels.isEmpty() && candidateHint != "unknown") labels += candidateHint.take(60)
        return labels.distinct()
    }

    private fun detectTimeLabels(text: String, candidateHint: String): List<String> {
        val labels = mutableListOf<String>()
        if (listOf("baseline", "pre-treatment", "pretreatment", "pre ").any { text.contains(it) }) labels += "baseline"
        if (listOf("post-treatment", "post infection", "post ", "after challenge").any { text.contains(it) }) labels += "post_event"
        if (listOf("longitudinal", "follow-up", "time course", "time-course", "serial samples").any { text.contains(it) }) labels += "longitudinal_time_course"
        if (labels.isEmpty() && candidateHint != "unknown") labels += candidateHint.take(60)
        return labels.distinct()
    }

    private fun detectContrastiveSlots(
        conditions: List<String>,
        outcomes: List<String>,
        controls: List<String>,
        time: List<String>,
        text: String
    ): List<String> {
        val slots = mutableListOf<String>()
        if (controls.isNotEmpty() && conditions.isNotEmpty()) slots += "exposed_vs_control"
        if (outcomes.any { it.contains("severity") } || listOf("mild", "severe", "critical").any { text.contains(it) }) slots += "mild_vs_severe"
        if (outcomes.any { it.contains("response_nonresponse") }) slots += "responder_vs_nonresponder"
        if (outcomes.any { it.contains("recovery") }) slots += "recovery_vs_persistence"
        if (time.isNotEmpty()) slots += "early_vs_late"
        return slots.distinct()
    }

    private fun detectTissue(text: String): String = when {
        listOf("pbmc", "peripheral blood", "whole blood").any { text.contains(it) } -> "blood/PBMC"
        listOf("lung", "airway", "nasal", "bronchial").any { text.contains(it) } -> "airway/lung"
        listOf("skin", "epithelial").any { text.contains(it) } -> "skin/epithelium"
        listOf("synovial", "joint").any { text.contains(it) } -> "joint/synovium"
        else -> "unknown"
    }

    private fun detectAssay(text: String): String = when {
        listOf("single-cell", "scrna", "single cell").any { text.contains(it) } -> "single-cell transcriptomics"
        listOf("rna-seq", "rnaseq", "transcriptomic", "gene expression").any { text.contains(it) } -> "RNA-seq/transcriptomic"
        listOf("cytokine", "elisa", "luminex", "proteomic").any { text.contains(it) } -> "cytokine/protein profiling"
        listOf("flow cytometry", "cytof").any { text.contains(it) } -> "cell phenotyping"
        else -> "unknown"
    }
}
