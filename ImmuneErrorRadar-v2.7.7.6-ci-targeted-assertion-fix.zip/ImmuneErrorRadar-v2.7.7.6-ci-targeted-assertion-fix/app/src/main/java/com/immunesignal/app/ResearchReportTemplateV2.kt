package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

object ResearchReportTemplateV2 {
    fun renderBrief(report: JSONObject): String {
        val summary = report.optJSONObject("researchStateSummary") ?: JSONObject()
        val delta = report.optJSONObject("knowledgeDelta") ?: JSONObject()
        val objects = report.optJSONArray("hypothesisObjects") ?: JSONArray()
        val top = objects.optJSONObject(0)
        return buildString {
            appendLine("SHORT DISCOVERY REPORT — LOCKED MODE")
            appendLine("Discovery: ${summary.optString("discoveryState", "Off")} | Bias: ${summary.optString("biasRiskState", "Normal")}")
            appendLine("New sources: ${delta.optInt("newSourcesSaved", 0)} | Repeated skipped: ${delta.optInt("repeatedSourcesSkipped", 0)} | Steered: ${delta.optInt("steeredQueriesGenerated", 0)}")
            appendLine("Next evidence: ${summary.optString("nextEvidence", "none")}")
            val global = report.optJSONObject("globalImmuneIntelligence") ?: JSONObject()
            if (global.length() > 0) {
                appendLine("Global next dataset: ${global.optString("nextGlobalDatasetNeeded", "none")}")
                appendLine("Global action: ${global.optString("globalDiscoveryAction", "none")}")
                val gHyp = global.optJSONArray("globalHypotheses") ?: JSONArray()
                val topGlobal = gHyp.optJSONObject(0)
                if (topGlobal != null) {
                    appendLine("Top global hypothesis: ${topGlobal.optString("status")} — ${topGlobal.optString("hypothesisId")}")
                }
            }
            appendLine()
            if (top != null) {
                appendLine("Top hypothesis: ${top.optString("status")} / ${top.optString("discoveryState")}")
                appendLine("• ${top.optString("label")}")
                appendLine("• Trust ${top.optInt("dataTrustScore")}/100 | Evidence ${ScoreFormat.oneDecimal(top.optDouble("evidenceScore10"))}/10 | Causality ${top.optInt("causalityScore")}/100")
                appendLine("• Gate: ${top.optString("minimumDataPackStatus")} | Flip: ${top.optString("signalFlip")}")
                appendLine("• Action: ${top.optString("nextBestMeasurement")}")
            } else {
                appendLine("No hypothesis object yet. Import a report or run search.")
            }
            appendLine()
            appendLine("Discovery Action: ${summary.optString("discoveryAction", "none")}")
            appendLine("Bias Alarm: ${summary.optString("biasAlarm", "Normal")}")
        }
    }
}
