package com.immunesignal.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.4.5: Failure-pattern memory.
 *
 * This ledger records why evidence hunts failed and turns repeated failures into
 * next-query constraints. It is local-only and claim-safe: it never treats a
 * failure pattern as biological evidence.
 */
data class FailurePattern(
    val id: String,
    val rootCause: String,
    val route: String,
    val hypothesisId: String?,
    val occurrenceCount: Int,
    val lastSeenMillis: Long,
    val datasetAccessions: List<String>,
    val suggestedAction: String,
    val claimLimit: String = "failure_memory_only_not_biological_proof"
)

data class FailurePatternReport(
    val active: Boolean,
    val patterns: List<FailurePattern>,
    val newlyRecorded: List<FailurePattern>,
    val summary: String
) {
    companion object {
        fun empty() = FailurePatternReport(
            active = false,
            patterns = emptyList(),
            newlyRecorded = emptyList(),
            summary = "No failure-pattern ledger activity in this cycle."
        )
    }
}

class FailurePatternLedger(private val context: Context) {
    private val fileName = "immune_failure_pattern_ledger_v145.json"
    private val maxPatterns = 160

    fun readAll(): List<FailurePattern> {
        val text = runCatching { context.openFileInput(fileName).bufferedReader().use { it.readText() } }.getOrNull().orEmpty()
        if (text.isBlank()) return emptyList()
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return emptyList()
        val arr = root.optJSONArray("patterns") ?: JSONArray()
        return (0 until arr.length()).mapNotNull { idx -> patternFromJson(arr.optJSONObject(idx) ?: return@mapNotNull null) }
    }

    fun getRecent(hours: Int = 168): List<FailurePattern> {
        val cutoff = System.currentTimeMillis() - hours.toLong().coerceAtLeast(1L) * 3600L * 1000L
        return readAll().filter { it.lastSeenMillis >= cutoff }
    }

    fun record(
        cause: String,
        route: String,
        hypothesis: String?,
        accession: String
    ): FailurePattern {
        val normalizedCause = normalizeCause(cause)
        val normalizedRoute = route.ifBlank { "unknown_route" }
        val key = "$normalizedCause:$normalizedRoute"
        val all = readAll().toMutableList()
        val existingIndex = all.indexOfFirst { it.id == key }
        val now = System.currentTimeMillis()
        val updated = if (existingIndex >= 0) {
            val old = all[existingIndex]
            old.copy(
                occurrenceCount = old.occurrenceCount + 1,
                lastSeenMillis = now,
                hypothesisId = old.hypothesisId ?: hypothesis,
                datasetAccessions = (old.datasetAccessions + accession).filter { it.isNotBlank() }.distinct().takeLast(20),
                suggestedAction = suggestAction(normalizedCause, normalizedRoute)
            )
        } else {
            FailurePattern(
                id = key,
                rootCause = normalizedCause,
                route = normalizedRoute,
                hypothesisId = hypothesis,
                occurrenceCount = 1,
                lastSeenMillis = now,
                datasetAccessions = listOf(accession).filter { it.isNotBlank() },
                suggestedAction = suggestAction(normalizedCause, normalizedRoute)
            )
        }
        if (existingIndex >= 0) all[existingIndex] = updated else all += updated
        write(all.sortedByDescending { it.lastSeenMillis }.take(maxPatterns))
        return updated
    }

    fun recordCycle(
        triageResults: List<TriageResult>,
        routeFits: List<DatasetRouteFitAssessment>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        learningOsReport: LearningOsReport,
        evidenceObjects: List<EvidenceObject>
    ): FailurePatternReport {
        val created = mutableListOf<FailurePattern>()
        val routeByAccession = routeFits.associateBy { it.accession }
        val metadataByAccession = parsedMetadata.associateBy { it.accession }
        for (triage in triageResults) {
            val route = routeByAccession[triage.accession]?.targetRoute ?: triage.routeFitPrediction
            for (cause in triage.likelyFailureModes) {
                created += record(cause, route, null, triage.accession)
            }
            if (triage.action == "LOW_PRIORITY" || triage.action == "SKIP_SIMILAR") {
                created += record(triage.action, route, null, triage.accession)
            }
        }
        for (fit in routeFits.filter { it.blocksHypothesisUpgrade }) {
            created += record("OFF_ROUTE", fit.targetRoute, null, fit.accession)
        }
        for (meta in metadataByAccession.values) {
            if (meta.outcomeLabels.isEmpty()) created += record("NO_OUTCOME_LABELS", routeByAccession[meta.accession]?.targetRoute ?: "unknown_route", null, meta.accession)
            if (meta.timeCourseLabels.isEmpty()) created += record("NO_TIMECOURSE", routeByAccession[meta.accession]?.targetRoute ?: "unknown_route", null, meta.accession)
        }
        for (cause in learningOsReport.incident.rootCauses) {
            created += record(cause, learningOsReport.incident.failedLane, null, "learning_os")
        }
        if (evidenceObjects.isEmpty() && triageResults.isEmpty() && learningOsReport.incident.rootCauses.isEmpty()) {
            return FailurePatternReport(
                active = true,
                patterns = getRecent(168),
                newlyRecorded = emptyList(),
                summary = "Failure-pattern ledger checked; no new failure root cause was strong enough to record."
            )
        }
        val recent = getRecent(168)
        val uniqueCreated = created.distinctBy { it.id + ":" + it.lastSeenMillis }
        return FailurePatternReport(
            active = true,
            patterns = recent,
            newlyRecorded = uniqueCreated.takeLast(20),
            summary = if (uniqueCreated.isEmpty()) {
                "Failure-pattern ledger checked; no new pattern recorded."
            } else {
                "Recorded ${uniqueCreated.size} failure signal(s); ${recent.size} recent pattern(s) available for query feedback."
            }
        )
    }

    private fun normalizeCause(cause: String): String {
        val upper = cause.uppercase()
        return when {
            upper.contains("NO_OUTCOME") || upper.contains("OUTCOME") && upper.contains("MISSING") -> "NO_OUTCOME_LABELS"
            upper.contains("ANIMAL") || upper.contains("MOUSE") || upper.contains("RAT") -> "ANIMAL_ONLY"
            upper.contains("TIME") || upper.contains("LONGITUDINAL") -> "NO_TIMECOURSE"
            upper.contains("METADATA") -> "METADATA_ONLY"
            upper.contains("OFF_ROUTE") || upper.contains("LOW_PRIORITY") || upper.contains("SKIP") -> upper.take(80)
            upper.contains("SPECIES") -> "WRONG_SPECIES"
            else -> upper.take(80).ifBlank { "UNKNOWN_FAILURE" }
        }
    }

    private fun suggestAction(cause: String, route: String): String = when (cause) {
        "NO_OUTCOME_LABELS" -> "Add/require terms: outcome, recovery, severity, prognosis, endpoint."
        "ANIMAL_ONLY" -> "Add/require terms: human, patient, clinical, cohort."
        "NO_TIMECOURSE" -> "Add/require terms: longitudinal, time-course, serial, temporal, follow-up."
        "METADATA_ONLY" -> "Require expression matrix/sample metadata before deep parsing."
        "OFF_ROUTE" -> "Tighten route terms or re-route candidate; do not upgrade unrelated hypothesis."
        "WRONG_SPECIES" -> "Require human/patient/cohort terms before considering hypothesis confidence."
        else -> when {
            route.contains("antiviral", ignoreCase = true) -> "Require viral load, infection, recovery, severity, human."
            route.contains("allergy", ignoreCase = true) -> "Require patch test/allergen/skin or airway/outcome/human terms."
            else -> "Inspect manually and convert the failure into one query constraint."
        }
    }

    private fun write(patterns: List<FailurePattern>) {
        val root = JSONObject()
            .put("schemaVersion", 145)
            .put("patterns", JSONArray(patterns.map { patternToJson(it) }))
        context.openFileOutput(fileName, Context.MODE_PRIVATE).bufferedWriter().use { it.write(root.toString()) }
    }

    companion object {
        fun patternToJson(item: FailurePattern): JSONObject = JSONObject()
            .put("id", item.id)
            .put("rootCause", item.rootCause)
            .put("route", item.route)
            .put("hypothesisId", item.hypothesisId ?: JSONObject.NULL)
            .put("occurrenceCount", item.occurrenceCount)
            .put("lastSeenMillis", item.lastSeenMillis)
            .put("datasetAccessions", JSONArray(item.datasetAccessions))
            .put("suggestedAction", item.suggestedAction)
            .put("claimLimit", item.claimLimit)

        fun reportToJson(item: FailurePatternReport): JSONObject = JSONObject()
            .put("active", item.active)
            .put("patterns", JSONArray(item.patterns.map { patternToJson(it) }))
            .put("newlyRecorded", JSONArray(item.newlyRecorded.map { patternToJson(it) }))
            .put("summary", item.summary)

        private fun patternFromJson(obj: JSONObject): FailurePattern = FailurePattern(
            id = obj.optString("id"),
            rootCause = obj.optString("rootCause"),
            route = obj.optString("route"),
            hypothesisId = obj.optString("hypothesisId").takeIf { it.isNotBlank() && it != "null" },
            occurrenceCount = obj.optInt("occurrenceCount", 1),
            lastSeenMillis = obj.optLong("lastSeenMillis", 0L),
            datasetAccessions = (obj.optJSONArray("datasetAccessions") ?: JSONArray()).let { arr -> (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } } },
            suggestedAction = obj.optString("suggestedAction"),
            claimLimit = obj.optString("claimLimit", "failure_memory_only_not_biological_proof")
        )
    }
}
