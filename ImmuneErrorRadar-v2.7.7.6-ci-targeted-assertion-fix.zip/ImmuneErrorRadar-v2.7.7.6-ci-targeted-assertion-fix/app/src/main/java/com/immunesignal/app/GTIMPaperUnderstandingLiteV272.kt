package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.7.2 Proof-of-Value patch: lightweight paper-understanding layer.
 *
 * This is deliberately not an LLM and not a causal inference engine. It reads only
 * the metadata/abstract digest already present in the local report and extracts
 * reviewer-useful signals: likely claim sentence, study design, sample-size hints,
 * human/animal/in-vitro context, data-availability/accession hints, and explicit
 * contradiction/null-result language. It upgrades visibility, not biological claims.
 */
data class GTIMPaperUnderstandingLiteReportV272(
    val active: Boolean,
    val version: String,
    val inspectedPapers: Int,
    val strongestClaim: String,
    val studyDesignSignals: List<String>,
    val sampleSizeSignals: List<String>,
    val modelContextSignals: List<String>,
    val datasetAvailabilitySignals: List<String>,
    val contradictionSignals: List<String>,
    val paperUnderstandingScore: Int,
    val limitations: List<String>,
    val summary: String,
    val claimLimit: String = GTIMPaperUnderstandingLiteV272.CLAIM_LIMIT
)

object GTIMPaperUnderstandingLiteV272 {
    const val VERSION: String = "2.7.2-proof-of-value-paper-understanding-lite"
    const val CLAIM_LIMIT: String = "abstract_metadata_extraction_only_not_full_text_not_causal_proof"

    fun analyze(report: JSONObject): GTIMPaperUnderstandingLiteReportV272 {
        if (!RuntimeFeatureFlags.ENABLE_PAPER_UNDERSTANDING_LITE_V272) return empty()
        val findings = report.optJSONArray("findings") ?: JSONArray()
        val texts = mutableListOf<String>()
        for (i in 0 until findings.length()) {
            val obj = findings.optJSONObject(i) ?: continue
            val text = listOf(
                obj.optString("title"),
                obj.optString("bridgeSignal"),
                obj.optString("whyItMatters"),
                obj.optString("evidenceTextDigest")
            ).joinToString(". ").replace(Regex("\\s+"), " ").trim()
            if (text.isNotBlank()) texts += text
        }
        val joined = texts.joinToString("\n").take(24000)
        if (joined.isBlank()) {
            return empty().copy(summary = "No abstract/title digest available yet; run one public lookup before claiming paper understanding.")
        }

        val designs = detectStudyDesigns(joined)
        val sampleHints = sampleSizeRegex.findAll(joined)
            .map { it.value.trim().replace(Regex("\\s+"), " ") }
            .distinct()
            .take(5)
            .toList()
        val modelSignals = detectModelSignals(joined)
        val datasetSignals = detectDatasetSignals(joined)
        val contradictions = detectContradictions(joined)
        val claim = extractClaimSentence(joined)
        val score = listOf(
            if (claim.isNotBlank()) 18 else 0,
            designs.size.coerceAtMost(3) * 8,
            sampleHints.size.coerceAtMost(2) * 7,
            modelSignals.size.coerceAtMost(3) * 7,
            datasetSignals.size.coerceAtMost(3) * 8,
            if (contradictions.isNotEmpty()) 8 else 0
        ).sum().coerceIn(0, 100)
        val summary = buildString {
            append("inspected=${texts.size}; ")
            append("design=${designs.firstOrNull() ?: "unknown"}; ")
            append("model=${modelSignals.firstOrNull() ?: "unknown"}; ")
            append("sample=${sampleHints.firstOrNull() ?: "not surfaced"}; ")
            append("dataset=${datasetSignals.firstOrNull() ?: "not surfaced"}")
        }
        return GTIMPaperUnderstandingLiteReportV272(
            active = true,
            version = VERSION,
            inspectedPapers = texts.size,
            strongestClaim = claim.ifBlank { "No claim-like sentence extracted from titles/abstract digests yet." },
            studyDesignSignals = designs,
            sampleSizeSignals = sampleHints,
            modelContextSignals = modelSignals,
            datasetAvailabilitySignals = datasetSignals,
            contradictionSignals = contradictions,
            paperUnderstandingScore = score,
            limitations = listOf(
                "abstract/title/digest only",
                "no full-text table reading",
                "no p-value or effect-size validation unless present in digest",
                "no mechanism, diagnosis, treatment, or patient prediction upgrade"
            ),
            summary = summary
        )
    }

    fun empty(): GTIMPaperUnderstandingLiteReportV272 = GTIMPaperUnderstandingLiteReportV272(
        active = false,
        version = VERSION,
        inspectedPapers = 0,
        strongestClaim = "No paper-understanding-lite signal available.",
        studyDesignSignals = emptyList(),
        sampleSizeSignals = emptyList(),
        modelContextSignals = emptyList(),
        datasetAvailabilitySignals = emptyList(),
        contradictionSignals = emptyList(),
        paperUnderstandingScore = 0,
        limitations = listOf("no findings or digest available"),
        summary = "paper-understanding-lite inactive or no findings"
    )

    private fun extractClaimSentence(text: String): String {
        val sentences = text.split(Regex("(?<=[.!?])\\s+"))
            .map { it.trim() }
            .filter { it.length in 40..260 }
        return sentences.firstOrNull { sentence ->
            claimVerbs.any { sentence.contains(it, ignoreCase = true) } &&
                biomedicalTerms.any { sentence.contains(it, ignoreCase = true) }
        }.orEmpty()
    }

    private fun detectStudyDesigns(text: String): List<String> {
        val lower = text.lowercase(Locale.US)
        val out = mutableListOf<String>()
        if (Regex("\\b(randomi[sz]ed|clinical trial|phase [1-4]|trial)\\b").containsMatchIn(lower)) out += "clinical_trial"
        if (Regex("\\b(cohort|prospective|retrospective|longitudinal)\\b").containsMatchIn(lower)) out += "cohort_or_longitudinal"
        if (Regex("\\b(case[- ]control|case control)\\b").containsMatchIn(lower)) out += "case_control"
        if (Regex("\\b(cross[- ]sectional|case series)\\b").containsMatchIn(lower)) out += "observational_descriptive"
        if (Regex("\\b(meta-analysis|systematic review|review)\\b").containsMatchIn(lower)) out += "review_or_meta_analysis"
        if (Regex("\\b(rna[- ]seq|transcriptome|scrna[- ]seq|single-cell|microarray|proteomic|metabolomic)\\b").containsMatchIn(lower)) out += "omics_dataset"
        if (Regex("\\b(in vitro|cell culture|cell line|ex vivo)\\b").containsMatchIn(lower)) out += "in_vitro_or_ex_vivo"
        if (Regex("\\b(mouse|mice|murine|rat|animal model|in vivo)\\b").containsMatchIn(lower)) out += "animal_model"
        return out.distinct().take(8)
    }

    private fun detectModelSignals(text: String): List<String> {
        val lower = text.lowercase(Locale.US)
        val out = mutableListOf<String>()
        if (Regex("\\b(human|patients|participants|subjects|pbmc|whole blood|serum|plasma)\\b").containsMatchIn(lower)) out += "human_or_patient_sample"
        if (Regex("\\b(mouse|mice|murine|rat|animal model)\\b").containsMatchIn(lower)) out += "animal_model"
        if (Regex("\\b(in vitro|cell line|culture|ex vivo)\\b").containsMatchIn(lower)) out += "in_vitro_or_ex_vivo"
        if (Regex("\\b(single-cell|scrna|rna-seq|transcriptome|microarray)\\b").containsMatchIn(lower)) out += "omics_readout"
        return out.distinct().take(6)
    }

    private fun detectDatasetSignals(text: String): List<String> {
        val out = mutableListOf<String>()
        datasetRegex.findAll(text).map { it.value.uppercase(Locale.US).replace(" ", "") }.distinct().take(8).forEach { out += it }
        val lower = text.lowercase(Locale.US)
        if (lower.contains("data availability")) out += "data_availability_text"
        if (lower.contains("supplementary")) out += "supplementary_data_hint"
        if (lower.contains("rna-seq") || lower.contains("transcriptome")) out += "transcriptome_matrix_hint"
        return out.distinct().take(10)
    }

    private fun detectContradictions(text: String): List<String> {
        val sentences = text.split(Regex("(?<=[.!?])\\s+"))
            .map { it.trim() }
            .filter { it.length in 30..240 }
        return sentences.filter { sentence ->
            contradictionTerms.any { sentence.contains(it, ignoreCase = true) }
        }.distinct().take(4)
    }

    private val claimVerbs = listOf(
        "associated with", "correlat", "increased", "decreased", "induced", "activated",
        "suppressed", "regulated", "linked to", "predict", "mediated", "drives", "contributes"
    )
    private val biomedicalTerms = listOf(
        "immune", "cytokine", "interferon", "t cell", "b cell", "monocyte", "inflammation",
        "viral", "stress", "cortisol", "microbiome", "endothelial", "autoimmune"
    )
    private val contradictionTerms = listOf(
        "not significant", "no association", "failed to", "did not", "contrary", "in contrast", "null result", "no evidence"
    )
    private val sampleSizeRegex = Regex("(?i)\\b(?:n\\s*=\\s*\\d{1,6}|\\d{2,6}\\s+(?:patients|participants|subjects|samples|cases|controls))\\b")
    private val datasetRegex = Regex("(?i)\\b(?:GSE\\s*\\d{3,8}|GDS\\s*\\d+|PRJNA\\s*\\d+|SRP\\s*\\d+|SRR\\s*\\d+|E-MTAB-\\s*\\d+|SDY\\s*\\d+)\\b")
}
