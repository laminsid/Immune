package com.immunesignal.app

/**
 * v1.10.40: final release stability gate.
 *
 * This guard does not change science or routing. It is a release-integrity lock
 * that prevents the final build from silently dropping one of the connected
 * decision layers that now form the lean-agent evidence path.
 */
data class FinalReleaseStabilityReport(
    val active: Boolean,
    val state: String,
    val requiredLayers: List<String>,
    val missingLayers: List<String>,
    val releaseDecision: String,
    val nextAction: String,
    val claimLimit: String = FinalReleaseStabilityGuard.CLAIM_LIMIT
) {
    companion object {
        fun fromRuntime(): FinalReleaseStabilityReport {
            val missing = FinalReleaseStabilityGuard.missingRequiredLayers()
            val state = if (missing.isEmpty()) {
                "FINAL_RELEASE_STABILITY_LOCKED"
            } else {
                "FINAL_RELEASE_STABILITY_MISSING_LAYER"
            }
            return FinalReleaseStabilityReport(
                active = true,
                state = state,
                requiredLayers = FinalReleaseStabilityGuard.REQUIRED_RELEASE_LAYERS,
                missingLayers = missing,
                releaseDecision = if (missing.isEmpty()) {
                    "All final evidence-path layers are registered; continue through bounded lead/metadata closure and modular technology retrieval only."
                } else {
                    "Release surface is incomplete; do not trust the final path until missing layers are restored."
                },
                nextAction = if (missing.isEmpty()) {
                    "Keep GitHub/Google Console release gates on static checks + Gradle unit tests; no broad scientific claim is allowed by this guard."
                } else {
                    "Restore missing runtime module(s): ${missing.joinToString(", ")}"
                }
            )
        }
    }
}

object FinalReleaseStabilityGuard {
    const val CLAIM_LIMIT: String = "final_release_stability_not_biological_proof"

    val REQUIRED_RELEASE_LAYERS: List<String> = listOf(
        "LeadClosureHandoffPolicy",
        "MetadataClosureAgent",
        "UnknownRouteClassifier",
        "LearningRulesAuditMonitor",
        "EBVLeadVerificationPolicy",
        "ImmuneEvidencePriorMatrix",
        "IntegratedPathLinkageGuard",
        "ReleaseVersionLinkageGuard",
        "BiomedicalResearchOntology",
        "BiomedicalConceptBridge",
        "ModernMedicalTechnologyIntelligence",
        "ViralCountermeasureIntelligence",
        "BiomedicalKnowledgeGraphLinker",
        "BiomedicalModularKnowledgeIndex",
        "LongevityBiologicalSystemsGraph",
        "LifestyleToLabMapper",
        "FastBiologicalRetrievalIndex",
        "HealthAdviceClaimGuard"
    )

    fun missingRequiredLayers(modules: List<String> = RuntimeModuleRegistry.activeModuleIds): List<String> =
        REQUIRED_RELEASE_LAYERS.filterNot { it in modules }

    fun isReleaseSurfaceAligned(modules: List<String> = RuntimeModuleRegistry.activeModuleIds): Boolean =
        missingRequiredLayers(modules).isEmpty()

    fun summary(): String = FinalReleaseStabilityReport.fromRuntime().releaseDecision
}
