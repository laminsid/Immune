package com.immunesignal.app

import java.util.Locale

/**
 * Metadata-first, abstract-second policy. It keeps data use low and only spends
 * network budget on the best candidates.
 */
object SelectiveAbstractFetcher {
    fun score(finding: ResearchFinding): AbstractCandidateScore {
        val text = (finding.title + " " + finding.bridgeSignal + " " + finding.whyItMatters + " " + finding.matchedAxes.joinToString(" ")).lowercase(Locale.US)
        var score = 0
        val reasons = mutableListOf<String>()
        fun add(points: Int, reason: String) { score += points; reasons += reason }
        if (finding.evidence.humanEvidence || finding.evidence.speciesClass == "human") add(18, "human evidence")
        if (finding.evidence.studyDesign.contains("cohort", true) || text.contains("cohort")) add(12, "cohort hint")
        if (text.contains("dataset") || text.contains("gse") || text.contains("geo") || text.contains("immport") || text.contains("sdy")) add(14, "dataset hint")
        if (text.contains("rna-seq") || text.contains("transcriptomic") || text.contains("single-cell") || text.contains("scrna")) add(14, "omics hint")
        if (text.contains("longitudinal") || text.contains("time course") || text.contains("early") || text.contains("delayed")) add(12, "time-course hint")
        if (text.contains("severity") || text.contains("recovery") || text.contains("outcome") || text.contains("viral load")) add(12, "outcome label hint")
        if (finding.matchedAxes.any { it.contains("interferon") || it.contains("regulatory_brake") || it.contains("tissue_damage") || it.contains("resolution") }) add(8, "priority immune axis")
        if (finding.sanityFlags.contains("METADATA_ONLY")) add(4, "metadata-only candidate worth abstract check")
        return AbstractCandidateScore(finding.sourceId, score.coerceIn(0, 100), reasons.distinct())
    }

    fun select(findings: List<ResearchFinding>, alreadySeen: Set<String>, threshold: Int = 65, maxAbstracts: Int = 2): List<AbstractCandidateScore> {
        return findings
            .filter { it.source == "PubMed" && !alreadySeen.contains("Abstract:${it.sourceId}") }
            .map { score(it) }
            .filter { it.score >= threshold }
            .sortedByDescending { it.score }
            .take(maxAbstracts.coerceAtLeast(0))
    }
}
