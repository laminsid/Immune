package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.9.5 post-search cognition patch.
 *
 * This layer deliberately runs after network search. It turns the finished run
 * into a compact evidence-closure card and an offline thinking board so the
 * app does not behave like "press Search, then stop thinking". It never proves
 * biology; it only connects points, keeps competing hypotheses alive, and
 * decides whether the next action is inspect, reroute, archive, or run a very
 * narrow search.
 */
data class EvidenceClosureCard(
    val accession: String,
    val decision: String,
    val closureScore: Int,
    val datasetUsabilityScore: Int,
    val routeFitScore: Int,
    val organism: String,
    val assayType: String,
    val sampleSize: String,
    val conditionLabels: List<String>,
    val outcomeLabels: List<String>,
    val controlLabels: List<String>,
    val timeCourseLabels: List<String>,
    val licenseAccess: String,
    val missingFields: List<String>,
    val nextAction: String,
    val blocksBroadSearch: Boolean,
    val claimLimit: String = "accession_closure_not_biological_proof"
)

data class EvidenceClosureReport(
    val active: Boolean,
    val mode: String,
    val searchEconomyState: String,
    val broadSearchBlocked: Boolean,
    val selectedAccession: String,
    val cards: List<EvidenceClosureCard>,
    val nextMicroAction: String,
    val queryBudgetDecision: String,
    val summary: String,
    val claimLimit: String = "evidence_closure_routing_only_not_biological_proof"
) {
    companion object {
        fun empty() = EvidenceClosureReport(
            active = false,
            mode = "NO_ACCESSION",
            searchEconomyState = "NO_DATASET_TO_CLOSE",
            broadSearchBlocked = false,
            selectedAccession = "none",
            cards = emptyList(),
            nextMicroAction = "Run Search only when a concrete evidence gap or accession exists.",
            queryBudgetDecision = "Normal guarded search allowed.",
            summary = "No dataset accession was available for closure."
        )
    }
}

data class PostSearchHypothesisCard(
    val hypothesisId: String,
    val label: String,
    val state: String,
    val confidence: Int,
    val support: List<String>,
    val objections: List<String>,
    val discriminator: String,
    val nextAction: String
)

data class PostSearchThinkingReport(
    val active: Boolean,
    val state: String,
    val synthesis: String,
    val linkedPoints: List<String>,
    val hypotheses: List<PostSearchHypothesisCard>,
    val contradictions: List<String>,
    val nextOfflineThought: String,
    val nextSearchGate: String,
    val shouldSearchAgain: Boolean,
    val summary: String,
    val claimLimit: String = "post_search_thinking_not_biological_proof"
) {
    companion object {
        fun empty() = PostSearchThinkingReport(
            active = false,
            state = "NO_REPORT",
            synthesis = "No saved research cycle is available for thinking.",
            linkedPoints = emptyList(),
            hypotheses = emptyList(),
            contradictions = emptyList(),
            nextOfflineThought = "Run or load a research cycle first.",
            nextSearchGate = "Search is not justified without a concrete missing evidence key.",
            shouldSearchAgain = false,
            summary = "Post-search thinking did not run."
        )
    }
}



data class ThinkingThreadCard(
    val threadId: String,
    val label: String,
    val state: String,
    val evidence: List<String>,
    val openQuestions: List<String>,
    val nextDecision: String
)

data class ThinkingContinuityReport(
    val active: Boolean,
    val state: String,
    val iteration: Int,
    val repeatedGaps: List<String>,
    val openThreads: List<ThinkingThreadCard>,
    val mergedHypothesisLine: String,
    val nextLocalQuestion: String,
    val nextSearchPermission: String,
    val thinkingDelta: String,
    val summary: String,
    val claimLimit: String = "thinking_continuity_not_biological_proof"
) {
    companion object {
        fun empty() = ThinkingContinuityReport(
            active = false,
            state = "NO_CONTINUITY",
            iteration = 0,
            repeatedGaps = emptyList(),
            openThreads = emptyList(),
            mergedHypothesisLine = "No thought thread has been created yet.",
            nextLocalQuestion = "Run or load a research cycle first.",
            nextSearchPermission = "Search is not justified without an evidence key.",
            thinkingDelta = "No previous thought state.",
            summary = "No continuity layer available."
        )
    }
}



data class AutonomousThoughtPulse(
    val cycleId: String,
    val createdAtMillis: Long,
    val reason: String,
    val state: String,
    val thoughtIteration: Int,
    val decision: String,
    val cognitiveDelta: String,
    val carriedHypothesis: String,
    val unresolvedGaps: List<String>,
    val nextLocalMove: String,
    val searchUnlockCondition: String,
    val claimLimit: String = "autonomous_thought_pulse_not_biological_proof"
)

object AutonomousThoughtPulseEngine {
    fun build(
        report: JSONObject,
        recentOfflineSteps: List<JSONObject>,
        recentPulses: List<JSONObject>,
        reason: String
    ): AutonomousThoughtPulse {
        val cycleId = report.optString("id", "cycle_unknown")
        val closure = report.optJSONObject("evidenceClosureReport") ?: JSONObject()
        val thinking = report.optJSONObject("postSearchThinkingReport") ?: JSONObject()
        val continuity = report.optJSONObject("thinkingContinuityReport") ?: JSONObject()
        val qualityGate = report.optJSONObject("scientificDiscoveryQualityGateReport") ?: JSONObject()
        val runbook = report.optJSONObject("scientificDiscoveryRunbookReport") ?: JSONObject()
        val cards = closure.optJSONArray("cards") ?: JSONArray()
        val topCard = cards.optJSONObject(0) ?: JSONObject()
        val hypotheses = thinking.optJSONArray("hypotheses") ?: JSONArray()
        val topHypothesis = hypotheses.optJSONObject(0) ?: JSONObject()
        val repeatedGaps = jsonArrayToStrings(continuity.optJSONArray("repeatedGaps"))
        val cardMissing = jsonArrayToStrings(topCard.optJSONArray("missingFields"))
        val unresolved = (repeatedGaps + cardMissing + jsonArrayToStrings(qualityGate.optJSONArray("requiredBeforeRun")))
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(8)
        val priorSameCyclePulses = recentPulses.count { it.optString("cycleId") == cycleId }
        val priorStepCount = recentOfflineSteps.count { it.optString("cycleId") == cycleId }
        val searchPermission = continuity.optString(
            "nextSearchPermission",
            thinking.optString("nextSearchGate", closure.optString("queryBudgetDecision", "Search requires one explicit evidence key."))
        )
        val blocksBroad = closure.optBoolean("broadSearchBlocked", false) ||
            searchPermission.startsWith("NO_BROAD_SEARCH", ignoreCase = true)
        val state = when {
            blocksBroad -> "PULSE_CLOSE_BEFORE_SEARCH"
            unresolved.isNotEmpty() && qualityGate.optBoolean("allowExecution", false) -> "PULSE_NARROW_SEARCH_CAN_BE_AUTHORIZED"
            unresolved.isNotEmpty() -> "PULSE_THINKING_REQUIRED"
            else -> "PULSE_READY_FOR_BOUNDED_NEXT_STEP"
        }
        val topGap = unresolved.firstOrNull() ?: "one explicit discriminator"
        val accession = topCard.optString("accession", closure.optString("selectedAccession", "current route"))
        val decision = when {
            blocksBroad -> "Block broad search; close $topGap for $accession first."
            runbook.optBoolean("active", false) -> "Use runbook checklist before any new query."
            else -> "Allow only a bounded next step with an explicit discriminator."
        }
        val carried = firstNonBlank(
            topHypothesis.optString("label"),
            continuity.optString("mergedHypothesisLine"),
            thinking.optString("synthesis"),
            "No active hypothesis; preserve the route only as context."
        )
        val previousState = recentPulses.firstOrNull { it.optString("cycleId") == cycleId }?.optString("state").orEmpty()
        val cognitiveDelta = when {
            previousState.isBlank() -> "Created a local thought pulse from saved research without network."
            previousState != state -> "Thought state changed: $previousState -> $state."
            priorStepCount > 0 -> "Manual offline thinking already added $priorStepCount step(s); pulse keeps the same evidence lock."
            else -> "No evidence change; pulse keeps the open gap visible instead of searching again."
        }
        val nextLocalMove = firstNonBlank(
            continuity.optString("nextLocalQuestion"),
            thinking.optString("nextOfflineThought"),
            topCard.optString("nextAction"),
            "Pick the smallest evidence key that would change the route decision."
        )
        val unlock = when {
            blocksBroad -> "Unlock search only with accession-specific metadata or one query that closes $topGap; do not run broad PubMed."
            unresolved.isNotEmpty() -> "Search allowed only if the query directly tests $topGap and writes pass/fail to the ledger."
            else -> "Search allowed through normal guarded runbook only."
        }
        return AutonomousThoughtPulse(
            cycleId = cycleId,
            createdAtMillis = System.currentTimeMillis(),
            reason = reason,
            state = state,
            thoughtIteration = priorSameCyclePulses + priorStepCount + 1,
            decision = decision,
            cognitiveDelta = cognitiveDelta,
            carriedHypothesis = carried.take(260),
            unresolvedGaps = unresolved,
            nextLocalMove = nextLocalMove.take(260),
            searchUnlockCondition = unlock.take(260)
        )
    }

    fun toJson(pulse: AutonomousThoughtPulse): JSONObject = JSONObject()
        .put("kind", "autonomous_thought_pulse_v197")
        .put("cycleId", pulse.cycleId)
        .put("createdAtMillis", pulse.createdAtMillis)
        .put("reason", pulse.reason)
        .put("state", pulse.state)
        .put("thoughtIteration", pulse.thoughtIteration)
        .put("decision", pulse.decision)
        .put("cognitiveDelta", pulse.cognitiveDelta)
        .put("carriedHypothesis", pulse.carriedHypothesis)
        .put("unresolvedGaps", JSONArray(pulse.unresolvedGaps))
        .put("nextLocalMove", pulse.nextLocalMove)
        .put("searchUnlockCondition", pulse.searchUnlockCondition)
        .put("claimLimit", pulse.claimLimit)

    fun compactFromJson(pulse: JSONObject): String = buildString {
        append("Autonomous thought pulse\n")
        append("• State: ").append(pulse.optString("state", "not recorded")).append("\n")
        append("• Decision: ").append(pulse.optString("decision", "No decision stored.").take(220)).append("\n")
        val gaps = jsonArrayToStrings(pulse.optJSONArray("unresolvedGaps")).take(4)
        append("• Open gaps: ").append(gaps.joinToString(", ").ifBlank { "none listed" }).append("\n")
        append("• Local move: ").append(pulse.optString("nextLocalMove", "Think before searching.").take(220)).append("\n")
        append("• Search unlock: ").append(pulse.optString("searchUnlockCondition", "No broad search without evidence closure.").take(220))
    }

    fun shouldSuppressDuplicate(
        report: JSONObject,
        latestPulse: JSONObject?,
        reason: String,
        nowMillis: Long,
        minIntervalMillis: Long
    ): Boolean {
        if (latestPulse == null) return false
        val sameCycle = latestPulse.optString("cycleId") == report.optString("id", "cycle_unknown")
        val sameReason = latestPulse.optString("reason") == reason
        val age = nowMillis - latestPulse.optLong("createdAtMillis", 0L)
        return sameCycle && sameReason && age >= 0L && age < minIntervalMillis
    }

    private fun jsonArrayToStrings(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { value -> value.isNotBlank() } }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}

object ThinkingContinuityEngine {
    fun build(
        recentReportJsonLines: List<String>,
        evidenceClosure: EvidenceClosureReport,
        postSearchThinking: PostSearchThinkingReport,
        learningOs: LearningOsReport
    ): ThinkingContinuityReport {
        if (!postSearchThinking.active && !evidenceClosure.active) return ThinkingContinuityReport.empty()
        val priorReports = recentReportJsonLines.mapNotNull { line -> runCatching { JSONObject(line) }.getOrNull() }
        val currentGaps = evidenceClosure.cards.flatMap { it.missingFields }
        val priorGaps = priorReports.flatMap { report ->
            val closure = report.optJSONObject("evidenceClosureReport") ?: JSONObject()
            val cards = closure.optJSONArray("cards") ?: JSONArray()
            (0 until cards.length()).flatMap { idx ->
                val missing = cards.optJSONObject(idx)?.optJSONArray("missingFields") ?: JSONArray()
                (0 until missing.length()).mapNotNull { missing.optString(it).takeIf { value -> value.isNotBlank() } }
            }
        }
        val repeated = (currentGaps + priorGaps)
            .groupingBy { it }
            .eachCount()
            .filter { it.value >= 2 || currentGaps.contains(it.key) }
            .toList()
            .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first })
            .map { it.first }
            .take(8)
        val priorActiveThinking = priorReports.count { report ->
            report.optJSONObject("postSearchThinkingReport")?.optBoolean("active", false) == true ||
                report.optJSONObject("thinkingContinuityReport")?.optBoolean("active", false) == true
        }
        val topClosure = evidenceClosure.cards.firstOrNull()
        val hypothesisThreads = postSearchThinking.hypotheses.take(3).mapIndexed { index, hyp ->
            ThinkingThreadCard(
                threadId = "thread_hypothesis_${index + 1}",
                label = hyp.label,
                state = when {
                    hyp.state.contains("HOLD", ignoreCase = true) -> "OPEN_BUT_HELD"
                    evidenceClosure.broadSearchBlocked -> "WAITING_FOR_CLOSURE"
                    else -> "READY_FOR_BOUNDED_TEST"
                },
                evidence = hyp.support.take(3),
                openQuestions = (hyp.objections + hyp.discriminator).filter { it.isNotBlank() }.take(4),
                nextDecision = hyp.nextAction
            )
        }
        val closureThread = topClosure?.let { card ->
            ThinkingThreadCard(
                threadId = "thread_accession_${card.accession.lowercase().replace(Regex("[^a-z0-9]"), "_").take(24)}",
                label = "Close accession ${card.accession} before broader discovery",
                state = if (card.blocksBroadSearch) "BLOCKS_SEARCH_UNTIL_CLOSED" else "INSPECTABLE_WITH_LIMITS",
                evidence = listOf(
                    "closure=${card.closureScore}/100",
                    "routeFit=${card.routeFitScore}/100",
                    "usability=${card.datasetUsabilityScore}/100"
                ),
                openQuestions = card.missingFields.take(5).map { "Close $it" },
                nextDecision = card.nextAction
            )
        }
        val threads = (listOfNotNull(closureThread) + hypothesisThreads)
            .distinctBy { it.threadId }
            .take(5)
        val rootCauseLine = learningOs.incident.rootCauses.joinToString(", ").ifBlank { "no root-cause tag" }
        val state = when {
            evidenceClosure.broadSearchBlocked -> "CONTINUE_THINKING_CLOSE_ACCESSION"
            repeated.isNotEmpty() && postSearchThinking.shouldSearchAgain -> "THINKING_CAN_AUTHORIZE_NARROW_SEARCH"
            repeated.isNotEmpty() -> "CONTINUE_THINKING_REPEATED_GAPS"
            else -> "CONTINUITY_READY"
        }
        val nextLocalQuestion = when {
            topClosure != null && repeated.isNotEmpty() -> "Which one repeated gap would change the decision for ${topClosure.accession}: ${repeated.first()}?"
            topClosure != null -> "What single missing field would make ${topClosure.accession} usable or archived?"
            else -> "Which hypothesis explains the current evidence with the fewest unsupported assumptions?"
        }
        val permission = when {
            evidenceClosure.broadSearchBlocked -> "NO_BROAD_SEARCH: only local metadata inspection or one accession-specific closure query."
            postSearchThinking.shouldSearchAgain -> "NARROW_SEARCH_ALLOWED: must satisfy the next search gate and one repeated evidence gap."
            else -> "THINK_FIRST: no search until a discriminator or new parent evidence is explicit."
        }
        val mergedLine = buildString {
            append(topClosure?.let { "${it.accession}: ${it.decision}" } ?: "No accession thread")
            append(" + ")
            append(postSearchThinking.hypotheses.firstOrNull()?.label?.take(120) ?: "no mechanism thread")
            append("; repeated-gap focus=")
            append(repeated.firstOrNull() ?: rootCauseLine)
        }
        val delta = when {
            priorActiveThinking == 0 -> "New thought thread created from the completed search."
            repeated.isNotEmpty() -> "Thought continuity detected repeated blocker(s): ${repeated.take(3).joinToString(", ")}."
            else -> "Thought continuity preserved the thread; no new repeated blocker identified."
        }
        return ThinkingContinuityReport(
            active = true,
            state = state,
            iteration = priorActiveThinking + 1,
            repeatedGaps = repeated,
            openThreads = threads,
            mergedHypothesisLine = mergedLine,
            nextLocalQuestion = nextLocalQuestion,
            nextSearchPermission = permission,
            thinkingDelta = delta,
            summary = "Thinking continuity: $state; iteration=${priorActiveThinking + 1}; openThreads=${threads.size}; repeatedGaps=${repeated.take(3).joinToString(", ").ifBlank { "none" }}."
        )
    }

    fun toJson(report: ThinkingContinuityReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("state", report.state)
        .put("iteration", report.iteration)
        .put("repeatedGaps", JSONArray(report.repeatedGaps))
        .put("openThreads", JSONArray(report.openThreads.map { threadToJson(it) }))
        .put("mergedHypothesisLine", report.mergedHypothesisLine)
        .put("nextLocalQuestion", report.nextLocalQuestion)
        .put("nextSearchPermission", report.nextSearchPermission)
        .put("thinkingDelta", report.thinkingDelta)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun threadToJson(thread: ThinkingThreadCard): JSONObject = JSONObject()
        .put("threadId", thread.threadId)
        .put("label", thread.label)
        .put("state", thread.state)
        .put("evidence", JSONArray(thread.evidence))
        .put("openQuestions", JSONArray(thread.openQuestions))
        .put("nextDecision", thread.nextDecision)

    fun manualStepFromReport(report: JSONObject, stepNumber: Int): JSONObject {
        val thinking = report.optJSONObject("postSearchThinkingReport") ?: JSONObject()
        val continuity = report.optJSONObject("thinkingContinuityReport") ?: JSONObject()
        val closure = report.optJSONObject("evidenceClosureReport") ?: JSONObject()
        val cards = closure.optJSONArray("cards") ?: JSONArray()
        val card = cards.optJSONObject(0) ?: JSONObject()
        val threads = continuity.optJSONArray("openThreads") ?: JSONArray()
        val firstThread = threads.optJSONObject(0) ?: JSONObject()
        val repeated = (continuity.optJSONArray("repeatedGaps") ?: JSONArray()).let { arr ->
            (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { value -> value.isNotBlank() } }
        }
        val focus = firstNonBlankJson(
            continuity.optString("nextLocalQuestion"),
            thinking.optString("nextOfflineThought"),
            closure.optString("nextMicroAction"),
            "Choose one missing evidence key before searching again."
        )
        val decision = when {
            card.optBoolean("blocksBroadSearch", false) -> "Do not search broadly. Close or archive ${card.optString("accession", "the accession")}."
            continuity.optString("nextSearchPermission").startsWith("NARROW_SEARCH_ALLOWED") -> "A narrow search is allowed only if it answers: $focus"
            else -> "Keep thinking offline until the discriminator is explicit."
        }
        return JSONObject()
            .put("kind", "manual_offline_thinking_step")
            .put("createdAtMillis", System.currentTimeMillis())
            .put("cycleId", report.optString("id", "cycle_unknown"))
            .put("stepNumber", stepNumber)
            .put("state", continuity.optString("state", thinking.optString("state", "NO_THINKING")))
            .put("focus", focus)
            .put("thread", firstThread.optString("label", thinking.optString("synthesis", "No open thread stored.")))
            .put("repeatedGaps", JSONArray(repeated.take(6)))
            .put("decision", decision)
            .put("nextPermission", continuity.optString("nextSearchPermission", thinking.optString("nextSearchGate", "Search only after evidence closure.")))
            .put("claimLimit", "manual_offline_thinking_not_biological_proof")
    }

    private fun firstNonBlankJson(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}

object EvidenceClosureEngine {
    fun shouldUseClosureMode(report: DatasetForagingReport): Boolean {
        if (!report.active || report.candidates.isEmpty()) return false
        val bestUsability = report.scoreSeparation.datasetUsabilityScore
        val hasUnclosedMetadata = report.parsedMetadata.any { metadata ->
            metadata.outcomeLabels.isEmpty() ||
                metadata.controlLabels.isEmpty() ||
                metadata.timeCourseLabels.isEmpty() ||
                metadata.sampleSizeStatus.equals("unknown", ignoreCase = true)
        }
        val highRouteFitUnpaid = report.scoreSeparation.routeFitScore >= 75 && bestUsability < 70
        return hasUnclosedMetadata || highRouteFitUnpaid
    }

    fun priorClosureQueriesFromReports(recentReportJsonLines: List<String>): List<ResearchQuery> {
        val latest = recentReportJsonLines.asSequence()
            .mapNotNull { line -> runCatching { JSONObject(line) }.getOrNull() }
            .firstOrNull { report ->
                val closure = report.optJSONObject("evidenceClosureReport") ?: JSONObject()
                closure.optBoolean("broadSearchBlocked", false) ||
                    (report.optJSONObject("thinkingContinuityReport") ?: JSONObject())
                        .optString("nextSearchPermission")
                        .startsWith("NO_BROAD_SEARCH", ignoreCase = true)
            } ?: return emptyList()
        val closure = latest.optJSONObject("evidenceClosureReport") ?: JSONObject()
        val cards = closure.optJSONArray("cards") ?: JSONArray()
        val card = cards.optJSONObject(0) ?: return emptyList()
        val accession = card.optString("accession").takeIf { it.isNotBlank() && it != "none" } ?: return emptyList()
        val missing = (0 until (card.optJSONArray("missingFields") ?: JSONArray()).length()).mapNotNull { idx ->
            (card.optJSONArray("missingFields") ?: JSONArray()).optString(idx).takeIf { it.isNotBlank() }
        }
        val condition = (0 until (card.optJSONArray("conditionLabels") ?: JSONArray()).length()).mapNotNull { idx ->
            (card.optJSONArray("conditionLabels") ?: JSONArray()).optString(idx).takeIf { it.isNotBlank() }
        }.take(3).joinToString(" ").ifBlank { "immune transcriptomic dataset" }
        val assay = card.optString("assayType", "RNA-seq single-cell").takeIf { it.isNotBlank() && it != "unknown" } ?: "RNA-seq single-cell"
        val targetTerms = missing.take(4).joinToString(" ").ifBlank { "outcome recovery severity control time-course metadata" }
        val safeId = accession.lowercase().replace(Regex("[^a-z0-9_]"), "_").take(32)
        return listOf(
            ResearchQuery(
                id = "q_v197_prior_accession_closure_$safeId",
                label = "v1.9.7 prior closure lock: $accession",
                query = "$accession $condition $assay $targetTerms outcome recovery severity endpoint longitudinal time-course control comparator placebo negative control metadata sample size license",
                reason = "Prior report blocked broad search. Close the saved accession card before spending another broad search cycle."
            )
        )
    }

    fun closureQueries(report: DatasetForagingReport): List<ResearchQuery> {
        val best = report.candidates.maxByOrNull { it.usabilityScore } ?: return emptyList()
        val accession = best.accession.takeIf { it.isNotBlank() } ?: return emptyList()
        val condition = best.conditionLabelsHint.takeIf { it.isNotBlank() && it != "unknown" } ?: "immune transcriptomic dataset"
        val assay = best.dataType.takeIf { it.isNotBlank() && it != "unknown" } ?: "RNA-seq single-cell"
        val safeId = accession.lowercase().replace(Regex("[^a-z0-9_]"), "_").take(32)
        return listOf(
            ResearchQuery(
                id = "q_v196_accession_closure_$safeId",
                label = "v1.9.5 closure: $accession metadata/outcome labels",
                query = "$accession $condition $assay outcome severity recovery endpoint longitudinal time-course control comparator placebo negative control metadata sample size license",
                reason = "Evidence Closure Mode: close one accession card before any broad PubMed expansion."
            )
        )
    }

    fun build(
        datasetForaging: DatasetForagingReport,
        evidenceObjects: List<EvidenceObject>,
        learningOs: LearningOsReport,
        executedQueries: List<ResearchQuery>
    ): EvidenceClosureReport {
        if (!datasetForaging.active || datasetForaging.candidates.isEmpty()) return EvidenceClosureReport.empty()
        val byMetadata = datasetForaging.parsedMetadata.associateBy { it.accession }
        val routeByAccession = datasetForaging.routeFitAssessments.associateBy { it.accession }
        val cards = datasetForaging.candidates
            .distinctBy { it.accession }
            .sortedByDescending { it.usabilityScore }
            .take(5)
            .map { candidate ->
                val metadata = byMetadata[candidate.accession]
                val route = routeByAccession[candidate.accession]
                val conditionLabels = metadata?.conditionLabels?.take(6).orEmpty().ifEmpty { listOfNotBlank(candidate.conditionLabelsHint.cleanUnknown()) }
                val outcomeLabels = metadata?.outcomeLabels?.take(6).orEmpty().ifEmpty { listOfNotBlank(candidate.outcomeLabelsHint.cleanUnknown()) }
                val controlLabels = metadata?.controlLabels?.take(6).orEmpty()
                val timeLabels = metadata?.timeCourseLabels?.take(6).orEmpty().ifEmpty { listOfNotBlank(candidate.timeCourseHint.cleanUnknown()) }
                val missing = buildList {
                    if ((metadata?.sampleSizeStatus ?: candidate.sampleSizeHint).isBlankOrUnknown()) add("sample_size")
                    if (conditionLabels.isEmpty()) add("condition_labels")
                    if (outcomeLabels.isEmpty()) add("outcome_recovery_severity_labels")
                    if (controlLabels.isEmpty()) add("control_or_comparator")
                    if (timeLabels.isEmpty()) add("time_order_or_longitudinal")
                    add("license_access")
                }.distinct()
                val closureScore = (
                    100 -
                        missing.size * 14 +
                        (if (conditionLabels.isNotEmpty()) 8 else 0) +
                        (if (controlLabels.isNotEmpty()) 10 else 0) +
                        (if (timeLabels.isNotEmpty()) 10 else 0) +
                        (if (outcomeLabels.isNotEmpty()) 14 else 0)
                ).coerceIn(0, 100)
                val blocksBroad = missing.any { it in listOf("outcome_recovery_severity_labels", "control_or_comparator", "time_order_or_longitudinal") } ||
                    ((route?.routeFitScore ?: 0) >= 75 && candidate.usabilityScore < 70)
                val decision = when {
                    closureScore >= 80 && !blocksBroad -> "USABLE_FOR_NEXT_EVIDENCE_TEST"
                    missing.contains("outcome_recovery_severity_labels") -> "HYPOTHESIS_ONLY_OUTCOME_BLOCKED"
                    blocksBroad -> "CLOSE_METADATA_BEFORE_SEARCH"
                    else -> "INSPECT_WITH_CAUTION"
                }
                EvidenceClosureCard(
                    accession = candidate.accession,
                    decision = decision,
                    closureScore = closureScore,
                    datasetUsabilityScore = candidate.usabilityScore,
                    routeFitScore = route?.routeFitScore ?: 0,
                    organism = metadata?.organism ?: candidate.organismHint.ifBlank { "unknown" },
                    assayType = metadata?.assayType ?: candidate.dataType.ifBlank { "unknown" },
                    sampleSize = metadata?.sampleSizeStatus ?: candidate.sampleSizeHint.ifBlank { "unknown" },
                    conditionLabels = conditionLabels,
                    outcomeLabels = outcomeLabels,
                    controlLabels = controlLabels,
                    timeCourseLabels = timeLabels,
                    licenseAccess = "unverified",
                    missingFields = missing,
                    nextAction = if (blocksBroad) {
                        "Do not broaden search. Close ${missing.take(3).joinToString("+")} for ${candidate.accession}."
                    } else {
                        "Use this accession only for a narrow falsification/replication check."
                    },
                    blocksBroadSearch = blocksBroad
                )
            }
        val selected = cards.firstOrNull()
        val broadBlocked = cards.any { it.blocksBroadSearch }
        val rootCauses = learningOs.incident.rootCauses.joinToString(", ").ifBlank { "none" }
        val closureQueries = executedQueries.count { it.id.startsWith("q_v196_accession_closure_") }
        val economy = when {
            broadBlocked && closureQueries > 0 -> "MICRO_CLOSURE_QUERY_USED"
            broadBlocked -> "MICRO_METADATA_ONLY_RECOMMENDED"
            else -> "NORMAL_GUARDED_SEARCH_ALLOWED"
        }
        return EvidenceClosureReport(
            active = true,
            mode = if (broadBlocked) "ACCESSION_CLOSURE_MODE" else "ACCESSION_INSPECTION_MODE",
            searchEconomyState = economy,
            broadSearchBlocked = broadBlocked,
            selectedAccession = selected?.accession ?: "none",
            cards = cards,
            nextMicroAction = selected?.nextAction ?: "No selected accession.",
            queryBudgetDecision = if (broadBlocked) {
                "Block broad PubMed replay; allow at most one accession-specific closure query or local metadata inspection."
            } else {
                "Normal guarded search may continue after closure card remains above threshold."
            },
            summary = "Evidence closure: ${selected?.decision ?: "NO_CARD"}; selected=${selected?.accession ?: "none"}; missing=${selected?.missingFields?.joinToString(", ") ?: "none"}; learning-root=$rootCauses."
        )
    }

    fun toJson(report: EvidenceClosureReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("mode", report.mode)
        .put("searchEconomyState", report.searchEconomyState)
        .put("broadSearchBlocked", report.broadSearchBlocked)
        .put("selectedAccession", report.selectedAccession)
        .put("cards", JSONArray(report.cards.map { cardToJson(it) }))
        .put("nextMicroAction", report.nextMicroAction)
        .put("queryBudgetDecision", report.queryBudgetDecision)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    fun cardToJson(card: EvidenceClosureCard): JSONObject = JSONObject()
        .put("accession", card.accession)
        .put("decision", card.decision)
        .put("closureScore", card.closureScore)
        .put("datasetUsabilityScore", card.datasetUsabilityScore)
        .put("routeFitScore", card.routeFitScore)
        .put("organism", card.organism)
        .put("assayType", card.assayType)
        .put("sampleSize", card.sampleSize)
        .put("conditionLabels", JSONArray(card.conditionLabels))
        .put("outcomeLabels", JSONArray(card.outcomeLabels))
        .put("controlLabels", JSONArray(card.controlLabels))
        .put("timeCourseLabels", JSONArray(card.timeCourseLabels))
        .put("licenseAccess", card.licenseAccess)
        .put("missingFields", JSONArray(card.missingFields))
        .put("nextAction", card.nextAction)
        .put("blocksBroadSearch", card.blocksBroadSearch)
        .put("claimLimit", card.claimLimit)
}

object PostSearchThinkingEngine {
    fun build(
        evidenceClosure: EvidenceClosureReport,
        datasetForaging: DatasetForagingReport,
        knowledgeMap: KnowledgeMapReport,
        epistemicBelief: EpistemicBeliefReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        qualityGate: ScientificDiscoveryQualityGateReport,
        runbook: ScientificDiscoveryRunbookReport,
        miniPeerReview: MiniPeerReviewReport,
        learningOs: LearningOsReport
    ): PostSearchThinkingReport {
        if (!datasetForaging.active && !evidenceClosure.active) return PostSearchThinkingReport.empty()
        val topClosure = evidenceClosure.cards.firstOrNull()
        val linked = buildList {
            if (topClosure != null) add("Accession ${topClosure.accession}: route-fit ${topClosure.routeFitScore}/100 vs closure ${topClosure.closureScore}/100.")
            if (datasetForaging.scoreSeparation.scoreState != "NOT_EVALUATED") add("Score separation prevents route-fit from pretending to be discovery: ${datasetForaging.scoreSeparation.scoreState}.")
            if (knowledgeMap.state.isNotBlank()) add("Knowledge map state: ${knowledgeMap.state}; blocker=${knowledgeMap.mainBlocker}.")
            if (epistemicBelief.state.isNotBlank()) add("Belief state: ${epistemicBelief.state}; revise=${epistemicBelief.revisedBeliefs}; weakened=${epistemicBelief.weakenedBeliefs}.")
            if (miniPeerReview.verdict.isNotBlank()) add("Peer-review gate: ${miniPeerReview.verdict}; objection=${miniPeerReview.strongestObjection.take(120)}.")
        }.distinct().take(6)
        val objections = buildList {
            if (topClosure?.missingFields?.isNotEmpty() == true) add("Missing closure fields: ${topClosure.missingFields.joinToString(", ")}.")
            if (!qualityGate.allowExecution) add("Quality gate blocks broad execution: ${qualityGate.gateState}.")
            if (learningOs.incident.rootCauses.isNotEmpty()) add("Learning OS root cause: ${learningOs.incident.rootCauses.joinToString(", ")}.")
            if (miniPeerReview.strongestObjection.isNotBlank()) add(miniPeerReview.strongestObjection)
        }.distinct().take(5)
        val hypotheses = buildHypotheses(topClosure, deepDiscovery, objections)
        val searchAgain = !evidenceClosure.broadSearchBlocked && qualityGate.allowExecution
        val nextOfflineThought = when {
            topClosure != null && evidenceClosure.broadSearchBlocked -> "Think locally around ${topClosure.accession}: separate metadata facts, missing labels, and competing explanations before spending more data."
            runbook.active -> "Use the runbook as a thought contract: ${runbook.routeDecision.take(180)}"
            else -> "Compare the strongest hypothesis against its simplest alternative before searching again."
        }
        val nextSearchGate = if (evidenceClosure.broadSearchBlocked) {
            "Search again only if it is accession-specific and closes ${topClosure?.missingFields?.take(3)?.joinToString("+") ?: "one evidence key"}."
        } else {
            "Search may continue only through the runbook/quality-gate evidence checklist."
        }
        val synthesis = when {
            topClosure != null -> "The current cycle produced a candidate to close, not a biological conclusion. The next value comes from resolving the accession card, not from wider search."
            else -> "The cycle produced reasoning structure but no accession-level object; reroute toward parent evidence or contradiction."
        }
        return PostSearchThinkingReport(
            active = true,
            state = if (evidenceClosure.broadSearchBlocked) "THINK_THEN_CLOSE_ACCESSION" else "THINK_THEN_BOUND_NEXT_SEARCH",
            synthesis = synthesis,
            linkedPoints = linked,
            hypotheses = hypotheses,
            contradictions = objections,
            nextOfflineThought = nextOfflineThought,
            nextSearchGate = nextSearchGate,
            shouldSearchAgain = searchAgain,
            summary = "Post-search thinking: ${if (searchAgain) "bounded search allowed" else "think/close before search"}; hypotheses=${hypotheses.size}; linked-points=${linked.size}."
        )
    }

    private fun buildHypotheses(
        topClosure: EvidenceClosureCard?,
        deepDiscovery: DeepDiscoveryReasoningReport,
        objections: List<String>
    ): List<PostSearchHypothesisCard> {
        val mechanismCards = deepDiscovery.mechanismHypotheses.take(3).mapIndexed { index, mechanism ->
            PostSearchHypothesisCard(
                hypothesisId = "post_search_mechanism_${index + 1}",
                label = mechanism.label,
                state = if (topClosure?.blocksBroadSearch == true) "HOLD_UNTIL_CLOSURE" else "INSPECT_WITH_LIMITS",
                confidence = mechanism.confidence.coerceIn(0, 100),
                support = mechanism.mechanismChain.take(3),
                objections = (listOf(mechanism.wrongGeneralizationRisk) + objections).filter { it.isNotBlank() }.take(4),
                discriminator = "Test whether ${mechanism.observableSignal.ifBlank { "the observed signal" }} precedes ${mechanism.expectedOutcome.ifBlank { "the expected outcome" }} with controls.",
                nextAction = topClosure?.nextAction ?: "Run the decisive test from the deep discovery report."
            )
        }
        if (mechanismCards.isNotEmpty()) return mechanismCards
        val fallbackLabel = topClosure?.let { "${it.accession} may be useful only if missing closure fields are resolved" }
            ?: "Current route needs parent evidence before it can guide search"
        return listOf(
            PostSearchHypothesisCard(
                hypothesisId = "post_search_fallback_1",
                label = fallbackLabel,
                state = "HOLD",
                confidence = (topClosure?.closureScore ?: 25).coerceIn(0, 70),
                support = listOfNotNull(topClosure?.let { "Accession object exists: ${it.accession}." }),
                objections = objections.ifEmpty { listOf("No decisive outcome/time/control evidence yet.") },
                discriminator = topClosure?.nextAction ?: "Find parent evidence or archive route.",
                nextAction = topClosure?.nextAction ?: "Reroute to contradiction or parent evidence."
            )
        )
    }

    fun toJson(report: PostSearchThinkingReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("state", report.state)
        .put("synthesis", report.synthesis)
        .put("linkedPoints", JSONArray(report.linkedPoints))
        .put("hypotheses", JSONArray(report.hypotheses.map { hypothesisToJson(it) }))
        .put("contradictions", JSONArray(report.contradictions))
        .put("nextOfflineThought", report.nextOfflineThought)
        .put("nextSearchGate", report.nextSearchGate)
        .put("shouldSearchAgain", report.shouldSearchAgain)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun hypothesisToJson(card: PostSearchHypothesisCard): JSONObject = JSONObject()
        .put("hypothesisId", card.hypothesisId)
        .put("label", card.label)
        .put("state", card.state)
        .put("confidence", card.confidence)
        .put("support", JSONArray(card.support))
        .put("objections", JSONArray(card.objections))
        .put("discriminator", card.discriminator)
        .put("nextAction", card.nextAction)

    fun compactFromJson(report: JSONObject): String {
        val thinking = report.optJSONObject("postSearchThinkingReport") ?: JSONObject()
        val closure = report.optJSONObject("evidenceClosureReport") ?: JSONObject()
        val cards = closure.optJSONArray("cards") ?: JSONArray()
        val card = cards.optJSONObject(0) ?: JSONObject()
        val hypotheses = thinking.optJSONArray("hypotheses") ?: JSONArray()
        val topHypothesis = hypotheses.optJSONObject(0) ?: JSONObject()
        return buildString {
            append("Thinking board\n")
            append("• State: ").append(thinking.optString("state", "NO_THINKING"))
            append("\n• Closure: ").append(card.optString("accession", closure.optString("selectedAccession", "none")))
                .append(" → ").append(card.optString("decision", closure.optString("mode", "not evaluated")))
            val missing = card.optJSONArray("missingFields")?.let { arr -> (0 until arr.length()).map { arr.optString(it) } }.orEmpty()
            append("\n• Missing: ").append(missing.take(4).joinToString(", ").ifBlank { "none listed" })
            append("\n• Hypothesis: ").append(topHypothesis.optString("label", "No hypothesis card yet").take(180))
            append("\n• Next thought: ").append(thinking.optString("nextOfflineThought", "No next thought stored").take(180))
            append("\n• Search gate: ").append(thinking.optString("nextSearchGate", "Search only after evidence closure").take(180))
        }
    }
}

private fun listOfNotBlank(value: String?): List<String> =
    value?.trim()?.takeIf { it.isNotBlank() }?.let { listOf(it) }.orEmpty()

private fun String?.isBlankOrUnknown(): Boolean {
    val value = this?.trim().orEmpty()
    return value.isBlank() || value.equals("unknown", ignoreCase = true) || value.equals("none", ignoreCase = true)
}

private fun String.cleanUnknown(): String? = if (this.isBlankOrUnknown()) null else this.trim()
