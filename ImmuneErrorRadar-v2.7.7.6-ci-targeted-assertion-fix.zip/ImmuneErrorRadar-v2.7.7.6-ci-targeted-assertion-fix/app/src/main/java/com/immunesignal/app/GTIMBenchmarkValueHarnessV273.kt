package com.immunesignal.app

import java.util.Locale

/**
 * v2.7.3 Proof-of-Value closure: benchmark value harness.
 *
 * This layer does not claim that GTIM beats PubMed/Elicit/Consensus. It forces the
 * report to state what was added beyond a normal search-result list: route
 * specificity, evidence gates, paper-lite extraction, dataset/accession hints, and
 * the next falsification action. If the value delta is weak, it says so and blocks
 * further feature expansion as the recommended product action.
 */
data class GTIMBenchmarkValueHarnessReportV273(
    val active: Boolean,
    val benchmarkState: String,
    val valueDeltaScore: Int,
    val matchedBenchmarkTopic: String,
    val addedBeyondBaseline: List<String>,
    val missingValueProof: List<String>,
    val stopExpansion: Boolean,
    val nextAction: String,
    val claimLimit: String = GTIMBenchmarkValueHarnessV273.CLAIM_LIMIT
)

object GTIMBenchmarkValueHarnessV273 {
    const val VERSION: String = "2.7.3-proof-benchmark-value-harness"
    const val CLAIM_LIMIT: String = "value_benchmark_only_not_scientific_or_commercial_claim"

    private val benchmarkTopics = listOf(
        "hantavirus" to listOf("hantavirus", "hfrs", "hcps", "puumala", "sin nombre", "andes virus", "seoul virus"),
        "ebv_sle" to listOf("ebv", "sle", "lupus", "type i interferon", "ifn"),
        "long_covid_interferon" to listOf("covid", "long covid", "pasc", "sars-cov-2", "sars cov 2", "interferon", "pbmc"),
        "ebola_hemorrhagic_viral_host_response" to listOf("ebola", "evd", "hemorrhagic", "viral hemorrhagic", "filovirus", "pbmc", "blood"),
        "hiv_retroviral_cd4_immune_depletion" to listOf("hiv", "aids", "sida", "cd4", "retroviral", "viral load", "t cell"),
        "allergy_type2_ige" to listOf("allergy", "allergies", "allergic", "hypersensitivity", "ige", "mast cell", "eosinophil", "il-4", "il-13"),
        "microbiome_depression_kynurenine" to listOf("depression", "microbiome", "gut bacteria", "tryptophan", "kynurenine", "il-6", "tnf"),
        "longevity_immunosenescence" to listOf("longevity", "aging", "ageing", "immunosenescence", "inflammaging", "senescence"),
        "pesticides_gut_immunity" to listOf("pesticide", "glyphosate", "organophosphate", "gut", "microbiome", "barrier"),
        "heavy_metals_inflammation" to listOf("heavy metal", "lead exposure", "blood lead", "lead poisoning", "arsenic", "cadmium", "mercury", "water", "inflammation")
    )

    fun evaluate(
        parsedIntentText: String,
        strongestRoute: String,
        topQuery: String,
        dataChannelsCount: Int,
        routeState: GTIMRouteEvidenceStateReportV272,
        paperLite: GTIMPaperUnderstandingLiteReportV272,
        proofOfValue: GTIMProofOfValueReportV272,
        currentTopic: String = ""
    ): GTIMBenchmarkValueHarnessReportV273 {
        if (!RuntimeFeatureFlags.ENABLE_BENCHMARK_VALUE_HARNESS_V273) return disabled()

        val lockedTopicCorpus = listOf(currentTopic, parsedIntentText, strongestRoute).joinToString(" ").lowercase(Locale.US)
        val untrustedExpansionCorpus = topQuery.lowercase(Locale.US)
        val topicContractBenchmark = contractBenchmarkFromCurrentTopic(currentTopic)
        val lockedMatched = lockedBenchmarkTopic(lockedTopicCorpus, untrustedExpansionCorpus)
        val matched = when {
            topicContractBenchmark != null -> topicContractBenchmark
            lockedMatched != "open_topic" -> {
                // The benchmark harness must lock to the current topic corpus before looking at
                // runtime or top-query expansion. This prevents a stale runtime contract or a
                // polluted top query from rewriting Covid/Ebola/etc. into pesticide/allergy/etc.
                lockedMatched
            }
            else -> GTIMRunContractRuntimeV2740.benchmarkTopicOr(lockedMatched)
        }
        val added = mutableListOf<String>()
        val missing = mutableListOf<String>()
        var score = 0

        if (strongestRoute.isNotBlank() && !strongestRoute.contains("No candidate route", ignoreCase = true)) {
            score += 18
            added += "topic-specific route is visible"
        } else {
            missing += "route still looks generic or hidden"
        }

        if (topQuery.isNotBlank()) {
            score += 14
            added += "next executable query is explicit"
        } else {
            missing += "no executable query exposed"
        }

        if (dataChannelsCount > 0) {
            score += 12
            added += "public data channel is surfaced"
        } else {
            missing += "no public data channel surfaced"
        }

        if (routeState.state in listOf("PROMISING_ROUTE", "EVIDENCE_CANDIDATE", "STRONG_SIGNAL_REVIEW_ONLY")) {
            score += 16
            added += "route state separated from evidence strength"
        } else {
            missing += "route is still below promising threshold"
        }

        if (paperLite.active && paperLite.paperUnderstandingScore >= RuntimeFeatureFlags.PROOF_OF_VALUE_MIN_PAPER_UNDERSTANDING_SCORE_V272) {
            score += 18
            added += "paper-understanding-lite extracted abstract signals"
        } else {
            missing += "paper-understanding-lite did not extract enough value yet"
        }

        if (paperLite.datasetAvailabilitySignals.isNotEmpty()) {
            score += 12
            added += "dataset/accession hint surfaced"
        } else {
            missing += "no dataset/accession hint surfaced"
        }

        if (proofOfValue.active && proofOfValue.valueState != "NO_VALUE_DELTA_YET") {
            score += 10
            added += "proof-of-value delta is non-empty"
        } else {
            missing += "no value delta beyond baseline search yet"
        }

        val boundedScore = score.coerceIn(0, 100)
        val state = when {
            boundedScore >= 70 -> "BENCHMARK_VALUE_VISIBLE"
            boundedScore >= RuntimeFeatureFlags.BENCHMARK_VALUE_MIN_DELTA_SCORE_V273 -> "BENCHMARK_VALUE_PARTIAL"
            else -> "BENCHMARK_VALUE_NOT_PROVEN"
        }
        val stop = boundedScore < RuntimeFeatureFlags.BENCHMARK_VALUE_STOP_EXPANSION_BELOW_V273
        val next = when (state) {
            "BENCHMARK_VALUE_VISIBLE" -> "Run the same topic against PubMed/Elicit/Consensus and record the unique gates or dataset seeds GTIM added."
            "BENCHMARK_VALUE_PARTIAL" -> "Run one second-pass lookup and require one dataset/accession hint or contradiction signal before adding features."
            else -> "Stop feature expansion; improve retrieval or paper-lite extraction on the five benchmark questions first."
        }
        return GTIMBenchmarkValueHarnessReportV273(
            active = true,
            benchmarkState = state,
            valueDeltaScore = boundedScore,
            matchedBenchmarkTopic = matched,
            addedBeyondBaseline = added.distinct().take(7),
            missingValueProof = missing.distinct().take(7),
            stopExpansion = stop,
            nextAction = next
        )
    }

    private fun contractBenchmarkFromCurrentTopic(currentTopic: String): String? {
        if (currentTopic.isBlank()) return null
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            rawQuery = currentTopic,
            inputMode = GTIMInputModeV2740.USER_QUERY,
            hasDatasetAccessions = true,
            matrixState = "DGE_READY"
        )
        return if ((contract.runMode == GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED || contract.runMode == GTIMRunModeV2740.USER_DIRECTED_SYNDROME_EXPLORATION) &&
            contract.primaryAnchor != GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY
        ) {
            GTIMDownstreamContractAdaptersV2740.benchmarkFromContract(contract)
        } else null
    }

    private fun lockedBenchmarkTopic(lockedTopicCorpus: String, untrustedExpansionCorpus: String): String {
        val lockedMatches = benchmarkTopics
            .map { (id, terms) -> id to terms.count { term -> lockedTopicCorpus.contains(term) } }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
        val topLocked = lockedMatches.firstOrNull()?.first
        if (topLocked != null) return topLocked

        val expansionMatches = benchmarkTopics
            .filter { (id, _) -> id !in setOf("pesticides_gut_immunity", "heavy_metals_inflammation") }
            .map { (id, terms) -> id to terms.count { term -> untrustedExpansionCorpus.contains(term) } }
            .filter { it.second >= 2 }
            .sortedByDescending { it.second }
        return expansionMatches.firstOrNull()?.first ?: "open_topic"
    }

    fun disabled(): GTIMBenchmarkValueHarnessReportV273 = GTIMBenchmarkValueHarnessReportV273(
        active = false,
        benchmarkState = "BENCHMARK_VALUE_DISABLED",
        valueDeltaScore = 0,
        matchedBenchmarkTopic = "not_evaluated",
        addedBeyondBaseline = emptyList(),
        missingValueProof = listOf("benchmark harness disabled"),
        stopExpansion = true,
        nextAction = "enable benchmark value harness"
    )
}
