package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.35: lead-closure handoff + metadata closure + route-prior classifier.
 *
 * This is a wiring and reporting layer only. It preserves a weak/off-route lead
 * across cycles, closes explicit metadata fields before broad search, and labels
 * possible routes as priors. It never upgrades biology, causality, diagnosis, or treatment.
 */
data class LeadClosureHandoffReport(
    val active: Boolean,
    val state: String,
    val carriedLeadCount: Int,
    val carriedLeadIds: List<String>,
    val missingFields: List<String>,
    val forcedNextAction: String,
    val allowedNextActions: List<String>,
    val blockedActions: List<String>,
    val pinnedLearningRules: List<String>,
    val claimLimit: String = LeadClosureHandoffPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = LeadClosureHandoffReport(
            active = false,
            state = "NOT_EVALUATED",
            carriedLeadCount = 0,
            carriedLeadIds = emptyList(),
            missingFields = emptyList(),
            forcedNextAction = "No prior weak lead handoff was evaluated.",
            allowedNextActions = emptyList(),
            blockedActions = emptyList(),
            pinnedLearningRules = emptyList()
        )
    }
}

data class MetadataClosureReport(
    val active: Boolean,
    val state: String,
    val inspectedLeadCount: Int,
    val requiredFields: List<String>,
    val closedFields: List<String>,
    val missingFields: List<String>,
    val nextAction: String,
    val claimLimit: String = LeadClosureHandoffPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = MetadataClosureReport(
            active = false,
            state = "NOT_EVALUATED",
            inspectedLeadCount = 0,
            requiredFields = LeadClosureHandoffPolicy.REQUIRED_METADATA_FIELDS,
            closedFields = emptyList(),
            missingFields = emptyList(),
            nextAction = "No metadata closure check was evaluated."
        )
    }
}

data class RoutePrior(
    val routeId: String,
    val label: String,
    val confidence: Int,
    val matchedTerms: List<String>,
    val claimLimit: String = LeadClosureHandoffPolicy.CLAIM_LIMIT
)

data class UnknownRouteClassificationReport(
    val active: Boolean,
    val state: String,
    val selectedRoute: String,
    val confidence: Int,
    val routePriors: List<RoutePrior>,
    val pinnedRule: String,
    val nextAction: String,
    val claimLimit: String = LeadClosureHandoffPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = UnknownRouteClassificationReport(
            active = false,
            state = "NOT_EVALUATED",
            selectedRoute = "none",
            confidence = 0,
            routePriors = emptyList(),
            pinnedRule = "No route prior was evaluated.",
            nextAction = "No route classification available yet."
        )
    }
}

object LeadClosureHandoffPolicy {
    const val CLAIM_LIMIT: String = "lead_closure_handoff_not_biological_proof"
    val REQUIRED_METADATA_FIELDS = listOf(
        "accession",
        "human_or_patient_data",
        "sample_size",
        "condition_labels",
        "outcome_labels",
        "control_or_comparator",
        "time_order",
        "tissue_or_cell_context",
        "license_access",
        "data_availability_text"
    )

    private val handoffTokens = listOf(
        "WEAK_DATASET_LEAD_FOUND",
        "ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP",
        "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION",
        "OPEN_LEADS_REQUIRE_SECONDARY_LOOKUP",
        "OFF_ROUTE_DATASET",
        "LEAD_OBJECT_SECONDARY_LOOKUP",
        "CLOSE_METADATA_BEFORE_SEARCH"
    )

    fun shouldForceLeadClosure(recentReports: List<String>): Boolean = recentReports.any { report ->
        handoffTokens.any { token -> report.contains(token, ignoreCase = true) }
    }

    fun extractSeedTextsFromRecentReports(recentReports: List<String>): List<String> {
        return recentReports.asSequence()
            .flatMap { report -> report.lines().asSequence() }
            .map { it.trim() }
            .filter { line -> handoffTokens.any { token -> line.contains(token, ignoreCase = true) } }
            .filter { it.length >= 30 }
            .map { line -> "Prior lead closure handoff: ${line.take(360)} Scope rule: interpret only from an immune-system perspective; lead-only, no proof." }
            .distinct()
            .take(6)
            .toList()
    }

    fun evaluateHandoff(
        recentReports: List<String>,
        leadObjects: List<LeadObject>,
        breakthrough: EvidenceDiscoveryBreakthroughReport,
        metadataClosure: MetadataClosureReport
    ): LeadClosureHandoffReport {
        val priorSeedTexts = extractSeedTextsFromRecentReports(recentReports)
        val leadIds = (leadObjects.map { it.leadId } + breakthrough.bestLead.takeIf { it.isNotBlank() && it != "none" }.orEmpty())
            .filter { it.isNotBlank() && !it.equals("none", true) }
            .distinct()
            .take(12)
        val active = leadIds.isNotEmpty() || priorSeedTexts.isNotEmpty() || shouldForceLeadClosure(recentReports)
        if (!active) return LeadClosureHandoffReport.empty().copy(state = "NO_PRIOR_LEAD_TO_CLOSE")
        val missing = (metadataClosure.missingFields.ifEmpty { REQUIRED_METADATA_FIELDS }).distinct()
        val action = when {
            missing.contains("accession") -> "Run LEAD_OBJECT_SECONDARY_LOOKUP before any broad search; extract GSE/PRJNA/SRP/SRR/E-MTAB/SDY/PMID/DOI or archive with reason."
            missing.any { it in listOf("condition_labels", "outcome_labels", "control_or_comparator", "time_order") } -> "Run minimum metadata closure for the carried lead: condition, outcome, control/comparator, and time-order fields."
            else -> "Run a contradiction/negative-control micro-probe for the carried route; keep claims locked."
        }
        return LeadClosureHandoffReport(
            active = true,
            state = if (leadIds.isNotEmpty()) "LEAD_CLOSURE_HANDOFF_ACTIVE" else "PRIOR_REPORT_LEAD_CLOSURE_REQUIRED",
            carriedLeadCount = maxOf(leadIds.size, priorSeedTexts.size),
            carriedLeadIds = leadIds.ifEmpty { priorSeedTexts.map { "prior_${stableId(it).take(32)}" } }.take(12),
            missingFields = missing,
            forcedNextAction = action,
            allowedNextActions = listOf("LEAD_OBJECT_SECONDARY_LOOKUP", "MINIMUM_METADATA_CLOSURE", "ARCHIVE_OR_COOLDOWN_WITH_EXPLICIT_REASON", "CONTRADICTION_MICRO_PROBE_AFTER_METADATA"),
            blockedActions = listOf("BROAD_PUBMED_SEARCH", "HYPOTHESIS_UPGRADE", "CAUSAL_LANGUAGE", "TREATMENT_OR_DRUG_RANKING"),
            pinnedLearningRules = listOf(
                "A weak or off-route lead must be preserved across the next cycle.",
                "A carried lead can only move through secondary lookup, metadata parsing, or explicit archive/cooldown.",
                "Contradiction search starts after minimum metadata identifies the route and evidence keys."
            )
        )
    }

    fun metadataClosure(leadObjects: List<LeadObject>, candidates: List<DatasetAccessionCandidate>, parsedMetadata: List<ParsedDatasetMetadata>): MetadataClosureReport {
        val inspectedCount = maxOf(leadObjects.size, candidates.size, parsedMetadata.size)
        if (inspectedCount == 0) return MetadataClosureReport.empty().copy(state = "NO_LEAD_TO_CLOSE")
        val closed = linkedSetOf<String>()
        if (leadObjects.any { it.detectedAccessions.isNotEmpty() } || candidates.any { it.accession.isNotBlank() && !it.accession.startsWith("MANUAL_", true) && it.accession != "DATASET_ACCESSION_UNRESOLVED" } || parsedMetadata.any { it.accession.isNotBlank() }) closed += "accession"
        if (leadObjects.any { it.humanLikely } || candidates.any { it.organismHint.contains("human", true) } || parsedMetadata.any { it.organism.contains("human", true) }) closed += "human_or_patient_data"
        if (leadObjects.any { it.sampleSizeLikely } || parsedMetadata.any { it.sampleSizeStatus.isNotBlank() && !it.sampleSizeStatus.contains("unknown", true) }) closed += "sample_size"
        if (parsedMetadata.any { it.conditionLabels.isNotEmpty() } || candidates.any { !it.conditionLabelsHint.contains("unknown", true) }) closed += "condition_labels"
        if (leadObjects.any { it.outcomeLikely } || parsedMetadata.any { it.outcomeLabels.isNotEmpty() } || candidates.any { !it.outcomeLabelsHint.contains("unknown", true) }) closed += "outcome_labels"
        if (leadObjects.any { it.controlLikely } || parsedMetadata.any { it.controlLabels.isNotEmpty() } || candidates.any { it.reasons.any { r -> r.contains("control", true) || r.contains("comparator", true) } }) closed += "control_or_comparator"
        if (leadObjects.any { it.timeLikely } || parsedMetadata.any { it.timeCourseLabels.isNotEmpty() } || candidates.any { !it.timeCourseHint.contains("unknown", true) }) closed += "time_order"
        if (parsedMetadata.any { it.tissueOrSource.isNotBlank() } || leadObjects.any { it.omicsType != "unknown" }) closed += "tissue_or_cell_context"
        if (leadObjects.any { it.licenseAccessLikely } || candidates.any { it.reasons.any { r -> r.contains("license", true) || r.contains("access", true) || r.contains("available", true) } }) closed += "license_access"
        if (leadObjects.any { it.dataAvailabilityText.isNotBlank() } || candidates.any { it.reasons.any { r -> r.contains("data availability", true) || r.contains("supplement", true) } }) closed += "data_availability_text"
        val missing = REQUIRED_METADATA_FIELDS.filter { it !in closed }
        return MetadataClosureReport(
            active = true,
            state = when {
                missing.isEmpty() -> "METADATA_CLOSURE_READY_FOR_CONTRADICTION"
                "accession" in missing -> "METADATA_CLOSURE_NEEDS_SECONDARY_LOOKUP"
                else -> "METADATA_CLOSURE_INCOMPLETE"
            },
            inspectedLeadCount = inspectedCount,
            requiredFields = REQUIRED_METADATA_FIELDS,
            closedFields = closed.toList(),
            missingFields = missing,
            nextAction = when {
                missing.isEmpty() -> "Run contradiction/negative-control micro-probe before any hypothesis upgrade."
                "accession" in missing -> "Resolve accession or source ID first; do not broaden search."
                else -> "Close missing metadata fields: ${missing.take(5).joinToString(", ")}."
            }
        )
    }

    fun classifyUnknownRoute(leadObjects: List<LeadObject>, candidates: List<DatasetAccessionCandidate>, routeFits: List<DatasetRouteFitAssessment>, recentReports: List<String>): UnknownRouteClassificationReport {
        val corpus = (leadObjects.joinToString(" ") { it.title + " " + it.snippet + " " + it.domain + " " + it.omicsType + " " + it.dataAvailabilityText } + " " +
            candidates.joinToString(" ") { it.sourceTitle + " " + it.conditionLabelsHint + " " + it.outcomeLabelsHint + " " + it.dataType + " " + it.reasons.joinToString(" ") } + " " +
            routeFits.joinToString(" ") { it.datasetRoute + " " + it.targetRoute + " " + it.reasons.joinToString(" ") } + " " +
            recentReports.take(3).joinToString(" ").take(6_000)).lowercase(Locale.US)
        val priors = routePriorRules().mapNotNull { rule ->
            val hits = rule.terms.filter { corpus.contains(it) }.distinct()
            if (hits.isEmpty()) null else RoutePrior(
                routeId = rule.routeId,
                label = rule.label,
                confidence = (20 + hits.size * 14).coerceAtMost(78),
                matchedTerms = hits.take(8)
            )
        }.sortedByDescending { it.confidence }
        if (priors.isEmpty()) return UnknownRouteClassificationReport.empty().copy(state = "NO_ROUTE_PRIOR", nextAction = "Keep route as unknown until metadata terms appear.")
        val selected = priors.first()
        return UnknownRouteClassificationReport(
            active = true,
            state = "ROUTE_PRIOR_ONLY_NOT_EVIDENCE",
            selectedRoute = selected.routeId,
            confidence = selected.confidence,
            routePriors = priors.take(6),
            pinnedRule = "Route priors guide the next lookup only; EBV/HHV-6/CMV terms are latent-virus vocabulary, not proof or preferred causality.",
            nextAction = "Use selected prior '${selected.routeId}' only to choose metadata/contradiction terms; do not upgrade biology."
        )
    }

    private data class PriorRule(val routeId: String, val label: String, val terms: List<String>)

    private fun routePriorRules(): List<PriorRule> = listOf(
        PriorRule("type2_allergy_mast_cell_route", "Type-2 / mast-cell / allergy", listOf("allergy", "allergic", "histamine", "mast", "ige", "eosinophil", "urticaria", "h1", "antihistamine", "telfast", "loratadine")),
        PriorRule("autoimmune_flare_route", "Autoimmune flare / activity", listOf("sle", "lupus", "rheumatoid", "arthritis", "autoimmune", "flare", "disease activity", "tnf", "il-6", "b cell")),
        PriorRule("interferon_antiviral_route", "Interferon / antiviral response", listOf("covid", "sars-cov-2", "corona", "hanta", "hantavirus", "viral", "interferon", "ifn", "antiviral", "viral load")),
        PriorRule("latent_virus_reactivation_route", "Latent-virus reactivation prior", listOf("ebv", "epstein", "hhv-6", "hhv6", "cmv", "herpesvirus", "reactivation", "latency", "latent virus", "mononucleosis")),
        PriorRule("drug_perturbation_route", "Medication/drug perturbation research", listOf("drug", "medication", "antihistamine", "loratadine", "fexofenadine", "telfast", "treatment exposure", "pharmacologic")),
        PriorRule("stress_immune_psychoneuro_route", "Stress/sleep immune context", listOf("stress", "sleep", "cortisol", "sympathetic", "autonomic", "fatigue", "psychoneuro", "anxiety")),
        PriorRule("barrier_tissue_route", "Barrier tissue / gut / airway context", listOf("barrier", "epithelial", "gut", "microbiome", "airway", "skin", "mucosal", "reflux")),
        PriorRule("rna_transcriptomic_state_route", "RNA/transcriptomic immune state", listOf("rna", "rna-seq", "transcript", "transcriptomic", "single-cell", "scrna", "gene expression", "omics"))
    )

    private fun stableId(value: String): String = value.lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .ifBlank { "lead" }
}
