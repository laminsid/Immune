package com.immunesignal.app

import java.util.Locale

/** v1.4.2: finds outcome/response labels in dataset metadata text. */
object OutcomeLabelDetector {
    private val labels = linkedMapOf(
        "severity" to listOf("severity", "mild", "moderate", "severe", "critical"),
        "recovery" to listOf("recovery", "recovered", "resolution", "convalescent", "follow-up"),
        "response_nonresponse" to listOf("responder", "non-responder", "nonresponder", "response", "nonresponse"),
        "relapse_remission" to listOf("relapse", "remission", "flare", "inactive disease"),
        "acute_chronic" to listOf("acute", "chronic", "persistent", "longitudinal"),
        "viral_burden" to listOf("viral load", "viral clearance", "viral shedding"),
        "hospitalization_mortality" to listOf("hospitalization", "icu", "mortality", "death")
    )

    fun detect(text: String): List<String> {
        val lower = text.lowercase(Locale.US)
        return labels.filter { (_, terms) -> terms.any { lower.contains(it) } }.keys.toList()
    }
}
