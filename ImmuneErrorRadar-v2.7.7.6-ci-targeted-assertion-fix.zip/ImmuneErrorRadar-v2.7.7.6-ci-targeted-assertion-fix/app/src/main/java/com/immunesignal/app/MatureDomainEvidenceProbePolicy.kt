package com.immunesignal.app

import org.json.JSONObject
import java.util.Locale

/**
 * v1.10.26: Mature domain evidence probe.
 *
 * The previous DATASET_HUNT loop became too strict: after the core accession
 * sweep failed, it could archive even though mature domain expertise existed.
 * This policy gives the autonomous researcher a relaxed, bounded bridge: reuse
 * mature domain vocabulary to run one or two data-availability/accession probes
 * before terminal archive. It still cannot prove biology, recommend treatment,
 * rank drugs, or upgrade causal claims.
 */
object MatureDomainEvidenceProbePolicy {
    const val CLAIM_LIMIT: String = "mature_domain_evidence_probe_not_biological_proof"
    const val SOURCE_FAMILY: String = "MATURE_DOMAIN_EVIDENCE_PROBE"

    data class MatureDomainSeed(
        val domainId: String,
        val label: String,
        val vocabulary: List<String>,
        val exposureCount: Int,
        val expertiseScore: Int
    )

    data class Report(
        val active: Boolean,
        val state: String,
        val summary: String,
        val selectedDomains: List<String>,
        val querySeeds: List<String>,
        val probeAttempted: Boolean,
        val relaxedInterpretationAllowed: Boolean,
        val nextAction: String,
        val claimLimit: String = CLAIM_LIMIT
    ) {
        companion object {
            fun empty() = Report(
                active = false,
                state = "NOT_EVALUATED",
                summary = "Mature domain probe was not evaluated.",
                selectedDomains = emptyList(),
                querySeeds = emptyList(),
                probeAttempted = false,
                relaxedInterpretationAllowed = false,
                nextAction = "Run accession-first search before mature-domain probing."
            )
        }
    }

    fun seedsFromRecentReports(recentReports: List<String>): List<MatureDomainSeed> {
        if (!RuntimeFeatureFlags.ENABLE_MATURE_DOMAIN_EVIDENCE_PROBE || recentReports.isEmpty()) return emptyList()
        val out = linkedMapOf<String, MatureDomainSeed>()
        recentReports.forEach { line ->
            val report = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
            val forager = report.optJSONObject("datasetForagingReport") ?: report.optJSONObject("datasetForaging") ?: return@forEach
            val expertise = forager.optJSONObject("domainExpertiseReport") ?: return@forEach
            val cards = expertise.optJSONArray("cards") ?: return@forEach
            for (i in 0 until cards.length()) {
                val card = cards.optJSONObject(i) ?: continue
                val state = card.optString("expertiseState", "")
                val score = card.optInt("expertiseScore", 0)
                val exposure = card.optInt("priorExposureCount", 0)
                if (!state.contains("MATURE", ignoreCase = true) && exposure < RuntimeFeatureFlags.MIN_RELAXED_DOMAIN_EXPOSURES) continue
                val domainId = card.optString("domainId", "")
                if (domainId.isBlank()) continue
                val vocabArray = card.optJSONArray("workingVocabulary")
                val vocab = mutableListOf<String>()
                if (vocabArray != null) {
                    for (j in 0 until vocabArray.length()) {
                        val term = vocabArray.optString(j).trim()
                        if (term.length in 2..48) vocab += term
                    }
                }
                val previous = out[domainId]
                val seed = MatureDomainSeed(
                    domainId = domainId,
                    label = card.optString("label", domainId),
                    vocabulary = vocab.distinct().take(8),
                    exposureCount = maxOf(exposure, previous?.exposureCount ?: 0),
                    expertiseScore = maxOf(score, previous?.expertiseScore ?: 0)
                )
                out[domainId] = seed
            }
        }
        return out.values
            .filter { it.vocabulary.isNotEmpty() }
            .sortedWith(compareByDescending<MatureDomainSeed> { it.expertiseScore }.thenByDescending { it.exposureCount })
            .take(RuntimeFeatureFlags.MAX_MATURE_DOMAIN_PROBE_DOMAINS)
    }

    fun shouldRunProbe(
        recentReports: List<String>,
        candidates: List<DatasetAccessionCandidate>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        attempts: List<DatasetSourceAttempt>
    ): Boolean {
        if (!RuntimeFeatureFlags.ENABLE_MATURE_DOMAIN_EVIDENCE_PROBE) return false
        if (candidates.isNotEmpty() || parsedMetadata.isNotEmpty()) return false
        if (attempts.any { it.sourceFamily == SOURCE_FAMILY }) return false
        val attempted = attempts.map { it.sourceFamily }.toSet()
        val coreExhausted = SourcePriorityArbitrationPolicy.coreAccessionFamilies.all { it in attempted }
        return coreExhausted && seedsFromRecentReports(recentReports).isNotEmpty()
    }

    fun compileProbeQueries(recentReports: List<String>): List<ResearchQuery> {
        val seeds = seedsFromRecentReports(recentReports)
        if (seeds.isEmpty()) return emptyList()
        val focusedSeed = MatureDomainFocusModePolicy.selectSeed(seeds, recentReports)
        val selectedSeeds = listOfNotNull(focusedSeed).ifEmpty { seeds.take(1) }
        return selectedSeeds.take(RuntimeFeatureFlags.MAX_MATURE_DOMAIN_PROBE_QUERIES).mapIndexed { index, seed ->
            val domainClause = seed.vocabulary
                .take(5)
                .joinToString(" OR ") { term -> if (term.contains(" ")) "\"$term\"" else term }
            val query = "($domainClause) (GSE OR GEO OR PRJNA OR SRP OR SDY OR E-MTAB OR phs OR data availability OR deposited OR accession) " +
                "human RNA-seq single-cell transcriptome cohort sample metadata phenotype outcome severity recovery control comparator longitudinal"
            ResearchQuery(
                id = "q_v11026_mature_domain_probe_${seed.domainId}_${index}".replace(Regex("[^A-Za-z0-9_]+"), "_"),
                label = "v1.10.32 mature-domain focus probe: ${seed.label}",
                query = query,
                reason = "v1.10.32 focus mode: reuse one selected mature-domain vocabulary for 2-3 cycles to capture weak leads before archive. Research leads only; no diagnosis, treatment, dose, drug ranking, causal claim, or biological proof. Claim limit: $CLAIM_LIMIT."
            )
        }
    }

    fun evaluate(
        accessionReport: AccessionAcquisitionReport,
        domainReport: DomainExpertiseMemoryPolicy.DomainExpertiseReport,
        attempts: List<DatasetSourceAttempt>,
        recentReports: List<String>
    ): Report {
        val seeds = seedsFromRecentReports(recentReports)
        val probeAttempted = attempts.any { it.sourceFamily == SOURCE_FAMILY }
        val matureFromCurrent = domainReport.cards
            .filter { it.expertiseState.contains("MATURE", ignoreCase = true) || it.priorExposureCount >= RuntimeFeatureFlags.MIN_RELAXED_DOMAIN_EXPOSURES }
            .map { it.domainId }
        val selected = (seeds.map { it.domainId } + matureFromCurrent).distinct().take(RuntimeFeatureFlags.MAX_MATURE_DOMAIN_PROBE_DOMAINS)
        val querySeeds = compileProbeQueries(recentReports).map { it.query }.take(RuntimeFeatureFlags.MAX_MATURE_DOMAIN_PROBE_QUERIES)
        val active = selected.isNotEmpty() && accessionReport.explicitAccessions.isEmpty() && accessionReport.weakAccessions.isEmpty()
        val state = when {
            !active -> "NOT_ACTIVE"
            probeAttempted -> "MATURE_DOMAIN_PROBE_ATTEMPTED_KEEP_PRIORS"
            accessionReport.state == "NO_ACCESSION_ARCHIVE_ROUTE" -> "MATURE_DOMAIN_PROBE_BEFORE_ARCHIVE"
            else -> "MATURE_DOMAIN_PROBE_READY"
        }
        val summary = when (state) {
            "MATURE_DOMAIN_PROBE_BEFORE_ARCHIVE" -> "Core accession sources failed, but mature domain expertise exists; run a relaxed mature-domain evidence probe before terminal archive."
            "MATURE_DOMAIN_PROBE_ATTEMPTED_KEEP_PRIORS" -> "Mature-domain probe attempted; preserve domain expertise as working research priors even without accession-level proof."
            "MATURE_DOMAIN_PROBE_READY" -> "Mature domain expertise is available for bounded accession/data-availability probing."
            else -> "No mature domain probe was activated."
        }
        val next = when (state) {
            "MATURE_DOMAIN_PROBE_BEFORE_ARCHIVE" -> "Run 1–2 mature-domain accession/data-availability probes using the strongest domain vocabulary; keep all claims locked."
            "MATURE_DOMAIN_PROBE_ATTEMPTED_KEEP_PRIORS" -> "Do not discard the domain track; keep it as a working research prior, then either manually inspect likely repositories or cool down only this route."
            "MATURE_DOMAIN_PROBE_READY" -> "Use mature-domain vocabulary in a bounded accession/data-availability query before switching domains."
            else -> "Continue normal accession-first search."
        }
        return Report(
            active = active,
            state = state,
            summary = summary,
            selectedDomains = selected,
            querySeeds = querySeeds,
            probeAttempted = probeAttempted,
            relaxedInterpretationAllowed = active,
            nextAction = next
        )
    }

    fun learningNote(report: Report): String {
        if (!report.active) return "v1.10.26 mature-domain probe: inactive; no mature domain track available for relaxed evidence probing."
        return "v1.10.26 mature-domain probe: ${report.state}; domains=${report.selectedDomains.joinToString(",")}; relaxed research-prior retention active; claim-limit=${report.claimLimit}"
    }
}
