package com.immunesignal.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max

/**
 * v1.8.2: knowledge-routed deep discovery reasoner + weighted scientific term index.
 *
 * Boundary: this layer upgrades reasoning quality, not claim strength. It turns
 * axes into mechanism hypotheses, competing explanations, decisive tests,
 * contradiction plans, and cross-axis bridge questions. It never proves biology,
 * diagnosis, treatment, immune protection, or causality.
 */
data class ScientificTermCard(
    val termId: String,
    val label: String,
    val domain: String,
    val importance: Int,
    val matched: Boolean,
    val aliases: List<String>,
    val queryHints: List<String>,
    val evidenceRequired: List<String>,
    val falseFriendWarnings: List<String>,
    val routeImpact: String
)

data class ScientificKnowledgeIndexReport(
    val active: Boolean,
    val version: String,
    val matchedTerms: List<ScientificTermCard>,
    val highPriorityMissingTerms: List<String>,
    val routeHints: List<String>,
    val evidenceRequirements: List<String>,
    val falseFriendWarnings: List<String>,
    val summary: String,
    val claimLimit: String = "scientific_index_guides_search_not_proof"
) {
    companion object {
        fun empty() = ScientificKnowledgeIndexReport(
            active = false,
            version = "v1.8.2",
            matchedTerms = emptyList(),
            highPriorityMissingTerms = emptyList(),
            routeHints = emptyList(),
            evidenceRequirements = emptyList(),
            falseFriendWarnings = emptyList(),
            summary = "Scientific knowledge index did not run.",
            claimLimit = "scientific_index_guides_search_not_proof"
        )
    }
}

data class MechanismHypothesisCard(
    val mechanismId: String,
    val label: String,
    val mechanismChain: List<String>,
    val upstreamTrigger: String,
    val immuneMediator: String,
    val cellOrTissueContext: String,
    val observableSignal: String,
    val expectedOutcome: String,
    val wrongGeneralizationRisk: String,
    val confidence: Int
)

data class MechanismTournamentCard(
    val hypothesisId: String,
    val explanation: String,
    val score: Int,
    val strengths: List<String>,
    val weaknesses: List<String>,
    val discriminator: String,
    val verdict: String
)

data class DecisiveExperimentPlan(
    val decisiveQuestion: String,
    val requiredDatasetFeatures: List<String>,
    val strengthenIf: List<String>,
    val weakenIf: List<String>,
    val abandonIf: List<String>,
    val nextQuery: String,
    val expectedUpdate: String
)

data class NoveltyAndNonObviousnessReport(
    val active: Boolean,
    val score: Int,
    val classLabel: String,
    val whyNovel: List<String>,
    val whyNotYetDiscovery: List<String>,
    val claimLimit: String = "novelty_score_not_biological_proof"
) {
    companion object {
        fun empty() = NoveltyAndNonObviousnessReport(false, 0, "NOT_EVALUATED", emptyList(), listOf("No lead evaluated."), "novelty_score_not_biological_proof")
    }
}

data class DeepContradictionPlan(
    val strongestObjection: String,
    val contradictionQueries: List<String>,
    val negativeControls: List<String>,
    val falsificationTargets: List<String>,
    val cooldownIfRepeated: String
)

data class CrossAxisBridgeCard(
    val fromAxis: String,
    val toAxis: String,
    val bridgeType: String,
    val bridgeQuestion: String,
    val hiddenVariableRisk: String,
    val evidenceNeeded: List<String>,
    val score: Int
)

data class DeepThinkSessionReport(
    val active: Boolean,
    val trigger: String,
    val mechanismHypothesis: String,
    val strongestObjection: String,
    val decisiveDataset: String,
    val falsificationPath: String,
    val nextQuery: String,
    val expectedUpdate: String,
    val sessionVerdict: String,
    val claimLimit: String = "deep_think_guides_discovery_not_proof"
) {
    companion object {
        fun empty() = DeepThinkSessionReport(false, "NOT_TRIGGERED", "none", "none", "none", "none", "none", "none", "SKIP", "deep_think_guides_discovery_not_proof")
    }
}

data class DeepDiscoveryReasoningReport(
    val active: Boolean,
    val state: String,
    val intelligenceScore: Int,
    val mechanismHypotheses: List<MechanismHypothesisCard>,
    val mechanismTournament: List<MechanismTournamentCard>,
    val decisiveExperiment: DecisiveExperimentPlan,
    val noveltyReport: NoveltyAndNonObviousnessReport,
    val contradictionPlan: DeepContradictionPlan,
    val crossAxisBridgeReport: List<CrossAxisBridgeCard>,
    val deepThinkSession: DeepThinkSessionReport,
    val nextDiscoveryMove: String,
    val summary: String,
    val claimLimit: String = "deep_discovery_reasoning_not_biological_proof"
) {
    companion object {
        fun empty() = DeepDiscoveryReasoningReport(
            active = false,
            state = "NOT_RUN",
            intelligenceScore = 0,
            mechanismHypotheses = emptyList(),
            mechanismTournament = emptyList(),
            decisiveExperiment = DecisiveExperimentPlan(
                decisiveQuestion = "Run a research cycle first.",
                requiredDatasetFeatures = emptyList(),
                strengthenIf = emptyList(),
                weakenIf = emptyList(),
                abandonIf = emptyList(),
                nextQuery = "",
                expectedUpdate = "none"
            ),
            noveltyReport = NoveltyAndNonObviousnessReport.empty(),
            contradictionPlan = DeepContradictionPlan("none", emptyList(), emptyList(), emptyList(), "none"),
            crossAxisBridgeReport = emptyList(),
            deepThinkSession = DeepThinkSessionReport.empty(),
            nextDiscoveryMove = "Run a research cycle.",
            summary = "Deep discovery reasoner did not run.",
            claimLimit = "deep_discovery_reasoning_not_biological_proof"
        )
    }
}

class ScientificKnowledgeIndexEngine(private val context: Context? = null) {
    fun build(
        queries: List<ResearchQuery>,
        findings: List<ResearchFinding>,
        datasetForagingReport: DatasetForagingReport,
        hypothesisObjects: List<HypothesisObject>
    ): ScientificKnowledgeIndexReport {
        val text = buildString {
            append(queries.joinToString(" ") { it.query + " " + it.reason })
            append(' ')
            append(findings.joinToString(" ") { it.title + " " + it.matchedAxes.joinToString(" ") })
            append(' ')
            append(datasetForagingReport.candidates.joinToString(" ") { it.sourceTitle + " " + it.conditionLabelsHint + " " + it.dataType })
            append(' ')
            append(datasetForagingReport.parsedMetadata.joinToString(" ") { it.conditionLabels.joinToString(" ") + " " + it.assayType + " " + it.tissueOrSource })
            append(' ')
            append(hypothesisObjects.joinToString(" ") { it.label + " " + it.missingData.joinToString(" ") })
        }.lowercase(Locale.US)
        val terms = loadTerms()
        val matched = terms.map { term ->
            val tokenHit = (term.aliases + term.label + term.termId).any { alias -> text.contains(alias.lowercase(Locale.US)) }
            term.copy(matched = tokenHit)
        }.filter { it.matched || it.importance >= 92 }
            .sortedWith(compareByDescending<ScientificTermCard> { it.matched }.thenByDescending { it.importance })
            .take(32)
        val missingHigh = terms
            .filter { it.importance >= 90 && matched.none { m -> m.termId == it.termId && m.matched } }
            .map { it.label }
            .take(12)
        val routeHints = matched.filter { it.matched }.flatMap { it.queryHints }.distinct().take(18)
        val evidenceReq = matched.filter { it.matched }.flatMap { it.evidenceRequired }.distinct().take(18)
        val warnings = matched.flatMap { it.falseFriendWarnings }.distinct().take(14)
        return ScientificKnowledgeIndexReport(
            active = true,
            version = "v1.9.3-scientific-term-index",
            matchedTerms = matched,
            highPriorityMissingTerms = missingHigh,
            routeHints = routeHints,
            evidenceRequirements = evidenceReq.ifEmpty { listOf("species", "sample_size", "condition_labels", "outcome_labels", "time_order", "control_or_comparator") },
            falseFriendWarnings = warnings.ifEmpty { listOf("Do not treat generic inflammation as a specific immune route.") },
            summary = "Scientific index matched ${matched.count { it.matched }} term(s); ${missingHigh.size} high-priority foundation term(s) remain useful for routing.",
            claimLimit = "scientific_index_guides_search_not_proof"
        )
    }

    private fun loadTerms(): List<ScientificTermCard> {
        val assetTerms = runCatching {
            val ctx = context ?: return@runCatching emptyList<ScientificTermCard>()
            val text = ctx.assets.open("scientific_term_index_v1.9.3.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(text)
            val arr = root.optJSONArray("terms") ?: JSONArray()
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                ScientificTermCard(
                    termId = obj.optString("id"),
                    label = obj.optString("label"),
                    domain = obj.optString("domain", "biology"),
                    importance = obj.optInt("importance", 70),
                    matched = false,
                    aliases = obj.optJSONArray("aliases")?.toStringList() ?: emptyList(),
                    queryHints = obj.optJSONArray("queryHints")?.toStringList() ?: emptyList(),
                    evidenceRequired = obj.optJSONArray("evidenceRequired")?.toStringList() ?: emptyList(),
                    falseFriendWarnings = obj.optJSONArray("falseFriendWarnings")?.toStringList() ?: emptyList(),
                    routeImpact = obj.optString("routeImpact", "search_prior")
                )
            }
        }.getOrDefault(emptyList())
        return if (assetTerms.isNotEmpty()) assetTerms else defaultTerms()
    }

    private fun JSONArray.toStringList(): List<String> = (0 until length()).mapNotNull { optString(it).takeIf { value -> value.isNotBlank() } }

    private fun defaultTerms(): List<ScientificTermCard> = listOf(
        term("innate_immunity", "Innate immunity", "immunology", 96, listOf("innate", "macrophage", "dendritic", "neutrophil", "pattern recognition", "TLR"), listOf("innate immune response", "pattern recognition receptor", "monocyte macrophage dendritic"), listOf("cell_type", "trigger", "time_order", "cytokine_or_gene_signature"), listOf("Innate activation is not automatically allergy, antiviral response, or autoimmunity."), "prioritize early trigger-response context"),
        term("adaptive_immunity", "Adaptive immunity", "immunology", 96, listOf("adaptive", "T cell", "B cell", "antibody", "memory", "clonal"), listOf("T cell B cell antibody memory", "clonal expansion", "adaptive immune response"), listOf("cell_type", "antigen_or_trigger", "time_order", "outcome_label"), listOf("Do not merge T-cell activation, B-cell antibody response, and cytokine intensity into one bucket."), "separate T-cell, B-cell, and antibody routes"),
        term("type2_allergy", "Type-2 allergy", "allergy", 97, listOf("allergy", "type 2", "Th2", "IL-4", "IL-5", "IL-13", "IgE", "eosinophil", "mast cell", "basophil", "atopy"), listOf("type 2 cytokines", "IgE eosinophil mast cell", "allergic inflammation"), listOf("trigger", "tissue_site", "type2_markers", "control_or_comparator", "severity_or_symptom_label"), listOf("Do not treat generic inflammation or interferon response as allergy."), "route allergy signals separately from antiviral and autoimmune signals"),
        term("interferon_antiviral", "Interferon antiviral response", "virology", 98, listOf("interferon", "IFN", "ISG", "viral load", "antiviral", "infection", "SARS", "influenza"), listOf("interferon stimulated genes", "viral load recovery", "antiviral response time course"), listOf("viral_load", "interferon_markers", "time_course", "recovery_or_deterioration", "human_or_relevant_model"), listOf("Allergy datasets do not prove antiviral behavior."), "require viral-load and timing labels before antiviral interpretation"),
        term("inflammation", "Inflammation", "immunology", 91, listOf("inflammation", "IL-6", "TNF", "CRP", "cytokine", "chemokine"), listOf("inflammatory cytokines", "TNF IL-6 CRP", "inflammatory marker"), listOf("specific_route", "cell_type", "tissue_context", "time_order", "outcome_label"), listOf("Inflammation is a broad state, not a diagnosis or mechanism by itself."), "force specificity before routing"),
        term("regulatory_brake", "Regulatory immune brake", "immunology", 93, listOf("Treg", "regulatory T", "IL-10", "TGF-beta", "checkpoint", "immune regulation"), listOf("regulatory T cell IL-10 TGF beta", "immune tolerance", "regulatory brake"), listOf("regulatory_marker", "effector_marker", "control_or_comparator", "outcome_label"), listOf("Low inflammation does not automatically mean regulatory control is functioning."), "look for regulation vs activation balance"),
        term("dna_genomics", "DNA/genomics", "genomics", 89, listOf("DNA", "genome", "genetic", "SNP", "GWAS", "variant", "HLA"), listOf("genetic variant immune response", "HLA allergy autoimmunity", "GWAS immune phenotype"), listOf("variant_or_locus", "phenotype", "population", "replication", "effect_size"), listOf("Genetic association is not dynamic immune state."), "separate inherited risk from current RNA/protein state"),
        term("rna_transcriptomics", "RNA/transcriptomics", "omics", 98, listOf("RNA", "RNA-seq", "transcriptomic", "gene expression", "single-cell", "scRNA", "spatial transcriptomics"), listOf("single-cell RNA immune state", "RNA-seq outcome severity", "transcriptomic signature"), listOf("assay_type", "cell_type", "tissue_source", "condition_labels", "outcome_labels", "batch_or_control"), listOf("Transcriptomic signature can reflect cell composition, treatment, batch, or tissue context, not only mechanism."), "prioritize cell/tissue/time metadata before mechanism language"),
        term("epigenetics", "Epigenetics", "omics", 86, listOf("methylation", "epigenetic", "chromatin", "ATAC", "histone"), listOf("DNA methylation immune aging", "ATAC-seq immune cells", "epigenetic inflammatory memory"), listOf("assay_type", "cell_type", "age_or_context", "control_or_comparator", "replication"), listOf("Epigenetic age and immune activation are not interchangeable."), "use as mechanism plausibility until validated"),
        term("trained_immunity", "Trained immunity / immune memory", "immunology", 88, listOf("trained immunity", "innate memory", "immune memory", "tolerance", "priming"), listOf("trained immunity monocyte", "immune memory tissue", "tolerance priming"), listOf("pre_post_trigger", "cell_type", "functional_readout", "time_order", "control"), listOf("Memory-like wording requires time-order or repeat challenge evidence."), "use for repeated-trigger hypotheses only with temporal evidence"),
        term("microbiome_barrier", "Microbiome / barrier axis", "mucosal", 84, listOf("microbiome", "gut barrier", "dysbiosis", "epithelium", "mucosal", "gut-lung"), listOf("microbiome gut barrier allergy", "mucosal immune response", "gut lung axis"), listOf("sample_site", "microbiome_profile", "barrier_marker", "immune_marker", "outcome_label"), listOf("Microbiome correlation is especially confounded by diet, drugs, and sampling site."), "route as context modifier unless immune outcome is present"),
        term("outcome_labels", "Outcome labels", "evidence", 100, listOf("outcome", "severity", "recovery", "endpoint", "clinical resolution", "viral load", "symptom score", "deterioration"), listOf("outcome severity recovery endpoint", "clinical resolution follow-up"), listOf("outcome_label", "timepoint", "measurement_definition"), listOf("Markers without outcomes cannot prove usefulness or direction."), "hard gate for upgrade")
    )

    private fun term(id: String, label: String, domain: String, importance: Int, aliases: List<String>, hints: List<String>, req: List<String>, warn: List<String>, impact: String): ScientificTermCard = ScientificTermCard(id, label, domain, importance, false, aliases, hints, req, warn, impact)
}

object DeepDiscoveryReasonerV180 {
    fun reason(
        scientificIndex: ScientificKnowledgeIndexReport,
        findings: List<ResearchFinding>,
        hypothesisObjects: List<HypothesisObject>,
        evidenceObjects: List<EvidenceObject>,
        datasetForagingReport: DatasetForagingReport,
        specializedReasoningReport: SpecializedReasoningReport,
        epistemicBeliefReport: EpistemicBeliefReport,
        causalReadinessReport: CausalReadinessReport,
        miniPeerReviewReport: MiniPeerReviewReport
    ): DeepDiscoveryReasoningReport {
        val mechanisms = MechanismHypothesisEngine.generate(scientificIndex, findings, hypothesisObjects, datasetForagingReport)
        val tournament = MechanismTournamentEngine.compete(mechanisms, evidenceObjects, datasetForagingReport, causalReadinessReport)
        val decisive = DecisiveExperimentPlanner.plan(mechanisms, tournament, scientificIndex, datasetForagingReport, specializedReasoningReport)
        val novelty = NoveltyAndNonObviousnessScorer.score(mechanisms, tournament, findings, datasetForagingReport, scientificIndex)
        val contradictions = DeepContradictionMiner.plan(mechanisms, tournament, datasetForagingReport, miniPeerReviewReport)
        val bridges = CrossAxisBridgeReasoner.bridge(scientificIndex, findings, datasetForagingReport, hypothesisObjects)
        val deepThink = DeepThinkSessionEngine.runIfNeeded(
            mechanisms = mechanisms,
            tournament = tournament,
            decisive = decisive,
            contradictionPlan = contradictions,
            epistemicBeliefReport = epistemicBeliefReport,
            causalReadinessReport = causalReadinessReport,
            datasetForagingReport = datasetForagingReport,
            novelty = novelty
        )
        val score = (novelty.score * 0.25 + (tournament.firstOrNull()?.score ?: 0) * 0.30 + causalReadinessReport.score * 0.20 + scientificIndex.matchedTerms.count { it.matched }.coerceAtMost(10) * 2.5).toInt().coerceIn(0, 100)
        val state = when {
            deepThink.active && novelty.score >= 60 -> "DEEP_INSPECTION_REQUIRED"
            mechanisms.isNotEmpty() && tournament.any { it.verdict == "LEAD" } -> "MECHANISM_LEAD"
            mechanisms.isNotEmpty() -> "MECHANISM_HYPOTHESIS_ONLY"
            else -> "NO_DEEP_LEAD"
        }
        val nextMove = if (deepThink.active) deepThink.nextQuery else decisive.nextQuery
        return DeepDiscoveryReasoningReport(
            active = true,
            state = state,
            intelligenceScore = score,
            mechanismHypotheses = mechanisms,
            mechanismTournament = tournament,
            decisiveExperiment = decisive,
            noveltyReport = novelty,
            contradictionPlan = contradictions,
            crossAxisBridgeReport = bridges,
            deepThinkSession = deepThink,
            nextDiscoveryMove = nextMove,
            summary = "Deep discovery v1.9.3: $state; mechanisms=${mechanisms.size}; tournament=${tournament.firstOrNull()?.verdict ?: "none"}; novelty=${novelty.classLabel} ${novelty.score}/100.",
            claimLimit = "deep_discovery_reasoning_not_biological_proof"
        )
    }
}

object MechanismHypothesisEngine {
    fun generate(
        scientificIndex: ScientificKnowledgeIndexReport,
        findings: List<ResearchFinding>,
        hypothesisObjects: List<HypothesisObject>,
        datasetForagingReport: DatasetForagingReport
    ): List<MechanismHypothesisCard> {
        val matched = scientificIndex.matchedTerms.filter { it.matched }
        val labels = matched.map { it.termId }.toSet()
        val axes = (findings.flatMap { it.matchedAxes } + hypothesisObjects.flatMap { it.label.split("__", " ") } + matched.map { it.label }).joinToString(" ").lowercase(Locale.US)
        val tissue = datasetForagingReport.parsedMetadata.firstOrNull()?.tissueOrSource?.takeIf { it.isNotBlank() }
            ?: datasetForagingReport.candidates.firstOrNull()?.conditionLabelsHint?.takeIf { it.isNotBlank() }
            ?: "unknown tissue/context"
        val assay = datasetForagingReport.parsedMetadata.firstOrNull()?.assayType?.takeIf { it.isNotBlank() }
            ?: datasetForagingReport.candidates.firstOrNull()?.dataType?.takeIf { it.isNotBlank() }
            ?: "metadata-level evidence"
        val cards = mutableListOf<MechanismHypothesisCard>()
        if (labels.contains("type2_allergy") || axes.contains("allergy") || axes.contains("ige")) {
            cards += MechanismHypothesisCard(
                mechanismId = "MECH_TYPE2_LOCAL_REACTIVITY",
                label = "Type-2/local allergy reactivity as a route-specific immune state",
                mechanismChain = listOf("external trigger/allergen", "epithelial or mast-cell activation", "Type-2 cytokine/IgE/eosinophil route", "local tissue response", "severity or resolution label required"),
                upstreamTrigger = "allergen/contact/airway or skin trigger",
                immuneMediator = "IL-4/IL-5/IL-13, IgE, eosinophils, mast cells",
                cellOrTissueContext = tissue,
                observableSignal = assay,
                expectedOutcome = "Should separate trigger-specific allergy from generic inflammation only if outcome/control labels exist.",
                wrongGeneralizationRisk = "Do not generalize this to antiviral response, autoimmunity, or whole-body inflammation without comparator data.",
                confidence = if (datasetForagingReport.parsedMetadata.any { it.outcomeLabels.isNotEmpty() }) 62 else 46
            )
        }
        if (labels.contains("interferon_antiviral") || axes.contains("viral") || axes.contains("interferon")) {
            cards += MechanismHypothesisCard(
                mechanismId = "MECH_IFN_TIMING_ANTIVIRAL",
                label = "Interferon timing as antiviral control vs inflammatory damage discriminator",
                mechanismChain = listOf("viral exposure", "early/delayed interferon response", "viral-load movement", "inflammatory amplification or recovery", "clinical outcome"),
                upstreamTrigger = "viral infection or viral mimic",
                immuneMediator = "IFN/ISG antiviral axis",
                cellOrTissueContext = tissue,
                observableSignal = "viral load + IFN/ISG transcriptomic timing",
                expectedOutcome = "Early coordinated IFN should align with viral control; delayed/excessive IFN may align with severity.",
                wrongGeneralizationRisk = "Cannot be inferred from allergy/contact dermatitis datasets unless viral comparator exists.",
                confidence = if (datasetForagingReport.parsedMetadata.any { it.timeCourseLabels.isNotEmpty() }) 58 else 38
            )
        }
        if (labels.contains("rna_transcriptomics") || axes.contains("rna") || axes.contains("transcript")) {
            cards += MechanismHypothesisCard(
                mechanismId = "MECH_RNA_STATE_CELL_CONTEXT",
                label = "RNA/transcriptomic state as hidden immune-context map",
                mechanismChain = listOf("trigger or treatment context", "cell composition and activation state", "RNA expression signature", "route-fit by tissue/cell metadata", "outcome validation required"),
                upstreamTrigger = "condition, exposure, treatment, or infection context",
                immuneMediator = "gene-expression program; cell-type composition; pathway activity",
                cellOrTissueContext = tissue,
                observableSignal = assay,
                expectedOutcome = "May reveal immune state before routine markers, but only after metadata, controls, and outcome labels are parsed.",
                wrongGeneralizationRisk = "RNA signal may be batch effect, tissue source, treatment artifact, or cell-composition shift.",
                confidence = if (datasetForagingReport.parsedMetadata.isNotEmpty()) 64 else 44
            )
        }
        if (cards.isEmpty()) {
            cards += MechanismHypothesisCard(
                mechanismId = "MECH_GENERIC_EVIDENCE_ROUTE",
                label = "Evidence-route hypothesis pending scientific term match",
                mechanismChain = listOf("source lead", "axis match", "metadata parser", "control/outcome check", "belief update"),
                upstreamTrigger = "unknown",
                immuneMediator = "unknown",
                cellOrTissueContext = tissue,
                observableSignal = assay,
                expectedOutcome = "Need term-index match and minimum metadata before a specific mechanism is proposed.",
                wrongGeneralizationRisk = "Generic inflammation or title-level evidence could create a false bridge.",
                confidence = 25
            )
        }
        return cards.sortedByDescending { it.confidence }.take(4)
    }
}

object MechanismTournamentEngine {
    fun compete(
        mechanisms: List<MechanismHypothesisCard>,
        evidenceObjects: List<EvidenceObject>,
        datasetForagingReport: DatasetForagingReport,
        causalReadinessReport: CausalReadinessReport
    ): List<MechanismTournamentCard> {
        if (mechanisms.isEmpty()) return emptyList()
        val hasOutcome = datasetForagingReport.parsedMetadata.any { it.outcomeLabels.isNotEmpty() }
        val hasControl = datasetForagingReport.parsedMetadata.any { it.controlLabels.isNotEmpty() } || evidenceObjects.any { it.hasNegativeControl }
        val hasTime = datasetForagingReport.parsedMetadata.any { it.timeCourseLabels.isNotEmpty() } || evidenceObjects.any { it.hasLongitudinalSignal }
        return mechanisms.map { mech ->
            var score = mech.confidence
            val strengths = mutableListOf<String>()
            val weaknesses = mutableListOf<String>()
            if (hasOutcome) { score += 12; strengths += "outcome_labels_present" } else weaknesses += "missing_outcome_labels"
            if (hasControl) { score += 10; strengths += "control_or_comparator_present" } else weaknesses += "missing_control_or_comparator"
            if (hasTime) { score += 10; strengths += "time_order_present" } else weaknesses += "missing_time_order"
            if (causalReadinessReport.level >= 3) { score += 8; strengths += "controlled_comparison_threshold_met" } else weaknesses += "below_controlled_comparison"
            if (mech.wrongGeneralizationRisk.contains("Cannot", true) || mech.wrongGeneralizationRisk.contains("Do not", true)) score -= 3
            val final = score.coerceIn(0, 100)
            MechanismTournamentCard(
                hypothesisId = mech.mechanismId,
                explanation = mech.label,
                score = final,
                strengths = strengths,
                weaknesses = weaknesses,
                discriminator = when {
                    !hasOutcome -> "Find outcome/recovery/severity labels for the same route."
                    !hasControl -> "Find control/placebo/comparator slots."
                    !hasTime -> "Find serial/follow-up/time-course evidence."
                    else -> "Run contradiction/control search against the strongest competing explanation."
                },
                verdict = when {
                    final >= 70 && hasOutcome && hasControl -> "LEAD"
                    final >= 50 -> "INSPECT"
                    else -> "WEAK_OR_ANALOGY"
                }
            )
        }.sortedByDescending { it.score }
    }
}

object DecisiveExperimentPlanner {
    fun plan(
        mechanisms: List<MechanismHypothesisCard>,
        tournament: List<MechanismTournamentCard>,
        scientificIndex: ScientificKnowledgeIndexReport,
        datasetForagingReport: DatasetForagingReport,
        specializedReasoningReport: SpecializedReasoningReport
    ): DecisiveExperimentPlan {
        val top = tournament.firstOrNull()
        val topMechanism = mechanisms.firstOrNull { it.mechanismId == top?.hypothesisId } ?: mechanisms.firstOrNull()
        val required = (scientificIndex.evidenceRequirements + top?.weaknesses.orEmpty() + listOf("species", "sample_size", "condition_labels", "outcome_labels", "time_order", "control_or_comparator", "license_or_access"))
            .map { it.replace("missing_", "") }
            .distinct()
            .take(12)
        val route = datasetForagingReport.routeFitAssessments.firstOrNull()?.targetRoute ?: topMechanism?.label ?: "immune_route"
        val query = buildString {
            append(route.replace("_", " "))
            append(" RNA-seq single-cell human outcome severity recovery longitudinal control comparator metadata")
            if (topMechanism?.immuneMediator?.contains("interferon", true) == true) append(" viral load IFN ISG")
            if (topMechanism?.immuneMediator?.contains("IgE", true) == true) append(" IgE eosinophil mast cell IL-4 IL-5 IL-13")
        }.trim()
        return DecisiveExperimentPlan(
            decisiveQuestion = "Which dataset can distinguish ${topMechanism?.label ?: "the top mechanism"} from its strongest alternative using outcome/time/control evidence?",
            requiredDatasetFeatures = required,
            strengthenIf = listOf("same-route human dataset", "condition + control slots", "outcome/recovery/severity labels", "time-course or pre/post trigger", "cell/tissue metadata agrees with mechanism"),
            weakenIf = listOf("metadata/title-only after next cycle", "route-fit remains high but usability stays low", "control slots contradict mechanism", "only animal/cell evidence is available for human claim"),
            abandonIf = listOf("better competing mechanism explains the same dataset with fewer assumptions", "negative-control search breaks the link", "no outcome/time/control labels after two bounded cycles"),
            nextQuery = query.ifBlank { specializedReasoningReport.decisiveNextTest },
            expectedUpdate = "Advance only if at least one blocker closes; otherwise weaken or archive the route."
        )
    }
}

object NoveltyAndNonObviousnessScorer {
    fun score(
        mechanisms: List<MechanismHypothesisCard>,
        tournament: List<MechanismTournamentCard>,
        findings: List<ResearchFinding>,
        datasetForagingReport: DatasetForagingReport,
        scientificIndex: ScientificKnowledgeIndexReport
    ): NoveltyAndNonObviousnessReport {
        if (mechanisms.isEmpty()) return NoveltyAndNonObviousnessReport.empty()
        val crossDomain = scientificIndex.matchedTerms.filter { it.matched }.map { it.domain }.distinct().size
        val hasDataset = datasetForagingReport.candidates.isNotEmpty()
        val hasParsed = datasetForagingReport.parsedMetadata.isNotEmpty()
        val axisBreadth = findings.flatMap { it.matchedAxes }.distinct().size
        val leadScore = tournament.firstOrNull()?.score ?: 0
        var score = 15 + crossDomain * 8 + axisBreadth.coerceAtMost(5) * 4 + leadScore / 3
        if (hasDataset) score += 10
        if (hasParsed) score += 10
        if (datasetForagingReport.parsedMetadata.any { it.outcomeLabels.isNotEmpty() }) score += 12
        val final = score.coerceIn(0, 100)
        val label = when {
            final >= 80 -> "POTENTIAL_NON_OBVIOUS_DISCOVERY_LEAD"
            final >= 60 -> "USEFUL_CROSS_AXIS_BRIDGE"
            final >= 40 -> "KNOWN_LINK_IN_NEW_CONTEXT"
            final >= 20 -> "ORDINARY_LEAD"
            else -> "WEAK_SPECULATION"
        }
        return NoveltyAndNonObviousnessReport(
            active = true,
            score = final,
            classLabel = label,
            whyNovel = listOf(
                "Matched ${crossDomain} scientific domain(s).",
                "Axis breadth=${axisBreadth}; dataset candidate present=$hasDataset; parsed metadata present=$hasParsed.",
                "Top mechanism score=${leadScore}/100."
            ),
            whyNotYetDiscovery = buildList {
                if (!hasParsed) add("Dataset metadata is not parsed enough.")
                if (datasetForagingReport.parsedMetadata.none { it.outcomeLabels.isNotEmpty() }) add("Outcome/recovery/severity labels are missing.")
                if (datasetForagingReport.parsedMetadata.none { it.controlLabels.isNotEmpty() }) add("Control/comparator structure is missing or weak.")
            }.ifEmpty { listOf("Still requires independent replication and negative controls.") },
            claimLimit = "novelty_score_not_biological_proof"
        )
    }
}

object DeepContradictionMiner {
    fun plan(
        mechanisms: List<MechanismHypothesisCard>,
        tournament: List<MechanismTournamentCard>,
        datasetForagingReport: DatasetForagingReport,
        miniPeerReviewReport: MiniPeerReviewReport
    ): DeepContradictionPlan {
        val top = mechanisms.firstOrNull()
        val route = datasetForagingReport.routeFitAssessments.firstOrNull()?.targetRoute?.replace("_", " ") ?: top?.label ?: "immune route"
        val objection = miniPeerReviewReport.strongestObjection.takeIf { it.isNotBlank() && it != "none" }
            ?: tournament.firstOrNull()?.weaknesses?.joinToString(", ")
            ?: "The mechanism may be a false bridge caused by metadata, tissue, batch, or route contamination."
        return DeepContradictionPlan(
            strongestObjection = objection,
            contradictionQueries = listOf(
                "$route negative control no association outcome severity",
                "$route comparator control contradict transcriptomic signature",
                "$route treatment artifact batch effect cell composition",
                "$route fails to predict recovery deterioration"
            ).distinct().take(4),
            negativeControls = listOf("unrelated_marker_control", "shuffled_timeline", "wrong_tissue_or_cell_type", "same_assay_unrelated_condition"),
            falsificationTargets = listOf("outcome_labels_absent", "control_slots_break_link", "better_route_explains_data", "time_order_reversed_or_missing"),
            cooldownIfRepeated = "If the same contradiction or metadata-only gap repeats twice, cool down this mechanism route for one cycle."
        )
    }
}

object CrossAxisBridgeReasoner {
    fun bridge(
        scientificIndex: ScientificKnowledgeIndexReport,
        findings: List<ResearchFinding>,
        datasetForagingReport: DatasetForagingReport,
        hypothesisObjects: List<HypothesisObject>
    ): List<CrossAxisBridgeCard> {
        val axes = (scientificIndex.matchedTerms.filter { it.matched }.map { it.termId } + findings.flatMap { it.matchedAxes } + hypothesisObjects.flatMap { it.label.split("__") })
            .map { it.trim().lowercase(Locale.US) }
            .filter { it.isNotBlank() }
            .distinct()
        val candidates = mutableListOf<CrossAxisBridgeCard>()
        fun addBridge(from: String, to: String, type: String, question: String, risk: String, evidence: List<String>, score: Int) {
            if (axes.any { it.contains(from) } && axes.any { it.contains(to) }) {
                candidates += CrossAxisBridgeCard(from, to, type, question, risk, evidence, score)
            }
        }
        addBridge("rna", "type2", "measurement_bridge", "Does transcriptomic state separate Type-2 allergy from generic inflammation?", "RNA may reflect cell composition, tissue source, or treatment artifact.", listOf("cell_type", "tissue_source", "control", "outcome_labels"), 74)
        addBridge("rna", "interferon", "temporal_bridge", "Does RNA/ISG timing precede recovery or deterioration?", "Interferon can be protective or damaging depending on timing.", listOf("viral_load", "time_course", "IFN/ISG", "outcome"), 78)
        addBridge("inflammation", "type2", "confounder_bridge", "Is allergy-specific Type-2 activation being confused with generic inflammation?", "IL-6/TNF/CRP may not identify allergy route.", listOf("type2_markers", "trigger", "comparator", "tissue_site"), 70)
        addBridge("dna", "rna", "layer_bridge", "Is inherited genetic risk separate from current gene-expression state?", "DNA association may not explain current immune dynamics.", listOf("variant", "expression", "cell_type", "replication"), 68)
        if (candidates.isEmpty() && axes.size >= 2) {
            candidates += CrossAxisBridgeCard(
                fromAxis = axes[0],
                toAxis = axes[1],
                bridgeType = "analogy_bridge",
                bridgeQuestion = "Is this cross-axis link real, or only a search co-occurrence?",
                hiddenVariableRisk = "Shared tissue/source/assay terms may create a false bridge.",
                evidenceNeeded = listOf("same_dataset", "control", "time_order", "outcome"),
                score = if (datasetForagingReport.parsedMetadata.isNotEmpty()) 52 else 35
            )
        }
        return candidates.sortedByDescending { it.score }.take(5)
    }
}

object DeepThinkSessionEngine {
    fun runIfNeeded(
        mechanisms: List<MechanismHypothesisCard>,
        tournament: List<MechanismTournamentCard>,
        decisive: DecisiveExperimentPlan,
        contradictionPlan: DeepContradictionPlan,
        epistemicBeliefReport: EpistemicBeliefReport,
        causalReadinessReport: CausalReadinessReport,
        datasetForagingReport: DatasetForagingReport,
        novelty: NoveltyAndNonObviousnessReport
    ): DeepThinkSessionReport {
        val repeatedGap = epistemicBeliefReport.revisedBeliefs >= 2 || epistemicBeliefReport.weakenedBeliefs >= 2
        val highRouteLowReadiness = datasetForagingReport.scoreSeparation.routeFitScore >= 80 && datasetForagingReport.scoreSeparation.datasetUsabilityScore < 70
        val contradiction = tournament.firstOrNull()?.weaknesses?.isNotEmpty() == true || causalReadinessReport.blockers.isNotEmpty()
        val blockedLead = novelty.score >= 55 && (highRouteLowReadiness || causalReadinessReport.level < 3)
        val trigger = when {
            repeatedGap -> "REPEATED_BELIEF_OR_GAP_REVISION"
            highRouteLowReadiness -> "HIGH_ROUTE_FIT_LOW_USABILITY"
            blockedLead -> "NOVELTY_LEAD_BLOCKED_BY_EVIDENCE"
            contradiction -> "CONTRADICTION_OR_CAUSAL_BLOCKER"
            else -> "NOT_TRIGGERED"
        }
        if (trigger == "NOT_TRIGGERED") return DeepThinkSessionReport.empty()
        val topMechanism = mechanisms.firstOrNull()
        return DeepThinkSessionReport(
            active = true,
            trigger = trigger,
            mechanismHypothesis = topMechanism?.mechanismChain?.joinToString(" → ") ?: "No mechanism chain available.",
            strongestObjection = contradictionPlan.strongestObjection,
            decisiveDataset = decisive.requiredDatasetFeatures.joinToString(", "),
            falsificationPath = decisive.abandonIf.joinToString("; "),
            nextQuery = decisive.nextQuery,
            expectedUpdate = decisive.expectedUpdate,
            sessionVerdict = if (blockedLead) "THINK_THEN_INSPECT" else "THINK_THEN_ROUTE",
            claimLimit = "deep_think_guides_discovery_not_proof"
        )
    }
}
