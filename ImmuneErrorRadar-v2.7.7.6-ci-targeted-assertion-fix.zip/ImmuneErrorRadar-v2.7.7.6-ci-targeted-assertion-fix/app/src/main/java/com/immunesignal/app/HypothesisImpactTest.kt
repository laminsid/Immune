package com.immunesignal.app

data class HypothesisImpactAssessment(
    val signalFlip: String,
    val decisionImpact: String,
    val changedMainBody: Boolean
)

/** Hard filter: a lead matters only if it changes rank, state, gate, next
 * evidence, or bias warning. Otherwise keep it as background/appendix. */
object HypothesisImpactTest {
    fun evaluate(
        card: HypothesisRankCard,
        gate: MinimumDataPackAssessment,
        states: ResearchStates,
        findings: List<ResearchFinding>
    ): HypothesisImpactAssessment {
        val hasNewHuman = findings.any { it.evidence.speciesClass == "human" }
        val hasContradictionPrompt = card.whyRanked.any { it.contains("contradict", ignoreCase = true) || it.contains("opposing", ignoreCase = true) }
        val signalFlip = when {
            card.status == "STRONG_SIGNAL" && gate.status == "PASS" -> "upgrade_candidate"
            gate.status == "BLOCKED" -> "quality_stop"
            states.biasRiskState == "Severe Bias" -> "downgrade_for_bias"
            hasNewHuman && card.evidenceQualityScore >= 60 -> "human_evidence_added"
            hasContradictionPrompt -> "contradiction_check_required"
            else -> "no_major_flip"
        }
        val impact = when (signalFlip) {
            "upgrade_candidate" -> "Allow focused 14-day tracking; still no causal claim until falsification criteria pass."
            "quality_stop" -> "Do not upgrade. Collect minimum data pack before treating this as a pattern."
            "downgrade_for_bias" -> "Move out of main discovery claims; run negative controls and contradiction search."
            "human_evidence_added" -> "Keep in main report; compare with personal timeline and missing measurements."
            "contradiction_check_required" -> "Keep as Watch only; actively search opposing evidence before next upgrade."
            else -> "No decision impact; keep as background unless it informs next measurement."
        }
        return HypothesisImpactAssessment(signalFlip, impact, signalFlip != "no_major_flip" || card.overallScore >= 55)
    }
}
