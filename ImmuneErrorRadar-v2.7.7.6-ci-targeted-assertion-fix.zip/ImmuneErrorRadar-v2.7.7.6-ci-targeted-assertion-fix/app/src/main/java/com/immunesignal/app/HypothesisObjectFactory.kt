package com.immunesignal.app

/**
 * v1.2 research lock adapter.
 *
 * Builds stable hypothesis objects from existing rank cards/findings without
 * adding new biological scope. This is the DTOS lesson translated to research:
 * every lead must expose states, gates, next evidence, and falsification.
 */
object HypothesisObjectFactory {
    fun build(
        cards: List<HypothesisRankCard>,
        findings: List<ResearchFinding>,
        importedSignals: List<ImportedReportSignal>
    ): List<HypothesisObject> {
        if (cards.isEmpty()) return emptyList()
        return cards.map { card ->
            val related = findings.filter { HypothesisId.fromAxes(it.matchedAxes) == card.hypothesisId }
                .ifEmpty { findings.filter { it.bridgeSignal == card.label }.take(3) }
            val axes = related.flatMap { it.matchedAxes }.ifEmpty { card.hypothesisId.split("__") }.distinct()
            val minPack = MinimumDataPackGate.assess(card, axes, related, importedSignals)
            val states = ResearchStateEngine.classify(card, minPack, related)
            val impact = HypothesisImpactTest.evaluate(card, minPack, states, related)
            HypothesisObject(
                hypothesisId = card.hypothesisId,
                label = card.label,
                status = card.status,
                discoveryState = states.discoveryState,
                biasRiskState = states.biasRiskState,
                dataTrustScore = DataTrustScore.estimate(card, related, minPack),
                evidenceScore10 = EvidenceScore.estimate(card, related, minPack),
                causalityScore = card.causalityScore,
                minimumDataPackStatus = minPack.status,
                missingData = minPack.missingData,
                nextBestMeasurement = minPack.nextBestMeasurement.ifBlank { card.nextBestMeasurement },
                signalFlip = impact.signalFlip,
                decisionImpact = impact.decisionImpact,
                falsification = FalsificationBuilder.forHypothesis(axes, minPack)
            )
        }.sortedWith(compareByDescending<HypothesisObject> { stateWeight(it.discoveryState) }.thenByDescending { it.dataTrustScore })
    }

    private fun stateWeight(state: String): Int = when (state) {
        "Strong Candidate" -> 4
        "Active" -> 3
        "Early" -> 2
        "Off" -> 1
        else -> 0
    }
}

object HypothesisId {
    fun fromAxes(axes: List<String>): String {
        val core = axes.sorted().take(4).joinToString("__")
        return if (core.isBlank()) "background_low_signal" else core
    }
}

object DataTrustScore {
    fun estimate(card: HypothesisRankCard, findings: List<ResearchFinding>, gate: MinimumDataPackAssessment): Int {
        if (findings.isEmpty()) return (card.evidenceQualityScore * 0.70).toInt().coerceIn(0, 100)
        val abstractPenalty = findings.count { it.sanityFlags.contains("METADATA_ONLY") || it.sanityFlags.contains("ABSTRACT_FETCH_FAILED") } * 4
        val gatePenalty = if (gate.status == "BLOCKED") 14 else if (gate.status == "PARTIAL") 7 else 0
        val sourceDiversityBonus = findings.map { it.sourceId }.distinct().size.coerceAtMost(3) * 2
        val base = card.evidenceQualityScore + sourceDiversityBonus - abstractPenalty - gatePenalty
        return base.coerceIn(0, 100)
    }
}

object EvidenceScore {
    fun estimate(card: HypothesisRankCard, findings: List<ResearchFinding>, gate: MinimumDataPackAssessment): Double {
        val human = if (findings.any { it.evidence.speciesClass == "human" }) 2.0 else if (findings.any { it.evidence.speciesClass != "unknown" }) 0.8 else 0.0
        val mechanism = if (card.causalityScore >= 60) 2.0 else if (card.causalityScore >= 40) 1.2 else 0.4
        val crossSource = when {
            findings.map { it.sourceId }.distinct().size >= 3 -> 2.0
            findings.map { it.sourceId }.distinct().size >= 2 -> 1.2
            else -> 0.4
        }
        val personal = when {
            card.personalRepeatability >= 3 -> 2.0
            card.personalRepeatability >= 1 -> 1.0
            else -> 0.0
        }
        val negative = negativeControlEvidencePoints(card.negativeControlStatus)
        val gatePenalty = if (gate.status == "BLOCKED") 1.5 else 0.0
        return (human + mechanism + crossSource + personal + negative - gatePenalty).coerceIn(0.0, 10.0)
    }

    private fun negativeControlEvidencePoints(status: String): Double {
        val s = status.lowercase()
        return when {
            s.contains("pass") || s.contains("passed") || s.contains("controls_passed") -> 2.0
            s.contains("control_required_before_strong") -> 0.4
            s.contains("watch_requires_controls") -> 0.8
            s.contains("weak_no_control_possible") -> 1.2
            s.contains("fail") || s.contains("failed") -> 0.0
            s.contains("control") -> 0.8
            else -> 1.2
        }
    }
}
