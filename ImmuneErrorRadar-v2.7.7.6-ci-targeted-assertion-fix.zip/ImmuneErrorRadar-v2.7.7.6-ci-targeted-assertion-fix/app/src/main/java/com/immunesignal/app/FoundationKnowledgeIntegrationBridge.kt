package com.immunesignal.app

import android.content.Context

/**
 * FoundationKnowledgeIntegrationBridge: Safe integration point
 * 
 * This integrates v1.4.6 Foundation Knowledge System into v1.4.5 ResearchAutopilot
 * WITHOUT modifying any v1.4.5 code.
 * 
 * Architecture:
 * ResearchAutopilot
 * ├─ [v1.4.5 unchanged]
 * │  ├─ QueryFeedbackPlanner
 * │  ├─ CandidateCollector
 * │  ├─ DatasetTriageEngine
 * │  └─ ... (all other v1.4.5 components)
 * │
 * └─ [v1.4.6 NEW - Optional]
 *    ├─ FoundationKnowledgeLayer
 *    ├─ AxisRankingEngine
 *    ├─ FoundationConflictResolver
 *    ├─ FoundationKnowledgeAccuracyLedger
 *    └─ FoundationPatchSuggestionLedger
 */

class FoundationKnowledgeIntegrationBridge(
    private val context: Context,
    private val enableFoundationKnowledge: Boolean = false
) {

    private var foundationLayer: FoundationKnowledgeLayer? = null
    private var axisRankingEngine: AxisRankingEngine? = null
    private var conflictResolver: FoundationConflictResolver? = null
    private var accuracyLedger: FoundationKnowledgeAccuracyLedger? = null
    private var patchLedger: FoundationPatchSuggestionLedger? = null

    init {
        if (enableFoundationKnowledge) {
            initializeFoundationKnowledge()
        }
    }

    /**
     * Initialize all foundation knowledge components
     * (Called only if enabled)
     */
    private fun initializeFoundationKnowledge() {
        try {
            foundationLayer = FoundationKnowledgeLayer(context)
            axisRankingEngine = AxisRankingEngine()
            conflictResolver = FoundationConflictResolver()
            accuracyLedger = FoundationKnowledgeAccuracyLedger(context)
            patchLedger = FoundationPatchSuggestionLedger(context)
        } catch (e: Exception) {
            // Initialization failed - foundation knowledge disabled
            // This does NOT break v1.4.5 operations
            clearFoundationResources()
        }
    }

    /**
     * MAIN ENTRY POINT: Analyze query with foundation knowledge
     * 
     * This is called BEFORE QueryFeedbackPlanner in ResearchAutopilot cycle
     * 
     * Returns analysis that guides search WITHOUT blocking it
     */
    fun analyzeWithFoundation(
        queryText: String,
        extractedMetadata: List<String>,
        datasetType: String = "unknown"
    ): FoundationAnalysisResult? {

        // If foundation not enabled, return null (v1.4.5 proceeds normally)
        if (!enableFoundationKnowledge || foundationLayer == null) {
            return null
        }

        return try {
            // 1. Analyze with foundation
            val result = foundationLayer!!.analyze(queryText, extractedMetadata, datasetType)

            // 2. Rank axes
            val rankedAxes = axisRankingEngine!!.computeFinalRanking(result.rankedAxes)

            // 3. Resolve conflicts
            val conflictReolution = conflictResolver!!.resolve(
                axis = if (result.primaryAxis != null) {
                    // Get axis definition from result
                    FoundationAxis(
                        id = result.primaryAxis!!,
                        coreMeaning = "",
                        requiredEvidence = result.requiredEvidence,
                        criticalEvidence = result.requiredEvidence.take(2),
                        forbiddenConflations = result.forbiddenConflations,
                        queryHints = emptyList(),
                        causalWarnings = result.causalWarnings,
                        datasetType = datasetType
                    )
                } else {
                    // Create minimal axis if none found
                    FoundationAxis(
                        id = "unknown",
                        coreMeaning = "Unknown axis",
                        requiredEvidence = emptyList(),
                        criticalEvidence = emptyList(),
                        forbiddenConflations = emptyList(),
                        queryHints = emptyList(),
                        causalWarnings = emptyList(),
                        datasetType = datasetType
                    )
                },
                rankedAxis = if (rankedAxes.isNotEmpty()) rankedAxes[0] else {
                    RankedAxis(
                        axisId = "unknown",
                        matchScore = 0f,
                        specificityScore = 0f,
                        evidenceCompletenessScore = 0f,
                        priorSuccessScore = 0f,
                        riskPenalty = 0f,
                        finalScore = 0f,
                        reason = "No matching axis",
                        criticalEvidenceMissing = emptyList(),
                        presentEvidence = emptyList()
                    )
                },
                presentEvidence = result.presentEvidence,
                compensatingEvidence = result.compensatingEvidence,
                detectedConflations = result.forbiddenConflations
            )

            FoundationAnalysisResult(
                primaryAxis = result.primaryAxis,
                recommendedAction = conflictReolution.action,
                claimLimit = conflictReolution.suggestedClaim.maxClaim,
                actionExplanation = conflictReolution.actionExplanation,
                confidenceLevel = result.confidenceLevel,
                fullExplanation = buildDetailedExplanation(
                    result = result,
                    rankedAxes = rankedAxes,
                    conflict = conflictReolution
                )
            )

        } catch (e: Exception) {
            // Log error but don't crash
            e.printStackTrace()
            null
        }
    }

    /**
     * Record success or failure of a prediction
     * (Called AFTER research outcome is known)
     */
    fun recordOutcome(
        axisId: String,
        wasSuccessful: Boolean,
        failureReason: String = "",
        reportId: String = ""
    ) {
        if (!enableFoundationKnowledge || accuracyLedger == null) return

        try {
            if (wasSuccessful) {
                accuracyLedger!!.recordCorrectPrediction(axisId)
            } else {
                accuracyLedger!!.recordIncorrectPrediction(axisId, failureReason)

                // If repeated failure, suggest patch
                val failureCount = accuracyLedger!!.getAxisReport(axisId).split("\n")
                    .filter { it.contains("Incorrect") }
                    .size

                if (failureCount >= 2) {
                    patchLedger?.suggestPatch(
                        axisId = axisId,
                        conflictDescription = "Repeated incorrect predictions: $failureReason",
                        suggestedChange = "Review axis definition for $axisId",
                        supportingReports = listOf(reportId)
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Get diagnostic report
     */
    fun getDiagnosticReport(): String {
        if (!enableFoundationKnowledge) {
            return "Foundation Knowledge System: DISABLED"
        }

        val sb = StringBuilder()

        sb.append("=== FOUNDATION KNOWLEDGE DIAGNOSTIC ===\n\n")

        // Accuracy report
        if (accuracyLedger != null) {
            val ranking = accuracyLedger!!.getAccuracyRanking()
            sb.append("Axis Performance:\n")
            ranking.take(5).forEach { rank ->
                sb.append("- ${rank.axisId}: ${String.format("%.1f%%", rank.successRate * 100)} " +
                    "(${rank.confidenceLevel})\n")
            }
            sb.append("\n")
        }

        // Patch summary
        if (patchLedger != null) {
            sb.append(patchLedger!!.getPatchSummary())
        }

        return sb.toString()
    }

    /**
     * Check if foundation knowledge is enabled and healthy
     */
    fun isHealthy(): Boolean {
        return enableFoundationKnowledge &&
            foundationLayer != null &&
            axisRankingEngine != null &&
            conflictResolver != null
    }

    /**
     * Clear resources (for cleanup)
     */
    fun clearFoundationResources() {
        foundationLayer = null
        axisRankingEngine = null
        conflictResolver = null
        accuracyLedger?.saveToStorage()
        accuracyLedger = null
        patchLedger?.saveToStorage()
        patchLedger = null
    }

    /**
     * Build detailed explanation
     */
    private fun buildDetailedExplanation(
        result: FoundationKnowledgeResult,
        rankedAxes: List<RankedAxis>,
        conflict: ConflictResolution
    ): String {
        val sb = StringBuilder()

        sb.append("=== FOUNDATION KNOWLEDGE ANALYSIS ===\n\n")

        sb.append("Ranked Axes:\n")
        rankedAxes.take(3).forEachIndexed { index, axis ->
            sb.append("${index + 1}. ${axis.axisId} (${String.format("%.2f", axis.finalScore)})\n")
        }

        sb.append("\nConflict Resolution:\n")
        sb.append(conflict.actionExplanation)

        sb.append("\nRecommended Action: ${conflict.action}\n")
        sb.append("Claim Limit: ${conflict.suggestedClaim.maxClaim}\n")

        sb.append("\nNext Steps:\n")
        conflict.nextSteps.forEach { step ->
            sb.append("- $step\n")
        }

        return sb.toString()
    }

    /**
     * SAFE DISABLE: Foundation knowledge can be toggled off at runtime
     */
    fun setEnabled(enabled: Boolean) {
        if (enabled && !enableFoundationKnowledge) {
            // Would need to reinitialize - not typically done runtime
            return
        }

        if (!enabled) {
            clearFoundationResources()
        }
    }
}

// ============ DATA CLASSES ============

data class FoundationAnalysisResult(
    val primaryAxis: String?,
    val recommendedAction: FoundationAction,
    val claimLimit: String,
    val actionExplanation: String,
    val confidenceLevel: ConfidenceLevel,
    val fullExplanation: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Usage in ResearchAutopilot:
 * 
 * class ResearchAutopilot(context: Context) {
 *     private val foundationBridge = 
 *         FoundationKnowledgeIntegrationBridge(context, enableFoundationKnowledge = true)
 * 
 *     fun runCycle(userQuery: String) {
 *         // Step 1: Analyze with foundation (NEW v1.4.6)
 *         val foundationResult = foundationBridge.analyzeWithFoundation(
 *             queryText = userQuery,
 *             extractedMetadata = extractMetadataFromDatasets(),
 *             datasetType = "human"
 *         )
 * 
 *         // Step 2: If foundation says "OFF_ROUTE" or "BLOCK", user still sees warning but can continue
 *         if (foundationResult?.recommendedAction == FoundationAction.BLOCK_HYPOTHESIS_UPGRADE) {
 *             report.addFoundationWarning(foundationResult.actionExplanation)
 *         }
 * 
 *         // Step 3: Continue with normal v1.4.5 cycle (UNCHANGED)
 *         val candidates = collectCandidates(userQuery)
 *         val triaged = triageDatasets(candidates)
 *         val parsed = parseDatasets(triaged)
 *         val scored = scoreEvidence(parsed)
 *         val hypotheses = rankHypotheses(scored)
 *         val report = buildReport(hypotheses)
 * 
 *         // Step 4: Record outcome (after human review)
 *         // foundationBridge.recordOutcome(axisId, wasSuccessful, reason)
 * 
 *         return report
 *     }
 * }
 */
