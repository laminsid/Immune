package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v1.9.0: probe outcome learning ledger. Token: probe_outcome_learning_ledger.
 *
 * v1.8.9 made the next discovery probe executable. This layer closes that
 * probe loop by comparing the previous probe contract against the current
 * cycle's actual evidence. It turns pass/fail/kill criteria into route and
 * belief adjustments. It guides routing only; it never proves biology,
 * diagnosis, treatment, causality, mechanism, or immune outcome.
 */
data class ProbeOutcomeClosureSignal(
    val evidenceKey: String,
    val status: String,
    val reason: String,
    val impact: String
)

data class ScientificDiscoveryProbeOutcomeLedgerReport(
    val active: Boolean,
    val version: String,
    val ledgerState: String,
    val previousProbeId: String,
    val previousPlannerState: String,
    val previousProbeQuery: String,
    val evidenceClosureScore: Int,
    val closedEvidenceKeys: List<String>,
    val unresolvedEvidenceKeys: List<String>,
    val passSignals: List<ProbeOutcomeClosureSignal>,
    val failSignals: List<ProbeOutcomeClosureSignal>,
    val killSignals: List<ProbeOutcomeClosureSignal>,
    val replayPenaltyKeys: List<String>,
    val routeDisposition: String,
    val beliefDisposition: String,
    val nextProbeDecision: String,
    val forcedDirectiveTerms: List<String>,
    val forcedEvidenceKeys: List<String>,
    val reportLine: String,
    val claimLimit: String = "probe_outcome_learning_guides_routing_not_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryProbeOutcomeLedgerReport(
            active = false,
            version = "v1.9.0",
            ledgerState = "NO_PREVIOUS_PROBE_TO_VERIFY",
            previousProbeId = "none",
            previousPlannerState = "none",
            previousProbeQuery = "No previous executable probe plan was available.",
            evidenceClosureScore = 0,
            closedEvidenceKeys = emptyList(),
            unresolvedEvidenceKeys = emptyList(),
            passSignals = emptyList(),
            failSignals = emptyList(),
            killSignals = emptyList(),
            replayPenaltyKeys = emptyList(),
            routeDisposition = "No route adjustment.",
            beliefDisposition = "No belief adjustment.",
            nextProbeDecision = "Run an executable probe plan first, then verify it in the next cycle.",
            forcedDirectiveTerms = emptyList(),
            forcedEvidenceKeys = emptyList(),
            reportLine = "Probe outcome ledger did not run because no previous probe contract was found.",
            claimLimit = "probe_outcome_learning_guides_routing_not_proof"
        )
    }
}

object ScientificDiscoveryProbeOutcomeLedgerEngineV190 {
    fun evaluate(
        recentReportJsonLines: List<String>,
        currentProbePlan: ScientificDiscoveryProbePlanReport,
        datasetForaging: DatasetForagingReport,
        evidenceObjects: List<EvidenceObject>,
        findings: List<ResearchFinding>,
        learningOs: LearningOsReport,
        discoveryReadiness: DiscoveryReadinessReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport,
        executionPolicy: ScientificDiscoveryExecutionPolicyReport,
        gapMiner: ScientificDiscoveryGapMinerReport
    ): ScientificDiscoveryProbeOutcomeLedgerReport {
        val previousPlan = findPreviousProbePlan(recentReportJsonLines)
            ?: return ScientificDiscoveryProbeOutcomeLedgerReport.empty()

        val previousProbeId = previousPlan.optString("selectedProbeId", "previous_probe")
        val previousPlannerState = previousPlan.optString("plannerState", "UNKNOWN")
        val previousProbeQuery = previousPlan.optString("selectedProbeQuery", "")
        val expectedEvidence = normalizeEvidence(
            jsonArrayToList(previousPlan.optJSONArray("evidencePack")) +
                jsonArrayToList(previousPlan.optJSONArray("forcedEvidenceKeys")) +
                jsonArrayToList(previousPlan.optJSONArray("passCriteria")).map { evidenceKeyFromText(it) }
        ).ifEmpty { listOf("minimum_metadata", "outcome_labels", "comparator_control", "time_order") }.take(32)

        val currentEvidence = currentEvidenceKeys(datasetForaging, evidenceObjects, findings, learningOs, discoveryReadiness, outcomeVerifier, executionPolicy)
        val closed = expectedEvidence.filter { key -> currentEvidence.any { evidenceMatches(key, it) } }.distinct()
        val unresolved = expectedEvidence.filterNot { key -> closed.any { evidenceMatches(key, it) } }.distinct()
        val closureScore = if (expectedEvidence.isEmpty()) 0 else ((closed.size * 100.0) / expectedEvidence.size).toInt().coerceIn(0, 100)

        val passSignals = closed.map { key ->
            ProbeOutcomeClosureSignal(key, "CLOSED", "Current cycle produced evidence compatible with previous probe requirement '$key'.", "Reward this probe route cautiously; keep claim gates active.")
        }.take(12)
        val failSignals = unresolved.map { key ->
            ProbeOutcomeClosureSignal(key, "UNRESOLVED", "Previous probe required '$key' but the current cycle did not close it.", "Do not reward this probe; force the missing evidence or cool down the route.")
        }.take(12)
        val previousKillCriteria = jsonArrayToList(previousPlan.optJSONArray("killCriteria")).map { evidenceKeyFromText(it) }
        val previousReplayBlocks = jsonArrayToList(previousPlan.optJSONArray("replayBlockKeys")).map { evidenceKeyFromText(it) }
        val killSignals = (previousKillCriteria + previousReplayBlocks)
            .filter { key -> unresolved.any { evidenceMatches(key, it) } || key.contains("metadata_only") || key.contains("replay") }
            .distinct()
            .take(10)
            .map { key -> ProbeOutcomeClosureSignal(key, "KILL_OR_COOLDOWN_TRIGGER", "Previous probe's kill/replay condition remains active: '$key'.", "Block replay and keep the hypothesis dormant until new parent evidence appears.") }

        val replayPenalty = normalizeEvidence(unresolved + previousReplayBlocks + outcomeVerifier.blockedReplayKeys + executionPolicy.queryReplayBlocks).take(20)
        val ledgerState = when {
            closureScore >= 70 && killSignals.isEmpty() -> "PROBE_REWARDED_WITH_GUARDS"
            closureScore in 35..69 -> "PROBE_PARTIAL_MIXED_KEEP_GATED"
            killSignals.isNotEmpty() -> "PROBE_FAILED_COOLDOWN_OR_KILL"
            else -> "PROBE_UNRESOLVED_FORCE_EVIDENCE"
        }
        val routeDisposition = when (ledgerState) {
            "PROBE_REWARDED_WITH_GUARDS" -> "Keep route alive for cautious inspection; do not upgrade without repeatability and controls."
            "PROBE_PARTIAL_MIXED_KEEP_GATED" -> "Keep route alive but force unresolved evidence before another broad search."
            "PROBE_FAILED_COOLDOWN_OR_KILL" -> "Cool down or bury the route; block replay until new parent evidence closes the missing keys."
            else -> "Do not repeat the same probe; force unresolved evidence keys first."
        }
        val beliefDisposition = when {
            closureScore >= 70 -> "Strengthen only the narrow evidence-backed belief; do not generalize across tissues or diseases."
            closureScore >= 35 -> "Keep belief mutable; mark unresolved keys as falsification pressure."
            else -> "Weaken or archive the belief unless the next cycle closes the forced evidence pack."
        }
        val nextDecision = when (ledgerState) {
            "PROBE_REWARDED_WITH_GUARDS" -> "Run a narrow replication/control probe, not a broad expansion."
            "PROBE_PARTIAL_MIXED_KEEP_GATED" -> "Run one closure probe for unresolved evidence keys."
            "PROBE_FAILED_COOLDOWN_OR_KILL" -> "Kill/cool down this probe route and switch to parent-evidence or contradiction mining."
            else -> "Run one evidence-closure probe; if unresolved again, archive the route."
        }
        val directiveTerms = normalizeTerms(
            compactTokens(previousProbeQuery, 22) + unresolved.flatMap { evidenceToTerms(it) } + closed.flatMap { evidenceToTerms(it) } + compactTokens(nextDecision, 18) + gapMiner.forcedDirectiveTerms.take(12)
        ).take(64)
        val forcedEvidence = normalizeEvidence(unresolved + replayPenalty + gapMiner.forcedEvidenceKeys).take(28)
        val line = "v1.9.0 probe outcome ledger: $ledgerState; previous=$previousProbeId; closed=${closed.size}/${expectedEvidence.size}; unresolved=${unresolved.take(5).joinToString("/").ifBlank { "none" }}; replayPenalty=${replayPenalty.take(3).joinToString("/").ifBlank { "none" }}."
        return ScientificDiscoveryProbeOutcomeLedgerReport(
            active = true,
            version = "v1.9.0-probe-outcome-learning-ledger",
            ledgerState = ledgerState,
            previousProbeId = previousProbeId,
            previousPlannerState = previousPlannerState,
            previousProbeQuery = previousProbeQuery.take(420),
            evidenceClosureScore = closureScore,
            closedEvidenceKeys = closed.take(24),
            unresolvedEvidenceKeys = unresolved.take(24),
            passSignals = passSignals,
            failSignals = failSignals,
            killSignals = killSignals,
            replayPenaltyKeys = replayPenalty,
            routeDisposition = routeDisposition.take(280),
            beliefDisposition = beliefDisposition.take(280),
            nextProbeDecision = nextDecision.take(280),
            forcedDirectiveTerms = directiveTerms,
            forcedEvidenceKeys = forcedEvidence,
            reportLine = line.take(560),
            claimLimit = "probe_outcome_learning_guides_routing_not_proof"
        )
    }

    private fun findPreviousProbePlan(lines: List<String>): JSONObject? {
        for (line in lines) {
            val root = runCatching { JSONObject(line) }.getOrNull() ?: continue
            val plan = root.optJSONObject("scientificDiscoveryProbePlanReport") ?: continue
            if (plan.optBoolean("active", false)) return plan
        }
        return null
    }

    private fun currentEvidenceKeys(datasetForaging: DatasetForagingReport, evidenceObjects: List<EvidenceObject>, findings: List<ResearchFinding>, learningOs: LearningOsReport, discoveryReadiness: DiscoveryReadinessReport, outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport, executionPolicy: ScientificDiscoveryExecutionPolicyReport): List<String> {
        val keys = mutableListOf<String>()
        if (datasetForaging.parsedMetadata.isNotEmpty()) keys += "minimum_metadata"
        if (datasetForaging.parsedMetadata.any { it.outcomeLabels.isNotEmpty() }) keys += "outcome_labels"
        if (datasetForaging.parsedMetadata.any { it.controlLabels.isNotEmpty() || it.contrastiveSlots.isNotEmpty() }) keys += "comparator_control"
        if (datasetForaging.parsedMetadata.any { it.timeCourseLabels.isNotEmpty() }) keys += "time_order"
        if (datasetForaging.parsedMetadata.any { it.organism.lowercase(Locale.US).contains("human") }) keys += "human_or_patient_data"
        if (datasetForaging.parsedMetadata.any { it.metadataQualityScore >= 70 }) keys += "metadata_quality"
        if (datasetForaging.scoreSeparation.datasetUsabilityScore >= 65) keys += "dataset_usability"
        if (datasetForaging.scoreSeparation.routeFitScore >= 75) keys += "route_fit"
        if (datasetForaging.contrastiveReport.gateStatus.contains("PASS", true)) keys += "contrastive_gate"
        if (datasetForaging.cumulativeEvidence.score >= 50) keys += "cumulative_evidence"
        if (evidenceObjects.any { it.hasNegativeControl }) keys += "negative_control"
        if (evidenceObjects.any { it.hasLongitudinalSignal }) keys += "time_order"
        if (evidenceObjects.any { it.hasMechanisticSignal }) keys += "mechanistic_signal"
        if (evidenceObjects.any { it.qualityScore >= 60 }) keys += "evidence_object_quality"
        if (evidenceObjects.any { it.causalClaimSafe }) keys += "causal_claim_safe"
        if (findings.any { it.evidence.humanEvidence }) keys += "human_or_patient_data"
        if (findings.any { it.causality.temporalityScore >= 60 }) keys += "time_order"
        if (findings.any { it.negativeControl.status.contains("control", true) }) keys += "negative_control"
        keys += outcomeVerifier.resolvedEvidenceKeys
        keys += executionPolicy.forcedEvidenceKeys.filter { key -> key.contains("closed", true) }
        if (learningOs.hypothesisUpdateGateStatus.contains("ALLOWED", true)) keys += "hypothesis_update_gate"
        if (discoveryReadiness.score >= 65) keys += "discovery_readiness"
        return normalizeEvidence(keys)
    }

    private fun jsonArrayToList(arr: JSONArray?): List<String> = if (arr == null) emptyList() else (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }
    private fun evidenceMatches(expected: String, actual: String): Boolean {
        val e = evidenceKeyFromText(expected); val a = evidenceKeyFromText(actual)
        return e == a || e.contains(a) || a.contains(e) || evidenceToTerms(e).any { it in evidenceToTerms(a) }
    }
    private fun evidenceKeyFromText(text: String): String {
        val t = text.lowercase(Locale.US)
        return when {
            t.contains("outcome") || t.contains("recovery") || t.contains("severity") || t.contains("endpoint") -> "outcome_labels"
            t.contains("time") || t.contains("longitudinal") || t.contains("serial") || t.contains("follow") || t.contains("temporal") -> "time_order"
            t.contains("control") || t.contains("comparator") || t.contains("placebo") || t.contains("negative") -> "comparator_control"
            t.contains("metadata") || t.contains("accession") || t.contains("license") || t.contains("sample") -> "minimum_metadata"
            t.contains("human") || t.contains("patient") || t.contains("clinical") -> "human_or_patient_data"
            t.contains("mechanism") || t.contains("mediator") || t.contains("pathway") -> "mechanistic_signal"
            t.contains("tissue") || t.contains("cell") || t.contains("single-cell") -> "cell_tissue_context"
            t.contains("replication") || t.contains("repeat") || t.contains("external") -> "replication_external_validation"
            t.contains("false") || t.contains("artifact") || t.contains("confound") || t.contains("batch") -> "false_friend_or_artifact_guard"
            else -> t.replace(Regex("[^a-z0-9_]+"), "_").trim('_').take(72).ifBlank { "unspecified_evidence" }
        }
    }
    private fun normalizeEvidence(values: List<String>): List<String> = values.map { evidenceKeyFromText(it) }.filter { it.length >= 3 }.distinctBy { it.lowercase(Locale.US) }
    private fun normalizeTerms(values: List<String>): List<String> = values.map { it.lowercase(Locale.US).replace(Regex("[^a-z0-9+_.-]+"), " ").trim() }.filter { it.length >= 3 && it !in stopWords }.distinct()
    private fun compactTokens(text: String, limit: Int): List<String> = text.lowercase(Locale.US).replace(Regex("[^a-z0-9+_.-]+"), " ").split(Regex("\\s+")).map { it.trim() }.filter { it.length >= 3 && it !in stopWords }.distinct().take(limit)
    private fun evidenceToTerms(key: String): List<String> = when (evidenceKeyFromText(key)) {
        "outcome_labels" -> listOf("outcome", "recovery", "severity", "endpoint", "clinical phenotype")
        "time_order" -> listOf("longitudinal", "serial", "time-course", "follow-up", "before after")
        "comparator_control" -> listOf("control", "comparator", "placebo", "negative control")
        "minimum_metadata" -> listOf("metadata", "accession", "sample size", "license", "labels")
        "human_or_patient_data" -> listOf("human", "patient", "clinical", "cohort")
        "mechanistic_signal" -> listOf("mechanism", "mediator", "pathway", "cell state")
        "cell_tissue_context" -> listOf("cell type", "tissue", "single-cell", "epithelial")
        "replication_external_validation" -> listOf("replication", "external validation", "independent cohort")
        "false_friend_or_artifact_guard" -> listOf("artifact", "batch effect", "confounder", "false positive")
        else -> listOf(key.replace('_', ' '))
    }
    private val stopWords = setOf("the", "and", "with", "without", "this", "that", "from", "into", "before", "after", "because", "probe", "route", "evidence", "required", "previous", "current", "cycle", "query", "data")
}
