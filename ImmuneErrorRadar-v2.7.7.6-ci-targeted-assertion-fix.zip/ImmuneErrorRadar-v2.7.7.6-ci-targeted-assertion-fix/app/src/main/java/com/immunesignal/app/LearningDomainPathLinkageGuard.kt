package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.29: Learning + domain expertise path linkage guard.
 *
 * v1.10.27/v1.10.28 connected the dataset-foraging pass paths. This guard
 * connects the adjacent learning paths as well: LearningRuleEngine, no-candidate
 * learning, query feedback, failure memory, domain expertise continuity, mature
 * domain probes, and final dataset path coverage. It is an integrity layer only;
 * it never upgrades a hypothesis or proves biology.
 */
data class LearningDomainPathLinkageReport(
    val active: Boolean,
    val state: String,
    val learningRuleMatchCount: Int,
    val domainTrackCount: Int,
    val matureDomainCount: Int,
    val protectedExpertiseCount: Int,
    val noCandidateLearningCount: Int,
    val queryFeedbackLinked: Boolean,
    val learningRulesLinkedToQueries: Boolean,
    val domainVocabularyLinkedToQueries: Boolean,
    val matureProbeLinkedToDomainExpertise: Boolean,
    val pathCoverageState: String,
    val warnings: List<String>,
    val handoffSummary: String,
    val nextAction: String,
    val claimLimit: String = LearningDomainPathLinkageGuard.CLAIM_LIMIT
) {
    companion object {
        fun empty() = LearningDomainPathLinkageReport(
            active = false,
            state = "NOT_EVALUATED",
            learningRuleMatchCount = 0,
            domainTrackCount = 0,
            matureDomainCount = 0,
            protectedExpertiseCount = 0,
            noCandidateLearningCount = 0,
            queryFeedbackLinked = false,
            learningRulesLinkedToQueries = false,
            domainVocabularyLinkedToQueries = false,
            matureProbeLinkedToDomainExpertise = false,
            pathCoverageState = "NOT_EVALUATED",
            warnings = emptyList(),
            handoffSummary = "Learning/domain path linkage was not evaluated.",
            nextAction = "Run dataset foraging before evaluating learning/domain linkage."
        )
    }
}

object LearningDomainPathLinkageGuard {
    const val CLAIM_LIMIT: String = "learning_domain_path_linkage_not_biological_proof"

    fun evaluate(
        executedQueries: List<ResearchQuery>,
        attempts: List<DatasetSourceAttempt>,
        learningRuleMatches: List<LearningRuleMatch>,
        domainReport: DomainExpertiseMemoryPolicy.DomainExpertiseReport,
        matureProbeReport: MatureDomainEvidenceProbePolicy.Report,
        pathLinkageReport: DatasetForagingPathLinkageReport,
        noCandidateRecords: List<NoCandidateLearningRecord>,
        queryFeedbackPlan: QueryFeedbackPlan,
        failurePatternReport: FailurePatternReport
    ): LearningDomainPathLinkageReport {
        val queryCorpus = (executedQueries.joinToString(" ") { it.query + " " + it.reason + " " + it.label } + " " +
            attempts.joinToString(" ") { it.query + " " + it.reason + " " + it.sourceFamily }).lowercase(Locale.US)
        val domainVocabulary = domainReport.cards
            .flatMap { it.workingVocabulary }
            .map { it.trim().lowercase(Locale.US) }
            .filter { it.length in 2..48 }
            .distinct()
        val domainVocabularyLinked = domainVocabulary.any { term -> queryCorpus.contains(term) }
        val learningSignals = learningRuleMatches
            .flatMap { it.matchedSignals + it.missingSignals.take(2) }
            .flatMap { signal ->
                val phrase = signal.replace("_", " ").lowercase(Locale.US)
                listOf(phrase) + phrase.split(" ").filter { token -> token.length >= 5 }
            }
            .filter { it.isNotBlank() }
            .distinct()
        val learningLinked = learningRuleMatches.isEmpty() || learningSignals.any { signal -> queryCorpus.contains(signal) }
        val matureLinked = if (domainReport.matureDomainCount > 0) {
            matureProbeReport.active || domainVocabularyLinked
        } else {
            true
        }
        val queryFeedbackLinked = noCandidateRecords.isEmpty() || queryFeedbackPlan.active || failurePatternReport.active
        val warnings = mutableListOf<String>()
        if (domainReport.cards.isNotEmpty() && !domainVocabularyLinked) {
            warnings += "Domain expertise exists but no domain vocabulary was visible in executed dataset-foraging queries."
        }
        if (domainReport.matureDomainCount > 0 && !matureLinked) {
            warnings += "Mature domain expertise exists but no mature-domain probe or domain query reuse is linked."
        }
        if (learningRuleMatches.isNotEmpty() && !learningLinked) {
            warnings += "Learning rule matches exist but their signals are not reflected in executed query wording."
        }
        if (noCandidateRecords.isNotEmpty() && !queryFeedbackLinked) {
            warnings += "No-candidate learning records exist but query feedback/failure memory is not linked."
        }
        if (pathLinkageReport.active && pathLinkageReport.coverageState != "PASS_COVERAGE_CONNECTED") {
            warnings += "Dataset path coverage is not connected: ${pathLinkageReport.coverageState}."
        }
        if (pathLinkageReport.warnings.isNotEmpty()) {
            warnings += "Dataset path linkage warning remains: ${pathLinkageReport.warnings.first()}"
        }
        val state = when {
            warnings.isNotEmpty() -> "LEARNING_DOMAIN_LINKAGE_WARNINGS"
            domainReport.matureDomainCount > 0 && matureProbeReport.active -> "CONNECTED_LEARNING_DOMAIN_MATURE_PROBE"
            domainReport.cards.isNotEmpty() -> "CONNECTED_LEARNING_DOMAIN_EXPERTISE"
            learningRuleMatches.isNotEmpty() -> "CONNECTED_LEARNING_RULES"
            else -> "CONNECTED_NO_DOMAIN_SIGNAL"
        }
        val next = when {
            warnings.isNotEmpty() -> "Repair learning/domain handoff before trusting the next route: ${warnings.first()}"
            matureProbeReport.active -> matureProbeReport.nextAction
            domainReport.matureDomainCount > 0 -> "Reuse mature domain vocabulary in the next bounded accession/data-availability probe; keep claims locked."
            learningRuleMatches.isNotEmpty() -> LearningRuleEngine.nextAction(learningRuleMatches)
            else -> pathLinkageReport.nextAction.ifBlank { "Continue bounded dataset-foraging with explicit learning handoff." }
        }
        val summary = "learningMatches=${learningRuleMatches.size}; domains=${domainReport.cards.size}; mature=${domainReport.matureDomainCount}; protected=${domainReport.protectedBeliefCount}; noCandidate=${noCandidateRecords.size}; domainQueryLinked=$domainVocabularyLinked; learningQueryLinked=$learningLinked; queryFeedbackLinked=$queryFeedbackLinked; pathCoverage=${pathLinkageReport.coverageState}."
        return LearningDomainPathLinkageReport(
            active = true,
            state = state,
            learningRuleMatchCount = learningRuleMatches.size,
            domainTrackCount = domainReport.cards.size,
            matureDomainCount = domainReport.matureDomainCount,
            protectedExpertiseCount = domainReport.protectedBeliefCount,
            noCandidateLearningCount = noCandidateRecords.size,
            queryFeedbackLinked = queryFeedbackLinked,
            learningRulesLinkedToQueries = learningLinked,
            domainVocabularyLinkedToQueries = domainVocabularyLinked,
            matureProbeLinkedToDomainExpertise = matureLinked,
            pathCoverageState = pathLinkageReport.coverageState,
            warnings = warnings.distinct(),
            handoffSummary = summary,
            nextAction = next,
            claimLimit = CLAIM_LIMIT
        )
    }
}
