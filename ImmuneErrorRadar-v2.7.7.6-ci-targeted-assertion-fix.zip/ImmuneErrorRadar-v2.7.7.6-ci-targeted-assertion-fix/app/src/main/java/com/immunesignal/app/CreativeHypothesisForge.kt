package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.11: Creative Hypothesis Forge.
 *
 * This layer is intentionally placed between repeated acquisition failure and
 * the next bounded search. It may invent research hypotheses, routes, and kill
 * tests, but it never creates evidence, never upgrades a hypothesis, and never
 * authorizes causal or medical language.
 */
data class CreativeHypothesisCard(
    val hypothesisId: String,
    val label: String,
    val trigger: String,
    val rationale: String,
    val whatWouldStrengthen: List<String>,
    val whatWouldKill: List<String>,
    val testQuery: String,
    val routeEffect: String,
    val claimLimit: String = "creative_hypothesis_not_evidence",
    val origin: String = "gap_generated",
    val steeringAxisId: String = "",
    val priority: Int = 50
)

data class CreativeHypothesisForgeReport(
    val active: Boolean,
    val state: String,
    val summary: String,
    val generated: List<CreativeHypothesisCard>,
    val selectedQuery: String,
    val killCriteria: List<String>,
    val nextAction: String,
    val steeringAxesUsed: List<SteeringAxis> = emptyList(),
    val expandedThinking: ExpandedThinkingWindowReport = ExpandedThinkingWindowReport.empty(),
    val claimLimit: String = "creative_hypothesis_not_evidence"
) {
    companion object {
        fun empty() = CreativeHypothesisForgeReport(
            active = false,
            state = "NOT_TRIGGERED",
            summary = "Creative hypothesis forge did not run.",
            generated = emptyList(),
            selectedQuery = "",
            killCriteria = emptyList(),
            nextAction = "Continue normal evidence acquisition.",
            steeringAxesUsed = emptyList(),
            expandedThinking = ExpandedThinkingWindowReport.empty(),
            claimLimit = "creative_hypothesis_not_evidence"
        )
    }
}

object CreativeHypothesisForge {
    private const val CLAIM_LIMIT = "creative_hypothesis_not_evidence"

    fun build(
        sourceFamiliesAttempted: List<String>,
        noCandidateLearningRecords: List<NoCandidateLearningRecord>,
        shards: List<TestableHypothesisShard>,
        candidates: List<DatasetAccessionCandidate>,
        terminalArchiveRequested: Boolean = false,
        steering: ResearchSteeringProfile? = null
    ): CreativeHypothesisForgeReport {
        val attempted = sourceFamiliesAttempted.distinct()
        val noCandidateCount = noCandidateLearningRecords.map { it.sourceFamily }.distinct().size
        val shouldRun = candidates.isEmpty() && (
            terminalArchiveRequested ||
                attempted.size >= 2 ||
                noCandidateCount >= 2 ||
                attempted.any { it == "PUBMED_CONTRADICTION" || it == "PUBMED_CONTROL" || it == "PUBMED_ACCESSION_MINING" }
            )
        if (!shouldRun) return CreativeHypothesisForgeReport.empty()

        val shardText = shards.joinToString(" ") { (it.label + " " + it.evidenceQuestion + " " + it.querySeeds.joinToString(" ")).lowercase(Locale.US) }
        val steeringAxes = SteeringAxisResolver.resolve(steering, shards, noCandidateLearningRecords)
        val expandedThinking = ExpandedThinkingWindowPolicy.evaluate(
            attemptedSourceFamilies = attempted,
            noCandidateLearningRecords = noCandidateLearningRecords,
            steeringAxes = steeringAxes,
            terminalArchiveRequested = terminalArchiveRequested
        )
        val cards = mutableListOf<CreativeHypothesisCard>()
        cards += steeringAxes.map { axisToCreativeCard(it, attempted) }
        cards += outcomePatternFirst(attempted)
        if (shardText.contains("viral") || shardText.contains("interferon") || shardText.contains("infection") || expandedThinking.active) {
            cards += timingWindowHypothesis(attempted)
        }
        if (shardText.contains("allerg") || shardText.contains("autoimmune") || shardText.contains("inflammation") || cards.size < 3 || expandedThinking.active) {
            cards += comparatorFirstHypothesis(attempted)
        }
        val distinct = cards
            .distinctBy { it.hypothesisId }
            .sortedWith(compareByDescending<CreativeHypothesisCard> { it.priority }.thenBy { it.hypothesisId })
            .take(expandedThinking.maxHypotheses.coerceAtLeast(3))
        val selected = distinct.firstOrNull()
        val kill = listOf(
            "If ${attempted.joinToString("+").ifBlank { "the next two bounded source families" }} plus PUBMED_CONTROL yields no accession/candidate/control-time signal, archive this route.",
            "If only marker/title evidence appears without outcome_labels + comparator_control + time_order, keep as context prior and do not upgrade.",
            "If a better route explains the same signals with fewer assumptions, retire this creative hypothesis."
        )
        return CreativeHypothesisForgeReport(
            active = true,
            state = if (terminalArchiveRequested) "FORGE_AFTER_SOURCE_EXHAUSTION" else "FORGE_AFTER_REPEATED_NO_CANDIDATE",
            summary = "Creative hypothesis generated after repeated no-candidate search; invention is limited to routing and test design, not evidence or claims.",
            generated = distinct,
            selectedQuery = selected?.testQuery.orEmpty(),
            killCriteria = kill,
            nextAction = selected?.let { "Test creative route: ${it.label}. Query: ${it.testQuery}" } ?: "Archive or reframe route before another broad search.",
            steeringAxesUsed = steeringAxes,
            expandedThinking = expandedThinking,
            claimLimit = CLAIM_LIMIT
        )
    }

    private fun axisToCreativeCard(axis: SteeringAxis, attempted: List<String>) = CreativeHypothesisCard(
        hypothesisId = "creative:steering:${axis.id}",
        label = axis.label,
        trigger = "Steering-aware creative forge activated after repeated no-candidate search: ${attempted.joinToString(", ").ifBlank { "none" }}.",
        rationale = axis.rationale,
        whatWouldStrengthen = axis.strengthenIf,
        whatWouldKill = axis.killIf,
        testQuery = axis.queryTerms.joinToString(" "),
        routeEffect = "Use user/science steering axis ${axis.id} as a bounded hypothesis-test route; not evidence.",
        claimLimit = "creative_steering_hypothesis_not_evidence",
        origin = "steering_axis",
        steeringAxisId = axis.id,
        priority = axis.priority
    )

    private fun outcomePatternFirst(attempted: List<String>) = CreativeHypothesisCard(
        hypothesisId = "creative:outcome_pattern_first",
        label = "Outcome-pattern-first route",
        trigger = "Repeated source rotation produced no dataset candidate: ${attempted.joinToString(", ").ifBlank { "none" }}.",
        rationale = "The failed route may be too disease/source-family-first. Search should pivot to response/nonresponse, recovery, severity, and longitudinal outcome structure before disease labels.",
        whatWouldStrengthen = listOf("human cohort", "responder/nonresponder", "severity or recovery endpoint", "longitudinal or follow-up labels", "control/comparator group"),
        whatWouldKill = listOf("no accession after PubMed contradiction/control", "only generic immune marker evidence", "no outcome or time-order fields"),
        testQuery = "human immune transcriptome cohort responder nonresponder severity recovery longitudinal follow-up control comparator dataset accession",
        routeEffect = "Generate outcome-first accession hunt before another disease-first query.",
        claimLimit = CLAIM_LIMIT,
        priority = 70
    )

    private fun timingWindowHypothesis(attempted: List<String>) = CreativeHypothesisCard(
        hypothesisId = "creative:timing_window_failure",
        label = "Timing-window failure route",
        trigger = "Outcome/time/control gaps remained open after source attempts: ${attempted.joinToString(", ")}.",
        rationale = "The real discriminator may be timing of immune activation vs recovery, not a static pathway name. The next hunt should prioritize serial sampling and early/late timepoint metadata.",
        whatWouldStrengthen = listOf("serial sampling", "baseline/pre-trigger sample", "acute vs recovery timepoint", "viral load or symptom severity endpoint"),
        whatWouldKill = listOf("cross-sectional only records", "no baseline/follow-up labels", "no same-subject or matched-group structure"),
        testQuery = "immune response time-course serial baseline recovery severity viral infection human RNA-seq cohort comparator accession",
        routeEffect = "Prioritize time-order evidence and kill static marker-only routes.",
        claimLimit = CLAIM_LIMIT,
        priority = 68
    )

    private fun comparatorFirstHypothesis(attempted: List<String>) = CreativeHypothesisCard(
        hypothesisId = "creative:comparator_first_falsification",
        label = "Comparator-first falsification route",
        trigger = "The system still lacks control/comparator evidence after ${attempted.size} attempted source family/families.",
        rationale = "A useful discovery route may appear only when searching for failed association, heterogeneity, placebo/healthy controls, or nonresponse instead of positive mechanism terms.",
        whatWouldStrengthen = listOf("healthy control", "placebo or comparator", "nonresponse/null association", "heterogeneity", "case/control labels"),
        whatWouldKill = listOf("no comparator/control labels", "confirmation-only result set", "same broad route repeats without new parent evidence"),
        testQuery = "immune transcriptomic nonresponse no association heterogeneity healthy control comparator placebo severity recovery cohort accession",
        routeEffect = "Force contradiction/control search before any new mechanism wording.",
        claimLimit = CLAIM_LIMIT,
        priority = 66
    )
}
