package com.immunesignal.app

/**
 * Standalone Semantic Mechanism Prior module.
 *
 * This deliberately avoids any "semantic matrix imputation" language. It creates a pathway prior
 * map only: useful for plausibility, query targeting, and lab-design suggestions, never for DGE,
 * fold-change, p-value, or expression-matrix claims.
 */
object GTIMSemanticMechanismPriorEngineV256 {
    const val STATUS: String = "SEMANTIC_PRIOR_NOT_MATRIX"
    const val PRIOR_TYPE: String = "Pathway Prior Map"

    fun build(intent: GTIMResearchIntentObjectV255, routes: List<GTIMCandidateRouteV256>): GTIMSemanticMechanismPriorV256 {
        val nodes = (intent.pathway + intent.cellTissue + routes.flatMap { it.cascade }).distinct().take(16)
        return GTIMSemanticMechanismPriorV256(
            active = nodes.isNotEmpty(),
            status = STATUS,
            priorType = PRIOR_TYPE,
            suggestedGenesOrPathways = nodes,
            usesAllowed = listOf("route plausibility", "dataset query guidance", "gene/pathway shortlist", "lab hypothesis design"),
            forbiddenUses = listOf("fold-change", "p-value", "DGE result", "confirmed expression matrix", "clinical claim")
        )
    }
}
