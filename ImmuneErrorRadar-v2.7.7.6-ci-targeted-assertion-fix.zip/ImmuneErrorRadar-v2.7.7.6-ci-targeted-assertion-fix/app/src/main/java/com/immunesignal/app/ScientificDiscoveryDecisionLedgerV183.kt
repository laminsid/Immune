package com.immunesignal.app

import java.util.Locale

/**
 * v1.8.3: decision-memory layer for deep discovery.
 *
 * v1.8.2 computes scientific weights. This layer turns those weights into a
 * falsifiable next-cycle contract: what the system selected, what it blocked,
 * what evidence would count as success, and what result should change or retire
 * the move. It guides routing only; it never proves biology.
 */
data class ScientificDiscoveryDecisionReport(
    val active: Boolean,
    val version: String,
    val selectedMove: String,
    val selectedReason: String,
    val blockedMove: String,
    val blockedReason: String,
    val successCriteria: List<String>,
    val failureCriteria: List<String>,
    val nextCycleContract: String,
    val decisionTags: List<String>,
    val changeIfFails: String,
    val carryForwardPolicy: String,
    val queryImpactTerms: List<String>,
    val evidenceImpactKeys: List<String>,
    val summary: String,
    val claimLimit: String = "scientific_decision_memory_guides_routing_not_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryDecisionReport(
            active = false,
            version = "v1.8.3",
            selectedMove = "none",
            selectedReason = "No scientific discovery decision was produced.",
            blockedMove = "none",
            blockedReason = "No blocker evaluated.",
            successCriteria = emptyList(),
            failureCriteria = emptyList(),
            nextCycleContract = "Run a research cycle first.",
            decisionTags = emptyList(),
            changeIfFails = "none",
            carryForwardPolicy = "No decision memory to carry forward.",
            queryImpactTerms = emptyList(),
            evidenceImpactKeys = emptyList(),
            summary = "Scientific discovery decision memory did not run.",
            claimLimit = "scientific_decision_memory_guides_routing_not_proof"
        )
    }
}

object ScientificDiscoveryDecisionEngineV183 {
    fun decide(
        scientificWeights: ScientificDiscoveryWeightReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        causalReadiness: CausalReadinessReport,
        miniPeerReview: MiniPeerReviewReport,
        datasetForaging: DatasetForagingReport,
        evidenceGain: EvidenceGainQueryRankerReport
    ): ScientificDiscoveryDecisionReport {
        if (!scientificWeights.active && !deepDiscovery.active) return ScientificDiscoveryDecisionReport.empty()

        val topWeight = scientificWeights.topWeights.firstOrNull()
        val decisive = deepDiscovery.decisiveExperiment
        val topTournament = deepDiscovery.mechanismTournament.firstOrNull()
        val parsed = datasetForaging.parsedMetadata
        val hasOutcome = parsed.any { it.outcomeLabels.isNotEmpty() }
        val hasControl = parsed.any { it.controlLabels.isNotEmpty() } || datasetForaging.contrastiveReport.gateStatus.contains("PASS", true)
        val hasTime = parsed.any { it.timeCourseLabels.isNotEmpty() }
        val highRouteFit = datasetForaging.routeFitAssessments.any { it.routeFitScore >= 80 }
        val falseFriend = scientificWeights.downgradedFalseFriends.firstOrNull()
        val causalBlocked = !causalReadiness.causalLanguageAllowed || miniPeerReview.verdict in setOf("HOLD", "REJECT")

        val selectedMove = when {
            topWeight?.action == "CLOSE_DECISIVE_EVIDENCE_GAP" -> "Close decisive evidence gap: ${topWeight.label}"
            decisive.nextQuery.isNotBlank() -> "Run decisive experiment query: ${decisive.decisiveQuestion}"
            evidenceGain.chosenQuery.isNotBlank() -> "Run highest evidence-gain query: ${evidenceGain.chosenQueryId}"
            topWeight != null -> "Prioritize scientific term: ${topWeight.label}"
            else -> "Continue bounded dataset inspection"
        }.take(260)

        val selectedReason = buildList {
            topWeight?.let { add("topWeight=${it.termId}/${it.action}/w${it.routingWeight}") }
            if (deepDiscovery.active) add("deep=${deepDiscovery.state}/${deepDiscovery.intelligenceScore}")
            add("causal=${causalReadiness.state}/level${causalReadiness.level}")
            add("peer=${miniPeerReview.verdict}")
            if (highRouteFit) add("highRouteFit=true")
        }.joinToString("; ").ifBlank { "Selected by bounded discovery policy." }

        val blockedMove = when {
            falseFriend != null -> "Do not generalize false-friend term: ${falseFriend.take(160)}"
            causalBlocked -> "Do not upgrade hypothesis or use causal/strong-signal language."
            highRouteFit && (!hasOutcome || !hasControl) -> "Do not let high route-fit bypass outcome/control evidence."
            else -> "No upgrade block beyond normal evidence gates."
        }
        val blockedReason = buildList {
            if (!hasOutcome) add("missing_outcome_labels")
            if (!hasControl) add("missing_control_or_comparator")
            if (!hasTime) add("missing_time_order")
            if (!causalReadiness.causalLanguageAllowed) add("causal_language_blocked")
            if (miniPeerReview.strongestObjection.isNotBlank()) add(miniPeerReview.strongestObjection.take(160))
        }.joinToString("; ").ifBlank { "Evidence gates remain normal." }

        val successCriteria = buildSuccessCriteria(scientificWeights, decisive, causalReadiness, miniPeerReview, hasOutcome, hasControl, hasTime)
        val failureCriteria = buildFailureCriteria(scientificWeights, causalReadiness, miniPeerReview, highRouteFit)
        val queryTerms = buildQueryImpactTerms(scientificWeights, deepDiscovery, evidenceGain, topTournament).take(22)
        val evidenceKeys = buildEvidenceImpactKeys(successCriteria + failureCriteria + scientificWeights.decisiveEvidenceDelta + causalReadiness.blockers + miniPeerReview.missingEvidence).take(14)
        val nextContract = "Next cycle must test ${evidenceKeys.take(5).joinToString("+").ifBlank { "minimum_metadata" }}; success requires ${successCriteria.take(2).joinToString(" | ").ifBlank { "new inspectable evidence" }}; failure triggers ${failureCriteria.take(2).joinToString(" | ").ifBlank { "route cooldown" }}."
        val changeIfFails = when {
            failureCriteria.any { it.contains("cool", true) } -> "Cool down this route and prefer contradiction/control search."
            failureCriteria.any { it.contains("outcome", true) } -> "Downgrade any belief that depends on effect/recovery/severity labels."
            causalReadiness.level < 3 -> "Keep only association/route-fit language and block mechanism upgrade."
            else -> "Retain as context prior only; require independent replication before reuse."
        }
        val carry = "Carry forward as one bounded decision memory item; hide from main routing if the same failure repeats in the next cycle."
        val tags = buildList {
            add("decision_memory_v183")
            if (highRouteFit) add("high_route_fit")
            if (!hasOutcome) add("needs_outcome")
            if (!hasControl) add("needs_control")
            if (!hasTime) add("needs_time_order")
            if (falseFriend != null) add("false_friend_guard")
            if (deepDiscovery.deepThinkSession.active) add("deep_think_active")
            if (causalBlocked) add("upgrade_blocked")
        }.distinct()
        val summary = "v1.8.3 decision memory: selected=${selectedMove.take(90)}; blocked=${blockedMove.take(90)}; next=${evidenceKeys.take(4).joinToString("/").ifBlank { "minimum_metadata" }}"

        return ScientificDiscoveryDecisionReport(
            active = true,
            version = "v1.8.3-decision-memory",
            selectedMove = selectedMove,
            selectedReason = selectedReason,
            blockedMove = blockedMove.take(260),
            blockedReason = blockedReason.take(360),
            successCriteria = successCriteria.take(8),
            failureCriteria = failureCriteria.take(8),
            nextCycleContract = nextContract.take(520),
            decisionTags = tags.take(12),
            changeIfFails = changeIfFails.take(260),
            carryForwardPolicy = carry,
            queryImpactTerms = queryTerms,
            evidenceImpactKeys = evidenceKeys,
            summary = summary.take(360),
            claimLimit = "scientific_decision_memory_guides_routing_not_proof"
        )
    }

    private fun buildSuccessCriteria(
        weights: ScientificDiscoveryWeightReport,
        decisive: DecisiveExperimentPlan,
        causal: CausalReadinessReport,
        peer: MiniPeerReviewReport,
        hasOutcome: Boolean,
        hasControl: Boolean,
        hasTime: Boolean
    ): List<String> = buildList {
        addAll(weights.decisiveEvidenceDelta.take(4).map { "Close $it" })
        decisive.requiredDatasetFeatures.take(4).forEach { add("Find dataset feature: $it") }
        if (!hasOutcome) add("Find explicit outcome/recovery/severity/endpoint labels")
        if (!hasControl) add("Find comparator/control/negative-control design")
        if (!hasTime) add("Find baseline/serial/follow-up/time-course ordering")
        if (causal.level < 3) add("Reach controlled-comparison readiness before causal wording")
        peer.missingEvidence.take(3).forEach { add("Close peer-review missing evidence: $it") }
    }.distinct()

    private fun buildFailureCriteria(
        weights: ScientificDiscoveryWeightReport,
        causal: CausalReadinessReport,
        peer: MiniPeerReviewReport,
        highRouteFit: Boolean
    ): List<String> = buildList {
        if (highRouteFit) add("If route-fit stays high but outcome/control/time remain missing, cool down this route")
        if (weights.downgradedFalseFriends.isNotEmpty()) add("If false-friend risk repeats, downgrade term to context-only prior")
        if (causal.level < 3) add("If controlled comparison is not found, block causal and strong-signal language")
        if (peer.verdict in setOf("HOLD", "REJECT")) add("If peer objection remains unresolved, do not reuse this belief for routing")
        weights.riskGuards.take(3).forEach { add("If violated: $it") }
    }.distinct()

    private fun buildQueryImpactTerms(
        weights: ScientificDiscoveryWeightReport,
        deep: DeepDiscoveryReasoningReport,
        evidenceGain: EvidenceGainQueryRankerReport,
        topTournament: MechanismTournamentCard?
    ): List<String> {
        val raw = mutableListOf<String>()
        raw += weights.searchPriorityVector
        raw += weights.topWeights.take(4).flatMap { it.queryTerms + it.label }
        raw += deep.decisiveExperiment.nextQuery
        raw += deep.contradictionPlan.contradictionQueries.take(2)
        raw += deep.contradictionPlan.negativeControls.take(2)
        raw += deep.deepThinkSession.nextQuery
        raw += evidenceGain.chosenQuery
        topTournament?.discriminator?.let { raw += it }
        return raw.flatMap { tokenize(it) }.distinct().take(30)
    }

    private fun buildEvidenceImpactKeys(raw: List<String>): List<String> = raw.map { evidenceKey(it) }
        .filter { it.isNotBlank() && it !in setOf("none", "unknown") }
        .distinct()

    private fun evidenceKey(raw: String): String {
        val text = raw.lowercase(Locale.US).replace("-", "_").replace(" ", "_")
        return when {
            text.contains("outcome") || text.contains("recovery") || text.contains("severity") || text.contains("endpoint") -> "outcome_labels"
            text.contains("time") || text.contains("longitudinal") || text.contains("serial") || text.contains("follow") || text.contains("baseline") -> "time_order"
            text.contains("control") || text.contains("comparator") || text.contains("placebo") || text.contains("negative") -> "comparator_control"
            text.contains("metadata") || text.contains("sample") || text.contains("license") || text.contains("phenotype") -> "minimum_metadata"
            text.contains("human") || text.contains("patient") || text.contains("clinical") -> "human_or_patient_data"
            text.contains("cell") || text.contains("tissue") -> "tissue_cell_context"
            text.contains("batch") || text.contains("artifact") || text.contains("assay") -> "assay_batch_control"
            text.contains("replication") || text.contains("validation") -> "replication_validation"
            text.contains("intervention") || text.contains("perturbation") -> "perturbation_intervention"
            text.contains("viral") || text.contains("load") -> "viral_load"
            text.contains("interferon") || text.contains("ifn") || text.contains("isg") -> "interferon_markers"
            else -> text.take(80)
        }
    }

    private fun tokenize(text: String): List<String> {
        val allowed = setOf(
            "outcome", "recovery", "severity", "endpoint", "longitudinal", "serial", "temporal", "follow-up", "baseline", "time-course",
            "control", "comparator", "placebo", "negative", "healthy", "metadata", "phenotype", "sample", "license",
            "human", "patient", "clinical", "rna-seq", "single-cell", "transcriptomic", "interferon", "ifn", "isg", "viral", "load",
            "cell", "tissue", "cell-type", "assay", "batch", "artifact", "replication", "validation", "perturbation", "intervention",
            "ige", "eosinophil", "mast", "cytokine", "signature", "mechanism", "confounder", "contradiction", "falsification", "gse", "geo", "sra", "prjna"
        )
        return text.lowercase(Locale.US)
            .replace("rna seq", "rna-seq")
            .replace("single cell", "single-cell")
            .split(Regex("[^a-z0-9_-]+"))
            .map { it.trim() }
            .filter { it.length >= 3 }
            .filter { it in allowed || it.startsWith("gse") || it.startsWith("prjna") }
            .distinct()
    }
}
