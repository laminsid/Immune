package com.immunesignal.app

/**
 * Hardcoded biological plausibility graph.
 *
 * v1.1 contract: this graph MUST stay in lock-step with
 * `app/src/main/assets/biological_plausibility_graph_v0.2.json`.
 * The JSON file is the canonical specification (auditable, diffable).
 * `BiologicalPlausibilityGraphTest.json_asset_matches_Kotlin_edges` enforces
 * this contract — if you edit one, edit the other and rerun the tests.
 *
 * Why hardcoded too: this object is called from `CausalityScorer` which has
 * no Android `Context`, so it cannot read assets at runtime without invasive
 * plumbing. The JSON-as-spec + test-as-enforcer pattern keeps a single
 * source of truth without surgery on every caller.
 */
object BiologicalPlausibilityGraph {
    private val knownPairs = mapOf(
        setOf("psychoneuroimmune_axis", "type2_allergy_axis") to "stress/autonomic signaling may modulate mast-cell and Type-2 reactivity",
        setOf("type2_allergy_axis", "autonomic_vascular_axis") to "histamine/mast-cell mediator release can plausibly affect vascular tone",
        setOf("gastric_acid_gut_axis", "type2_allergy_axis") to "gut barrier/reflux/microbiome context can interact with airway or allergy symptoms",
        setOf("testosterone_immune_axis", "type2_allergy_axis") to "sex-hormone signaling can plausibly modulate Type-2 inflammation",
        setOf("nutrition_protein_axis", "muscle_mass_reserve_axis") to "protein and muscle reserve affect recovery and inflammatory resilience",
        setOf("rna_transcriptomic_axis", "tnf_il6_autoimmune_axis") to "gene-expression states can expose inflammatory pathway activation",
        setOf("dna_genomic_axis", "aging_immune_axis") to "genetic/epigenetic signals can bridge aging clocks and immune remodeling",
        setOf("regulatory_brake_axis", "hyperinflammatory_axis") to "regulatory failure is a plausible brake-loss path in severe inflammation",
        setOf("psychomusculoskeletal_axis", "psychoneuroimmune_axis") to "sleep/stress/fear-avoidance can plausibly affect pain persistence and muscle guarding",
        setOf("interferon_antiviral_axis", "rna_transcriptomic_axis") to "interferon programs often appear as transcriptomic response signatures in antiviral contexts",
        setOf("interferon_antiviral_axis", "tissue_damage_axis") to "antiviral inflammation can interact with tissue-damage and repair signals",
        setOf("tcell_activation_axis", "bcell_antibody_axis") to "T-cell help and B-cell antibody responses can be coupled in adaptive immune activation",
        setOf("bcell_antibody_axis", "type2_allergy_axis") to "antibody and Type-2/allergy routes can overlap through IgE and B-cell class-switch contexts",
        setOf("tissue_damage_axis", "tnf_il6_autoimmune_axis") to "tissue-damage signals can travel with TNF/IL-6 inflammatory activation",
        setOf("aging_immune_axis", "interferon_antiviral_axis") to "aging/immunosenescence can alter antiviral interferon response baselines",
        setOf("diabetes_metabolic_inflammation", "tnf_il6_autoimmune_axis") to "metabolic inflammation can confound TNF/IL-6 inflammatory interpretation",
        setOf("tumor_immune_evasion_axis", "tcell_exhaustion_axis") to "tumor immune evasion and chronic-antigen states can share exhaustion markers, but disease-specific antigen context is mandatory",
        setOf("tumor_immune_evasion_axis", "regulatory_brake_axis") to "checkpoint/regulatory brake failure can be a search bridge in cancer immune escape only with tumor comparator data",
        setOf("hiv_aids_tcell_depletion_axis", "tcell_exhaustion_axis") to "HIV/AIDS chronic viral antigen exposure can overlap with exhaustion programs while CD4 depletion remains a differentiator",
        setOf("hiv_aids_tcell_depletion_axis", "fungal_th17_neutrophil_axis") to "AIDS-related opportunistic fungal risk requires host immune-deficit context, not only fungal terms",
        setOf("fungal_th17_neutrophil_axis", "th17_il17_axis") to "anti-fungal defense often depends on Th17/IL-17 and neutrophil/barrier context",
        setOf("epidemic_pandemic_immune_response_axis", "interferon_antiviral_axis") to "epidemic/pandemic response can bridge to interferon timing when pathogen, wave, and severity labels are present",
        setOf("epidemic_pandemic_immune_response_axis", "hyperinflammatory_axis") to "severe epidemic cases may overlap cytokine storm axes but require severity grading and controls"
    )

    fun plausibilityScore(axes: List<String>): Pair<Int, List<String>> {
        val notes = mutableListOf<String>()
        var score = 20
        val axisSet = axes.toSet()
        knownPairs.forEach { (pair, mechanism) ->
            if (axisSet.containsAll(pair)) {
                score += 18
                notes += mechanism
            }
        }
        if (axes.any { it.contains("rna") || it.contains("dna") }) {
            score += 8
            notes += "omics axis can reveal hidden upstream state but needs curated datasets."
        }
        if (axes.size >= 3) {
            score += 8
            notes += "multi-axis bridge found; stronger as a hypothesis, weaker as proof until temporality is tested."
        }
        if (notes.isEmpty()) notes += "No known graph edge matched; keep as speculative until a mechanism is found."
        return score.coerceIn(0, 100) to notes.distinct()
    }
}
