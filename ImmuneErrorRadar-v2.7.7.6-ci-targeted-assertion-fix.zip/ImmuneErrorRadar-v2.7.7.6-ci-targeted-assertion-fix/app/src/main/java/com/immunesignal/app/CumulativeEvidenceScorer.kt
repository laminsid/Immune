package com.immunesignal.app

/** v1.4.4: transparent cumulative scoring; separates usability from route fit. */
object CumulativeEvidenceScorer {
    fun score(
        evidenceObjects: List<EvidenceObject>,
        parsed: List<ParsedDatasetMetadata>,
        routeFits: List<DatasetRouteFitAssessment> = emptyList()
    ): CumulativeEvidenceReport {
        val upgrades = mutableListOf<String>()
        val downgrades = mutableListOf<String>()
        val rationale = mutableListOf<String>()
        var score = 0

        if (parsed.any { it.usabilityVerdict == "USABLE_FOR_TEST" }) { score += 25; upgrades += "At least one parsed dataset is usable for test." } else downgrades += "No dataset parsed as usable for test."
        if (parsed.any { it.organism == "human" }) { score += 12; upgrades += "Human metadata detected." } else downgrades += "Human metadata not established."
        if (parsed.any { it.outcomeLabels.isNotEmpty() }) { score += 16; upgrades += "Outcome labels detected." } else downgrades += "Outcome labels missing."
        if (parsed.any { it.controlLabels.isNotEmpty() }) { score += 12; upgrades += "Control labels detected." } else downgrades += "Control labels missing."
        if (parsed.any { it.contrastiveSlots.isNotEmpty() }) { score += 12; upgrades += "Contrastive comparison slot exists." } else downgrades += "No contrastive slot yet."
        if (evidenceObjects.any { it.contradictsHypothesis }) { score -= 12; downgrades += "Contradiction object detected; block over-upgrade." }
        if (evidenceObjects.any { it.causalClaimSafe }) { score += 8; upgrades += "At least one cautious causal-safe evidence object." } else downgrades += "No causal-safe evidence object."
        if (evidenceObjects.any { it.hasLongitudinalSignal }) { score += 8; upgrades += "Longitudinal signal present." }
        if (evidenceObjects.any { it.hasNegativeControl }) { score += 7; upgrades += "Negative/control signal present." }

        val routeBlocked = routeFits.isNotEmpty() && routeFits.all { it.blocksHypothesisUpgrade }
        val mixedRoute = routeFits.any { it.blocksHypothesisUpgrade } && routeFits.any { !it.blocksHypothesisUpgrade }
        when {
            routeBlocked -> {
                score = minOf(score, 45)
                downgrades += "Route-fit gate: usable dataset is off-route for the current target hypothesis."
            }
            mixedRoute -> {
                score = minOf(score, 60)
                downgrades += "Route-fit gate: mixed in-route/off-route candidates require separation before upgrade."
            }
            routeFits.any { it.status == "IN_ROUTE" } -> upgrades += "Route-fit gate: at least one dataset fits the current target route."
        }

        score = score.coerceIn(0, 100)
        val state = when {
            routeBlocked -> "OFF_ROUTE_DATASET"
            mixedRoute -> "MIXED_ROUTE_CAUTION"
            score >= 75 -> "TESTABLE_LEAD"
            score >= 60 -> "CANDIDATE"
            score >= 35 -> "INTERPRETABLE_BUT_NOT_READY"
            else -> "OFF"
        }
        rationale += "Score is cumulative and conservative; it is not a clinical prediction and not a Bayesian truth claim."
        rationale += "Dataset usability, route fit, and hypothesis confidence must be read separately."
        return CumulativeEvidenceReport(score, state, upgrades.distinct(), downgrades.distinct(), rationale.distinct())
    }
}
