package com.immunesignal.app

/**
 * v1.5.8: minimum metadata parse guard.
 *
 * This wrapper guarantees that any candidate selected by CandidateActionResolver
 * receives at least a parse attempt and a visible metadata state. It does not
 * infer biology beyond title/hint-level metadata and cannot upgrade hypotheses.
 */
object MinimumMetadataParser {
    fun parse(
        candidates: List<DatasetAccessionCandidate>,
        findings: List<ResearchFinding>,
        actionReport: CandidateActionReport
    ): List<ParsedDatasetMetadata> {
        if (candidates.isEmpty()) return emptyList()
        val parsed = DatasetParser.parse(candidates, findings)
        val parsedKeys = parsed.map { it.accession }.toSet()
        val fallback = candidates
            .filter { it.accession !in parsedKeys }
            .map { fallbackMetadata(it, actionReport.decisions.firstOrNull { d -> d.accession == it.accession }) }
        return (parsed + fallback)
            .distinctBy { it.accession + ":" + it.sourceFamily }
            .sortedByDescending { it.metadataQualityScore }
    }

    private fun fallbackMetadata(candidate: DatasetAccessionCandidate, decision: CandidateActionDecision?): ParsedDatasetMetadata {
        val condition = candidate.conditionLabelsHint.takeIf { it.isNotBlank() && it != "unknown" }?.let { listOf(it.take(80)) } ?: emptyList()
        val outcome = candidate.outcomeLabelsHint.takeIf { it.isNotBlank() && it != "unknown" }?.let { listOf(it.take(80)) } ?: emptyList()
        val time = candidate.timeCourseHint.takeIf { it.isNotBlank() && it != "unknown" }?.let { listOf(it.take(80)) } ?: emptyList()
        val organism = when {
            candidate.organismHint.contains("human", ignoreCase = true) -> "human"
            candidate.organismHint.contains("mouse", ignoreCase = true) || candidate.organismHint.contains("animal", ignoreCase = true) -> "animal_or_model"
            else -> "unknown"
        }
        val reasons = buildList {
            add("Minimum metadata fallback created because parser returned no object for a selected candidate.")
            if (decision != null) add("Candidate action: ${decision.action}; ${decision.reason}")
            add("This is metadata inspection only and cannot upgrade a hypothesis.")
        }
        return ParsedDatasetMetadata(
            accession = candidate.accession,
            sourceFamily = candidate.source,
            organism = organism,
            sampleSizeStatus = candidate.sampleSizeHint.ifBlank { "unknown" },
            conditionLabels = condition,
            outcomeLabels = outcome,
            controlLabels = emptyList(),
            timeCourseLabels = time,
            tissueOrSource = "unknown",
            assayType = candidate.dataType.ifBlank { "unknown" },
            contrastiveSlots = emptyList(),
            metadataQualityScore = 30,
            usabilityVerdict = "MINIMUM_METADATA_ONLY",
            evidenceObjectEligible = false,
            reasons = reasons
        )
    }
}
