package com.immunesignal.app

/** v1.4.2: lightweight evidence graph, not a neural network. */
object EvidenceHypergraphLite {
    fun build(parsed: List<ParsedDatasetMetadata>): List<EvidenceHypergraphNode> {
        val nodes = mutableListOf<EvidenceHypergraphNode>()
        for (item in parsed.take(20)) {
            val baseLinks = listOf(item.accession, item.organism, item.usabilityVerdict).filter { it.isNotBlank() && it != "unknown" }
            nodes += EvidenceHypergraphNode(
                nodeId = "dataset_${item.accession}",
                nodeType = "dataset",
                label = item.accession,
                links = baseLinks + item.conditionLabels + item.outcomeLabels + item.controlLabels + item.timeCourseLabels,
                strength = item.metadataQualityScore,
                contradictionFlag = item.usabilityVerdict == "NOT_USABLE"
            )
            for (label in (item.conditionLabels + item.outcomeLabels + item.controlLabels + item.contrastiveSlots).distinct()) {
                nodes += EvidenceHypergraphNode(
                    nodeId = "label_${label}_${item.accession}",
                    nodeType = "metadata_label",
                    label = label,
                    links = listOf(item.accession, item.usabilityVerdict, item.assayType).filter { it.isNotBlank() && it != "unknown" },
                    strength = (item.metadataQualityScore - 10).coerceIn(0, 100),
                    contradictionFlag = false
                )
            }
        }
        return nodes.distinctBy { it.nodeId }.sortedByDescending { it.strength }.take(80)
    }
}
