package com.immunesignal.app

import org.json.JSONObject
import java.io.File
import java.util.ArrayDeque

/**
 * v1.10.5: Pure file-IO helper for ResearchKnowledgeStore.
 *
 * The Android store keeps its Context-facing API and per-file locks, while this
 * helper makes hot JSONL behavior independently testable on the JVM: append-only
 * writes, bounded trimming, last-N reads from the end of the file, and malformed
 * line rejection without silently returning invalid records.
 */
object ResearchKnowledgeStoreFileOps {
    fun appendOnly(file: File, line: String) {
        file.parentFile?.mkdirs()
        file.appendText(line + "\n", Charsets.UTF_8)
    }

    fun trimFile(file: File, maxLines: Int): Int {
        if (maxLines <= 0) {
            file.writeText("", Charsets.UTF_8)
            return 0
        }
        val valid = readAllValidJsonLines(file)
        if (valid.size <= maxLines) return valid.size
        val trimmed = valid.takeLast(maxLines)
        file.writeText(trimmed.joinToString(separator = "\n", postfix = "\n"), Charsets.UTF_8)
        return trimmed.size
    }

    fun readAllValidJsonLines(
        file: File,
        onRejected: (String) -> Unit = {}
    ): List<String> {
        if (!file.exists() || file.length() <= 0L) return emptyList()
        return file.readLines(Charsets.UTF_8).mapNotNull { raw ->
            val line = raw.trim()
            if (line.isBlank()) null else if (isValidJsonLine(line)) line else {
                onRejected(line)
                null
            }
        }
    }

    fun readLastValidJsonLines(
        file: File,
        limit: Int,
        onRejected: (String) -> Unit = {}
    ): List<String> {
        if (limit <= 0 || !file.exists() || file.length() <= 0L) return emptyList()

        val validTail = ArrayDeque<String>()

        file.bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.forEach { raw ->
                val line = raw.trim()
                if (line.isBlank()) return@forEach

                if (isValidJsonLine(line)) {
                    validTail.addLast(line)
                    while (validTail.size > limit) {
                        validTail.removeFirst()
                    }
                } else {
                    onRejected(line)
                }
            }
        }

        return validTail.toList()
    }

    fun isValidJsonLine(line: String): Boolean {
        return try {
            JSONObject(line)
            true
        } catch (_: Exception) {
            false
        }
    }
}
