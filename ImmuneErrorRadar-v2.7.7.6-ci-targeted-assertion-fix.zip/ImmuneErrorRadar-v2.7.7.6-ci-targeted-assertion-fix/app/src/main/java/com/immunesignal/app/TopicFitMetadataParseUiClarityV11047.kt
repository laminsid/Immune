// legacy_audit_v11048: RELAXED_PROGRESSION_NO_CLAIM_RELAXATION
package com.immunesignal.app

/**
 * v1.10.47 + v1.10.48 + v1.10.49 + v1.10.50 + v1.10.51 + v1.10.52: topic-fit, controlled relaxation, minimum-metadata forcing, UI clarity, route correction, comparator hunt, EvidenceObjectCandidate, environmental/psychophysiological exposome routing, open exploration, medical term index, and diagnostic reasoning sandbox.
 *
 * This layer fixes a real operational failure observed in v1.10.46/v1.10.47 reports:
 * old mature-domain priors can dominate unrelated topics, many candidates can be
 * retained without any parsed metadata, and the UI can confuse useful learning
 * with a scientific discovery. The layer is deliberately bounded: it never
 * creates an EvidenceObject, diagnosis, treatment, dose, or causal claim. v1.10.48 lowers strictness only for progression; v1.10.49 corrects topic routes and creates EvidenceObjectCandidate records without relaxing claim gates; v1.10.50 opens environmental, psychophysiological, hormonal, physical, toxin/substance, digestive, food, age, weather, light, smell, and irritant exposures as research context only. v1.10.51 reconciles legacy report/query cards to the corrected route and activates EvidenceObjectCandidate for useful metadata blocked by control/comparator. v1.10.52 relaxes exploratory linking, strengthens the medical term index, opens dynamic nodes such as sugar/salt, and exposes diagnostic reasoning as a sandbox without producing patient diagnosis or treatment.
 */

/**
 * v1.10.49: a bounded intermediate object.
 *
 * This is NOT an EvidenceObject and cannot upgrade a biological claim. It marks
 * parsed metadata that is useful enough for the next evidence hunt but still blocked
 * by a missing comparator/control, contradiction/null-result search, or route fit.
 */
data class EvidenceObjectCandidateV11049(
    val candidateId: String,
    val accession: String,
    val status: String,
    val route: String,
    val metadataScore: Int,
    val closedGates: List<String>,
    val missingGates: List<String>,
    val nextAction: String,
    val claimLimit: String = "evidence_object_candidate_not_biological_proof"
)

data class TopicFitMetadataParseReport(
    val active: Boolean,
    val state: String,
    val topicLabel: String,
    val preferredLane: String,
    val topicFitScore: Int,
    val suppressedMatureDomain: String,
    val forcedMinimumMetadataCount: Int,
    val parsedMetadataCount: Int,
    val evidenceObjectCount: Int,
    val learningStatus: String,
    val discoveryStatus: String,
    val evidenceStatus: String,
    val missingGates: List<String>,
    val invalidators: List<String>,
    val userSummaryLines: List<String>,
    val nextAction: String,
    val reasons: List<String>,
    val strictnessMode: String,
    val progressionAllowed: Boolean,
    val contextSeeds: List<String>,
    val softProgressionGates: List<String>,
    val hardClaimGates: List<String>,
    val contextAlignmentStatus: String,
    val routeFitBoostPolicy: String,
    val topicRouteCorrectionStatus: String = "NOT_EVALUATED",
    val comparatorHuntMode: String = "NOT_EVALUATED",
    val evidenceObjectCandidates: List<EvidenceObjectCandidateV11049> = emptyList(),
    val evidenceObjectCandidateCount: Int = evidenceObjectCandidates.size,
    val legacyRouteReconciliationStatus: String = "NOT_EVALUATED",
    val reconciledMatureDomainFocus: String = "none",
    val reconciledQuerySeed: String = "none",
    val comparatorHuntQueries: List<String> = emptyList(),
    val legacySuppressionNotes: List<String> = emptyList(),
    val openExplorationMode: String = "NOT_EVALUATED",
    val diagnosticReasoningMode: String = "NOT_EVALUATED",
    val medicalIndexTerms: List<String> = emptyList(),
    val medicalTermSummaries: List<String> = emptyList(),
    val dynamicNodesOpened: List<String> = emptyList(),
    val exploratoryRouteCandidates: List<String> = emptyList(),
    val exploratoryLinkQueries: List<String> = emptyList(),
    val diagnosticReasoningLines: List<String> = emptyList(),
    val openExplorationGuardrails: List<String> = emptyList(),
    val claimLimit: String = CLAIM_LIMIT
) {
    companion object {
        const val CLAIM_LIMIT: String = "topic_fit_metadata_parse_ui_clarity_not_biological_proof"

        fun empty() = TopicFitMetadataParseReport(
            active = false,
            state = "NOT_EVALUATED",
            topicLabel = "unknown",
            preferredLane = "none",
            topicFitScore = 0,
            suppressedMatureDomain = "none",
            forcedMinimumMetadataCount = 0,
            parsedMetadataCount = 0,
            evidenceObjectCount = 0,
            learningStatus = "not evaluated",
            discoveryStatus = "not evaluated",
            evidenceStatus = "not evaluated",
            missingGates = emptyList(),
            invalidators = emptyList(),
            userSummaryLines = emptyList(),
            nextAction = "Run a research cycle.",
            reasons = emptyList(),
            strictnessMode = "NOT_EVALUATED",
            progressionAllowed = false,
            contextSeeds = emptyList(),
            softProgressionGates = emptyList(),
            hardClaimGates = emptyList(),
            contextAlignmentStatus = "NOT_EVALUATED",
            routeFitBoostPolicy = "No context alignment evaluated.",
            legacyRouteReconciliationStatus = "NOT_EVALUATED",
            reconciledMatureDomainFocus = "none",
            reconciledQuerySeed = "none",
            comparatorHuntQueries = emptyList(),
            legacySuppressionNotes = emptyList(),
            openExplorationMode = "NOT_EVALUATED",
            diagnosticReasoningMode = "NOT_EVALUATED",
            medicalIndexTerms = emptyList(),
            medicalTermSummaries = emptyList(),
            dynamicNodesOpened = emptyList(),
            exploratoryRouteCandidates = emptyList(),
            exploratoryLinkQueries = emptyList(),
            diagnosticReasoningLines = emptyList(),
            openExplorationGuardrails = emptyList()
        )
    }
}

object TopicFitMetadataParseUiClarityV11047 {
    const val CLAIM_LIMIT: String = TopicFitMetadataParseReport.CLAIM_LIMIT
    const val STRICTNESS_MODE: String = "OPEN_EXPLORATION_NO_PATIENT_DIAGNOSIS"

    fun evaluate(
        steering: ResearchSteeringProfile?,
        matureFocus: MatureDomainFocusReport,
        longevity: LongevityBiologicalSystemsReport,
        candidateAction: CandidateActionReport,
        parsedMetadata: List<ParsedDatasetMetadata>,
        evidenceObjects: List<EvidenceObject>,
        metadataClosure: MetadataClosureReport
    ): TopicFitMetadataParseReport {
        val topicText = topicText(steering)
        val topicCore = userTopicText(steering).ifBlank { topicText }
        val topicLabel = topicLabel(topicCore)
        val preferredLane = preferredLane(topicCore, longevity.selectedLane)
        val matureDomain = matureFocus.selectedDomain.ifBlank { "none" }
        val suppressed = suppressedMatureDomain(topicCore, matureDomain)
        val topicFit = topicFitScore(topicCore, matureDomain, preferredLane)
        val forcedCount = candidateAction.minimumMetadataAccessions.size
        val missing = buildMissingGates(metadataClosure, parsedMetadata)
        val contextSeeds = controlledContextSeeds(topicCore, preferredLane, longevity)
        val openExploration = OpenExplorationMedicalIndexV11052.evaluate(topicCore, preferredLane, contextSeeds)
        val softGates = softProgressionGates(missing)
        val hardGates = hardClaimGates(missing)
        val contextAlignment = contextAlignmentStatus(topicCore, contextSeeds, suppressed, candidateAction)
        val topicCorrection = topicRouteCorrectionStatus(topicCore, preferredLane, matureDomain, suppressed)
        val comparatorHunt = comparatorHuntMode(missing, parsedMetadata)
        val reconciledFocus = RouteReconciliationEvidenceCandidateV11051.reconciledMatureDomainFocus(topicLabel, preferredLane, suppressed)
        val reconciliationStatus = RouteReconciliationEvidenceCandidateV11051.legacyRouteReconciliationStatus(topicLabel, preferredLane, suppressed)
        val reconciledQuerySeed = RouteReconciliationEvidenceCandidateV11051.reconciledQuerySeed(topicLabel, preferredLane)
        val comparatorQueries = RouteReconciliationEvidenceCandidateV11051.comparatorHuntQueries(topicLabel, preferredLane, parsedMetadata.map { it.accession })
        val legacySuppressionNotes = RouteReconciliationEvidenceCandidateV11051.legacySuppressionNotes(topicLabel, preferredLane, suppressed)
        val evidenceObjectCandidates = buildEvidenceObjectCandidates(parsedMetadata, preferredLane, missing)
        val progressionAllowed = candidateAction.decisions.isNotEmpty() || contextSeeds.isNotEmpty() || parsedMetadata.isNotEmpty() || openExploration.dynamicNodes.isNotEmpty()
        val evidenceCount = evidenceObjects.size
        val parsedCount = parsedMetadata.size
        val discovery = when {
            evidenceCount > 0 -> "evidence_object_present"
            parsedCount > 0 -> "metadata_probe_only_no_discovery"
            candidateAction.decisions.isNotEmpty() -> "candidate_leads_only_no_discovery"
            openExploration.dynamicNodes.isNotEmpty() -> "open_route_node_generation_no_discovery"
            else -> "no_discovery_yet"
        }
        val learning = when {
            suppressed != "none" -> "topic_fit_corrected_stale_prior"
            forcedCount > 0 -> "minimum_metadata_parse_forced"
            parsedCount > 0 -> "metadata_visibility_improved"
            contextSeeds.isNotEmpty() -> "context_aligned_lookup_ready"
            openExploration.medicalIndexTerms.isNotEmpty() -> "medical_index_dynamic_node_learning"
            else -> "routing_memory_only"
        }
        val evidenceStatus = when {
            evidenceCount > 0 -> "evidence_object_available_but_still_claim_gated"
            evidenceObjectCandidates.isNotEmpty() -> "evidence_object_candidate_available_blocked_by_control"
            parsedCount > 0 -> "parsed_metadata_available_not_biological_proof"
            else -> "no_evidence_object_yet"
        }
        val state = when {
            suppressed != "none" && evidenceObjectCandidates.isNotEmpty() -> "TOPIC_ROUTE_CORRECTED_EVIDENCE_OBJECT_CANDIDATE"
            evidenceObjectCandidates.isNotEmpty() -> "EVIDENCE_OBJECT_CANDIDATE_BLOCKED_BY_CONTROL"
            suppressed != "none" && forcedCount > 0 -> "TOPIC_FIT_CORRECTED_AND_METADATA_FORCED"
            suppressed != "none" -> "TOPIC_FIT_SUPPRESSED_STALE_PRIOR"
            forcedCount > 0 -> "MINIMUM_METADATA_PARSE_FORCED_NO_UPGRADE"
            parsedCount > 0 -> "PARSED_METADATA_VISIBLE_NO_UPGRADE"
            openExploration.dynamicNodes.isNotEmpty() -> "OPEN_EXPLORATION_DYNAMIC_NODES_NO_DIAGNOSIS"
            progressionAllowed -> "RELAXED_PROGRESSION_CONTEXT_ALIGNED_NO_UPGRADE"
            else -> "TOPIC_FIT_ACTIVE_NO_EVIDENCE_OBJECT"
        }
        val invalidators = listOf(
            "no explicit accession/source ID after secondary lookup",
            "no control/comparator after minimum metadata closure",
            "no outcome labels or case/contrast definition",
            "no time order or longitudinal/serial signal",
            "topic-fit remains low and a stale mature prior keeps replaying",
            "exposure is not measurable with timing/intensity/frequency/context fields"
        )
        val next = when {
            evidenceObjectCandidates.isNotEmpty() -> "Run COMPARATOR_HUNT_MODE for ${evidenceObjectCandidates.first().accession}: healthy/matched/placebo/responder/non-responder/negative-control labels, then run contradiction/null-result search."
            "control_or_comparator" in missing -> "Run COMPARATOR_HUNT_MODE with reconciled query: ${comparatorQueries.firstOrNull() ?: reconciledQuerySeed}."
            forcedCount > 0 -> "Parse the forced minimum-metadata candidate(s), then run contradiction/null-result search before strengthening any biological link."
            parsedCount > 0 && missing.isNotEmpty() -> "Close ${missing.take(3).joinToString("+")} on parsed metadata before any hypothesis upgrade."
            suppressed != "none" -> "Cooldown stale mature-domain prior and execute the topic-specific lane: $preferredLane."
            openExploration.exploratoryLinkQueries.isNotEmpty() -> "Run OPEN_EXPLORATION_LINKING_MODE with: ${openExploration.exploratoryLinkQueries.first()}; keep diagnostic reasoning sandboxed."
            contextSeeds.isNotEmpty() -> "Run context-aligned secondary lookup with ${contextSeeds.take(5).joinToString("+")}; parse minimum metadata even if route-fit is still weak."
            else -> "Run topic-specific secondary lookup; do not broaden through stale mature-domain priors."
        }
        val reasons = buildList {
            add("v1.10.50 linkage owner active: ${EnvironmentalPsychophysiologicalExposomeLaneV11050.ASSET_NAME} via ${EnvironmentalPsychophysiologicalExposomeLaneV11050.PATHWAY_TEMPLATE}.")
            add("Exposome biomarkers=${ExposomeToLabMapperV11050.biomarkersForLane(preferredLane).take(5).joinToString(", ").ifBlank { "not selected" }}; comparators=${ExposomeToLabMapperV11050.comparatorsForLane(preferredLane).take(4).joinToString(", ").ifBlank { "not selected" }}.")
            add("Exposure advice guard active: ${NoExposureAdviceGuardV11050.forbiddenClaims.take(3).joinToString(", ")}.")
            add("Topic-fit dominance runs before mature-domain reuse.")
            add("Learning and discovery are separated: learning can be useful while discovery remains absent.")
            add("v1.10.48 strictness is lowered only for progress: context seeds and weak leads may move to metadata inspection; claim gates stay hard.")
            add("v1.10.49 corrects the route from the real user topic before mature-domain priors can replay.")
            add("v1.10.50 treats environmental, psychophysiological, hormonal, light/weather, substance, digestive, food, age, and irritant factors as exposure/context variables only, never as diagnosis, dose, or recommendation.")
            add("v1.10.51 reconciles legacy mature-domain, post-PubMed, knowledge-gap, global-action, UI, exporter, JSON, and learning-summary surfaces to the corrected route.")
            add("v1.10.52 relaxes exploratory linking: weak terms can open dynamic nodes and route candidates before they become evidence.")
            add("v1.10.53 CI route-linkage hardening: ${RouteLinkageHardeningV11053.reportLinkageSummary()}.")
            add("v1.10.54 GitHub CI/runtime hardening: ${GithubCiRuntimeSurfaceHardeningV11054.summary()}.")
            add("Diagnostic reasoning sandbox: ${openExploration.diagnosticReasoningMode}; shows differential route thinking, not patient diagnosis.")
            add("Medical index terms: ${openExploration.medicalIndexTerms.joinToString(", ").ifBlank { "none" }}.")
            add("Dynamic nodes opened: ${openExploration.dynamicNodesOpened.take(8).joinToString(", ").ifBlank { "none" }}.")
            add("Reconciled query seed: $reconciledQuerySeed.")
            legacySuppressionNotes.forEach { add(it) }
            if (suppressed != "none") add("Suppressed mature domain '$suppressed' because topic '$topicLabel' prefers '$preferredLane'.")
            if (forcedCount > 0) add("CandidateActionResolver forced $forcedCount minimum metadata parse(s) without allowing a hypothesis upgrade.")
            if (evidenceObjectCandidates.isNotEmpty()) add("Created ${evidenceObjectCandidates.size} EvidenceObjectCandidate record(s), all blocked from EvidenceObject until comparator/control and contradiction gates close.")
            if (contextSeeds.isNotEmpty()) add("Controlled context seeds selected for lookup priority only: ${contextSeeds.take(6).joinToString(", ")}.")
            if (parsedCount == 0) add("No parsed metadata is visible yet; UI must not imply a discovery.")
        }
        val userSummary = listOf(
            "Topic: $topicLabel",
            "Selected route: $preferredLane",
            "Why selected: topic-fit gate outranks stale mature-domain priors.",
            "Strictness: $STRICTNESS_MODE",
            "Open exploration: ${openExploration.mode}",
            "Diagnostic reasoning: ${openExploration.diagnosticReasoningMode}",
            "Medical index: ${openExploration.medicalIndexTerms.joinToString(", ").ifBlank { "none" }}",
            "Dynamic nodes: ${openExploration.dynamicNodesOpened.take(8).joinToString(", ").ifBlank { "none" }}",
            "Route correction: $topicCorrection",
            "Legacy reconciliation: $reconciliationStatus",
            "Reconciled legacy focus: $reconciledFocus",
            "Reconciled query seed: $reconciledQuerySeed",
            "Comparator hunt queries: ${comparatorQueries.take(2).joinToString(" | ").ifBlank { "none" }}",
            "Learning: $learning",
            "Discovery: $discovery",
            "Evidence: $evidenceStatus",
            "EvidenceObjectCandidate: ${evidenceObjectCandidates.size}",
            "Comparator hunt: $comparatorHunt",
            "Context seeds: ${contextSeeds.take(6).joinToString(", ").ifBlank { "none" }}",
            "Exposome asset: ${EnvironmentalPsychophysiologicalExposomeLaneV11050.ASSET_NAME}",
            "Exposome path: ${EnvironmentalPsychophysiologicalExposomeLaneV11050.PATHWAY_TEMPLATE}",
            "Exposure policy: exposure/context only; no personal health advice, no dose, no recommendation.",
            "Soft progression gates: ${softGates.take(5).joinToString(", ").ifBlank { "none" }}",
            "Hard claim gates: ${hardGates.take(5).joinToString(", ").ifBlank { "none" }}",
            "Invalidates if: ${invalidators.take(2).joinToString("; ")}",
            "Next: $next"
        )
        return TopicFitMetadataParseReport(
            active = true,
            state = state,
            topicLabel = topicLabel,
            preferredLane = preferredLane,
            topicFitScore = topicFit,
            suppressedMatureDomain = suppressed,
            forcedMinimumMetadataCount = forcedCount,
            parsedMetadataCount = parsedCount,
            evidenceObjectCount = evidenceCount,
            learningStatus = learning,
            discoveryStatus = discovery,
            evidenceStatus = evidenceStatus,
            missingGates = missing,
            invalidators = invalidators,
            userSummaryLines = userSummary,
            nextAction = next,
            reasons = reasons,
            strictnessMode = STRICTNESS_MODE,
            progressionAllowed = progressionAllowed,
            contextSeeds = contextSeeds,
            softProgressionGates = softGates,
            hardClaimGates = hardGates,
            contextAlignmentStatus = contextAlignment,
            routeFitBoostPolicy = "Context alignment may raise lookup priority and parsing priority only; it must not raise evidence confidence, route-fit-to-proof, or hypothesis probability.",
            topicRouteCorrectionStatus = topicCorrection,
            comparatorHuntMode = comparatorHunt,
            evidenceObjectCandidates = evidenceObjectCandidates,
            evidenceObjectCandidateCount = evidenceObjectCandidates.size,
            legacyRouteReconciliationStatus = reconciliationStatus,
            reconciledMatureDomainFocus = reconciledFocus,
            reconciledQuerySeed = reconciledQuerySeed,
            comparatorHuntQueries = comparatorQueries,
            legacySuppressionNotes = legacySuppressionNotes,
            openExplorationMode = openExploration.mode,
            diagnosticReasoningMode = openExploration.diagnosticReasoningMode,
            medicalIndexTerms = openExploration.medicalIndexTerms,
            medicalTermSummaries = openExploration.termSummaries,
            dynamicNodesOpened = openExploration.dynamicNodesOpened,
            exploratoryRouteCandidates = openExploration.exploratoryRouteCandidates,
            exploratoryLinkQueries = openExploration.exploratoryLinkQueries,
            diagnosticReasoningLines = openExploration.reasoningLines,
            openExplorationGuardrails = openExploration.guardrails,
            claimLimit = CLAIM_LIMIT
        )
    }

    fun topicText(steering: ResearchSteeringProfile?): String {
        return listOf(
            userTopicText(steering),
            steering?.focusQuestion.orEmpty(),
            steering?.variables?.joinToString(" ").orEmpty(),
            steering?.requiredTerms?.joinToString(" ").orEmpty(),
            steering?.inferredAxes?.joinToString(" ").orEmpty()
        ).joinToString(" ").lowercase()
    }

    fun userTopicText(steering: ResearchSteeringProfile?): String {
        val focus = steering?.focusQuestion.orEmpty()
        val extracted = Regex("""immune-system lens:\s*([^.;\n]+)""", RegexOption.IGNORE_CASE)
            .find(focus)
            ?.groupValues
            ?.getOrNull(1)
            ?.trim()
            ?.removeSuffix(".")
            .orEmpty()
        val firstVariable = steering?.variables?.firstOrNull()?.trim().orEmpty()
        val raw = extracted.ifBlank { firstVariable }
        return normalizeTopicToken(raw).lowercase()
    }

    private fun normalizeTopicToken(raw: String): String {
        val value = raw.trim()
        return when (value.lowercase()) {
            "ashawagandha", "ashwaganda", "ashwagandah" -> "ashwagandha"
            "long-covid", "long covid" -> "long covid"
            "me cfs", "me/cfs" -> "me/cfs"
            "pollen", "حبوب الطلع" -> "pollen"
            "dust", "الغبار" -> "dust"
            "stress", "التوتر", "الإجهاد", "الضغوطات النفسية" -> "stress"
            "depression", "الكآبة", "الاكتئاب", "الكئابة" -> "depression"
            "humidity", "الرطوبة" -> "humidity"
            "heat", "الحرارة" -> "heat"
            "smell", "الرائحة" -> "smell"
            "stomach acidity", "حموضة المعدة" -> "stomach acidity"
            else -> value
        }
    }

    fun preferredLane(topicText: String, fallbackSystemsLane: String = "none"): String {
        val exposomeLane = EnvironmentalPsychophysiologicalExposomeLaneV11050.selectLane(topicText, "__NO_EXPOSOME_LANE__")
        if (exposomeLane != "__NO_EXPOSOME_LANE__") return exposomeLane
        return when {
            containsAny(topicText, "dust", "pollen", "mold", "air quality", "pollution", "particulate", "pm2.5", "odor", "odour", "smell", "fragrance", "humidity", "weather", "temperature", "heat", "cold", "غبار", "حبوب الطلع", "الرائحة", "الرطوبة", "الجو", "الحرارة") -> "ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE"
            containsAny(topicText, "stress", "psychological", "psychosocial", "depression", "anxiety", "burnout", "trauma", "hpa", "cortisol", "ضغط", "التوتر", "الإجهاد", "الضغوط", "الكآبة", "الاكتئاب") -> "PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE"
            containsAny(topicText, "hormone", "hormones", "estrogen", "progesterone", "testosterone", "thyroid", "insulin", "melatonin", "cortisol", "هرمون", "الهرمونات") -> "ENDOCRINE_HORMONE_HPA_IMMUNE_LANE"
            containsAny(topicText, "enzyme", "enzymes", "gastric", "acid", "stomach acidity", "reflux", "ph", "digestion", "digestive", "food", "meal", "nutrition", "diet", "spice", "enzym", "حموضة", "المعدة", "المأكولات", "الأكل", "الغذاء", "الانزيمات") -> "DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE"
            containsAny(topicText, "light", "uv", "radiation", "infrared", "blue light", "screen", "moon", "lunar", "season", "circadian", "sunlight", "ضوء", "الضوء", "الأشعة", "القمر") -> "PHYSICAL_LIGHT_RADIATION_CIRCADIAN_IMMUNE_LANE"
            containsAny(topicText, "alcohol", "smoking", "tobacco", "nicotine", "drug", "drugs", "substance", "cannabis", "opioid", "stimulant", "الكحول", "التدخين", "المخدرات") -> "TOXIN_SUBSTANCE_EXPOSURE_IMMUNE_LANE"
            containsAny(topicText, "age", "aging", "elderly", "older", "العمر") -> "AGE_LIFE_STAGE_IMMUNE_CONTEXT_LANE"
            containsAny(topicText, "rna", "transcript", "mrna", "mirna", "scrna", "single-cell", "single cell", "gene expression") -> "RNA_TRANSCRIPTOMIC_IMMUNE_STATE_LANE"
            containsAny(topicText, "dna", "genome", "genetic", "epigenetic", "variant", "methylation") -> "GENETIC_EPIGENETIC_IMMUNE_VARIANT_LANE"
            containsAny(topicText, "ashwagandha", "curcumin", "quercetin", "honey", "eucalyptus", "wormwood", "herb", "herbal") -> "HERB_EXPOSURE_HPA_IMMUNE_MODULATION_LANE"
            containsAny(topicText, "rituximab", "jak inhibitor", "jak inhibitors", "loratadine", "immunomodulator", "immunomodulators") -> "DRUG_PERTURBATION_IMMUNE_CONTROL_LANE"
            containsAny(topicText, "vaccine", "vaccination", "immunization") -> {
                if (containsAny(topicText, "aging", "elderly", "older", "cmv", "immunosenescence", "t-cell", "t cell")) {
                    "IMMUNE_AGING_VACCINE_RESPONSE_LANE"
                } else {
                    "VACCINE_IMMUNE_RESPONSE_LANE"
                }
            }
            containsAny(topicText, "antibiotic", "antibiotics", "microbiome", "dysbiosis") -> "DRUG_PERTURBATION_MICROBIOME_BARRIER_IMMUNE_LANE"
            containsAny(topicText, "sleep", "circadian", "insomnia", "hrv", "cortisol", "night") -> "CIRCADIAN_SLEEP_INTELLIGENCE"
            containsAny(topicText, "fatigue", "me/cfs", "long covid", "mitochondria", "metabolomics") -> "MITOCHONDRIAL_FATIGUE_LANE"
            containsAny(topicText, "longevity", "aging", "senescence", "immunosenescence", "cmv") -> "IMMUNE_AGING_IMMUNOSENESCENCE_LANE"
            containsAny(topicText, "allergy", "allergies", "histamine", "antihistamine", "mast cell", "urticaria") -> "TYPE2_ALLERGY_MAST_CELL_LANE"
            fallbackSystemsLane.isNotBlank() && fallbackSystemsLane != "OFF" -> fallbackSystemsLane
            else -> "GENERAL_IMMUNE_DATASET_CLOSURE_LANE"
        }
    }

    private fun topicLabel(topicText: String): String = when {
        containsAny(topicText, "sugar", "glucose", "hba1c", "insulin", "glycemic", "diabetes", "salt", "sodium", "blood pressure", "hypertension", "osmotic", "السكر", "الملح", "الصوديوم", "ضغط الدم") -> "Sugar/Salt metabolic-electrolyte context"
        containsAny(topicText, "dust", "pollen", "mold", "air quality", "pollution", "odor", "smell", "humidity", "weather", "temperature", "heat", "cold", "غبار", "حبوب الطلع", "الرائحة", "الرطوبة", "الجو", "الحرارة") -> "Environmental exposure"
        containsAny(topicText, "stress", "psychological", "depression", "anxiety", "burnout", "hpa", "cortisol", "التوتر", "الإجهاد", "الضغوط", "الكآبة", "الاكتئاب") -> "Stress/HPA/psychological exposure"
        containsAny(topicText, "hormone", "hormones", "estrogen", "progesterone", "testosterone", "thyroid", "insulin", "melatonin", "الهرمونات") -> "Hormones/endocrine context"
        containsAny(topicText, "enzyme", "enzymes", "gastric", "stomach acidity", "reflux", "digestion", "food", "meal", "nutrition", "diet", "حموضة", "المأكولات", "الغذاء", "الانزيمات") -> "Digestive/food exposure"
        containsAny(topicText, "light", "uv", "radiation", "blue light", "moon", "lunar", "season", "circadian", "الضوء", "الأشعة", "القمر") -> "Light/radiation/circadian exposure"
        containsAny(topicText, "alcohol", "smoking", "tobacco", "nicotine", "drug", "drugs", "substance", "الكحول", "التدخين", "المخدرات") -> "Substance/toxin exposure"
        containsAny(topicText, "age", "aging", "elderly", "older", "العمر") -> "Age/life-stage context"
        containsAny(topicText, "rna", "transcript", "mrna", "mirna", "scrna", "single-cell", "gene expression") -> "RNA/Transcriptomics"
        containsAny(topicText, "dna", "genome", "genetic", "epigenetic", "variant", "methylation") -> "DNA/Genetics"
        containsAny(topicText, "ashwagandha") -> "Ashwagandha"
        containsAny(topicText, "curcumin") -> "Curcumin"
        containsAny(topicText, "quercetin") -> "Quercetin"
        containsAny(topicText, "rituximab") -> "Rituximab"
        containsAny(topicText, "loratadine") -> "Loratadine"
        containsAny(topicText, "immunomodulator", "immunomodulators") -> "Immunomodulators"
        containsAny(topicText, "vaccine", "vaccination", "immunization") -> "Vaccine"
        containsAny(topicText, "antibiotic", "antibiotics") -> "Antibiotics"
        containsAny(topicText, "sleep", "circadian") -> "Sleep/Circadian"
        containsAny(topicText, "fatigue", "me/cfs", "long covid") -> "Fatigue/Long COVID"
        containsAny(topicText, "longevity", "aging", "senescence") -> "Longevity/Aging"
        containsAny(topicText, "allergy", "allergies", "histamine", "antihistamine") -> "Allergy/Histamine"
        topicText.isBlank() -> "unknown"
        else -> topicText.split(Regex("\\s+")).take(4).joinToString(" ")
    }

    private fun suppressedMatureDomain(topicText: String, matureDomain: String): String {
        if (matureDomain == "none" || matureDomain.isBlank()) return "none"
        val mature = matureDomain.lowercase()
        val allergyTopic = containsAny(topicText, "allergy", "allergies", "histamine", "antihistamine", "mast cell", "urticaria")
        val staleAntihistamine = mature.contains("antihistamine") || mature.contains("mast_cell") || mature.contains("histamine")
        val topicExplicitlyDifferent = containsAny(topicText, "vaccine", "vaccination", "antibiotic", "antibiotics", "longevity", "sleep", "circadian", "fatigue", "long covid", "mitochondria", "rna", "transcript", "dna", "genetic", "ashwagandha", "curcumin", "quercetin", "rituximab", "immunomodulator", "dust", "pollen", "stress", "depression", "hormone", "enzyme", "gastric", "food", "light", "radiation", "moon", "weather", "temperature", "smell", "humidity", "alcohol", "smoking", "tobacco", "drug", "age", "sugar", "glucose", "hba1c", "insulin", "salt", "sodium", "blood pressure", "hypertension", "osmotic")
        return if (staleAntihistamine && topicExplicitlyDifferent && !allergyTopic) matureDomain else "none"
    }

    private fun topicFitScore(topicText: String, matureDomain: String, preferredLane: String): Int {
        val suppressed = suppressedMatureDomain(topicText, matureDomain) != "none"
        return when {
            suppressed -> 35
            preferredLane == "GENERAL_IMMUNE_DATASET_CLOSURE_LANE" -> 55
            preferredLane.contains("RNA_TRANSCRIPTOMIC") && containsAny(topicText, "rna", "transcript", "mrna", "scrna") -> 94
            preferredLane.contains("HERB_EXPOSURE") && containsAny(topicText, "ashwagandha", "curcumin", "quercetin", "herb") -> 90
            preferredLane.contains("DRUG_PERTURBATION_IMMUNE_CONTROL") && containsAny(topicText, "rituximab", "loratadine", "immunomodulator") -> 90
            preferredLane.contains("VACCINE") && containsAny(topicText, "vaccine", "vaccination", "immunization") -> 92
            preferredLane.contains("ANTIBIOTIC", true) || preferredLane.contains("DRUG_PERTURBATION", true) -> 90
            preferredLane.contains("SLEEP", true) || preferredLane.contains("CIRCADIAN", true) -> 90
            preferredLane.contains("FATIGUE", true) || preferredLane.contains("MITOCHONDRIAL", true) -> 88
            preferredLane.contains("METABOLIC_SUGAR_SALT", true) -> 90
            preferredLane.contains("ENVIRONMENTAL", true) || preferredLane.contains("AEROALLERGEN", true) -> 90
            preferredLane.contains("PSYCHONEUROENDOCRINE", true) || preferredLane.contains("STRESS", true) -> 90
            preferredLane.contains("ENDOCRINE", true) || preferredLane.contains("HORMONE", true) -> 90
            preferredLane.contains("DIGESTIVE", true) || preferredLane.contains("FOOD", true) -> 88
            preferredLane.contains("PHYSICAL_LIGHT", true) || preferredLane.contains("RADIATION", true) -> 88
            preferredLane.contains("TOXIN", true) || preferredLane.contains("SUBSTANCE", true) -> 88
            preferredLane.contains("AGE_LIFE_STAGE", true) -> 88
            else -> 72
        }
    }

    private fun buildMissingGates(metadataClosure: MetadataClosureReport, parsedMetadata: List<ParsedDatasetMetadata>): List<String> {
        val fromClosure = metadataClosure.missingFields
        val parsedGaps = buildList {
            if (parsedMetadata.isEmpty()) {
                add("minimum_metadata")
                add("accession")
            }
            if (parsedMetadata.none { it.controlLabels.isNotEmpty() }) add("control_or_comparator")
            if (parsedMetadata.none { it.outcomeLabels.isNotEmpty() }) add("outcome_labels")
            if (parsedMetadata.none { it.timeCourseLabels.isNotEmpty() }) add("time_order")
        }
        return (fromClosure + parsedGaps)
            .map { it.replace("comparator_control", "control_or_comparator") }
            .distinct()
            .take(10)
    }


    private fun controlledContextSeeds(topicText: String, preferredLane: String, longevity: LongevityBiologicalSystemsReport): List<String> {
        val seeds = mutableListOf<String>()
        seeds += EnvironmentalPsychophysiologicalExposomeLaneV11050.contextSeeds(topicText, preferredLane, longevity.selectedLane)
        when (preferredLane) {
            "METABOLIC_SUGAR_SALT_IMMUNE_CARDIO_LANE" -> seeds += listOf("sugar", "glucose", "HbA1c", "insulin", "salt", "sodium", "blood pressure", "osmotic stress", "CRP", "IL-6", "TNF-alpha", "lipids", "urine sodium", "baseline", "matched control", "exposed unexposed")
            "ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE" -> seeds += listOf("dust", "pollen", "mold", "air pollution", "PM2.5", "humidity", "temperature", "odor/fragrance", "IgE", "eosinophil", "nasal/airway barrier", "exposed unexposed", "seasonal baseline", "negative control")
            "PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE" -> seeds += listOf("psychological stress", "HPA axis", "cortisol", "depression", "anxiety", "sleep quality", "HRV", "CRP", "IL-6", "TNF-alpha", "diurnal rhythm", "matched control")
            "ENDOCRINE_HORMONE_HPA_IMMUNE_LANE" -> seeds += listOf("hormones", "cortisol", "estrogen", "progesterone", "testosterone", "thyroid", "insulin", "melatonin", "immune cytokines", "cycle phase", "baseline", "matched control")
            "DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE" -> seeds += listOf("gastric acidity", "stomach pH", "reflux", "digestive enzymes", "food exposure", "meal timing", "microbiome", "barrier tissue", "CRP", "IgE", "baseline", "exposed unexposed")
            "PHYSICAL_LIGHT_RADIATION_CIRCADIAN_IMMUNE_LANE" -> seeds += listOf("light exposure", "UV", "radiation", "blue light", "screen exposure", "moon/lunar", "season", "temperature", "circadian", "melatonin", "cortisol", "time-course")
            "TOXIN_SUBSTANCE_EXPOSURE_IMMUNE_LANE" -> seeds += listOf("alcohol", "smoking", "tobacco", "nicotine", "substance exposure", "drug exposure", "airway inflammation", "liver immune markers", "baseline", "exposed unexposed", "no advice", "negative control")
            "AGE_LIFE_STAGE_IMMUNE_CONTEXT_LANE" -> seeds += listOf("age", "older adults", "life stage", "immunosenescence", "CMV serostatus", "T-cell subsets", "CRP", "IL-6", "TNF-alpha", "matched age control", "comorbidity", "medication context")
            "RNA_TRANSCRIPTOMIC_IMMUNE_STATE_LANE" -> seeds += listOf("RNA-seq", "single-cell", "transcriptome", "gene expression", "GSE", "PRJNA", "control", "time-course", "responder non-responder", "batch effect", "cell composition")
            "GENETIC_EPIGENETIC_IMMUNE_VARIANT_LANE" -> seeds += listOf("genotype", "variant", "HLA", "methylation", "epigenetic", "cohort", "matched control", "replication", "negative control")
            "HERB_EXPOSURE_HPA_IMMUNE_MODULATION_LANE" -> seeds += listOf("herb exposure", "ashwagandha", "curcumin", "quercetin", "HPA axis", "cortisol", "cytokine", "placebo", "baseline", "exposed unexposed", "no supplement advice")
            "DRUG_PERTURBATION_IMMUNE_CONTROL_LANE" -> seeds += listOf("drug perturbation", "immunomodulator", "exposed unexposed", "baseline", "responder non-responder", "matched control", "no dose", "no treatment claim")
            "VACCINE_IMMUNE_RESPONSE_LANE" -> seeds += listOf("vaccine response", "human cohort", "neutralizing antibody", "T-cell response", "control", "time-course", "adverse immune response", "nonresponse")
            "IMMUNE_AGING_VACCINE_RESPONSE_LANE" -> seeds += listOf("CMV serostatus", "T-cell exhaustion", "immunosenescence", "vaccine response", "older adults", "CRP", "IL-6", "negative control")
            "DRUG_PERTURBATION_MICROBIOME_BARRIER_IMMUNE_LANE" -> seeds += listOf("antibiotics", "microbiome", "barrier tissue", "dysbiosis", "inflammation", "control cohort", "before after", "no association")
            "CIRCADIAN_SLEEP_INTELLIGENCE" -> seeds += listOf("sleep", "circadian", "cortisol", "HRV", "CRP", "IL-6", "light exposure", "night eating", "null result")
            "MITOCHONDRIAL_FATIGUE_LANE" -> seeds += listOf("mitochondrial", "fatigue", "Long COVID", "ME/CFS", "metabolomics", "oxidative stress", "matched control", "failed replication")
            "IMMUNE_AGING_IMMUNOSENESCENCE_LANE" -> seeds += listOf("CMV", "T-cell subsets", "T-cell exhaustion", "CRP", "IL-6", "TNF-alpha", "older adults", "no association")
            "TYPE2_ALLERGY_MAST_CELL_LANE" -> seeds += listOf("histamine", "mast cell", "IgE", "eosinophil", "allergy", "control", "negative control", "heterogeneity")
            else -> seeds += listOf("human cohort", "dataset accession", "outcome labels", "control comparator", "time order", "contradiction")
        }
        if (topicText.contains("ebv") || topicText.contains("epstein") || longevity.selectedLane.contains("IMMUNE_AGING")) seeds += listOf("EBV", "HHV-6", "CMV", "molecular mimicry", "failed replication")
        if (topicText.contains("hpa") || topicText.contains("stress") || topicText.contains("cortisol")) seeds += listOf("HPA axis", "cortisol", "stress immune", "diurnal rhythm")
        return seeds.distinct().take(12)
    }

    private fun softProgressionGates(missing: List<String>): List<String> {
        val allowed = setOf("minimum_metadata", "accession", "control_or_comparator", "outcome_labels", "time_order", "sample_size", "condition_labels", "license_access")
        return missing.filter { it in allowed }.distinct()
    }

    private fun hardClaimGates(missing: List<String>): List<String> {
        return (missing + listOf("contradiction_or_negative_control", "human_or_patient_data", "no_treatment_or_dose_claim"))
            .map { it.replace("comparator_control", "control_or_comparator") }
            .distinct()
            .take(12)
    }


    private fun topicRouteCorrectionStatus(topicText: String, preferredLane: String, matureDomain: String, suppressed: String): String {
        val stale = suppressed != "none"
        val raw = topicText.ifBlank { "unknown" }
        return when {
            stale -> "TOPIC_ROUTE_OVERRIDE_APPLIED: topic=$raw; preferred=$preferredLane; suppressed=$suppressed"
            matureDomain.lowercase().contains("antihistamine") && preferredLane != "TYPE2_ALLERGY_MAST_CELL_LANE" -> "TOPIC_ROUTE_OVERRIDE_RECOMMENDED: topic=$raw; preferred=$preferredLane; stale=$matureDomain"
            preferredLane == "GENERAL_IMMUNE_DATASET_CLOSURE_LANE" -> "TOPIC_ROUTE_GENERAL_FALLBACK"
            else -> "TOPIC_ROUTE_CONFIRMED: $preferredLane"
        }
    }

    private fun comparatorHuntMode(missing: List<String>, parsedMetadata: List<ParsedDatasetMetadata>): String {
        val needsControl = "control_or_comparator" in missing || parsedMetadata.any { it.controlLabels.isEmpty() }
        return if (needsControl) {
            "COMPARATOR_HUNT_MODE: healthy control | matched control | placebo | responder vs non-responder | baseline | exposed vs unexposed | untreated | negative control"
        } else {
            "COMPARATOR_CLOSED_OR_NOT_REQUIRED"
        }
    }

    private fun buildEvidenceObjectCandidates(
        parsedMetadata: List<ParsedDatasetMetadata>,
        preferredLane: String,
        missing: List<String>
    ): List<EvidenceObjectCandidateV11049> {
        return parsedMetadata
            .filter { item ->
                item.metadataQualityScore >= 70 &&
                    (item.outcomeLabels.isNotEmpty() || item.contrastiveSlots.isNotEmpty()) &&
                    item.controlLabels.isEmpty() &&
                    item.usabilityVerdict != "USABLE_FOR_TEST"
            }
            .take(3)
            .mapIndexed { index, item ->
                EvidenceObjectCandidateV11049(
                    candidateId = "EOC_v11049_${index + 1}_${item.accession.take(24)}",
                    accession = item.accession,
                    status = RouteReconciliationEvidenceCandidateV11051.candidateStatus(missing),
                    route = preferredLane,
                    metadataScore = item.metadataQualityScore,
                    closedGates = listOfNotNull(
                        "minimum_metadata",
                        if (item.accession.isNotBlank()) "accession_or_source_id" else null,
                        if (item.outcomeLabels.isNotEmpty()) "outcome_labels" else null,
                        if (item.timeCourseLabels.isNotEmpty()) "time_order" else null,
                        if (item.conditionLabels.isNotEmpty()) "condition_labels" else null
                    ).distinct(),
                    missingGates = (missing + listOf("control_or_comparator", "contradiction_or_negative_control")).distinct(),
                    nextAction = "Find healthy/matched/placebo/responder-vs-nonresponder/baseline/negative-control labels for ${item.accession}; then run contradiction/null-result search. Do not create EvidenceObject until control and contradiction gates close."
                )
            }
    }

    private fun contextAlignmentStatus(
        topicText: String,
        contextSeeds: List<String>,
        suppressed: String,
        candidateAction: CandidateActionReport
    ): String {
        return when {
            contextSeeds.isNotEmpty() && candidateAction.minimumMetadataAccessions.isNotEmpty() -> "CONTEXT_ALIGNED_METADATA_PROBE_READY"
            contextSeeds.isNotEmpty() && suppressed != "none" -> "CONTEXT_ALIGNED_STALE_PRIOR_SUPPRESSED"
            contextSeeds.isNotEmpty() && topicText.isNotBlank() -> "CONTEXT_ALIGNED_SECONDARY_LOOKUP_READY"
            else -> "NO_CONTEXT_ALIGNMENT"
        }
    }

    private fun containsAny(text: String, vararg terms: String): Boolean = terms.any { text.contains(it.lowercase()) }
}
