package com.immunesignal.app

/**
 * v2.7.7.4 — Final Execution Readiness Closure.
 *
 * This is the closing surface for the v2.7.7 execution line. It does not create
 * a new discovery route. It summarizes the already-linked Matrix/DGE execution
 * bridge and Treatment execution bridge into one reviewer-readable final state.
 * It keeps all treatment and DGE outputs research-only and claim-gated.
 */
data class GTIMFinalExecutionReadinessReportV2774(
    val active: Boolean,
    val state: String,
    val targetId: String,
    val readinessLine: String,
    val nextStepLine: String,
    val lockLine: String
) {
    companion object {
        fun empty(): GTIMFinalExecutionReadinessReportV2774 = GTIMFinalExecutionReadinessReportV2774(
            active = false,
            state = "NOT_EVALUATED",
            targetId = "NO_TARGET",
            readinessLine = "Final execution readiness: not evaluated.",
            nextStepLine = "Final next step: not evaluated.",
            lockLine = "Final locks: research-only; no clinical or biological claim."
        )
    }
}

object GTIMFinalExecutionReadinessV2774 {
    const val VERSION: String = "2.7.7.4-final-execution-readiness-closure"
    const val CLAIM_LIMIT: String = "final_execution_readiness_only_not_biological_or_clinical_claim"

    fun build(
        matrixAuditCard: GTIMMatrixAuditCardReportV2745,
        treatmentKnowledge: GTIMTreatmentKnowledgeReportV2772,
        treatmentExecution: GTIMTreatmentExecutionBridgeReportV2773
    ): GTIMFinalExecutionReadinessReportV2774 {
        if (!matrixAuditCard.active) return GTIMFinalExecutionReadinessReportV2774.empty()

        val target = matrixAuditCard.targetId.ifBlank { "NO_TARGET" }
        val hasTarget = target != "NO_TARGET" &&
            !target.contains("NO_ACCESSION", ignoreCase = true) &&
            !target.contains("NO_TOPIC_COMPATIBLE", ignoreCase = true)
        val dgeState = matrixAuditCard.dgeExecutionState.ifBlank { "DGE_EXECUTION_NOT_EVALUATED" }
        val treatmentState = if (treatmentExecution.active) treatmentExecution.state else "TREATMENT_NOT_ACTIVE"
        val researchValue = matrixAuditCard.researchValueState.ifBlank { "RESEARCH_VALUE_NOT_ASSIGNED" }
        val hasActionableSoftLead = researchValue.contains("ACTIONABLE", ignoreCase = true) ||
            researchValue.contains("REVIEW_LEAD", ignoreCase = true) ||
            researchValue.contains("SOFT", ignoreCase = true)
        val hasDgeBridge = dgeState.contains("BRIDGE", ignoreCase = true) ||
            dgeState.contains("METADATA_ENGINEERING", ignoreCase = true) ||
            dgeState.contains("MATRIX_LOADED", ignoreCase = true) ||
            dgeState.contains("ACCESSION_LOOKUP", ignoreCase = true)
        val hasTreatmentBridge = treatmentExecution.active && treatmentState.contains("REVIEW_ONLY", ignoreCase = true)

        val state = when {
            hasTarget && hasDgeBridge && hasTreatmentBridge -> "FINAL_RESEARCH_EXECUTION_TARGET_WITH_TREATMENT_CONTEXT_REVIEW_ONLY"
            hasTarget && hasDgeBridge -> "FINAL_DGE_EXECUTION_TARGET_REVIEW_ONLY"
            hasTarget && hasActionableSoftLead -> "FINAL_ACTIONABLE_SOFT_RESEARCH_LEAD_REVIEW_ONLY"
            hasTarget -> "FINAL_ACCESSION_TARGET_NEEDS_EXECUTION_BRIDGE_REVIEW_ONLY"
            treatmentKnowledge.active -> "FINAL_TREATMENT_CONTEXT_NEEDS_DATASET_TARGET_REVIEW_ONLY"
            else -> "FINAL_TOPIC_NEEDS_DATASET_TARGET_REVIEW_ONLY"
        }

        val topGaps = matrixAuditCard.blockingGaps.take(3).joinToString("; ").ifBlank { "no matrix gaps surfaced" }
        val treatmentLanes = treatmentKnowledge.matchedLanes.take(4).joinToString(",").ifBlank { "none" }
        val readiness = "Final execution readiness: version=$VERSION | state=$state | target=$target | dge=$dgeState | treatment=$treatmentState | research_value=$researchValue | treatment_lanes=$treatmentLanes | claim=$CLAIM_LIMIT"
        val next = nextStepFor(state, target, matrixAuditCard, treatmentExecution, topGaps)
        val locks = "Final locks: observed-only signals; raw/count matrix + sample metadata + comparator labels required before DGE; treatment lanes are research routing only; no treatment advice, no dosing, no clinical management, no efficacy claim, no patient-specific decision."

        return GTIMFinalExecutionReadinessReportV2774(
            active = true,
            state = state,
            targetId = target,
            readinessLine = normalizeLine(readiness),
            nextStepLine = normalizeLine(next),
            lockLine = normalizeLine(locks)
        )
    }

    fun compactLine(report: GTIMFinalExecutionReadinessReportV2774): String = report.readinessLine

    private fun nextStepFor(
        state: String,
        target: String,
        matrixAuditCard: GTIMMatrixAuditCardReportV2745,
        treatmentExecution: GTIMTreatmentExecutionBridgeReportV2773,
        topGaps: String
    ): String {
        val dgeNext = matrixAuditCard.dgeExecutionNextLine
            .removePrefix("DGE execution next:")
            .trim()
            .ifBlank { "fetch matrix, parse metadata, map comparator labels" }
        val treatmentNext = if (treatmentExecution.active) {
            treatmentExecution.nextActionLine.removePrefix("Treatment execution next:").trim()
        } else {
            "no treatment execution lane active"
        }
        return when {
            state.contains("TREATMENT_CONTEXT", ignoreCase = true) ->
                "Final next step: $target -> close matrix/sample/comparator gates, then map treatment/resistance/trial labels; dge_next=$dgeNext; treatment_next=$treatmentNext | gaps=$topGaps | boundary=review-only."
            state.contains("DGE_EXECUTION_TARGET", ignoreCase = true) ->
                "Final next step: $target -> complete DGE execution bridge first; dge_next=$dgeNext | gaps=$topGaps | boundary=review-only."
            state.contains("SOFT_RESEARCH_LEAD", ignoreCase = true) ->
                "Final next step: $target -> promote soft lead only by fetching raw/count matrix and standardizing sample metadata/comparator labels | gaps=$topGaps | boundary=review-only."
            state.contains("ACCESSION_TARGET", ignoreCase = true) ->
                "Final next step: $target -> resolve dataset object, matrix file, sample metadata, and comparator labels before any DGE interpretation | gaps=$topGaps | boundary=review-only."
            else ->
                "Final next step: feed a topic-compatible dataset accession or manual matrix URL/file seed; keep output as research lead only | boundary=review-only."
        }
    }

    private fun normalizeLine(value: String): String = value
        .replace(Regex("\\s+"), " ")
        .trim()
}
