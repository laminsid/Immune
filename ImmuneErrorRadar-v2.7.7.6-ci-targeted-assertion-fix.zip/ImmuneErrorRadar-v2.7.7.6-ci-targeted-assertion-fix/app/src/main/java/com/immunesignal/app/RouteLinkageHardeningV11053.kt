package com.immunesignal.app

/**
 * v1.10.53: CI route-linkage hardening.
 *
 * This is a wiring/quality release only. It closes the gap where v1.10.51/v1.10.52
 * fields were computed but not passed into TopicFitMetadataParseReport, causing JSON,
 * UI, exporter, and learning notes to fall back to defaults. It does not change the
 * scientific evidence threshold and never creates diagnosis, treatment, dose, or drug
 * ranking output.
 */
object RouteLinkageHardeningV11053 {
    const val VERSION_LABEL: String = "v1.10.53-alpha-ci-route-linkage-hardening"
    const val CLAIM_LIMIT: String = "route_linkage_hardening_not_biological_proof"
    const val RETURN_FIELD_CLOSURE: String = "TOPIC_FIT_REPORT_RETURN_FIELDS_CLOSED"

    val requiredReportReturnFields: List<String> = listOf(
        "legacyRouteReconciliationStatus",
        "reconciledMatureDomainFocus",
        "reconciledQuerySeed",
        "comparatorHuntQueries",
        "legacySuppressionNotes",
        "openExplorationMode",
        "diagnosticReasoningMode",
        "medicalIndexTerms",
        "medicalTermSummaries",
        "dynamicNodesOpened",
        "exploratoryRouteCandidates",
        "exploratoryLinkQueries",
        "diagnosticReasoningLines",
        "openExplorationGuardrails"
    )

    fun reportLinkageSummary(): String =
        "$RETURN_FIELD_CLOSURE: ${requiredReportReturnFields.size} fields now propagate from TopicFit evaluation into JSON/UI/export/report surfaces; claim-limit=$CLAIM_LIMIT"
}
