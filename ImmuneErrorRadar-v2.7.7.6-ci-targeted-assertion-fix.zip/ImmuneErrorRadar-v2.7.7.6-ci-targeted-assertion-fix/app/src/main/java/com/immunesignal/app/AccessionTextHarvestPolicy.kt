package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.24: Abstract Accession Text Harvest.
 *
 * PubMed accession-mining often succeeds only after abstract/data-availability
 * text is fetched. This policy extracts a small, reviewable evidence-text digest
 * from abstracts and availability-like sentences so DatasetAccessionResolver can
 * inspect GSE/PRJNA/SRP/E-MTAB/SDY identifiers without storing whole abstracts
 * in the main finding object.
 *
 * This is retrieval support only: it does not prove biology, diagnosis,
 * treatment, drug response, or causality.
 */
object AccessionTextHarvestPolicy {
    const val CLAIM_LIMIT = "abstract_accession_harvest_not_biological_proof"
    private const val MAX_DIGEST_CHARS = 1400

    private val accessionRegex = Regex(
        """\b(GSE\s*\d+|GSM\s*\d+|GDS\s*\d+|SDY\s*\d+|PRJNA\s*\d+|PRJEB\s*\d+|PRJDB\s*\d+|SRP\s*\d+|SRA\s*\d+|SRR\s*\d+|SRX\s*\d+|SRS\s*\d+|ERR\s*\d+|ERX\s*\d+|ERP\s*\d+|DRR\s*\d+|DRX\s*\d+|DRP\s*\d+|E-MTAB-\s*\d+|E-GEOD-\s*\d+|E-MEXP-\s*\d+|EGAS\s*\d+|SAMN\s*\d+|SAMEA\s*\d+|SAMD\s*\d+|phs\s*\d+(?:\.v\d+\.p\d+)?)\b""",
        RegexOption.IGNORE_CASE
    )

    private val harvestTerms = listOf(
        "data availability", "data are available", "deposited", "accession", "geo", "gene expression omnibus",
        "sra", "sequence read archive", "bioproject", "biosample", "arrayexpress", "ega", "immport", "dbgap",
        "dataset", "supplementary data", "expression matrix", "sample metadata", "phenotype", "clinical cohort",
        "rna-seq", "rnaseq", "transcriptome", "transcriptomic", "single-cell", "scrna-seq",
        "outcome", "severity", "recovery", "responder", "nonresponder", "non-responder", "longitudinal",
        "time-course", "follow-up", "baseline", "control", "comparator", "placebo",
        "histamine", "mast cell", "antihistamine", "inflammation", "inflammatory", "diabetes", "hba1c",
        "aging", "immunosenescence", "inflammaging", "reflux", "gerd", "gastric acid", "gut barrier", "drug perturbation", "medication exposure"
    )

    fun digest(text: String): String {
        if (text.isBlank()) return ""
        val normalized = text.replace(Regex("\\s+"), " ").trim()
        val sentences = normalized
            .split(Regex("(?<=[.!?])\\s+|\\n+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
        val selected = mutableListOf<String>()
        val explicitMatches = accessionRegex.findAll(normalized)
            .map { it.value.trim() }
            .distinctBy { it.uppercase(Locale.US).replace(Regex("\\s+"), "") }
            .take(12)
            .toList()
        if (explicitMatches.isNotEmpty()) {
            selected += "Accession-like IDs: ${explicitMatches.joinToString(", ")}."
        }
        for (sentence in sentences) {
            val lower = sentence.lowercase(Locale.US)
            val hasHarvestTerm = harvestTerms.any { lower.contains(it) }
            val hasAccession = accessionRegex.containsMatchIn(sentence)
            if (hasAccession || hasHarvestTerm) {
                selected += sentence.take(360)
            }
            if (selected.joinToString(" ").length >= MAX_DIGEST_CHARS) break
        }
        return selected
            .distinct()
            .joinToString(" ")
            .take(MAX_DIGEST_CHARS)
    }

    fun flags(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val lower = text.lowercase(Locale.US)
        val out = mutableListOf<String>()
        if (accessionRegex.containsMatchIn(text)) out += "ACCESSION_TEXT_SIGNAL"
        if (listOf("data availability", "deposited", "accession", "geo", "sra", "bioproject", "arrayexpress", "immport", "dbgap").any { lower.contains(it) }) {
            out += "DATA_AVAILABILITY_TEXT_SIGNAL"
        }
        if (listOf("histamine", "mast cell", "antihistamine", "diabetes", "reflux", "gerd", "immunosenescence", "inflammaging", "drug perturbation").any { lower.contains(it) }) {
            out += "DOMAIN_TEXT_SIGNAL"
        }
        return out.distinct()
    }

    fun summary(): String = "v1.10.24 abstract accession harvest: use abstract/data-availability snippets for accession parsing without treating them as biological proof."
}
