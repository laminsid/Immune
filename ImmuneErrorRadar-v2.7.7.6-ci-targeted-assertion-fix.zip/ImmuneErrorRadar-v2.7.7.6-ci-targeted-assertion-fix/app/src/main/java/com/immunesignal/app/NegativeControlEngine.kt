package com.immunesignal.app

object NegativeControlEngine {
    fun assess(axes: List<String>, causalityPreview: Int = 0): NegativeControlAssessment {
        val notes = mutableListOf<String>()
        val reverseRisk = if (axes.size >= 2) "needs_reverse_time_test" else "low_information"
        val shuffledRisk = if (axes.size >= 3) "needs_shuffle_test" else "not_enough_axes"
        val unrelatedRisk = when {
            axes.contains("psychoneuroimmune_axis") && axes.contains("autonomic_vascular_axis") -> "moderate_check_required"
            axes.contains("dna_genomic_axis") || axes.contains("rna_transcriptomic_axis") -> "high_requires_dataset_control"
            else -> "standard_check"
        }
        notes += "Reverse-time control: outcome should not predict earlier exposure."
        notes += "Shuffled-timeline control: relation should weaken when dates are randomized."
        notes += "Unrelated-marker control: a biologically unrelated marker should not score equally strong."
        val status = when {
            causalityPreview >= 70 && axes.size >= 2 -> "control_required_before_strong"
            axes.size >= 2 -> "watch_requires_controls"
            else -> "weak_no_control_possible"
        }
        return NegativeControlAssessment(
            status = status,
            reverseTimeRisk = reverseRisk,
            shuffledTimelineRisk = shuffledRisk,
            unrelatedMarkerRisk = unrelatedRisk,
            notes = notes
        )
    }
}
