package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.38: Immune Evidence Prior Matrix.
 *
 * This replaces unsafe broad context injection with a small, auditable prior selector.
 * Priors only choose lookup terms and gates. They never prove EBV, molecular mimicry,
 * treatment effect, supplement value, diagnosis, or causality.
 */
data class EvidencePriorSelectionReport(
    val active: Boolean,
    val state: String,
    val selectedPriorId: String,
    val selectedRoute: String,
    val reason: String,
    val queryTerms: List<String>,
    val requiredGates: List<String>,
    val forbiddenClaims: List<String>,
    val invalidators: List<String>,
    val noiseGuards: List<String>,
    val blockedInjection: Boolean,
    val nextAction: String,
    val claimLimit: String = ImmuneEvidencePriorMatrix.CLAIM_LIMIT
) {
    companion object {
        fun empty() = EvidencePriorSelectionReport(
            active = false,
            state = "NOT_EVALUATED",
            selectedPriorId = "none",
            selectedRoute = "none",
            reason = "No evidence prior was evaluated.",
            queryTerms = emptyList(),
            requiredGates = emptyList(),
            forbiddenClaims = emptyList(),
            invalidators = emptyList(),
            noiseGuards = emptyList(),
            blockedInjection = false,
            nextAction = "No evidence-prior action available."
        )
    }
}

object ImmuneEvidencePriorMatrix {
    const val CLAIM_LIMIT: String = "evidence_prior_matrix_routing_only_not_biological_proof"

    private data class PriorRule(
        val id: String,
        val route: String,
        val tier: String,
        val triggers: List<String>,
        val queryTerms: List<String>,
        val requiredGates: List<String>,
        val forbiddenClaims: List<String>,
        val invalidators: List<String>,
        val disabledByDefault: Boolean = false
    )

    private val defaultRequiredGates = listOf(
        "accession_or_source_id",
        "human_or_patient_data",
        "outcome_labels",
        "control_or_comparator",
        "time_order",
        "contradiction_or_negative_control"
    )

    private val commonForbiddenClaims = listOf(
        "biological proof",
        "causal claim",
        "diagnosis",
        "treatment recommendation",
        "drug ranking",
        "supplement recommendation",
        "first scientific breakthrough"
    )

    private val rules = listOf(
        PriorRule(
            id = "EBV_MOLECULAR_MIMICRY",
            route = "latent_virus_molecular_mimicry_route",
            tier = "A",
            triggers = listOf("ebv", "epstein", "ebna1", "molecular mimicry", "herpesviridae", "multiple sclerosis", "ms", "sle", "autoantibody"),
            queryTerms = listOf("EBV", "Epstein-Barr", "EBNA1", "molecular mimicry", "cross-reactive", "autoantibody", "B cell", "GSE", "PRJNA", "SRP", "SDY", "control", "longitudinal", "negative control"),
            requiredGates = defaultRequiredGates + listOf("ebv_or_herpesviridae_term", "molecular_mimicry_context"),
            forbiddenClaims = commonForbiddenClaims + listOf("EBV causality confirmed", "molecular mimicry confirmed", "autoimmune mechanism confirmed"),
            invalidators = listOf(
                "No EBV/Herpesviridae term appears in accession-level metadata.",
                "No molecular mimicry or cross-reactive context appears after secondary lookup.",
                "No control/comparator exists for the same dataset or cohort.",
                "Time order does not place EBV/reactivation before immune outcome.",
                "Contradiction or negative-control search explains the lead better."
            )
        ),
        PriorRule(
            id = "SARS_COV_2_RESOLUTION_FAILURE",
            route = "interferon_resolution_failure_route",
            tier = "A",
            triggers = listOf("sars-cov-2", "covid", "long covid", "post-viral", "interferon", "ifn", "resolution failure"),
            queryTerms = listOf("SARS-CoV-2", "Long COVID", "interferon", "IFN-alpha", "IFN-beta", "ISG", "CXCL10", "recovery", "severity", "longitudinal", "control", "GSE", "PRJNA"),
            requiredGates = defaultRequiredGates + listOf("viral_context", "recovery_or_severity_label"),
            forbiddenClaims = commonForbiddenClaims + listOf("viral persistence confirmed", "protection against variants"),
            invalidators = listOf("No longitudinal recovery/severity labels are found.", "No viral or interferon term appears in metadata.", "Control/comparator remains absent.")
        ),
        PriorRule(
            id = "SLE_INTERFERON_AUTOANTIBODY",
            route = "sle_interferon_autoantibody_route",
            tier = "A",
            triggers = listOf("sle", "lupus", "anti-dsdna", "ana", "flare", "interferon", "ifn-alpha", "ifn beta"),
            queryTerms = listOf("SLE", "lupus", "IFN-alpha", "IFN-beta", "anti-dsDNA", "ANA", "flare", "disease activity", "cohort", "SDY", "GSE", "control", "longitudinal"),
            requiredGates = defaultRequiredGates + listOf("autoantibody_or_interferon_context", "flare_or_activity_label"),
            forbiddenClaims = commonForbiddenClaims + listOf("SLE mechanism confirmed"),
            invalidators = listOf("No SLE/flare/activity labels are found.", "No interferon or autoantibody context appears.", "No longitudinal/control signal appears.")
        ),
        PriorRule(
            id = "MS_CNS_BARRIER_EBV",
            route = "ms_cns_barrier_latent_virus_route",
            tier = "A",
            triggers = listOf("multiple sclerosis", "ms", "cns", "blood brain barrier", "glialcam", "ebv", "ebna1"),
            queryTerms = listOf("multiple sclerosis", "MS", "EBV", "EBNA1", "GlialCAM", "CNS", "blood-brain barrier", "B cell", "GSE", "PRJNA", "control", "longitudinal"),
            requiredGates = defaultRequiredGates + listOf("cns_or_barrier_context"),
            forbiddenClaims = commonForbiddenClaims + listOf("MS causality confirmed"),
            invalidators = listOf("No CNS/barrier or MS context is found.", "EBV terms do not survive accession-level lookup.", "No matched control exists.")
        ),
        PriorRule(
            id = "CMV_IMMUNOSENESCENCE",
            route = "cmv_immunosenescence_route",
            tier = "B",
            triggers = listOf("cmv", "cytomegalovirus", "immunosenescence", "aging", "senescence", "t cell"),
            queryTerms = listOf("CMV", "cytomegalovirus", "immunosenescence", "aging", "T cell", "cohort", "control", "GSE", "PRJNA", "longitudinal"),
            requiredGates = defaultRequiredGates + listOf("age_or_senescence_context"),
            forbiddenClaims = commonForbiddenClaims + listOf("immune aging mechanism confirmed"),
            invalidators = listOf("No CMV term appears in metadata.", "Age/senescence context is absent.", "No comparator/control is found.")
        ),
        PriorRule(
            id = "DRUG_PERTURBATION_CONTROL",
            route = "drug_perturbation_control_route",
            tier = "B",
            triggers = listOf("prednisone", "glucocorticoid", "rituximab", "anti-cd20", "jak inhibitor", "baricitinib", "tofacitinib", "drug", "medication"),
            queryTerms = listOf("glucocorticoid", "prednisone", "rituximab", "anti-CD20", "JAK inhibitor", "drug perturbation", "exposure", "control", "GSE", "PRJNA", "no treatment", "no dose"),
            requiredGates = defaultRequiredGates + listOf("exposure_or_perturbation_context", "no_treatment_claim"),
            forbiddenClaims = commonForbiddenClaims + listOf("dose recommendation", "drug efficacy claim"),
            invalidators = listOf("Dataset only supports treatment narrative without controls.", "No exposure/control metadata exists.", "The route becomes drug advice rather than research perturbation." )
        ),
        PriorRule(
            id = "NATURAL_COMPOUND_NOISE_CONTROL",
            route = "natural_compound_perturbation_noise_control",
            tier = "C",
            triggers = listOf("curcumin", "turmeric", "ashwagandha", "quercetin", "nf-kb", "nrf2", "mast cell stabilizer"),
            queryTerms = listOf("curcumin", "quercetin", "ashwagandha", "NF-kB", "oxidative stress", "perturbation", "control", "transcriptome", "no supplement advice"),
            requiredGates = defaultRequiredGates + listOf("supplement_noise_guard", "human_dataset_or_cell_context_declared"),
            forbiddenClaims = commonForbiddenClaims + listOf("supplement efficacy", "natural treatment recommendation"),
            invalidators = listOf("Only supplement-marketing language appears.", "No dataset/accession exists.", "No control/comparator exists."),
            disabledByDefault = true
        )
    )

    fun select(
        steering: ResearchSteeringProfile?,
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        metadataClosure: MetadataClosureReport,
        routeReport: UnknownRouteClassificationReport,
        ebvReport: EBVLeadVerificationReport,
        recentReports: List<String>
    ): EvidencePriorSelectionReport {
        val corpus = buildCorpus(steering, leadObjects, candidates, routeReport, ebvReport, recentReports)
        val scored = rules.mapNotNull { rule ->
            val hits = rule.triggers.filter { corpus.contains(it.lowercase(Locale.US)) }.distinct()
            val routeBoost = if (routeReport.selectedRoute.contains(rule.route.substringBeforeLast("_route"), true)) 8 else 0
            val ebvBoost = if (rule.id == "EBV_MOLECULAR_MIMICRY" && ebvReport.active) 20 else 0
            val metadataBoost = if (metadataClosure.active && metadataClosure.missingFields.contains("accession")) 6 else 0
            val score = hits.size * 10 + routeBoost + ebvBoost + metadataBoost - if (rule.disabledByDefault) 25 else 0
            if (score <= 0) null else Triple(rule, hits, score)
        }.sortedByDescending { it.third }

        if (scored.isEmpty()) {
            return EvidencePriorSelectionReport.empty().copy(
                state = "NO_EVIDENCE_PRIOR_SELECTED",
                reason = "No prior matched the current lead, topic, or missing metadata fields; continue neutral lead closure.",
                blockedInjection = true,
                noiseGuards = listOf("No random context injection", "Use only accession/control/time-order lookup terms"),
                forbiddenClaims = commonForbiddenClaims,
                nextAction = "Run neutral secondary lookup: accession, source ID, outcome, control, and time-order fields."
            )
        }

        val (rule, hits, score) = scored.first()
        val missingGates = rule.requiredGates.filter { gate ->
            when (gate) {
                "accession_or_source_id" -> "accession" in metadataClosure.missingFields
                "human_or_patient_data" -> "human_or_patient_data" in metadataClosure.missingFields
                "outcome_labels" -> "outcome_labels" in metadataClosure.missingFields
                "control_or_comparator" -> "control_or_comparator" in metadataClosure.missingFields
                "time_order" -> "time_order" in metadataClosure.missingFields
                else -> true
            }
        }
        val state = when {
            rule.disabledByDefault -> "EVIDENCE_PRIOR_SUPPLEMENT_NOISE_GUARDED"
            rule.id == "EBV_MOLECULAR_MIMICRY" && ebvReport.active -> "EVIDENCE_PRIOR_EBV_CRITERION_SELECTED"
            missingGates.contains("accession_or_source_id") -> "EVIDENCE_PRIOR_SELECTED_NEEDS_ACCESSION"
            missingGates.any { it == "control_or_comparator" || it == "time_order" || it == "outcome_labels" } -> "EVIDENCE_PRIOR_SELECTED_METADATA_LOCKED"
            else -> "EVIDENCE_PRIOR_SELECTED_READY_FOR_CONTRADICTION"
        }
        val boundedTerms = rule.queryTerms
            .filterNot { it.contains("treatment", true) || it.contains("dose", true) || it.contains("advice", true) }
            .take(14)
        return EvidencePriorSelectionReport(
            active = true,
            state = state,
            selectedPriorId = rule.id,
            selectedRoute = rule.route,
            reason = "Selected ${rule.id} from tier ${rule.tier} because matched ${hits.take(6).joinToString(", ").ifBlank { "route prior" }}; score=$score. Random context injection is blocked.",
            queryTerms = boundedTerms,
            requiredGates = rule.requiredGates,
            forbiddenClaims = rule.forbiddenClaims.distinct(),
            invalidators = rule.invalidators,
            noiseGuards = buildNoiseGuards(rule),
            blockedInjection = true,
            nextAction = when (state) {
                "EVIDENCE_PRIOR_EBV_CRITERION_SELECTED" -> "Use EBV prior only inside secondary lookup for the carried lead: accession + EBV/EBNA1/molecular-mimicry terms + control + time-order; no breakthrough claim."
                "EVIDENCE_PRIOR_SELECTED_NEEDS_ACCESSION" -> "Use selected prior terms only to extract accession/source IDs, then parse minimum metadata."
                "EVIDENCE_PRIOR_SELECTED_METADATA_LOCKED" -> "Close missing gates for ${rule.id}: ${missingGates.take(5).joinToString(", ")}; do not run broad search."
                "EVIDENCE_PRIOR_SUPPLEMENT_NOISE_GUARDED" -> "Keep natural-compound prior disabled unless a dataset/accession and control metadata are visible."
                else -> "Run contradiction/negative-control micro-probe for ${rule.id}; keep all claims locked."
            }
        )
    }

    private fun buildNoiseGuards(rule: PriorRule): List<String> {
        val guards = mutableListOf(
            "No random.choice/context injection.",
            "Prior terms are lookup keys only, not belief updates.",
            "Require accession/control/time-order before contradiction search.",
            "Do not upgrade hypothesis without EvidenceObject."
        )
        if (rule.route.contains("drug", true)) guards += "Drug terms are perturbation/control vocabulary only; no treatment, dose, or ranking."
        if (rule.disabledByDefault) guards += "Natural compound prior is disabled by default to avoid supplement noise."
        return guards.distinct()
    }

    private fun buildCorpus(
        steering: ResearchSteeringProfile?,
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        routeReport: UnknownRouteClassificationReport,
        ebvReport: EBVLeadVerificationReport,
        recentReports: List<String>
    ): String {
        return (
            steering?.variables.orEmpty().joinToString(" ") + " " +
                steering?.focusQuestion.orEmpty() + " " +
                leadObjects.joinToString(" ") { listOf(it.leadId, it.title, it.snippet, it.domain, it.omicsType, it.dataAvailabilityText, it.detectedAccessions.joinToString(" ")).joinToString(" ") } + " " +
                candidates.joinToString(" ") { listOf(it.accession, it.sourceTitle, it.conditionLabelsHint, it.outcomeLabelsHint, it.timeCourseHint, it.dataType, it.reasons.joinToString(" ")).joinToString(" ") } + " " +
                routeReport.selectedRoute + " " + routeReport.routePriors.joinToString(" ") { it.routeId + " " + it.matchedTerms.joinToString(" ") } + " " +
                ebvReport.state + " " + ebvReport.matchedTerms.joinToString(" ") + " " +
                recentReports.take(6).joinToString(" ").take(10_000)
            ).lowercase(Locale.US)
    }
}
