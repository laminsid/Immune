package com.immunesignal.app

/**
 * v1.10.52: open exploration + medical term index + diagnostic reasoning sandbox.
 *
 * This deliberately relaxes discovery routing, not medical safety. The engine can open
 * new route nodes, connect weak signals more freely, and expose differential diagnostic
 * reasoning as a sandbox for understanding how it thinks. It still cannot output a
 * patient diagnosis, treatment choice, dose, drug ranking, or emergency triage decision.
 */
data class OpenExplorationProfileV11052(
    val active: Boolean,
    val mode: String,
    val diagnosticReasoningMode: String,
    val matchedTerms: List<String>,
    val medicalIndexTerms: List<String>,
    val termSummaries: List<String>,
    val dynamicNodes: List<String>,
    val dynamicNodesOpened: List<String>,
    val exploratoryRouteCandidates: List<String>,
    val exploratoryLinkQueries: List<String>,
    val reasoningLines: List<String>,
    val guardrails: List<String>,
    val claimLimit: String = OpenExplorationMedicalIndexV11052.CLAIM_LIMIT
)

object OpenExplorationMedicalIndexV11052 {
    const val VERSION_LABEL: String = "v1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox"
    const val EXPLORATION_MODE: String = "OPEN_EXPLORATION_LINKING_MODE"
    const val DIAGNOSTIC_REASONING_MODE: String = "DIFFERENTIAL_DIAGNOSTIC_REASONING_SANDBOX_NOT_PATIENT_DIAGNOSIS"
    const val CLAIM_LIMIT: String = "diagnostic_reasoning_sandbox_not_patient_diagnosis"

    data class MedicalTermCard(
        val key: String,
        val aliases: List<String>,
        val summary: String,
        val routeNodes: List<String>,
        val biomarkerKeys: List<String>,
        val contradictionTerms: List<String>
    )

    val coreMedicalTermIndex: List<MedicalTermCard> = listOf(
        MedicalTermCard(
            key = "EBV",
            aliases = listOf("ebv", "epstein-barr", "ebna1", "herpesviridae"),
            summary = "Latent-virus/reactivation and molecular-mimicry research prior; requires accession, EBV term, comparator, time order, and contradiction search.",
            routeNodes = listOf("latent_virus_reactivation", "molecular_mimicry", "b_cell_autoimmunity", "immune_aging"),
            biomarkerKeys = listOf("EBV serology", "EBNA1", "B cell", "autoantibody", "T-cell subsets"),
            contradictionTerms = listOf("no EBV association", "failed replication", "negative control", "CMV confounding")
        ),
        MedicalTermCard(
            key = "COVID / Long COVID",
            aliases = listOf("covid", "sars-cov-2", "long covid", "post-acute covid"),
            summary = "Viral-response and post-viral immune-state prior; separates viral load, interferon timing, inflammation, fatigue, and tissue/context labels.",
            routeNodes = listOf("interferon_antiviral_axis", "post_viral_fatigue", "mitochondrial_fatigue", "tissue_damage_context"),
            biomarkerKeys = listOf("IFN-alpha", "IFN-gamma", "IL-6", "TNF-alpha", "CRP", "metabolomics"),
            contradictionTerms = listOf("no association", "heterogeneity", "reverse timing", "unrelated marker control")
        ),
        MedicalTermCard(
            key = "SLE",
            aliases = listOf("sle", "lupus", "systemic lupus"),
            summary = "Autoimmune phenotype prior; useful for route contrast only until cohort labels, flare/recovery outcomes, controls, and time order are explicit.",
            routeNodes = listOf("autoimmune_flare", "b_cell_antibody_axis", "interferon_signature", "complement_consumption"),
            biomarkerKeys = listOf("ANA", "anti-dsDNA", "C3", "C4", "IFN signature", "B cells"),
            contradictionTerms = listOf("non-SLE control", "disease activity mismatch", "medication confounding", "failed replication")
        ),
        MedicalTermCard(
            key = "IL-6",
            aliases = listOf("il-6", "interleukin-6", "interleukin 6"),
            summary = "Inflammatory cytokine prior; marker direction needs outcome, timing, tissue/cell source, and comparator before any mechanism language.",
            routeNodes = listOf("cytokine_inflammation", "acute_phase_response", "stress_immune", "metabolic_inflammation"),
            biomarkerKeys = listOf("IL-6", "CRP", "TNF-alpha", "ESR"),
            contradictionTerms = listOf("null cytokine association", "batch effect", "cell composition artifact", "non-inflammatory control")
        ),
        MedicalTermCard(
            key = "CRP / TNF-alpha",
            aliases = listOf("crp", "tnf", "tnf-alpha", "tumor necrosis factor", "esr"),
            summary = "General inflammatory-marker prior; good for triage, weak for mechanism unless linked to specific exposure, route, tissue, and outcome labels.",
            routeNodes = listOf("systemic_inflammation", "metabolic_inflammation", "stress_inflammation", "tissue_damage"),
            biomarkerKeys = listOf("CRP", "TNF-alpha", "ESR", "IL-6"),
            contradictionTerms = listOf("non-specific marker", "no outcome link", "unrelated inflammation", "confounding")
        ),
        MedicalTermCard(
            key = "Sugar / Glucose / HbA1c",
            aliases = listOf("sugar", "glucose", "hba1c", "insulin", "diabetes", "glycemic", "السكر"),
            summary = "Metabolic exposure/context prior; opens glucose-insulin-inflammatory routing and requires fasting/postprandial timing, HbA1c/glucose/insulin, outcome, and matched controls.",
            routeNodes = listOf("sugar_glucose_insulin", "metabolic_inflammation", "mitochondrial_energy", "immune_activation"),
            biomarkerKeys = listOf("glucose", "HbA1c", "insulin", "HOMA-IR", "CRP", "IL-6", "lipids"),
            contradictionTerms = listOf("no glycemic association", "diet confounding", "BMI confounding", "reverse causality")
        ),
        MedicalTermCard(
            key = "Salt / Sodium / Osmotic stress",
            aliases = listOf("salt", "sodium", "hypertension", "blood pressure", "osmotic", "الملح", "الصوديوم", "ضغط الدم"),
            summary = "Electrolyte/osmotic/cardiometabolic context prior; links sodium, blood pressure, vascular inflammation, kidney context, and immune readouts.",
            routeNodes = listOf("salt_sodium_osmotic", "blood_pressure_vascular", "kidney_context", "immune_inflammation"),
            biomarkerKeys = listOf("sodium", "blood pressure", "aldosterone", "renin", "CRP", "IL-6", "urine sodium"),
            contradictionTerms = listOf("salt insensitive", "no BP change", "kidney confounding", "medication confounding")
        ),
        MedicalTermCard(
            key = "Stress / Cortisol / HPA",
            aliases = listOf("stress", "cortisol", "hpa", "depression", "anxiety", "التوتر", "الكورتيزول", "الاكتئاب"),
            summary = "Psychoneuroendocrine exposure prior; connects stress timing, cortisol rhythm, HRV, sleep, cytokines, and immune outcomes.",
            routeNodes = listOf("hpa_axis", "stress_immune", "circadian_cortisol", "psychoneuroimmune"),
            biomarkerKeys = listOf("cortisol", "HRV", "CRP", "IL-6", "TNF-alpha", "sleep quality"),
            contradictionTerms = listOf("no cortisol association", "reverse timing", "sleep confounding", "depression confounding")
        )
    )

    fun evaluate(topicText: String, preferredLane: String, contextSeeds: List<String>): OpenExplorationProfileV11052 {
        val lower = topicText.lowercase()
        val matched = coreMedicalTermIndex.filter { card -> card.aliases.any { lower.contains(it.lowercase()) } }
        val defaultCards = if (matched.isEmpty()) coreMedicalTermIndex.filter { it.key in listOf("IL-6", "CRP / TNF-alpha", "Sugar / Glucose / HbA1c", "Salt / Sodium / Osmotic stress") } else matched
        val nodes = (defaultCards.flatMap { it.routeNodes } + contextSeeds.map { seed -> "context:${seed.lowercase().replace(' ', '_')}" }).distinct().take(18)
        val routeCandidates = (defaultCards.flatMap { card ->
            listOf(
                "${card.key}: exposure → pathway → biomarker → dataset → outcome → comparator → contradiction",
                "${card.key}: compare positive/negative or exposed/unexposed cohorts before any claim"
            )
        } + listOf("Open node candidate: sugar/salt/metabolic-electrolyte context can branch into immune, vascular, endocrine, kidney, and mitochondrial routes.")).distinct().take(12)
        val queries = defaultCards.flatMap { card ->
            listOf(
                "${card.key} immune response human cohort ${card.biomarkerKeys.take(4).joinToString(" ")} control comparator outcome GSE PRJNA SDY",
                "${card.key} ${card.contradictionTerms.take(3).joinToString(" ")} negative control failed replication heterogeneity"
            )
        }.distinct().take(10)
        val reasoning = listOf(
            "Diagnostic reasoning sandbox is enabled for transparency: it may show differential possibilities and competing mechanisms, not a patient diagnosis.",
            "Open exploration may create new route nodes from weak signals; nodes must later be pruned, merged, or promoted by evidence gates.",
            "Current governing lane: $preferredLane.",
            "Matched medical index terms: ${defaultCards.map { it.key }.joinToString(", ")}.",
            "Reasoning format: possible route → supportive signals → missing discriminators → what would falsify it.",
            "Sugar and salt are first-class exposure/context nodes linked to glucose/insulin/HbA1c, sodium/BP/osmotic stress, inflammation, kidney/vascular context, and matched controls."
        )
        val guardrails = listOf(
            "Do not output a final diagnosis for a person.",
            "Do not output treatment, dose, drug ranking, supplement advice, or emergency triage.",
            "Differential reasoning must stay hypothetical and evidence-gated.",
            "Every new node needs comparator/control, time order, outcome labels, and contradiction/null search before strengthening."
        )
        return OpenExplorationProfileV11052(
            active = true,
            mode = EXPLORATION_MODE,
            diagnosticReasoningMode = DIAGNOSTIC_REASONING_MODE,
            matchedTerms = defaultCards.map { it.key },
            medicalIndexTerms = defaultCards.map { it.key },
            termSummaries = defaultCards.map { "${it.key}: ${it.summary}" },
            dynamicNodes = nodes,
            dynamicNodesOpened = nodes,
            exploratoryRouteCandidates = routeCandidates,
            exploratoryLinkQueries = queries,
            reasoningLines = reasoning,
            guardrails = guardrails
        )
    }
}
