package com.immunesignal.app

/**
 * FoundationConflictResolver: Handles conflicts between data and foundation knowledge
 * 
 * Key Principle:
 * Data challenging foundation ≠ immediate rejection
 * Instead: downgrade confidence, require more evidence, suggest patch
 * 
 * This prevents rigid gatekeeping while maintaining quality standards
 */

class FoundationConflictResolver {

    /**
     * Main conflict resolution logic
     * 
     * Returns action based on evidence coverage and criticality
     */
    fun resolve(
        axis: FoundationAxis,
        rankedAxis: RankedAxis,
        presentEvidence: List<String>,
        compensatingEvidence: List<CompensatingEvidence>,
        detectedConflations: List<String>
    ): ConflictResolution {

        // 1. Calculate required evidence coverage
        val requiredCoverage = calculateCoverage(
            present = presentEvidence,
            required = axis.requiredEvidence
        )

        // 2. Check for critical evidence
        val hasCriticalMissing = axis.criticalEvidence.any { it !in presentEvidence }

        // 3. Check forbidden conflations
        val hasConflations = detectedConflations.isNotEmpty()

        // 4. Evaluate compensation
        val compensationStrength = evaluateCompensation(compensatingEvidence)

        // 5. Determine action
        val action = determineAction(
            requiredCoverage = requiredCoverage,
            hasCriticalMissing = hasCriticalMissing,
            hasConflations = hasConflations,
            compensationStrength = compensationStrength,
            matchScore = rankedAxis.matchScore,
            presentEvidenceCount = presentEvidence.size
        )

        // 6. Generate detailed explanation
        val explanation = buildExplanation(
            axis = axis,
            action = action,
            requiredCoverage = requiredCoverage,
            presentEvidence = presentEvidence,
            missingEvidence = axis.requiredEvidence.filter { it !in presentEvidence },
            compensatingEvidence = compensatingEvidence,
            detectedConflations = detectedConflations
        )

        return ConflictResolution(
            action = action,
            actionExplanation = explanation,
            confidenceAdjustment = calculateConfidenceAdjustment(action),
            suggestedClaim = generateClaim(action, axis),
            nextSteps = generateNextSteps(action, axis)
        )
    }

    /**
     * Calculate what percentage of required evidence is present (0.0-1.0)
     */
    private fun calculateCoverage(
        present: List<String>,
        required: List<String>
    ): Float {
        if (required.isEmpty()) return 1f
        val coverage = present.count { it in required }.toFloat() / required.size
        return coverage.coerceIn(0f, 1f)
    }

    /**
     * Evaluate how well compensating evidence fills gaps
     */
    private fun evaluateCompensation(compensation: List<CompensatingEvidence>): Float {
        if (compensation.isEmpty()) return 0f
        return compensation.map { it.compensationStrength }.average().toFloat()
    }

    /**
     * Core decision logic
     * 
     * Formula:
     * if requiredCoverage >= 0.85 && !criticalMissing → PROCEED
     * else if requiredCoverage >= 0.60 && compensation > 0.5 → PROCEED_WITH_CAUTION
     * else if requiredCoverage >= 0.40 → REQUIRE_MORE_EVIDENCE
     * else if matchScore < 0.35 → DOWNGRADE_TO_ANALOGY
     * else → BLOCK_HYPOTHESIS_UPGRADE
     */
    private fun determineAction(
        requiredCoverage: Float,
        hasCriticalMissing: Boolean,
        hasConflations: Boolean,
        compensationStrength: Float,
        matchScore: Float,
        presentEvidenceCount: Int
    ): FoundationAction {

        // Forbidden conflations are hard stops because they can create false biological meaning.
        if (hasConflations) {
            return FoundationAction.BLOCK_HYPOTHESIS_UPGRADE
        }

        return when {
            // Very weak axis match: block upgrade before confidence can drift.
            matchScore < 0.20f ->
                FoundationAction.BLOCK_HYPOTHESIS_UPGRADE

            // High required coverage with no missing critical evidence: proceed to evidence inspection.
            requiredCoverage >= 0.85f && !hasCriticalMissing ->
                FoundationAction.PROCEED

            // Medium coverage plus strong compensation: proceed, but cap claims.
            requiredCoverage >= 0.60f && compensationStrength > 0.50f ->
                FoundationAction.PROCEED_WITH_CAUTION

            // Partial coverage: do not reject, but require the missing evidence.
            requiredCoverage >= 0.40f || presentEvidenceCount >= 3 ->
                FoundationAction.REQUIRE_MORE_EVIDENCE

            // Weak route match: analogy/contrast only.
            matchScore < 0.35f ->
                FoundationAction.DOWNGRADE_TO_ANALOGY

            // Default for ambiguous cases.
            else ->
                FoundationAction.REQUIRE_MORE_EVIDENCE
        }
    }

    /**
     * Adjust confidence level based on action
     */
    private fun calculateConfidenceAdjustment(action: FoundationAction): Float {
        return when (action) {
            FoundationAction.PROCEED -> 0f                    // No adjustment
            FoundationAction.PROCEED_WITH_CAUTION -> -0.15f   // Reduce confidence
            FoundationAction.REQUIRE_MORE_EVIDENCE -> -0.25f  // Reduce more
            FoundationAction.DOWNGRADE_TO_ANALOGY -> -0.35f   // Significant reduction
            FoundationAction.BLOCK_HYPOTHESIS_UPGRADE -> -0.5f
            FoundationAction.SUGGEST_FOUNDATION_PATCH -> -0.2f
        }
    }

    /**
     * Generate appropriate claim limit for the given action
     */
    private fun generateClaim(action: FoundationAction, axis: FoundationAxis): ClaimLimit {
        return when (action) {
            FoundationAction.PROCEED ->
                ClaimLimit(
                    maxClaim = "foundation_supported",
                    description = "Foundation knowledge supports this route. Evidence still gates hypothesis."
                )

            FoundationAction.PROCEED_WITH_CAUTION ->
                ClaimLimit(
                    maxClaim = "mechanism_plausibility",
                    description = "Consistent with ${axis.id}, but missing evidence. Mechanism, not proof."
                )

            FoundationAction.REQUIRE_MORE_EVIDENCE ->
                ClaimLimit(
                    maxClaim = "direction_only",
                    description = "Shows relevance but insufficient for hypothesis."
                )

            FoundationAction.DOWNGRADE_TO_ANALOGY ->
                ClaimLimit(
                    maxClaim = "analogy_only",
                    description = "Weak match. Use as analogy to guide future search, not evidence."
                )

            FoundationAction.BLOCK_HYPOTHESIS_UPGRADE ->
                ClaimLimit(
                    maxClaim = "none",
                    description = "Do not upgrade to hypothesis. Violates foundation knowledge."
                )

            FoundationAction.SUGGEST_FOUNDATION_PATCH ->
                ClaimLimit(
                    maxClaim = "foundation_challenge",
                    description = "This data challenges foundation knowledge. Suggest patch review."
                )
        }
    }

    /**
     * Generate next steps for the user
     */
    private fun generateNextSteps(action: FoundationAction, axis: FoundationAxis): List<String> {
        val steps = mutableListOf<String>()

        steps.add("Foundation axis: ${axis.id}")

        when (action) {
            FoundationAction.PROCEED -> {
                steps.add("1. Foundation knowledge supports this route")
                steps.add("2. Proceed to evidence quality gates")
                steps.add("3. Remember: foundation guides, evidence proves")
            }

            FoundationAction.PROCEED_WITH_CAUTION -> {
                steps.add("1. Foundation partially supports, with gaps")
                steps.add("2. Proceed but mark as mechanism, not primary hypothesis")
                steps.add("3. Seek: ${axis.requiredEvidence.filter { it !in steps }.take(2)}")
            }

            FoundationAction.REQUIRE_MORE_EVIDENCE -> {
                steps.add("1. Incomplete match to ${axis.id}")
                steps.add("2. Do not upgrade to hypothesis without: ${axis.criticalEvidence.take(2)}")
                steps.add("3. Use as candidate for future search")
            }

            FoundationAction.DOWNGRADE_TO_ANALOGY -> {
                steps.add("1. Weak match to ${axis.id}")
                steps.add("2. Use as mechanism analogy only")
                steps.add("3. Require specific axis match for hypothesis")
            }

            FoundationAction.BLOCK_HYPOTHESIS_UPGRADE -> {
                steps.add("1. Forbidden conflation or critical mismatch detected")
                steps.add("2. Do NOT treat as evidence for hypothesis")
                steps.add("3. Consider completely different axis")
            }

            FoundationAction.SUGGEST_FOUNDATION_PATCH -> {
                steps.add("1. Data challenges foundation knowledge")
                steps.add("2. Record this conflict")
                steps.add("3. Await review before updating foundation")
            }
        }

        return steps
    }

    /**
     * Build detailed explanation of resolution
     */
    private fun buildExplanation(
        axis: FoundationAxis,
        action: FoundationAction,
        requiredCoverage: Float,
        presentEvidence: List<String>,
        missingEvidence: List<String>,
        compensatingEvidence: List<CompensatingEvidence>,
        detectedConflations: List<String>
    ): String {
        val sb = StringBuilder()

        sb.append("=== FOUNDATION CONFLICT RESOLUTION ===\n\n")

        sb.append("Axis: ${axis.id}\n")
        sb.append("Decision: $action\n\n")

        sb.append("Evidence Analysis:\n")
        sb.append("- Coverage: ${String.format("%.1f%%", requiredCoverage * 100)}\n")
        sb.append("- Present: ${presentEvidence.joinToString(", ")}\n")
        if (missingEvidence.isNotEmpty()) {
            sb.append("- Missing: ${missingEvidence.joinToString(", ")}\n")
        }

        if (compensatingEvidence.isNotEmpty()) {
            sb.append("- Compensating: ${compensatingEvidence.map { it.name }.joinToString(", ")}\n")
        }

        if (detectedConflations.isNotEmpty()) {
            sb.append("\n⚠️ WARNING: Forbidden conflations detected:\n")
            detectedConflations.forEach { conflation ->
                sb.append("  - $conflation\n")
            }
        }

        sb.append("\nReasoning:\n")
        sb.append(buildDetailedReasoning(action, requiredCoverage, compensatingEvidence.isNotEmpty()))

        return sb.toString()
    }

    /**
     * Build detailed reasoning for the decision
     */
    private fun buildDetailedReasoning(
        action: FoundationAction,
        coverage: Float,
        hasCompensation: Boolean
    ): String {
        return when (action) {
            FoundationAction.PROCEED ->
                "All critical evidence present and coverage >= 85%. " +
                "Foundation knowledge supports this route."

            FoundationAction.PROCEED_WITH_CAUTION ->
                "Coverage >= 60% with compensating evidence. " +
                "Consistent with axis but missing non-critical markers. " +
                "Proceed for mechanism exploration, not primary hypothesis."

            FoundationAction.REQUIRE_MORE_EVIDENCE ->
                "Partial coverage (${String.format("%.0f%%", coverage * 100)}). " +
                "Dataset shows relevance but insufficient for hypothesis. " +
                "Gather additional evidence for stronger match."

            FoundationAction.DOWNGRADE_TO_ANALOGY ->
                "Weak keyword/evidence match. " +
                "Use as analogy to inform mechanism thinking, not as direct evidence."

            FoundationAction.BLOCK_HYPOTHESIS_UPGRADE ->
                "Either forbidden conflation detected or critical evidence missing. " +
                "Do NOT upgrade to hypothesis. Consider alternative axes."

            FoundationAction.SUGGEST_FOUNDATION_PATCH ->
                "Data pattern challenges current foundation knowledge. " +
                "Document for foundation review. Await patch approval before upgrade."
        }
    }

    /**
     * Merge multiple conflicts (if analyzing multiple datasets)
     */
    fun mergeConflicts(conflicts: List<ConflictResolution>): MergedConflictAnalysis {
        val actions = conflicts.map { it.action }
        val mostCommonAction = actions.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
            ?: FoundationAction.REQUIRE_MORE_EVIDENCE

        val allClaims = conflicts.flatMap { it.suggestedClaim.description.split(";") }
        val conservativeClaim = if (conflicts.any { it.action == FoundationAction.BLOCK_HYPOTHESIS_UPGRADE }) {
            "none"
        } else if (conflicts.any { it.action == FoundationAction.DOWNGRADE_TO_ANALOGY }) {
            "analogy_only"
        } else {
            "mechanism_plausibility"
        }

        return MergedConflictAnalysis(
            aggregateAction = mostCommonAction,
            conservativeClaim = conservativeClaim,
            conflictCount = conflicts.size,
            actionDistribution = actions.groupingBy { it }.eachCount(),
            recommendation = "Treat as ${conservativeClaim}. Consistent across ${conflicts.size} datasets."
        )
    }
}

// ============ DATA CLASSES ============

data class ConflictResolution(
    val action: FoundationAction,
    val actionExplanation: String,
    val confidenceAdjustment: Float,  // -0.5 to 0.0
    val suggestedClaim: ClaimLimit,
    val nextSteps: List<String>
)

data class ClaimLimit(
    val maxClaim: String,            // none, analogy_only, mechanism, foundation_supported
    val description: String
)

data class MergedConflictAnalysis(
    val aggregateAction: FoundationAction,
    val conservativeClaim: String,
    val conflictCount: Int,
    val actionDistribution: Map<FoundationAction, Int>,
    val recommendation: String
)
