package com.immunesignal.app

/** v1.10.21: reusable marker vocabulary derived from the scientific term-index family. */
object ScientificTermMarkerBank {
    val markerTerms: List<String> = listOf(
        "ige", "eosinophil", "histamine", "mast cell", "tryptase", "crp", "il-6", "tnf", "il-10", "il-1b",
        "interferon", "ifn", "cxcl10", "t cell", "b cell", "antibody", "igg", "iga", "cytokine", "chemokine",
        "blood pressure", "heart rate", "hrv", "cortisol", "hpa axis", "rna", "rna-seq", "gene expression",
        "transcriptomic", "single-cell", "scrna", "dna methylation", "epigenetic", "mitochondrial", "glycolysis",
        "glucose", "insulin", "microbiome", "intestinal permeability", "testosterone", "protein", "muscle mass"
    )
}
