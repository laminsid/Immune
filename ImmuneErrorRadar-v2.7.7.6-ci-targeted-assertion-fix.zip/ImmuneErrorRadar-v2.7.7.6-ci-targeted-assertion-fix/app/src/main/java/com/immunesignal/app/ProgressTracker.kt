package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.5.0: Progress Tracker
 *
 * Monitors session progress in real-time and provides UI-ready data.
 * Shows: percentage, time remaining, current task, phase status.
 */

data class ProgressUpdate(
    val sessionId: String,
    val overallProgress: Int,                // 0-100
    val timeUsed: String,                    // "8m 32s"
    val timeRemaining: String,               // "6m 28s"
    val estimatedCompletion: String,         // "6m 28s"
    val currentPhase: String?,               // "INTERACTION_DETECTION"
    val currentTask: String,                 // "Analyzing hypothesis pair #9/15"
    val phases: List<PhaseProgressUpdate>,
    val progressBar: String                  // "████████░░░░░░" visual
)

data class PhaseProgressUpdate(
    val phaseName: String,
    val status: String,                      // "COMPLETED", "IN_PROGRESS", "PENDING", etc
    val progress: Int,                       // 0-100
    val icon: String,                        // "✅", "⏳", "⏸", etc
    val timeUsed: String,
    val findings: String,                    // Summary of findings
    val estimatedTimeRemaining: String
)

object ProgressTracker {
    
    fun generateProgressUpdate(
        session: LearningSession,
        currentTask: String = "",
        phaseFindings: Map<String, String> = emptyMap()
    ): ProgressUpdate {
        val timeUsedMs = session.timeUsed()
        val timeRemainingMs = session.timeRemaining()
        
        return ProgressUpdate(
            sessionId = session.sessionId,
            overallProgress = session.overallProgress(),
            timeUsed = formatTime(timeUsedMs),
            timeRemaining = formatTime(timeRemainingMs),
            estimatedCompletion = formatTime(timeRemainingMs),
            currentPhase = session.phases
                .find { it.status == PhaseStatus.IN_PROGRESS }?.phaseName,
            currentTask = currentTask,
            phases = session.phases.map { phase ->
                val findings = phaseFindings[phase.phaseName] ?: ""
                PhaseProgressUpdate(
                    phaseName = phase.phaseName,
                    status = phase.status.name,
                    progress = phase.progress,
                    icon = getStatusIcon(phase.status),
                    timeUsed = formatTime(phase.timeUsed()),
                    findings = findings,
                    estimatedTimeRemaining = estimatePhaseTimeRemaining(phase)
                )
            },
            progressBar = generateProgressBar(session.overallProgress())
        )
    }
    
    fun generateProgressBar(progress: Int, width: Int = 30): String {
        val filled = (progress * width / 100).coerceAtMost(width)
        val empty = width - filled
        return "█".repeat(filled) + "░".repeat(empty) + " $progress%"
    }
    
    fun formatTime(millis: Long): String {
        val seconds = (millis / 1000) % 60
        val minutes = (millis / (1000 * 60)) % 60
        val hours = millis / (1000 * 60 * 60)
        
        return when {
            hours > 0 -> "$hours:${String.format("%02d", minutes)}:${String.format("%02d", seconds)}"
            minutes > 0 -> "${minutes}m ${seconds.toInt()}s"
            else -> "${seconds.toInt()}s"
        }
    }
    
    private fun getStatusIcon(status: PhaseStatus): String = when (status) {
        PhaseStatus.COMPLETED -> "✅"
        PhaseStatus.IN_PROGRESS -> "⏳"
        PhaseStatus.PAUSED -> "⏸"
        PhaseStatus.PENDING -> "⏸"
        PhaseStatus.FAILED -> "❌"
    }
    
    private fun estimatePhaseTimeRemaining(phase: PhaseState): String {
        if (phase.status == PhaseStatus.COMPLETED) return "Done"
        if (phase.status == PhaseStatus.PENDING) return "Not started"
        
        // Estimate based on progress
        val timeUsed = phase.timeUsed()
        if (timeUsed == 0L || phase.progress == 0) return "Calculating..."
        
        val estimatedTotal = (timeUsed * 100 / phase.progress.coerceAtLeast(1)).toLong()
        val remaining = (estimatedTotal - timeUsed).coerceAtLeast(0L)
        
        return formatTime(remaining)
    }
    
    fun generateUIReport(session: LearningSession): String {
        val progress = generateProgressUpdate(session)
        
        return buildString {
            append("┌─────────────────────────────────────────────┐\n")
            append("│ 🧠 THINKING SESSION                         │\n")
            append("├─────────────────────────────────────────────┤\n")
            append("│                                             │\n")
            append("│ 📊 Progress                                 │\n")
            append("│ [${progress.progressBar}]  ${progress.overallProgress}%\n")
            append("│                                             │\n")
            append("│ ⏱ Time Usage                               │\n")
            append("│ Used: ${progress.timeUsed} / Limit: ${formatTime(session.timeLimit)}\n")
            append("│ Remaining: ~${progress.timeRemaining}                    │\n")
            append("│                                             │\n")
            append("│ 📋 Phase Status                            │\n")
            
            session.phases.forEachIndexed { idx, phase ->
                val phaseReport = progress.phases[idx]
                append("│ ${phaseReport.icon} ${phase.phaseName.padEnd(20)} (${phase.progress}%)\n")
                if (phase.progress > 0) {
                    append("│    [${generateProgressBar(phase.progress, 20)}]\n")
                }
            }
            
            append("│                                             │\n")
            if (progress.currentPhase != null) {
                append("│ 🎯 Current Task                            │\n")
                append("│ ${progress.currentTask.take(40).padEnd(40)}│\n")
            }
            append("│                                             │\n")
            append("├─────────────────────────────────────────────┤\n")
            append("│ [⏸ PAUSE] [⏭ SKIP] [⏹ STOP]              │\n")
            append("└─────────────────────────────────────────────┘\n")
        }
    }
    
    // For JSON reporting. Uses JSONObject so phase findings or task text with
    // quotes/newlines cannot corrupt checkpoint diagnostics.
    fun generateJSONReport(session: LearningSession): String {
        val progress = generateProgressUpdate(session)
        val phases = JSONArray()
        progress.phases.forEach { phase ->
            phases.put(JSONObject().apply {
                put("phaseName", phase.phaseName)
                put("status", phase.status)
                put("progress", phase.progress)
                put("icon", phase.icon)
                put("timeUsed", phase.timeUsed)
                put("findings", phase.findings)
                put("estimatedTimeRemaining", phase.estimatedTimeRemaining)
            })
        }
        return JSONObject().apply {
            put("sessionId", progress.sessionId)
            put("overallProgress", progress.overallProgress)
            put("timeUsed", progress.timeUsed)
            put("timeRemaining", progress.timeRemaining)
            put("estimatedCompletion", progress.estimatedCompletion)
            put("currentPhase", progress.currentPhase ?: "")
            put("currentTask", progress.currentTask)
            put("progressBar", progress.progressBar)
            put("claimLimit", RuntimeFeatureFlags.LEARNING_SESSION_CLAIM_LIMIT)
            put("phases", phases)
        }.toString()
    }
}

// Simple observer pattern for UI updates
interface ProgressListener {
    fun onProgressUpdate(progress: ProgressUpdate)
    fun onPhaseComplete(phaseName: String, findings: String)
    fun onSessionComplete(insights: LearningInsights)
}

class ProgressBroadcaster {
    private val listeners = mutableListOf<ProgressListener>()
    
    fun addListener(listener: ProgressListener) {
        listeners.add(listener)
    }
    
    fun removeListener(listener: ProgressListener) {
        listeners.remove(listener)
    }
    
    fun broadcastProgress(progress: ProgressUpdate) {
        listeners.forEach { it.onProgressUpdate(progress) }
    }
    
    fun broadcastPhaseComplete(phaseName: String, findings: String) {
        listeners.forEach { it.onPhaseComplete(phaseName, findings) }
    }
    
    fun broadcastSessionComplete(insights: LearningInsights) {
        listeners.forEach { it.onSessionComplete(insights) }
    }
}
