package com.immunesignal.app

/**
 * v1.10.54: GitHub CI/runtime-surface hardening.
 *
 * Wiring-only release. It corrects stale version labels, keeps static-check PASS output
 * at the real end of the script, and documents the runtime surfaces that must stay
 * aligned before GitHub builds. No biological, diagnostic, treatment, dose, or drug
 * ranking claim is relaxed.
 */
object GithubCiRuntimeSurfaceHardeningV11054 {
    const val VERSION_LABEL: String = "v1.10.54-alpha-github-ci-runtime-surface-hardening"
    const val CLAIM_LIMIT: String = "github_ci_runtime_surface_hardening_not_biological_proof"
    const val VERSION_LABEL_INTEGRITY: String = "VERSION_LABELS_MATCH_OWNING_RELEASES"
    const val STATIC_CHECK_PASS_ORDER: String = "STATIC_CHECK_PASS_PRINTS_AFTER_FINAL_AUDIT"
    const val GENERATED_ARTIFACT_POLICY: String = "NO_BUILD_CACHE_OR_BINARY_ARTIFACTS_IN_RELEASE_ZIP"

    val guardedSurfaces: List<String> = listOf(
        "Gradle versionCode/versionName",
        "RuntimeFeatureFlags release train",
        "EngineRuntimeStatus active engine",
        "ReleaseVersionLinkageGuard",
        "RuntimeModuleRegistry",
        "GitHub android-debug workflow",
        "fast/full static checks",
        "route reconciliation labels",
        "open exploration / diagnostic sandbox labels"
    )

    fun summary(): String =
        "v1.10.54 CI hardening: $VERSION_LABEL_INTEGRITY; $STATIC_CHECK_PASS_ORDER; $GENERATED_ARTIFACT_POLICY; guarded=${guardedSurfaces.size}; claim-limit=$CLAIM_LIMIT"
}
