package com.immunesignal.app

import java.util.Locale

class PersonalPatternLedger(
    private val localRecords: List<String>,
    private val importedSignals: List<ImportedReportSignal>
) {
    fun assess(axes: List<String>): PersonalPatternAssessment {
        val text = (localRecords + importedSignals.map { it.matchedAxes.joinToString(" ") + " " + it.extractedKeywords.joinToString(" ") }).joinToString(" ").lowercase(Locale.US)
        val counts = axes.associateWith { axis -> Regex(Regex.escape(axis.lowercase(Locale.US))).findAll(text).count() }
        val repeated = counts.values.sum().coerceAtMost(5)
        val strongest = counts.toList().sortedByDescending { it.second }.filter { it.second > 0 }.map { it.first }.take(4)
        val temporalSupport = when {
            text.contains("before") || text.contains("after") || text.contains("next day") || text.contains("24h") || text.contains("48h") -> "temporal_clues_present"
            localRecords.size + importedSignals.size >= 3 -> "repeated_records_no_clear_time_order"
            localRecords.isNotEmpty() || importedSignals.isNotEmpty() -> "single_or_sparse_local_context"
            else -> "no_local_timeline_yet"
        }
        val next = when {
            axes.contains("autonomic_vascular_axis") -> "Measure BP + pulse before/during/after allergy/stress episodes."
            axes.contains("gastric_acid_gut_axis") -> "Log reflux/meal/acid-suppression timing before allergy or airway symptoms."
            axes.contains("testosterone_immune_axis") -> "Track testosterone lab date with fatigue, muscle reserve, inflammation, and allergy intensity."
            axes.contains("rna_transcriptomic_axis") || axes.contains("dna_genomic_axis") -> "Separate inherited DNA, epigenetic aging, and RNA expression evidence."
            else -> "Collect 3 repeated episodes with timestamped trigger, symptom, marker, and recovery fields."
        }
        return PersonalPatternAssessment(
            repeatedObservationCount = repeated,
            temporalSupport = temporalSupport,
            strongestLocalAxes = strongest,
            nextBestMeasurement = next
        )
    }
}
