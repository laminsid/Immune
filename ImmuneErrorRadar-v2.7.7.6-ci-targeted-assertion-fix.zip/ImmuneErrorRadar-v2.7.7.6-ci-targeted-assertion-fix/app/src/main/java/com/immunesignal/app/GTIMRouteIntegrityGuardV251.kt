package com.immunesignal.app

/**
 * GTIM v2.5.1 route-integrity hardening.
 *
 * This guard is deliberately small and deterministic. It proves that the GTIM surface is connected
 * to the existing v1.11.x accession/comparator/matrix dossier path and prevents the global dossier
 * from becoming an isolated marketing/reporting island.
 */
data class GTIMRouteIntegrityReportV251(
    val passed: Boolean,
    val status: String,
    val bridgePath: List<String>,
    val connectedSurfaces: List<String>,
    val requiredAnchors: List<String>,
    val brokenLinks: List<String>,
    val weakLeadProtection: String,
    val playProtectPosture: String,
    val githubCiPosture: String,
    val nextRepairAction: String
)

object GTIMRouteIntegrityGuardV251 {
    private val requiredBridgePath = listOf(
        "ResearchGradeMechanismDossierV1110",
        "GTIMDiscoveryDossierV250",
        "DatasetForagingJson.globalTranslationalDossier",
        "GlobalResearchGradeBriefV11061",
        "ResearchAutopilotActivity",
        "RuntimeModuleRegistry"
    )

    fun evaluate(
        report: ResearchGradeMechanismDossierReportV1110,
        evidenceObjects: List<GTIMEvidenceObjectV250>,
        mechanismCandidates: List<GTIMMechanismCandidateV250>
    ): GTIMRouteIntegrityReportV251 {
        val anchors = buildList {
            if (report.active) add("mechanism_report_active")
            if (evidenceObjects.isNotEmpty()) add("gtim_evidence_objects_present")
            if (mechanismCandidates.isNotEmpty()) add("gtim_mechanism_candidates_present")
            if (report.accessionCandidates.isNotEmpty()) add("confirmed_accession_path_present")
            if (report.sourceMetadataEnrichmentCards.isNotEmpty()) add("source_metadata_enrichment_path_present")
            if (report.researchQuestion.isNotBlank()) add("research_intent_question_anchor_present")
            if (report.comparatorExtractionCards.isNotEmpty()) add("comparator_extraction_path_present")
            if (report.matrixAnalysisGate.isNotBlank()) add("matrix_gate_path_present")
            if (report.contradictionNullResultSearch.isNotEmpty()) add("contradiction_search_path_present")
        }.distinct()

        val broken = mutableListOf<String>()
        if (!report.active) broken += "mechanism report is inactive"
        if (evidenceObjects.isEmpty() && report.sourceMetadataEnrichmentCards.isNotEmpty()) broken += "metadata cards exist but GTIM evidence object map is empty"
        if (mechanismCandidates.isEmpty() && evidenceObjects.isNotEmpty()) broken += "evidence objects exist but no bounded mechanism candidate/fallback was created"
        if (mechanismCandidates.any { it.status.contains("CONFIRMED", ignoreCase = true) }) broken += "GTIM candidate status must not claim confirmation"
        if (mechanismCandidates.any { it.confidenceIndex.score >= 90 }) broken += "GTIM confidence cannot reach 90+ without external validation"
        if (evidenceObjects.any { it.accessionId.startsWith("MANUAL_TEXT_SNIPPET", ignoreCase = true) && it.evidenceStrength != "GRADE_1_WEAK_TEXTUAL_LEAD" }) {
            broken += "manual text snippets must remain grade-1 weak textual leads"
        }
        if (evidenceObjects.any { it.dataScarcityRole.contains("CROSS_SPECIES", ignoreCase = true) && it.evidenceStrength.startsWith("GRADE_5") }) {
            broken += "cross-species evidence cannot be matrix-ready human confirmation"
        }

        val passed = broken.isEmpty() && anchors.contains("mechanism_report_active") && anchors.any {
            it == "confirmed_accession_path_present" || it == "source_metadata_enrichment_path_present" || it == "research_intent_question_anchor_present"
        }
        val status = when {
            passed && report.accessionCandidates.isNotEmpty() -> "GTIM_ROUTE_CONNECTED_WITH_ACCESSION_ANCHOR"
            passed && report.sourceMetadataEnrichmentCards.isNotEmpty() -> "GTIM_ROUTE_CONNECTED_WITH_METADATA_ANCHOR"
            passed -> "GTIM_ROUTE_CONNECTED_WITH_INTENT_ANCHOR"
            else -> "GTIM_ROUTE_REPAIR_REQUIRED"
        }
        return GTIMRouteIntegrityReportV251(
            passed = passed,
            status = status,
            bridgePath = requiredBridgePath,
            connectedSurfaces = anchors,
            requiredAnchors = listOf(
                "active mechanism report",
                "confirmed accession OR source metadata enrichment OR parsed research intent",
                "JSON export path",
                "brief/UI surface",
                "runtime registry declaration",
                "claim boundary and weak-lead protection"
            ),
            brokenLinks = broken.distinct(),
            weakLeadProtection = "manual snippets/text-mined leads remain exploratory; they cannot become confirmed accessions, DGE results, or clinical claims",
            playProtectPosture = "no new sensitive permissions, no background telemetry, research-use-only language, cleartext disabled",
            githubCiPosture = "static audits should verify route tokens, release linkage, JSON export, weak-lead guard, and Play-safe manifest posture",
            nextRepairAction = if (passed) "No structural GTIM route repair required; continue with accession/comparator/matrix evidence closure." else broken.firstOrNull() ?: "Inspect route linkage guard."
        )
    }
}
