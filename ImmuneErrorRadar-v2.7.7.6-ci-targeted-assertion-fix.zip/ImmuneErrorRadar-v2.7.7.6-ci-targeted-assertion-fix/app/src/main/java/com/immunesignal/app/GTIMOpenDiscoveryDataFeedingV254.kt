package com.immunesignal.app

/**
 * GTIM v2.6.3 Open Discovery DataFeed with accession-seed loop breaker.
 *
 * This layer relaxes result visibility and creates data-feeding actions without relaxing
 * biological proof, DGE, diagnosis, treatment, or patient-outcome claim locks. It is wired
 * into the existing GTIM dossier and JSON surface; it is not a parallel pipeline.
 */
data class GTIMDataFeedingChannelV254(
    val channelId: String,
    val priority: Int,
    val sourceFamily: String,
    val intakeMode: String,
    val querySeed: String,
    val expectedGain: String,
    val localFirstPrivacyPosture: String,
    val playProtectPosture: String,
    val nextAction: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
)

data class GTIMOpenDiscoveryDataFeedReportV254(
    val active: Boolean,
    val status: String,
    val strictnessPosture: String,
    val relaxedSurfaces: List<String>,
    val dataFeedingChannels: List<GTIMDataFeedingChannelV254>,
    val immediateActions: List<String>,
    val stillLocked: List<String>,
    val githubPosture: String,
    val playProtectPosture: String,
    val claimBoundary: String = GTIMClaimGuardV250.CLAIM_BOUNDARY
) {
    companion object {
        fun empty() = GTIMOpenDiscoveryDataFeedReportV254(
            active = false,
            status = "GTIM_OPEN_DISCOVERY_DATAFEED_IDLE",
            strictnessPosture = "no data-feed actions created",
            relaxedSurfaces = emptyList(),
            dataFeedingChannels = emptyList(),
            immediateActions = emptyList(),
            stillLocked = GTIMRelaxedExplorationPolicyV253.CLAIMS_STILL_BLOCKED,
            githubPosture = "not evaluated",
            playProtectPosture = "not evaluated"
        )
    }
}

object GTIMOpenDiscoveryDataFeedingV254 {
    const val VERSION: String = "2.7.3-final-proof-benchmark-learning-locked"
    const val STATUS_PASS: String = "GTIM_OPEN_DISCOVERY_DATAFEED_ACTIVE"
    const val CLAIM_POSTURE: String = "relax discovery visibility and data intake, not clinical or biological confirmation"

    fun evaluate(
        report: ResearchGradeMechanismDossierReportV1110,
        evidenceObjects: List<GTIMEvidenceObjectV250>,
        mechanismCandidates: List<GTIMMechanismCandidateV250>,
        routeIntegrity: GTIMRouteIntegrityReportV251
    ): GTIMOpenDiscoveryDataFeedReportV254 {
        val channels = buildChannels(report, evidenceObjects, mechanismCandidates)
            .distinctBy { it.channelId + it.querySeed }
            .sortedByDescending { it.priority }
            .take(12)

        val actions = buildImmediateActions(report, channels, mechanismCandidates)
        return GTIMOpenDiscoveryDataFeedReportV254(
            active = true,
            status = if (channels.isNotEmpty()) STATUS_PASS else "GTIM_OPEN_DISCOVERY_DATAFEED_NEEDS_MANUAL_SEED",
            strictnessPosture = CLAIM_POSTURE,
            relaxedSurfaces = listOf(
                "show weak leads instead of dry blockers",
                "show off-route leads as re-route/contrast material",
                "show manual snippets/PDF/PMID/DOI/GSE/PRJNA seeds as feedable leads",
                "show repository and metadata hunt actions even when accession is unresolved",
                "keep DGE and confirmation locked until matrix/comparator gates close"
            ),
            dataFeedingChannels = channels,
            immediateActions = actions,
            stillLocked = GTIMRelaxedExplorationPolicyV253.CLAIMS_STILL_BLOCKED + listOf(
                "confirmed human mechanism from text-only or off-route dataset",
                "automatic wet-lab protocol as medical instruction",
                "background collection or hidden telemetry"
            ),
            githubPosture = "v2.6.3 data-feed surface is JSON-visible, report-visible, registry-visible, and covered by static audit",
            playProtectPosture = "user-started research discovery only; INTERNET remains explicit for dataset/literature lookup; no sensitive Android permissions, no background telemetry or scraping, no patient clinical decision support",
            claimBoundary = GTIMClaimGuardV250.CLAIM_BOUNDARY
        )
    }

    private fun buildChannels(
        report: ResearchGradeMechanismDossierReportV1110,
        evidenceObjects: List<GTIMEvidenceObjectV250>,
        mechanismCandidates: List<GTIMMechanismCandidateV250>
    ): List<GTIMDataFeedingChannelV254> {
        val axis = mechanismCandidates.firstOrNull()?.targetAxis?.ifBlank { report.researchQuestion }
            ?: report.researchQuestion.ifBlank { "immune mechanism candidate" }
        val gaps = (report.blockingGaps + evidenceObjects.flatMap { it.blockingGaps }).distinct()
        val hasRepositorySeed = report.accessionCandidates.isNotEmpty() || evidenceObjects.any { it.accessionId.isNotBlank() && it.sourceType != "source_metadata_or_text_mined_lead" }
        val primarySeed = evidenceObjects.firstOrNull { it.accessionId.isNotBlank() && it.sourceType == "primary_accession_seed_capture" }
        val needsAccession = !hasRepositorySeed
        val needsComparator = gaps.any { it.contains("comparator", true) || it.contains("control", true) } || report.matrixReadinessScore < 40
        val needsMatrix = report.matrixAnalysisGate.contains("NO_ACCESSION", true) || report.matrixAnalysisGate.contains("METADATA_GAP", true) || report.matrixReadinessScore < 50
        val channels = mutableListOf<GTIMDataFeedingChannelV254>()

        if (primarySeed != null) {
            channels += channel(
                "DF_ACCESSION_SEED_METADATA_CLOSURE", 110, primarySeed.repository, "accession_seed_metadata_closure",
                "${primarySeed.accessionId} sample metadata comparator matrix tissue cell type platform",
                "Break the loop: captured accession seed is visible; close metadata/comparator/matrix instead of asking for another seed.",
                "User-supplied accession metadata lookup only; no patient identity upload.",
                "Public repository lookup initiated by the user; no hidden background scraping.",
                "Open ${primarySeed.accessionId} repository metadata and parse title, organism, platform, sample count, groups, comparator labels, and matrix hints."
            )
        }

        if (needsAccession) {
            channels += channel(
                "DF_GEO_SERIES_ACCESSION", 100, "GEO/GDS", "direct_repository_search",
                "$axis (GSE OR GEO Series OR GDS) human transcriptome RNA-seq single-cell control baseline outcome severity recovery",
                "Find stable GSE/GDS handles and sample tables before any mechanism upgrade.",
                "Run only after user starts research search; store accession metadata, not patient identity.",
                "Uses INTERNET only for explicit public-repository lookup.",
                "Query GEO/GDS first, then parse accession, sample count, tissue/cell type, groups, and matrix hints."
            )
            channels += channel(
                "DF_SRA_BIOPROJECT_ACCESSION", 94, "SRA/BioProject", "direct_repository_search",
                "$axis (PRJNA OR SRP OR SRR OR SRA) human RNA-seq single-cell immune response comparator phenotype",
                "Recover sequencing projects when GEO has no series-level record.",
                "User-started public metadata lookup; no background collection.",
                "No broad Android package/device access; public biomedical metadata only.",
                "Search BioProject/SRA and convert PRJNA/SRP/SRR handles into accession candidates."
            )
            channels += channel(
                "DF_ARRAYEXPRESS_HANDLE", 82, "ArrayExpress/BioStudies", "direct_repository_search",
                "$axis (E-MTAB OR E-GEOD OR ArrayExpress) human immune transcriptome comparator control",
                "Catch European/archive records not surfaced by PubMed/GEO queries.",
                "User-started lookup; keep only dataset handles and metadata summaries.",
                "No sensitive permission expansion.",
                "Search ArrayExpress/BioStudies for E-MTAB/E-GEOD handles and sample annotation files."
            )
            channels += channel(
                "DF_IMMPORT_SDY_HANDLE", 78, "ImmPort", "accession_mining",
                "$axis (SDY OR ImmPort) immune cohort cytokine cell subset vaccine infection autoimmune control",
                "Find immunology-specific SDY studies with curated immune assay context.",
                "User-started public/controlled-access metadata lookup; controlled data remain external.",
                "No hidden transfer of controlled-access data.",
                "Search ImmPort/SDY metadata and mark controlled-access gaps explicitly."
            )
            if (RuntimeFeatureFlags.ENABLE_EUROPE_PMC_LOOKUP_V265) {
                channels += channel(
                    "DF_EUROPE_PMC_DATA_AVAILABILITY", 76, "Europe PMC", "rest_data_availability_lookup",
                    "$axis Europe PMC Data Availability GSE PRJNA SRP E-MTAB SDY accession deposited comparator",
                    "Use Europe PMC REST metadata/full-text hints to surface accession-bearing papers before declaring no public channel.",
                    "User-started public metadata lookup; no patient data or hidden background scraping.",
                    "HTTPS-only Europe PMC/EBI endpoint; research metadata only.",
                    "Run Europe PMC query, extract PMID/DOI/PMCID/accession strings, then route handles back to repository-specific validation."
                )
            }
            if (RuntimeFeatureFlags.ENABLE_OPENALEX_LOOKUP_V265) {
                channels += channel(
                    "DF_OPENALEX_WORKS_DISCOVERY", 70, "OpenAlex", "works_cross_index_lookup",
                    "$axis OpenAlex works dataset accession transcriptome cohort comparator data availability",
                    "Use OpenAlex Works metadata to broaden DOI/open-access/source discovery when direct repositories are dry.",
                    "User-started public works lookup; metadata leads stay weak until repository confirmation.",
                    "HTTPS-only OpenAlex endpoint; no clinical decision or personal-data upload.",
                    "Run OpenAlex Works search, recover DOI/source metadata, then feed DOI/PMID/PMCID/accession hints into resolver."
                )
            }
        }

        if (needsComparator) {
            channels += channel(
                "DF_COMPARATOR_LABEL_HUNT", 90, "sample_metadata", "metadata_table_or_abstract_mining",
                "$axis (healthy control OR matched control OR baseline OR placebo OR responder OR non-responder OR case control)",
                "Close the most important blocker: comparator/control labels.",
                "Accept user-provided CSV/TSV sample metadata locally; do not upload automatically.",
                "Document/file picker only through user action; no broad file-system permission.",
                "Extract group labels and classify them as healthy/matched/baseline/placebo/responder/non-responder."
            )
        }

        if (needsMatrix) {
            channels += channel(
                "DF_MATRIX_FILE_HINT_HUNT", 86, "matrix_files", "repository_supplement_parser",
                "$axis (matrix file OR count matrix OR expression matrix OR supplementary file OR Series Matrix File)",
                "Move from lead to analyzable dataset readiness.",
                "Store only file hints and source URLs/handles unless user imports files manually.",
                "No background downloads; user-started research retrieval only.",
                "Look for series-matrix/count files and mark whether DGE can be attempted later."
            )
        }

        channels += channel(
            "DF_PUBMED_DATA_AVAILABILITY_MINING", 72, "PubMed/PMC", "data_availability_text_mining",
            "$axis \"Data Availability\" (GSE OR PRJNA OR SRP OR E-MTAB OR SDY OR deposited)",
            "Convert papers into dataset handles instead of stopping at narrative abstracts.",
            "Text-mined leads are stored as weak leads only, never as confirmed accessions until repository lookup closes.",
            "Public abstracts/full-text availability only; no clinical advice surface.",
            "Mine data-availability statements and feed extracted handles to repository-specific validation."
        )

        channels += channel(
            "DF_MANUAL_SEED_INTAKE", 68, "manual_seed", "user_supplied_seed",
            "PMID / DOI / GSE / PRJNA / SRP / SRR / E-MTAB / SDY / PDF / snippet",
            "Let researchers feed the engine with concrete evidence handles instead of waiting for autonomous search.",
            "Local-first manual intake; user controls what is pasted/imported.",
            "No background collection; no patient-level claim generation.",
            "Ask for one accession/PMID/DOI/PDF/snippet and turn it into a weak or repository-backed evidence object."
        )

        channels += channel(
            "DF_NULL_CONTRADICTION_QUEUE", 54, "PubMed/PMC", "contradiction_search",
            "$axis (null result OR no association OR failed replication OR negative result OR opposite direction)",
            "Prevent false excitement while still allowing scientific exploration.",
            "Search terms only; no personal data.",
            "Research-only contradiction mining.",
            "Attach null/contradiction leads to each candidate without suppressing exploratory output."
        )
        return channels
    }

    private fun buildImmediateActions(
        report: ResearchGradeMechanismDossierReportV1110,
        channels: List<GTIMDataFeedingChannelV254>,
        mechanismCandidates: List<GTIMMechanismCandidateV250>
    ): List<String> {
        val top = mechanismCandidates.firstOrNull()?.targetAxis ?: report.researchQuestion.ifBlank { "top immune mechanism route" }
        return listOf(
            "Keep showing this as an exploratory scientific lead, not as a failed run.",
            "Feed one concrete handle now: PMID, DOI, GSE, PRJNA, SRP/SRR, E-MTAB, SDY, PDF, or data-availability snippet.",
            "Run the top repository query: ${channels.firstOrNull()?.querySeed ?: top}",
            "If no accession appears, keep the lead and switch to PubMed Data Availability mining before declaring exhaustion.",
            "For any found dataset, extract sample groups, comparator labels, tissue/cell context, sample count, and matrix-file hints before DGE."
        )
    }

    private fun channel(
        id: String,
        priority: Int,
        source: String,
        intake: String,
        query: String,
        gain: String,
        privacy: String,
        play: String,
        next: String
    ) = GTIMDataFeedingChannelV254(
        channelId = id,
        priority = priority,
        sourceFamily = source,
        intakeMode = intake,
        querySeed = query,
        expectedGain = gain,
        localFirstPrivacyPosture = privacy,
        playProtectPosture = play,
        nextAction = next
    )
}
