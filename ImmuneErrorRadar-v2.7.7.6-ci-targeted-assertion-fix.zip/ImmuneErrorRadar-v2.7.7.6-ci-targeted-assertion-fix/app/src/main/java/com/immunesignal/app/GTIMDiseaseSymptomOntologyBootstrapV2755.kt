package com.immunesignal.app

/**
 * v2.7.5.5 — Disease/Symptom Ontology Bootstrap
 *
 * A small, local-first starter ontology that sits before route building. It is not a
 * diagnostic module. It turns disease/symptom/pathogen words into research anchors,
 * search axes, and anti-conflation rules so known diseases do not fall to
 * autonomous_unknown and symptoms remain differential research frames.
 */
object GTIMDiseaseSymptomOntologyBootstrapV2755 {
    const val VERSION: String = "2.7.5.5-disease-symptom-ontology-bootstrap"

    data class Profile(
        val id: String,
        val displayName: String,
        val aliases: Set<String>,
        val symptoms: Set<String>,
        val immuneAxes: Set<String>,
        val searchKeywords: Set<String>,
        val primaryAnchor: GTIMPrimaryAnchorV2740,
        val diseaseFamily: GTIMDiseaseFamilyV2740,
        val confidence: Int,
        val claimMode: GTIMClaimModeV2740,
        val claimLimit: String,
        val forbiddenConflations: Set<String>,
        val defaultRunMode: GTIMRunModeV2740
    )

    data class Detection(
        val profile: Profile,
        val matchedAlias: String,
        val reason: String
    )

    val diseaseProfiles: List<Profile> = listOf(
        Profile(
            id = "covid_long_covid",
            displayName = "COVID / Long COVID",
            aliases = setOf("covid", "long covid", "pasc", "sars cov 2", "sars-cov-2", "corona", "كورونا", "كوفيد"),
            symptoms = setOf("fever", "fatigue", "cough", "dyspnea", "post viral symptoms"),
            immuneAxes = setOf("interferon timing", "IL-6/TNF cytokines", "post-viral inflammation", "PBMC/airway host response"),
            searchKeywords = setOf("COVID PBMC transcriptomics GSE", "long COVID interferon IL-6 TNF cohort", "SARS-CoV-2 host response data availability"),
            primaryAnchor = GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL,
            diseaseFamily = GTIMDiseaseFamilyV2740.RESPIRATORY_VIRAL,
            confidence = 92,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "research_mapping_only_not_diagnosis",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "generic_microbiome_identity_mutation"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "hantavirus_zoonotic",
            displayName = "Hantavirus",
            aliases = setOf("hanta", "hantavirus", "hfrs", "hcps", "hantavirus pulmonary syndrome", "هانتا"),
            symptoms = setOf("fever", "renal involvement", "pulmonary syndrome", "vascular leakage", "thrombocytopenia"),
            immuneAxes = setOf("endothelial activation", "cytokine response", "innate antiviral signaling", "vascular immune injury"),
            searchKeywords = setOf("hantavirus transcriptomics", "hantavirus cytokine human cohort", "HFRS PBMC gene expression"),
            primaryAnchor = GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL,
            diseaseFamily = GTIMDiseaseFamilyV2740.VECTOR_BORNE_OR_ZOONOTIC,
            confidence = 90,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "pathogen_research_mapping_only",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "generic_covid_long_covid_route_without_query_support"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "ebola_evd",
            displayName = "Ebola / EVD",
            aliases = setOf("ebola", "evd", "filovirus", "ايبولا", "ابولا"),
            symptoms = setOf("fever", "hemorrhage", "vascular leakage", "shock", "fatigue"),
            immuneAxes = setOf("hemorrhagic viral host response", "innate immune activation", "cytokine storm context", "vascular immune injury"),
            searchKeywords = setOf("Ebola EVD PBMC transcriptomics", "Ebola virus disease human cohort GSE", "filovirus host response dataset"),
            primaryAnchor = GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL,
            diseaseFamily = GTIMDiseaseFamilyV2740.HEMORRHAGIC_VIRAL,
            confidence = 90,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "pathogen_research_mapping_only",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "depression_neuroimmune_axis", "longevity_immunosenescence"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "hiv_aids",
            displayName = "HIV / AIDS",
            aliases = setOf("hiv", "aids", "sida", "الايدز", "الإيدز", "سيدا"),
            symptoms = setOf("immune deficiency", "opportunistic infection", "fatigue", "weight loss"),
            immuneAxes = setOf("CD4 depletion", "chronic immune activation", "mucosal immune remodeling", "microbiome immune interaction"),
            searchKeywords = setOf("HIV CD4 immune activation transcriptomics", "HIV PBMC cohort GSE", "HIV microbiome immune activation"),
            primaryAnchor = GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION,
            diseaseFamily = GTIMDiseaseFamilyV2740.RETROVIRAL_IMMUNODEFICIENCY,
            confidence = 91,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "pathogen_research_mapping_only",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "covid_interferon_cytokine_bridge", "hemorrhagic_fever_route"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "influenza_antiviral",
            displayName = "Influenza",
            aliases = setOf("influenza", "flu", "h1n1", "h3n2", "grippe", "انفلونزا", "الانفلونزا"),
            symptoms = setOf("fever", "fatigue", "myalgia", "cough", "post viral fatigue"),
            immuneAxes = setOf("antiviral interferon", "respiratory epithelial response", "cytokine response", "post viral fatigue"),
            searchKeywords = setOf("influenza host response transcriptomics GSE", "influenza PBMC cytokine cohort", "H1N1 interferon gene expression"),
            primaryAnchor = GTIMPrimaryAnchorV2740.INFLUENZA_RESPIRATORY_VIRAL,
            diseaseFamily = GTIMDiseaseFamilyV2740.INFLUENZA_RESPIRATORY_VIRAL,
            confidence = 87,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "pathogen_research_mapping_only",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "covid_identity_mutation_without_query_support"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "dengue_vector_borne",
            displayName = "Dengue",
            aliases = setOf("dengue", "denv", "حمى الضنك", "ضنك"),
            symptoms = setOf("fever", "vascular leakage", "thrombocytopenia", "rash", "myalgia"),
            immuneAxes = setOf("vascular immune injury", "innate antiviral signaling", "antibody-dependent enhancement context", "cytokine response"),
            searchKeywords = setOf("dengue transcriptomics human cohort", "DENV PBMC GSE", "dengue vascular cytokine response"),
            primaryAnchor = GTIMPrimaryAnchorV2740.DENGUE_VECTOR_BORNE_VIRAL,
            diseaseFamily = GTIMDiseaseFamilyV2740.DENGUE_VECTOR_BORNE_VIRAL,
            confidence = 88,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "pathogen_research_mapping_only",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "generic_covid_route_without_query_support"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "tuberculosis_macrophage",
            displayName = "Tuberculosis",
            aliases = setOf("tuberculosis", "tb", "mycobacterium tuberculosis", "سل", "السل"),
            symptoms = setOf("cough", "fever", "night sweats", "weight loss", "fatigue"),
            immuneAxes = setOf("macrophage activation", "granuloma", "Th1 IFN-gamma", "chronic infection inflammation"),
            searchKeywords = setOf("tuberculosis macrophage transcriptomics", "TB granuloma immune dataset", "mycobacterium tuberculosis PBMC GSE"),
            primaryAnchor = GTIMPrimaryAnchorV2740.TUBERCULOSIS_GRANULOMATOUS_IMMUNE,
            diseaseFamily = GTIMDiseaseFamilyV2740.TUBERCULOSIS_GRANULOMATOUS_IMMUNE,
            confidence = 87,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "pathogen_research_mapping_only",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "covid_interferon_cytokine_bridge"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "diabetes_metabolic_inflammation",
            displayName = "Diabetes",
            aliases = setOf("diabetes", "diabetic", "type 2 diabetes", "t2d", "type 1 diabetes", "t1d", "glucose", "insulin", "سكري", "السكري"),
            symptoms = setOf("fatigue", "thirst", "polyuria", "weight change", "slow wound healing"),
            immuneAxes = setOf("metabolic inflammation", "insulin resistance inflammation", "beta-cell autoimmunity", "adipose inflammation", "gut microbiome metabolic axis"),
            searchKeywords = setOf("diabetes inflammation cytokines", "T2D insulin resistance IL-6 TNF", "T1D beta cell autoimmunity", "diabetes PBMC transcriptomics", "diabetes cohort GSE"),
            primaryAnchor = GTIMPrimaryAnchorV2740.DIABETES_METABOLIC_INFLAMMATION,
            diseaseFamily = GTIMDiseaseFamilyV2740.METABOLIC_INFLAMMATION,
            confidence = 82,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "research_mapping_only_not_diagnosis",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "covid_interferon_cytokine_bridge", "autonomous_unknown_discovery"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "fatigue_syndrome",
            displayName = "Fatigue syndrome / fatigue signal",
            aliases = setOf("fatigue", "tiredness", "exhaustion", "low energy", "chronic fatigue", "me cfs", "mecfs", "خمول", "تعب", "ارهاق"),
            symptoms = setOf("fatigue", "post exertional malaise", "sleep disruption", "brain fog"),
            immuneAxes = setOf("post viral fatigue", "mitochondrial stress", "HPA/sleep stress", "inflammatory fatigue", "metabolic immune fatigue"),
            searchKeywords = setOf("fatigue cytokines cohort GSE", "post viral fatigue transcriptomics PBMC", "ME CFS immune signature dataset", "fatigue inflammation IL-6 TNF cohort"),
            primaryAnchor = GTIMPrimaryAnchorV2740.FATIGUE_SYNDROME_NEUROIMMUNE_METABOLIC,
            diseaseFamily = GTIMDiseaseFamilyV2740.FATIGUE_SYNDROME,
            confidence = 82,
            claimMode = GTIMClaimModeV2740.RESEARCH_DIRECTION_ONLY,
            claimLimit = "symptom_mapping_not_medical_diagnosis",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "single_covid_identity_without_query_support"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_SYNDROME_EXPLORATION
        ),
        Profile(
            id = "fever_syndrome",
            displayName = "Fever syndrome",
            aliases = setOf("fever", "temperature", "حمى", "الحمي", "حراره"),
            symptoms = setOf("fever", "systemic inflammation", "infectious differential"),
            immuneAxes = setOf("infectious/inflammatory differential", "innate cytokine response", "pathogen emergence screening"),
            searchKeywords = setOf("fever syndrome cytokines cohort", "acute fever transcriptomics GSE", "infectious inflammatory differential dataset"),
            primaryAnchor = GTIMPrimaryAnchorV2740.GENERAL_FEVER_SYNDROME,
            diseaseFamily = GTIMDiseaseFamilyV2740.GENERAL_FEVER_SYNDROME,
            confidence = 82,
            claimMode = GTIMClaimModeV2740.RESEARCH_DIRECTION_ONLY,
            claimLimit = "symptom_mapping_not_medical_diagnosis",
            forbiddenConflations = setOf("single_pathogen_lock_without_query_support"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_SYNDROME_EXPLORATION
        ),
        Profile(
            id = "pcos_reproductive_metabolic",
            displayName = "PCOS",
            aliases = setOf("pcos", "polycystic ovary", "polycystic ovarian", "تكيس", "المبايض"),
            symptoms = setOf("irregular cycles", "androgen excess", "insulin resistance", "reproductive endocrine symptoms"),
            immuneAxes = setOf("reproductive hormone axis", "insulin resistance", "metabolic inflammation", "gut/metabolic axis"),
            searchKeywords = setOf("PCOS insulin resistance inflammation", "PCOS cytokines cohort", "polycystic ovary microbiome metabolic axis"),
            primaryAnchor = GTIMPrimaryAnchorV2740.PCOS_REPRODUCTIVE_METABOLIC,
            diseaseFamily = GTIMDiseaseFamilyV2740.PCOS_REPRODUCTIVE_METABOLIC,
            confidence = 80,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "research_mapping_only_not_diagnosis",
            forbiddenConflations = setOf("direct_yeast_causes_pcos_strong_claim_without_evidence", "allergy_type2_ige_mast_eosinophil"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "thyroid_hashimoto",
            displayName = "Thyroid / Hashimoto",
            aliases = setOf("hashimoto", "thyroiditis", "autoimmune thyroid", "thyroid", "hypothyroid", "hypothyroidism", "غده", "الغده", "خمول الغده"),
            symptoms = setOf("fatigue", "cold intolerance", "weight change", "low energy"),
            immuneAxes = setOf("thyroid autoantibody", "TPO/Tg antibody", "thyroid axis", "microbiome thyroid axis"),
            searchKeywords = setOf("Hashimoto thyroiditis cytokines", "autoimmune thyroid transcriptomics", "thyroid microbiome immune axis"),
            primaryAnchor = GTIMPrimaryAnchorV2740.THYROID_HASHIMOTO_AUTOIMMUNE,
            diseaseFamily = GTIMDiseaseFamilyV2740.THYROID_AUTOIMMUNE,
            confidence = 80,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "research_mapping_only_not_diagnosis",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "generic_endocrine_only_without_autoimmune_context"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "asthma_type2_airway",
            displayName = "Asthma",
            aliases = setOf("asthma", "asthmatic", "airway hyperresponsiveness", "wheeze", "wheezing", "ربو"),
            symptoms = setOf("wheeze", "dyspnea", "cough", "airway hyperresponsiveness"),
            immuneAxes = setOf("type-2 airway inflammation", "epithelial barrier", "IL-4/IL-5/IL-13", "allergy microbiome modulation"),
            searchKeywords = setOf("asthma type 2 airway inflammation dataset", "asthma epithelial barrier IL-13 GSE", "asthma microbiome immune axis"),
            primaryAnchor = GTIMPrimaryAnchorV2740.ASTHMA_TYPE2_AIRWAY,
            diseaseFamily = GTIMDiseaseFamilyV2740.AIRWAY_TYPE2,
            confidence = 82,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "research_mapping_only_not_diagnosis",
            forbiddenConflations = setOf("ebola_hemorrhagic_viral_host_response", "generic_covid_route_without_query_support"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "alzheimer_neuroimmune",
            displayName = "Alzheimer neuroimmune axis",
            aliases = setOf("alzheimer", "alzheimer's", "alzheimers", "dementia", "الخرف", "الزهايمر"),
            symptoms = setOf("cognitive decline", "memory impairment", "neurodegeneration"),
            immuneAxes = setOf("microglia activation", "neuroinflammation", "amyloid/tau immune context", "gut-brain inflammation"),
            searchKeywords = setOf("Alzheimer microglia transcriptomics", "Alzheimer neuroinflammation dataset", "dementia immune cohort GSE"),
            primaryAnchor = GTIMPrimaryAnchorV2740.ALZHEIMER_NEUROIMMUNE,
            diseaseFamily = GTIMDiseaseFamilyV2740.ALZHEIMER_NEUROIMMUNE,
            confidence = 78,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "research_mapping_only_not_diagnosis",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "covid_identity_mutation_without_query_support"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        ),
        Profile(
            id = "sepsis_systemic_inflammation",
            displayName = "Sepsis",
            aliases = setOf("sepsis", "septic shock", "تعفن الدم", "إنتان", "انتان"),
            symptoms = setOf("fever", "shock", "systemic inflammation", "organ dysfunction"),
            immuneAxes = setOf("systemic inflammatory response", "innate immune dysregulation", "immune paralysis", "cytokine response"),
            searchKeywords = setOf("sepsis transcriptomics cohort", "septic shock PBMC GSE", "sepsis immune paralysis cytokine dataset"),
            primaryAnchor = GTIMPrimaryAnchorV2740.SEPSIS_SYSTEMIC_INFLAMMATION,
            diseaseFamily = GTIMDiseaseFamilyV2740.SEPSIS_SYSTEMIC_INFLAMMATION,
            confidence = 86,
            claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
            claimLimit = "syndrome_research_mapping_not_diagnosis",
            forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "covid_identity_mutation_without_query_support"),
            defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
        )
    )

    fun detect(normalizedQuery: String): Detection? {
        val q = normalizedQuery.trim()
        if (q.isBlank()) return null

        specialCaseProfile(q)?.let { (profile, alias) ->
            return Detection(
                profile = profile,
                matchedAlias = alias,
                reason = "Ontology bootstrap matched '$alias' to ${profile.id}; ${profile.claimLimit}."
            )
        }

        val candidates = diseaseProfiles.mapNotNull { profile ->
            val matched = profile.aliases.firstOrNull { alias -> containsAlias(q, alias) }
            if (matched != null) profile to matched else null
        }
        if (candidates.isEmpty()) return null
        val selected = candidates.maxWithOrNull(
            compareBy<Pair<Profile, String>> { it.first.confidence }
                .thenBy { it.second.length }
        ) ?: return null
        return Detection(
            profile = selected.first,
            matchedAlias = selected.second,
            reason = "Ontology bootstrap matched '${selected.second}' to ${selected.first.id}; ${selected.first.claimLimit}."
        )
    }

    fun profileForAnchor(anchor: GTIMPrimaryAnchorV2740): Profile? = diseaseProfiles.firstOrNull { it.primaryAnchor == anchor }

    fun searchKeywordsFor(anchor: GTIMPrimaryAnchorV2740): Set<String> = profileForAnchor(anchor)?.searchKeywords.orEmpty()

    fun symptomAliases(): Set<String> = diseaseProfiles.flatMap { it.symptoms }.toSet()

    fun learningEdgeTemplate(anchor: GTIMPrimaryAnchorV2740, newEdge: String, evidenceLevel: GTIMEvidenceLabelV2740): Map<String, String> {
        return mapOf(
            "anchor" to anchor.routeId,
            "new_edge" to newEdge,
            "evidence_level" to evidenceLevel.name,
            "promote_to_core" to "false",
            "claim_limit" to (profileForAnchor(anchor)?.claimLimit ?: "research_mapping_only_not_diagnosis")
        )
    }

    fun canPromoteLearnedEdge(evidenceLevel: GTIMEvidenceLabelV2740, hasValidAccession: Boolean, outsideContract: Boolean): Boolean {
        return evidenceLevel == GTIMEvidenceLabelV2740.CONFIRMED_EVIDENCE && hasValidAccession && !outsideContract
    }


    private fun specialCaseProfile(q: String): Pair<Profile, String>? {
        val isOutbreakFrame = listOf("epidemic", "pandemic", "outbreak", "epidemics", "وباء", "اوبئه", "الاوبئه", "جائحه", "تفشي").any { containsAlias(q, it) || q.contains(it) }
        if (isOutbreakFrame) {
            return Profile(
                id = "outbreak_surveillance_pathogen_emergence",
                displayName = "Outbreak / epidemic surveillance frame",
                aliases = setOf("epidemic", "pandemic", "outbreak"),
                symptoms = setOf("surveillance frame", "pathogen emergence", "immune escape"),
                immuneAxes = setOf("pathogen emergence", "variant/immune escape monitoring", "surveillance differential"),
                searchKeywords = setOf("outbreak pathogen emergence immune escape dataset", "epidemic surveillance immune response cohort", "pandemic immune escape comparator"),
                primaryAnchor = GTIMPrimaryAnchorV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE,
                diseaseFamily = GTIMDiseaseFamilyV2740.OUTBREAK_OR_EPIDEMIC_SURVEILLANCE,
                confidence = 85,
                claimMode = GTIMClaimModeV2740.RESEARCH_DIRECTION_ONLY,
                claimLimit = "surveillance_frame_not_single_disease_lock",
                forbiddenConflations = setOf("single_pathogen_lock_without_query_support", "single_disease_high_confidence_without_query_support"),
                defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_SYNDROME_EXPLORATION
            ) to "epidemic/outbreak surveillance frame"
        }

        val hasYeast = listOf("yeast", "fungal", "fungus", "candida", "خميره", "فطري", "فطريات").any { containsAlias(q, it) || q.contains(it) }
        val hasEndocrine = listOf("pcos", "polycystic", "thyroid", "hypothyroid", "تكيس", "الغده", "الغدة").any { containsAlias(q, it) || q.contains(it) }
        if (hasYeast && hasEndocrine) {
            return Profile(
                id = "yeast_fungal_to_endocrine_immune",
                displayName = "Yeast/fungal exposure to endocrine-immune research axis",
                aliases = setOf("yeast", "fungal", "candida"),
                symptoms = setOf("endocrine/reproductive symptoms", "thyroid symptoms", "PCOS-like research context"),
                immuneAxes = setOf("fungal exposure", "barrier dysfunction", "immune-metabolic stress", "endocrine axis"),
                searchKeywords = setOf("fungal exposure endocrine immune axis", "candida gut barrier metabolic inflammation", "yeast fungal PCOS thyroid research"),
                primaryAnchor = GTIMPrimaryAnchorV2740.YEAST_FUNGAL_ENDOCRINE_IMMUNE,
                diseaseFamily = GTIMDiseaseFamilyV2740.FUNGAL_YEAST_EXPOSURE,
                confidence = 84,
                claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                claimLimit = "exploratory_bridge_not_causal_claim",
                forbiddenConflations = setOf("direct_yeast_causes_pcos_strong_claim_without_evidence", "allergy_type2_ige_mast_eosinophil"),
                defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
            ) to "yeast/fungal + endocrine"
        }

        val hasDepression = listOf("depression", "depressive", "mood disorder", "major depressive", "اكتئاب", "الاكتئاب").any { containsAlias(q, it) || q.contains(it) }
        val hasMicrobiome = listOf("microbiome", "microbiota", "gut bacteria", "gut-brain", "gut brain", "bacteria", "بكتيريا", "ميكروبيوم").any { q.contains(it) }
        if (hasDepression && hasMicrobiome) {
            return Profile(
                id = "gut_microbiome_to_neuroinflammation",
                displayName = "Gut microbiome to depression / neuroimmune axis",
                aliases = setOf("gut bacteria depression", "microbiome depression"),
                symptoms = setOf("mood symptoms", "fatigue", "sleep disruption"),
                immuneAxes = setOf("microbiome metabolites", "tryptophan/kynurenine", "IL-6/TNF/CRP", "HPA axis"),
                searchKeywords = setOf("microbiome depression kynurenine IL-6 TNF cohort", "gut bacteria depression human cohort GSE"),
                primaryAnchor = GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION,
                diseaseFamily = GTIMDiseaseFamilyV2740.NEUROIMMUNE,
                confidence = 88,
                claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                claimLimit = "research_mapping_only_not_diagnosis",
                forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "ibd_only_identity_mutation"),
                defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
            ) to "gut microbiome + depression"
        }

        val hasPcosOnly = listOf("pcos", "polycystic", "polycystic ovary", "polycystic ovarian", "تكيس", "المبايض").any { containsAlias(q, it) || q.contains(it) }
        if (hasPcosOnly) {
            return Profile(
                id = "pcos_reproductive_metabolic",
                displayName = "PCOS / reproductive-metabolic research axis",
                aliases = setOf("pcos", "polycystic ovary", "polycystic ovarian"),
                symptoms = setOf("irregular cycles", "androgen excess", "insulin resistance", "reproductive endocrine symptoms"),
                immuneAxes = setOf("reproductive hormone axis", "insulin resistance", "metabolic inflammation", "gut/metabolic axis"),
                searchKeywords = setOf("PCOS insulin resistance inflammation", "PCOS cytokines cohort", "polycystic ovary microbiome metabolic axis"),
                primaryAnchor = GTIMPrimaryAnchorV2740.PCOS_REPRODUCTIVE_METABOLIC,
                diseaseFamily = GTIMDiseaseFamilyV2740.PCOS_REPRODUCTIVE_METABOLIC,
                confidence = 80,
                claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                claimLimit = "research_mapping_only_not_diagnosis",
                forbiddenConflations = setOf("direct_yeast_causes_pcos_strong_claim_without_evidence", "allergy_type2_ige_mast_eosinophil"),
                defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
            ) to "pcos reproductive-metabolic anchor"
        }

        if (listOf("type 1 diabetes", "t1d", "autoimmune diabetes", "beta cell", "β-cell").any { q.contains(it) }) {
            return Profile(
                id = "t1d_autoimmune_beta_cell_axis",
                displayName = "Type 1 diabetes / beta-cell autoimmunity",
                aliases = setOf("type 1 diabetes", "T1D"),
                symptoms = setOf("hyperglycemia", "fatigue", "polyuria"),
                immuneAxes = setOf("beta-cell autoimmunity", "T-cell autoimmune response", "islet inflammation"),
                searchKeywords = setOf("T1D beta cell autoimmunity GSE", "type 1 diabetes PBMC transcriptomics"),
                primaryAnchor = GTIMPrimaryAnchorV2740.T1D_AUTOIMMUNE_BETA_CELL,
                diseaseFamily = GTIMDiseaseFamilyV2740.BETA_CELL_AUTOIMMUNE,
                confidence = 86,
                claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                claimLimit = "research_mapping_only_not_diagnosis",
                forbiddenConflations = setOf("generic_diabetes_type2_metabolic_only", "allergy_type2_ige_mast_eosinophil"),
                defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
            ) to "type 1 diabetes"
        }

        if (listOf("type 2 diabetes", "t2d", "insulin resistance", "hba1c", "hyperglycemia", "glycemic", "glycaemic").any { q.contains(it) }) {
            return Profile(
                id = "type2_diabetes_insulin_resistance_inflammation_axis",
                displayName = "Type 2 diabetes / insulin resistance inflammation",
                aliases = setOf("type 2 diabetes", "T2D"),
                symptoms = setOf("hyperglycemia", "fatigue", "insulin resistance"),
                immuneAxes = setOf("insulin resistance", "adipose inflammation", "IL-6/TNF metabolic inflammation", "gut microbiome metabolic axis"),
                searchKeywords = setOf("T2D insulin resistance IL-6 TNF", "type 2 diabetes metabolic inflammation GSE"),
                primaryAnchor = GTIMPrimaryAnchorV2740.T2D_INSULIN_RESISTANCE_INFLAMMATION,
                diseaseFamily = GTIMDiseaseFamilyV2740.METABOLIC_INFLAMMATION,
                confidence = 84,
                claimMode = GTIMClaimModeV2740.ANCHOR_PROTECTED_EXPLORATORY_BRIDGE,
                claimLimit = "research_mapping_only_not_diagnosis",
                forbiddenConflations = setOf("allergy_type2_ige_mast_eosinophil", "covid_interferon_cytokine_bridge"),
                defaultRunMode = GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED
            ) to "type 2 diabetes"
        }
        return null
    }

    private fun containsAlias(q: String, alias: String): Boolean {
        val a = alias.lowercase().trim()
        if (a.isBlank()) return false
        if (a.any { !it.isLetterOrDigit() && !it.isWhitespace() }) return q.contains(a)
        val padded = " $q "
        val normalizedAlias = a.replace(Regex("\\s+"), " ")
        return padded.contains(" $normalizedAlias ") || q.contains(normalizedAlias)
    }
}
