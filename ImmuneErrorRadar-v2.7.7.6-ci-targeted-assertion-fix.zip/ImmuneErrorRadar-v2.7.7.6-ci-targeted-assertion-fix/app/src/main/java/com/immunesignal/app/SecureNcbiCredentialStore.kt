package com.immunesignal.app

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.io.IOException

/**
 * Stores optional NCBI E-utilities credentials without leaving API keys in a
 * plain filesDir text file. The legacy `ncbi_api_key.txt` path is read once as
 * a migration fallback, then deleted after a successful encrypted write.
 */
object SecureNcbiCredentialStore {
    private const val PREFS = "immune_secure_ncbi_credentials"
    private const val KEY_API_KEY = "ncbi_api_key"
    private const val KEY_CONTACT_EMAIL = "ncbi_contact_email"
    private const val LEGACY_API_KEY_FILE = "ncbi_api_key.txt"
    private const val DEFAULT_CONTACT_EMAIL = "research@vraimony.com"

    fun readApiKey(context: Context): String? {
        encryptedPrefs(context)?.getString(KEY_API_KEY, null)?.takeIf { it.isNotBlank() }?.let { return it }
        val legacy = readLegacyApiKey(context)
        if (!legacy.isNullOrBlank()) {
            saveApiKey(context, legacy)
            runCatching { context.deleteFile(LEGACY_API_KEY_FILE) }
            return legacy
        }
        return null
    }

    fun saveApiKey(context: Context, value: String) {
        val clean = value.trim()
        if (clean.isBlank()) return
        encryptedPrefs(context)?.edit()?.putString(KEY_API_KEY, clean)?.apply()
    }

    fun readContactEmail(context: Context): String {
        return encryptedPrefs(context)?.getString(KEY_CONTACT_EMAIL, null)?.takeIf { it.isNotBlank() }
            ?: DEFAULT_CONTACT_EMAIL
    }

    fun saveContactEmail(context: Context, value: String) {
        val clean = value.trim()
        if (clean.isBlank()) return
        encryptedPrefs(context)?.edit()?.putString(KEY_CONTACT_EMAIL, clean)?.apply()
    }

    private fun encryptedPrefs(context: Context) = runCatching {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            PREFS,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }.getOrNull()

    private fun readLegacyApiKey(context: Context): String? = try {
        context.openFileInput(LEGACY_API_KEY_FILE).bufferedReader(Charsets.UTF_8).use { it.readText().trim() }
            .takeIf { it.isNotBlank() }
    } catch (_: IOException) {
        null
    } catch (_: Exception) {
        null
    }
}
