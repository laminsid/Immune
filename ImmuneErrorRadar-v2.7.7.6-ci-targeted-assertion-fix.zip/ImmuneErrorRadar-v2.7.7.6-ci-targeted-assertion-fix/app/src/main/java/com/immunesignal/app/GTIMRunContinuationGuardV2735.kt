package com.immunesignal.app

import java.util.Locale

/**
 * v2.7.3.5: prevents a discovery cycle from finalizing immediately after it
 * opens a promising route but before the accession/comparator follow-up has
 * been attempted. This is a continuation guard, not an evidence upgrade.
 */
data class GTIMRunContinuationPlanV2735(
    val shouldRun: Boolean,
    val reason: String,
    val queries: List<ResearchQuery>,
    val claimLimit: String = GTIMRunContinuationGuardV2735.CLAIM_LIMIT
)

object GTIMRunContinuationGuardV2735 {
    const val CLAIM_LIMIT: String = "continuation_lookup_only_not_evidence_not_gate_closure"

    fun build(
        topicRoutePlan: GTIMTopicRoutePlanV270,
        selectedQueries: List<ResearchQuery>,
        findingsCount: Int,
        stopped: Boolean,
        stopReason: String,
        executedQueryCount: Int
    ): GTIMRunContinuationPlanV2735 {
        if (!RuntimeFeatureFlags.ENABLE_RUN_CONTINUATION_GUARD_V2735) {
            return GTIMRunContinuationPlanV2735(false, "disabled", emptyList())
        }
        if (stopped) {
            return GTIMRunContinuationPlanV2735(false, "blocked: $stopReason", emptyList())
        }

        val hasTopicRoute = topicRoutePlan.active
        val hasExplicitContinuationNeed = selectedQueries.any { query ->
            val text = (query.label + " " + query.query + " " + query.reason).lowercase(Locale.US)
            text.contains("topic-specific") ||
                text.contains("promising") ||
                text.contains("accession") ||
                text.contains("comparator") ||
                text.contains("matrix") ||
                text.contains("data availability") ||
                text.contains("gse") ||
                text.contains("prjna") ||
                text.contains("sra")
        }
        if (!hasTopicRoute && !hasExplicitContinuationNeed) {
            return GTIMRunContinuationPlanV2735(false, "no promising route continuation signal", emptyList())
        }

        val needsContinuation = findingsCount < RuntimeFeatureFlags.RUN_CONTINUATION_MIN_FINDINGS_BEFORE_STOP_V2735 ||
            executedQueryCount < RuntimeFeatureFlags.RUN_CONTINUATION_MIN_EXECUTED_QUERIES_V2735 ||
            hasTopicRoute
        if (!needsContinuation) {
            return GTIMRunContinuationPlanV2735(false, "first pass already satisfied minimum continuation budget", emptyList())
        }

        val sourceSeeds = when {
            topicRoutePlan.querySeeds.isNotEmpty() -> topicRoutePlan.querySeeds
            selectedQueries.isNotEmpty() -> selectedQueries.map { it.query }
            else -> listOf("immune response transcriptome comparator accession data availability GSE PRJNA PMID DOI")
        }

        val selectedText = selectedQueries.joinToString(" ") { it.label + " " + it.query + " " + it.reason }.lowercase(Locale.US)
        val continuationLimit = when {
            selectedText.contains("relationship") || selectedText.contains("microbiome") || selectedText.contains("mediator") ->
                RuntimeFeatureFlags.RUN_CONTINUATION_RELATIONSHIP_QUERY_LIMIT_V2738
            selectedText.contains("accession") && selectedText.contains("matrix") ->
                RuntimeFeatureFlags.RUN_CONTINUATION_ACCESSION_NO_MATRIX_QUERY_LIMIT_V2738
            else -> RuntimeFeatureFlags.RUN_CONTINUATION_QUERY_LIMIT_V2735
        }

        val continuationQueries = sourceSeeds
            .map { seed -> enrichSeed(seed) }
            .distinctBy { it.lowercase(Locale.US) }
            .take(continuationLimit)
            .mapIndexed { index, query ->
                ResearchQuery(
                    id = "q_v2735_continuation_${topicRoutePlan.primaryTopicId.ifBlank { "dynamic" }}_$index"
                        .replace(Regex("[^A-Za-z0-9_]+"), "_"),
                    label = "v2.7.3.5 continuation guard: ${topicRoutePlan.topicTitle.ifBlank { "active route" }}",
                    query = query,
                    reason = "Promising route opened but accession/comparator follow-up has not been attempted enough in this cycle. Run bounded second-pass lookup before final report. Claim limit: $CLAIM_LIMIT."
                )
            }

        return GTIMRunContinuationPlanV2735(
            shouldRun = continuationQueries.isNotEmpty(),
            reason = "promising route requires bounded second-pass lookup before cycle finalization",
            queries = continuationQueries
        )
    }

    private fun enrichSeed(seed: String): String {
        val normalized = seed.replace(Regex("\\s+"), " ").trim()
        val required = listOf(
            "data availability",
            "accession",
            "comparator",
            "matrix",
            "GSE",
            "PRJNA",
            "SRA",
            "PMID",
            "DOI",
            "human",
            "PBMC",
            "RNA-seq"
        )
        val lower = normalized.lowercase(Locale.US)
        val missing = required.filterNot { lower.contains(it.lowercase(Locale.US)) }
        return (listOf(normalized) + missing).joinToString(" ").take(420)
    }
}
