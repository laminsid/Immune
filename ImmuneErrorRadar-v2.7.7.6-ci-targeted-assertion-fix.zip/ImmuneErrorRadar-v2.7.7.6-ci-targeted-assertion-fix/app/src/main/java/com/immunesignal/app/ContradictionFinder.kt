package com.immunesignal.app

data class ContradictionTemplate(
    val axisA: String,
    val axisB: String? = null,
    val contradictionQuery: String,
    val rationale: String
)

object ContradictionFinder {
    private val templates = listOf(
        ContradictionTemplate("type2_allergy_axis", "aging_immune_axis", "Search for evidence that chronic allergy increases inflammatory burden rather than preserving immune youth.", "Allergy-aging bridge can flip direction by chronicity and inflammatory burden."),
        ContradictionTemplate("psychoneuroimmune_axis", "autonomic_vascular_axis", "Search for evidence that stress raises blood pressure rather than lowering it through histamine-like pathways.", "Autonomic effects can reverse by context and stress load."),
        ContradictionTemplate("testosterone_immune_axis", null, "Search for evidence that testosterone effects differ by sex, age, dose, and disease context.", "Hormonal immune effects are strongly context dependent."),
        ContradictionTemplate("gastric_acid_gut_axis", null, "Search for evidence separating reflux/GERD, low-acid suspicion, PPI use, and microbiome mechanisms.", "Gut-acid signals are easily confounded by medication and phenotype."),
        ContradictionTemplate("interferon_antiviral_axis", "tissue_damage_axis", "Search for evidence that interferon/antiviral activation tracks tissue damage, severity, or delayed recovery rather than protection.", "Antiviral signatures may reflect burden or damage, not benefit."),
        ContradictionTemplate("rna_transcriptomic_axis", null, "Search for batch effect, cell-composition shift, tissue-source confounding, or treatment artifact explaining the RNA signature.", "Transcriptomic signals can be route-fit artifacts without metadata controls."),
        ContradictionTemplate("bcell_antibody_axis", "type2_allergy_axis", "Search for evidence that antibody/IgE signals are nonspecific allergy burden rather than a distinct immune-state bridge.", "Antibody and Type-2 signals can be overlapping rather than causal."),
        ContradictionTemplate("diabetes_metabolic_inflammation", null, "Search for metabolic, medication, BMI, or glycemic-control confounding before interpreting immune inflammation in diabetes datasets.", "Metabolic disease can confound immune-state labels."),
        ContradictionTemplate("aging_immune_axis", null, "Search for age-stratification failures, cohort effects, and immunosenescence baselines that break the proposed immune link.", "Aging context can create apparent immune bridges without causal direction."),
        ContradictionTemplate("gastric_acid_reflux_gut_barrier", null, "Search for reflux/GERD phenotype, PPI exposure, microbiome-only evidence, and missing immune readout as alternative explanations.", "Gut-barrier/reflux adjacent-domain leads require explicit immune readout.")
    )

    fun contradictionSearchPrompts(axes: List<String>, label: String): List<String> {
        val axisSet = axes.toSet()
        val prompts = templates.mapNotNull { template ->
            val matched = if (template.axisB == null) axisSet.contains(template.axisA) else axisSet.contains(template.axisA) && axisSet.contains(template.axisB)
            if (matched) "${template.contradictionQuery} Rationale: ${template.rationale}" else null
        }.toMutableList()
        if (prompts.isEmpty()) prompts += "Search for null findings, no-association papers, failed replication, heterogeneity, negative controls, and context-dependent failures for: $label."
        return prompts.distinct().take(4)
    }
}
