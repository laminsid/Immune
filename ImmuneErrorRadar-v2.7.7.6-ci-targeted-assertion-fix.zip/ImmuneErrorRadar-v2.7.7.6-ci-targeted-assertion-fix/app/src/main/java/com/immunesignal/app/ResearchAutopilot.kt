// legacy_audit_v11051: v1.10.51 route reconciliation + evidence candidate activation
package com.immunesignal.app

// legacy audit token: v1.10.22 domain expertise continuity

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.min

// legacy_audit_version_token_v11029_autopilot: v1.10.29 learning/domain path linkage
class ResearchAutopilot(
    private val context: Context,
    private val runtimeTopicSnapshot: ResearchTopicCaptureSnapshotV2740? = null
) {
    private data class DatasetForagingRunResult(
        val findings: List<ResearchFinding>,
        val report: DatasetForagingReport
    )

    private val store = ResearchKnowledgeStore(context)

    // v1.5.4: Foundation Knowledge OS is integrated but disabled by default.
    // One-line rollback/enable point: flip this flag without touching the v1.4.5/v1.5.0 cycle.
    private val enableFoundationKnowledgeOs: Boolean = RuntimeFeatureFlags.ENABLE_FOUNDATION_KNOWLEDGE_OS

    suspend fun runCycle(
        shouldStop: () -> Boolean = { false },
        limits: ResearchRunLimits = ResearchRunLimits()
    ): ResearchCycleReport {
        val started = System.currentTimeMillis()
        val searchDeadline = started + limits.maxSearchMillis
        val seen = store.seenSourceIds()
        val seenAbstracts = seen.filter { it.startsWith("Abstract:") }.toSet()
        val seenAxisPairsBefore = store.seenAxisPairs()
        val importedSignalsRaw = store.readImportedSignals(20)
        val importedRawTextsRawV11031 = store.readImportedRawText(20)
        val importedSignals = TopicRunIsolationPolicyV2742.scopedImportedSignals(importedSignalsRaw, runtimeTopicSnapshot)
        val importedRawTextsV11031 = TopicRunIsolationPolicyV2742.scopedImportedRawTexts(importedRawTextsRawV11031, runtimeTopicSnapshot)
        val localRecords = LocalCaseStore(context).readLatest(40)
        val personalLedger = PersonalPatternLedger(localRecords, importedSignals)
        val storedSteering = store.readActiveSteering()
        val steering = TopicRunIsolationPolicyV2742.chooseSteering(runtimeTopicSnapshot, storedSteering)
        val recentReportsRaw = store.readLatestReports(20)
        val recentReports = TopicRunIsolationPolicyV2742.scopedRecentReports(recentReportsRaw, runtimeTopicSnapshot)
        val leadClosureHandoffRequestedV11035 = LeadClosureHandoffPolicy.shouldForceLeadClosure(recentReports)
        val priorLeadClosureSeedTextsV11035 = LeadClosureHandoffPolicy.extractSeedTextsFromRecentReports(recentReports)
        val manualEvidenceSeedInputsV11031 = listOfNotNull(runtimeTopicSnapshot?.normalizedTopic?.takeIf { it.isNotBlank() }) +
            importedRawTextsV11031 +
            importedSignals.map { it.title + " " + it.preview + " " + it.extractedKeywords.joinToString(" ") } +
            priorLeadClosureSeedTextsV11035
        val manualEvidenceSeedRequestedV11031 = EvidenceLeadAndManualSeedPolicy.hasManualSeedSignal(manualEvidenceSeedInputsV11031) || leadClosureHandoffRequestedV11035
        val activeCognitiveDirectiveV165 = store.readActiveCognitiveNextCycleDirective()
        val priorClosureQueriesV197 = EvidenceClosureEngine.priorClosureQueriesFromReports(recentReports)
        val priorClosureLockV197 = priorClosureQueriesV197.isNotEmpty()
        val priorLinkedSpineDirectiveV200 = LinkedCognitionSpineEngine.priorSearchDirective(recentReports)
        val priorLinkedSpineLockV200 = priorLinkedSpineDirectiveV200.active
        val priorMomentumDirectiveV199 = CognitiveMomentumEngine.priorSearchDirective(recentReports)
        val priorMomentumLockV199 = priorMomentumDirectiveV199.active && !priorClosureLockV197 && !priorLinkedSpineLockV200
        val failureMemoryStore = PersistentFailureMemory(context)
        val failureMemoryBefore = failureMemoryStore.read()
        val failurePatternLedger = FailurePatternLedger(context)
        val inheritedPersistentPatternsV145 = failureMemoryBefore.records.map { record ->
            FailurePattern(
                id = "PERSISTENT:${record.rootCause}:${record.sourceFamily}",
                rootCause = record.rootCause,
                route = "unknown_route",
                hypothesisId = null,
                occurrenceCount = record.timesFailed,
                lastSeenMillis = record.lastAttemptedAtMillis,
                datasetAccessions = emptyList(),
                suggestedAction = "Inherited from persistent failure memory; force next source: ${record.forcedNextSource}."
            )
        }
        val recentFailurePatternsBefore = (failurePatternLedger.getRecent(hours = 168) + inheritedPersistentPatternsV145)
            .distinctBy { it.id }
        val stagnationPlan = AutonomousStagnationEngine.planFromRecentReports(recentReports, limits, failureMemoryBefore)
        val learningPivot = ResearchLearningLoopEngine.pivotFromRecentReports(recentReports)
        val appliedPivot = if (learningPivot.pivotType != "NO_PIVOT") learningPivot else stagnationPlan.pendingPivot
        val (effectiveMaxQueries, effectiveResultsPerQuery) = EngineRuntimeStatus.enforceQueryBudget(
            baseLimits = limits,
            appliedPivot = appliedPivot,
            stagnationPlan = stagnationPlan
        )
        val priorSearchDirectiveV203 = ResearchSearchDirectiveResolver.resolvePrior(
            closureQueries = priorClosureQueriesV197,
            linkedSpine = priorLinkedSpineDirectiveV200,
            momentum = priorMomentumDirectiveV199,
            baseMaxQueries = effectiveMaxQueries,
            baseResultsPerQuery = effectiveResultsPerQuery
        )
        val priorUnifiedSearchLockV203 = priorSearchDirectiveV203.active
        val recentFindings = store.readRecentFindings(120)
        val autonomousPlan = AutonomousResearchPlanner().plan(
            latestReports = recentReports,
            recentFindings = recentFindings,
            importedSignals = importedSignals,
            steering = steering,
            seenAxisPairs = seenAxisPairsBefore
        )
        val plannedQueries = QueryPlanner().build(
            plan = autonomousPlan,
            steering = steering,
            pivot = appliedPivot,
            maxQueries = effectiveMaxQueries
        )
        val findings = mutableListOf<ResearchFinding>()
        val executedQueries = mutableListOf<ResearchQuery>()
        val executedQueryIds = mutableSetOf<String>()
        val runtimeDiagnostics = mutableListOf<String>()
        val autonomousDiscoveryDecisionV2743 = AutonomousDiscoveryModeV2743.fromSnapshot(runtimeTopicSnapshot)
        if (autonomousDiscoveryDecisionV2743.active) {
            runtimeDiagnostics += "AutonomousDiscoveryModeV2743:${autonomousDiscoveryDecisionV2743.selectedCandidateId}:${autonomousDiscoveryDecisionV2743.state}"
        }

        fun recordRuntimeIssue(stage: String, error: Throwable) {
            runtimeDiagnostics += ResearchCycleSearchStage.runtimeIssue(stage, error)
        }
        var repeatedSkipped = 0
        var stopped = false
        var stopReason = "completed"
        var runtimeFailoverApplied = false
        val initialResearchState = EngineRuntimeStatus.stateFor(appliedPivot, stagnationPlan.active)
        val hypothesisShards = HypothesisDecomposer.decompose(
            globalQuestion = runtimeTopicSnapshot?.normalizedTopic
                ?.takeIf { it.isNotBlank() }
                ?.let { "Which public datasets can map trigger-response-outcome immune patterns for the user topic: $it?" }
                ?: "Which public datasets can map trigger-response-outcome immune patterns across allergy, autoimmunity, and viral response?"
        )
        val fallbackRouteContextV271 = listOfNotNull(
            RuntimeCrashSafetyAndTopicGuardV2740.routeText(runtimeTopicSnapshot),
            steering?.focusQuestion,
            steering?.variables?.joinToString(" "),
            steering?.requiredTerms?.joinToString(" "),
            steering?.inferredAxes?.joinToString(" "),
            importedSignals.joinToString(" ") { it.title + " " + it.preview + " " + it.extractedKeywords.joinToString(" ") },
            importedRawTextsV11031.joinToString(" "),
            autonomousPlan.lanes.firstOrNull()?.label
        ).joinToString(" ").replace(Regex("\\s+"), " ").trim()
        val rawTopicRouteContextV271 = TopicIsolationAndScoreGateV2741.searchRouteContext(
            snapshot = runtimeTopicSnapshot,
            fallbackContext = fallbackRouteContextV271
        ).replace(Regex("\\s+"), " ").trim()
        val forcedClosureInputGuardV2738 = GTIMForcedClosureCommandGuardV2737.evaluate(rawTopicRouteContextV271)
        val topicRouteContextV271 = GTIMForcedClosureCommandGuardV2737.rewriteForRouting(rawTopicRouteContextV271)
        val runDecisionContractV2741 = GTIMRunContractRuntimeV2740.beginRun(
            rawQuery = runtimeTopicSnapshot?.normalizedTopic?.takeIf { it.isNotBlank() }
                ?: topicRouteContextV271,
            inputMode = if (runtimeTopicSnapshot?.autonomousDiscovery == true || runtimeTopicSnapshot?.normalizedTopic.isNullOrBlank()) {
                GTIMInputModeV2740.AUTONOMOUS_DISCOVERY
            } else {
                GTIMInputModeV2740.USER_QUERY
            },
            accessionCount = 0,
            matrixState = "DGE_NOT_READY_NO_ACCESSION"
        )
        runtimeDiagnostics += "GTIMRunDecisionContractV2741:${runDecisionContractV2741.runMode}:${runDecisionContractV2741.primaryAnchor.routeId}:cap=${runDecisionContractV2741.evidenceCaps.dataQualityMax}/${runDecisionContractV2741.evidenceCaps.evidenceStrengthMax}/${runDecisionContractV2741.evidenceCaps.routeConfidenceMax}"
        if (forcedClosureInputGuardV2738.active) {
            runtimeDiagnostics += "GTIMForcedClosureCommandGuardV2737:input_rewritten_before_search:${forcedClosureInputGuardV2738.detectedPatterns.joinToString(",")}"
        }
        val topicRoutePlanForSearchV271 = if (RuntimeFeatureFlags.ENABLE_TOPIC_SPECIFIC_ROUTE_BUILDER_V270 && topicRouteContextV271.isNotBlank()) {
            GTIMTopicSpecificRouteBuilderV270.build(topicRouteContextV271)
        } else {
            GTIMTopicRoutePlanV270.empty()
        }
        val relationshipPlanForSearchV2738 = GTIMRelationshipDiscoveryRouterV2736.build(topicRouteContextV271)
        val microbiomeBridgePlanForSearchV2738 = GTIMGeneralMicrobiomeImmuneBridgeV2732.build(topicRouteContextV271)
        val expansionLockForSearchV2738 = GTIMExpansionLockV2738.evaluate(recentReports)
        if (expansionLockForSearchV2738.active) {
            runtimeDiagnostics += "GTIMExpansionLockV2738:${expansionLockForSearchV2738.state}:${expansionLockForSearchV2738.reason}"
        }
        var datasetForagingReport = DatasetForagingReport.empty()

        suspend fun runQueryBatch(queryBatch: List<ResearchQuery>, retMax: Int) {
            val result = ResearchCycleSearchStage.executeBatch(
                queryBatch = queryBatch,
                retMax = retMax,
                seenSourceIds = seen,
                existingFindings = findings,
                existingExecutedQueryIds = executedQueryIds,
                shouldStop = shouldStop,
                searchDeadlineMillis = searchDeadline,
                searchPubMed = ::searchPubMed,
                fetchPubMedSummariesBatch = { pmids, query ->
                    fetchPubMedSummariesBatch(pmids, query, personalLedger, limits, seenAbstracts)
                }
            )
            findings += result.findings
            executedQueries += result.executedQueries
            executedQueryIds.clear()
            executedQueryIds += result.executedQueryIds
            repeatedSkipped += result.repeatedSkipped
            runtimeDiagnostics += result.runtimeDiagnostics
            if (result.stopped) {
                stopped = true
                stopReason = result.stopReason
            }
        }

        val learningValueModeActiveV11033 = ImmuneLearningValueModePolicy.shouldForceDatasetFirst(
            steering = steering,
            importedSignals = importedSignals,
            importedRawTexts = importedRawTextsV11031,
            recentReports = recentReports
        )
        val datasetHuntUnlockDecisionV108 = DatasetHuntSearchUnlockPolicy.evaluate(
            recentReports = recentReports,
            researchState = initialResearchState,
            priorDirective = priorSearchDirectiveV203,
            memory = failureMemoryBefore,
            learningValueModeActive = learningValueModeActiveV11033
        )
        val evidenceFirstDirectiveRequestsDatasetV108 = priorSearchDirectiveV203.mode == "EVIDENCE_FIRST_ACCESSION_SEARCH" ||
            priorSearchDirectiveV203.reason.startsWith("EVIDENCE_FIRST", ignoreCase = true)
        val learningValueDatasetFirstAllowedV11033 = learningValueModeActiveV11033 && datasetHuntUnlockDecisionV108.allowDatasetAccessionSearch
        val routerRequestsDatasetFirstV108 = DirectDatasetSourceRouter.shouldRunDatasetFirst(
            recentReports = recentReports + listOf(priorSearchDirectiveV203.mode, priorSearchDirectiveV203.reason),
            researchState = initialResearchState,
            appliedPivot = appliedPivot,
            memory = failureMemoryBefore
        )
        val datasetFirstRequested = manualEvidenceSeedRequestedV11031 ||
            leadClosureHandoffRequestedV11035 ||
            learningValueDatasetFirstAllowedV11033 ||
            ((!priorSearchDirectiveV203.blockDatasetFirst ||
                datasetHuntUnlockDecisionV108.allowDatasetAccessionSearch ||
                evidenceFirstDirectiveRequestsDatasetV108) && routerRequestsDatasetFirstV108)
        val evidenceFirstForagerModeV108 = datasetFirstRequested &&
            (leadClosureHandoffRequestedV11035 || learningValueDatasetFirstAllowedV11033 || datasetHuntUnlockDecisionV108.allowDatasetAccessionSearch || evidenceFirstDirectiveRequestsDatasetV108)
        if (datasetFirstRequested) {
            val forage = runDatasetFirstForaging(
                shards = hypothesisShards,
                memory = failureMemoryBefore,
                personalLedger = personalLedger,
                seen = seen,
                executedQueries = executedQueries,
                executedQueryIds = executedQueryIds,
                recordRuntimeIssue = ::recordRuntimeIssue,
                shouldStop = shouldStop,
                searchDeadline = searchDeadline,
                evidenceFirstBudget = evidenceFirstForagerModeV108,
                steering = steering,
                recentReports = recentReports,
                manualEvidenceSeeds = manualEvidenceSeedInputsV11031
            )
            findings += forage.findings
            datasetForagingReport = forage.report
        }

        val datasetHuntUnlockAppliedV108 = datasetFirstRequested && (learningValueDatasetFirstAllowedV11033 || datasetHuntUnlockDecisionV108.allowDatasetAccessionSearch)
        val foragerNetworkQueryExecutedV11015 = datasetForagingReport.sourceFamiliesAttempted.any { it != "ARCHIVE_OR_REFRAME_ROUTE" } &&
            executedQueries.any { it.id.startsWith("q_v142_") }
        val zeroQueryRecoveryQueriesV11015 = if (datasetFirstRequested && executedQueries.isEmpty() && datasetForagingReport.active) {
            DatasetQueryCompiler.zeroQueryAccessionRecoveryQueries(failureMemoryBefore).take(1)
        } else {
            emptyList()
        }
        val evidenceFirstForagerExecutedV108 = evidenceFirstForagerModeV108 && foragerNetworkQueryExecutedV11015
        val creativeContinuationPlanV11012 = CreativeContinuationPolicy.build(
            datasetForagingReport = datasetForagingReport,
            shards = hypothesisShards,
            memory = failureMemoryBefore
        )
        val normalPostForagerQueriesV203 = when {
            zeroQueryRecoveryQueriesV11015.isNotEmpty() -> zeroQueryRecoveryQueriesV11015
            evidenceFirstForagerExecutedV108 && creativeContinuationPlanV11012.active -> creativeContinuationPlanV11012.queries
            evidenceFirstForagerModeV108 -> emptyList()
            datasetFirstRequested -> DatasetQueryCompiler.compile(hypothesisShards, failureMemoryBefore).take(effectiveMaxQueries)
            else -> plannedQueries
        }
        val priorDirectiveForPostForagerV108 = when {
            zeroQueryRecoveryQueriesV11015.isNotEmpty() -> priorSearchDirectiveV203.copy(
                active = true,
                mode = "ZERO_QUERY_ACCESSION_RECOVERY",
                governingLayer = "accession_acquisition_zero_query_recovery",
                queries = zeroQueryRecoveryQueriesV11015,
                reason = "v1.10.15 zero-query recovery: dataset-first forager was active but produced only an offline/archive marker or empty plan; execute one bounded accession-mining query before archive/reframe.",
                maxQueries = 1,
                maxResultsPerQuery = minOf(10, effectiveResultsPerQuery),
                blockDatasetFirst = false,
                trace = priorSearchDirectiveV203.trace + datasetHuntUnlockDecisionV108.trace + listOf(
                    "accession_acquisition:zero_query_recovery=active",
                    "accession_acquisition:query=${zeroQueryRecoveryQueriesV11015.firstOrNull()?.id ?: "none"}"
                )
            )
            evidenceFirstForagerExecutedV108 && creativeContinuationPlanV11012.active -> priorSearchDirectiveV203.copy(
                active = true,
                mode = creativeContinuationPlanV11012.mode,
                governingLayer = "creative_hypothesis_forge",
                queries = creativeContinuationPlanV11012.queries,
                reason = creativeContinuationPlanV11012.reason,
                maxQueries = creativeContinuationPlanV11012.maxQueries,
                maxResultsPerQuery = creativeContinuationPlanV11012.maxResultsPerQuery,
                blockDatasetFirst = false,
                trace = priorSearchDirectiveV203.trace + datasetHuntUnlockDecisionV108.trace + listOf(
                    "dataset_hunt_unlock:evidence_first_forager_completed",
                    "creative_hypothesis_forge:continuation_query=${creativeContinuationPlanV11012.queries.firstOrNull()?.id ?: "none"}",
                    "creative_hypothesis_forge:claim_limit=${creativeContinuationPlanV11012.claimLimit}"
                )
            )
            evidenceFirstForagerExecutedV108 -> priorSearchDirectiveV203.copy(
                active = false,
                mode = "EVIDENCE_FIRST_FORAGER_EXECUTED",
                governingLayer = if (datasetHuntUnlockAppliedV108) "dataset_hunt_unlock" else "linked_cognition_spine",
                queries = emptyList(),
                reason = if (datasetHuntUnlockAppliedV108) datasetHuntUnlockDecisionV108.reason else "EVIDENCE_FIRST: bounded accession forager executed; no additional same-cycle search is allowed.",
                maxQueries = 0,
                maxResultsPerQuery = 0,
                blockDatasetFirst = false,
                trace = priorSearchDirectiveV203.trace + datasetHuntUnlockDecisionV108.trace + listOf(
                    if (learningValueModeActiveV11033) "dataset_hunt_unlock:learning_value_mode_forager_consumed_same_cycle_budget" else "dataset_hunt_unlock:evidence_first_forager_consumed_same_cycle_budget"
                )
            )
            else -> priorSearchDirectiveV203
        }
        val postForagerDirectiveV203 = ResearchSearchDirectiveResolver.resolveAfterForager(
            prior = priorDirectiveForPostForagerV108,
            datasetForagingReport = datasetForagingReport,
            baseQueries = normalPostForagerQueriesV203,
            baseMaxQueries = if (datasetHuntUnlockAppliedV108) 1 else effectiveMaxQueries,
            baseResultsPerQuery = if (datasetHuntUnlockAppliedV108) 3 else effectiveResultsPerQuery
        )
        val postForagerQueriesBase = postForagerDirectiveV203.queries
        val postForagerMaxQueriesV197 = postForagerDirectiveV203.maxQueries
        val (postForagerQueriesLinkedV165, cognitiveNextCyclePlanV165) = CognitiveNextCycleBridge.applyToQueries(
            baseQueries = postForagerQueriesBase,
            directive = activeCognitiveDirectiveV165,
            maxQueries = postForagerMaxQueriesV197
        )
        if (cognitiveNextCyclePlanV165.directiveConsumed && activeCognitiveDirectiveV165 != null) {
            store.markCognitiveNextCycleDirectiveConsumed(activeCognitiveDirectiveV165)
        }
        val (postForagerQueriesEvidenceRankedV170, evidenceGainQueryRankerReportV170) = EvidenceGainQueryRanker.rank(
            queries = postForagerQueriesLinkedV165,
            directive = activeCognitiveDirectiveV165,
            recentFailurePatterns = recentFailurePatternsBefore
        )
        val foundationBridgeV151 = FoundationKnowledgeIntegrationBridge(
            context = context,
            enableFoundationKnowledge = enableFoundationKnowledgeOs
        )
        val foundationAnalysisV151 = foundationBridgeV151.analyzeWithFoundation(
            queryText = postForagerQueriesEvidenceRankedV170.joinToString(" ") { it.query },
            extractedMetadata = ((steering?.variables ?: emptyList()) +
                hypothesisShards.flatMap { it.querySeeds + listOf(it.label, it.evidenceQuestion) } +
                postForagerQueriesEvidenceRankedV170.flatMap { it.query.split(" ").take(12) })
                .map { it.trim().lowercase(Locale.US) }
                .filter { it.isNotBlank() }
                .distinct()
                .take(80),
            datasetType = "unknown"
        )
        val phaseSpineReportV205 = ResearchCyclePhaseSpine.build()
        val queryFeedbackPlanV145 = QueryFeedbackPlanner.applyNoCandidateLearning(
            base = QueryFeedbackPlanner.improveBatch(postForagerQueriesEvidenceRankedV170, recentFailurePatternsBefore),
            records = datasetForagingReport.noCandidateLearningRecords
        )
        val effectiveResultsForThisPass = postForagerDirectiveV203.maxResultsPerQuery
        val unifiedSearchLockAfterForagerV204 = postForagerDirectiveV203.active || postForagerDirectiveV203.blockDatasetFirst || datasetHuntUnlockAppliedV108
        val selectedSearchQueriesV206 = ResearchCyclePlanStage.enforceSearchBudget(
            directive = postForagerDirectiveV203,
            candidateQueries = queryFeedbackPlanV145.improvedQueries
        )
        val topicRouteDirectQueriesV271 = if (topicRoutePlanForSearchV271.active) {
            topicRoutePlanForSearchV271.querySeeds
                .take(RuntimeFeatureFlags.TOPIC_SPECIFIC_ROUTE_QUERY_LIMIT_V270.coerceAtMost(4))
                .mapIndexed { idx, seed ->
                    ResearchQuery(
                        id = "q_v271_topic_route_${topicRoutePlanForSearchV271.primaryTopicId}_$idx".replace(Regex("[^A-Za-z0-9_]+"), "_"),
                        label = "v2.7.2 topic-specific direct route: ${topicRoutePlanForSearchV271.topicTitle}",
                        query = seed,
                        reason = "Topic-specific route query is injected before the generic post-forager batch so a new topic opens its own evidence path in the same cycle. Claim limit: ${GTIMTopicSpecificRouteBuilderV270.CLAIM_LIMIT}."
                    )
                }
        } else {
            emptyList()
        }
        val relationshipDirectQueriesV2738 = if (relationshipPlanForSearchV2738.active) {
            (relationshipPlanForSearchV2738.supportingLeadQueries + relationshipPlanForSearchV2738.contradictionQueries)
                .take(4)
                .mapIndexed { idx, seed ->
                    ResearchQuery(
                        id = "q_v2738_relationship_${relationshipPlanForSearchV2738.matchedArchetype}_$idx".replace(Regex("[^A-Za-z0-9_]+"), "_"),
                        label = "v2.7.3.8 relationship discovery direct query: ${relationshipPlanForSearchV2738.matchedArchetype}",
                        query = seed,
                        reason = "Relationship discovery queries are executed in the same cycle, not only printed in the brief. Claim limit: ${GTIMRelationshipDiscoveryRouterV2736.CLAIM_LIMIT}."
                    )
                }
        } else {
            emptyList()
        }
        val microbiomeDirectQueriesV2738 = if (microbiomeBridgePlanForSearchV2738.active) {
            microbiomeBridgePlanForSearchV2738.querySeeds
                .take(4)
                .mapIndexed { idx, seed ->
                    ResearchQuery(
                        id = "q_v2738_microbiome_bridge_$idx",
                        label = "v2.7.3.8 general microbiome immune bridge direct query",
                        query = seed,
                        reason = "General microbiome bridge is connected to real query execution; lookup-only, not proof. Claim limit: ${GTIMGeneralMicrobiomeImmuneBridgeV2732.CLAIM_LIMIT}."
                    )
                }
        } else {
            emptyList()
        }
        val autonomousDirectQueriesV2743 = AutonomousDiscoveryModeV2743.autonomousQueries(autonomousDiscoveryDecisionV2743, maxQueries = 3)
        val selectedSearchQueriesPreContractV2741 = (autonomousDirectQueriesV2743 + topicRouteDirectQueriesV271 + relationshipDirectQueriesV2738 + microbiomeDirectQueriesV2738 + selectedSearchQueriesV206)
            .distinctBy { it.query.lowercase(Locale.US) }
        val contractSafeQueryTextsV2741 = GTIMRunContractRuntimeV2740.filterQueryTexts(selectedSearchQueriesPreContractV2741.map { it.query }).toSet()
        val selectedSearchQueriesPreLockV2738 = selectedSearchQueriesPreContractV2741
            .filter { it.query in contractSafeQueryTextsV2741 || runDecisionContractV2741.runMode == GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION }
            .ifEmpty {
                listOf(
                    ResearchQuery(
                        id = "q_v2741_contract_anchor_fallback",
                        label = "v2.7.4.1 protected anchor fallback: ${runDecisionContractV2741.primaryAnchor.routeId}",
                        query = runDecisionContractV2741.allowedSeeds.take(4).joinToString(" "),
                        reason = "All unsafe cross-topic queries were filtered by GTIMRunDecisionContract; fallback stays inside the protected anchor/allowed bridge set."
                    )
                )
            }
            .distinctBy { it.query.lowercase(Locale.US) }
        val selectedSearchQueriesTopicIsolatedV2742 = TopicRunIsolationPolicyV2742.filterQueriesForCurrentTopic(
            queries = selectedSearchQueriesPreLockV2738,
            snapshot = runtimeTopicSnapshot,
            maxQueries = selectedSearchQueriesPreLockV2738.size.coerceAtLeast(1)
        )
        runtimeDiagnostics += TopicRunIsolationPolicyV2742.isolationTrace(
            snapshot = runtimeTopicSnapshot,
            storedReports = recentReportsRaw.size,
            scopedReports = recentReports.size,
            originalQueries = selectedSearchQueriesPreLockV2738.size,
            filteredQueries = selectedSearchQueriesTopicIsolatedV2742.size
        )
        val selectedSearchQueriesWithTopicV271 = GTIMExpansionLockV2738.filterQueries(
            report = expansionLockForSearchV2738,
            queries = selectedSearchQueriesTopicIsolatedV2742,
            fallbackQueries = TopicRunIsolationPolicyV2742.topicFirstQueries(runtimeTopicSnapshot).ifEmpty { selectedSearchQueriesV206 }
        ).take(selectedSearchQueriesTopicIsolatedV2742.size.coerceAtLeast(1))
        val cyclePlanStageReportV206 = ResearchCyclePlanStage.buildReport(
            directive = postForagerDirectiveV203,
            candidateQueries = queryFeedbackPlanV145.improvedQueries,
            selectedQueries = selectedSearchQueriesWithTopicV271,
            phaseSpine = phaseSpineReportV205
        )
        runQueryBatch(selectedSearchQueriesWithTopicV271, effectiveResultsForThisPass)

        // v1.10.7: runtime failover is now delegated to the search stage.
        // This keeps the search-lock invariant in one place and makes future
        // search-stage repairs possible without editing the whole runCycle body.
        val runtimeFailoverPlanV207 = ResearchCycleSearchStage.buildRuntimeFailoverPlan(
            unifiedSearchLockAfterForager = unifiedSearchLockAfterForagerV204,
            stopped = stopped,
            newFindingsCount = findings.size,
            repeatedSkipped = repeatedSkipped,
            effectiveMaxQueries = effectiveMaxQueries,
            effectiveResultsPerQuery = effectiveResultsPerQuery
        )
        if (runtimeFailoverPlanV207.shouldRun) {
            runtimeFailoverApplied = true
            runQueryBatch(runtimeFailoverPlanV207.queries, runtimeFailoverPlanV207.resultsPerQuery)
        }

        val continuationPlanV2735 = GTIMRunContinuationGuardV2735.build(
            topicRoutePlan = topicRoutePlanForSearchV271,
            selectedQueries = selectedSearchQueriesWithTopicV271,
            findingsCount = findings.size,
            stopped = stopped,
            stopReason = stopReason,
            executedQueryCount = executedQueries.size
        )
        if (continuationPlanV2735.shouldRun && !stopped) {
            runtimeDiagnostics += "GTIMRunContinuationGuardV2735:${continuationPlanV2735.reason}"
            runQueryBatch(continuationPlanV2735.queries, minOf(effectiveResultsForThisPass.coerceAtLeast(8), 12))
        }

        val searchFinished = System.currentTimeMillis()
        val learningDeadline = searchFinished + limits.maxLearningMillis
        val ranked = learnAndRank(
            findings = findings,
            importedSignals = importedSignals,
            steering = steering,
            shouldStop = shouldStop,
            deadlineMillis = learningDeadline
        )
        val completed = System.currentTimeMillis()
        if (!stopped && shouldStop()) { stopped = true; stopReason = "stopped_by_user" }
        if (!stopped && completed >= learningDeadline) { stopped = true; stopReason = "learning_limit_${limits.maxLearningMillis / (60L * 1000L)}_min_reached" }

        val newAxisPairs = computeNewAxisPairs(ranked, seenAxisPairsBefore)
        val dnaRnaSignals = ranked.count { it.matchedAxes.any { axis -> axis == "dna_genomic_axis" || axis == "rna_transcriptomic_axis" } }
        val freshnessReportV145 = EvidenceFreshnessScorer.report(ranked)
        val learningRuleMatchesV11021 = LearningRuleEngine.evaluate(ranked)
        val routeFingerprintReportV11021 = RouteFingerprintGuard.evaluate(executedQueries, store.readLatestReports(RuntimeFeatureFlags.ROUTE_FINGERPRINT_LOOKBACK))
        val hypothesisCards = HypothesisRankingEngine.rank(ranked)
        val hypothesisObjects = HypothesisObjectFactory.build(hypothesisCards, ranked, importedSignals)
        val learningDeltaCards = LearningDeltaEngine.build(hypothesisObjects, store.readLatestReports(8))
        val mistakeRiskCards = ResearchMistakeLibrary.topRisks(hypothesisObjects, ranked)
        val baseResearchStateSummary = ResearchStateEngine.summarize(hypothesisObjects, mistakeRiskCards)
        val globalImmuneIntelligence = GlobalImmuneIntelligenceEngine.build(ranked, importedSignals, steering)
        val datasetCandidatesV133 = ranked
            .flatMap { DatasetCandidateExtractor.extractFromFinding(it) }
            .distinctBy { it.datasetId + it.sourceTitle }
            .sortedByDescending { it.priorityScore }
            .take(12)
        val datasetCandidatesV137 = (datasetForagingReport.candidates + DatasetAccessionResolver.fromFindings(ranked))
            .distinctBy { it.accession + ":" + it.sourceFindingId }
            .sortedByDescending { it.usabilityScore }
            .take(30)
        val routeFitAssessmentsV144 = RouteFitGate.evaluate(datasetCandidatesV137, ranked, hypothesisShards)
        val triageResultsV145 = MLDatasetTriageEngine.triage(datasetCandidatesV137, routeFitAssessmentsV144)
        val candidateActionReportV158 = CandidateActionResolver.resolve(
            candidates = datasetCandidatesV137,
            triageResults = triageResultsV145,
            routeFits = routeFitAssessmentsV144
        )
        val parseCandidateAccessionsV158 = candidateActionReportV158.parseAccessions.toSet()
        val parseCandidatesV158 = datasetCandidatesV137.filter { it.accession in parseCandidateAccessionsV158 }
        val parsedMetadataV158 = MinimumMetadataParser.parse(parseCandidatesV158, ranked, candidateActionReportV158)
        val triageReportV145 = MLDatasetTriageEngine.report(triageResultsV145, parseCandidatesV158)
        val contrastiveReportV158 = ContrastiveEvidenceGate.evaluate(parsedMetadataV158)
        val preliminaryForagerV158 = datasetForagingReport.copy(
            candidates = datasetCandidatesV137,
            parsedMetadata = parsedMetadataV158,
            contrastiveReport = contrastiveReportV158,
            evidenceHypergraph = EvidenceHypergraphLite.build(parsedMetadataV158),
            cumulativeEvidence = CumulativeEvidenceScorer.score(emptyList(), parsedMetadataV158, routeFitAssessmentsV144),
            routeFitAssessments = routeFitAssessmentsV144,
            triageReport = triageReportV145,
            candidateActionReport = candidateActionReportV158,
            queryFeedbackPlan = queryFeedbackPlanV145,
            freshnessReport = freshnessReportV145
        )
        val evidenceObjects = EvidenceObjectFactory.build(ranked, datasetCandidatesV137, routeFitAssessmentsV144).take(32)
        datasetForagingReport = preliminaryForagerV158.copy(
            cumulativeEvidence = CumulativeEvidenceScorer.score(evidenceObjects, parsedMetadataV158, routeFitAssessmentsV144)
        )
        val discoveryReadiness = DiscoveryReadinessScorer.score(evidenceObjects, datasetCandidatesV137, routeFitAssessmentsV144)
        val scoreSeparationV144 = RouteFitGate.separation(
            candidates = datasetCandidatesV137,
            routeFits = routeFitAssessmentsV144,
            discoveryReadiness = discoveryReadiness,
            evidenceObjects = evidenceObjects
        )
        val reportConsistencyGuardV158 = ReportConsistencyGuard.includePathLinkageWarnings(
            base = ReportConsistencyGuard.evaluate(
                routeFits = routeFitAssessmentsV144,
                parsedMetadata = parsedMetadataV158,
                scoreSeparation = scoreSeparationV144,
                candidateActionReport = candidateActionReportV158
            ),
            pathLinkageReport = datasetForagingReport.pathLinkageReport
        )
        val metadataClosureReportTopV11035 = LeadClosureHandoffPolicy.metadataClosure(
            leadObjects = datasetForagingReport.leadObjects,
            candidates = datasetCandidatesV137,
            parsedMetadata = parsedMetadataV158
        )
        val leadClosureHandoffReportTopV11035 = LeadClosureHandoffPolicy.evaluateHandoff(
            recentReports = recentReports,
            leadObjects = datasetForagingReport.leadObjects,
            breakthrough = datasetForagingReport.evidenceDiscoveryBreakthroughReport,
            metadataClosure = metadataClosureReportTopV11035
        )
        val unknownRouteClassificationTopV11035 = LeadClosureHandoffPolicy.classifyUnknownRoute(
            leadObjects = datasetForagingReport.leadObjects,
            candidates = datasetCandidatesV137,
            routeFits = routeFitAssessmentsV144,
            recentReports = recentReports
        )
        val ebvLeadVerificationTopV11037 = EBVLeadVerificationPolicy.evaluate(
            leadObjects = datasetForagingReport.leadObjects,
            candidates = datasetCandidatesV137,
            metadataClosure = metadataClosureReportTopV11035,
            routeReport = unknownRouteClassificationTopV11035,
            recentReports = recentReports
        )
        val evidencePriorSelectionTopV11038 = ImmuneEvidencePriorMatrix.select(
            steering = steering,
            leadObjects = datasetForagingReport.leadObjects,
            candidates = datasetCandidatesV137,
            metadataClosure = metadataClosureReportTopV11035,
            routeReport = unknownRouteClassificationTopV11035,
            ebvReport = ebvLeadVerificationTopV11037,
            recentReports = recentReports
        )
        val biomedicalOntologyTopV11041 = BiomedicalResearchOntologyV11041.evaluate(
            steering = steering,
            leadObjects = datasetForagingReport.leadObjects,
            candidates = datasetCandidatesV137,
            evidencePrior = evidencePriorSelectionTopV11038,
            recentReports = recentReports
        )
        val biomedicalConceptBridgeTopV11042 = BiomedicalConceptBridgeV11042.evaluate(
            ontology = biomedicalOntologyTopV11041,
            evidencePrior = evidencePriorSelectionTopV11038,
            ebv = ebvLeadVerificationTopV11037,
            metadataClosure = metadataClosureReportTopV11035,
            recentReports = recentReports
        )
        val modernMedicalTechnologyTopV11043 = ModernMedicalTechnologyIntelligenceV11043.evaluate(
            ontology = biomedicalOntologyTopV11041,
            conceptBridge = biomedicalConceptBridgeTopV11042,
            evidencePrior = evidencePriorSelectionTopV11038,
            ebv = ebvLeadVerificationTopV11037,
            metadataClosure = metadataClosureReportTopV11035,
            recentReports = recentReports
        )
        val viralCountermeasureTopV11044 = ViralCountermeasureIntelligenceV11044.evaluate(
            steering = steering,
            leadObjects = datasetForagingReport.leadObjects,
            metadataClosure = metadataClosureReportTopV11035,
            evidencePrior = evidencePriorSelectionTopV11038,
            ontology = biomedicalOntologyTopV11041,
            conceptBridge = biomedicalConceptBridgeTopV11042,
            modernTech = modernMedicalTechnologyTopV11043,
            recentReports = recentReports
        )
        val longevityBiologicalSystemsTopV11046 = LongevityBiologicalSystemsGraphV11046.evaluate(
            steering = steering,
            leadObjects = datasetForagingReport.leadObjects,
            candidates = datasetCandidatesV137,
            ontology = biomedicalOntologyTopV11041,
            conceptBridge = biomedicalConceptBridgeTopV11042,
            modernTech = modernMedicalTechnologyTopV11043,
            viral = viralCountermeasureTopV11044,
            evidencePrior = evidencePriorSelectionTopV11038,
            metadataClosure = metadataClosureReportTopV11035,
            recentReports = recentReports
        )
        val biomedicalKnowledgeGraphTopV11044 = BiomedicalKnowledgeGraphLinkerV11044.link(
            ontology = biomedicalOntologyTopV11041,
            conceptBridge = biomedicalConceptBridgeTopV11042,
            modernTech = modernMedicalTechnologyTopV11043,
            viral = viralCountermeasureTopV11044,
            metadataClosure = metadataClosureReportTopV11035,
            longevity = longevityBiologicalSystemsTopV11046
        )
        val topicFitMetadataParseTopV11047 = TopicFitMetadataParseUiClarityV11047.evaluate(
            steering = steering,
            matureFocus = datasetForagingReport.matureDomainFocusReport,
            longevity = longevityBiologicalSystemsTopV11046,
            candidateAction = candidateActionReportV158,
            parsedMetadata = parsedMetadataV158,
            evidenceObjects = evidenceObjects,
            metadataClosure = metadataClosureReportTopV11035
        )
        val metadataClosureStrategyMatrixTopV11056 = MetadataClosureStrategyMatrixV11058.evaluate(
            steering = steering,
            leadObjects = datasetForagingReport.leadObjects,
            candidates = datasetForagingReport.candidates,
            parsedMetadata = parsedMetadataV158,
            attempts = datasetForagingReport.passes.flatMap { it.attempts },
            topicFit = topicFitMetadataParseTopV11047,
            metadataClosure = metadataClosureReportTopV11035,
            recentReports = recentReports
        )
        val mechanismDiscoveryDossierTopV1110 = ResearchGradeMechanismDossierV1110.evaluate(
            steering = steering,
            matrix = metadataClosureStrategyMatrixTopV11056,
            candidates = datasetForagingReport.candidates,
            parsedMetadata = parsedMetadataV158,
            leadObjects = datasetForagingReport.leadObjects,
            attempts = datasetForagingReport.passes.flatMap { it.attempts }
        )
        datasetForagingReport = datasetForagingReport.copy(
            scoreSeparation = scoreSeparationV144,
            reportConsistencyGuard = reportConsistencyGuardV158,
            leadClosureHandoffReport = leadClosureHandoffReportTopV11035,
            metadataClosureReport = metadataClosureReportTopV11035,
            unknownRouteClassificationReport = unknownRouteClassificationTopV11035,
            ebvLeadVerificationReport = ebvLeadVerificationTopV11037,
            evidencePriorSelectionReport = evidencePriorSelectionTopV11038,
            biomedicalOntologyReport = biomedicalOntologyTopV11041,
            biomedicalConceptBridgeReport = biomedicalConceptBridgeTopV11042,
            modernMedicalTechnologyReport = modernMedicalTechnologyTopV11043,
            viralCountermeasureReport = viralCountermeasureTopV11044,
            longevityBiologicalSystemsReport = longevityBiologicalSystemsTopV11046,
            biomedicalKnowledgeGraphLinkageReport = biomedicalKnowledgeGraphTopV11044,
            topicFitMetadataParseReport = topicFitMetadataParseTopV11047,
            metadataClosureStrategyMatrixReport = metadataClosureStrategyMatrixTopV11056,
            mechanismDiscoveryDossierReport = mechanismDiscoveryDossierTopV1110
        )
        val metadataOnlyRatio = if (ranked.isEmpty()) 0.0 else ranked.count { it.sanityFlags.contains("METADATA_ONLY") }.toDouble() / ranked.size.toDouble()
        val failedLane = autonomousPlan.lanes.firstOrNull()?.laneType ?: autonomousPlan.strategy
        val failureSignature = FailureSignature(
            newUsefulSources = ranked.size,
            repeatedSkipped = repeatedSkipped,
            metadataOnlyRatio = metadataOnlyRatio,
            sameLaneFailureCount = if (ranked.isEmpty() && repeatedSkipped >= 10) 2 else 0,
            abstractFetchFailures = ranked.count { it.sanityFlags.contains("ABSTRACT_FETCH_FAILED") },
            datasetCandidateCount = datasetCandidatesV133.size,
            hypothesisDeltaCount = learningDeltaCards.count { it.deltaType != "no_change" },
            failedLane = failedLane
        )
        val learningOsReport = ResearchLearningLoopEngine.build(
            signature = failureSignature,
            findings = ranked,
            datasets = datasetCandidatesV137,
            evidenceObjects = evidenceObjects,
            discoveryReadiness = discoveryReadiness
        )
        val failurePatternReportV145 = failurePatternLedger.recordCycle(
            triageResults = triageResultsV145,
            routeFits = routeFitAssessmentsV144,
            parsedMetadata = parsedMetadataV158,
            learningOsReport = learningOsReport,
            evidenceObjects = evidenceObjects
        )
        val autoContinuationReportV158 = AutoContinuationTrigger.evaluate(
            parsedMetadata = parsedMetadataV158,
            contrastiveReport = contrastiveReportV158,
            failurePatternReport = failurePatternReportV145,
            queryFeedbackPlan = queryFeedbackPlanV145,
            triageReport = triageReportV145
        )
        datasetForagingReport = datasetForagingReport.copy(
            failurePatternReport = failurePatternReportV145,
            queryFeedbackPlan = queryFeedbackPlanV145,
            freshnessReport = freshnessReportV145,
            autoContinuationReport = autoContinuationReportV158
        )
        val learningDomainPathLinkageReportV11029 = LearningDomainPathLinkageGuard.evaluate(
            executedQueries = executedQueries,
            attempts = datasetForagingReport.passes.flatMap { it.attempts },
            learningRuleMatches = learningRuleMatchesV11021,
            domainReport = datasetForagingReport.domainExpertiseReport,
            matureProbeReport = datasetForagingReport.matureDomainEvidenceProbeReport,
            pathLinkageReport = datasetForagingReport.pathLinkageReport,
            noCandidateRecords = datasetForagingReport.noCandidateLearningRecords,
            queryFeedbackPlan = queryFeedbackPlanV145,
            failurePatternReport = failurePatternReportV145
        )
        val integratedPathLinkageReportTopV11039 = IntegratedPathLinkageGuard.evaluate(
            pathLinkage = datasetForagingReport.pathLinkageReport,
            learningDomain = learningDomainPathLinkageReportV11029,
            evidenceLead = datasetForagingReport.evidenceLeadPathLinkageReport,
            leadClosure = datasetForagingReport.leadClosureHandoffReport,
            metadataClosure = datasetForagingReport.metadataClosureReport,
            unknownRoute = datasetForagingReport.unknownRouteClassificationReport,
            ebv = datasetForagingReport.ebvLeadVerificationReport,
            evidencePrior = datasetForagingReport.evidencePriorSelectionReport,
            longevity = datasetForagingReport.longevityBiologicalSystemsReport
        )
        datasetForagingReport = datasetForagingReport.copy(
            learningDomainPathLinkageReport = learningDomainPathLinkageReportV11029,
            integratedPathLinkageReport = integratedPathLinkageReportTopV11039,
            reportConsistencyGuard = ReportConsistencyGuard.includePathLinkageWarnings(
                base = datasetForagingReport.reportConsistencyGuard,
                pathLinkageReport = datasetForagingReport.pathLinkageReport,
                learningDomainPathLinkageReport = learningDomainPathLinkageReportV11029
            )
        )
        val learningValueScoreReportV11034 = UsefulLearningReportPolicy.learningValueScore(
            steering = steering,
            importedSignals = importedSignals,
            importedRawTexts = importedRawTextsV11031,
            forager = datasetForagingReport,
            learningOs = learningOsReport,
            discoveryReadiness = discoveryReadiness
        )
        val topicMemoryLedgerReportV11034 = UsefulLearningReportPolicy.topicMemoryLedger(
            steering = steering,
            importedSignals = importedSignals,
            importedRawTexts = importedRawTextsV11031,
            forager = datasetForagingReport
        )
        val leadInspectionQueueReportV11034 = UsefulLearningReportPolicy.leadInspectionQueue(datasetForagingReport)
        val researchProgressWithoutEvidenceReportV11034 = UsefulLearningReportPolicy.progressWithoutEvidence(
            forager = datasetForagingReport,
            learningValue = learningValueScoreReportV11034,
            topicLedger = topicMemoryLedgerReportV11034,
            leadQueue = leadInspectionQueueReportV11034
        )
        val usefulReportLayersReportV11034 = UsefulLearningReportPolicy.reportLayers(
            topicLedger = topicMemoryLedgerReportV11034,
            learningValue = learningValueScoreReportV11034,
            leadQueue = leadInspectionQueueReportV11034,
            progress = researchProgressWithoutEvidenceReportV11034
        )
        datasetForagingReport = datasetForagingReport.copy(
            learningValueScoreReport = learningValueScoreReportV11034,
            topicMemoryLedgerReport = topicMemoryLedgerReportV11034,
            leadInspectionQueueReport = leadInspectionQueueReportV11034,
            usefulReportLayersReport = usefulReportLayersReportV11034,
            researchProgressWithoutEvidenceReport = researchProgressWithoutEvidenceReportV11034
        )
        val hardStagnationObserved = EngineRuntimeStatus.hardStagnationTriggered(
            newFindingsCount = ranked.size,
            repeatedSkipped = repeatedSkipped,
            datasetCandidateCount = datasetCandidatesV137.size
        )
        val runtimeStatus = ActiveResearchEngineStatus(
            engineVersion = EngineRuntimeStatus.ACTIVE_ENGINE_VERSION,
            activeModules = EngineRuntimeStatus.ACTIVE_MODULES,
            researchState = if (datasetForagingReport.active || runtimeFailoverApplied) "DATASET_HUNT" else initialResearchState,
            appliedPivotType = appliedPivot.pivotType,
            effectiveMaxQueries = effectiveMaxQueries,
            effectiveResultsPerQuery = effectiveResultsPerQuery,
            runtimeFailoverApplied = runtimeFailoverApplied,
            forcedQueries = executedQueries
                .filter { it.id.startsWith("q_pivot_") || it.id.startsWith("q_antistag_") || it.id.startsWith("q_runtime_") || it.id.startsWith("q_v142_") || it.id.startsWith("q_v196_") || it.id.startsWith("q_v197_") || it.id.startsWith("q_v199_") || it.id.startsWith("q_v200_") || it.id.startsWith("q_v201_") || it.id.startsWith("q_v11015_") || it.id.startsWith("q_v203_") || it.id.startsWith("q_v204_") || it.id.startsWith("q_v206_") }
                .map { "${it.label}: ${it.query}" }
                .take(12),
            executedQueryIds = executedQueries.map { it.id }
        )
        val executionLockBaseReport = EngineRuntimeStatus.buildExecutionLock(
            runtimeStatus = runtimeStatus,
            learningOsReport = learningOsReport,
            hardStagnationObserved = hardStagnationObserved,
            datasetForagingReport = datasetForagingReport
        )
        val executionLockReport = if (runtimeDiagnostics.isEmpty()) {
            executionLockBaseReport
        } else {
            executionLockBaseReport.copy(
                status = "WARN",
                failures = executionLockBaseReport.failures + runtimeDiagnostics.distinct().take(12),
                enforcedActions = executionLockBaseReport.enforcedActions +
                    "Runtime diagnostics recorded: HTTP/JSON/rate-limit errors are no longer swallowed silently."
            )
        }
        val cyclePhaseAuditReportV204 = ResearchCyclePhaseAuditEngine.build(
            priorDirective = priorSearchDirectiveV203,
            postForagerDirective = postForagerDirectiveV203,
            datasetFirstRequested = datasetFirstRequested,
            datasetFirstUnlockApplied = evidenceFirstForagerExecutedV108 || zeroQueryRecoveryQueriesV11015.isNotEmpty(),
            runtimeFailoverAttempted = runtimeFailoverApplied,
            executedQueryIds = executedQueries.map { it.id },
            findingsCount = findings.size,
            rankedCount = ranked.size,
            runtimeDiagnostics = runtimeDiagnostics.distinct(),
            stopped = stopped,
            stopReason = stopReason
        )

        val persistentFailureMemoryAfter = failureMemoryStore.recordCycle(
            executedQueries = executedQueries,
            learningOsReport = learningOsReport,
            datasetForagingReport = datasetForagingReport,
            evidenceObjects = evidenceObjects
        )
        val researchStateSummary = ResearchStateEngine.actionableSummary(
            base = baseResearchStateSummary,
            datasetForagingReport = datasetForagingReport,
            learningOsReport = learningOsReport,
            runtimeStatus = runtimeStatus,
            discoveryReadiness = discoveryReadiness
        )
        val resilienceDecision = NoResultRecoveryEngine.decide(failureSignature)
        val queryEvolutionState = if (resilienceDecision.pivotType == "NO_PIVOT") null else AdaptiveQueryEvolution.evolve(
            seed = resilienceDecision.nextQuerySeed,
            pivot = resilienceDecision,
            activeAxes = ranked.flatMap { it.matchedAxes }.distinct().take(5)
        )
        val foundationKnowledgeNotesV151 = foundationAnalysisV151?.let { analysis ->
            listOf(
                "v1.5.6 Foundation Knowledge OS: axis=${analysis.primaryAxis ?: "unknown"}; action=${analysis.recommendedAction}; confidence=${analysis.confidenceLevel}; claim-limit=${analysis.claimLimit}.",
                "v1.5.6 Foundation Knowledge OS: ${analysis.actionExplanation.take(260)}"
            )
        } ?: listOf(
            "v1.5.6 Foundation Knowledge OS: integrated, disabled by default; it guides search only and never proves biology."
        )

        val reportV3 = ResearchReportV3Builder.build(
            findings = ranked,
            hypothesisObjects = hypothesisObjects,
            learningDeltas = learningDeltaCards,
            datasetCandidates = datasetCandidatesV133,
            pivot = resilienceDecision,
            repeatedSkipped = repeatedSkipped,
            global = globalImmuneIntelligence,
            evidenceObjects = evidenceObjects,
            learningOs = learningOsReport,
            discoveryReadiness = discoveryReadiness,
            datasetForagingReport = datasetForagingReport
        )
        val reasoningReport = ResearchReasoningEngine.reason(
            findings = ranked,
            hypothesisObjects = hypothesisObjects,
            datasetCandidates = datasetCandidatesV133,
            pivot = resilienceDecision,
            global = globalImmuneIntelligence,
            repeatedSkipped = repeatedSkipped,
            reportV3 = reportV3
        )
        val specializedReasoningReport = SpecializedReasoningEngine.evaluate(
            findings = ranked,
            hypothesisObjects = hypothesisObjects,
            evidenceObjects = evidenceObjects,
            datasetForagingReport = datasetForagingReport,
            learningOsReport = learningOsReport,
            reasoningReport = reasoningReport,
            reportV3 = reportV3
        )
        val knowledgeMapReport = CumulativeKnowledgeMapEngine.build(
            currentFindings = ranked,
            hypothesisObjects = hypothesisObjects,
            evidenceObjects = evidenceObjects,
            datasetForagingReport = datasetForagingReport,
            specializedReasoningReport = specializedReasoningReport,
            recentReportLines = recentReports
        )
        val epistemicBeliefReport = EpistemicBeliefEngine.build(
            currentFindings = ranked,
            hypothesisObjects = hypothesisObjects,
            evidenceObjects = evidenceObjects,
            datasetForagingReport = datasetForagingReport,
            specializedReasoningReport = specializedReasoningReport,
            knowledgeMapReport = knowledgeMapReport,
            recentReportLines = recentReports
        )
        val cognitivePathIntegrationReport = CognitivePathIntegrationEngine.integrate(
            knowledgeMapReport = knowledgeMapReport,
            epistemicBeliefReport = epistemicBeliefReport,
            specializedReasoningReport = specializedReasoningReport,
            datasetForagingReport = datasetForagingReport,
            learningOsReport = learningOsReport
        )
        val cognitiveLoopCalibrationReport = CognitiveLoopCalibrationEngine.calibrate(
            nextCyclePlan = cognitiveNextCyclePlanV165,
            datasetForagingReport = datasetForagingReport,
            knowledgeMapReport = knowledgeMapReport,
            epistemicBeliefReport = epistemicBeliefReport,
            specializedReasoningReport = specializedReasoningReport,
            learningOsReport = learningOsReport
        )
        val directiveLifecycleReportV170 = DirectiveLifecycleEngine.evaluate(
            nextCyclePlan = cognitiveNextCyclePlanV165,
            calibrationReport = cognitiveLoopCalibrationReport,
            cognitivePathIntegrationReport = cognitivePathIntegrationReport
        )
        val beliefFalsificationContractReportV171 = BeliefFalsificationContractEngine.build(epistemicBeliefReport)
        val memoryConsolidationReportV173 = MemoryConsolidationEngine.consolidate(
            beliefReport = epistemicBeliefReport,
            contractReport = beliefFalsificationContractReportV171
        )
        val causalReadinessReportV174 = CausalReadinessGate.evaluate(
            evidenceObjects = evidenceObjects,
            datasetForagingReport = datasetForagingReport,
            hypothesisObjects = hypothesisObjects
        )
        val reflectionLessonReportV176 = ReflectionLessonEngine.build(
            learningOsReport = learningOsReport,
            datasetForagingReport = datasetForagingReport,
            cognitiveLoopCalibrationReport = cognitiveLoopCalibrationReport
        )
        val miniPeerReviewReportV177 = MiniPeerReviewGate.review(
            hypothesisObjects = hypothesisObjects,
            datasetForagingReport = datasetForagingReport,
            causalReadinessReport = causalReadinessReportV174,
            epistemicBeliefReport = epistemicBeliefReport
        )
        val reportSimplificationReportV178 = ReportSimplificationLayer.build(
            beliefReport = epistemicBeliefReport,
            cognitivePathIntegrationReport = cognitivePathIntegrationReport,
            evidenceGainReport = evidenceGainQueryRankerReportV170,
            miniPeerReviewReport = miniPeerReviewReportV177,
            reflectionLessonReport = reflectionLessonReportV176
        )
        val scientificKnowledgeIndexReportV180 = ScientificKnowledgeIndexEngine(context).build(
            queries = executedQueries,
            findings = ranked,
            datasetForagingReport = datasetForagingReport,
            hypothesisObjects = hypothesisObjects
        )
        val deepDiscoveryReasoningReportV180 = DeepDiscoveryReasonerV180.reason(
            scientificIndex = scientificKnowledgeIndexReportV180,
            findings = ranked,
            hypothesisObjects = hypothesisObjects,
            evidenceObjects = evidenceObjects,
            datasetForagingReport = datasetForagingReport,
            specializedReasoningReport = specializedReasoningReport,
            epistemicBeliefReport = epistemicBeliefReport,
            causalReadinessReport = causalReadinessReportV174,
            miniPeerReviewReport = miniPeerReviewReportV177
        )
        val scientificDiscoveryWeightReportV182 = ScientificDiscoveryWeightEngine.weigh(
            scientificIndex = scientificKnowledgeIndexReportV180,
            deepDiscovery = deepDiscoveryReasoningReportV180,
            causalReadinessReport = causalReadinessReportV174,
            miniPeerReviewReport = miniPeerReviewReportV177,
            datasetForagingReport = datasetForagingReport,
            evidenceGainReport = evidenceGainQueryRankerReportV170
        )
        val scientificDiscoveryDecisionReportV183 = ScientificDiscoveryDecisionEngineV183.decide(
            scientificWeights = scientificDiscoveryWeightReportV182,
            deepDiscovery = deepDiscoveryReasoningReportV180,
            causalReadiness = causalReadinessReportV174,
            miniPeerReview = miniPeerReviewReportV177,
            datasetForaging = datasetForagingReport,
            evidenceGain = evidenceGainQueryRankerReportV170
        )
        val scientificDiscoveryStressTestReportV184 = ScientificDiscoveryStressTestEngineV184.stressTest(
            decisionMemory = scientificDiscoveryDecisionReportV183,
            scientificWeights = scientificDiscoveryWeightReportV182,
            deepDiscovery = deepDiscoveryReasoningReportV180,
            causalReadiness = causalReadinessReportV174,
            miniPeerReview = miniPeerReviewReportV177,
            datasetForaging = datasetForagingReport
        )
        val scientificDiscoveryExecutionPolicyReportV185 = ScientificDiscoveryExecutionPolicyEngineV185.enforce(
            stressTest = scientificDiscoveryStressTestReportV184,
            decisionMemory = scientificDiscoveryDecisionReportV183,
            scientificWeights = scientificDiscoveryWeightReportV182,
            causalReadiness = causalReadinessReportV174,
            miniPeerReview = miniPeerReviewReportV177,
            epistemicBelief = epistemicBeliefReport,
            memoryConsolidation = memoryConsolidationReportV173
        )
        val scientificDiscoveryOutcomeVerifierReportV186 = ScientificDiscoveryOutcomeVerifierEngineV186.verify(
            nextCyclePlan = cognitiveNextCyclePlanV165,
            loopCalibration = cognitiveLoopCalibrationReport,
            executionPolicy = scientificDiscoveryExecutionPolicyReportV185,
            stressTest = scientificDiscoveryStressTestReportV184,
            decisionMemory = scientificDiscoveryDecisionReportV183,
            scientificWeights = scientificDiscoveryWeightReportV182,
            datasetForaging = datasetForagingReport,
            learningOs = learningOsReport,
            causalReadiness = causalReadinessReportV174,
            miniPeerReview = miniPeerReviewReportV177
        )
        val scientificDiscoveryLineageReportV187 = ScientificDiscoveryLineageEngineV187.build(
            hypothesisObjects = hypothesisObjects,
            evidenceObjects = evidenceObjects,
            datasetForaging = datasetForagingReport,
            knowledgeMap = knowledgeMapReport,
            epistemicBelief = epistemicBeliefReport,
            deepDiscovery = deepDiscoveryReasoningReportV180,
            executionPolicy = scientificDiscoveryExecutionPolicyReportV185,
            outcomeVerifier = scientificDiscoveryOutcomeVerifierReportV186,
            causalReadiness = causalReadinessReportV174,
            miniPeerReview = miniPeerReviewReportV177
        )

        val scientificDiscoveryGapMinerReportV188 = ScientificDiscoveryGapMinerEngineV188.mine(
            knowledgeIndex = scientificKnowledgeIndexReportV180,
            deepDiscovery = deepDiscoveryReasoningReportV180,
            scientificWeights = scientificDiscoveryWeightReportV182,
            decisionMemory = scientificDiscoveryDecisionReportV183,
            outcomeVerifier = scientificDiscoveryOutcomeVerifierReportV186,
            lineage = scientificDiscoveryLineageReportV187,
            datasetForaging = datasetForagingReport,
            knowledgeMap = knowledgeMapReport,
            epistemicBelief = epistemicBeliefReport
        )
        val scientificDiscoveryProbePlanReportV189 = ScientificDiscoveryProbePlannerEngineV189.plan(
            gapMiner = scientificDiscoveryGapMinerReportV188,
            lineage = scientificDiscoveryLineageReportV187,
            outcomeVerifier = scientificDiscoveryOutcomeVerifierReportV186,
            executionPolicy = scientificDiscoveryExecutionPolicyReportV185,
            scientificWeights = scientificDiscoveryWeightReportV182,
            deepDiscovery = deepDiscoveryReasoningReportV180,
            knowledgeIndex = scientificKnowledgeIndexReportV180,
            datasetForaging = datasetForagingReport
        )
        val scientificDiscoveryProbeOutcomeLedgerReportV190 = ScientificDiscoveryProbeOutcomeLedgerEngineV190.evaluate(
            recentReportJsonLines = recentReports,
            currentProbePlan = scientificDiscoveryProbePlanReportV189,
            datasetForaging = datasetForagingReport,
            evidenceObjects = evidenceObjects,
            findings = ranked,
            learningOs = learningOsReport,
            discoveryReadiness = discoveryReadiness,
            outcomeVerifier = scientificDiscoveryOutcomeVerifierReportV186,
            executionPolicy = scientificDiscoveryExecutionPolicyReportV185,
            gapMiner = scientificDiscoveryGapMinerReportV188
        )
        val scientificDiscoveryMetaStrategyReportV191 = ScientificDiscoveryMetaStrategyGovernorEngineV191.govern(
            recentReportJsonLines = recentReports,
            probeOutcomeLedger = scientificDiscoveryProbeOutcomeLedgerReportV190,
            currentProbePlan = scientificDiscoveryProbePlanReportV189,
            gapMiner = scientificDiscoveryGapMinerReportV188,
            lineage = scientificDiscoveryLineageReportV187,
            outcomeVerifier = scientificDiscoveryOutcomeVerifierReportV186,
            executionPolicy = scientificDiscoveryExecutionPolicyReportV185,
            deepDiscovery = deepDiscoveryReasoningReportV180,
            scientificWeights = scientificDiscoveryWeightReportV182,
            datasetForaging = datasetForagingReport,
            learningOs = learningOsReport,
            discoveryReadiness = discoveryReadiness
        )
        val scientificDiscoveryQualityGateReportV192 = ScientificDiscoveryQualityGateEngineV192.evaluate(
            metaStrategy = scientificDiscoveryMetaStrategyReportV191,
            probeOutcomeLedger = scientificDiscoveryProbeOutcomeLedgerReportV190,
            currentProbePlan = scientificDiscoveryProbePlanReportV189,
            executionPolicy = scientificDiscoveryExecutionPolicyReportV185,
            outcomeVerifier = scientificDiscoveryOutcomeVerifierReportV186,
            causalReadiness = causalReadinessReportV174,
            miniPeerReview = miniPeerReviewReportV177,
            scientificWeights = scientificDiscoveryWeightReportV182,
            datasetForaging = datasetForagingReport,
            discoveryReadiness = discoveryReadiness,
            learningOs = learningOsReport
        )

        val scientificDiscoveryRunbookReportV193 = ScientificDiscoveryRunbookEngineV193.compile(
            qualityGate = scientificDiscoveryQualityGateReportV192,
            metaStrategy = scientificDiscoveryMetaStrategyReportV191,
            currentProbePlan = scientificDiscoveryProbePlanReportV189,
            probeOutcomeLedger = scientificDiscoveryProbeOutcomeLedgerReportV190,
            executionPolicy = scientificDiscoveryExecutionPolicyReportV185,
            stressTest = scientificDiscoveryStressTestReportV184,
            gapMiner = scientificDiscoveryGapMinerReportV188,
            lineage = scientificDiscoveryLineageReportV187,
            deepDiscovery = deepDiscoveryReasoningReportV180,
            datasetForaging = datasetForagingReport,
            learningOs = learningOsReport
        )
        val evidenceClosureReportV195 = EvidenceClosureEngine.build(
            datasetForaging = datasetForagingReport,
            evidenceObjects = evidenceObjects,
            learningOs = learningOsReport,
            executedQueries = executedQueries
        )
        val postSearchThinkingReportV195 = PostSearchThinkingEngine.build(
            evidenceClosure = evidenceClosureReportV195,
            datasetForaging = datasetForagingReport,
            knowledgeMap = knowledgeMapReport,
            epistemicBelief = epistemicBeliefReport,
            deepDiscovery = deepDiscoveryReasoningReportV180,
            qualityGate = scientificDiscoveryQualityGateReportV192,
            runbook = scientificDiscoveryRunbookReportV193,
            miniPeerReview = miniPeerReviewReportV177,
            learningOs = learningOsReport
        )
        val thinkingContinuityReportV196 = ThinkingContinuityEngine.build(
            recentReportJsonLines = recentReports,
            evidenceClosure = evidenceClosureReportV195,
            postSearchThinking = postSearchThinkingReportV195,
            learningOs = learningOsReport
        )
        val hypothesisGraphReportV198 = HypothesisGraphCognitionEngine.build(
            recentReportJsonLines = recentReports,
            evidenceClosure = evidenceClosureReportV195,
            postSearchThinking = postSearchThinkingReportV195,
            thinkingContinuity = thinkingContinuityReportV196,
            learningOs = learningOsReport,
            deepDiscovery = deepDiscoveryReasoningReportV180,
            qualityGate = scientificDiscoveryQualityGateReportV192
        )
        val cognitiveMomentumReportV199 = CognitiveMomentumEngine.build(
            recentReportJsonLines = recentReports,
            evidenceClosure = evidenceClosureReportV195,
            thinkingContinuity = thinkingContinuityReportV196,
            hypothesisGraph = hypothesisGraphReportV198,
            learningOs = learningOsReport,
            datasetForaging = datasetForagingReport,
            executedQueries = executedQueries
        )
        val linkedCognitionSpineReportV200 = LinkedCognitionSpineEngine.build(
            evidenceClosure = evidenceClosureReportV195,
            postSearchThinking = postSearchThinkingReportV195,
            thinkingContinuity = thinkingContinuityReportV196,
            hypothesisGraph = hypothesisGraphReportV198,
            cognitiveMomentum = cognitiveMomentumReportV199,
            datasetForaging = datasetForagingReport,
            qualityGate = scientificDiscoveryQualityGateReportV192,
            runbook = scientificDiscoveryRunbookReportV193,
            executedQueries = executedQueries,
            priorSpineWasActive = priorLinkedSpineLockV200
        )
        val pathMaintenanceReportV207 = ResearchCyclePathMaintenanceGuard.build(
            directive = postForagerDirectiveV203,
            phaseSpine = phaseSpineReportV205,
            planStage = cyclePlanStageReportV206,
            phaseAudit = cyclePhaseAuditReportV204
        )
        val extendedThinkingBudgetReportV11016 = ExtendedThinkingBudgetPolicy.evaluate(
            executedQueries = executedQueries,
            datasetForaging = datasetForagingReport,
            learningOs = learningOsReport,
            postSearchThinking = postSearchThinkingReportV195,
            thinkingContinuity = thinkingContinuityReportV196,
            hypothesisGraph = hypothesisGraphReportV198,
            cognitiveMomentum = cognitiveMomentumReportV199,
            linkedSpine = linkedCognitionSpineReportV200,
            maxLearningMillis = limits.maxLearningMillis
        )

        val learningLoopActivationReportV262 = LearningLoopActivationV262.build(
            findings = ranked,
            evidenceObjects = evidenceObjects,
            beliefReport = epistemicBeliefReport,
            gapMiner = scientificDiscoveryGapMinerReportV188,
            routeFingerprint = routeFingerprintReportV11021,
            learningRuleMatches = learningRuleMatchesV11021,
            recentReports = recentReports
        )

        return ResearchCycleReport(
            id = "cycle_$started",
            createdAtMillis = started,
            completedAtMillis = completed,
            stoppedByUser = stopped && stopReason == "stopped_by_user",
            stopReason = stopReason,
            searchDurationMillis = (searchFinished - started).coerceAtLeast(0),
            learningDurationMillis = (completed - searchFinished).coerceAtLeast(0),
            queries = executedQueries,
            findings = ranked,
            activeSteeringProfile = steering,
            importedReportSignals = importedSignals.take(8),
            hypothesisRankCards = hypothesisCards,
            emergentLinks = buildEmergentLinks(ranked, importedSignals, steering),
            nextQuestions = buildNextQuestions(ranked, importedSignals, steering, autonomousPlan),
            knowledgeDelta = KnowledgeDelta(
                newSourcesSaved = ranked.size,
                repeatedSourcesSkipped = repeatedSkipped,
                newAxisPairs = newAxisPairs,
                manualReportSignalsUsed = importedSignals.size,
                dnaRnaSignals = dnaRnaSignals,
                steeredQueriesGenerated = executedQueries.count { it.id.startsWith("q_steer_") },
                learningNotes = buildLearningNotes(
                    findings = ranked,
                    importedSignals = importedSignals,
                    newAxisPairs = newAxisPairs,
                    stopReason = stopReason,
                    steering = steering,
                    autonomousPlan = autonomousPlan,
                    stagnationPlan = stagnationPlan,
                    runtimeStatus = runtimeStatus,
                    executionLockReport = executionLockReport,
                    learningValueModeActiveV11033 = learningValueModeActiveV11033
                ) + listOf(
                    "v1.4.5 active engine: ${runtimeStatus.engineVersion}; state=${runtimeStatus.researchState}; execution lock=${executionLockReport.status}.",
                    "v1.10.2 runtime hardening: diagnostics=${runtimeDiagnostics.distinct().take(4).joinToString(" | ").ifBlank { "none" }}; NCBI compliance guard active; HTTP errors are typed, not silent.",
                    "v2.7.4.1 run decision contract: mode=${runDecisionContractV2741.runMode}; anchor=${runDecisionContractV2741.primaryAnchor.routeId}; bridges=${runDecisionContractV2741.discoveryBridges.take(4).joinToString(",") { it.routeId }}; cap=${runDecisionContractV2741.evidenceCaps.dataQualityMax}/${runDecisionContractV2741.evidenceCaps.evidenceStrengthMax}/${runDecisionContractV2741.evidenceCaps.routeConfidenceMax}; reason=${runDecisionContractV2741.anchorReason.take(180)}",
                    "v1.10.3 search directive resolver: mode=${postForagerDirectiveV203.mode}; governing=${postForagerDirectiveV203.governingLayer}; maxQueries=${postForagerDirectiveV203.maxQueries}; results=${postForagerDirectiveV203.maxResultsPerQuery}; reason=${postForagerDirectiveV203.reason.take(180)}",
                    "v1.10.3 search directive trace: ${postForagerDirectiveV203.trace.takeLast(4).joinToString(" -> ").take(260)}",
                    "v1.10.4 cycle phase audit: ${cyclePhaseAuditReportV204.summary.take(260)}",
                    "v1.10.4 next gate: ${cyclePhaseAuditReportV204.nextGate.take(220)}",
                    "v1.10.5 phase spine: ${phaseSpineReportV205.summary}; invariant=${phaseSpineReportV205.dominantInvariant.take(180)}",
                    "v1.10.6 plan stage: ${cyclePlanStageReportV206.summary.take(240)}; next=${cyclePlanStageReportV206.nextPhase.take(160)}",
                    "v1.10.7 search stage extraction: failover=${if (runtimeFailoverPlanV207.shouldRun) "ran" else "not_run"}; blockedByLock=${runtimeFailoverPlanV207.blockedByLock}; reason=${runtimeFailoverPlanV207.reason.take(180)}",
                    "v1.10.8 dataset-hunt unlock: allowed=${datasetHuntUnlockDecisionV108.allowDatasetAccessionSearch}; evidenceFirstDirective=$evidenceFirstDirectiveRequestsDatasetV108; routerRequested=$routerRequestsDatasetFirstV108; applied=$datasetHuntUnlockAppliedV108; evidenceFirstForagerExecuted=$evidenceFirstForagerExecutedV108; reason=${datasetHuntUnlockDecisionV108.reason.take(180)}",
                    "v1.10.7 path maintenance: ${pathMaintenanceReportV207.summary.take(220)}; repair=${pathMaintenanceReportV207.repairTarget.take(180)}",
                    "v1.10.5 store hardening: ResearchKnowledgeStore hot JSONL paths now delegate to testable append/trim/readLast file ops.",
                    "v1.4.5 dataset interpreter: active=${datasetForagingReport.active}; sources=${datasetForagingReport.sourceFamiliesAttempted.joinToString(", ").ifBlank { "none" }}; candidates=${datasetForagingReport.candidates.size}; parsed=${datasetForagingReport.parsedMetadata.size}; contrast=${datasetForagingReport.contrastiveReport.gateStatus}; cumulative=${datasetForagingReport.cumulativeEvidence.score}/100 ${datasetForagingReport.cumulativeEvidence.state}.",
                    "v1.4.4 route-fit gate: blocked=${datasetForagingReport.routeFitAssessments.count { it.blocksHypothesisUpgrade }}; score-state=${datasetForagingReport.scoreSeparation.scoreState}; route-fit=${datasetForagingReport.scoreSeparation.routeFitScore}/100; hypothesis-confidence=${datasetForagingReport.scoreSeparation.hypothesisConfidenceScore}/100.",
                    "v1.4.5 ML-safe triage: active=${datasetForagingReport.triageReport.active}; parsed=${datasetForagingReport.triageReport.parsedAccessions.size}; skipped=${datasetForagingReport.triageReport.skippedAccessions.size}; claim-limit=${datasetForagingReport.triageReport.claimLimit}.",
                    "v1.4.5 failure-pattern ledger: ${datasetForagingReport.failurePatternReport.summary}",
                    "v1.4.5 query feedback: ${datasetForagingReport.queryFeedbackPlan.summary}",
                    "v1.10.10 contradiction/control execution + exploratory capture: state=${datasetForagingReport.state}; leads=${datasetForagingReport.candidates.count { it.status == "EXPLORATORY_LEAD_NEEDS_ACCESSION" }}; no-candidate=${datasetForagingReport.noCandidateLearningRecords.takeLast(3).joinToString(" | ") { "source=${it.sourceFamily}; missing=${it.missing}; next=${it.nextPreferredSource}" }.ifBlank { "none" }}.",
                    "v1.10.11 creative hypothesis forge: active=${datasetForagingReport.creativeHypothesisForgeReport.active}; state=${datasetForagingReport.creativeHypothesisForgeReport.state}; generated=${datasetForagingReport.creativeHypothesisForgeReport.generated.size}; claim-limit=${datasetForagingReport.creativeHypothesisForgeReport.claimLimit}.",
                    "v1.10.13 steering-aware creative forge: axes=${datasetForagingReport.creativeHypothesisForgeReport.steeringAxesUsed.take(5).joinToString(",") { it.id }}; expandedThinking=${datasetForagingReport.expandedThinkingReport.active}; mode=${datasetForagingReport.expandedThinkingReport.mode}; claim-limit=${datasetForagingReport.expandedThinkingReport.claimLimit}.",
                    "v1.10.13 creative continuation: active=${creativeContinuationPlanV11012.active}; mode=${creativeContinuationPlanV11012.mode}; source=${creativeContinuationPlanV11012.sourceFamily.ifBlank { "none" }}; queries=${creativeContinuationPlanV11012.queries.size}; claim-limit=${creativeContinuationPlanV11012.claimLimit}.",
                    "v1.4.5 freshness weighting: average=${datasetForagingReport.freshnessReport.averageFreshness}/100; ${datasetForagingReport.freshnessReport.summary}",
                    "v1.6.1 specialist evidence protocol: ${specializedReasoningReport.state} ${specializedReasoningReport.specialistScore}/100; weakest=${specializedReasoningReport.weakestLink.take(180)}",
                    "v1.6.1 decisive next test: ${specializedReasoningReport.decisiveNextTest.take(220)}",
                    "v1.6.2 cumulative knowledge map: ${knowledgeMapReport.state} ${knowledgeMapReport.mapScore}/100; carried=${knowledgeMapReport.carriedForwardNodes}; newNodes=${knowledgeMapReport.newNodesThisCycle}; newLinks=${knowledgeMapReport.newLinksThisCycle}.",
                    "v1.6.2 map next action: ${knowledgeMapReport.nextMapAction.take(220)}",
                    "v1.6.3 epistemic belief model: ${epistemicBeliefReport.state} ${epistemicBeliefReport.beliefScore}/100; new=${epistemicBeliefReport.newBeliefsThisCycle}; weakened=${epistemicBeliefReport.weakenedBeliefs}; revise=${epistemicBeliefReport.revisedBeliefs}.",
                    "v1.6.3 belief next action: ${epistemicBeliefReport.nextBeliefAction.take(220)}",
                    "v1.6.4 cognitive path integration: ${cognitivePathIntegrationReport.state} ${cognitivePathIntegrationReport.integrationScore}/100; route=${cognitivePathIntegrationReport.routeIntegrity}; decision=${cognitivePathIntegrationReport.decision.decisionType}.",
                    "v1.6.4 linked next action: ${cognitivePathIntegrationReport.decision.action.take(220)}",
                    "v1.6.7 cognitive directive retirement: ${cognitiveNextCyclePlanV165.summary.take(260)}",
                    "v1.6.8 cognitive loop calibration: ${cognitiveLoopCalibrationReport.outcome} ${cognitiveLoopCalibrationReport.calibrationScore}/100; action=${cognitiveLoopCalibrationReport.nextCalibrationAction.take(220)}",
                    "v1.6.9 epistemic belief discipline: strengthened=${epistemicBeliefReport.transitionSummary.strengthenedBelief.take(180)}; weakened=${epistemicBeliefReport.transitionSummary.weakenedBelief.take(180)}; dropped=${epistemicBeliefReport.transitionSummary.droppedBelief.take(180)}.",
                    "v1.6.9 belief abandonment question: ${epistemicBeliefReport.transitionSummary.abandonmentQuestion}",
                    "v1.7.0 directive lifecycle: ${directiveLifecycleReportV170.state}; applied=${directiveLifecycleReportV170.previousDirectiveApplied}; next=${directiveLifecycleReportV170.nextDirectiveState}.",
                    "v1.7.2 evidence-gain query ranker: ${evidenceGainQueryRankerReportV170.summary.take(220)}",
                    "v1.7.1 belief contracts: ${beliefFalsificationContractReportV171.summary.take(220)}",
                    "v1.7.3 memory consolidation: ${memoryConsolidationReportV173.summary.take(220)}",
                    "v1.7.4 causal readiness: ${causalReadinessReportV174.summary.take(220)}",
                    "v1.7.6 reflection lesson: ${reflectionLessonReportV176.lesson.take(220)}",
                    "v1.7.7 mini peer review: ${miniPeerReviewReportV177.summary.take(220)}",
                    "v1.7.8 simplified report: next=${reportSimplificationReportV178.nextTest.take(180)}",
                    "v1.8.2 scientific term index: ${scientificKnowledgeIndexReportV180.summary.take(220)}",
                    "v1.8.2 deep discovery reasoner: ${deepDiscoveryReasoningReportV180.summary.take(240)}",
                    "v1.8.2 decisive experiment: ${deepDiscoveryReasoningReportV180.decisiveExperiment.decisiveQuestion.take(240)}",
                    "v1.8.2 deep think session: trigger=${deepDiscoveryReasoningReportV180.deepThinkSession.trigger}; verdict=${deepDiscoveryReasoningReportV180.deepThinkSession.sessionVerdict}.",
                    "v1.8.2 weighted discovery intelligence: ${scientificDiscoveryWeightReportV182.summary.take(240)}",
                    "v1.8.2 learning receipt: ${scientificDiscoveryWeightReportV182.learningReceipt.take(220)}",
                    "v1.8.3 discovery decision memory: ${scientificDiscoveryDecisionReportV183.summary.take(240)}",
                    "v1.8.3 next-cycle contract: ${scientificDiscoveryDecisionReportV183.nextCycleContract.take(240)}",
                    "v1.8.4 counterfactual discovery stress test: ${scientificDiscoveryStressTestReportV184.reportLine.take(240)}",
                    "v1.8.4 stress branch actions: ${scientificDiscoveryStressTestReportV184.branchActions.take(2).joinToString(" | ").take(240)}",
                    "v1.8.5 execution policy: ${scientificDiscoveryExecutionPolicyReportV185.reportLine.take(260)}",
                    "v1.8.5 policy blocks: ${scientificDiscoveryExecutionPolicyReportV185.blockedActions.take(3).joinToString(" | ").take(240)}",
                    "v1.8.6 outcome verifier: ${scientificDiscoveryOutcomeVerifierReportV186.reportLine.take(260)}",
                    "v1.8.6 verifier adjustment: route=${scientificDiscoveryOutcomeVerifierReportV186.routeAdjustment.take(180)}; belief=${scientificDiscoveryOutcomeVerifierReportV186.beliefAdjustment.take(180)}",
                    "v1.8.7 hypothesis lineage: ${scientificDiscoveryLineageReportV187.reportLine.take(260)}",
                    "v1.8.7 lineage next action: ${scientificDiscoveryLineageReportV187.nextLineageAction.take(220)}",
                    "v1.8.8 latent discovery gap miner: ${scientificDiscoveryGapMinerReportV188.reportLine.take(260)}",
                    "v1.8.8 next discovery probe: ${scientificDiscoveryGapMinerReportV188.nextDiscoveryProbe.take(220)}",
                    "v1.8.9 executable discovery probe plan: ${scientificDiscoveryProbePlanReportV189.reportLine.take(260)}",
                    "v1.8.9 selected probe query: ${scientificDiscoveryProbePlanReportV189.selectedProbeQuery.take(220)}",
                    "v1.9.0 probe outcome ledger: ${scientificDiscoveryProbeOutcomeLedgerReportV190.reportLine.take(260)}",
                    "v1.9.0 probe next decision: ${scientificDiscoveryProbeOutcomeLedgerReportV190.nextProbeDecision.take(220)}",
                    "v1.9.1 meta-strategy governor: ${scientificDiscoveryMetaStrategyReportV191.reportLine.take(260)}",
                    "v1.9.1 strategy decision: ${scientificDiscoveryMetaStrategyReportV191.continuationDecision.take(220)}",
                    "v1.9.2 discovery quality gate: ${scientificDiscoveryQualityGateReportV192.reportLine.take(260)}",
                    "v1.9.2 quality decision: ${scientificDiscoveryQualityGateReportV192.executionDecision.take(220)}",
                    "v1.9.3 executable quality runbook: ${scientificDiscoveryRunbookReportV193.reportLine.take(260)}",
                    "v1.9.3 runbook route decision: ${scientificDiscoveryRunbookReportV193.routeDecision.take(220)}",
                    "v1.9.5 evidence closure mode: ${evidenceClosureReportV195.summary.take(260)}",
                    "v1.9.5 post-search thinking: ${postSearchThinkingReportV195.summary.take(260)}",
                    "v1.9.6 thinking continuity: ${thinkingContinuityReportV196.summary.take(260)}",
                    "v1.9.8 hypothesis graph: ${hypothesisGraphReportV198.summary.take(260)}",
                    "v1.9.9 cognitive momentum: ${cognitiveMomentumReportV199.summary.take(260)}",
                    "v1.10.0 linked cognition spine: ${linkedCognitionSpineReportV200.summary.take(260)}",
                    "v1.10.16 extended thinking budget: ${extendedThinkingBudgetReportV11016.summary.take(260)}; passes=${extendedThinkingBudgetReportV11016.passesExecuted}/${extendedThinkingBudgetReportV11016.minimumPassesRequired}; next=${extendedThinkingBudgetReportV11016.nextAction.take(180)}",
                    "v1.10.17 extended acquisition sweep: minSources=${RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES}; minQueryPaths=${RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_QUERY_PATHS}; claim-limit=${ExtendedAcquisitionSweepPolicy.CLAIM_LIMIT}",
                    "v1.10.18 autonomous exploration sandbox: ${AutonomousExplorationSandboxPolicy.summary()} domains=${AutonomousExplorationSandboxPolicy.adjacentDomains.joinToString(",")}; claim-limit=${AutonomousExplorationSandboxPolicy.CLAIM_LIMIT}",
                    "v1.10.19 source priority arbitration: ${SourcePriorityArbitrationPolicy.summary(datasetForagingReport.sourceFamiliesAttempted, datasetForagingReport.noCandidateLearningRecords.firstOrNull()?.nextPreferredSource.orEmpty().ifBlank { datasetForagingReport.accessionAcquisitionReport.nextAction })}; claim-limit=${SourcePriorityArbitrationPolicy.CLAIM_LIMIT}",
                    "v1.10.23 domain expertise continuity: ${datasetForagingReport.domainExpertiseReport.summary.take(260)}; protected=${datasetForagingReport.domainExpertiseReport.protectedBeliefCount}; claim-limit=${datasetForagingReport.domainExpertiseReport.claimLimit}",
                    "v1.10.23 learning rule engine: matches=${learningRuleMatchesV11021.size}; top=${learningRuleMatchesV11021.firstOrNull()?.ruleId ?: "none"}; action=${LearningRuleEngine.nextAction(learningRuleMatchesV11021).take(180)}; claim-limit=${LearningRuleEngine.CLAIM_LIMIT}",
                    "v1.10.23 route fingerprint guard: ${routeFingerprintReportV11021.summary.take(220)}; claim-limit=${RouteFingerprintGuard.CLAIM_LIMIT}",
                    "v2.7.2 learning loop activation: ${LearningLoopActivationV262.oneLine(learningLoopActivationReportV262)}; claim-limit=${LearningLoopActivationV262.CLAIM_LIMIT}",
                    "v1.10.23 accession mining intensity: PubMed accession-mining uses a deeper bounded retMax/abstract window than contradiction/control; claim-limit=${AccessionMiningIntensityPolicy.CLAIM_LIMIT}",
                    "v1.10.24 abstract accession harvest: ${AccessionTextHarvestPolicy.summary()}; claim-limit=${AccessionTextHarvestPolicy.CLAIM_LIMIT}",
                    "v1.10.25 data-availability query priority: ${DataAvailabilityAccessionQueryPolicy.summary()}; claim-limit=${DataAvailabilityAccessionQueryPolicy.CLAIM_LIMIT}",
                    MatureDomainEvidenceProbePolicy.learningNote(datasetForagingReport.matureDomainEvidenceProbeReport),
                    "v1.10.27 path linkage guard: ${datasetForagingReport.pathLinkageReport.state}; ${datasetForagingReport.pathLinkageReport.handoffSummary.take(220)}; warnings=${datasetForagingReport.pathLinkageReport.warnings.size}; claim-limit=${datasetForagingReport.pathLinkageReport.claimLimit}",
                    "v1.10.28 pass coverage linkage: coverage=${datasetForagingReport.pathLinkageReport.coverageState}; corePaths=${datasetForagingReport.pathLinkageReport.coreQueryPathCount}; adjacentPaths=${datasetForagingReport.pathLinkageReport.adjacentQueryPathCount}; maturePaths=${datasetForagingReport.pathLinkageReport.matureProbeQueryPathCount}; claim-limit=${datasetForagingReport.pathLinkageReport.claimLimit}",
                    "v1.10.30 learning/domain path linkage: ${datasetForagingReport.learningDomainPathLinkageReport.state}; ${datasetForagingReport.learningDomainPathLinkageReport.handoffSummary.take(240)}; warnings=${datasetForagingReport.learningDomainPathLinkageReport.warnings.size}; claim-limit=${datasetForagingReport.learningDomainPathLinkageReport.claimLimit}",
                    "v1.10.31 evidence-lead path linkage: ${datasetForagingReport.evidenceLeadPathLinkageReport.state}; manualLinked=${datasetForagingReport.evidenceLeadPathLinkageReport.manualSeedLinkedToForager}; weakLinked=${datasetForagingReport.evidenceLeadPathLinkageReport.weakLeadLinkedToRelaxation}; decisionLinked=${datasetForagingReport.evidenceLeadPathLinkageReport.breakthroughLinkedToDecision}; warnings=${datasetForagingReport.evidenceLeadPathLinkageReport.warnings.size}; claim-limit=${datasetForagingReport.evidenceLeadPathLinkageReport.claimLimit}",
                    "v1.10.32 mature-domain focus: ${datasetForagingReport.matureDomainFocusReport.state}; domain=${datasetForagingReport.matureDomainFocusReport.selectedDomain}; gaps=${datasetForagingReport.knowledgeGapQueueReport.items.size}; semanticReplay=${datasetForagingReport.strongRouteFingerprintReport.replayRisk}; claim-limit=${datasetForagingReport.matureDomainFocusReport.claimLimit}",
                    "v1.10.33 lean runtime: ${datasetForagingReport.leanAgentRuntimeReport.state}; agents=${datasetForagingReport.leanAgentRuntimeReport.microAgentsRun.size}; gates=${datasetForagingReport.leanAgentRuntimeReport.hardGatesApplied.size}; claim-limit=${datasetForagingReport.leanAgentRuntimeReport.claimLimit}",
                    UsefulLearningReportPolicy.learningNote(datasetForagingReport.learningValueScoreReport),
                    "v1.10.34 topic memory: threads=${datasetForagingReport.topicMemoryLedgerReport.threadCount}; active=${datasetForagingReport.topicMemoryLedgerReport.activeThread?.immuneAxis ?: "none"}; leadQueue=${datasetForagingReport.leadInspectionQueueReport.openItems}; progress=${datasetForagingReport.researchProgressWithoutEvidenceReport.progressState}; claim-limit=${datasetForagingReport.learningValueScoreReport.claimLimit}",
                    "v1.10.35 lead closure handoff: ${datasetForagingReport.leadClosureHandoffReport.state}; carried=${datasetForagingReport.leadClosureHandoffReport.carriedLeadCount}; missing=${datasetForagingReport.leadClosureHandoffReport.missingFields.take(5).joinToString(",").ifBlank { "none" }}; claim-limit=${datasetForagingReport.leadClosureHandoffReport.claimLimit}",
                    "v1.10.35 metadata closure: ${datasetForagingReport.metadataClosureReport.state}; closed=${datasetForagingReport.metadataClosureReport.closedFields.size}; missing=${datasetForagingReport.metadataClosureReport.missingFields.take(5).joinToString(",").ifBlank { "none" }}; claim-limit=${datasetForagingReport.metadataClosureReport.claimLimit}",
                    "v1.10.35 unknown-route classifier: ${datasetForagingReport.unknownRouteClassificationReport.state}; selected=${datasetForagingReport.unknownRouteClassificationReport.selectedRoute}; confidence=${datasetForagingReport.unknownRouteClassificationReport.confidence}/100; claim-limit=${datasetForagingReport.unknownRouteClassificationReport.claimLimit}",
                    "v1.10.37 EBV criterion lane: ${datasetForagingReport.ebvLeadVerificationReport.state}; target=${datasetForagingReport.ebvLeadVerificationReport.targetLeadId}; missing=${datasetForagingReport.ebvLeadVerificationReport.missingEvidence.take(5).joinToString(",").ifBlank { "none" }}; claim-limit=${datasetForagingReport.ebvLeadVerificationReport.claimLimit}",
                    "v1.10.38 evidence prior matrix: ${datasetForagingReport.evidencePriorSelectionReport.state}; selected=${datasetForagingReport.evidencePriorSelectionReport.selectedPriorId}; gates=${datasetForagingReport.evidencePriorSelectionReport.requiredGates.take(5).joinToString(",").ifBlank { "none" }}; claim-limit=${datasetForagingReport.evidencePriorSelectionReport.claimLimit}",
                    "v1.10.39 integrated path linkage: ${datasetForagingReport.integratedPathLinkageReport.state}; connected=${datasetForagingReport.integratedPathLinkageReport.connectedLayers.take(8).joinToString(",").ifBlank { "none" }}; openWarnings=${datasetForagingReport.integratedPathLinkageReport.openWarnings.size}; claim-limit=${datasetForagingReport.integratedPathLinkageReport.claimLimit}",
                    "v1.10.40 release stability gate: ${FinalReleaseStabilityReport.fromRuntime().state}; missing=${FinalReleaseStabilityGuard.missingRequiredLayers().joinToString(",").ifBlank { "none" }}; claim-limit=${FinalReleaseStabilityGuard.CLAIM_LIMIT}",
                    "v1.10.41 biomedical research ontology: ${datasetForagingReport.biomedicalOntologyReport.state}; domains=${datasetForagingReport.biomedicalOntologyReport.selectedDomains.take(4).joinToString(",").ifBlank { "none" }}; diagnostic=${datasetForagingReport.biomedicalOntologyReport.diagnosticPhenotypeMode}; claim-limit=${datasetForagingReport.biomedicalOntologyReport.claimLimit}",
                    "v1.10.42 biomedical concept bridge: ${datasetForagingReport.biomedicalConceptBridgeReport.state}; bridges=${datasetForagingReport.biomedicalConceptBridgeReport.selectedBridgeIds.take(3).joinToString(",").ifBlank { "none" }}; keys=${datasetForagingReport.biomedicalConceptBridgeReport.evidenceKeysToClose.take(5).joinToString(",").ifBlank { "none" }}; claim-limit=${datasetForagingReport.biomedicalConceptBridgeReport.claimLimit}",
                    "v1.10.43 modern medical technology intelligence: ${datasetForagingReport.modernMedicalTechnologyReport.state}; modules=${datasetForagingReport.modernMedicalTechnologyReport.selectedModuleIds.take(4).joinToString(",").ifBlank { "none" }}; partitions=${datasetForagingReport.modernMedicalTechnologyReport.partitionIndexKeys.take(5).joinToString(",").ifBlank { "none" }}; claim-limit=${datasetForagingReport.modernMedicalTechnologyReport.claimLimit}",
                    "v1.10.44 viral countermeasure intelligence: ${datasetForagingReport.viralCountermeasureReport.state}; virus=${datasetForagingReport.viralCountermeasureReport.selectedVirusKey}; lane=${datasetForagingReport.viralCountermeasureReport.selectedLane}; keys=${datasetForagingReport.viralCountermeasureReport.evidenceKeysToClose.take(5).joinToString(",").ifBlank { "none" }}; claim-limit=${datasetForagingReport.viralCountermeasureReport.claimLimit}",
                    "v1.10.46 longevity biological systems graph: ${datasetForagingReport.longevityBiologicalSystemsReport.state}; lane=${datasetForagingReport.longevityBiologicalSystemsReport.selectedLane}; biomarkers=${datasetForagingReport.longevityBiologicalSystemsReport.biomarkersRequired.take(6).joinToString(",").ifBlank { "none" }}; contradiction=${datasetForagingReport.longevityBiologicalSystemsReport.contradictionSearchTerms.take(3).joinToString(",").ifBlank { "none" }}; claim-limit=${datasetForagingReport.longevityBiologicalSystemsReport.claimLimit}",
                    "legacy audit token: v1.10.47 topic-fit metadata parse UI clarity; upgraded by v1.10.48 relaxed progression context alignment",
                    "v1.10.52 open exploration + medical index + diagnostic reasoning sandbox: ${datasetForagingReport.topicFitMetadataParseReport.state}; topic=${datasetForagingReport.topicFitMetadataParseReport.topicLabel}; preferred=${datasetForagingReport.topicFitMetadataParseReport.preferredLane}; correction=${datasetForagingReport.topicFitMetadataParseReport.topicRouteCorrectionStatus}; reconciliation=${datasetForagingReport.topicFitMetadataParseReport.legacyRouteReconciliationStatus}; reconciledQuery=${datasetForagingReport.topicFitMetadataParseReport.reconciledQuerySeed}; comparator=${datasetForagingReport.topicFitMetadataParseReport.comparatorHuntMode}; comparatorQueries=${datasetForagingReport.topicFitMetadataParseReport.comparatorHuntQueries.take(2).joinToString(" | ")}; forced=${datasetForagingReport.topicFitMetadataParseReport.forcedMinimumMetadataCount}; parsed=${datasetForagingReport.topicFitMetadataParseReport.parsedMetadataCount}; eoc=${datasetForagingReport.topicFitMetadataParseReport.evidenceObjectCandidateCount}; suppressed=${datasetForagingReport.topicFitMetadataParseReport.suppressedMatureDomain}; open=${datasetForagingReport.topicFitMetadataParseReport.openExplorationMode}; diagnosticSandbox=${datasetForagingReport.topicFitMetadataParseReport.diagnosticReasoningMode}; medicalIndex=${datasetForagingReport.topicFitMetadataParseReport.medicalIndexTerms.take(6).joinToString("|")}; dynamicNodes=${datasetForagingReport.topicFitMetadataParseReport.dynamicNodesOpened.take(6).joinToString("|")}; claim-limit=${datasetForagingReport.topicFitMetadataParseReport.claimLimit}",
                    "v1.10.44 biomedical dictionary/database linkage: ${datasetForagingReport.biomedicalKnowledgeGraphLinkageReport.state}; partitions=${datasetForagingReport.biomedicalKnowledgeGraphLinkageReport.selectedPartitions.take(6).joinToString(",").ifBlank { "none" }}; edges=${datasetForagingReport.biomedicalKnowledgeGraphLinkageReport.bridgeEdges.size}; claim-limit=${datasetForagingReport.biomedicalKnowledgeGraphLinkageReport.claimLimit}",
                    "v1.10.0 prior spine lock: ${if (priorLinkedSpineLockV200) "ACTIVE ${priorLinkedSpineDirectiveV200.mode}" else "inactive"}",
                    "v1.9.9 prior momentum lock: ${if (priorMomentumLockV199) "ACTIVE ${priorMomentumDirectiveV199.mode}" else "inactive"}",
                    "v1.9.7 prior closure lock: ${if (priorClosureLockV197) "ACTIVE one-query accession closure" else "inactive"}",
                    *foundationKnowledgeNotesV151.toTypedArray(),
                    "v1.4.3 persistent failure memory: ${persistentFailureMemoryAfter.summary}",
                    "v1.3.7 Learning OS: ${learningOsReport.incident.rootCauses.joinToString(", ").ifBlank { "no incident" }}; next: ${learningOsReport.nextLearningAction}",
                    "Discovery readiness: ${discoveryReadiness.score}/100 ${discoveryReadiness.state}"
                )
            ),
            autonomousPlan = autonomousPlan,
            resilienceDecision = resilienceDecision,
            queryEvolutionState = queryEvolutionState,
            datasetCandidatesV133 = datasetCandidatesV133,
            datasetCandidatesV137 = datasetCandidatesV137,
            evidenceObjects = evidenceObjects,
            discoveryReadiness = discoveryReadiness,
            learningOsReport = learningOsReport,
            runtimeStatus = runtimeStatus,
            executionLockReport = executionLockReport,
            datasetForagingReport = datasetForagingReport,
            persistentFailureMemory = persistentFailureMemoryAfter,
            reportV3 = reportV3,
            reasoningReport = reasoningReport,
            specializedReasoningReport = specializedReasoningReport,
            knowledgeMapReport = knowledgeMapReport,
            epistemicBeliefReport = epistemicBeliefReport,
            cognitivePathIntegrationReport = cognitivePathIntegrationReport,
            cognitiveNextCyclePlan = cognitiveNextCyclePlanV165,
            cognitiveLoopCalibrationReport = cognitiveLoopCalibrationReport,
            directiveLifecycleReport = directiveLifecycleReportV170,
            evidenceGainQueryRankerReport = evidenceGainQueryRankerReportV170,
            beliefFalsificationContractReport = beliefFalsificationContractReportV171,
            memoryConsolidationReport = memoryConsolidationReportV173,
            causalReadinessReport = causalReadinessReportV174,
            reflectionLessonReport = reflectionLessonReportV176,
            miniPeerReviewReport = miniPeerReviewReportV177,
            reportSimplificationReport = reportSimplificationReportV178,
            scientificKnowledgeIndexReport = scientificKnowledgeIndexReportV180,
            deepDiscoveryReasoningReport = deepDiscoveryReasoningReportV180,
            scientificDiscoveryWeightReport = scientificDiscoveryWeightReportV182,
            scientificDiscoveryDecisionReport = scientificDiscoveryDecisionReportV183,
            scientificDiscoveryStressTestReport = scientificDiscoveryStressTestReportV184,
            scientificDiscoveryExecutionPolicyReport = scientificDiscoveryExecutionPolicyReportV185,
            scientificDiscoveryOutcomeVerifierReport = scientificDiscoveryOutcomeVerifierReportV186,
            scientificDiscoveryLineageReport = scientificDiscoveryLineageReportV187,
            scientificDiscoveryGapMinerReport = scientificDiscoveryGapMinerReportV188,
            scientificDiscoveryProbePlanReport = scientificDiscoveryProbePlanReportV189,
            scientificDiscoveryProbeOutcomeLedgerReport = scientificDiscoveryProbeOutcomeLedgerReportV190,
            scientificDiscoveryMetaStrategyReport = scientificDiscoveryMetaStrategyReportV191,
            scientificDiscoveryQualityGateReport = scientificDiscoveryQualityGateReportV192,
            scientificDiscoveryRunbookReport = scientificDiscoveryRunbookReportV193,
            evidenceClosureReport = evidenceClosureReportV195,
            postSearchThinkingReport = postSearchThinkingReportV195,
            thinkingContinuityReport = thinkingContinuityReportV196,
            hypothesisGraphReport = hypothesisGraphReportV198,
            cognitiveMomentumReport = cognitiveMomentumReportV199,
            linkedCognitionSpineReport = linkedCognitionSpineReportV200,
            cyclePlanStageReport = cyclePlanStageReportV206,
            cyclePhaseAuditReport = cyclePhaseAuditReportV204,
            pathMaintenanceReport = pathMaintenanceReportV207,
            extendedThinkingBudgetReport = extendedThinkingBudgetReportV11016,
            hypothesisObjects = hypothesisObjects,
            learningDeltaCards = learningDeltaCards,
            mistakeRiskCards = mistakeRiskCards,
            researchStateSummary = researchStateSummary,
            globalImmuneIntelligence = globalImmuneIntelligence,
            limitations = listOf(
                "This is a private research-mining tool. It does not prove causality.",
                "DNA/RNA links are hypothesis leads only unless validated against curated datasets and repeated observations.",
                "Search avoids previously stored PubMed IDs, but similar scientific ideas may recur under new papers.",
                "Manual imported reports are treated as unverified research notes until source quality is checked.",
                "Research steering variables focus the search; they do not prove a causal relationship.",
                "Evidence quality, causality, and negative controls are ranking aids, not proof.",
                "Human evidence is separated from animal/cell-only evidence when metadata allows it.",
                "Global dataset candidates are leads for inspection; accession, license, sample size, and outcome labels must be verified before modeling.",
                "Antiviral-response notes describe research direction only; they do not predict protection against new variants.",
                "v1.3.3 no-result recovery changes research strategy after empty or repeated cycles; it does not claim discovery when no useful delta occurred.",
                "v1.3.4 research reasoning generates questions, competing explanations, discriminators, reframed search terms, and self-critique; it does not prove any hypothesis.",
                "v1.3.6 anti-stagnation applies the prior failed-cycle pivot in the next run and widens low-data PubMed retmax before normal lanes.",
                "v1.3.7 learning OS converts repeated failure into root-cause tags, preventive gates, lane cooldowns, and regression vectors; it does not claim discovery without evidence objects.",
                "v1.4.3 keeps dataset parsing active, closes legacy daily-scan runtime routes, and rewrites next evidence into executable dataset/control/contradiction actions; it still does not prove causality or clinical value.",
                "v1.4.4 separates dataset usability, route fit, and hypothesis confidence; off-route datasets cannot upgrade unrelated hypotheses.",
                "v1.4.5 ML-safe triage ranks dataset inspection only; it is triage_only_not_biological_proof and cannot prove mechanisms, diagnosis, treatment, or immune outcomes.",
                "v1.4.5 failure-pattern memory and query feedback learn from repeated search failures; they rank the next hunt and do not constitute biological proof.",
                "v1.5.6 Foundation Knowledge OS guides route selection, conflict resolution, and query planning; it is foundation_knowledge_not_evidence and never auto-updates JSON knowledge packs.",
                "v1.5.6 Learning Sessions are bounded, pausable research-review sessions; they create checkpointed insights and do not perform diagnosis, treatment, or biological proof.",
                "v1.6.1 Specialist Evidence Protocol adds evidence gaps, hypothesis tournament, reasoning audit, and next-cycle protocol; it is specialized_reasoning_not_biological_proof.",
                "v1.6.2 Cumulative Knowledge Map carries forward prior nodes/links/gaps so each search starts from accumulated context; it is knowledge_map_not_biological_proof.",
                "v1.6.3 Epistemic Belief Model turns accumulated knowledge into mutable research priors that can be weakened, revised, or retired when credibility is lost; it is epistemic_beliefs_not_biological_proof.",
                "v1.6.4 Cognitive Path Integration links map, belief, specialist protocol, and forager outputs into one next action; it is cognitive_path_integration_not_biological_proof.",
                "v1.6.7 Cognitive Directive Retirement consumes applied, invalid, or already-satisfied next-cycle directives so the same cognitive route cannot silently replay; it routes search only and cannot prove biology or upgrade hypotheses.",
                "v1.6.8 Cognitive Loop Calibration evaluates whether the previous directive improved the next cycle; it may dampen or reward routing behavior, but it cannot prove biology or upgrade hypotheses.",
                "v1.6.9 Epistemic Belief Discipline exposes strengthened/weakened/dropped beliefs, prunes weak unused beliefs, and forces every active belief to answer what evidence would make the system abandon it; it is still epistemic_beliefs_not_biological_proof.",
                "v1.7.0 Closed Cognitive Loop records directive lifecycle states from proposed/stored/applied/measured/retired/replay-blocked; it is directive_lifecycle_not_biological_proof.",
                "v1.7.1 Belief Falsification Contracts require strengthen/weaken/abandon/do-not-route conditions before a belief can guide routing; they are belief_falsification_contracts_not_biological_proof.",
                "v1.7.2 Evidence-Gain Query Ranker chooses the next query by blocker closure and falsification value; it is evidence_gain_ranking_not_biological_proof.",
                "v1.7.3 Memory Consolidation hides weak unused beliefs from the main report and keeps them as archive/mistake patterns; it is memory_consolidation_not_biological_proof.",
                "v1.7.4 Causal Readiness Gate blocks causal or strong-signal language below controlled comparison/repeated human signal thresholds; it is causal_readiness_not_biological_proof.",
                "v1.7.6 Reflection Lesson Store converts repeated search failures into prevention rules; it is reflection_lessons_not_biological_proof.",
                "v1.7.7 Mini Peer Review Gate can hold, inspect, reject, or advance with limits, but cannot prove biology.",
                "v1.7.8 Report Simplification Layer separates the user-facing summary from the technical appendix.",
                "v1.8.2 Scientific Term Index provides expanded local prior knowledge about immune, biology, DNA/RNA, allergy, virus, and inflammation terms; it guides routing only and cannot prove biology.",
                "v1.8.2 Deep Discovery Reasoner routes mechanism hypotheses, competing explanations, decisive tests, contradiction plans, cross-axis bridges, and gated Deep Think sessions into next-cycle routing; it is deep_discovery_reasoning_not_biological_proof.",
                "v1.8.2 Weighted Scientific Discovery Intelligence turns the scientific term index into routing weights, false-friend downgrades, decisive evidence deltas, and risk guards; it is scientific_weighting_guides_routing_not_proof.",
                "v1.8.3 Scientific Discovery Decision Memory turns weighted discovery into a falsifiable next-cycle contract with selected move, blocked move, success criteria, failure criteria, and change-if-fails policy; it is scientific_decision_memory_guides_routing_not_proof.",
                "v1.8.4 Counterfactual Discovery Stress Test simulates pass/fail/null/contradiction branches before the next cycle; it guides routing and cooldown only, not biological proof.",
                "v1.8.5 Policy-Enforced Discovery Control converts stress-test branches into concrete route cooldown, weak-belief burial, query replay blocks, and forced evidence keys; it guides routing only and cannot prove biology.",
                "v1.8.6 Outcome Verification Discovery Memory measures whether the enforced policy moved evidence readiness, resolved or repeated blockers, and should be rewarded, dampened, rerouted, or blocked; it guides routing only and cannot prove biology.",
                "v1.8.7 Hypothesis Lineage Discovery Graph records hypothesis origin, parent evidence, contradiction carry-forward, split/merge decisions, and next lineage tests; it guides routing only and cannot prove biology.",
                "v1.8.8 Latent Discovery Gap Miner finds dormant hypotheses, unasked bridge questions, and high-value evidence gaps that may deserve a narrow probe; it guides routing only and cannot prove biology.",
                "v1.8.9 Executable Discovery Probe Planner converts a latent opportunity into a bounded probe query, evidence pack, pass/fail/kill gates, replay blocks, and next-cycle route effect; it guides routing only and cannot prove biology.",
                "v1.9.0 Probe Outcome Learning Ledger verifies whether the previous probe closed its evidence pack, failed, or triggered kill/replay penalties; it guides routing only and cannot prove biology.",
                "v1.9.1 Meta-Strategy Governor chooses whether to continue, close evidence, reroute, replicate narrowly, archive, or allow one bounded Deep Think session; it guides strategy only and cannot prove biology.",
                "v1.9.2 Discovery Quality Gate blocks execution-worthy mistakes before the next cycle spends research budget; it guides routing only and cannot prove biology.",
                "v1.9.3 Executable Quality Runbook compiles the allowed mode, evidence checklist, hard stops, pass/fail signals, and replay blocks for the next cycle; it guides routing only and cannot prove biology.",
                "v1.10.0 Linked Cognition Spine connects closure, thinking, continuity, graph, momentum, quality gate, and runbook into one governing decision; it is linked_cognition_spine_not_biological_proof.",
                "v1.9.5 Evidence Closure Mode converts an accession into a local closure card and may block broad search until metadata, labels, controls, time order, and license/access are checked; it is accession_closure_not_biological_proof.",
                "v1.9.5 Post-Search Thinking connects evidence, hypotheses, objections, and next discriminators after the search has ended; it is post_search_thinking_not_biological_proof.",
                "v1.9.6 Thinking Continuity keeps offline thought threads, repeated blockers, and search permission alive across cycles; it is thinking_continuity_not_biological_proof.",
                "v1.9.8 Hypothesis Graph Cognition connects accessions, hypotheses, gaps, and objections into a local graph; it is hypothesis_graph_not_biological_proof.",
                "v1.9.9 Cognitive Momentum measures whether thinking progressed or repeated the same blocker and constrains the next search accordingly; it is cognitive_momentum_not_biological_proof.",
                "v1.10.4 Cycle Phase Audit verifies Plan/Search/Reason/Persist wiring and blocks runtime failover under active search locks; it is cycle_phase_audit_not_biological_proof.",
                "v1.10.7 Search Stage extraction moves network execution and runtime failover planning into a repairable stage; it changes wiring only, not biological interpretation.",
                "v1.10.7 Path Maintenance Guard connects phase spine, plan stage, search directive, and phase audit so broken handoffs can be repaired locally; it is path_maintenance_guard_not_biological_proof.",
                "v1.10.16 Extended Thinking Budget gives stalled/no-accession cycles a longer checkpointed local thinking budget and explicit reasoning passes before archive/reframe; it is extended_thinking_budget_not_biological_proof.",
                    "v1.10.17 Extended Acquisition Sweep prevents fast archive/reframe after only one accession-source attempt; it requires bounded source-family coverage before terminal archive; it is extended_acquisition_sweep_not_biological_proof.",
                    "v1.10.18 Autonomous Exploration Sandbox allows adjacent-domain retrieval across antihistamine/histamine, inflammatory disease, drug perturbation, aging, diabetes/metabolic inflammation, and gastric-acid/reflux/gut-barrier contexts; it is exploration_sandbox_not_biological_proof and never creates treatment, dosage, drug ranking, or clinical advice.",
                "v1.10.19 Source Priority Arbitration prevents creative/control routing from overriding accession-first search while NO_ACCESSION remains active.",
                "v1.10.20 Domain Expertise Continuity carries domain priors across cycles, deepens mature tracks before jumping domains, and remains domain_expertise_memory_not_biological_proof.",
                "v1.10.22 Accession Exhaustion Gate prevents archive/reframe until core accession sources, including PUBMED_ACCESSION_MINING, are attempted.",
                "v1.10.22 Domain Query Activation injects safe domain vocabulary into accession-mining queries so domain expertise can mature without claim upgrades.",
                "v1.10.23 Accession Mining Intensity gives PUBMED_ACCESSION_MINING a deeper bounded PubMed/abstract window before no-accession archive while keeping claims locked.",
                "v1.10.24 Abstract Accession Text Harvest extracts accession/data-availability snippets from fetched abstracts for retrieval only; it is ${AccessionTextHarvestPolicy.CLAIM_LIMIT}.",
                "v1.10.25 Data-Availability Accession Query Priority makes PUBMED_ACCESSION_MINING search deposition/accession language before broad mechanism terms; it is ${DataAvailabilityAccessionQueryPolicy.CLAIM_LIMIT}.",
                "v1.10.26 Mature Domain Evidence Probe relaxes terminal archive after core accession failure by reusing mature domain vocabulary for bounded data-availability probes; it is ${MatureDomainEvidenceProbePolicy.CLAIM_LIMIT}.",
                "v1.10.28 Dataset Pass Coverage Linkage aligns core accession, adjacent/contradiction/control, and mature-domain probe attempts into separate pass summaries; it is ${DatasetForagingPathLinkageGuard.CLAIM_LIMIT}.",
                "v1.10.30 Learning/Domain Path Linkage connects learning rules, no-candidate learning, query feedback, failure memory, mature domain priors, and dataset pass coverage into one auditable handoff; it is ${LearningDomainPathLinkageGuard.CLAIM_LIMIT}.",
                "v1.10.30 Release Version Linkage unifies build version, active engine, learning-session schema, report labels, docs, and GitHub/static-check audit expectations; it is ${ReleaseVersionLinkageGuard.CLAIM_LIMIT}.",
                "No medical advice, diagnosis, treatment, or drug selection is generated."
            )
        )
    }

    private fun buildQueries(importedSignals: List<ImportedReportSignal>, steering: ResearchSteeringProfile?, autonomousPlan: AutonomousResearchPlan): List<ResearchQuery> {
        val recentCases = LocalCaseStore(context).readLatest(15)
        val axisBoosts = inferAxisBoosts(recentCases, importedSignals) + (steering?.inferredAxes?.toSet() ?: emptySet())
        val globalCore = buildGlobalCoreQueries()
        val base = mutableListOf(
            ResearchQuery(
                "q_type2_stress_mast",
                "Type-2 + stress + mast-cell bridge",
                "(allergic rhinitis OR asthma OR allergy) AND (stress OR sleep OR psychoneuroimmunology) AND (mast cell OR IgE OR eosinophil)",
                "Looks for non-obvious links between psychological load, Type-2 allergy, and mast-cell/eosinophil activation."
            ),
            ResearchQuery(
                "q_ra_stress_cytokine",
                "RA + stress + inflammatory cytokines",
                "(rheumatoid arthritis) AND (stress OR sleep OR depression) AND (IL-6 OR TNF OR inflammation)",
                "Tests whether chronic stress/recovery debt may amplify autoimmune inflammatory axes."
            ),
            ResearchQuery(
                "q_back_inflammation_psych",
                "Back pain + inflammatory/psychological bridge",
                "(low back pain OR disc herniation OR intervertebral disc degeneration) AND (stress OR sleep OR fear avoidance OR inflammation)",
                "Searches for mechanical-neuroimmune bridges relevant to pain amplification and recovery failure."
            ),
            ResearchQuery(
                "q_allergy_aging_immunosenescence",
                "Allergy + aging / immunosenescence",
                "(allergy OR allergic rhinitis OR asthma OR IgE) AND (aging OR immunosenescence OR inflammaging OR longevity)",
                "Tests the non-linear hypothesis that allergic reactivity may represent preserved responsiveness in some contexts and inflammatory burden in others."
            ),
            ResearchQuery(
                "q_histamine_bp_autonomic",
                "Histamine + blood pressure + autonomic bridge",
                "(histamine OR mast cell OR allergy OR anaphylaxis) AND (blood pressure OR hypotension OR autonomic OR vasodilation)",
                "Looks for stress pressure-up vs histamine/vasodilation pressure-down mechanisms."
            ),
            ResearchQuery(
                "q_dna_epigenetic_allergy_aging",
                "DNA / epigenetic allergy-aging bridge",
                "(DNA methylation OR epigenetic OR genome OR SNP) AND (allergy OR asthma OR IgE) AND (aging OR immunosenescence OR inflammaging)",
                "Adds DNA/epigenetic mechanisms: methylation age, variants, and immune reactivity."
            ),
            ResearchQuery(
                "q_rna_transcriptomic_cross_immune",
                "RNA / transcriptomic cross-condition bridge",
                "(RNA-seq OR transcriptomic OR gene expression OR single-cell RNA) AND (allergy OR asthma) AND (rheumatoid arthritis OR autoimmunity OR cytokine storm)",
                "Searches RNA signatures that may bridge allergy, autoimmunity, and hyperinflammatory states."
            ),
            ResearchQuery(
                "q_mirna_mast_autonomic",
                "miRNA + mast-cell/autonomic bridge",
                "(microRNA OR miRNA OR noncoding RNA) AND (mast cell OR histamine OR allergy) AND (stress OR autonomic OR blood pressure)",
                "Looks for non-obvious RNA regulation between mast cells, stress, and vascular/autonomic behavior."
            ),
            ResearchQuery(
                "q_cytokine_regulatory_brake_genomics",
                "Hyperinflammation + genomic/RNA brake failure",
                "(cytokine storm OR hyperinflammation OR ARDS) AND (IL-10 OR regulatory T cells OR immune regulation) AND (genomics OR transcriptomics OR RNA-seq)",
                "Looks for regulatory-brake failure patterns with omics evidence."
            ),
            ResearchQuery(
                "q_gastric_acid_allergy_microbiome",
                "Gastric acid + allergy + microbiome bridge",
                "(gastric acid OR hypochlorhydria OR reflux OR GERD OR proton pump inhibitor OR H pylori) AND (allergy OR asthma OR IgE OR mast cell) AND (microbiome OR gut barrier OR gut-lung axis)",
                "Tests whether stomach-acid context, reflux, acid suppression, or gastritis-like factors connect to allergy through microbiome/gut-barrier or gut-lung pathways."
            ),
            ResearchQuery(
                "q_nutrition_muscle_immune_recovery",
                "Nutrition + muscle mass + immune recovery",
                "(protein intake OR diet diversity OR malnutrition OR sarcopenia OR muscle mass) AND (immune function OR inflammation OR recovery OR aging)",
                "Looks for nutrition/protein/muscle reserve as an immune-recovery and inflammaging modifier."
            ),
            ResearchQuery(
                "q_testosterone_immune_inflammation",
                "Testosterone + immune regulation",
                "(testosterone OR androgen OR hypogonadism) AND (immune function OR inflammation OR allergy OR autoimmunity OR cytokine)",
                "Tests whether testosterone/androgen context modulates inflammatory tone, allergy, autoimmunity, muscle reserve, or recovery."
            )
        )

        if (axisBoosts.contains("airway")) {
            base += ResearchQuery(
                "q_airway_stress_trigger",
                "Airway trigger timing",
                "(asthma OR allergic rhinitis OR sinusitis) AND (emotional stress OR panic OR breathing pattern) AND (exacerbation OR trigger)",
                "Added because stored/imported context contained airway/allergy or breathing-context signals."
            )
        }
        if (axisBoosts.contains("aging")) {
            base += ResearchQuery(
                "q_local_aging_allergy_bridge",
                "Local allergy-aging bridge",
                "(IgE OR eosinophil OR allergy) AND (inflammaging OR immunosenescence OR recovery OR frailty)",
                "Added because stored/imported context contained aging/autonomic/allergy bridge fields."
            )
        }
        if (axisBoosts.contains("autonomic")) {
            base += ResearchQuery(
                "q_local_autonomic_mast_bp",
                "Local autonomic-mast-cell BP bridge",
                "(mast cell OR histamine OR allergy) AND (autonomic OR blood pressure OR dizziness OR vasodilation)",
                "Added because stored/imported context contained BP, dizziness, flushing, or faintness during allergy context."
            )
        }
        if (axisBoosts.contains("gut_metabolic")) {
            base += ResearchQuery(
                "q_local_gut_metabolic_axis",
                "Local gut/nutrition/testosterone bridge",
                "(gastric acid OR reflux OR microbiome OR diet diversity OR protein intake OR muscle mass OR testosterone) AND (allergy OR immune regulation OR inflammation OR aging)",
                "Added because recent local/imported reports contained gut-acid, nutrition, muscle, or testosterone signals."
            )
        }
        if (axisBoosts.contains("genomics")) {
            base += ResearchQuery(
                "q_local_dna_rna_axis",
                "Local DNA/RNA immune bridge",
                "(epigenetics OR DNA methylation OR RNA-seq OR single-cell RNA OR miRNA) AND (immune regulation OR allergy OR inflammation OR aging)",
                "Added because recent local/imported reports contained DNA/RNA/genomic or transcriptomic signals."
            )
        }
        if (axisBoosts.contains("mechanical")) {
            base += ResearchQuery(
                "q_muscle_guarding_disc",
                "Muscle guarding / disc / stress loop",
                "(muscle guarding OR central sensitization) AND (low back pain OR disc) AND (stress OR sleep)",
                "Added because stored/imported context contained mechanical load or stress-amplified pain context."
            )
        }
        val steered = buildSteeredQueries(steering)
        val autonomous = AutonomousResearchPlanner().queries(autonomousPlan)
        return (steered + autonomous + globalCore + base).distinctBy { it.id }
    }

    private fun buildGlobalCoreQueries(): List<ResearchQuery> {
        return listOf(
            ResearchQuery(
                "q_global_antiviral_dataset",
                "Global antiviral response datasets",
                "(RNA-seq OR transcriptomic OR single-cell OR cohort OR dataset) AND (viral infection OR influenza OR RSV OR COVID OR hantavirus) AND (interferon OR viral load OR recovery OR severity)",
                "Finds public human immune datasets that separate protective antiviral response from deterioration or hyperinflammation."
            ),
            ResearchQuery(
                "q_global_trigger_response_outcome",
                "Trigger-response-outcome immune mapping",
                "(immune response OR cytokine OR interferon OR T cell OR antibody) AND (trigger OR exposure OR infection OR allergen) AND (outcome OR recovery OR severity) AND (dataset OR cohort)",
                "Looks for datasets that contain trigger, immune response axis, and outcome labels rather than isolated markers."
            ),
            ResearchQuery(
                "q_global_regulatory_brake_cross_condition",
                "Regulatory brake across conditions",
                "(IL-10 OR Treg OR regulatory T cells OR immune resolution) AND (allergy OR rheumatoid arthritis OR viral infection OR ARDS OR cytokine storm) AND (human OR patient OR cohort)",
                "Tests whether regulatory-brake failure bridges allergy, autoimmunity, and severe viral inflammation."
            ),
            ResearchQuery(
                "q_global_protection_damage_split",
                "Protection vs tissue damage split",
                "(interferon OR T cell OR antibody OR viral control) AND (tissue damage OR lung damage OR organ damage OR hyperinflammation) AND (human OR patient OR cohort)",
                "Separates useful pathogen control from damaging immune over-response."
            )
        )
    }

    private fun buildSteeredQueries(steering: ResearchSteeringProfile?): List<ResearchQuery> {
        if (steering == null || steering.variables.isEmpty()) return emptyList()
        // v0.9.1 privacy fix: sanitize user-supplied steering tokens BEFORE they
        // reach the outbound NCBI URL. This enforces the README claim that no
        // private case data is uploaded.
        val varSan = SteeringSanitizer.sanitize(steering.variables)
        val reqSan = SteeringSanitizer.sanitize(steering.requiredTerms)
        val excSan = SteeringSanitizer.sanitize(steering.excludedTerms)
        val variables = varSan.cleaned.take(8)
        val required = reqSan.cleaned.take(5)
        val focus = steering.focusQuestion.trim()
        val negative = excSan.cleaned.take(5).joinToString(" ") { "NOT " + pubmedTerm(it) }
        if (variables.isEmpty()) return emptyList()
        val out = mutableListOf<ResearchQuery>()

        val core = (variables + required).distinctBy { it.lowercase(Locale.US) }.take(10)
        if (core.isNotEmpty()) {
            val joined = core.joinToString(" AND ") { pubmedTerm(it) }
            out += ResearchQuery(
                id = "q_steer_core_${steering.profileId.takeLast(6)}",
                label = "Steered core variable search",
                query = listOf(joined, negative).filter { it.isNotBlank() }.joinToString(" "),
                reason = "User-directed research variables: ${variables.joinToString(", ")}. Focus: ${focus.ifBlank { "connect these variables and look for non-obvious mechanisms" }}"
            )
        }

        var pairIndex = 0
        for (i in 0 until variables.size) {
            for (j in i + 1 until variables.size) {
                if (pairIndex >= 8) break
                val a = variables[i]
                val b = variables[j]
                val contextTerms = required.joinToString(" OR ") { pubmedTerm(it) }
                val query = buildString {
                    append(pubmedTerm(a))
                    append(" AND ")
                    append(pubmedTerm(b))
                    if (contextTerms.isNotBlank()) append(" AND (").append(contextTerms).append(")")
                    if (negative.isNotBlank()) append(" ").append(negative)
                }
                out += ResearchQuery(
                    id = "q_steer_pair_${steering.profileId.takeLast(6)}_$pairIndex",
                    label = "Steered bridge: $a ↔ $b",
                    query = query,
                    reason = "User asked the engine to connect variables without code changes. Focus: ${focus.ifBlank { "find biological, causal, or hidden bridge mechanisms" }}"
                )
                pairIndex += 1
            }
        }
        return out
    }

    private fun pubmedTerm(term: String): String {
        val clean = term.trim().replace(Regex("\\s+"), " ").take(80)
        if (clean.isBlank()) return ""
        return if (clean.contains(" ")) "\"$clean\"" else clean
    }

    private fun inferAxisBoosts(records: List<String>, importedSignals: List<ImportedReportSignal>): Set<String> {
        val joined = (records.joinToString(" ") + " " + importedSignals.joinToString(" ") { it.matchedAxes.joinToString(" ") + " " + it.extractedKeywords.joinToString(" ") }).lowercase(Locale.US)
        val out = mutableSetOf<String>()
        if (joined.contains("allergylike\":true") || joined.contains("breathingdanger\":true") || joined.contains("type2_allergy_axis")) out += "airway"
        if (joined.contains("backordiscpain\":true") || joined.contains("mechanicalloadaxis") || joined.contains("psychomusculoskeletal_axis")) out += "mechanical"
        if (joined.contains("psychoneuroimmunestressaxis") || joined.contains("psychoneuroimmune_axis")) out += "stress"
        if (joined.contains("agingautonomicmap") || joined.contains("immunosenescenceaxis") || joined.contains("inflammagingaxis") || joined.contains("aging_immune_axis")) out += "aging"
        if (joined.contains("bloodpressureinstability") || joined.contains("dizzinessonstanding\":true") || joined.contains("faintnessduringallergy\":true") || joined.contains("autonomic_vascular_axis")) out += "autonomic"
        if (joined.contains("dna") || joined.contains("genomic") || joined.contains("epigenetic") || joined.contains("rna") || joined.contains("transcriptomic") || joined.contains("dna_genomic_axis") || joined.contains("rna_transcriptomic_axis")) out += "genomics"
        if (joined.contains("gutnutritionhormone") || joined.contains("gastric") || joined.contains("reflux") || joined.contains("microbiome") || joined.contains("protein") || joined.contains("musclemass") || joined.contains("testosterone") || joined.contains("gastric_acid_gut_axis") || joined.contains("testosterone_immune_axis")) out += "gut_metabolic"
        return out
    }


    private suspend fun runDatasetFirstForaging(
        shards: List<TestableHypothesisShard>,
        memory: PersistentFailureMemorySnapshot,
        personalLedger: PersonalPatternLedger,
        seen: Set<String>,
        executedQueries: MutableList<ResearchQuery>,
        executedQueryIds: MutableSet<String>,
        recordRuntimeIssue: (String, Throwable) -> Unit,
        shouldStop: () -> Boolean,
        searchDeadline: Long,
        evidenceFirstBudget: Boolean = false,
        steering: ResearchSteeringProfile? = null,
        recentReports: List<String> = emptyList(),
        manualEvidenceSeeds: List<String> = emptyList()
    ): DatasetForagingRunResult {
        val expandedRoutes = ExtendedAcquisitionSweepPolicy.expandRoutes(
            routes = DirectDatasetSourceRouter.routes(memory),
            memory = memory,
            evidenceFirstBudget = evidenceFirstBudget
        )
        val routes = SourcePriorityArbitrationPolicy.arbitrateRoutes(
            routes = expandedRoutes,
            memory = memory,
            accessionPressure = evidenceFirstBudget
        )
        val findings = mutableListOf<ResearchFinding>()
        val candidates = mutableListOf<DatasetAccessionCandidate>()
        val attempts = mutableListOf<DatasetSourceAttempt>()
        val manualEvidenceSeedReportV11031 = EvidenceLeadAndManualSeedPolicy.fromManualTexts(manualEvidenceSeeds)
        candidates += manualEvidenceSeedReportV11031.candidates.map { it.candidate }
        EvidenceLeadAndManualSeedPolicy.manualSeedAttempt(manualEvidenceSeedReportV11031)?.let { attempts += it }
        val reusableDomainVocabulary = DomainExpertiseMemoryPolicy.reusableQueryVocabularyFromRecentReports(recentReports)
            .ifEmpty { DomainExpertiseMemoryPolicy.bootstrapQueryVocabularyForExploration() }

        fun canContinue(): Boolean = !shouldStop() && System.currentTimeMillis() < searchDeadline

        // Backward audit token: val routeBudget = if (evidenceFirstBudget) RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES else 4
        val routeBudget = if (evidenceFirstBudget) {
            val externalLookupBudget = if (RuntimeFeatureFlags.ENABLE_EUROPE_PMC_LOOKUP_V265 || RuntimeFeatureFlags.ENABLE_OPENALEX_LOOKUP_V265) 6 else 0
            maxOf(
                RuntimeFeatureFlags.MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES,
                RuntimeFeatureFlags.MIN_CORE_ACCESSION_SOURCE_FAMILIES_BEFORE_ARCHIVE,
                externalLookupBudget
            )
        } else 4
        val perRouteQueryBudget = if (evidenceFirstBudget) 1 else -1
        for (route in routes.take(routeBudget)) {
            if (!canContinue()) break
            if (route.ncbiDb == "offline") {
                attempts += DatasetSourceAttempt(
                    sourceFamily = route.sourceFamily,
                    ncbiDb = route.ncbiDb,
                    query = "ARCHIVE_OR_REFRAME_ROUTE",
                    attempted = true,
                    idsFound = 0,
                    candidatesExtracted = 0,
                    status = "ARCHIVE_OR_REFRAME_ROUTE",
                    reason = route.reason
                )
                continue
            }
            // Backward audit token: DatasetQueryCompiler.compileForRoute(route, shards, memory)
            val sourceQueries = DatasetQueryCompiler.compileForRoute(route, shards, memory, reusableDomainVocabulary)
                .take(if (perRouteQueryBudget > 0) perRouteQueryBudget else if (route.ncbiDb == "pubmed") 2 else 3)

            for (query in sourceQueries) {
                if (!canContinue()) break
                if (!executedQueryIds.add(query.id)) continue
                executedQueries += query
                if (route.ncbiDb == "pubmed") {
                    val intensityPlan = AccessionMiningIntensityPolicy.planForSourceFamily(route.sourceFamily)
                    val ids = try {
                        searchPubMed(query.query, retMax = intensityPlan.retMax)
                    } catch (e: Exception) {
                        recordRuntimeIssue("datasetFirstPubMed:${query.id}", e)
                        emptyList()
                    }
                    val fresh = ids.filter { id -> !seen.contains("PubMed:$id") && findings.none { it.source == "PubMed" && it.sourceId == id } }
                    val batch = if (fresh.isEmpty()) emptyList() else try {
                        fetchPubMedSummariesBatch(
                            fresh.take(intensityPlan.retMax),
                            query,
                            personalLedger,
                            ResearchRunLimits(maxResultsPerQuery = intensityPlan.retMax, maxAbstractsPerCycle = intensityPlan.abstractBudget),
                            emptySet()
                        )
                    } catch (e: Exception) {
                        recordRuntimeIssue("datasetFirstPubMedSummary:${query.id}", e)
                        emptyList()
                    }
                    findings += batch
                    val explicitCandidates = DatasetAccessionResolver.fromFindings(batch)
                    val exploratoryCandidates = if (explicitCandidates.isEmpty()) {
                        DatasetAccessionResolver.fromExploratoryFindings(batch, route.sourceFamily, query)
                    } else {
                        emptyList()
                    }
                    val routeCandidates = (explicitCandidates + exploratoryCandidates)
                        .distinctBy { it.accession + ":" + it.sourceFindingId }
                    candidates += routeCandidates
                    attempts += DatasetSourceAttempt(
                        sourceFamily = route.sourceFamily,
                        ncbiDb = route.ncbiDb,
                        query = query.query,
                        attempted = true,
                        idsFound = ids.size,
                        candidatesExtracted = routeCandidates.size,
                        status = when {
                            batch.isEmpty() -> "NO_FRESH_PUBMED_EVIDENCE"
                            routeCandidates.any { it.status == "EXPLORATORY_LEAD_NEEDS_ACCESSION" } -> "EXPLORATORY_LEADS_CAPTURED"
                            routeCandidates.isNotEmpty() -> "PUBMED_DATASET_CANDIDATES_EXTRACTED"
                            else -> "PUBMED_EVIDENCE_INSPECTED_NO_DATASET_LEAD"
                        },
                        reason = route.reason + " " + intensityPlan.summary
                    )
                } else if (route.ncbiDb == "europepmc") {
                    val batch = try {
                        searchEuropePmcFindings(query, personalLedger, retMax = 12)
                    } catch (e: Exception) {
                        recordRuntimeIssue("datasetFirstEuropePmc:${query.id}", e)
                        emptyList()
                    }
                    findings += batch
                    val extracted = DatasetAccessionResolver.fromFindings(batch)
                    candidates += extracted
                    attempts += DatasetSourceAttempt(
                        sourceFamily = route.sourceFamily,
                        ncbiDb = route.ncbiDb,
                        query = query.query,
                        attempted = true,
                        idsFound = batch.size,
                        candidatesExtracted = extracted.size,
                        status = when {
                            batch.isEmpty() -> "EUROPE_PMC_NO_RESULTS"
                            extracted.isEmpty() -> "EUROPE_PMC_METADATA_FOUND_NO_ACCESSION"
                            else -> "EUROPE_PMC_ACCESSION_LEADS_EXTRACTED"
                        },
                        reason = route.reason + " Europe PMC REST endpoint used for user-triggered public data-availability lookup only."
                    )
                } else if (route.ncbiDb == "openalex") {
                    val batch = try {
                        searchOpenAlexFindings(query, personalLedger, retMax = 12)
                    } catch (e: Exception) {
                        recordRuntimeIssue("datasetFirstOpenAlex:${query.id}", e)
                        emptyList()
                    }
                    findings += batch
                    val extracted = DatasetAccessionResolver.fromFindings(batch)
                    candidates += extracted
                    attempts += DatasetSourceAttempt(
                        sourceFamily = route.sourceFamily,
                        ncbiDb = route.ncbiDb,
                        query = query.query,
                        attempted = true,
                        idsFound = batch.size,
                        candidatesExtracted = extracted.size,
                        status = when {
                            batch.isEmpty() -> "OPENALEX_NO_RESULTS"
                            extracted.isEmpty() -> "OPENALEX_WORKS_FOUND_NO_ACCESSION"
                            else -> "OPENALEX_ACCESSION_LEADS_EXTRACTED"
                        },
                        reason = route.reason + " OpenAlex Works endpoint used for user-triggered cross-index public metadata lookup only."
                    )
                } else {
                    val ids = try {
                        searchNcbiIds(route.ncbiDb, query.query, retMax = 12)
                    } catch (e: Exception) {
                        recordRuntimeIssue("datasetFirstNcbi:${route.ncbiDb}:${query.id}", e)
                        emptyList()
                    }
                    val fresh = ids.filter { id ->
                        val key1 = "NCBI_${route.sourceFamily}:$id"
                        !seen.contains(key1) && findings.none { it.sourceId == id && it.source.contains(route.sourceFamily) }
                    }
                    val batch = if (fresh.isEmpty()) emptyList() else try {
                        fetchNcbiDatasetSummariesBatch(route, fresh.take(20), query, personalLedger)
                    } catch (e: Exception) {
                        recordRuntimeIssue("datasetFirstNcbiSummary:${route.ncbiDb}:${query.id}", e)
                        emptyList()
                    }
                    findings += batch
                    val extracted = DatasetAccessionResolver.fromFindings(batch)
                    candidates += extracted
                    attempts += DatasetSourceAttempt(
                        sourceFamily = route.sourceFamily,
                        ncbiDb = route.ncbiDb,
                        query = query.query,
                        attempted = true,
                        idsFound = ids.size,
                        candidatesExtracted = extracted.size,
                        status = when {
                            ids.isEmpty() -> "SOURCE_SEARCH_NO_IDS"
                            batch.isEmpty() -> "IDS_FOUND_BUT_NO_USABLE_METADATA"
                            extracted.isEmpty() -> "METADATA_FOUND_NO_ACCESSION"
                            else -> "DATASET_CANDIDATES_EXTRACTED"
                        },
                        reason = route.reason
                    )
                }
            }
        }

        if (MatureDomainEvidenceProbePolicy.shouldRunProbe(
                recentReports = recentReports,
                candidates = candidates,
                parsedMetadata = emptyList(),
                attempts = attempts
            ) && canContinue()
        ) {
            val matureProbeQueries = MatureDomainEvidenceProbePolicy.compileProbeQueries(recentReports)
                .take(RuntimeFeatureFlags.MAX_MATURE_DOMAIN_PROBE_QUERIES)
            for (query in matureProbeQueries) {
                if (!canContinue()) break
                if (!executedQueryIds.add(query.id)) continue
                executedQueries += query
                val ids = try {
                    searchPubMed(query.query, retMax = 20)
                } catch (e: Exception) {
                    recordRuntimeIssue("matureDomainProbe:${query.id}", e)
                    emptyList()
                }
                val fresh = ids.filter { id -> !seen.contains("PubMed:$id") && findings.none { it.source == "PubMed" && it.sourceId == id } }
                val batch = if (fresh.isEmpty()) emptyList() else try {
                    fetchPubMedSummariesBatch(
                        fresh.take(20),
                        query,
                        personalLedger,
                        ResearchRunLimits(maxResultsPerQuery = 20, maxAbstractsPerCycle = 3),
                        emptySet()
                    )
                } catch (e: Exception) {
                    recordRuntimeIssue("matureDomainProbeSummary:${query.id}", e)
                    emptyList()
                }
                findings += batch
                val explicitCandidates = DatasetAccessionResolver.fromFindings(batch)
                val exploratoryCandidates = if (explicitCandidates.isEmpty()) {
                    DatasetAccessionResolver.fromExploratoryFindings(batch, MatureDomainEvidenceProbePolicy.SOURCE_FAMILY, query)
                } else {
                    emptyList()
                }
                val routeCandidates = (explicitCandidates + exploratoryCandidates)
                    .distinctBy { it.accession + ":" + it.sourceFindingId }
                candidates += routeCandidates
                attempts += DatasetSourceAttempt(
                    sourceFamily = MatureDomainEvidenceProbePolicy.SOURCE_FAMILY,
                    ncbiDb = "pubmed",
                    query = query.query,
                    attempted = true,
                    idsFound = ids.size,
                    candidatesExtracted = routeCandidates.size,
                    status = when {
                        batch.isEmpty() -> "MATURE_DOMAIN_PROBE_NO_FRESH_EVIDENCE"
                        routeCandidates.any { it.status == "EXPLORATORY_LEAD_NEEDS_ACCESSION" } -> "MATURE_DOMAIN_EXPLORATORY_LEADS_CAPTURED"
                        routeCandidates.isNotEmpty() -> "MATURE_DOMAIN_DATASET_CANDIDATES_EXTRACTED"
                        else -> "MATURE_DOMAIN_EVIDENCE_INSPECTED_NO_DATASET_LEAD"
                    },
                    reason = "v1.10.26 mature-domain evidence probe: relaxed research-prior probing after core accession exhaustion. ${query.reason}"
                )
            }
        }

        val distinctCandidates = candidates
            .distinctBy { it.accession + ":" + it.sourceFindingId }
            .sortedWith(compareByDescending<DatasetAccessionCandidate> { it.status == "LEAD_ONLY_NOT_EVIDENCE" }.thenByDescending { it.usabilityScore })
            .take(30)
        val parsedMetadata = DatasetParser.parse(distinctCandidates, findings)
        val contrastiveReport = ContrastiveEvidenceGate.evaluate(parsedMetadata)
        val evidenceHypergraph = EvidenceHypergraphLite.build(parsedMetadata)
        val cumulativeEvidence = CumulativeEvidenceScorer.score(emptyList(), parsedMetadata)
        val sourceFamilies = attempts.map { it.sourceFamily }.distinct()
        val noCandidateAttemptedFamilies = attempts
            .filter { it.attempted && it.candidatesExtracted == 0 }
            .map { it.sourceFamily }
            .distinct()
        val cycleNextNoCandidateSource = if (noCandidateAttemptedFamilies.isNotEmpty()) {
            SourcePriorityArbitrationPolicy.nextSourceAfterNoCandidateSequence(noCandidateAttemptedFamilies)
        } else {
            ""
        }
        val terminalArchiveRequested = attempts.any { it.sourceFamily == "ARCHIVE_OR_REFRAME_ROUTE" }
        val nearMissOrLeadSignalExistsV11033 = manualEvidenceSeedReportV11031.active ||
            attempts.any { it.attempted && it.idsFound > 0 && it.candidatesExtracted == 0 }
        val noCandidateLearningRecords = if (candidates.isEmpty()) {
            attempts
                .filter { it.attempted && it.candidatesExtracted == 0 && it.sourceFamily != "ARCHIVE_OR_REFRAME_ROUTE" }
                .distinctBy { it.sourceFamily }
                .map { attempt ->
                    val followUpSource = if (nearMissOrLeadSignalExistsV11033) {
                        "LEAD_OBJECT_SECONDARY_LOOKUP"
                    } else {
                        cycleNextNoCandidateSource.ifBlank { DirectDatasetSourceRouter.nextSourceAfterNoCandidate(attempt.sourceFamily) }
                    }
                    val followUpReason = if (nearMissOrLeadSignalExistsV11033) {
                        "${attempt.sourceFamily} produced a weak/near-miss lead signal; inspect the LeadObject ledger, source IDs, and supplementary-data phrases before rotating to another broad source family."
                    } else {
                        "${attempt.sourceFamily} returned no usable dataset candidate; rotate to the next untried source family instead of returning to THINK_FIRST."
                    }
                    NoCandidateLearningRecord(
                        sourceFamily = attempt.sourceFamily,
                        queryId = executedQueries.lastOrNull { q -> q.query == attempt.query }?.id ?: "unknown_query",
                        status = attempt.status,
                        missing = if (attempt.idsFound == 0) "accession_like_id" else "usable_dataset_metadata_or_accession",
                        nextPreferredSource = followUpSource,
                        reason = followUpReason
                    )
                }
        } else {
            emptyList()
        }
        val nextNoCandidateSource = if (nearMissOrLeadSignalExistsV11033) {
            "LEAD_OBJECT_SECONDARY_LOOKUP"
        } else {
            cycleNextNoCandidateSource.ifBlank { noCandidateLearningRecords.firstOrNull()?.nextPreferredSource.orEmpty() }
        }
        val relaxedMatureDomainProbeAvailable = MatureDomainEvidenceProbePolicy.seedsFromRecentReports(recentReports).isNotEmpty() ||
            attempts.any { it.sourceFamily == MatureDomainEvidenceProbePolicy.SOURCE_FAMILY }
        val accessionAcquisitionReport = AccessionAcquisitionHardening.evaluate(
            candidates = distinctCandidates,
            parsedMetadata = parsedMetadata,
            attempts = attempts,
            noCandidateLearningRecords = noCandidateLearningRecords,
            memory = memory,
            relaxedMatureDomainProbeAvailable = relaxedMatureDomainProbeAvailable
        )
        val creativeHypothesisForgeReport = CreativeHypothesisForge.build(
            sourceFamiliesAttempted = sourceFamilies,
            noCandidateLearningRecords = noCandidateLearningRecords,
            shards = shards,
            candidates = distinctCandidates,
            terminalArchiveRequested = terminalArchiveRequested,
            steering = steering
        )
        val domainExpertiseReportV11020 = DomainExpertiseMemoryPolicy.build(
            attempts = attempts,
            queries = executedQueries,
            candidates = distinctCandidates,
            parsedMetadata = parsedMetadata,
            recentReports = recentReports
        )
        val leadObjectsV11031 = EvidenceLeadAndManualSeedPolicy.toLeadObjects(
            manualSeedReport = manualEvidenceSeedReportV11031,
            candidates = distinctCandidates,
            attempts = attempts
        )
        val matureDomainFocusReportV11032 = MatureDomainFocusModePolicy.evaluate(
            domainReport = domainExpertiseReportV11020,
            attempts = attempts,
            candidates = distinctCandidates,
            parsedMetadata = parsedMetadata,
            recentReports = recentReports
        )
        val domainSpecificKillCriteriaReportV11032 = MatureDomainFocusModePolicy.killCriteria(
            focus = matureDomainFocusReportV11032,
            attempts = attempts,
            candidates = distinctCandidates,
            parsedMetadata = parsedMetadata
        )
        val domainExpertiseScoreUpgradeReportV11032 = MatureDomainFocusModePolicy.scoreUpgrade(
            domainReport = domainExpertiseReportV11020,
            attempts = attempts,
            candidates = distinctCandidates,
            parsedMetadata = parsedMetadata,
            leadObjects = leadObjectsV11031
        )
        val knowledgeGapQueueReportV11032 = MatureDomainFocusModePolicy.gapQueue(
            focus = matureDomainFocusReportV11032,
            attempts = attempts,
            candidates = distinctCandidates,
            parsedMetadata = parsedMetadata
        )
        val strongRouteFingerprintReportV11032 = MatureDomainFocusModePolicy.strongFingerprint(
            queries = executedQueries,
            attempts = attempts,
            focus = matureDomainFocusReportV11032,
            gapQueue = knowledgeGapQueueReportV11032,
            recentReports = recentReports
        )
        val matureDomainEvidenceProbeReportV11026 = MatureDomainEvidenceProbePolicy.evaluate(
            accessionReport = accessionAcquisitionReport,
            domainReport = domainExpertiseReportV11020,
            attempts = attempts,
            recentReports = recentReports
        )
        val datasetLeadRelaxationReportV11031 = EvidenceLeadAndManualSeedPolicy.relax(
            candidates = distinctCandidates,
            leadObjects = leadObjectsV11031
        )
        val evidenceDiscoveryBreakthroughReportV11031 = EvidenceLeadAndManualSeedPolicy.breakthrough(
            candidates = distinctCandidates,
            attempts = attempts,
            manualSeedReport = manualEvidenceSeedReportV11031,
            relaxationReport = datasetLeadRelaxationReportV11031,
            accessionReport = accessionAcquisitionReport,
            leadObjects = leadObjectsV11031
        )
        val metadataClosureReportV11035 = LeadClosureHandoffPolicy.metadataClosure(
            leadObjects = leadObjectsV11031,
            candidates = distinctCandidates,
            parsedMetadata = parsedMetadata
        )
        val leadClosureHandoffReportV11035 = LeadClosureHandoffPolicy.evaluateHandoff(
            recentReports = recentReports,
            leadObjects = leadObjectsV11031,
            breakthrough = evidenceDiscoveryBreakthroughReportV11031,
            metadataClosure = metadataClosureReportV11035
        )
        val unknownRouteClassificationReportV11035 = LeadClosureHandoffPolicy.classifyUnknownRoute(
            leadObjects = leadObjectsV11031,
            candidates = distinctCandidates,
            routeFits = emptyList(),
            recentReports = recentReports
        )
        val ebvLeadVerificationReportV11037 = EBVLeadVerificationPolicy.evaluate(
            leadObjects = leadObjectsV11031,
            candidates = distinctCandidates,
            metadataClosure = metadataClosureReportV11035,
            routeReport = unknownRouteClassificationReportV11035,
            recentReports = recentReports
        )
        val evidencePriorSelectionReportV11038 = ImmuneEvidencePriorMatrix.select(
            steering = steering,
            leadObjects = leadObjectsV11031,
            candidates = distinctCandidates,
            metadataClosure = metadataClosureReportV11035,
            routeReport = unknownRouteClassificationReportV11035,
            ebvReport = ebvLeadVerificationReportV11037,
            recentReports = recentReports
        )
        val biomedicalOntologyReportV11041 = BiomedicalResearchOntologyV11041.evaluate(
            steering = steering,
            leadObjects = leadObjectsV11031,
            candidates = distinctCandidates,
            evidencePrior = evidencePriorSelectionReportV11038,
            recentReports = recentReports
        )
        val biomedicalConceptBridgeReportV11042 = BiomedicalConceptBridgeV11042.evaluate(
            ontology = biomedicalOntologyReportV11041,
            evidencePrior = evidencePriorSelectionReportV11038,
            ebv = ebvLeadVerificationReportV11037,
            metadataClosure = metadataClosureReportV11035,
            recentReports = recentReports
        )
        val modernMedicalTechnologyReportV11043 = ModernMedicalTechnologyIntelligenceV11043.evaluate(
            ontology = biomedicalOntologyReportV11041,
            conceptBridge = biomedicalConceptBridgeReportV11042,
            evidencePrior = evidencePriorSelectionReportV11038,
            ebv = ebvLeadVerificationReportV11037,
            metadataClosure = metadataClosureReportV11035,
            recentReports = recentReports
        )
        val viralCountermeasureReportV11044 = ViralCountermeasureIntelligenceV11044.evaluate(
            steering = steering,
            leadObjects = leadObjectsV11031,
            metadataClosure = metadataClosureReportV11035,
            evidencePrior = evidencePriorSelectionReportV11038,
            ontology = biomedicalOntologyReportV11041,
            conceptBridge = biomedicalConceptBridgeReportV11042,
            modernTech = modernMedicalTechnologyReportV11043,
            recentReports = recentReports
        )
        val longevityBiologicalSystemsReportV11046 = LongevityBiologicalSystemsGraphV11046.evaluate(
            steering = steering,
            leadObjects = leadObjectsV11031,
            candidates = distinctCandidates,
            ontology = biomedicalOntologyReportV11041,
            conceptBridge = biomedicalConceptBridgeReportV11042,
            modernTech = modernMedicalTechnologyReportV11043,
            viral = viralCountermeasureReportV11044,
            evidencePrior = evidencePriorSelectionReportV11038,
            metadataClosure = metadataClosureReportV11035,
            recentReports = recentReports
        )
        val biomedicalKnowledgeGraphReportV11044 = BiomedicalKnowledgeGraphLinkerV11044.link(
            ontology = biomedicalOntologyReportV11041,
            conceptBridge = biomedicalConceptBridgeReportV11042,
            modernTech = modernMedicalTechnologyReportV11043,
            viral = viralCountermeasureReportV11044,
            metadataClosure = metadataClosureReportV11035,
            longevity = longevityBiologicalSystemsReportV11046
        )
        val topicFitMetadataParseForagerV11047 = TopicFitMetadataParseUiClarityV11047.evaluate(
            steering = steering,
            matureFocus = matureDomainFocusReportV11032,
            longevity = longevityBiologicalSystemsReportV11046,
            candidateAction = CandidateActionReport.empty(),
            parsedMetadata = parsedMetadata,
            evidenceObjects = emptyList(),
            metadataClosure = metadataClosureReportV11035
        )
        val metadataClosureStrategyMatrixReportV11056 = MetadataClosureStrategyMatrixV11058.evaluate(
            steering = steering,
            leadObjects = leadObjectsV11031,
            candidates = distinctCandidates,
            parsedMetadata = parsedMetadata,
            attempts = attempts,
            topicFit = topicFitMetadataParseForagerV11047,
            metadataClosure = metadataClosureReportV11035,
            recentReports = recentReports
        )
        val mechanismDiscoveryDossierReportV1110 = ResearchGradeMechanismDossierV1110.evaluate(
            steering = steering,
            matrix = metadataClosureStrategyMatrixReportV11056,
            candidates = distinctCandidates,
            parsedMetadata = parsedMetadata,
            leadObjects = leadObjectsV11031,
            attempts = attempts
        )
        val evidenceActivitySeparationReportV11031 = EvidenceLeadAndManualSeedPolicy.activitySeparation(
            attempts = attempts,
            candidates = distinctCandidates,
            evidenceObjects = emptyList(),
            noCandidateRecords = noCandidateLearningRecords,
            domainReport = domainExpertiseReportV11020
        )

        val coreAccessionSourceSetV11028 = SourcePriorityArbitrationPolicy.coreAccessionFamilies.toSet()
        val pass1 = DatasetForagingPass(
            passId = "PASS1_DATASET_ACCESSION_HUNT",
            label = "Core accession-source hunt",
            status = if (attempts.any { it.sourceFamily in coreAccessionSourceSetV11028 && it.idsFound > 0 }) "ATTEMPTED_WITH_SOURCE_RESPONSE" else "ATTEMPTED_NO_IDS",
            attempts = attempts.filter { it.sourceFamily in coreAccessionSourceSetV11028 }
        )
        val pass2 = DatasetForagingPass(
            passId = "PASS2_METADATA_USABILITY_INSPECTION",
            label = "Metadata usability inspection",
            status = if (distinctCandidates.isEmpty()) "NO_CANDIDATE_TO_SCORE" else "CANDIDATES_SCORED_${distinctCandidates.size}",
            attempts = attempts.filter { it.candidatesExtracted > 0 }
        )
        val pass3 = DatasetForagingPass(
            passId = "PASS3_ADJACENT_CONTRADICTION_CONTROL_CHECK",
            label = "Adjacent-domain / contradiction / control check",
            status = if (attempts.any { it.ncbiDb == "pubmed" && it.sourceFamily !in coreAccessionSourceSetV11028 && it.sourceFamily != MatureDomainEvidenceProbePolicy.SOURCE_FAMILY && it.idsFound > 0 }) "SECONDARY_CHECK_ATTEMPTED" else "SECONDARY_CHECK_NO_IDS_OR_NOT_REACHED",
            attempts = attempts.filter { it.ncbiDb == "pubmed" && it.sourceFamily !in coreAccessionSourceSetV11028 && it.sourceFamily != MatureDomainEvidenceProbePolicy.SOURCE_FAMILY }
        )
        val matureProbeAttempts = attempts.filter { it.sourceFamily == MatureDomainEvidenceProbePolicy.SOURCE_FAMILY }
        val pass4 = if (matureProbeAttempts.isNotEmpty() || matureDomainEvidenceProbeReportV11026.active) {
            DatasetForagingPass(
                passId = "PASS4_MATURE_DOMAIN_EVIDENCE_PROBE",
                label = "Mature-domain evidence probe linkage",
                status = when {
                    matureProbeAttempts.any { it.candidatesExtracted > 0 } -> "MATURE_DOMAIN_PROBE_CANDIDATE_CAPTURED"
                    matureProbeAttempts.isNotEmpty() -> "MATURE_DOMAIN_PROBE_ATTEMPTED_NO_CANDIDATE"
                    matureDomainEvidenceProbeReportV11026.active -> "MATURE_DOMAIN_PROBE_READY_NOT_ATTEMPTED"
                    else -> "NOT_EVALUATED"
                },
                attempts = matureProbeAttempts
            )
        } else {
            null
        }
        val blockedReason = when {
            matureDomainEvidenceProbeReportV11026.active -> "Mature domain evidence probe: relax terminal archive because mature domain expertise exists; keep working priors and run bounded accession/data-availability probes without claims."
            accessionAcquisitionReport.state == "NO_ACCESSION_ARCHIVE_ROUTE" -> "Accession acquisition hardening: source sweep completed with no dataset handle; archive or reframe route before another broad report."
            accessionAcquisitionReport.state == "NO_ACCESSION_CONTINUE_SOURCE_SWEEP" -> "Extended acquisition sweep: do not archive yet; too few accession-capable source families/query paths were attempted."
            accessionAcquisitionReport.state == "FOUND_WEAK_ACCESSION_NEEDS_METADATA" -> "Accession acquisition hardening: weak/unresolved dataset handle found; keep report compact and parse metadata before any hypothesis upgrade."
            terminalArchiveRequested -> "Learning stopped: all bounded source families failed; archive or reframe the route before another search cycle."
            distinctCandidates.any { it.status == "EXPLORATORY_LEAD_NEEDS_ACCESSION" } -> "Exploratory capture only: weak unresolved leads may guide inspection, but hypothesis upgrade remains blocked until accession/metadata closure."
            distinctCandidates.isNotEmpty() -> "Learning allowed only as dataset-candidate inspection; hypothesis upgrade still requires evidence object quality."
            attempts.any { it.idsFound > 0 } -> "Learning blocked: source returned IDs but no usable accession/metadata candidate survived."
            else -> "Learning blocked: direct dataset-source searches returned no usable evidence object."
        }
        val finalForagerState = when {
            accessionAcquisitionReport.state == "FOUND_ACCESSION" -> "DATASET_FORAGING_FOUND_ACCESSION"
            leadClosureHandoffReportV11035.active && metadataClosureReportV11035.state == "METADATA_CLOSURE_NEEDS_SECONDARY_LOOKUP" -> "DATASET_FORAGING_LEAD_OBJECT_SECONDARY_LOOKUP"
            leadClosureHandoffReportV11035.active && metadataClosureReportV11035.state == "METADATA_CLOSURE_INCOMPLETE" -> "DATASET_FORAGING_MINIMUM_METADATA_CLOSURE"
            accessionAcquisitionReport.state == "FOUND_WEAK_ACCESSION_NEEDS_METADATA" -> "DATASET_FORAGING_WEAK_ACCESSION_NEEDS_METADATA"
            evidenceDiscoveryBreakthroughReportV11031.state == "WEAK_DATASET_LEAD_FOUND" -> "DATASET_FORAGING_WEAK_DATASET_LEAD_FOUND"
            evidenceDiscoveryBreakthroughReportV11031.state == "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION" -> "DATASET_FORAGING_NEAR_MISS_MANUAL_INSPECTION"
            evidenceDiscoveryBreakthroughReportV11031.state == "ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP" -> "DATASET_FORAGING_ACCESSION_TEXT_SECONDARY_LOOKUP"
            matureDomainEvidenceProbeReportV11026.active -> "DATASET_FORAGING_MATURE_DOMAIN_EVIDENCE_PROBE"
            accessionAcquisitionReport.state == "NO_ACCESSION_ARCHIVE_ROUTE" -> "DATASET_FORAGING_NO_ACCESSION_ARCHIVE_ROUTE"
            accessionAcquisitionReport.state == "NO_ACCESSION_CONTINUE_SOURCE_SWEEP" -> "DATASET_FORAGING_CONTINUE_SOURCE_SWEEP"
            terminalArchiveRequested -> "DATASET_FORAGING_ARCHIVE_OR_REFRAME"
            distinctCandidates.any { it.status == "EXPLORATORY_LEAD_NEEDS_ACCESSION" } -> "DATASET_FORAGING_EXPLORATORY_LEAD"
            distinctCandidates.isEmpty() -> "DATASET_FORAGING_NO_CANDIDATE"
            else -> "DATASET_FORAGING_CANDIDATE_INSPECTION"
        }
        val finalForagerNextAction = when {
            accessionAcquisitionReport.state == "FOUND_ACCESSION" -> accessionAcquisitionReport.nextAction
            leadClosureHandoffReportV11035.active -> leadClosureHandoffReportV11035.forcedNextAction
            accessionAcquisitionReport.state == "FOUND_WEAK_ACCESSION_NEEDS_METADATA" -> accessionAcquisitionReport.nextAction
            evidenceDiscoveryBreakthroughReportV11031.state in setOf("WEAK_DATASET_LEAD_FOUND", "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION", "ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP") -> evidenceDiscoveryBreakthroughReportV11031.nextAction
            matureDomainEvidenceProbeReportV11026.active -> matureDomainEvidenceProbeReportV11026.nextAction
            accessionAcquisitionReport.state == "NO_ACCESSION_ARCHIVE_ROUTE" -> accessionAcquisitionReport.nextAction
            accessionAcquisitionReport.state == "NO_ACCESSION_CONTINUE_SOURCE_SWEEP" -> accessionAcquisitionReport.nextAction
            terminalArchiveRequested -> "Archive or reframe this route: all bounded source-family attempts are in cooldown or exhausted without candidate-level evidence."
            distinctCandidates.any { it.status == "EXPLORATORY_LEAD_NEEDS_ACCESSION" } -> "Inspect exploratory unresolved leads for accession, full metadata, outcome labels, controls, and time order; do not upgrade hypotheses yet."
            distinctCandidates.isEmpty() -> {
                val rotation = if (nextNoCandidateSource.isNotBlank()) " Next source family: $nextNoCandidateSource because ${sourceFamilies.joinToString(", ").ifBlank { "the previous direct source" }} returned no candidate." else ""
                "Change evidence representation: search by outcome labels such as response/nonresponse, severity, recovery, and longitudinal labels before disease names.$rotation"
            }
            else -> "Inspect the highest-scoring dataset candidate for condition labels, outcome labels, sample size, and license before any hypothesis upgrade."
        }
        val guardedForagerDecisionV11031 = ReportConsistencyGuard.preventArchiveProbeConflict(
            foragerState = finalForagerState,
            foragerNextAction = finalForagerNextAction,
            nextProbeExists = manualEvidenceSeedReportV11031.active ||
                leadObjectsV11031.isNotEmpty() ||
                matureDomainEvidenceProbeReportV11026.active ||
                matureDomainFocusReportV11032.active ||
                knowledgeGapQueueReportV11032.items.isNotEmpty() ||
                leadClosureHandoffReportV11035.active ||
                ebvLeadVerificationReportV11037.active ||
                evidencePriorSelectionReportV11038.active ||
                evidenceDiscoveryBreakthroughReportV11031.state in setOf("WEAK_DATASET_LEAD_FOUND", "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION", "ACCESSION_TEXT_NEEDS_SECONDARY_LOOKUP")
        )
        val evidenceLeadPathLinkageReportV11031 = EvidenceLeadAndManualSeedPolicy.linkage(
            manualSeedReport = manualEvidenceSeedReportV11031,
            relaxationReport = datasetLeadRelaxationReportV11031,
            breakthroughReport = evidenceDiscoveryBreakthroughReportV11031,
            attempts = attempts,
            candidates = distinctCandidates,
            finalForagerState = finalForagerState,
            finalForagerNextAction = finalForagerNextAction,
            guardedForagerState = guardedForagerDecisionV11031.first,
            guardedForagerNextAction = guardedForagerDecisionV11031.second
        )
        val leanAgentRuntimeReportV11033 = LeanAgentRuntimePolicy.emit(
            leadObjects = leadObjectsV11031,
            focus = matureDomainFocusReportV11032,
            gaps = knowledgeGapQueueReportV11032,
            fingerprint = strongRouteFingerprintReportV11032,
            finalState = guardedForagerDecisionV11031.first,
            nextAction = guardedForagerDecisionV11031.second
        )
        val pathLinkageReportV11027 = DatasetForagingPathLinkageGuard.evaluate(
            attempts = attempts,
            accessionReport = accessionAcquisitionReport,
            matureProbeReport = matureDomainEvidenceProbeReportV11026,
            foragerState = guardedForagerDecisionV11031.first,
            foragerNextAction = guardedForagerDecisionV11031.second
        )
        val integratedPathLinkageReportV11039 = IntegratedPathLinkageGuard.evaluate(
            pathLinkage = pathLinkageReportV11027,
            learningDomain = LearningDomainPathLinkageReport.empty(),
            evidenceLead = evidenceLeadPathLinkageReportV11031,
            leadClosure = leadClosureHandoffReportV11035,
            metadataClosure = metadataClosureReportV11035,
            unknownRoute = unknownRouteClassificationReportV11035,
            ebv = ebvLeadVerificationReportV11037,
            evidencePrior = evidencePriorSelectionReportV11038,
            longevity = longevityBiologicalSystemsReportV11046
        )
        val onePageExecutiveEvidenceReportV11031 = EvidenceLeadAndManualSeedPolicy.executiveSummary(
            breakthrough = evidenceDiscoveryBreakthroughReportV11031,
            activity = evidenceActivitySeparationReportV11031,
            matureDomainUsed = matureDomainEvidenceProbeReportV11026.active,
            nextAction = guardedForagerDecisionV11031.second
        )
        return DatasetForagingRunResult(
            findings = findings.distinctBy { it.source + ":" + it.sourceId },
            report = DatasetForagingReport(
                active = true,
                state = guardedForagerDecisionV11031.first,
                evidenceMode = "DATASET_FIRST_MULTI_PASS",
                sourceFamiliesAttempted = sourceFamilies,
                hypothesisShards = shards,
                passes = listOfNotNull(pass1, pass2, pass3, pass4),
                candidates = distinctCandidates,
                parsedMetadata = parsedMetadata,
                contrastiveReport = contrastiveReport,
                evidenceHypergraph = evidenceHypergraph,
                cumulativeEvidence = cumulativeEvidence,
                noCandidateLearningRecords = noCandidateLearningRecords,
                creativeHypothesisForgeReport = creativeHypothesisForgeReport,
                expandedThinkingReport = creativeHypothesisForgeReport.expandedThinking,
                accessionAcquisitionReport = accessionAcquisitionReport,
                domainExpertiseReport = domainExpertiseReportV11020,
                matureDomainEvidenceProbeReport = matureDomainEvidenceProbeReportV11026,
                pathLinkageReport = pathLinkageReportV11027,
                manualEvidenceSeedReport = manualEvidenceSeedReportV11031,
                datasetLeadRelaxationReport = datasetLeadRelaxationReportV11031,
                evidenceDiscoveryBreakthroughReport = evidenceDiscoveryBreakthroughReportV11031,
                evidenceActivitySeparationReport = evidenceActivitySeparationReportV11031,
                onePageExecutiveEvidenceReport = onePageExecutiveEvidenceReportV11031,
                evidenceLeadPathLinkageReport = evidenceLeadPathLinkageReportV11031,
                leadObjects = leadObjectsV11031,
                leadClosureHandoffReport = leadClosureHandoffReportV11035,
                metadataClosureReport = metadataClosureReportV11035,
                unknownRouteClassificationReport = unknownRouteClassificationReportV11035,
                ebvLeadVerificationReport = ebvLeadVerificationReportV11037,
                evidencePriorSelectionReport = evidencePriorSelectionReportV11038,
                biomedicalOntologyReport = biomedicalOntologyReportV11041,
                biomedicalConceptBridgeReport = biomedicalConceptBridgeReportV11042,
                modernMedicalTechnologyReport = modernMedicalTechnologyReportV11043,
                viralCountermeasureReport = viralCountermeasureReportV11044,
                longevityBiologicalSystemsReport = longevityBiologicalSystemsReportV11046,
                biomedicalKnowledgeGraphLinkageReport = biomedicalKnowledgeGraphReportV11044,
                topicFitMetadataParseReport = topicFitMetadataParseForagerV11047,
                metadataClosureStrategyMatrixReport = metadataClosureStrategyMatrixReportV11056,
                mechanismDiscoveryDossierReport = mechanismDiscoveryDossierReportV1110,
                integratedPathLinkageReport = integratedPathLinkageReportV11039,
                matureDomainFocusReport = matureDomainFocusReportV11032,
                domainSpecificKillCriteriaReport = domainSpecificKillCriteriaReportV11032,
                domainExpertiseScoreUpgradeReport = domainExpertiseScoreUpgradeReportV11032,
                knowledgeGapQueueReport = knowledgeGapQueueReportV11032,
                strongRouteFingerprintReport = strongRouteFingerprintReportV11032,
                leanAgentRuntimeReport = leanAgentRuntimeReportV11033,
                blockedLearningReason = blockedReason,
                nextAction = guardedForagerDecisionV11031.second
            )
        )
    }


    private fun learnAndRank(
        findings: List<ResearchFinding>,
        importedSignals: List<ImportedReportSignal>,
        steering: ResearchSteeringProfile?,
        shouldStop: () -> Boolean,
        deadlineMillis: Long
    ): List<ResearchFinding> {
        if (shouldStop() || System.currentTimeMillis() >= deadlineMillis) return findings.take(20)
        val importedAxes = importedSignals.flatMap { it.matchedAxes }.toSet()
        val steeringAxes = steering?.inferredAxes?.toSet() ?: emptySet()
        val steeringTerms = (steering?.variables.orEmpty() + steering?.requiredTerms.orEmpty()).map { it.lowercase(Locale.US) }
        return findings
            .distinctBy { it.source + it.sourceId }
            .map { finding ->
                val overlapBoost = finding.matchedAxes.count { importedAxes.contains(it) } * 5
                val steeringAxisBoost = finding.matchedAxes.count { steeringAxes.contains(it) } * 6
                val text = (finding.title + " " + finding.bridgeSignal + " " + finding.whyItMatters).lowercase(Locale.US)
                val steeringTermBoost = steeringTerms.count { it.isNotBlank() && text.contains(it) } * 3
                val omicsBoost = if (finding.matchedAxes.any { it == "dna_genomic_axis" || it == "rna_transcriptomic_axis" }) 10 else 0
                val evidenceBoost = (finding.evidence.evidenceQualityScore - 50).coerceIn(-20, 25) / 2
                val causalBoost = (finding.causality.causalityScore - 45).coerceIn(-20, 25) / 2
                val controlPenalty = if (finding.negativeControl.status == "weak_no_control_possible") 4 else 0
                finding.copy(noveltyScore = (finding.noveltyScore + overlapBoost + steeringAxisBoost + steeringTermBoost + omicsBoost + evidenceBoost + causalBoost - controlPenalty).coerceIn(0, 100))
            }
            .sortedWith(compareByDescending<ResearchFinding> { it.noveltyScore }.thenByDescending { it.matchedAxes.size })
            .take(24)
    }


    private suspend fun searchNcbiIds(db: String, query: String, retMax: Int): List<String> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=$db&sort=relevance&retmode=json&retmax=$retMax&term=$encoded$ncbiCredentials"
        val text = httpGetWithRetry(url)
        val root = JSONObject(text)
        val arr = root.optJSONObject("esearchresult")?.optJSONArray("idlist") ?: return emptyList()
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    }

    private suspend fun fetchNcbiDatasetSummariesBatch(
        route: DirectDatasetSourceRouter.SourceRoute,
        ids: List<String>,
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger
    ): List<ResearchFinding> {
        if (ids.isEmpty()) return emptyList()
        val joined = ids.joinToString(",")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=${route.ncbiDb}&retmode=json&id=$joined$ncbiCredentials"
        val text = httpGetWithRetry(url)
        val root = JSONObject(text)
        val resultObj = root.optJSONObject("result") ?: return emptyList()
        return ids.mapNotNull { id ->
            val doc = resultObj.optJSONObject(id) ?: return@mapNotNull null
            buildFindingFromDatasetDoc(route, id, doc, query, personalLedger)
        }
    }

    private fun buildFindingFromDatasetDoc(
        route: DirectDatasetSourceRouter.SourceRoute,
        uid: String,
        doc: JSONObject,
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger
    ): ResearchFinding? {
        val docText = flattenJsonObject(doc).take(8000)
        val title = firstNonBlank(
            doc.optString("title"),
            doc.optString("exp_title"),
            doc.optString("study_title"),
            doc.optString("caption"),
            doc.optString("gds"),
            "Untitled dataset candidate"
        ).take(240)
        val accession = resolveDatasetAccessionFromDoc(route, uid, doc, docText, title)
        val datasetText = "$accession $title $docText"
        val queryRoute = RouteFitGate.inferDatasetRoute("${query.query} ${query.reason}")
        val datasetRoute = RouteFitGate.inferDatasetRoute(datasetText)
        val axes = matchAxes(datasetText)
        val evidence = SourceClassifier.classifySource(datasetText, listOf("Dataset", route.sourceFamily))
        val personal = personalLedger.assess(axes)
        val negativePreview = NegativeControlEngine.assess(axes, 0)
        val causality = CausalityScorer.score(datasetText, axes, evidence, personal, negativePreview.status)
        val negative = NegativeControlEngine.assess(axes, causality.causalityScore)
        val url = when {
            accession.startsWith("GSE") || accession.startsWith("GDS") || accession.startsWith("GSM") -> "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=$accession"
            accession.startsWith("PRJNA") -> "https://www.ncbi.nlm.nih.gov/bioproject/$accession"
            route.ncbiDb == "sra" -> "https://www.ncbi.nlm.nih.gov/sra/$uid"
            route.ncbiDb == "gds" -> "https://www.ncbi.nlm.nih.gov/gds/$uid"
            else -> "https://www.ncbi.nlm.nih.gov/${route.ncbiDb}/$uid"
        }
        val sourceName = when (route.sourceFamily) {
            "GEO_GDS" -> "NCBI_GEO_GDS"
            "SRA_PRJNA" -> "NCBI_SRA_PRJNA"
            else -> "NCBI_${route.sourceFamily}"
        }
        return ResearchFinding(
            source = sourceName,
            sourceId = accession,
            title = "$accession — $title".take(260),
            published = firstNonBlank(doc.optString("pdat"), doc.optString("pd"), doc.optString("created"), "dataset_metadata"),
            url = url,
            matchedAxes = axes,
            noveltyScore = (55 + axes.size * 8 + if (accession != uid) 12 else 0).coerceIn(0, 100),
            bridgeSignal = "Direct dataset-source candidate from ${route.sourceFamily}; dataset route $datasetRoute; target route $queryRoute; inspect metadata before hypothesis upgrade.",
            whyItMatters = "This source can break the PubMed-only loop by providing an accession/metadata object. Route-fit must be checked before using it for any hypothesis.",
            evidence = evidence,
            causality = causality,
            negativeControl = negative,
            personalPattern = personal,
            sanityFlags = listOf("DIRECT_DATASET_SOURCE", "METADATA_NEEDS_INSPECTION", "ROUTE_FIT_PENDING", "DATASET_ROUTE_$datasetRoute", "TARGET_ROUTE_$queryRoute").distinct()
        )
    }


    /**
     * v1.10.8 maintenance9: normalize direct NCBI dataset accessions.
     *
     * Entrez GDS/SRA esummary records often carry numeric UIDs plus accession-like
     * fields buried in metadata (study_acc, bioproject, experiment acc, run acc).
     * Returning a bare numeric UID as a dataset accession makes downstream parsing
     * look active while still producing weak/unresolved candidates. This method
     * extracts explicit accessions first, then applies a safe GDS UID fallback.
     */
    private fun resolveDatasetAccessionFromDoc(
        route: DirectDatasetSourceRouter.SourceRoute,
        uid: String,
        doc: JSONObject,
        docText: String,
        title: String
    ): String {
        val directFields = listOf(
            doc.optString("accession"),
            doc.optString("acc"),
            doc.optString("gds"),
            doc.optString("geo_accession"),
            doc.optString("bioproject"),
            doc.optString("bioproject_acc"),
            doc.optString("study_acc"),
            doc.optString("study"),
            doc.optString("exp_acc"),
            doc.optString("experiment"),
            doc.optString("run_acc"),
            doc.optString("run")
        ).joinToString(" ")
        val explicit = DatasetAccessionResolver.extract(
            text = "$directFields $docText $title",
            sourceFindingId = "NCBI_${route.sourceFamily}:$uid",
            sourceTitle = title,
            sourceUrl = ""
        ).firstOrNull { it.accession != "DATASET_ACCESSION_UNRESOLVED" }?.accession
        if (!explicit.isNullOrBlank()) return explicit

        return when {
            route.ncbiDb == "gds" && uid.all { it.isDigit() } -> "GDS$uid"
            route.ncbiDb == "sra" -> {
                // v1.10.8 final hardening: an Entrez SRA numeric UID is not itself a
                // biological dataset accession. Do not synthesize a fake SRA<uid>
                // accession because downstream gates count explicit-looking prefixes
                // as stronger evidence. Only explicit SRA/BioProject/study/run fields
                // may become accessions; otherwise keep the lead unresolved.
                val fieldAccession = firstNonBlank(
                    doc.optString("bioproject"),
                    doc.optString("bioproject_acc"),
                    doc.optString("study_acc"),
                    doc.optString("run_acc"),
                    doc.optString("acc"),
                    doc.optString("accession")
                )
                if (fieldAccession.isNotBlank()) fieldAccession else "DATASET_ACCESSION_UNRESOLVED"
            }
            else -> firstNonBlank(doc.optString("accession"), doc.optString("bioproject"), uid)
        }
    }

    private fun flattenJsonObject(obj: JSONObject): String {
        val out = mutableListOf<String>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = obj.opt(key)
            if (value != null && value != JSONObject.NULL) out += "$key=$value"
        }
        return out.joinToString(" ")
    }

    private fun firstNonBlank(vararg values: String): String {
        return values.firstOrNull { it.isNotBlank() } ?: ""
    }

    private suspend fun searchPubMed(query: String, retMax: Int): List<String> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&sort=pub+date&retmode=json&retmax=$retMax&term=$encoded$ncbiCredentials"
        val text = httpGetWithRetry(url)
        val root = JSONObject(text)
        val arr = root.optJSONObject("esearchresult")?.optJSONArray("idlist") ?: return emptyList()
        val ids = mutableListOf<String>()
        for (i in 0 until arr.length()) ids += arr.optString(i)
        return ids.filter { it.isNotBlank() }
    }

    /**
     * v0.9.1: Batched esummary. NCBI accepts up to 200 IDs in a single request.
     * v0.9.0 was issuing one request per pmid, which produced ~150 round-trips
     * per cycle and wasted ~2 minutes against NCBI's 3-req/sec ceiling.
     *
     * v1.0: Now also batch-fetches abstracts via efetch and uses them to
     * enrich evidence classification. Title-only classification is too
     * shallow for serious evidence triage; abstract text catches mechanism
     * keywords, study design, sample size hints, and limitations.
     */
    private suspend fun fetchPubMedSummariesBatch(
        pmids: List<String>,
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger,
        limits: ResearchRunLimits,
        seenAbstracts: Set<String> = emptySet()
    ): List<ResearchFinding> {
        if (pmids.isEmpty()) return emptyList()
        val joined = pmids.joinToString(",")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id=$joined$ncbiCredentials"
        val text = httpGetWithRetry(url)
        val root = JSONObject(text)
        val resultObj = root.optJSONObject("result") ?: return emptyList()
        // v1.3.3: metadata first, then selectively fetch top abstracts only.
        // This prevents 50–100MB cycles while still allowing the best candidates
        // to become mechanism/dataset leads.
        val firstPass = mutableListOf<ResearchFinding>()
        val docs = linkedMapOf<String, JSONObject>()
        for (pmid in pmids) {
            val doc = resultObj.optJSONObject(pmid) ?: continue
            docs[pmid] = doc
            val finding = buildFindingFromDoc(pmid, doc, query, personalLedger, "") ?: continue
            firstPass += finding
        }
        val abstracts = if (limits.fetchAbstracts || limits.enableSelectiveAbstracts) {
            val chosen = if (limits.fetchAbstracts) {
                firstPass.take(limits.maxAbstractsPerCycle).map { AbstractCandidateScore(it.sourceId, 100, listOf("forced abstract mode")) }
            } else {
                SelectiveAbstractFetcher.select(
                    firstPass,
                    alreadySeen = seenAbstracts,
                    threshold = limits.abstractEligibilityThreshold,
                    maxAbstracts = limits.maxAbstractsPerCycle
                )
            }
            if (chosen.isEmpty()) emptyMap() else try {
                fetchPubMedAbstractsBatch(chosen.map { it.pmid })
            } catch (_: Exception) {
                emptyMap()
            }
        } else {
            emptyMap()
        }
        if (abstracts.isEmpty()) return firstPass
        return firstPass.map { finding ->
            val abstractText = abstracts[finding.sourceId]
            if (abstractText.isNullOrBlank()) finding
            else buildFindingFromDoc(finding.sourceId, docs[finding.sourceId] ?: return@map finding, query, personalLedger, abstractText) ?: finding
        }
    }

    /**
     * v1.0: Fetch abstract text for up to 200 pmids in a single efetch call.
     * Returns map of pmid -> abstract text. Returns empty map on any failure
     * (caller falls back gracefully to title-only classification).
     *
     * Uses retmode=text with rettype=abstract, then parses by PMID markers.
     * This is intentionally tolerant: NCBI's text format has minor variations
     * across journals.
     */
    private suspend fun fetchPubMedAbstractsBatch(pmids: List<String>): Map<String, String> {
        if (pmids.isEmpty()) return emptyMap()
        val joined = pmids.joinToString(",")
        val url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&rettype=abstract&retmode=text&id=$joined$ncbiCredentials"
        val text = httpGetWithRetry(url)
        return parseAbstractText(text)
    }

    private suspend fun searchEuropePmcFindings(
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger,
        retMax: Int
    ): List<ResearchFinding> {
        if (!RuntimeFeatureFlags.ENABLE_EUROPE_PMC_LOOKUP_V265) return emptyList()
        val encoded = URLEncoder.encode(query.query, "UTF-8")
        val url = "https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=$encoded&format=json&pageSize=$retMax&resultType=core&sort=CITED"
        val text = httpGetExternal(url)
        val arr = JSONObject(text).optJSONObject("resultList")?.optJSONArray("result") ?: return emptyList()
        val out = mutableListOf<ResearchFinding>()
        for (i in 0 until arr.length()) {
            val doc = arr.optJSONObject(i) ?: continue
            val sourceId = firstNonBlank(doc.optString("pmid"), doc.optString("pmcid"), doc.optString("doi"), doc.optString("id"), "EPMC_$i")
            val title = firstNonBlank(doc.optString("title"), "Untitled Europe PMC result")
            val published = firstNonBlank(doc.optString("firstPublicationDate"), doc.optString("pubYear"), "unknown")
            val externalUrl = when {
                doc.optString("pmid").isNotBlank() -> "https://europepmc.org/article/MED/${doc.optString("pmid")}"
                doc.optString("pmcid").isNotBlank() -> "https://europepmc.org/article/PMC/${doc.optString("pmcid").removePrefix("PMC")}"
                else -> "https://europepmc.org/search?query=${URLEncoder.encode(sourceId, "UTF-8")}"
            }
            val abstractText = firstNonBlank(doc.optString("abstractText"), doc.optString("synopsis"))
            val digest = flattenJsonObject(doc).take(5000)
            buildFindingFromExternalText(
                sourceName = "Europe PMC",
                sourceId = sourceId,
                title = title,
                published = published,
                url = externalUrl,
                query = query,
                personalLedger = personalLedger,
                abstractText = "$abstractText $digest",
                flags = listOf("EUROPE_PMC_REST_LOOKUP", "DATA_AVAILABILITY_TEXT_MINING", "CLAIM_LIMIT_${GTIMClaimGuardV250.CLAIM_BOUNDARY}")
            )?.let { out += it }
        }
        return out.distinctBy { it.source + ":" + it.sourceId }.take(retMax)
    }

    private suspend fun searchOpenAlexFindings(
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger,
        retMax: Int
    ): List<ResearchFinding> {
        if (!RuntimeFeatureFlags.ENABLE_OPENALEX_LOOKUP_V265) return emptyList()
        val encoded = URLEncoder.encode(query.query, "UTF-8")
        val url = "https://api.openalex.org/works?search=$encoded&per-page=$retMax&sort=cited_by_count:desc&filter=has_abstract:true,type:article&select=id,doi,title,publication_date,publication_year,cited_by_count,abstract_inverted_index,open_access"
        val text = httpGetExternal(url)
        val arr = JSONObject(text).optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<ResearchFinding>()
        for (i in 0 until arr.length()) {
            val doc = arr.optJSONObject(i) ?: continue
            val sourceId = firstNonBlank(doc.optString("doi"), doc.optString("id"), "OPENALEX_$i").removePrefix("https://doi.org/")
            val title = firstNonBlank(doc.optString("title"), "Untitled OpenAlex work")
            val published = firstNonBlank(doc.optString("publication_date"), doc.optString("publication_year"), "unknown")
            val externalUrl = firstNonBlank(doc.optString("doi"), doc.optString("id"), "https://openalex.org")
            val abstractText = reconstructOpenAlexAbstract(doc.optJSONObject("abstract_inverted_index"))
            val digest = flattenJsonObject(doc).take(5000)
            buildFindingFromExternalText(
                sourceName = "OpenAlex",
                sourceId = sourceId,
                title = title,
                published = published,
                url = externalUrl,
                query = query,
                personalLedger = personalLedger,
                abstractText = "$abstractText $digest",
                flags = listOf("OPENALEX_WORKS_LOOKUP", "CROSS_INDEX_METADATA", "CLAIM_LIMIT_${GTIMClaimGuardV250.CLAIM_BOUNDARY}")
            )?.let { out += it }
        }
        return out.distinctBy { it.source + ":" + it.sourceId }.take(retMax)
    }

    private fun reconstructOpenAlexAbstract(index: JSONObject?): String {
        if (index == null) return ""
        val words = mutableListOf<Pair<Int, String>>()
        val keys = index.keys()
        while (keys.hasNext()) {
            val word = keys.next()
            val positions = index.optJSONArray(word) ?: continue
            for (i in 0 until positions.length()) {
                val position = positions.optInt(i, -1)
                if (position >= 0) words += position to word
            }
        }
        return words.sortedBy { it.first }.joinToString(" ") { it.second }.take(4096)
    }

    private fun buildFindingFromExternalText(
        sourceName: String,
        sourceId: String,
        title: String,
        published: String,
        url: String,
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger,
        abstractText: String,
        flags: List<String>
    ): ResearchFinding? {
        val evidenceText = "$title ${query.query} ${query.reason} $abstractText"
        val axes = matchAxes(evidenceText)
        var evidence = SourceClassifier.classifySource(evidenceText, listOf(sourceName, "Public metadata", "Data availability"))
        val sanityFlags = mutableListOf<String>()
        sanityFlags += flags
        sanityFlags += AccessionTextHarvestPolicy.flags(evidenceText)
        sanityFlags += "EXTERNAL_PUBLIC_METADATA_ONLY_UNTIL_ACCESSION_RESOLVED"
        if (abstractText.isBlank()) sanityFlags += "ABSTRACT_FETCH_FAILED"
        if (evidence.speciesClass == "unknown") {
            sanityFlags += "METADATA_ONLY"
            if (evidence.evidenceQualityScore > 45) evidence = evidence.copy(evidenceQualityScore = 45)
        }
        val personal = personalLedger.assess(axes)
        val negativePreview = NegativeControlEngine.assess(axes, 0)
        val causality = CausalityScorer.score(evidenceText, axes, evidence, personal, negativePreview.status)
        val negative = NegativeControlEngine.assess(axes, causality.causalityScore)
        return ResearchFinding(
            source = sourceName,
            sourceId = sourceId,
            title = title.take(260),
            published = published,
            url = url,
            matchedAxes = axes,
            noveltyScore = scoreNovelty(axes, title, query),
            bridgeSignal = "External public-source metadata lead from $sourceName; treat as lookup path, not evidence, until accession/comparator/matrix gates close.",
            whyItMatters = "This can break the no-public-data-channel loop by surfacing PMID/DOI/PMCID/accession-bearing data-availability text for secondary repository resolution.",
            evidence = evidence,
            causality = causality,
            negativeControl = negative,
            personalPattern = personal,
            sanityFlags = sanityFlags.distinct(),
            evidenceTextDigest = AccessionTextHarvestPolicy.digest(evidenceText)
        )
    }

    /**
     * Parse PubMed efetch abstract text into pmid -> body map.
     *
     * Format example per record:
     *   N. Citation. Year;Vol(Iss):Pages.
     *
     *   Title
     *
     *   Authors
     *
     *   Affiliation
     *
     *   Abstract paragraph...
     *
     *   DOI: 10.xxxx/...
     *   PMID: 12345678 [Indexed for MEDLINE]
     *
     * Records are separated by blank lines. We split on lines that start
     * with a record number "1.", "2.", ... and look for the trailing PMID.
     */
    internal fun parseAbstractText(text: String): Map<String, String> {
        if (text.isBlank()) return emptyMap()
        val out = mutableMapOf<String, String>()
        val pmidPattern = Regex("""PMID:\s*(\d+)""")
        // Records start with a line like "1. " or "2. " at the beginning of a line
        // (after a blank line). Use a lookahead split.
        val records = text.split(Regex("(?=\\r?\\n\\d+:?\\s*[A-Z])"))
        for (record in records) {
            val match = pmidPattern.find(record) ?: continue
            val pmid = match.groupValues[1]
            // Cap each abstract at 4 KB so a single junk record can't blow up memory
            val body = record.trim().take(4096)
            if (body.isNotBlank()) out[pmid] = body
        }
        // Fallback: if the regex split produced one big blob (some journals
        // don't use numbered records), do a per-PMID linear scan.
        if (out.isEmpty()) {
            val matches = pmidPattern.findAll(text).toList()
            for ((idx, m) in matches.withIndex()) {
                val pmid = m.groupValues[1]
                val start = if (idx == 0) 0 else matches[idx - 1].range.last + 1
                val end = m.range.last + 1
                val body = text.substring(start, end).trim().take(4096)
                if (body.isNotBlank()) out[pmid] = body
            }
        }
        return out
    }

    private fun buildFindingFromDoc(
        pmid: String,
        doc: JSONObject,
        query: ResearchQuery,
        personalLedger: PersonalPatternLedger,
        abstractText: String = ""
    ): ResearchFinding? {
        val title = doc.optString("title", "Untitled")
        val published = doc.optString("pubdate", "unknown")
        val pubTypeArray = doc.optJSONArray("pubtype")
        val pubTypes = if (pubTypeArray == null) emptyList() else (0 until pubTypeArray.length()).map { pubTypeArray.optString(it) }.filter { it.isNotBlank() }
        // v1.0: include abstract text in evidenceText so SourceClassifier and
        // CausalityScorer can use mechanism/study-design/temporal cues that
        // titles often hide.
        val hasUsableAbstract = abstractText.isNotBlank() && abstractText != "ABSTRACT_FETCH_FAILED"
        val abstractWasTruncated = abstractText.length >= 4096
        val evidenceText = title + " " + query.query + " " + query.reason + " " + pubTypes.joinToString(" ") + if (hasUsableAbstract) " " + abstractText else ""
        val evidenceTextDigestV11024 = AccessionTextHarvestPolicy.digest(evidenceText)
        val axes = matchAxes(evidenceText)
        var evidence = SourceClassifier.classifySource(evidenceText, pubTypes)
        // v1.1: statistical sanity gates promised in CANONICAL_SCORING_FORMULA_v0.9.1.md.
        val sanityFlags = mutableListOf<String>()
        if (!hasUsableAbstract) sanityFlags += "ABSTRACT_FETCH_FAILED"
        if (abstractWasTruncated) sanityFlags += "ABSTRACT_TRUNCATED"
        sanityFlags += AccessionTextHarvestPolicy.flags(evidenceText)
        sanityFlags += "SCORE_CALIBRATION_UNCALIBRATED_HEURISTIC"
        if (evidence.speciesClass == "unknown" && !hasUsableAbstract) {
            sanityFlags += "METADATA_ONLY"
            // Cap evidence quality at 45 to prevent metadata-only sources from
            // ranking with full-text-evidence sources.
            if (evidence.evidenceQualityScore > 45) {
                evidence = evidence.copy(evidenceQualityScore = 45)
            }
        }
        val personal = personalLedger.assess(axes)
        if (personal.repeatedObservationCount in 1..2) {
            sanityFlags += "LOW_POWER"
        }
        val negativePreview = NegativeControlEngine.assess(axes, 0)
        val causality = CausalityScorer.score(evidenceText, axes, evidence, personal, negativePreview.status)
        val negative = NegativeControlEngine.assess(axes, causality.causalityScore)
        val score = scoreNovelty(axes, title, query)
        return ResearchFinding(
            source = "PubMed",
            sourceId = pmid,
            title = title,
            published = published,
            url = "https://pubmed.ncbi.nlm.nih.gov/$pmid/",
            matchedAxes = axes,
            noveltyScore = score,
            bridgeSignal = bridgeSignal(axes),
            whyItMatters = whyItMatters(axes, query),
            evidence = evidence,
            causality = causality,
            negativeControl = negative,
            personalPattern = personal,
            sanityFlags = sanityFlags.distinct(),
            evidenceTextDigest = evidenceTextDigestV11024
        )
    }

    private suspend fun fetchPubMedSummary(pmid: String, query: ResearchQuery, personalLedger: PersonalPatternLedger): ResearchFinding? {
        // Kept for backward compatibility with any single-id callers.
        return fetchPubMedSummariesBatch(listOf(pmid), query, personalLedger, ResearchRunLimits(enableSelectiveAbstracts = false), emptySet()).firstOrNull()
    }

    private fun matchAxes(text: String): List<String> {
        // v1.1: delegate to the single-source-of-truth AxisMatcher to prevent
        // drift between this method and ResearchKnowledgeStore.inferAxes.
        return AxisMatcher.match(text)
    }

    private fun scoreNovelty(axes: List<String>, title: String, query: ResearchQuery): Int {
        var score = min(95, 20 + axes.size * 12)
        if (axes.contains("psychoneuroimmune_axis") && axes.contains("type2_allergy_axis")) score += 12
        if (axes.contains("psychoneuroimmune_axis") && axes.contains("tnf_il6_autoimmune_axis")) score += 10
        if (axes.contains("psychomusculoskeletal_axis") && axes.contains("psychoneuroimmune_axis")) score += 10
        if (axes.contains("regulatory_brake_axis") && axes.contains("hyperinflammatory_axis")) score += 10
        if (axes.contains("aging_immune_axis") && axes.contains("type2_allergy_axis")) score += 14
        if (axes.contains("autonomic_vascular_axis") && axes.contains("type2_allergy_axis")) score += 12
        if (axes.contains("autonomic_vascular_axis") && axes.contains("psychoneuroimmune_axis")) score += 8
        if (axes.contains("dna_genomic_axis") && axes.contains("aging_immune_axis")) score += 14
        if (axes.contains("gastric_acid_gut_axis") && axes.contains("type2_allergy_axis")) score += 16
        if (axes.contains("gut_barrier_microbiome_axis") && axes.contains("type2_allergy_axis")) score += 15
        if (axes.contains("nutrition_protein_axis") && axes.contains("muscle_mass_reserve_axis")) score += 12
        if (axes.contains("testosterone_immune_axis") && (axes.contains("tnf_il6_autoimmune_axis") || axes.contains("type2_allergy_axis"))) score += 14
        if (axes.contains("rna_transcriptomic_axis") && axes.contains("type2_allergy_axis")) score += 14
        if (axes.contains("rna_transcriptomic_axis") && axes.contains("tnf_il6_autoimmune_axis")) score += 12
        if (axes.contains("dna_genomic_axis") && axes.contains("type2_allergy_axis")) score += 10
        if (title.lowercase(Locale.US).contains("review")) score -= 5
        if (query.id.contains("cross") || query.id.contains("dna") || query.id.contains("rna") || query.id.contains("mirna")) score += 8
        return score.coerceIn(0, 100)
    }

    private fun bridgeSignal(axes: List<String>): String {
        val joined = axes.joinToString(" + ")
        return when {
            axes.size >= 3 -> "Cross-axis bridge candidate: $joined"
            axes.size == 2 -> "Two-axis bridge candidate: $joined"
            axes.size == 1 -> "Single-axis evidence: ${axes.first()}"
            else -> "Weak match; keep only as background lead"
        }
    }

    private fun whyItMatters(axes: List<String>, query: ResearchQuery): String {
        return when {
            axes.contains("gastric_acid_gut_axis") && axes.contains("type2_allergy_axis") -> "May connect stomach-acid/reflux/acid-suppression context with allergy through gut-barrier, microbiome, or airway reflux pathways."
            axes.contains("gut_barrier_microbiome_axis") && axes.contains("type2_allergy_axis") -> "May connect gut microbiome/barrier state with allergic or airway immune reactivity."
            axes.contains("nutrition_protein_axis") && axes.contains("muscle_mass_reserve_axis") -> "May connect protein/diet adequacy and muscle reserve with immune recovery and aging resilience."
            axes.contains("testosterone_immune_axis") -> "May test whether androgen/testosterone context modulates immune tone, inflammatory balance, muscle reserve, or recovery."
            axes.contains("dna_genomic_axis") && axes.contains("aging_immune_axis") -> "May connect DNA/epigenetic aging signals with immune responsiveness or inflammaging."
            axes.contains("rna_transcriptomic_axis") && axes.contains("type2_allergy_axis") -> "May reveal RNA expression patterns behind allergy reactivity beyond serum markers."
            axes.contains("rna_transcriptomic_axis") && axes.contains("tnf_il6_autoimmune_axis") -> "May help compare transcriptomic inflammatory states across RA-like and other immune axes."
            axes.contains("psychoneuroimmune_axis") && axes.contains("type2_allergy_axis") -> "May help test whether stress/sleep shifts airway or allergy reactivity rather than merely coinciding with symptoms."
            axes.contains("psychoneuroimmune_axis") && axes.contains("tnf_il6_autoimmune_axis") -> "May connect chronic stress/recovery debt with inflammatory-axis amplification in autoimmune-like patterns."
            axes.contains("psychomusculoskeletal_axis") && axes.contains("psychoneuroimmune_axis") -> "May explain pain persistence through stress, sleep, guarding, and sensitization without claiming structural causation."
            axes.contains("aging_immune_axis") && axes.contains("type2_allergy_axis") -> "May test whether allergic reactivity is preserved responsiveness in one context or inflammaging burden in another."
            axes.contains("autonomic_vascular_axis") && axes.contains("type2_allergy_axis") -> "May connect allergy/histamine-like episodes to blood-pressure instability or vasodilation patterns."
            axes.contains("regulatory_brake_axis") -> "May reveal a brake-failure mechanism shared across mild and severe over-response states."
            else -> "Relevant to query: ${query.label}. Needs full-text review and comparison against local case vectors."
        }
    }

    private fun buildEmergentLinks(findings: List<ResearchFinding>, importedSignals: List<ImportedReportSignal>, steering: ResearchSteeringProfile?): List<String> {
        val links = mutableListOf<String>()
        if (steering != null && steering.variables.isNotEmpty()) {
            links += "Steered research active: ${steering.variables.take(6).joinToString(" ↔ ")}. Treat links as hypotheses until repeated temporal/data evidence appears."
        }
        if (findings.any { it.matchedAxes.contains("interferon_antiviral_axis") && it.matchedAxes.contains("resolution_recovery_axis") }) links += "Global antiviral bridge: interferon timing plus recovery/resolution labels should be prioritized before any variant-resilience hypothesis."
        if (findings.any { it.matchedAxes.contains("interferon_antiviral_axis") && it.matchedAxes.contains("tissue_damage_axis") }) links += "Protection-vs-damage split detected: separate pathogen-control signals from tissue-injury signals."
        if (findings.any { it.matchedAxes.contains("tcell_activation_axis") || it.matchedAxes.contains("bcell_antibody_axis") }) links += "Adaptive immune response detected: model T-cell/B-cell memory separately from acute cytokine intensity."
        if (findings.any { it.matchedAxes.contains("psychoneuroimmune_axis") && it.matchedAxes.contains("type2_allergy_axis") }) links += "Stress/sleep may be treated as an amplifier axis for Type-2 airway/allergy signals, not as a standalone cause."
        if (findings.any { it.matchedAxes.contains("psychomusculoskeletal_axis") && it.matchedAxes.contains("psychoneuroimmune_axis") }) links += "Back/disc-like patterns should track mechanical load + sleep + fear/tension loops as a recovery-failure model."
        if (findings.any { it.matchedAxes.contains("regulatory_brake_axis") && it.matchedAxes.contains("hyperinflammatory_axis") }) links += "Regulatory-brake failure remains a bridge candidate from mild immune misfires to systemic runaway amplification."
        if (findings.any { it.matchedAxes.contains("aging_immune_axis") && it.matchedAxes.contains("type2_allergy_axis") }) links += "Allergy-aging link should be modeled as nonlinear: preserved responsiveness vs chronic inflammaging burden."
        if (findings.any { it.matchedAxes.contains("autonomic_vascular_axis") && it.matchedAxes.contains("type2_allergy_axis") }) links += "Autonomic-mast-cell vascular bridge candidate: stress pressure-up may compete with histamine pressure-down."
        if (findings.any { it.matchedAxes.contains("dna_genomic_axis") && it.matchedAxes.contains("aging_immune_axis") }) links += "DNA/epigenetic aging markers may be useful as a bridge between immune responsiveness and inflammaging load."
        if (findings.any { it.matchedAxes.contains("gastric_acid_gut_axis") && it.matchedAxes.contains("type2_allergy_axis") }) links += "Gut-acid/reflux/acid-suppression context should be tracked against allergy intensity, airway symptoms, and microbiome/gut-barrier findings."
        if (findings.any { it.matchedAxes.contains("testosterone_immune_axis") }) links += "Testosterone/androgen context should be modeled as immune-modulation and recovery/muscle-reserve hypothesis, not endocrine diagnosis."
        if (findings.any { it.matchedAxes.contains("rna_transcriptomic_axis") && (it.matchedAxes.contains("type2_allergy_axis") || it.matchedAxes.contains("tnf_il6_autoimmune_axis")) }) links += "RNA/transcriptomic signatures may expose hidden immune states that routine blood biomarkers miss."
        if (importedSignals.any { it.matchedAxes.contains("dna_genomic_axis") || it.matchedAxes.contains("rna_transcriptomic_axis") }) links += "Manual imported reports introduced DNA/RNA context; prioritize source-quality review before treating it as a confirmed mechanism."
        if (links.isEmpty()) links += "No strong new cross-axis bridge found in this cycle; broaden queries or inspect full texts manually."
        return links.distinct()
    }

    private fun buildNextQuestions(findings: List<ResearchFinding>, importedSignals: List<ImportedReportSignal>, steering: ResearchSteeringProfile?, autonomousPlan: AutonomousResearchPlan): List<String> {
        val questions = mutableListOf<String>()
        if (steering != null && steering.variables.isNotEmpty()) {
            questions += "For the steered variables (${steering.variables.take(6).joinToString(", ")}), what temporal order would falsify the assumed relationship?"
            questions += "Which steered variable is likely a trigger, amplifier, maintainer, marker, or coincidence?"
        }
        val nextLaneLabel = autonomousPlan.lanes.firstOrNull()?.label ?: "global trigger-response dataset discovery"
        questions += "Which autonomous lane should be deepened next: $nextLaneLabel?"
        questions += "Which public dataset has trigger, immune-response axis, and outcome labels rather than markers alone?"
        questions += "Does adding stress/sleep context improve separation beyond biomarkers alone?"
        questions += "Which axis changes first: Type-2, interferon antiviral, TNF/IL-6, regulatory brake, DNA/RNA expression, or tissue-damage context?"
        questions += "Does high allergy reactivity pair with low inflammaging and fast recovery, or with chronic inflammatory burden?"
        questions += "During stress/allergy episodes, does BP/pulse move upward, downward, or become unstable?"
        if (findings.any { it.matchedAxes.contains("dna_genomic_axis") }) questions += "Which DNA/epigenetic signals are repeated across allergy, aging, and inflammatory datasets?"
        if (findings.any { it.matchedAxes.contains("gastric_acid_gut_axis") }) questions += "Do reflux, low-acid suspicion, PPI/antacid context, or gastritis/H. pylori history cluster before allergy or airway flares?"
        if (findings.any { it.matchedAxes.contains("nutrition_protein_axis") || it.matchedAxes.contains("muscle_mass_reserve_axis") }) questions += "Does protein/diet diversity and muscle reserve predict faster recovery or lower inflammatory load?"
        if (findings.any { it.matchedAxes.contains("testosterone_immune_axis") }) questions += "Does testosterone/androgen context modify allergy, inflammatory tone, muscle reserve, or fatigue recovery in repeated observations?"
        if (findings.any { it.matchedAxes.contains("interferon_antiviral_axis") }) questions += "Do early interferon signatures separate recovery from hyperinflammatory deterioration across viral datasets?"
        if (findings.any { it.matchedAxes.contains("tissue_damage_axis") }) questions += "Which markers separate immune protection from host tissue damage?"
        if (findings.any { it.matchedAxes.contains("rna_transcriptomic_axis") }) questions += "Which RNA/transcriptomic genes recur across allergy, RA-like inflammation, antiviral response, and hyperinflammatory literature?"
        if (importedSignals.isNotEmpty()) questions += "Do imported personal reports support the same axis pairs as public sources, or do they contradict them?"
        if (findings.any { it.noveltyScore >= 70 }) questions += "Manually review high-novelty papers and add confirmed mechanisms to axis/rule JSON files."
        if (findings.any { it.evidence.speciesClass != "human" }) questions += "Which leads are human evidence vs animal/cell-only? Do not merge them in the same confidence bucket."
        if (findings.any { it.negativeControl.status.contains("control") }) questions += "Which top hypothesis survives reverse-time, shuffled-timeline, and unrelated-marker negative controls?"
        return questions.distinct()
    }

    private fun computeNewAxisPairs(findings: List<ResearchFinding>, seenPairs: Set<String>): List<String> {
        return findings.flatMap { finding ->
            val axes = finding.matchedAxes.sorted()
            axes.flatMapIndexed { idx, a -> axes.drop(idx + 1).map { b -> "$a + $b" } }
        }.distinct().filterNot { seenPairs.contains(it) }.take(20)
    }

    private fun buildLearningNotes(
        findings: List<ResearchFinding>,
        importedSignals: List<ImportedReportSignal>,
        newAxisPairs: List<String>,
        stopReason: String,
        steering: ResearchSteeringProfile?,
        autonomousPlan: AutonomousResearchPlan,
        stagnationPlan: AutonomousStagnationEngine.StagnationPlan? = null,
        runtimeStatus: ActiveResearchEngineStatus,
        executionLockReport: ExecutionLockReport,
        learningValueModeActiveV11033: Boolean
    ): List<String> {
        val notes = mutableListOf<String>()
        val executedCount = runtimeStatus.executedQueryIds.size
        val executionLine = if (executedCount == 0) {
            "Search executed: 0; planned budget ${runtimeStatus.effectiveMaxQueries} x ${runtimeStatus.effectiveResultsPerQuery}; status NOT_EXECUTED_OR_BLOCKED."
        } else {
            "Search executed: $executedCount query path(s); planned budget ${runtimeStatus.effectiveMaxQueries} x ${runtimeStatus.effectiveResultsPerQuery}."
        }
        notes += "Search stop reason: $stopReason. Active engine ${runtimeStatus.engineVersion}; state ${runtimeStatus.researchState}; $executionLine"
        notes += "Execution lock: ${executionLockReport.status}; ${executionLockReport.enforcedActions.joinToString("; ")}."
        notes += "Autonomous researcher mode: the engine chooses Explore + Deepen + Challenge lanes by itself; research steering is optional acceleration."
        notes += "New source policy: previously stored PubMed IDs are skipped. If many sources are skipped, the next cycle rotates strategy instead of requiring user guidance."
        if (stagnationPlan != null && stagnationPlan.active) {
            notes += "v1.3.6 anti-stagnation active: applied previous pivot ${stagnationPlan.pendingPivot.pivotType}; effective queries ${stagnationPlan.effectiveMaxQueries}; PubMed retmax ${stagnationPlan.effectiveResultsPerQuery}."
            notes += "Anti-stagnation reason: ${stagnationPlan.reason}"
        }
        notes += "Autonomous plan: ${autonomousPlan.strategy}; next fallback: ${autonomousPlan.nextStrategyIfNoUsefulSource}"
        notes += "v1.2 lock policy: only findings that change a hypothesis rank, gate, state, next measurement, or bias warning enter the main report."
        notes += "v1.3 global policy: prioritize public datasets, immune-axis mapping, and trigger-response-outcome structure before any ML model."
        if (steering != null && steering.variables.isNotEmpty()) notes += "Research steering active: ${steering.variables.take(8).joinToString(", ")}; generated directed variable-bridge queries without changing code."
        ImmuneLearningValueModePolicy.learningNote(learningValueModeActiveV11033)?.let { notes += it }
        if (newAxisPairs.isNotEmpty()) notes += "New axis pairs found: ${newAxisPairs.take(5).joinToString("; ")}."
        if (findings.any { it.matchedAxes.contains("dna_genomic_axis") }) notes += "DNA/genomic axis appeared; separate epigenetic-aging from inherited-variant evidence."
        if (findings.any { it.matchedAxes.contains("gastric_acid_gut_axis") }) notes += "Gut-acid axis appeared; separate reflux/GERD, low-acid suspicion, acid suppression, gastritis/H. pylori, and microbiome mechanisms."
        if (findings.any { it.matchedAxes.contains("testosterone_immune_axis") }) notes += "Testosterone axis appeared; treat as hormone-immune modulation hypothesis, not diagnosis or replacement advice."
        if (findings.any { it.matchedAxes.contains("interferon_antiviral_axis") }) notes += "Interferon/antiviral axis appeared; separate early pathogen-control from late inflammatory damage."
        if (findings.any { it.matchedAxes.contains("tcell_activation_axis") || it.matchedAxes.contains("bcell_antibody_axis") }) notes += "Adaptive antiviral axis appeared; track T-cell/B-cell evidence separately from cytokine intensity."
        if (findings.any { it.matchedAxes.contains("rna_transcriptomic_axis") }) notes += "RNA/transcriptomic axis appeared; prioritize expression signatures over single-marker assumptions."
        if (importedSignals.isNotEmpty()) notes += "Manual reports used: ${importedSignals.size}; treat them as private leads until source quality is checked."
        if (findings.isEmpty()) notes += "No useful new source found; the autonomous planner will rotate toward dataset, omics, or contradiction search in the next cycle."
        return notes.distinct()
    }

    /**
     * v0.9.1: NCBI compliance & resilience.
     *
     * - Adds tool=&email= as required by NCBI E-utilities policy
     *   (https://www.ncbi.nlm.nih.gov/books/NBK25497/).
     * - Adds optional encrypted api_key storage via SecureNcbiCredentialStore
     *   (raises rate limit from 3/sec to 10/sec).
     * - Uses OkHttp with centralized headers, rate limiting, typed HTTP errors,
     *   and coroutine-aware retry backoff.
     */
    private val ncbiContactEmail: String by lazy {
        SecureNcbiCredentialStore.readContactEmail(context).ifBlank { "research@vraimony.com" }
    }

    private val ncbiApiKey: String? by lazy {
        SecureNcbiCredentialStore.readApiKey(context)
    }

    private val ncbiCredentials: String by lazy {
        val email = URLEncoder.encode(ncbiContactEmail, "UTF-8")
        val tool = URLEncoder.encode("ImmuneErrorRadarPrivateResearch", "UTF-8")
        val keyParam = ncbiApiKey?.takeIf { it.isNotBlank() }?.let { "&api_key=${URLEncoder.encode(it, "UTF-8")}" } ?: ""
        "&tool=$tool&email=$email$keyParam"
    }

    private val ncbiClient: NcbiClient by lazy {
        NcbiClient(contactEmail = ncbiContactEmail, apiKey = ncbiApiKey)
    }

    private val externalHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .callTimeout(30, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("User-Agent", "ImmuneErrorRadar/${EngineRuntimeStatus.ACTIVE_ENGINE_VERSION} (PublicLookup; no-tracking)")
                    .header("Accept", "application/json,text/plain;q=0.9,*/*;q=0.1")
                    .build()
                chain.proceed(request)
            }
            .build()
    }

    private suspend fun httpGetWithRetry(urlText: String, attempts: Int = 3): String {
        return ncbiClient.getWithRetry(urlText, attempts)
    }

    private suspend fun httpGetExternal(urlText: String, attempts: Int = 2): String {
        var lastError: Exception? = null
        var backoffMillis = 250L
        repeat(attempts.coerceAtLeast(1)) { attemptIndex ->
            try {
                return withContext(Dispatchers.IO) {
                    val request = Request.Builder().url(urlText).get().build()
                    externalHttpClient.newCall(request).execute().use { response ->
                        val body = response.body?.string().orEmpty()
                        if (!response.isSuccessful) {
                            throw IOException("External HTTP ${response.code} for ${request.url.host}; body=${body.take(180)}")
                        }
                        body
                    }
                }
            } catch (error: Exception) {
                lastError = error
                if (attemptIndex < attempts - 1) {
                    delay(backoffMillis)
                    backoffMillis = (backoffMillis * 2).coerceAtMost(1200L)
                }
            }
        }
        throw lastError ?: IOException("External request failed without captured error")
    }

}
