package com.immunesignal.app

object TriggerTimeline {
    fun compactSummary(input: CaseInput): String {
        val c = input.causeContext
        val items = mutableListOf<String>()
        if (c.pollenDustExposure) items += "pollen/dust"
        if (c.coldAirExposure) items += "cold air"
        if (c.smokeFragranceExposure) items += "smoke/fragrance"
        if (c.moldOrPetsExposure) items += "mold/pets"
        if (c.recentInfectionLike) items += "recent infection-like episode"
        if (c.majorEmotionalEvent) items += "major emotional event"
        if (c.heavyLifting) items += "heavy lifting"
        if (c.suddenTwist) items += "sudden twist"
        return if (items.isEmpty()) "No trigger timeline clues entered." else "Entered trigger clues: ${items.joinToString(", ")}."
    }
}
