package com.immunesignal.app

import java.util.Locale

/**
 * v2.7.3.7 safety/integrity guard.
 * Rejects user or prompt text that tries to close evidence/matrix/contradiction gates by command.
 * It never blocks research routing; it rewrites the request into exploratory route review only.
 */
data class GTIMForcedClosureGuardReportV2737(
    val active: Boolean,
    val version: String,
    val state: String,
    val detectedPatterns: List<String>,
    val blockedActions: List<String>,
    val safeCommand: String,
    val rewrittenMode: String,
    val requiredChecks: List<String>,
    val safeStructuredIntakeHint: String,
    val claimLimit: String = GTIMForcedClosureCommandGuardV2737.CLAIM_LIMIT
) {
    companion object {
        fun inactive() = GTIMForcedClosureGuardReportV2737(
            active = false,
            version = GTIMForcedClosureCommandGuardV2737.VERSION,
            state = "NO_FORCED_CLOSURE_PATTERN_DETECTED",
            detectedPatterns = emptyList(),
            blockedActions = emptyList(),
            safeCommand = "OPEN_EXPLORATORY_ROUTE_REVIEW",
            rewrittenMode = "normal_open_discovery",
            requiredChecks = GTIMForcedClosureCommandGuardV2737.REQUIRED_CHECKS,
            safeStructuredIntakeHint = "No forced closure rewrite needed."
        )
    }
}

object GTIMForcedClosureCommandGuardV2737 {
    const val VERSION: String = "2.7.3.7-forced-closure-safety-guard"
    const val STATE: String = "FORCED_CLOSURE_REJECTED_EXPLORATORY_ROUTE_REVIEW_ONLY"
    const val CLAIM_LIMIT: String = "research_route_review_only_no_forced_gate_closure_no_evidence_upgrade"

    private val riskyPatterns: List<Pair<String, Regex>> = listOf(
        "FORCE_INTEGRATION_CLOSURE" to Regex("force[_\\s-]*integration[_\\s-]*closure", RegexOption.IGNORE_CASE),
        "hyperDriveModeActive" to Regex("hyper[_\\s-]*drive[_\\s-]*mode[_\\s-]*active", RegexOption.IGNORE_CASE),
        "override_off_route_block" to Regex("override[_\\s-]*off[_\\s-]*route[_\\s-]*block", RegexOption.IGNORE_CASE),
        "force_gate_closure" to Regex("force[_\\s-]*gate[_\\s-]*closure", RegexOption.IGNORE_CASE),
        "matrix=READY" to Regex("matrix\\s*[:=]\\s*READY", RegexOption.IGNORE_CASE),
        "gate closure command" to Regex("(close|unlock|bypass)\\s+(the\\s+)?(matrix|contradiction|metadata|evidence)\\s+gate", RegexOption.IGNORE_CASE),
        "prove causality" to Regex("prove[n]?\\s+(causality|causal|mechanism)", RegexOption.IGNORE_CASE),
        "statistically proven" to Regex("statistically\\s+proven|global(ly)?\\s+validated|worldwide\\s+validated", RegexOption.IGNORE_CASE),
        "final wet-lab protocol claim" to Regex("wet[-\\s]*lab\\s+protocol\\s+(final|proven|validated|ready)", RegexOption.IGNORE_CASE),
        "strong proof by command" to Regex("(solid|hard|confirmed)\\s+(molecular\\s+)?(discovery|proof|evidence)\\s+by\\s+command", RegexOption.IGNORE_CASE)
    )

    val REQUIRED_CHECKS: List<String> = listOf(
        "verify_dataset_route",
        "verify_case_control_labels",
        "verify_assay_type",
        "verify_organism",
        "verify_tissue_or_cell_source",
        "run_contradiction_search",
        "run_off_route_check",
        "report_missing_metadata"
    )

    val BLOCKED_ACTIONS: List<String> = listOf(
        "forced matrix readiness",
        "forced contradiction closure",
        "forced evidence upgrade",
        "override of off-route dataset block",
        "causality/proof claim from prompt text",
        "final wet-lab validation claim without data"
    )

    fun evaluate(text: String): GTIMForcedClosureGuardReportV2737 {
        val raw = text.trim()
        if (raw.isBlank()) return GTIMForcedClosureGuardReportV2737.inactive()
        val detected = riskyPatterns
            .filter { (_, regex) -> regex.containsMatchIn(raw) }
            .map { it.first }
            .distinct()
        if (detected.isEmpty()) return GTIMForcedClosureGuardReportV2737.inactive()
        return GTIMForcedClosureGuardReportV2737(
            active = true,
            version = VERSION,
            state = STATE,
            detectedPatterns = detected,
            blockedActions = BLOCKED_ACTIONS,
            safeCommand = "OPEN_EXPLORATORY_ROUTE_REVIEW",
            rewrittenMode = "EXPLORATORY_ROUTE_REVIEW_ONLY",
            requiredChecks = REQUIRED_CHECKS,
            safeStructuredIntakeHint = safeStructuredIntake(raw),
            claimLimit = CLAIM_LIMIT
        )
    }

    fun rewriteForRouting(text: String): String {
        val report = evaluate(text)
        if (!report.active) return text
        return listOf(
            "command: ${report.safeCommand}",
            "claim_mode: research_leads_only",
            "override_off_route_block: false",
            "force_gate_closure: false",
            "required_checks: ${report.requiredChecks.joinToString(", ")}",
            "safety_rewrite: ${report.state}",
            "original_topic_context:",
            text
        ).joinToString("\n")
    }

    fun oneLine(report: GTIMForcedClosureGuardReportV2737): String = if (!report.active) {
        "Forced-closure safety guard: no forced closure pattern detected."
    } else {
        "${report.state}; blocked=${report.detectedPatterns.joinToString(", ")}; mode=${report.rewrittenMode}; claimLimit=${report.claimLimit}"
    }

    private fun safeStructuredIntake(raw: String): String {
        val compact = raw
            .replace(Regex("\\s+"), " ")
            .take(260)
            .lowercase(Locale.US)
        return "OPEN_EXPLORATORY_ROUTE_REVIEW | force_gate_closure=false | override_off_route_block=false | context=${compact}"
    }
}
