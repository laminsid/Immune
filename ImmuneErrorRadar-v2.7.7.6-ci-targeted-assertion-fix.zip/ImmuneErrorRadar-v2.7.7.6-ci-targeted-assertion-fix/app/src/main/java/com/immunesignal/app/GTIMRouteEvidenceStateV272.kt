package com.immunesignal.app

/**
 * v2.7.2: explicit route-state ladder to avoid pretending that early route value
 * is the same as strong biological evidence.
 */
data class GTIMRouteEvidenceStateReportV272(
    val active: Boolean,
    val state: String,
    val reason: String,
    val nextGate: String,
    val claimLimit: String = GTIMRouteEvidenceStateV272.CLAIM_LIMIT
)

object GTIMRouteEvidenceStateV272 {
    const val VERSION: String = "2.7.2-proof-of-value-route-state-ladder"
    const val CLAIM_LIMIT: String = "route_state_visibility_only_not_evidence_upgrade"

    fun classify(
        routeScore: Int,
        discoveryScore: Int,
        evidenceScore: Int,
        leadCount: Int,
        routeCount: Int,
        accessionCount: Int,
        seedCount: Int,
        paperUnderstanding: GTIMPaperUnderstandingLiteReportV272
    ): GTIMRouteEvidenceStateReportV272 {
        if (!RuntimeFeatureFlags.ENABLE_PROMISING_ROUTE_STATE_V272) {
            return GTIMRouteEvidenceStateReportV272(false, "EXPLORATORY_ROUTE_NOT_EVIDENCE", "route state ladder disabled", "enable flag")
        }
        val hasPaperSignals = paperUnderstanding.active && paperUnderstanding.paperUnderstandingScore >= 20
        val hasDatasetHint = paperUnderstanding.datasetAvailabilitySignals.isNotEmpty()
        val meetsPromisingNumericThreshold =
            routeScore >= RuntimeFeatureFlags.PROMISING_ROUTE_MIN_CAUSALITY_THRESHOLD_V2738 ||
                evidenceScore >= RuntimeFeatureFlags.PROMISING_ROUTE_MIN_EVIDENCE_THRESHOLD_V2738 ||
                routeScore >= RuntimeFeatureFlags.PROMISING_ROUTE_MIN_ROUTE_SCORE_V272
        val state = when {
            evidenceScore >= RuntimeFeatureFlags.STRONG_SIGNAL_EVIDENCE_THRESHOLD &&
                routeScore >= RuntimeFeatureFlags.STRONG_SIGNAL_CAUSALITY_THRESHOLD &&
                accessionCount > 0 && hasDatasetHint -> "STRONG_SIGNAL_REVIEW_ONLY"
            accessionCount > 0 && hasDatasetHint -> "EVIDENCE_CANDIDATE"
            meetsPromisingNumericThreshold || discoveryScore >= 15 || seedCount > 0 || hasPaperSignals || leadCount > 0 || routeCount > 0 -> "PROMISING_ROUTE"
            else -> "EXPLORATORY_LEAD"
        }
        val reason = when (state) {
            "STRONG_SIGNAL_REVIEW_ONLY" -> "meets numeric route/evidence threshold plus accession/data hint; still review-only and claim-gated"
            "EVIDENCE_CANDIDATE" -> "has accession/data-availability hint but still needs metadata/comparator/matrix validation"
            "PROMISING_ROUTE" -> "route has seeds, paper-lite signals, or planned queries worth a second pass without upgrading claims"
            else -> "route is visible but not yet useful enough to call promising"
        }
        val nextGate = when (state) {
            "STRONG_SIGNAL_REVIEW_ONLY" -> "human review: verify methods, comparator, effect direction, and contradiction closure"
            "EVIDENCE_CANDIDATE" -> "close comparator + metadata + matrix readiness"
            "PROMISING_ROUTE" -> "run second-pass public lookup and capture accession/comparator evidence"
            else -> "feed structured topic or one PMID/DOI/GSE seed"
        }
        return GTIMRouteEvidenceStateReportV272(true, state, reason, nextGate)
    }
}
