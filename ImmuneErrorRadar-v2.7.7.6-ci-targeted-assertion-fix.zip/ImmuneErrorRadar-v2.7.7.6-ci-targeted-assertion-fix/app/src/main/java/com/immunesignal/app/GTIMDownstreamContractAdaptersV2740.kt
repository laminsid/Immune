package com.immunesignal.app

/**
 * Minimal adapters to connect existing downstream layers to the run contract.
 * Use these methods inside existing classes instead of local ifEmpty/defaultRoute/fallback logic.
 */
object GTIMDownstreamContractAdaptersV2740 {

    fun selectRoutesFromContract(
        contract: GTIMRunDecisionContractV2740,
        candidates: List<GTIMRouteGovernanceV2740.RouteCandidate>
    ): List<GTIMRouteGovernanceV2740.RouteDecision> {
        val evaluated = candidates.map { GTIMRouteGovernanceV2740.evaluate(contract, it) }
        val allowed = evaluated.filter { it.allowed }

        if (allowed.isNotEmpty()) return allowed

        // Stop dangerous fallbacks in user-directed mode.
        if (contract.runMode == GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED || contract.runMode == GTIMRunModeV2740.USER_DIRECTED_SYNDROME_EXPLORATION) {
            return listOf(
                GTIMRouteGovernanceV2740.RouteDecision(
                    decision = GTIMRouteGovernanceV2740.RouteDecisionType.ALLOW_PRIMARY_ANCHOR,
                    allowed = true,
                    routeId = contract.primaryAnchor.routeId,
                    label = GTIMEvidenceLabelV2740.PLAUSIBLE_MECHANISM,
                    claimMode = contract.claimMode,
                    confidenceCap = contract.evidenceCaps.routeConfidenceMax,
                    reason = "Fallback constrained to protected primary anchor only; no default/allergy/known-prior leakage."
                )
            )
        }

        // Autonomous mode may use broad exploration when no candidate survives.
        return listOf(
            GTIMRouteGovernanceV2740.RouteDecision(
                decision = GTIMRouteGovernanceV2740.RouteDecisionType.ALLOW_AUTONOMOUS_EXPLORATION,
                allowed = true,
                routeId = GTIMDiscoveryBridgeV2740.AUTONOMOUS_CROSS_DOMAIN_WEAK_LEAD.routeId,
                label = GTIMEvidenceLabelV2740.SPECULATIVE_BRIDGE,
                claimMode = GTIMClaimModeV2740.AUTONOMOUS_EXPLORATORY_HYPOTHESIS,
                confidenceCap = contract.evidenceCaps.routeConfidenceMax,
                reason = "Autonomous fallback: broad weak-lead exploration allowed and explicitly labeled."
            )
        )
    }

    fun selectSeedsFromContract(
        contract: GTIMRunDecisionContractV2740,
        proposedSeedIds: List<String>
    ): List<String> {
        val filtered = proposedSeedIds.filter { candidate ->
            val trimmed = candidate.trim()
            when {
                trimmed.isBlank() -> false
                contract.canUseSeed(trimmed) -> true
                looksLikeRouteId(trimmed) -> contract.canUseRoute(trimmed)
                else -> !containsBlockedConcept(trimmed, contract)
            }
        }.distinct()
        if (filtered.isNotEmpty()) return filtered

        return if (contract.runMode == GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED || contract.runMode == GTIMRunModeV2740.USER_DIRECTED_SYNDROME_EXPLORATION) {
            listOf(contract.primaryAnchor.routeId)
        } else {
            contract.allowedSeeds.take(12)
        }
    }

    fun filterQueryTextWithContract(
        contract: GTIMRunDecisionContractV2740,
        proposedQueries: List<String>
    ): List<String> {
        return proposedQueries.filter { query ->
            query.isNotBlank() && (contract.runMode == GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION || !containsBlockedConcept(query, contract))
        }.distinct()
    }

    private fun looksLikeRouteId(value: String): Boolean {
        return value.contains("_") && value.lowercase() == value
    }

    fun isTextAllowedByContract(text: String, contract: GTIMRunDecisionContractV2740): Boolean {
        if (text.isBlank()) return true
        if (!GTIMCanonicalRouteIdentityV2748.isAllowedRouteText(text, contract)) return false
        if (contract.runMode == GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION &&
            contract.primaryAnchor == GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY
        ) return true
        return !containsBlockedConcept(text, contract)
    }

    fun safeDataFeedAction(contract: GTIMRunDecisionContractV2740): String {
        val topic = contract.benchmarkTopic ?: contract.primaryAnchor.routeId
        return when (contract.primaryAnchor) {
            GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> "Run COVID / Long-COVID interferon host-response route first: COVID SARS-CoV-2 PASC interferon IL-6 TNF PBMC/airway transcriptomics comparator GSE/SRA/PMID."
            GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> "Run allergy / IgE / mast-cell / type-2 route first: allergy hypersensitivity IgE mast cell eosinophil IL-4 IL-5 IL-13 comparator dataset GSE/SRA/PMID."
            GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> "Run Ebola / hemorrhagic viral host-response route first: Ebola EVD human cohort PBMC/blood transcriptomics comparator GSE/SRA/PMID."
            GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION -> "Run HIV / CD4 immune-depletion route first: HIV AIDS CD4 T-cell immune remodeling viral load comparator GSE/SRA/PMID."
            GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> "Run hantavirus / zoonotic viral immune route first: hantavirus HFRS HCPS cytokine PBMC/blood comparator GSE/SRA/PMID."
            GTIMPrimaryAnchorV2740.FATIGUE_SYNDROME_NEUROIMMUNE_METABOLIC -> "Run fatigue syndrome route first: fatigue post-viral mitochondrial HPA sleep inflammatory metabolic-immune human cohort comparator GSE/SRA/PMID."
            GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> "Run gut microbiome → depression neuroimmune route first: microbiome tryptophan kynurenine IL-6 TNF CRP human cohort comparator PRJNA/GSE/PMID."
            GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE -> "Run IBD / mucosal-barrier microbiome route first: IBD Crohn colitis intestinal barrier mucosal inflammation comparator GSE/SRA/PMID."
            else -> {
                val ontologyKeywords = GTIMDiseaseSymptomOntologyBootstrapV2755.searchKeywordsFor(contract.primaryAnchor).take(2).joinToString("; ")
                if (ontologyKeywords.isNotBlank()) {
                    "Run ontology-anchored route first: $topic; $ontologyKeywords; comparator dataset accession/PMID lookup; suppress template routes outside the active run contract."
                } else {
                    "Run contract-anchored route first: $topic comparator dataset accession/PMID lookup; suppress template routes outside the active run contract."
                }
            }
        }
    }

    fun safeQuery(contract: GTIMRunDecisionContractV2740): String {
        return when (contract.primaryAnchor) {
            GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> "COVID SARS-CoV-2 Long COVID PASC interferon IL-6 TNF PBMC airway transcriptomics comparator GSE PRJNA PMID"
            GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> "allergy hypersensitivity IgE mast cell eosinophil IL-4 IL-5 IL-13 human comparator GSE PRJNA PMID"
            GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> "Ebola EVD hemorrhagic viral host response PBMC blood transcriptomics human cohort comparator GSE PRJNA PMID"
            GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION -> "HIV AIDS CD4 T cell immune depletion viral load transcriptomics comparator GSE PRJNA PMID"
            GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> "hantavirus HFRS HCPS zoonotic viral immune response cytokine human cohort comparator GSE PRJNA PMID"
            GTIMPrimaryAnchorV2740.FATIGUE_SYNDROME_NEUROIMMUNE_METABOLIC -> "fatigue chronic fatigue post viral mitochondrial HPA sleep IL-6 TNF CRP human cohort comparator GSE PRJNA PMID"
            GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> "gut microbiome depression tryptophan kynurenine IL-6 TNF CRP human cohort dataset PRJNA GSE PMID"
            GTIMPrimaryAnchorV2740.IBD_INFLAMMATORY_BOWEL_DISEASE -> "IBD Crohn colitis intestinal barrier mucosal inflammation microbiome comparator GSE PRJNA PMID"
            else -> {
                val ontologyKeywords = GTIMDiseaseSymptomOntologyBootstrapV2755.searchKeywordsFor(contract.primaryAnchor).take(3).joinToString(" ")
                if (ontologyKeywords.isNotBlank()) "$ontologyKeywords comparator dataset accession PMID GSE PRJNA" else "${contract.benchmarkTopic ?: contract.primaryAnchor.routeId} comparator dataset accession PMID GSE PRJNA"
            }
        }
    }

    private fun containsBlockedConcept(text: String, contract: GTIMRunDecisionContractV2740): Boolean {
        val normalizedText = normalizeConcept(text)
        val blocked = contract.blockedRoutes + contract.forbiddenConflations + contract.forbiddenIdentityMutations
        return blocked.any { blockedTerm ->
            val normalizedBlocked = normalizeConcept(blockedTerm)
            when {
                normalizedBlocked.isBlank() -> false
                normalizedText.contains(normalizedBlocked) -> true
                normalizedBlocked.contains("allergy") || normalizedBlocked.contains("ige") -> containsAny(normalizedText, "allergy", "allergies", "allergic", "hypersensitivity", "ige", "mast cell", "mast-cell", "eosinophil", "type 2", "type2")
                normalizedBlocked.contains("covid") || normalizedBlocked.contains("sars") -> containsAny(normalizedText, "covid", "sars cov 2", "sars-cov-2", "long covid", "pasc")
                normalizedBlocked.contains("ebola") || normalizedBlocked.contains("hemorrhagic") -> containsAny(normalizedText, "ebola", "evd", "hemorrhagic", "filovirus")
                normalizedBlocked.contains("hiv") || normalizedBlocked.contains("retroviral") -> containsAny(normalizedText, "hiv", "aids", "sida", "cd4", "retroviral")
                normalizedBlocked.contains("depression") -> containsAny(normalizedText, "depression", "major depressive", "mood disorder")
                normalizedBlocked.contains("ibd") || normalizedBlocked.contains("mucosal") -> containsAny(normalizedText, "ibd", "crohn", "colitis", "inflammatory bowel", "mucosal", "intestinal barrier")
                else -> false
            }
        }
    }

    private fun containsAny(text: String, vararg needles: String): Boolean = needles.any { text.contains(it) }

    private fun normalizeConcept(value: String): String {
        return value.lowercase()
            .replace('_', ' ')
            .replace('-', ' ')
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun benchmarkFromContract(contract: GTIMRunDecisionContractV2740): String {
        return contract.benchmarkTopic ?: contract.primaryAnchor.routeId
    }

    fun applyScoreCaps(
        contract: GTIMRunDecisionContractV2740,
        rawDataQuality: Int,
        rawEvidenceStrength: Int,
        rawRouteConfidence: Int
    ): Triple<Int, Int, Int> {
        val dq = rawDataQuality.coerceIn(0, contract.evidenceCaps.dataQualityMax)
        val ev = rawEvidenceStrength.coerceIn(0, contract.evidenceCaps.evidenceStrengthMax)
        val rc = rawRouteConfidence.coerceIn(0, contract.evidenceCaps.routeConfidenceMax)
        return Triple(dq, ev, rc)
    }

    fun uiSummary(contract: GTIMRunDecisionContractV2740): String {
        val main = when (contract.runMode) {
            GTIMRunModeV2740.USER_DIRECTED_ANCHOR_PROTECTED -> "Main question understood: ${contract.primaryAnchor.routeId}"
            GTIMRunModeV2740.USER_DIRECTED_SYNDROME_EXPLORATION -> "Directed syndrome exploration: ${contract.primaryAnchor.routeId}"
            GTIMRunModeV2740.AUTONOMOUS_DISCOVERY_FREE_EXPLORATION -> "Autonomous discovery: broad cross-domain exploration"
        }
        val paths = contract.discoveryBridges.take(5).joinToString(separator = "\n") { "- ${it.routeId}" }
        val warning = if (contract.evidenceCaps.causalityClaimAllowed) {
            "Claim strength: evidence-limited; causal claims require dataset support."
        } else {
            "Claim strength: exploratory only; not confirmed causality."
        }
        return "$main\n\nPossible discovery paths:\n$paths\n\n$warning\nEvidence cap: data=${contract.evidenceCaps.dataQualityMax}, evidence=${contract.evidenceCaps.evidenceStrengthMax}."
    }
}
