package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.9.8 hypothesis graph cognition.
 *
 * This layer turns post-search thinking into a durable hypothesis map. It does
 * not search and it does not prove biology. It keeps hypotheses, accessions,
 * objections, and open evidence gaps connected across saved cycles so the app
 * can reason locally before spending another network cycle.
 */
data class HypothesisGraphNode(
    val nodeId: String,
    val label: String,
    val nodeType: String,
    val state: String,
    val confidence: Int,
    val evidence: List<String>,
    val missingEvidence: List<String>,
    val objections: List<String>,
    val nextTest: String
)

data class HypothesisGraphEdge(
    val fromNodeId: String,
    val toNodeId: String,
    val relation: String,
    val weight: Int,
    val rationale: String
)

data class HypothesisGraphReport(
    val active: Boolean,
    val state: String,
    val graphIteration: Int,
    val nodes: List<HypothesisGraphNode>,
    val edges: List<HypothesisGraphEdge>,
    val dominantHypothesis: String,
    val weakestLink: String,
    val killSwitch: String,
    val nextReasoningMove: String,
    val searchDecision: String,
    val summary: String,
    val claimLimit: String = "hypothesis_graph_not_biological_proof"
) {
    companion object {
        fun empty() = HypothesisGraphReport(
            active = false,
            state = "NO_GRAPH",
            graphIteration = 0,
            nodes = emptyList(),
            edges = emptyList(),
            dominantHypothesis = "No hypothesis graph has been created yet.",
            weakestLink = "No saved evidence object.",
            killSwitch = "Run or load a research cycle before graph reasoning.",
            nextReasoningMove = "No graph move available.",
            searchDecision = "Search is not justified without a graph node and evidence gap.",
            summary = "No hypothesis graph available."
        )
    }
}

object HypothesisGraphCognitionEngine {
    fun build(
        recentReportJsonLines: List<String>,
        evidenceClosure: EvidenceClosureReport,
        postSearchThinking: PostSearchThinkingReport,
        thinkingContinuity: ThinkingContinuityReport,
        learningOs: LearningOsReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        qualityGate: ScientificDiscoveryQualityGateReport
    ): HypothesisGraphReport {
        if (!evidenceClosure.active && !postSearchThinking.active && !thinkingContinuity.active) {
            return HypothesisGraphReport.empty()
        }
        val priorReports = recentReportJsonLines.mapNotNull { line -> runCatching { JSONObject(line) }.getOrNull() }
        val priorGraphCount = priorReports.count { (it.optJSONObject("hypothesisGraphReport") ?: JSONObject()).optBoolean("active", false) }
        val currentMissing = evidenceClosure.cards.flatMap { it.missingFields }
        val repeatedGaps = thinkingContinuity.repeatedGaps.ifEmpty { currentMissing }
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(8)
        val priorDominant = priorReports.firstOrNull {
            (it.optJSONObject("hypothesisGraphReport") ?: JSONObject()).optBoolean("active", false)
        }?.optJSONObject("hypothesisGraphReport")?.optString("dominantHypothesis").orEmpty()

        val accessionNodes = evidenceClosure.cards.take(3).map { card ->
            HypothesisGraphNode(
                nodeId = stableNodeId("accession", card.accession),
                label = "Accession ${card.accession}: ${card.decision}",
                nodeType = "ACCESSION",
                state = if (card.blocksBroadSearch) "OPEN_BLOCKER" else "INSPECTABLE",
                confidence = card.closureScore.coerceIn(0, 100),
                evidence = listOf(
                    "routeFit=${card.routeFitScore}/100",
                    "usability=${card.datasetUsabilityScore}/100",
                    "organism=${card.organism}",
                    "assay=${card.assayType}"
                ).filter { !it.endsWith("=unknown") },
                missingEvidence = card.missingFields.take(8),
                objections = listOf("Accession route-fit cannot upgrade a biological hypothesis until decisive labels close."),
                nextTest = card.nextAction
            )
        }
        val hypothesisNodes = postSearchThinking.hypotheses.take(4).mapIndexed { index, hyp ->
            val missing = repeatedGaps.ifEmpty { currentMissing }.take(6)
            HypothesisGraphNode(
                nodeId = stableNodeId("hypothesis", hyp.hypothesisId.ifBlank { "h$index" }),
                label = hyp.label,
                nodeType = "HYPOTHESIS",
                state = when {
                    hyp.state.contains("HOLD", ignoreCase = true) -> "HELD_FOR_EVIDENCE"
                    missing.isNotEmpty() -> "OPEN_TEST_REQUIRED"
                    else -> "CANDIDATE_FOR_NARROW_TEST"
                },
                confidence = hyp.confidence.coerceIn(0, 100),
                evidence = hyp.support.take(5),
                missingEvidence = missing,
                objections = hyp.objections.take(5),
                nextTest = hyp.discriminator.ifBlank { hyp.nextAction }
            )
        }
        val gapNodes = repeatedGaps.take(5).map { gap ->
            HypothesisGraphNode(
                nodeId = stableNodeId("gap", gap),
                label = "Evidence gap: $gap",
                nodeType = "EVIDENCE_GAP",
                state = "MUST_CLOSE_OR_ARCHIVE",
                confidence = 100,
                evidence = listOf("Repeated or current missing key."),
                missingEvidence = listOf(gap),
                objections = listOf("Searching more without closing this gap repeats the same failure pattern."),
                nextTest = "Close $gap with metadata, outcome/control/time evidence, or archive the route."
            )
        }
        val objectionNode = firstNonBlank(
            qualityGate.executionDecision,
            learningOs.nextLearningAction,
            deepDiscovery.contradictionPlan.strongestObjection,
            postSearchThinking.contradictions.firstOrNull().orEmpty()
        ).takeIf { it.isNotBlank() }?.let { objection ->
            HypothesisGraphNode(
                nodeId = stableNodeId("objection", objection.take(60)),
                label = "Strongest objection",
                nodeType = "OBJECTION",
                state = "ACTIVE_GUARD",
                confidence = 90,
                evidence = listOf(objection.take(260)),
                missingEvidence = repeatedGaps.take(4),
                objections = listOf(objection.take(260)),
                nextTest = "Resolve the objection before strengthening any hypothesis."
            )
        }
        val nodes = (accessionNodes + hypothesisNodes + gapNodes + listOfNotNull(objectionNode))
            .distinctBy { it.nodeId }
            .take(12)
        val edges = buildEdges(accessionNodes, hypothesisNodes, gapNodes, objectionNode).take(18)
        val dominant = firstNonBlank(
            hypothesisNodes.maxByOrNull { it.confidence }?.label.orEmpty(),
            priorDominant,
            accessionNodes.firstOrNull()?.label.orEmpty(),
            "No dominant hypothesis; preserve only the evidence route."
        )
        val weakest = repeatedGaps.firstOrNull()
            ?: qualityGate.requiredBeforeRun.firstOrNull()
            ?: evidenceClosure.cards.firstOrNull()?.missingFields?.firstOrNull()
            ?: "one explicit discriminator"
        val blocked = evidenceClosure.broadSearchBlocked || thinkingContinuity.nextSearchPermission.startsWith("NO_BROAD_SEARCH", ignoreCase = true)
        val state = when {
            blocked -> "GRAPH_CLOSE_BEFORE_SEARCH"
            repeatedGaps.size >= 3 -> "GRAPH_REVISE_OR_ARCHIVE_PRESSURE"
            qualityGate.allowExecution -> "GRAPH_NARROW_TEST_ALLOWED"
            else -> "GRAPH_THINK_FIRST"
        }
        val killSwitch = when {
            blocked -> "If $weakest remains unresolved after the closure query, archive or cool down the accession route."
            repeatedGaps.isNotEmpty() -> "If repeated gaps persist, do not let the same hypothesis route another broad query."
            else -> "If no node gains evidence, preserve as context only and require parent evidence."
        }
        val nextMove = when {
            accessionNodes.isNotEmpty() && blocked -> "Close the accession node first: ${accessionNodes.first().nextTest.take(220)}"
            gapNodes.isNotEmpty() -> "Resolve the highest-value gap node: ${gapNodes.first().label}."
            hypothesisNodes.isNotEmpty() -> "Run the discriminator for the top hypothesis: ${hypothesisNodes.first().nextTest.take(220)}"
            else -> "Build a parent-evidence node before searching."
        }
        val searchDecision = when {
            blocked -> "NO_BROAD_SEARCH: graph requires accession/gap closure first."
            qualityGate.allowExecution && repeatedGaps.isNotEmpty() -> "NARROW_SEARCH_ALLOWED: query must close $weakest and update the graph."
            else -> "THINK_FIRST: no new search until the graph has a falsifiable node."
        }
        return HypothesisGraphReport(
            active = true,
            state = state,
            graphIteration = priorGraphCount + 1,
            nodes = nodes,
            edges = edges,
            dominantHypothesis = dominant.take(300),
            weakestLink = weakest,
            killSwitch = killSwitch.take(260),
            nextReasoningMove = nextMove.take(260),
            searchDecision = searchDecision,
            summary = "Hypothesis graph: $state; nodes=${nodes.size}; edges=${edges.size}; weakest=$weakest; iteration=${priorGraphCount + 1}."
        )
    }

    private fun buildEdges(
        accessionNodes: List<HypothesisGraphNode>,
        hypothesisNodes: List<HypothesisGraphNode>,
        gapNodes: List<HypothesisGraphNode>,
        objectionNode: HypothesisGraphNode?
    ): List<HypothesisGraphEdge> {
        val edges = mutableListOf<HypothesisGraphEdge>()
        val topAccession = accessionNodes.firstOrNull()
        val topHypothesis = hypothesisNodes.firstOrNull()
        if (topAccession != null && topHypothesis != null) {
            edges += HypothesisGraphEdge(
                fromNodeId = topAccession.nodeId,
                toNodeId = topHypothesis.nodeId,
                relation = "ROUTE_SUPPORTS_ONLY_IF_CLOSED",
                weight = ((topAccession.confidence + topHypothesis.confidence) / 2).coerceIn(0, 100),
                rationale = "Dataset/accession can support the hypothesis only after missing labels and controls close."
            )
        }
        for (gap in gapNodes) {
            for (hyp in hypothesisNodes.take(2)) {
                edges += HypothesisGraphEdge(
                    fromNodeId = gap.nodeId,
                    toNodeId = hyp.nodeId,
                    relation = "GAP_BLOCKS_UPGRADE",
                    weight = 100,
                    rationale = "This evidence gap must be closed before the hypothesis can route or strengthen."
                )
            }
            if (topAccession != null) {
                edges += HypothesisGraphEdge(
                    fromNodeId = gap.nodeId,
                    toNodeId = topAccession.nodeId,
                    relation = "GAP_BLOCKS_ACCESSION_CLOSURE",
                    weight = 95,
                    rationale = "The accession remains hypothesis-only until this key is resolved."
                )
            }
        }
        if (objectionNode != null) {
            for (hyp in hypothesisNodes.take(2)) {
                edges += HypothesisGraphEdge(
                    fromNodeId = objectionNode.nodeId,
                    toNodeId = hyp.nodeId,
                    relation = "OBJECTION_CHALLENGES",
                    weight = 90,
                    rationale = "The strongest objection must be answered before confidence can rise."
                )
            }
        }
        return edges.distinctBy { "${it.fromNodeId}->${it.toNodeId}:${it.relation}" }
    }

    fun toJson(report: HypothesisGraphReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("state", report.state)
        .put("graphIteration", report.graphIteration)
        .put("nodes", JSONArray(report.nodes.map { nodeToJson(it) }))
        .put("edges", JSONArray(report.edges.map { edgeToJson(it) }))
        .put("dominantHypothesis", report.dominantHypothesis)
        .put("weakestLink", report.weakestLink)
        .put("killSwitch", report.killSwitch)
        .put("nextReasoningMove", report.nextReasoningMove)
        .put("searchDecision", report.searchDecision)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun nodeToJson(node: HypothesisGraphNode): JSONObject = JSONObject()
        .put("nodeId", node.nodeId)
        .put("label", node.label)
        .put("nodeType", node.nodeType)
        .put("state", node.state)
        .put("confidence", node.confidence)
        .put("evidence", JSONArray(node.evidence))
        .put("missingEvidence", JSONArray(node.missingEvidence))
        .put("objections", JSONArray(node.objections))
        .put("nextTest", node.nextTest)

    private fun edgeToJson(edge: HypothesisGraphEdge): JSONObject = JSONObject()
        .put("fromNodeId", edge.fromNodeId)
        .put("toNodeId", edge.toNodeId)
        .put("relation", edge.relation)
        .put("weight", edge.weight)
        .put("rationale", edge.rationale)

    fun compactFromJson(report: JSONObject): String {
        val graph = report.optJSONObject("hypothesisGraphReport") ?: JSONObject()
        if (!graph.optBoolean("active", false)) {
            return "Hypothesis graph\n• State: no graph yet. Run Search once, then graph reasoning can connect accessions, gaps, and hypotheses."
        }
        val nodes = graph.optJSONArray("nodes") ?: JSONArray()
        val edges = graph.optJSONArray("edges") ?: JSONArray()
        val topNodes = (0 until nodes.length()).mapNotNull { nodes.optJSONObject(it) }.take(3)
        return buildString {
            append("Hypothesis graph\n")
            append("• State: ").append(graph.optString("state", "unknown")).append("\n")
            append("• Dominant: ").append(graph.optString("dominantHypothesis", "none").take(180)).append("\n")
            append("• Weakest link: ").append(graph.optString("weakestLink", "none")).append("\n")
            append("• Nodes/edges: ").append(nodes.length()).append("/").append(edges.length()).append("\n")
            if (topNodes.isNotEmpty()) {
                append("• Open nodes: ").append(topNodes.joinToString(" | ") { node ->
                    "${node.optString("nodeType")}:${node.optString("state")}"
                }.take(220)).append("\n")
            }
            append("• Next: ").append(graph.optString("nextReasoningMove", "none").take(220)).append("\n")
            append("• Search decision: ").append(graph.optString("searchDecision", "THINK_FIRST").take(220))
        }
    }

    private fun stableNodeId(prefix: String, raw: String): String {
        val clean = raw.lowercase()
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .take(48)
            .ifBlank { "unknown" }
        return "${prefix}_$clean"
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}
