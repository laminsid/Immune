package com.immunesignal.app

/**
 * v1.4.2: Dataset Parser & Outcome Label Intelligence.
 *
 * These are metadata-interpreter primitives. They do not train ML models, do
 * not make clinical claims, and do not expand the biological scope. They answer
 * a narrower question: after a dataset accession/candidate is found, is the
 * dataset interpretable enough to create a real evidence object?
 */
data class ParsedDatasetMetadata(
    val accession: String,
    val sourceFamily: String,
    val organism: String,
    val sampleSizeStatus: String,
    val conditionLabels: List<String>,
    val outcomeLabels: List<String>,
    val controlLabels: List<String>,
    val timeCourseLabels: List<String>,
    val tissueOrSource: String,
    val assayType: String,
    val contrastiveSlots: List<String>,
    val metadataQualityScore: Int,
    val usabilityVerdict: String,
    val evidenceObjectEligible: Boolean,
    val reasons: List<String>
)

data class ContrastiveEvidenceReport(
    val gateStatus: String,
    val slotsDetected: List<String>,
    val summary: String,
    val nextContrastiveQuestion: String
) {
    companion object {
        fun empty() = ContrastiveEvidenceReport(
            gateStatus = "NOT_EVALUATED",
            slotsDetected = emptyList(),
            summary = "No parsed dataset metadata was available for contrastive evaluation.",
            nextContrastiveQuestion = "Acquire at least one dataset candidate with condition and outcome labels."
        )
    }
}

data class EvidenceHypergraphNode(
    val nodeId: String,
    val nodeType: String,
    val label: String,
    val links: List<String>,
    val strength: Int,
    val contradictionFlag: Boolean
)

data class CumulativeEvidenceReport(
    val score: Int,
    val state: String,
    val upgrades: List<String>,
    val downgrades: List<String>,
    val rationale: List<String>
) {
    companion object {
        fun empty() = CumulativeEvidenceReport(
            score = 0,
            state = "OFF",
            upgrades = emptyList(),
            downgrades = listOf("No parsed dataset metadata or evidence objects yet."),
            rationale = listOf("Cumulative evidence scoring is locked until interpretable metadata exists.")
        )
    }
}
