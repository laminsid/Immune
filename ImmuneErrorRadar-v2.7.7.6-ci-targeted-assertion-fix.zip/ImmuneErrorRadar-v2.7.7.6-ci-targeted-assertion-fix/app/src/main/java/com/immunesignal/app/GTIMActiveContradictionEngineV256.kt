package com.immunesignal.app

/**
 * Active contradiction/null-result engine.
 *
 * Produces support and opposition search paths. It must never suppress weak-lead visibility, and
 * it must never upgrade confidence while contradiction gaps remain open.
 */
object GTIMActiveContradictionEngineV256 {
    const val STATUS: String = "ACTIVE_CONTRADICTION_ENGINE_READY"

    fun search(
        intent: GTIMResearchIntentObjectV255,
        plan: GTIMDataFeedPlanV255,
        routes: List<GTIMCandidateRouteV256>
    ): GTIMContradictionEngineReportV256 {
        val base = (intent.triggerExposure + intent.diseasePhenotype + intent.pathway).take(8).joinToString(" OR ").ifBlank { "immune mechanism" }
        val targets = plan.contradictionTargets.ifEmpty { listOf("null result", "no association", "opposite direction", "failed replication", "species mismatch", "tissue mismatch") }
        val contradictionQueries = targets.take(6).map { target -> "($base) AND \"$target\"" }
        return GTIMContradictionEngineReportV256(
            active = true,
            status = STATUS,
            supportQueries = routes.take(4).map { it.cascade.joinToString(" AND ") },
            contradictionQueries = contradictionQueries,
            nullResultTargets = targets,
            interpretationRule = "Attach supporting, opposing, null, and uncertain evidence to the route; do not suppress weak-lead display; do not upgrade while contradiction gaps are open."
        )
    }
}
