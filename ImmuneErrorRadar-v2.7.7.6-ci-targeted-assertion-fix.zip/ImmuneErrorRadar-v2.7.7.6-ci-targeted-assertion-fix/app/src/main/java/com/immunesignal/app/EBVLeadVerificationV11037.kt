package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.37: EBV criterion lane for weak/off-route lead verification.
 *
 * This is deliberately not a discovery shortcut. EBV/Herpesviridae/molecular-mimicry
 * terms may open a falsifiable verification lane for the carried lead, but they cannot
 * create an EvidenceObject or upgrade a hypothesis until accession, metadata,
 * control/comparator, time-order, and contradiction gates close.
 */
data class EBVLeadVerificationReport(
    val active: Boolean,
    val state: String,
    val targetLeadId: String,
    val criterionQuestion: String,
    val matchedTerms: List<String>,
    val closedEvidence: List<String>,
    val missingEvidence: List<String>,
    val allowedNextAction: String,
    val blockedClaims: List<String>,
    val invalidators: List<String>,
    val claimLimit: String = EBVLeadVerificationPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = EBVLeadVerificationReport(
            active = false,
            state = "NOT_EVALUATED",
            targetLeadId = "none",
            criterionQuestion = "No EBV verification criterion was evaluated.",
            matchedTerms = emptyList(),
            closedEvidence = emptyList(),
            missingEvidence = emptyList(),
            allowedNextAction = "No EBV-specific action available.",
            blockedClaims = emptyList(),
            invalidators = emptyList()
        )
    }
}

object EBVLeadVerificationPolicy {
    const val CLAIM_LIMIT: String = "ebv_criterion_lane_not_biological_proof"

    private val ebvTerms = listOf(
        "ebv", "epstein", "epstein-barr", "epstein barr", "herpesviridae",
        "herpesvirus", "hhv-6", "hhv6", "cmv", "latent virus", "reactivation"
    )
    private val mimicryTerms = listOf("molecular mimicry", "mimicry", "cross-reactive", "cross reactive", "autoantibody", "autoimmune")
    private val accessionTerms = listOf("gse", "geo", "prjna", "srp", "srr", "e-mtab", "sdy", "pmid", "doi")
    private val humanTerms = listOf("human", "patient", "cohort", "clinical", "sample")
    private val outcomeTerms = listOf("outcome", "severity", "recovery", "flare", "response", "endpoint")
    private val controlTerms = listOf(
        "healthy control", "negative control", "matched control", "control group", "control cohort",
        "case control", "case-control", "comparator group", "matched comparator"
    )
    private val timeTerms = listOf("longitudinal", "time-course", "time course", "serial", "follow-up", "baseline", "pre-trigger", "pre trigger")
    private val contradictionTerms = listOf("no association", "failed replication", "nonresponse", "heterogeneity", "reverse timing", "unrelated marker")

    fun evaluate(
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        metadataClosure: MetadataClosureReport,
        routeReport: UnknownRouteClassificationReport,
        recentReports: List<String>
    ): EBVLeadVerificationReport {
        val target = leadObjects.firstOrNull()?.leadId
            ?: candidates.firstOrNull()?.accession
            ?: extractManualLeadId(recentReports)
            ?: "none"
        val corpus = buildCorpus(leadObjects, candidates, routeReport, recentReports)
        val matched = (ebvTerms + mimicryTerms).filter { corpus.contains(it) }.distinct()
        val ebvSignal = ebvTerms.any { corpus.contains(it) }
        val mimicrySignal = mimicryTerms.any { corpus.contains(it) }
        val routePriorSignal = routeReport.routePriors.any { it.routeId == "latent_virus_reactivation_route" } ||
            routeReport.selectedRoute == "latent_virus_reactivation_route"
        val shouldEvaluate = ebvSignal || mimicrySignal || routePriorSignal
        if (!shouldEvaluate) {
            return EBVLeadVerificationReport.empty().copy(
                state = "NO_EBV_CRITERION_SIGNAL",
                criterionQuestion = "No EBV/Herpesviridae/molecular-mimicry signal was present; keep the carried lead on the normal metadata-closure path."
            )
        }

        val closed = linkedSetOf<String>()
        if (target != "none") closed += "target_lead_preserved"
        if (ebvSignal) closed += "ebv_or_herpesvirus_term"
        if (mimicrySignal) closed += "molecular_mimicry_context"
        if (metadataClosure.closedFields.contains("accession") || accessionTerms.any { corpus.contains(it) }) closed += "accession_or_source_id"
        if (metadataClosure.closedFields.contains("human_or_patient_data") || humanTerms.any { corpus.contains(it) }) closed += "human_or_patient_data"
        if (metadataClosure.closedFields.contains("outcome_labels") || outcomeTerms.any { corpus.contains(it) }) closed += "outcome_labels"
        if (metadataClosure.closedFields.contains("control_or_comparator") || controlTerms.any { corpus.contains(it) }) closed += "control_or_comparator"
        if (metadataClosure.closedFields.contains("time_order") || timeTerms.any { corpus.contains(it) }) closed += "time_order"
        if (contradictionTerms.any { corpus.contains(it) }) closed += "contradiction_or_negative_control_signal"

        val required = listOf(
            "target_lead_preserved",
            "ebv_or_herpesvirus_term",
            "molecular_mimicry_context",
            "accession_or_source_id",
            "human_or_patient_data",
            "outcome_labels",
            "control_or_comparator",
            "time_order",
            "contradiction_or_negative_control_signal"
        )
        val missing = required.filter { it !in closed }
        val state = when {
            missing.isEmpty() -> "EBV_CRITERION_READY_FOR_FALSIFICATION_REVIEW"
            "accession_or_source_id" in missing -> "EBV_CRITERION_NEEDS_SECONDARY_LOOKUP"
            missing.any { it in listOf("control_or_comparator", "time_order", "outcome_labels") } -> "EBV_CRITERION_BLOCKED_MINIMUM_METADATA"
            else -> "EBV_CRITERION_ROUTE_PRIOR_ONLY"
        }
        return EBVLeadVerificationReport(
            active = true,
            state = state,
            targetLeadId = target,
            criterionQuestion = "Can the carried weak lead be explicitly linked to EBV/Herpesviridae molecular mimicry with accession-level metadata, controls, time order, outcomes, and contradiction search?",
            matchedTerms = matched.take(12),
            closedEvidence = closed.toList(),
            missingEvidence = missing,
            allowedNextAction = when (state) {
                "EBV_CRITERION_READY_FOR_FALSIFICATION_REVIEW" -> "Run EBV-specific contradiction/negative-control review; still do not upgrade biology until an EvidenceObject exists."
                "EBV_CRITERION_NEEDS_SECONDARY_LOOKUP" -> "Run EBV criterion secondary lookup for the target lead: extract GSE/PRJNA/SRP/SRR/E-MTAB/SDY/PMID/DOI and source/data-availability text."
                "EBV_CRITERION_BLOCKED_MINIMUM_METADATA" -> "Close EBV criterion metadata: control/comparator, time order, outcome labels, and human cohort context before any contradiction or claim."
                else -> "Keep EBV as a route prior only and continue normal lead closure."
            },
            blockedClaims = listOf(
                "EBV causality",
                "first scientific breakthrough",
                "molecular mimicry confirmed",
                "autoimmune mechanism confirmed",
                "diagnosis/treatment recommendation"
            ),
            invalidators = listOf(
                "No explicit EBV/Herpesviridae term appears in accession-level metadata.",
                "No control/comparator exists for the same dataset or cohort.",
                "Time order does not place EBV/reactivation before immune outcome.",
                "Contradiction/negative-control search explains the lead better.",
                "Another route explains the same lead with fewer assumptions."
            )
        )
    }

    private fun buildCorpus(
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        routeReport: UnknownRouteClassificationReport,
        recentReports: List<String>
    ): String {
        return (
            leadObjects.joinToString(" ") {
                listOf(it.leadId, it.title, it.snippet, it.domain, it.omicsType, it.dataAvailabilityText, it.detectedAccessions.joinToString(" ")).joinToString(" ")
            } + " " +
                candidates.joinToString(" ") {
                    listOf(it.accession, it.sourceTitle, it.conditionLabelsHint, it.outcomeLabelsHint, it.timeCourseHint, it.dataType, it.reasons.joinToString(" ")).joinToString(" ")
                } + " " +
                routeReport.routePriors.joinToString(" ") { it.routeId + " " + it.label + " " + it.matchedTerms.joinToString(" ") } + " " +
                recentReports.take(8).joinToString(" ").take(12_000)
            ).lowercase(Locale.US)
    }

    private fun extractManualLeadId(recentReports: List<String>): String? {
        val pattern = Regex("MANUAL_TEXT_SNIPPET_[A-Za-z0-9_]+")
        return recentReports.asSequence()
            .flatMap { pattern.findAll(it).asSequence().map { match -> match.value } }
            .firstOrNull()
    }
}
