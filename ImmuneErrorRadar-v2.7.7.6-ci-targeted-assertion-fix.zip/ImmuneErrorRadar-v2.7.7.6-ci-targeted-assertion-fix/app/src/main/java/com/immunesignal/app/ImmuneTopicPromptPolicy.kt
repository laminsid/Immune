package com.immunesignal.app

/**
 * v1.10.33 UX scope adapter.
 * A user can enter any topic, but the research engine only treats it as an immune-system
 * research steering prompt. It must not become a general-purpose answer engine.
 */
object ImmuneTopicPromptPolicy {
    const val CLAIM_LIMIT: String = "immune_topic_prompt_routing_only_not_biological_proof"

    private val immuneLensTerms = listOf(
        "immune response",
        "inflammation",
        "cytokine",
        "mast cell",
        "barrier tissue",
        "allergy",
        "autoimmunity",
        "viral response",
        "human cohort",
        "dataset accession",
        "outcome labels",
        "control comparator"
    )

    fun shouldApply(topic: String): Boolean = normalizeTopic(topic).length >= 2

    fun normalizeTopic(topic: String): String {
        return topic
            .replace("\r", " ")
            .replace("\n", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(600)
    }

    fun variablesText(topic: String): String {
        val clean = normalizeTopic(topic)
        return (listOf(clean) + immuneLensTerms).filter { it.isNotBlank() }.joinToString(", ")
    }

    fun focusQuestion(topic: String): String {
        val clean = normalizeTopic(topic)
        return "Research this user topic only through an immune-system lens: $clean. " +
            "Look for immune response, inflammation, allergy, autoimmunity, barrier, cytokine, stress-immune, cohort, outcome-label, control/comparator, and public dataset signals. " +
            "If the topic has no usable immune angle, report no usable immune lead instead of answering the non-immune domain."
    }

    fun requiredTermsText(): String {
        return listOf(
            "immune",
            "inflammation",
            "dataset",
            "human",
            "outcome",
            "control"
        ).joinToString(", ")
    }

    fun importedLearningNote(topic: String): String {
        val clean = normalizeTopic(topic)
        return "User research topic for Immune Error Radar: $clean\n" +
            "Scope rule: interpret only from an immune-system perspective. Do not produce general-domain advice. " +
            "Convert the topic into immune research leads, weak leads, dataset queries, missing metadata, contradiction checks, and learning memory. " +
            "If no immune route exists, record that as a no-usable-immune-lead outcome. Claim limit: $CLAIM_LIMIT."
    }

    fun compactUiLine(topic: String): String {
        val clean = normalizeTopic(topic)
        return if (clean.isBlank()) {
            "Autonomous immune research mode"
        } else {
            "Topic: ${clean.take(110)}${if (clean.length > 110) "…" else ""} • immune lens only"
        }
    }
}
