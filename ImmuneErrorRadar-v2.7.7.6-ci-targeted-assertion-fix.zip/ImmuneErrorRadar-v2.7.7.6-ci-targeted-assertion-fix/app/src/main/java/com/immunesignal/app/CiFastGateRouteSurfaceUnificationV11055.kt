package com.immunesignal.app

/**
 * v1.10.55: CI fast-gate and route-surface unification.
 *
 * This is a wiring and GitHub-readiness patch. It keeps v1.10.52 open exploration,
 * v1.10.51 route reconciliation, and v1.10.50 exposome linkage intact while making the
 * default GitHub static-check surface bounded and deterministic. The full release gate
 * remains available for manual/release runs.
 */
object CiFastGateRouteSurfaceUnificationV11055 {
    const val VERSION_LABEL: String = "v1.10.55-alpha-ci-fast-gate-route-surface-unification"
    const val CLAIM_LIMIT: String = "ci_fast_gate_route_surface_unification_not_biological_proof"
    const val DEFAULT_STATIC_GATE: String = "FAST_CI_GATE_DEFAULT"
    const val FULL_STATIC_GATE: String = "FULL_RELEASE_GATE_OPT_IN"
    const val ROUTE_SURFACE_CONTRACT: String = "CORRECTED_ROUTE_SURFACE_MUST_REACH_JSON_UI_EXPORT_AND_LEGACY_CARDS"
    const val ARTIFACT_POLICY: String = "NO_GENERATED_BUILD_CACHE_BINARY_OR_PYTHON_CACHE_ARTIFACTS"

    val requiredFastGateAudits: List<String> = listOf(
        "quiet_json_parse",
        "kotlin_delimiter_audit",
        "kotlin_regex_escape_safety",
        "github_workflow_pipefail_safety",
        "v11050_no_isolated_exposome_paths",
        "v11051_route_reconciliation",
        "v11052_open_exploration_medical_index",
        "v11053_route_linkage_hardening",
        "v11054_github_ci_runtime_surface_hardening",
        "v11055_release_linkage"
    )

    fun summary(): String =
        "v1.10.55 CI gate: $DEFAULT_STATIC_GATE; $FULL_STATIC_GATE; route contract=$ROUTE_SURFACE_CONTRACT; audits=${requiredFastGateAudits.size}; claim-limit=$CLAIM_LIMIT"
}
