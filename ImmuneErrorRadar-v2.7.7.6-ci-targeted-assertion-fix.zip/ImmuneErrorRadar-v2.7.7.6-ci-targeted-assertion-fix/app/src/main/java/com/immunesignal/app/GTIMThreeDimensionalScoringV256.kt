package com.immunesignal.app

/**
 * Standalone GTIM v2.5.6 scoring module.
 *
 * Keeps Data Quality, Novelty, Biological Plausibility, Discovery Value, and Evidence
 * Confidence separate so a rich research question never collapses to scientific zero merely
 * because accession/matrix closure is still missing.
 */
object GTIMThreeDimensionalScoringV256 {
    const val STATUS: String = "THREE_DIMENSIONAL_GRADING_ACTIVE"

    fun score(
        intent: GTIMResearchIntentObjectV255,
        plan: GTIMDataFeedPlanV255,
        report: ResearchGradeMechanismDossierReportV1110,
        evidenceObjects: List<GTIMEvidenceObjectV250>,
        mechanismCandidates: List<GTIMMechanismCandidateV250>,
        routes: List<GTIMCandidateRouteV256>
    ): GTIMThreeDimensionalScoreV256 {
        val dataQuality = (report.matrixReadinessScore + evidenceObjects.size * 8 + report.accessionCandidates.size * 15).coerceIn(0, 100)
        val novelty = (45 + routes.size * 6 + if (intent.active) intent.intentCompletenessScore / 5 else 0).coerceIn(0, 88)
        val plausibility = (intent.routeConstructionScore / 2 + routes.size * 8 + mechanismCandidates.size * 4).coerceIn(0, 86)
        val discoveryValue = ((novelty * 0.35) + (plausibility * 0.35) + (intent.intentCompletenessScore * 0.20) + (plan.dataFeedPlanScore * 0.10)).toInt().coerceIn(0, 90)
        val evidenceConfidence = (dataQuality * 0.65 + report.matrixReadinessScore * 0.35).toInt().coerceIn(0, 86)
        val interpretation = when {
            dataQuality < 20 && discoveryValue >= 55 -> "weak evidence, useful discovery route"
            dataQuality >= 60 -> "evidence route approaching controlled review"
            discoveryValue >= 45 -> "exploratory hypothesis worth feeding with stronger data"
            else -> "early exploratory lead; keep only if scientifically interesting"
        }
        return GTIMThreeDimensionalScoreV256(
            dataQualityScore = dataQuality,
            noveltyScore = novelty,
            biologicalPlausibilityScore = plausibility,
            discoveryValueScore = discoveryValue,
            evidenceConfidenceScore = evidenceConfidence,
            interpretation = interpretation
        )
    }
}
