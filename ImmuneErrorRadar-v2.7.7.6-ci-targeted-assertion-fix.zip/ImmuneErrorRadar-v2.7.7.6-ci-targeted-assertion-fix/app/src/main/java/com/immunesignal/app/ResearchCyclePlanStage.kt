package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.10.6: first executable extraction from ResearchAutopilot.runCycle.
 *
 * This stage is intentionally small: it owns the final plan handoff immediately
 * before network execution. It does not interpret biology and it does not change
 * scoring. Its job is to enforce the search directive budget after cognitive
 * directive + evidence-gain ranking + query-feedback rewrites, so no later
 * helper can accidentally reopen a broad query batch.
 */
data class ResearchCyclePlanStageReport(
    val active: Boolean,
    val version: String,
    val state: String,
    val governingLayer: String,
    val directiveMode: String,
    val inputQueryCount: Int,
    val selectedQueryCount: Int,
    val maxQueries: Int,
    val maxResultsPerQuery: Int,
    val selectedQueryIds: List<String>,
    val rejectedQueryIds: List<String>,
    val warnings: List<String>,
    val handoffTrace: List<String>,
    val nextPhase: String,
    val summary: String,
    val claimLimit: String = "cycle_plan_stage_not_biological_proof"
) {
    companion object {
        fun empty() = ResearchCyclePlanStageReport(
            active = false,
            version = "v1.10.6",
            state = "NOT_EVALUATED",
            governingLayer = "none",
            directiveMode = "unknown",
            inputQueryCount = 0,
            selectedQueryCount = 0,
            maxQueries = 0,
            maxResultsPerQuery = 0,
            selectedQueryIds = emptyList(),
            rejectedQueryIds = emptyList(),
            warnings = emptyList(),
            handoffTrace = emptyList(),
            nextPhase = "No extracted plan stage available.",
            summary = "Cycle plan stage was not evaluated."
        )
    }
}

object ResearchCyclePlanStage {
    /**
     * Enforce a directive after all query rewriting/ranking layers have run.
     * This is the last guard before NcbiClient execution.
     */
    fun enforceSearchBudget(
        directive: ResearchSearchDirective,
        candidateQueries: List<ResearchQuery>
    ): List<ResearchQuery> {
        if (directive.maxQueries <= 0 || directive.isOfflineOnly) return emptyList()
        val bounded = candidateQueries.distinctBy { it.id }
        if (!directive.active) return bounded.take(directive.maxQueries)

        val directiveIds = directive.queries.map { it.id }.toSet()
        val matched = if (directiveIds.isEmpty()) {
            bounded
        } else {
            bounded.filter { it.id in directiveIds }
        }
        if (matched.isNotEmpty()) return matched.take(directive.maxQueries)
        return directive.queries.take(directive.maxQueries)
    }

    fun buildReport(
        directive: ResearchSearchDirective,
        candidateQueries: List<ResearchQuery>,
        selectedQueries: List<ResearchQuery>,
        phaseSpine: ResearchCyclePhaseSpineReport
    ): ResearchCyclePlanStageReport {
        val selectedIds = selectedQueries.map { it.id }
        val selectedIdSet = selectedIds.toSet()
        val rejectedIds = candidateQueries.map { it.id }.filterNot { it in selectedIdSet }.distinct()
        val warnings = mutableListOf<String>()
        if (directive.isOfflineOnly && selectedQueries.isNotEmpty()) {
            warnings += "OFFLINE_DIRECTIVE_HAS_SELECTED_QUERIES"
        }
        if (directive.active && selectedQueries.size > directive.maxQueries) {
            warnings += "SELECTED_QUERY_COUNT_EXCEEDS_DIRECTIVE_BUDGET"
        }
        if (directive.active && directive.queries.isNotEmpty()) {
            val directiveIds = directive.queries.map { it.id }.toSet()
            val outsideDirective = selectedQueries.map { it.id }.filterNot { it in directiveIds }
            if (outsideDirective.isNotEmpty()) {
                warnings += "SELECTED_QUERY_OUTSIDE_ACTIVE_DIRECTIVE:${outsideDirective.take(4).joinToString(",") }"
            }
        }
        val state = when {
            warnings.isNotEmpty() -> "PLAN_WARNING"
            directive.isOfflineOnly -> "OFFLINE_ONLY_PLAN"
            directive.active -> "DIRECTIVE_BOUNDED_PLAN"
            selectedQueries.isEmpty() -> "EMPTY_PLAN"
            else -> "NORMAL_BOUNDED_PLAN"
        }
        val nextPhase = when {
            directive.isOfflineOnly -> "Skip network search; continue local thinking/persist only."
            selectedQueries.isEmpty() -> "No query leaves PLAN; reason/search stack must inspect the directive before running network."
            directive.active -> "Execute only selected directive queries, then re-audit SEARCH phase."
            else -> "Execute bounded normal planner queries."
        }
        val trace = directive.trace.takeLast(6) + listOf(
            "phase_spine=${phaseSpine.state}:${phaseSpine.nextExtractionTarget}",
            "plan_stage:selected=${selectedQueries.size}/${candidateQueries.size}; rejected=${rejectedIds.size}"
        )
        return ResearchCyclePlanStageReport(
            active = true,
            version = "v1.10.6",
            state = state,
            governingLayer = directive.governingLayer,
            directiveMode = directive.mode,
            inputQueryCount = candidateQueries.size,
            selectedQueryCount = selectedQueries.size,
            maxQueries = directive.maxQueries,
            maxResultsPerQuery = directive.maxResultsPerQuery,
            selectedQueryIds = selectedIds,
            rejectedQueryIds = rejectedIds.take(20),
            warnings = warnings,
            handoffTrace = trace,
            nextPhase = nextPhase,
            summary = "Plan stage $state: governing=${directive.governingLayer}; mode=${directive.mode}; selected=${selectedQueries.size}/${candidateQueries.size}; maxQueries=${directive.maxQueries}."
        )
    }

    fun toJson(report: ResearchCyclePlanStageReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("state", report.state)
        .put("governingLayer", report.governingLayer)
        .put("directiveMode", report.directiveMode)
        .put("inputQueryCount", report.inputQueryCount)
        .put("selectedQueryCount", report.selectedQueryCount)
        .put("maxQueries", report.maxQueries)
        .put("maxResultsPerQuery", report.maxResultsPerQuery)
        .put("selectedQueryIds", JSONArray(report.selectedQueryIds))
        .put("rejectedQueryIds", JSONArray(report.rejectedQueryIds))
        .put("warnings", JSONArray(report.warnings))
        .put("handoffTrace", JSONArray(report.handoffTrace))
        .put("nextPhase", report.nextPhase)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)
}
