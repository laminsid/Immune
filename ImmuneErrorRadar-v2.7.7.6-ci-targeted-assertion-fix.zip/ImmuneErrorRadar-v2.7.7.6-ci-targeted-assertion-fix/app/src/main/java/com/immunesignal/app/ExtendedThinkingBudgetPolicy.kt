package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.10.16: Extended thinking budget policy.
 *
 * This is not a sleep/timer hack. It turns "thinking time" into explicit local
 * reasoning passes that must be visible in the report before the engine archives
 * or reframes a stalled dataset route. The policy expands the available Deep
 * Think budget from short review windows to a longer, checkpointed research-review
 * budget while preserving all claim limits: no biology, causality, diagnosis, or
 * treatment is proven by additional thinking.
 */
data class ExtendedThinkingBudgetReport(
    val active: Boolean,
    val version: String,
    val mode: String,
    val minimumPassesRequired: Int,
    val passesExecuted: Int,
    val defaultSessionBudgetMillis: Long,
    val cycleLearningBudgetMillis: Long,
    val priorFastWindowMillis: Long,
    val trigger: String,
    val passSummaries: List<String>,
    val blockedActions: List<String>,
    val nextAction: String,
    val summary: String,
    val claimLimit: String = "extended_thinking_budget_not_biological_proof"
) {
    companion object {
        fun empty() = ExtendedThinkingBudgetReport(
            active = false,
            version = "v1.10.16",
            mode = "NORMAL_THINKING_BUDGET",
            minimumPassesRequired = 0,
            passesExecuted = 0,
            defaultSessionBudgetMillis = RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS,
            cycleLearningBudgetMillis = RuntimeFeatureFlags.DEFAULT_RESEARCH_LEARNING_TIME_LIMIT_MILLIS,
            priorFastWindowMillis = RuntimeFeatureFlags.PRIOR_FAST_THINKING_WINDOW_MILLIS,
            trigger = "No extended thinking trigger.",
            passSummaries = emptyList(),
            blockedActions = listOf("hypothesis_upgrade", "causal_language", "medical_claim"),
            nextAction = "Use normal search/learning gates.",
            summary = "Extended thinking budget was not triggered."
        )
    }
}

object ExtendedThinkingBudgetPolicy {
    fun evaluate(
        executedQueries: List<ResearchQuery>,
        datasetForaging: DatasetForagingReport,
        learningOs: LearningOsReport,
        postSearchThinking: PostSearchThinkingReport,
        thinkingContinuity: ThinkingContinuityReport,
        hypothesisGraph: HypothesisGraphReport,
        cognitiveMomentum: CognitiveMomentumReport,
        linkedSpine: LinkedCognitionSpineReport,
        maxLearningMillis: Long
    ): ExtendedThinkingBudgetReport {
        val noDatasetHandle = datasetForaging.candidates.isEmpty() &&
            datasetForaging.parsedMetadata.isEmpty() &&
            datasetForaging.accessionAcquisitionReport.explicitAccessions.isEmpty() &&
            datasetForaging.accessionAcquisitionReport.weakAccessions.isEmpty()
        val zeroOrThinSearch = executedQueries.isEmpty() || executedQueries.size == 1
        val repeatedGapPressure = learningOs.incident.rootCauses.any {
            it == "NO_DATASET_ACCESSION" || it == "BROAD_QUERY" || it == "NO_CONTROL_SIGNAL" || it == "WRONG_VOCABULARY"
        }
        val shouldExtend = noDatasetHandle || repeatedGapPressure || zeroOrThinSearch ||
            cognitiveMomentum.state.contains("STALLED", ignoreCase = true) ||
            linkedSpine.routeMode.contains("GAP_CLOSURE", ignoreCase = true)
        if (!shouldExtend) return ExtendedThinkingBudgetReport.empty()

        val passes = buildPasses(
            executedQueries = executedQueries,
            datasetForaging = datasetForaging,
            learningOs = learningOs,
            postSearchThinking = postSearchThinking,
            thinkingContinuity = thinkingContinuity,
            hypothesisGraph = hypothesisGraph,
            cognitiveMomentum = cognitiveMomentum,
            linkedSpine = linkedSpine
        )
        val next = when {
            executedQueries.isEmpty() -> "Run one bounded accession-recovery query before archive/reframe; do not end the cycle with zero network queries."
            noDatasetHandle -> "Keep thinking locally, then run only one accession/outcome/control query; archive if no parent evidence appears."
            else -> "Use the selected discriminator and evidence keys; keep claims locked until metadata/control/time/outcome close."
        }
        return ExtendedThinkingBudgetReport(
            active = true,
            version = "v1.10.16",
            mode = "EXTENDED_LOCAL_THINKING_BUDGET",
            minimumPassesRequired = RuntimeFeatureFlags.MIN_AUTONOMOUS_THINKING_PASSES,
            passesExecuted = passes.size,
            defaultSessionBudgetMillis = RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS,
            cycleLearningBudgetMillis = maxLearningMillis.coerceAtLeast(RuntimeFeatureFlags.DEFAULT_RESEARCH_LEARNING_TIME_LIMIT_MILLIS),
            priorFastWindowMillis = RuntimeFeatureFlags.PRIOR_FAST_THINKING_WINDOW_MILLIS,
            trigger = "Dataset/accession gap or thin/zero search requires extended local reasoning before archive/reframe.",
            passSummaries = passes,
            blockedActions = listOf(
                "do_not_stop_after_30_seconds_when_dataset_gap_is_open",
                "do_not_archive_without_zero_query_recovery_attempt",
                "do_not_upgrade_hypothesis_from_thinking_only",
                "do_not_use_causal_or_medical_language"
            ),
            nextAction = next,
            summary = "Extended thinking budget active: ${passes.size} local pass(es), session budget ${formatMillis(RuntimeFeatureFlags.DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS)}, cycle learning budget ${formatMillis(maxLearningMillis)}; claim limit remains extended_thinking_budget_not_biological_proof."
        )
    }

    private fun buildPasses(
        executedQueries: List<ResearchQuery>,
        datasetForaging: DatasetForagingReport,
        learningOs: LearningOsReport,
        postSearchThinking: PostSearchThinkingReport,
        thinkingContinuity: ThinkingContinuityReport,
        hypothesisGraph: HypothesisGraphReport,
        cognitiveMomentum: CognitiveMomentumReport,
        linkedSpine: LinkedCognitionSpineReport
    ): List<String> {
        val rootCauses = learningOs.incident.rootCauses.joinToString(", ").ifBlank { "none" }
        val queryIds = executedQueries.map { it.id }.joinToString(", ").ifBlank { "none" }
        val passes = mutableListOf(
            "Pass 1 — execution reality: executedQueries=${executedQueries.size}; ids=$queryIds; sourceFamilies=${datasetForaging.sourceFamiliesAttempted.joinToString(", ").ifBlank { "none" }}.",
            "Pass 2 — blocker isolation: rootCauses=$rootCauses; accessionState=${datasetForaging.accessionAcquisitionReport.state}; candidates=${datasetForaging.candidates.size}; parsed=${datasetForaging.parsedMetadata.size}.",
            "Pass 3 — discriminator check: graphWeakest=${hypothesisGraph.weakestLink.ifBlank { "unknown" }}; thinkingGate=${postSearchThinking.nextSearchGate.ifBlank { "none" }}; continuity=${thinkingContinuity.state}.",
            "Pass 4 — archive/search decision: momentum=${cognitiveMomentum.state}; spine=${linkedSpine.routeMode}; next=${linkedSpine.nextAction.ifBlank { cognitiveMomentum.nextAction }.take(180)}."
        )
        if (RuntimeFeatureFlags.MIN_AUTONOMOUS_THINKING_PASSES > 4) {
            while (passes.size < RuntimeFeatureFlags.MIN_AUTONOMOUS_THINKING_PASSES) {
                passes += "Pass ${passes.size + 1} — reserve pass: no claim upgrade; preserve evidence keys and require accession/outcome/control/time closure."
            }
        }
        return passes.take(RuntimeFeatureFlags.MIN_AUTONOMOUS_THINKING_PASSES.coerceAtLeast(4))
    }

    fun toJson(report: ExtendedThinkingBudgetReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("mode", report.mode)
        .put("minimumPassesRequired", report.minimumPassesRequired)
        .put("passesExecuted", report.passesExecuted)
        .put("defaultSessionBudgetMillis", report.defaultSessionBudgetMillis)
        .put("cycleLearningBudgetMillis", report.cycleLearningBudgetMillis)
        .put("priorFastWindowMillis", report.priorFastWindowMillis)
        .put("trigger", report.trigger)
        .put("passSummaries", JSONArray(report.passSummaries))
        .put("blockedActions", JSONArray(report.blockedActions))
        .put("nextAction", report.nextAction)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun formatMillis(value: Long): String {
        val minutes = value / (60L * 1000L)
        return "${minutes}m"
    }
}
