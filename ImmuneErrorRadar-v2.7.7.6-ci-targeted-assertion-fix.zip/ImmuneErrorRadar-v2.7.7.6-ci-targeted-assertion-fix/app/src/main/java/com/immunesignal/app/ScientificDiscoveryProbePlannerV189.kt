package com.immunesignal.app

import java.util.Locale

/**
 * v1.8.9: executable discovery probe planner. Token: executable_discovery_probe_plan.
 *
 * v1.8.8 mined latent opportunities. This layer turns the best latent gap into
 * a bounded, executable probe plan: query, evidence pack, pass/fail/kill gates,
 * replay block, and next-cycle route effect. It guides routing only; it never
 * proves biology, diagnosis, treatment, causal mechanism, or immune outcome.
 */
data class DiscoveryProbeStep(
    val stepId: String,
    val label: String,
    val query: String,
    val requiredEvidence: List<String>,
    val passIf: List<String>,
    val failIf: List<String>,
    val killRouteIf: List<String>,
    val routeEffect: String,
    val reason: String
)

data class ScientificDiscoveryProbePlanReport(
    val active: Boolean,
    val version: String,
    val plannerState: String,
    val selectedProbeId: String,
    val selectedProbeQuery: String,
    val probeSteps: List<DiscoveryProbeStep>,
    val evidencePack: List<String>,
    val passCriteria: List<String>,
    val failCriteria: List<String>,
    val killCriteria: List<String>,
    val replayBlockKeys: List<String>,
    val forcedDirectiveTerms: List<String>,
    val forcedEvidenceKeys: List<String>,
    val probeBudget: Int,
    val ifProbeSucceeds: String,
    val ifProbeFails: String,
    val reportLine: String,
    val claimLimit: String = "executable_probe_plan_guides_routing_not_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryProbePlanReport(
            active = false,
            version = "v1.8.9",
            plannerState = "NOT_RUN",
            selectedProbeId = "none",
            selectedProbeQuery = "Run latent gap mining before building an executable probe plan.",
            probeSteps = emptyList(),
            evidencePack = emptyList(),
            passCriteria = emptyList(),
            failCriteria = emptyList(),
            killCriteria = emptyList(),
            replayBlockKeys = emptyList(),
            forcedDirectiveTerms = emptyList(),
            forcedEvidenceKeys = emptyList(),
            probeBudget = 0,
            ifProbeSucceeds = "No probe success policy available.",
            ifProbeFails = "No probe failure policy available.",
            reportLine = "Executable discovery probe planner did not run.",
            claimLimit = "executable_probe_plan_guides_routing_not_proof"
        )
    }
}

object ScientificDiscoveryProbePlannerEngineV189 {
    fun plan(
        gapMiner: ScientificDiscoveryGapMinerReport,
        lineage: ScientificDiscoveryLineageReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport,
        executionPolicy: ScientificDiscoveryExecutionPolicyReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        knowledgeIndex: ScientificKnowledgeIndexReport,
        datasetForaging: DatasetForagingReport
    ): ScientificDiscoveryProbePlanReport {
        if (!gapMiner.active && !deepDiscovery.active && !scientificWeights.active) {
            return ScientificDiscoveryProbePlanReport.empty()
        }

        val selected = gapMiner.latentOpportunities.maxWithOrNull(
            compareBy<LatentDiscoveryOpportunityCard> { it.priority }
                .thenByDescending { it.missingEvidence.size }
                .thenBy { it.opportunityId }
        )
        val baseQuery = selected?.probeQuery?.takeIf { it.isNotBlank() }
            ?: deepDiscovery.decisiveExperiment.nextQuery.takeIf { it.isNotBlank() }
            ?: gapMiner.nextDiscoveryProbe.takeIf { it.isNotBlank() }
            ?: "human immune response RNA-seq outcome severity recovery control longitudinal dataset"

        val evidencePack = normalizeEvidence(
            (selected?.missingEvidence ?: emptyList()) +
                gapMiner.forcedEvidenceKeys +
                outcomeVerifier.unmetEvidenceKeys +
                outcomeVerifier.forcedNextEvidence +
                executionPolicy.forcedEvidenceKeys +
                scientificWeights.decisiveEvidenceDelta +
                lineage.forcedEvidenceKeys +
                deepDiscovery.decisiveExperiment.requiredDatasetFeatures +
                knowledgeIndex.evidenceRequirements
        ).ifEmpty { listOf("minimum_metadata", "outcome_labels", "comparator_control", "time_order") }.take(24)

        val passCriteria = normalizeCriteria(
            (selected?.promoteIf ?: emptyList()) +
                evidencePack.map { "found_$it" } +
                deepDiscovery.decisiveExperiment.strengthenIf +
                outcomeVerifier.successSignals.map { it.evidenceKey }
        ).take(16)
        val failCriteria = normalizeCriteria(
            (selected?.killIf ?: emptyList()) +
                deepDiscovery.decisiveExperiment.weakenIf +
                outcomeVerifier.failureSignals.map { it.evidenceKey } +
                executionPolicy.queryReplayBlocks
        ).take(16)
        val killCriteria = normalizeCriteria(
            deepDiscovery.decisiveExperiment.abandonIf +
                listOfNotNull(
                    "metadata_only_repeats_without_outcome_control_time".takeIf { evidencePack.any { key -> key == "outcome_labels" || key == "comparator_control" || key == "time_order" } },
                    "same_route_replay_without_new_evidence".takeIf { executionPolicy.queryReplayBlocks.isNotEmpty() },
                    "contradiction_or_negative_control_overrides_current_route".takeIf { lineage.contradictionCarryForward.isNotEmpty() }
                )
        ).take(12)

        val steps = buildProbeSteps(
            selected = selected,
            baseQuery = baseQuery,
            evidencePack = evidencePack,
            passCriteria = passCriteria,
            failCriteria = failCriteria,
            killCriteria = killCriteria,
            deepDiscovery = deepDiscovery,
            datasetForaging = datasetForaging
        )
        val replayBlocks = normalizeEvidence(
            executionPolicy.queryReplayBlocks + outcomeVerifier.blockedReplayKeys + killCriteria + gapMiner.blockedBy
        ).take(16)
        val terms = normalizeTerms(
            compactTokens(baseQuery, 24) +
                gapMiner.forcedDirectiveTerms +
                selected?.let { compactTokens(it.label, 12) + compactTokens(it.whyItMatters, 10) }.orEmpty() +
                evidencePack.flatMap { evidenceToTerms(it) } +
                steps.flatMap { compactTokens(it.query, 14) }
        ).take(64)

        val highRisk = replayBlocks.isNotEmpty() || failCriteria.size >= passCriteria.size || datasetForaging.scoreSeparation.routeFitScore >= 85 && datasetForaging.scoreSeparation.datasetUsabilityScore < 70
        val plannerState = when {
            highRisk && evidencePack.contains("outcome_labels") -> "EXECUTE_PROBE_WITH_KILL_SWITCH"
            selected != null && selected.priority >= 85 -> "EXECUTE_HIGH_VALUE_LATENT_PROBE"
            passCriteria.isNotEmpty() -> "EXECUTE_GUARDED_DECISIVE_PROBE"
            else -> "EXECUTE_MINIMUM_EVIDENCE_PROBE"
        }
        val probeBudget = when (plannerState) {
            "EXECUTE_PROBE_WITH_KILL_SWITCH" -> 1
            "EXECUTE_HIGH_VALUE_LATENT_PROBE" -> 2
            else -> 1
        }
        val selectedId = selected?.opportunityId ?: "probe:${stableId(baseQuery)}"
        val successPolicy = "If probe closes ${evidencePack.take(4).joinToString("/")}, allow cautious inspection and rerank the mechanism tournament; do not upgrade biology without controls and repeatability."
        val failurePolicy = "If probe fails ${failCriteria.take(3).joinToString("/").ifBlank { "minimum evidence" }}, cool down this route, block replay keys, and keep the hypothesis dormant until new parent evidence appears."
        val reportLine = "v1.8.9 executable probe plan: $plannerState; probe=$selectedId; evidence=${evidencePack.take(5).joinToString("/")}; budget=$probeBudget; replayBlocks=${replayBlocks.take(3).joinToString("/").ifBlank { "none" }}."
        return ScientificDiscoveryProbePlanReport(
            active = true,
            version = "v1.8.9-executable-discovery-probe-plan",
            plannerState = plannerState,
            selectedProbeId = selectedId,
            selectedProbeQuery = baseQuery.take(420),
            probeSteps = steps.take(4),
            evidencePack = evidencePack,
            passCriteria = passCriteria,
            failCriteria = failCriteria,
            killCriteria = killCriteria,
            replayBlockKeys = replayBlocks,
            forcedDirectiveTerms = terms,
            forcedEvidenceKeys = normalizeEvidence(evidencePack + replayBlocks + steps.flatMap { it.requiredEvidence }).take(24),
            probeBudget = probeBudget,
            ifProbeSucceeds = successPolicy.take(280),
            ifProbeFails = failurePolicy.take(280),
            reportLine = reportLine.take(520),
            claimLimit = "executable_probe_plan_guides_routing_not_proof"
        )
    }

    private fun buildProbeSteps(
        selected: LatentDiscoveryOpportunityCard?,
        baseQuery: String,
        evidencePack: List<String>,
        passCriteria: List<String>,
        failCriteria: List<String>,
        killCriteria: List<String>,
        deepDiscovery: DeepDiscoveryReasoningReport,
        datasetForaging: DatasetForagingReport
    ): List<DiscoveryProbeStep> {
        val firstQuery = enrichQuery(baseQuery, evidencePack)
        val steps = mutableListOf<DiscoveryProbeStep>()
        steps += DiscoveryProbeStep(
            stepId = "probe_step_${stableId(firstQuery)}",
            label = selected?.label ?: "Minimum executable evidence probe",
            query = firstQuery,
            requiredEvidence = evidencePack.take(10),
            passIf = passCriteria.take(8),
            failIf = failCriteria.take(8),
            killRouteIf = killCriteria.take(6),
            routeEffect = if (datasetForaging.scoreSeparation.routeFitScore >= 85) "route_fit_must_be_paid_by_metadata_outcome_control_time" else "guarded_probe_before_route_reuse",
            reason = selected?.whyItMatters ?: "Converts the highest-value missing evidence into a bounded probe before another broad cycle."
        )
        val contradictionQueries = deepDiscovery.contradictionPlan.contradictionQueries.take(2)
        contradictionQueries.forEachIndexed { idx, q ->
            steps += DiscoveryProbeStep(
                stepId = "contradiction_probe_${idx + 1}_${stableId(q)}",
                label = "Contradiction / negative-control probe ${idx + 1}",
                query = enrichQuery(q, evidencePack + "negative_control"),
                requiredEvidence = normalizeEvidence(evidencePack + "falsification_contradiction" + "negative_control").take(10),
                passIf = listOf("contradiction_checked", "negative_control_available"),
                failIf = listOf("no_contradiction_lane", "metadata_only_contradiction"),
                killRouteIf = listOf("negative_control_invalidates_selected_route"),
                routeEffect = "forces objection-first discovery before route upgrade",
                reason = "A high-value probe must survive the strongest objection before it can guide the next route."
            )
        }
        return steps.distinctBy { it.stepId }
    }

    private fun enrichQuery(query: String, evidence: List<String>): String {
        val terms = evidence.flatMap { evidenceToTerms(it) }.distinctBy { it.lowercase(Locale.US) }.take(12)
        return (query.split(Regex("\\s+")) + terms)
            .map { it.trim().trim(',', ';', '.', ':') }
            .filter { it.length >= 3 }
            .distinctBy { it.lowercase(Locale.US) }
            .joinToString(" ")
            .take(520)
    }

    private fun normalizeEvidence(values: List<String>): List<String> = values
        .map { normalizeEvidenceKey(it) }
        .filter { it.isNotBlank() }
        .distinctBy { it.lowercase(Locale.US) }

    private fun normalizeCriteria(values: List<String>): List<String> = values
        .map { it.trim().replace(Regex("\\s+"), "_").lowercase(Locale.US) }
        .map { normalizeEvidenceKey(it) }
        .filter { it.isNotBlank() }
        .distinctBy { it.lowercase(Locale.US) }

    private fun normalizeTerms(values: List<String>): List<String> = values
        .map { it.trim().lowercase(Locale.US).replace(Regex("[^a-z0-9_+/-]"), " ").replace(Regex("\\s+"), " ").trim() }
        .flatMap { it.split(' ') }
        .map { it.trim('-', '+', '/', '_') }
        .filter { it.length >= 3 && it !in stopWords }
        .distinctBy { it.lowercase(Locale.US) }

    private fun compactTokens(text: String, max: Int): List<String> = normalizeTerms(text.split(Regex("\\s+")).take(80)).take(max)

    private fun normalizeEvidenceKey(value: String): String {
        val v = value.lowercase(Locale.US)
        return when {
            v.contains("outcome") || v.contains("recovery") || v.contains("severity") || v.contains("endpoint") -> "outcome_labels"
            v.contains("control") || v.contains("comparator") || v.contains("placebo") -> "comparator_control"
            v.contains("time") || v.contains("longitudinal") || v.contains("serial") || v.contains("follow") || v.contains("baseline") || v.contains("pre_trigger") -> "time_order"
            v.contains("metadata") || v.contains("accession") || v.contains("sample") || v.contains("license") -> "minimum_metadata"
            v.contains("human") || v.contains("patient") || v.contains("phenotype") -> "human_or_patient_phenotype"
            v.contains("negative") || v.contains("contradiction") || v.contains("falsification") -> "falsification_contradiction"
            v.contains("cell") || v.contains("tissue") -> "cell_tissue_context"
            v.contains("replication") || v.contains("external") || v.contains("repeat") -> "replication_external_validation"
            v.contains("direction") || v.contains("effect") -> "effect_direction"
            v.contains("route") && v.contains("replay") -> "query_replay_block"
            else -> v.replace(Regex("[^a-z0-9_]+"), "_").trim('_').take(64)
        }
    }

    private fun evidenceToTerms(key: String): List<String> = when (normalizeEvidenceKey(key)) {
        "outcome_labels" -> listOf("outcome", "severity", "recovery", "endpoint", "prognosis")
        "comparator_control" -> listOf("control", "comparator", "placebo", "negative_control")
        "time_order" -> listOf("longitudinal", "time_course", "follow_up", "baseline", "serial")
        "minimum_metadata" -> listOf("metadata", "accession", "sample_size", "license", "condition")
        "human_or_patient_phenotype" -> listOf("human", "patient", "phenotype", "clinical")
        "falsification_contradiction" -> listOf("contradiction", "negative_control", "null_result", "failed_replication")
        "cell_tissue_context" -> listOf("cell_type", "tissue", "single_cell", "epithelial")
        "replication_external_validation" -> listOf("replication", "external_validation", "independent_cohort")
        "effect_direction" -> listOf("effect_direction", "increase", "decrease", "reversal")
        else -> listOf(key)
    }

    private fun stableId(seed: String): String = seed.lowercase(Locale.US).fold(7) { acc, ch -> acc * 31 + ch.code }.let { kotlin.math.abs(it).toString(36) }

    private val stopWords = setOf(
        "and", "or", "the", "with", "without", "from", "this", "that", "into", "before", "after", "should", "must", "only", "route", "cycle", "query", "search", "dataset", "evidence", "probe"
    )
}
