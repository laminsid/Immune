package com.immunesignal.app

import java.util.Locale

/**
 * v1.9.3: executable quality runbook. Token: executable_quality_runbook.
 *
 * v1.9.2 decides whether a strategy is execution-worthy. This compiler turns
 * that decision into a compact runbook: the one allowed mode, the primary
 * query clause, hard stop conditions, pass/fail signals, and the exact evidence
 * checklist that must be closed before the route can consume more research
 * budget. It guides routing only; it never proves biology, diagnosis,
 * treatment, causality, mechanism, or immune outcome.
 */
data class DiscoveryRunbookStepCard(
    val stepId: String,
    val label: String,
    val action: String,
    val queryClause: String,
    val requiredEvidence: List<String>,
    val passIf: List<String>,
    val stopIf: List<String>,
    val prevents: List<String>
)

data class ScientificDiscoveryRunbookReport(
    val active: Boolean,
    val version: String,
    val runbookState: String,
    val selectedRunMode: String,
    val primaryQueryClause: String,
    val executionBudget: Int,
    val evidenceChecklist: List<String>,
    val hardStops: List<String>,
    val passSignals: List<String>,
    val failSignals: List<String>,
    val blockedReplayKeys: List<String>,
    val forcedDirectiveTerms: List<String>,
    val forcedEvidenceKeys: List<String>,
    val routeDecision: String,
    val runbookSteps: List<DiscoveryRunbookStepCard>,
    val reportLine: String,
    val claimLimit: String = "executable_quality_runbook_routing_only_not_biological_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryRunbookReport(
            active = false,
            version = "v1.9.3",
            runbookState = "NOT_RUN",
            selectedRunMode = "NO_RUNBOOK",
            primaryQueryClause = "Run discovery quality gate before compiling an executable runbook.",
            executionBudget = 0,
            evidenceChecklist = emptyList(),
            hardStops = emptyList(),
            passSignals = emptyList(),
            failSignals = emptyList(),
            blockedReplayKeys = emptyList(),
            forcedDirectiveTerms = emptyList(),
            forcedEvidenceKeys = emptyList(),
            routeDecision = "No route decision compiled.",
            runbookSteps = emptyList(),
            reportLine = "Executable quality runbook did not run.",
            claimLimit = "executable_quality_runbook_routing_only_not_biological_proof"
        )
    }
}

object ScientificDiscoveryRunbookEngineV193 {
    fun compile(
        qualityGate: ScientificDiscoveryQualityGateReport,
        metaStrategy: ScientificDiscoveryMetaStrategyReport,
        currentProbePlan: ScientificDiscoveryProbePlanReport,
        probeOutcomeLedger: ScientificDiscoveryProbeOutcomeLedgerReport,
        executionPolicy: ScientificDiscoveryExecutionPolicyReport,
        stressTest: ScientificDiscoveryStressTestReport,
        gapMiner: ScientificDiscoveryGapMinerReport,
        lineage: ScientificDiscoveryLineageReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        datasetForaging: DatasetForagingReport,
        learningOs: LearningOsReport
    ): ScientificDiscoveryRunbookReport {
        if (!qualityGate.active && !metaStrategy.active && !currentProbePlan.active && !gapMiner.active) {
            return ScientificDiscoveryRunbookReport.empty()
        }

        val gateState = qualityGate.gateState.uppercase(Locale.US)
        val selectedMode = when {
            gateState.contains("BLOCK") -> "REROUTE_OR_ARCHIVE_ONLY"
            gateState.contains("HOLD") -> "CORE_EVIDENCE_CLOSURE_ONLY"
            gateState.contains("INSPECT") -> "ONE_BOUNDED_INSPECTION"
            gateState.contains("PASS") -> "BOUNDED_EXECUTION_WITH_GATES"
            else -> "GUARDED_EXECUTION"
        }
        val budget = when (selectedMode) {
            "REROUTE_OR_ARCHIVE_ONLY" -> 0
            "CORE_EVIDENCE_CLOSURE_ONLY" -> 1
            "ONE_BOUNDED_INSPECTION" -> 1
            "BOUNDED_EXECUTION_WITH_GATES" -> metaStrategy.routeBudget.coerceIn(1, 3)
            else -> 1
        }
        val evidence = normalizeEvidence(
            qualityGate.forcedEvidenceKeys + qualityGate.requiredBeforeRun +
                metaStrategy.forcedEvidenceKeys + currentProbePlan.evidencePack +
                currentProbePlan.forcedEvidenceKeys + probeOutcomeLedger.unresolvedEvidenceKeys +
                executionPolicy.forcedEvidenceKeys + stressTest.forcedEvidenceKeys +
                gapMiner.forcedEvidenceKeys + lineage.forcedEvidenceKeys
        ).ifEmpty { listOf("minimum_metadata", "outcome_labels", "comparator_control", "time_order") }.take(36)

        val blockedReplay = normalizeEvidence(
            currentProbePlan.replayBlockKeys + probeOutcomeLedger.replayPenaltyKeys + executionPolicy.queryReplayBlocks +
                if (!qualityGate.allowExecution) listOf("same_query_replay", "metadata_only_replay") else emptyList()
        ).take(20)

        val hardStops = buildHardStops(
            qualityGate = qualityGate,
            selectedMode = selectedMode,
            evidence = evidence,
            blockedReplay = blockedReplay,
            datasetForaging = datasetForaging,
            learningOs = learningOs
        )
        val passSignals = evidence.map { key -> "closed_$key" }.take(12) + when {
            qualityGate.allowExecution -> listOf("quality_gate_allows_bounded_execution")
            else -> emptyList()
        }
        val failSignals = (hardStops + probeOutcomeLedger.failSignals.map { it.evidenceKey }).map { it.take(90) }.distinct().take(16)
        val primaryQuery = buildPrimaryQuery(
            qualityGate = qualityGate,
            currentProbePlan = currentProbePlan,
            gapMiner = gapMiner,
            deepDiscovery = deepDiscovery,
            evidence = evidence
        )
        val steps = buildSteps(selectedMode, primaryQuery, evidence, hardStops, passSignals, blockedReplay)
        val routeDecision = when (selectedMode) {
            "REROUTE_OR_ARCHIVE_ONLY" -> "Do not spend a normal discovery cycle on this route; require new parent evidence or archive it as dormant."
            "CORE_EVIDENCE_CLOSURE_ONLY" -> "Run only the evidence-closure probe; no broad hypothesis or mechanism expansion."
            "ONE_BOUNDED_INSPECTION" -> "Allow one inspection pass with hard stops; no upgrade language."
            "BOUNDED_EXECUTION_WITH_GATES" -> "Execute the selected strategy only with pass/fail/kill gates and replay protection."
            else -> "Run guarded execution with evidence checklist visible."
        }
        val forcedTerms = normalizeTerms(
            qualityGate.forcedDirectiveTerms + metaStrategy.forcedDirectiveTerms + currentProbePlan.forcedDirectiveTerms +
                stressTest.forcedNextTerms + gapMiner.forcedDirectiveTerms + compactTokens(primaryQuery, 48) + evidence.flatMap { evidenceToTerms(it) }
        ).take(96)
        val state = when {
            hardStops.any { it.contains("block", true) || it.contains("reroute", true) } -> "RUNBOOK_BLOCKS_BROAD_EXECUTION"
            selectedMode.contains("CLOSURE") -> "RUNBOOK_CORE_EVIDENCE_CLOSURE"
            selectedMode.contains("INSPECTION") -> "RUNBOOK_LIMITED_INSPECTION"
            else -> "RUNBOOK_READY_WITH_GATES"
        }
        val line = "v1.9.3 executable quality runbook: $state; mode=$selectedMode; budget=$budget; evidence=${evidence.take(5).joinToString("/")}; hardStops=${hardStops.size}."
        return ScientificDiscoveryRunbookReport(
            active = true,
            version = "v1.9.3-executable-quality-runbook",
            runbookState = state,
            selectedRunMode = selectedMode,
            primaryQueryClause = primaryQuery.take(520),
            executionBudget = budget,
            evidenceChecklist = evidence,
            hardStops = hardStops,
            passSignals = passSignals.distinct().take(18),
            failSignals = failSignals,
            blockedReplayKeys = blockedReplay,
            forcedDirectiveTerms = forcedTerms,
            forcedEvidenceKeys = evidence,
            routeDecision = routeDecision.take(360),
            runbookSteps = steps,
            reportLine = line.take(620),
            claimLimit = "executable_quality_runbook_routing_only_not_biological_proof"
        )
    }

    private fun buildPrimaryQuery(
        qualityGate: ScientificDiscoveryQualityGateReport,
        currentProbePlan: ScientificDiscoveryProbePlanReport,
        gapMiner: ScientificDiscoveryGapMinerReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        evidence: List<String>
    ): String {
        val base = listOf(
            currentProbePlan.selectedProbeQuery,
            gapMiner.nextDiscoveryProbe,
            deepDiscovery.decisiveExperiment.nextQuery,
            qualityGate.executionDecision
        ).firstOrNull { it.isNotBlank() && !it.contains("no ", true) } ?: "human immune dataset RNA-seq outcome control longitudinal metadata"
        val evidenceTerms = evidence.flatMap { evidenceToTerms(it) }.distinct().take(16).joinToString(" ")
        return listOf(base, evidenceTerms).joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }

    private fun buildHardStops(
        qualityGate: ScientificDiscoveryQualityGateReport,
        selectedMode: String,
        evidence: List<String>,
        blockedReplay: List<String>,
        datasetForaging: DatasetForagingReport,
        learningOs: LearningOsReport
    ): List<String> {
        val stops = mutableListOf<String>()
        if (!qualityGate.allowExecution || selectedMode == "REROUTE_OR_ARCHIVE_ONLY") stops += "block_broad_execution_until_new_parent_evidence"
        if (blockedReplay.isNotEmpty()) stops += "stop_if_same_query_or_probe_replays_without_new_evidence"
        if (datasetForaging.scoreSeparation.routeFitScore >= 85 && datasetForaging.scoreSeparation.datasetUsabilityScore < 70) stops += "stop_if_route_fit_remains_high_but_usability_below_70"
        if (datasetForaging.candidates.isNotEmpty() && datasetForaging.parsedMetadata.isEmpty()) stops += "stop_if_candidate_remains_metadata_or_title_only"
        if (evidence.any { it.contains("outcome", true) }) stops += "stop_if_no_outcome_recovery_severity_endpoint_labels"
        if (evidence.any { it.contains("control", true) || it.contains("comparator", true) }) stops += "stop_if_no_control_or_comparator_labels"
        if (evidence.any { it.contains("time", true) }) stops += "stop_if_no_longitudinal_or_time_order_signal"
        if (learningOs.incident.rootCauses.any { it.contains("NO_OUTCOME", true) }) stops += "stop_if_learning_os_repeats_no_outcome_labels"
        return stops.distinct().take(16)
    }

    private fun buildSteps(
        selectedMode: String,
        primaryQuery: String,
        evidence: List<String>,
        hardStops: List<String>,
        passSignals: List<String>,
        blockedReplay: List<String>
    ): List<DiscoveryRunbookStepCard> {
        val closureKeys = evidence.take(6)
        val inspect = DiscoveryRunbookStepCard(
            stepId = "runbook_step_1_evidence_closure",
            label = "Execute the narrow evidence-closure query",
            action = selectedMode,
            queryClause = primaryQuery.take(420),
            requiredEvidence = closureKeys,
            passIf = passSignals.take(6),
            stopIf = hardStops.take(6),
            prevents = listOf("metadata_only_progress", "route_fit_only_upgrade", "unbounded_query_replay") + blockedReplay.take(4)
        )
        val verify = DiscoveryRunbookStepCard(
            stepId = "runbook_step_2_verify_or_cooldown",
            label = "Verify closure before rewarding the route",
            action = "VERIFY_EVIDENCE_CLOSURE_OR_COOLDOWN",
            queryClause = "Do not add a second broad query until the checklist is closed.",
            requiredEvidence = closureKeys,
            passIf = listOf("evidence_closure_score_improves", "at_least_one_core_key_closed"),
            stopIf = listOf("same_gap_repeats", "same_query_replay", "no_new_parent_evidence"),
            prevents = listOf("false_learning_reward", "belief_reactivation_without_evidence")
        )
        return listOf(inspect, verify)
    }

    private fun normalizeEvidence(values: List<String>): List<String> = values
        .map { it.trim().lowercase(Locale.US).replace(Regex("[^a-z0-9_]+"), "_").trim('_') }
        .filter { it.isNotBlank() && it != "none" && it != "unknown" }
        .distinct()

    private fun normalizeTerms(values: List<String>): List<String> = values
        .flatMap { it.split(Regex("\\s+")) }
        .map { it.trim().lowercase(Locale.US).replace(Regex("[^a-z0-9_+-]"), "") }
        .filter { it.length >= 3 && it !in stopTerms }
        .distinct()

    private fun compactTokens(text: String, max: Int): List<String> = normalizeTerms(listOf(text)).take(max)

    private fun evidenceToTerms(key: String): List<String> = when {
        key.contains("outcome", true) -> listOf("outcome", "recovery", "severity", "endpoint")
        key.contains("time", true) -> listOf("longitudinal", "time-course", "serial", "follow-up")
        key.contains("control", true) || key.contains("comparator", true) -> listOf("control", "comparator", "placebo", "negative control")
        key.contains("metadata", true) -> listOf("metadata", "sample size", "condition labels", "license")
        key.contains("human", true) -> listOf("human", "patient", "clinical cohort")
        else -> compactTokens(key.replace('_', ' '), 6)
    }

    private val stopTerms = setOf("the", "and", "with", "for", "from", "that", "this", "into", "only", "before", "after", "because", "without", "route", "query")
}
