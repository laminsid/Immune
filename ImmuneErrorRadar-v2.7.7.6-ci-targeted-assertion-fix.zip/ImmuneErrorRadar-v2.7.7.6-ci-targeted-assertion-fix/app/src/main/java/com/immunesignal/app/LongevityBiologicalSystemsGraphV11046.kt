package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.46: Longevity & Biological Systems Graph.
 *
 * A research-routing layer that converts lifestyle/exposure topics into falsifiable
 * biomedical search paths. It links exposure terms to pathways, measurable biomarkers,
 * accession/dataset lookup templates, outcomes, and contradiction searches.
 *
 * Canonical path: Exposure → Pathway → Biomarker → Dataset → Outcome → Contradiction.
 * Boundary: this layer is not a wellness coach, treatment recommender, supplement
 * advisor, dosing engine, diagnosis engine, or personal health recommendation system.
 * Herbs, foods, vitamins, sleep, exercise, environment, and toxins are handled only as
 * research exposures/noise/control variables for scientists and lab-facing workflows.
 */
data class BiologicalSystemsModuleCard(
    val moduleId: String,
    val label: String,
    val laneId: String,
    val matchedTerms: List<String>,
    val biomarkers: List<String>,
    val lookupTerms: List<String>,
    val datasetTemplates: List<String>,
    val contradictionTerms: List<String>,
    val invalidators: List<String>
)

data class ExposurePathwayCard(
    val exposure: String,
    val pathway: String,
    val biomarkers: List<String>,
    val datasetTemplate: String,
    val outcomeTerms: List<String>,
    val contradictionTemplate: String
)

data class BiologicalSystemEdge(
    val fromNode: String,
    val relation: String,
    val toNode: String,
    val evidenceGate: String
)

data class LongevityBiologicalSystemsReport(
    val active: Boolean,
    val state: String,
    val selectedLane: String,
    val selectedModules: List<String>,
    val moduleCards: List<BiologicalSystemsModuleCard>,
    val exposurePathways: List<ExposurePathwayCard>,
    val graphEdges: List<BiologicalSystemEdge>,
    val fastRetrievalPartitions: List<String>,
    val biomarkersRequired: List<String>,
    val datasetQueryTemplates: List<String>,
    val contradictionSearchTerms: List<String>,
    val linkedLayers: List<String>,
    val missingData: List<String>,
    val invalidators: List<String>,
    val reportSummaryFields: List<String>,
    val guardrails: List<String>,
    val nextResearchQuestion: String,
    val nextAction: String,
    val claimLimit: String = LongevityBiologicalSystemsGraphV11046.CLAIM_LIMIT
) {
    companion object {
        fun empty() = LongevityBiologicalSystemsReport(
            active = false,
            state = "NOT_EVALUATED",
            selectedLane = "OFF",
            selectedModules = emptyList(),
            moduleCards = emptyList(),
            exposurePathways = emptyList(),
            graphEdges = emptyList(),
            fastRetrievalPartitions = emptyList(),
            biomarkersRequired = emptyList(),
            datasetQueryTemplates = emptyList(),
            contradictionSearchTerms = emptyList(),
            linkedLayers = emptyList(),
            missingData = emptyList(),
            invalidators = emptyList(),
            reportSummaryFields = emptyList(),
            guardrails = emptyList(),
            nextResearchQuestion = "No longevity or biological systems route evaluated.",
            nextAction = "Run ontology and evidence-prior routing first."
        )
    }
}

object LongevityBiologicalSystemsGraphV11046 {
    const val CLAIM_LIMIT: String = "longevity_biological_systems_research_only_not_health_advice"

    val knowledgeModules: List<String> = listOf(
        "immune",
        "viral",
        "metabolic",
        "cardiovascular",
        "neurological",
        "endocrine_hpa",
        "mitochondrial",
        "nutrition",
        "drugs",
        "herbs_exposures",
        "longevity_biomarkers"
    )

    private val commonGuardrails = listOf(
        "research routing only",
        "no patient diagnosis",
        "no treatment recommendation",
        "no supplement protocol",
        "no dose recommendation",
        "no dose or personal health advice",
        "herbs, foods, vitamins, sleep, exercise, environment, and toxins are exposure/noise/control variables only",
        "contradiction search is mandatory before any link can strengthen",
        "biomarker and dataset closure must precede mechanism language"
    )

    private val requiredSummaryFields = listOf(
        "selected_biological_pathway",
        "why_selected",
        "required_biomarkers",
        "missing_data",
        "what_would_falsify",
        "next_search"
    )

    private data class LaneDefinition(
        val laneId: String,
        val label: String,
        val modules: List<String>,
        val triggers: List<String>,
        val exposure: String,
        val pathway: String,
        val biomarkers: List<String>,
        val lookupTerms: List<String>,
        val datasetTemplates: List<String>,
        val outcomeTerms: List<String>,
        val contradictionTerms: List<String>,
        val graphEdges: List<BiologicalSystemEdge>,
        val invalidators: List<String>,
        val priority: Int
    )

    private val lanes = listOf(
        LaneDefinition(
            laneId = "CIRCADIAN_SLEEP_INTELLIGENCE",
            label = "Circadian / Sleep Intelligence",
            modules = listOf("neurological", "endocrine_hpa", "immune", "metabolic", "longevity_biomarkers"),
            triggers = listOf("sleep", "circadian", "insomnia", "melatonin", "light exposure", "night eating", "screen", "screens", "blue light", "hrv", "cortisol", "chronotype", "shift work", "نوم", "ساعة بيولوجية"),
            exposure = "sleep/light/meal-timing exposure",
            pathway = "circadian-HPA-autonomic-inflammatory pathway",
            biomarkers = listOf("cortisol", "HRV", "CRP", "IL-6", "TNF-alpha", "glucose", "blood pressure", "sleep timing"),
            lookupTerms = listOf("sleep inflammation", "circadian cortisol HRV", "night eating glucose inflammation", "screen light immune", "actigraphy cytokines", "GSE", "PRJNA"),
            datasetTemplates = listOf("sleep inflammation CRP IL-6 HRV cohort GSE", "circadian autoimmune cortisol cytokine dataset", "night eating glucose immune longitudinal dataset"),
            outcomeTerms = listOf("inflammation", "immune response", "autonomic stress", "metabolic dysregulation", "fatigue", "autoimmune flare"),
            contradictionTerms = listOf("sleep inflammation no association", "circadian cortisol cytokine failed replication", "HRV immune marker weak evidence", "night eating inflammation confounder control"),
            graphEdges = listOf(
                BiologicalSystemEdge("sleep/light timing", "modulates", "cortisol/HRV", "time_order"),
                BiologicalSystemEdge("cortisol/HRV", "links_to", "CRP/IL-6/TNF-alpha", "biomarker_panel"),
                BiologicalSystemEdge("circadian disruption", "confounded_by", "shift work/stress/obesity", "negative_control")
            ),
            invalidators = listOf("No objective sleep/light timing field exists", "No inflammatory or autonomic biomarker exists", "Only subjective sleep narrative exists", "No time order or control/comparator exists"),
            priority = 105
        ),
        LaneDefinition(
            laneId = "METABOLIC_IMMUNE_LANE",
            label = "Metabolic-Immune Lane",
            modules = listOf("metabolic", "immune", "cardiovascular", "mitochondrial", "longevity_biomarkers"),
            triggers = listOf("glucose", "insulin", "hba1c", "diabetes", "obesity", "metabolic", "lipids", "triglyceride", "cholesterol", "inflammation", "mitochondria", "سكري", "سمنة"),
            exposure = "glucose/insulin/lipid/adiposity exposure",
            pathway = "metabolic-inflammatory-mitochondrial pathway",
            biomarkers = listOf("glucose", "HbA1c", "insulin", "lipids", "CRP", "IL-6", "TNF-alpha", "blood pressure", "VO2max"),
            lookupTerms = listOf("glucose immune inflammation", "insulin resistance cytokines", "obesity CRP IL-6", "lipids immune phenotype", "metabolic inflammation cohort", "GSE", "PRJNA"),
            datasetTemplates = listOf("glucose immune cytokines cohort dataset", "insulin resistance CRP IL-6 transcriptome GSE", "exercise glucose immune longitudinal dataset"),
            outcomeTerms = listOf("chronic inflammation", "diabetes", "cardiovascular risk", "immune activation", "mitochondrial stress"),
            contradictionTerms = listOf("glucose immune no association", "insulin resistance cytokines weak replication", "obesity inflammation confounder adjusted", "metabolic immune negative control"),
            graphEdges = listOf(
                BiologicalSystemEdge("glucose/insulin", "affects", "immune activation", "biomarker_panel"),
                BiologicalSystemEdge("adiposity/lipids", "links_to", "CRP/IL-6/TNF-alpha", "control_or_comparator"),
                BiologicalSystemEdge("exercise/VO2max", "modifies", "metabolic inflammation", "longitudinal_time_order")
            ),
            invalidators = listOf("No glucose/HbA1c/insulin/lipid field exists", "No inflammatory marker exists", "No BMI/adiposity or medication confounder control exists", "No comparator or longitudinal ordering exists"),
            priority = 110
        ),
        LaneDefinition(
            laneId = "MITOCHONDRIAL_FATIGUE_LANE",
            label = "Mitochondrial & Fatigue Lane",
            modules = listOf("mitochondrial", "immune", "neurological", "viral", "longevity_biomarkers"),
            triggers = listOf("mitochondria", "mtdna", "fatigue", "me/cfs", "cfs", "long covid", "energy", "oxidative stress", "metabolomics", "lactate", "atp", "post-exertional", "تعب"),
            exposure = "fatigue/post-viral/energy metabolism exposure",
            pathway = "mitochondrial-oxidative-stress-metabolomics pathway",
            biomarkers = listOf("lactate", "ATP", "oxidative stress", "metabolomics", "CRP", "IL-6", "TNF-alpha", "VO2max", "HRV"),
            lookupTerms = listOf("mitochondrial fatigue metabolomics", "ME/CFS oxidative stress dataset", "Long COVID mitochondrial metabolomics", "post-exertional malaise cytokines", "GSE", "PRJNA", "MetaboLights"),
            datasetTemplates = listOf("mitochondrial fatigue metabolomics dataset", "ME/CFS cytokine metabolomics control cohort", "Long COVID mitochondrial transcriptome GSE"),
            outcomeTerms = listOf("fatigue severity", "post-exertional malaise", "energy metabolism", "oxidative stress", "functional impairment"),
            contradictionTerms = listOf("mitochondrial fatigue no association", "ME/CFS metabolomics failed replication", "Long COVID mitochondrial weak evidence", "oxidative stress fatigue negative control"),
            graphEdges = listOf(
                BiologicalSystemEdge("post-viral/fatigue exposure", "routes_to", "mitochondrial/metabolomic markers", "dataset_accession"),
                BiologicalSystemEdge("oxidative stress", "links_to", "immune cytokines", "control_or_comparator"),
                BiologicalSystemEdge("fatigue outcome", "requires", "severity/time-course label", "outcome_labels")
            ),
            invalidators = listOf("Fatigue appears without severity or time-course labels", "No metabolomics/mitochondrial marker exists", "No viral or control comparator context exists", "Only narrative fatigue terms exist"),
            priority = 108
        ),
        LaneDefinition(
            laneId = "VACCINE_IMMUNE_RESPONSE_LANE",
            label = "Vaccine Immune-Response Lane",
            modules = listOf("immune", "viral", "longevity_biomarkers"),
            triggers = listOf("vaccine", "vaccination", "immunization", "immune response", "antibody", "t cell response", "t-cell response", "adjuvant", "booster", "neutralization", "serology"),
            exposure = "vaccine/antigen immune-response exposure",
            pathway = "vaccine-antigen-antibody-T-cell-cytokine pathway",
            biomarkers = listOf("antibody titer", "neutralization", "T-cell subsets", "IFN-gamma", "IL-6", "TNF-alpha", "CRP", "serology"),
            lookupTerms = listOf("vaccine immune response cohort", "vaccination antibody titer T cell", "vaccine cytokine response dataset", "ImmPort", "SDY", "GSE", "PRJNA", "control", "longitudinal"),
            datasetTemplates = listOf("vaccine immune response human cohort SDY ImmPort", "vaccination antibody T-cell cytokine longitudinal dataset", "vaccine response control comparator GSE PRJNA"),
            outcomeTerms = listOf("antibody response", "T-cell response", "seroconversion", "neutralization", "reactogenicity", "immune durability"),
            contradictionTerms = listOf("vaccine immune response no association", "vaccine response heterogeneity", "failed replication vaccine cytokine", "vaccine response negative control"),
            graphEdges = listOf(
                BiologicalSystemEdge("vaccine/antigen exposure", "routes_to", "antibody/T-cell response", "human_or_patient_data"),
                BiologicalSystemEdge("immune readout", "requires", "control/comparator and time order", "control_or_comparator"),
                BiologicalSystemEdge("response claim", "must_face", "heterogeneity/null-result evidence", "contradiction_search")
            ),
            invalidators = listOf("No explicit vaccine/antigen exposure exists", "No antibody/T-cell/serology outcome exists", "No baseline or comparator exists", "No longitudinal/time-order field exists"),
            priority = 125
        ),
        LaneDefinition(
            laneId = "DRUG_PERTURBATION_MICROBIOME_BARRIER_IMMUNE_LANE",
            label = "Drug Perturbation / Microbiome-Barrier Immune Lane",
            modules = listOf("drugs", "immune", "metabolic", "nutrition", "viral"),
            triggers = listOf("antibiotic", "antibiotics", "microbiome", "dysbiosis", "gut barrier", "barrier", "medication", "drug perturbation", "antimicrobial", "flora"),
            exposure = "antibiotic/drug perturbation exposure",
            pathway = "drug-microbiome-barrier-immune-inflammatory pathway",
            biomarkers = listOf("microbiome composition", "CRP", "IL-6", "TNF-alpha", "WBC/RBC", "IgA", "barrier markers", "metabolomics"),
            lookupTerms = listOf("antibiotics immune response microbiome", "antibiotic perturbation cytokines", "microbiome barrier inflammation cohort", "antibiotic transcriptome GSE", "PRJNA", "control", "longitudinal"),
            datasetTemplates = listOf("antibiotics immune response microbiome longitudinal dataset", "antibiotic perturbation cytokine control cohort GSE", "microbiome barrier inflammation PRJNA control"),
            outcomeTerms = listOf("immune modulation", "microbiome shift", "barrier inflammation", "cytokine response", "infection susceptibility"),
            contradictionTerms = listOf("antibiotics immune response no association", "antibiotic microbiome immune weak evidence", "antibiotic cytokine failed replication", "microbiome inflammation negative control"),
            graphEdges = listOf(
                BiologicalSystemEdge("antibiotic exposure", "perturbs", "microbiome/barrier context", "exposure_measurement"),
                BiologicalSystemEdge("microbiome/barrier context", "links_to", "immune cytokines", "biomarker_panel"),
                BiologicalSystemEdge("drug perturbation", "requires", "no treatment/dose/ranking claim", "claim_guard")
            ),
            invalidators = listOf("No antibiotic/drug exposure field exists", "No microbiome/barrier or immune biomarker exists", "No untreated/control comparator exists", "Source drifts into treatment/dose/ranking advice"),
            priority = 123
        ),
        LaneDefinition(
            laneId = "IMMUNE_AGING_IMMUNOSENESCENCE_LANE",
            label = "Immune Aging / Immunosenescence Lane",
            modules = listOf("immune", "viral", "longevity_biomarkers", "endocrine_hpa"),
            triggers = listOf("immunosenescence", "immune aging", "aging", "senescence", "cmv", "cytomegalovirus", "t-cell exhaustion", "t cell exhaustion", "exhaustion", "vaccine response", "inflammaging", "telomere", "شيخوخة"),
            exposure = "age/CMV/chronic immune activation exposure",
            pathway = "CMV-T-cell-exhaustion-inflammaging pathway",
            biomarkers = listOf("CMV serostatus", "T-cell subsets", "T-cell exhaustion", "CRP", "IL-6", "TNF-alpha", "WBC/RBC", "platelets", "vaccine response"),
            lookupTerms = listOf("CMV immunosenescence T-cell exhaustion", "immune aging vaccine response", "inflammaging IL-6 CRP", "senescence T cell cohort", "GSE", "ImmPort", "SDY"),
            datasetTemplates = listOf("CMV immunosenescence T cell exhaustion GSE", "immune aging vaccine response ImmPort SDY", "inflammaging CRP IL-6 longitudinal cohort"),
            outcomeTerms = listOf("immune aging", "vaccine response", "chronic inflammation", "T-cell exhaustion", "infection susceptibility"),
            contradictionTerms = listOf("CMV immunosenescence no association", "T-cell exhaustion aging failed replication", "immune aging vaccine response weak evidence", "inflammaging confounder adjusted"),
            graphEdges = listOf(
                BiologicalSystemEdge("CMV/chronic antigen exposure", "associates_with", "T-cell exhaustion", "human_or_patient_data"),
                BiologicalSystemEdge("T-cell exhaustion", "links_to", "vaccine response", "outcome_labels"),
                BiologicalSystemEdge("age", "confounded_by", "comorbidity/medication/stress", "negative_control")
            ),
            invalidators = listOf("No age/CMV/serostatus field exists", "No immune-cell phenotype exists", "No vaccine or immune outcome exists", "No age/comorbidity comparator exists"),
            priority = 104
        ),
        LaneDefinition(
            laneId = "TOXIN_PLASTIC_ENVIRONMENT_EXPOSURE_LANE",
            label = "Toxin / Plastic / Environment Exposure Lane",
            modules = listOf("herbs_exposures", "endocrine_hpa", "immune", "metabolic", "cardiovascular", "longevity_biomarkers"),
            triggers = listOf("plastic", "microplastic", "phthalate", "bpa", "pollution", "air quality", "pm2.5", "smoking", "alcohol", "toxin", "toxic", "pesticide", "endocrine disruptor", "environment", "تلوث", "بلاستيك"),
            exposure = "toxin/plastic/pollution/smoking/alcohol exposure",
            pathway = "environment-endocrine-immune-inflammatory pathway",
            biomarkers = listOf("CRP", "IL-6", "TNF-alpha", "cortisol", "hormones", "lipids", "blood pressure", "WBC/RBC", "platelets"),
            lookupTerms = listOf("microplastic inflammation immune", "BPA phthalate endocrine immune", "PM2.5 cytokines CRP", "smoking immune biomarkers", "alcohol inflammation cohort", "GSE", "PRJNA"),
            datasetTemplates = listOf("microplastic immune inflammation dataset", "PM2.5 CRP IL-6 cohort dataset", "phthalate endocrine immune transcriptome GSE"),
            outcomeTerms = listOf("inflammation", "endocrine disruption", "immune activation", "cardiovascular risk", "metabolic stress"),
            contradictionTerms = listOf("microplastic inflammation no association", "BPA immune weak evidence", "PM2.5 cytokines confounder adjusted", "smoking immune negative control"),
            graphEdges = listOf(
                BiologicalSystemEdge("environment/toxin exposure", "perturbs", "endocrine/immune biomarkers", "exposure_measurement"),
                BiologicalSystemEdge("air quality/smoking", "links_to", "CRP/IL-6/blood pressure", "control_or_comparator"),
                BiologicalSystemEdge("plastic/toxin route", "requires", "measured exposure not narrative", "metadata_closure")
            ),
            invalidators = listOf("Exposure is not measured or classified", "No endocrine/immune biomarker exists", "No smoking/alcohol/air-quality confounder control exists", "Only general toxin narrative exists"),
            priority = 101
        ),
        LaneDefinition(
            laneId = "NUTRITION_MICRONUTRIENT_INTELLIGENCE",
            label = "Nutrition / Micronutrient Intelligence",
            modules = listOf("nutrition", "immune", "metabolic", "longevity_biomarkers"),
            triggers = listOf("vitamin d", "25(oh)d", "vitamin c", "b12", "zinc", "selenium", "iron", "ferritin", "magnesium", "omega-3", "diet", "nutrition", "micronutrient", "فيتامين", "مغنيسيوم", "زنك"),
            exposure = "diet/vitamin/mineral status exposure",
            pathway = "micronutrient-immune-metabolic pathway",
            biomarkers = listOf("25(OH)D", "vitamin C", "B12", "zinc", "selenium", "iron/ferritin", "magnesium", "omega-3 index", "CRP", "WBC/RBC"),
            lookupTerms = listOf("vitamin D immune CRP", "zinc immune cytokines", "selenium immune response", "B12 inflammation cohort", "omega-3 CRP immune", "GSE", "PRJNA"),
            datasetTemplates = listOf("vitamin D immune inflammation cohort dataset", "zinc cytokine immune response GSE", "omega-3 CRP immune longitudinal dataset"),
            outcomeTerms = listOf("immune function", "inflammation", "infection response", "metabolic outcome", "hematology"),
            contradictionTerms = listOf("vitamin D immune no association", "zinc cytokines failed replication", "omega-3 CRP weak evidence", "micronutrient immune confounder adjusted"),
            graphEdges = listOf(
                BiologicalSystemEdge("micronutrient status", "maps_to", "immune/inflammatory biomarkers", "biomarker_panel"),
                BiologicalSystemEdge("dietary exposure", "confounded_by", "baseline health/socioeconomic/season", "negative_control"),
                BiologicalSystemEdge("vitamin/mineral term", "treated_as", "research exposure not supplement advice", "claim_guard")
            ),
            invalidators = listOf("No measured nutrient status exists", "No immune or inflammatory marker exists", "No baseline/season/dietary confounder control exists", "Source implies dosing or treatment advice rather than research exposure"),
            priority = 100
        ),
        LaneDefinition(
            laneId = "HERBS_FOODS_EXPOSURE_CONTROL_LANE",
            label = "Herbs & Foods as Exposure / Noise / Control",
            modules = listOf("herbs_exposures", "nutrition", "immune", "metabolic"),
            triggers = listOf("honey", "عسل", "wormwood", "artemisia", "شيح", "eucalyptus", "كاليبتوس", "curcumin", "turmeric", "quercetin", "propolis", "ginger", "garlic", "olive oil", "herb", "food", "natural compound"),
            exposure = "herb/food/natural-compound exposure",
            pathway = "natural-compound-noise-control immune pathway",
            biomarkers = listOf("CRP", "IL-6", "TNF-alpha", "oxidative stress", "NF-kB", "glucose", "lipids", "WBC/RBC"),
            lookupTerms = listOf("curcumin quercetin NF-kB immune", "honey inflammation cytokines", "artemisia immune transcriptome", "eucalyptus inflammation", "natural compound control group", "GSE", "PRJNA"),
            datasetTemplates = listOf("curcumin quercetin immune transcriptome GSE", "honey inflammation cytokine dataset", "natural compound immune control cohort dataset"),
            outcomeTerms = listOf("immune marker change", "inflammation", "oxidative stress", "metabolic marker", "noise/confounder"),
            contradictionTerms = listOf("curcumin immune no association", "quercetin cytokines failed replication", "honey inflammation weak evidence", "natural compound placebo control null"),
            graphEdges = listOf(
                BiologicalSystemEdge("herb/food exposure", "classified_as", "exposure/noise/control", "claim_guard"),
                BiologicalSystemEdge("natural compound", "may_affect", "NF-kB/oxidative-stress markers", "dataset_accession"),
                BiologicalSystemEdge("claimed benefit", "must_face", "null/placebo/negative-control evidence", "contradiction_search")
            ),
            invalidators = listOf("No measured exposure or compound identity exists", "No control/placebo/comparator exists", "Only benefit claim appears", "Dose/treatment advice requested instead of research routing"),
            priority = 96
        )
    )

    fun evaluate(
        steering: ResearchSteeringProfile?,
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        ontology: BiomedicalResearchOntologyReport,
        conceptBridge: BiomedicalConceptBridgeReport,
        modernTech: ModernMedicalTechnologyReport,
        viral: ViralCountermeasureReport,
        evidencePrior: EvidencePriorSelectionReport,
        metadataClosure: MetadataClosureReport,
        recentReports: List<String>
    ): LongevityBiologicalSystemsReport {
        val corpus = buildCorpus(steering, leadObjects, candidates, ontology, conceptBridge, modernTech, viral, evidencePrior, metadataClosure, recentReports)
        val topicText = TopicFitMetadataParseUiClarityV11047.topicText(steering)
        val preferredFromTopic = TopicFitMetadataParseUiClarityV11047.preferredLane(topicText, "none")
        val scored = lanes.map { lane ->
            val hits = lane.triggers.filter { corpus.contains(it.lowercase(Locale.US)) }.distinct()
            val topicHits = lane.triggers.filter { topicText.contains(it.lowercase(Locale.US)) }.distinct()
            val ontologyBoost = lane.modules.count { module -> ontology.selectedDomains.any { it.contains(module.substringBefore('_'), ignoreCase = true) } } * 3
            val viralBoost = if (lane.modules.contains("viral") && viral.active) 8 else 0
            val evidenceBoost = if (evidencePrior.queryTerms.any { term -> lane.lookupTerms.any { it.contains(term, ignoreCase = true) || term.contains(it, ignoreCase = true) } }) 5 else 0
            val topicFitBoost = when {
                lane.laneId == preferredFromTopic -> 80
                preferredFromTopic == "IMMUNE_AGING_VACCINE_RESPONSE_LANE" && lane.laneId == "IMMUNE_AGING_IMMUNOSENESCENCE_LANE" -> 65
                preferredFromTopic == "TYPE2_ALLERGY_MAST_CELL_LANE" && lane.laneId == "HERBS_FOODS_EXPOSURE_CONTROL_LANE" -> 0
                preferredFromTopic != "none" && preferredFromTopic != "GENERAL_IMMUNE_DATASET_CLOSURE_LANE" && lane.laneId == "IMMUNE_AGING_IMMUNOSENESCENCE_LANE" && topicHits.isEmpty() -> -35
                else -> 0
            }
            Triple(lane, (topicHits + hits).distinct(), lane.priority + hits.size * 12 + topicHits.size * 20 + ontologyBoost + viralBoost + evidenceBoost + topicFitBoost)
        }.filter { it.second.isNotEmpty() || it.third >= 112 }
            .sortedByDescending { it.third }

        val selected = if (scored.isEmpty()) {
            lanes.filter { it.laneId in listOf("METABOLIC_IMMUNE_LANE", "CIRCADIAN_SLEEP_INTELLIGENCE") }.map { Triple(it, emptyList<String>(), it.priority) }
        } else {
            scored.take(3)
        }

        val cards = selected.map { (lane, hits, _) ->
            BiologicalSystemsModuleCard(
                moduleId = lane.laneId,
                label = lane.label,
                laneId = lane.laneId,
                matchedTerms = hits.take(14),
                biomarkers = lane.biomarkers,
                lookupTerms = lane.lookupTerms.take(16),
                datasetTemplates = lane.datasetTemplates,
                contradictionTerms = lane.contradictionTerms,
                invalidators = lane.invalidators
            )
        }
        val selectedLane = cards.firstOrNull()?.laneId ?: "BASELINE_LONGEVITY_SYSTEMS_INDEX"
        val exposureCards = selected.map { (lane, _, _) ->
            ExposurePathwayCard(
                exposure = lane.exposure,
                pathway = lane.pathway,
                biomarkers = lane.biomarkers.take(10),
                datasetTemplate = lane.datasetTemplates.first(),
                outcomeTerms = lane.outcomeTerms,
                contradictionTemplate = lane.contradictionTerms.first()
            )
        }
        val modules = cards.flatMap { card -> lanes.firstOrNull { it.laneId == card.laneId }?.modules ?: emptyList() }.distinct()
        val biomarkers = cards.flatMap { it.biomarkers }.distinct().take(32)
        val datasetTemplates = cards.flatMap { it.datasetTemplates }.distinct().take(16)
        val contradictions = cards.flatMap { it.contradictionTerms }.distinct().take(18)
        val missing = buildMissingData(metadataClosure, biomarkers)
        val linked = listOfNotNull(
            "BiomedicalResearchOntology".takeIf { ontology.active },
            "BiomedicalConceptBridge".takeIf { conceptBridge.active },
            "ModernMedicalTechnologyIntelligence".takeIf { modernTech.active },
            "ViralCountermeasureIntelligence".takeIf { viral.active },
            "EvidencePriorMatrix".takeIf { evidencePrior.active },
            "MetadataClosureAgent".takeIf { metadataClosure.active },
            "LearningAuditMonitor"
        )
        val graphEdges = selected.flatMap { it.first.graphEdges }.distinct().take(24)
        val state = when {
            scored.isEmpty() -> "LONGEVITY_SYSTEMS_BASELINE_READY_CONTRADICTION_REQUIRED"
            missing.any { it in listOf("control_or_comparator", "time_order", "outcome_labels") } -> "LONGEVITY_SYSTEMS_ROUTE_METADATA_OPEN"
            contradictions.isNotEmpty() -> "LONGEVITY_SYSTEMS_GRAPH_READY_CONTRADICTION_REQUIRED"
            else -> "LONGEVITY_SYSTEMS_GRAPH_READY_RESEARCH_ONLY"
        }
        val nextQuestion = "Does ${exposureCards.firstOrNull()?.exposure ?: "the selected exposure"} map to ${biomarkers.take(5).joinToString(", ").ifBlank { "measurable biomarkers" }} in a dataset with control/time/outcome labels, and does a contradiction/null-result study weaken it?"
        return LongevityBiologicalSystemsReport(
            active = true,
            state = state,
            selectedLane = selectedLane,
            selectedModules = modules,
            moduleCards = cards,
            exposurePathways = exposureCards,
            graphEdges = graphEdges,
            fastRetrievalPartitions = (modules + listOf("dataset_templates", "contradiction_search", "metadata_closure")).distinct().take(18),
            biomarkersRequired = biomarkers,
            datasetQueryTemplates = datasetTemplates,
            contradictionSearchTerms = contradictions,
            linkedLayers = linked,
            missingData = missing,
            invalidators = cards.flatMap { it.invalidators }.distinct().take(18),
            reportSummaryFields = requiredSummaryFields,
            guardrails = commonGuardrails,
            nextResearchQuestion = nextQuestion,
            nextAction = "Load only selected modules (${modules.take(6).joinToString(", ")}); run dataset template plus contradiction/null-result query before strengthening any biological link."
        )
    }

    private fun buildMissingData(metadataClosure: MetadataClosureReport, biomarkers: List<String>): List<String> {
        val base = mutableListOf<String>()
        base += metadataClosure.missingFields
        if (biomarkers.isEmpty()) base += "biomarker_panel"
        if (!base.any { it.contains("control", ignoreCase = true) }) base += "control_or_comparator"
        if (!base.any { it.contains("time", ignoreCase = true) }) base += "time_order"
        if (!base.any { it.contains("outcome", ignoreCase = true) }) base += "outcome_labels"
        return base.distinct().take(16)
    }

    private fun buildCorpus(
        steering: ResearchSteeringProfile?,
        leadObjects: List<LeadObject>,
        candidates: List<DatasetAccessionCandidate>,
        ontology: BiomedicalResearchOntologyReport,
        conceptBridge: BiomedicalConceptBridgeReport,
        modernTech: ModernMedicalTechnologyReport,
        viral: ViralCountermeasureReport,
        evidencePrior: EvidencePriorSelectionReport,
        metadataClosure: MetadataClosureReport,
        recentReports: List<String>
    ): String {
        val parts = mutableListOf<String>()
        steering?.let { parts += listOf(it.profileId, it.focusQuestion, it.variables.joinToString(" "), it.requiredTerms.joinToString(" "), it.excludedTerms.joinToString(" "), it.inferredAxes.joinToString(" ")) }
        parts += leadObjects.flatMap { listOf(it.source, it.title, it.snippet, it.domain, it.organism, it.omicsType, it.dataAvailabilityText, it.detectedAccessions.joinToString(" ")) }
        parts += candidates.flatMap { listOf(it.accession, it.source, it.sourceTitle, it.organismHint, it.conditionLabelsHint, it.outcomeLabelsHint, it.triggerResponseOutcomeHint, it.timeCourseHint, it.dataType, it.status, it.reasons.joinToString(" ")) }
        parts += listOf(
            ontology.selectedDomains.joinToString(" "),
            ontology.matchedTerms.joinToString(" "),
            ontology.queryExpansionKeys.joinToString(" "),
            conceptBridge.selectedBridgeIds.joinToString(" "),
            conceptBridge.matchedConcepts.joinToString(" "),
            modernTech.selectedModuleIds.joinToString(" "),
            modernTech.matchedTechnologies.joinToString(" "),
            viral.selectedVirusKey,
            viral.selectedLane,
            viral.priorityLookupTerms.joinToString(" "),
            evidencePrior.selectedPriorId,
            evidencePrior.selectedRoute,
            evidencePrior.queryTerms.joinToString(" "),
            metadataClosure.closedFields.joinToString(" "),
            metadataClosure.missingFields.joinToString(" ")
        )
        parts += recentReports.takeLast(12)
        return parts.joinToString(" ").lowercase(Locale.US)
    }
}

object HealthAdviceClaimGuardV11046 {
    const val CLAIM_LIMIT: String = LongevityBiologicalSystemsGraphV11046.CLAIM_LIMIT

    val forbiddenPersonalAdviceTokens: List<String> = listOf(
        "dose",
        "dosage",
        "take this",
        "treatment plan",
        "cure",
        "medical advice",
        "personal recommendation",
        "وصفة",
        "جرعة",
        "علاج"
    )

    fun isResearchRoutingOnly(text: String): Boolean = forbiddenPersonalAdviceTokens.none {
        text.contains(it, ignoreCase = true)
    }
}
