package com.immunesignal.app

import kotlin.math.roundToInt

/**
 * v1.4.5: ML-safe dataset triage.
 *
 * This is intentionally a bounded research-routing layer. It is rule-based now
 * and replaceable by a model later, but the claim limit stays the same: it only
 * ranks the hunt and never proves biology.
 */
data class TriageResult(
    val accession: String,
    val usefulnessScore: Int,
    val routeFitPrediction: String,
    val likelyFailureModes: List<String>,
    val action: String,
    val mlConfidence: Int,
    val reason: String,
    val claimLimit: String = "triage_only_not_biological_proof"
)

data class DatasetTriageReport(
    val active: Boolean,
    val results: List<TriageResult>,
    val parsedAccessions: List<String>,
    val skippedAccessions: List<String>,
    val summary: String,
    val claimLimit: String = "triage_only_not_biological_proof"
) {
    companion object {
        fun empty() = DatasetTriageReport(
            active = false,
            results = emptyList(),
            parsedAccessions = emptyList(),
            skippedAccessions = emptyList(),
            summary = "Dataset triage was not evaluated in this cycle."
        )
    }
}

object DatasetTriageEngine {
    fun triage(candidates: List<DatasetAccessionCandidate>, routeFits: List<DatasetRouteFitAssessment>): List<TriageResult> {
        val fitByAccession = routeFits.associateBy { it.accession }
        return candidates.map { candidate -> triage(candidate, fitByAccession[candidate.accession]) }
    }

    fun triage(candidate: DatasetAccessionCandidate, routeFit: DatasetRouteFitAssessment? = null): TriageResult {
        val titleScore = scoreTitle(candidate.sourceTitle)
        val metadataScore = scoreMetadata(candidate)
        val accessibilityScore = scoreAccessibility(candidate)
        val routeScore = routeFit?.routeFitScore ?: RouteEmbeddingScorer.scoreRouteFit(candidate, QueryFeedbackPlanner.inferRoute(candidate.sourceTitle)).similarityScore
        val likelyFailures = FailurePredictionModel.predict(candidate, routeFit)
        val overall = (titleScore * 0.30 + metadataScore * 0.30 + accessibilityScore * 0.15 + routeScore * 0.25).roundToInt().coerceIn(0, 100)
        val action = when {
            likelyFailures.contains("OFF_ROUTE") -> "LOW_PRIORITY"
            likelyFailures.contains("ANIMAL_ONLY") && !candidate.organismHint.contains("human", ignoreCase = true) -> "LOW_PRIORITY"
            likelyFailures.contains("NO_OUTCOME_LABELS") && overall < 70 -> "LOW_PRIORITY"
            likelyFailures.contains("METADATA_ONLY") && overall < 65 -> "SKIP_SIMILAR"
            overall >= 75 -> "PARSE"
            overall >= 60 -> "PARSE_WITH_CAUTION"
            else -> "LOW_PRIORITY"
        }
        val confidence = (45 + likelyFailures.size * 8 + kotlin.math.abs(routeScore - 50) / 3).coerceIn(45, 85)
        return TriageResult(
            accession = candidate.accession,
            usefulnessScore = overall,
            routeFitPrediction = routeFit?.status ?: RouteEmbeddingScorer.scoreRouteFit(candidate, QueryFeedbackPlanner.inferRoute(candidate.sourceTitle)).status,
            likelyFailureModes = likelyFailures,
            action = action,
            mlConfidence = confidence,
            reason = buildReason(candidate, routeFit, likelyFailures, overall, action)
        )
    }

    fun report(results: List<TriageResult>, parseCandidates: List<DatasetAccessionCandidate>): DatasetTriageReport {
        if (results.isEmpty()) return DatasetTriageReport.empty()
        val parsed = parseCandidates.map { it.accession }.distinct()
        val skipped = results.filter { it.accession !in parsed }.map { it.accession }.distinct()
        return DatasetTriageReport(
            active = true,
            results = results,
            parsedAccessions = parsed,
            skippedAccessions = skipped,
            summary = "ML-safe triage evaluated ${results.size} candidate(s); ${parsed.size} selected for parsing, ${skipped.size} kept as low-priority/skip-similar."
        )
    }

    fun shouldParse(result: TriageResult): Boolean = result.action == "PARSE" || result.action == "PARSE_WITH_CAUTION"

    private fun scoreTitle(title: String): Int {
        var score = 35
        if (matches(title, "human|patient|cohort|clinical|trial|participant")) score += 20
        if (matches(title, "outcome|severity|recovery|prognosis|endpoint|responder|nonresponder|response")) score += 20
        if (matches(title, "time-course|longitudinal|serial|temporal|follow-up|timepoint")) score += 12
        if (matches(title, "RNA-seq|transcriptom|single-cell|scrna|gene expression")) score += 10
        if (matches(title, "mouse|rat|zebrafish|murine|animal model")) score -= 20
        return score.coerceIn(0, 100)
    }

    private fun scoreMetadata(candidate: DatasetAccessionCandidate): Int {
        var score = 35
        val text = listOf(candidate.conditionLabelsHint, candidate.outcomeLabelsHint, candidate.triggerResponseOutcomeHint, candidate.timeCourseHint, candidate.sampleSizeHint, candidate.organismHint).joinToString(" ")
        if (matches(text, "human|patient|cohort|clinical|participant")) score += 18
        if (matches(text, "outcome|severity|recovery|endpoint|response|responder|nonresponder")) score += 22
        if (matches(text, "longitudinal|time-course|serial|temporal|timepoint|follow-up")) score += 14
        if (matches(text, "control|placebo|negative control|healthy control|exposed control")) score += 10
        if (matches(text, "mouse|rat|murine|zebrafish") && !matches(text, "human|patient|participant")) score -= 25
        if (text.length < 120) score -= 10
        return score.coerceIn(0, 100)
    }

    private fun scoreAccessibility(candidate: DatasetAccessionCandidate): Int = when {
        candidate.accession.startsWith("GSE", ignoreCase = true) -> 80
        candidate.accession.startsWith("PRJNA", ignoreCase = true) -> 70
        candidate.accession.startsWith("SDY", ignoreCase = true) -> 75
        candidate.sourceUrl.isNotBlank() -> 60
        else -> 40
    }

    private fun matches(text: String, pattern: String): Boolean = Regex(pattern, RegexOption.IGNORE_CASE).containsMatchIn(text)

    private fun buildReason(candidate: DatasetAccessionCandidate, routeFit: DatasetRouteFitAssessment?, failures: List<String>, overall: Int, action: String): String {
        val fit = routeFit?.let { "route-fit ${it.routeFitScore}/100 ${it.status}" } ?: "route-fit predicted from metadata"
        val failText = failures.joinToString(", ").ifBlank { "no major predicted failure" }
        return "Triage $overall/100 → $action for ${candidate.accession}; $fit; predicted: $failText."
    }
}

object FailurePredictionModel {
    fun predict(candidate: DatasetAccessionCandidate, routeFit: DatasetRouteFitAssessment? = null): List<String> {
        val text = listOf(candidate.sourceTitle, candidate.organismHint, candidate.conditionLabelsHint, candidate.outcomeLabelsHint, candidate.triggerResponseOutcomeHint, candidate.timeCourseHint, candidate.sampleSizeHint, candidate.dataType).joinToString(" ")
        val failures = linkedSetOf<String>()
        if (routeFit?.blocksHypothesisUpgrade == true) failures += "OFF_ROUTE"
        if (!matches(text, "outcome|phenotype|severity|recovery|endpoint|responder|nonresponder|response")) failures += "NO_OUTCOME_LABELS"
        if (!matches(text, "longitudinal|time-course|serial|temporal|timepoint|follow-up|before|after")) failures += "NO_TIMECOURSE"
        if (matches(text, "mouse|rat|murine|zebrafish|animal") && !matches(text, "human|patient|participant|clinical")) failures += "ANIMAL_ONLY"
        if (text.length < 180 || candidate.conditionLabelsHint.length < 30) failures += "METADATA_ONLY"
        return failures.toList()
    }

    private fun matches(text: String, pattern: String): Boolean = Regex(pattern, RegexOption.IGNORE_CASE).containsMatchIn(text)
}

data class RouteFitScore(
    val similarityScore: Int,
    val status: String,
    val reason: String,
    val claimLimit: String = "similarity_only_not_biological_proof"
)

object RouteEmbeddingScorer {
    fun scoreRouteFit(candidate: DatasetAccessionCandidate, hypothesisRoute: String): RouteFitScore {
        val datasetRoute = RouteFitGate.inferDatasetRoute(
            listOf(candidate.accession, candidate.sourceTitle, candidate.conditionLabelsHint, candidate.outcomeLabelsHint, candidate.triggerResponseOutcomeHint, candidate.dataType).joinToString(" ")
        )
        val score = when {
            datasetRoute == hypothesisRoute -> 92
            datasetRoute.startsWith("allergy") && hypothesisRoute.startsWith("allergy") -> 82
            datasetRoute == "general_immune_omics" -> 58
            datasetRoute == "unknown_route" -> 35
            hypothesisRoute == "general_immune_mapping" -> 55
            else -> 25
        }.coerceIn(0, 100)
        val status = when {
            score >= 80 -> "STRONG_CANDIDATE"
            score >= 60 -> "INSPECT"
            score >= 35 -> "WEAK_ANALOGY"
            else -> "OFF_ROUTE"
        }
        return RouteFitScore(score, status, "Dataset route=$datasetRoute; target route=$hypothesisRoute.")
    }
}

/** Backward-compatible naming for the approved architecture: MLDatasetTriageEngine ranks inspection only. */
object MLDatasetTriageEngine {
    fun triage(candidates: List<DatasetAccessionCandidate>, routeFits: List<DatasetRouteFitAssessment>): List<TriageResult> =
        DatasetTriageEngine.triage(candidates, routeFits)

    fun shouldParse(result: TriageResult): Boolean = DatasetTriageEngine.shouldParse(result)

    fun report(results: List<TriageResult>, parseCandidates: List<DatasetAccessionCandidate>): DatasetTriageReport =
        DatasetTriageEngine.report(results, parseCandidates)
}
