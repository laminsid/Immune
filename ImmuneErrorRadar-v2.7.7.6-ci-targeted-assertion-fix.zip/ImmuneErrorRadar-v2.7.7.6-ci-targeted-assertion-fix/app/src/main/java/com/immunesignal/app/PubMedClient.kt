package com.immunesignal.app

/**
 * Placeholder extraction seam. Network code remains in ResearchAutopilot in v1.3.3
 * to avoid a risky rewrite; future versions can move HTTP here safely.
 */
class PubMedClient
