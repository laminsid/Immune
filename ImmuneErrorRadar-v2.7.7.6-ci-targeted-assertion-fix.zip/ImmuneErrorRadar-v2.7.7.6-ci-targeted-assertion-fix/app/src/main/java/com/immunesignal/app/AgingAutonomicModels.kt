package com.immunesignal.app

data class AgingImmuneProfile(
    val immunosenescenceAxis: Int,
    val inflammagingAxis: Int,
    val immuneResponsivenessAxis: Int,
    val agingLoadIndex: Int,
    val resilienceIndex: Int
)

data class AutonomicVascularProfile(
    val sympatheticPressureUp: Int,
    val histaminePressureDown: Int,
    val bloodPressureInstability: Int
)
