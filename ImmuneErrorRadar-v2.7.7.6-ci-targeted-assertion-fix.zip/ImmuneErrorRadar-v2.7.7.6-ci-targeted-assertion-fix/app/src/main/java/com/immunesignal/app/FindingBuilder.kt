package com.immunesignal.app

import org.json.JSONObject

/** Compatibility seam for future extraction from ResearchAutopilot. */
object FindingBuilder {
    fun datasetCandidates(finding: ResearchFinding): List<DatasetCandidateV133> = DatasetCandidateExtractor.extractFromFinding(finding)
    fun isUseful(finding: ResearchFinding): Boolean = finding.noveltyScore >= 45 || finding.matchedAxes.size >= 2 || finding.evidence.evidenceQualityScore >= 55
    fun sourceLabel(doc: JSONObject): String = doc.optString("source", "PubMed") + ":" + doc.optString("sourceId", doc.optString("uid", "unknown"))
}
