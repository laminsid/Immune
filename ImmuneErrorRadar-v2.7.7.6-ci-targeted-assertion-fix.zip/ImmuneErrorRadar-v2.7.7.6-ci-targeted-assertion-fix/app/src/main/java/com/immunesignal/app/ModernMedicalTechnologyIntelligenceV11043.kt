package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.43: Modern Medical Technology Intelligence.
 *
 * Scientist/lab-facing technology layer for modern biomedical methods: RNA platforms,
 * single-cell/spatial/multi-omics, nanomedicine/delivery, advanced lab assays,
 * accession repositories, and computational-medicine vocabulary. It is deliberately
 * modular: it selects a few technology modules by lead/ontology/bridge context instead
 * of injecting a large static knowledge blob into every query.
 *
 * Boundary: guides lookup, metadata parsing, accession retrieval, platform recognition,
 * bridge linking, and falsification planning only. It never creates diagnosis, treatment,
 * dose, therapeutic efficacy, lab-validation, or clinical-recommendation claims.
 */
data class ModernTechnologyModuleCard(
    val moduleId: String,
    val label: String,
    val category: String,
    val matchedTerms: List<String>,
    val lookupTerms: List<String>,
    val evidenceKeys: List<String>,
    val connectors: List<String>,
    val invalidators: List<String>,
    val forbiddenClaims: List<String>
)

data class ModernMedicalTechnologyReport(
    val active: Boolean,
    val state: String,
    val routingMode: String,
    val selectedModuleIds: List<String>,
    val moduleCards: List<ModernTechnologyModuleCard>,
    val matchedTechnologies: List<String>,
    val priorityLookupTerms: List<String>,
    val evidenceKeysToClose: List<String>,
    val partitionIndexKeys: List<String>,
    val retrievalPolicy: String,
    val invalidators: List<String>,
    val forbiddenClaims: List<String>,
    val nextAction: String,
    val claimLimit: String = ModernMedicalTechnologyIntelligenceV11043.CLAIM_LIMIT
) {
    companion object {
        fun empty() = ModernMedicalTechnologyReport(
            active = false,
            state = "NOT_EVALUATED",
            routingMode = "OFF",
            selectedModuleIds = emptyList(),
            moduleCards = emptyList(),
            matchedTechnologies = emptyList(),
            priorityLookupTerms = emptyList(),
            evidenceKeysToClose = emptyList(),
            partitionIndexKeys = emptyList(),
            retrievalPolicy = "No modern technology module selected.",
            invalidators = emptyList(),
            forbiddenClaims = emptyList(),
            nextAction = "No modern technology routing available."
        )
    }
}

object ModernMedicalTechnologyIntelligenceV11043 {
    const val CLAIM_LIMIT: String = "modern_medical_technology_routing_only_not_lab_or_clinical_proof"

    private data class TechnologyModule(
        val id: String,
        val label: String,
        val category: String,
        val triggers: List<String>,
        val lookupTerms: List<String>,
        val evidenceKeys: List<String>,
        val connectors: List<String>,
        val invalidators: List<String>,
        val priority: Int
    )

    private val forbiddenClaims = listOf(
        "patient diagnosis",
        "treatment recommendation",
        "drug dose recommendation",
        "therapeutic efficacy claim",
        "lab validation confirmed",
        "clinical utility confirmed",
        "causal mechanism confirmed",
        "scientific breakthrough confirmed"
    )

    private val modules = listOf(
        TechnologyModule(
            id = "RNA_SINGLE_CELL_SPATIAL_OMICS",
            label = "RNA / single-cell / spatial transcriptomics module",
            category = "omics_rna",
            triggers = listOf("rna", "rna-seq", "transcriptome", "transcriptomics", "scrna", "single-cell", "single cell", "single-nucleus", "snrna", "spatial transcriptomics", "cell atlas", "gene expression", "isg", "interferon-stimulated"),
            lookupTerms = listOf("RNA-seq", "scRNA-seq", "single-cell", "single-nucleus", "spatial transcriptomics", "gene expression", "transcriptome", "cell type", "GSE", "SRP", "SRR", "PRJNA", "sample metadata", "condition labels"),
            evidenceKeys = listOf("omics_accession", "platform", "cell_type", "tissue_or_cell_context", "condition_labels", "outcome_labels", "control_or_comparator", "batch_or_platform_artifact", "time_order"),
            connectors = listOf("GENETICS_CELLS_CHROMOSOMES_MITOCHONDRIA", "ORGAN_SYSTEMS", "BLOOD_HEMATOLOGY_VASCULAR"),
            invalidators = listOf("No explicit RNA/omics platform appears", "No accession or sample metadata is available", "Signal may be batch/cell-composition artifact without controls"),
            priority = 100
        ),
        TechnologyModule(
            id = "NANO_DELIVERY_EXOSOME_LNP",
            label = "Nanomedicine / delivery / exosome / LNP module",
            category = "nano_delivery",
            triggers = listOf("nano", "nanoparticle", "nanomedicine", "lipid nanoparticle", "lnp", "nanocarrier", "exosome", "extracellular vesicle", "delivery", "drug delivery", "rna delivery"),
            lookupTerms = listOf("nanoparticle", "nanomedicine", "lipid nanoparticle", "LNP", "nanocarrier", "exosome", "extracellular vesicle", "RNA delivery", "biodistribution", "immune activation", "control", "toxicity", "metadata"),
            evidenceKeys = listOf("material_or_delivery_platform", "payload_or_cargo", "dose_or_exposure_as_metadata_only", "immune_activation_marker", "control_or_comparator", "biodistribution_or_tissue_context", "safety_or_artifact_signal"),
            connectors = listOf("MEDICATIONS_RESEARCH_PERTURBATIONS", "GENETICS_CELLS_CHROMOSOMES_MITOCHONDRIA", "BLOOD_HEMATOLOGY_VASCULAR"),
            invalidators = listOf("Only generic nano narrative appears", "No material/payload/platform metadata exists", "No immune control/comparator or safety artifact signal is visible"),
            priority = 88
        ),
        TechnologyModule(
            id = "MULTI_OMICS_PROTEOMICS_METABOLOMICS_EPIGENOMICS",
            label = "Multi-omics / proteomics / metabolomics / epigenomics module",
            category = "multi_omics",
            triggers = listOf("multi-omics", "multiomics", "proteomics", "metabolomics", "lipidomics", "epigenomics", "methylation", "atac-seq", "cite-seq", "mass spectrometry", "pathway enrichment"),
            lookupTerms = listOf("multi-omics", "proteomics", "metabolomics", "epigenomics", "methylation", "ATAC-seq", "CITE-seq", "mass spectrometry", "pathway enrichment", "GSE", "PRIDE", "MetaboLights", "control", "cohort"),
            evidenceKeys = listOf("omics_modality", "accession", "platform", "sample_size", "condition_labels", "outcome_labels", "control_or_comparator", "normalization_or_batch_control"),
            connectors = listOf("GENETICS_CELLS_CHROMOSOMES_MITOCHONDRIA", "COMMON_DISEASES_AND_CLINICAL_PHENOTYPES"),
            invalidators = listOf("No omics modality is explicit", "No dataset accession or repository handle exists", "No normalization/batch control is visible"),
            priority = 84
        ),
        TechnologyModule(
            id = "ADVANCED_LAB_ASSAY_PLATFORMS",
            label = "Advanced lab assay platform module",
            category = "lab_platforms",
            triggers = listOf("flow cytometry", "cytof", "mass cytometry", "elisa", "multiplex", "cytokine panel", "qpcr", "digital pcr", "ddpcr", "pcr", "serology", "neutralization", "immunophenotyping", "immunoassay"),
            lookupTerms = listOf("flow cytometry", "CyTOF", "mass cytometry", "ELISA", "multiplex cytokine", "qPCR", "digital PCR", "ddPCR", "serology", "immunophenotyping", "panel", "control", "reference range"),
            evidenceKeys = listOf("assay_platform", "measurement_definition", "sample_type", "control_or_comparator", "baseline_or_reference_range", "time_order", "quality_control"),
            connectors = listOf("BLOOD_HEMATOLOGY_VASCULAR", "PATHOGENS_VIRUS_BACTERIA_PARASITE", "COMMON_DISEASES_AND_CLINICAL_PHENOTYPES"),
            invalidators = listOf("Assay platform is missing", "Measurement definition is absent", "No control/baseline/reference range is available"),
            priority = 80
        ),
        TechnologyModule(
            id = "ACCESSION_REPOSITORY_INDEX",
            label = "Accession repository / dataset-source module",
            category = "retrieval_index",
            triggers = listOf("gse", "geo", "sra", "prjna", "srp", "srr", "e-mtab", "arrayexpress", "sdy", "immport", "dbgap", "ena", "pride", "metabolights", "data availability", "supplementary data"),
            lookupTerms = listOf("GSE", "GEO", "SRA", "PRJNA", "SRP", "SRR", "E-MTAB", "ArrayExpress", "SDY", "ImmPort", "dbGaP", "ENA", "PRIDE", "MetaboLights", "data availability", "supplementary data"),
            evidenceKeys = listOf("accession", "repository", "source_id", "license_access", "sample_size", "condition_labels", "data_availability_text", "secondary_lookup_status"),
            connectors = listOf("ALL_MODULES"),
            invalidators = listOf("No accession/repository/source ID appears", "No data-availability or supplementary-data phrase is found"),
            priority = 96
        ),
        TechnologyModule(
            id = "COMPUTATIONAL_MEDICINE_AI_BIOMARKER_DISCOVERY",
            label = "Computational medicine / AI biomarker discovery module",
            category = "computational_medicine",
            triggers = listOf("machine learning", "ai", "classifier", "signature", "biomarker discovery", "risk score", "pathway", "network", "cluster", "latent", "embedding", "prediction"),
            lookupTerms = listOf("machine learning", "classifier", "biomarker signature", "pathway enrichment", "network analysis", "clustering", "external validation", "train test", "cross-validation", "held-out cohort", "replication"),
            evidenceKeys = listOf("model_input_features", "training_cohort", "validation_cohort", "external_replication", "label_definition", "leakage_control", "clinical_or_biological_endpoint"),
            connectors = listOf("GENETICS_CELLS_CHROMOSOMES_MITOCHONDRIA", "COMMON_DISEASES_AND_CLINICAL_PHENOTYPES"),
            invalidators = listOf("No validation/replication cohort exists", "Labels are unclear", "Model output is narrative without endpoint or leakage controls"),
            priority = 60
        ),
        TechnologyModule(
            id = "CELL_GENE_THERAPY_RESEARCH_CONTEXT",
            label = "Cell/gene therapy research-context module",
            category = "advanced_therapeutic_research",
            triggers = listOf("car-t", "car t", "cell therapy", "gene therapy", "crispr", "base editing", "prime editing", "viral vector", "aav", "lentiviral", "mrna therapy"),
            lookupTerms = listOf("CAR-T", "cell therapy", "gene therapy", "CRISPR", "base editing", "prime editing", "viral vector", "AAV", "lentiviral", "mRNA therapy", "immune response", "control", "safety"),
            evidenceKeys = listOf("intervention_as_research_context", "delivery_vector_or_platform", "cell_type", "immune_response_marker", "control_or_comparator", "safety_or_off_target_signal", "outcome_labels"),
            connectors = listOf("GENETICS_CELLS_CHROMOSOMES_MITOCHONDRIA", "MEDICATIONS_RESEARCH_PERTURBATIONS"),
            invalidators = listOf("Therapeutic context becomes recommendation", "No vector/platform/cell metadata is visible", "No safety/control signal exists"),
            priority = 62
        )
    )

    fun evaluate(
        ontology: BiomedicalResearchOntologyReport,
        conceptBridge: BiomedicalConceptBridgeReport,
        evidencePrior: EvidencePriorSelectionReport,
        ebv: EBVLeadVerificationReport,
        metadataClosure: MetadataClosureReport,
        recentReports: List<String>
    ): ModernMedicalTechnologyReport {
        val corpus = buildCorpus(ontology, conceptBridge, evidencePrior, ebv, metadataClosure, recentReports)
        val selected = modules.mapNotNull { module ->
            val hits = module.triggers.filter { corpus.contains(it.lowercase(Locale.US)) }.distinct()
            val connectorBoost = module.connectors.count { connector ->
                connector == "ALL_MODULES" || ontology.selectedDomains.contains(connector) || conceptBridge.selectedBridgeIds.any { it.contains(connector, ignoreCase = true) }
            } * 6
            val accessionBoost = if (metadataClosure.missingFields.contains("accession") && module.id == "ACCESSION_REPOSITORY_INDEX") 25 else 0
            val rnaBoost = if (conceptBridge.selectedBridgeIds.any { it.contains("RNA", ignoreCase = true) } && module.id == "RNA_SINGLE_CELL_SPATIAL_OMICS") 12 else 0
            val ebvBoost = if (ebv.active && module.id in setOf("RNA_SINGLE_CELL_SPATIAL_OMICS", "ACCESSION_REPOSITORY_INDEX", "ADVANCED_LAB_ASSAY_PLATFORMS")) 8 else 0
            val score = module.priority + hits.size * 9 + connectorBoost + accessionBoost + rnaBoost + ebvBoost
            if (hits.isEmpty() && connectorBoost == 0 && accessionBoost == 0) null else Triple(module, hits, score)
        }.sortedByDescending { it.third }.take(4)

        if (selected.isEmpty()) {
            return ModernMedicalTechnologyReport(
                active = true,
                state = "TECHNOLOGY_MODULE_BASELINE_INDEX_ONLY",
                routingMode = "MODULAR_RETRIEVAL_READY",
                selectedModuleIds = listOf("ACCESSION_REPOSITORY_INDEX"),
                moduleCards = emptyList(),
                matchedTechnologies = emptyList(),
                priorityLookupTerms = modules.first { it.id == "ACCESSION_REPOSITORY_INDEX" }.lookupTerms.take(12),
                evidenceKeysToClose = listOf("accession", "repository", "data_availability_text", "sample_size", "condition_labels", "control_or_comparator"),
                partitionIndexKeys = listOf("retrieval_index", "accession_first", "technology_module_index"),
                retrievalPolicy = "Load only the accession-repository module until a technology-specific term appears.",
                invalidators = listOf("No technology-specific term survived context routing."),
                forbiddenClaims = forbiddenClaims,
                nextAction = "Run accession/source lookup first; do not load broad technology vocabulary until a module trigger appears."
            )
        }

        val cards = selected.map { (module, hits, _) ->
            ModernTechnologyModuleCard(
                moduleId = module.id,
                label = module.label,
                category = module.category,
                matchedTerms = hits.take(12),
                lookupTerms = module.lookupTerms.take(16),
                evidenceKeys = module.evidenceKeys,
                connectors = module.connectors,
                invalidators = module.invalidators,
                forbiddenClaims = forbiddenClaims
            )
        }
        val evidenceKeys = cards.flatMap { it.evidenceKeys }.distinct().let { keys ->
            val missingFirst = metadataClosure.missingFields.filter { it in keys }
            (missingFirst + keys).distinct().take(28)
        }
        val state = when {
            cards.any { it.moduleId == "ACCESSION_REPOSITORY_INDEX" } && metadataClosure.missingFields.contains("accession") -> "TECHNOLOGY_RETRIEVAL_ACCESSION_FIRST"
            cards.any { it.moduleId == "RNA_SINGLE_CELL_SPATIAL_OMICS" } -> "TECHNOLOGY_RNA_OMICS_ROUTE_LINKED"
            cards.any { it.moduleId == "NANO_DELIVERY_EXOSOME_LNP" } -> "TECHNOLOGY_NANO_ROUTE_LINKED_RESEARCH_ONLY"
            cards.any { it.moduleId == "COMPUTATIONAL_MEDICINE_AI_BIOMARKER_DISCOVERY" } -> "TECHNOLOGY_COMPUTATIONAL_ROUTE_NEEDS_VALIDATION"
            else -> "TECHNOLOGY_MODULES_LINKED_METADATA_OPEN"
        }
        val partitions = cards.map { it.category }.distinct() + listOf("accession_first", "evidence_keys", "forbidden_claims")
        return ModernMedicalTechnologyReport(
            active = true,
            state = state,
            routingMode = "MODULAR_RETRIEVAL_SELECTED",
            selectedModuleIds = cards.map { it.moduleId },
            moduleCards = cards,
            matchedTechnologies = cards.flatMap { it.matchedTerms }.distinct().take(24),
            priorityLookupTerms = cards.flatMap { it.lookupTerms }.distinct().take(36),
            evidenceKeysToClose = evidenceKeys,
            partitionIndexKeys = partitions.distinct(),
            retrievalPolicy = "Load selected modules only; do not expand the whole biomedical ontology in one query. Keep accession, platform, sample, control, and outcome fields ahead of mechanism language.",
            invalidators = cards.flatMap { it.invalidators }.distinct().take(18),
            forbiddenClaims = forbiddenClaims,
            nextAction = "Use selected technology modules for secondary lookup; close ${evidenceKeys.take(6).joinToString(", ")} before mechanism, lab-utility, or breakthrough language."
        )
    }

    private fun buildCorpus(
        ontology: BiomedicalResearchOntologyReport,
        conceptBridge: BiomedicalConceptBridgeReport,
        evidencePrior: EvidencePriorSelectionReport,
        ebv: EBVLeadVerificationReport,
        metadataClosure: MetadataClosureReport,
        recentReports: List<String>
    ): String = listOf(
        ontology.selectedDomains.joinToString(" "),
        ontology.matchedTerms.joinToString(" "),
        ontology.queryExpansionKeys.joinToString(" "),
        conceptBridge.selectedBridgeIds.joinToString(" "),
        conceptBridge.matchedConcepts.joinToString(" "),
        conceptBridge.priorityLookupTerms.joinToString(" "),
        conceptBridge.evidenceKeysToClose.joinToString(" "),
        evidencePrior.selectedPriorId,
        evidencePrior.selectedRoute,
        evidencePrior.queryTerms.joinToString(" "),
        ebv.matchedTerms.joinToString(" "),
        metadataClosure.closedFields.joinToString(" "),
        metadataClosure.missingFields.joinToString(" "),
        recentReports.takeLast(10).joinToString(" ")
    ).joinToString(" ").lowercase(Locale.US)
}
