package com.immunesignal.app

/**
 * v1.3.4: Research Reasoning Layer.
 *
 * This layer is intentionally symbolic/rule-based. It does not add ML or new
 * biology axes. Its job is to turn observations and failed searches into a
 * better research question, competing explanations, discriminating evidence,
 * a reframed search plan, and a self-critique. In short: learning remembers;
 * reasoning decides what the failure/result means.
 */
data class ResearchReasoningReport(
    val observation: String,
    val interpretedMeaning: String,
    val generatedQuestions: List<String>,
    val competingHypotheses: List<String>,
    val discriminatorEvidence: List<String>,
    val reframedSearch: String,
    val selfCritique: List<String>,
    val nextReasonedMove: String
) {
    companion object {
        fun empty() = ResearchReasoningReport(
            observation = "No research cycle evaluated yet.",
            interpretedMeaning = "No reasoning state available.",
            generatedQuestions = listOf("What immune trigger-response-outcome question should be explored first?"),
            competingHypotheses = listOf("No competing explanation yet."),
            discriminatorEvidence = listOf("Run an autonomous cycle and inspect useful delta."),
            reframedSearch = "Start with Explore + Deepen + Challenge.",
            selfCritique = listOf("Do not infer causality before evidence gates pass."),
            nextReasonedMove = "Run autonomous researcher mode."
        )
    }
}

object ResearchReasoningEngine {
    fun reason(
        findings: List<ResearchFinding>,
        hypothesisObjects: List<HypothesisObject>,
        datasetCandidates: List<DatasetCandidateV133>,
        pivot: PivotDecision,
        global: GlobalImmuneIntelligenceReport,
        repeatedSkipped: Int,
        reportV3: ResearchReportV3
    ): ResearchReasoningReport {
        val axes = (findings.flatMap { it.matchedAxes } +
            global.axisMap.map { it.axis } +
            datasetCandidates.flatMap { inferAxesFromDatasetCandidate(it) })
            .filter { it.isNotBlank() }
            .distinct()
            .take(8)

        val observation = buildObservation(findings, datasetCandidates, pivot, repeatedSkipped, reportV3)
        val interpretedMeaning = buildMeaning(findings, datasetCandidates, pivot, repeatedSkipped, global)
        val questions = ResearchQuestionGenerator.generate(axes, pivot, findings, global)
        val competing = CompetingHypothesisBuilder.build(axes, findings, global)
        val discriminators = DiscriminatorEngine.build(competing, axes, datasetCandidates, global)
        val reframed = SearchReframingEngine.reframe(pivot, axes, global, reportV3)
        val critique = SelfCriticEngine.critique(findings, hypothesisObjects, datasetCandidates, pivot, repeatedSkipped)
        val nextMove = when {
            reframed.isNotBlank() -> reframed
            reportV3.nextAutonomousMove.isNotBlank() -> reportV3.nextAutonomousMove
            else -> "Run Explore + Deepen + Challenge with dataset-first fallback."
        }

        return ResearchReasoningReport(
            observation = observation,
            interpretedMeaning = interpretedMeaning,
            generatedQuestions = questions,
            competingHypotheses = competing,
            discriminatorEvidence = discriminators,
            reframedSearch = reframed,
            selfCritique = critique,
            nextReasonedMove = nextMove
        )
    }

    private fun buildObservation(
        findings: List<ResearchFinding>,
        datasets: List<DatasetCandidateV133>,
        pivot: PivotDecision,
        repeatedSkipped: Int,
        reportV3: ResearchReportV3
    ): String {
        return when {
            datasets.isNotEmpty() -> "Dataset lead detected: ${datasets.first().datasetId} (${datasets.first().dataType})."
            findings.isNotEmpty() -> "Useful source detected: ${findings.first().title}."
            pivot.pivotType != "NO_PIVOT" -> "No useful source survived; pivot selected: ${pivot.pivotType}. Repeated skipped: $repeatedSkipped."
            repeatedSkipped > 0 -> "Search mostly repeated known sources ($repeatedSkipped skipped) with no useful delta."
            else -> "Cycle result: ${reportV3.cycleResult}."
        }
    }

    private fun buildMeaning(
        findings: List<ResearchFinding>,
        datasets: List<DatasetCandidateV133>,
        pivot: PivotDecision,
        repeatedSkipped: Int,
        global: GlobalImmuneIntelligenceReport
    ): String {
        return when {
            datasets.isNotEmpty() -> "The research should move from literature titles toward dataset verification and outcome-label inspection."
            findings.any { it.evidence.speciesClass == "human" } -> "At least one human-relevant source can update the hypothesis ledger, subject to evidence locks."
            findings.isNotEmpty() -> "The lead is mechanistic or weakly grounded; use it for plausibility, not proof."
            pivot.pivotType != "NO_PIVOT" -> "The failed path is informative: the current query layer is likely too broad, exhausted, or using the wrong biological vocabulary."
            repeatedSkipped >= 10 -> "The source family is saturated; rotate away from known PubMed IDs toward datasets, contradiction terms, negative controls, or outcome labels without adding biology axes."
            global.globalHypotheses.isNotEmpty() -> "The global baseline exists, but it still lacks enough dataset-backed evidence to become a locked hypothesis."
            else -> "No meaningful interpretation yet; the next cycle must generate a sharper question."
        }
    }

    private fun inferAxesFromDatasetCandidate(candidate: DatasetCandidateV133): List<String> {
        val text = listOf(candidate.dataType, candidate.conditionHint, candidate.outcomeLabelsHint, candidate.sourceTitle).joinToString(" ").lowercase()
        val axes = mutableListOf<String>()
        if (text.contains("interferon") || text.contains("viral")) axes += "interferon_antiviral_axis"
        if (text.contains("rna") || text.contains("transcript")) axes += "rna_transcriptomic_axis"
        if (text.contains("single-cell") || text.contains("single cell")) axes += "cell_state_axis"
        if (text.contains("severity") || text.contains("outcome")) axes += "outcome_label_axis"
        if (text.contains("allergy") || text.contains("asthma")) axes += "type2_allergy_axis"
        return axes
    }
}

object ResearchQuestionGenerator {
    fun generate(
        axes: List<String>,
        pivot: PivotDecision,
        findings: List<ResearchFinding>,
        global: GlobalImmuneIntelligenceReport
    ): List<String> {
        val out = mutableListOf<String>()
        if (pivot.pivotType != "NO_PIVOT") {
            out += "What does the failed search imply: exhausted vocabulary, weak evidence lane, or missing dataset labels?"
        }
        if (axes.any { it.contains("regulatory") || it.contains("resolution") }) {
            out += "Is the 'regulatory brake' visible as IL-10/Treg/FOXP3/resolution markers rather than the phrase itself?"
        }
        if (axes.any { it.contains("interferon") || it.contains("viral") }) {
            out += "Does timing of interferon separate protective viral control from tissue-damaging inflammation?"
        }
        if (axes.any { it.contains("rna") || it.contains("cell_state") }) {
            out += "Do transcriptomic or single-cell datasets reveal the immune state before routine cytokines change?"
        }
        if (findings.isEmpty() && global.datasetCandidates.isEmpty()) {
            out += "Which public dataset family is more promising next: GEO/GSE, ImmPort/SDY, or single-cell atlases?"
        }
        if (out.isEmpty()) out += "Which trigger-response-outcome chain changed most in this cycle?"
        return out.distinct().take(5)
    }
}

object CompetingHypothesisBuilder {
    fun build(
        axes: List<String>,
        findings: List<ResearchFinding>,
        global: GlobalImmuneIntelligenceReport
    ): List<String> {
        val out = mutableListOf<String>()
        if (axes.any { it.contains("interferon") }) {
            out += "A: Early interferon supports recovery; late or excessive interferon contributes to tissue damage."
            out += "B: Viral load rises first; interferon is delayed and secondary inflammation follows."
        }
        if (axes.any { it.contains("tnf") || it.contains("il6") || it.contains("tissue_damage") }) {
            out += "C: Severity is driven more by TNF/IL-6 and tissue-damage loops than by the initial trigger."
        }
        if (axes.any { it.contains("regulatory") || it.contains("resolution") }) {
            out += "D: Failure of IL-10/Treg/resolution programs explains persistence better than trigger strength."
        }
        if (axes.any { it.contains("type2") }) {
            out += "E: Allergy-like Type-2 activation is a false-alarm module, not a direct model of antiviral response."
        }
        if (findings.isEmpty() && global.globalHypotheses.isNotEmpty()) {
            out += "F: The baseline hypothesis may be too broad; it needs narrower disease/time-course framing."
        }
        if (out.isEmpty()) out += "A: The current signal may be a search artifact until a dataset-backed axis appears."
        return out.distinct().take(6)
    }
}

object DiscriminatorEngine {
    fun build(
        competing: List<String>,
        axes: List<String>,
        datasets: List<DatasetCandidateV133>,
        global: GlobalImmuneIntelligenceReport
    ): List<String> {
        val out = mutableListOf<String>()
        if (competing.any { it.startsWith("A:") || it.startsWith("B:") }) {
            out += "Need time-course data: viral load, interferon markers, inflammatory cytokines, and outcome labels in the same cohort."
        }
        if (competing.any { it.startsWith("C:") }) {
            out += "Need tissue-damage or severity labels to separate inflammatory response from actual damage."
        }
        if (competing.any { it.startsWith("D:") }) {
            out += "Need IL-10/Treg/FOXP3/resolution markers or cell-state labels, not only generic cytokine terms."
        }
        if (axes.any { it.contains("rna") } || datasets.any { it.dataType.contains("RNA", ignoreCase = true) }) {
            out += "Need RNA-seq/single-cell metadata with species, sample size, condition, and recovery/severity labels."
        }
        if (global.datasetCandidates.isEmpty() && datasets.isEmpty()) {
            out += "Need at least one verifiable GSE/GEO/SDY/ImmPort accession before modeling."
        }
        if (out.isEmpty()) out += "Need a dataset that contains trigger, response axis, and outcome in one study."
        return out.distinct().take(5)
    }
}

object SearchReframingEngine {
    fun reframe(
        pivot: PivotDecision,
        axes: List<String>,
        global: GlobalImmuneIntelligenceReport,
        reportV3: ResearchReportV3
    ): String {
        if (pivot.pivotType != "NO_PIVOT") {
            val seed = pivot.nextQuerySeed.ifBlank { "human immune response dataset outcome labels" }
            return when (pivot.pivotType) {
                "MECHANISM_TO_DATASET", "GENERAL_TO_DATASET" -> "Reframe from mechanism words to dataset identifiers: GSE/GEO/ImmPort/SDY + $seed."
                "METADATA_TO_TOP_ABSTRACTS" -> "Reframe by reviewing only top eligible abstracts, then extract trigger-response-outcome phrases."
                "GENERAL_TO_CONTRADICTION", "STALLED_TO_CHALLENGE" -> "Reframe as contradiction search: look for nonresponse, heterogeneity, or harmful timing evidence."
                "REPEAT_TO_EVIDENCE_LANE_ROTATION" -> "Reframe to scope-safe evidence-lane rotation: contradiction terms + negative controls + longitudinal outcome labels, using existing axes only."
                else -> "Reframe next search intent to ${pivot.nextIntent}: $seed."
            }
        }
        if (global.nextGlobalDatasetNeeded.isNotBlank()) return "Search next for: ${global.nextGlobalDatasetNeeded}"
        return reportV3.nextAutonomousMove.ifBlank { "Move from broad terms to marker/gene/cell-state/time-course terms." }
    }
}

object SelfCriticEngine {
    fun critique(
        findings: List<ResearchFinding>,
        hypotheses: List<HypothesisObject>,
        datasets: List<DatasetCandidateV133>,
        pivot: PivotDecision,
        repeatedSkipped: Int
    ): List<String> {
        val out = mutableListOf<String>()
        if (findings.isEmpty() && datasets.isEmpty()) out += "No discovery claim is allowed: no useful source or dataset candidate survived this cycle."
        if (repeatedSkipped >= 10) out += "Risk: the engine may be circling an exhausted PubMed neighborhood; apply cooldown to repeated queries."
        if (findings.any { it.evidence.speciesClass != "human" }) out += "Risk: animal/cell-only evidence must not be treated as human immune behavior."
        if (findings.any { it.sanityFlags.contains("METADATA_ONLY") }) out += "Risk: title/metadata can mislead; mechanism claims require abstract or dataset verification."
        if (hypotheses.none { it.status == "STRONG_SIGNAL" || it.discoveryState == "Active" }) out += "No hypothesis is strong yet; keep competing explanations alive."
        if (pivot.pivotType != "NO_PIVOT") out += "The pivot is a research tactic, not evidence that the hypothesis is correct."
        if (out.isEmpty()) out += "Keep falsification active: every upgraded hypothesis needs a contradiction search."
        return out.distinct().take(6)
    }
}
