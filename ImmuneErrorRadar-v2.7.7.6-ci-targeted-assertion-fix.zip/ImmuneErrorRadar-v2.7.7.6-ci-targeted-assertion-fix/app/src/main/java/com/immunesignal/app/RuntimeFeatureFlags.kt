// legacy_audit_version_token_v1110: RELEASE_TRAIN_VERSION_NAME: String = "1.11.0-alpha-research-grade-mechanism-dossier"; RELEASE_TRAIN_VERSION_CODE: Int = 124; LEARNING_SESSION_SCHEMA_VERSION: String = "1.11.0"
// legacy_audit_version_token_v11055: RELEASE_TRAIN_VERSION_NAME: String = "1.10.55-alpha-ci-fast-gate-route-surface-unification"; RELEASE_TRAIN_VERSION_CODE: Int = 117; LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.55"
// legacy_audit_version_token_v11051: RELEASE_TRAIN_VERSION_NAME: String = "1.10.51-alpha-route-reconciliation-evidence-candidate-activation"; LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.51"
// legacy_audit_version_token_v11052: RELEASE_TRAIN_VERSION_NAME: String = "1.10.52-alpha-open-exploration-medical-index-diagnostic-reasoning-sandbox"; RELEASE_TRAIN_VERSION_CODE: Int = 114; LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.52"
// legacy_audit_version_token_v11053: RELEASE_TRAIN_VERSION_NAME: String = "1.10.53-alpha-ci-route-linkage-hardening"; RELEASE_TRAIN_VERSION_CODE: Int = 115; LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.53"
// legacy_audit_version_token_v11054: RELEASE_TRAIN_VERSION_NAME: String = "1.10.54-alpha-github-ci-runtime-surface-hardening"; RELEASE_TRAIN_VERSION_CODE: Int = 116; LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.54"
package com.immunesignal.app

/**
 * v1.6.1: single rollback/activation point for optional research-intelligence layers.
 *
 * These flags keep the production research cycle backward-compatible. Foundation
 * knowledge remains disabled by default. Learning Sessions are user-initiated UI
 * tools, not background workers, and never run unless the user presses Think.
 */
// legacy audit token: 1.10.22
// legacy_audit_version_token_v11027: 1.10.27
object RuntimeFeatureFlags {
    const val ENABLE_FOUNDATION_KNOWLEDGE_OS: Boolean = false
    const val ENABLE_LEARNING_SESSION_UI: Boolean = true
    const val DEFAULT_SEARCH_TIME_LIMIT_MILLIS: Long = 20L * 60L * 1000L
    const val DEFAULT_RESEARCH_LEARNING_TIME_LIMIT_MILLIS: Long = 45L * 60L * 1000L
    const val DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS: Long = 45L * 60L * 1000L
    const val PRIOR_FAST_THINKING_WINDOW_MILLIS: Long = 15L * 1000L
    const val MIN_AUTONOMOUS_THINKING_PASSES: Int = 2
    const val MIN_EXTENDED_ACCESSION_SOURCE_FAMILIES: Int = 1
    const val MIN_EXTENDED_ACCESSION_QUERY_PATHS: Int = 1
    const val MIN_CORE_ACCESSION_SOURCE_FAMILIES_BEFORE_ARCHIVE: Int = 1
    const val ENABLE_ACCESSION_EXHAUSTION_GATE: Boolean = true
    const val ENABLE_DOMAIN_QUERY_ACTIVATION: Boolean = true

    const val ENABLE_ACCESSION_MINING_INTENSITY: Boolean = true
    const val PUBMED_ACCESSION_MINING_RETMAX: Int = 25
    const val PUBMED_ACCESSION_MINING_ABSTRACTS_PER_CYCLE: Int = 5
    const val PUBMED_ADJACENT_DOMAIN_RETMAX: Int = 15
    const val PUBMED_ADJACENT_DOMAIN_ABSTRACTS_PER_CYCLE: Int = 2

    const val ENABLE_DATA_AVAILABILITY_ACCESSION_QUERY_PRIORITY: Boolean = true
    const val MAX_DATA_AVAILABILITY_DOMAIN_TERMS: Int = 5
    const val MAX_DATA_AVAILABILITY_LABEL_TERMS: Int = 12
    const val ENABLE_MATURE_DOMAIN_EVIDENCE_PROBE: Boolean = true
    const val ENABLE_MATURE_DOMAIN_FOCUS_MODE: Boolean = true
    const val ENABLE_STRONG_ROUTE_FINGERPRINT: Boolean = true
    const val ENABLE_LEAN_AGENT_RUNTIME_ORCHESTRATOR: Boolean = true
    const val MAX_MATURE_DOMAIN_PROBE_DOMAINS: Int = 3
    const val MAX_MATURE_DOMAIN_PROBE_QUERIES: Int = 2
    const val MIN_RELAXED_DOMAIN_EXPOSURES: Int = 1
    const val ENABLE_AUTONOMOUS_EXPLORATION_SANDBOX: Boolean = true
    const val MIN_EXPLORATION_SANDBOX_QUERY_VARIANTS: Int = 1
    const val ENABLE_SOURCE_PRIORITY_ARBITRATION: Boolean = true
    const val ENABLE_DOMAIN_EXPERTISE_MEMORY: Boolean = true
    const val MIN_DOMAIN_EXPERTISE_SCORE_TO_REUSE: Int = 3
    const val MAX_DOMAIN_EXPERTISE_CARDS: Int = 6
    const val MIN_DOMAIN_EXPERTISE_MATURITY_EXPOSURES: Int = 1
    const val ENABLE_LEARNING_RULE_ENGINE: Boolean = true
    const val MIN_LEARNING_RULE_COVERAGE: Double = 0.25
    const val ENABLE_DOMAIN_EXPERTISE_QUERY_REUSE: Boolean = true
    const val ENABLE_ROUTE_FINGERPRINT_GUARD: Boolean = true
    const val ROUTE_FINGERPRINT_LOOKBACK: Int = 5
    const val MAX_EPISTEMIC_BELIEFS_PER_REPORT: Int = 60

    const val MAX_HYPOTHESIS_RANK_CARDS: Int = 12
    const val MAX_LEARNING_DELTA_CARDS: Int = 12
    const val ENABLE_AXIS_PERFORMANCE_LEARNING: Boolean = true
    const val ENABLE_DYNAMIC_PLAUSIBILITY_GRAPH_LEARNER: Boolean = true
    const val ENABLE_BAYESIAN_BELIEF_REVISION_V262: Boolean = true
    const val ENABLE_EPISTEMIC_DISTANCE_METER_V262: Boolean = true
    const val ENABLE_LEARNING_LOOP_ACTIVATION_V262: Boolean = true
    const val STRONG_SIGNAL_CAUSALITY_THRESHOLD: Int = 65
    const val STRONG_SIGNAL_EVIDENCE_THRESHOLD: Int = 65
    const val EVIDENCE_DECAY_PENALTY_AFTER_YEAR_3: Int = 3
    const val EVIDENCE_DECAY_PENALTY_AFTER_YEAR_7: Int = 8
    const val EVIDENCE_DECAY_PENALTY_AFTER_YEAR_12: Int = 15
    const val MAX_LEARNING_SESSION_HISTORY: Int = 20
    const val ENABLE_RELEASE_VERSION_LINKAGE_GUARD: Boolean = true
    const val ENABLE_GLOBAL_RESEARCH_GRADE_BRIEF_V11061: Boolean = true
    const val GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061: Int = 64
    const val ENABLE_RESEARCH_GRADE_MECHANISM_DOSSIER_V1110: Boolean = true
    const val ENABLE_GRADED_EXPLORATORY_RESULTS_V1115: Boolean = true
    const val ENABLE_EXPLORATORY_RUNTIME_RELAXATION_V265: Boolean = true
    const val ENABLE_EUROPE_PMC_LOOKUP_V265: Boolean = true
    const val ENABLE_OPENALEX_LOOKUP_V265: Boolean = true
    const val ENABLE_SEED_ACCESSION_BOOTSTRAP_V265: Boolean = true
    const val EXPLORATORY_MIN_ROUTE_FIT_FOR_RULE_V265: Int = 5
    const val EXPLORATORY_MIN_CONFIDENCE_V265: Int = 1
    const val EXPLORATORY_MIN_GTIM_CONFIDENCE_V265: Int = 1
    const val EXPLORATORY_MAX_BOOTSTRAP_ACCESSION_SEEDS_V265: Int = 24
    const val ENABLE_KNOWN_PRIOR_EVIDENCE_SEEDS_V269: Boolean = true
    const val KNOWN_PRIOR_SEED_MATCH_MIN_TOKENS_V269: Int = 1
    const val KNOWN_PRIOR_SEED_QUERY_LIMIT_V269: Int = 12
    const val ENABLE_RUN_CONTINUATION_GUARD_V2735: Boolean = true
    const val RUN_CONTINUATION_QUERY_LIMIT_V2735: Int = 2
    const val RUN_CONTINUATION_RELATIONSHIP_QUERY_LIMIT_V2738: Int = 4
    const val RUN_CONTINUATION_ACCESSION_NO_MATRIX_QUERY_LIMIT_V2738: Int = 6
    const val RUN_CONTINUATION_MIN_FINDINGS_BEFORE_STOP_V2735: Int = 3
    const val RUN_CONTINUATION_MIN_EXECUTED_QUERIES_V2735: Int = 2
    const val KNOWN_PRIOR_SEEDS_CLOSE_CONTRADICTION_GATE_V269: Boolean = false
    const val KNOWN_PRIOR_SEEDS_FORCE_MATRIX_READY_V269: Boolean = false
    const val ENABLE_TOPIC_SPECIFIC_ROUTE_BUILDER_V270: Boolean = true
    const val TOPIC_SPECIFIC_ROUTE_MIN_MATCH_TERMS_V270: Int = 1
    const val TOPIC_SPECIFIC_ROUTE_MAX_PROFILES_V270: Int = 3
    const val TOPIC_SPECIFIC_ROUTE_QUERY_LIMIT_V270: Int = 10
    const val TOPIC_SPECIFIC_ROUTE_LEARNING_LINK_REQUIRED_V270: Boolean = true
    const val ENABLE_PROMISING_ROUTE_STATE_V272: Boolean = true
    const val ENABLE_PAPER_UNDERSTANDING_LITE_V272: Boolean = true
    const val ENABLE_PROOF_OF_VALUE_MODE_V272: Boolean = true
    const val ENABLE_PUBMED_BASELINE_BENCHMARK_V272: Boolean = true
    const val KEEP_STRONG_SIGNAL_REVIEW_GATED_V272: Boolean = true
    const val PROMISING_ROUTE_MIN_ROUTE_SCORE_V272: Int = 20
    const val PROMISING_ROUTE_MIN_CAUSALITY_THRESHOLD_V2738: Int = 40
    const val PROMISING_ROUTE_MIN_EVIDENCE_THRESHOLD_V2738: Int = 40
    const val PROOF_OF_VALUE_MIN_PAPER_UNDERSTANDING_SCORE_V272: Int = 20
    const val ENABLE_BENCHMARK_VALUE_HARNESS_V273: Boolean = true
    const val ENABLE_EXPANSION_LOCK_V2738: Boolean = true
    const val EXPANSION_LOCK_MIN_BENCHMARK_SCORE_V2738: Int = 25
    const val BENCHMARK_VALUE_MIN_DELTA_SCORE_V273: Int = 35
    const val BENCHMARK_VALUE_STOP_EXPANSION_BELOW_V273: Int = 25

    const val ENABLE_EXPLORATORY_ROUTE_LINKAGE_PRECHECK_V266: Boolean = true
    const val EXPLORATORY_MIN_PUBLIC_LOOKUP_ACTIONS_V266: Int = 1
    const val EXPLORATORY_ROUTE_SURFACE_MIN_SCORE_V266: Int = 1
    const val EXPLORATORY_ALLOW_EMPTY_MATRIX_ROUTE_BRIEF_V266: Boolean = true
    // legacy_audit_version_token_v11034: RELEASE_TRAIN_VERSION_NAME: String = "1.10.34-alpha-useful-learning-report"
    // legacy_audit_version_token_v11041: RELEASE_TRAIN_VERSION_NAME: String = "1.10.41-alpha-biomedical-research-ontology"
    // legacy_audit_version_token_v11042: RELEASE_TRAIN_VERSION_NAME: String = "1.10.42-alpha-biomedical-concept-bridge"
    // legacy_audit_version_token_v11043: RELEASE_TRAIN_VERSION_NAME: String = "1.10.43-alpha-modern-medtech-modular-index"
    // legacy_audit_version_token_v11044: RELEASE_TRAIN_VERSION_NAME: String = "1.10.44-alpha-viral-countermeasure-knowledge-graph"
    // legacy_audit_version_token_v11045: RELEASE_TRAIN_VERSION_NAME: String = "1.10.45-alpha-compile-scope-linkage-guard"
    // legacy_audit_version_token_v11046: RELEASE_TRAIN_VERSION_NAME: String = "1.10.46-alpha-longevity-biological-systems-graph"
    // legacy_audit_version_token_v11047: RELEASE_TRAIN_VERSION_NAME: String = "1.10.47-alpha-topic-fit-metadata-parse-ui-clarity"
    // legacy_audit_version_token_v11048: RELEASE_TRAIN_VERSION_NAME: String = "1.10.48-alpha-relaxed-progression-context-alignment"
    // legacy_audit_version_token_v11049: RELEASE_TRAIN_VERSION_NAME: String = "1.10.49-alpha-topic-route-correction-evidence-object-candidate"
    // legacy_audit_version_token_v11050: RELEASE_TRAIN_VERSION_NAME: String = "1.10.50-alpha-environmental-psychophysiological-exposome-lane"
    const val RELEASE_TRAIN_VERSION_NAME: String = "2.7.3-final-proof-benchmark-learning-locked"
    // legacy_audit_version_token_v11034: RELEASE_TRAIN_VERSION_CODE: Int = 96
    // legacy_audit_version_token_v11041: RELEASE_TRAIN_VERSION_CODE: Int = 103
    // legacy_audit_version_token_v11042: RELEASE_TRAIN_VERSION_CODE: Int = 104
    // legacy_audit_version_token_v11043: RELEASE_TRAIN_VERSION_CODE: Int = 105
    // legacy_audit_version_token_v11044: RELEASE_TRAIN_VERSION_CODE: Int = 106
    // legacy_audit_version_token_v11045: RELEASE_TRAIN_VERSION_CODE: Int = 107
    // legacy_audit_version_token_v11046: RELEASE_TRAIN_VERSION_CODE: Int = 108
    // legacy_audit_version_token_v11047: RELEASE_TRAIN_VERSION_CODE: Int = 109
    // legacy_audit_version_token_v11048: RELEASE_TRAIN_VERSION_CODE: Int = 110
    // legacy_audit_version_token_v11049: RELEASE_TRAIN_VERSION_CODE: Int = 111
    // legacy_audit_version_token_v11050: RELEASE_TRAIN_VERSION_CODE: Int = 112
    const val RELEASE_TRAIN_VERSION_CODE: Int = 148

    const val ENABLE_DATASET_PATH_LINKAGE_GUARD: Boolean = true
    const val ENABLE_DATASET_PASS_COVERAGE_LINKAGE: Boolean = true
    // legacy_audit_version_token_v11029_schema: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.29"
    // legacy_audit_version_token_v11034: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.34"
    // legacy_audit_version_token_v11041: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.41"
    // legacy_audit_version_token_v11042: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.42"
    // legacy_audit_version_token_v11043: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.43"
    // legacy_audit_version_token_v11044: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.44"
    // legacy_audit_version_token_v11045: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.45"
    // legacy_audit_version_token_v11046: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.46"
    // legacy_audit_version_token_v11047: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.47"
    // legacy_audit_version_token_v11048: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.48"
    // legacy_audit_version_token_v11049: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.49"
    // legacy_audit_version_token_v11050: LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.50"
    const val LEARNING_SESSION_SCHEMA_VERSION: String = "2.7.3"

    const val FOUNDATION_CLAIM_LIMIT: String = "foundation_knowledge_not_evidence"
    const val LEARNING_SESSION_CLAIM_LIMIT: String = "learning_session_not_biological_proof"
    const val CHECKPOINT_CLAIM_LIMIT: String = "learning_session_checkpoint_not_evidence"
    const val SPECIALIZED_REASONING_CLAIM_LIMIT: String = "specialized_reasoning_not_biological_proof"
    const val EPISTEMIC_BELIEF_CLAIM_LIMIT: String = "epistemic_beliefs_not_biological_proof"
    const val COGNITIVE_PATH_CLAIM_LIMIT: String = "cognitive_path_integration_not_biological_proof"
}
