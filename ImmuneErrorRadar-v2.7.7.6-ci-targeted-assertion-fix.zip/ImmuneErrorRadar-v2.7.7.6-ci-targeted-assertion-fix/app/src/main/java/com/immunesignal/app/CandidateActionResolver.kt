package com.immunesignal.app

/**
 * v1.5.8: single candidate action resolver for auto-light learning.
 *
 * The bug this layer fixes is a split-brain decision path: ML triage could mark
 * a direct dataset candidate as LOW_PRIORITY while RouteFitGate marked it
 * IN_ROUTE with a high score. Search-time learning should not stop there.
 * Strong direct accessions get at least a minimum metadata parse; this still
 * does not upgrade any biological hypothesis. v1.10.48 lowers strictness only
 * for research progression: repeated weak/off-route candidates can be inspected
 * as OFF_ROUTE_MINIMUM_METADATA_PROBE instead of being dead-stopped.
 */
enum class CandidateAction {
    PARSE_FULL,
    PARSE_MINIMUM_METADATA,
    LOW_PRIORITY_SAVE_ONLY,
    SKIP_SIMILAR,
    BLOCK_OFF_ROUTE
}

data class CandidateActionDecision(
    val accession: String,
    val action: CandidateAction,
    val reason: String,
    val routeFitScore: Int,
    val triageAction: String,
    val forcesMinimumMetadata: Boolean,
    val claimLimit: String = "candidate_action_not_biological_proof"
)

data class CandidateActionReport(
    val active: Boolean,
    val decisions: List<CandidateActionDecision>,
    val parseAccessions: List<String>,
    val minimumMetadataAccessions: List<String>,
    val blockedAccessions: List<String>,
    val summary: String,
    val claimLimit: String = "candidate_action_not_biological_proof"
) {
    companion object {
        fun empty() = CandidateActionReport(
            active = false,
            decisions = emptyList(),
            parseAccessions = emptyList(),
            minimumMetadataAccessions = emptyList(),
            blockedAccessions = emptyList(),
            summary = "Candidate action resolver was not evaluated in this cycle."
        )
    }
}

object CandidateActionResolver {
    private val directAccessionPrefixes = listOf("GSE", "GDS", "PRJNA", "SRP", "SDY")

    fun resolve(
        candidates: List<DatasetAccessionCandidate>,
        triageResults: List<TriageResult>,
        routeFits: List<DatasetRouteFitAssessment>
    ): CandidateActionReport {
        if (candidates.isEmpty()) return CandidateActionReport.empty()
        val triageByAccession = triageResults.associateBy { it.accession }
        val routeByAccession = routeFits.associateBy { it.accession }
        val initialDecisions = candidates.map { candidate ->
            decide(candidate, triageByAccession[candidate.accession], routeByAccession[candidate.accession])
        }
        val decisions = forceMinimumMetadataWhenStalled(candidates, initialDecisions, routeByAccession)
        val parse = decisions.filter { it.action == CandidateAction.PARSE_FULL || it.action == CandidateAction.PARSE_MINIMUM_METADATA }
            .map { it.accession }
            .distinct()
        val minimum = decisions.filter { it.action == CandidateAction.PARSE_MINIMUM_METADATA }
            .map { it.accession }
            .distinct()
        val blocked = decisions.filter { it.action == CandidateAction.BLOCK_OFF_ROUTE }
            .map { it.accession }
            .distinct()
        val forced = decisions.count { it.forcesMinimumMetadata }
        return CandidateActionReport(
            active = true,
            decisions = decisions,
            parseAccessions = parse,
            minimumMetadataAccessions = minimum,
            blockedAccessions = blocked,
            summary = "CandidateActionResolver evaluated ${decisions.size} candidate(s); ${parse.size} selected for parsing, ${minimum.size} minimum-metadata forced, ${blocked.size} blocked off-route. v1.10.48 relaxed progression lowers strictness for metadata visibility only: weak/off-route candidates may become OFF_ROUTE_MINIMUM_METADATA_PROBE, while claim upgrade remains blocked until accession/control/time/outcome/contradiction gates close."
        )
    }

    private fun forceMinimumMetadataWhenStalled(
        candidates: List<DatasetAccessionCandidate>,
        decisions: List<CandidateActionDecision>,
        routeByAccession: Map<String, DatasetRouteFitAssessment>
    ): List<CandidateActionDecision> {
        val alreadyParsing = decisions.any { it.action == CandidateAction.PARSE_FULL || it.action == CandidateAction.PARSE_MINIMUM_METADATA }
        if (alreadyParsing || candidates.size < 2) return decisions
        val forcedAccessions = candidates
            .sortedWith(compareByDescending<DatasetAccessionCandidate> { it.usabilityScore }
                .thenByDescending { routeByAccession[it.accession]?.routeFitScore ?: 0 }
                .thenByDescending { contextAlignmentPriority(it) })
            .take(if (candidates.size >= 6) 3 else 2)
            .map { it.accession }
            .toSet()
        return decisions.map { decision ->
            if (decision.accession in forcedAccessions) {
                decision.copy(
                    action = CandidateAction.PARSE_MINIMUM_METADATA,
                    reason = "OFF_ROUTE_MINIMUM_METADATA_PROBE: candidate set stalled with zero parsed metadata; force minimum metadata visibility only, while keeping hypothesis upgrade blocked.",
                    forcesMinimumMetadata = true
                )
            } else {
                decision
            }
        }
    }

    private fun decide(
        candidate: DatasetAccessionCandidate,
        triage: TriageResult?,
        routeFit: DatasetRouteFitAssessment?
    ): CandidateActionDecision {
        val routeScore = routeFit?.routeFitScore ?: 0
        val triageAction = triage?.action ?: "NOT_TRIAGED"
        val direct = hasDirectAccession(candidate.accession)
        val blocked = routeFit?.blocksHypothesisUpgrade == true && routeScore < 20
        val weakButInspectable = candidate.usabilityScore >= 8 || contextAlignmentPriority(candidate) >= 2

        val action = when {
            direct && routeScore >= 85 -> CandidateAction.PARSE_MINIMUM_METADATA
            weakButInspectable && routeScore >= 20 -> CandidateAction.PARSE_MINIMUM_METADATA
            blocked -> CandidateAction.BLOCK_OFF_ROUTE
            triageAction == "PARSE" -> CandidateAction.PARSE_FULL
            triageAction == "PARSE_WITH_CAUTION" -> CandidateAction.PARSE_MINIMUM_METADATA
            direct && routeScore >= 70 -> CandidateAction.PARSE_MINIMUM_METADATA
            triageAction == "SKIP_SIMILAR" -> CandidateAction.SKIP_SIMILAR
            else -> CandidateAction.LOW_PRIORITY_SAVE_ONLY
        }
        val forced = action == CandidateAction.PARSE_MINIMUM_METADATA && triageAction !in listOf("PARSE", "PARSE_WITH_CAUTION")
        val reason = when (action) {
            CandidateAction.PARSE_FULL -> "Triage selected full parse."
            CandidateAction.PARSE_MINIMUM_METADATA -> if (forced) {
                "Relaxed progression: direct/context-aligned candidate requires minimum metadata parse even when ML triage is cautious; no hypothesis upgrade allowed."
            } else {
                "Candidate is parse-worthy but remains locked to metadata inspection before any upgrade."
            }
            CandidateAction.LOW_PRIORITY_SAVE_ONLY -> "Saved as a low-priority lead; no parsing cycle consumed."
            CandidateAction.SKIP_SIMILAR -> "Skipped as similar/metadata-thin unless future failure memory asks for it."
            CandidateAction.BLOCK_OFF_ROUTE -> "Blocked as off-route for this target; useful only as contrast/re-route."
        }
        return CandidateActionDecision(
            accession = candidate.accession,
            action = action,
            reason = reason,
            routeFitScore = routeScore,
            triageAction = triageAction,
            forcesMinimumMetadata = forced
        )
    }


    private fun contextAlignmentPriority(candidate: DatasetAccessionCandidate): Int {
        val text = listOf(
            candidate.accession,
            candidate.sourceTitle,
            candidate.conditionLabelsHint,
            candidate.outcomeLabelsHint,
            candidate.triggerResponseOutcomeHint,
            candidate.dataType,
            candidate.reasons.joinToString(" ")
        ).joinToString(" ").lowercase()
        var score = 0
        if (listOf("ebv", "epstein", "hhv-6", "cmv", "long covid", "me/cfs", "vaccine", "antibiotic", "microbiome", "sleep", "circadian", "cortisol", "hrv", "mitochond", "crp", "il-6", "tnf").any { text.contains(it) }) score += 2
        if (listOf("control", "comparator", "healthy", "cohort", "longitudinal", "serial", "baseline", "follow-up", "case", "outcome", "response").any { text.contains(it) }) score += 2
        if (listOf("gse", "prjna", "srp", "sdy", "e-mtab", "srr", "data availability", "supplementary").any { text.contains(it) }) score += 1
        return score
    }

    private fun hasDirectAccession(accession: String): Boolean {
        val normalized = accession.trim().uppercase()
        return normalized.isNotBlank() && normalized != "DATASET_ACCESSION_UNRESOLVED" && directAccessionPrefixes.any { normalized.startsWith(it) }
    }
}
