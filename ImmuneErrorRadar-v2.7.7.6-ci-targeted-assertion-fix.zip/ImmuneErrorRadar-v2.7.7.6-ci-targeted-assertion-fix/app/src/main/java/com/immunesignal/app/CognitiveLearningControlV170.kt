package com.immunesignal.app

import java.util.Locale
import kotlin.math.abs

/**
 * v1.7.0+: closed cognitive-learning control layer.
 *
 * These reports are not new biology modules. They sit above the existing
 * v1.4-v1.6 engines and make each cycle measurable: what directive was stored,
 * applied, measured, retired, or replay-blocked; what query has the highest
 * expected evidence gain; which beliefs may route; how causal-ready the evidence
 * is; which reflection lesson prevents the next repeated mistake; and whether a
 * mini peer-review would hold or reject the current upgrade.
 */
data class DirectiveLifecycleReport(
    val active: Boolean,
    val state: String,
    val previousDirectiveApplied: Boolean,
    val expectedEffect: String,
    val observedEffect: String,
    val improved: Boolean,
    val retiredOrReplayBlocked: Boolean,
    val nextDirectiveState: String,
    val nextAction: String,
    val visibleBrief: String,
    val claimLimit: String = "directive_lifecycle_not_biological_proof"
) {
    companion object {
        fun empty() = DirectiveLifecycleReport(
            active = false,
            state = "NO_DIRECTIVE",
            previousDirectiveApplied = false,
            expectedEffect = "No stored directive was available.",
            observedEffect = "No directive outcome was measured.",
            improved = false,
            retiredOrReplayBlocked = false,
            nextDirectiveState = "PROPOSED_AFTER_CURRENT_REPORT",
            nextAction = "Store the next integrated cognitive directive after this report is saved.",
            visibleBrief = "No directive lifecycle was measured yet.",
            claimLimit = "directive_lifecycle_not_biological_proof"
        )
    }
}

object DirectiveLifecycleEngine {
    fun evaluate(
        nextCyclePlan: CognitiveNextCyclePlan,
        calibrationReport: CognitiveLoopCalibrationReport,
        cognitivePathIntegrationReport: CognitivePathIntegrationReport
    ): DirectiveLifecycleReport {
        val hasDirective = nextCyclePlan.directiveId != null
        if (!hasDirective && !cognitivePathIntegrationReport.active) return DirectiveLifecycleReport.empty()
        val applied = nextCyclePlan.active && nextCyclePlan.appliedQueryCount > 0
        val retired = nextCyclePlan.directiveConsumed || (nextCyclePlan.suppressedReason?.contains("consumed", true) == true)
        val measured = calibrationReport.active
        val helped = calibrationReport.outcome == "DIRECTIVE_HELPED"
        val mixed = calibrationReport.outcome == "MIXED_PROGRESS"
        val state = when {
            applied && measured && helped -> "APPLIED_MEASURED_REWARDED"
            applied && measured && mixed -> "APPLIED_MEASURED_MIXED"
            applied && measured -> "APPLIED_MEASURED_PENALIZED"
            retired && nextCyclePlan.consumptionReason == "retired_noop_or_already_satisfied" -> "RETIRED_ALREADY_SATISFIED"
            retired -> "APPLIED_OR_RETIRED_SINGLE_USE"
            hasDirective -> "DIRECTIVE_SEEN_NOT_APPLIED"
            else -> "NEXT_DIRECTIVE_PROPOSED"
        }
        val expected = when {
            nextCyclePlan.appliedTerms.isNotEmpty() -> "Expected to close: ${nextCyclePlan.appliedTerms.take(6).joinToString(", ")}."
            cognitivePathIntegrationReport.decision.requiredEvidence.isNotEmpty() -> "Expected to request: ${cognitivePathIntegrationReport.decision.requiredEvidence.take(5).joinToString(", ")}."
            else -> "Expected a bounded metadata/control/outcome improvement."
        }
        val observed = when {
            measured -> "Observed ${calibrationReport.outcome} at ${calibrationReport.calibrationScore}/100."
            nextCyclePlan.directiveConsumed -> "Observed directive consumption without a full calibration outcome: ${nextCyclePlan.consumptionReason ?: "consumed"}."
            else -> nextCyclePlan.suppressedReason ?: "No prior directive was applied in this cycle."
        }
        val nextState = if (cognitivePathIntegrationReport.active) {
            "PROPOSED_FROM_${cognitivePathIntegrationReport.decision.decisionType}"
        } else {
            "NO_NEW_DIRECTIVE"
        }
        val action = when {
            helped -> "Reward similar directives only when they request the same missing evidence type."
            mixed -> "Keep the next directive bounded and require one measurable evidence-gate movement."
            retired -> "Do not replay satisfied or consumed directives; save only a new fingerprint."
            else -> "Store the next path directive, then force APPLIED -> MEASURED in the following cycle."
        }
        return DirectiveLifecycleReport(
            active = true,
            state = state,
            previousDirectiveApplied = applied,
            expectedEffect = expected,
            observedEffect = observed,
            improved = helped,
            retiredOrReplayBlocked = retired,
            nextDirectiveState = nextState,
            nextAction = action,
            visibleBrief = "Directive lifecycle: $state. Previous applied=$applied; measured=$measured; next=$nextState.",
            claimLimit = "directive_lifecycle_not_biological_proof"
        )
    }
}

data class EvidenceGainQueryScore(
    val queryId: String,
    val query: String,
    val score: Int,
    val closesGaps: List<String>,
    val testsBeliefs: List<String>,
    val falsificationValue: String,
    val reason: String
)

data class EvidenceGainQueryRankerReport(
    val active: Boolean,
    val chosenQueryId: String,
    val chosenQuery: String,
    val chosenScore: Int,
    val scores: List<EvidenceGainQueryScore>,
    val blockedRepeatRisk: Boolean,
    val summary: String,
    val claimLimit: String = "evidence_gain_ranking_not_biological_proof"
) {
    companion object {
        fun empty() = EvidenceGainQueryRankerReport(
            active = false,
            chosenQueryId = "none",
            chosenQuery = "",
            chosenScore = 0,
            scores = emptyList(),
            blockedRepeatRisk = false,
            summary = "No evidence-gain query ranking was evaluated.",
            claimLimit = "evidence_gain_ranking_not_biological_proof"
        )
    }
}

object EvidenceGainQueryRanker {
    fun rank(
        queries: List<ResearchQuery>,
        directive: CognitiveNextCycleDirective?,
        recentFailurePatterns: List<FailurePattern>
    ): Pair<List<ResearchQuery>, EvidenceGainQueryRankerReport> {
        if (queries.isEmpty()) return queries to EvidenceGainQueryRankerReport.empty()
        val failureText = recentFailurePatterns.joinToString(" ") { it.rootCause + " " + it.suggestedAction }.lowercase(Locale.US)
        val required = (directive?.requiredEvidence ?: emptyList()).map { it.lowercase(Locale.US) }
        val scores = queries.map { query ->
            val text = (query.query + " " + query.reason).lowercase(Locale.US)
            val closes = mutableListOf<String>()
            var score = 10
            fun hasAny(vararg terms: String): Boolean = terms.any { text.contains(it) }
            if (hasAny("outcome", "severity", "recovery", "endpoint")) { score += 30; closes += "OUTCOME_LABELS" }
            if (hasAny("longitudinal", "time-course", "serial", "follow-up", "temporal")) { score += 20; closes += "TIME_ORDER" }
            if (hasAny("control", "comparator", "placebo", "healthy control", "negative control")) { score += 20; closes += "CONTROL_OR_COMPARATOR" }
            if (hasAny("metadata", "phenotype", "sample", "gse", "geo", "sra", "prjna")) { score += 15; closes += "MINIMUM_METADATA" }
            if (hasAny("validation", "replication", "contradiction", "negative")) score += 15
            if (required.any { req -> text.contains(req.replace("_", " ")) }) score += 10
            if (failureText.contains("no_outcome_labels") && !closes.contains("OUTCOME_LABELS")) score -= 25
            if (failureText.contains("metadata") && !closes.contains("MINIMUM_METADATA")) score -= 15
            if (query.id.contains("cognitive", true)) score += 10
            val repeatRisk = query.reason.contains("broad", true) && closes.isEmpty()
            if (repeatRisk) score -= 20
            EvidenceGainQueryScore(
                queryId = query.id,
                query = query.query.take(260),
                score = score.coerceIn(0, 100),
                closesGaps = closes.distinct(),
                testsBeliefs = required.take(5),
                falsificationValue = if (text.contains("negative") || text.contains("contradiction")) "DIRECT" else "INDIRECT",
                reason = "Evidence-gain score favors blocker closure, belief testing, outcome/time/control labels, and repeat-failure avoidance."
            )
        }.sortedByDescending { it.score }
        val ranked = queries.sortedByDescending { query -> scores.firstOrNull { it.queryId == query.id }?.score ?: 0 }
        val top = scores.first()
        val repeatRisk = scores.any { it.score < 20 && it.closesGaps.isEmpty() }
        return ranked to EvidenceGainQueryRankerReport(
            active = true,
            chosenQueryId = top.queryId,
            chosenQuery = top.query,
            chosenScore = top.score,
            scores = scores.take(8),
            blockedRepeatRisk = repeatRisk,
            summary = "Chosen query ${top.queryId} scored ${top.score}/100 because it closes ${top.closesGaps.joinToString(", ").ifBlank { "no hard blocker" }}.",
            claimLimit = "evidence_gain_ranking_not_biological_proof"
        )
    }
}

data class BeliefFalsificationContract(
    val beliefId: String,
    val strengthenIf: List<String>,
    val weakenIf: List<String>,
    val abandonIf: List<String>,
    val doNotRouteIf: List<String>,
    val nextEvidenceRequired: List<String>,
    val routingAllowed: Boolean,
    val contractLine: String
)

data class BeliefFalsificationContractReport(
    val active: Boolean,
    val contracts: List<BeliefFalsificationContract>,
    val blockedFromRouting: Int,
    val topAtRiskBelief: String,
    val summary: String,
    val claimLimit: String = "belief_falsification_contracts_not_biological_proof"
) {
    companion object {
        fun empty() = BeliefFalsificationContractReport(
            active = false,
            contracts = emptyList(),
            blockedFromRouting = 0,
            topAtRiskBelief = "none",
            summary = "No belief contracts were generated.",
            claimLimit = "belief_falsification_contracts_not_biological_proof"
        )
    }
}

object BeliefFalsificationContractEngine {
    fun build(report: EpistemicBeliefReport): BeliefFalsificationContractReport {
        if (!report.active) return BeliefFalsificationContractReport.empty()
        val contracts = report.beliefs.take(24).map { belief ->
            val required = belief.requiredEvidenceToKeep.ifEmpty { listOf("independent_evidence", "control_or_comparator", "outcome_labels") }
            val abandon = belief.falsifiers.ifEmpty { listOf("stronger_competing_route", "failed_minimum_data_pack", "repeat_contradiction") }
            val block = buildList {
                if (belief.status in listOf("RETIRED", "REVISE_REQUIRED", "WEAKENED")) add("status_${belief.status.lowercase(Locale.US)}")
                if (belief.credibility < 55) add("credibility_below_55")
                if (belief.contradictionCount > belief.supportCount) add("contradictions_exceed_support")
                if (abandon.isEmpty()) add("missing_abandon_if")
            }
            val routeAllowed = block.isEmpty() || belief.beliefType == "FOUNDATION_PRIOR"
            BeliefFalsificationContract(
                beliefId = belief.beliefId,
                strengthenIf = required.take(3) + listOf("independent_repeat_or_control_support"),
                weakenIf = listOf("same_gap_repeats", "metadata_only_after_next_cycle", "lower_quality_route_explains_signal"),
                abandonIf = abandon.take(5),
                doNotRouteIf = block.ifEmpty { listOf("none_currently") },
                nextEvidenceRequired = required.take(5),
                routingAllowed = routeAllowed,
                contractLine = "${belief.beliefId}: strengthen with ${required.take(2).joinToString("+")}; abandon if ${abandon.take(2).joinToString("+")}."
            )
        }
        val blocked = contracts.count { !it.routingAllowed }
        val atRisk = contracts.firstOrNull { !it.routingAllowed }?.contractLine ?: "No active belief is blocked from routing."
        return BeliefFalsificationContractReport(
            active = true,
            contracts = contracts,
            blockedFromRouting = blocked,
            topAtRiskBelief = atRisk,
            summary = "Belief contracts generated: ${contracts.size}; blocked from routing: $blocked.",
            claimLimit = "belief_falsification_contracts_not_biological_proof"
        )
    }
}

data class MemoryConsolidationReport(
    val active: Boolean,
    val mainBeliefsKept: Int,
    val archivedBeliefs: Int,
    val routingBeliefs: Int,
    val blockedBeliefs: Int,
    val garbageCollectorAction: String,
    val summary: String,
    val claimLimit: String = "memory_consolidation_not_biological_proof"
) {
    companion object {
        fun empty() = MemoryConsolidationReport(false, 0, 0, 0, 0, "none", "No memory consolidation evaluated.", "memory_consolidation_not_biological_proof")
    }
}

object MemoryConsolidationEngine {
    fun consolidate(beliefReport: EpistemicBeliefReport, contractReport: BeliefFalsificationContractReport): MemoryConsolidationReport {
        if (!beliefReport.active) return MemoryConsolidationReport.empty()
        val main = beliefReport.beliefs.count { it.status in listOf("ACTIVE_PRIOR", "ACTIVE_WITH_WARNINGS", "PROVISIONAL", "CARRIED_FORWARD") && it.credibility >= 45 }
        val archived = beliefReport.beliefs.count { it.status == "RETIRED" || it.credibility < 35 }
        val routing = contractReport.contracts.count { it.routingAllowed }
        val blocked = contractReport.contracts.count { !it.routingAllowed }
        val action = when {
            archived >= 10 -> "Move weak unused beliefs to historical mistake archive and hide them from the main report."
            blocked > routing -> "Do not let weak beliefs route the next query; route from gap/evidence contracts instead."
            else -> "Keep only decision-impact beliefs in the main report; archive the rest as context."
        }
        return MemoryConsolidationReport(
            active = true,
            mainBeliefsKept = main,
            archivedBeliefs = archived,
            routingBeliefs = routing,
            blockedBeliefs = blocked,
            garbageCollectorAction = action,
            summary = "Memory consolidation: $main main / $archived archived; $routing routing / $blocked blocked.",
            claimLimit = "memory_consolidation_not_biological_proof"
        )
    }
}

data class CausalReadinessReport(
    val active: Boolean,
    val state: String,
    val level: Int,
    val score: Int,
    val causalLanguageAllowed: Boolean,
    val strongSignalAllowed: Boolean,
    val blockers: List<String>,
    val nextAction: String,
    val summary: String,
    val claimLimit: String = "causal_readiness_not_biological_proof"
) {
    companion object {
        fun empty() = CausalReadinessReport(false, "NOT_EVALUATED", 0, 0, false, false, listOf("No evidence evaluated."), "Acquire evidence objects first.", "No causal readiness evaluated.", "causal_readiness_not_biological_proof")
    }
}

object CausalReadinessGate {
    fun evaluate(
        evidenceObjects: List<EvidenceObject>,
        datasetForagingReport: DatasetForagingReport,
        hypothesisObjects: List<HypothesisObject>
    ): CausalReadinessReport {
        val hasRoute = datasetForagingReport.routeFitAssessments.any { it.routeFitScore >= 70 }
        val hasTemporal = evidenceObjects.any { it.hasLongitudinalSignal } || datasetForagingReport.parsedMetadata.any { it.timeCourseLabels.isNotEmpty() }
        val hasControl = evidenceObjects.any { it.hasNegativeControl } || datasetForagingReport.parsedMetadata.any { it.controlLabels.isNotEmpty() }
        val hasRepeatedHuman = evidenceObjects.count { it.qualityScore >= 60 && it.sourceType.contains("human", true) } >= 2 || hypothesisObjects.any { it.dataTrustScore >= 70 && it.causalityScore >= 60 }
        val hasIntervention = evidenceObjects.any { it.hasMechanisticSignal && it.causalClaimSafe && it.hasNegativeControl }
        val level = when {
            hasIntervention -> 5
            hasRepeatedHuman -> 4
            hasControl -> 3
            hasTemporal -> 2
            hasRoute -> 1
            else -> 0
        }
        val state = when (level) {
            5 -> "INTERVENTION_SUPPORTED"
            4 -> "REPEATED_HUMAN_SIGNAL"
            3 -> "CONTROLLED_COMPARISON"
            2 -> "TEMPORAL_CANDIDATE"
            1 -> "ROUTE_FIT_ONLY"
            else -> "ASSOCIATION_ONLY"
        }
        val blockers = buildList {
            if (!hasTemporal) add("TIME_ORDER")
            if (!hasControl) add("CONTROL_OR_COMPARATOR")
            if (!hasRepeatedHuman) add("REPEATED_HUMAN_SIGNAL")
            if (!hasIntervention) add("INTERVENTION_OR_PERTURBATION")
        }
        val score = (level * 18 + datasetForagingReport.scoreSeparation.hypothesisConfidenceScore / 5).coerceIn(0, 100)
        return CausalReadinessReport(
            active = true,
            state = state,
            level = level,
            score = score,
            causalLanguageAllowed = level >= 3,
            strongSignalAllowed = level >= 4,
            blockers = blockers,
            nextAction = if (blockers.isNotEmpty()) "Close ${blockers.first()} before causal or strong-signal wording." else "Keep claim-safe language and verify replication.",
            summary = "Causal readiness: $state level $level/5; causal language allowed=${level >= 3}; strong signal allowed=${level >= 4}.",
            claimLimit = "causal_readiness_not_biological_proof"
        )
    }
}

data class ReflectionLessonReport(
    val active: Boolean,
    val lesson: String,
    val prevention: String,
    val cooldownAction: String,
    val repeatedMistakeRisk: String,
    val claimLimit: String = "reflection_lessons_not_biological_proof"
) {
    companion object {
        fun empty() = ReflectionLessonReport(false, "No reflection lesson generated.", "No prevention needed.", "none", "LOW", "reflection_lessons_not_biological_proof")
    }
}

object ReflectionLessonEngine {
    fun build(
        learningOsReport: LearningOsReport,
        datasetForagingReport: DatasetForagingReport,
        cognitiveLoopCalibrationReport: CognitiveLoopCalibrationReport
    ): ReflectionLessonReport {
        val roots = learningOsReport.incident.rootCauses
        val noOutcome = roots.contains("NO_OUTCOME_LABELS") || datasetForagingReport.parsedMetadata.any { it.outcomeLabels.isEmpty() }
        val metadataOnly = roots.contains("METADATA_ONLY") || (datasetForagingReport.candidates.isNotEmpty() && datasetForagingReport.parsedMetadata.isEmpty())
        val lesson = when {
            noOutcome -> "High route-fit without outcome/recovery/severity labels is not discovery."
            metadataOnly -> "Dataset accession alone is not evidence until metadata and controls are parsed."
            cognitiveLoopCalibrationReport.dampenSimilarDirective -> "A directive that does not move a gate should be dampened, not replayed."
            else -> "No major repeated mistake detected; keep evidence gates visible."
        }
        val prevention = when {
            noOutcome -> "Force outcome/time/control terms before model or hypothesis language."
            metadataOnly -> "Force minimum metadata parser before contrastive or upgrade language."
            cognitiveLoopCalibrationReport.dampenSimilarDirective -> "Require a different evidence route or stronger blocker closure before replay."
            else -> "Continue bounded search and keep claim limits visible."
        }
        val risk = if (noOutcome || metadataOnly || cognitiveLoopCalibrationReport.dampenSimilarDirective) "MEDIUM" else "LOW"
        return ReflectionLessonReport(
            active = true,
            lesson = lesson,
            prevention = prevention,
            cooldownAction = if (risk == "MEDIUM") "Cool down similar broad route for 1 cycle if the same blocker repeats." else "none",
            repeatedMistakeRisk = risk,
            claimLimit = "reflection_lessons_not_biological_proof"
        )
    }
}

data class MiniPeerReviewReport(
    val active: Boolean,
    val verdict: String,
    val strongestObjection: String,
    val missingEvidence: List<String>,
    val alternativeExplanation: String,
    val falsificationTest: String,
    val survivesNegativeControl: Boolean,
    val summary: String,
    val claimLimit: String = "mini_peer_review_not_biological_proof"
) {
    companion object {
        fun empty() = MiniPeerReviewReport(false, "NOT_REVIEWED", "No hypothesis reviewed.", emptyList(), "unknown", "none", false, "No mini peer review ran.", "mini_peer_review_not_biological_proof")
    }
}

object MiniPeerReviewGate {
    fun review(
        hypothesisObjects: List<HypothesisObject>,
        datasetForagingReport: DatasetForagingReport,
        causalReadinessReport: CausalReadinessReport,
        epistemicBeliefReport: EpistemicBeliefReport
    ): MiniPeerReviewReport {
        val top = hypothesisObjects.maxByOrNull { (it.evidenceScore10 * 10).toInt() + it.dataTrustScore }
        if (top == null) return MiniPeerReviewReport.empty()
        val missing = (top.missingData + causalReadinessReport.blockers).distinct().take(8)
        val titleOnly = datasetForagingReport.parsedMetadata.isEmpty() && datasetForagingReport.candidates.isNotEmpty()
        val objection = when {
            titleOnly -> "Candidate is still accession/title-level; metadata parser has not made it reviewable."
            missing.any { it.contains("OUTCOME", true) || it.contains("outcome", true) } -> "Outcome labels are missing, so effect/recovery/severity cannot be judged."
            causalReadinessReport.level < 3 -> "Evidence is below controlled-comparison threshold; causal wording is blocked."
            epistemicBeliefReport.revisedBeliefs > 0 -> "Active beliefs still require revision before upgrade."
            else -> "Evidence may be inspectable, but still requires independent replication."
        }
        val verdict = when {
            missing.any { it.contains("OUTCOME", true) || it.contains("TIME", true) || it.contains("CONTROL", true) } -> "HOLD"
            titleOnly -> "INSPECT"
            causalReadinessReport.strongSignalAllowed -> "ADVANCE_WITH_LIMITS"
            causalReadinessReport.causalLanguageAllowed -> "INSPECT"
            else -> "HOLD"
        }
        return MiniPeerReviewReport(
            active = true,
            verdict = verdict,
            strongestObjection = objection,
            missingEvidence = missing,
            alternativeExplanation = "A better route, confounder, or non-specific inflammation signal may explain the same evidence.",
            falsificationTest = top.falsification.firstOrNull() ?: "Run negative-control and comparator search before upgrade.",
            survivesNegativeControl = causalReadinessReport.level >= 3 && datasetForagingReport.contrastiveReport.gateStatus != "NOT_EVALUATED",
            summary = "Mini peer review: $verdict. Strongest objection: ${objection.take(140)}",
            claimLimit = "mini_peer_review_not_biological_proof"
        )
    }
}

data class ReportSimplificationReport(
    val active: Boolean,
    val whatChanged: List<String>,
    val gotStronger: String,
    val gotWeaker: String,
    val dropped: String,
    val nextTest: String,
    val whyThisNextTest: String,
    val claimLimit: String = "simple_report_router_not_biological_proof"
) {
    companion object {
        fun empty() = ReportSimplificationReport(false, emptyList(), "none", "none", "none", "Run a research cycle.", "No report yet.", "simple_report_router_not_biological_proof")
    }
}

object ReportSimplificationLayer {
    fun build(
        beliefReport: EpistemicBeliefReport,
        cognitivePathIntegrationReport: CognitivePathIntegrationReport,
        evidenceGainReport: EvidenceGainQueryRankerReport,
        miniPeerReviewReport: MiniPeerReviewReport,
        reflectionLessonReport: ReflectionLessonReport
    ): ReportSimplificationReport {
        if (!beliefReport.active && !cognitivePathIntegrationReport.active) return ReportSimplificationReport.empty()
        val changed = buildList {
            add("Closed-loop state: ${cognitivePathIntegrationReport.decision.decisionType}.")
            if (evidenceGainReport.active) add("Query ranked by expected evidence gain: ${evidenceGainReport.chosenScore}/100.")
            if (miniPeerReviewReport.active) add("Mini peer review verdict: ${miniPeerReviewReport.verdict}.")
            if (reflectionLessonReport.active) add("Lesson: ${reflectionLessonReport.lesson.take(120)}")
        }
        return ReportSimplificationReport(
            active = true,
            whatChanged = changed.take(6),
            gotStronger = beliefReport.transitionSummary.strengthenedBelief,
            gotWeaker = beliefReport.transitionSummary.weakenedBelief,
            dropped = beliefReport.transitionSummary.droppedBelief,
            nextTest = cognitivePathIntegrationReport.decision.action,
            whyThisNextTest = cognitivePathIntegrationReport.decision.reason.take(240),
            claimLimit = "simple_report_router_not_biological_proof"
        )
    }
}
