package com.immunesignal.app

/**
 * v1.10.50 linkage owner for environmental / psychophysiological exposome routing.
 *
 * This class is intentionally small and deterministic. It owns the public lane ids,
 * the asset binding, the exposure-to-lab pathway template, and the no-advice guard
 * used by TopicFitMetadataParseUiClarityV11047. It prevents v1.10.50 from becoming
 * a documentation-only or asset-only island.
 */
object EnvironmentalPsychophysiologicalExposomeLaneV11050 {
    const val ASSET_NAME: String = "environmental_psychophysiological_exposome_v1.10.50.json"
    const val CLAIM_LIMIT: String = "exposome_context_routing_only_not_health_advice"
    const val PATHWAY_TEMPLATE: String = "Exposure -> Pathway -> Biomarker -> Dataset -> Outcome -> Comparator -> Contradiction"

    val laneIds: List<String> = listOf(
        "ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE",
        "PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE",
        "ENDOCRINE_HORMONE_HPA_IMMUNE_LANE",
        "DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE",
        "PHYSICAL_LIGHT_RADIATION_CIRCADIAN_IMMUNE_LANE",
        "TOXIN_SUBSTANCE_EXPOSURE_IMMUNE_LANE",
        "AGE_LIFE_STAGE_IMMUNE_CONTEXT_LANE"
    )

    fun selectLane(topicText: String, fallback: String = "GENERAL_IMMUNE_DATASET_CLOSURE_LANE"): String {
        return when {
            hasAny(topicText, "dust", "pollen", "mold", "air quality", "pollution", "particulate", "pm2.5", "odor", "odour", "smell", "fragrance", "humidity", "weather", "temperature", "heat", "cold", "غبار", "حبوب الطلع", "الرائحة", "الرطوبة", "الجو", "الحرارة") -> "ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE"
            hasAny(topicText, "stress", "psychological", "psychosocial", "depression", "anxiety", "burnout", "trauma", "hpa", "cortisol", "ضغط", "التوتر", "الإجهاد", "الضغوط", "الكآبة", "الاكتئاب", "الكئابة") -> "PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE"
            hasAny(topicText, "hormone", "hormones", "estrogen", "progesterone", "testosterone", "thyroid", "insulin", "melatonin", "cortisol", "هرمون", "الهرمونات") -> "ENDOCRINE_HORMONE_HPA_IMMUNE_LANE"
            hasAny(topicText, "enzyme", "enzymes", "gastric", "acid", "stomach acidity", "reflux", "ph", "digestion", "digestive", "food", "meal", "nutrition", "diet", "spice", "enzym", "حموضة", "المعدة", "المأكولات", "الأكل", "الغذاء", "الانزيمات") -> "DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE"
            hasAny(topicText, "light", "uv", "radiation", "infrared", "blue light", "screen", "moon", "lunar", "season", "circadian", "sunlight", "ضوء", "الضوء", "الأشعة", "القمر") -> "PHYSICAL_LIGHT_RADIATION_CIRCADIAN_IMMUNE_LANE"
            hasAny(topicText, "alcohol", "smoking", "tobacco", "nicotine", "drug", "drugs", "substance", "cannabis", "opioid", "stimulant", "الكحول", "التدخين", "المخدرات") -> "TOXIN_SUBSTANCE_EXPOSURE_IMMUNE_LANE"
            hasAny(topicText, "age", "aging", "elderly", "older", "العمر") -> "AGE_LIFE_STAGE_IMMUNE_CONTEXT_LANE"
            else -> fallback
        }
    }

    fun contextSeeds(topicText: String, preferredLane: String, longevitySelectedLane: String): List<String> {
        val seeds = mutableListOf<String>()
        when (preferredLane) {
            "ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE" -> seeds += listOf("dust", "pollen", "mold", "air pollution", "PM2.5", "humidity", "temperature", "odor/fragrance", "IgE", "eosinophil", "nasal/airway barrier", "exposed unexposed", "seasonal baseline", "negative control")
            "PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE" -> seeds += listOf("psychological stress", "HPA axis", "cortisol", "depression", "anxiety", "sleep quality", "HRV", "CRP", "IL-6", "TNF-alpha", "diurnal rhythm", "matched control")
            "ENDOCRINE_HORMONE_HPA_IMMUNE_LANE" -> seeds += listOf("hormones", "cortisol", "estrogen", "progesterone", "testosterone", "thyroid", "insulin", "melatonin", "immune cytokines", "cycle phase", "baseline", "matched control")
            "DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE" -> seeds += listOf("gastric acidity", "stomach pH", "reflux", "digestive enzymes", "food exposure", "meal timing", "microbiome", "barrier tissue", "CRP", "IgE", "baseline", "exposed unexposed")
            "PHYSICAL_LIGHT_RADIATION_CIRCADIAN_IMMUNE_LANE" -> seeds += listOf("light exposure", "UV", "radiation", "blue light", "screen exposure", "moon/lunar", "season", "temperature", "circadian", "melatonin", "cortisol", "time-course")
            "TOXIN_SUBSTANCE_EXPOSURE_IMMUNE_LANE" -> seeds += listOf("alcohol", "smoking", "tobacco", "nicotine", "substance exposure", "drug exposure", "airway inflammation", "liver immune markers", "baseline", "exposed unexposed", "no advice", "negative control")
            "AGE_LIFE_STAGE_IMMUNE_CONTEXT_LANE" -> seeds += listOf("age", "older adults", "life stage", "immunosenescence", "CMV serostatus", "T-cell subsets", "CRP", "IL-6", "TNF-alpha", "matched age control", "comorbidity", "medication context")
        }
        if (topicText.contains("ebv") || topicText.contains("epstein") || longevitySelectedLane.contains("IMMUNE_AGING")) {
            seeds += listOf("EBV", "HHV-6", "CMV", "molecular mimicry", "failed replication")
        }
        if (topicText.contains("hpa") || topicText.contains("stress") || topicText.contains("cortisol")) {
            seeds += listOf("HPA axis", "cortisol", "stress immune", "diurnal rhythm")
        }
        return seeds.distinct()
    }

    fun laneIsExposome(lane: String): Boolean = lane in laneIds

    private fun hasAny(text: String, vararg terms: String): Boolean = terms.any { text.contains(it.lowercase()) }
}

object ExposomeToLabMapperV11050 {
    const val CLAIM_LIMIT: String = EnvironmentalPsychophysiologicalExposomeLaneV11050.CLAIM_LIMIT

    fun biomarkersForLane(lane: String): List<String> = when (lane) {
        "ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE" -> listOf("IgE", "eosinophils", "CRP", "IL-6", "airway/nasal labels")
        "PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE" -> listOf("cortisol", "HRV", "CRP", "IL-6", "TNF-alpha", "sleep quality labels")
        "ENDOCRINE_HORMONE_HPA_IMMUNE_LANE" -> listOf("cortisol", "estrogen", "progesterone", "testosterone", "thyroid", "insulin", "melatonin", "CRP")
        "DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE" -> listOf("stomach pH", "digestive enzymes", "CRP", "IgE", "glucose", "lipids", "microbiome labels")
        "PHYSICAL_LIGHT_RADIATION_CIRCADIAN_IMMUNE_LANE" -> listOf("melatonin", "cortisol", "HRV", "CRP", "IL-6", "sleep timing labels")
        "TOXIN_SUBSTANCE_EXPOSURE_IMMUNE_LANE" -> listOf("CRP", "IL-6", "TNF-alpha", "WBC", "liver inflammation labels")
        "AGE_LIFE_STAGE_IMMUNE_CONTEXT_LANE" -> listOf("CMV serostatus", "T-cell subsets", "CRP", "IL-6", "TNF-alpha")
        else -> emptyList()
    }

    fun comparatorsForLane(lane: String): List<String> = when (lane) {
        "ENVIRONMENTAL_AEROALLERGEN_IRRITANT_IMMUNE_LANE" -> listOf("seasonal baseline", "exposed vs unexposed", "matched control", "negative control")
        "PSYCHONEUROENDOCRINE_STRESS_IMMUNE_LANE" -> listOf("baseline", "high vs low stress", "matched control", "longitudinal follow-up")
        "ENDOCRINE_HORMONE_HPA_IMMUNE_LANE" -> listOf("cycle phase", "baseline", "matched control", "time-course")
        "DIGESTIVE_ENZYME_GASTRIC_FOOD_IMMUNE_LANE" -> listOf("pre/post exposure", "exposed vs unexposed", "baseline", "matched control")
        "PHYSICAL_LIGHT_RADIATION_CIRCADIAN_IMMUNE_LANE" -> listOf("day/night", "seasonal baseline", "exposed vs unexposed", "time-course")
        "TOXIN_SUBSTANCE_EXPOSURE_IMMUNE_LANE" -> listOf("exposed vs unexposed", "baseline", "dose category as metadata only", "negative control")
        "AGE_LIFE_STAGE_IMMUNE_CONTEXT_LANE" -> listOf("age-matched control", "younger vs older", "baseline", "longitudinal follow-up")
        else -> emptyList()
    }
}

object NoExposureAdviceGuardV11050 {
    val forbiddenClaims: List<String> = listOf(
        "diagnosis",
        "treatment recommendation",
        "dose advice",
        "supplement recommendation",
        "personal behavior prescription",
        "causal claim without control/time/contradiction gates"
    )
}
