package com.immunesignal.app

import java.util.Locale

/**
 * v2.7.3.6 Relationship Discovery Router.
 * Builds review-only chains: Microbiome/Exposure -> Molecule/Metabolite -> Immune mediator -> Phenotype.
 */
data class GTIMRelationshipDiscoveryPlanV2736(
    val active: Boolean,
    val version: String,
    val state: String,
    val matchedArchetype: String,
    val relationshipChain: List<String>,
    val mediatorCandidates: List<String>,
    val immuneMediators: List<String>,
    val phenotypeTargets: List<String>,
    val supportingLeadQueries: List<String>,
    val contradictionQueries: List<String>,
    val datasetNeeded: List<String>,
    val comparatorNeeded: List<String>,
    val nextQuery: String,
    val gtimAdded: List<String>,
    val gtimDidNotProve: List<String>,
    val claimLimit: String = GTIMRelationshipDiscoveryRouterV2736.CLAIM_LIMIT
) {
    companion object {
        fun empty(): GTIMRelationshipDiscoveryPlanV2736 = GTIMRelationshipDiscoveryPlanV2736(
            active = false,
            version = GTIMRelationshipDiscoveryRouterV2736.VERSION,
            state = "RELATIONSHIP_ROUTE_NOT_OPENED",
            matchedArchetype = "none",
            relationshipChain = emptyList(),
            mediatorCandidates = emptyList(),
            immuneMediators = emptyList(),
            phenotypeTargets = emptyList(),
            supportingLeadQueries = emptyList(),
            contradictionQueries = emptyList(),
            datasetNeeded = emptyList(),
            comparatorNeeded = emptyList(),
            nextQuery = "Ask a relationship question with at least two of: microbiome/exposure, molecule/metabolite, immune mediator, phenotype.",
            gtimAdded = emptyList(),
            gtimDidNotProve = listOf("causality", "diagnosis", "treatment", "patient-level prediction")
        )
    }
}

private data class RelationshipArchetypeV2736(
    val id: String,
    val matchTerms: List<String>,
    val chain: List<String>,
    val mediators: List<String>,
    val immuneMediators: List<String>,
    val phenotypes: List<String>,
    val datasetNeeded: List<String>,
    val comparatorNeeded: List<String>,
    val queryTemplates: List<String>,
    val contradictionTemplates: List<String>
)

object GTIMRelationshipDiscoveryRouterV2736 {
    const val VERSION: String = "2.7.3.6-relationship-discovery-router"
    const val STATE: String = "RELATIONSHIP_DISCOVERY_ROUTE_OPENED"
    const val CLAIM_LIMIT: String = "relationship_route_discovery_only_not_causality_not_diagnosis_not_treatment"

    private val microbiomeTerms = listOf("microbiome", "microbiota", "gut bacteria", "gut-brain", "gut brain", "dysbiosis", "microbial", "stool", "metagenomics", "16s", "resistome")
    private val exposureTerms = listOf("pesticide", "glyphosate", "livestock antibiotic", "poultry antibiotic", "meat antibiotic", "microplastic", "bpa", "pfas", "phthalate", "heavy metal", "lead exposure", "blood lead", "lead poisoning", "arsenic", "cadmium", "mercury")
    private val moleculeTerms = listOf("metabolite", "molecule", "scfa", "short-chain fatty", "butyrate", "bile acid", "tryptophan", "kynurenine", "gaba", "serotonin", "lps", "endotoxin", "toxin", "xenobiotic")
    private val immuneTerms = listOf("il-6", "il6", "tnf", "crp", "interferon", "ifn", "cytokine", "inflammasome", "th17", "il-17", "barrier", "intestinal permeability", "immune mediator", "inflammation", "neuroinflammation")
    private val phenotypeTerms = listOf("depression", "anxiety", "mood", "major depressive", "phenotype", "disease", "autoimmune", "immune dysregulation", "endocrine", "neuroimmune")

    private val archetypes = listOf(

        RelationshipArchetypeV2736(
            id = "covid_interferon_cytokine_bridge",
            matchTerms = listOf("covid", "sars-cov-2", "sars cov 2", "long covid", "pasc", "interferon", "ifn", "pbmc", "post-viral", "il-6", "tnf"),
            chain = listOf("SARS-CoV-2 or post-viral state", "interferon timing or persistence", "IL-6/TNF cytokine mediator", "PBMC/airway host-response matrix", "COVID or Long COVID phenotype"),
            mediators = listOf("type I interferon", "viral RNA / antigen persistence proxy", "post-viral inflammatory program", "endothelial or epithelial stress proxy"),
            immuneMediators = listOf("IFN-alpha/beta", "IL-6", "TNF", "CXCL10", "CRP"),
            phenotypes = listOf("COVID", "Long COVID / PASC", "post-viral immune phenotype"),
            datasetNeeded = listOf("COVID/PASC phenotype label", "PBMC or airway transcriptome", "cytokine/interferon readout", "timepoint metadata", "healthy/recovered comparator"),
            comparatorNeeded = listOf("acute vs recovered", "Long COVID vs recovered/healthy", "severe vs mild", "timepoint-separated comparator"),
            queryTemplates = listOf("COVID SARS-CoV-2 Long COVID PASC interferon IL-6 TNF PBMC RNA-seq comparator GSE PRJNA", "SARS-CoV-2 PBMC transcriptome interferon cytokine data availability recovered healthy controls", "Long COVID interferon cytokine host response dataset null result comparator"),
            contradictionTemplates = listOf("Long COVID interferon no association null result", "COVID PBMC cytokine failed replication recovered controls", "SARS-CoV-2 interferon opposite direction timepoint comparator")
        ),
        RelationshipArchetypeV2736(
            id = "allergy_type2_ige_mast_cell_bridge",
            matchTerms = listOf("allergy", "allergies", "allergic", "hypersensitivity", "atopy", "atopic", "allergen", "ige", "mast cell", "eosinophil", "il-4", "il-5", "il-13", "type 2", "th2"),
            chain = listOf("allergen or hypersensitivity trigger", "epithelial / mast-cell activation", "IgE or eosinophil mediator", "IL-4/IL-5/IL-13 type-2 axis", "allergic phenotype"),
            mediators = listOf("IgE", "histamine / mast-cell degranulation proxy", "eosinophil signal", "epithelial alarmin proxy"),
            immuneMediators = listOf("IL-4", "IL-5", "IL-13", "IgE", "eosinophil markers"),
            phenotypes = listOf("allergic disease", "hypersensitivity", "atopic/type-2 phenotype"),
            datasetNeeded = listOf("allergy phenotype label", "allergen/exposure metadata", "IgE or cytokine readout", "mast/eosinophil marker", "case/control comparator"),
            comparatorNeeded = listOf("allergic cases vs healthy controls", "sensitized vs non-sensitized", "severity or exposure-window comparator"),
            queryTemplates = listOf("allergy allergic hypersensitivity IgE mast cell eosinophil IL-4 IL-5 IL-13 dataset comparator GSE", "allergen exposure type 2 inflammation cytokine profiling allergic cases healthy controls", "atopy IgE eosinophil transcriptome data availability PMID DOI GSE"),
            contradictionTemplates = listOf("allergy IgE mast cell no association null result", "allergic disease IL-4 IL-13 failed replication", "atopy cytokine opposite direction healthy controls")
        ),
        RelationshipArchetypeV2736(
            id = "microbiome_depression_il6_bridge",
            matchTerms = microbiomeTerms + listOf("depression", "major depressive", "mood", "il-6", "il6", "crp", "tnf"),
            chain = listOf("microbe/community", "microbial molecule or metabolite", "IL-6/TNF/CRP inflammatory mediator", "gut-brain / neuroimmune axis", "depression or mood phenotype"),
            mediators = listOf("SCFA", "LPS/endotoxin", "tryptophan/kynurenine", "bile acids", "environmental xenobiotic carried by microbial metabolism"),
            immuneMediators = listOf("IL-6", "TNF", "CRP", "inflammasome", "microglia / BBB proxy"),
            phenotypes = listOf("depression", "major depressive disorder", "mood phenotype", "neuroinflammation"),
            datasetNeeded = listOf("16S/metagenomics", "metabolomics", "cytokine panel", "host transcriptome or PBMC RNA-seq", "case/control metadata"),
            comparatorNeeded = listOf("depression vs matched control", "high vs low microbial/metabolite abundance", "inflammation-high vs inflammation-low", "medication/diet confounder labels"),
            queryTemplates = listOf("microbiome depression IL-6 TNF CRP metabolomics case control data availability PMID DOI GSE PRJNA", "gut bacteria microbial metabolite depression cytokine IL-6 metabolomics metagenomics comparator", "microbiome gut-brain axis depression tryptophan kynurenine SCFA CRP dataset"),
            contradictionTemplates = listOf("microbiome depression IL-6 no association null result case control", "gut bacteria depression metabolomics failed replication opposite direction", "microbiome mood disorder antibiotic diet confounder negative result")
        ),
        RelationshipArchetypeV2736(
            id = "microbiome_anxiety_tryptophan_kynurenine_bridge",
            matchTerms = microbiomeTerms + listOf("anxiety", "tryptophan", "kynurenine", "serotonin", "gaba"),
            chain = listOf("microbiome/community", "tryptophan-kynurenine or neurotransmitter-adjacent metabolite", "immune/inflammatory mediator", "gut-brain axis", "anxiety phenotype"),
            mediators = listOf("tryptophan", "kynurenine", "serotonin", "GABA", "indole derivatives"),
            immuneMediators = listOf("IL-6", "TNF", "CRP", "IFN-related kynurenine route", "microglia proxy"),
            phenotypes = listOf("anxiety", "stress reactivity", "neuroimmune phenotype"),
            datasetNeeded = listOf("microbiome profile", "metabolomics", "cytokine panel", "psychiatric phenotype labels", "diet/medication metadata"),
            comparatorNeeded = listOf("anxiety vs control", "high vs low kynurenine/tryptophan ratio", "inflammation-high vs low", "pre/post intervention if present"),
            queryTemplates = listOf("microbiome anxiety tryptophan kynurenine IL-6 TNF metabolomics case control PMID DOI GSE", "gut microbiota anxiety serotonin GABA cytokine inflammation dataset comparator", "microbiome kynurenine pathway anxiety immune mediator data availability"),
            contradictionTemplates = listOf("microbiome anxiety kynurenine no association null result", "gut microbiota anxiety metabolomics failed replication", "tryptophan microbiome anxiety opposite direction case control")
        ),
        RelationshipArchetypeV2736(
            id = "pesticide_gut_barrier_inflammation_bridge",
            matchTerms = listOf("pesticide", "pesticides", "glyphosate", "food residue", "sprayed food", "organophosphate", "gut barrier", "intestinal permeability") + microbiomeTerms + immuneTerms,
            chain = listOf("food pesticide residue", "microbiome/barrier disruption", "LPS or permeability mediator", "IL-6/TNF/CRP inflammation", "immune/inflammatory phenotype"),
            mediators = listOf("LPS/endotoxin", "tight-junction disruption", "SCFA shift", "oxidative stress", "xenobiotic metabolism"),
            immuneMediators = listOf("IL-6", "TNF", "CRP", "IL-1beta", "inflammasome"),
            phenotypes = listOf("gut inflammation", "systemic inflammation", "immune dysregulation"),
            datasetNeeded = listOf("exposure metadata", "microbiome/metagenomics", "gut-barrier marker", "cytokine/CRP panel", "exposed/unexposed comparator"),
            comparatorNeeded = listOf("exposed vs unexposed", "dose/window label", "diet control", "occupational vs dietary route separated"),
            queryTemplates = listOf("pesticide glyphosate gut microbiome intestinal permeability IL-6 TNF CRP data availability PMID DOI GSE", "food pesticide residue gut barrier inflammation microbiome metabolomics comparator", "organophosphate microbiome LPS cytokine exposed unexposed dataset"),
            contradictionTemplates = listOf("pesticide gut microbiome inflammation no association null result", "glyphosate intestinal permeability failed replication cytokine", "pesticide microbiome confounding diet negative result")
        ),
        RelationshipArchetypeV2736(
            id = "livestock_antibiotics_resistome_immune_bridge",
            matchTerms = listOf("livestock antibiotic", "antibiotics in livestock", "poultry antibiotic", "meat antibiotic", "resistome", "antimicrobial resistance", "farm antibiotic") + microbiomeTerms + immuneTerms,
            chain = listOf("livestock/food antibiotic exposure", "gut resistome or dysbiosis", "barrier/metabolite mediator", "immune dysregulation", "inflammatory phenotype"),
            mediators = listOf("resistome shift", "SCFA depletion", "bile acid shift", "LPS/barrier signal", "microbial diversity loss"),
            immuneMediators = listOf("IL-6", "TNF", "CRP", "Th17", "mucosal IgA"),
            phenotypes = listOf("immune dysregulation", "gut inflammation", "allergy/autoimmune-adjacent route"),
            datasetNeeded = listOf("metagenomic resistome", "antibiotic exposure metadata", "microbiome diversity", "cytokine panel", "food-source metadata"),
            comparatorNeeded = listOf("high vs low exposure", "antibiotic-free comparator", "resistome-high vs low", "diet/geography controls"),
            queryTemplates = listOf("livestock antibiotics resistome gut microbiome immune dysregulation IL-6 TNF metagenomics data availability", "poultry meat antibiotic exposure resistome inflammation cytokine comparator dataset", "antimicrobial resistance gut microbiome immune phenotype SCFA CRP PMID DOI GSE"),
            contradictionTemplates = listOf("livestock antibiotics resistome immune dysregulation no association", "food antibiotic exposure microbiome inflammation null result", "resistome immune phenotype failed replication confounding")
        ),
        RelationshipArchetypeV2736(
            id = "plastic_pfas_endocrine_immune_inflammation_bridge",
            matchTerms = listOf("microplastic", "microplastics", "plastic", "bpa", "pfas", "phthalate", "endocrine disruptor", "endocrine immune", "xenoestrogen") + immuneTerms,
            chain = listOf("plastic/PFAS/BPA/phthalate exposure", "endocrine or barrier mediator", "immune mediator", "systemic inflammation", "endocrine-immune phenotype"),
            mediators = listOf("endocrine disruption", "oxidative stress", "barrier disruption", "xenobiotic metabolism", "hormone-immune cross-talk"),
            immuneMediators = listOf("IL-6", "TNF", "CRP", "IFN", "inflammasome"),
            phenotypes = listOf("endocrine-immune inflammation", "metabolic inflammation", "systemic inflammatory phenotype"),
            datasetNeeded = listOf("measured exposure level", "serum/urine biomarker", "cytokine panel", "host transcriptome", "exposed/unexposed comparator"),
            comparatorNeeded = listOf("exposed vs unexposed", "dose quartiles", "sex/age/hormone metadata", "occupational vs environmental route"),
            queryTemplates = listOf("microplastics BPA PFAS endocrine immune inflammation IL-6 TNF CRP human cohort data availability", "phthalate endocrine disruptor cytokine transcriptome exposed unexposed comparator DOI PMID", "PFAS immune inflammation CRP IL-6 human cohort dataset OpenAlex Europe PMC"),
            contradictionTemplates = listOf("PFAS immune inflammation no association null result", "microplastics cytokine human cohort negative result", "BPA endocrine immune inflammation failed replication")
        )
    )

    fun build(rawText: String): GTIMRelationshipDiscoveryPlanV2736 = buildInternal(rawText, null)

    /**
     * Contract-scoped entrypoint for production pipelines. The plain build(rawText)
     * remains pure for unit tests and standalone relationship exploration; this method
     * applies the active run contract only when the caller explicitly supplies it.
     */
    fun buildForContract(rawText: String, contract: GTIMRunDecisionContractV2740?): GTIMRelationshipDiscoveryPlanV2736 = buildInternal(rawText, contract)

    private fun buildInternal(rawText: String, contract: GTIMRunDecisionContractV2740?): GTIMRelationshipDiscoveryPlanV2736 {
        val normalized = rawText.lowercase(Locale.US)
        if (normalized.isBlank()) return GTIMRelationshipDiscoveryPlanV2736.empty()
        val activeSignals = listOf(
            microbiomeTerms.any { normalized.contains(it) } || exposureTerms.any { normalized.contains(it) },
            moleculeTerms.any { normalized.contains(it) },
            immuneTerms.any { normalized.contains(it) },
            phenotypeTerms.any { normalized.contains(it) }
        ).count { it }
        val archetype = archetypes
            .map { it to relationshipMatchScore(normalized, it) }
            .filter { (candidate, score) -> score > 0 && isArchetypeTopicCompatible(normalized, candidate.id) }
            .maxByOrNull { it.second }
            ?.first
        if (activeSignals < 2 && archetype == null) return GTIMRelationshipDiscoveryPlanV2736.empty()
        val selected = archetype ?: return GTIMRelationshipDiscoveryPlanV2736.empty()
        val selectedContractRouteId = contractRouteIdForArchetype(selected.id)
        if (contract != null && !contract.canUseRoute(selectedContractRouteId)) {
            return GTIMRelationshipDiscoveryPlanV2736.empty()
        }
        val extractedMediators = selected.mediators.filter { normalized.contains(it.lowercase(Locale.US)) }.ifEmpty { selected.mediators.take(4) }
        val extractedImmune = selected.immuneMediators.filter { mediator ->
            val m = mediator.lowercase(Locale.US)
            normalized.contains(m) || normalized.contains(m.replace("-", ""))
        }.ifEmpty { selected.immuneMediators.take(4) }
        val phenotypes = selected.phenotypes.filter { normalized.contains(it.lowercase(Locale.US)) }.ifEmpty { selected.phenotypes.take(3) }
        val chain = selected.chain
        return GTIMRelationshipDiscoveryPlanV2736(
            active = true,
            version = VERSION,
            state = STATE,
            matchedArchetype = selected.id,
            relationshipChain = chain,
            mediatorCandidates = extractedMediators,
            immuneMediators = extractedImmune,
            phenotypeTargets = phenotypes,
            supportingLeadQueries = selected.queryTemplates,
            contradictionQueries = selected.contradictionTemplates,
            datasetNeeded = selected.datasetNeeded,
            comparatorNeeded = selected.comparatorNeeded,
            nextQuery = selected.queryTemplates.first(),
            gtimAdded = listOf(
                "contract route: $selectedContractRouteId",
                "relationship chain: ${chain.joinToString(" -> ")}",
                "mediator candidates: ${extractedMediators.take(4).joinToString(", ")}",
                "immune mediator gate: ${extractedImmune.take(4).joinToString(", ")}",
                "supporting and contradiction queries separated",
                "dataset/comparator requirements made explicit"
            ),
            gtimDidNotProve = listOf("causality", "diagnosis", "treatment", "patient-level prediction", "that any exposure or microbe applies to all patients")
        )
    }

    private fun relationshipMatchScore(normalized: String, archetype: RelationshipArchetypeV2736): Int {
        val raw = archetype.matchTerms.count { term -> normalized.contains(term.lowercase(Locale.US)) }
        val id = archetype.id
        val requiredBoost = when {
            id.startsWith("covid_") && containsAny(normalized, "covid", "sars-cov-2", "sars cov 2", "long covid", "pasc") -> 20
            id.startsWith("allergy_") && containsAny(normalized, "allergy", "allergies", "allergic", "hypersensitivity", "atopy", "atopic", "allergen") -> 20
            id.startsWith("microbiome_depression") && containsAny(normalized, "depression", "major depressive", "mood") && containsAny(normalized, "microbiome", "microbiota", "gut bacteria", "gut-brain", "tryptophan", "kynurenine") -> 20
            id.startsWith("microbiome_anxiety") && containsAny(normalized, "anxiety") && containsAny(normalized, "microbiome", "microbiota", "gut bacteria", "tryptophan", "kynurenine") -> 20
            id.startsWith("pesticide_") && containsAny(normalized, "pesticide", "pesticides", "glyphosate", "organophosphate", "food residue", "sprayed food") -> 20
            id.startsWith("livestock_") && containsAny(normalized, "livestock", "poultry", "resistome", "farm antibiotic", "antibiotics in livestock", "meat antibiotic") -> 20
            id.startsWith("plastic_") && containsAny(normalized, "microplastic", "microplastics", "pfas", "bpa", "phthalate", "plasticizer") -> 20
            else -> 0
        }
        return raw + requiredBoost
    }

    private fun isArchetypeTopicCompatible(normalized: String, id: String): Boolean = when {
        id.startsWith("covid_") -> containsAny(normalized, "covid", "sars-cov-2", "sars cov 2", "long covid", "pasc")
        id.startsWith("allergy_") -> containsAny(normalized, "allergy", "allergies", "allergic", "hypersensitivity", "atopy", "atopic", "allergen")
        id.startsWith("microbiome_depression") -> containsAny(normalized, "depression", "major depressive", "mood") && containsAny(normalized, "microbiome", "microbiota", "gut bacteria", "gut-brain", "tryptophan", "kynurenine", "bacteria")
        id.startsWith("microbiome_anxiety") -> containsAny(normalized, "anxiety") && containsAny(normalized, "microbiome", "microbiota", "gut bacteria", "tryptophan", "kynurenine", "bacteria")
        id.startsWith("pesticide_") -> containsAny(normalized, "pesticide", "pesticides", "glyphosate", "organophosphate", "food residue", "sprayed food")
        id.startsWith("livestock_") -> containsAny(normalized, "livestock", "poultry", "resistome", "farm antibiotic", "antibiotics in livestock", "meat antibiotic")
        id.startsWith("plastic_") -> containsAny(normalized, "microplastic", "microplastics", "pfas", "bpa", "phthalate", "plasticizer")
        else -> false
    }

    private fun contractRouteIdForArchetype(id: String): String = when {
        id.startsWith("covid_") -> GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL.routeId
        id.startsWith("allergy_") -> GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL.routeId
        id.startsWith("microbiome_depression") -> GTIMDiscoveryBridgeV2740.GUT_MICROBIOME_TO_NEUROINFLAMMATION.routeId
        id.startsWith("microbiome_anxiety") -> GTIMDiscoveryBridgeV2740.MICROBIOME_TO_HPA_STRESS_AXIS.routeId
        id.startsWith("pesticide_") -> "pesticide_exposure"
        id.startsWith("livestock_") -> "livestock_antibiotics_resistome_immune_bridge"
        id.startsWith("plastic_") -> "plastic_pfas_endocrine_immune_inflammation_bridge"
        else -> id
    }

    private fun containsAny(normalized: String, vararg needles: String): Boolean = needles.any { normalized.contains(it) }

    fun oneLine(plan: GTIMRelationshipDiscoveryPlanV2736): String = if (!plan.active) {
        "Relationship discovery route not opened."
    } else {
        "${plan.state}; archetype=${plan.matchedArchetype}; chain=${plan.relationshipChain.joinToString(" -> ")}; claimLimit=${plan.claimLimit}"
    }
}
