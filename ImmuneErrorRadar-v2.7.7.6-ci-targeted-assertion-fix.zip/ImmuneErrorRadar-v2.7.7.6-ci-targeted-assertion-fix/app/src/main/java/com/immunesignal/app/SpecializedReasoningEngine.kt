package com.immunesignal.app

/**
 * v1.6.0: Specialized Research Reasoning Engine.
 *
 * This is not a general chatbot layer. It is a bounded domain reasoning layer
 * that forces the immune-research cycle to behave like a disciplined research
 * assistant: define competing explanations, demand discriminating evidence,
 * prevent axis contamination, and choose the next decisive test.
 *
 * Claim boundary: this layer improves the hunt; it never proves biology,
 * diagnosis, treatment value, immune outcomes, or causality.
 */
data class SpecialistReasoningMove(
    val name: String,
    val status: String,
    val score: Int,
    val finding: String,
    val nextAction: String
)

/** v1.6.1: explicit evidence gaps so the specialist layer is measurable, not narrative. */
data class EvidenceGapCard(
    val gapId: String,
    val status: String,
    val severity: Int,
    val whyItMatters: String,
    val requiredAction: String
)

/** v1.6.1: hypothesis tournament ranks live explanations by testability, not confidence theater. */
data class HypothesisTournamentCard(
    val hypothesisId: String,
    val label: String,
    val status: String,
    val score: Int,
    val nextDiscriminator: String
)

/** v1.6.1: audit questions that expose whether the cycle beat a generic answer. */
data class ReasoningAuditQuestion(
    val question: String,
    val answer: String,
    val passed: Boolean
)

data class SpecializedReasoningReport(
    val active: Boolean,
    val specialistScore: Int,
    val state: String,
    val weakestLink: String,
    val strongestImprovement: String,
    val decisiveNextTest: String,
    val falsificationDemand: String,
    val axisDiscipline: String,
    val generalModelFailureRisks: List<String>,
    val expertMoves: List<SpecialistReasoningMove>,
    val evidenceGaps: List<EvidenceGapCard>,
    val hypothesisTournament: List<HypothesisTournamentCard>,
    val reasoningAudit: List<ReasoningAuditQuestion>,
    val specialistVerdict: String,
    val nextCycleProtocol: List<String>,
    val visibleBrief: String,
    val claimLimit: String = "specialized_reasoning_not_biological_proof"
) {
    companion object {
        fun empty() = SpecializedReasoningReport(
            active = false,
            specialistScore = 0,
            state = "NOT_EVALUATED",
            weakestLink = "No research cycle was available for specialized reasoning.",
            strongestImprovement = "Run a Search cycle first.",
            decisiveNextTest = "No decisive next test yet.",
            falsificationDemand = "No falsification demand yet.",
            axisDiscipline = "No axis discipline decision yet.",
            generalModelFailureRisks = emptyList(),
            expertMoves = emptyList(),
            evidenceGaps = emptyList(),
            hypothesisTournament = emptyList(),
            reasoningAudit = emptyList(),
            specialistVerdict = "No specialist verdict yet.",
            nextCycleProtocol = emptyList(),
            visibleBrief = "Specialized reasoning has not run yet."
        )
    }
}

object SpecializedReasoningEngine {
    fun evaluate(
        findings: List<ResearchFinding>,
        hypothesisObjects: List<HypothesisObject>,
        evidenceObjects: List<EvidenceObject>,
        datasetForagingReport: DatasetForagingReport,
        learningOsReport: LearningOsReport,
        reasoningReport: ResearchReasoningReport,
        reportV3: ResearchReportV3
    ): SpecializedReasoningReport {
        val parsedCount = datasetForagingReport.parsedMetadata.size
        val candidateCount = datasetForagingReport.candidates.size
        val routeFitScore = datasetForagingReport.scoreSeparation.routeFitScore
        val hypothesisConfidence = datasetForagingReport.scoreSeparation.hypothesisConfidenceScore
        val contrastiveStatus = datasetForagingReport.contrastiveReport.gateStatus
        val hasOutcomeLabels = datasetForagingReport.parsedMetadata.any { it.outcomeLabels.isNotEmpty() }
        val hasControls = datasetForagingReport.parsedMetadata.any { it.controlLabels.isNotEmpty() }
        val hasTimeCourse = datasetForagingReport.parsedMetadata.any { it.timeCourseLabels.isNotEmpty() }
        val explicitContradiction = findings.any { it.causality.contradictionPenalty > 0 || it.negativeControl.status.contains("watch", ignoreCase = true) }
        val rootCauses = learningOsReport.incident.rootCauses
        val routeBlocked = datasetForagingReport.routeFitAssessments.any { it.blocksHypothesisUpgrade }
        val highRouteNoMetadata = routeFitScore >= 80 && parsedCount == 0 && candidateCount > 0
        val narrativeUpgradeRisk = routeFitScore >= 80 && hypothesisConfidence >= 60 && parsedCount == 0

        val score = buildScore(
            parsedCount = parsedCount,
            evidenceObjects = evidenceObjects,
            hasOutcomeLabels = hasOutcomeLabels,
            hasControls = hasControls,
            hasTimeCourse = hasTimeCourse,
            explicitContradiction = explicitContradiction,
            routeBlocked = routeBlocked,
            highRouteNoMetadata = highRouteNoMetadata,
            narrativeUpgradeRisk = narrativeUpgradeRisk,
            contrastiveStatus = contrastiveStatus
        )
        val state = when {
            score >= 80 -> "SPECIALIST_STRONG"
            score >= 65 -> "SPECIALIST_USEFUL"
            score >= 45 -> "SPECIALIST_CAUTION"
            else -> "SPECIALIST_WEAK"
        }
        val weakest = weakestLink(
            parsedCount,
            hasOutcomeLabels,
            hasControls,
            hasTimeCourse,
            contrastiveStatus,
            explicitContradiction,
            highRouteNoMetadata,
            rootCauses
        )
        val decisive = decisiveNextTest(
            datasetForagingReport,
            learningOsReport,
            reasoningReport,
            reportV3,
            hasOutcomeLabels,
            hasControls,
            hasTimeCourse,
            explicitContradiction,
            highRouteNoMetadata
        )
        val falsification = falsificationDemand(reasoningReport, datasetForagingReport, explicitContradiction)
        val axisDiscipline = axisDiscipline(datasetForagingReport, findings)
        val risks = generalModelRisks(
            narrativeUpgradeRisk = narrativeUpgradeRisk,
            highRouteNoMetadata = highRouteNoMetadata,
            routeBlocked = routeBlocked,
            parsedCount = parsedCount,
            contrastiveStatus = contrastiveStatus,
            findings = findings,
            reportV3 = reportV3
        )
        val moves = expertMoves(
            reasoningReport = reasoningReport,
            learningOsReport = learningOsReport,
            datasetForagingReport = datasetForagingReport,
            weakest = weakest,
            decisive = decisive,
            falsification = falsification,
            axisDiscipline = axisDiscipline,
            score = score
        )
        val gaps = evidenceGapMatrix(
            parsedCount = parsedCount,
            hasOutcomeLabels = hasOutcomeLabels,
            hasControls = hasControls,
            hasTimeCourse = hasTimeCourse,
            explicitContradiction = explicitContradiction,
            highRouteNoMetadata = highRouteNoMetadata
        )
        val tournament = hypothesisTournament(
            hypothesisObjects = hypothesisObjects,
            reasoningReport = reasoningReport,
            datasetForagingReport = datasetForagingReport,
            gaps = gaps
        )
        val audit = reasoningAudit(
            competingCount = reasoningReport.competingHypotheses.size,
            discriminatorCount = reasoningReport.discriminatorEvidence.size,
            gaps = gaps,
            risks = risks,
            decisive = decisive,
            falsification = falsification
        )
        val protocol = nextCycleProtocol(
            decisive = decisive,
            gaps = gaps,
            datasetForagingReport = datasetForagingReport,
            reasoningReport = reasoningReport
        )
        val verdict = specialistVerdict(state, score, gaps, audit, tournament)
        val improvement = strongestImprovement(weakest, decisive, datasetForagingReport)
        val brief = "Specialized reasoning: $state ($score/100). Verdict: $verdict Weakest link: $weakest Next decisive test: $decisive"
        return SpecializedReasoningReport(
            active = true,
            specialistScore = score,
            state = state,
            weakestLink = weakest,
            strongestImprovement = improvement,
            decisiveNextTest = decisive,
            falsificationDemand = falsification,
            axisDiscipline = axisDiscipline,
            generalModelFailureRisks = risks,
            expertMoves = moves,
            evidenceGaps = gaps,
            hypothesisTournament = tournament,
            reasoningAudit = audit,
            specialistVerdict = verdict,
            nextCycleProtocol = protocol,
            visibleBrief = brief
        )
    }

    private fun buildScore(
        parsedCount: Int,
        evidenceObjects: List<EvidenceObject>,
        hasOutcomeLabels: Boolean,
        hasControls: Boolean,
        hasTimeCourse: Boolean,
        explicitContradiction: Boolean,
        routeBlocked: Boolean,
        highRouteNoMetadata: Boolean,
        narrativeUpgradeRisk: Boolean,
        contrastiveStatus: String
    ): Int {
        var score = 35
        if (parsedCount > 0) score += 12 else score -= 8
        if (evidenceObjects.isNotEmpty()) score += 8
        if (hasOutcomeLabels) score += 12 else score -= 6
        if (hasControls) score += 8
        if (hasTimeCourse) score += 8
        if (explicitContradiction) score += 10
        if (contrastiveStatus.contains("PASS", ignoreCase = true)) score += 12
        if (routeBlocked) score += 5
        if (highRouteNoMetadata) score -= 12
        if (narrativeUpgradeRisk) score -= 8
        return score.coerceIn(0, 100)
    }

    private fun weakestLink(
        parsedCount: Int,
        hasOutcomeLabels: Boolean,
        hasControls: Boolean,
        hasTimeCourse: Boolean,
        contrastiveStatus: String,
        explicitContradiction: Boolean,
        highRouteNoMetadata: Boolean,
        rootCauses: List<String>
    ): String = when {
        highRouteNoMetadata -> "High route-fit exists, but minimum metadata is still missing."
        parsedCount == 0 -> "No parsed dataset metadata; the engine cannot inspect condition/outcome labels yet."
        !hasOutcomeLabels -> "Outcome/recovery/severity labels are missing."
        !hasTimeCourse -> "Time order is missing; causality cannot be separated from correlation."
        !hasControls -> "Control or comparator labels are weak."
        contrastiveStatus == "NOT_EVALUATED" -> "Contrastive gate did not run yet."
        !explicitContradiction -> "Contradiction/falsification search is still too weak."
        rootCauses.isNotEmpty() -> "Repeated failure pattern still active: ${rootCauses.joinToString(", ")}."
        else -> "No critical weak link detected, but claim limits remain active."
    }

    private fun decisiveNextTest(
        datasetForagingReport: DatasetForagingReport,
        learningOsReport: LearningOsReport,
        reasoningReport: ResearchReasoningReport,
        reportV3: ResearchReportV3,
        hasOutcomeLabels: Boolean,
        hasControls: Boolean,
        hasTimeCourse: Boolean,
        explicitContradiction: Boolean,
        highRouteNoMetadata: Boolean
    ): String = when {
        highRouteNoMetadata -> "Parse minimum metadata for the high route-fit accession before any hypothesis language is upgraded."
        !hasOutcomeLabels -> "Search for the same route plus outcome/recovery/severity/response labels."
        !hasTimeCourse -> "Find longitudinal or early-vs-late samples to establish time order."
        !hasControls -> "Find healthy/exposed/placebo/responder comparator labels."
        !explicitContradiction -> "Run contradiction search: nonresponse, no association, failed replication, or harmful timing."
        learningOsReport.nextLearningAction.isNotBlank() -> learningOsReport.nextLearningAction
        reasoningReport.discriminatorEvidence.isNotEmpty() -> reasoningReport.discriminatorEvidence.first()
        reportV3.nextAutonomousMove.isNotBlank() -> reportV3.nextAutonomousMove
        datasetForagingReport.nextAction.isNotBlank() -> datasetForagingReport.nextAction
        else -> "Run the next dataset-first Search cycle with explicit falsification terms."
    }.take(280)

    private fun falsificationDemand(
        reasoningReport: ResearchReasoningReport,
        datasetForagingReport: DatasetForagingReport,
        explicitContradiction: Boolean
    ): String {
        if (!explicitContradiction) {
            return "Before strengthening any hypothesis, find a result that could make it false: nonresponse, no association, reverse timing, or unrelated-marker control."
        }
        val discriminator = reasoningReport.discriminatorEvidence.firstOrNull().orEmpty()
        val next = datasetForagingReport.contrastiveReport.nextContrastiveQuestion
        return listOf(discriminator, next)
            .firstOrNull { it.isNotBlank() }
            ?: "Keep the contradiction lane open until the top hypothesis survives negative controls."
    }

    private fun axisDiscipline(datasetForagingReport: DatasetForagingReport, findings: List<ResearchFinding>): String {
        val topRoute = datasetForagingReport.routeFitAssessments.maxByOrNull { it.routeFitScore }
        if (topRoute != null) {
            return when {
                topRoute.blocksHypothesisUpgrade -> "Axis discipline: ${topRoute.accession} belongs to ${topRoute.datasetRoute}; it must not upgrade ${topRoute.targetRoute}."
                topRoute.routeFitScore >= 85 -> "Axis discipline: keep this lead inside ${topRoute.datasetRoute}; inspect metadata before broadening to adjacent axes."
                else -> "Axis discipline: route-fit is modest; use only as analogy or contrast."
            }
        }
        val axes = findings.flatMap { it.matchedAxes }.distinct().take(4)
        return if (axes.isNotEmpty()) {
            "Axis discipline: active axes are ${axes.joinToString(", ")}; generic inflammation alone cannot select the route."
        } else {
            "Axis discipline: no reliable axis selected yet."
        }
    }

    private fun generalModelRisks(
        narrativeUpgradeRisk: Boolean,
        highRouteNoMetadata: Boolean,
        routeBlocked: Boolean,
        parsedCount: Int,
        contrastiveStatus: String,
        findings: List<ResearchFinding>,
        reportV3: ResearchReportV3
    ): List<String> {
        val risks = mutableListOf<String>()
        if (narrativeUpgradeRisk) risks += "Generic-AI risk: treating high route-fit as biological confidence."
        if (highRouteNoMetadata) risks += "Generic-AI risk: explaining a dataset before reading its minimum metadata."
        if (routeBlocked) risks += "Generic-AI risk: transferring evidence across axes because vocabulary overlaps."
        if (parsedCount == 0) risks += "Generic-AI risk: producing mechanism narrative from titles only."
        if (contrastiveStatus == "NOT_EVALUATED") risks += "Generic-AI risk: answering without a contrastive comparator."
        if (findings.none { it.causality.contradictionPenalty > 0 }) risks += "Generic-AI risk: confirmation-only search with weak falsification."
        if (reportV3.whatWeDoNotBelieveYet.length < 80) risks += "Generic-AI risk: unknowns are too short to protect against overclaiming."
        return risks.distinct().take(6).ifEmpty { listOf("No major general-model reasoning risk detected in this cycle.") }
    }

    private fun expertMoves(
        reasoningReport: ResearchReasoningReport,
        learningOsReport: LearningOsReport,
        datasetForagingReport: DatasetForagingReport,
        weakest: String,
        decisive: String,
        falsification: String,
        axisDiscipline: String,
        score: Int
    ): List<SpecialistReasoningMove> {
        val competingStatus = if (reasoningReport.competingHypotheses.size >= 2) "PASS" else "WEAK"
        val discriminatorStatus = if (reasoningReport.discriminatorEvidence.isNotEmpty()) "PASS" else "WEAK"
        val failureStatus = if (learningOsReport.incident.rootCauses.isNotEmpty()) "PASS" else "WATCH"
        val routeStatus = if (datasetForagingReport.routeFitAssessments.isNotEmpty()) "PASS" else "WATCH"
        val falsifierStatus = if (falsification.contains("Before strengthening", ignoreCase = true)) "REQUIRED" else "PASS"
        return listOf(
            SpecialistReasoningMove(
                name = "Competing explanations",
                status = competingStatus,
                score = if (competingStatus == "PASS") 80 else 45,
                finding = reasoningReport.competingHypotheses.firstOrNull() ?: "Only one explanation is visible.",
                nextAction = "Keep at least two live explanations until a discriminator resolves them."
            ),
            SpecialistReasoningMove(
                name = "Discriminator evidence",
                status = discriminatorStatus,
                score = if (discriminatorStatus == "PASS") 78 else 35,
                finding = reasoningReport.discriminatorEvidence.firstOrNull() ?: weakest,
                nextAction = decisive
            ),
            SpecialistReasoningMove(
                name = "Failure-to-query learning",
                status = failureStatus,
                score = if (failureStatus == "PASS") 75 else 50,
                finding = learningOsReport.incident.rootCauses.joinToString(", ").ifBlank { "No repeated failure root cause this cycle." },
                nextAction = learningOsReport.nextLearningAction.ifBlank { "Keep recording failure causes." }
            ),
            SpecialistReasoningMove(
                name = "Axis contamination guard",
                status = routeStatus,
                score = if (routeStatus == "PASS") 82 else 48,
                finding = axisDiscipline,
                nextAction = "Never let generic inflammation choose the route without required evidence."
            ),
            SpecialistReasoningMove(
                name = "Falsification pressure",
                status = falsifierStatus,
                score = if (falsifierStatus == "PASS") 76 else 42,
                finding = falsification,
                nextAction = "Run negative-control or contradiction terms before upgrade."
            ),
            SpecialistReasoningMove(
                name = "Specialist score",
                status = if (score >= 65) "USEFUL" else "CAUTION",
                score = score,
                finding = "Domain reasoning score is $score/100.",
                nextAction = if (score < 65) "Do not compare this cycle to a strong AI result until the decisive test is executed." else "Proceed with cautious dataset inspection."
            )
        )
    }


    private fun evidenceGapMatrix(
        parsedCount: Int,
        hasOutcomeLabels: Boolean,
        hasControls: Boolean,
        hasTimeCourse: Boolean,
        explicitContradiction: Boolean,
        highRouteNoMetadata: Boolean
    ): List<EvidenceGapCard> {
        val gaps = mutableListOf<EvidenceGapCard>()
        if (parsedCount == 0 || highRouteNoMetadata) {
            gaps += EvidenceGapCard(
                gapId = "MINIMUM_METADATA",
                status = if (parsedCount == 0) "MISSING" else "PARTIAL",
                severity = if (highRouteNoMetadata) 95 else 85,
                whyItMatters = "The engine cannot inspect species, condition labels, outcome labels, or controls from title-only evidence.",
                requiredAction = "Run minimum metadata parsing for the strongest accession before using mechanistic language."
            )
        }
        if (!hasOutcomeLabels) {
            gaps += EvidenceGapCard(
                gapId = "OUTCOME_LABELS",
                status = "MISSING",
                severity = 92,
                whyItMatters = "A research lead without recovery, severity, response, or endpoint labels cannot test success versus damage.",
                requiredAction = "Require outcome/recovery/severity/response terms in the next query or parse metadata for those labels."
            )
        }
        if (!hasTimeCourse) {
            gaps += EvidenceGapCard(
                gapId = "TIME_ORDER",
                status = "MISSING",
                severity = 84,
                whyItMatters = "Without early/late or longitudinal samples, correlation can masquerade as causality.",
                requiredAction = "Prefer longitudinal, serial, follow-up, early timepoint, or time-course datasets."
            )
        }
        if (!hasControls) {
            gaps += EvidenceGapCard(
                gapId = "COMPARATOR_CONTROL",
                status = "WEAK",
                severity = 74,
                whyItMatters = "A comparator is needed to separate trigger response from background immune noise.",
                requiredAction = "Find healthy, exposed, placebo, responder, non-responder, or negative-control labels."
            )
        }
        if (!explicitContradiction) {
            gaps += EvidenceGapCard(
                gapId = "FALSIFICATION_LANE",
                status = "WEAK",
                severity = 78,
                whyItMatters = "A specialist engine must search for what would make its lead wrong, not only what supports it.",
                requiredAction = "Add nonresponse, no association, failed replication, reverse timing, or unrelated-marker control terms."
            )
        }
        return gaps.sortedByDescending { it.severity }.take(6)
    }

    private fun hypothesisTournament(
        hypothesisObjects: List<HypothesisObject>,
        reasoningReport: ResearchReasoningReport,
        datasetForagingReport: DatasetForagingReport,
        gaps: List<EvidenceGapCard>
    ): List<HypothesisTournamentCard> {
        val routeSignal = datasetForagingReport.routeFitAssessments.maxByOrNull { it.routeFitScore }
        val gapPenalty = gaps.sumOf { (it.severity / 25).coerceAtMost(4) }.coerceAtMost(18)
        val cards = hypothesisObjects.take(5).map { hyp ->
            val base = (hyp.dataTrustScore * 0.35 + hyp.evidenceScore10 * 6.0 + hyp.causalityScore * 0.25).toInt()
            val specificityBoost = if (routeSignal != null && hyp.label.contains(routeSignal.datasetRoute, ignoreCase = true)) 8 else 0
            val score = (base + specificityBoost - gapPenalty).coerceIn(0, 100)
            HypothesisTournamentCard(
                hypothesisId = hyp.hypothesisId,
                label = hyp.label,
                status = when {
                    score >= 75 -> "TESTABLE_FRONT_RUNNER"
                    score >= 55 -> "KEEP_ALIVE"
                    else -> "WEAK_OR_ANALOGY"
                },
                score = score,
                nextDiscriminator = hyp.nextBestMeasurement.ifBlank { routeSignal?.allowedUse ?: "Find discriminator evidence before ranking this hypothesis higher." }
            )
        }
        if (cards.isNotEmpty()) return cards.sortedByDescending { it.score }

        val generated = reasoningReport.competingHypotheses.take(4).mapIndexed { index, text ->
            HypothesisTournamentCard(
                hypothesisId = "competing_${index + 1}",
                label = text.take(120),
                status = "UNSTRUCTURED_KEEP_ALIVE",
                score = (50 - gapPenalty + index).coerceIn(20, 65),
                nextDiscriminator = reasoningReport.discriminatorEvidence.getOrNull(index)
                    ?: "Convert this explanation into a structured hypothesis object with a decisive discriminator."
            )
        }
        return generated
    }

    private fun reasoningAudit(
        competingCount: Int,
        discriminatorCount: Int,
        gaps: List<EvidenceGapCard>,
        risks: List<String>,
        decisive: String,
        falsification: String
    ): List<ReasoningAuditQuestion> {
        return listOf(
            ReasoningAuditQuestion(
                question = "Did the cycle keep at least two competing explanations alive?",
                answer = if (competingCount >= 2) "Yes: $competingCount explanations visible." else "No: competing explanations are too thin.",
                passed = competingCount >= 2
            ),
            ReasoningAuditQuestion(
                question = "Is there a discriminator that could separate the explanations?",
                answer = if (discriminatorCount > 0) "Yes: discriminator evidence requested." else "No: next step risks becoming generic follow-up.",
                passed = discriminatorCount > 0
            ),
            ReasoningAuditQuestion(
                question = "Are the top evidence gaps explicit and actionable?",
                answer = if (gaps.isNotEmpty()) "Yes: ${gaps.first().gapId} is the top gap." else "No critical gap surfaced.",
                passed = gaps.isNotEmpty()
            ),
            ReasoningAuditQuestion(
                question = "Did the engine name what would falsify the lead?",
                answer = falsification.take(180),
                passed = !falsification.contains("No falsification", ignoreCase = true)
            ),
            ReasoningAuditQuestion(
                question = "Is the next action a decisive test rather than a vague search?",
                answer = decisive.take(180),
                passed = listOf("metadata", "outcome", "longitudinal", "control", "contradiction", "viral load", "severity", "recovery")
                    .any { decisive.contains(it, ignoreCase = true) }
            ),
            ReasoningAuditQuestion(
                question = "Did the cycle avoid generic-AI overclaiming?",
                answer = if (risks.none { it.contains("Generic-AI risk") }) "No major generic-AI risk detected." else risks.first().take(180),
                passed = risks.count { it.contains("Generic-AI risk") } <= 2
            )
        )
    }

    private fun nextCycleProtocol(
        decisive: String,
        gaps: List<EvidenceGapCard>,
        datasetForagingReport: DatasetForagingReport,
        reasoningReport: ResearchReasoningReport
    ): List<String> {
        val steps = mutableListOf<String>()
        steps += "1) Execute decisive test: ${decisive.take(180)}"
        gaps.take(3).forEachIndexed { index, gap ->
            steps += "${index + 2}) Close ${gap.gapId}: ${gap.requiredAction.take(170)}"
        }
        val contrastive = datasetForagingReport.contrastiveReport.nextContrastiveQuestion
        if (contrastive.isNotBlank()) steps += "${steps.size + 1}) Contrastive check: ${contrastive.take(170)}"
        val reframed = reasoningReport.reframedSearch
        if (reframed.isNotBlank()) steps += "${steps.size + 1}) Reframed search: ${reframed.take(170)}"
        steps += "${steps.size + 1}) Keep claim limit: specialized reasoning guides the hunt; evidence gates belief."
        return steps.take(7)
    }

    private fun specialistVerdict(
        state: String,
        score: Int,
        gaps: List<EvidenceGapCard>,
        audit: List<ReasoningAuditQuestion>,
        tournament: List<HypothesisTournamentCard>
    ): String {
        val failedAudits = audit.count { !it.passed }
        val topGap = gaps.maxByOrNull { it.severity }
        val topHypothesis = tournament.maxByOrNull { it.score }
        return when {
            topGap != null && topGap.severity >= 90 -> "Not ready for strong reasoning: close ${topGap.gapId} first."
            failedAudits >= 3 -> "Specialist reasoning is still weak; the next cycle must execute the discriminator protocol."
            topHypothesis != null && topHypothesis.score >= 75 && score >= 70 -> "Useful specialist lead; run the listed decisive test before any upgrade."
            state.contains("CAUTION") || score < 65 -> "Cautious specialist lead only; use as search routing, not evidence."
            else -> "Specialist reasoning is useful for prioritizing the next hunt, not for proof."
        }
    }

    private fun strongestImprovement(weakest: String, decisive: String, datasetForagingReport: DatasetForagingReport): String {
        return when {
            weakest.contains("metadata", ignoreCase = true) -> "Convert high route-fit leads into minimum metadata objects immediately."
            weakest.contains("Outcome", ignoreCase = true) -> "Make outcome/recovery/severity labels mandatory in the next query."
            weakest.contains("Time", ignoreCase = true) -> "Prioritize longitudinal/time-course datasets over more titles."
            weakest.contains("Contradiction", ignoreCase = true) -> "Run a contradiction lane before any confidence increase."
            datasetForagingReport.autoContinuationReport.triggered -> datasetForagingReport.autoContinuationReport.recommendedAction
            else -> decisive
        }.take(260)
    }
}
