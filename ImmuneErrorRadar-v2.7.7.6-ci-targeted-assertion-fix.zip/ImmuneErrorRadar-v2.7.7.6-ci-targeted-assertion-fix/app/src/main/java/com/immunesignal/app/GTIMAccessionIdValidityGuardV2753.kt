package com.immunesignal.app

/**
 * v2.7.5.3 — Accession ID validity guard.
 *
 * Prevents bare repository prefixes such as "GSE", "SDY", "PMID", "PRJNA" from
 * becoming Matrix Audit targets. A matrix target must be a full accession token.
 */
object GTIMAccessionIdValidityGuardV2753 {
    const val VERSION: String = "2.7.5.3-accession-id-validity-guard"

    private val fullAccessionRegex = Regex(
        "(?i)^(GSE\\d+|GDS\\d+|PRJNA\\d+|SRP\\d+|SRR\\d+|E-MTAB-\\d+|SDY\\d+|PMID:\\d+|DOI:[A-Za-z0-9./_:-]+)$"
    )

    private val barePrefixRegex = Regex("(?i)^(GSE|GDS|PRJNA|SRP|SRR|E-MTAB-|SDY|PMID|DOI)$")

    fun isFullAccession(value: String): Boolean = fullAccessionRegex.matches(canonical(value))

    fun isBarePrefix(value: String): Boolean = barePrefixRegex.matches(value.trim())

    fun canonical(value: String): String {
        return value.trim().takeWhile { ch -> ch.isLetterOrDigit() || ch == ':' || ch == '-' || ch == '_' || ch == '.' || ch == '/' }
    }

    fun extractFullAccessions(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val regex = Regex("(?i)\\b(GSE\\d+|GDS\\d+|PRJNA\\d+|SRP\\d+|SRR\\d+|E-MTAB-\\d+|SDY\\d+|PMID:\\d+|DOI:[A-Za-z0-9./_:-]+)\\b")
        return regex.findAll(text)
            .map { canonical(it.value) }
            .filter { isFullAccession(it) }
            .distinct()
            .toList()
    }
}
