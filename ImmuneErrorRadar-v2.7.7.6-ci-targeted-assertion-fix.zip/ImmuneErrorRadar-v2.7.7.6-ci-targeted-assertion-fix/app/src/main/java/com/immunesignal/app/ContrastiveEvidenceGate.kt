package com.immunesignal.app

/** v1.4.2: evaluates whether metadata supports real contrastive learning questions. */
object ContrastiveEvidenceGate {
    fun evaluate(parsed: List<ParsedDatasetMetadata>): ContrastiveEvidenceReport {
        if (parsed.isEmpty()) return ContrastiveEvidenceReport.empty()
        val slots = parsed.flatMap { it.contrastiveSlots }.distinct()
        val usable = parsed.count { it.usabilityVerdict == "USABLE_FOR_TEST" }
        val partial = parsed.count { it.usabilityVerdict == "USABLE_FOR_HYPOTHESIS_GENERATION_ONLY" }
        val status = when {
            usable > 0 && slots.isNotEmpty() -> "PASS_TESTABLE_CONTRAST"
            partial > 0 && slots.isNotEmpty() -> "PASS_HYPOTHESIS_GENERATION_ONLY"
            slots.isNotEmpty() -> "WEAK_CONTRAST_METADATA_ONLY"
            else -> "BLOCKED_NO_CONTRASTIVE_SLOT"
        }
        val next = when {
            slots.contains("responder_vs_nonresponder") -> "Compare responder/non-responder immune signatures before any upgrade."
            slots.contains("mild_vs_severe") -> "Inspect mild/severe labels and check whether immune response precedes severity."
            slots.contains("exposed_vs_control") -> "Inspect exposed/control balance, sample size, and confounders."
            else -> "Search specifically for response/nonresponse, mild/severe, recovery/persistent, or exposed/control labels."
        }
        return ContrastiveEvidenceReport(
            gateStatus = status,
            slotsDetected = slots,
            summary = "Parsed ${parsed.size} dataset candidate(s): usable=$usable, hypothesis-generation-only=$partial, contrastive slots=${slots.size}.",
            nextContrastiveQuestion = next
        )
    }
}
