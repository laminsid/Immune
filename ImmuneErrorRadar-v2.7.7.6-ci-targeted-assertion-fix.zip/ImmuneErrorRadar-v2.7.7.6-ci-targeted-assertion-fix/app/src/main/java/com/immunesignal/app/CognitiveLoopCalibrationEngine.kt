package com.immunesignal.app

/**
 * v1.6.8: cognitive loop calibration.
 *
 * v1.6.5-v1.6.7 closed the loop by carrying one bounded cognitive directive
 * into the next search and retiring it after use. This layer evaluates whether
 * the carried directive actually improved the next cycle. It is a calibration
 * layer only: it can dampen or reward future routing behavior, but it cannot
 * prove biology, upgrade hypotheses, diagnose, or auto-edit foundation packs.
 */
data class CognitiveLoopCalibrationSignal(
    val name: String,
    val direction: String,
    val score: Int,
    val reason: String
)

data class CognitiveLoopCalibrationReport(
    val active: Boolean,
    val state: String,
    val calibrationScore: Int,
    val directiveId: String?,
    val routingFingerprint: String?,
    val outcome: String,
    val improvedSignals: List<CognitiveLoopCalibrationSignal>,
    val stalledSignals: List<CognitiveLoopCalibrationSignal>,
    val dampenSimilarDirective: Boolean,
    val rewardSimilarDirective: Boolean,
    val nextCalibrationAction: String,
    val visibleBrief: String,
    val claimLimit: String = "cognitive_loop_calibration_not_biological_proof"
) {
    companion object {
        fun empty() = CognitiveLoopCalibrationReport(
            active = false,
            state = "NOT_EVALUATED",
            calibrationScore = 0,
            directiveId = null,
            routingFingerprint = null,
            outcome = "NO_DIRECTIVE_EVALUATED",
            improvedSignals = emptyList(),
            stalledSignals = emptyList(),
            dampenSimilarDirective = false,
            rewardSimilarDirective = false,
            nextCalibrationAction = "Run a cycle with an applied cognitive directive before calibration is possible.",
            visibleBrief = "No cognitive loop calibration yet.",
            claimLimit = "cognitive_loop_calibration_not_biological_proof"
        )
    }
}

object CognitiveLoopCalibrationEngine {
    fun calibrate(
        nextCyclePlan: CognitiveNextCyclePlan,
        datasetForagingReport: DatasetForagingReport,
        knowledgeMapReport: KnowledgeMapReport,
        epistemicBeliefReport: EpistemicBeliefReport,
        specializedReasoningReport: SpecializedReasoningReport,
        learningOsReport: LearningOsReport
    ): CognitiveLoopCalibrationReport {
        val evaluated = nextCyclePlan.active || nextCyclePlan.directiveConsumed || nextCyclePlan.directiveId != null
        if (!evaluated) return CognitiveLoopCalibrationReport.empty()

        val improved = mutableListOf<CognitiveLoopCalibrationSignal>()
        val stalled = mutableListOf<CognitiveLoopCalibrationSignal>()

        fun improve(name: String, score: Int, reason: String) {
            improved += CognitiveLoopCalibrationSignal(name, "IMPROVED", score.coerceIn(0, 100), reason)
        }
        fun stall(name: String, score: Int, reason: String) {
            stalled += CognitiveLoopCalibrationSignal(name, "STALLED", score.coerceIn(0, 100), reason)
        }

        if (nextCyclePlan.appliedQueryCount > 0) {
            improve("DIRECTIVE_APPLIED", 15, "The previous integrated path changed at least one query in this cycle.")
        } else if (nextCyclePlan.directiveConsumed) {
            improve("DIRECTIVE_RETIRED", 8, nextCyclePlan.consumptionReason ?: "The directive was safely consumed or retired.")
        } else {
            stall("DIRECTIVE_NOT_APPLIED", 12, nextCyclePlan.suppressedReason ?: "No next-cycle routing change was applied.")
        }

        if (datasetForagingReport.parsedMetadata.isNotEmpty()) {
            improve("METADATA_PROGRESS", 22, "At least one dataset metadata object was parsed after routing.")
        } else if (datasetForagingReport.candidates.isNotEmpty()) {
            stall("METADATA_STILL_MISSING", 22, "Dataset candidates exist, but no parsed metadata is available yet.")
        }

        if (datasetForagingReport.contrastiveReport.gateStatus != "NOT_EVALUATED") {
            improve("CONTRASTIVE_GATE_ADVANCED", 18, "The contrastive gate moved beyond NOT_EVALUATED.")
        } else if (datasetForagingReport.active) {
            stall("CONTRASTIVE_GATE_STALLED", 18, "The dataset forager ran, but contrastive evaluation did not advance.")
        }

        if (datasetForagingReport.cumulativeEvidence.score > 0) {
            improve("CUMULATIVE_EVIDENCE_MOVED", datasetForagingReport.cumulativeEvidence.score.coerceIn(5, 25), "Cumulative evidence score is now above zero.")
        } else if (datasetForagingReport.active) {
            stall("CUMULATIVE_EVIDENCE_ZERO", 14, "Cumulative evidence remains at zero; the route still needs usable metadata/outcomes.")
        }

        if (knowledgeMapReport.newLinksThisCycle > 0 || knowledgeMapReport.newNodesThisCycle > 0) {
            improve("MAP_EXTENDED", 10, "The cumulative map added nodes or links this cycle.")
        } else if (knowledgeMapReport.active) {
            stall("MAP_NO_DELTA", 8, "The map carried context but did not add new structure.")
        }

        if (epistemicBeliefReport.revisedBeliefs > 0 || epistemicBeliefReport.weakenedBeliefs > 0 || epistemicBeliefReport.retiredBeliefs > 0) {
            improve("BELIEF_UPDATED", 12, "The belief model changed credibility state instead of keeping stale priors.")
        } else if (epistemicBeliefReport.active && epistemicBeliefReport.newBeliefsThisCycle == 0) {
            stall("BELIEF_NO_CHANGE", 7, "The belief model did not add or revise a belief this cycle.")
        }

        if (specializedReasoningReport.evidenceGaps.isNotEmpty() && specializedReasoningReport.decisiveNextTest.isNotBlank()) {
            improve("SPECIALIST_TEST_NAMED", 8, "The specialist protocol named a gap and a decisive next test.")
        } else if (specializedReasoningReport.active) {
            stall("SPECIALIST_TEST_WEAK", 8, "Specialist reasoning ran, but the decisive test/gap was not explicit enough.")
        }

        val rootCauses = learningOsReport.incident.rootCauses
        if (rootCauses.isEmpty()) {
            improve("FAILURE_PRESSURE_LOW", 5, "No active Learning OS root cause was recorded.")
        } else {
            val severe = rootCauses.any { it in listOf("NO_OUTCOME_LABELS", "METADATA_ONLY", "OFF_ROUTE", "NO_TIMECOURSE") }
            stall("FAILURE_PRESSURE_ACTIVE", if (severe) 18 else 10, "Learning OS still reports: ${rootCauses.take(4).joinToString(", ")}.")
        }

        val positive = improved.sumOf { it.score }
        val negative = stalled.sumOf { it.score }
        val score = (50 + positive - negative).coerceIn(0, 100)
        val outcome = when {
            score >= 70 -> "DIRECTIVE_HELPED"
            score >= 50 -> "MIXED_PROGRESS"
            else -> "DIRECTIVE_DID_NOT_HELP_ENOUGH"
        }
        val dampen = outcome == "DIRECTIVE_DID_NOT_HELP_ENOUGH" && stalled.size >= improved.size
        val reward = outcome == "DIRECTIVE_HELPED" && improved.size > stalled.size
        val nextAction = when {
            reward -> "Allow similar bounded directives when they request the same missing evidence type."
            dampen -> "Dampen similar directives; require a different evidence route or stronger metadata requirement before replay."
            else -> "Keep the next directive bounded and require one measurable metadata or contrastive-gate improvement."
        }
        val brief = when (outcome) {
            "DIRECTIVE_HELPED" -> "The previous linked path appears useful: it improved the next search or evidence structure."
            "MIXED_PROGRESS" -> "The previous linked path helped partially, but evidence gaps still remain."
            else -> "The previous linked path did not improve enough; similar routes should be dampened."
        }
        return CognitiveLoopCalibrationReport(
            active = true,
            state = "CALIBRATED",
            calibrationScore = score,
            directiveId = nextCyclePlan.directiveId,
            routingFingerprint = nextCyclePlan.routingFingerprint,
            outcome = outcome,
            improvedSignals = improved.take(8),
            stalledSignals = stalled.take(8),
            dampenSimilarDirective = dampen,
            rewardSimilarDirective = reward,
            nextCalibrationAction = nextAction,
            visibleBrief = brief,
            claimLimit = "cognitive_loop_calibration_not_biological_proof"
        )
    }
}
