package com.immunesignal.app

/**
 * v1.10.23: Accession Mining Intensity.
 *
 * The previous accession-exhaustion gate correctly prevented archive before
 * PUBMED_ACCESSION_MINING, but the PubMed mining lane still used the same thin
 * PubMed budget as contradiction/control. This policy gives accession-mining a
 * deeper, still-bounded retrieval window because accession IDs are often hidden
 * in abstracts or dataset-availability language rather than in titles.
 *
 * It changes retrieval depth only. It does not prove biology, treatment value,
 * causality, dosage, or drug ranking.
 */
object AccessionMiningIntensityPolicy {
    const val CLAIM_LIMIT: String = "accession_mining_intensity_not_biological_proof"

    data class IntensityPlan(
        val sourceFamily: String,
        val retMax: Int,
        val abstractBudget: Int,
        val summary: String,
        val claimLimit: String = CLAIM_LIMIT
    )

    fun planForSourceFamily(sourceFamily: String): IntensityPlan {
        val normalized = sourceFamily.trim().uppercase()
        return when {
            !RuntimeFeatureFlags.ENABLE_ACCESSION_MINING_INTENSITY -> IntensityPlan(
                sourceFamily = sourceFamily,
                retMax = 10,
                abstractBudget = 1,
                summary = "Accession mining intensity disabled; using conservative PubMed defaults."
            )
            normalized.contains("ACCESSION_MINING") -> IntensityPlan(
                sourceFamily = sourceFamily,
                retMax = RuntimeFeatureFlags.PUBMED_ACCESSION_MINING_RETMAX,
                abstractBudget = RuntimeFeatureFlags.PUBMED_ACCESSION_MINING_ABSTRACTS_PER_CYCLE,
                summary = "v1.10.23 accession-mining intensity: deepen PubMed accession mining to ${RuntimeFeatureFlags.PUBMED_ACCESSION_MINING_RETMAX} IDs and ${RuntimeFeatureFlags.PUBMED_ACCESSION_MINING_ABSTRACTS_PER_CYCLE} abstracts before declaring no accession."
            )
            normalized.contains("ADJACENT_DOMAIN") -> IntensityPlan(
                sourceFamily = sourceFamily,
                retMax = RuntimeFeatureFlags.PUBMED_ADJACENT_DOMAIN_RETMAX,
                abstractBudget = RuntimeFeatureFlags.PUBMED_ADJACENT_DOMAIN_ABSTRACTS_PER_CYCLE,
                summary = "v1.10.23 adjacent-domain intensity: allow a modest PubMed window for near-miss domain leads without claim upgrade."
            )
            normalized.contains("CONTRADICTION") || normalized.contains("CONTROL") -> IntensityPlan(
                sourceFamily = sourceFamily,
                retMax = 10,
                abstractBudget = 1,
                summary = "Contradiction/control stays narrow; it cannot consume accession-mining depth."
            )
            else -> IntensityPlan(
                sourceFamily = sourceFamily,
                retMax = 10,
                abstractBudget = 1,
                summary = "Default bounded PubMed retrieval depth."
            )
        }
    }

    fun isDeepAccessionMining(sourceFamily: String): Boolean {
        val plan = planForSourceFamily(sourceFamily)
        return plan.retMax >= RuntimeFeatureFlags.PUBMED_ACCESSION_MINING_RETMAX &&
            plan.abstractBudget >= RuntimeFeatureFlags.PUBMED_ACCESSION_MINING_ABSTRACTS_PER_CYCLE
    }
}
