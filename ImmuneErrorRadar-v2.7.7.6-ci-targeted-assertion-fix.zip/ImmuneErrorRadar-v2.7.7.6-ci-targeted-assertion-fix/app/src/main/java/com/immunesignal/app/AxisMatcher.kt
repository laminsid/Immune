package com.immunesignal.app

import java.util.Locale

/**
 * Canonical axis matcher (v1.1).
 *
 * v0.9.0 had two near-duplicate dictionaries: `matchAxes` in ResearchAutopilot
 * and `inferAxes` in ResearchKnowledgeStore. Same input could produce
 * different axis sets depending on which engine called it. Drift this subtle
 * is exactly the kind of bug that survives years.
 *
 * v1.1 collapses both into this single object. Both legacy methods now
 * delegate here. Adding a new axis or keyword requires editing exactly ONE
 * place.
 *
 * Rule: keep the superset (the previously-richer `matchAxes` dictionary).
 * Removing keywords from this list is a behaviour change — bump the version
 * suffix and add a regression test before doing so.
 */
object AxisMatcher {
    // version tag exposed for diagnostic logs / JSON output
    const val VERSION = "v1.10.2-word-boundary"

    private data class AxisRule(val axis: String, val keywords: List<String>)
    private data class CompiledAxisRule(val axis: String, val keywordPattern: Regex)

    // Order is preserved in the output (some downstream code prefers a
    // deterministic ordering). New axes append to the end.
    private val rules: List<AxisRule> = listOf(
        AxisRule("type2_allergy_axis", listOf(
            "ige", "allerg", "asthma", "eosinophil", "mast cell", "mast",
            "histamine", "type-2", "type 2"
        )),
        AxisRule("tnf_il6_autoimmune_axis", listOf(
            "tnf", "il-6", "il6", "rheumatoid", "autoimmune", "arthritis"
        )),
        AxisRule("hyperinflammatory_axis", listOf(
            "cytokine storm", "hyperinflammation", "ards", "sepsis", "ferritin"
        )),
        AxisRule("regulatory_brake_axis", listOf(
            "il-10", "il10", "regulatory", "treg", "immune regulation"
        )),
        AxisRule("psychoneuroimmune_axis", listOf(
            "stress", "sleep", "depression", "anxiety", "psychoneuro", "panic"
        )),
        AxisRule("psychomusculoskeletal_axis", listOf(
            "back pain", "disc", "muscle", "sensitization",
            "fear avoidance", "mechanical"
        )),
        AxisRule("aging_immune_axis", listOf(
            "aging", "immunosenescence", "inflammaging", "longevity",
            "senescence", "frailty"
        )),
        AxisRule("autonomic_vascular_axis", listOf(
            "blood pressure", "hypotension", "vasodilation", "autonomic",
            "dizziness", "heart rate", "vascular"
        )),
        AxisRule("dna_genomic_axis", listOf(
            "dna", "genome", "genomic", "genetic", "epigenetic",
            "methylation", "snp", "variant", "chromatin"
        )),
        AxisRule("rna_transcriptomic_axis", listOf(
            "rna", "rna-seq", "transcript", "transcriptomic", "mrna", "mirna",
            "single-cell", "single cell", "scrna", "gene expression"
        )),
        AxisRule("gastric_acid_gut_axis", listOf(
            "stomach acid", "gastric acid", "hypochlorhydria", "achlorhydria",
            "reflux", "gerd", "ppi", "proton pump", "h pylori", "gastritis"
        )),
        AxisRule("gut_barrier_microbiome_axis", listOf(
            "microbiome", "gut barrier", "intestinal permeability", "dysbiosis",
            "gut-lung", "gut immune"
        )),
        AxisRule("nutrition_protein_axis", listOf(
            "nutrition", "protein intake", "diet diversity", "malnutrition",
            "appetite", "amino acid"
        )),
        AxisRule("muscle_mass_reserve_axis", listOf(
            "muscle mass", "sarcopenia", "lean mass", "strength training",
            "resistance exercise", "myokine"
        )),
        AxisRule("testosterone_immune_axis", listOf(
            "testosterone", "androgen", "hypogonadism", "sex hormone",
            "male hormone"
        )),
        AxisRule("interferon_antiviral_axis", listOf(
            "interferon", "ifn", "antiviral", "viral response", "virus", "viral",
            "influenza", "sars-cov-2", "covid", "rsv", "hantavirus", "viral load"
        )),
        AxisRule("tcell_activation_axis", listOf(
            "t cell", "t-cell", "cd4", "cd8", "cytotoxic", "th1", "th17", "t lymphocyte"
        )),
        AxisRule("bcell_antibody_axis", listOf(
            "b cell", "b-cell", "antibody", "antibodies", "neutralizing antibody",
            "plasma cell", "serology", "humoral"
        )),
        AxisRule("tissue_damage_axis", listOf(
            "tissue damage", "organ damage", "lung damage", "epithelial damage",
            "endothelial", "fibrosis", "injury", "necrosis"
        )),
        AxisRule("resolution_recovery_axis", listOf(
            "resolution", "recovery", "convalescent", "repair", "remission",
            "immune resolution", "return to baseline"
        ))
    )

    private val compiledRules: List<CompiledAxisRule> = rules.map { rule ->
        val alternatives = rule.keywords
            .map { Regex.escape(it.lowercase(Locale.US)) }
            .sortedByDescending { it.length }
            .joinToString("|")
        CompiledAxisRule(
            axis = rule.axis,
            keywordPattern = Regex("(?<![A-Za-z0-9])(?:$alternatives)(?![A-Za-z0-9])", RegexOption.IGNORE_CASE)
        )
    }

    fun match(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val normalized = text.lowercase(Locale.US)
        val out = mutableListOf<String>()
        for (rule in compiledRules) {
            if (rule.keywordPattern.containsMatchIn(normalized)) out += rule.axis
        }
        return out.distinct()
    }

    /** All axis names the matcher knows about, in declared order. */
    fun knownAxes(): List<String> = rules.map { it.axis }
}

