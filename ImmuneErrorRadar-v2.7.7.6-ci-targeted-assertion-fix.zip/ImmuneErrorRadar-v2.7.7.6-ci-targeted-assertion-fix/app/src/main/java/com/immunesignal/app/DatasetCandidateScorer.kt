package com.immunesignal.app

object DatasetCandidateScorer {
    data class Score(val score: Int, val reasons: List<String>)

    fun score(
        accession: String,
        organismHint: String,
        conditionLabelsHint: String,
        outcomeLabelsHint: String,
        triggerResponseOutcomeHint: String,
        timeCourseHint: String,
        sampleSizeHint: String,
        dataType: String
    ): Score {
        var score = 0
        val reasons = mutableListOf<String>()
        if (accession != "DATASET_ACCESSION_UNRESOLVED") { score += 20; reasons += "Explicit accession detected." } else reasons += "Dataset mentioned but accession unresolved."
        if (organismHint.startsWith("human")) { score += 18; reasons += "Human/patient/cohort language detected." }
        if (conditionLabelsHint != "unknown") { score += 14; reasons += "Condition label hint detected." }
        if (outcomeLabelsHint != "unknown") { score += 18; reasons += "Outcome/response label hint detected." }
        if (triggerResponseOutcomeHint != "not established") { score += 12; reasons += "Trigger-response-outcome structure hinted." }
        if (timeCourseHint != "unknown") { score += 10; reasons += "Longitudinal/time-course hint detected." }
        if (sampleSizeHint != "unknown") { score += 5; reasons += "Sample-size hint detected." }
        if (dataType != "unknown") { score += 10; reasons += "Reusable data type detected: $dataType." }
        return Score(score.coerceIn(0, 100), reasons)
    }
}
