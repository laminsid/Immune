package com.immunesignal.app

import android.content.Context
import org.json.JSONObject

/**
 * FoundationKnowledgeLayer: The biological prior knowledge system
 * 
 * Responsibilities:
 * 1. Loads biological foundation knowledge (axes, rules, constraints)
 * 2. Identifies applicable axes for a research query
 * 3. Maps evidence to axis requirements
 * 4. Flags conflicts between data and foundation
 * 5. Prevents biological nonsense (forbidden conflations)
 * 6. Does NOT prove biology - only guides search
 */

// ============ ENUMS ============

enum class ConfidenceLevel {
    HIGH, MEDIUM, LOW, CAUTION
}

enum class ConflictState {
    NO_CONFLICT,
    PARTIAL_EVIDENCE_MISSING,
    DATA_CHALLENGES_FOUNDATION,
    OFF_ROUTE,
    UNKNOWN_AXIS
}

enum class FoundationAction {
    PROCEED,                        // All critical evidence present
    PROCEED_WITH_CAUTION,          // Missing non-critical evidence, has compensation
    REQUIRE_MORE_EVIDENCE,         // Partial match, needs more data
    DOWNGRADE_TO_ANALOGY,          // Too weak for hypothesis, maybe mechanism support
    BLOCK_HYPOTHESIS_UPGRADE,      // Do not let this become evidence
    SUGGEST_FOUNDATION_PATCH       // This conflicts enough to warrant knowledge update
}

// ============ DATA CLASSES ============

data class FoundationAxis(
    val id: String,
    val coreMeaning: String,
    val requiredEvidence: List<String>,
    val criticalEvidence: List<String>,
    val forbiddenConflations: List<String>,
    val queryHints: List<String>,
    val causalWarnings: List<String>,
    val datasetType: String,  // "human", "mouse", "cell_culture", "transcriptomic", etc.
    val specificity: Float = 0.5f  // 0.0-1.0: how specific is this axis
)

data class RankedAxis(
    val axisId: String,
    val matchScore: Float,                    // Raw keyword match 0.0-1.0
    val specificityScore: Float,              // How specific is the match
    val evidenceCompletenessScore: Float,     // % of required evidence present
    val priorSuccessScore: Float,             // Historical accuracy of this axis
    val riskPenalty: Float,                   // Previous false blocks/errors
    val finalScore: Float,                    // Computed final ranking
    val reason: String,
    val criticalEvidenceMissing: List<String>,
    val presentEvidence: List<String>
)

data class CompensatingEvidence(
    val name: String,
    val compensationStrength: Float,  // 0.0-1.0: how much does this compensate?
    val relevance: String
)

data class FoundationKnowledgeResult(
    val primaryAxis: String?,
    val rankedAxes: List<RankedAxis>,
    val matchScore: Float,
    val confidenceLevel: ConfidenceLevel,
    val requiredEvidence: List<String>,
    val presentEvidence: List<String>,
    val missingEvidence: List<String>,
    val compensatingEvidence: List<CompensatingEvidence>,
    val forbiddenConflations: List<String>,
    val causalWarnings: List<String>,
    val conflictState: ConflictState,
    val recommendedAction: FoundationAction,
    val claimLimit: String = "foundation_knowledge_not_evidence",
    val timestamp: Long = System.currentTimeMillis()
)

// ============ MAIN LAYER ============

class FoundationKnowledgeLayer(private val context: Context) {

    private val axes = mutableMapOf<String, FoundationAxis>()
    private val forbiddenConflationRules = mutableListOf<String>()
    private val datasetTypePreferences = mutableMapOf<String, List<String>>()

    init {
        loadFoundationKnowledge()
    }

    /**
     * Load all foundation knowledge from JSON files
     */
    private fun loadFoundationKnowledge() {
        // v2.6.3: load packs independently so one optional seed asset cannot
        // collapse the whole foundation layer into the minimal fallback.
        var loadedAny = false

        fun loadAxesPack(filename: String, parser: (JSONObject) -> Unit = { parseAxes(it) }) {
            runCatching {
                parser(loadJsonAsset(filename))
                loadedAny = true
            }
        }

        loadAxesPack("biology_foundation_pack.json")
        loadAxesPack("immune_disease_seed_v1.0.json")
        loadAxesPack("immunology_axis_rules.json") { parseAxisRules(it) }
        loadAxesPack("psychoneuroimmune_context_pack.json")
        runCatching { parseConflictRules(loadJsonAsset("foundation_conflict_rules.json")) }
        runCatching { parseConflictRules(loadJsonAsset("disease_axis_bridge_rules_v1.0.json")) }

        if (!loadedAny) {
            // Fallback: create basic axes if files not found
            createMinimalFoundation()
        }
    }

    /**
     * Analyze a research query/dataset against foundation knowledge
     * 
     * @param queryText: User's research query or dataset description
     * @param presentEvidence: Keywords/metadata found in the dataset
     * @param datasetType: "human", "mouse", "cell", "transcriptomic", etc.
     * 
     * @return FoundationKnowledgeResult with full analysis
     */
    fun analyze(
        queryText: String,
        presentEvidence: List<String>,
        datasetType: String = "unknown"
    ): FoundationKnowledgeResult {

        // 1. Find all matching axes
        val rankedAxes = rankAxesAgainst(queryText, presentEvidence, datasetType)

        if (rankedAxes.isEmpty()) {
            return createUnknownAxisResult(presentEvidence)
        }

        // 2. Determine primary axis (highest score)
        val primaryAxis = rankedAxes.first()

        // 3. Get axis definition
        val axisDef = axes[primaryAxis.axisId]
            ?: return createUnknownAxisResult(presentEvidence)

        // 4. Analyze evidence completeness
        val missingEvidence = axisDef.requiredEvidence.filter { it !in presentEvidence }
        val compensating = findCompensatingEvidence(presentEvidence, axisDef)

        // 5. Check for forbidden conflations
        val detectedConflations = checkForbiddenConflations(presentEvidence, axisDef)

        // 6. Determine conflict state
        val conflictState = determineConflictState(axisDef, missingEvidence, compensating)

        // 7. Determine recommended action
        val action = determineAction(axisDef, primaryAxis, missingEvidence, compensating)

        // 8. Determine confidence level
        val confidence = determineConfidence(primaryAxis, action)

        return FoundationKnowledgeResult(
            primaryAxis = primaryAxis.axisId,
            rankedAxes = rankedAxes,
            matchScore = primaryAxis.matchScore,
            confidenceLevel = confidence,
            requiredEvidence = axisDef.requiredEvidence,
            presentEvidence = presentEvidence,
            missingEvidence = missingEvidence,
            compensatingEvidence = compensating,
            forbiddenConflations = detectedConflations,
            causalWarnings = axisDef.causalWarnings,
            conflictState = conflictState,
            recommendedAction = action,
            claimLimit = "foundation_knowledge_not_evidence"
        )
    }

    /**
     * Rank all axes against the given evidence
     * Formula: 0.35*matchScore + 0.25*specificity + 0.25*completeness + 0.10*priorSuccess - 0.15*penalty
     */
    private fun rankAxesAgainst(
        queryText: String,
        presentEvidence: List<String>,
        datasetType: String
    ): List<RankedAxis> {

        val results = mutableListOf<RankedAxis>()

        for ((axisId, axis) in axes) {
            // Dataset-type mismatch is a penalty, not a hard skip. Mouse/cell studies can
            // still support mechanism plausibility, but they must not drive human confidence.
            val datasetTypePenalty = if (datasetType != "unknown" &&
                axis.datasetType != "unknown" &&
                datasetType != axis.datasetType &&
                !datasetType.contains(axis.datasetType, ignoreCase = true) &&
                !axis.datasetType.contains(datasetType, ignoreCase = true)
            ) 0.20f else 0.0f

            // Calculate match score (keyword overlap)
            val matchScore = calculateMatchScore(queryText, axis.queryHints)

            // Specificity from axis definition
            val specificityScore = axis.specificity

            // Evidence completeness
            val evidenceCompleteness = calculateEvidenceCompleteness(
                presentEvidence, 
                axis.requiredEvidence,
                axis.criticalEvidence
            )

            // Prior success (will be fetched from AccuracyLedger later)
            val priorSuccess = 0.5f  // Default: neutral

            // Risk penalty (will be fetched from AccuracyLedger later)
            val penalty = datasetTypePenalty

            // Final score formula
            val finalScore = 
                0.35f * matchScore +
                0.25f * specificityScore +
                0.25f * evidenceCompleteness +
                0.10f * priorSuccess -
                0.15f * penalty

            if (finalScore > 0.15f) {  // Only include axes with meaningful match
                val criticalMissing = axis.criticalEvidence.filter { it !in presentEvidence }
                val present = presentEvidence.filter { it in axis.requiredEvidence }

                results.add(RankedAxis(
                    axisId = axisId,
                    matchScore = matchScore,
                    specificityScore = specificityScore,
                    evidenceCompletenessScore = evidenceCompleteness,
                    priorSuccessScore = priorSuccess,
                    riskPenalty = penalty,
                    finalScore = finalScore,
                    reason = "Query/evidence match to $axisId",
                    criticalEvidenceMissing = criticalMissing,
                    presentEvidence = present
                ))
            }
        }

        // Sort by final score descending
        return results.sortedByDescending { it.finalScore }
    }

    /**
     * Calculate how well query keywords match axis hints (0.0-1.0)
     */
    private fun calculateMatchScore(queryText: String, hints: List<String>): Float {
        if (hints.isEmpty()) return 0f
        
        val lowerQuery = queryText.lowercase()
        val matches = hints.count { hint ->
            lowerQuery.contains(hint.lowercase())
        }
        
        return (matches.toFloat() / hints.size).coerceIn(0f, 1f)
    }

    /**
     * Calculate how complete the evidence is (0.0-1.0)
     */
    private fun calculateEvidenceCompleteness(
        present: List<String>,
        required: List<String>,
        critical: List<String>
    ): Float {
        if (required.isEmpty()) return 1f
        
        // Critical evidence is weighted higher
        val criticalPresent = critical.count { it in present }
        val criticalScore = if (critical.isNotEmpty()) {
            (criticalPresent.toFloat() / critical.size) * 0.6f
        } else {
            0f
        }

        val nonCritical = required.filter { it !in critical }
        val nonCriticalPresent = nonCritical.count { it in present }
        val nonCriticalScore = if (nonCritical.isNotEmpty()) {
            (nonCriticalPresent.toFloat() / nonCritical.size) * 0.4f
        } else {
            0.4f
        }

        return (criticalScore + nonCriticalScore).coerceIn(0f, 1f)
    }

    /**
     * Find evidence that compensates for missing required evidence
     */
    private fun findCompensatingEvidence(
        presentEvidence: List<String>,
        axis: FoundationAxis
    ): List<CompensatingEvidence> {
        val compensating = mutableListOf<CompensatingEvidence>()

        // Human data compensates for lack of specific markers
        if ("human" in presentEvidence && "human_or_relevant_model" in axis.requiredEvidence) {
            compensating.add(CompensatingEvidence(
                name = "human",
                compensationStrength = 0.7f,
                relevance = "Human data compensates for model organism specificity"
            ))
        }

        // Time-course compensates for some marker gaps
        if ("time_course" in presentEvidence || "longitudinal" in presentEvidence) {
            compensating.add(CompensatingEvidence(
                name = "time_course",
                compensationStrength = 0.6f,
                relevance = "Temporal data helps understand mechanism even with incomplete markers"
            ))
        }

        // Outcome labels are strong compensators
        if ("outcome" in presentEvidence || "severity" in presentEvidence) {
            compensating.add(CompensatingEvidence(
                name = "outcome_labels",
                compensationStrength = 0.8f,
                relevance = "Clinical outcome provides context for biological relevance"
            ))
        }

        return compensating
    }

    /**
     * Check if data contains forbidden conflations
     */
    private fun checkForbiddenConflations(
        presentEvidence: List<String>,
        axis: FoundationAxis
    ): List<String> {
        val detected = mutableListOf<String>()

        for (conflation in axis.forbiddenConflations) {
            // Simple keyword matching for now
            if (presentEvidence.any { it.lowercase().contains(conflation.lowercase()) }) {
                detected.add(conflation)
            }
        }

        return detected
    }

    /**
     * Determine the current state of conflict
     */
    private fun determineConflictState(
        axis: FoundationAxis,
        missingEvidence: List<String>,
        compensating: List<CompensatingEvidence>
    ): ConflictState {
        return when {
            missingEvidence.isEmpty() -> ConflictState.NO_CONFLICT
            compensating.isNotEmpty() && missingEvidence.size <= 2 -> ConflictState.PARTIAL_EVIDENCE_MISSING
            missingEvidence.size > axis.requiredEvidence.size * 0.5f -> ConflictState.OFF_ROUTE
            else -> ConflictState.PARTIAL_EVIDENCE_MISSING
        }
    }

    /**
     * Determine recommended action based on evidence analysis
     */
    private fun determineAction(
        axis: FoundationAxis,
        ranked: RankedAxis,
        missingEvidence: List<String>,
        compensating: List<CompensatingEvidence>
    ): FoundationAction {
        // Check critical evidence
        val criticalMissing = axis.criticalEvidence.filter { it !in ranked.presentEvidence }
        
        return when {
            missingEvidence.isEmpty() && ranked.matchScore > 0.75f ->
                FoundationAction.PROCEED

            missingEvidence.size <= 1 && compensating.isNotEmpty() ->
                FoundationAction.PROCEED_WITH_CAUTION

            missingEvidence.size <= 2 && compensating.isNotEmpty() ->
                FoundationAction.PROCEED_WITH_CAUTION

            criticalMissing.isNotEmpty() && missingEvidence.size > axis.requiredEvidence.size * 0.4f ->
                FoundationAction.REQUIRE_MORE_EVIDENCE

            ranked.matchScore < 0.35f ->
                FoundationAction.DOWNGRADE_TO_ANALOGY

            ranked.matchScore < 0.20f ->
                FoundationAction.BLOCK_HYPOTHESIS_UPGRADE

            else ->
                FoundationAction.REQUIRE_MORE_EVIDENCE
        }
    }

    /**
     * Determine confidence level
     */
    private fun determineConfidence(
        ranked: RankedAxis,
        action: FoundationAction
    ): ConfidenceLevel {
        return when {
            ranked.finalScore > 0.80f && action == FoundationAction.PROCEED ->
                ConfidenceLevel.HIGH
            ranked.finalScore > 0.60f && action == FoundationAction.PROCEED_WITH_CAUTION ->
                ConfidenceLevel.MEDIUM
            ranked.finalScore > 0.40f ->
                ConfidenceLevel.LOW
            else ->
                ConfidenceLevel.CAUTION
        }
    }

    /**
     * Load JSON from assets
     */
    private fun loadJsonAsset(filename: String): JSONObject {
        val jsonText = context.assets.open(filename).bufferedReader(Charsets.UTF_8).use { it.readText() }
        return JSONObject(jsonText)
    }

    /**
     * Parse axes from biology_foundation_pack.json
     */
    private fun parseAxes(pack: JSONObject) {
        val axesArray = pack.optJSONArray("axes") ?: return

        for (i in 0 until axesArray.length()) {
            val axisObj = axesArray.getJSONObject(i)

            val requiredList = mutableListOf<String>()
            axisObj.optJSONArray("requiredEvidence")?.let {
                for (j in 0 until it.length()) {
                    requiredList.add(it.getString(j))
                }
            }

            val criticalList = mutableListOf<String>()
            axisObj.optJSONArray("criticalEvidence")?.let {
                for (j in 0 until it.length()) {
                    criticalList.add(it.getString(j))
                }
            } ?: run {
                // If not explicitly marked, first 2-3 are critical
                criticalList.addAll(requiredList.take(2))
            }

            val forbiddenList = mutableListOf<String>()
            axisObj.optJSONArray("forbiddenConflations")?.let {
                for (j in 0 until it.length()) {
                    forbiddenList.add(it.getString(j))
                }
            }

            val hintsList = mutableListOf<String>()
            axisObj.optJSONArray("queryHints")?.let {
                for (j in 0 until it.length()) {
                    hintsList.add(it.getString(j))
                }
            }

            val warningsList = mutableListOf<String>()
            axisObj.optJSONArray("causalWarnings")?.let {
                for (j in 0 until it.length()) {
                    warningsList.add(it.getString(j))
                }
            }

            axes[axisObj.getString("id")] = FoundationAxis(
                id = axisObj.getString("id"),
                coreMeaning = axisObj.getString("coreMeaning"),
                requiredEvidence = requiredList,
                criticalEvidence = criticalList,
                forbiddenConflations = forbiddenList,
                queryHints = hintsList,
                causalWarnings = warningsList,
                datasetType = axisObj.optString("datasetType", "human"),
                specificity = axisObj.optDouble("specificity", 0.5).toFloat()
            )
        }
    }

    /**
     * Parse additional axis rules
     */
    private fun parseAxisRules(rules: JSONObject) {
        // Additional axis definitions or overrides
        parseAxes(rules)
    }

    /**
     * Parse conflict rules
     */
    private fun parseConflictRules(rules: JSONObject) {
        val conflationsArray = rules.optJSONArray("forbiddenConflations") ?: return
        for (i in 0 until conflationsArray.length()) {
            forbiddenConflationRules.add(conflationsArray.getString(i))
        }
    }

    /**
     * Create minimal foundation if JSON loading fails
     * (Fallback for development/testing)
     */
    private fun createMinimalFoundation() {
        axes["interferon_antiviral_timing"] = FoundationAxis(
            id = "interferon_antiviral_timing",
            coreMeaning = "Early interferon supports antiviral control; excessive IFN may worsen inflammation",
            requiredEvidence = listOf("viral_load", "time_course", "interferon_markers", "outcome"),
            criticalEvidence = listOf("viral_load", "time_course"),
            forbiddenConflations = listOf("generic_inflammation_as_antiviral"),
            queryHints = listOf("viral", "interferon", "antiviral", "IFN", "ISG"),
            causalWarnings = listOf("Correlation does not imply causation"),
            datasetType = "human",
            specificity = 0.85f
        )

        axes["generic_inflammation"] = FoundationAxis(
            id = "generic_inflammation",
            coreMeaning = "Inflammation markers alone do not specify mechanism",
            requiredEvidence = listOf("cytokines", "trigger", "outcome"),
            criticalEvidence = listOf("trigger", "outcome"),
            forbiddenConflations = listOf("inflammation_means_cause"),
            queryHints = listOf("inflammation", "cytokine", "IL-6", "TNF"),
            causalWarnings = listOf("Generic markers need context"),
            datasetType = "human",
            specificity = 0.4f
        )
    }

    /**
     * Create result for unknown/unmatched query
     */
    private fun createUnknownAxisResult(presentEvidence: List<String>): FoundationKnowledgeResult {
        return FoundationKnowledgeResult(
            primaryAxis = null,
            rankedAxes = emptyList(),
            matchScore = 0f,
            confidenceLevel = ConfidenceLevel.CAUTION,
            requiredEvidence = emptyList(),
            presentEvidence = presentEvidence,
            missingEvidence = emptyList(),
            compensatingEvidence = emptyList(),
            forbiddenConflations = emptyList(),
            causalWarnings = listOf("Cannot determine applicable biological axis"),
            conflictState = ConflictState.UNKNOWN_AXIS,
            recommendedAction = FoundationAction.REQUIRE_MORE_EVIDENCE,
            claimLimit = "foundation_knowledge_not_evidence"
        )
    }
}
