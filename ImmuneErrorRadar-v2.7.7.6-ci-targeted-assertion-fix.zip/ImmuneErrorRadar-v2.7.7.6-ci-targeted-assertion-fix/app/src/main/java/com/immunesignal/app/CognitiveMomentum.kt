package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v1.9.9 Cognitive Momentum Auditor.
 *
 * This layer measures whether the post-search thinking system is actually
 * moving. It is deliberately conservative: it does not prove biology and it
 * does not create broad searches. It converts repeated gaps, graph stalling,
 * and accession-closure progress into one operational decision for the next
 * cycle.
 */
data class CognitiveMomentumReport(
    val active: Boolean,
    val state: String,
    val momentumScore: Int,
    val progressScore: Int,
    val repetitionPenalty: Int,
    val closedEvidenceKeys: List<String>,
    val stalledEvidenceKeys: List<String>,
    val graphDelta: String,
    val decisionLock: String,
    val nextAction: String,
    val searchDecision: String,
    val summary: String,
    val claimLimit: String = "cognitive_momentum_not_biological_proof"
) {
    companion object {
        fun empty() = CognitiveMomentumReport(
            active = false,
            state = "NO_MOMENTUM",
            momentumScore = 0,
            progressScore = 0,
            repetitionPenalty = 0,
            closedEvidenceKeys = emptyList(),
            stalledEvidenceKeys = emptyList(),
            graphDelta = "No prior graph or evidence closure available.",
            decisionLock = "Run or load a research cycle before measuring momentum.",
            nextAction = "No action available.",
            searchDecision = "Search is not justified without a saved evidence gap.",
            summary = "No cognitive momentum report available."
        )
    }
}

object CognitiveMomentumEngine {
    data class PriorSearchDirective(
        val active: Boolean,
        val mode: String,
        val queries: List<ResearchQuery>,
        val reason: String
    ) {
        companion object {
            fun none() = PriorSearchDirective(false, "NO_PRIOR_MOMENTUM_LOCK", emptyList(), "No prior momentum lock.")
        }
    }

    fun build(
        recentReportJsonLines: List<String>,
        evidenceClosure: EvidenceClosureReport,
        thinkingContinuity: ThinkingContinuityReport,
        hypothesisGraph: HypothesisGraphReport,
        learningOs: LearningOsReport,
        datasetForaging: DatasetForagingReport,
        executedQueries: List<ResearchQuery>
    ): CognitiveMomentumReport {
        if (!evidenceClosure.active && !thinkingContinuity.active && !hypothesisGraph.active) {
            return CognitiveMomentumReport.empty()
        }
        val priorReports = recentReportJsonLines.mapNotNull { line -> runCatching { JSONObject(line) }.getOrNull() }
        val currentGaps = (evidenceClosure.cards.flatMap { it.missingFields } + thinkingContinuity.repeatedGaps)
            .map { normalizeKey(it) }
            .filter { it.isNotBlank() }
            .distinct()
        val previousGaps = priorReports.firstOrNull()
            ?.let { latest -> extractGaps(latest) }
            ?: emptyList()
        val currentClosed = evidenceClosure.cards.flatMap { card ->
            listOfNotNull(
                "minimum_metadata".takeIf { card.sampleSize != "unknown" || card.organism != "unknown" || card.assayType != "unknown" },
                "control_or_comparator".takeIf { card.controlLabels.isNotEmpty() },
                "outcome_labels".takeIf { card.outcomeLabels.isNotEmpty() },
                "time_order".takeIf { card.timeCourseLabels.isNotEmpty() },
                "license_access".takeIf { card.licenseAccess != "unknown" }
            )
        }.distinct()
        val stillStalled = (currentGaps + learningOs.incident.rootCauses.map { normalizeKey(it) })
            .filter { it.isNotBlank() }
            .distinct()
            .filter { key -> currentClosed.none { closed -> keysOverlap(key, closed) } }
            .take(8)
        val newlyClosed = currentClosed.filter { closed -> previousGaps.any { key -> keysOverlap(key, closed) } || previousGaps.isEmpty() }.take(8)
        val queryDisciplineBonus = when {
            executedQueries.isEmpty() -> 8
            executedQueries.size == 1 && executedQueries.first().id.contains("closure", ignoreCase = true) -> 18
            executedQueries.size <= 2 && executedQueries.any { it.id.contains("v199", ignoreCase = true) || it.id.contains("closure", ignoreCase = true) } -> 14
            executedQueries.size <= 2 -> 8
            else -> 0
        }
        val graphProgress = when {
            hypothesisGraph.nodes.isNotEmpty() && hypothesisGraph.edges.isNotEmpty() -> 12
            hypothesisGraph.active -> 6
            else -> 0
        }
        val closureProgress = minOf(45, newlyClosed.size * 10 + evidenceClosure.cards.count { !it.blocksBroadSearch } * 8)
        val repetitionPenalty = minOf(55, stillStalled.size * 7 + if (hypothesisGraph.searchDecision.startsWith("NO_BROAD_SEARCH", true)) 12 else 0)
        val progressScore = (closureProgress + graphProgress + queryDisciplineBonus).coerceIn(0, 100)
        val momentumScore = (progressScore - repetitionPenalty + 50).coerceIn(0, 100)
        val weakest = firstNonBlank(stillStalled.firstOrNull().orEmpty(), hypothesisGraph.weakestLink, "one decisive evidence key")
        val graphDelta = when {
            newlyClosed.isNotEmpty() -> "Evidence closure moved: ${newlyClosed.take(4).joinToString(", ")}."
            previousGaps.isNotEmpty() && stillStalled.isNotEmpty() -> "Same blocker remains from prior run: ${stillStalled.take(3).joinToString(", ")}."
            hypothesisGraph.active -> "Graph exists but has not earned a strong evidence upgrade."
            else -> "No graph delta."
        }
        val state = when {
            momentumScore >= 70 && newlyClosed.isNotEmpty() -> "MOMENTUM_ADVANCING"
            stillStalled.size >= 3 || momentumScore < 45 -> "MOMENTUM_STALLED_CLOSE_OR_ARCHIVE"
            evidenceClosure.broadSearchBlocked || hypothesisGraph.searchDecision.startsWith("NO_BROAD_SEARCH", true) -> "MOMENTUM_LOCKED_TO_CLOSURE"
            else -> "MOMENTUM_THINK_FIRST"
        }
        val decisionLock = when (state) {
            "MOMENTUM_ADVANCING" -> "Continue only with bounded evidence-closure or replication; no broad mechanism expansion."
            "MOMENTUM_STALLED_CLOSE_OR_ARCHIVE" -> "Do not run another broad search. Close $weakest or archive/cool down the route."
            "MOMENTUM_LOCKED_TO_CLOSURE" -> "Keep accession/gap closure as the only permitted network action."
            else -> "Think offline until one falsifiable evidence key is selected."
        }
        val nextAction = when {
            evidenceClosure.cards.isNotEmpty() -> evidenceClosure.cards.first().nextAction
            hypothesisGraph.nextReasoningMove.isNotBlank() -> hypothesisGraph.nextReasoningMove
            thinkingContinuity.nextLocalQuestion.isNotBlank() -> thinkingContinuity.nextLocalQuestion
            else -> "Select one discriminator before searching."
        }.take(260)
        val searchDecision = when (state) {
            "MOMENTUM_ADVANCING" -> "NARROW_SEARCH_ALLOWED: must verify or replicate the newly closed key; no broad expansion."
            "MOMENTUM_STALLED_CLOSE_OR_ARCHIVE" -> "NO_BROAD_SEARCH: close $weakest or archive/cool down."
            "MOMENTUM_LOCKED_TO_CLOSURE" -> "NO_BROAD_SEARCH: accession/gap closure only."
            else -> "THINK_FIRST: no network cycle until the graph has one explicit discriminator."
        }
        return CognitiveMomentumReport(
            active = true,
            state = state,
            momentumScore = momentumScore,
            progressScore = progressScore,
            repetitionPenalty = repetitionPenalty,
            closedEvidenceKeys = newlyClosed,
            stalledEvidenceKeys = stillStalled,
            graphDelta = graphDelta.take(260),
            decisionLock = decisionLock.take(260),
            nextAction = nextAction,
            searchDecision = searchDecision.take(260),
            summary = "Cognitive momentum: $state; momentum=$momentumScore/100; progress=$progressScore/100; penalty=$repetitionPenalty/100; weakest=$weakest."
        )
    }

    fun priorSearchDirective(recentReportJsonLines: List<String>): PriorSearchDirective {
        val latest = recentReportJsonLines.asSequence()
            .mapNotNull { line -> runCatching { JSONObject(line) }.getOrNull() }
            .firstOrNull() ?: return PriorSearchDirective.none()
        val momentum = latest.optJSONObject("cognitiveMomentumReport") ?: JSONObject()
        val graph = latest.optJSONObject("hypothesisGraphReport") ?: JSONObject()
        val closure = latest.optJSONObject("evidenceClosureReport") ?: JSONObject()
        val momentumDecision = momentum.optString("searchDecision")
        val graphDecision = graph.optString("searchDecision")
        val mustConstrain = momentumDecision.startsWith("NO_BROAD_SEARCH", true) ||
            momentumDecision.startsWith("THINK_FIRST", true) ||
            graphDecision.startsWith("NO_BROAD_SEARCH", true) ||
            graphDecision.startsWith("THINK_FIRST", true)
        if (!mustConstrain) return PriorSearchDirective.none()
        val card = closure.optJSONArray("cards")?.optJSONObject(0) ?: JSONObject()
        val accession = card.optString("accession").takeIf { it.isNotBlank() && it != "none" }
        val weakest = firstNonBlank(
            momentum.optJSONArray("stalledEvidenceKeys")?.optString(0).orEmpty(),
            graph.optString("weakestLink"),
            "outcome_labels"
        )
        val dominant = firstNonBlank(
            graph.optString("dominantHypothesis"),
            (latest.optJSONObject("thinkingContinuityReport") ?: JSONObject()).optString("mergedHypothesisLine"),
            "immune transcriptomic route"
        )
        val queryText = if (accession != null) {
            val condition = arrayToList(card.optJSONArray("conditionLabels")).take(3).joinToString(" ").ifBlank { "immune transcriptomic dataset" }
            "$accession $condition $weakest outcome recovery severity endpoint longitudinal time-course control comparator placebo negative control metadata sample size license"
        } else {
            "$dominant $weakest outcome recovery severity endpoint longitudinal time-course control comparator negative control metadata sample size"
        }
        val safeId = (accession ?: weakest).lowercase().replace(Regex("[^a-z0-9_]+"), "_").take(36).ifBlank { "gap" }
        val query = ResearchQuery(
            id = "q_v199_momentum_lock_$safeId",
            label = "v1.9.9 momentum lock: ${accession ?: weakest}",
            query = queryText.take(520),
            reason = "Prior cognitive momentum/graph report blocked broad search. Execute one narrow evidence-closure query or keep thinking offline."
        )
        return PriorSearchDirective(
            active = true,
            mode = if (accession != null) "ACCESSION_CLOSURE_ONLY" else "GRAPH_GAP_CLOSURE_ONLY",
            queries = listOf(query),
            reason = firstNonBlank(momentumDecision, graphDecision, "prior graph requires constrained search")
        )
    }

    fun toJson(report: CognitiveMomentumReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("state", report.state)
        .put("momentumScore", report.momentumScore)
        .put("progressScore", report.progressScore)
        .put("repetitionPenalty", report.repetitionPenalty)
        .put("closedEvidenceKeys", JSONArray(report.closedEvidenceKeys))
        .put("stalledEvidenceKeys", JSONArray(report.stalledEvidenceKeys))
        .put("graphDelta", report.graphDelta)
        .put("decisionLock", report.decisionLock)
        .put("nextAction", report.nextAction)
        .put("searchDecision", report.searchDecision)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun extractGaps(report: JSONObject): List<String> {
        val closure = report.optJSONObject("evidenceClosureReport") ?: JSONObject()
        val cards = closure.optJSONArray("cards") ?: JSONArray()
        val closureGaps = (0 until cards.length()).flatMap { idx ->
            arrayToList(cards.optJSONObject(idx)?.optJSONArray("missingFields"))
        }
        val continuity = report.optJSONObject("thinkingContinuityReport") ?: JSONObject()
        val graph = report.optJSONObject("hypothesisGraphReport") ?: JSONObject()
        val momentum = report.optJSONObject("cognitiveMomentumReport") ?: JSONObject()
        return (closureGaps +
            arrayToList(continuity.optJSONArray("repeatedGaps")) +
            listOf(graph.optString("weakestLink")) +
            arrayToList(momentum.optJSONArray("stalledEvidenceKeys")))
            .map { normalizeKey(it) }
            .filter { it.isNotBlank() }
            .distinct()
    }

    private fun arrayToList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { idx -> arr.optString(idx).takeIf { it.isNotBlank() } }
    }

    private fun normalizeKey(value: String): String = value.trim().lowercase()
        .replace(Regex("[^a-z0-9_]+"), "_")
        .trim('_')
        .replace("recovery_severity_response", "outcome_labels")
        .replace("control_comparator", "control_or_comparator")

    private fun keysOverlap(a: String, b: String): Boolean {
        val x = normalizeKey(a)
        val y = normalizeKey(b)
        return x == y || x.contains(y) || y.contains(x)
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}
