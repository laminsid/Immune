package com.immunesignal.app

import java.util.Locale

data class LearningRule(
    val ruleId: String,
    val description: String,
    val requiredSignals: List<String>,
    val interpretation: String,
    val confidencePolicy: String
)

data class LearningRuleMatch(
    val ruleId: String,
    val coverage: Double,
    val matchedSignals: List<String>,
    val missingSignals: List<String>,
    val interpretation: String,
    val confidencePolicy: String,
    val claimLimit: String = LearningRuleEngine.CLAIM_LIMIT
)

/** v1.10.21: activates learning_rules_v0.2 as routing/search signals, never as proof. */
object LearningRuleEngine {
    const val CLAIM_LIMIT = "learning_rules_route_only_not_biological_proof"

    private val defaultRules = listOf(
        LearningRule("allergy_aging_inverse_candidate", "Tests whether high allergic reactivity coexists with low aging-load markers and fast recovery.", listOf("high_allergy_reactivity", "low_inflammaging_load", "fast_recovery", "low_frequent_infection_signal"), "Possible preserved immune responsiveness pattern.", "hypothesis_only_until_repeated_longitudinal_observation"),
        LearningRule("allergy_inflammaging_burden_candidate", "Tests whether chronic allergic activation coexists with inflammatory aging burden.", listOf("high_allergy_reactivity", "high_crp_or_il6", "poor_sleep", "slow_recovery"), "Possible chronic immune irritation / inflammaging burden.", "hypothesis_only"),
        LearningRule("stress_allergy_bp_instability_candidate", "Tests whether stress-related allergy spikes are followed by dizziness, flushing, or lower blood pressure.", listOf("stress_spike", "allergy_spike", "histamine_like_symptoms", "bp_drop_or_dizziness"), "Possible autonomic-mast-cell vascular interaction.", "requires_repeated_temporal_pattern")
    )

    fun evaluate(findings: List<ResearchFinding>, rules: List<LearningRule> = defaultRules): List<LearningRuleMatch> {
        if (!RuntimeFeatureFlags.ENABLE_LEARNING_RULE_ENGINE || findings.isEmpty()) return emptyList()
        val corpus = findings.joinToString(" ") { listOf(it.title, it.bridgeSignal, it.whyItMatters, it.matchedAxes.joinToString(" ")).joinToString(" ") }.lowercase(Locale.US)
        return rules.mapNotNull { rule ->
            val matched = rule.requiredSignals.filter { signal -> signalMatches(signal, corpus) }
            val coverage = matched.size.toDouble() / rule.requiredSignals.size.coerceAtLeast(1).toDouble()
            if (coverage >= RuntimeFeatureFlags.MIN_LEARNING_RULE_COVERAGE) {
                LearningRuleMatch(
                    ruleId = rule.ruleId,
                    coverage = coverage,
                    matchedSignals = matched,
                    missingSignals = rule.requiredSignals - matched.toSet(),
                    interpretation = rule.interpretation,
                    confidencePolicy = rule.confidencePolicy
                )
            } else null
        }.sortedByDescending { it.coverage }.take(5)
    }

    fun nextAction(matches: List<LearningRuleMatch>): String {
        val top = matches.firstOrNull() ?: return "No learning rule reached coverage; keep rules as dormant query priors."
        return "Use ${top.ruleId} as a query/falsification prior only; close missing signals: ${top.missingSignals.take(3).joinToString(", ").ifBlank { "none" }}."
    }

    private fun signalMatches(signal: String, corpus: String): Boolean = when (signal) {
        "high_allergy_reactivity" -> listOf("allergy", "allergic", "ige", "eosinophil", "histamine", "mast cell", "urticaria").any { corpus.contains(it) }
        "low_inflammaging_load" -> listOf("low inflammation", "low crp", "low il-6", "low inflammaging", "fast recovery").any { corpus.contains(it) }
        "fast_recovery" -> listOf("fast recovery", "recovery", "resolution", "resolved", "improved").any { corpus.contains(it) }
        "low_frequent_infection_signal" -> listOf("low infection", "infrequent infection", "no frequent infection", "viral control").any { corpus.contains(it) }
        "high_crp_or_il6" -> listOf("crp", "il-6", "il6", "tnf", "inflammatory burden").any { corpus.contains(it) }
        "poor_sleep" -> listOf("poor sleep", "insomnia", "sleep quality", "sleep disruption").any { corpus.contains(it) }
        "slow_recovery" -> listOf("slow recovery", "delayed recovery", "persistent", "chronic", "prolonged").any { corpus.contains(it) }
        "stress_spike" -> listOf("stress", "hpa", "cortisol", "sympathetic").any { corpus.contains(it) }
        "allergy_spike" -> listOf("allergy", "histamine", "mast cell", "urticaria", "ige").any { corpus.contains(it) }
        "histamine_like_symptoms" -> listOf("histamine", "flushing", "itch", "urticaria", "h1", "h2").any { corpus.contains(it) }
        "bp_drop_or_dizziness" -> listOf("blood pressure", "bp", "dizziness", "orthostatic", "hypotension").any { corpus.contains(it) }
        else -> corpus.contains(signal.replace("_", " "))
    }
}
