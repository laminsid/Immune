package com.immunesignal.app

/**
 * v1.6.4: cognitive path integration.
 *
 * This is not another independent feature. It is the bridge that forces the
 * accumulated map, mutable beliefs, specialist evidence protocol, and dataset
 * forager to agree on one next research action. The goal is to prevent random
 * parallel additions: every cycle must now produce a linked path from what was
 * observed -> what is believed -> what blocks belief -> what the next search
 * must do.
 *
 * Boundary: this layer coordinates research routing only. It does not prove
 * biology, diagnosis, treatment, protection, or causality.
 */
data class CognitivePathNode(
    val pathId: String,
    val role: String,
    val label: String,
    val sourceLayer: String,
    val score: Int,
    val status: String,
    val rationale: String
)

data class CognitivePathLink(
    val fromId: String,
    val toId: String,
    val relation: String,
    val strength: Int,
    val requiredBeforeUpgrade: Boolean,
    val rationale: String
)

data class CognitivePathDecision(
    val decisionType: String,
    val action: String,
    val reason: String,
    val blocksHypothesisUpgrade: Boolean,
    val nextSearchTerms: List<String>,
    val requiredEvidence: List<String>
)

data class CognitivePathIntegrationReport(
    val active: Boolean,
    val state: String,
    val integrationScore: Int,
    val routeIntegrity: String,
    val nodes: List<CognitivePathNode>,
    val links: List<CognitivePathLink>,
    val decision: CognitivePathDecision,
    val linkedWarnings: List<String>,
    val changedSincePrevious: List<String>,
    val visibleBrief: String,
    val claimLimit: String = "cognitive_path_integration_not_biological_proof"
) {
    companion object {
        fun empty() = CognitivePathIntegrationReport(
            active = false,
            state = "NOT_BUILT",
            integrationScore = 0,
            routeIntegrity = "NOT_EVALUATED",
            nodes = emptyList(),
            links = emptyList(),
            decision = CognitivePathDecision(
                decisionType = "NO_DECISION",
                action = "Run a research cycle to build an integrated cognitive path.",
                reason = "No map, beliefs, or specialist protocol available yet.",
                blocksHypothesisUpgrade = true,
                nextSearchTerms = emptyList(),
                requiredEvidence = listOf("minimum_metadata", "outcome_labels", "controls_or_comparator")
            ),
            linkedWarnings = listOf("No integrated path has run yet."),
            changedSincePrevious = emptyList(),
            visibleBrief = "No linked cognitive path yet.",
            claimLimit = "cognitive_path_integration_not_biological_proof"
        )
    }
}

object CognitivePathIntegrationEngine {
    fun integrate(
        knowledgeMapReport: KnowledgeMapReport,
        epistemicBeliefReport: EpistemicBeliefReport,
        specializedReasoningReport: SpecializedReasoningReport,
        datasetForagingReport: DatasetForagingReport,
        learningOsReport: LearningOsReport
    ): CognitivePathIntegrationReport {
        val pathNodes = linkedMapOf<String, CognitivePathNode>()
        val links = mutableListOf<CognitivePathLink>()

        fun addNode(node: CognitivePathNode): String {
            pathNodes[node.pathId] = node
            return node.pathId
        }

        val topGap = knowledgeMapReport.gaps.maxByOrNull { it.severity }
        val topBelief = epistemicBeliefReport.beliefs
            .sortedWith(compareBy<EpistemicBelief> { beliefPriority(it.status) }.thenByDescending { it.credibility })
            .firstOrNull()
        val topUpdate = epistemicBeliefReport.updates.firstOrNull()
        val topEvidenceGap = specializedReasoningReport.evidenceGaps.maxByOrNull { it.severity }
        val topRouteFit = datasetForagingReport.routeFitAssessments.maxByOrNull { it.routeFitScore }
        val rootCauses = learningOsReport.incident.rootCauses

        val mapNode = addNode(
            CognitivePathNode(
                pathId = "path:map:${sanitize(knowledgeMapReport.state)}",
                role = "MEMORY_MAP",
                label = knowledgeMapReport.state,
                sourceLayer = "CumulativeKnowledgeMapEngine",
                score = knowledgeMapReport.mapScore,
                status = knowledgeMapReport.state,
                rationale = knowledgeMapReport.nextMapAction.take(220)
            )
        )
        val beliefNode = addNode(
            CognitivePathNode(
                pathId = "path:belief:${sanitize(topBelief?.beliefId ?: epistemicBeliefReport.state)}",
                role = "MUTABLE_BELIEF",
                label = topBelief?.statement?.take(120) ?: epistemicBeliefReport.state,
                sourceLayer = "EpistemicBeliefEngine",
                score = topBelief?.credibility ?: epistemicBeliefReport.beliefScore,
                status = topBelief?.status ?: epistemicBeliefReport.state,
                rationale = topBelief?.lastChangedReason?.take(220) ?: epistemicBeliefReport.nextBeliefAction.take(220)
            )
        )
        val specialistNode = addNode(
            CognitivePathNode(
                pathId = "path:specialist:${sanitize(specializedReasoningReport.state)}",
                role = "EVIDENCE_PROTOCOL",
                label = specializedReasoningReport.state,
                sourceLayer = "SpecializedReasoningEngine",
                score = specializedReasoningReport.specialistScore,
                status = specializedReasoningReport.specialistVerdict.take(80),
                rationale = specializedReasoningReport.decisiveNextTest.take(220)
            )
        )
        val foragerNode = addNode(
            CognitivePathNode(
                pathId = "path:forager:${sanitize(datasetForagingReport.state)}",
                role = "DATASET_FORAGER",
                label = datasetForagingReport.state,
                sourceLayer = "DatasetFirstForager",
                score = datasetForagingReport.scoreSeparation.routeFitScore,
                status = datasetForagingReport.scoreSeparation.scoreState,
                rationale = datasetForagingReport.nextAction.take(220)
            )
        )

        if (topGap != null) {
            val gapNode = addNode(
                CognitivePathNode(
                    pathId = "path:gap:${sanitize(topGap.gapId)}",
                    role = "OPEN_GAP",
                    label = topGap.gapId,
                    sourceLayer = "CumulativeKnowledgeMapEngine",
                    score = topGap.severity,
                    status = if (topGap.blocksUpgrade) "BLOCKS_UPGRADE" else "GAP_TRACKED",
                    rationale = topGap.nextAction.take(220)
                )
            )
            links += CognitivePathLink(
                fromId = mapNode,
                toId = gapNode,
                relation = "map_identifies_blocking_gap",
                strength = topGap.severity,
                requiredBeforeUpgrade = topGap.blocksUpgrade,
                rationale = "The map must drive the next evidence request instead of a broad restart."
            )
            links += CognitivePathLink(
                fromId = gapNode,
                toId = specialistNode,
                relation = "gap_sets_decisive_test",
                strength = maxOf(topGap.severity, topEvidenceGap?.severity ?: 0),
                requiredBeforeUpgrade = true,
                rationale = "Specialist reasoning must turn the top map gap into a concrete discriminator."
            )
        }

        if (topBelief != null) {
            links += CognitivePathLink(
                fromId = mapNode,
                toId = beliefNode,
                relation = "map_updates_mutable_belief",
                strength = ((knowledgeMapReport.mapScore + topBelief.credibility) / 2).coerceIn(0, 100),
                requiredBeforeUpgrade = topBelief.status in listOf("WEAKENED", "REVISE_REQUIRED", "RETIRED"),
                rationale = "The belief state must be updated by accumulated map evidence, not kept as a static assumption."
            )
        }
        links += CognitivePathLink(
            fromId = beliefNode,
            toId = specialistNode,
            relation = "belief_requires_specialist_test",
            strength = specializedReasoningReport.specialistScore.coerceIn(0, 100),
            requiredBeforeUpgrade = true,
            rationale = "Mutable beliefs can guide the hunt only after the specialist protocol names the evidence gap and falsifier."
        )
        links += CognitivePathLink(
            fromId = specialistNode,
            toId = foragerNode,
            relation = "specialist_test_controls_next_search",
            strength = datasetForagingReport.scoreSeparation.routeFitScore.coerceIn(0, 100),
            requiredBeforeUpgrade = datasetForagingReport.parsedMetadata.isEmpty() || datasetForagingReport.scoreSeparation.hypothesisUpgradeAllowed.not(),
            rationale = "The next search must satisfy the decisive test rather than collect unrelated new titles."
        )

        val requiredEvidence = requiredEvidence(topGap, topEvidenceGap, topBelief, rootCauses)
        val searchTerms = nextTerms(requiredEvidence, topRouteFit, datasetForagingReport, specializedReasoningReport, epistemicBeliefReport)
        val blocksUpgrade = topGap?.blocksUpgrade == true ||
            datasetForagingReport.parsedMetadata.isEmpty() ||
            datasetForagingReport.scoreSeparation.hypothesisUpgradeAllowed.not() ||
            topBelief?.status in listOf("WEAKENED", "REVISE_REQUIRED", "RETIRED")
        val routeIntegrity = routeIntegrity(datasetForagingReport, topBelief, topGap)
        val decision = CognitivePathDecision(
            decisionType = when {
                topBelief?.status == "RETIRED" -> "RETIRE_PATH"
                topBelief?.status == "REVISE_REQUIRED" -> "REVISE_BEFORE_SEARCH"
                blocksUpgrade -> "CONTINUE_EVIDENCE_HUNT"
                else -> "ALLOW_CAUTIONARY_INSPECTION"
            },
            action = when {
                topBelief?.status == "RETIRED" -> "Do not use the retired belief for routing; preserve it only as a mistake pattern."
                topBelief?.status == "REVISE_REQUIRED" -> "Run a falsification-first follow-up before this belief can guide ranking."
                datasetForagingReport.parsedMetadata.isEmpty() -> "Parse minimum dataset metadata before any new broad literature search."
                topGap != null -> topGap.nextAction
                else -> specializedReasoningReport.decisiveNextTest.ifBlank { datasetForagingReport.nextAction }
            },
            reason = buildReason(topBelief, topGap, topEvidenceGap, topUpdate, datasetForagingReport),
            blocksHypothesisUpgrade = blocksUpgrade,
            nextSearchTerms = searchTerms,
            requiredEvidence = requiredEvidence
        )
        val warnings = buildList {
            if (datasetForagingReport.parsedMetadata.isEmpty()) add("Minimum metadata is missing; do not treat route fit as evidence.")
            if (topBelief?.status in listOf("WEAKENED", "REVISE_REQUIRED", "RETIRED")) add("Top belief lost credibility; route decisions must be conservative.")
            if (topGap?.blocksUpgrade == true) add("Top map gap blocks hypothesis upgrade until resolved.")
            if (rootCauses.isNotEmpty()) add("Learning OS root causes still active: ${rootCauses.take(4).joinToString(", ")}.")
            add("Integrated path guides research only; it is not biological proof.")
        }
        val score = integrationScore(
            knowledgeMapReport = knowledgeMapReport,
            epistemicBeliefReport = epistemicBeliefReport,
            specializedReasoningReport = specializedReasoningReport,
            datasetForagingReport = datasetForagingReport,
            blocksUpgrade = blocksUpgrade,
            linkedWarnings = warnings
        )
        val state = when {
            score >= 80 && !blocksUpgrade -> "LINKED_READY_FOR_CAUTIOUS_INSPECTION"
            score >= 65 -> "LINKED_EVIDENCE_HUNT"
            score >= 45 -> "LINKED_BUT_BLOCKED"
            else -> "LINK_WEAK_REBUILD_PATH"
        }
        val changed = buildList {
            add("Linked ${pathNodes.size} cognitive node(s) across map, belief, specialist, and forager layers.")
            add("Decision: ${decision.decisionType}; blocks upgrade=${decision.blocksHypothesisUpgrade}.")
            if (searchTerms.isNotEmpty()) add("Next search terms now come from linked path: ${searchTerms.take(6).joinToString(", ")}.")
        }
        val brief = "Integrated path: $state ($score/100). Next: ${decision.action.take(150)}"
        return CognitivePathIntegrationReport(
            active = true,
            state = state,
            integrationScore = score,
            routeIntegrity = routeIntegrity,
            nodes = pathNodes.values.toList(),
            links = links.distinctBy { it.fromId + it.relation + it.toId }.take(24),
            decision = decision,
            linkedWarnings = warnings,
            changedSincePrevious = changed,
            visibleBrief = brief,
            claimLimit = "cognitive_path_integration_not_biological_proof"
        )
    }

    private fun requiredEvidence(
        topGap: KnowledgeMapGap?,
        topEvidenceGap: EvidenceGapCard?,
        topBelief: EpistemicBelief?,
        rootCauses: List<String>
    ): List<String> {
        val terms = mutableListOf<String>()
        topGap?.nextAction?.let { terms += evidenceTermsFromText(it) }
        topEvidenceGap?.requiredAction?.let { terms += evidenceTermsFromText(it) }
        topBelief?.requiredEvidenceToKeep?.let { terms += it }
        rootCauses.forEach { cause ->
            when {
                cause.contains("OUTCOME", true) -> terms += listOf("outcome_labels", "recovery", "severity")
                cause.contains("TIME", true) -> terms += listOf("time_course", "longitudinal")
                cause.contains("ANIMAL", true) -> terms += listOf("human", "patient_cohort")
                cause.contains("CONTROL", true) -> terms += listOf("control_or_comparator")
            }
        }
        return terms.map { normalizeEvidence(it) }.filter { it.isNotBlank() }.distinct().take(12)
            .ifEmpty { listOf("minimum_metadata", "outcome_labels", "controls_or_comparator", "time_order") }
    }

    private fun nextTerms(
        requiredEvidence: List<String>,
        topRouteFit: DatasetRouteFitAssessment?,
        datasetForagingReport: DatasetForagingReport,
        specializedReasoningReport: SpecializedReasoningReport,
        epistemicBeliefReport: EpistemicBeliefReport
    ): List<String> {
        val text = buildString {
            append(requiredEvidence.joinToString(" ")).append(' ')
            append(topRouteFit?.datasetRoute.orEmpty()).append(' ')
            append(topRouteFit?.targetRoute.orEmpty()).append(' ')
            append(datasetForagingReport.queryFeedbackPlan.improvedQueries.joinToString(" ") { it.query }).append(' ')
            append(specializedReasoningReport.decisiveNextTest).append(' ')
            append(epistemicBeliefReport.nextBeliefAction)
        }.lowercase()
        val terms = linkedSetOf<String>()
        mapOf(
            "outcome" to "outcome",
            "recovery" to "recovery",
            "severity" to "severity",
            "time" to "time-course",
            "longitudinal" to "longitudinal",
            "control" to "control",
            "comparator" to "comparator",
            "human" to "human",
            "patient" to "patient",
            "viral" to "viral load",
            "interferon" to "interferon",
            "allergy" to "allergy",
            "skin" to "skin",
            "rna" to "RNA-seq",
            "single" to "single-cell"
        ).forEach { (needle, term) -> if (needle in text) terms += term }
        if (terms.isEmpty()) terms += requiredEvidence.take(6)
        return terms.take(10)
    }

    private fun routeIntegrity(datasetForagingReport: DatasetForagingReport, topBelief: EpistemicBelief?, topGap: KnowledgeMapGap?): String = when {
        topBelief?.status == "RETIRED" -> "ROUTE_RETIRED_BY_BELIEF_LOSS"
        topBelief?.status == "REVISE_REQUIRED" -> "ROUTE_REQUIRES_BELIEF_REVISION"
        topGap?.blocksUpgrade == true -> "ROUTE_BLOCKED_BY_MAP_GAP"
        datasetForagingReport.parsedMetadata.isEmpty() && datasetForagingReport.scoreSeparation.routeFitScore >= 80 -> "HIGH_ROUTE_FIT_REQUIRES_MINIMUM_METADATA"
        datasetForagingReport.routeFitAssessments.any { it.blocksHypothesisUpgrade } -> "ROUTE_FIT_BLOCKED"
        datasetForagingReport.scoreSeparation.hypothesisUpgradeAllowed -> "ROUTE_INTEGRITY_CAUTIONARY_PASS"
        else -> "ROUTE_INTEGRITY_EVIDENCE_HUNT"
    }

    private fun buildReason(
        topBelief: EpistemicBelief?,
        topGap: KnowledgeMapGap?,
        topEvidenceGap: EvidenceGapCard?,
        topUpdate: EpistemicBeliefUpdate?,
        datasetForagingReport: DatasetForagingReport
    ): String {
        val parts = mutableListOf<String>()
        topBelief?.let { parts += "belief=${it.status}/${it.credibility}" }
        topUpdate?.let { parts += "update=${it.updateType}" }
        topGap?.let { parts += "mapGap=${it.gapId}:${it.severity}" }
        topEvidenceGap?.let { parts += "specialistGap=${it.gapId}:${it.severity}" }
        parts += "parsedMetadata=${datasetForagingReport.parsedMetadata.size}"
        parts += "routeFit=${datasetForagingReport.scoreSeparation.routeFitScore}"
        return parts.joinToString("; ")
    }

    private fun integrationScore(
        knowledgeMapReport: KnowledgeMapReport,
        epistemicBeliefReport: EpistemicBeliefReport,
        specializedReasoningReport: SpecializedReasoningReport,
        datasetForagingReport: DatasetForagingReport,
        blocksUpgrade: Boolean,
        linkedWarnings: List<String>
    ): Int {
        var score = 30
        if (knowledgeMapReport.active) score += 15
        if (epistemicBeliefReport.active) score += 15
        if (specializedReasoningReport.active) score += 15
        if (datasetForagingReport.active) score += 10
        if (datasetForagingReport.parsedMetadata.isNotEmpty()) score += 8 else score -= 8
        if (epistemicBeliefReport.revisedBeliefs > 0 || epistemicBeliefReport.retiredBeliefs > 0) score -= 10
        if (blocksUpgrade) score -= 5
        score -= linkedWarnings.count { it.contains("missing", true) || it.contains("blocks", true) } * 2
        return score.coerceIn(0, 100)
    }

    private fun evidenceTermsFromText(text: String): List<String> {
        val lower = text.lowercase()
        return buildList {
            if ("outcome" in lower || "recovery" in lower || "severity" in lower) add("outcome_labels")
            if ("time" in lower || "longitudinal" in lower || "temporal" in lower) add("time_course")
            if ("control" in lower || "comparator" in lower) add("controls_or_comparator")
            if ("metadata" in lower || "accession" in lower || "species" in lower) add("minimum_metadata")
            if ("human" in lower || "patient" in lower) add("human_or_patient_data")
            if ("viral" in lower || "load" in lower) add("viral_load")
            if ("interferon" in lower || "ifn" in lower) add("interferon_markers")
        }
    }

    private fun normalizeEvidence(value: String): String = value
        .lowercase()
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')

    private fun beliefPriority(status: String): Int = when (status) {
        "RETIRED" -> 0
        "REVISE_REQUIRED" -> 1
        "WEAKENED" -> 2
        "ACTIVE_WITH_WARNINGS" -> 3
        "PROVISIONAL" -> 4
        "ACTIVE_PRIOR" -> 5
        else -> 6
    }

    private fun sanitize(value: String): String = value
        .lowercase()
        .replace(Regex("[^a-z0-9_:-]+"), "_")
        .trim('_')
        .take(90)
        .ifBlank { "unknown" }
}
