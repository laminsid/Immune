package com.immunesignal.app

/**
 * v2.7.5.0 — Matrix/accession state consistency lock.
 *
 * One report cannot say ACCESSION_STATE=DGE_READY while also saying
 * matrix=DGE_NOT_READY_ACCESSION_HANDLE_ONLY. This guard is deliberately
 * conservative: DGE_READY is allowed only when the matrix state itself is a
 * ready state. Handles and partial metadata remain useful, but not ready.
 */
data class GTIMMatrixStateConsistencyReportV2750(
    val accessionState: String,
    val matrixState: String,
    val readinessScore: Int,
    val consistencyGap: String?
)

object GTIMMatrixStateConsistencyGuardV2750 {
    const val VERSION: String = "2.7.5.0-matrix-state-consistency-lock"

    private val readyMatrixStates = setOf(
        "DGE_READY",
        "DGE_READY_WITH_ACCESSION",
        "DGE_READY_ACCESSION_BACKED",
        "READY",
        "ACCESSION_READY"
    )

    fun normalize(
        accessionState: String,
        rawMatrixState: String,
        rawReadinessScore: Int
    ): GTIMMatrixStateConsistencyReportV2750 {
        val acc = accessionState.ifBlank { "NO_ACCESSION_ID_CAPTURED" }
        val raw = rawMatrixState.ifBlank { defaultMatrixFor(acc) }
        val matrixUpper = raw.uppercase().trim()
        val matrixIsReady = matrixUpper in readyMatrixStates
        val matrixIsNotReady = matrixUpper.startsWith("DGE_NOT_READY") || matrixUpper.contains("NOT_READY")

        if (acc == "DGE_READY" && !matrixIsReady) {
            return GTIMMatrixStateConsistencyReportV2750(
                accessionState = "ACCESSION_HANDLE_CAPTURED_METADATA_PARTIAL",
                matrixState = if (matrixIsNotReady) normalizeNotReadyMatrix(raw, "ACCESSION_HANDLE_CAPTURED_METADATA_PARTIAL") else "DGE_NOT_READY_METADATA_GAP",
                readinessScore = rawReadinessScore.coerceIn(0, 65),
                consistencyGap = "STATE_CONSISTENCY_DOWNGRADE:: accession_state=DGE_READY was downgraded because matrix_state=$raw is not a ready matrix state."
            )
        }

        if (matrixIsReady && acc != "DGE_READY") {
            return GTIMMatrixStateConsistencyReportV2750(
                accessionState = acc,
                matrixState = matrixUpper,
                readinessScore = rawReadinessScore.coerceAtLeast(80).coerceAtMost(100),
                consistencyGap = null
            )
        }

        if (acc == "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED") {
            return GTIMMatrixStateConsistencyReportV2750(
                accessionState = acc,
                matrixState = "DGE_NOT_READY_NO_TOPIC_COMPATIBLE_ACCESSION",
                readinessScore = rawReadinessScore.coerceIn(0, 35),
                consistencyGap = "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED:: accession handles exist, but none passed active-contract topic compatibility."
            )
        }

        if (acc == "NO_ACCESSION_ID_CAPTURED") {
            return GTIMMatrixStateConsistencyReportV2750(
                accessionState = acc,
                matrixState = "DGE_NOT_READY_NO_ACCESSION",
                readinessScore = rawReadinessScore.coerceIn(0, 25),
                consistencyGap = null
            )
        }

        val normalizedMatrix = normalizeNotReadyMatrix(raw, acc)
        return GTIMMatrixStateConsistencyReportV2750(
            accessionState = acc,
            matrixState = normalizedMatrix,
            readinessScore = rawReadinessScore.coerceIn(0, if (normalizedMatrix.startsWith("DGE_NOT_READY")) 75 else 100),
            consistencyGap = null
        )
    }

    private fun defaultMatrixFor(accessionState: String): String = when (accessionState) {
        "NO_ACCESSION_ID_CAPTURED" -> "DGE_NOT_READY_NO_ACCESSION"
        "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" -> "DGE_NOT_READY_NO_TOPIC_COMPATIBLE_ACCESSION"
        "ACCESSION_HANDLE_CAPTURED_DATASET_OBJECT_NOT_RESOLVED",
        "DATASET_OBJECT_RESOLUTION_PENDING" -> "DGE_NOT_READY_ACCESSION_HANDLE_ONLY"
        "MATRIX_FILE_NOT_READY" -> "DGE_NOT_READY_ACCESSION_HANDLE_ONLY"
        "METADATA_TRAITS_NOT_PARSED",
        "COMPARATOR_LABELS_MISSING_OR_AMBIGUOUS",
        "ACCESSION_HANDLE_CAPTURED_METADATA_PARTIAL" -> "DGE_NOT_READY_METADATA_GAP"
        "DGE_READY" -> "DGE_READY"
        else -> "DGE_NOT_READY_METADATA_GAP"
    }

    private fun normalizeNotReadyMatrix(matrixState: String, accessionState: String): String {
        val upper = matrixState.uppercase().trim()
        if (upper.startsWith("DGE_NOT_READY")) {
            return if (upper.contains("NO_ACCESSION") && accessionState != "NO_ACCESSION_ID_CAPTURED") {
                "DGE_NOT_READY_ACCESSION_HANDLE_ONLY"
            } else upper
        }
        return defaultMatrixFor(accessionState)
    }
}
