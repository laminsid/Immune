package com.immunesignal.app

object ResearchMistakeLibrary {
    fun topRisks(objects: List<HypothesisObject>, findings: List<ResearchFinding>): List<MistakeRiskCard> {
        val risks = mutableListOf<MistakeRiskCard>()
        val weakEvidenceOrTrust = objects.filter { it.dataTrustScore < 60 || it.evidenceScore10 < 7.0 }
        if (weakEvidenceOrTrust.isNotEmpty()) {
            risks += MistakeRiskCard(
                risk = "Treating weak or metadata-heavy evidence as a strong biological signal.",
                preventionGate = "Require Evidence >= 7/10 and Data Trust >= 60 before STRONG_SIGNAL.",
                affectedHypotheses = weakEvidenceOrTrust.map { it.hypothesisId }.take(5)
            )
        }
        val noTiming = objects.filter { it.missingData.any { m -> m.contains("timestamp", true) || m.contains("event_timing", true) } }
        if (noTiming.isNotEmpty()) {
            risks += MistakeRiskCard(
                risk = "Mistaking correlation for causation because time order is missing.",
                preventionGate = "Cause candidate must be measured before outcome in at least 3 observations.",
                affectedHypotheses = noTiming.map { it.hypothesisId }.take(5)
            )
        }
        val animalOrCell = findings.filter { it.evidence.speciesClass != "human" }.map { HypothesisId.fromAxes(it.matchedAxes) }.distinct()
        if (animalOrCell.isNotEmpty()) {
            risks += MistakeRiskCard(
                risk = "Merging animal/cell-only evidence into human confidence.",
                preventionGate = "Keep animal/cell evidence as mechanism plausibility only until human source exists.",
                affectedHypotheses = animalOrCell.take(5)
            )
        }
        val controlWeak = objects.filter { it.biasRiskState == "Alert" || it.biasRiskState == "Severe Bias" }
        if (controlWeak.isNotEmpty()) {
            risks += MistakeRiskCard(
                risk = "Novelty mistaken for truth; negative controls or contradiction checks are incomplete.",
                preventionGate = "Run reverse-time, shuffled-timeline, and contradiction search before upgrading.",
                affectedHypotheses = controlWeak.map { it.hypothesisId }.take(5)
            )
        }
        return risks.distinctBy { it.risk }.take(3).ifEmpty {
            listOf(
                MistakeRiskCard(
                    risk = "No dominant mistake risk detected, but causal proof is still absent.",
                    preventionGate = "Continue using temporality, repeatability, and contradiction checks.",
                    affectedHypotheses = objects.take(3).map { it.hypothesisId }
                )
            )
        }
    }
}
