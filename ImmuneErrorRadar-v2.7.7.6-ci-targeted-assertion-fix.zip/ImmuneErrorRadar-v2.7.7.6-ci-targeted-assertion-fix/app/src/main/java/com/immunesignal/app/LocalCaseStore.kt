package com.immunesignal.app

import android.content.Context
import org.json.JSONObject

class LocalCaseStore(private val context: Context) {
    private val fileName = "immune_signal_cases.jsonl"
    private val maxRecords = 200

    fun save(record: JSONObject) {
        val existing = readAll().toMutableList()
        existing.add(record.toString())
        val trimmed = existing.takeLast(maxRecords)
        context.openFileOutput(fileName, Context.MODE_PRIVATE).bufferedWriter().use { writer ->
            trimmed.forEach { line ->
                writer.write(line)
                writer.newLine()
            }
        }
    }

    fun readLatest(limit: Int): List<String> = readAll().takeLast(limit).asReversed()

    private fun readAll(): List<String> {
        return try {
            context.openFileInput(fileName).bufferedReader().useLines { lines ->
                lines.map { it.trim() }.filter { it.startsWith("{") && it.endsWith("}") }.toList()
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
