package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

/**
 * v1.6.6: closes the cognitive loop with single-use continuity guards.
 *
 * Earlier versions produced a linked cognitive path, but the next cycle still
 * mostly relied on the normal query planner. This bridge turns the integrated
 * path decision into a bounded next-cycle directive. v1.6.6 adds single-use
 * consumption and query-inflation protection so the same directive cannot be
 * replayed across cycles. It is intentionally narrow:
 * it can add one follow-up query and annotate existing queries; it cannot prove
 * biology, upgrade hypotheses, or edit foundation knowledge packs.
 */
data class CognitiveNextCycleDirective(
    val directiveId: String,
    val createdAtMillis: Long,
    val sourceCycleId: String,
    val state: String,
    val decisionType: String,
    val routeIntegrity: String,
    val action: String,
    val reason: String,
    val nextSearchTerms: List<String>,
    val requiredEvidence: List<String>,
    val blockedClaims: List<String>,
    val priority: Int,
    val expiresAtMillis: Long,
    val consumedCount: Int,
    val useLimit: Int = 1,
    val claimLimit: String = "next_cycle_routing_only_not_biological_proof"
) {
    fun isExpired(nowMillis: Long = System.currentTimeMillis()): Boolean = nowMillis > expiresAtMillis
    fun isConsumed(): Boolean = consumedCount >= useLimit.coerceAtLeast(1)
    fun isActive(nowMillis: Long = System.currentTimeMillis()): Boolean = !isExpired(nowMillis) && !isConsumed()
}

data class CognitiveNextCyclePlan(
    val active: Boolean,
    val directiveId: String?,
    val appliedQueryCount: Int,
    val addedFollowUpQuery: Boolean,
    val appliedTerms: List<String>,
    val blockedClaims: List<String>,
    val summary: String,
    val suppressedReason: String? = null,
    val directiveConsumed: Boolean = false,
    val consumptionReason: String? = null,
    val routingFingerprint: String? = null,
    val useLimit: Int = 1,
    val claimLimit: String = "next_cycle_routing_only_not_biological_proof"
) {
    companion object {
        fun none(reason: String) = CognitiveNextCyclePlan(
            active = false,
            directiveId = null,
            appliedQueryCount = 0,
            addedFollowUpQuery = false,
            appliedTerms = emptyList(),
            blockedClaims = defaultBlockedClaims(),
            summary = reason,
            suppressedReason = reason,
            directiveConsumed = false,
            consumptionReason = null,
            routingFingerprint = null,
            useLimit = 0
        )
    }
}

object CognitiveNextCycleBridge {
    private const val DEFAULT_TTL_MILLIS = 7L * 24L * 60L * 60L * 1000L
    private const val MAX_DIRECTIVE_USES = 1
    private const val MAX_TERMS_APPLIED_TO_BASE_QUERY = 8
    private const val MAX_FOLLOW_UP_TERMS = 12

    fun directiveFromReportJson(reportJson: JSONObject): CognitiveNextCycleDirective? {
        val path = reportJson.optJSONObject("cognitivePathIntegrationReport") ?: return null
        if (!path.optBoolean("active", false)) return null
        val decision = path.optJSONObject("decision") ?: return null
        val baseTerms = jsonArrayToList(decision.optJSONArray("nextSearchTerms"))
        val baseEvidence = jsonArrayToList(decision.optJSONArray("requiredEvidence"))
        val controlTerms = extractV17ControlTerms(reportJson)
        val controlEvidence = extractV17RequiredEvidence(reportJson)
        val discoveryTerms = extractV18DiscoveryTerms(reportJson)
        val discoveryEvidence = extractV18RequiredEvidence(reportJson)
        val weightedTerms = extractV182WeightedDiscoveryTerms(reportJson)
        val weightedEvidence = extractV182WeightedDiscoveryEvidence(reportJson)
        val decisionTerms = extractV183DecisionMemoryTerms(reportJson)
        val decisionEvidence = extractV183DecisionMemoryEvidence(reportJson)
        val stressTerms = extractV184StressTestTerms(reportJson)
        val stressEvidence = extractV184StressTestEvidence(reportJson)
        val policyTerms = extractV185ExecutionPolicyTerms(reportJson)
        val policyEvidence = extractV185ExecutionPolicyEvidence(reportJson)
        val verifierTerms = extractV186OutcomeVerifierTerms(reportJson)
        val verifierEvidence = extractV186OutcomeVerifierEvidence(reportJson)
        val lineageTerms = extractV187LineageTerms(reportJson)
        val lineageEvidence = extractV187LineageEvidence(reportJson)
        val gapTerms = extractV188GapMinerTerms(reportJson)
        val gapEvidence = extractV188GapMinerEvidence(reportJson)
        val probeTerms = extractV189ProbePlanTerms(reportJson)
        val probeEvidence = extractV189ProbePlanEvidence(reportJson)
        val probeOutcomeTerms = extractV190ProbeOutcomeLedgerTerms(reportJson)
        val probeOutcomeEvidence = extractV190ProbeOutcomeLedgerEvidence(reportJson)
        val metaStrategyTerms = extractV191MetaStrategyTerms(reportJson)
        val metaStrategyEvidence = extractV191MetaStrategyEvidence(reportJson)
        val qualityGateTerms = extractV192QualityGateTerms(reportJson)
        val qualityGateEvidence = extractV192QualityGateEvidence(reportJson)
        val runbookTerms = extractV193RunbookTerms(reportJson)
        val runbookEvidence = extractV193RunbookEvidence(reportJson)
        val terms = mergeDirectiveTerms(baseTerms + controlTerms + discoveryTerms + weightedTerms + decisionTerms + stressTerms + policyTerms + verifierTerms + lineageTerms + gapTerms + probeTerms + probeOutcomeTerms + metaStrategyTerms + qualityGateTerms + runbookTerms)
        val evidence = mergeEvidenceKeys(baseEvidence + controlEvidence + discoveryEvidence + weightedEvidence + decisionEvidence + stressEvidence + policyEvidence + verifierEvidence + lineageEvidence + gapEvidence + probeEvidence + probeOutcomeEvidence + metaStrategyEvidence + qualityGateEvidence + runbookEvidence)
        if (terms.isEmpty() && evidence.isEmpty()) return null
        val now = System.currentTimeMillis()
        val cycleId = reportJson.optString("id", "cycle_unknown")
        val decisionType = decision.optString("decisionType", "FOLLOW_UP_REQUIRED")
        val routeIntegrity = path.optString("routeIntegrity", "UNKNOWN_ROUTE_INTEGRITY")
        val priority = priorityFor(decisionType, routeIntegrity, evidence, path.optJSONArray("linkedWarnings"))
        val controlReason = listOf(
            buildV17ControlReason(reportJson),
            buildV18DiscoveryReason(reportJson),
            buildV182WeightedReason(reportJson),
            buildV183DecisionMemoryReason(reportJson),
            buildV184StressTestReason(reportJson),
            buildV185ExecutionPolicyReason(reportJson),
            buildV186OutcomeVerifierReason(reportJson),
            buildV187LineageReason(reportJson),
            buildV188GapMinerReason(reportJson),
            buildV189ProbePlanReason(reportJson),
            buildV190ProbeOutcomeLedgerReason(reportJson),
            buildV191MetaStrategyReason(reportJson),
            buildV192QualityGateReason(reportJson),
            buildV193RunbookReason(reportJson)
        ).filter { it.isNotBlank() }.joinToString(" ").take(900)
        return CognitiveNextCycleDirective(
            directiveId = stableDirectiveId(cycleId, decisionType, terms, evidence),
            createdAtMillis = now,
            sourceCycleId = cycleId,
            state = path.optString("state", "ACTIVE"),
            decisionType = decisionType,
            routeIntegrity = routeIntegrity,
            action = appendControlSuffix(
                decision.optString("action", "Run a bounded follow-up query from the integrated cognitive path."),
                reportJson
            ),
            reason = listOf(
                decision.optString("reason", "Integrated cognitive path produced a next-cycle routing directive."),
                controlReason
            ).filter { it.isNotBlank() }.joinToString(" ").take(900),
            nextSearchTerms = terms,
            requiredEvidence = evidence,
            blockedClaims = defaultBlockedClaims(),
            priority = priority,
            expiresAtMillis = now + DEFAULT_TTL_MILLIS,
            consumedCount = 0,
            useLimit = MAX_DIRECTIVE_USES
        )
    }


    private fun appendControlSuffix(action: String, reportJson: JSONObject): String {
        val peer = reportJson.optJSONObject("miniPeerReviewReport") ?: JSONObject()
        val causal = reportJson.optJSONObject("causalReadinessReport") ?: JSONObject()
        val memory = reportJson.optJSONObject("memoryConsolidationReport") ?: JSONObject()
        val suffix = buildList {
            val verdict = peer.optString("verdict", "")
            if (verdict in setOf("HOLD", "INSPECT", "REJECT")) add("peer=$verdict")
            val causalState = causal.optString("state", "")
            if (causalState.isNotBlank()) add("causal=$causalState")
            val memoryAction = memory.optString("garbageCollectorAction", "")
            if (memoryAction.contains("Do not let weak beliefs", true)) add("weak-belief-routing-blocked")
            val deep = reportJson.optJSONObject("deepDiscoveryReasoningReport") ?: JSONObject()
            if (deep.optBoolean("active", false)) add("deep=${deep.optString("state", "DISCOVERY_ROUTE")}")
            val index = reportJson.optJSONObject("scientificKnowledgeIndexReport") ?: JSONObject()
            if (index.optBoolean("active", false)) add("scientific-index-routed")
            val weights = reportJson.optJSONObject("scientificDiscoveryWeightReport") ?: JSONObject()
            if (weights.optBoolean("active", false)) add("weighted-discovery=${weights.optString("version", "v1.8.2")}")
            val decision = reportJson.optJSONObject("scientificDiscoveryDecisionReport") ?: JSONObject()
            if (decision.optBoolean("active", false)) add("decision-memory=${decision.optString("version", "v1.8.3")}")
            val stress = reportJson.optJSONObject("scientificDiscoveryStressTestReport") ?: JSONObject()
            if (stress.optBoolean("active", false)) add("stress-test=${stress.optString("version", "v1.8.4")}")
            val policy = reportJson.optJSONObject("scientificDiscoveryExecutionPolicyReport") ?: JSONObject()
            if (policy.optBoolean("active", false)) add("execution-policy=${policy.optString("version", "v1.8.5")}")
            val verifier = reportJson.optJSONObject("scientificDiscoveryOutcomeVerifierReport") ?: JSONObject()
            if (verifier.optBoolean("active", false)) add("outcome-verifier=${verifier.optString("version", "v1.8.6")}")
            val lineage = reportJson.optJSONObject("scientificDiscoveryLineageReport") ?: JSONObject()
            if (lineage.optBoolean("active", false)) add("lineage=${lineage.optString("version", "v1.8.7")}")
            val gapMiner = reportJson.optJSONObject("scientificDiscoveryGapMinerReport") ?: JSONObject()
            if (gapMiner.optBoolean("active", false)) add("gap-miner=${gapMiner.optString("version", "v1.8.8")}")
            val probePlan = reportJson.optJSONObject("scientificDiscoveryProbePlanReport") ?: JSONObject()
            if (probePlan.optBoolean("active", false)) add("probe-plan=${probePlan.optString("version", "v1.8.9")}")
            val probeOutcome = reportJson.optJSONObject("scientificDiscoveryProbeOutcomeLedgerReport") ?: JSONObject()
            if (probeOutcome.optBoolean("active", false)) add("probe-outcome=${probeOutcome.optString("version", "v1.9.0")}")
            val meta = reportJson.optJSONObject("scientificDiscoveryMetaStrategyReport") ?: JSONObject()
            if (meta.optBoolean("active", false)) add("meta-strategy=${meta.optString("version", "v1.9.1")}")
            val quality = reportJson.optJSONObject("scientificDiscoveryQualityGateReport") ?: JSONObject()
            if (quality.optBoolean("active", false)) add("quality-gate=${quality.optString("version", "v1.9.2")}")
            val runbook = reportJson.optJSONObject("scientificDiscoveryRunbookReport") ?: JSONObject()
            if (runbook.optBoolean("active", false)) add("runbook=${runbook.optString("version", "v1.9.3")}")
        }.joinToString("; ")
        return if (suffix.isBlank()) action.take(700) else "$action v1.8.3 control + v1.8.4 stress + v1.8.5 policy + v1.8.6 outcome verification + v1.8.7 lineage graph + v1.8.8 latent gap miner + v1.8.9 executable probe plan + v1.9.2 quality gate + v1.9.3 runbook: $suffix".take(700)
    }

    private fun buildV17ControlReason(reportJson: JSONObject): String {
        val evidenceGain = reportJson.optJSONObject("evidenceGainQueryRankerReport") ?: JSONObject()
        val causal = reportJson.optJSONObject("causalReadinessReport") ?: JSONObject()
        val peer = reportJson.optJSONObject("miniPeerReviewReport") ?: JSONObject()
        val reflection = reportJson.optJSONObject("reflectionLessonReport") ?: JSONObject()
        val parts = buildList {
            if (evidenceGain.optBoolean("active", false)) add("Evidence-gain selected ${evidenceGain.optString("chosenQueryId", "none")} at ${evidenceGain.optInt("chosenScore", 0)}/100.")
            if (causal.optBoolean("active", false)) add("Causal readiness is ${causal.optString("state", "ASSOCIATION_ONLY")}; next=${causal.optString("nextAction", "close blockers")}")
            if (peer.optBoolean("active", false)) add("Mini peer review verdict=${peer.optString("verdict", "HOLD")}; objection=${peer.optString("strongestObjection", "none").take(180)}")
            if (reflection.optBoolean("active", false)) add("Reflection prevention=${reflection.optString("prevention", "keep gates visible").take(160)}")
        }
        return if (parts.isEmpty()) "" else "v1.7.1 actionable control: ${parts.joinToString(" ")}".take(900)
    }

    private fun buildV18DiscoveryReason(reportJson: JSONObject): String {
        val index = reportJson.optJSONObject("scientificKnowledgeIndexReport") ?: JSONObject()
        val deep = reportJson.optJSONObject("deepDiscoveryReasoningReport") ?: JSONObject()
        val parts = buildList {
            if (index.optBoolean("active", false)) {
                add("Scientific index route hints=${jsonArrayToList(index.optJSONArray("routeHints")).take(4).joinToString(" | ").take(240)}")
                val warnings = jsonArrayToList(index.optJSONArray("falseFriendWarnings")).take(2).joinToString(" | ")
                if (warnings.isNotBlank()) add("False-friend guard=$warnings")
            }
            if (deep.optBoolean("active", false)) {
                add("Deep discovery state=${deep.optString("state", "NO_DEEP_LEAD")}; intelligence=${deep.optInt("intelligenceScore", 0)}/100.")
                val decisive = deep.optJSONObject("decisiveExperiment") ?: JSONObject()
                val decisiveQuery = decisive.optString("nextQuery", "")
                if (decisiveQuery.isNotBlank()) add("Decisive query=${decisiveQuery.take(240)}")
                val contradiction = deep.optJSONObject("contradictionPlan") ?: JSONObject()
                val objection = contradiction.optString("strongestObjection", "")
                if (objection.isNotBlank() && objection != "none") add("Strongest objection=${objection.take(180)}")
                val think = deep.optJSONObject("deepThinkSession") ?: JSONObject()
                if (think.optBoolean("active", false)) add("Deep-think trigger=${think.optString("trigger", "UNKNOWN")}; verdict=${think.optString("sessionVerdict", "THINK_THEN_ROUTE")}")
            }
        }
        return if (parts.isEmpty()) "" else "v1.8.2 knowledge-routed discovery: ${parts.joinToString(" ")}".take(900)
    }

    private fun buildV182WeightedReason(reportJson: JSONObject): String {
        val weights = reportJson.optJSONObject("scientificDiscoveryWeightReport") ?: JSONObject()
        if (!weights.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Weighted scientific discovery=${weights.optString("version", "v1.8.2")}; ${weights.optString("learningReceipt", "no receipt").take(220)}")
            val decisive = jsonArrayToList(weights.optJSONArray("decisiveEvidenceDelta")).take(5).joinToString("/")
            if (decisive.isNotBlank()) add("decisive-evidence=$decisive")
            val guards = jsonArrayToList(weights.optJSONArray("riskGuards")).take(2).joinToString(" | ")
            if (guards.isNotBlank()) add("risk-guards=$guards")
        }
        return "v1.8.2 weighted discovery intelligence: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV182WeightedDiscoveryTerms(reportJson: JSONObject): List<String> {
        val terms = mutableListOf<String>()
        val weights = reportJson.optJSONObject("scientificDiscoveryWeightReport") ?: JSONObject()
        if (!weights.optBoolean("active", false)) return emptyList()
        terms += jsonArrayToList(weights.optJSONArray("searchPriorityVector")).flatMap { compactQueryTokens(it, 10) }
        terms += jsonArrayToList(weights.optJSONArray("prioritizedTerms")).flatMap { compactQueryTokens(it, 4) }
        val topWeights = weights.optJSONArray("topWeights")
        if (topWeights != null) {
            for (i in 0 until topWeights.length().coerceAtMost(8)) {
                val card = topWeights.optJSONObject(i) ?: continue
                terms += compactQueryTokens(card.optString("label", ""), 4)
                terms += jsonArrayToList(card.optJSONArray("queryTerms")).flatMap { compactQueryTokens(it, 6) }
                if (card.optString("action") == "DOWNGRADE_FALSE_FRIEND") {
                    terms += listOf("negative control", "comparator", "contradiction", "confounder")
                }
            }
        }
        return terms.distinctBy { it.lowercase(Locale.US) }.take(42)
    }

    private fun extractV182WeightedDiscoveryEvidence(reportJson: JSONObject): List<String> {
        val evidence = mutableListOf<String>()
        val weights = reportJson.optJSONObject("scientificDiscoveryWeightReport") ?: JSONObject()
        if (!weights.optBoolean("active", false)) return emptyList()
        evidence += jsonArrayToList(weights.optJSONArray("decisiveEvidenceDelta")).map { evidenceKeyFromGap(it) }
        val topWeights = weights.optJSONArray("topWeights")
        if (topWeights != null) {
            for (i in 0 until topWeights.length().coerceAtMost(8)) {
                val card = topWeights.optJSONObject(i) ?: continue
                if (card.optString("action") in setOf("CLOSE_DECISIVE_EVIDENCE_GAP", "ADD_FOUNDATION_CONTROL_TERM", "DOWNGRADE_FALSE_FRIEND")) {
                    evidence += jsonArrayToList(card.optJSONArray("requiredEvidence")).map { evidenceKeyFromGap(it) }
                }
            }
        }
        val guards = jsonArrayToList(weights.optJSONArray("riskGuards")).joinToString(" ")
        if (guards.contains("causal", true)) evidence += "comparator_control"
        if (guards.contains("outcome", true)) evidence += "outcome_labels"
        if (guards.contains("time", true) || guards.contains("longitudinal", true)) evidence += "time_order"
        return mergeEvidenceKeys(evidence)
    }

    private fun buildV183DecisionMemoryReason(reportJson: JSONObject): String {
        val decision = reportJson.optJSONObject("scientificDiscoveryDecisionReport") ?: JSONObject()
        if (!decision.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Decision-memory=${decision.optString("version", "v1.8.3")}; selected=${decision.optString("selectedMove", "none").take(180)}")
            val blocked = decision.optString("blockedMove", "")
            if (blocked.isNotBlank() && blocked != "none") add("blocked=${blocked.take(160)}")
            val contract = decision.optString("nextCycleContract", "")
            if (contract.isNotBlank()) add("contract=${contract.take(220)}")
            val change = decision.optString("changeIfFails", "")
            if (change.isNotBlank() && change != "none") add("if-fails=${change.take(160)}")
        }
        return "v1.8.3 discovery decision memory: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV183DecisionMemoryTerms(reportJson: JSONObject): List<String> {
        val terms = mutableListOf<String>()
        val decision = reportJson.optJSONObject("scientificDiscoveryDecisionReport") ?: JSONObject()
        if (!decision.optBoolean("active", false)) return emptyList()
        terms += jsonArrayToList(decision.optJSONArray("queryImpactTerms"))
        terms += compactQueryTokens(decision.optString("selectedMove", ""), 10)
        terms += compactQueryTokens(decision.optString("nextCycleContract", ""), 14)
        terms += compactQueryTokens(decision.optString("changeIfFails", ""), 8)
        terms += jsonArrayToList(decision.optJSONArray("successCriteria")).flatMap { compactQueryTokens(it, 8) }
        terms += jsonArrayToList(decision.optJSONArray("failureCriteria")).flatMap { compactQueryTokens(it, 8) }
        return terms.distinctBy { it.lowercase(Locale.US) }.take(36)
    }

    private fun extractV183DecisionMemoryEvidence(reportJson: JSONObject): List<String> {
        val evidence = mutableListOf<String>()
        val decision = reportJson.optJSONObject("scientificDiscoveryDecisionReport") ?: JSONObject()
        if (!decision.optBoolean("active", false)) return emptyList()
        evidence += jsonArrayToList(decision.optJSONArray("evidenceImpactKeys"))
        evidence += jsonArrayToList(decision.optJSONArray("successCriteria")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(decision.optJSONArray("failureCriteria")).map { evidenceKeyFromGap(it) }
        val blocked = decision.optString("blockedReason", "")
        if (blocked.contains("outcome", true)) evidence += "outcome_labels"
        if (blocked.contains("control", true) || blocked.contains("comparator", true)) evidence += "comparator_control"
        if (blocked.contains("time", true) || blocked.contains("longitudinal", true)) evidence += "time_order"
        return mergeEvidenceKeys(evidence)
    }

    private fun buildV185ExecutionPolicyReason(reportJson: JSONObject): String {
        val policy = reportJson.optJSONObject("scientificDiscoveryExecutionPolicyReport") ?: JSONObject()
        if (!policy.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Policy=${policy.optString("version", "v1.8.5")}; state=${policy.optString("policyState", "NOT_RUN")}; mode=${policy.optString("executionMode", "NO_POLICY")}")
            val blocked = jsonArrayToList(policy.optJSONArray("blockedActions")).take(3).joinToString("/")
            if (blocked.isNotBlank()) add("blocked=$blocked")
            val allowed = jsonArrayToList(policy.optJSONArray("allowedActions")).take(3).joinToString("/")
            if (allowed.isNotBlank()) add("allowed=$allowed")
            val replay = jsonArrayToList(policy.optJSONArray("queryReplayBlocks")).take(2).joinToString("/")
            if (replay.isNotBlank()) add("replay-block=$replay")
        }
        return "v1.8.5 policy-enforced discovery control: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV185ExecutionPolicyTerms(reportJson: JSONObject): List<String> {
        val terms = mutableListOf<String>()
        val policy = reportJson.optJSONObject("scientificDiscoveryExecutionPolicyReport") ?: JSONObject()
        if (!policy.optBoolean("active", false)) return emptyList()
        terms += jsonArrayToList(policy.optJSONArray("forcedDirectiveTerms"))
        terms += jsonArrayToList(policy.optJSONArray("allowedActions")).flatMap { compactQueryTokens(it, 8) }
        terms += jsonArrayToList(policy.optJSONArray("blockedActions")).flatMap { compactQueryTokens(it, 8) }
        terms += jsonArrayToList(policy.optJSONArray("queryReplayBlocks")).flatMap { compactQueryTokens(it, 8) }
        terms += jsonArrayToList(policy.optJSONArray("rerouteTriggers")).flatMap { compactQueryTokens(it, 8) }
        terms += compactQueryTokens(policy.optString("routeCooldownPolicy", ""), 10)
        terms += compactQueryTokens(policy.optString("beliefBurialPolicy", ""), 10)
        return terms.distinctBy { it.lowercase(Locale.US) }.take(48)
    }

    private fun extractV185ExecutionPolicyEvidence(reportJson: JSONObject): List<String> {
        val evidence = mutableListOf<String>()
        val policy = reportJson.optJSONObject("scientificDiscoveryExecutionPolicyReport") ?: JSONObject()
        if (!policy.optBoolean("active", false)) return emptyList()
        evidence += jsonArrayToList(policy.optJSONArray("forcedEvidenceKeys"))
        evidence += jsonArrayToList(policy.optJSONArray("allowedActions")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(policy.optJSONArray("blockedActions")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(policy.optJSONArray("queryReplayBlocks")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(policy.optJSONArray("rerouteTriggers")).map { evidenceKeyFromGap(it) }
        val cooldown = policy.optString("routeCooldownPolicy", "")
        if (cooldown.contains("outcome", true)) evidence += "outcome_labels"
        if (cooldown.contains("control", true) || cooldown.contains("comparator", true)) evidence += "comparator_control"
        if (cooldown.contains("time", true)) evidence += "time_order"
        if (cooldown.contains("metadata", true)) evidence += "minimum_metadata"
        val burial = policy.optString("beliefBurialPolicy", "")
        if (burial.contains("belief", true)) evidence += "belief_burial_policy"
        return mergeEvidenceKeys(evidence)
    }

    private fun buildV186OutcomeVerifierReason(reportJson: JSONObject): String {
        val verifier = reportJson.optJSONObject("scientificDiscoveryOutcomeVerifierReport") ?: JSONObject()
        if (!verifier.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Verifier=${verifier.optString("version", "v1.8.6")}; state=${verifier.optString("verifierState", "NOT_RUN")}; score=${verifier.optInt("outcomeScore", 0)}/100")
            val unmet = jsonArrayToList(verifier.optJSONArray("unmetEvidenceKeys")).take(3).joinToString("/")
            if (unmet.isNotBlank()) add("unmet=$unmet")
            val resolved = jsonArrayToList(verifier.optJSONArray("resolvedEvidenceKeys")).take(3).joinToString("/")
            if (resolved.isNotBlank()) add("resolved=$resolved")
            val adjustment = verifier.optString("nextPolicyAdjustment", "")
            if (adjustment.isNotBlank()) add("adjust=${adjustment.take(180)}")
        }
        return "v1.8.6 outcome verification discovery memory: ${parts.joinToString(" ")}".take(900)
    }

    private fun buildV187LineageReason(reportJson: JSONObject): String {
        val lineage = reportJson.optJSONObject("scientificDiscoveryLineageReport") ?: JSONObject()
        if (!lineage.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Lineage=${lineage.optString("version", "v1.8.7")}; state=${lineage.optString("lineageState", "NOT_RUN")}; score=${lineage.optInt("graphCompletenessScore", 0)}/100")
            val carry = jsonArrayToList(lineage.optJSONArray("contradictionCarryForward")).take(3).joinToString("/")
            if (carry.isNotBlank()) add("carry=$carry")
            val action = lineage.optString("nextLineageAction", "")
            if (action.isNotBlank()) add("next=${action.take(180)}")
        }
        return "v1.8.7 hypothesis lineage graph: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV187LineageTerms(reportJson: JSONObject): List<String> {
        val lineage = reportJson.optJSONObject("scientificDiscoveryLineageReport") ?: JSONObject()
        if (!lineage.optBoolean("active", false)) return emptyList()
        val terms = mutableListOf<String>()
        terms += jsonArrayToList(lineage.optJSONArray("forcedDirectiveTerms"))
        terms += compactQueryTokens(lineage.optString("nextLineageAction", ""), 14)
        terms += jsonArrayToList(lineage.optJSONArray("contradictionCarryForward")).flatMap { compactQueryTokens(it, 8) }
        terms += jsonArrayToList(lineage.optJSONArray("mergeCandidates")).flatMap { compactQueryTokens(it, 8) }
        val cards = lineage.optJSONArray("hypothesisLineages")
        if (cards != null) {
            for (i in 0 until cards.length().coerceAtMost(4)) {
                val card = cards.optJSONObject(i) ?: continue
                terms += compactQueryTokens(card.optString("nextLineageTest", ""), 10)
                terms += compactQueryTokens(card.optString("splitOrMergeAction", ""), 8)
            }
        }
        return terms.distinctBy { it.lowercase(Locale.US) }.take(44)
    }

    private fun extractV187LineageEvidence(reportJson: JSONObject): List<String> {
        val lineage = reportJson.optJSONObject("scientificDiscoveryLineageReport") ?: JSONObject()
        if (!lineage.optBoolean("active", false)) return emptyList()
        val evidence = mutableListOf<String>()
        evidence += jsonArrayToList(lineage.optJSONArray("forcedEvidenceKeys"))
        evidence += jsonArrayToList(lineage.optJSONArray("contradictionCarryForward")).map { evidenceKeyFromGap(it) }
        val cards = lineage.optJSONArray("hypothesisLineages")
        if (cards != null) {
            for (i in 0 until cards.length().coerceAtMost(5)) {
                val card = cards.optJSONObject(i) ?: continue
                evidence += jsonArrayToList(card.optJSONArray("parentEvidence"))
                evidence += jsonArrayToList(card.optJSONArray("contradictions")).map { evidenceKeyFromGap(it) }
                evidence += evidenceKeyFromGap(card.optString("nextLineageTest", ""))
            }
        }
        return mergeEvidenceKeys(evidence)
    }

    private fun extractV186OutcomeVerifierTerms(reportJson: JSONObject): List<String> {
        val terms = mutableListOf<String>()
        val verifier = reportJson.optJSONObject("scientificDiscoveryOutcomeVerifierReport") ?: JSONObject()
        if (!verifier.optBoolean("active", false)) return emptyList()
        terms += jsonArrayToList(verifier.optJSONArray("forcedNextEvidence")).flatMap { evidenceToSearchTerms(listOf(it)) }
        terms += jsonArrayToList(verifier.optJSONArray("unmetEvidenceKeys")).flatMap { evidenceToSearchTerms(listOf(it)) }
        terms += jsonArrayToList(verifier.optJSONArray("blockedReplayKeys")).flatMap { compactQueryTokens(it, 8) }
        terms += compactQueryTokens(verifier.optString("routeAdjustment", ""), 12)
        terms += compactQueryTokens(verifier.optString("nextPolicyAdjustment", ""), 12)
        return terms.distinctBy { it.lowercase(Locale.US) }.take(40)
    }

    private fun extractV186OutcomeVerifierEvidence(reportJson: JSONObject): List<String> {
        val evidence = mutableListOf<String>()
        val verifier = reportJson.optJSONObject("scientificDiscoveryOutcomeVerifierReport") ?: JSONObject()
        if (!verifier.optBoolean("active", false)) return emptyList()
        evidence += jsonArrayToList(verifier.optJSONArray("forcedNextEvidence"))
        evidence += jsonArrayToList(verifier.optJSONArray("unmetEvidenceKeys"))
        evidence += jsonArrayToList(verifier.optJSONArray("blockedReplayKeys")).map { evidenceKeyFromGap(it) }
        val adjustment = verifier.optString("nextPolicyAdjustment", "")
        if (adjustment.contains("outcome", true)) evidence += "outcome_labels"
        if (adjustment.contains("control", true) || adjustment.contains("comparator", true)) evidence += "comparator_control"
        if (adjustment.contains("time", true) || adjustment.contains("longitudinal", true)) evidence += "time_order"
        if (adjustment.contains("falsification", true) || adjustment.contains("contradiction", true)) evidence += "falsification_contradiction"
        return mergeEvidenceKeys(evidence)
    }

    private fun buildV184StressTestReason(reportJson: JSONObject): String {
        val stress = reportJson.optJSONObject("scientificDiscoveryStressTestReport") ?: JSONObject()
        if (!stress.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Stress-test=${stress.optString("version", "v1.8.4")}; state=${stress.optString("stressState", "NOT_RUN")}; scenario=${stress.optString("selectedScenario", "none")}")
            val pass = jsonArrayToList(stress.optJSONArray("passSignals")).take(3).joinToString("/")
            if (pass.isNotBlank()) add("pass=$pass")
            val fail = jsonArrayToList(stress.optJSONArray("failSignals")).take(3).joinToString("/")
            if (fail.isNotBlank()) add("fail=$fail")
            val nullPolicy = stress.optString("nullResultPolicy", "")
            if (nullPolicy.isNotBlank()) add("null-policy=${nullPolicy.take(160)}")
        }
        return "v1.8.4 counterfactual discovery stress test: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV184StressTestTerms(reportJson: JSONObject): List<String> {
        val terms = mutableListOf<String>()
        val stress = reportJson.optJSONObject("scientificDiscoveryStressTestReport") ?: JSONObject()
        if (!stress.optBoolean("active", false)) return emptyList()
        terms += jsonArrayToList(stress.optJSONArray("forcedNextTerms"))
        terms += compactQueryTokens(stress.optString("selectedScenario", ""), 6)
        terms += jsonArrayToList(stress.optJSONArray("passSignals")).flatMap { compactQueryTokens(it, 6) }
        terms += jsonArrayToList(stress.optJSONArray("failSignals")).flatMap { compactQueryTokens(it, 6) }
        terms += jsonArrayToList(stress.optJSONArray("branchActions")).flatMap { compactQueryTokens(it, 10) }
        terms += compactQueryTokens(stress.optString("contradictionPolicy", ""), 10)
        return terms.distinctBy { it.lowercase(Locale.US) }.take(44)
    }

    private fun extractV184StressTestEvidence(reportJson: JSONObject): List<String> {
        val evidence = mutableListOf<String>()
        val stress = reportJson.optJSONObject("scientificDiscoveryStressTestReport") ?: JSONObject()
        if (!stress.optBoolean("active", false)) return emptyList()
        evidence += jsonArrayToList(stress.optJSONArray("forcedEvidenceKeys"))
        evidence += jsonArrayToList(stress.optJSONArray("passSignals")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(stress.optJSONArray("failSignals")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(stress.optJSONArray("routeCooldownSignals")).map { evidenceKeyFromGap(it) }
        val nullPolicy = stress.optString("nullResultPolicy", "")
        if (nullPolicy.contains("outcome", true)) evidence += "outcome_labels"
        if (nullPolicy.contains("control", true) || nullPolicy.contains("comparator", true)) evidence += "comparator_control"
        if (nullPolicy.contains("time", true)) evidence += "time_order"
        val contradiction = stress.optString("contradictionPolicy", "")
        if (contradiction.contains("negative", true) || contradiction.contains("contradiction", true)) evidence += "falsification_contradiction"
        return mergeEvidenceKeys(evidence)
    }

    private fun extractV17ControlTerms(reportJson: JSONObject): List<String> {
        val terms = mutableListOf<String>()
        val evidenceGain = reportJson.optJSONObject("evidenceGainQueryRankerReport") ?: JSONObject()
        if (evidenceGain.optBoolean("active", false)) {
            terms += compactQueryTokens(evidenceGain.optString("chosenQuery", ""), 14)
            val scores = evidenceGain.optJSONArray("scores")
            if (scores != null && scores.length() > 0) {
                val top = scores.optJSONObject(0) ?: JSONObject()
                terms += jsonArrayToList(top.optJSONArray("closesGaps")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
            }
        }
        val causal = reportJson.optJSONObject("causalReadinessReport") ?: JSONObject()
        terms += jsonArrayToList(causal.optJSONArray("blockers")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
        val peer = reportJson.optJSONObject("miniPeerReviewReport") ?: JSONObject()
        terms += jsonArrayToList(peer.optJSONArray("missingEvidence")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
        terms += compactQueryTokens(peer.optString("falsificationTest", ""), 8)
        val reflection = reportJson.optJSONObject("reflectionLessonReport") ?: JSONObject()
        terms += compactQueryTokens(reflection.optString("prevention", ""), 10)
        return terms.distinctBy { it.lowercase(Locale.US) }.take(32)
    }

    private fun extractV17RequiredEvidence(reportJson: JSONObject): List<String> {
        val evidence = mutableListOf<String>()
        val evidenceGain = reportJson.optJSONObject("evidenceGainQueryRankerReport") ?: JSONObject()
        val scores = evidenceGain.optJSONArray("scores")
        if (scores != null && scores.length() > 0) {
            val top = scores.optJSONObject(0) ?: JSONObject()
            evidence += jsonArrayToList(top.optJSONArray("closesGaps")).map { evidenceKeyFromGap(it) }
            evidence += jsonArrayToList(top.optJSONArray("testsBeliefs")).map { evidenceKeyFromGap(it) }
        }
        val causal = reportJson.optJSONObject("causalReadinessReport") ?: JSONObject()
        evidence += jsonArrayToList(causal.optJSONArray("blockers")).map { evidenceKeyFromGap(it) }
        val peer = reportJson.optJSONObject("miniPeerReviewReport") ?: JSONObject()
        evidence += jsonArrayToList(peer.optJSONArray("missingEvidence")).map { evidenceKeyFromGap(it) }
        val contracts = (reportJson.optJSONObject("beliefFalsificationContractReport") ?: JSONObject()).optJSONArray("contracts")
        if (contracts != null) {
            for (i in 0 until contracts.length().coerceAtMost(4)) {
                val contract = contracts.optJSONObject(i) ?: continue
                if (!contract.optBoolean("routingAllowed", true)) {
                    evidence += jsonArrayToList(contract.optJSONArray("nextEvidenceRequired")).map { evidenceKeyFromGap(it) }
                }
            }
        }
        val reflection = reportJson.optJSONObject("reflectionLessonReport") ?: JSONObject()
        val prevention = reflection.optString("prevention", "")
        if (prevention.contains("outcome", true)) evidence += "outcome_labels"
        if (prevention.contains("time", true)) evidence += "time_order"
        if (prevention.contains("control", true) || prevention.contains("comparator", true)) evidence += "comparator_control"
        if (prevention.contains("metadata", true)) evidence += "minimum_metadata"
        return mergeEvidenceKeys(evidence)
    }

    private fun buildV188GapMinerReason(reportJson: JSONObject): String {
        val miner = reportJson.optJSONObject("scientificDiscoveryGapMinerReport") ?: JSONObject()
        if (!miner.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Gap-miner=${miner.optString("version", "v1.8.8")}; state=${miner.optString("minerState", "NOT_RUN")}; score=${miner.optInt("opportunityScore", 0)}/100")
            val top = miner.optString("topOpportunity", "")
            if (top.isNotBlank() && top != "none") add("top=${top.take(160)}")
            val blocked = jsonArrayToList(miner.optJSONArray("blockedBy")).take(3).joinToString("/")
            if (blocked.isNotBlank()) add("blocked=$blocked")
            val probe = miner.optString("nextDiscoveryProbe", "")
            if (probe.isNotBlank()) add("probe=${probe.take(180)}")
        }
        return "v1.8.8 latent discovery gap miner: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV188GapMinerTerms(reportJson: JSONObject): List<String> {
        val miner = reportJson.optJSONObject("scientificDiscoveryGapMinerReport") ?: JSONObject()
        if (!miner.optBoolean("active", false)) return emptyList()
        val terms = mutableListOf<String>()
        terms += jsonArrayToList(miner.optJSONArray("forcedDirectiveTerms"))
        terms += compactQueryTokens(miner.optString("nextDiscoveryProbe", ""), 18)
        terms += jsonArrayToList(miner.optJSONArray("unaskedBridgeQuestions")).flatMap { compactQueryTokens(it, 10) }
        val opportunities = miner.optJSONArray("latentOpportunities")
        if (opportunities != null) {
            for (i in 0 until opportunities.length().coerceAtMost(5)) {
                val card = opportunities.optJSONObject(i) ?: continue
                terms += compactQueryTokens(card.optString("probeQuery", ""), 14)
                terms += compactQueryTokens(card.optString("label", ""), 8)
            }
        }
        return terms.distinctBy { it.lowercase(Locale.US) }.take(48)
    }

    private fun extractV188GapMinerEvidence(reportJson: JSONObject): List<String> {
        val miner = reportJson.optJSONObject("scientificDiscoveryGapMinerReport") ?: JSONObject()
        if (!miner.optBoolean("active", false)) return emptyList()
        val evidence = mutableListOf<String>()
        evidence += jsonArrayToList(miner.optJSONArray("forcedEvidenceKeys"))
        evidence += jsonArrayToList(miner.optJSONArray("missingButHighValueEvidence"))
        evidence += jsonArrayToList(miner.optJSONArray("blockedBy")).map { evidenceKeyFromGap(it) }
        val opportunities = miner.optJSONArray("latentOpportunities")
        if (opportunities != null) {
            for (i in 0 until opportunities.length().coerceAtMost(5)) {
                val card = opportunities.optJSONObject(i) ?: continue
                evidence += jsonArrayToList(card.optJSONArray("missingEvidence"))
                evidence += jsonArrayToList(card.optJSONArray("promoteIf")).map { evidenceKeyFromGap(it) }
                evidence += jsonArrayToList(card.optJSONArray("killIf")).map { evidenceKeyFromGap(it) }
            }
        }
        return mergeEvidenceKeys(evidence)
    }

    private fun buildV189ProbePlanReason(reportJson: JSONObject): String {
        val plan = reportJson.optJSONObject("scientificDiscoveryProbePlanReport") ?: JSONObject()
        if (!plan.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Probe-plan=${plan.optString("version", "v1.8.9")}; state=${plan.optString("plannerState", "NOT_RUN")}; budget=${plan.optInt("probeBudget", 0)}")
            val probe = plan.optString("selectedProbeId", "")
            if (probe.isNotBlank() && probe != "none") add("probe=$probe")
            val query = plan.optString("selectedProbeQuery", "")
            if (query.isNotBlank()) add("query=${query.take(180)}")
            val kill = jsonArrayToList(plan.optJSONArray("killCriteria")).take(3).joinToString("/")
            if (kill.isNotBlank()) add("kill=$kill")
        }
        return "v1.8.9 executable discovery probe plan: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV189ProbePlanTerms(reportJson: JSONObject): List<String> {
        val plan = reportJson.optJSONObject("scientificDiscoveryProbePlanReport") ?: JSONObject()
        if (!plan.optBoolean("active", false)) return emptyList()
        val terms = mutableListOf<String>()
        terms += jsonArrayToList(plan.optJSONArray("forcedDirectiveTerms"))
        terms += compactQueryTokens(plan.optString("selectedProbeQuery", ""), 22)
        terms += jsonArrayToList(plan.optJSONArray("evidencePack")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
        val steps = plan.optJSONArray("probeSteps")
        if (steps != null) {
            for (i in 0 until steps.length().coerceAtMost(4)) {
                val step = steps.optJSONObject(i) ?: continue
                terms += compactQueryTokens(step.optString("query", ""), 18)
                terms += compactQueryTokens(step.optString("label", ""), 8)
            }
        }
        return terms.distinctBy { it.lowercase(Locale.US) }.take(56)
    }

    private fun extractV189ProbePlanEvidence(reportJson: JSONObject): List<String> {
        val plan = reportJson.optJSONObject("scientificDiscoveryProbePlanReport") ?: JSONObject()
        if (!plan.optBoolean("active", false)) return emptyList()
        val evidence = mutableListOf<String>()
        evidence += jsonArrayToList(plan.optJSONArray("forcedEvidenceKeys"))
        evidence += jsonArrayToList(plan.optJSONArray("evidencePack"))
        evidence += jsonArrayToList(plan.optJSONArray("passCriteria")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(plan.optJSONArray("failCriteria")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(plan.optJSONArray("killCriteria")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(plan.optJSONArray("replayBlockKeys"))
        val steps = plan.optJSONArray("probeSteps")
        if (steps != null) {
            for (i in 0 until steps.length().coerceAtMost(4)) {
                val step = steps.optJSONObject(i) ?: continue
                evidence += jsonArrayToList(step.optJSONArray("requiredEvidence"))
                evidence += jsonArrayToList(step.optJSONArray("killRouteIf")).map { evidenceKeyFromGap(it) }
            }
        }
        return mergeEvidenceKeys(evidence)
    }


    private fun buildV190ProbeOutcomeLedgerReason(reportJson: JSONObject): String {
        val ledger = reportJson.optJSONObject("scientificDiscoveryProbeOutcomeLedgerReport") ?: JSONObject()
        if (!ledger.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Probe-outcome=${ledger.optString("version", "v1.9.0")}; state=${ledger.optString("ledgerState", "NOT_RUN")}; closure=${ledger.optInt("evidenceClosureScore", 0)}/100")
            val prev = ledger.optString("previousProbeId", "")
            if (prev.isNotBlank() && prev != "none") add("previous=$prev")
            val unresolved = jsonArrayToList(ledger.optJSONArray("unresolvedEvidenceKeys")).take(4).joinToString("/")
            if (unresolved.isNotBlank()) add("unresolved=$unresolved")
            val next = ledger.optString("nextProbeDecision", "")
            if (next.isNotBlank()) add("next=${next.take(180)}")
        }
        return "v1.9.0 probe outcome learning ledger: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV190ProbeOutcomeLedgerTerms(reportJson: JSONObject): List<String> {
        val ledger = reportJson.optJSONObject("scientificDiscoveryProbeOutcomeLedgerReport") ?: JSONObject()
        if (!ledger.optBoolean("active", false)) return emptyList()
        val terms = mutableListOf<String>()
        terms += jsonArrayToList(ledger.optJSONArray("forcedDirectiveTerms"))
        terms += compactQueryTokens(ledger.optString("previousProbeQuery", ""), 18)
        terms += compactQueryTokens(ledger.optString("nextProbeDecision", ""), 18)
        terms += jsonArrayToList(ledger.optJSONArray("unresolvedEvidenceKeys")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
        terms += jsonArrayToList(ledger.optJSONArray("closedEvidenceKeys")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
        return terms.distinctBy { it.lowercase(Locale.US) }.take(56)
    }

    private fun extractV190ProbeOutcomeLedgerEvidence(reportJson: JSONObject): List<String> {
        val ledger = reportJson.optJSONObject("scientificDiscoveryProbeOutcomeLedgerReport") ?: JSONObject()
        if (!ledger.optBoolean("active", false)) return emptyList()
        val evidence = mutableListOf<String>()
        evidence += jsonArrayToList(ledger.optJSONArray("forcedEvidenceKeys"))
        evidence += jsonArrayToList(ledger.optJSONArray("unresolvedEvidenceKeys"))
        evidence += jsonArrayToList(ledger.optJSONArray("replayPenaltyKeys"))
        val failSignals = ledger.optJSONArray("failSignals")
        if (failSignals != null) {
            for (i in 0 until failSignals.length().coerceAtMost(8)) {
                val signal = failSignals.optJSONObject(i) ?: continue
                evidence += signal.optString("evidenceKey", "")
            }
        }
        val killSignals = ledger.optJSONArray("killSignals")
        if (killSignals != null) {
            for (i in 0 until killSignals.length().coerceAtMost(8)) {
                val signal = killSignals.optJSONObject(i) ?: continue
                evidence += signal.optString("evidenceKey", "")
            }
        }
        return mergeEvidenceKeys(evidence)
    }


    private fun buildV191MetaStrategyReason(reportJson: JSONObject): String {
        val governor = reportJson.optJSONObject("scientificDiscoveryMetaStrategyReport") ?: JSONObject()
        if (!governor.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Meta-strategy=${governor.optString("version", "v1.9.1")}; state=${governor.optString("strategyState", "NOT_RUN")}; score=${governor.optInt("governorScore", 0)}/100")
            add("mode=${governor.optString("explorationExploitationMode", "BALANCED_GUARDED")}; budget=${governor.optInt("routeBudget", 1)}")
            val selected = governor.optString("selectedStrategy", "")
            if (selected.isNotBlank()) add("selected=${selected.take(160)}")
            val blocked = jsonArrayToList(governor.optJSONArray("blockedMoves")).take(4).joinToString("/")
            if (blocked.isNotBlank()) add("blocked=$blocked")
            val deep = governor.optString("deepThinkPermission", "")
            if (deep.isNotBlank()) add("deepThink=$deep")
        }
        return "v1.9.1 meta-strategy governor: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV191MetaStrategyTerms(reportJson: JSONObject): List<String> {
        val governor = reportJson.optJSONObject("scientificDiscoveryMetaStrategyReport") ?: JSONObject()
        if (!governor.optBoolean("active", false)) return emptyList()
        val terms = mutableListOf<String>()
        terms += jsonArrayToList(governor.optJSONArray("forcedDirectiveTerms"))
        terms += compactQueryTokens(governor.optString("selectedStrategy", ""), 18)
        terms += compactQueryTokens(governor.optString("continuationDecision", ""), 18)
        terms += jsonArrayToList(governor.optJSONArray("allowedMoves")).flatMap { compactQueryTokens(it, 8) }
        terms += jsonArrayToList(governor.optJSONArray("forcedEvidenceKeys")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
        val moves = governor.optJSONArray("strategyMoves")
        if (moves != null) {
            for (i in 0 until moves.length().coerceAtMost(4)) {
                val move = moves.optJSONObject(i) ?: continue
                terms += compactQueryTokens(move.optString("reason", ""), 12)
                terms += jsonArrayToList(move.optJSONArray("queryTerms"))
            }
        }
        return terms.distinctBy { it.lowercase(Locale.US) }.take(64)
    }

    private fun extractV191MetaStrategyEvidence(reportJson: JSONObject): List<String> {
        val governor = reportJson.optJSONObject("scientificDiscoveryMetaStrategyReport") ?: JSONObject()
        if (!governor.optBoolean("active", false)) return emptyList()
        val evidence = mutableListOf<String>()
        evidence += jsonArrayToList(governor.optJSONArray("forcedEvidenceKeys"))
        evidence += jsonArrayToList(governor.optJSONArray("blockedMoves")).map { evidenceKeyFromGap(it) }
        val moves = governor.optJSONArray("strategyMoves")
        if (moves != null) {
            for (i in 0 until moves.length().coerceAtMost(5)) {
                val move = moves.optJSONObject(i) ?: continue
                evidence += jsonArrayToList(move.optJSONArray("evidenceKeys"))
            }
        }
        return mergeEvidenceKeys(evidence)
    }

    private fun buildV192QualityGateReason(reportJson: JSONObject): String {
        val gate = reportJson.optJSONObject("scientificDiscoveryQualityGateReport") ?: JSONObject()
        if (!gate.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Quality gate=${gate.optString("version", "v1.9.2")}; state=${gate.optString("gateState", "NOT_RUN")}; score=${gate.optInt("qualityScore", 0)}/100; allow=${gate.optBoolean("allowExecution", false)}")
            val decision = gate.optString("executionDecision", "")
            if (decision.isNotBlank()) add("decision=${decision.take(180)}")
            val disposition = gate.optString("routeDisposition", "")
            if (disposition.isNotBlank()) add("route=$disposition")
            val blocked = jsonArrayToList(gate.optJSONArray("blockedBecause")).take(4).joinToString("/")
            if (blocked.isNotBlank()) add("blocked=$blocked")
        }
        return "v1.9.2 discovery quality gate: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV192QualityGateTerms(reportJson: JSONObject): List<String> {
        val gate = reportJson.optJSONObject("scientificDiscoveryQualityGateReport") ?: JSONObject()
        if (!gate.optBoolean("active", false)) return emptyList()
        val terms = mutableListOf<String>()
        terms += jsonArrayToList(gate.optJSONArray("forcedDirectiveTerms"))
        terms += compactQueryTokens(gate.optString("executionDecision", ""), 20)
        terms += compactQueryTokens(gate.optString("routeDisposition", ""), 8)
        terms += jsonArrayToList(gate.optJSONArray("requiredBeforeRun")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
        val issues = gate.optJSONArray("qualityIssues")
        if (issues != null) {
            for (i in 0 until issues.length().coerceAtMost(6)) {
                val issue = issues.optJSONObject(i) ?: continue
                terms += compactQueryTokens(issue.optString("label", ""), 10)
                terms += jsonArrayToList(issue.optJSONArray("queryTerms"))
            }
        }
        return terms.distinctBy { it.lowercase(Locale.US) }.take(72)
    }

    private fun extractV192QualityGateEvidence(reportJson: JSONObject): List<String> {
        val gate = reportJson.optJSONObject("scientificDiscoveryQualityGateReport") ?: JSONObject()
        if (!gate.optBoolean("active", false)) return emptyList()
        val evidence = mutableListOf<String>()
        evidence += jsonArrayToList(gate.optJSONArray("forcedEvidenceKeys"))
        evidence += jsonArrayToList(gate.optJSONArray("requiredBeforeRun"))
        val issues = gate.optJSONArray("qualityIssues")
        if (issues != null) {
            for (i in 0 until issues.length().coerceAtMost(8)) {
                val issue = issues.optJSONObject(i) ?: continue
                evidence += issue.optString("evidenceKey", "")
                evidence += issue.optString("requiredBeforeRun", "")
            }
        }
        return mergeEvidenceKeys(evidence)
    }


    private fun buildV193RunbookReason(reportJson: JSONObject): String {
        val runbook = reportJson.optJSONObject("scientificDiscoveryRunbookReport") ?: JSONObject()
        if (!runbook.optBoolean("active", false)) return ""
        val parts = buildList {
            add("Runbook=${runbook.optString("version", "v1.9.3")}; state=${runbook.optString("runbookState", "NOT_RUN")}; mode=${runbook.optString("selectedRunMode", "NO_RUNBOOK")}; budget=${runbook.optInt("executionBudget", 0)}")
            val query = runbook.optString("primaryQueryClause", "")
            if (query.isNotBlank()) add("query=${query.take(180)}")
            val routeDecision = runbook.optString("routeDecision", "")
            if (routeDecision.isNotBlank()) add("route=${routeDecision.take(180)}")
            val hardStops = jsonArrayToList(runbook.optJSONArray("hardStops")).take(3).joinToString("/")
            if (hardStops.isNotBlank()) add("hardStops=$hardStops")
            val replay = jsonArrayToList(runbook.optJSONArray("blockedReplayKeys")).take(3).joinToString("/")
            if (replay.isNotBlank()) add("replay-block=$replay")
        }
        return "v1.9.3 executable quality runbook: ${parts.joinToString(" ")}".take(900)
    }

    private fun extractV193RunbookTerms(reportJson: JSONObject): List<String> {
        val runbook = reportJson.optJSONObject("scientificDiscoveryRunbookReport") ?: JSONObject()
        if (!runbook.optBoolean("active", false)) return emptyList()
        val terms = mutableListOf<String>()
        terms += jsonArrayToList(runbook.optJSONArray("forcedDirectiveTerms"))
        terms += compactQueryTokens(runbook.optString("primaryQueryClause", ""), 28)
        terms += compactQueryTokens(runbook.optString("selectedRunMode", ""), 8)
        terms += compactQueryTokens(runbook.optString("routeDecision", ""), 18)
        terms += jsonArrayToList(runbook.optJSONArray("evidenceChecklist")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
        terms += jsonArrayToList(runbook.optJSONArray("hardStops")).flatMap { compactQueryTokens(it, 10) }
        terms += jsonArrayToList(runbook.optJSONArray("passSignals")).flatMap { compactQueryTokens(it, 8) }
        terms += jsonArrayToList(runbook.optJSONArray("failSignals")).flatMap { compactQueryTokens(it, 8) }
        terms += jsonArrayToList(runbook.optJSONArray("blockedReplayKeys")).flatMap { compactQueryTokens(it, 8) }
        val steps = runbook.optJSONArray("runbookSteps")
        if (steps != null) {
            for (i in 0 until steps.length().coerceAtMost(5)) {
                val step = steps.optJSONObject(i) ?: continue
                terms += compactQueryTokens(step.optString("queryClause", ""), 20)
                terms += compactQueryTokens(step.optString("label", ""), 8)
                terms += compactQueryTokens(step.optString("action", ""), 8)
            }
        }
        return terms.distinctBy { it.lowercase(Locale.US) }.take(72)
    }

    private fun extractV193RunbookEvidence(reportJson: JSONObject): List<String> {
        val runbook = reportJson.optJSONObject("scientificDiscoveryRunbookReport") ?: JSONObject()
        if (!runbook.optBoolean("active", false)) return emptyList()
        val evidence = mutableListOf<String>()
        evidence += jsonArrayToList(runbook.optJSONArray("forcedEvidenceKeys"))
        evidence += jsonArrayToList(runbook.optJSONArray("evidenceChecklist"))
        evidence += jsonArrayToList(runbook.optJSONArray("hardStops")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(runbook.optJSONArray("passSignals")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(runbook.optJSONArray("failSignals")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(runbook.optJSONArray("blockedReplayKeys"))
        val steps = runbook.optJSONArray("runbookSteps")
        if (steps != null) {
            for (i in 0 until steps.length().coerceAtMost(6)) {
                val step = steps.optJSONObject(i) ?: continue
                evidence += jsonArrayToList(step.optJSONArray("requiredEvidence"))
                evidence += jsonArrayToList(step.optJSONArray("passIf")).map { evidenceKeyFromGap(it) }
                evidence += jsonArrayToList(step.optJSONArray("stopIf")).map { evidenceKeyFromGap(it) }
                evidence += jsonArrayToList(step.optJSONArray("prevents")).map { evidenceKeyFromGap(it) }
            }
        }
        return mergeEvidenceKeys(evidence)
    }

    private fun extractV18DiscoveryTerms(reportJson: JSONObject): List<String> {
        val terms = mutableListOf<String>()
        val index = reportJson.optJSONObject("scientificKnowledgeIndexReport") ?: JSONObject()
        if (index.optBoolean("active", false)) {
            terms += jsonArrayToList(index.optJSONArray("routeHints")).flatMap { compactQueryTokens(it, 8) }
            terms += jsonArrayToList(index.optJSONArray("evidenceRequirements")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
            val matched = index.optJSONArray("matchedTerms")
            if (matched != null) {
                for (i in 0 until matched.length().coerceAtMost(8)) {
                    val term = matched.optJSONObject(i) ?: continue
                    if (term.optBoolean("matched", false)) {
                        terms += compactQueryTokens(term.optString("label", ""), 4)
                        terms += jsonArrayToList(term.optJSONArray("queryHints")).flatMap { compactQueryTokens(it, 6) }
                    }
                }
            }
        }
        val deep = reportJson.optJSONObject("deepDiscoveryReasoningReport") ?: JSONObject()
        if (deep.optBoolean("active", false)) {
            terms += compactQueryTokens(deep.optString("nextDiscoveryMove", ""), 14)
            val decisive = deep.optJSONObject("decisiveExperiment") ?: JSONObject()
            terms += compactQueryTokens(decisive.optString("nextQuery", ""), 18)
            terms += jsonArrayToList(decisive.optJSONArray("requiredDatasetFeatures")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
            val contradiction = deep.optJSONObject("contradictionPlan") ?: JSONObject()
            terms += jsonArrayToList(contradiction.optJSONArray("contradictionQueries")).flatMap { compactQueryTokens(it, 10) }
            terms += jsonArrayToList(contradiction.optJSONArray("negativeControls")).flatMap { compactQueryTokens(it, 6) }
            val bridges = deep.optJSONArray("crossAxisBridgeReport")
            if (bridges != null) {
                for (i in 0 until bridges.length().coerceAtMost(3)) {
                    val bridge = bridges.optJSONObject(i) ?: continue
                    terms += compactQueryTokens(bridge.optString("bridgeQuestion", ""), 10)
                    terms += jsonArrayToList(bridge.optJSONArray("evidenceNeeded")).flatMap { evidenceToSearchTerms(listOf(evidenceKeyFromGap(it))) }
                }
            }
            val think = deep.optJSONObject("deepThinkSession") ?: JSONObject()
            if (think.optBoolean("active", false)) {
                terms += compactQueryTokens(think.optString("nextQuery", ""), 14)
                terms += compactQueryTokens(think.optString("falsificationPath", ""), 10)
            }
        }
        return terms.distinctBy { it.lowercase(Locale.US) }.take(40)
    }

    private fun extractV18RequiredEvidence(reportJson: JSONObject): List<String> {
        val evidence = mutableListOf<String>()
        val index = reportJson.optJSONObject("scientificKnowledgeIndexReport") ?: JSONObject()
        evidence += jsonArrayToList(index.optJSONArray("evidenceRequirements")).map { evidenceKeyFromGap(it) }
        val deep = reportJson.optJSONObject("deepDiscoveryReasoningReport") ?: JSONObject()
        val decisive = deep.optJSONObject("decisiveExperiment") ?: JSONObject()
        evidence += jsonArrayToList(decisive.optJSONArray("requiredDatasetFeatures")).map { evidenceKeyFromGap(it) }
        evidence += jsonArrayToList(decisive.optJSONArray("strengthenIf")).map { evidenceKeyFromGap(it) }
        val contradiction = deep.optJSONObject("contradictionPlan") ?: JSONObject()
        evidence += jsonArrayToList(contradiction.optJSONArray("falsificationTargets")).map { evidenceKeyFromGap(it) }
        val novelty = deep.optJSONObject("noveltyReport") ?: JSONObject()
        evidence += jsonArrayToList(novelty.optJSONArray("whyNotYetDiscovery")).map { evidenceKeyFromGap(it) }
        val think = deep.optJSONObject("deepThinkSession") ?: JSONObject()
        if (think.optBoolean("active", false)) {
            evidence += listOf("falsification_lane", "minimum_metadata", "outcome_labels")
        }
        return mergeEvidenceKeys(evidence)
    }

    private fun evidenceKeyFromGap(raw: String): String {
        val text = raw.lowercase(Locale.US).replace("-", "_").replace(" ", "_")
        return when {
            text.contains("outcome") || text.contains("recovery") || text.contains("severity") || text.contains("endpoint") -> "outcome_labels"
            text.contains("time") || text.contains("temporal") || text.contains("longitudinal") || text.contains("follow") -> "time_order"
            text.contains("control") || text.contains("comparator") || text.contains("placebo") -> "comparator_control"
            text.contains("metadata") || text.contains("sample") || text.contains("phenotype") || text.contains("license") -> "minimum_metadata"
            text.contains("tissue") || text.contains("cell_type") || text.contains("cell") || text.contains("source") -> "tissue_cell_context"
            text.contains("batch") || text.contains("artifact") || text.contains("assay") -> "assay_batch_control"
            text.contains("human") || text.contains("patient") || text.contains("clinical") -> "human_or_patient_data"
            text.contains("intervention") || text.contains("perturbation") || text.contains("negative") || text.contains("contradiction") || text.contains("falsif") -> "falsification_lane"
            text.contains("viral") || text.contains("infection") -> "viral_load"
            text.contains("interferon") || text == "ifn" || text.contains("isg") -> "interferon_markers"
            text.contains("type2") || text.contains("ige") || text.contains("eosinophil") || text.contains("mast") -> "type2_markers"
            else -> text.take(80)
        }
    }

    private fun compactQueryTokens(text: String, limit: Int): List<String> {
        val allowed = setOf(
            "outcome", "recovery", "severity", "endpoint", "longitudinal", "time-course", "serial", "temporal", "follow-up",
            "control", "comparator", "placebo", "healthy", "negative", "metadata", "phenotype", "sample", "gse", "geo", "sra", "prjna",
            "human", "patient", "clinical", "rna-seq", "single-cell", "transcriptomic", "interferon", "ifn", "isg", "viral", "load", "replication", "validation",
            "cell", "cell-type", "tissue", "assay", "batch", "artifact", "bridge", "discriminator", "validation", "replication", "ige", "eosinophil", "mast", "il-4", "il-5", "il-13", "cytokine", "gene", "signature", "severity", "resolution"
        )
        return text.lowercase(Locale.US)
            .replace("rna seq", "rna-seq")
            .replace("single cell", "single-cell")
            .split(Regex("[^a-z0-9_-]+"))
            .map { it.trim() }
            .filter { it.length >= 3 }
            .filter { it in allowed || it.startsWith("gse") || it.startsWith("prjna") }
            .distinct()
            .take(limit)
    }

    private fun mergeDirectiveTerms(terms: List<String>): List<String> = terms
        .map { it.trim().lowercase(Locale.US) }
        .filter { it.length >= 3 }
        .filterNot { it in setOf("none", "unknown", "not evaluated") }
        .distinct()
        .take(36)

    private fun mergeEvidenceKeys(keys: List<String>): List<String> = keys
        .map { evidenceKeyFromGap(it) }
        .filter { it.length >= 3 }
        .filterNot { it in setOf("none", "unknown", "not_evaluated") }
        .distinct()
        .take(24)

    fun toJson(directive: CognitiveNextCycleDirective): JSONObject = JSONObject()
        .put("directiveId", directive.directiveId)
        .put("createdAtMillis", directive.createdAtMillis)
        .put("sourceCycleId", directive.sourceCycleId)
        .put("state", directive.state)
        .put("decisionType", directive.decisionType)
        .put("routeIntegrity", directive.routeIntegrity)
        .put("action", directive.action)
        .put("reason", directive.reason)
        .put("nextSearchTerms", JSONArray(directive.nextSearchTerms))
        .put("requiredEvidence", JSONArray(directive.requiredEvidence))
        .put("blockedClaims", JSONArray(directive.blockedClaims))
        .put("priority", directive.priority)
        .put("expiresAtMillis", directive.expiresAtMillis)
        .put("consumedCount", directive.consumedCount)
        .put("useLimit", directive.useLimit)
        .put("routingFingerprint", routingFingerprint(directive))
        .put("claimLimit", directive.claimLimit)

    fun fromJson(obj: JSONObject): CognitiveNextCycleDirective? {
        val id = obj.optString("directiveId")
        if (id.isBlank()) return null
        return runCatching {
            CognitiveNextCycleDirective(
                directiveId = id,
                createdAtMillis = obj.optLong("createdAtMillis", 0L),
                sourceCycleId = obj.optString("sourceCycleId", "cycle_unknown"),
                state = obj.optString("state", "UNKNOWN"),
                decisionType = obj.optString("decisionType", "FOLLOW_UP_REQUIRED"),
                routeIntegrity = obj.optString("routeIntegrity", "UNKNOWN_ROUTE_INTEGRITY"),
                action = obj.optString("action", "Run bounded follow-up."),
                reason = obj.optString("reason", "No reason saved."),
                nextSearchTerms = jsonArrayToList(obj.optJSONArray("nextSearchTerms")),
                requiredEvidence = jsonArrayToList(obj.optJSONArray("requiredEvidence")),
                blockedClaims = jsonArrayToList(obj.optJSONArray("blockedClaims")).ifEmpty { defaultBlockedClaims() },
                priority = obj.optInt("priority", 50).coerceIn(0, 100),
                expiresAtMillis = obj.optLong("expiresAtMillis", System.currentTimeMillis()),
                consumedCount = obj.optInt("consumedCount", 0).coerceAtLeast(0),
                useLimit = obj.optInt("useLimit", MAX_DIRECTIVE_USES).coerceAtLeast(1),
                claimLimit = obj.optString("claimLimit", "next_cycle_routing_only_not_biological_proof")
            )
        }.getOrNull()
    }

    fun markConsumed(directive: CognitiveNextCycleDirective): CognitiveNextCycleDirective = directive.copy(
        state = "CONSUMED",
        consumedCount = directive.consumedCount + 1
    )

    fun sameRoutingFingerprint(a: CognitiveNextCycleDirective, b: CognitiveNextCycleDirective): Boolean =
        routingFingerprint(a) == routingFingerprint(b)

    fun routingFingerprint(directive: CognitiveNextCycleDirective): String {
        val raw = listOf(
            directive.decisionType,
            directive.routeIntegrity,
            normalizedTerms(directive.nextSearchTerms).joinToString("|"),
            normalizedTerms(directive.requiredEvidence).joinToString("|")
        ).joinToString("::")
        return "route_${abs(raw.lowercase(Locale.US).hashCode())}"
    }

    fun applyToQueries(
        baseQueries: List<ResearchQuery>,
        directive: CognitiveNextCycleDirective?,
        maxQueries: Int
    ): Pair<List<ResearchQuery>, CognitiveNextCyclePlan> {
        if (directive == null) return baseQueries to CognitiveNextCyclePlan.none("No integrated cognitive next-cycle directive was available.")
        if (directive.isExpired()) return baseQueries to CognitiveNextCyclePlan.none("Integrated cognitive directive expired; normal planner kept control.")
        if (directive.isConsumed()) return baseQueries to CognitiveNextCyclePlan.none("Integrated cognitive directive already consumed once; replay blocked to prevent query inflation.")
        if (baseQueries.isEmpty()) return baseQueries to CognitiveNextCyclePlan.none("No base query batch available for cognitive follow-up.")

        val candidateTerms = normalizedTerms(directive.nextSearchTerms + evidenceToSearchTerms(directive.requiredEvidence))
        if (candidateTerms.isEmpty()) {
            return baseQueries to consumedNoopPlan(
                directive = directive,
                reason = "Directive did not contain usable search terms; retiring it to avoid repeated no-op cycles."
            )
        }

        val existingQueryText = baseQueries.joinToString(" ") { it.query }
        val missingTerms = candidateTerms.filterNot { term -> containsNormalized(existingQueryText, term) }.take(16)
        if (missingTerms.isEmpty()) {
            return baseQueries to consumedNoopPlan(
                directive = directive,
                reason = "Directive terms were already covered by the current query batch; retiring satisfied directive to prevent replay."
            )
        }

        val followUpQuery = buildFollowUpQuery(directive, missingTerms)
        val annotated = baseQueries.mapIndexed { index, query ->
            if (index == 0) {
                val merged = mergeTerms(query.query, missingTerms.take(MAX_TERMS_APPLIED_TO_BASE_QUERY))
                query.copy(
                    query = merged,
                    reason = (query.reason + " v1.8.3 decision-memory cognitive next-cycle bridge: ${directive.decisionType}; ${directive.action}").take(650)
                )
            } else query
        }
        val withFollowUp = (listOf(followUpQuery) + annotated)
            .distinctBy { it.id }
            .take(maxQueries.coerceAtLeast(1))
        return withFollowUp to CognitiveNextCyclePlan(
            active = true,
            directiveId = directive.directiveId,
            appliedQueryCount = withFollowUp.size,
            addedFollowUpQuery = true,
            appliedTerms = missingTerms.take(16),
            blockedClaims = directive.blockedClaims,
            summary = "Applied single-use integrated cognitive path from ${directive.sourceCycleId}: ${directive.decisionType}; required=${directive.requiredEvidence.joinToString(", ").ifBlank { "none" }}.",
            suppressedReason = null,
            directiveConsumed = true,
            consumptionReason = "applied_follow_up_once",
            routingFingerprint = routingFingerprint(directive),
            useLimit = directive.useLimit
        )
    }

    private fun consumedNoopPlan(directive: CognitiveNextCycleDirective, reason: String): CognitiveNextCyclePlan = CognitiveNextCyclePlan(
        active = false,
        directiveId = directive.directiveId,
        appliedQueryCount = 0,
        addedFollowUpQuery = false,
        appliedTerms = emptyList(),
        blockedClaims = directive.blockedClaims,
        summary = reason,
        suppressedReason = reason,
        directiveConsumed = true,
        consumptionReason = "retired_noop_or_already_satisfied",
        routingFingerprint = routingFingerprint(directive),
        useLimit = directive.useLimit
    )

    private fun buildFollowUpQuery(directive: CognitiveNextCycleDirective, appliedTerms: List<String>): ResearchQuery {
        val query = appliedTerms
            .take(MAX_FOLLOW_UP_TERMS)
            .joinToString(" ")
            .ifBlank { "human immune dataset outcome labels longitudinal RNA-seq" }
        return ResearchQuery(
            id = "q_cognitive_path_followup_${directive.directiveId.takeLast(10)}",
            label = "COGNITIVE PATH FOLLOW-UP",
            query = query,
            reason = "Follow-up query from integrated map/belief/specialist/deep-discovery path. ${directive.reason.take(260)}"
        )
    }

    private fun mergeTerms(query: String, terms: List<String>): String {
        val tokens = query.split(Regex("\\s+")).filter { it.isNotBlank() }
        val merged = (tokens + terms).distinctBy { it.lowercase(Locale.US) }
        return merged.joinToString(" ").take(900)
    }

    private fun containsNormalized(text: String, term: String): Boolean {
        val haystack = text.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), " ").trim()
        val needle = term.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), " ").trim()
        if (needle.isBlank()) return true
        return haystack.contains(needle)
    }

    private fun normalizedTerms(terms: List<String>): List<String> = terms
        .flatMap { term -> term.replace("_", " ").split(";") }
        .map { it.trim().lowercase(Locale.US) }
        .filter { it.length >= 3 }
        .filterNot { it in setOf("none", "unknown", "not evaluated") }
        .distinct()
        .take(24)

    private fun evidenceToSearchTerms(requiredEvidence: List<String>): List<String> = requiredEvidence.flatMap { evidence ->
        when (evidence.lowercase(Locale.US).replace("-", "_")) {
            "minimum_metadata" -> listOf("sample metadata", "phenotype labels", "GSE", "GEO")
            // Keep this as concrete outcome-label evidence, not broad immune-response language.
            // v1.6.6/v1.6.7 replay guards treat a directive as satisfied when the current
            // batch already contains the outcome/severity/recovery/endpoint lane. Including
            // "response" here made an already-covered directive look missing and inflated the
            // next query batch, because "response" is often a generic pathway word rather than
            // an outcome-label marker.
            "outcome_labels" -> listOf("outcome", "recovery", "severity", "endpoint")
            "time_order", "time_course" -> listOf("longitudinal", "time-course", "serial", "temporal", "follow-up")
            "comparator_control", "controls_or_comparator" -> listOf("control", "comparator", "placebo", "healthy control")
            "falsification_lane" -> listOf("negative control", "validation cohort", "replication")
            "bridge_discriminator" -> listOf("bridge", "discriminator", "mechanism", "control")
            "parent_evidence" -> listOf("parent evidence", "lineage", "accession", "metadata")
            "replication_external_validation" -> listOf("replication", "validation cohort", "external cohort")
            "human_or_patient_data" -> listOf("human", "patient", "clinical cohort")
            "tissue_cell_context" -> listOf("cell type", "tissue source", "single-cell", "cell composition")
            "assay_batch_control" -> listOf("assay metadata", "batch effect", "technical control")
            "viral_load" -> listOf("viral load", "infection", "viral kinetics")
            "interferon_markers" -> listOf("interferon", "IFN", "interferon stimulated genes")
            "type2_markers" -> listOf("IgE", "eosinophil", "mast cell", "IL-4", "IL-5", "IL-13")
            else -> listOf(evidence.replace("_", " "))
        }
    }

    private fun priorityFor(decisionType: String, routeIntegrity: String, evidence: List<String>, warnings: JSONArray?): Int {
        var score = 50
        val text = "$decisionType $routeIntegrity ${evidence.joinToString(" ")}".lowercase(Locale.US)
        if ("block" in text || "requires" in text) score += 15
        if ("minimum_metadata" in text || "outcome_labels" in text) score += 15
        if ("retired" in text || "revise" in text) score += 10
        if ((warnings?.length() ?: 0) > 0) score += 5
        return score.coerceIn(0, 100)
    }

    private fun stableDirectiveId(cycleId: String, decisionType: String, terms: List<String>, evidence: List<String>): String {
        val raw = listOf(cycleId, decisionType, terms.joinToString("|"), evidence.joinToString("|"))
            .joinToString("|")
            .lowercase(Locale.US)
        return "cognitive_${abs(raw.hashCode())}"
    }

    private fun jsonArrayToList(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { idx -> array.optString(idx).trim().takeIf { it.isNotBlank() } }
    }
}

fun defaultBlockedClaims(): List<String> = listOf(
    "no_biological_proof",
    "no_hypothesis_upgrade_without_evidence_gates",
    "no_medical_or_diagnostic_claim",
    "no_foundation_json_auto_update"
)
