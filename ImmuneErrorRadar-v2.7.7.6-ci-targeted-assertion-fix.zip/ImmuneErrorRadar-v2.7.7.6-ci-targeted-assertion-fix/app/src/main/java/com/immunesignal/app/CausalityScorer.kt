package com.immunesignal.app

import java.util.Locale

object CausalityScorer {
    fun score(
        text: String,
        axes: List<String>,
        evidence: EvidenceAssessment,
        personal: PersonalPatternAssessment,
        // v0.9.1: integrate negative-control resistance into the numeric score.
        // Default keeps backward compatibility for any caller that hasn't yet
        // computed a preview status.
        negativeControlStatus: String = "weak_no_control_possible"
    ): CausalityAssessment {
        val t = text.lowercase(Locale.US)
        val temporality = when {
            listOf("before", "after", "preced", "follow-up", "longitudinal", "prospective", "time course", "lag").any { t.contains(it) } -> 55
            evidence.studyDesign.contains("cohort") || evidence.studyDesign.contains("trial") -> 50
            else -> 20
        }
        val (plausibility, graphNotes) = BiologicalPlausibilityGraph.plausibilityScore(axes)
        val measurable = measurableMarkerScore(text, axes)
        val repeatability = when {
            personal.repeatedObservationCount >= 3 -> 70
            personal.repeatedObservationCount == 2 -> 48
            personal.repeatedObservationCount == 1 -> 25
            else -> 10
        }
        val contradictionPenalty = when {
            t.contains("conflicting") || t.contains("inconsistent") || t.contains("controversial") -> 18
            t.contains("no association") || t.contains("not associated") -> 25
            else -> 5
        }
        val designBoost = when {
            evidence.studyDesign.contains("randomized") -> 10
            evidence.studyDesign.contains("cohort") -> 8
            evidence.studyDesign.contains("case_control") -> 3
            else -> 0
        }
        // v0.9.1: penalise causality when negative-control discipline is missing.
        // Aligns the numeric score with the README claim that
        // "negative-control resistance" is part of the upgrade rule.
        val negativeControlPenalty = when (negativeControlStatus) {
            "control_required_before_strong" -> 12
            "watch_requires_controls" -> 6
            else -> 0
        }
        val raw = (temporality * 0.22 + plausibility * 0.26 + measurable * 0.18 + repeatability * 0.18 + evidence.evidenceQualityScore * 0.16 + designBoost - contradictionPenalty - negativeControlPenalty).toInt()
        val rationale = mutableListOf<String>()
        rationale += "Temporality score: $temporality/100."
        rationale += "Biological plausibility: $plausibility/100."
        rationale += "Measurable marker support: $measurable/100."
        rationale += "Personal repeatability proxy: $repeatability/100."
        rationale += "Contradiction penalty: $contradictionPenalty."
        if (negativeControlPenalty > 0) {
            rationale += "Negative-control penalty: $negativeControlPenalty (status=$negativeControlStatus)."
        }
        rationale += graphNotes
        return CausalityAssessment(
            causalityScore = raw.coerceIn(0, 100),
            temporalityScore = temporality,
            biologicalPlausibilityScore = plausibility,
            measurableMarkerScore = measurable,
            repeatabilityScore = repeatability,
            contradictionPenalty = contradictionPenalty,
            rationale = rationale.distinct().take(8)
        )
    }

    private fun measurableMarkerScore(text: String, axes: List<String>): Int {
        val t = text.lowercase(Locale.US)
        var score = 15
        val markers = ScientificTermMarkerBank.markerTerms
        score += markers.count { t.contains(it) } * 8
        if (axes.contains("autonomic_vascular_axis")) score += 8
        if (axes.contains("rna_transcriptomic_axis") || axes.contains("dna_genomic_axis")) score += 10
        return score.coerceIn(0, 100)
    }
}
