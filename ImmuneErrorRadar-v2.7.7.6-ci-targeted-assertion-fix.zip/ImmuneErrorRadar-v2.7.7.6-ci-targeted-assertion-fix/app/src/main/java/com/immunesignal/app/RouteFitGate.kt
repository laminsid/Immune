package com.immunesignal.app

import java.util.Locale
import kotlin.math.roundToInt

/**
 * v1.4.4: Route-Fit Gate.
 *
 * Purpose: keep dataset usability separate from hypothesis fit. A dataset can be
 * technically excellent and still be off-route for the current biological
 * question. This prevents query contamination such as treating an allergy/skin
 * dataset as support for an antiviral/interferon timing hypothesis only because
 * the search query contained viral/interferon terms.
 */
object RouteFitGate {
    private data class RouteRule(val route: String, val keywords: List<String>)

    private val routeRules = listOf(
        RouteRule(
            route = "allergy_contact_dermatitis_il1_skin",
            keywords = listOf("nickel", "patch test", "contact dermatitis", "epidermal", "skin", "anakinra", "il-1", "il1", "allergic contact")
        ),
        RouteRule(
            route = "allergy_type2_airway_or_skin",
            keywords = listOf("allergy", "allergic", "asthma", "ige", "eosinophil", "mast cell", "allergen", "rhinitis")
        ),
        RouteRule(
            route = "antiviral_interferon_timing",
            keywords = listOf("viral infection", "virus", "viral", "influenza", "rsv", "covid", "sars-cov-2", "hantavirus", "interferon", "ifn", "viral load", "antiviral")
        ),
        RouteRule(
            route = "autoimmune_activity_regulatory",
            keywords = listOf("rheumatoid", "arthritis", "autoimmune", "lupus", "disease activity", "treg", "regulatory t")
        ),
        RouteRule(
            route = "hyperinflammation_tissue_damage",
            keywords = listOf("ards", "sepsis", "cytokine storm", "hyperinflammation", "tissue damage", "organ damage", "lung damage")
        ),
        RouteRule(
            route = "general_immune_omics",
            keywords = listOf("rna-seq", "transcriptomic", "single-cell", "scrna", "gene expression", "cohort", "dataset")
        )
    )

    fun evaluate(
        candidates: List<DatasetAccessionCandidate>,
        findings: List<ResearchFinding>,
        shards: List<TestableHypothesisShard>
    ): List<DatasetRouteFitAssessment> {
        val findingById = findings.associateBy { it.source + ":" + it.sourceId }
        return candidates.map { candidate ->
            val finding = findingById[candidate.sourceFindingId]
            val datasetText = listOf(
                candidate.accession,
                candidate.sourceTitle,
                candidate.conditionLabelsHint,
                candidate.outcomeLabelsHint,
                candidate.triggerResponseOutcomeHint,
                candidate.dataType,
                finding?.title.orEmpty()
            ).joinToString(" ")
            val datasetRoute = inferDatasetRoute(datasetText, finding?.matchedAxes.orEmpty())
            val targetRoute = inferTargetRoute(candidate, finding, shards)
            val fitScore = fitScore(datasetRoute, targetRoute, datasetText)
            val status = statusFor(fitScore, datasetRoute, targetRoute)
            val blocks = status == "OFF_ROUTE_DATASET" || status == "CROSS_DOMAIN_LEAD"
            DatasetRouteFitAssessment(
                accession = candidate.accession,
                datasetRoute = datasetRoute,
                targetRoute = targetRoute,
                routeFitScore = fitScore,
                status = status,
                allowedUse = allowedUse(status, datasetRoute, targetRoute),
                blocksHypothesisUpgrade = blocks,
                reasons = buildReasons(candidate, datasetRoute, targetRoute, fitScore, status)
            )
        }
    }

    fun separation(
        candidates: List<DatasetAccessionCandidate>,
        routeFits: List<DatasetRouteFitAssessment>,
        discoveryReadiness: DiscoveryReadinessReport,
        evidenceObjects: List<EvidenceObject>
    ): DatasetScoreSeparation {
        val datasetUsability = candidates.maxOfOrNull { it.usabilityScore } ?: 0
        val routeFit = routeFits.maxOfOrNull { it.routeFitScore } ?: if (candidates.isEmpty()) 0 else 35
        val anyBlocked = routeFits.any { it.blocksHypothesisUpgrade }
        val anyInRoute = routeFits.any { it.status == "IN_ROUTE" || it.status == "PARTIAL_ROUTE" }
        val hypothesisConfidence = when {
            candidates.isEmpty() -> 0
            anyBlocked && !anyInRoute -> minOf(35, (discoveryReadiness.score * 0.40).roundToInt())
            anyBlocked -> minOf(discoveryReadiness.score, 55)
            else -> discoveryReadiness.score
        }.coerceIn(0, 100)
        val state = when {
            candidates.isEmpty() -> "NO_DATASET"
            anyBlocked && !anyInRoute -> "USABLE_DATASET_OFF_ROUTE"
            anyBlocked -> "MIXED_ROUTE_CAUTION"
            hypothesisConfidence >= 75 -> "TESTABLE_LEAD"
            hypothesisConfidence >= 60 -> "CANDIDATE"
            else -> "INSPECTION_ONLY"
        }
        val allowed = !anyBlocked || anyInRoute
        val summary = when (state) {
            "USABLE_DATASET_OFF_ROUTE" -> "Dataset usability is separated from hypothesis confidence: the best dataset is usable, but it does not fit the current hypothesis route."
            "MIXED_ROUTE_CAUTION" -> "At least one dataset is off-route; use only in-route candidates for hypothesis upgrades."
            "TESTABLE_LEAD", "CANDIDATE" -> "Dataset usability and route fit are aligned enough for cautious inspection."
            else -> "No hypothesis upgrade is allowed from the current score stack."
        }
        val reasons = buildList {
            add("Dataset usability score: $datasetUsability/100.")
            add("Route-fit score: $routeFit/100.")
            add("Hypothesis-confidence score: $hypothesisConfidence/100.")
            if (anyBlocked) add("At least one route-fit gate blocks biological hypothesis upgrade.")
            if (evidenceObjects.none { it.causalClaimSafe }) add("No causal-safe evidence object is present.")
        }
        return DatasetScoreSeparation(
            datasetUsabilityScore = datasetUsability,
            routeFitScore = routeFit,
            hypothesisConfidenceScore = hypothesisConfidence,
            hypothesisUpgradeAllowed = allowed && hypothesisConfidence >= 60,
            scoreState = state,
            summary = summary,
            reasons = reasons.distinct()
        )
    }

    fun inferDatasetRoute(text: String, axes: List<String> = emptyList()): String {
        val lower = text.lowercase(Locale.US)
        val explicitScores = routeRules.map { rule ->
            rule.route to rule.keywords.count { lower.contains(it) }
        }.toMap()
        val bestExplicit = explicitScores.maxByOrNull { it.value }
        if (bestExplicit != null && bestExplicit.value >= 2) return bestExplicit.key
        if (bestExplicit != null && bestExplicit.value == 1 && bestExplicit.key != "general_immune_omics") return bestExplicit.key
        return when {
            axes.contains("interferon_antiviral_axis") -> "antiviral_interferon_timing"
            axes.contains("type2_allergy_axis") && axes.contains("rna_transcriptomic_axis") -> "allergy_type2_airway_or_skin"
            axes.contains("type2_allergy_axis") -> "allergy_type2_airway_or_skin"
            axes.contains("tnf_il6_autoimmune_axis") || axes.contains("regulatory_brake_axis") -> "autoimmune_activity_regulatory"
            axes.contains("hyperinflammatory_axis") || axes.contains("tissue_damage_axis") -> "hyperinflammation_tissue_damage"
            axes.contains("rna_transcriptomic_axis") || axes.contains("dna_genomic_axis") -> "general_immune_omics"
            else -> "unknown_route"
        }
    }

    private fun inferTargetRoute(
        candidate: DatasetAccessionCandidate,
        finding: ResearchFinding?,
        shards: List<TestableHypothesisShard>
    ): String {
        val sourceText = listOf(
            finding?.bridgeSignal.orEmpty(),
            finding?.whyItMatters.orEmpty(),
            finding?.matchedAxes.orEmpty().joinToString(" ")
        ).joinToString(" ")
        val direct = inferDatasetRoute(sourceText, finding?.matchedAxes.orEmpty())
        if (direct != "unknown_route" && direct != "general_immune_omics") return direct

        val accessionOrTitle = (candidate.accession + " " + candidate.sourceTitle).lowercase(Locale.US)
        val shard = shards.firstOrNull { shard ->
            shard.querySeeds.any { seed -> accessionOrTitle.contains(seed.lowercase(Locale.US).take(24)) }
        }
        val shardText = listOf(shard?.label.orEmpty(), shard?.evidenceQuestion.orEmpty(), shard?.querySeeds.orEmpty().joinToString(" ")).joinToString(" ")
        return inferDatasetRoute(shardText).takeIf { it != "unknown_route" } ?: "general_immune_mapping"
    }

    private fun fitScore(datasetRoute: String, targetRoute: String, datasetText: String): Int {
        if (datasetRoute == "unknown_route") return 25
        if (targetRoute == "general_immune_mapping" || targetRoute == "general_immune_omics") return if (datasetRoute == "general_immune_omics") 70 else 55
        if (datasetRoute == targetRoute) return 92
        if (datasetRoute.startsWith("allergy") && targetRoute.startsWith("allergy")) return 82
        if (datasetRoute == "general_immune_omics") return 58
        if (targetRoute == "antiviral_interferon_timing" && datasetRoute.startsWith("allergy")) return 28
        if (datasetRoute == "antiviral_interferon_timing" && targetRoute.startsWith("allergy")) return 35
        val text = datasetText.lowercase(Locale.US)
        val sharedOmics = listOf("rna", "single-cell", "transcript").any { text.contains(it) }
        return if (sharedOmics) 45 else 35
    }

    private fun statusFor(score: Int, datasetRoute: String, targetRoute: String): String = when {
        score >= 80 -> "IN_ROUTE"
        score >= 55 -> "PARTIAL_ROUTE"
        score >= 40 -> "CROSS_DOMAIN_LEAD"
        else -> "OFF_ROUTE_DATASET"
    }

    private fun allowedUse(status: String, datasetRoute: String, targetRoute: String): String = when (status) {
        "IN_ROUTE" -> "Allowed for dataset inspection and cautious hypothesis testing after minimum data pack passes."
        "PARTIAL_ROUTE" -> "Allowed only for hypothesis-generation with explicit route caution."
        "CROSS_DOMAIN_LEAD" -> "Allowed for analogy/contrast learning only; do not upgrade the target hypothesis."
        else -> "Inspection only; do not use as support for the target hypothesis."
    } + " Dataset route=$datasetRoute; target route=$targetRoute."

    private fun buildReasons(
        candidate: DatasetAccessionCandidate,
        datasetRoute: String,
        targetRoute: String,
        score: Int,
        status: String
    ): List<String> = buildList {
        add("Dataset route inferred as $datasetRoute from title/metadata, not from the search query.")
        add("Target route inferred as $targetRoute from current hypothesis context.")
        add("Route-fit score $score/100 → $status.")
        if (status == "OFF_ROUTE_DATASET" || status == "CROSS_DOMAIN_LEAD") {
            add("Candidate ${candidate.accession} may be useful, but it cannot upgrade an unrelated biological hypothesis.")
        }
    }
}
