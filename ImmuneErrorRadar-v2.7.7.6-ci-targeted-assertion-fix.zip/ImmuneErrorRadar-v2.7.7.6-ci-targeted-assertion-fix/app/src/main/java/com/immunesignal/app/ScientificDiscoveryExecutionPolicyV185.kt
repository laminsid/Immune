package com.immunesignal.app

import java.util.Locale

/**
 * v1.8.5: policy-enforced discovery control. Token: policy_enforced_discovery_control.
 *
 * v1.8.4 stress-tests the next scientific decision. This layer converts the
 * stress-test branches into an execution policy: which routes are cooled down,
 * which weak beliefs are buried, which query replays are blocked, and which
 * evidence keys are forced into the next directive. It guides routing only; it
 * never proves biology, diagnosis, treatment, or causal mechanism.
 */
data class ScientificExecutionPolicyAction(
    val policyId: String,
    val label: String,
    val trigger: String,
    val enforcement: String,
    val allowedNextAction: String,
    val blockedIf: String,
    val reason: String
)

data class ScientificDiscoveryExecutionPolicyReport(
    val active: Boolean,
    val version: String,
    val policyState: String,
    val executionMode: String,
    val policyActions: List<ScientificExecutionPolicyAction>,
    val allowedActions: List<String>,
    val blockedActions: List<String>,
    val queryReplayBlocks: List<String>,
    val routeCooldownPolicy: String,
    val beliefBurialPolicy: String,
    val forcedDirectiveTerms: List<String>,
    val forcedEvidenceKeys: List<String>,
    val rerouteTriggers: List<String>,
    val reportLine: String,
    val claimLimit: String = "execution_policy_guides_routing_not_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryExecutionPolicyReport(
            active = false,
            version = "v1.8.5",
            policyState = "NOT_RUN",
            executionMode = "NO_POLICY",
            policyActions = emptyList(),
            allowedActions = emptyList(),
            blockedActions = emptyList(),
            queryReplayBlocks = emptyList(),
            routeCooldownPolicy = "Run a research cycle before enforcing discovery policy.",
            beliefBurialPolicy = "No belief burial policy available.",
            forcedDirectiveTerms = emptyList(),
            forcedEvidenceKeys = emptyList(),
            rerouteTriggers = emptyList(),
            reportLine = "Discovery execution policy did not run.",
            claimLimit = "execution_policy_guides_routing_not_proof"
        )
    }
}

object ScientificDiscoveryExecutionPolicyEngineV185 {
    fun enforce(
        stressTest: ScientificDiscoveryStressTestReport,
        decisionMemory: ScientificDiscoveryDecisionReport,
        scientificWeights: ScientificDiscoveryWeightReport,
        causalReadiness: CausalReadinessReport,
        miniPeerReview: MiniPeerReviewReport,
        epistemicBelief: EpistemicBeliefReport,
        memoryConsolidation: MemoryConsolidationReport
    ): ScientificDiscoveryExecutionPolicyReport {
        if (!stressTest.active && !decisionMemory.active && !scientificWeights.active) {
            return ScientificDiscoveryExecutionPolicyReport.empty()
        }

        val scenario = stressTest.selectedScenario.uppercase(Locale.US)
        val hasCooldown = stressTest.routeCooldownSignals.isNotEmpty() || scenario.contains("TRAP") || scenario.contains("NULL") || scenario.contains("FALSE_FRIEND")
        val hasContradiction = scenario.contains("CONTRADICTION") || stressTest.contradictionPolicy.contains("contradiction", true) || miniPeerReview.verdict in setOf("HOLD", "REJECT")
        val weakBeliefPressure = epistemicBelief.retiredBeliefs + epistemicBelief.revisedBeliefs + memoryConsolidation.archivedBeliefs + memoryConsolidation.blockedBeliefs
        val hasFalseFriend = scientificWeights.downgradedFalseFriends.isNotEmpty() || scenario.contains("FALSE_FRIEND")
        val causalBlocked = causalReadiness.level < 3 || !causalReadiness.causalLanguageAllowed

        val executionMode = when {
            hasFalseFriend -> "DOWNGRADE_FALSE_FRIEND_AND_FORCE_CONTROLS"
            hasContradiction -> "FORCE_FALSIFICATION_FIRST"
            hasCooldown -> "COOLDOWN_ROUTE_AND_PARSE_METADATA"
            weakBeliefPressure >= 8 -> "BURY_WEAK_BELIEFS_AND_REROUTE"
            causalBlocked -> "GUARDED_ASSOCIATION_ONLY"
            else -> "EXECUTE_WITH_EVIDENCE_GUARDS"
        }
        val policyState = when (executionMode) {
            "DOWNGRADE_FALSE_FRIEND_AND_FORCE_CONTROLS" -> "ENFORCED_FALSE_FRIEND_DOWNGRADE"
            "FORCE_FALSIFICATION_FIRST" -> "ENFORCED_FALSIFICATION"
            "COOLDOWN_ROUTE_AND_PARSE_METADATA" -> "ENFORCED_ROUTE_COOLDOWN"
            "BURY_WEAK_BELIEFS_AND_REROUTE" -> "ENFORCED_MEMORY_PRUNE"
            "GUARDED_ASSOCIATION_ONLY" -> "ENFORCED_CAUSAL_LOCK"
            else -> "ENFORCED_GUARDED_DISCOVERY"
        }

        val actions = buildPolicyActions(executionMode, stressTest, decisionMemory, scientificWeights, causalReadiness, miniPeerReview, weakBeliefPressure)
        val allowed = buildAllowedActions(executionMode, stressTest, causalReadiness)
        val blocked = buildBlockedActions(executionMode, stressTest, scientificWeights, causalReadiness, memoryConsolidation)
        val replayBlocks = buildReplayBlocks(stressTest, decisionMemory, scientificWeights, memoryConsolidation)
        val forcedEvidence = normalizeEvidence(
            stressTest.forcedEvidenceKeys +
                decisionMemory.evidenceImpactKeys +
                scientificWeights.decisiveEvidenceDelta +
                causalReadiness.blockers +
                miniPeerReview.missingEvidence +
                replayBlocks
        ).take(18)
        val forcedTerms = normalizeTerms(
            stressTest.forcedNextTerms +
                decisionMemory.queryImpactTerms +
                scientificWeights.searchPriorityVector +
                allowed +
                blocked +
                replayBlocks
        ).take(44)
        val reroutes = buildRerouteTriggers(executionMode, stressTest, decisionMemory, forcedEvidence)
        val cooldownPolicy = when {
            hasFalseFriend -> "Downgrade false-friend terms to context-only prior until control/comparator and outcome labels appear."
            hasCooldown -> "Cool down the selected route for one cycle if it repeats high route-fit without outcome/control/time or metadata parsing."
            else -> "No cooldown unless the next cycle repeats the same missing decisive evidence."
        }
        val burialPolicy = when {
            weakBeliefPressure >= 8 -> "Bury weak/revised/retired beliefs in historical mistake memory; do not allow them to route the next query."
            memoryConsolidation.blockedBeliefs > memoryConsolidation.routingBeliefs -> "Block weak beliefs from routing; route only from evidence contracts and stress-test policy."
            else -> "Keep only decision-impact beliefs visible; archive unused weak beliefs as context."
        }
        val reportLine = "v1.8.5 policy: $policyState/$executionMode; allowed=${allowed.take(2).joinToString(" | ")}; blocked=${blocked.take(2).joinToString(" | ")}; evidence=${forcedEvidence.take(4).joinToString("/")}."

        return ScientificDiscoveryExecutionPolicyReport(
            active = true,
            version = "v1.8.5-policy-enforced-discovery-control",
            policyState = policyState,
            executionMode = executionMode,
            policyActions = actions.take(8),
            allowedActions = allowed.take(10),
            blockedActions = blocked.take(10),
            queryReplayBlocks = replayBlocks.take(10),
            routeCooldownPolicy = cooldownPolicy,
            beliefBurialPolicy = burialPolicy,
            forcedDirectiveTerms = forcedTerms,
            forcedEvidenceKeys = forcedEvidence,
            rerouteTriggers = reroutes.take(10),
            reportLine = reportLine.take(520),
            claimLimit = "execution_policy_guides_routing_not_proof"
        )
    }

    private fun buildPolicyActions(
        executionMode: String,
        stressTest: ScientificDiscoveryStressTestReport,
        decisionMemory: ScientificDiscoveryDecisionReport,
        weights: ScientificDiscoveryWeightReport,
        causal: CausalReadinessReport,
        peer: MiniPeerReviewReport,
        weakBeliefPressure: Int
    ): List<ScientificExecutionPolicyAction> = buildList {
        add(
            ScientificExecutionPolicyAction(
                policyId = "evidence_contract_enforcement",
                label = "Enforce next evidence contract",
                trigger = decisionMemory.nextCycleContract.ifBlank { stressTest.selectedScenario },
                enforcement = "Force required evidence keys before any belief strengthening.",
                allowedNextAction = "Run metadata/outcome/control/time-order search or parser.",
                blockedIf = "Only route-fit, title, metadata-only, or generic marker evidence repeats.",
                reason = "A decision memory without an enforcement policy can replay the same weak route."
            )
        )
        if (executionMode.contains("FALSIFICATION") || peer.verdict in setOf("HOLD", "REJECT")) {
            add(
                ScientificExecutionPolicyAction(
                    policyId = "falsification_first",
                    label = "Run falsification before upgrade",
                    trigger = peer.strongestObjection.ifBlank { stressTest.contradictionPolicy },
                    enforcement = "Add contradiction, negative-control, failed-replication, and effect-reversal terms.",
                    allowedNextAction = "Falsification lane plus controlled-comparison parsing.",
                    blockedIf = "Next query only searches supportive mechanism terms.",
                    reason = "The strongest objection must be attacked before the route can become a stronger lead."
                )
            )
        }
        if (executionMode.contains("FALSE_FRIEND") || weights.downgradedFalseFriends.isNotEmpty()) {
            add(
                ScientificExecutionPolicyAction(
                    policyId = "false_friend_downgrade",
                    label = "Downgrade false-friend term",
                    trigger = weights.downgradedFalseFriends.firstOrNull() ?: "false_friend_route_boost",
                    enforcement = "Use term as context only until comparator/control/outcome labels exist.",
                    allowedNextAction = "Search controls, confounders, and unrelated-marker checks.",
                    blockedIf = "Term is used as a direct mechanism or causal bridge.",
                    reason = "Scientific vocabulary can look intelligent while hiding missing evidence."
                )
            )
        }
        if (executionMode.contains("COOLDOWN") || stressTest.routeCooldownSignals.isNotEmpty()) {
            add(
                ScientificExecutionPolicyAction(
                    policyId = "route_cooldown",
                    label = "Cool down weak route replay",
                    trigger = stressTest.routeCooldownSignals.take(3).joinToString("/").ifBlank { stressTest.selectedScenario },
                    enforcement = "Block the same broad route if decisive evidence does not change.",
                    allowedNextAction = "Switch to parser/control/falsification search.",
                    blockedIf = "Same route-fit terms reappear without new outcome/control/time evidence.",
                    reason = "High route-fit without usability is a discovery trap."
                )
            )
        }
        if (weakBeliefPressure >= 8) {
            add(
                ScientificExecutionPolicyAction(
                    policyId = "belief_burial",
                    label = "Bury weak unused beliefs",
                    trigger = "weak_belief_pressure=$weakBeliefPressure",
                    enforcement = "Move weak unused beliefs to historical mistake memory and prevent routing.",
                    allowedNextAction = "Route from evidence contracts, not weak beliefs.",
                    blockedIf = "A retired/revised belief tries to seed the next query.",
                    reason = "Accumulated weak beliefs can create fake intelligence."
                )
            )
        }
        if (causal.level < 3) {
            add(
                ScientificExecutionPolicyAction(
                    policyId = "causal_language_lock",
                    label = "Keep association-only language",
                    trigger = "causal_level=${causal.level}/${causal.state}",
                    enforcement = "Block causal and strong-signal wording below controlled comparison.",
                    allowedNextAction = "Search comparator/control/time-order evidence.",
                    blockedIf = "Report tries to upgrade route-fit or association into mechanism. ",
                    reason = "Causal claims need controlled-comparison readiness."
                )
            )
        }
    }

    private fun buildAllowedActions(executionMode: String, stressTest: ScientificDiscoveryStressTestReport, causal: CausalReadinessReport): List<String> = buildList {
        add("parse_minimum_metadata")
        add("search_outcome_recovery_severity_endpoint_labels")
        add("search_comparator_control_negative_control_design")
        add("search_longitudinal_serial_follow_up_time_order")
        if (executionMode.contains("FALSIFICATION") || stressTest.contradictionPolicy.isNotBlank()) add("run_falsification_contradiction_lane")
        if (executionMode.contains("COOLDOWN")) add("switch_to_metadata_parser_before_broad_search")
        if (causal.level < 3) add("keep_association_only_language")
    }.distinct()

    private fun buildBlockedActions(
        executionMode: String,
        stressTest: ScientificDiscoveryStressTestReport,
        weights: ScientificDiscoveryWeightReport,
        causal: CausalReadinessReport,
        memory: MemoryConsolidationReport
    ): List<String> = buildList {
        add("block_hypothesis_upgrade_from_route_fit_only")
        add("block_metadata_title_only_discovery_claim")
        if (causal.level < 3) add("block_causal_or_strong_signal_language")
        if (stressTest.routeCooldownSignals.isNotEmpty() || executionMode.contains("COOLDOWN")) add("block_same_route_replay_without_new_decisive_evidence")
        if (weights.downgradedFalseFriends.isNotEmpty()) add("block_false_friend_as_mechanism")
        if (memory.blockedBeliefs > 0) add("block_weak_belief_routing")
    }.distinct()

    private fun buildReplayBlocks(
        stressTest: ScientificDiscoveryStressTestReport,
        decisionMemory: ScientificDiscoveryDecisionReport,
        weights: ScientificDiscoveryWeightReport,
        memory: MemoryConsolidationReport
    ): List<String> = buildList {
        stressTest.routeCooldownSignals.forEach { add("replay_block_$it") }
        decisionMemory.failureCriteria.take(4).forEach { add("failure_replay_block_${normalizeKey(it)}") }
        weights.downgradedFalseFriends.take(4).forEach { add("false_friend_replay_block_${normalizeKey(it)}") }
        if (memory.blockedBeliefs > 0) add("weak_belief_routing_replay_block")
        add("same_query_batch_without_new_outcome_control_time_block")
    }.distinct()

    private fun buildRerouteTriggers(
        executionMode: String,
        stressTest: ScientificDiscoveryStressTestReport,
        decisionMemory: ScientificDiscoveryDecisionReport,
        evidence: List<String>
    ): List<String> = buildList {
        add("if_no_${evidence.take(3).joinToString("_").ifBlank { "minimum_metadata" }}_then_reroute")
        if (executionMode.contains("FALSIFICATION")) add("if_contradiction_found_then_downgrade_mechanism_and_reroute")
        if (executionMode.contains("COOLDOWN")) add("if_route_fit_repeats_without_decisive_labels_then_cooldown_route")
        if (executionMode.contains("FALSE_FRIEND")) add("if_false_friend_repeats_then_context_prior_only")
        if (decisionMemory.changeIfFails.isNotBlank()) add("if_fails_${normalizeKey(decisionMemory.changeIfFails)}")
        stressTest.branchActions.take(3).forEach { add("branch_${normalizeKey(it)}") }
    }.distinct()

    private fun normalizeEvidence(items: List<String>): List<String> = items.map { evidenceKey(it) }.filter { it.isNotBlank() }.distinct()

    private fun evidenceKey(text: String): String {
        val lower = text.lowercase(Locale.US)
        return when {
            lower.contains("outcome") || lower.contains("recovery") || lower.contains("severity") || lower.contains("endpoint") -> "outcome_labels"
            lower.contains("time") || lower.contains("longitudinal") || lower.contains("serial") || lower.contains("baseline") || lower.contains("follow") -> "time_order"
            lower.contains("control") || lower.contains("comparator") || lower.contains("placebo") || lower.contains("negative") -> "comparator_control"
            lower.contains("metadata") || lower.contains("sample") || lower.contains("accession") || lower.contains("license") -> "minimum_metadata"
            lower.contains("replication") || lower.contains("validation") || lower.contains("repeated") -> "replication_validation"
            lower.contains("contradiction") || lower.contains("falsification") || lower.contains("failed") || lower.contains("null") -> "falsification_contradiction"
            lower.contains("confound") || lower.contains("artifact") || lower.contains("batch") || lower.contains("assay") -> "artifact_confounder_control"
            lower.contains("human") || lower.contains("patient") || lower.contains("phenotype") || lower.contains("clinical") -> "human_or_patient_phenotype"
            lower.contains("tissue") || lower.contains("cell") -> "tissue_cell_context"
            lower.contains("route") || lower.contains("cooldown") || lower.contains("replay") -> "route_cooldown_policy"
            lower.contains("belief") || lower.contains("archive") || lower.contains("burial") -> "belief_burial_policy"
            else -> normalizeKey(text).take(80)
        }
    }

    private fun normalizeTerms(items: List<String>): List<String> = items.flatMap { text ->
        text.lowercase(Locale.US)
            .replace("rna seq", "rna-seq")
            .replace("single cell", "single-cell")
            .split(Regex("[^a-z0-9_-]+"))
            .map { it.trim() }
            .filter { it.length >= 3 }
            .filter { it in allowedTerms || it.startsWith("gse") || it.startsWith("prjna") }
    }.distinct()

    private fun normalizeKey(text: String): String = text.lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .take(90)

    private val allowedTerms = setOf(
        "outcome", "recovery", "severity", "endpoint", "clinical", "phenotype", "human", "patient",
        "control", "comparator", "placebo", "negative", "healthy", "metadata", "accession", "sample", "license",
        "longitudinal", "serial", "baseline", "follow-up", "time-course", "temporal", "replication", "validation",
        "contradiction", "falsification", "null", "failed", "effect", "direction", "reversal", "confounder", "artifact",
        "batch", "assay", "rna-seq", "single-cell", "transcriptomic", "cell-type", "tissue", "interferon", "viral", "load",
        "mechanism", "perturbation", "intervention", "dataset", "geo", "sra", "immune", "allergy", "inflammation",
        "cooldown", "replay", "block", "policy", "burial", "archive", "evidence", "contract", "parser"
    )
}
