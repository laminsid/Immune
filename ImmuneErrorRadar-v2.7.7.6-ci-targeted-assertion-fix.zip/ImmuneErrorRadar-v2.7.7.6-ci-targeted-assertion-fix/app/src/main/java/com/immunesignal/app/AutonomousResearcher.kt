package com.immunesignal.app

import org.json.JSONObject
import java.util.Locale

/**
 * v1.3.2: Autonomous Researcher Mode.
 *
 * This is not an ML layer. It is the research-strategy layer that was missing
 * in v1.3: the app should work as a curious biomedical researcher by default,
 * while steering remains optional acceleration.
 *
 * It plans three lanes every cycle:
 * - EXPLORE: open a new biological bridge or dataset territory.
 * - DEEPEN: gather stronger evidence for an existing/open axis.
 * - CHALLENGE: search for contradictions, opposite mechanisms, or bias.
 *
 * The lock system still decides what is allowed to upgrade.
 */
data class AutonomousResearchLane(
    val laneId: String,
    val laneType: String,
    val label: String,
    val query: String,
    val reason: String,
    val targetAxes: List<String>
)

data class AutonomousResearchPlan(
    val mode: String,
    val strategy: String,
    val cycleIndex: Int,
    val lanes: List<AutonomousResearchLane>,
    val nextStrategyIfNoUsefulSource: String,
    val notes: List<String>
) {
    companion object {
        fun empty() = AutonomousResearchPlan(
            mode = "autonomous_researcher",
            strategy = "explore_deepen_challenge",
            cycleIndex = 0,
            lanes = emptyList(),
            nextStrategyIfNoUsefulSource = "Rotate to dataset-first and contradiction-first search.",
            notes = listOf("Autonomous researcher mode is active by default; steering is optional.")
        )
    }
}

class AutonomousResearchPlanner {
    fun plan(
        latestReports: List<String>,
        recentFindings: List<JSONObject>,
        importedSignals: List<ImportedReportSignal>,
        steering: ResearchSteeringProfile?,
        seenAxisPairs: Set<String>
    ): AutonomousResearchPlan {
        val cycleIndex = latestReports.size.coerceAtLeast(0) % 4
        val previousNoUseful = latestReports.firstOrNull()?.let { latest ->
            runCatching {
                val obj = JSONObject(latest)
                val delta = obj.optJSONObject("knowledgeDelta") ?: JSONObject()
                delta.optInt("newSourcesSaved", 0) == 0 && delta.optInt("repeatedSourcesSkipped", 0) > 0
            }.getOrDefault(false)
        } ?: false

        val frontierAxes = selectFrontierAxes(recentFindings, importedSignals)
        val mode = if (steering != null && steering.variables.isNotEmpty()) "guided_plus_autonomous" else "autonomous_researcher"
        val lanes = mutableListOf<AutonomousResearchLane>()

        lanes += exploreLane(cycleIndex, seenAxisPairs)
        lanes += deepenLane(frontierAxes, cycleIndex)
        lanes += challengeLane(frontierAxes, cycleIndex)
        if (previousNoUseful) lanes += evolvedLane(cycleIndex, frontierAxes) else lanes += datasetLane(cycleIndex)

        val notes = mutableListOf<String>()
        notes += "Autonomous researcher mode is the default; user steering is optional acceleration, not a requirement."
        notes += "Each cycle runs Explore + Deepen + Challenge lanes before any broad fallback."
        notes += "If a cycle returns no useful source, the next cycle changes strategy instead of asking the user to guide it."
        if (steering != null && steering.variables.isNotEmpty()) notes += "Guided steering is active and will be combined with autonomous lanes."
        if (previousNoUseful) notes += "Previous cycle had no useful new source; query evolution switched toward dataset/omics/contradiction lanes."

        return AutonomousResearchPlan(
            mode = mode,
            strategy = if (previousNoUseful) "evolved_dataset_contradiction" else "explore_deepen_challenge",
            cycleIndex = cycleIndex,
            lanes = lanes.distinctBy { it.laneId }.take(4),
            nextStrategyIfNoUsefulSource = when (cycleIndex) {
                0 -> "Switch from broad antiviral search to regulatory-brake contradictions."
                1 -> "Switch from allergy/tolerance search to human dataset discovery."
                2 -> "Switch from regulatory-brake search to tissue-damage/resolution separation."
                else -> "Switch from tissue-damage search to omics and longitudinal outcome datasets."
            },
            notes = notes.distinct()
        )
    }

    fun queries(plan: AutonomousResearchPlan): List<ResearchQuery> {
        return plan.lanes.map { lane ->
            ResearchQuery(
                id = "q_auto_${lane.laneId}",
                label = "${lane.laneType}: ${lane.label}",
                query = lane.query,
                reason = lane.reason
            )
        }
    }

    private fun selectFrontierAxes(
        recentFindings: List<JSONObject>,
        importedSignals: List<ImportedReportSignal>
    ): List<String> {
        val counts = linkedMapOf<String, Int>()
        for (finding in recentFindings.take(60)) {
            val arr = finding.optJSONArray("matchedAxes") ?: continue
            for (i in 0 until arr.length()) {
                val axis = arr.optString(i)
                if (axis.isNotBlank()) counts[axis] = (counts[axis] ?: 0) + 1
            }
        }
        for (signal in importedSignals.take(20)) {
            for (axis in signal.matchedAxes) counts[axis] = (counts[axis] ?: 0) + 2
        }
        return counts.entries.sortedByDescending { it.value }.map { it.key }.take(5)
    }

    private fun exploreLane(cycleIndex: Int, seenAxisPairs: Set<String>): AutonomousResearchLane {
        val options = listOf(
            AutonomousResearchLane(
                "explore_antiviral_precision",
                "EXPLORE",
                "protective antiviral response vs damaging inflammation",
                "(viral infection OR influenza OR RSV OR COVID OR hantavirus) AND (interferon timing OR early interferon OR delayed interferon OR viral load) AND (recovery OR severity OR tissue damage) AND (human OR cohort OR dataset)",
                "Autonomously explores how the immune system separates pathogen control from host-damage escalation.",
                listOf("interferon_antiviral_axis", "tissue_damage_axis", "resolution_recovery_axis")
            ),
            AutonomousResearchLane(
                "explore_tolerance_allergy",
                "EXPLORE",
                "allergen tolerance vs Type-2 over-response",
                "(allergen tolerance OR immune tolerance OR desensitization) AND (IgE OR mast cell OR eosinophil OR IL-4 OR IL-13) AND (human OR patient OR cohort)",
                "Autonomously explores why harmless triggers become immune over-response, using allergy as the low-risk misfire model.",
                listOf("type2_allergy_axis", "regulatory_brake_axis")
            ),
            AutonomousResearchLane(
                "explore_regulatory_brake_cross_condition",
                "EXPLORE",
                "regulatory brake across allergy, autoimmunity, and viral inflammation",
                "(IL-10 OR Treg OR regulatory T cells OR immune resolution) AND (allergy OR asthma OR rheumatoid arthritis OR viral infection OR ARDS OR cytokine storm) AND (human OR patient OR cohort)",
                "Autonomously searches for shared brake-failure mechanisms across different immune errors.",
                listOf("regulatory_brake_axis", "tnf_il6_autoimmune_axis", "interferon_antiviral_axis")
            ),
            AutonomousResearchLane(
                "explore_resolution_recovery",
                "EXPLORE",
                "resolution and recovery after immune activation",
                "(immune resolution OR recovery OR convalescence) AND (cytokine OR interferon OR T cell OR antibody) AND (viral infection OR allergy OR autoimmune) AND (longitudinal OR time course OR dataset)",
                "Autonomously looks for the difference between successful shutdown and chronic/overactive immune response.",
                listOf("resolution_recovery_axis", "regulatory_brake_axis")
            )
        )
        return options[cycleIndex % options.size]
    }

    private fun deepenLane(frontierAxes: List<String>, cycleIndex: Int): AutonomousResearchLane {
        val axes = frontierAxes.joinToString(" ").lowercase(Locale.US)
        return when {
            axes.contains("interferon") || axes.contains("viral") -> AutonomousResearchLane(
                "deepen_interferon_timing",
                "DEEPEN",
                "interferon timing and viral outcome labels",
                "(early interferon OR delayed interferon OR interferon signature) AND (viral load OR severity OR recovery OR deterioration) AND (RNA-seq OR transcriptomic OR cytokine OR longitudinal)",
                "Deepens an antiviral frontier by looking for timing + outcome rather than marker-only studies.",
                listOf("interferon_antiviral_axis", "resolution_recovery_axis")
            )
            axes.contains("type2") || axes.contains("mast") || axes.contains("histamine") -> AutonomousResearchLane(
                "deepen_mast_tolerance",
                "DEEPEN",
                "mast-cell tolerance and mediator control",
                "(mast cell OR histamine OR IgE) AND (tolerance OR regulation OR desensitization OR resolution) AND (human OR cohort OR patient)",
                "Deepens Type-2/mast-cell leads by seeking regulation and shutdown mechanisms.",
                listOf("type2_allergy_axis", "mast_cell_histamine_axis", "regulatory_brake_axis")
            )
            axes.contains("gut") || axes.contains("testosterone") || axes.contains("muscle") -> AutonomousResearchLane(
                "deepen_metabolic_immune_bridge",
                "DEEPEN",
                "gut, hormone, muscle reserve as immune modifiers",
                "(microbiome OR gastric acid OR protein intake OR muscle mass OR testosterone) AND (immune regulation OR inflammation OR recovery) AND (human OR cohort)",
                "Deepens metabolic/hormonal modifiers only where they connect to measurable immune response or recovery.",
                listOf("gastric_acid_gut_axis", "testosterone_immune_axis", "muscle_mass_reserve_axis")
            )
            else -> listOf(
                AutonomousResearchLane(
                    "deepen_dataset_outcomes_${cycleIndex}",
                    "DEEPEN",
                    "public immune datasets with outcome labels",
                    "(immune profiling OR cytokine profiling OR RNA-seq OR single-cell) AND (dataset OR cohort OR longitudinal) AND (outcome OR severity OR recovery) AND (human OR patient)",
                    "Deepens global dataset discovery because the frontier lacks a strong dominant axis yet.",
                    listOf("rna_transcriptomic_axis", "interferon_antiviral_axis", "resolution_recovery_axis")
                )
            ).first()
        }
    }

    private fun challengeLane(frontierAxes: List<String>, cycleIndex: Int): AutonomousResearchLane {
        val axes = frontierAxes.joinToString(" ").lowercase(Locale.US)
        return when {
            axes.contains("interferon") -> AutonomousResearchLane(
                "challenge_interferon_harm_${cycleIndex}",
                "CHALLENGE",
                "when antiviral interferon becomes harmful or insufficient",
                "(interferon OR antiviral response) AND (late OR delayed OR excessive OR harmful OR severe disease) AND (viral infection OR ARDS OR COVID OR influenza) AND (human OR patient)",
                "Challenges the simple idea that stronger antiviral response is always better.",
                listOf("interferon_antiviral_axis", "tissue_damage_axis")
            )
            axes.contains("allergy") || axes.contains("type2") -> AutonomousResearchLane(
                "challenge_type2_burden_${cycleIndex}",
                "CHALLENGE",
                "allergy as preserved responsiveness vs inflammatory burden",
                "(allergy OR asthma OR IgE) AND (inflammaging OR chronic inflammation OR immune aging OR frailty) AND (human OR cohort)",
                "Challenges the idea that high allergic reactivity is protective by searching for chronic-burden evidence.",
                listOf("type2_allergy_axis", "aging_immune_axis", "inflammaging_axis")
            )
            else -> AutonomousResearchLane(
                "challenge_cross_condition_bias_${cycleIndex}",
                "CHALLENGE",
                "cross-condition contradiction and non-replication",
                "(immune response OR cytokine OR biomarker) AND (conflicting results OR no association OR inconsistent OR heterogeneity) AND (human OR cohort)",
                "Looks for contradictions so the engine does not only collect confirming evidence.",
                listOf("bias_control_axis")
            )
        }
    }

    private fun datasetLane(cycleIndex: Int): AutonomousResearchLane {
        return AutonomousResearchLane(
            "dataset_frontier_$cycleIndex",
            "DATASET",
            "dataset-first immune discovery",
            "(GSE OR GEO OR ImmPort OR dataset OR RNA-seq OR single-cell) AND (immune response OR cytokine OR interferon OR T cell OR antibody) AND (human OR patient) AND (severity OR recovery OR outcome)",
            "Keeps the project global-first by looking for reusable public datasets before any ML model.",
            listOf("rna_transcriptomic_axis", "interferon_antiviral_axis", "global_dataset_axis")
        )
    }

    private fun evolvedLane(cycleIndex: Int, frontierAxes: List<String>): AutonomousResearchLane {
        val axes = frontierAxes.joinToString(" ").lowercase(Locale.US)
        return when {
            axes.contains("interferon") -> AutonomousResearchLane(
                "evolved_antiviral_omics_$cycleIndex",
                "EVOLVE",
                "omics dataset after repeated source exhaustion",
                "(transcriptomic OR RNA-seq OR single-cell OR scRNA) AND (interferon OR antiviral) AND (severity OR recovery OR viral load) AND (dataset OR cohort)",
                "The previous cycle produced no useful source; strategy evolved from article discovery to omics dataset discovery.",
                listOf("rna_transcriptomic_axis", "interferon_antiviral_axis")
            )
            else -> AutonomousResearchLane(
                "evolved_mechanism_contradiction_$cycleIndex",
                "EVOLVE",
                "mechanism + contradiction after repeated source exhaustion",
                "(immune regulation OR immune tolerance OR immune resolution) AND (contradictory OR heterogeneity OR nonresponse OR severe outcome) AND (human OR cohort OR dataset)",
                "The previous cycle produced no useful source; strategy evolved toward contradictions and resolution mechanisms.",
                listOf("regulatory_brake_axis", "resolution_recovery_axis", "bias_control_axis")
            )
        }
    }
}
