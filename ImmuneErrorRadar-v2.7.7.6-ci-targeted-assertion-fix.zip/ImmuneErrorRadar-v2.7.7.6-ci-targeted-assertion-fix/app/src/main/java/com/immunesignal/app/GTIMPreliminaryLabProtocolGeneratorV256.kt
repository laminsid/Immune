package com.immunesignal.app

/**
 * Preliminary lab-protocol generator.
 *
 * Generates falsifiable wet-lab draft ideas for researchers. The output is not validation, not
 * treatment advice, and not a clinical protocol.
 */
object GTIMPreliminaryLabProtocolGeneratorV256 {
    const val STATUS: String = "LAB_PROTOCOL_DRAFT_NOT_VALIDATION"

    fun draft(
        intent: GTIMResearchIntentObjectV255,
        routes: List<GTIMCandidateRouteV256>,
        mechanismCandidates: List<GTIMMechanismCandidateV250>
    ): GTIMPreliminaryLabProtocolDraftV256 {
        val hypothesis = routes.firstOrNull()?.cascade?.joinToString(" → ")
            ?: mechanismCandidates.firstOrNull()?.targetAxis
            ?: "candidate immune mechanism"
        val cells = intent.cellTissue.ifEmpty { listOf("PBMC", "T cells", "B cells", "monocytes") }.take(4)
        val assays = intent.assayType.ifEmpty { listOf("qPCR", "flow cytometry", "cytokine panel", "RNA-seq/scRNA-seq") }.take(5)
        return GTIMPreliminaryLabProtocolDraftV256(
            active = true,
            status = STATUS,
            hypothesis = hypothesis,
            suggestedValidationDesign = listOf(
                "Define cohort/groups from comparator intent: ${intent.comparatorWanted.joinToString(", ").ifBlank { "case vs matched/recovered/healthy controls" }}",
                "Use cell/tissue context: ${cells.joinToString(", ")}",
                "Run assays: ${assays.joinToString(", ")}",
                "Measure pathway markers: ${intent.pathway.take(6).joinToString(", ").ifBlank { "interferon/cytokine/cell-state markers" }}",
                "Pre-register falsification rule before interpreting any signal"
            ),
            positiveControl = "known stimulated immune-response or disease-relevant positive control defined by the lab",
            negativeControl = "healthy/matched baseline control and technical no-template/isotype controls where applicable",
            expectedDirection = "direction must be derived from real matrix/assay data; do not infer fold-change from semantic prior",
            falsificationCondition = "no reproducible difference across comparator groups, opposite biomarker direction, or failure under independent cohort/assay replication",
            minimumEvidenceBeforeClaim = listOf("accession or protocol source", "sample count", "biospecimen", "comparator", "matrix/assay data", "contradiction review")
        )
    }
}
