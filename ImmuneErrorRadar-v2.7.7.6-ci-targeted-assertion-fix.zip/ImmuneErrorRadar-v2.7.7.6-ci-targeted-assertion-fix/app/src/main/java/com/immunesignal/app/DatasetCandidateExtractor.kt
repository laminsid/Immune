package com.immunesignal.app

import java.util.Locale

object DatasetCandidateExtractor {
    private val accessionRegex = Regex("""\b(GSE\d+|GSM\d+|GDS\d+|SDY\d+|ImmPort\s*SDY\d+|GEO\s*Series\s*\d+)\b""", RegexOption.IGNORE_CASE)
    private val sampleRegex = Regex("""\b(n\s*=\s*\d+|\d+\s+(patients|subjects|samples|donors|cases))\b""", RegexOption.IGNORE_CASE)

    fun extractFromFinding(finding: ResearchFinding): List<DatasetCandidateV133> {
        val text = listOf(finding.title, finding.whyItMatters).joinToString(" ")
        return extract(text, finding.title, finding.url, finding.matchedAxes)
    }

    fun extract(text: String, sourceTitle: String = "", sourceUrl: String = "", axes: List<String> = AxisMatcher.match(text)): List<DatasetCandidateV133> {
        val matches = accessionRegex.findAll(text).map { it.value.replace(" ", "").uppercase(Locale.US) }.distinct().toList()
        val hasDatasetTerm = text.contains("dataset", true) || text.contains("RNA-seq", true) || text.contains("single-cell", true) || text.contains("cohort", true) || text.contains("longitudinal", true)
        val ids = if (matches.isNotEmpty()) matches else if (hasDatasetTerm) listOf("DATASET_CANDIDATE_UNVERIFIED") else emptyList()
        return ids.map { id ->
            val lower = text.lowercase(Locale.US)
            val species = when {
                lower.contains("human") || lower.contains("patient") || lower.contains("cohort") -> "human_candidate"
                lower.contains("mouse") || lower.contains("murine") || lower.contains("rat") -> "animal_candidate"
                lower.contains("cell line") || lower.contains("in vitro") -> "cell_candidate"
                else -> "unknown"
            }
            val dataType = when {
                lower.contains("single-cell") || lower.contains("scrna") -> "single-cell/RNA"
                lower.contains("rna-seq") || lower.contains("transcriptomic") -> "RNA-seq/transcriptomic"
                lower.contains("cytokine") || lower.contains("immune profiling") -> "immune profiling/cytokine"
                lower.contains("methylation") || lower.contains("epigen") -> "epigenetic"
                else -> "unknown"
            }
            val sampleHint = sampleRegex.find(text)?.value ?: "unknown"
            val outcome = when {
                lower.contains("severity") -> "severity label candidate"
                lower.contains("recovery") -> "recovery label candidate"
                lower.contains("outcome") -> "outcome label candidate"
                lower.contains("viral load") -> "viral-load outcome candidate"
                else -> "unknown"
            }
            val time = when {
                lower.contains("longitudinal") -> "longitudinal candidate"
                lower.contains("time course") || lower.contains("time-course") -> "time-course candidate"
                lower.contains("early") || lower.contains("delayed") -> "timing hint"
                else -> "unknown"
            }
            val priority = listOf(
                if (id != "DATASET_CANDIDATE_UNVERIFIED") 22 else 8,
                if (species.startsWith("human")) 18 else 0,
                if (dataType != "unknown") 16 else 0,
                if (outcome != "unknown") 18 else 0,
                if (time != "unknown") 14 else 0,
                if (sampleHint != "unknown") 8 else 0,
                axes.size.coerceAtMost(4) * 3
            ).sum().coerceIn(0, 100)
            DatasetCandidateV133(
                datasetId = id,
                source = if (id.startsWith("GSE") || id.startsWith("GSM") || id.startsWith("GDS") || id.startsWith("GEO")) "GEO/NCBI" else if (id.startsWith("SDY") || id.startsWith("IMM")) "ImmPort" else "candidate_from_text",
                species = species,
                sampleSizeHint = sampleHint,
                dataType = dataType,
                conditionHint = inferCondition(lower),
                outcomeLabelsHint = outcome,
                timeCourseHint = time,
                priorityScore = priority,
                whyUseful = "May contain reusable immune-axis data for trigger-response-outcome testing.",
                nextVerificationStep = "Verify accession, sample count, species, timepoints, and outcome labels before modeling.",
                sourceTitle = sourceTitle.take(240),
                sourceUrl = sourceUrl
            )
        }
    }

    private fun inferCondition(text: String): String = when {
        listOf("nickel", "contact dermatitis", "patch test", "anakinra", "epidermal", "skin").any { text.contains(it) } -> "allergy/contact-dermatitis/skin"
        text.contains("hantavirus") -> "hantavirus/viral hemorrhagic candidate"
        text.contains("covid") || text.contains("influenza") || text.contains("rsv") || text.contains("viral") -> "viral response"
        text.contains("asthma") || text.contains("allergy") || text.contains("allergic") -> "allergy/asthma"
        text.contains("rheumatoid") || text.contains("arthritis") -> "autoimmune inflammatory"
        text.contains("sepsis") || text.contains("ards") || text.contains("cytokine storm") -> "hyperinflammatory/systemic"
        else -> "unknown"
    }
}
