package com.immunesignal.app

/** v1.4.0: turns a broad research mission into testable evidence shards. */
object HypothesisDecomposer {
    fun decompose(globalQuestion: String): List<TestableHypothesisShard> {
        val base = globalQuestion.ifBlank {
            "Which public datasets can map trigger-response-outcome immune patterns across allergy, autoimmunity, and viral response?"
        }
        return listOf(
            TestableHypothesisShard(
                shardId = "H1_ALLERGY_DATASET_LABELS",
                label = "Allergy/asthma dataset label shard",
                evidenceQuestion = "Can allergy/asthma public datasets provide trigger, immune-response, and outcome/recovery labels rather than markers alone?",
                querySeeds = listOf(
                    "allergy asthma immune response RNA-seq GSE outcome severity",
                    "allergen challenge single-cell immune response GSE outcome",
                    "asthma transcriptomic cohort response nonresponse GSE"
                )
            ),
            TestableHypothesisShard(
                shardId = "H2_VIRAL_LONGITUDINAL_LABELS",
                label = "Viral response longitudinal shard",
                evidenceQuestion = "Can viral-response public datasets provide longitudinal immune-response labels and clinical outcome/recovery labels?",
                querySeeds = listOf(
                    "viral infection immune response longitudinal RNA-seq GSE severity recovery",
                    "influenza RSV COVID single-cell cohort immune response outcome",
                    "interferon response dataset PRJNA SRP recovery severity"
                )
            ),
            TestableHypothesisShard(
                shardId = "H3_AUTOIMMUNE_ACTIVITY_OUTCOME",
                label = "Autoimmunity activity/outcome shard",
                evidenceQuestion = "Can autoimmunity datasets link immune activation/regulatory-brake signals to disease activity or response labels?",
                querySeeds = listOf(
                    "autoimmunity rheumatoid arthritis transcriptomic GSE disease activity response",
                    "lupus immune activation RNA-seq cohort outcome GSE",
                    "regulatory T cell cytokine autoimmunity dataset response nonresponse"
                )
            )
        ).map { shard ->
            // Keep the original mission visible without allowing it to remain a single broad hypothesis.
            shard.copy(evidenceQuestion = shard.evidenceQuestion + " Mission context: " + base.take(160))
        }
    }
}
