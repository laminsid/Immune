package com.immunesignal.app

/**
 * v1.3.7: Evidence Acquisition + Learning OS models.
 * These models move the researcher from query rotation to evidence-object learning.
 */
data class DatasetAccessionCandidate(
    val accession: String,
    val source: String,
    val organismHint: String,
    val conditionLabelsHint: String,
    val outcomeLabelsHint: String,
    val triggerResponseOutcomeHint: String,
    val timeCourseHint: String,
    val sampleSizeHint: String,
    val dataType: String,
    val usabilityScore: Int,
    val status: String,
    val sourceFindingId: String,
    val sourceTitle: String,
    val sourceUrl: String,
    val reasons: List<String>
)

data class EvidenceObject(
    val evidenceId: String,
    val sourceType: String,
    val sourceId: String,
    val title: String,
    val accessionIds: List<String>,
    val supportsHypothesis: Boolean,
    val contradictsHypothesis: Boolean,
    val hasNegativeControl: Boolean,
    val hasLongitudinalSignal: Boolean,
    val hasMechanisticSignal: Boolean,
    val causalClaimSafe: Boolean,
    val linkedHypothesisId: String,
    val decisionImpact: String,
    val qualityScore: Int,
    val reasons: List<String>
)

data class ResearchIncidentReceipt(
    val incidentId: String,
    val rootCauses: List<String>,
    val observedSignals: List<String>,
    val failedLane: String,
    val severity: String,
    val createdAtMillis: Long
)

data class PreventiveGateDecision(
    val gateId: String,
    val rootCause: String,
    val action: String,
    val forcedNextIntent: String,
    val forcedQuerySeed: String,
    val blocksHypothesisUpgrade: Boolean
)

data class RegressionVector(
    val caseId: String,
    val inputSignature: String,
    val expectedRootCause: String,
    val expectedGate: String,
    val expectedNextAction: String
)

data class LaneCooldownRecord(
    val laneName: String,
    val failureCount: Int,
    val lastFailureReason: String,
    val cooldownCycles: Int,
    val blockedUntilCycle: Int
)

data class DiscoveryReadinessReport(
    val score: Int,
    val state: String,
    val blockers: List<String>,
    val strengths: List<String>
) {
    companion object {
        fun empty() = DiscoveryReadinessReport(
            score = 0,
            state = "OFF",
            blockers = listOf("No evidence object evaluated yet."),
            strengths = emptyList()
        )
    }
}

data class LearningOsReport(
    val incident: ResearchIncidentReceipt,
    val preventiveGates: List<PreventiveGateDecision>,
    val regressionVectors: List<RegressionVector>,
    val laneCooldowns: List<LaneCooldownRecord>,
    val discoveryReadiness: DiscoveryReadinessReport,
    val hypothesisUpdateGateStatus: String,
    val nextLearningAction: String
) {
    companion object {
        fun empty() = LearningOsReport(
            incident = ResearchIncidentReceipt(
                incidentId = "none",
                rootCauses = emptyList(),
                observedSignals = emptyList(),
                failedLane = "none",
                severity = "NONE",
                createdAtMillis = 0L
            ),
            preventiveGates = emptyList(),
            regressionVectors = emptyList(),
            laneCooldowns = emptyList(),
            discoveryReadiness = DiscoveryReadinessReport.empty(),
            hypothesisUpdateGateStatus = "NO_EVIDENCE_OBJECT_NO_UPGRADE",
            nextLearningAction = "Run a research cycle and require evidence objects before hypothesis upgrades."
        )
    }
}
