package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max

/**
 * v1.3.7: Vraimony-style learning loop.
 * Incident -> root cause -> preventive gate -> regression vector -> forced next evidence path.
 */
object ResearchLearningLoopEngine {
    fun build(
        signature: FailureSignature,
        findings: List<ResearchFinding>,
        datasets: List<DatasetAccessionCandidate>,
        evidenceObjects: List<EvidenceObject>,
        discoveryReadiness: DiscoveryReadinessReport
    ): LearningOsReport {
        val rootCauses = tagRootCauses(signature, findings, datasets, evidenceObjects)
        val observed = observedSignals(signature, findings, datasets, evidenceObjects)
        val severity = when {
            rootCauses.contains("REPEATED_PMIDS") && rootCauses.contains("NO_DATASET_ACCESSION") -> "HIGH"
            rootCauses.size >= 2 -> "MEDIUM"
            rootCauses.isNotEmpty() -> "LOW"
            else -> "NONE"
        }
        val incident = ResearchIncidentReceipt(
            incidentId = "incident_${System.currentTimeMillis()}",
            rootCauses = rootCauses,
            observedSignals = observed,
            failedLane = signature.failedLane,
            severity = severity,
            createdAtMillis = System.currentTimeMillis()
        )
        val gates = buildPreventiveGates(rootCauses)
        val cooldowns = buildCooldowns(signature, rootCauses)
        val vectors = buildRegressionVectors(signature, rootCauses, gates)
        val hasDecisionEvidence = evidenceObjects.any { it.decisionImpact != "no_upgrade" }
        val hypothesisGate = if (hasDecisionEvidence) "EVIDENCE_OBJECT_PRESENT_UPGRADE_ALLOWED_WITH_LOCKS" else "NO_EVIDENCE_OBJECT_NO_UPGRADE"
        val next = gates.firstOrNull()?.action ?: when {
            discoveryReadiness.state == "OFF" -> "Acquire a dataset accession or contradiction/control evidence object before another hypothesis update."
            else -> "Inspect the strongest dataset/evidence object and verify labels before modeling."
        }
        return LearningOsReport(
            incident = incident,
            preventiveGates = gates,
            regressionVectors = vectors,
            laneCooldowns = cooldowns,
            discoveryReadiness = discoveryReadiness,
            hypothesisUpdateGateStatus = hypothesisGate,
            nextLearningAction = next
        )
    }

    fun pivotFromRecentReports(recentReports: List<String>): PivotDecision {
        val latest = recentReports.firstOrNull()?.let { runCatching { JSONObject(it) }.getOrNull() } ?: return PivotDecision.none()
        val learning = latest.optJSONObject("learningOsReport") ?: return PivotDecision.none()
        val gates = learning.optJSONArray("preventiveGates") ?: return PivotDecision.none()
        val first = gates.optJSONObject(0) ?: return PivotDecision.none()
        val intent = first.optString("forcedNextIntent", "")
        val seed = first.optString("forcedQuerySeed", "")
        if (intent.isBlank() || seed.isBlank()) return PivotDecision.none()
        return ScopeDisciplineLock.sanitizePivot(
            PivotDecision(
                pivotType = "LEARNING_OS_FORCED_GATE",
                reason = "Previous failure created preventive gate ${first.optString("gateId")}: ${first.optString("action")}",
                nextIntent = intent,
                nextQuerySeed = seed,
                priority = 94
            )
        )
    }

    private fun tagRootCauses(
        signature: FailureSignature,
        findings: List<ResearchFinding>,
        datasets: List<DatasetAccessionCandidate>,
        evidenceObjects: List<EvidenceObject>
    ): List<String> {
        val out = mutableListOf<String>()
        if (signature.repeatedSkipped >= 10) out += "REPEATED_PMIDS"
        if (datasets.none { it.accession != "DATASET_ACCESSION_UNRESOLVED" }) out += "NO_DATASET_ACCESSION"
        if (findings.isNotEmpty() && findings.all { it.sanityFlags.contains("METADATA_ONLY") || it.sanityFlags.contains("ABSTRACT_FETCH_FAILED") }) out += "ABSTRACT_ONLY_RESULTS"
        if (signature.newUsefulSources <= 0 && signature.repeatedSkipped < 10) out += "BROAD_QUERY"
        if (datasets.any { it.conditionLabelsHint == "unknown" } || (datasets.isEmpty() && findings.isNotEmpty())) out += "NO_CONDITION_LABELS"
        if (datasets.any { it.outcomeLabelsHint == "unknown" } || (datasets.isEmpty() && findings.isNotEmpty())) out += "NO_OUTCOME_LABELS"
        if (evidenceObjects.none { it.contradictsHypothesis }) out += "NO_CONTRADICTION_SEARCH"
        if (evidenceObjects.none { it.hasNegativeControl }) out += "NO_CONTROL_SIGNAL"
        if (findings.isNotEmpty() && findings.maxOf { it.evidence.evidenceQualityScore } < 45) out += "SOURCE_TOO_WEAK"
        if (signature.failedLane.contains("broad", true) || signature.failedLane.contains("explore", true) && signature.newUsefulSources <= 0) out += "WRONG_VOCABULARY"
        return out.distinct()
    }

    private fun observedSignals(
        signature: FailureSignature,
        findings: List<ResearchFinding>,
        datasets: List<DatasetAccessionCandidate>,
        evidenceObjects: List<EvidenceObject>
    ): List<String> = listOf(
        "newUsefulSources=${signature.newUsefulSources}",
        "repeatedSkipped=${signature.repeatedSkipped}",
        "metadataOnlyRatio=${signature.metadataOnlyRatio}",
        "datasetCandidates=${datasets.size}",
        "explicitAccessions=${datasets.count { it.accession != "DATASET_ACCESSION_UNRESOLVED" }}",
        "evidenceObjects=${evidenceObjects.size}",
        "decisionEvidence=${evidenceObjects.count { it.decisionImpact != "no_upgrade" }}",
        "findings=${findings.size}"
    )

    private fun buildPreventiveGates(rootCauses: List<String>): List<PreventiveGateDecision> {
        return rootCauses.map { cause ->
            when (cause) {
                "NO_DATASET_ACCESSION" -> PreventiveGateDecision(
                    gateId = "FORCE_DATASET_ACCESSION_SEARCH",
                    rootCause = cause,
                    action = "Force dataset accession query before next broad PubMed exploration.",
                    forcedNextIntent = "dataset_accession_search",
                    forcedQuerySeed = "GSE OR GEO OR SDY OR ImmPort OR PRJNA OR SRP RNA-seq single-cell immune response outcome severity",
                    blocksHypothesisUpgrade = true
                )
                "REPEATED_PMIDS" -> PreventiveGateDecision(
                    gateId = "LANE_COOLDOWN",
                    rootCause = cause,
                    action = "Block the same PubMed query family for five cycles.",
                    forcedNextIntent = "cooldown_dataset_contradiction",
                    forcedQuerySeed = "immune response dataset accession negative control no association conflicting results longitudinal outcome",
                    blocksHypothesisUpgrade = true
                )
                "ABSTRACT_ONLY_RESULTS" -> PreventiveGateDecision(
                    gateId = "ABSTRACT_TO_DATASET_BRIDGE_REQUIRED",
                    rootCause = cause,
                    action = "Lower evidence score and require dataset bridge before ranking.",
                    forcedNextIntent = "abstract_to_dataset_bridge",
                    forcedQuerySeed = "supplementary data GEO accession RNA-seq cohort outcome immune profiling",
                    blocksHypothesisUpgrade = true
                )
                "NO_CONTRADICTION_SEARCH" -> PreventiveGateDecision(
                    gateId = "CONTRADICTION_REQUIRED",
                    rootCause = cause,
                    action = "Run failed-replication/no-association/heterogeneity search before upgrade.",
                    forcedNextIntent = "contradiction_search",
                    forcedQuerySeed = "failed to replicate no association conflicting results heterogeneity negative control immune response cohort",
                    blocksHypothesisUpgrade = true
                )
                "NO_CONTROL_SIGNAL" -> PreventiveGateDecision(
                    gateId = "NEGATIVE_CONTROL_REQUIRED",
                    rootCause = cause,
                    action = "Require control/negative-control language before causal interpretation.",
                    forcedNextIntent = "control_signal_search",
                    forcedQuerySeed = "negative control control group matched controls baseline immune response dataset",
                    blocksHypothesisUpgrade = true
                )
                "NO_OUTCOME_LABELS" -> PreventiveGateDecision(
                    gateId = "OUTCOME_LABEL_REQUIRED",
                    rootCause = cause,
                    action = "Search for recovery/severity/response labels before modeling.",
                    forcedNextIntent = "outcome_label_search",
                    forcedQuerySeed = "outcome recovery severity viral load response labels longitudinal immune dataset",
                    blocksHypothesisUpgrade = true
                )
                "NO_CONDITION_LABELS" -> PreventiveGateDecision(
                    gateId = "CONDITION_LABEL_REQUIRED",
                    rootCause = cause,
                    action = "Search for condition/phenotype labels before modeling.",
                    forcedNextIntent = "condition_label_search",
                    forcedQuerySeed = "condition phenotype case control allergy autoimmunity viral response immune dataset",
                    blocksHypothesisUpgrade = true
                )
                else -> PreventiveGateDecision(
                    gateId = "ROOT_CAUSE_${cause.uppercase(Locale.US)}",
                    rootCause = cause,
                    action = "Narrow the evidence lane and create a test vector for this failure.",
                    forcedNextIntent = "root_cause_repair",
                    forcedQuerySeed = "immune response dataset contradiction control outcome cohort",
                    blocksHypothesisUpgrade = true
                )
            }
        }.distinctBy { it.gateId }.take(5)
    }

    private fun buildCooldowns(signature: FailureSignature, rootCauses: List<String>): List<LaneCooldownRecord> {
        if (!rootCauses.contains("REPEATED_PMIDS") && !rootCauses.contains("BROAD_QUERY")) return emptyList()
        val count = max(signature.sameLaneFailureCount, if (signature.repeatedSkipped >= 20) 3 else 2)
        return listOf(
            LaneCooldownRecord(
                laneName = signature.failedLane.ifBlank { "unknown_lane" },
                failureCount = count,
                lastFailureReason = rootCauses.joinToString(" + "),
                cooldownCycles = if (count >= 3) 5 else 3,
                blockedUntilCycle = count + if (count >= 3) 5 else 3
            )
        )
    }

    private fun buildRegressionVectors(signature: FailureSignature, rootCauses: List<String>, gates: List<PreventiveGateDecision>): List<RegressionVector> {
        if (rootCauses.isEmpty() || gates.isEmpty()) return emptyList()
        return rootCauses.take(4).mapIndexed { index, cause ->
            val gate = gates.firstOrNull { it.rootCause == cause } ?: gates.first()
            RegressionVector(
                caseId = "v137_${cause.lowercase(Locale.US)}_$index",
                inputSignature = "new=${signature.newUsefulSources}; repeated=${signature.repeatedSkipped}; metadata=${signature.metadataOnlyRatio}; datasets=${signature.datasetCandidateCount}",
                expectedRootCause = cause,
                expectedGate = gate.gateId,
                expectedNextAction = gate.forcedNextIntent
            )
        }
    }

    fun learningOsToJson(report: LearningOsReport): JSONObject {
        return JSONObject()
            .put("incident", incidentToJson(report.incident))
            .put("preventiveGates", JSONArray(report.preventiveGates.map { gateToJson(it) }))
            .put("regressionVectors", JSONArray(report.regressionVectors.map { regressionToJson(it) }))
            .put("laneCooldowns", JSONArray(report.laneCooldowns.map { cooldownToJson(it) }))
            .put("discoveryReadiness", discoveryToJson(report.discoveryReadiness))
            .put("hypothesisUpdateGateStatus", report.hypothesisUpdateGateStatus)
            .put("nextLearningAction", report.nextLearningAction)
    }

    private fun incidentToJson(item: ResearchIncidentReceipt): JSONObject = JSONObject()
        .put("incidentId", item.incidentId)
        .put("rootCauses", JSONArray(item.rootCauses))
        .put("observedSignals", JSONArray(item.observedSignals))
        .put("failedLane", item.failedLane)
        .put("severity", item.severity)
        .put("createdAtMillis", item.createdAtMillis)

    private fun gateToJson(item: PreventiveGateDecision): JSONObject = JSONObject()
        .put("gateId", item.gateId)
        .put("rootCause", item.rootCause)
        .put("action", item.action)
        .put("forcedNextIntent", item.forcedNextIntent)
        .put("forcedQuerySeed", item.forcedQuerySeed)
        .put("blocksHypothesisUpgrade", item.blocksHypothesisUpgrade)

    private fun regressionToJson(item: RegressionVector): JSONObject = JSONObject()
        .put("caseId", item.caseId)
        .put("inputSignature", item.inputSignature)
        .put("expectedRootCause", item.expectedRootCause)
        .put("expectedGate", item.expectedGate)
        .put("expectedNextAction", item.expectedNextAction)

    private fun cooldownToJson(item: LaneCooldownRecord): JSONObject = JSONObject()
        .put("laneName", item.laneName)
        .put("failureCount", item.failureCount)
        .put("lastFailureReason", item.lastFailureReason)
        .put("cooldownCycles", item.cooldownCycles)
        .put("blockedUntilCycle", item.blockedUntilCycle)

    fun discoveryToJson(item: DiscoveryReadinessReport): JSONObject = JSONObject()
        .put("score", item.score)
        .put("state", item.state)
        .put("blockers", JSONArray(item.blockers))
        .put("strengths", JSONArray(item.strengths))
}
