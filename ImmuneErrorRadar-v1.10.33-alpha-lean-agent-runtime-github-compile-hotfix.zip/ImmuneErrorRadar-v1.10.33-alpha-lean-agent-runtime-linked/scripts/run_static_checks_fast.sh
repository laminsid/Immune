#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
find . -type d -name __pycache__ -prune -exec rm -rf {} +
find . -name "*.pyc" -delete
python3 scripts/validate_json.py
python3 scripts/audit_kotlin_delimiters.py
python3 scripts/audit_discovery_exporter_local_names_v11033.py
python3 scripts/audit_release_version_linkage_v11030.py
python3 scripts/audit_release_version_linkage_v11031.py
python3 scripts/audit_release_version_linkage_v11032.py
python3 scripts/audit_release_version_linkage_v11033.py
python3 - <<'PY_AUDIT_STRINGS'
import pathlib
bad=[]
for path in pathlib.Path('app/src/main/java').rglob('*.kt'):
    for i,line in enumerate(path.read_text(errors='replace').splitlines(),1):
        if '"""' in line:
            continue
        cnt=0
        esc=False
        for ch in line:
            if esc:
                esc=False
                continue
            if ch == '\\':
                esc=True
                continue
            if ch == '"':
                cnt += 1
        if cnt % 2 == 1:
            bad.append(f'{path}:{i}: {line[:140]}')
if bad:
    raise SystemExit('Kotlin raw/newline string literal audit failed:\n' + '\n'.join(bad[:20]))
print('Kotlin string literal audit: PASS')
PY_AUDIT_STRINGS
python3 - <<'PY_XML'
import pathlib, xml.etree.ElementTree as ET
for p in pathlib.Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('XML parse: PASS')
PY_XML
