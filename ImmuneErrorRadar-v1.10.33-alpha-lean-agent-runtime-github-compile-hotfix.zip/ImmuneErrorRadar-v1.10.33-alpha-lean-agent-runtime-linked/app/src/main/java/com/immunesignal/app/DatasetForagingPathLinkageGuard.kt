package com.immunesignal.app

/**
 * v1.10.27: Dataset foraging path linkage guard.
 * v1.10.28: Dataset pass coverage linkage aligns pass summaries with core/adjacent/mature execution paths.
 *
 * This is a wiring/integrity layer, not a biological model. It checks that the
 * route selected by the accession layer, mature-domain probe layer, pass
 * summaries, and final forager next action tell the same operational story.
 * It prevents the system from silently running a mature-domain probe while the
 * report still reads as if the route was terminally archived, and it separates
 * core accession attempts from adjacent/relaxed probes.
 */
data class DatasetForagingPathLinkageReport(
    val active: Boolean,
    val state: String,
    val coreSourcesAttempted: List<String>,
    val adjacentSourcesAttempted: List<String>,
    val matureProbeAttempted: Boolean,
    val attemptedCoreCount: Int,
    val totalQueryPathCount: Int,
    val coreQueryPathCount: Int = 0,
    val adjacentQueryPathCount: Int = 0,
    val matureProbeQueryPathCount: Int = 0,
    val coverageState: String = "NOT_EVALUATED",
    val warnings: List<String>,
    val handoffSummary: String,
    val nextAction: String,
    val claimLimit: String = DatasetForagingPathLinkageGuard.CLAIM_LIMIT
) {
    companion object {
        fun empty() = DatasetForagingPathLinkageReport(
            active = false,
            state = "NOT_EVALUATED",
            coreSourcesAttempted = emptyList(),
            adjacentSourcesAttempted = emptyList(),
            matureProbeAttempted = false,
            attemptedCoreCount = 0,
            totalQueryPathCount = 0,
            coreQueryPathCount = 0,
            adjacentQueryPathCount = 0,
            matureProbeQueryPathCount = 0,
            coverageState = "NOT_EVALUATED",
            warnings = emptyList(),
            handoffSummary = "Dataset foraging path linkage was not evaluated.",
            nextAction = "Run dataset foraging before path linkage audit."
        )
    }
}

object DatasetForagingPathLinkageGuard {
    const val CLAIM_LIMIT: String = "dataset_path_linkage_not_biological_proof"

    private val coreSources = SourcePriorityArbitrationPolicy.coreAccessionFamilies
    private val adjacentSources = setOf(
        "PUBMED_ADJACENT_DOMAIN_MINING",
        "PUBMED_CONTRADICTION",
        "PUBMED_CONTROL"
    )

    fun evaluate(
        attempts: List<DatasetSourceAttempt>,
        accessionReport: AccessionAcquisitionReport,
        matureProbeReport: MatureDomainEvidenceProbePolicy.Report,
        foragerState: String,
        foragerNextAction: String
    ): DatasetForagingPathLinkageReport {
        val attempted = attempts.filter { it.attempted && it.ncbiDb != "offline" }
        val attemptedFamilies = attempted.map { it.sourceFamily }.distinct()
        val coreAttempted = attemptedFamilies.filter { it in coreSources }
        val adjacentAttempted = attemptedFamilies.filter { it in adjacentSources }
        val matureAttempted = attemptedFamilies.any { it == MatureDomainEvidenceProbePolicy.SOURCE_FAMILY }
        val coreQueryPathCount = attempted.count { it.sourceFamily in coreSources }
        val adjacentQueryPathCount = attempted.count { it.sourceFamily in adjacentSources }
        val matureProbeQueryPathCount = attempted.count { it.sourceFamily == MatureDomainEvidenceProbePolicy.SOURCE_FAMILY }
        val classifiedQueryPathCount = coreQueryPathCount + adjacentQueryPathCount + matureProbeQueryPathCount
        val totalQueryPathCount = attempted.size
        val coverageState = if (classifiedQueryPathCount == totalQueryPathCount) "PASS_COVERAGE_CONNECTED" else "PASS_COVERAGE_GAP"
        val warnings = mutableListOf<String>()

        if (accessionReport.state == "NO_ACCESSION_ARCHIVE_ROUTE" && matureProbeReport.active) {
            warnings += "Mature-domain probe is active; terminal archive wording must be relaxed."
        }
        if (matureProbeReport.active && !foragerState.contains("MATURE_DOMAIN", ignoreCase = true)) {
            warnings += "Mature-domain probe is active but final forager state does not expose DATASET_FORAGING_MATURE_DOMAIN_EVIDENCE_PROBE."
        }
        if (matureProbeReport.active && !foragerNextAction.contains("mature", ignoreCase = true)) {
            warnings += "Mature-domain probe is active but final nextAction does not route through mature-domain evidence probing."
        }
        if (accessionReport.state == "NO_ACCESSION_CONTINUE_SOURCE_SWEEP" && coreAttempted.size < coreSources.size) {
            warnings += "Core accession sweep is incomplete; continue source sweep before archive/reframe."
        }
        if (accessionReport.state == "NO_ACCESSION_ARCHIVE_ROUTE" && coreAttempted.size < coreSources.size) {
            warnings += "Terminal archive requested before all core accession families were attempted."
        }
        if (attemptedFamilies.size != attempts.filter { it.attempted }.distinctBy { it.sourceFamily }.size) {
            warnings += "Duplicate source-family attempts detected; report should collapse them by source family for decision output."
        }
        if (coverageState != "PASS_COVERAGE_CONNECTED") {
            warnings += "Some executed dataset-foraging query paths were not classified as core, adjacent, or mature-domain coverage."
        }

        val state = when {
            warnings.isEmpty() && matureProbeReport.active -> "CONNECTED_MATURE_DOMAIN_PROBE"
            warnings.isEmpty() && accessionReport.state == "NO_ACCESSION_ARCHIVE_ROUTE" -> "CONNECTED_TERMINAL_ARCHIVE"
            warnings.isEmpty() -> "CONNECTED"
            else -> "LINKAGE_WARNINGS"
        }
        val summary = "core=${coreAttempted.joinToString(",").ifBlank { "none" }}; adjacent=${adjacentAttempted.joinToString(",").ifBlank { "none" }}; matureProbe=$matureAttempted; coverage=$coverageState ($classifiedQueryPathCount/$totalQueryPathCount); accessionState=${accessionReport.state}; foragerState=$foragerState."
        val next = when {
            warnings.isNotEmpty() -> "Repair path handoff before trusting the next autonomous move: ${warnings.first()}"
            matureProbeReport.active -> matureProbeReport.nextAction
            accessionReport.state == "NO_ACCESSION_CONTINUE_SOURCE_SWEEP" -> accessionReport.nextAction
            accessionReport.state == "NO_ACCESSION_ARCHIVE_ROUTE" -> accessionReport.nextAction
            else -> foragerNextAction.ifBlank { accessionReport.nextAction }
        }
        return DatasetForagingPathLinkageReport(
            active = true,
            state = state,
            coreSourcesAttempted = coreAttempted,
            adjacentSourcesAttempted = adjacentAttempted,
            matureProbeAttempted = matureAttempted,
            attemptedCoreCount = coreAttempted.size,
            totalQueryPathCount = totalQueryPathCount,
            coreQueryPathCount = coreQueryPathCount,
            adjacentQueryPathCount = adjacentQueryPathCount,
            matureProbeQueryPathCount = matureProbeQueryPathCount,
            coverageState = coverageState,
            warnings = warnings.distinct(),
            handoffSummary = summary,
            nextAction = next,
            claimLimit = CLAIM_LIMIT
        )
    }
}
