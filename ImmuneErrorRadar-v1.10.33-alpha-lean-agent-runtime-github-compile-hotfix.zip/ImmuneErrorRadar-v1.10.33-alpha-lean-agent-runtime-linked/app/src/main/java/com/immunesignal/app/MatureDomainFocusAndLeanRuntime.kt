package com.immunesignal.app

import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

/**
 * v1.10.32 + v1.10.33: connected focus/queue/runtime layer.
 *
 * This layer does not create biological proof. It narrows routing, preserves
 * gaps, blocks semantic replay, and emits a compact runtime decision card.
 */
data class LeadObject(
    val leadId: String,
    val source: String,
    val sourceFamily: String,
    val title: String,
    val snippet: String,
    val detectedAccessions: List<String>,
    val dataAvailabilityText: String,
    val organism: String,
    val humanLikely: Boolean,
    val omicsType: String,
    val domain: String,
    val outcomeLikely: Boolean,
    val controlLikely: Boolean,
    val timeLikely: Boolean,
    val licenseAccessLikely: Boolean,
    val sampleSizeLikely: Boolean,
    val confidence: Int,
    val claimLimit: String = EvidenceLeadAndManualSeedPolicy.CLAIM_LIMIT
)

data class MatureDomainFocusReport(
    val active: Boolean,
    val state: String,
    val selectedDomain: String,
    val selectedLabel: String,
    val focusCycleWindow: Int,
    val cyclesRemaining: Int,
    val querySeed: String,
    val reason: String,
    val nextAction: String,
    val claimLimit: String = MatureDomainFocusModePolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = MatureDomainFocusReport(false, "NOT_EVALUATED", "none", "none", 0, 0, "", "Mature domain focus was not evaluated.", "Run domain expertise first.")
    }
}

data class DomainSpecificKillCriteriaReport(
    val active: Boolean,
    val domainId: String,
    val killCriteria: List<String>,
    val killTriggered: Boolean,
    val triggerReasons: List<String>,
    val nextAction: String,
    val claimLimit: String = MatureDomainFocusModePolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = DomainSpecificKillCriteriaReport(false, "none", emptyList(), false, emptyList(), "No domain-specific kill criteria evaluated.")
    }
}

data class DomainExpertiseScoreUpgradeReport(
    val active: Boolean,
    val upgradedScores: Map<String, Int>,
    val scoringInputs: Map<String, List<String>>,
    val summary: String,
    val claimLimit: String = MatureDomainFocusModePolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = DomainExpertiseScoreUpgradeReport(false, emptyMap(), emptyMap(), "Domain expertise score upgrade was not evaluated.")
    }
}

data class KnowledgeGapQueueItem(
    val gapId: String,
    val priority: Int,
    val attemptCount: Int,
    val lastAttemptedSource: String,
    val cooldown: Int,
    val nextQuery: String,
    val status: String
)

data class KnowledgeGapQueueReport(
    val active: Boolean,
    val queueState: String,
    val items: List<KnowledgeGapQueueItem>,
    val nextAction: String,
    val claimLimit: String = MatureDomainFocusModePolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = KnowledgeGapQueueReport(false, "NOT_EVALUATED", emptyList(), "No knowledge gap queue evaluated.")
    }
}

data class StrongRouteFingerprintReport(
    val active: Boolean,
    val fingerprint: String,
    val intent: String,
    val domain: String,
    val sourceFamily: String,
    val blockerSet: List<String>,
    val axisSet: List<String>,
    val normalizedTerms: List<String>,
    val lastOutcome: String,
    val replayRisk: Boolean,
    val nextAction: String,
    val claimLimit: String = MatureDomainFocusModePolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = StrongRouteFingerprintReport(false, "", "", "none", "none", emptyList(), emptyList(), emptyList(), "none", false, "Semantic route fingerprint was not evaluated.")
    }
}

data class LeanAgentRuntimeReport(
    val active: Boolean,
    val state: String,
    val checkpointLoaded: Boolean,
    val microAgentsRun: List<String>,
    val hardGatesApplied: List<String>,
    val stateDeltas: List<String>,
    val compactDecisionCard: String,
    val nextAction: String,
    val warnings: List<String>,
    val claimLimit: String = LeanAgentRuntimePolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = LeanAgentRuntimeReport(false, "NOT_EVALUATED", false, emptyList(), emptyList(), emptyList(), "No lean runtime decision card emitted.", "Run a research cycle first.", emptyList())
    }
}

object MatureDomainFocusModePolicy {
    const val CLAIM_LIMIT = "domain_focus_search_prior_not_biological_proof"
    private const val FOCUS_CYCLES = 3

    fun selectSeed(seeds: List<MatureDomainEvidenceProbePolicy.MatureDomainSeed>, recentReports: List<String>): MatureDomainEvidenceProbePolicy.MatureDomainSeed? {
        if (!RuntimeFeatureFlags.ENABLE_MATURE_DOMAIN_FOCUS_MODE || seeds.isEmpty()) return seeds.firstOrNull()
        val priorFocus = latestFocusDomain(recentReports)
        val focused = priorFocus?.let { id -> seeds.firstOrNull { it.domainId == id } }
        return focused ?: seeds.sortedWith(compareByDescending<MatureDomainEvidenceProbePolicy.MatureDomainSeed> { it.expertiseScore }.thenByDescending { it.exposureCount }).firstOrNull()
    }

    fun evaluate(
        domainReport: DomainExpertiseMemoryPolicy.DomainExpertiseReport,
        attempts: List<DatasetSourceAttempt>,
        candidates: List<DatasetAccessionCandidate>,
        parsedMetadata: List<ParsedDatasetMetadata>,
        recentReports: List<String>
    ): MatureDomainFocusReport {
        val cards = domainReport.cards.filter { it.expertiseState.contains("MATURE", true) || it.priorExposureCount >= RuntimeFeatureFlags.MIN_DOMAIN_EXPERTISE_MATURITY_EXPOSURES }
        if (!RuntimeFeatureFlags.ENABLE_MATURE_DOMAIN_FOCUS_MODE || cards.isEmpty()) return MatureDomainFocusReport.empty().copy(state = "NO_MATURE_DOMAIN_TO_FOCUS")
        val priorFocus = latestFocusDomain(recentReports)
        val selected = priorFocus?.let { id -> cards.firstOrNull { it.domainId == id } }
            ?: cards.sortedWith(compareByDescending<DomainExpertiseMemoryPolicy.DomainExpertiseCard> { upgradedScoreFor(it, candidates, parsedMetadata, attempts) }.thenByDescending { it.priorExposureCount }).first()
        val persistedCount = countRecentFocus(recentReports, selected.domainId)
        val querySeed = buildFocusedQuery(selected)
        return MatureDomainFocusReport(
            active = true,
            state = if (persistedCount > 0) "FOCUS_DOMAIN_PERSISTING" else "FOCUS_DOMAIN_SELECTED",
            selectedDomain = selected.domainId,
            selectedLabel = selected.label,
            focusCycleWindow = FOCUS_CYCLES,
            cyclesRemaining = (FOCUS_CYCLES - persistedCount).coerceAtLeast(1),
            querySeed = querySeed,
            reason = "Focus one mature domain for 2-3 cycles; this changes routing depth only, not belief strength.",
            nextAction = "Run focused dataset lead capture for ${selected.domainId}; stop only through domain-specific kill criteria."
        )
    }

    fun killCriteria(focus: MatureDomainFocusReport, attempts: List<DatasetSourceAttempt>, candidates: List<DatasetAccessionCandidate>, parsedMetadata: List<ParsedDatasetMetadata>): DomainSpecificKillCriteriaReport {
        if (!focus.active || focus.selectedDomain == "none") return DomainSpecificKillCriteriaReport.empty()
        val criteria = criteriaFor(focus.selectedDomain)
        val corpus = (attempts.joinToString(" ") { it.query + " " + it.reason + " " + it.status } + " " + candidates.joinToString(" ") { it.sourceTitle + " " + it.conditionLabelsHint + " " + it.outcomeLabelsHint + " " + it.dataType } + " " + parsedMetadata.joinToString(" ") { it.conditionLabels.joinToString(" ") + " " + it.outcomeLabels.joinToString(" ") + " " + it.assayType }).lowercase(Locale.US)
        val reasons = mutableListOf<String>()
        val focusedAttempts = attempts.count { it.query.contains(focus.selectedDomain.substringBefore('_'), ignoreCase = true) || it.sourceFamily == MatureDomainEvidenceProbePolicy.SOURCE_FAMILY }
        val human = parsedMetadata.any { it.organism.contains("human", true) } || candidates.any { it.organismHint.contains("human", true) }
        val outcome = parsedMetadata.any { it.outcomeLabels.isNotEmpty() } || candidates.any { !it.outcomeLabelsHint.contains("unknown", true) }
        val control = parsedMetadata.any { it.controlLabels.isNotEmpty() } || candidates.any { it.reasons.any { r -> r.contains("control", true) || r.contains("comparator", true) } }
        val omics = listOf("rna", "seq", "transcript", "metabol", "cytokine", "omics", "single-cell").any { corpus.contains(it) }
        if (focusedAttempts >= 3 && !domainTermsPresent(focus.selectedDomain, corpus)) reasons += "No domain core terms after focused probes."
        if (focusedAttempts >= 3 && !human) reasons += "No human/patient cohort signal after focused probes."
        if (focusedAttempts >= 3 && !omics) reasons += "No omics/cytokine/clinical metadata signal after focused probes."
        if (focusedAttempts >= 3 && !outcome) reasons += "No outcome/severity labels after focused probes."
        if (focusedAttempts >= 3 && !control) reasons += "No control/comparator signal after focused probes."
        return DomainSpecificKillCriteriaReport(
            active = true,
            domainId = focus.selectedDomain,
            killCriteria = criteria,
            killTriggered = reasons.size >= 2,
            triggerReasons = reasons,
            nextAction = if (reasons.size >= 2) "Cool down this focus domain and rotate to next mature domain; do not archive global research if other leads/gaps remain." else "Continue focused probing until 2-3 cycle window completes or kill criteria trigger."
        )
    }

    fun scoreUpgrade(domainReport: DomainExpertiseMemoryPolicy.DomainExpertiseReport, attempts: List<DatasetSourceAttempt>, candidates: List<DatasetAccessionCandidate>, parsedMetadata: List<ParsedDatasetMetadata>, leadObjects: List<LeadObject>): DomainExpertiseScoreUpgradeReport {
        if (domainReport.cards.isEmpty()) return DomainExpertiseScoreUpgradeReport.empty()
        val scores = linkedMapOf<String, Int>()
        val inputs = linkedMapOf<String, List<String>>()
        domainReport.cards.forEach { card ->
            val nearMiss = leadObjects.count { it.domain == card.domainId || it.domain == "unknown" && card.workingVocabulary.any { t -> it.snippet.contains(t, true) } }
            val failedHistory = attempts.count { it.candidatesExtracted == 0 && card.workingVocabulary.any { t -> it.query.contains(t, true) } }
            val candidateHits = candidates.count { card.workingVocabulary.any { t -> it.sourceTitle.contains(t, true) || it.conditionLabelsHint.contains(t, true) } }
            val metadataHits = parsedMetadata.count { card.workingVocabulary.any { t -> it.conditionLabels.joinToString(" ").contains(t, true) || it.tissueOrSource.contains(t, true) } }
            val confounders = card.falsificationGates.count { it.contains("control", true) || it.contains("medication", true) || it.contains("time", true) }
            val upgraded = (card.expertiseScore + nearMiss * 4 + candidateHits * 5 + metadataHits * 8 + failedHistory.coerceAtMost(5) + confounders).coerceAtMost(95)
            scores[card.domainId] = upgraded
            inputs[card.domainId] = listOf("vocabulary=${card.workingVocabulary.size}", "failedQueryHistory=$failedHistory", "nearMissLeads=$nearMiss", "knownConfounders=$confounders", "candidateDatasets=$candidateHits", "manualSeedsLinked=${leadObjects.count { it.sourceFamily == EvidenceLeadAndManualSeedPolicy.MANUAL_MODE }}")
        }
        return DomainExpertiseScoreUpgradeReport(true, scores, inputs, "Domain expertise upgraded as a search prior only; no biological proof or hypothesis upgrade.")
    }

    fun gapQueue(focus: MatureDomainFocusReport, attempts: List<DatasetSourceAttempt>, candidates: List<DatasetAccessionCandidate>, parsedMetadata: List<ParsedDatasetMetadata>): KnowledgeGapQueueReport {
        val gaps = listOf("license_access", "sample_size", "outcome_labels", "time_order", "control_or_comparator", "minimum_metadata", "condition_labels", "human_or_patient_data")
        val items = gaps.mapIndexed { index, gap ->
            val closed = when (gap) {
                "sample_size" -> parsedMetadata.any { it.sampleSizeStatus.contains("available", true) } || candidates.any { !it.sampleSizeHint.contains("unknown", true) }
                "outcome_labels" -> parsedMetadata.any { it.outcomeLabels.isNotEmpty() } || candidates.any { !it.outcomeLabelsHint.contains("unknown", true) }
                "time_order" -> parsedMetadata.any { it.timeCourseLabels.isNotEmpty() } || candidates.any { !it.timeCourseHint.contains("unknown", true) }
                "control_or_comparator" -> parsedMetadata.any { it.controlLabels.isNotEmpty() }
                "condition_labels" -> parsedMetadata.any { it.conditionLabels.isNotEmpty() } || candidates.any { it.conditionLabelsHint.isNotBlank() && !it.conditionLabelsHint.contains("unknown", true) }
                "human_or_patient_data" -> parsedMetadata.any { it.organism.contains("human", true) } || candidates.any { it.organismHint.contains("human", true) }
                "minimum_metadata" -> parsedMetadata.isNotEmpty()
                else -> candidates.any { it.reasons.any { r -> r.contains("license", true) || r.contains("access", true) } }
            }
            val attempted = attempts.count { it.query.contains(gap.substringBefore('_'), true) || it.status.contains(gap.substringBefore('_'), true) }
            KnowledgeGapQueueItem(
                gapId = gap,
                priority = if (closed) 0 else (100 - index * 7).coerceAtLeast(25),
                attemptCount = attempted,
                lastAttemptedSource = attempts.lastOrNull()?.sourceFamily ?: "none",
                cooldown = if (!closed && attempted > 2) 1 else 0,
                nextQuery = buildGapQuery(focus, gap),
                status = if (closed) "CLOSED_OR_PARTIAL" else "OPEN"
            )
        }.filter { it.status == "OPEN" }.sortedByDescending { it.priority }
        return KnowledgeGapQueueReport(
            active = true,
            queueState = if (items.isEmpty()) "NO_OPEN_CORE_GAPS" else "OPEN_GAPS_ROUTABLE",
            items = items,
            nextAction = items.firstOrNull()?.let { "Run gap query: ${it.nextQuery}" } ?: "All core gaps are closed or partially closed; proceed to metadata/evidence gating."
        )
    }

    fun strongFingerprint(queries: List<ResearchQuery>, attempts: List<DatasetSourceAttempt>, focus: MatureDomainFocusReport, gapQueue: KnowledgeGapQueueReport, recentReports: List<String>): StrongRouteFingerprintReport {
        if (!RuntimeFeatureFlags.ENABLE_STRONG_ROUTE_FINGERPRINT || queries.isEmpty()) return StrongRouteFingerprintReport.empty()
        val intent = when {
            gapQueue.items.any { it.gapId == "outcome_labels" } -> "outcome_label_probe"
            focus.active -> "mature_domain_focus_probe"
            else -> "dataset_lead_foraging"
        }
        val domain = focus.selectedDomain.takeIf { it != "none" } ?: "general_immune_dataset"
        val sourceFamily = attempts.lastOrNull()?.sourceFamily ?: "unknown_source"
        val blockerSet = gapQueue.items.take(4).map { it.gapId }
        val axisSet = queries.flatMap { q -> listOf("histamine", "diabetes", "inflammation", "aging", "gut", "mast", "omics").filter { q.query.contains(it, true) } }.distinct()
        val normalizedTerms = queries.joinToString(" ") { it.query.lowercase(Locale.US) }.replace(Regex("[^a-z0-9\\s-]"), " ").split(Regex("\\s+")).filter { it.length > 3 }.distinct().take(16)
        val lastOutcome = attempts.lastOrNull()?.status ?: "none"
        val raw = listOf(intent, domain, sourceFamily, blockerSet.joinToString("|"), axisSet.joinToString("|"), normalizedTerms.joinToString("|"), lastOutcome).joinToString("::")
        val fp = sha256(raw).take(20)
        val replay = recentReports.take(RuntimeFeatureFlags.ROUTE_FINGERPRINT_LOOKBACK).any { it.contains(fp) || (it.contains(intent) && it.contains(domain) && it.contains(sourceFamily) && blockerSet.any { b -> it.contains(b) }) }
        return StrongRouteFingerprintReport(true, fp, intent, domain, sourceFamily, blockerSet, axisSet, normalizedTerms, lastOutcome, replay, if (replay) "Rewrite route: same intent + blocker + source family indicates semantic replay risk." else "Store semantic route fingerprint and continue.")
    }

    private fun latestFocusDomain(recentReports: List<String>): String? = recentReports.asReversed().asSequence().mapNotNull { line ->
        val obj = runCatching { JSONObject(line) }.getOrNull() ?: return@mapNotNull null
        val forager = obj.optJSONObject("datasetForagingReport") ?: obj.optJSONObject("datasetForaging") ?: return@mapNotNull null
        val focus = forager.optJSONObject("matureDomainFocusReport") ?: return@mapNotNull null
        focus.optString("selectedDomain").takeIf { it.isNotBlank() && it != "none" }
    }.firstOrNull()

    private fun countRecentFocus(recentReports: List<String>, domainId: String): Int = recentReports.take(FOCUS_CYCLES).count { line ->
        line.contains("\"selectedDomain\":\"$domainId\"") || line.contains("\"selectedDomain\": \"$domainId\"")
    }

    fun buildFocusedQuery(card: DomainExpertiseMemoryPolicy.DomainExpertiseCard): String {
        val terms = card.workingVocabulary.take(6).joinToString(" ") { if (it.contains(" ")) "\"$it\"" else it }
        return "$terms RNA-seq GSE PRJNA SRP E-MTAB SDY human cohort outcome severity control comparator metadata data availability"
    }

    private fun criteriaFor(domainId: String): List<String> = when (domainId) {
        "antihistamine_histamine_mast_cell" -> listOf("No histamine/mast-cell/urticaria terms after 3 focused probes", "No human cohort", "No omics/cytokine/clinical metadata", "No outcome or severity labels", "Only treatment-response papers without dataset access")
        "diabetes_metabolic_inflammation" -> listOf("No diabetes phenotype", "No metabolic inflammation markers", "No cohort/control labels", "No transcriptomic/metabolomic dataset", "Only generic inflammation papers")
        else -> listOf("No domain core terms after focused probes", "No human/patient cohort", "No omics/clinical metadata", "No outcome labels", "No control/comparator")
    }

    private fun domainTermsPresent(domainId: String, corpus: String): Boolean = when (domainId) {
        "antihistamine_histamine_mast_cell" -> listOf("histamine", "mast", "urticaria", "allergy").any { corpus.contains(it) }
        "diabetes_metabolic_inflammation" -> listOf("diabetes", "metabolic", "glucose", "insulin").any { corpus.contains(it) }
        "gastric_acid_reflux_gut_barrier" -> listOf("gastric", "reflux", "gut", "barrier", "microbiome").any { corpus.contains(it) }
        "aging_immunosenescence_inflammaging" -> listOf("aging", "ageing", "immunosenescence", "inflammaging").any { corpus.contains(it) }
        else -> domainId.split('_').any { it.length > 4 && corpus.contains(it) }
    }

    private fun buildGapQuery(focus: MatureDomainFocusReport, gap: String): String {
        val domain = focus.querySeed.ifBlank { focus.selectedDomain.replace('_', ' ') }
        val gapTerms = when (gap) {
            "license_access" -> "open access supplementary data availability repository accession"
            "sample_size" -> "sample size n cohort metadata"
            "outcome_labels" -> "outcome severity recovery response phenotype labels"
            "time_order" -> "longitudinal time course baseline follow-up"
            "control_or_comparator" -> "control comparator healthy cohort case control"
            "minimum_metadata" -> "metadata samples phenotype assay platform"
            "condition_labels" -> "condition disease phenotype diagnosis labels"
            else -> "human patient cohort"
        }
        return "$domain $gapTerms"
    }

    private fun upgradedScoreFor(card: DomainExpertiseMemoryPolicy.DomainExpertiseCard, candidates: List<DatasetAccessionCandidate>, parsedMetadata: List<ParsedDatasetMetadata>, attempts: List<DatasetSourceAttempt>): Int {
        val candidateHits = candidates.count { c -> card.workingVocabulary.any { t -> c.sourceTitle.contains(t, true) || c.conditionLabelsHint.contains(t, true) } }
        val metadataHits = parsedMetadata.count { m -> card.workingVocabulary.any { t -> m.conditionLabels.joinToString(" ").contains(t, true) || m.assayType.contains(t, true) } }
        val failureHistory = attempts.count { it.candidatesExtracted == 0 && card.workingVocabulary.any { t -> it.query.contains(t, true) } }.coerceAtMost(5)
        return (card.expertiseScore + candidateHits * 5 + metadataHits * 8 + failureHistory).coerceAtMost(95)
    }

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }
}

object LeanAgentRuntimePolicy {
    const val CLAIM_LIMIT = "lean_agent_runtime_routing_only_not_biological_proof"

    fun emit(
        leadObjects: List<LeadObject>,
        focus: MatureDomainFocusReport,
        gaps: KnowledgeGapQueueReport,
        fingerprint: StrongRouteFingerprintReport,
        finalState: String,
        nextAction: String
    ): LeanAgentRuntimeReport {
        if (!RuntimeFeatureFlags.ENABLE_LEAN_AGENT_RUNTIME_ORCHESTRATOR) return LeanAgentRuntimeReport.empty()
        val agents = mutableListOf("LeadForager", "ManualSeedParser", "DatasetCandidateBuilder", "MetadataGateChecker", "ReportConsistencyGuard")
        if (focus.active) agents += "DomainExpertiseUpdater"
        if (fingerprint.active) agents += "RouteFingerprintChecker"
        val gates = listOf("accession_pattern_gate", "pmid_doi_pattern_gate", "metadata_presence_gate", "outcome_control_time_gate", "archive_allowed_gate")
        val deltas = mutableListOf<String>()
        if (leadObjects.isNotEmpty()) deltas += "lead_ledger_delta=${leadObjects.size}"
        if (focus.active) deltas += "domain_focus=${focus.selectedDomain}"
        if (gaps.items.isNotEmpty()) deltas += "open_gap_queue=${gaps.items.size}"
        if (fingerprint.replayRisk) deltas += "route_replay_risk=true"
        val card = "state=$finalState | leads=${leadObjects.size} | focus=${focus.selectedDomain} | openGaps=${gaps.items.size} | replay=${fingerprint.replayRisk} | next=$nextAction"
        return LeanAgentRuntimeReport(
            active = true,
            state = "LEAN_AGENT_RUNTIME_DECISION_CARD",
            checkpointLoaded = true,
            microAgentsRun = agents.distinct(),
            hardGatesApplied = gates,
            stateDeltas = deltas,
            compactDecisionCard = card.take(500),
            nextAction = nextAction,
            warnings = listOf("Runtime orchestrates deterministic micro-agents only; no continuous LLM agent and no claim upgrade.")
        )
    }
}
