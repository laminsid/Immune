package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30351GithubSafeLiteMatrixTest {
    @Test
    fun liteMatrixHasFullCohortLabelsAndSelectedProbeRows() {
        assertTrue(GSE85047SurvivalAxisLiteMatrixV30351.attached())
        assertTrue(GSE85047SurvivalAxisLiteMatrixV30351.readyForSurvivalAxisLite())
        val rows = GSE85047SurvivalAxisLiteMatrixV30351.rows()
        assertEquals(283, rows.size)
        assertEquals(55, rows.count { it.group == "case_mycn_amplified" })
        assertEquals(222, rows.count { it.group == "control_non_mycn" })
        assertTrue(rows.first().values.containsKey("PROBE_2318743"))
        assertEquals(20, GSE85047SurvivalAxisLiteMatrixV30351.selectedProbes.size)
    }

    @Test
    fun liteMatrixBoundaryDoesNotPretendFullTranscriptomeDiscovery() {
        val boundary = GSE85047SurvivalAxisLiteMatrixV30351.claimBoundary()
        assertTrue(boundary.contains("not a full transcriptome"))
        assertTrue(boundary.contains("not partner-gene discovery fuel"))
    }
}
