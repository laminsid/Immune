package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30345BiologicalContextContinuityTest {
    @Test
    fun topicFrameSeparatesHumanPediatricGeneticContext() {
        val frame = BiologicalContextContinuityLayerV30345.classifyTopic(
            "gse85047 pediatric neuroblastoma mycn amplified vs non immune cold cd8 nk cytotoxicity"
        )
        assertEquals("HUMAN", frame.requestedOrganism)
        assertEquals("PEDIATRIC", frame.ageContext)
        assertEquals("GENE_EXPRESSION_OR_GENETIC_CONTEXT", frame.geneticContext)
        assertTrue(frame.requiredQueryTerms.contains("pediatric"))
        assertTrue(frame.requiredQueryTerms.contains("human"))
        assertTrue(frame.transferRule.contains("HUMAN_GENE_EXPRESSION_SUPPORT_REQUIRES_HUMAN_ROWS"))
    }

    @Test
    fun evidenceContextSeparatesPlantMicrobeVirusAndAnimal() {
        assertEquals("PLANT", BiologicalContextContinuityLayerV30345.classifyEvidenceText("Arabidopsis plant immunity transcriptome").organism)
        assertEquals("MICROBE", BiologicalContextContinuityLayerV30345.classifyEvidenceText("bacterial microbiome strain gene expression").organism)
        assertEquals("VIRUS", BiologicalContextContinuityLayerV30345.classifyEvidenceText("viral genome Ebola filovirus glycoprotein").organism)
        assertEquals("ANIMAL_MODEL", BiologicalContextContinuityLayerV30345.classifyEvidenceText("murine mouse neuroblastoma single-cell model").organism)
    }

    @Test
    fun proofQueriesReceiveBiologicalContinuationFuel() {
        val queries = ResearchObjectiveV3.ContinueHypothesisProof(
            topic = "pediatric neuroblastoma MYCN CD8 NK GSE85047"
        ).querySeeds()
        val joined = queries.joinToString(" ").lowercase()
        assertTrue(joined.contains("pediatric"))
        assertTrue(joined.contains("age group"))
        assertTrue(joined.contains("healthy control"))
        assertTrue(joined.contains("gene symbol"))
        assertTrue(joined.contains("orthology not assumed"))
    }

    @Test
    fun topicalRelevanceBlocksPathogenOrPlantGeneticsAsHumanHostSupport() {
        val frame = BiomedicalTopicFrameV3.from("human cancer tumor immune microenvironment CD8 GZMB")
        val plant = EvidenceTopicalRelevanceHardGateV30324.evaluate(
            frame,
            "Arabidopsis plant immunity transcriptome cancer-like stress dataset GSE999",
            EvidenceRoleV3.DATASET,
            SourceKindV3.GEO
        )
        assertFalse(plant.countsAsSupport)
        assertEquals("PLANT", plant.organismMatch)

        val virus = EvidenceTopicalRelevanceHardGateV30324.evaluate(
            frame,
            "viral genome immune evasion dataset GSE998",
            EvidenceRoleV3.DATASET,
            SourceKindV3.GEO
        )
        assertFalse(virus.countsAsSupport)
        assertEquals("VIRUS", virus.organismMatch)
    }
    @Test
    fun macrophageAndMacropTruncatedTitlesDoNotBecomePlantContext() {
        val topic = BiologicalContextContinuityLayerV30345.classifyTopic(
            "cancer tumor immune microenvironment macrophage myeloid cd8 gzmb"
        )
        assertEquals("HUMAN", topic.requestedOrganism)
        assertFalse(topic.requiredQueryTerms.joinToString(" ").lowercase().contains("plant genetics"))

        val evidence = BiologicalContextContinuityLayerV30345.classifyEvidenceText(
            "MYCN-driven neuroblastoma has low T-cell content and macrophage suppression"
        )
        assertFalse(evidence.organism == "PLANT")
    }

}
