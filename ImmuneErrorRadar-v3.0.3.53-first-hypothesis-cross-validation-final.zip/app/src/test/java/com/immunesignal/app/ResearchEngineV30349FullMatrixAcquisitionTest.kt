package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30349FullMatrixAcquisitionTest {
    @Test
    fun acquisitionContractKeepsOfficialGse85047MatrixRouteAndEmbeddedState() {
        val manifest = GSE85047FullMatrixAcquisitionV30349.manifestJson(localRowsObserved = 0, networkAvailable = false)
        assertEquals("GSE85047", manifest.getString("accession"))
        assertEquals(283, manifest.getInt("expectedPrimaryTumorCount"))
        assertTrue(manifest.getString("seriesMatrixUrl").contains("GSE85047_series_matrix.txt.gz"))
        assertEquals("GITHUB_SAFE_GSE85047_LITE_MATRIX_ATTACHED_REVIEW_ONLY", manifest.getString("state"))
    }

    @Test
    fun acquisitionFuelIsInjectedIntoOpenDiscoveryContinuation() {
        val fuel = GSE85047FullMatrixAcquisitionV30349.continuationFuel().joinToString(" ")
        assertTrue(fuel.contains("283 primary untreated"))
        assertTrue(fuel.contains("MYCN amplification status"))
        assertTrue(fuel.contains("Do not replace full matrix with 6v6"))
    }
}
