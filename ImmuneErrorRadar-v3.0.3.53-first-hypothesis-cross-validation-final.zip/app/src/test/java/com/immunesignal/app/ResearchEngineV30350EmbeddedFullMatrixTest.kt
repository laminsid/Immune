package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30350EmbeddedFullMatrixTest {
    @Test
    fun v30350WrapperDelegatesToGithubSafeLiteMatrixAfterRawBundleRemoval() {
        val manifest = GSE85047EmbeddedFullMatrixV30350.manifestJson()
        assertEquals("GSE85047", manifest.getString("accession"))
        assertEquals(283, manifest.getInt("observedSampleCount"))
        assertEquals(20, manifest.getInt("selectedProbeCount"))
        assertEquals("GSE85047EmbeddedFullMatrixV30350", manifest.getString("compatWrapper"))
        assertEquals("GSE85047SurvivalAxisLiteMatrixV30351", manifest.getString("replacedBy"))
        assertTrue(manifest.getString("assetLiteMatrixPath").contains("GSE85047_SURVIVAL_AXIS_LITE_MATRIX_v30351.csv"))
    }

    @Test
    fun liteMatrixAttachedChangesGateButDoesNotUnlockTreatmentOrGlobalDiscovery() {
        val gate = GSE85047FullMatrixAcquisitionV30349.manifestJson(localRowsObserved = 0, networkAvailable = false)
        assertEquals("GITHUB_SAFE_GSE85047_LITE_MATRIX_ATTACHED_REVIEW_ONLY", gate.getString("state"))
        assertTrue(GSE85047EmbeddedFullMatrixV30350.attached())
        assertTrue(GSE85047EmbeddedFullMatrixV30350.claimBoundary().contains("full transcriptome ETL"))
        assertFalse(GSE85047EmbeddedFullMatrixV30350.claimBoundary().contains("treatment recommendation"))
    }
}
