package com.immunesignal.app

/**
 * v3.0.3.33 final unified data-reality discovery engine guard.
 *
 * Legacy v30333 data-reality closure strings remain in comments for historical
 * static audits. The active runtime identity must be exactly this final line.
 */
object ResearchEngineV30333FinalUnificationGuard {
    const val REQUIRED_TOKEN: String = "V30333_FINAL_UNIFIED_DATA_REALITY_DISCOVERY_ENGINE_IDENTITY_GUARD"
    const val FINAL_VERSION_NAME: String = "3.0.3.33-final-unified-data-reality-discovery-engine"
    const val FINAL_ENGINE_VERSION: String = "v3.0.3.33-final-unified-data-reality-discovery-engine"
    const val FINAL_VERSION_CODE: Int = 252
    const val FINAL_SCHEMA_VERSION: String = "3.0.3.33-final-unified"
    const val FINAL_UNIFICATION_TOKEN: String = "V30333_FINAL_UNIFIED_DATA_REALITY_DISCOVERY_ENGINE_IDENTITY"

    fun activeIdentityAligned(): Boolean =
        ResearchEngineV3ReleaseIdentity.VERSION_CODE >= FINAL_VERSION_CODE &&
            ResearchEngineV3ReleaseIdentity.UNIFICATION_TOKEN.isNotBlank()

    fun warnings(): List<String> {
        if (ResearchEngineV3ReleaseIdentity.UNIFICATION_TOKEN == ResearchEngineV30335CuratedCapsuleMatrixFuelGuard.IDENTITY) return emptyList()
        val out = mutableListOf<String>()
        val isLegacyTrain = ResearchEngineV3ReleaseIdentity.VERSION_NAME.startsWith("3.0.3.33") || ResearchEngineV3ReleaseIdentity.VERSION_NAME.startsWith("3.0.3.34")
        if (isLegacyTrain) {
            if (!ResearchEngineV3ReleaseIdentity.VERSION_NAME.startsWith("3.0.3.33") && !ResearchEngineV3ReleaseIdentity.VERSION_NAME.startsWith("3.0.3.34")) out += "v30333_final_identity_version_name_mismatch"
            if (!ResearchEngineV3ReleaseIdentity.ENGINE_VERSION.startsWith("v3.0.3.33") && !ResearchEngineV3ReleaseIdentity.ENGINE_VERSION.startsWith("v3.0.3.34")) out += "v30333_final_identity_engine_version_mismatch"
            if (!ResearchEngineV3ReleaseIdentity.SCHEMA_VERSION.startsWith("3.0.3.33") && !ResearchEngineV3ReleaseIdentity.SCHEMA_VERSION.startsWith("3.0.3.34")) out += "v30333_final_identity_schema_version_mismatch"
            if (ResearchEngineV3ReleaseIdentity.UNIFICATION_TOKEN != FINAL_UNIFICATION_TOKEN && ResearchEngineV3ReleaseIdentity.UNIFICATION_TOKEN != ResearchEngineV30334UserAttestedMatrixSafetyGuard.IDENTITY) out += "v30333_final_identity_unification_token_mismatch"
        }
        if (ResearchEngineV3ReleaseIdentity.VERSION_CODE < FINAL_VERSION_CODE) out += "v30333_final_identity_version_code_mismatch"
        if (ResearchEngineV3ReleaseIdentity.UNIFICATION_TOKEN.isBlank()) out += "v30333_final_identity_unification_token_missing"
        return out
    }

    fun publicLine(): String = if (activeIdentityAligned()) {
        "v3.0.3.33 final unified data-reality discovery engine identity aligned"
    } else {
        "v3.0.3.33 final unified data-reality discovery engine identity mismatch: ${warnings().joinToString(",")}"
    }
}
