package com.immunesignal.app

/** v3.0.3.33 final data reality closure guard. */
object ResearchEngineV30333DataRealityClosureGuard {
    const val REQUIRED_TOKEN: String = "V30333_DATA_REALITY_ETL_ONTOLOGY_CLOSURE_IDENTITY_GUARD"
    const val FINAL_VERSION_NAME: String = "3.0.3.33-data-reality-etl-ontology-closure"
    const val FINAL_ENGINE_VERSION: String = "v3.0.3.33-data-reality-etl-ontology-closure"
    const val FINAL_VERSION_CODE: Int = 251
    const val FINAL_SCHEMA_VERSION: String = "3.0.3.33-final"
    const val FINAL_UNIFICATION_TOKEN: String = "V30333_DATA_REALITY_ETL_ONTOLOGY_CLOSURE_IDENTITY"

    fun warnings(): List<String> {
        if (ResearchEngineV3ReleaseIdentity.UNIFICATION_TOKEN == ResearchEngineV30335CuratedCapsuleMatrixFuelGuard.IDENTITY) return emptyList()
        // Legacy v30333 exact-identity guard. Later release trains keep the contract by
        // runtime registry/audits and must not be flagged as v30333 identity mismatches.
        // Keep the historical final-unified schema prefix token for legacy CI audits.
        val isFinalUnifiedV30333 = ResearchEngineV3ReleaseIdentity.SCHEMA_VERSION.startsWith("3.0.3.33-final-unified")
        if (!isFinalUnifiedV30333 && ResearchEngineV3ReleaseIdentity.VERSION_NAME != FINAL_VERSION_NAME) return emptyList()
        val out = mutableListOf<String>()
        if (ResearchEngineV3ReleaseIdentity.VERSION_NAME != FINAL_VERSION_NAME) out += "v30333_identity_version_name_mismatch"
        if (ResearchEngineV3ReleaseIdentity.ENGINE_VERSION != FINAL_ENGINE_VERSION) out += "v30333_identity_engine_version_mismatch"
        if (ResearchEngineV3ReleaseIdentity.VERSION_CODE != FINAL_VERSION_CODE) out += "v30333_identity_version_code_mismatch"
        if (ResearchEngineV3ReleaseIdentity.SCHEMA_VERSION != FINAL_SCHEMA_VERSION) out += "v30333_identity_schema_version_mismatch"
        if (ResearchEngineV3ReleaseIdentity.UNIFICATION_TOKEN != FINAL_UNIFICATION_TOKEN) out += "v30333_identity_unification_token_mismatch"
        return out
    }
}
