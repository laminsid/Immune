package com.immunesignal.app

import java.util.Locale

/**
 * v1.8.7: hypothesis-lineage discovery graph. Token: hypothesis_lineage_discovery_graph.
 *
 * The previous layers select, stress-test, enforce, and verify a discovery move.
 * This layer records where each hypothesis came from, which evidence changed it,
 * which contradiction must be carried forward, and whether the route should be
 * split, merged, cooled down, or kept as a bounded inspection path. It is a
 * provenance and routing layer only: no biological proof, diagnosis, treatment,
 * or causal claim is created here.
 */
data class ScientificLineageNode(
    val nodeId: String,
    val nodeType: String,
    val label: String,
    val source: String,
    val confidence: Int,
    val evidenceKeys: List<String>,
    val parentIds: List<String>
)

data class HypothesisLineageCard(
    val hypothesisId: String,
    val label: String,
    val origin: String,
    val priorState: String,
    val currentState: String,
    val parentEvidence: List<String>,
    val contradictions: List<String>,
    val splitOrMergeAction: String,
    val confidenceShift: Int,
    val lineageVerdict: String,
    val nextLineageTest: String
)

data class ScientificDiscoveryLineageReport(
    val active: Boolean,
    val version: String,
    val lineageState: String,
    val graphCompletenessScore: Int,
    val activeHypotheses: Int,
    val splitRequired: Boolean,
    val mergeCandidates: List<String>,
    val contradictionCarryForward: List<String>,
    val lineageNodes: List<ScientificLineageNode>,
    val hypothesisLineages: List<HypothesisLineageCard>,
    val forcedEvidenceKeys: List<String>,
    val forcedDirectiveTerms: List<String>,
    val nextLineageAction: String,
    val reportLine: String,
    val claimLimit: String = "hypothesis_lineage_guides_routing_not_proof"
) {
    companion object {
        fun empty() = ScientificDiscoveryLineageReport(
            active = false,
            version = "v1.8.7",
            lineageState = "NOT_RUN",
            graphCompletenessScore = 0,
            activeHypotheses = 0,
            splitRequired = false,
            mergeCandidates = emptyList(),
            contradictionCarryForward = emptyList(),
            lineageNodes = emptyList(),
            hypothesisLineages = emptyList(),
            forcedEvidenceKeys = emptyList(),
            forcedDirectiveTerms = emptyList(),
            nextLineageAction = "Run a discovery cycle before building hypothesis lineage.",
            reportLine = "Hypothesis lineage graph did not run.",
            claimLimit = "hypothesis_lineage_guides_routing_not_proof"
        )
    }
}

object ScientificDiscoveryLineageEngineV187 {
    fun build(
        hypothesisObjects: List<HypothesisObject>,
        evidenceObjects: List<EvidenceObject>,
        datasetForaging: DatasetForagingReport,
        knowledgeMap: KnowledgeMapReport,
        epistemicBelief: EpistemicBeliefReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        executionPolicy: ScientificDiscoveryExecutionPolicyReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport,
        causalReadiness: CausalReadinessReport,
        miniPeerReview: MiniPeerReviewReport
    ): ScientificDiscoveryLineageReport {
        if (
            hypothesisObjects.isEmpty() && evidenceObjects.isEmpty() && datasetForaging.candidates.isEmpty() &&
            !deepDiscovery.active && !executionPolicy.active && !outcomeVerifier.active
        ) return ScientificDiscoveryLineageReport.empty()

        val nodes = buildLineageNodes(hypothesisObjects, evidenceObjects, datasetForaging, knowledgeMap, deepDiscovery, outcomeVerifier)
        val cards = buildHypothesisCards(
            hypothesisObjects = hypothesisObjects,
            evidenceObjects = evidenceObjects,
            datasetForaging = datasetForaging,
            epistemicBelief = epistemicBelief,
            deepDiscovery = deepDiscovery,
            executionPolicy = executionPolicy,
            outcomeVerifier = outcomeVerifier,
            causalReadiness = causalReadiness,
            miniPeerReview = miniPeerReview
        )
        val contradictionCarry = buildContradictionCarryForward(cards, deepDiscovery, miniPeerReview, outcomeVerifier).take(12)
        val mergeCandidates = buildMergeCandidates(cards, knowledgeMap).take(8)
        val splitRequired = cards.any { it.splitOrMergeAction.contains("SPLIT", true) } || contradictionCarry.any { it.contains("split", true) }
        val forcedEvidence = normalizeEvidence(
            cards.flatMap { it.parentEvidence } + cards.flatMap { it.contradictions } + contradictionCarry +
                outcomeVerifier.forcedNextEvidence + executionPolicy.forcedEvidenceKeys + causalReadiness.blockers + miniPeerReview.missingEvidence
        ).take(18)
        val forcedTerms = normalizeTerms(
            cards.flatMap { compactTokens(it.nextLineageTest, 14) } +
                cards.flatMap { compactTokens(it.splitOrMergeAction, 10) } +
                contradictionCarry.flatMap { compactTokens(it, 10) } +
                mergeCandidates.flatMap { compactTokens(it, 8) } +
                deepDiscovery.decisiveExperiment.nextQuery.split(' ')
        ).take(52)
        val score = graphScore(nodes, cards, datasetForaging, causalReadiness, outcomeVerifier)
        val state = when {
            cards.any { it.lineageVerdict == "LINEAGE_BROKEN_REROUTE" } -> "LINEAGE_BROKEN_REROUTE"
            splitRequired -> "SPLIT_ROUTE_BEFORE_NEXT_DISCOVERY"
            contradictionCarry.isNotEmpty() -> "CONTRADICTION_CARRY_FORWARD"
            score >= 75 -> "LINEAGE_READY_FOR_TARGETED_INSPECTION"
            score >= 45 -> "PARTIAL_LINEAGE_NEEDS_DECISIVE_EVIDENCE"
            else -> "BOOTSTRAP_LINEAGE"
        }
        val nextAction = when (state) {
            "LINEAGE_BROKEN_REROUTE" -> "Do not reuse the current route unchanged; rebuild lineage from unmet evidence keys and strongest contradiction."
            "SPLIT_ROUTE_BEFORE_NEXT_DISCOVERY" -> "Split mixed mechanisms into separate route hypotheses before searching again."
            "CONTRADICTION_CARRY_FORWARD" -> "Carry the strongest contradiction into the next query and require control/outcome/time evidence."
            "LINEAGE_READY_FOR_TARGETED_INSPECTION" -> "Run the targeted lineage test; keep claim language bounded to inspection."
            else -> "Build minimum metadata lineage: accession → condition/control/time/outcome → hypothesis before any mechanism wording."
        }
        val reportLine = "v1.8.7 lineage: $state score=$score/100; hypotheses=${cards.size}; split=$splitRequired; carry=${contradictionCarry.take(2).joinToString(" | ").ifBlank { "none" }}."
        return ScientificDiscoveryLineageReport(
            active = true,
            version = "v1.8.7-hypothesis-lineage-discovery-graph",
            lineageState = state,
            graphCompletenessScore = score,
            activeHypotheses = cards.size,
            splitRequired = splitRequired,
            mergeCandidates = mergeCandidates,
            contradictionCarryForward = contradictionCarry,
            lineageNodes = nodes.take(40),
            hypothesisLineages = cards.take(12),
            forcedEvidenceKeys = forcedEvidence,
            forcedDirectiveTerms = forcedTerms,
            nextLineageAction = nextAction,
            reportLine = reportLine.take(520),
            claimLimit = "hypothesis_lineage_guides_routing_not_proof"
        )
    }

    private fun buildLineageNodes(
        hypothesisObjects: List<HypothesisObject>,
        evidenceObjects: List<EvidenceObject>,
        datasetForaging: DatasetForagingReport,
        knowledgeMap: KnowledgeMapReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport
    ): List<ScientificLineageNode> = buildList {
        hypothesisObjects.take(8).forEach { h ->
            add(
                ScientificLineageNode(
                    nodeId = "hypothesis:${safeId(h.hypothesisId)}",
                    nodeType = "hypothesis",
                    label = h.label.take(160),
                    source = "hypothesis_object",
                    confidence = ((h.evidenceScore10 * 10).toInt() + h.dataTrustScore + h.causalityScore) / 3,
                    evidenceKeys = normalizeEvidence(h.missingData + h.falsification + h.minimumDataPackStatus),
                    parentIds = emptyList()
                )
            )
        }
        evidenceObjects.take(12).forEach { e ->
            add(
                ScientificLineageNode(
                    nodeId = "evidence:${safeId(e.evidenceId)}",
                    nodeType = if (e.contradictsHypothesis) "contradiction_evidence" else "evidence",
                    label = e.title.take(160),
                    source = e.sourceType,
                    confidence = e.qualityScore,
                    evidenceKeys = normalizeEvidence(e.decisionImpact + " " + e.reasons.joinToString(" ") + " " + e.accessionIds.joinToString(" ")),
                    parentIds = listOfNotNull(e.linkedHypothesisId.takeIf { it.isNotBlank() }?.let { "hypothesis:${safeId(it)}" })
                )
            )
        }
        datasetForaging.parsedMetadata.take(12).forEach { m ->
            add(
                ScientificLineageNode(
                    nodeId = "dataset:${safeId(m.accession)}",
                    nodeType = "dataset_metadata",
                    label = "${m.accession} ${m.organism} ${m.assayType}".take(160),
                    source = m.sourceFamily,
                    confidence = m.metadataQualityScore,
                    evidenceKeys = normalizeEvidence(m.conditionLabels + m.outcomeLabels + m.controlLabels + m.timeCourseLabels + m.tissueOrSource + m.assayType),
                    parentIds = emptyList()
                )
            )
        }
        knowledgeMap.gaps.take(8).forEach { g ->
            add(
                ScientificLineageNode(
                    nodeId = "gap:${safeId(g.gapId)}",
                    nodeType = "blocking_gap",
                    label = g.nextAction.take(160),
                    source = "knowledge_map",
                    confidence = g.severity,
                    evidenceKeys = normalizeEvidence(g.gapId + " " + g.nextAction),
                    parentIds = emptyList()
                )
            )
        }
        if (deepDiscovery.active) {
            deepDiscovery.mechanismTournament.take(4).forEach { t ->
                add(
                    ScientificLineageNode(
                        nodeId = "mechanism:${safeId(t.hypothesisId)}",
                        nodeType = "competing_mechanism",
                        label = t.explanation.take(160),
                        source = "deep_discovery_reasoner",
                        confidence = t.score,
                        evidenceKeys = normalizeEvidence(t.strengths + t.weaknesses + t.discriminator),
                        parentIds = emptyList()
                    )
                )
            }
        }
        outcomeVerifier.unmetEvidenceKeys.take(8).forEach { key ->
            add(
                ScientificLineageNode(
                    nodeId = "unmet:${safeId(key)}",
                    nodeType = "unmet_evidence_key",
                    label = key,
                    source = "outcome_verifier",
                    confidence = 90,
                    evidenceKeys = normalizeEvidence(key),
                    parentIds = emptyList()
                )
            )
        }
    }

    private fun buildHypothesisCards(
        hypothesisObjects: List<HypothesisObject>,
        evidenceObjects: List<EvidenceObject>,
        datasetForaging: DatasetForagingReport,
        epistemicBelief: EpistemicBeliefReport,
        deepDiscovery: DeepDiscoveryReasoningReport,
        executionPolicy: ScientificDiscoveryExecutionPolicyReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport,
        causalReadiness: CausalReadinessReport,
        miniPeerReview: MiniPeerReviewReport
    ): List<HypothesisLineageCard> {
        val topMechanism = deepDiscovery.mechanismTournament.firstOrNull()
        val contradictionPool = (evidenceObjects.filter { it.contradictsHypothesis }.map { it.title } +
            deepDiscovery.contradictionPlan.strongestObjection + miniPeerReview.strongestObjection + outcomeVerifier.failureSignals.map { it.explanation })
            .filter { it.isNotBlank() && it != "none" }.distinct()
        val fallback = if (hypothesisObjects.isEmpty()) {
            listOf(
                HypothesisObject(
                    hypothesisId = "lineage_bootstrap",
                    label = topMechanism?.explanation ?: datasetForaging.candidates.firstOrNull()?.sourceTitle ?: "Bootstrap lineage from dataset/evidence route.",
                    status = "WATCH",
                    discoveryState = "Candidate",
                    biasRiskState = "Alert",
                    dataTrustScore = datasetForaging.scoreSeparation.hypothesisConfidenceScore,
                    evidenceScore10 = datasetForaging.scoreSeparation.datasetUsabilityScore / 10.0,
                    causalityScore = causalReadiness.score,
                    minimumDataPackStatus = "REQUIRED",
                    missingData = outcomeVerifier.unmetEvidenceKeys.ifEmpty { executionPolicy.forcedEvidenceKeys },
                    nextBestMeasurement = outcomeVerifier.nextPolicyAdjustment,
                    signalFlip = "lineage_bootstrap",
                    decisionImpact = "Build explicit lineage before mechanism upgrade.",
                    falsification = contradictionPool.take(4)
                )
            )
        } else hypothesisObjects
        return fallback.take(8).map { h ->
            val linked = evidenceObjects.filter { it.linkedHypothesisId == h.hypothesisId || it.linkedHypothesisId.isBlank() }.take(5)
            val parentEvidence = normalizeEvidence(
                h.missingData + linked.flatMap { it.accessionIds + it.reasons + it.decisionImpact } +
                    datasetForaging.parsedMetadata.flatMap { it.outcomeLabels + it.controlLabels + it.timeCourseLabels }.take(10) +
                    outcomeVerifier.resolvedEvidenceKeys + outcomeVerifier.unmetEvidenceKeys
            ).take(14)
            val contradictions = (contradictionPool + h.falsification + linked.filter { it.contradictsHypothesis }.map { it.title }).distinct().take(8)
            val routeFitTrap = datasetForaging.scoreSeparation.routeFitScore >= 85 && datasetForaging.scoreSeparation.datasetUsabilityScore < 70
            val mixedAxes = h.hypothesisId.count { it == '_' } >= 5 || h.label.split("axis", ignoreCase = true).size > 3
            val weakBelief = epistemicBelief.retiredBeliefs > 0 || epistemicBelief.revisedBeliefs > 0
            val action = when {
                routeFitTrap -> "SPLIT_ROUTE: high route-fit but low usability; separate dataset route from biological mechanism."
                contradictions.isNotEmpty() && causalReadiness.level < 3 -> "SPLIT_OR_HOLD: carry contradiction and require controlled comparison before merging routes."
                mixedAxes -> "SPLIT_MIXED_AXES: keep tissue/cell/assay/outcome mechanisms separate until discriminator resolves them."
                weakBelief -> "DO_NOT_MERGE_WITH_WEAK_BELIEF: use evidence contract, not revised/retired belief, for routing."
                else -> "KEEP_SINGLE_LINEAGE_WITH_GUARDS: inspect targeted evidence before upgrade."
            }
            val priorState = when {
                weakBelief -> "MUTABLE_OR_REVISED_PRIOR"
                h.status.contains("WATCH", true) -> "WATCH_PRIOR"
                else -> h.status
            }
            val currentState = when {
                outcomeVerifier.policyFailed -> "FAILED_POLICY_REQUIRES_REROUTE"
                outcomeVerifier.policySucceeded -> "POLICY_VALIDATED_INSPECT"
                miniPeerReview.verdict == "REJECT" -> "REVIEW_REJECTED"
                causalReadiness.level < 3 -> "ASSOCIATION_OR_ROUTE_FIT_ONLY"
                else -> "INSPECT_WITH_GUARDS"
            }
            val shift = (outcomeVerifier.outcomeScore - 50) + (causalReadiness.level * 4) - if (routeFitTrap) 25 else 0 - if (contradictions.isNotEmpty()) 8 else 0
            val verdict = when {
                outcomeVerifier.policyFailed || routeFitTrap -> "LINEAGE_BROKEN_REROUTE"
                contradictions.isNotEmpty() && causalReadiness.level < 3 -> "LINEAGE_HELD_BY_CONTRADICTION"
                action.contains("SPLIT") -> "SPLIT_BEFORE_UPGRADE"
                outcomeVerifier.policySucceeded && causalReadiness.level >= 3 -> "LINEAGE_INSPECTABLE"
                else -> "LINEAGE_PROVISIONAL"
            }
            val nextTest = buildNextLineageTest(h, topMechanism, outcomeVerifier, miniPeerReview, causalReadiness, datasetForaging)
            HypothesisLineageCard(
                hypothesisId = h.hypothesisId,
                label = h.label.take(180),
                origin = lineageOrigin(h, datasetForaging, deepDiscovery),
                priorState = priorState,
                currentState = currentState,
                parentEvidence = parentEvidence,
                contradictions = contradictions,
                splitOrMergeAction = action,
                confidenceShift = shift.coerceIn(-100, 100),
                lineageVerdict = verdict,
                nextLineageTest = nextTest.take(260)
            )
        }
    }

    private fun lineageOrigin(h: HypothesisObject, datasetForaging: DatasetForagingReport, deepDiscovery: DeepDiscoveryReasoningReport): String = when {
        datasetForaging.candidates.isNotEmpty() -> "dataset_candidate:${datasetForaging.candidates.first().accession}"
        deepDiscovery.active -> "deep_discovery:${deepDiscovery.state}"
        h.signalFlip.isNotBlank() -> "signal_flip:${h.signalFlip.take(80)}"
        else -> "hypothesis_object"
    }

    private fun buildNextLineageTest(
        h: HypothesisObject,
        mechanism: MechanismTournamentCard?,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport,
        miniPeerReview: MiniPeerReviewReport,
        causalReadiness: CausalReadinessReport,
        datasetForaging: DatasetForagingReport
    ): String {
        val unmet = outcomeVerifier.unmetEvidenceKeys.firstOrNull()
            ?: h.missingData.firstOrNull()
            ?: causalReadiness.blockers.firstOrNull()
            ?: "minimum_metadata"
        val discriminator = mechanism?.discriminator?.takeIf { it.isNotBlank() }
            ?: miniPeerReview.falsificationTest.takeIf { it.isNotBlank() }
            ?: datasetForaging.contrastiveReport.nextContrastiveQuestion
        return "Test lineage by resolving $unmet; discriminator: $discriminator; do not merge routes until parent evidence and contradiction are explicit."
    }

    private fun buildContradictionCarryForward(
        cards: List<HypothesisLineageCard>,
        deepDiscovery: DeepDiscoveryReasoningReport,
        miniPeerReview: MiniPeerReviewReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport
    ): List<String> = (
        cards.flatMap { it.contradictions } +
            deepDiscovery.contradictionPlan.negativeControls +
            deepDiscovery.contradictionPlan.falsificationTargets +
            listOf(miniPeerReview.strongestObjection, miniPeerReview.falsificationTest) +
            outcomeVerifier.failureSignals.map { it.explanation }
        ).filter { it.isNotBlank() && it != "none" && it != "No hypothesis reviewed." }
        .map { it.take(220) }
        .distinct()

    private fun buildMergeCandidates(cards: List<HypothesisLineageCard>, knowledgeMap: KnowledgeMapReport): List<String> {
        val edgeHints = knowledgeMap.edges
            .filter { it.confidence >= 75 && !it.edgeType.contains("gap", true) }
            .map { "merge_if_same_parent:${it.fromNode}->${it.toNode}" }
        val sharedEvidence = cards
            .flatMap { card -> card.parentEvidence.map { it to card.hypothesisId } }
            .groupBy({ it.first }, { it.second })
            .filter { it.value.distinct().size >= 2 }
            .map { "shared_evidence:${it.key}" }
        return (edgeHints + sharedEvidence).distinct()
    }

    private fun graphScore(
        nodes: List<ScientificLineageNode>,
        cards: List<HypothesisLineageCard>,
        datasetForaging: DatasetForagingReport,
        causalReadiness: CausalReadinessReport,
        outcomeVerifier: ScientificDiscoveryOutcomeVerifierReport
    ): Int {
        var score = 20
        if (nodes.any { it.nodeType == "dataset_metadata" }) score += 18
        if (nodes.any { it.nodeType == "evidence" || it.nodeType == "contradiction_evidence" }) score += 14
        if (cards.any { it.parentEvidence.any { key -> key.contains("outcome", true) } }) score += 14
        if (cards.any { it.parentEvidence.any { key -> key.contains("control", true) || key.contains("comparator", true) } }) score += 12
        if (cards.any { it.parentEvidence.any { key -> key.contains("time", true) || key.contains("longitudinal", true) } }) score += 10
        if (cards.any { it.contradictions.isNotEmpty() }) score += 8
        if (causalReadiness.level >= 3) score += 10
        if (outcomeVerifier.policyFailed) score -= 18
        if (datasetForaging.scoreSeparation.routeFitScore >= 85 && datasetForaging.scoreSeparation.datasetUsabilityScore < 70) score -= 16
        return score.coerceIn(0, 100)
    }

    private fun normalizeEvidence(items: List<String>): List<String> = items.flatMap { normalizeEvidence(it) }.distinct().take(80)
    private fun normalizeEvidence(item: String): List<String> {
        val lower = item.lowercase(Locale.US)
        return buildList {
            if (lower.contains("outcome") || lower.contains("recovery") || lower.contains("severity") || lower.contains("endpoint")) add("outcome_labels")
            if (lower.contains("control") || lower.contains("comparator") || lower.contains("placebo") || lower.contains("negative")) add("comparator_control")
            if (lower.contains("time") || lower.contains("longitudinal") || lower.contains("serial") || lower.contains("follow")) add("time_order")
            if (lower.contains("metadata") || lower.contains("accession") || lower.contains("sample")) add("minimum_metadata")
            if (lower.contains("human") || lower.contains("patient") || lower.contains("phenotype")) add("human_or_patient_phenotype")
            if (lower.contains("contradiction") || lower.contains("falsification") || lower.contains("failed") || lower.contains("null")) add("falsification_contradiction")
            if (lower.contains("replication") || lower.contains("external")) add("replication_external_validation")
            if (isEmpty()) add(safeId(lower).ifBlank { "minimum_metadata" })
        }
    }

    private fun normalizeTerms(items: List<String>): List<String> = items
        .map { it.trim().lowercase(Locale.US) }
        .filter { it.length >= 3 }
        .filterNot { it in setOf("the", "and", "with", "from", "that", "this", "none") }
        .distinct()

    private fun compactTokens(value: String, max: Int): List<String> = value
        .lowercase(Locale.US)
        .replace(Regex("[^a-z0-9_+ -]"), " ")
        .split(Regex("\\s+"))
        .filter { it.length >= 3 }
        .filterNot { it in setOf("the", "and", "for", "with", "that", "this", "not", "only", "route") }
        .take(max)

    private fun safeId(value: String): String = value
        .lowercase(Locale.US)
        .replace(Regex("[^a-z0-9_]+"), "_")
        .trim('_')
        .take(96)
}
