package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ResearchQuery(
    val id: String,
    val label: String,
    val query: String,
    val reason: String
)

data class EvidenceAssessment(
    val sourceClass: String,
    val speciesClass: String,
    val studyDesign: String,
    val humanEvidence: Boolean,
    val evidenceQualityScore: Int,
    val limitations: List<String>
)

data class CausalityAssessment(
    val causalityScore: Int,
    val temporalityScore: Int,
    val biologicalPlausibilityScore: Int,
    val measurableMarkerScore: Int,
    val repeatabilityScore: Int,
    val contradictionPenalty: Int,
    val rationale: List<String>
)

data class NegativeControlAssessment(
    val status: String,
    val reverseTimeRisk: String,
    val shuffledTimelineRisk: String,
    val unrelatedMarkerRisk: String,
    val notes: List<String>
)

data class PersonalPatternAssessment(
    val repeatedObservationCount: Int,
    val temporalSupport: String,
    val strongestLocalAxes: List<String>,
    val nextBestMeasurement: String
)

data class HypothesisRankCard(
    val hypothesisId: String,
    val label: String,
    val status: String,
    val overallScore: Int,
    val evidenceQualityScore: Int,
    val causalityScore: Int,
    val personalRepeatability: Int,
    val negativeControlStatus: String,
    val nextBestMeasurement: String,
    val whyRanked: List<String>
)

/**
 * v1.2: DTOS-inspired research lock output.
 *
 * A hypothesis object is the single source of truth for one research lead.
 * It prevents the engine from repeating narrative and forces every new source
 * to change a rank, state, gate, next measurement, or bias warning.
 */
data class HypothesisObject(
    val hypothesisId: String,
    val label: String,
    val status: String,
    val discoveryState: String,
    val biasRiskState: String,
    val dataTrustScore: Int,
    val evidenceScore10: Double,
    val causalityScore: Int,
    val minimumDataPackStatus: String,
    val missingData: List<String>,
    val nextBestMeasurement: String,
    val signalFlip: String,
    val decisionImpact: String,
    val falsification: List<String>
)

data class LearningDeltaCard(
    val hypothesisId: String,
    val deltaType: String,
    val previousStatus: String,
    val currentStatus: String,
    val signalFlip: String,
    val decisionImpact: String,
    val nextAction: String
)

data class MistakeRiskCard(
    val risk: String,
    val preventionGate: String,
    val affectedHypotheses: List<String>
)

data class ResearchStateSummary(
    val discoveryState: String,
    val biasRiskState: String,
    val nextEvidence: String,
    val discoveryAction: String,
    val biasAlarm: String
) {
    companion object {
        fun empty() = ResearchStateSummary(
            discoveryState = "Off",
            biasRiskState = "Normal",
            nextEvidence = "Start DATASET_HUNT: direct GEO/GDS and SRA/PRJNA source attempts before broad PubMed.",
            discoveryAction = "No hypothesis upgrade until a dataset candidate or evidence object is acquired.",
            biasAlarm = "Normal: no ranked hypothesis yet; keep discovery state OFF until evidence objects exist."
        )
    }
}

data class PublicDatasetCandidate(
    val datasetId: String,
    val source: String,
    val condition: String,
    val dataType: String,
    val speciesClass: String,
    val sampleHint: String,
    val matchedAxes: List<String>,
    val qualityScore: Int,
    val accessNote: String,
    val url: String
)

data class ImmuneAxisSummary(
    val axis: String,
    val count: Int,
    val role: String,
    val topEvidence: String
)

data class TriggerResponseEdge(
    val trigger: String,
    val responseAxis: String,
    val tissueOrOutcome: String,
    val evidenceScore: Int,
    val status: String,
    val rationale: String
)

data class GlobalHypothesisLead(
    val hypothesisId: String,
    val question: String,
    val conditions: List<String>,
    val evidenceScore10: Double,
    val dataTrustScore: Int,
    val status: String,
    val nextDatasetNeeded: String,
    val falsifier: String
)

data class AntiviralResponseNote(
    val theme: String,
    val status: String,
    val involvedAxes: List<String>,
    val researchNote: String
)

data class GlobalImmuneIntelligenceReport(
    val mode: String,
    val datasetCandidates: List<PublicDatasetCandidate>,
    val axisMap: List<ImmuneAxisSummary>,
    val triggerResponseEdges: List<TriggerResponseEdge>,
    val globalHypotheses: List<GlobalHypothesisLead>,
    val antiviralResponseNotes: List<AntiviralResponseNote>,
    val nextGlobalDatasetNeeded: String,
    val globalDiscoveryAction: String,
    val globalBiasAlarm: String
)

data class ResearchFinding(
    val source: String,
    val sourceId: String,
    val title: String,
    val published: String,
    val url: String,
    val matchedAxes: List<String>,
    val noveltyScore: Int,
    val bridgeSignal: String,
    val whyItMatters: String,
    val evidence: EvidenceAssessment,
    val causality: CausalityAssessment,
    val negativeControl: NegativeControlAssessment,
    val personalPattern: PersonalPatternAssessment,
    // v1.1: statistical sanity flags promised in CANONICAL_SCORING_FORMULA_v0.9.1.md.
    // Default empty for backward compatibility with old saved findings.
    // Possible values: "METADATA_ONLY", "INSUFFICIENT_DATA", "WEAK_PERMUTATION_TEST",
    // "LOW_POWER", "ABSTRACT_FETCH_FAILED".
    val sanityFlags: List<String> = emptyList()
)

data class ImportedReportSignal(
    val reportId: String,
    val createdAtMillis: Long,
    val title: String,
    val matchedAxes: List<String>,
    val extractedKeywords: List<String>,
    val preview: String
)

data class ResearchSteeringProfile(
    val profileId: String,
    val createdAtMillis: Long,
    val variables: List<String>,
    val focusQuestion: String,
    val requiredTerms: List<String>,
    val excludedTerms: List<String>,
    val inferredAxes: List<String>
)

data class KnowledgeDelta(
    val newSourcesSaved: Int,
    val repeatedSourcesSkipped: Int,
    val newAxisPairs: List<String>,
    val manualReportSignalsUsed: Int,
    val dnaRnaSignals: Int,
    val steeredQueriesGenerated: Int,
    val learningNotes: List<String>
)

data class ResearchRunLimits(
    val maxSearchMillis: Long = 10L * 60L * 1000L,
    val maxLearningMillis: Long = 15L * 60L * 1000L,
    val maxQueries: Int = 4,
    val maxResultsPerQuery: Int = 5,
    // v1.3.1: keep APK data use low by default. Abstract fetching can be
    // selectively enabled for the top candidates only.
    val fetchAbstracts: Boolean = false,
    // v1.3.3: if enabled, metadata scan stays cheap but the best candidates
    // can earn abstract review. Hard cap protects mobile data use.
    val enableSelectiveAbstracts: Boolean = true,
    val maxAbstractsPerCycle: Int = 2,
    val abstractEligibilityThreshold: Int = 65
)

data class ResearchCycleReport(
    val id: String,
    val createdAtMillis: Long,
    val completedAtMillis: Long,
    val stoppedByUser: Boolean,
    val stopReason: String,
    val searchDurationMillis: Long,
    val learningDurationMillis: Long,
    val queries: List<ResearchQuery>,
    val findings: List<ResearchFinding>,
    val activeSteeringProfile: ResearchSteeringProfile?,
    val importedReportSignals: List<ImportedReportSignal>,
    val hypothesisRankCards: List<HypothesisRankCard>,
    val emergentLinks: List<String>,
    val nextQuestions: List<String>,
    val knowledgeDelta: KnowledgeDelta,
    val autonomousPlan: AutonomousResearchPlan = AutonomousResearchPlan.empty(),
    val resilienceDecision: PivotDecision = PivotDecision.none(),
    val queryEvolutionState: QueryEvolutionState? = null,
    val datasetCandidatesV133: List<DatasetCandidateV133> = emptyList(),
    val datasetCandidatesV137: List<DatasetAccessionCandidate> = emptyList(),
    val evidenceObjects: List<EvidenceObject> = emptyList(),
    val discoveryReadiness: DiscoveryReadinessReport = DiscoveryReadinessReport.empty(),
    val learningOsReport: LearningOsReport = LearningOsReport.empty(),
    val runtimeStatus: ActiveResearchEngineStatus = ActiveResearchEngineStatus(
        engineVersion = EngineRuntimeStatus.ACTIVE_ENGINE_VERSION,
        activeModules = EngineRuntimeStatus.ACTIVE_MODULES,
        researchState = "RESEARCH_NORMAL",
        appliedPivotType = "NO_PIVOT",
        effectiveMaxQueries = 4,
        effectiveResultsPerQuery = 5,
        runtimeFailoverApplied = false,
        forcedQueries = emptyList(),
        executedQueryIds = emptyList()
    ),
    val executionLockReport: ExecutionLockReport = ExecutionLockReport(
        status = "PASS",
        failures = emptyList(),
        enforcedActions = listOf("Normal research cycle; no forced execution needed.")
    ),
    val datasetForagingReport: DatasetForagingReport = DatasetForagingReport.empty(),
    val persistentFailureMemory: PersistentFailureMemorySnapshot = PersistentFailureMemorySnapshot.empty(),
    val reportV3: ResearchReportV3 = ResearchReportV3.empty(),
    val reasoningReport: ResearchReasoningReport = ResearchReasoningReport.empty(),
    val specializedReasoningReport: SpecializedReasoningReport = SpecializedReasoningReport.empty(),
    val knowledgeMapReport: KnowledgeMapReport = KnowledgeMapReport.empty(),
    val epistemicBeliefReport: EpistemicBeliefReport = EpistemicBeliefReport.empty(),
    val cognitivePathIntegrationReport: CognitivePathIntegrationReport = CognitivePathIntegrationReport.empty(),
    val cognitiveNextCyclePlan: CognitiveNextCyclePlan = CognitiveNextCyclePlan.none("No next-cycle cognitive directive applied."),
    val cognitiveLoopCalibrationReport: CognitiveLoopCalibrationReport = CognitiveLoopCalibrationReport.empty(),
    val directiveLifecycleReport: DirectiveLifecycleReport = DirectiveLifecycleReport.empty(),
    val evidenceGainQueryRankerReport: EvidenceGainQueryRankerReport = EvidenceGainQueryRankerReport.empty(),
    val beliefFalsificationContractReport: BeliefFalsificationContractReport = BeliefFalsificationContractReport.empty(),
    val memoryConsolidationReport: MemoryConsolidationReport = MemoryConsolidationReport.empty(),
    val causalReadinessReport: CausalReadinessReport = CausalReadinessReport.empty(),
    val reflectionLessonReport: ReflectionLessonReport = ReflectionLessonReport.empty(),
    val miniPeerReviewReport: MiniPeerReviewReport = MiniPeerReviewReport.empty(),
    val reportSimplificationReport: ReportSimplificationReport = ReportSimplificationReport.empty(),
    val scientificKnowledgeIndexReport: ScientificKnowledgeIndexReport = ScientificKnowledgeIndexReport.empty(),
    val deepDiscoveryReasoningReport: DeepDiscoveryReasoningReport = DeepDiscoveryReasoningReport.empty(),
    val scientificDiscoveryWeightReport: ScientificDiscoveryWeightReport = ScientificDiscoveryWeightReport.empty(),
    val scientificDiscoveryDecisionReport: ScientificDiscoveryDecisionReport = ScientificDiscoveryDecisionReport.empty(),
    val scientificDiscoveryStressTestReport: ScientificDiscoveryStressTestReport = ScientificDiscoveryStressTestReport.empty(),
    val scientificDiscoveryExecutionPolicyReport: ScientificDiscoveryExecutionPolicyReport = ScientificDiscoveryExecutionPolicyReport.empty(),
    val scientificDiscoveryOutcomeVerifierReport: ScientificDiscoveryOutcomeVerifierReport = ScientificDiscoveryOutcomeVerifierReport.empty(),
    val scientificDiscoveryLineageReport: ScientificDiscoveryLineageReport = ScientificDiscoveryLineageReport.empty(),
    val scientificDiscoveryGapMinerReport: ScientificDiscoveryGapMinerReport = ScientificDiscoveryGapMinerReport.empty(),
    val scientificDiscoveryProbePlanReport: ScientificDiscoveryProbePlanReport = ScientificDiscoveryProbePlanReport.empty(),
    val scientificDiscoveryProbeOutcomeLedgerReport: ScientificDiscoveryProbeOutcomeLedgerReport = ScientificDiscoveryProbeOutcomeLedgerReport.empty(),
    val scientificDiscoveryMetaStrategyReport: ScientificDiscoveryMetaStrategyReport = ScientificDiscoveryMetaStrategyReport.empty(),
    val scientificDiscoveryQualityGateReport: ScientificDiscoveryQualityGateReport = ScientificDiscoveryQualityGateReport.empty(),
    val limitations: List<String>,
    val hypothesisObjects: List<HypothesisObject> = emptyList(),
    val learningDeltaCards: List<LearningDeltaCard> = emptyList(),
    val mistakeRiskCards: List<MistakeRiskCard> = emptyList(),
    val researchStateSummary: ResearchStateSummary = ResearchStateSummary.empty(),
    val globalImmuneIntelligence: GlobalImmuneIntelligenceReport = GlobalImmuneIntelligenceReport(
        mode = "global_dataset_intelligence",
        datasetCandidates = emptyList(),
        axisMap = emptyList(),
        triggerResponseEdges = emptyList(),
        globalHypotheses = emptyList(),
        antiviralResponseNotes = emptyList(),
        nextGlobalDatasetNeeded = "Run a global dataset discovery cycle.",
        globalDiscoveryAction = "No global discovery action yet.",
        globalBiasAlarm = "Normal: no global hypothesis evaluated yet."
    )
)

object ResearchJsonCodec {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    fun reportToJson(report: ResearchCycleReport): JSONObject {
        return JSONObject()
            .put("schemaVersion", 192)
            .put("productMode", "Immune Error Radar Autonomous Global Immune Researcher")
            .put("id", report.id)
            .put("createdAtMillis", report.createdAtMillis)
            .put("completedAtMillis", report.completedAtMillis)
            .put("createdAtText", dateFormat.format(Date(report.createdAtMillis)))
            .put("completedAtText", dateFormat.format(Date(report.completedAtMillis)))
            .put("stoppedByUser", report.stoppedByUser)
            .put("stopReason", report.stopReason)
            .put("searchDurationMillis", report.searchDurationMillis)
            .put("learningDurationMillis", report.learningDurationMillis)
            .put("queries", JSONArray(report.queries.map { queryToJson(it) }))
            .put("findings", JSONArray(report.findings.map { findingToJson(it) }))
            .put("activeSteeringProfile", report.activeSteeringProfile?.let { steeringProfileToJson(it) } ?: JSONObject.NULL)
            .put("importedReportSignals", JSONArray(report.importedReportSignals.map { importedSignalToJson(it) }))
            .put("hypothesisRankCards", JSONArray(report.hypothesisRankCards.map { hypothesisCardToJson(it) }))
            .put("hypothesisObjects", JSONArray(report.hypothesisObjects.map { hypothesisObjectToJson(it) }))
            .put("learningDeltaCards", JSONArray(report.learningDeltaCards.map { learningDeltaCardToJson(it) }))
            .put("mistakeRiskCards", JSONArray(report.mistakeRiskCards.map { mistakeRiskCardToJson(it) }))
            .put("researchStateSummary", researchStateSummaryToJson(report.researchStateSummary))
            .put("globalImmuneIntelligence", globalImmuneIntelligenceToJson(report.globalImmuneIntelligence))
            .put("emergentLinks", JSONArray(report.emergentLinks))
            .put("nextQuestions", JSONArray(report.nextQuestions))
            .put("knowledgeDelta", knowledgeDeltaToJson(report.knowledgeDelta))
            .put("autonomousPlan", autonomousPlanToJson(report.autonomousPlan))
            .put("resilienceDecision", pivotDecisionToJson(report.resilienceDecision))
            .put("queryEvolutionState", report.queryEvolutionState?.let { queryEvolutionStateToJson(it) } ?: JSONObject.NULL)
            .put("datasetCandidatesV133", JSONArray(report.datasetCandidatesV133.map { datasetCandidateV133ToJson(it) }))
            .put("datasetCandidatesV137", JSONArray(report.datasetCandidatesV137.map { datasetAccessionCandidateToJson(it) }))
            .put("evidenceObjects", JSONArray(report.evidenceObjects.map { evidenceObjectToJson(it) }))
            .put("discoveryReadiness", ResearchLearningLoopEngine.discoveryToJson(report.discoveryReadiness))
            .put("learningOsReport", ResearchLearningLoopEngine.learningOsToJson(report.learningOsReport))
            .put("runtimeStatus", EngineRuntimeStatus.runtimeStatusToJson(report.runtimeStatus))
            .put("executionLockReport", EngineRuntimeStatus.executionLockToJson(report.executionLockReport))
            .put("datasetForagingReport", DatasetForagingJson.reportToJson(report.datasetForagingReport))
            .put("persistentFailureMemory", PersistentFailureMemory.memoryToJson(report.persistentFailureMemory))
            .put("reportV3", reportV3ToJson(report.reportV3))
            .put("reasoningReport", reasoningReportToJson(report.reasoningReport))
            .put("specializedReasoningReport", specializedReasoningToJson(report.specializedReasoningReport))
            .put("knowledgeMapReport", knowledgeMapToJson(report.knowledgeMapReport))
            .put("epistemicBeliefReport", epistemicBeliefToJson(report.epistemicBeliefReport))
            .put("cognitivePathIntegrationReport", cognitivePathIntegrationToJson(report.cognitivePathIntegrationReport))
            .put("cognitiveNextCyclePlan", cognitiveNextCyclePlanToJson(report.cognitiveNextCyclePlan))
            .put("cognitiveLoopCalibrationReport", cognitiveLoopCalibrationToJson(report.cognitiveLoopCalibrationReport))
            .put("directiveLifecycleReport", directiveLifecycleToJson(report.directiveLifecycleReport))
            .put("evidenceGainQueryRankerReport", evidenceGainQueryRankerToJson(report.evidenceGainQueryRankerReport))
            .put("beliefFalsificationContractReport", beliefFalsificationContractReportToJson(report.beliefFalsificationContractReport))
            .put("memoryConsolidationReport", memoryConsolidationToJson(report.memoryConsolidationReport))
            .put("causalReadinessReport", causalReadinessToJson(report.causalReadinessReport))
            .put("reflectionLessonReport", reflectionLessonToJson(report.reflectionLessonReport))
            .put("miniPeerReviewReport", miniPeerReviewToJson(report.miniPeerReviewReport))
            .put("reportSimplificationReport", reportSimplificationToJson(report.reportSimplificationReport))
            .put("scientificKnowledgeIndexReport", scientificKnowledgeIndexToJson(report.scientificKnowledgeIndexReport))
            .put("deepDiscoveryReasoningReport", deepDiscoveryReasoningToJson(report.deepDiscoveryReasoningReport))
            .put("scientificDiscoveryWeightReport", scientificDiscoveryWeightToJson(report.scientificDiscoveryWeightReport))
            .put("scientificDiscoveryDecisionReport", scientificDiscoveryDecisionToJson(report.scientificDiscoveryDecisionReport))
            .put("scientificDiscoveryStressTestReport", scientificDiscoveryStressTestToJson(report.scientificDiscoveryStressTestReport))
            .put("scientificDiscoveryExecutionPolicyReport", scientificDiscoveryExecutionPolicyToJson(report.scientificDiscoveryExecutionPolicyReport))
            .put("scientificDiscoveryOutcomeVerifierReport", scientificDiscoveryOutcomeVerifierToJson(report.scientificDiscoveryOutcomeVerifierReport))
            .put("scientificDiscoveryLineageReport", scientificDiscoveryLineageToJson(report.scientificDiscoveryLineageReport))
            .put("scientificDiscoveryGapMinerReport", scientificDiscoveryGapMinerToJson(report.scientificDiscoveryGapMinerReport))
            .put("scientificDiscoveryProbePlanReport", scientificDiscoveryProbePlanToJson(report.scientificDiscoveryProbePlanReport))
            .put("scientificDiscoveryProbeOutcomeLedgerReport", scientificDiscoveryProbeOutcomeLedgerToJson(report.scientificDiscoveryProbeOutcomeLedgerReport))
            .put("scientificDiscoveryMetaStrategyReport", scientificDiscoveryMetaStrategyToJson(report.scientificDiscoveryMetaStrategyReport))
            .put("scientificDiscoveryQualityGateReport", scientificDiscoveryQualityGateToJson(report.scientificDiscoveryQualityGateReport))
            .put("limitations", JSONArray(report.limitations))
    }


    fun scientificDiscoveryWeightToJson(report: ScientificDiscoveryWeightReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("topWeights", JSONArray(report.topWeights.map { scientificDecisionWeightToJson(it) }))
        .put("prioritizedTerms", JSONArray(report.prioritizedTerms))
        .put("downgradedFalseFriends", JSONArray(report.downgradedFalseFriends))
        .put("decisiveEvidenceDelta", JSONArray(report.decisiveEvidenceDelta))
        .put("searchPriorityVector", JSONArray(report.searchPriorityVector))
        .put("riskGuards", JSONArray(report.riskGuards))
        .put("learningReceipt", report.learningReceipt)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun scientificDecisionWeightToJson(card: ScientificDecisionWeightCard): JSONObject = JSONObject()
        .put("termId", card.termId)
        .put("label", card.label)
        .put("matched", card.matched)
        .put("importance", card.importance)
        .put("evidenceGapScore", card.evidenceGapScore)
        .put("falseFriendRisk", card.falseFriendRisk)
        .put("routingWeight", card.routingWeight)
        .put("action", card.action)
        .put("requiredEvidence", JSONArray(card.requiredEvidence))
        .put("queryTerms", JSONArray(card.queryTerms))
        .put("why", card.why)


    fun scientificDiscoveryDecisionToJson(report: ScientificDiscoveryDecisionReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("selectedMove", report.selectedMove)
        .put("selectedReason", report.selectedReason)
        .put("blockedMove", report.blockedMove)
        .put("blockedReason", report.blockedReason)
        .put("successCriteria", JSONArray(report.successCriteria))
        .put("failureCriteria", JSONArray(report.failureCriteria))
        .put("nextCycleContract", report.nextCycleContract)
        .put("decisionTags", JSONArray(report.decisionTags))
        .put("changeIfFails", report.changeIfFails)
        .put("carryForwardPolicy", report.carryForwardPolicy)
        .put("queryImpactTerms", JSONArray(report.queryImpactTerms))
        .put("evidenceImpactKeys", JSONArray(report.evidenceImpactKeys))
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    fun scientificDiscoveryStressTestToJson(report: ScientificDiscoveryStressTestReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("stressState", report.stressState)
        .put("selectedScenario", report.selectedScenario)
        .put("scenarios", JSONArray(report.scenarios.map { discoveryStressScenarioToJson(it) }))
        .put("passSignals", JSONArray(report.passSignals))
        .put("failSignals", JSONArray(report.failSignals))
        .put("nullResultPolicy", report.nullResultPolicy)
        .put("contradictionPolicy", report.contradictionPolicy)
        .put("routeCooldownSignals", JSONArray(report.routeCooldownSignals))
        .put("forcedNextTerms", JSONArray(report.forcedNextTerms))
        .put("forcedEvidenceKeys", JSONArray(report.forcedEvidenceKeys))
        .put("branchActions", JSONArray(report.branchActions))
        .put("reportLine", report.reportLine)
        .put("claimLimit", report.claimLimit)


    fun scientificDiscoveryExecutionPolicyToJson(report: ScientificDiscoveryExecutionPolicyReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("policyState", report.policyState)
        .put("executionMode", report.executionMode)
        .put("policyActions", JSONArray(report.policyActions.map { scientificExecutionPolicyActionToJson(it) }))
        .put("allowedActions", JSONArray(report.allowedActions))
        .put("blockedActions", JSONArray(report.blockedActions))
        .put("queryReplayBlocks", JSONArray(report.queryReplayBlocks))
        .put("routeCooldownPolicy", report.routeCooldownPolicy)
        .put("beliefBurialPolicy", report.beliefBurialPolicy)
        .put("forcedDirectiveTerms", JSONArray(report.forcedDirectiveTerms))
        .put("forcedEvidenceKeys", JSONArray(report.forcedEvidenceKeys))
        .put("rerouteTriggers", JSONArray(report.rerouteTriggers))
        .put("reportLine", report.reportLine)
        .put("claimLimit", report.claimLimit)

    fun scientificDiscoveryOutcomeVerifierToJson(report: ScientificDiscoveryOutcomeVerifierReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("verifierState", report.verifierState)
        .put("outcomeScore", report.outcomeScore)
        .put("policyApplied", report.policyApplied)
        .put("policySucceeded", report.policySucceeded)
        .put("policyFailed", report.policyFailed)
        .put("successSignals", JSONArray(report.successSignals.map { scientificOutcomeVerificationSignalToJson(it) }))
        .put("failureSignals", JSONArray(report.failureSignals.map { scientificOutcomeVerificationSignalToJson(it) }))
        .put("unmetEvidenceKeys", JSONArray(report.unmetEvidenceKeys))
        .put("resolvedEvidenceKeys", JSONArray(report.resolvedEvidenceKeys))
        .put("routeAdjustment", report.routeAdjustment)
        .put("beliefAdjustment", report.beliefAdjustment)
        .put("nextPolicyAdjustment", report.nextPolicyAdjustment)
        .put("forcedNextEvidence", JSONArray(report.forcedNextEvidence))
        .put("blockedReplayKeys", JSONArray(report.blockedReplayKeys))
        .put("learningReceipt", report.learningReceipt)
        .put("reportLine", report.reportLine)
        .put("claimLimit", report.claimLimit)

    private fun scientificOutcomeVerificationSignalToJson(signal: ScientificOutcomeVerificationSignal): JSONObject = JSONObject()
        .put("signalId", signal.signalId)
        .put("direction", signal.direction)
        .put("weight", signal.weight)
        .put("evidenceKey", signal.evidenceKey)
        .put("explanation", signal.explanation)

    fun scientificDiscoveryLineageToJson(report: ScientificDiscoveryLineageReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("lineageState", report.lineageState)
        .put("graphCompletenessScore", report.graphCompletenessScore)
        .put("activeHypotheses", report.activeHypotheses)
        .put("splitRequired", report.splitRequired)
        .put("mergeCandidates", JSONArray(report.mergeCandidates))
        .put("contradictionCarryForward", JSONArray(report.contradictionCarryForward))
        .put("lineageNodes", JSONArray(report.lineageNodes.map { scientificLineageNodeToJson(it) }))
        .put("hypothesisLineages", JSONArray(report.hypothesisLineages.map { hypothesisLineageCardToJson(it) }))
        .put("forcedEvidenceKeys", JSONArray(report.forcedEvidenceKeys))
        .put("forcedDirectiveTerms", JSONArray(report.forcedDirectiveTerms))
        .put("nextLineageAction", report.nextLineageAction)
        .put("reportLine", report.reportLine)
        .put("claimLimit", report.claimLimit)

    private fun scientificLineageNodeToJson(node: ScientificLineageNode): JSONObject = JSONObject()
        .put("nodeId", node.nodeId)
        .put("nodeType", node.nodeType)
        .put("label", node.label)
        .put("source", node.source)
        .put("confidence", node.confidence)
        .put("evidenceKeys", JSONArray(node.evidenceKeys))
        .put("parentIds", JSONArray(node.parentIds))

    private fun hypothesisLineageCardToJson(card: HypothesisLineageCard): JSONObject = JSONObject()
        .put("hypothesisId", card.hypothesisId)
        .put("label", card.label)
        .put("origin", card.origin)
        .put("priorState", card.priorState)
        .put("currentState", card.currentState)
        .put("parentEvidence", JSONArray(card.parentEvidence))
        .put("contradictions", JSONArray(card.contradictions))
        .put("splitOrMergeAction", card.splitOrMergeAction)
        .put("confidenceShift", card.confidenceShift)
        .put("lineageVerdict", card.lineageVerdict)
        .put("nextLineageTest", card.nextLineageTest)


    fun scientificDiscoveryGapMinerToJson(report: ScientificDiscoveryGapMinerReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("minerState", report.minerState)
        .put("opportunityScore", report.opportunityScore)
        .put("topOpportunity", report.topOpportunity)
        .put("latentOpportunities", JSONArray(report.latentOpportunities.map { latentDiscoveryOpportunityToJson(it) }))
        .put("dormantHypotheses", JSONArray(report.dormantHypotheses))
        .put("unaskedBridgeQuestions", JSONArray(report.unaskedBridgeQuestions))
        .put("missingButHighValueEvidence", JSONArray(report.missingButHighValueEvidence))
        .put("blockedBy", JSONArray(report.blockedBy))
        .put("forcedDirectiveTerms", JSONArray(report.forcedDirectiveTerms))
        .put("forcedEvidenceKeys", JSONArray(report.forcedEvidenceKeys))
        .put("nextDiscoveryProbe", report.nextDiscoveryProbe)
        .put("reportLine", report.reportLine)
        .put("claimLimit", report.claimLimit)

    private fun latentDiscoveryOpportunityToJson(card: LatentDiscoveryOpportunityCard): JSONObject = JSONObject()
        .put("opportunityId", card.opportunityId)
        .put("label", card.label)
        .put("opportunityType", card.opportunityType)
        .put("priority", card.priority)
        .put("whyItMatters", card.whyItMatters)
        .put("missingEvidence", JSONArray(card.missingEvidence))
        .put("probeQuery", card.probeQuery)
        .put("promoteIf", JSONArray(card.promoteIf))
        .put("killIf", JSONArray(card.killIf))
        .put("linkedLineage", card.linkedLineage)

    fun scientificDiscoveryProbePlanToJson(report: ScientificDiscoveryProbePlanReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("plannerState", report.plannerState)
        .put("selectedProbeId", report.selectedProbeId)
        .put("selectedProbeQuery", report.selectedProbeQuery)
        .put("probeSteps", JSONArray(report.probeSteps.map { discoveryProbeStepToJson(it) }))
        .put("evidencePack", JSONArray(report.evidencePack))
        .put("passCriteria", JSONArray(report.passCriteria))
        .put("failCriteria", JSONArray(report.failCriteria))
        .put("killCriteria", JSONArray(report.killCriteria))
        .put("replayBlockKeys", JSONArray(report.replayBlockKeys))
        .put("forcedDirectiveTerms", JSONArray(report.forcedDirectiveTerms))
        .put("forcedEvidenceKeys", JSONArray(report.forcedEvidenceKeys))
        .put("probeBudget", report.probeBudget)
        .put("ifProbeSucceeds", report.ifProbeSucceeds)
        .put("ifProbeFails", report.ifProbeFails)
        .put("reportLine", report.reportLine)
        .put("claimLimit", report.claimLimit)

    private fun discoveryProbeStepToJson(step: DiscoveryProbeStep): JSONObject = JSONObject()
        .put("stepId", step.stepId)
        .put("label", step.label)
        .put("query", step.query)
        .put("requiredEvidence", JSONArray(step.requiredEvidence))
        .put("passIf", JSONArray(step.passIf))
        .put("failIf", JSONArray(step.failIf))
        .put("killRouteIf", JSONArray(step.killRouteIf))
        .put("routeEffect", step.routeEffect)
        .put("reason", step.reason)



    fun scientificDiscoveryMetaStrategyToJson(report: ScientificDiscoveryMetaStrategyReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("strategyState", report.strategyState)
        .put("governorScore", report.governorScore)
        .put("selectedStrategy", report.selectedStrategy)
        .put("blockedStrategy", report.blockedStrategy)
        .put("continuationDecision", report.continuationDecision)
        .put("routeBudget", report.routeBudget)
        .put("deepThinkPermission", report.deepThinkPermission)
        .put("explorationExploitationMode", report.explorationExploitationMode)
        .put("strategyMoves", JSONArray(report.strategyMoves.map { metaStrategyMoveToJson(it) }))
        .put("allowedMoves", JSONArray(report.allowedMoves))
        .put("blockedMoves", JSONArray(report.blockedMoves))
        .put("forcedDirectiveTerms", JSONArray(report.forcedDirectiveTerms))
        .put("forcedEvidenceKeys", JSONArray(report.forcedEvidenceKeys))
        .put("reportLine", report.reportLine)
        .put("claimLimit", report.claimLimit)

    private fun metaStrategyMoveToJson(card: MetaStrategyMoveCard): JSONObject = JSONObject()
        .put("moveId", card.moveId)
        .put("label", card.label)
        .put("decision", card.decision)
        .put("reason", card.reason)
        .put("evidenceKeys", JSONArray(card.evidenceKeys))
        .put("queryTerms", JSONArray(card.queryTerms))
        .put("routeEffect", card.routeEffect)


    fun scientificDiscoveryQualityGateToJson(report: ScientificDiscoveryQualityGateReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("gateState", report.gateState)
        .put("qualityScore", report.qualityScore)
        .put("executionDecision", report.executionDecision)
        .put("allowExecution", report.allowExecution)
        .put("selectedStrategy", report.selectedStrategy)
        .put("blockedBecause", JSONArray(report.blockedBecause))
        .put("qualityIssues", JSONArray(report.qualityIssues.map { discoveryQualityIssueToJson(it) }))
        .put("requiredBeforeRun", JSONArray(report.requiredBeforeRun))
        .put("forcedDirectiveTerms", JSONArray(report.forcedDirectiveTerms))
        .put("forcedEvidenceKeys", JSONArray(report.forcedEvidenceKeys))
        .put("routeDisposition", report.routeDisposition)
        .put("reportLine", report.reportLine)
        .put("claimLimit", report.claimLimit)

    private fun discoveryQualityIssueToJson(card: DiscoveryQualityIssueCard): JSONObject = JSONObject()
        .put("issueId", card.issueId)
        .put("severity", card.severity)
        .put("label", card.label)
        .put("evidenceKey", card.evidenceKey)
        .put("requiredBeforeRun", card.requiredBeforeRun)
        .put("routeEffect", card.routeEffect)
        .put("queryTerms", JSONArray(card.queryTerms))

    fun scientificDiscoveryProbeOutcomeLedgerToJson(report: ScientificDiscoveryProbeOutcomeLedgerReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("ledgerState", report.ledgerState)
        .put("previousProbeId", report.previousProbeId)
        .put("previousPlannerState", report.previousPlannerState)
        .put("previousProbeQuery", report.previousProbeQuery)
        .put("evidenceClosureScore", report.evidenceClosureScore)
        .put("closedEvidenceKeys", JSONArray(report.closedEvidenceKeys))
        .put("unresolvedEvidenceKeys", JSONArray(report.unresolvedEvidenceKeys))
        .put("passSignals", JSONArray(report.passSignals.map { probeOutcomeClosureSignalToJson(it) }))
        .put("failSignals", JSONArray(report.failSignals.map { probeOutcomeClosureSignalToJson(it) }))
        .put("killSignals", JSONArray(report.killSignals.map { probeOutcomeClosureSignalToJson(it) }))
        .put("replayPenaltyKeys", JSONArray(report.replayPenaltyKeys))
        .put("routeDisposition", report.routeDisposition)
        .put("beliefDisposition", report.beliefDisposition)
        .put("nextProbeDecision", report.nextProbeDecision)
        .put("forcedDirectiveTerms", JSONArray(report.forcedDirectiveTerms))
        .put("forcedEvidenceKeys", JSONArray(report.forcedEvidenceKeys))
        .put("reportLine", report.reportLine)
        .put("claimLimit", report.claimLimit)

    private fun probeOutcomeClosureSignalToJson(signal: ProbeOutcomeClosureSignal): JSONObject = JSONObject()
        .put("evidenceKey", signal.evidenceKey)
        .put("status", signal.status)
        .put("reason", signal.reason)
        .put("impact", signal.impact)

    private fun scientificExecutionPolicyActionToJson(action: ScientificExecutionPolicyAction): JSONObject = JSONObject()
        .put("policyId", action.policyId)
        .put("label", action.label)
        .put("trigger", action.trigger)
        .put("enforcement", action.enforcement)
        .put("allowedNextAction", action.allowedNextAction)
        .put("blockedIf", action.blockedIf)
        .put("reason", action.reason)

    private fun discoveryStressScenarioToJson(scenario: DiscoveryStressScenario): JSONObject = JSONObject()
        .put("scenarioId", scenario.scenarioId)
        .put("label", scenario.label)
        .put("trigger", scenario.trigger)
        .put("expectedEvidence", JSONArray(scenario.expectedEvidence))
        .put("passCondition", scenario.passCondition)
        .put("failCondition", scenario.failCondition)
        .put("ifPass", scenario.ifPass)
        .put("ifFail", scenario.ifFail)
        .put("routingEffect", scenario.routingEffect)
        .put("risk", scenario.risk)


    fun cognitiveNextCyclePlanToJson(plan: CognitiveNextCyclePlan): JSONObject {
        return JSONObject()
            .put("active", plan.active)
            .put("directiveId", plan.directiveId ?: JSONObject.NULL)
            .put("appliedQueryCount", plan.appliedQueryCount)
            .put("addedFollowUpQuery", plan.addedFollowUpQuery)
            .put("appliedTerms", JSONArray(plan.appliedTerms))
            .put("blockedClaims", JSONArray(plan.blockedClaims))
            .put("summary", plan.summary)
            .put("suppressedReason", plan.suppressedReason ?: JSONObject.NULL)
            .put("directiveConsumed", plan.directiveConsumed)
            .put("consumptionReason", plan.consumptionReason ?: JSONObject.NULL)
            .put("routingFingerprint", plan.routingFingerprint ?: JSONObject.NULL)
            .put("useLimit", plan.useLimit)
            .put("claimLimit", plan.claimLimit)
    }


    fun cognitiveLoopCalibrationToJson(report: CognitiveLoopCalibrationReport): JSONObject {
        return JSONObject()
            .put("active", report.active)
            .put("state", report.state)
            .put("calibrationScore", report.calibrationScore)
            .put("directiveId", report.directiveId ?: JSONObject.NULL)
            .put("routingFingerprint", report.routingFingerprint ?: JSONObject.NULL)
            .put("outcome", report.outcome)
            .put("improvedSignals", JSONArray(report.improvedSignals.map { cognitiveLoopCalibrationSignalToJson(it) }))
            .put("stalledSignals", JSONArray(report.stalledSignals.map { cognitiveLoopCalibrationSignalToJson(it) }))
            .put("dampenSimilarDirective", report.dampenSimilarDirective)
            .put("rewardSimilarDirective", report.rewardSimilarDirective)
            .put("nextCalibrationAction", report.nextCalibrationAction)
            .put("visibleBrief", report.visibleBrief)
            .put("claimLimit", report.claimLimit)
    }

    private fun cognitiveLoopCalibrationSignalToJson(signal: CognitiveLoopCalibrationSignal): JSONObject {
        return JSONObject()
            .put("name", signal.name)
            .put("direction", signal.direction)
            .put("score", signal.score)
            .put("reason", signal.reason)
    }

    fun directiveLifecycleToJson(report: DirectiveLifecycleReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("state", report.state)
        .put("previousDirectiveApplied", report.previousDirectiveApplied)
        .put("expectedEffect", report.expectedEffect)
        .put("observedEffect", report.observedEffect)
        .put("improved", report.improved)
        .put("retiredOrReplayBlocked", report.retiredOrReplayBlocked)
        .put("nextDirectiveState", report.nextDirectiveState)
        .put("nextAction", report.nextAction)
        .put("visibleBrief", report.visibleBrief)
        .put("claimLimit", report.claimLimit)

    fun evidenceGainQueryRankerToJson(report: EvidenceGainQueryRankerReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("chosenQueryId", report.chosenQueryId)
        .put("chosenQuery", report.chosenQuery)
        .put("chosenScore", report.chosenScore)
        .put("scores", JSONArray(report.scores.map { evidenceGainScoreToJson(it) }))
        .put("blockedRepeatRisk", report.blockedRepeatRisk)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun evidenceGainScoreToJson(score: EvidenceGainQueryScore): JSONObject = JSONObject()
        .put("queryId", score.queryId)
        .put("query", score.query)
        .put("score", score.score)
        .put("closesGaps", JSONArray(score.closesGaps))
        .put("testsBeliefs", JSONArray(score.testsBeliefs))
        .put("falsificationValue", score.falsificationValue)
        .put("reason", score.reason)

    fun beliefFalsificationContractReportToJson(report: BeliefFalsificationContractReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("contracts", JSONArray(report.contracts.map { beliefFalsificationContractToJson(it) }))
        .put("blockedFromRouting", report.blockedFromRouting)
        .put("topAtRiskBelief", report.topAtRiskBelief)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun beliefFalsificationContractToJson(contract: BeliefFalsificationContract): JSONObject = JSONObject()
        .put("beliefId", contract.beliefId)
        .put("strengthenIf", JSONArray(contract.strengthenIf))
        .put("weakenIf", JSONArray(contract.weakenIf))
        .put("abandonIf", JSONArray(contract.abandonIf))
        .put("doNotRouteIf", JSONArray(contract.doNotRouteIf))
        .put("nextEvidenceRequired", JSONArray(contract.nextEvidenceRequired))
        .put("routingAllowed", contract.routingAllowed)
        .put("contractLine", contract.contractLine)

    fun memoryConsolidationToJson(report: MemoryConsolidationReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("mainBeliefsKept", report.mainBeliefsKept)
        .put("archivedBeliefs", report.archivedBeliefs)
        .put("routingBeliefs", report.routingBeliefs)
        .put("blockedBeliefs", report.blockedBeliefs)
        .put("garbageCollectorAction", report.garbageCollectorAction)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    fun causalReadinessToJson(report: CausalReadinessReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("state", report.state)
        .put("level", report.level)
        .put("score", report.score)
        .put("causalLanguageAllowed", report.causalLanguageAllowed)
        .put("strongSignalAllowed", report.strongSignalAllowed)
        .put("blockers", JSONArray(report.blockers))
        .put("nextAction", report.nextAction)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    fun reflectionLessonToJson(report: ReflectionLessonReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("lesson", report.lesson)
        .put("prevention", report.prevention)
        .put("cooldownAction", report.cooldownAction)
        .put("repeatedMistakeRisk", report.repeatedMistakeRisk)
        .put("claimLimit", report.claimLimit)

    fun miniPeerReviewToJson(report: MiniPeerReviewReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("verdict", report.verdict)
        .put("strongestObjection", report.strongestObjection)
        .put("missingEvidence", JSONArray(report.missingEvidence))
        .put("alternativeExplanation", report.alternativeExplanation)
        .put("falsificationTest", report.falsificationTest)
        .put("survivesNegativeControl", report.survivesNegativeControl)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    fun reportSimplificationToJson(report: ReportSimplificationReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("whatChanged", JSONArray(report.whatChanged))
        .put("gotStronger", report.gotStronger)
        .put("gotWeaker", report.gotWeaker)
        .put("dropped", report.dropped)
        .put("nextTest", report.nextTest)
        .put("whyThisNextTest", report.whyThisNextTest)
        .put("claimLimit", report.claimLimit)


    fun scientificKnowledgeIndexToJson(report: ScientificKnowledgeIndexReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("version", report.version)
        .put("matchedTerms", JSONArray(report.matchedTerms.map { scientificTermCardToJson(it) }))
        .put("highPriorityMissingTerms", JSONArray(report.highPriorityMissingTerms))
        .put("routeHints", JSONArray(report.routeHints))
        .put("evidenceRequirements", JSONArray(report.evidenceRequirements))
        .put("falseFriendWarnings", JSONArray(report.falseFriendWarnings))
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun scientificTermCardToJson(card: ScientificTermCard): JSONObject = JSONObject()
        .put("termId", card.termId)
        .put("label", card.label)
        .put("domain", card.domain)
        .put("importance", card.importance)
        .put("matched", card.matched)
        .put("aliases", JSONArray(card.aliases))
        .put("queryHints", JSONArray(card.queryHints))
        .put("evidenceRequired", JSONArray(card.evidenceRequired))
        .put("falseFriendWarnings", JSONArray(card.falseFriendWarnings))
        .put("routeImpact", card.routeImpact)

    fun deepDiscoveryReasoningToJson(report: DeepDiscoveryReasoningReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("state", report.state)
        .put("intelligenceScore", report.intelligenceScore)
        .put("mechanismHypotheses", JSONArray(report.mechanismHypotheses.map { mechanismHypothesisToJson(it) }))
        .put("mechanismTournament", JSONArray(report.mechanismTournament.map { mechanismTournamentToJson(it) }))
        .put("decisiveExperiment", decisiveExperimentToJson(report.decisiveExperiment))
        .put("noveltyReport", noveltyReportToJson(report.noveltyReport))
        .put("contradictionPlan", contradictionPlanToJson(report.contradictionPlan))
        .put("crossAxisBridgeReport", JSONArray(report.crossAxisBridgeReport.map { crossAxisBridgeToJson(it) }))
        .put("deepThinkSession", deepThinkSessionToJson(report.deepThinkSession))
        .put("nextDiscoveryMove", report.nextDiscoveryMove)
        .put("summary", report.summary)
        .put("claimLimit", report.claimLimit)

    private fun mechanismHypothesisToJson(card: MechanismHypothesisCard): JSONObject = JSONObject()
        .put("mechanismId", card.mechanismId)
        .put("label", card.label)
        .put("mechanismChain", JSONArray(card.mechanismChain))
        .put("upstreamTrigger", card.upstreamTrigger)
        .put("immuneMediator", card.immuneMediator)
        .put("cellOrTissueContext", card.cellOrTissueContext)
        .put("observableSignal", card.observableSignal)
        .put("expectedOutcome", card.expectedOutcome)
        .put("wrongGeneralizationRisk", card.wrongGeneralizationRisk)
        .put("confidence", card.confidence)

    private fun mechanismTournamentToJson(card: MechanismTournamentCard): JSONObject = JSONObject()
        .put("hypothesisId", card.hypothesisId)
        .put("explanation", card.explanation)
        .put("score", card.score)
        .put("strengths", JSONArray(card.strengths))
        .put("weaknesses", JSONArray(card.weaknesses))
        .put("discriminator", card.discriminator)
        .put("verdict", card.verdict)

    private fun decisiveExperimentToJson(plan: DecisiveExperimentPlan): JSONObject = JSONObject()
        .put("decisiveQuestion", plan.decisiveQuestion)
        .put("requiredDatasetFeatures", JSONArray(plan.requiredDatasetFeatures))
        .put("strengthenIf", JSONArray(plan.strengthenIf))
        .put("weakenIf", JSONArray(plan.weakenIf))
        .put("abandonIf", JSONArray(plan.abandonIf))
        .put("nextQuery", plan.nextQuery)
        .put("expectedUpdate", plan.expectedUpdate)

    private fun noveltyReportToJson(report: NoveltyAndNonObviousnessReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("score", report.score)
        .put("classLabel", report.classLabel)
        .put("whyNovel", JSONArray(report.whyNovel))
        .put("whyNotYetDiscovery", JSONArray(report.whyNotYetDiscovery))
        .put("claimLimit", report.claimLimit)

    private fun contradictionPlanToJson(plan: DeepContradictionPlan): JSONObject = JSONObject()
        .put("strongestObjection", plan.strongestObjection)
        .put("contradictionQueries", JSONArray(plan.contradictionQueries))
        .put("negativeControls", JSONArray(plan.negativeControls))
        .put("falsificationTargets", JSONArray(plan.falsificationTargets))
        .put("cooldownIfRepeated", plan.cooldownIfRepeated)

    private fun crossAxisBridgeToJson(card: CrossAxisBridgeCard): JSONObject = JSONObject()
        .put("fromAxis", card.fromAxis)
        .put("toAxis", card.toAxis)
        .put("bridgeType", card.bridgeType)
        .put("bridgeQuestion", card.bridgeQuestion)
        .put("hiddenVariableRisk", card.hiddenVariableRisk)
        .put("evidenceNeeded", JSONArray(card.evidenceNeeded))
        .put("score", card.score)

    private fun deepThinkSessionToJson(report: DeepThinkSessionReport): JSONObject = JSONObject()
        .put("active", report.active)
        .put("trigger", report.trigger)
        .put("mechanismHypothesis", report.mechanismHypothesis)
        .put("strongestObjection", report.strongestObjection)
        .put("decisiveDataset", report.decisiveDataset)
        .put("falsificationPath", report.falsificationPath)
        .put("nextQuery", report.nextQuery)
        .put("expectedUpdate", report.expectedUpdate)
        .put("sessionVerdict", report.sessionVerdict)
        .put("claimLimit", report.claimLimit)


    fun cognitivePathIntegrationToJson(report: CognitivePathIntegrationReport): JSONObject {
        return JSONObject()
            .put("active", report.active)
            .put("state", report.state)
            .put("integrationScore", report.integrationScore)
            .put("routeIntegrity", report.routeIntegrity)
            .put("nodes", JSONArray(report.nodes.map { cognitivePathNodeToJson(it) }))
            .put("links", JSONArray(report.links.map { cognitivePathLinkToJson(it) }))
            .put("decision", cognitivePathDecisionToJson(report.decision))
            .put("linkedWarnings", JSONArray(report.linkedWarnings))
            .put("changedSincePrevious", JSONArray(report.changedSincePrevious))
            .put("visibleBrief", report.visibleBrief)
            .put("claimLimit", report.claimLimit)
    }

    private fun cognitivePathNodeToJson(node: CognitivePathNode): JSONObject {
        return JSONObject()
            .put("pathId", node.pathId)
            .put("role", node.role)
            .put("label", node.label)
            .put("sourceLayer", node.sourceLayer)
            .put("score", node.score)
            .put("status", node.status)
            .put("rationale", node.rationale)
    }

    private fun cognitivePathLinkToJson(link: CognitivePathLink): JSONObject {
        return JSONObject()
            .put("fromId", link.fromId)
            .put("toId", link.toId)
            .put("relation", link.relation)
            .put("strength", link.strength)
            .put("requiredBeforeUpgrade", link.requiredBeforeUpgrade)
            .put("rationale", link.rationale)
    }

    private fun cognitivePathDecisionToJson(decision: CognitivePathDecision): JSONObject {
        return JSONObject()
            .put("decisionType", decision.decisionType)
            .put("action", decision.action)
            .put("reason", decision.reason)
            .put("blocksHypothesisUpgrade", decision.blocksHypothesisUpgrade)
            .put("nextSearchTerms", JSONArray(decision.nextSearchTerms))
            .put("requiredEvidence", JSONArray(decision.requiredEvidence))
    }

    fun knowledgeMapToJson(report: KnowledgeMapReport): JSONObject {
        return JSONObject()
            .put("active", report.active)
            .put("mapScore", report.mapScore)
            .put("state", report.state)
            .put("carriedForwardNodes", report.carriedForwardNodes)
            .put("newNodesThisCycle", report.newNodesThisCycle)
            .put("newLinksThisCycle", report.newLinksThisCycle)
            .put("nodes", JSONArray(report.nodes.map { knowledgeMapNodeToJson(it) }))
            .put("edges", JSONArray(report.edges.map { knowledgeMapEdgeToJson(it) }))
            .put("gaps", JSONArray(report.gaps.map { knowledgeMapGapToJson(it) }))
            .put("carriedForwardInsights", JSONArray(report.carriedForwardInsights))
            .put("changedSincePrevious", JSONArray(report.changedSincePrevious))
            .put("nextMapAction", report.nextMapAction)
            .put("visibleBrief", report.visibleBrief)
            .put("mapStructureScore", report.mapStructureScore)
            .put("evidenceReadinessScore", report.evidenceReadinessScore)
            .put("causalReadinessScore", report.causalReadinessScore)
            .put("upgradeStatus", report.upgradeStatus)
            .put("mainBlocker", report.mainBlocker)
            .put("claimLimit", report.claimLimit)
    }

    private fun knowledgeMapNodeToJson(node: KnowledgeMapNode): JSONObject {
        return JSONObject()
            .put("nodeId", node.nodeId)
            .put("nodeType", node.nodeType)
            .put("label", node.label)
            .put("score", node.score)
            .put("occurrences", node.occurrences)
            .put("evidenceIds", JSONArray(node.evidenceIds))
            .put("status", node.status)
            .put("summary", node.summary)
    }

    private fun knowledgeMapEdgeToJson(edge: KnowledgeMapEdge): JSONObject {
        return JSONObject()
            .put("fromNode", edge.fromNode)
            .put("toNode", edge.toNode)
            .put("relation", edge.relation)
            .put("weight", edge.weight)
            .put("supportCount", edge.supportCount)
            .put("status", edge.status)
            .put("rationale", edge.rationale)
    }

    private fun knowledgeMapGapToJson(gap: KnowledgeMapGap): JSONObject {
        return JSONObject()
            .put("gapId", gap.gapId)
            .put("affectedNodes", JSONArray(gap.affectedNodes))
            .put("severity", gap.severity)
            .put("nextAction", gap.nextAction)
            .put("blocksUpgrade", gap.blocksUpgrade)
    }

    fun epistemicBeliefToJson(report: EpistemicBeliefReport): JSONObject {
        return JSONObject()
            .put("active", report.active)
            .put("state", report.state)
            .put("beliefScore", report.beliefScore)
            .put("carriedForwardBeliefs", report.carriedForwardBeliefs)
            .put("newBeliefsThisCycle", report.newBeliefsThisCycle)
            .put("weakenedBeliefs", report.weakenedBeliefs)
            .put("revisedBeliefs", report.revisedBeliefs)
            .put("retiredBeliefs", report.retiredBeliefs)
            .put("beliefs", JSONArray(report.beliefs.map { epistemicBeliefItemToJson(it) }))
            .put("updates", JSONArray(report.updates.map { epistemicBeliefUpdateToJson(it) }))
            .put("foundationBeliefs", JSONArray(report.foundationBeliefs))
            .put("mutableBeliefWarnings", JSONArray(report.mutableBeliefWarnings))
            .put("nextBeliefAction", report.nextBeliefAction)
            .put("visibleBrief", report.visibleBrief)
            .put("transitionSummary", epistemicBeliefTransitionSummaryToJson(report.transitionSummary))
            .put("claimLimit", report.claimLimit)
    }

    private fun epistemicBeliefItemToJson(belief: EpistemicBelief): JSONObject {
        return JSONObject()
            .put("beliefId", belief.beliefId)
            .put("statement", belief.statement)
            .put("beliefType", belief.beliefType)
            .put("status", belief.status)
            .put("confidence", belief.confidence)
            .put("credibility", belief.credibility)
            .put("supportCount", belief.supportCount)
            .put("contradictionCount", belief.contradictionCount)
            .put("linkedNodes", JSONArray(belief.linkedNodes))
            .put("requiredEvidenceToKeep", JSONArray(belief.requiredEvidenceToKeep))
            .put("falsifiers", JSONArray(belief.falsifiers))
            .put("abandonmentQuestion", belief.abandonmentQuestion)
            .put("lastChangedReason", belief.lastChangedReason)
    }

    private fun epistemicBeliefTransitionSummaryToJson(summary: EpistemicBeliefTransitionSummary): JSONObject {
        return JSONObject()
            .put("strengthenedBelief", summary.strengthenedBelief)
            .put("weakenedBelief", summary.weakenedBelief)
            .put("droppedBelief", summary.droppedBelief)
            .put("pruningRule", summary.pruningRule)
            .put("unusedWeakBeliefsPruned", summary.unusedWeakBeliefsPruned)
            .put("abandonmentQuestion", summary.abandonmentQuestion)
    }

    private fun epistemicBeliefUpdateToJson(update: EpistemicBeliefUpdate): JSONObject {
        return JSONObject()
            .put("beliefId", update.beliefId)
            .put("updateType", update.updateType)
            .put("previousStatus", update.previousStatus)
            .put("newStatus", update.newStatus)
            .put("reason", update.reason)
            .put("nextAction", update.nextAction)
    }

    fun specializedReasoningToJson(report: SpecializedReasoningReport): JSONObject {
        return JSONObject()
            .put("active", report.active)
            .put("specialistScore", report.specialistScore)
            .put("state", report.state)
            .put("weakestLink", report.weakestLink)
            .put("strongestImprovement", report.strongestImprovement)
            .put("decisiveNextTest", report.decisiveNextTest)
            .put("falsificationDemand", report.falsificationDemand)
            .put("axisDiscipline", report.axisDiscipline)
            .put("generalModelFailureRisks", JSONArray(report.generalModelFailureRisks))
            .put("expertMoves", JSONArray(report.expertMoves.map { specialistMoveToJson(it) }))
            .put("evidenceGaps", JSONArray(report.evidenceGaps.map { evidenceGapToJson(it) }))
            .put("hypothesisTournament", JSONArray(report.hypothesisTournament.map { hypothesisTournamentToJson(it) }))
            .put("reasoningAudit", JSONArray(report.reasoningAudit.map { reasoningAuditToJson(it) }))
            .put("specialistVerdict", report.specialistVerdict)
            .put("nextCycleProtocol", JSONArray(report.nextCycleProtocol))
            .put("visibleBrief", report.visibleBrief)
            .put("claimLimit", report.claimLimit)
    }

    private fun specialistMoveToJson(move: SpecialistReasoningMove): JSONObject {
        return JSONObject()
            .put("name", move.name)
            .put("status", move.status)
            .put("score", move.score)
            .put("finding", move.finding)
            .put("nextAction", move.nextAction)
    }

    private fun evidenceGapToJson(gap: EvidenceGapCard): JSONObject {
        return JSONObject()
            .put("gapId", gap.gapId)
            .put("status", gap.status)
            .put("severity", gap.severity)
            .put("whyItMatters", gap.whyItMatters)
            .put("requiredAction", gap.requiredAction)
    }

    private fun hypothesisTournamentToJson(card: HypothesisTournamentCard): JSONObject {
        return JSONObject()
            .put("hypothesisId", card.hypothesisId)
            .put("label", card.label)
            .put("status", card.status)
            .put("score", card.score)
            .put("nextDiscriminator", card.nextDiscriminator)
    }

    private fun reasoningAuditToJson(item: ReasoningAuditQuestion): JSONObject {
        return JSONObject()
            .put("question", item.question)
            .put("answer", item.answer)
            .put("passed", item.passed)
    }

    fun findingToJson(finding: ResearchFinding): JSONObject {
        return JSONObject()
            .put("source", finding.source)
            .put("sourceId", finding.sourceId)
            .put("title", finding.title)
            .put("published", finding.published)
            .put("url", finding.url)
            .put("matchedAxes", JSONArray(finding.matchedAxes))
            .put("noveltyScore", finding.noveltyScore)
            .put("bridgeSignal", finding.bridgeSignal)
            .put("whyItMatters", finding.whyItMatters)
            .put("evidence", evidenceToJson(finding.evidence))
            .put("causality", causalityToJson(finding.causality))
            .put("negativeControl", negativeControlToJson(finding.negativeControl))
            .put("personalPattern", personalPatternToJson(finding.personalPattern))
            // v1.1: emit statistical sanity flags so report exports show them.
            .put("sanityFlags", JSONArray(finding.sanityFlags))
    }

    fun evidenceToJson(evidence: EvidenceAssessment): JSONObject {
        return JSONObject()
            .put("sourceClass", evidence.sourceClass)
            .put("speciesClass", evidence.speciesClass)
            .put("studyDesign", evidence.studyDesign)
            .put("humanEvidence", evidence.humanEvidence)
            .put("evidenceQualityScore", evidence.evidenceQualityScore)
            .put("limitations", JSONArray(evidence.limitations))
    }

    fun causalityToJson(causality: CausalityAssessment): JSONObject {
        return JSONObject()
            .put("causalityScore", causality.causalityScore)
            .put("temporalityScore", causality.temporalityScore)
            .put("biologicalPlausibilityScore", causality.biologicalPlausibilityScore)
            .put("measurableMarkerScore", causality.measurableMarkerScore)
            .put("repeatabilityScore", causality.repeatabilityScore)
            .put("contradictionPenalty", causality.contradictionPenalty)
            .put("rationale", JSONArray(causality.rationale))
    }

    fun negativeControlToJson(negative: NegativeControlAssessment): JSONObject {
        return JSONObject()
            .put("status", negative.status)
            .put("reverseTimeRisk", negative.reverseTimeRisk)
            .put("shuffledTimelineRisk", negative.shuffledTimelineRisk)
            .put("unrelatedMarkerRisk", negative.unrelatedMarkerRisk)
            .put("notes", JSONArray(negative.notes))
    }

    fun personalPatternToJson(pattern: PersonalPatternAssessment): JSONObject {
        return JSONObject()
            .put("repeatedObservationCount", pattern.repeatedObservationCount)
            .put("temporalSupport", pattern.temporalSupport)
            .put("strongestLocalAxes", JSONArray(pattern.strongestLocalAxes))
            .put("nextBestMeasurement", pattern.nextBestMeasurement)
    }

    fun hypothesisCardToJson(card: HypothesisRankCard): JSONObject {
        return JSONObject()
            .put("hypothesisId", card.hypothesisId)
            .put("label", card.label)
            .put("status", card.status)
            .put("overallScore", card.overallScore)
            .put("evidenceQualityScore", card.evidenceQualityScore)
            .put("causalityScore", card.causalityScore)
            .put("personalRepeatability", card.personalRepeatability)
            .put("negativeControlStatus", card.negativeControlStatus)
            .put("nextBestMeasurement", card.nextBestMeasurement)
            .put("whyRanked", JSONArray(card.whyRanked))
    }

    fun hypothesisObjectToJson(obj: HypothesisObject): JSONObject {
        return JSONObject()
            .put("hypothesisId", obj.hypothesisId)
            .put("label", obj.label)
            .put("status", obj.status)
            .put("discoveryState", obj.discoveryState)
            .put("biasRiskState", obj.biasRiskState)
            .put("dataTrustScore", obj.dataTrustScore)
            .put("evidenceScore10", obj.evidenceScore10)
            .put("causalityScore", obj.causalityScore)
            .put("minimumDataPackStatus", obj.minimumDataPackStatus)
            .put("missingData", JSONArray(obj.missingData))
            .put("nextBestMeasurement", obj.nextBestMeasurement)
            .put("signalFlip", obj.signalFlip)
            .put("decisionImpact", obj.decisionImpact)
            .put("falsification", JSONArray(obj.falsification))
    }

    fun learningDeltaCardToJson(card: LearningDeltaCard): JSONObject {
        return JSONObject()
            .put("hypothesisId", card.hypothesisId)
            .put("deltaType", card.deltaType)
            .put("previousStatus", card.previousStatus)
            .put("currentStatus", card.currentStatus)
            .put("signalFlip", card.signalFlip)
            .put("decisionImpact", card.decisionImpact)
            .put("nextAction", card.nextAction)
    }

    fun mistakeRiskCardToJson(card: MistakeRiskCard): JSONObject {
        return JSONObject()
            .put("risk", card.risk)
            .put("preventionGate", card.preventionGate)
            .put("affectedHypotheses", JSONArray(card.affectedHypotheses))
    }

    fun researchStateSummaryToJson(summary: ResearchStateSummary): JSONObject {
        return JSONObject()
            .put("discoveryState", summary.discoveryState)
            .put("biasRiskState", summary.biasRiskState)
            .put("nextEvidence", summary.nextEvidence)
            .put("discoveryAction", summary.discoveryAction)
            .put("biasAlarm", summary.biasAlarm)
    }

    fun globalImmuneIntelligenceToJson(report: GlobalImmuneIntelligenceReport): JSONObject {
        return JSONObject()
            .put("mode", report.mode)
            .put("datasetCandidates", JSONArray(report.datasetCandidates.map { publicDatasetCandidateToJson(it) }))
            .put("axisMap", JSONArray(report.axisMap.map { immuneAxisSummaryToJson(it) }))
            .put("triggerResponseEdges", JSONArray(report.triggerResponseEdges.map { triggerResponseEdgeToJson(it) }))
            .put("globalHypotheses", JSONArray(report.globalHypotheses.map { globalHypothesisLeadToJson(it) }))
            .put("antiviralResponseNotes", JSONArray(report.antiviralResponseNotes.map { antiviralResponseNoteToJson(it) }))
            .put("nextGlobalDatasetNeeded", report.nextGlobalDatasetNeeded)
            .put("globalDiscoveryAction", report.globalDiscoveryAction)
            .put("globalBiasAlarm", report.globalBiasAlarm)
    }

    fun publicDatasetCandidateToJson(candidate: PublicDatasetCandidate): JSONObject {
        return JSONObject()
            .put("datasetId", candidate.datasetId)
            .put("source", candidate.source)
            .put("condition", candidate.condition)
            .put("dataType", candidate.dataType)
            .put("speciesClass", candidate.speciesClass)
            .put("sampleHint", candidate.sampleHint)
            .put("matchedAxes", JSONArray(candidate.matchedAxes))
            .put("qualityScore", candidate.qualityScore)
            .put("accessNote", candidate.accessNote)
            .put("url", candidate.url)
    }

    fun immuneAxisSummaryToJson(axis: ImmuneAxisSummary): JSONObject {
        return JSONObject()
            .put("axis", axis.axis)
            .put("count", axis.count)
            .put("role", axis.role)
            .put("topEvidence", axis.topEvidence)
    }

    fun triggerResponseEdgeToJson(edge: TriggerResponseEdge): JSONObject {
        return JSONObject()
            .put("trigger", edge.trigger)
            .put("responseAxis", edge.responseAxis)
            .put("tissueOrOutcome", edge.tissueOrOutcome)
            .put("evidenceScore", edge.evidenceScore)
            .put("status", edge.status)
            .put("rationale", edge.rationale)
    }

    fun globalHypothesisLeadToJson(lead: GlobalHypothesisLead): JSONObject {
        return JSONObject()
            .put("hypothesisId", lead.hypothesisId)
            .put("question", lead.question)
            .put("conditions", JSONArray(lead.conditions))
            .put("evidenceScore10", lead.evidenceScore10)
            .put("dataTrustScore", lead.dataTrustScore)
            .put("status", lead.status)
            .put("nextDatasetNeeded", lead.nextDatasetNeeded)
            .put("falsifier", lead.falsifier)
    }

    fun antiviralResponseNoteToJson(note: AntiviralResponseNote): JSONObject {
        return JSONObject()
            .put("theme", note.theme)
            .put("status", note.status)
            .put("involvedAxes", JSONArray(note.involvedAxes))
            .put("researchNote", note.researchNote)
    }


    fun pivotDecisionToJson(pivot: PivotDecision): JSONObject {
        return JSONObject()
            .put("pivotType", pivot.pivotType)
            .put("reason", pivot.reason)
            .put("nextIntent", pivot.nextIntent)
            .put("nextQuerySeed", pivot.nextQuerySeed)
            .put("priority", pivot.priority)
    }

    fun queryEvolutionStateToJson(state: QueryEvolutionState): JSONObject {
        return JSONObject()
            .put("hypothesisId", state.hypothesisId)
            .put("currentStage", state.currentStage)
            .put("nextStage", state.nextStage)
            .put("evolvedQuery", state.evolvedQuery)
            .put("reason", state.reason)
    }

    fun datasetCandidateV133ToJson(candidate: DatasetCandidateV133): JSONObject {
        return JSONObject()
            .put("datasetId", candidate.datasetId)
            .put("source", candidate.source)
            .put("species", candidate.species)
            .put("sampleSizeHint", candidate.sampleSizeHint)
            .put("dataType", candidate.dataType)
            .put("conditionHint", candidate.conditionHint)
            .put("outcomeLabelsHint", candidate.outcomeLabelsHint)
            .put("timeCourseHint", candidate.timeCourseHint)
            .put("priorityScore", candidate.priorityScore)
            .put("whyUseful", candidate.whyUseful)
            .put("nextVerificationStep", candidate.nextVerificationStep)
            .put("sourceTitle", candidate.sourceTitle)
            .put("sourceUrl", candidate.sourceUrl)
    }

    fun datasetAccessionCandidateToJson(candidate: DatasetAccessionCandidate): JSONObject {
        return JSONObject()
            .put("accession", candidate.accession)
            .put("source", candidate.source)
            .put("organismHint", candidate.organismHint)
            .put("conditionLabelsHint", candidate.conditionLabelsHint)
            .put("outcomeLabelsHint", candidate.outcomeLabelsHint)
            .put("triggerResponseOutcomeHint", candidate.triggerResponseOutcomeHint)
            .put("timeCourseHint", candidate.timeCourseHint)
            .put("sampleSizeHint", candidate.sampleSizeHint)
            .put("dataType", candidate.dataType)
            .put("usabilityScore", candidate.usabilityScore)
            .put("status", candidate.status)
            .put("sourceFindingId", candidate.sourceFindingId)
            .put("sourceTitle", candidate.sourceTitle)
            .put("sourceUrl", candidate.sourceUrl)
            .put("reasons", JSONArray(candidate.reasons))
    }

    fun evidenceObjectToJson(evidence: EvidenceObject): JSONObject {
        return JSONObject()
            .put("evidenceId", evidence.evidenceId)
            .put("sourceType", evidence.sourceType)
            .put("sourceId", evidence.sourceId)
            .put("title", evidence.title)
            .put("accessionIds", JSONArray(evidence.accessionIds))
            .put("supportsHypothesis", evidence.supportsHypothesis)
            .put("contradictsHypothesis", evidence.contradictsHypothesis)
            .put("hasNegativeControl", evidence.hasNegativeControl)
            .put("hasLongitudinalSignal", evidence.hasLongitudinalSignal)
            .put("hasMechanisticSignal", evidence.hasMechanisticSignal)
            .put("causalClaimSafe", evidence.causalClaimSafe)
            .put("linkedHypothesisId", evidence.linkedHypothesisId)
            .put("decisionImpact", evidence.decisionImpact)
            .put("qualityScore", evidence.qualityScore)
            .put("reasons", JSONArray(evidence.reasons))
    }

    fun reportV3ToJson(report: ResearchReportV3): JSONObject {
        return JSONObject()
            .put("cycleResult", report.cycleResult)
            .put("newUsefulLead", report.newUsefulLead)
            .put("hypothesisChanged", report.hypothesisChanged)
            .put("whyItMatters", report.whyItMatters)
            .put("nextAutonomousMove", report.nextAutonomousMove)
            .put("doNotBelieveYet", report.doNotBelieveYet)
            .put("technicalPointer", report.technicalPointer)
            .put("hypothesis", report.hypothesis)
            .put("supportingEvidence", report.supportingEvidence)
            .put("counterEvidenceOrContradiction", report.counterEvidenceOrContradiction)
            .put("whatWeDoNotBelieveYet", report.whatWeDoNotBelieveYet)
            .put("integrityStatus", report.integrityStatus)
            .put("integrityFailures", JSONArray(report.integrityFailures))
            .also { json ->
                report.learningSessionReport?.let { session ->
                    json.put("learningSessionReport", JSONObject()
                        .put("sessionId", session.sessionId)
                        .put("sessionType", session.sessionType.name)
                        .put("status", session.status.name)
                        .put("progress", session.progress)
                        .put("timeUsed", session.timeUsed)
                        .put("timeLimit", session.timeLimit)
                        .put("nextAction", session.nextAction)
                        .put("claimLimits", JSONObject(session.claimLimits))
                    )
                }
            }
    }


    fun reasoningReportToJson(report: ResearchReasoningReport): JSONObject {
        return JSONObject()
            .put("observation", report.observation)
            .put("interpretedMeaning", report.interpretedMeaning)
            .put("generatedQuestions", JSONArray(report.generatedQuestions))
            .put("competingHypotheses", JSONArray(report.competingHypotheses))
            .put("discriminatorEvidence", JSONArray(report.discriminatorEvidence))
            .put("reframedSearch", report.reframedSearch)
            .put("selfCritique", JSONArray(report.selfCritique))
            .put("nextReasonedMove", report.nextReasonedMove)
    }

    fun autonomousPlanToJson(plan: AutonomousResearchPlan): JSONObject {
        return JSONObject()
            .put("mode", plan.mode)
            .put("strategy", plan.strategy)
            .put("cycleIndex", plan.cycleIndex)
            .put("lanes", JSONArray(plan.lanes.map { autonomousLaneToJson(it) }))
            .put("nextStrategyIfNoUsefulSource", plan.nextStrategyIfNoUsefulSource)
            .put("notes", JSONArray(plan.notes))
    }

    fun autonomousLaneToJson(lane: AutonomousResearchLane): JSONObject {
        return JSONObject()
            .put("laneId", lane.laneId)
            .put("laneType", lane.laneType)
            .put("label", lane.label)
            .put("query", lane.query)
            .put("reason", lane.reason)
            .put("targetAxes", JSONArray(lane.targetAxes))
    }

    fun steeringProfileToJson(profile: ResearchSteeringProfile): JSONObject {
        return JSONObject()
            .put("profileId", profile.profileId)
            .put("createdAtMillis", profile.createdAtMillis)
            .put("variables", JSONArray(profile.variables))
            .put("focusQuestion", profile.focusQuestion)
            .put("requiredTerms", JSONArray(profile.requiredTerms))
            .put("excludedTerms", JSONArray(profile.excludedTerms))
            .put("inferredAxes", JSONArray(profile.inferredAxes))
    }

    fun steeringProfileFromJson(obj: JSONObject): ResearchSteeringProfile {
        val variables = obj.optJSONArray("variables") ?: JSONArray()
        val required = obj.optJSONArray("requiredTerms") ?: JSONArray()
        val excluded = obj.optJSONArray("excludedTerms") ?: JSONArray()
        val axes = obj.optJSONArray("inferredAxes") ?: JSONArray()
        return ResearchSteeringProfile(
            profileId = obj.optString("profileId"),
            createdAtMillis = obj.optLong("createdAtMillis"),
            variables = (0 until variables.length()).map { variables.optString(it) }.filter { it.isNotBlank() },
            focusQuestion = obj.optString("focusQuestion"),
            requiredTerms = (0 until required.length()).map { required.optString(it) }.filter { it.isNotBlank() },
            excludedTerms = (0 until excluded.length()).map { excluded.optString(it) }.filter { it.isNotBlank() },
            inferredAxes = (0 until axes.length()).map { axes.optString(it) }.filter { it.isNotBlank() }
        )
    }

    fun importedSignalToJson(signal: ImportedReportSignal): JSONObject {
        return JSONObject()
            .put("reportId", signal.reportId)
            .put("createdAtMillis", signal.createdAtMillis)
            .put("title", signal.title)
            .put("matchedAxes", JSONArray(signal.matchedAxes))
            .put("extractedKeywords", JSONArray(signal.extractedKeywords))
            .put("preview", signal.preview)
    }

    fun importedSignalFromJson(obj: JSONObject): ImportedReportSignal {
        val axes = obj.optJSONArray("matchedAxes") ?: JSONArray()
        val keys = obj.optJSONArray("extractedKeywords") ?: JSONArray()
        return ImportedReportSignal(
            reportId = obj.optString("reportId"),
            createdAtMillis = obj.optLong("createdAtMillis"),
            title = obj.optString("title"),
            matchedAxes = (0 until axes.length()).map { axes.optString(it) }.filter { it.isNotBlank() },
            extractedKeywords = (0 until keys.length()).map { keys.optString(it) }.filter { it.isNotBlank() },
            preview = obj.optString("preview")
        )
    }

    private fun queryToJson(query: ResearchQuery): JSONObject {
        return JSONObject()
            .put("id", query.id)
            .put("label", query.label)
            .put("query", query.query)
            .put("reason", query.reason)
    }

    private fun knowledgeDeltaToJson(delta: KnowledgeDelta): JSONObject {
        return JSONObject()
            .put("newSourcesSaved", delta.newSourcesSaved)
            .put("repeatedSourcesSkipped", delta.repeatedSourcesSkipped)
            .put("newAxisPairs", JSONArray(delta.newAxisPairs))
            .put("manualReportSignalsUsed", delta.manualReportSignalsUsed)
            .put("dnaRnaSignals", delta.dnaRnaSignals)
            .put("steeredQueriesGenerated", delta.steeredQueriesGenerated)
            .put("learningNotes", JSONArray(delta.learningNotes))
    }
}
