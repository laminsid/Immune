package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResearchEngineV30354CrossValidationExecutionTest {
    @Test
    fun internalCrossValidationExecutesButExternalExpressionReplicationRemainsRequired() {
        val first = FirstHypothesisCandidateV30352.evaluate("GSE85047 neuroblastoma hypoxia_stroma_proxy PFS")
        val cv = FirstHypothesisCrossValidationExecutionV30354.evaluate("GSE85047 neuroblastoma hypoxia_stroma_proxy PFS", first)
        assertTrue(cv.active)
        assertEquals("INTERNAL_CROSS_VALIDATION_EXECUTED_EXTERNAL_REPLICATION_REQUIRED", cv.state)
        assertEquals(5, cv.internalFoldCount)
        assertTrue(cv.internalConsistentFolds >= 0)
        assertEquals("EXTERNAL_REPLICATION_METADATA_ATTACHED_EXPRESSION_PROXY_REQUIRED", cv.externalReplicationStatus)
        assertFalse(cv.highImpactClaimAllowed)
        assertTrue(cv.boundary.contains("not independent replication"))
    }

    @Test
    fun gse49711MetadataRouteIsAttachedButNotExpressionReplication() {
        assertFalse(ExternalReplicationLiteMatrixRegistryV30354.hasAnyReplicationMatrix())
        assertTrue(ExternalReplicationLiteMatrixRegistryV30354.hasGse49711MetadataOnlyRoute())
        assertEquals(498, ExternalReplicationLiteMatrixRegistryV30354.gse49711MetadataRowCount)
        assertTrue(ExternalReplicationLiteMatrixRegistryV30354.schemaHeader().contains("hypoxia_stroma_proxy"))
        val report = FirstHypothesisCrossValidationExecutionV30354.evaluate(
            "GSE85047 neuroblastoma hypoxia_stroma_proxy PFS",
            FirstHypothesisCandidateV30352.evaluate("GSE85047 neuroblastoma hypoxia_stroma_proxy PFS")
        )
        val gse = report.externalTargets.first { it.accession.contains("GSE49710/GSE49711") }
        assertEquals(0, gse.rows.size)
        assertEquals(498, gse.metadataRowCount)
        assertEquals("GSE49711_METADATA_ONLY_REPLICATION_ROUTE_v30355.csv", gse.metadataFile)
        assertTrue(report.externalTargets.any { it.accession.contains("TARGET-NBL") })
        assertTrue(report.externalTargets.any { it.rows.isEmpty() })
    }
}
