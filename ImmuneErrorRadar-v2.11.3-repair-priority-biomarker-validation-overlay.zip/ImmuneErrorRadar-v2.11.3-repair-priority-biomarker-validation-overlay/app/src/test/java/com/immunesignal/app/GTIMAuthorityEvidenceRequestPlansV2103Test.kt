package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMAuthorityEvidenceRequestPlansV2103Test {

    @Test
    fun dossierCarriesAuthorityEvidenceExpansionHintsWithoutBlockingDiscovery() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("MSI dMMR colorectal cancer checkpoint immunotherapy nivolumab ipilimumab")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSEAUTH2103", null, dgeBlocked("GSEAUTH2103"))

        assertEquals("2.10.8-root-cause-eco-immune-dossier-internal-extension", dossier.version)
        assertTrue(dossier.knowledgeAssetContract?.state?.contains("PASS") == true)
        assertTrue(dossier.authorityEvidenceRequestPlans.isNotEmpty())
        assertTrue(dossier.authorityEvidenceRequestPlans.all { it.noHttpExecution })
        assertTrue(dossier.authorityEvidenceRequestPlans.any { it.sourceType == "FDA_OR_AUTHORITY_LABEL" })
        assertTrue(dossier.conciseLines.any { it.startsWith("Authority evidence expansion hint:") })
        assertTrue(dossier.conciseLines.any { it.contains("not_a_discovery_blocker=true") })
        assertTrue(dossier.explorationPosture?.state?.contains("RELAXED") == true)
        assertFalse(dossier.conciseLines.joinToString("\n").lowercase().contains("recommended dose"))
    }

    @Test
    fun knowledgeAssetContractKeepsOntologyBroadAndResearchOnly() {
        val report = GTIMKnowledgeBaseAssetContractV2103.validate()

        assertEquals("KNOWLEDGE_ASSET_CONTRACT_PASS_RESEARCH_ONLY_BROAD_ONTOLOGY", report.state)
        assertTrue(report.hasOpenExplorationFallback)
        assertTrue(report.hasEvidenceRankLegend)
        assertTrue(report.hasEscapeRiskFields)
        assertTrue(report.hasClaimLimits)
        assertTrue(report.line.contains("not_disease_whitelist=true"))
    }

    @Test
    fun openExplorationStillProducesExpansionHintsButNoClinicalActionClaim() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("rare immune genetic mechanism unknown syndrome novel pathway")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", null, dgeBlocked("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED"))
        val joined = dossier.conciseLines.joinToString("\n")

        assertTrue(dossier.immunotherapyHypothesisCards.any { it.mechanismId == "open_mechanism_exploration" })
        assertTrue(dossier.authorityEvidenceRequestPlans.any { it.state == "EVIDENCE_EXPANSION_OPEN_EXPLORATION_HINT" })
        assertTrue(joined.contains("not disease whitelist") || joined.contains("not_disease_whitelist"))
        assertFalse(joined.lowercase().contains("proven treatment"))
        assertFalse(joined.lowercase().contains("clinical management plan"))
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
