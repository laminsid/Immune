package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMLatentAxisFilterV2107Test {

    @Test
    fun latentFilterPrioritizesMicrobiomeMetabolismAndImmuneBridgeWithoutRenderingSection() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Alzheimer APOE amyloid tau glucose insulin microbiome inflammation protein clearance")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSE210700", null, dgeBlocked("GSE210700"))
        val joined = dossier.conciseLines.joinToString("\n")

        assertTrue(dossier.version == "2.10.8-root-cause-eco-immune-dossier-internal-extension")
        assertTrue(dossier.freeHypothesisSynthesis?.cards?.isNotEmpty() == true)
        assertTrue(dossier.freeHypothesisSynthesis!!.cards.any { card ->
            card.missingEvidence.any { it.contains("metabolic", ignoreCase = true) || it.contains("microbiome", ignoreCase = true) || it.contains("immune", ignoreCase = true) }
        })
        assertFalse(joined.contains("Latent axis filter:"))
        assertFalse(joined.contains("mandatory_internal_pass"))
        assertFalse(joined.contains("Microbiome-first router"))
        assertFalse(joined.contains("Metabolism-first filter"))
    }

    @Test
    fun directFilterRemainsGeneralAndNotDiseaseWhitelist() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("rare unexplained tissue stress immune genetic metabolic route")
        val filter = GTIMLatentAxisFilterV2107.build(
            contract = contract,
            establishedEvidence = emptyList(),
            discoveryFindings = emptyList(),
            mechanismMap = emptyList(),
            therapeuticRoutes = emptyList(),
            immunotherapyCards = emptyList(),
            dgeVerdict = dgeBlocked("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED")
        )

        assertTrue(filter.hidden)
        assertTrue(filter.policy.contains("not_disease_whitelist"))
        assertTrue(filter.scores.any { it.axisId == "microbiome_axis" })
        assertTrue(filter.scores.any { it.axisId == "metabolic_axis" })
        assertTrue(filter.scores.any { it.axisId == "immune_interaction_axis" })
        assertTrue(filter.routeInfluenceTokens.isNotEmpty())
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
