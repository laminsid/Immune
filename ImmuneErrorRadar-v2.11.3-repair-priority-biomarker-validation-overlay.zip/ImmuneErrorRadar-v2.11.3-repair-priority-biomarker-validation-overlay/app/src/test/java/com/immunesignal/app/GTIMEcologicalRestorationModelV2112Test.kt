package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMEcologicalRestorationModelV2112Test {

    @Test
    fun pondAnalogyBecomesRestorationLensNotHumanTreatmentClaim() {
        val contract = GTIMRunDecisionContractFactoryV2740.build(
            "pond black water swamp bacteria cleaning microbiome barrier inflammation root cause"
        )
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(
            contract,
            "GSE211200",
            null,
            dgeBlocked("GSE211200")
        )
        val root = dossier.ecoImmuneRootCause!!
        val restoration = root.ecologicalRestoration!!
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(restoration.active)
        assertTrue(restoration.version.contains("2.11.2"))
        assertTrue(restoration.collapseSignals.isNotEmpty())
        assertTrue(restoration.restorationSequences.isNotEmpty())
        assertTrue(restoration.analogyGuard.contains("never_proves_human_causality"))
        assertTrue(root.rootCauseGraphState.contains("restoration_lens="))
        assertTrue(joined.contains("restoration lens"))
        assertTrue(joined.contains("analogy"))
        assertTrue(joined.contains("recovery_markers") || joined.contains("recovery markers"))
        assertTrue(dossier.dataHarmonization!!.sourceCapsules.any { it.capsuleId == "CAPSULE_ECOLOGICAL_RESTORATION_CONTEXT" })
        assertFalse(joined.contains("pond restoration proves"))
        assertFalse(joined.contains("recommended dose"))
        assertFalse(joined.contains("clinical management plan"))
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
