package com.immunesignal.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMImmunotherapyKnowledgeBaseDossierV2102Test {

    @Test
    fun cancerTopicRendersEvidenceRankVariantGateAndClinicalTrialsRequestPlan() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("colon cancer MSI dMMR checkpoint DNA repair apoptosis immunotherapy")
        val bridge = GTIMMetadataFirstObservedEvidenceBridgeV2950.build(contract, fileDiscovery("GSE210200"), JSONObject().put("geoSoftText", cancerSoftText()))
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSE210200", bridge, dgeBlocked("GSE210200"))

        assertEquals("2.10.8-root-cause-eco-immune-dossier-internal-extension", dossier.version)
        assertTrue(dossier.immunotherapyKnowledgeLine.contains("non-restrictive mechanism ontology"))
        assertTrue(dossier.immunotherapyHypothesisCards.any { it.evidenceRank.contains("A_TO_D") || it.evidenceRank.contains("A_CANDIDATE") })
        assertTrue(dossier.immunotherapyHypothesisCards.any { it.targetConservation.isNotBlank() && it.escapeRisk.isNotBlank() })
        assertTrue(dossier.clinicalTrialsRequestPlans.all { it.noHttpExecution })
        assertTrue(dossier.conciseLines.any { it.startsWith("Therapeutic hypothesis card:") })
        assertTrue(dossier.conciseLines.any { it.startsWith("ClinicalTrials request plan:") })
    }

    @Test
    fun unknownTopicFallsBackToOpenExplorationWithoutDiseaseWhitelist() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("rare immune genetic pathway novel tissue stress unexplained syndrome")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", null, dgeBlocked("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED"))
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(dossier.immunotherapyHypothesisCards.any { it.mechanismId == "open_mechanism_exploration" })
        assertTrue(joined.contains("not disease whitelist"))
        assertTrue(joined.contains("open immune/genetic therapeutic exploration"))
        assertFalse(joined.contains("recommended dose"))
        assertFalse(joined.contains("clinical management plan"))
        assertFalse(joined.contains("proven treatment"))
    }

    @Test
    fun viralTopicCarriesVariantEscapeGateButNoCountermeasureClaim() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("viral outbreak RSV Ebola monoclonal antibody neutralization variant escape")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSEVIRAL", null, dgeBlocked("GSEVIRAL"))
        val card = dossier.immunotherapyHypothesisCards.first { it.mechanismId == "passive_antiviral_antibody" }

        assertTrue(card.escapeRisk.contains("RAPIDLY_MUTATING") || card.escapeRisk.contains("DOCUMENTED_ESCAPE") || card.escapeRisk.contains("CONSERVATION"))
        assertTrue(card.clinicalTrialsRequestPlan.contains("clinicaltrials.gov/api/v2/studies"))
        assertFalse(card.line.lowercase().contains("efficacy claim=false"))
        assertTrue(card.line.contains("no_dosing_no_clinical_management_no_efficacy_claim=true"))
    }

    private fun fileDiscovery(target: String): GTIMRepositoryFileDiscoveryReportV2800 =
        GTIMRepositoryFileDiscoveryReportV2800(
            active = true,
            targetId = target,
            repository = "GEO",
            state = "FILE_DISCOVERY_REQUEST_READY",
            candidateFileTypes = GTIMRepositoryFileDiscoveryV2800.MATRIX_FILE_SIGNATURES,
            repositoryLookupUrls = emptyList(),
            downloadMode = "USER_STARTED_PUBLIC_REPOSITORY_ONLY",
            fileDiscoveryLine = "test",
            downloadRequestLine = "test",
            boundaryLine = "test"
        )

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )

    private fun cancerSoftText(): String = """
        ^SAMPLE = GSM2102001
        !Sample_title = dMMR MSI colorectal tumor sample
        !Sample_characteristics_ch1 = disease state: colorectal cancer
        !Sample_characteristics_ch1 = biomarker: MSI-H dMMR
        !Sample_relation = SRA: SRP210200
    """.trimIndent()
}
