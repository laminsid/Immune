package com.immunesignal.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMHypothesisLearningLedgerV2106Test {

    @Test
    fun freeHypothesesBecomeLearnableRoutesWithoutBecomingMedicalTruth() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("colon cancer MSI DNA repair checkpoint apoptosis immune visibility novel route")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSE210600", null, dgeBlocked("GSE210600"))
        val ledger = dossier.hypothesisLearningLedger
        val joined = dossier.conciseLines.joinToString("\n")

        assertTrue(dossier.version == "2.10.8-root-cause-eco-immune-dossier-internal-extension")
        assertTrue(ledger?.active == true)
        assertTrue(ledger?.entries?.isNotEmpty() == true)
        assertTrue(joined.contains("Hypothesis learning ledger:"))
        assertTrue(joined.contains("Hypothesis learning entry:"))
        assertTrue(joined.contains("not_medical_truth=true"))
        assertTrue(joined.contains("reusable research memory, not medical truth"))
        assertFalse(joined.lowercase().contains("recommended dose"))
        assertFalse(joined.lowercase().contains("stop medication"))
        assertFalse(joined.lowercase().contains("proven treatment"))
    }

    @Test
    fun ledgerKeepsNextProofReinforcementWeakeningAndFalsificationSignals() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("autoimmune B cell CD19 cytokine reset experimental analogy")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "GSEAUTO2106", null, dgeBlocked("GSEAUTO2106"))
        val entry = dossier.hypothesisLearningLedger!!.entries.first()

        assertTrue(entry.nextProofTasks.isNotEmpty())
        assertTrue(entry.reinforcementSignals.isNotEmpty())
        assertTrue(entry.weakeningSignals.isNotEmpty())
        assertTrue(entry.falsificationPriority.contains("FALSIFICATION_PRIORITY"))
        assertTrue(entry.reusableLearningKey.isNotBlank())
        assertTrue(entry.learningStatus.contains("LEARNABLE"))
    }

    @Test
    fun unknownTopicStillProducesOpenLedgerRoute() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("rare immune genetic tissue stress unexplained mediator")
        val dossier = GTIMMedicalResearchDossierBuilderV2100.build(contract, "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", null, dgeBlocked("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED"))
        val ledger = dossier.hypothesisLearningLedger!!
        val joined = dossier.conciseLines.joinToString("\n").lowercase()

        assertTrue(ledger.entries.isNotEmpty())
        assertTrue(ledger.state.contains("LEDGER"))
        assertTrue(joined.contains("authority_is_weight_not_blocker=true"))
        assertTrue(joined.contains("operational_learning_only"))
        assertFalse(joined.contains("clinical management plan"))
    }

    private fun dgeBlocked(target: String): GTIMDgeReadinessVerdictReportV2802 =
        GTIMDgeReadinessVerdictReportV2802(
            active = true,
            targetId = target,
            verdict = "DGE_BLOCKED_OBSERVED_FILE_EVIDENCE_NOT_COMPLETE",
            blockers = listOf("observed_file_evidence_required"),
            line = "test",
            boundaryLine = "test"
        )
}
