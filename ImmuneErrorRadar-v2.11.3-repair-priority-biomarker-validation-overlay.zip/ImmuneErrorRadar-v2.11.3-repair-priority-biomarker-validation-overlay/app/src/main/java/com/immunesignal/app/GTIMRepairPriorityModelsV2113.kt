package com.immunesignal.app

// v2.11.3 — Repair priority and validation models.
// This layer turns restoration routes into an ordered research queue. It does not
// recommend treatment; it ranks which repair-function hypotheses are most worth
// testing and states the biomarkers/falsification signals needed to validate them.

data class GTIMRepairFunctionRankV2113(
    val rankId: String,
    val sourceRouteId: String,
    val sourceLayer: String,
    val dysfunctionClass: String,
    val repairFunction: String,
    val candidateRouteClasses: List<String>,
    val score: Int,
    val priorityBand: String,
    val impactLogic: String,
    val feasibilityLogic: String,
    val riskLogic: String,
    val evidenceNeed: List<String>,
    val claimLimit: String,
    val line: String
)

data class GTIMRepairBiomarkerPlanV2113(
    val planId: String,
    val sourceRankId: String,
    val biomarkerGroups: List<String>,
    val recoveryMarkers: List<String>,
    val falsificationSignals: List<String>,
    val minimalDataPack: List<String>,
    val upgradeRule: String,
    val line: String
)

data class GTIMRepairPriorityValidationReportV2113(
    val active: Boolean,
    val version: String,
    val state: String,
    val principle: String,
    val rankedRepairFunctions: List<GTIMRepairFunctionRankV2113>,
    val biomarkerPlans: List<GTIMRepairBiomarkerPlanV2113>,
    val executionOrder: List<String>,
    val integrationState: String,
    val boundaryLine: String,
    val line: String
) {
    companion object {
        fun empty(): GTIMRepairPriorityValidationReportV2113 = GTIMRepairPriorityValidationReportV2113(
            active = false,
            version = GTIMRepairPriorityValidationEngineV2113.VERSION,
            state = "REPAIR_PRIORITY_VALIDATION_NOT_EVALUATED",
            principle = GTIMRepairPriorityValidationEngineV2113.PRINCIPLE,
            rankedRepairFunctions = emptyList(),
            biomarkerPlans = emptyList(),
            executionOrder = emptyList(),
            integrationState = "NOT_EVALUATED",
            boundaryLine = GTIMRepairPriorityValidationEngineV2113.BOUNDARY,
            line = "Repair priority validation: not evaluated."
        )
    }
}
