package com.immunesignal.app

// v2.10.9 — CI hardening guard for the root-cause eco-immune integration.
// This is intentionally small: it does not add biomedical behavior. It verifies that
// the connected dossier chain has the minimum objects GitHub/JUnit usually breaks on.
data class GTIMCiHardeningGuardReportV2109(
    val active: Boolean,
    val version: String,
    val state: String,
    val checks: List<String>,
    val blockers: List<String>,
    val line: String
) {
    companion object {
        fun empty(): GTIMCiHardeningGuardReportV2109 = GTIMCiHardeningGuardReportV2109(
            active = false,
            version = GTIMCiHardeningGuardV2109.VERSION,
            state = "CI_HARDENING_NOT_EVALUATED",
            checks = emptyList(),
            blockers = emptyList(),
            line = "CI hardening guard: not evaluated."
        )
    }
}

object GTIMCiHardeningGuardV2109 {
    const val VERSION: String = "2.10.9-ci-hardening-root-cause-integration"
    const val PURPOSE: String = "github_ci_compile_regression_guard_no_new_biomedical_logic"

    fun build(
        dossierVersion: String,
        rootCause: GTIMEcoImmuneRootCauseReportV2108,
        freeHypothesis: GTIMFreeHypothesisSynthesisReportV2105,
        learningLedger: GTIMHypothesisLearningLedgerReportV2106,
        dataHarmonization: GTIMDataHarmonizationReportV2110? = null
    ): GTIMCiHardeningGuardReportV2109 {
        val checks = listOf(
            "dossier_version=$dossierVersion",
            "root_cause_active=${rootCause.active}",
            "root_cause_candidates=${rootCause.candidates.size}",
            "restoration_routes=${rootCause.restorationRoutes.size}",
            "falsification_plans=${rootCause.falsificationPlans.size}",
            "microbial_reversal_active=${rootCause.microbialReversal?.active ?: false}",
            "microbial_reversal_candidates=${rootCause.microbialReversal?.candidateRoutes?.size ?: 0}",
            "ecological_restoration_active=${rootCause.ecologicalRestoration?.active ?: false}",
            "ecological_restoration_sequences=${rootCause.ecologicalRestoration?.restorationSequences?.size ?: 0}",
            "symptom_overlap_active=${rootCause.symptomOverlap?.active ?: false}",
            "symptom_overlap_hypotheses=${rootCause.symptomOverlap?.dysfunctionHypotheses?.size ?: 0}",
            "repair_priority_active=${rootCause.repairPriorityValidation?.active ?: false}",
            "repair_priority_ranks=${rootCause.repairPriorityValidation?.rankedRepairFunctions?.size ?: 0}",
            "repair_priority_biomarker_plans=${rootCause.repairPriorityValidation?.biomarkerPlans?.size ?: 0}",
            "free_hypothesis_active=${freeHypothesis.active}",
            "free_hypothesis_cards=${freeHypothesis.cards.size}",
            "learning_ledger_active=${learningLedger.active}",
            "learning_ledger_entries=${learningLedger.entries.size}",
            "data_harmonization_active=${dataHarmonization?.active ?: false}",
            "data_harmonization_routes=${dataHarmonization?.solutionRoutes?.size ?: 0}",
            "soft_spurious_guard_blocks_causal_claims_not_routes=true",
            "microbial_reversal_no_wetlab_or_treatment_protocol=true",
            "ecological_restoration_analogy_not_proof=true",
            "symptoms_are_not_disease_identity=true",
            "repair_priority_requires_biomarkers_and_falsification=true",
            "no_network_execution=true",
            "no_android_ui_dependency=true"
        )
        val blockers = mutableListOf<String>()
        if (!dossierVersion.contains("2.10.9") && !dossierVersion.contains("2.11.0") && !dossierVersion.contains("2.11.2") && !dossierVersion.contains("2.11.3")) blockers += "DOSSIER_VERSION_NOT_2109_OR_2110_OR_2112_OR_2113"
        if (!rootCause.active) blockers += "ROOT_CAUSE_REPORT_NOT_ACTIVE"
        if (rootCause.candidates.isEmpty()) blockers += "ROOT_CAUSE_CANDIDATES_EMPTY"
        if (rootCause.restorationRoutes.isEmpty()) blockers += "RESTORATION_ROUTES_EMPTY"
        if (rootCause.repairPriorityValidation != null && rootCause.repairPriorityValidation.active && rootCause.repairPriorityValidation.rankedRepairFunctions.isEmpty()) blockers += "REPAIR_PRIORITY_RANKS_EMPTY"
        if (rootCause.falsificationPlans.isEmpty()) blockers += "FALSIFICATION_PLANS_EMPTY"
        if (!freeHypothesis.active) blockers += "FREE_HYPOTHESIS_NOT_ACTIVE"
        if (!learningLedger.active) blockers += "LEARNING_LEDGER_NOT_ACTIVE"
        if (dataHarmonization != null && !dataHarmonization.active) blockers += "DATA_HARMONIZATION_NOT_ACTIVE"
        val state = if (blockers.isEmpty()) "CI_HARDENING_PASS_ROOT_CAUSE_CHAIN_CONNECTED" else "CI_HARDENING_WARN_REVIEW_CHAIN_CONNECTION"
        val line = "CI hardening guard: version=$VERSION | state=$state | purpose=$PURPOSE | checks=${checks.joinToString(";").oneLine()} | blockers=${blockers.joinToString(";").ifBlank { "none" }}"
        return GTIMCiHardeningGuardReportV2109(
            active = true,
            version = VERSION,
            state = state,
            checks = checks,
            blockers = blockers,
            line = line
        )
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
