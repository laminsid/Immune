package com.immunesignal.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * v2.6.3 Safe Launcher.
 *
 * The launcher is intentionally built programmatically instead of inflating a large XML
 * surface. This keeps the first screen resilient if a drawable/theme/layout regression
 * slips into a later UI polish pass. ResearchAutopilotActivity and HistoryActivity keep
 * their existing layouts; this screen is only the stable front door.
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildStableLauncher())
    }

    private fun buildStableLauncher(): View {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(248, 250, 251))
            isFillViewport = true
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(36))
        }
        scroll.addView(
            root,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
        )

        // v2.9.3: button-only launcher. Explanatory/report cards are removed from the live UI.
        root.addView(primaryButton("Start GTIM Research") { openActivity(ResearchAutopilotActivity::class.java) })
        return scroll
    }

    private fun heroCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = roundedBackground(Color.rgb(4, 47, 46), dp(24), strokeColor = Color.rgb(13, 148, 136), strokeWidth = 1)
        }
        card.addView(label("GTIM · RESEARCH ENGINE", Color.WHITE))
        card.addView(text("Immune Error Radar", 32f, Color.WHITE, Typeface.BOLD, top = 16))
        card.addView(text("Global Translational Immunology & Discovery Dossier Engine", 14f, Color.rgb(176, 240, 234), Typeface.BOLD, top = 6))
        card.addView(text("Research leads only. Full technical details stay in Export.", 13f, Color.rgb(221, 250, 247), Typeface.NORMAL, top = 14))
        return card
    }

    private fun capabilityCard(title: String, body: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = roundedBackground(Color.WHITE, dp(18), strokeColor = Color.rgb(209, 228, 226), strokeWidth = 1)
        }
        card.addView(text(title, 15f, Color.rgb(10, 22, 40), Typeface.BOLD))
        card.addView(text(body, 13f, Color.rgb(71, 85, 105), Typeface.NORMAL, top = 5))
        return card
    }

    private fun safetyNote(): TextView = text(
        "Boundary: biomedical research data-engineering only. Outputs are exploratory hypotheses and evidence plans, not clinical claims.",
        12f,
        Color.rgb(71, 85, 105),
        Typeface.NORMAL
    ).apply {
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
    }

    private fun label(value: String, color: Int): TextView = TextView(this).apply {
        text = value
        textSize = 10f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(color)
        letterSpacing = 0.07f
        setPadding(dp(10), dp(5), dp(10), dp(5))
        background = roundedBackground(Color.argb(42, 255, 255, 255), dp(999), strokeColor = Color.argb(80, 255, 255, 255), strokeWidth = 1)
    }

    private fun text(value: String, sizeSp: Float, color: Int, style: Int, top: Int = 0): TextView = TextView(this).apply {
        text = value
        textSize = sizeSp
        typeface = Typeface.create(Typeface.DEFAULT, style)
        setTextColor(color)
        setLineSpacing(dp(2).toFloat(), 1.0f)
        if (top > 0) {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(top) }
        }
    }

    private fun primaryButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        isAllCaps = false
        setTextColor(Color.WHITE)
        minHeight = dp(56)
        background = roundedBackground(Color.rgb(15, 118, 110), dp(16))
        setOnClickListener { action() }
    }

    private fun secondaryButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 14f
        isAllCaps = false
        setTextColor(Color.rgb(11, 94, 87))
        minHeight = dp(52)
        background = roundedBackground(Color.rgb(240, 249, 248), dp(16), strokeColor = Color.rgb(209, 228, 226), strokeWidth = 1)
        setOnClickListener { action() }
    }

    private fun openActivity(target: Class<out Activity>) {
        runCatching { startActivity(Intent(this, target)) }
            .onFailure { error ->
                Toast.makeText(
                    this,
                    "Unable to open screen: ${error.javaClass.simpleName}",
                    Toast.LENGTH_LONG
                ).show()
            }
    }

    private fun spacer(heightDp: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(heightDp)
        )
    }

    private fun roundedBackground(color: Int, radius: Int, strokeColor: Int? = null, strokeWidth: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != null && strokeWidth > 0) {
                setStroke(dp(strokeWidth), strokeColor)
            }
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
