package com.immunesignal.app

// v2.11.3 — Repair priority validation engine.
// Integrates symptom overlap, ecological restoration, microbial reversal, and
// root-cause routes into a ranked test queue with explicit biomarkers and kill rules.
object GTIMRepairPriorityValidationEngineV2113 {
    const val VERSION: String = "2.11.3-repair-priority-biomarker-validation"
    const val PRINCIPLE: String = "rank_repair_functions_by_root_cause_impact_testability_risk_and_missing_biomarkers"
    const val BOUNDARY: String = "research_priority_and_validation_plan_only_not_diagnosis_not_treatment_not_wetlab_protocol"

    fun build(
        rootCandidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
        restorationRoutes: List<GTIMEcosystemRestorationRouteV2108>,
        microbialReversal: GTIMMicrobialReversalReportV2111?,
        ecologicalRestoration: GTIMEcologicalRestorationReportV2112?,
        symptomOverlap: GTIMSymptomOverlapReportV2112?
    ): GTIMRepairPriorityValidationReportV2113 {
        val routeRanks = restorationRoutes.mapIndexed { index, route -> rankRoute(index, route) }
        val symptomRanks = symptomOverlap?.restorativeRoutes.orEmpty().take(4).mapIndexed { index, route -> rankSymptomRoute(index, route) }
        val microbialRanks = microbialReversal?.candidateRoutes.orEmpty().take(4).mapIndexed { index, route -> rankMicrobialRoute(index, route) }
        val ecologicalRanks = ecologicalRestoration?.restorationSequences.orEmpty().take(4).mapIndexed { index, sequence -> rankEcologicalSequence(index, sequence) }
        val rootCandidateRanks = rootCandidates.take(4).mapIndexed { index, candidate -> rankRootCandidate(index, candidate) }

        val ranked = (routeRanks + symptomRanks + microbialRanks + ecologicalRanks + rootCandidateRanks)
            .distinctBy { it.sourceLayer + ":" + it.sourceRouteId + ":" + it.repairFunction }
            .sortedWith(compareByDescending<GTIMRepairFunctionRankV2113> { it.score }.thenBy { it.rankId })
            .take(10)
        val plans = ranked.take(6).map { buildBiomarkerPlan(it) }
        val order = ranked.take(5).mapIndexed { idx, rank ->
            "${idx + 1}. ${rank.repairFunction} -> ${rank.priorityBand} -> require ${plans.firstOrNull { it.sourceRankId == rank.rankId }?.biomarkerGroups?.take(2)?.joinToString("+") ?: "biomarker plan"}"
        }
        val state = when {
            ranked.any { it.priorityBand == "P0_HIGH_VALUE_TEST_FIRST" } -> "REPAIR_PRIORITY_HIGH_VALUE_TEST_QUEUE_READY"
            ranked.isNotEmpty() -> "REPAIR_PRIORITY_RESEARCH_QUEUE_READY"
            else -> "REPAIR_PRIORITY_OPEN_NO_RANKABLE_ROUTE"
        }
        val integration = "CONNECTED|routes=${restorationRoutes.size}|microbial=${microbialReversal?.candidateRoutes?.size ?: 0}|ecological=${ecologicalRestoration?.restorationSequences?.size ?: 0}|symptom=${symptomOverlap?.restorativeRoutes?.size ?: 0}|ranked=${ranked.size}|plans=${plans.size}"
        val line = "Repair priority validation: version=$VERSION | state=$state | principle=$PRINCIPLE | integration=$integration | top=${ranked.firstOrNull()?.repairFunction?.oneLine().orEmpty()} | execution_order=${order.joinToString(";").oneLine()} | boundary=$BOUNDARY"
        return GTIMRepairPriorityValidationReportV2113(
            active = true,
            version = VERSION,
            state = state,
            principle = PRINCIPLE,
            rankedRepairFunctions = ranked,
            biomarkerPlans = plans,
            executionOrder = order,
            integrationState = integration,
            boundaryLine = BOUNDARY,
            line = line
        )
    }

    private fun rankRoute(index: Int, route: GTIMEcosystemRestorationRouteV2108): GTIMRepairFunctionRankV2113 {
        val text = (route.routeClass + " " + route.restorationLogic + " " + route.researchLevers.joinToString(" ")).lowercase()
        val function = when {
            text.contains("barrier") || text.contains("mucosal") -> "barrier and mucosal tolerance restoration"
            text.contains("microbial") || text.contains("microbiome") || text.contains("metabolite") -> "microbial-metabolite function restoration"
            text.contains("metabolic") || text.contains("mitochond") || text.contains("energy") -> "immunometabolic resilience restoration"
            text.contains("variant") || text.contains("adaptive") || text.contains("immune readiness") -> "immune readiness and durability restoration"
            text.contains("symptom_overlap") || text.contains("dysfunction") -> "symptom-to-dysfunction repair-function search"
            else -> "open system repair-function search"
        }
        return rank(
            id = "RP_ROUTE_${index + 1}_${route.routeId}".safeId(),
            sourceId = route.routeId,
            layer = "root_restoration_route",
            dysfunction = route.routeClass,
            repairFunction = function,
            candidateClasses = route.researchLevers,
            requiredEvidence = route.requiredEvidence,
            sourceText = text
        )
    }

    private fun rankSymptomRoute(index: Int, route: GTIMRestorativeFunctionRouteV2112): GTIMRepairFunctionRankV2113 = rank(
        id = "RP_SYMPTOM_${index + 1}_${route.dysfunctionClass}".safeId(),
        sourceId = route.routeId,
        layer = "symptom_overlap_resolver",
        dysfunction = route.dysfunctionClass,
        repairFunction = route.restorativeFunction,
        candidateClasses = route.candidateRouteClasses,
        requiredEvidence = route.requiredEvidence,
        sourceText = (route.dysfunctionClass + " " + route.restorativeFunction + " " + route.candidateRouteClasses.joinToString(" ")).lowercase()
    )

    private fun rankMicrobialRoute(index: Int, route: GTIMMicrobialReversalCandidateV2111): GTIMRepairFunctionRankV2113 = rank(
        id = "RP_MRE_${index + 1}_${route.candidateId}".safeId(),
        sourceId = route.candidateId,
        layer = "microbial_reversal_engine",
        dysfunction = route.sourceFunctionId,
        repairFunction = route.hypotheticalRole,
        candidateClasses = listOf(route.candidateClass, route.evidenceRank),
        requiredEvidence = route.missingEvidence,
        sourceText = (route.candidateClass + " " + route.hypotheticalRole + " " + route.evidenceRank).lowercase()
    )

    private fun rankEcologicalSequence(index: Int, sequence: GTIMRestorationSequenceV2112): GTIMRepairFunctionRankV2113 = rank(
        id = "RP_ERM_${index + 1}_${sequence.collapseType.name}".safeId(),
        sourceId = sequence.sequenceId,
        layer = "ecological_restoration_model",
        dysfunction = sequence.collapseType.name,
        repairFunction = sequence.firstRepairFunction,
        candidateClasses = listOf(sequence.microbialRole, sequence.secondOrderEffect, sequence.confidenceState),
        requiredEvidence = sequence.recoveryIndicators + sequence.failureSignals,
        sourceText = (sequence.collapseType.name + " " + sequence.firstRepairFunction + " " + sequence.microbialRole).lowercase()
    )

    private fun rankRootCandidate(index: Int, candidate: GTIMEcoImmuneRootCauseCandidateV2108): GTIMRepairFunctionRankV2113 = rank(
        id = "RP_ROOT_${index + 1}_${candidate.candidateId}".safeId(),
        sourceId = candidate.candidateId,
        layer = "eco_immune_root_cause_candidate",
        dysfunction = candidate.upstreamDysfunction,
        repairFunction = candidate.restorationNeed,
        candidateClasses = candidate.contextModifiers,
        requiredEvidence = candidate.missingEvidence + candidate.falsificationTests,
        sourceText = (candidate.upstreamDysfunction + " " + candidate.restorationNeed + " " + candidate.priority).lowercase()
    )

    private fun rank(
        id: String,
        sourceId: String,
        layer: String,
        dysfunction: String,
        repairFunction: String,
        candidateClasses: List<String>,
        requiredEvidence: List<String>,
        sourceText: String
    ): GTIMRepairFunctionRankV2113 {
        val impact = impactScore(sourceText)
        val feasibility = feasibilityScore(sourceText, candidateClasses)
        val riskPenalty = riskPenalty(sourceText, candidateClasses)
        val evidence = if (requiredEvidence.isNotEmpty()) 14 else 6
        val score = (impact + feasibility + evidence - riskPenalty).coerceIn(10, 95)
        val band = when {
            score >= 76 -> "P0_HIGH_VALUE_TEST_FIRST"
            score >= 61 -> "P1_STRONG_RESEARCH_ROUTE"
            score >= 46 -> "P2_KEEP_AS_SECONDARY_ROUTE"
            else -> "P3_LOW_CONFIDENCE_OPEN_QUESTION"
        }
        val impactLogic = "impact=$impact because route targets ${dominantImpactAxis(sourceText)} rather than a single symptom"
        val feasibilityLogic = "feasibility=$feasibility based on candidate class and availability of non-clinical validation proxies"
        val riskLogic = "risk_penalty=$riskPenalty; engineered/live routes require containment and cannot be operational advice"
        val line = "Repair-function rank: version=$VERSION | id=$id | source=$layer:$sourceId | band=$band | score=$score | dysfunction=${dysfunction.oneLine()} | repair_function=${repairFunction.oneLine()} | classes=${candidateClasses.take(5).joinToString(";").oneLine()} | impact=${impactLogic.oneLine()} | feasibility=${feasibilityLogic.oneLine()} | risk=${riskLogic.oneLine()} | evidence_need=${requiredEvidence.take(6).joinToString(";").oneLine()} | claim_limit=research_priority_not_treatment"
        return GTIMRepairFunctionRankV2113(
            rankId = id,
            sourceRouteId = sourceId,
            sourceLayer = layer,
            dysfunctionClass = dysfunction,
            repairFunction = repairFunction,
            candidateRouteClasses = candidateClasses.take(6),
            score = score,
            priorityBand = band,
            impactLogic = impactLogic,
            feasibilityLogic = feasibilityLogic,
            riskLogic = riskLogic,
            evidenceNeed = requiredEvidence.distinct().take(8),
            claimLimit = "research_priority_not_treatment_or_clinical_claim",
            line = line
        )
    }

    private fun buildBiomarkerPlan(rank: GTIMRepairFunctionRankV2113): GTIMRepairBiomarkerPlanV2113 {
        val text = (rank.dysfunctionClass + " " + rank.repairFunction + " " + rank.candidateRouteClasses.joinToString(" ")).lowercase()
        val biomarkers = biomarkerGroups(text)
        val recovery = recoveryMarkers(text)
        val falsify = listOf(
            "no directionally coherent biomarker shift despite adequate model exposure",
            "repair function does not map to the dominant dysfunction after discriminator review",
            "alternative mechanism explains recovery without the proposed route",
            "candidate route increases inflammatory or dysbiosis risk in safety review"
        ) + rank.evidenceNeed.take(2).map { "missing bridge remains unresolved: $it" }
        val minimal = listOf(
            "topic-compatible cohort or model context",
            "baseline and follow-up marker panel",
            "negative/control comparator",
            "exposure or intervention timing context",
            "confounder review for diet, drugs, geography, and prior infection"
        )
        val upgrade = "upgrade only if recovery markers, dysfunction discriminator, and safety boundary align; otherwise keep as hypothesis or kill route"
        val line = "Repair validation plan: version=$VERSION | id=BP_${rank.rankId} | rank=${rank.rankId} | biomarkers=${biomarkers.joinToString(";").oneLine()} | recovery=${recovery.joinToString(";").oneLine()} | falsify=${falsify.take(6).joinToString(";").oneLine()} | minimal_data=${minimal.joinToString(";").oneLine()} | upgrade_rule=${upgrade.oneLine()}"
        return GTIMRepairBiomarkerPlanV2113(
            planId = "BP_${rank.rankId}".safeId(),
            sourceRankId = rank.rankId,
            biomarkerGroups = biomarkers,
            recoveryMarkers = recovery,
            falsificationSignals = falsify.distinct().take(8),
            minimalDataPack = minimal,
            upgradeRule = upgrade,
            line = line
        )
    }

    private fun impactScore(text: String): Int = when {
        containsAny(text, listOf("barrier", "mucosal", "tolerance", "microbial", "microbiome", "metabolite")) -> 38
        containsAny(text, listOf("immune", "inflammation", "cytokine", "variant", "readiness")) -> 34
        containsAny(text, listOf("toxin", "exposome", "plastic", "pfas", "pollution")) -> 32
        containsAny(text, listOf("neuro", "microglia", "brain")) -> 30
        containsAny(text, listOf("metabolic", "mitochond", "energy")) -> 29
        else -> 24
    }

    private fun feasibilityScore(text: String, classes: List<String>): Int {
        val joined = (text + " " + classes.joinToString(" ")).lowercase()
        return when {
            containsAny(joined, listOf("postbiotic", "metabolite", "marker", "biomarker", "barrier")) -> 30
            containsAny(joined, listOf("microbiome", "metagen", "scfa", "cohort")) -> 27
            containsAny(joined, listOf("phage", "defined consortium")) -> 23
            containsAny(joined, listOf("engineered", "synthetic", "live")) -> 18
            else -> 22
        }
    }

    private fun riskPenalty(text: String, classes: List<String>): Int {
        val joined = (text + " " + classes.joinToString(" ")).lowercase()
        return when {
            containsAny(joined, listOf("engineered", "synthetic", "live bacterial", "colonization")) -> 18
            containsAny(joined, listOf("phage", "consortium")) -> 12
            containsAny(joined, listOf("toxin", "exposome", "pfas", "plastic")) -> 9
            else -> 5
        }
    }

    private fun dominantImpactAxis(text: String): String = when {
        containsAny(text, listOf("barrier", "mucosal")) -> "barrier/mucosal interface"
        containsAny(text, listOf("microbiome", "microbial", "metabolite", "scfa")) -> "microbial-metabolite ecology"
        containsAny(text, listOf("immune", "cytokine", "inflammation", "tolerance")) -> "immune decision threshold"
        containsAny(text, listOf("toxin", "exposome", "plastic", "pfas")) -> "external pressure and toxin handling"
        containsAny(text, listOf("neuro", "brain", "microglia")) -> "neuroimmune stress"
        containsAny(text, listOf("metabolic", "mitochond")) -> "immunometabolic resilience"
        else -> "open dysfunction map"
    }

    private fun biomarkerGroups(text: String): List<String> {
        val out = mutableListOf<String>()
        if (containsAny(text, listOf("barrier", "mucosal", "gut"))) out += listOf("barrier integrity markers", "mucosal inflammation markers", "epithelial injury markers")
        if (containsAny(text, listOf("microbiome", "microbial", "metabolite", "scfa"))) out += listOf("metagenomic composition/function", "SCFA or bile-acid metabolite profile", "pathobiont/protective-function ratio")
        if (containsAny(text, listOf("immune", "inflammation", "cytokine", "tolerance"))) out += listOf("cytokine/inflammatory panel", "immune-cell phenotype", "tolerance or regulatory immune markers")
        if (containsAny(text, listOf("metabolic", "mitochond", "energy"))) out += listOf("glucose-insulin/lipid context", "lactate or oxidative-stress proxy", "mitochondrial stress proxy")
        if (containsAny(text, listOf("toxin", "exposome", "plastic", "pfas", "pollution"))) out += listOf("exposure burden measurement", "oxidative-stress markers", "exposure-to-barrier bridge markers")
        if (containsAny(text, listOf("neuro", "brain", "microglia"))) out += listOf("neuroinflammatory proxy markers", "neuroimmune symptom/function endpoints")
        return out.distinct().ifEmpty { listOf("mechanism-specific biomarker panel", "topic-compatible comparator marker") }.take(7)
    }

    private fun recoveryMarkers(text: String): List<String> {
        val out = mutableListOf(
            "dysfunction-specific marker moves in predicted direction",
            "symptom proxy improves only with matching mechanism evidence"
        )
        if (containsAny(text, listOf("barrier", "mucosal"))) out += "barrier integrity improves without inflammatory worsening"
        if (containsAny(text, listOf("microbiome", "microbial"))) out += "microbial function/diversity shift matches the proposed missing function"
        if (containsAny(text, listOf("immune", "inflammation"))) out += "inflammatory tone decreases without immune suppression overclaim"
        if (containsAny(text, listOf("toxin", "exposome"))) out += "measured exposure burden or bioavailability route decreases"
        return out.distinct().take(6)
    }

    private fun containsAny(text: String, tokens: List<String>): Boolean = tokens.any { text.contains(it.lowercase()) }
    private fun String.safeId(): String = replace(Regex("[^A-Za-z0-9_]+"), "_").take(120)
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
