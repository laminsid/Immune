package com.immunesignal.app

// v2.10.4 — Lightweight integrity contract for the immunotherapy knowledge asset.
// It validates that the ontology remains broad, research-only, escape-aware, and no_http_execution.
data class GTIMKnowledgeAssetContractReportV2103(
    val active: Boolean,
    val version: String,
    val state: String,
    val mechanismCount: Int,
    val hasOpenExplorationFallback: Boolean,
    val hasEvidenceRankLegend: Boolean,
    val hasEscapeRiskFields: Boolean,
    val hasClaimLimits: Boolean,
    val line: String
)

object GTIMKnowledgeBaseAssetContractV2103 {
    const val VERSION: String = "2.10.4-knowledge-base-asset-contract"

    fun validate(entries: List<GTIMImmunotherapyMechanismEntryV2102> = GTIMImmunotherapyKnowledgeBaseV2102.entries()): GTIMKnowledgeAssetContractReportV2103 {
        val hasOpen = entries.any { it.id == "open_mechanism_exploration" }
        val hasRanks = entries.all { it.evidenceRank.isNotBlank() } && entries.any { it.evidenceRank.contains("A", true) } && entries.any { it.evidenceRank.contains("D", true) || it.evidenceRank.contains("E", true) }
        val hasEscape = entries.all { it.targetConservation.isNotBlank() && it.escapeRisk.isNotBlank() }
        val hasLimits = entries.all { entry ->
            val joined = entry.claimLimits.joinToString(" ").lowercase()
            joined.contains("research") && joined.contains("not_treatment_advice") && joined.contains("not_authority_validated")
        }
        val state = if (hasOpen && hasRanks && hasEscape && hasLimits) {
            "KNOWLEDGE_ASSET_CONTRACT_PASS_RESEARCH_ONLY_BROAD_ONTOLOGY"
        } else {
            "KNOWLEDGE_ASSET_CONTRACT_REVIEW_REQUIRED"
        }
        val line = "Knowledge asset contract: version=$VERSION | state=$state | mechanisms=${entries.size} | open_fallback=$hasOpen | evidence_rank_legend=$hasRanks | escape_fields=$hasEscape | claim_limits=$hasLimits | not_disease_whitelist=true | no_clinical_rank_upgrade_without_external_source=true"
        return GTIMKnowledgeAssetContractReportV2103(
            active = true,
            version = VERSION,
            state = state,
            mechanismCount = entries.size,
            hasOpenExplorationFallback = hasOpen,
            hasEvidenceRankLegend = hasRanks,
            hasEscapeRiskFields = hasEscape,
            hasClaimLimits = hasLimits,
            line = line
        )
    }
}
