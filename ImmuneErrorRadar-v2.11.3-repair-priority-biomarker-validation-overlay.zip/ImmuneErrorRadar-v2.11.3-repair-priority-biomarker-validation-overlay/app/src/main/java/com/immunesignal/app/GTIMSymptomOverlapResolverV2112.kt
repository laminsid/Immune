package com.immunesignal.app

// v2.11.2 — Symptom Overlap Resolver.
// Prevents direct symptom -> disease -> treatment jumps. It builds overlapping
// dysfunction hypotheses, discriminators, shared mechanisms, and repair functions.
object GTIMSymptomOverlapResolverV2112 {
    const val VERSION: String = "2.11.2-symptom-overlap-resolver"
    const val PRINCIPLE: String = "symptoms_are_overlap_signals_not_disease_identity"
    const val BOUNDARY: String = "symptom_overlap_resolution_is_research_triage_not_diagnosis_not_treatment_not_clinical_advice"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        corpus: String,
        restoration: GTIMEcologicalRestorationReportV2112?,
        microbialReversal: GTIMMicrobialReversalReportV2111?
    ): GTIMSymptomOverlapReportV2112 {
        val symptoms = extractSymptoms(contract, corpus)
        val families = diseaseFamilies(contract, corpus, symptoms)
        val signal = GTIMSymptomOverlapSignalV2112(
            signalId = "SYMPTOM_OVERLAP_${contract.primaryAnchor.routeId.take(40).ifBlank { "OPEN" }}".replace(Regex("[^A-Za-z0-9_]+"), "_"),
            symptomCluster = symptoms.ifEmpty { listOf("non_specific_topic_signal") },
            overlappingDiseaseFamilies = families,
            ambiguityState = if (symptoms.size >= 2 || families.size >= 2) "OVERLAP_PRESENT_REQUIRE_DYSFUNCTION_MAPPING" else "OPEN_TOPIC_REQUIRE_DISCRIMINATORS",
            line = "Symptom overlap signal: version=$VERSION | symptoms=${symptoms.ifEmpty { listOf("non_specific_topic_signal") }.joinToString(";").oneLine()} | families=${families.joinToString(";").oneLine()} | ambiguity=${if (symptoms.size >= 2 || families.size >= 2) "OVERLAP_PRESENT_REQUIRE_DYSFUNCTION_MAPPING" else "OPEN_TOPIC_REQUIRE_DISCRIMINATORS"} | principle=$PRINCIPLE"
        )
        val hypotheses = GTIMDysfunctionHypothesisGraphV2112.build(signal.symptomCluster, corpus, restoration)
        val evidencePlans = GTIMDiscriminatingEvidencePlannerV2112.plan(hypotheses)
        val shared = GTIMSharedRootMechanismMapperV2112.map(hypotheses, families)
        val routes = GTIMRestorativeFunctionSearchV2112.build(hypotheses, microbialReversal)
        val state = when {
            hypotheses.any { it.dysfunctionClass == "open_dysfunction_map" } && hypotheses.size == 1 -> "SYMPTOM_OVERLAP_OPEN_MAP_REQUIRES_DISCRIMINATORS"
            hypotheses.size >= 3 -> "SYMPTOM_OVERLAP_MULTI_DYSFUNCTION_MAP_READY"
            else -> "SYMPTOM_OVERLAP_DYSFUNCTION_MAP_READY"
        }
        val integration = "CONNECTED_TO_ECOLOGICAL_RESTORATION_MRE_DOSSIER|symptoms=${signal.symptomCluster.size}|hypotheses=${hypotheses.size}|evidence_plans=${evidencePlans.size}|repair_routes=${routes.size}"
        val line = "Symptom Overlap Interpretation: version=$VERSION | state=$state | principle=$PRINCIPLE | symptoms=${signal.symptomCluster.joinToString(";").oneLine()} | hypotheses=${hypotheses.map { it.dysfunctionClass }.distinct().joinToString(";").oneLine()} | discriminators=${evidencePlans.size} | repair_routes=${routes.size} | integration=$integration | boundary=$BOUNDARY"
        return GTIMSymptomOverlapReportV2112(
            active = true,
            version = VERSION,
            state = state,
            principle = PRINCIPLE,
            symptomSignals = listOf(signal),
            dysfunctionHypotheses = hypotheses,
            evidencePlans = evidencePlans,
            sharedRootMechanisms = shared,
            restorativeRoutes = routes,
            integrationState = integration,
            boundaryLine = BOUNDARY,
            line = line
        )
    }

    private fun extractSymptoms(contract: GTIMRunDecisionContractV2740, corpus: String): List<String> {
        val text = listOf(contract.rawQuery, contract.normalizedQuery, contract.primaryAnchor.routeId, contract.diseaseFamily.name, corpus).joinToString(" ").lowercase()
        val symptomMap = listOf(
            "fatigue" to listOf("fatigue", "tired", "weakness", "exhaust", "low energy"),
            "fever" to listOf("fever", "حمى"),
            "inflammation" to listOf("inflammation", "inflamed", "التهاب"),
            "joint pain" to listOf("joint", "arthritis", "مفاصل"),
            "gut disturbance" to listOf("gut", "diarrhea", "constipation", "bloating", "ibd", "colitis", "أمعاء"),
            "brain fog" to listOf("brain fog", "fog", "cognitive", "ضباب"),
            "rash or skin barrier" to listOf("rash", "skin", "eczema", "itch", "جلد"),
            "respiratory/mucosal" to listOf("cough", "asthma", "lung", "rhinitis", "mucosal", "تنفس"),
            "neurologic damage" to listOf("paralysis", "nerve", "demyelin", "blind", "retina", "neuro", "شلل", "عمى"),
            "weight loss/systemic" to listOf("weight loss", "wasting", "cachexia"),
            "pain" to listOf("pain", "ache", "ألم")
        )
        return symptomMap.filter { (_, tokens) -> tokens.any { text.contains(it.lowercase()) } }.map { it.first }.distinct().take(8)
    }

    private fun diseaseFamilies(contract: GTIMRunDecisionContractV2740, corpus: String, symptoms: List<String>): List<String> {
        val text = listOf(contract.rawQuery, contract.normalizedQuery, contract.primaryAnchor.routeId, contract.diseaseFamily.name, corpus, symptoms.joinToString(" ")).joinToString(" ").lowercase()
        val families = mutableListOf<String>()
        if (hasAny(text, listOf("infection", "virus", "bacteria", "hanta", "ebola", "hiv", "covid", "pathogen", "fever"))) families += "infectious_or_post_infectious"
        if (hasAny(text, listOf("autoimmune", "arthritis", "treg", "th17", "tolerance", "joint", "rash"))) families += "autoimmune_or_tolerance_loss"
        if (hasAny(text, listOf("allergy", "asthma", "ige", "mast", "skin", "rhinitis"))) families += "allergic_or_barrier_reactive"
        if (hasAny(text, listOf("metabolic", "insulin", "glucose", "fatigue", "mitochond", "energy"))) families += "metabolic_or_energy_stress"
        if (hasAny(text, listOf("microbiome", "dysbiosis", "gut", "butyrate", "scfa"))) families += "microbiome_ecology"
        if (hasAny(text, listOf("pollution", "pfas", "microplastic", "water", "toxin", "exposome"))) families += "environmental_exposome"
        if (hasAny(text, listOf("neuro", "brain", "paralysis", "blind", "retina", "microglia", "demyelin"))) families += "neuroimmune_or_tissue_damage"
        if (hasAny(text, listOf("cancer", "tumor", "oncology", "cachexia"))) families += "cancer_or_tissue_remodeling"
        return families.distinct().ifEmpty { listOf("open_multifamily_overlap") }.take(8)
    }

    private fun hasAny(text: String, tokens: List<String>): Boolean = tokens.any { text.contains(it.lowercase()) }
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
