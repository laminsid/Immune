package com.immunesignal.app

// v2.11.2 — Converts dysfunction hypotheses into repair-function research routes.
object GTIMRestorativeFunctionSearchV2112 {
    const val VERSION: String = "2.11.2-restorative-function-search"
    const val SAFETY_BOUNDARY: String = "repair_function_routes_are_research_only_not_medical_actions_not_dosing_not_live_organism_use"

    fun build(
        hypotheses: List<GTIMDysfunctionHypothesisV2112>,
        microbialReversal: GTIMMicrobialReversalReportV2111?
    ): List<GTIMRestorativeFunctionRouteV2112> {
        val microbialClasses = microbialReversal?.candidateRoutes?.map { it.candidateClass }?.distinct().orEmpty()
        return hypotheses.take(6).mapIndexed { index, h ->
            val routeClasses = (candidateClassesFor(h.dysfunctionClass) + microbialClasses.take(2)).distinct().take(6)
            val required = (h.discriminatingEvidence + "recovery biomarker" + "falsification comparator" + "safety boundary review").distinct().take(7)
            val function = h.repairFunctions.joinToString(" + ").ifBlank { "identify missing stabilizing function" }
            val id = "REPAIR_FUNCTION_${index + 1}_${h.dysfunctionClass}".take(96)
            val line = "Restorative function route: version=$VERSION | id=$id | dysfunction=${h.dysfunctionClass} | function=${function.oneLine()} | candidate_classes=${routeClasses.joinToString(";").oneLine()} | required=${required.joinToString(";").oneLine()} | boundary=$SAFETY_BOUNDARY"
            GTIMRestorativeFunctionRouteV2112(id, h.dysfunctionClass, function, routeClasses, required, SAFETY_BOUNDARY, line)
        }
    }

    private fun candidateClassesFor(dysfunction: String): List<String> = when (dysfunction) {
        "immune_overactivation" -> listOf("immune_recalibration_route", "postbiotic_or_metabolite_route", "microbial_tolerance_training_route")
        "barrier_failure" -> listOf("barrier_support_route", "mucus_tight_junction_context_route", "microbiome_metabolite_route")
        "microbial_ecosystem_imbalance" -> listOf("defined_consortium_research_route", "competitive_displacement_route", "metabolite_function_route")
        "metabolic_energy_stress" -> listOf("immunometabolic_route", "host_microbial_conversion_route", "mitochondrial_context_route")
        "exposome_pressure" -> listOf("exposure_pressure_mapping_route", "microbial_sink_or_biotransformation_route", "barrier_resilience_route")
        "neuroimmune_tissue_stress" -> listOf("neuroimmune_bridge_route", "peripheral_inflammation_bridge_route", "long_horizon_tissue_repair_route")
        else -> listOf("open_repair_function_discovery_route")
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
