package com.immunesignal.app

// v2.11.2 — Symptom overlap models.
// Symptoms are non-specific overlap signals. The system must infer dysfunctions,
// discriminators, shared roots, and repair functions before naming a disease.

data class GTIMSymptomOverlapSignalV2112(
    val signalId: String,
    val symptomCluster: List<String>,
    val overlappingDiseaseFamilies: List<String>,
    val ambiguityState: String,
    val line: String
)

data class GTIMDysfunctionHypothesisV2112(
    val hypothesisId: String,
    val sourceSymptoms: List<String>,
    val dysfunctionClass: String,
    val mechanismLogic: String,
    val discriminatingEvidence: List<String>,
    val repairFunctions: List<String>,
    val routePriority: String,
    val claimLimit: String,
    val line: String
)

data class GTIMDiscriminatingEvidencePlanV2112(
    val planId: String,
    val dysfunctionClass: String,
    val evidenceNeeded: List<String>,
    val separatesFrom: List<String>,
    val missingProof: String,
    val line: String
)

data class GTIMSharedRootMechanismV2112(
    val mechanismId: String,
    val diseaseFamilies: List<String>,
    val sharedMechanism: String,
    val repairFunctionTarget: String,
    val falsificationNeed: String,
    val line: String
)

data class GTIMRestorativeFunctionRouteV2112(
    val routeId: String,
    val dysfunctionClass: String,
    val restorativeFunction: String,
    val candidateRouteClasses: List<String>,
    val requiredEvidence: List<String>,
    val safetyBoundary: String,
    val line: String
)

data class GTIMSymptomOverlapReportV2112(
    val active: Boolean,
    val version: String,
    val state: String,
    val principle: String,
    val symptomSignals: List<GTIMSymptomOverlapSignalV2112>,
    val dysfunctionHypotheses: List<GTIMDysfunctionHypothesisV2112>,
    val evidencePlans: List<GTIMDiscriminatingEvidencePlanV2112>,
    val sharedRootMechanisms: List<GTIMSharedRootMechanismV2112>,
    val restorativeRoutes: List<GTIMRestorativeFunctionRouteV2112>,
    val integrationState: String,
    val boundaryLine: String,
    val line: String
) {
    companion object {
        fun empty(): GTIMSymptomOverlapReportV2112 = GTIMSymptomOverlapReportV2112(
            active = false,
            version = GTIMSymptomOverlapResolverV2112.VERSION,
            state = "SYMPTOM_OVERLAP_NOT_EVALUATED",
            principle = GTIMSymptomOverlapResolverV2112.PRINCIPLE,
            symptomSignals = emptyList(),
            dysfunctionHypotheses = emptyList(),
            evidencePlans = emptyList(),
            sharedRootMechanisms = emptyList(),
            restorativeRoutes = emptyList(),
            integrationState = "NOT_EVALUATED",
            boundaryLine = GTIMSymptomOverlapResolverV2112.BOUNDARY,
            line = "Symptom overlap resolver: not evaluated."
        )
    }
}
