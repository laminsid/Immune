package com.immunesignal.app

// v2.11.2 — Classifies system-level collapse patterns before proposing repairs.
object GTIMEcologicalCollapseClassifierV2112 {
    const val VERSION: String = "2.11.2-ecological-collapse-classifier"
    const val CLAIM_LIMIT: String = "collapse_pattern_is_a_research_interpretation_not_causal_or_clinical_proof"

    fun classify(
        contract: GTIMRunDecisionContractV2740,
        corpus: String,
        rootCandidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
        microbialReversal: GTIMMicrobialReversalReportV2111?
    ): List<GTIMEcologicalCollapseSignalV2112> {
        val rootText = rootCandidates.joinToString(" ") { it.upstreamDysfunction + " " + it.causalChain + " " + it.restorationNeed }
        val reversalText = microbialReversal?.let { r ->
            listOf(
                r.damageMechanisms.joinToString(" ") { it.damageClass + " " + it.harmfulMechanism },
                r.counterFunctions.joinToString(" ") { it.counterFunctionClass + " " + it.reversalLogic }
            ).joinToString(" ")
        }.orEmpty()
        val text = listOf(contract.rawQuery, contract.normalizedQuery, contract.primaryAnchor.routeId, contract.diseaseFamily.name, corpus, rootText, reversalText).joinToString(" ").lowercase()
        val signals = mutableListOf<GTIMEcologicalCollapseSignalV2112>()

        if (hasAny(text, listOf("pond", "swamp", "black water", "stagnant", "sludge", "winter", "anaerobic", "organic", "decompos", "rot", "odor"))) {
            signals += signal(
                id = "pond_to_host_ecological_collapse_analogy",
                type = GTIMEcologicalCollapseTypeV2112.ORGANIC_OVERLOAD,
                trigger = "pond-like visible ecosystem collapse analogy",
                interpretation = "visible deterioration may reflect overload, oxygen/context loss, microbial imbalance, and missing cleanup functions rather than one isolated enemy",
                discriminators = listOf("organic burden proxy", "oxygen/redox or stagnation context", "microbial community shift", "return-of-life recovery marker")
            )
        }
        if (hasAny(text, listOf("microbiome", "dysbiosis", "bacteria", "microbial", "butyrate", "scfa", "diversity", "commensal"))) {
            signals += signal(
                id = "microbial_ecosystem_low_diversity_or_function_loss",
                type = GTIMEcologicalCollapseTypeV2112.LOW_DIVERSITY,
                trigger = "microbial diversity or functional-loss language",
                interpretation = "loss of stabilizing microbial functions may permit inflammation, pathogen niche occupation, or weak barrier recovery",
                discriminators = listOf("metagenomic or functional microbiome profile", "metabolite output such as SCFA context", "negative-control population/context", "time-direction evidence")
            )
        }
        if (hasAny(text, listOf("pathogen", "biofilm", "c difficile", "infection", "h pylori", "staphyl", "salmonella", "niche", "colonization"))) {
            signals += signal(
                id = "pathogen_niche_or_biofilm_lock",
                type = GTIMEcologicalCollapseTypeV2112.PATHOGEN_DOMINANCE,
                trigger = "pathogen dominance, niche lock, or biofilm signal",
                interpretation = "a harmful organism or community may be stabilizing the damaged state by occupying the niche, producing toxins, or resisting clearance",
                discriminators = listOf("target organism identity", "biofilm/toxin marker", "polymicrobial context", "resistance/escape review")
            )
        }
        if (hasAny(text, listOf("toxin", "pfas", "plastic", "microplastic", "nanoplastic", "pollution", "heavy metal", "bpa", "phthalate", "chlorine", "water", "exposome"))) {
            signals += signal(
                id = "toxin_exposome_pressure_collapse",
                type = GTIMEcologicalCollapseTypeV2112.TOXIN_ACCUMULATION,
                trigger = "toxin, particle, water, pollution, or exposome pressure",
                interpretation = "external pressure may keep the system in a damaged state by stressing barrier, metabolism, microbial ecology, or immune tone",
                discriminators = listOf("exposure measurement", "source/context validation", "burden or byproduct marker", "alternative-exposure control")
            )
        }
        if (hasAny(text, listOf("barrier", "mucosal", "permeability", "gut", "skin", "lung", "epithelial", "mucus", "tight junction", "leaky"))) {
            signals += signal(
                id = "barrier_failure_entry_surface_collapse",
                type = GTIMEcologicalCollapseTypeV2112.BARRIER_FAILURE,
                trigger = "barrier, mucosal, or entry-surface failure signal",
                interpretation = "entry surfaces may fail as ecological boundaries, allowing antigens, microbes, toxins, or inflammatory loops to persist",
                discriminators = listOf("barrier integrity marker", "mucosal immune readout", "local microbiome/metabolite profile", "tissue-specific comparator")
            )
        }
        if (hasAny(text, listOf("inflammation", "cytokine", "autoimmune", "allergy", "asthma", "mast", "ige", "th17", "treg", "tolerance", "fever"))) {
            signals += signal(
                id = "immune_overactivation_or_misclassification",
                type = GTIMEcologicalCollapseTypeV2112.IMMUNE_OVERACTIVATION,
                trigger = "inflammatory, allergic, autoimmune, fever, or tolerance-loss signal",
                interpretation = "immune decision thresholds may be misclassifying signals, maintaining a damaging response after the original trigger changes or disappears",
                discriminators = listOf("cytokine pattern", "autoimmunity/tolerance marker", "infection-history control", "subgroup/context stratification")
            )
        }
        if (hasAny(text, listOf("fatigue", "metabolic", "insulin", "glucose", "mitochond", "lactate", "lipid", "energy", "bile", "metabolite"))) {
            signals += signal(
                id = "metabolic_stagnation_or_conversion_gap",
                type = GTIMEcologicalCollapseTypeV2112.METABOLIC_STAGNATION,
                trigger = "fatigue, energy, metabolite, or metabolic-conversion signal",
                interpretation = "host-microbial metabolic conversion may be insufficient, producing low repair capacity or persistent immune-energy stress",
                discriminators = listOf("metabolite panel", "mitochondrial/energy proxy", "diet/context modifier", "longitudinal recovery marker")
            )
        }
        if (hasAny(text, listOf("brain fog", "neuro", "brain", "microglia", "paralysis", "blind", "retina", "nerve", "demyelin", "alzheimer", "tau", "amyloid"))) {
            signals += signal(
                id = "neuroimmune_system_stress_loop",
                type = GTIMEcologicalCollapseTypeV2112.NEUROIMMUNE_STRESS,
                trigger = "brain, nerve, retina, paralysis, blindness, or neuroimmune tissue-stress signal",
                interpretation = "tissue-level outcomes may be downstream of immune, barrier, vascular, microbial-metabolite, or toxin loops rather than a single surface symptom",
                discriminators = listOf("neuroinflammatory marker", "barrier/peripheral inflammation bridge", "tissue-specific imaging/biomarker context", "clear alternative-cause review")
            )
        }

        if (signals.isEmpty()) {
            signals += signal(
                id = "open_ecological_restoration_scan",
                type = GTIMEcologicalCollapseTypeV2112.UNKNOWN,
                trigger = "non-specific topic with no dominant collapse pattern",
                interpretation = "keep a restoration lens open: identify what system condition failed before proposing any repair function",
                discriminators = listOf("symptom cluster", "context timeline", "basic mechanism marker", "negative comparator")
            )
        }
        return signals.distinctBy { it.signalId }.take(8)
    }

    private fun signal(
        id: String,
        type: GTIMEcologicalCollapseTypeV2112,
        trigger: String,
        interpretation: String,
        discriminators: List<String>
    ): GTIMEcologicalCollapseSignalV2112 {
        val line = "Ecological collapse signal: version=$VERSION | id=$id | type=${type.name} | trigger=${trigger.oneLine()} | interpretation=${interpretation.oneLine()} | discriminators=${discriminators.joinToString(";").oneLine()} | claim_limit=$CLAIM_LIMIT"
        return GTIMEcologicalCollapseSignalV2112(id, type, trigger, interpretation, discriminators, CLAIM_LIMIT, line)
    }

    private fun hasAny(text: String, tokens: List<String>): Boolean = tokens.any { text.contains(it.lowercase()) }
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
