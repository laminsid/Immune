package com.immunesignal.app

/**
 * v2.8.9 — report surface compression + ETL priority view.
 *
 * Display-only helper. It keeps the public brief decision-first while preserving
 * legacy audit/test tokens elsewhere in the rendered brief. It does not change
 * routing, ETL/DGE gates, treatment safety, or Claim Guard behavior.
 */
object GTIMReportSurfacePriorityViewV2809 {
    const val VERSION: String = "2.8.9-report-surface-compression-etl-priority-view+2.9.0-compact-ui"

    fun buildLines(actual: GTIMActualEtlExecutionReportV2800, maxLine: Int = 360): List<String> {
        if (!actual.active) return emptyList()
        val finalRun = GTIMActualEtlFinalRunContractV2803.build(actual)
        val next = nextAction(actual, finalRun)
        val metadataBridgeLines = actual.metadataFirstBridge?.let { bridge ->
            listOf(
                bridge.line,
                bridge.softProbe.line,
                bridge.gseToSrpMapping.line,
                bridge.externalAvailability.line,
                bridge.publicExpressionSources?.line.orEmpty(),
                bridge.externalEvidenceCapsule?.line.orEmpty(),
                bridge.publicExpressionRequestPlan?.line.orEmpty(),
                bridge.learningCache?.line.orEmpty(),
                bridge.learningCacheExport?.line.orEmpty(),
                bridge.deviceFilePolicy.line
            ).filter { it.isNotBlank() }
        }.orEmpty()
        val medicalDossierLines = actual.medicalResearchDossier?.conciseLines.orEmpty()
        return (listOf(
            "Priority view: version=$VERSION | final_etl=${finalRun.state} | dge=${actual.dgeReadinessVerdict.verdict} | target=${actual.targetId}",
            "Final ETL verdict: ${finalRun.state} | first_blocking_gate=${finalRun.firstBlockingGate} | dge_queue=${finalRun.dgeQueueState}",
            "DGE verdict: ${actual.dgeReadinessVerdict.verdict} | run_state=${actual.dge.state} | gene_pathway=${actual.genePathway.state}",
            GTIMDgeNotReadyReasonMapperV2940.line(actual, finalRun),
            "Next action: $next"
        ) + medicalDossierLines + metadataBridgeLines + listOf(
            "ETL gates: target=${gateTarget(actual)} | files=${gateObservedFiles(actual)} | matrix=${gateMatrix(actual)} | metadata=${gateMetadata(actual)} | comparator=${gateComparator(actual)} | sample_linkage=${gateSampleLinkage(actual)} | DGE=${gateDge(actual)}"
        )).map { clip(it, maxLine) }
    }

    private fun nextAction(actual: GTIMActualEtlExecutionReportV2800, finalRun: GTIMActualEtlFinalRunReportV2803): String = when {
        finalRun.state == "FINAL_ETL_STOP_NO_TOPIC_COMPATIBLE_TARGET" || actual.targetId.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", ignoreCase = true) ->
            "feed topic-compatible accession or manual matrix URL/file seed before ETL/DGE"
        finalRun.state == "FINAL_ETL_STOP_OBSERVED_FILE_EVIDENCE_REQUIRED" ->
            "run metadata-first SOFT probe, GSE→SRP mapping, and HEAD/listing evidence before any large matrix download for ${actual.targetId}"
        finalRun.state == "FINAL_ETL_STOP_MATRIX_FILE_NOT_CLASSIFIED" ->
            "classify observed matrix file type and parser plan for ${actual.targetId}"
        finalRun.state == "FINAL_ETL_STOP_SAMPLE_METADATA_NOT_EXTRACTED" ->
            "extract sample metadata rows with source_field and evidence_snippet"
        finalRun.state == "FINAL_ETL_STOP_CASE_CONTROL_EVIDENCE_REQUIRED" ->
            "suggest case/control labels only with evidence snippets"
        finalRun.state == "FINAL_ETL_STOP_SAMPLE_ID_LINKAGE_NOT_CONFIRMED" ->
            "match metadata sample IDs to matrix columns/barcodes"
        finalRun.state == "FINAL_ETL_READY_REVIEW_ONLY_DGE_NOT_RUN" ->
            "queue review-only DGE; do not claim biological or treatment signal until reviewed output exists"
        else -> "continue ETL gate closure before any DGE or gene/pathway signal"
    }

    private fun gateTarget(actual: GTIMActualEtlExecutionReportV2800): String =
        if (actual.fileDiscovery.state == "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET" || actual.targetId.equals("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED", true)) "BLOCKED" else "PASS"

    private fun gateObservedFiles(actual: GTIMActualEtlExecutionReportV2800): String =
        if (actual.observedFileEvidence.state == "OBSERVED_FILE_EVIDENCE_COMPLETE_REVIEW_ONLY") "PASS" else "BLOCKED"

    private fun gateMatrix(actual: GTIMActualEtlExecutionReportV2800): String =
        if (actual.matrixFileClassifier.state == "MATRIX_FILE_CLASSIFIED_REVIEW_ONLY") "PASS" else "BLOCKED"

    private fun gateMetadata(actual: GTIMActualEtlExecutionReportV2800): String =
        if (actual.sampleMetadataExtraction.state == "SAMPLE_METADATA_EXTRACTED_REVIEW_ONLY") "PASS" else "BLOCKED"

    private fun gateComparator(actual: GTIMActualEtlExecutionReportV2800): String =
        if (actual.caseControlLabelSuggestions.state == "CASE_CONTROL_LABELS_SUGGESTED_WITH_EVIDENCE") "PASS" else "BLOCKED"

    private fun gateSampleLinkage(actual: GTIMActualEtlExecutionReportV2800): String =
        if (actual.sampleIdLinkageVerification.state == "SAMPLE_ID_LINKAGE_CONFIRMED_REVIEW_ONLY") "PASS" else "BLOCKED"

    private fun gateDge(actual: GTIMActualEtlExecutionReportV2800): String =
        if (actual.dgeReadinessVerdict.verdict == "DGE_READY_REVIEW_ONLY_NOT_RUN") "READY_REVIEW_ONLY_NOT_RUN" else "NOT_RUN"

    private fun clip(value: String, max: Int): String {
        val oneLine = value.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1).trimEnd() + "…"
    }
}
