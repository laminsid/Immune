package com.immunesignal.app

// legacy_v2100_audit_marker: 2.10.0-medical-research-dossier

/** v2.10.0 — Established science evidence layer.
 * Creates conservative baseline cards. It does not fetch literature and does not
 * claim that a route applies to the current user/patient. Its purpose is to split
 * known science classes from GTIM-generated exploratory findings.
 */
object GTIMEstablishedScienceEvidenceLayerV2100 {
    const val VERSION: String = "2.10.0-established-science-evidence-layer"

    fun build(contract: GTIMRunDecisionContractV2740): List<GTIMEstablishedEvidenceCardV2100> {
        val anchor = contract.primaryAnchor.routeId.lowercase()
        val base = mutableListOf(
            card(
                id = "ESTABLISHED_BASELINE_REVIEW_METHOD",
                area = "evidence methodology",
                statement = "Established-science section must be based on guidelines, systematic reviews, trials, curated public datasets, or documented repository metadata; narrative claims are not accepted as proof.",
                level = "METHOD_BASELINE",
                kind = "review_framework",
                limit = "This card defines the evidence standard; it is not a disease-specific conclusion."
            )
        )
        when {
            anchor.contains("cancer") -> base += cancerCards()
            anchor.contains("ibd") || anchor.contains("mucosal") || anchor.contains("microbiome") -> base += gutImmuneCards()
            anchor.contains("covid") || anchor.contains("viral") || anchor.contains("ebola") || anchor.contains("hantavirus") -> base += viralImmuneCards(anchor)
            anchor.contains("diabetes") || anchor.contains("metabolic") || anchor.contains("insulin") -> base += metabolicImmuneCards()
            anchor.contains("autoimmune") || anchor.contains("sle") || anchor.contains("ra") || anchor.contains("psoriasis") || anchor.contains("thyroid") -> base += autoimmuneCards()
            else -> base += genericImmuneCards()
        }
        return base.distinctBy { it.cardId }.take(8)
    }

    private fun cancerCards(): List<GTIMEstablishedEvidenceCardV2100> = listOf(
        card(
            id = "ESTABLISHED_ONCO_BIOMARKER_FIRST",
            area = "oncology immunogenetics",
            statement = "For cancer topics, biomarker status such as MSI-H/dMMR/TMB/MMR, antigen presentation and tumor microenvironment context must be separated from any therapy-route hypothesis.",
            level = "A_TO_B_CONTEXT_DEPENDENT",
            kind = "biomarker_driven_oncology_baseline",
            limit = "Does not imply eligibility or response; biomarker and clinical context must be verified externally."
        ),
        card(
            id = "ESTABLISHED_ONCO_COMBINATION_CAUTION",
            area = "combination strategy",
            statement = "DNA-damage, cell-cycle, apoptosis and immune-visibility mechanisms can be biologically relevant routes, but a proposed combination remains a hypothesis unless tested in appropriate models or clinical studies.",
            level = "C_MECHANISTIC_TO_D_EXPLORATORY",
            kind = "mechanism_class_baseline",
            limit = "No dosing, regimen, efficacy, or patient-selection claim is allowed."
        )
    )

    private fun gutImmuneCards(): List<GTIMEstablishedEvidenceCardV2100> = listOf(
        card(
            id = "ESTABLISHED_GUT_BARRIER_MICROBIOME",
            area = "gut barrier and microbiome",
            statement = "Diet, microbiome composition, epithelial barrier integrity, short-chain fatty acids and mucosal cytokines are plausible evidence domains for gut-immune topics.",
            level = "B_TO_C_CONTEXT_DEPENDENT",
            kind = "mucosal_immunology_baseline",
            limit = "A diet route is not a cure claim; disease, comparator and outcome evidence must be explicit."
        ),
        card(
            id = "ESTABLISHED_RESTRICTION_CAUTION",
            area = "nutrition safety",
            statement = "Long-term broad elimination diets require nutrition-risk review and should not be treated as universal therapy from mechanism alone.",
            level = "SAFETY_BASELINE",
            kind = "nutrition_claim_guard",
            limit = "The app can flag risks but cannot manage a diet clinically."
        )
    )

    private fun viralImmuneCards(anchor: String): List<GTIMEstablishedEvidenceCardV2100> = listOf(
        card(
            id = "ESTABLISHED_VIRAL_HOST_RESPONSE",
            area = "viral host response",
            statement = "Innate immune activation, interferon signaling, cytokine balance, tissue tropism and immune evasion are core evidence domains for viral topics.",
            level = "B_TO_C_CONTEXT_DEPENDENT",
            kind = "host_response_baseline",
            limit = "Does not prove causal pathway, prognosis, or countermeasure efficacy for this run."
        ),
        card(
            id = "ESTABLISHED_OUTBREAK_SAFETY_BOUNDARY",
            area = "infectious disease safety",
            statement = "Pathogen, strain, sample source, biosafety context and comparator metadata must be explicit before translational interpretation.",
            level = if (anchor.contains("ebola") || anchor.contains("hantavirus")) "HIGH_SAFETY_BOUNDARY" else "SAFETY_BOUNDARY",
            kind = "infectious_disease_claim_guard",
            limit = "No clinical, public-health, or countermeasure instruction is produced."
        )
    )

    private fun metabolicImmuneCards(): List<GTIMEstablishedEvidenceCardV2100> = listOf(
        card(
            id = "ESTABLISHED_METABOLIC_INFLAMMATION",
            area = "metabolic inflammation",
            statement = "Insulin resistance, adipose/liver inflammation, gut barrier signals and cytokine pathways are valid research domains for diabetes/metabolic topics.",
            level = "B_TO_C_CONTEXT_DEPENDENT",
            kind = "metabolic_immunology_baseline",
            limit = "No medication change or glycemic-management claim is allowed."
        )
    )

    private fun autoimmuneCards(): List<GTIMEstablishedEvidenceCardV2100> = listOf(
        card(
            id = "ESTABLISHED_AUTOIMMUNE_AXIS",
            area = "autoimmune immunology",
            statement = "Autoantibodies, antigen presentation, interferon/cytokine axes, tissue-specific immune infiltration and therapy-response/resistance metadata are core evidence domains for autoimmune topics.",
            level = "B_TO_C_CONTEXT_DEPENDENT",
            kind = "autoimmune_mechanism_baseline",
            limit = "Mechanism mapping is not diagnosis, flare prediction, or treatment choice."
        )
    )

    private fun genericImmuneCards(): List<GTIMEstablishedEvidenceCardV2100> = listOf(
        card(
            id = "ESTABLISHED_GENERIC_IMMUNE_MECHANISM",
            area = "general immunology",
            statement = "A valid immune/genetic dossier must identify topic anchor, comparator, sample context, mechanism axis and validation status before any translational route is surfaced.",
            level = "METHOD_BASELINE",
            kind = "general_research_baseline",
            limit = "Unknown topics remain discovery-only until evidence gates close."
        )
    )

    private fun card(id: String, area: String, statement: String, level: String, kind: String, limit: String): GTIMEstablishedEvidenceCardV2100 {
        val line = "Established science: id=$id | area=$area | level=$level | kind=$kind | statement=${statement.oneLine()} | limit=${limit.oneLine()}"
        return GTIMEstablishedEvidenceCardV2100(id, area, statement, level, kind, limit, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
