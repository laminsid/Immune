package com.immunesignal.app

// v2.11.2 — Builds dysfunction hypotheses from overlapping symptom clusters.
object GTIMDysfunctionHypothesisGraphV2112 {
    const val VERSION: String = "2.11.2-dysfunction-hypothesis-graph"
    const val CLAIM_LIMIT: String = "symptoms_generate_dysfunction_hypotheses_not_disease_identity_or_treatment"

    fun build(symptoms: List<String>, corpus: String, restoration: GTIMEcologicalRestorationReportV2112?): List<GTIMDysfunctionHypothesisV2112> {
        val text = (symptoms.joinToString(" ") + " " + corpus + " " + restoration?.line.orEmpty()).lowercase()
        val hypotheses = mutableListOf<GTIMDysfunctionHypothesisV2112>()
        if (hasAny(text, listOf("fever", "inflammation", "inflamed", "cytokine", "pain", "allergy", "autoimmune", "mast", "tolerance"))) {
            hypotheses += hypothesis(
                "immune_overactivation_or_misclassification",
                symptoms,
                "immune_overactivation",
                "shared symptoms may reflect excessive or misdirected immune decision loops rather than a single disease label",
                listOf("cytokine/inflammatory pattern", "infection-history separator", "autoimmunity/tolerance marker", "organ/tissue target context"),
                listOf("immune recalibration", "tolerance restoration", "inflammatory durability reduction"),
                "HIGH_IF_CHRONIC_INFLAMMATION_OR_TOLERANCE_SIGNAL_PRESENT"
            )
        }
        if (hasAny(text, listOf("gut", "diarrhea", "constipation", "bloating", "barrier", "mucosal", "skin", "rash", "lung", "cough", "leaky"))) {
            hypotheses += hypothesis(
                "barrier_mucosal_failure",
                symptoms,
                "barrier_failure",
                "shared symptoms across gut, skin, lung, and allergy-like states may reflect a failed boundary between exposure and immune response",
                listOf("barrier integrity marker", "mucosal/local immune readout", "microbiome/metabolite context", "food/exposure timeline"),
                listOf("barrier restoration", "mucus/tight-junction support", "entry-surface tolerance"),
                "HIGH_IF_MUCOSAL_OR_SKIN_GUT_PATTERN_PRESENT"
            )
        }
        if (hasAny(text, listOf("microbiome", "dysbiosis", "bacteria", "antibiotic", "butyrate", "scfa", "commensal", "pathogen"))) {
            hypotheses += hypothesis(
                "microbial_ecosystem_imbalance",
                symptoms,
                "microbial_ecosystem_imbalance",
                "shared symptoms may come from missing microbial functions, wrong metabolites, pathogen niche dominance, or low ecological resilience",
                listOf("metagenomic/functional profile", "SCFA or metabolite marker", "antibiotic/infection timeline", "pathogen/biofilm check"),
                listOf("microbial restoration", "metabolite restoration", "competitive niche repair"),
                "HIGH_IF_DYSBIOSIS_OR_MICROBIAL_FUNCTION_SIGNAL_PRESENT"
            )
        }
        if (hasAny(text, listOf("fatigue", "weakness", "energy", "metabolic", "insulin", "glucose", "mitochond", "brain fog", "lactate"))) {
            hypotheses += hypothesis(
                "immunometabolic_energy_stress",
                symptoms,
                "metabolic_energy_stress",
                "fatigue/brain fog/pain-like clusters can overlap through metabolic-energy constraints that alter immune tone and repair capacity",
                listOf("glucose/insulin/lipid context", "mitochondrial or lactate proxy", "metabolite panel", "sleep/stress/context modifier"),
                listOf("metabolic flexibility support", "host-microbial metabolite correction", "repair capacity restoration"),
                "MEDIUM_HIGH_IF_FATIGUE_OR_METABOLIC_SIGNAL_PRESENT"
            )
        }
        if (hasAny(text, listOf("pollution", "pfas", "plastic", "microplastic", "toxin", "water", "chlorine", "heavy metal", "exposome", "food"))) {
            hypotheses += hypothesis(
                "exposome_pressure_or_toxin_burden",
                symptoms,
                "exposome_pressure",
                "non-specific inflammatory or barrier symptoms may be maintained by environmental pressure that must be measured before causal ranking",
                listOf("exposure/source measurement", "burden or byproduct marker", "geography/work/water/food context", "alternative-exposure control"),
                listOf("pressure reduction", "toxin binding/biotransformation research route", "barrier/exposome resilience"),
                "MEDIUM_HIGH_IF_EXPOSURE_CONTEXT_PRESENT"
            )
        }
        if (hasAny(text, listOf("neuro", "brain fog", "headache", "paralysis", "blind", "retina", "nerve", "demyelin", "alzheimer", "microglia"))) {
            hypotheses += hypothesis(
                "neuroimmune_or_tissue_damage_loop",
                symptoms,
                "neuroimmune_tissue_stress",
                "neurologic or tissue-loss symptoms are high-risk overlap signals that require separation of structural injury, immune loops, vascular causes, toxins, and infection",
                listOf("tissue-specific marker", "neuroinflammation/peripheral bridge", "vascular/structural comparator", "infection/toxin separator"),
                listOf("neuroimmune loop reduction", "barrier/peripheral-driver control", "tissue-specific repair research route"),
                "LONG_HORIZON_REQUIRES_STRONG_DISCRIMINATORS"
            )
        }
        if (hypotheses.isEmpty()) {
            hypotheses += hypothesis(
                "open_shared_symptom_dysfunction_scan",
                symptoms,
                "open_dysfunction_map",
                "symptoms are too non-specific to name a disease; build a discriminator-first dysfunction map before repair search",
                listOf("symptom timing", "organ context", "exposure/infection timeline", "minimum biomarker panel"),
                listOf("open root-cause mapping", "discriminator-first search", "repair-function candidate scan"),
                "OPEN_SCAN_USEFUL_BUT_LOW_CONFIDENCE"
            )
        }
        return hypotheses.distinctBy { it.hypothesisId }.take(8)
    }

    private fun hypothesis(
        id: String,
        symptoms: List<String>,
        dysfunction: String,
        logic: String,
        discriminators: List<String>,
        repairs: List<String>,
        priority: String
    ): GTIMDysfunctionHypothesisV2112 {
        val source = symptoms.ifEmpty { listOf("non_specific_research_query") }.take(6)
        val line = "Dysfunction hypothesis: version=$VERSION | id=$id | dysfunction=$dysfunction | symptoms=${source.joinToString(";").oneLine()} | logic=${logic.oneLine()} | discriminators=${discriminators.joinToString(";").oneLine()} | repair_functions=${repairs.joinToString(";").oneLine()} | priority=$priority | claim_limit=$CLAIM_LIMIT"
        return GTIMDysfunctionHypothesisV2112(id, source, dysfunction, logic, discriminators, repairs, priority, CLAIM_LIMIT, line)
    }

    private fun hasAny(text: String, tokens: List<String>): Boolean = tokens.any { text.contains(it.lowercase()) }
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
