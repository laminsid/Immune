package com.immunesignal.app

import org.json.JSONObject
import java.util.Locale

object GTIMGeoSoftMetadataProbeV2950 {
    const val VERSION: String = "2.9.8-geo-soft-metadata-probe-public-source-ready"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        fileDiscovery: GTIMRepositoryFileDiscoveryReportV2800,
        report: JSONObject? = null
    ): GTIMSoftMetadataProbeReportV2950 {
        val target = GTIMAccessionIdValidityGuardV2753.canonical(fileDiscovery.targetId)
        val softUrl = softUrlFor(target)
        if (fileDiscovery.state == "BLOCKED_NO_TOPIC_COMPATIBLE_TARGET") {
            return emit(target, "GEO_SOFT_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET", softUrl, emptyList(), emptyList(), emptyList(), emptyList())
        }
        if (!target.startsWith("GSE", true)) {
            return emit(target, "GEO_SOFT_NOT_APPLICABLE_NON_GSE_TARGET", softUrl, emptyList(), emptyList(), emptyList(), emptyList())
        }
        val text = softText(report)
        val rows = rowsFromArrays(report).ifEmpty { parseSampleRows(text) }
        val supplementary = supplementaryFromArrays(report).ifEmpty { parseSupplementaryFiles(text) }
        val sra = extractAccessions(text + " " + report?.toString().orEmpty(), Regex("\\bSRP\\d+\\b", RegexOption.IGNORE_CASE)).distinct()
        val runs = extractAccessions(text + " " + report?.toString().orEmpty(), Regex("\\bSRR\\d+\\b", RegexOption.IGNORE_CASE)).distinct()
        val bio = extractAccessions(text + " " + report?.toString().orEmpty(), Regex("\\bPRJNA\\d+\\b", RegexOption.IGNORE_CASE)).distinct()
        val compatibility = if (text.isNotBlank()) GTIMTargetQueryConsistencyGateV2940.keywordCompatibilityScore(text, contract) else 0
        val weighted = if (text.isNotBlank()) GTIMWeightedAnchorCompatibilityV2960.evaluateText(text, contract) else null
        val state = when {
            rows.isNotEmpty() -> "GEO_SOFT_METADATA_PARSED_REVIEW_ONLY"
            text.isNotBlank() -> "GEO_SOFT_TEXT_FOUND_NO_SAMPLE_ROWS_REVIEW_REQUIRED"
            else -> "GEO_SOFT_METADATA_PROBE_REQUIRED"
        }
        val finalState = when {
            state == "GEO_SOFT_METADATA_PARSED_REVIEW_ONLY" && weighted?.state == GTIMWeightedAnchorCompatibilityV2960.NO_MATCH_STATE ->
                "GEO_SOFT_METADATA_TOPIC_MISMATCH_REVIEW_ONLY"
            state == "GEO_SOFT_METADATA_PARSED_REVIEW_ONLY" && (weighted?.nearMatch == true || compatibility in 1..1) ->
                "GEO_SOFT_METADATA_NEAR_MATCH_REVIEW"
            else -> state
        }
        return emit(target, finalState, softUrl, rows, supplementary, (sra + runs).distinct(), bio, weighted)
    }

    private fun emit(
        target: String,
        state: String,
        softUrl: String,
        rows: List<GTIMSampleMetadataRowV2802>,
        supplementary: List<GTIMObservedRepositoryFileV2802>,
        sra: List<String>,
        bio: List<String>,
        weighted: GTIMWeightedAnchorCompatibilityReportV2960? = null
    ): GTIMSoftMetadataProbeReportV2950 {
        val weightedState = weighted?.state ?: "not_evaluated"
        val weightedScore = weighted?.score?.toString() ?: "na"
        val line = "GEO SOFT metadata probe: version=$VERSION | state=$state | target=$target | soft_url=$softUrl | samples=${rows.size} | supplementary_refs=${supplementary.size} | sra_refs=${sra.take(5).joinToString(",").ifBlank { "none" }} | bioproject_refs=${bio.take(5).joinToString(",").ifBlank { "none" }} | weighted_anchor=$weightedState | weighted_score=$weightedScore | comparator_confirmed=false"
        return GTIMSoftMetadataProbeReportV2950(
            active = true,
            targetId = target,
            state = state,
            softUrl = softUrl,
            sampleRows = rows,
            supplementaryFiles = supplementary,
            sraAccessions = sra,
            bioProjectAccessions = bio,
            line = GTIMMetadataFirstObservedEvidenceBridgeV2950.normalize(line),
            boundaryLine = "GEO SOFT boundary: SOFT metadata may suggest sample/comparator labels and file links; it does not prove case/control truth, observed file completeness, DGE readiness, or biological signal."
        )
    }

    private fun softUrlFor(target: String): String =
        if (target.startsWith("GSE", true)) "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=$target&targ=gsm&form=text" else "not_applicable"

    private fun softText(report: JSONObject?): String {
        if (report == null) return ""
        val roots = listOf(
            report,
            report.optJSONObject("actualEtlExecution"),
            report.optJSONObject("gtimActualEtl"),
            report.optJSONObject("mechanismDiscoveryDossierReport"),
            report.optJSONObject("geoSoftMetadata")
        ).filterNotNull()
        val keys = listOf("geoSoftText", "softMetadataText", "geo_soft_text", "softText", "text")
        return roots.asSequence()
            .flatMap { root -> keys.asSequence().map { root.optString(it, "") } }
            .firstOrNull { it.isNotBlank() }
            .orEmpty()
    }

    private fun rowsFromArrays(report: JSONObject?): List<GTIMSampleMetadataRowV2802> {
        if (report == null) return emptyList()
        val arrays = listOfNotNull(
            report.optJSONArray("geoSoftSampleRows"),
            report.optJSONObject("geoSoftMetadata")?.optJSONArray("sampleRows")
        )
        val out = mutableListOf<GTIMSampleMetadataRowV2802>()
        for (array in arrays) {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val sample = firstNonBlank(obj.optString("sampleId"), obj.optString("sample_id"), obj.optString("gsm"), obj.optString("id"))
                val source = firstNonBlank(obj.optString("sourceField"), obj.optString("source_field"), "GEO_SOFT")
                val evidence = firstNonBlank(obj.optString("evidenceSnippet"), obj.optString("evidence_snippet"), obj.optString("title"), obj.optString("characteristics"))
                val raw = obj.keys().asSequence().joinToString(" ") { key -> "$key=${obj.optString(key)}" }
                if (sample.isNotBlank() || evidence.isNotBlank()) out += GTIMSampleMetadataRowV2802(sample.ifBlank { "soft_sample_${out.size + 1}" }, source, evidence.ifBlank { raw.take(180) }, raw)
            }
        }
        return out.distinctBy { it.sampleId.lowercase(Locale.US) }
    }

    private fun parseSampleRows(text: String): List<GTIMSampleMetadataRowV2802> {
        if (text.isBlank()) return emptyList()
        data class Builder(var sampleId: String = "", val fields: MutableList<Pair<String, String>> = mutableListOf())
        val builders = mutableListOf<Builder>()
        var current: Builder? = null
        for (line in text.lineSequence()) {
            val trimmed = line.trim()
            if (trimmed.startsWith("^SAMPLE", true)) {
                current = Builder(sampleId = trimmed.substringAfter("=").trim())
                builders += current
            } else if (trimmed.startsWith("!Sample_", true)) {
                val key = trimmed.substringBefore("=").trim().removePrefix("!")
                val value = trimmed.substringAfter("=", "").trim()
                current?.fields?.add(key to value)
            }
        }
        return builders.mapNotNull { b ->
            val raw = b.fields.joinToString(" | ") { (k, v) -> "$k=$v" }
            val evidence = b.fields.firstOrNull { it.first.contains("characteristics", true) }?.second
                ?: b.fields.firstOrNull { it.first.contains("title", true) }?.second
                ?: raw.take(180)
            if (b.sampleId.isBlank() && raw.isBlank()) null else GTIMSampleMetadataRowV2802(
                sampleId = b.sampleId.ifBlank { "soft_sample" },
                sourceField = "GEO_SOFT_SAMPLE",
                evidenceSnippet = evidence.take(220),
                rawText = raw
            )
        }.distinctBy { it.sampleId.lowercase(Locale.US) }
    }

    private fun supplementaryFromArrays(report: JSONObject?): List<GTIMObservedRepositoryFileV2802> {
        if (report == null) return emptyList()
        val arrays = listOfNotNull(
            report.optJSONArray("geoSoftSupplementaryFiles"),
            report.optJSONObject("geoSoftMetadata")?.optJSONArray("supplementaryFiles")
        )
        val out = mutableListOf<GTIMObservedRepositoryFileV2802>()
        for (array in arrays) {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val url = firstNonBlank(obj.optString("sourceUrl"), obj.optString("source_url"), obj.optString("url"))
                val name = firstNonBlank(obj.optString("fileName"), obj.optString("file_name"), obj.optString("name"), fileNameFromUrl(url))
                if (name.isNotBlank()) {
                    val hint = firstNonBlank(obj.optString("parserHint"), obj.optString("parser_hint"), GTIMSupplementaryFileDiscoveryV2802.classifyFileType(name, ""))
                    out += GTIMObservedRepositoryFileV2802(name, url, obj.optLong("sizeBytes", obj.optLong("size_bytes", 0L)), "soft_metadata_reference", "soft_metadata_probe", hint)
                }
            }
        }
        return out.distinctBy { it.fileName.lowercase(Locale.US) + "|" + it.sourceUrl.lowercase(Locale.US) }
    }

    private fun parseSupplementaryFiles(text: String): List<GTIMObservedRepositoryFileV2802> {
        if (text.isBlank()) return emptyList()
        return text.lineSequence()
            .map { it.trim() }
            .filter { it.startsWith("!Sample_supplementary_file", true) || it.startsWith("!Series_supplementary_file", true) }
            .map { it.substringAfter("=", "").trim() }
            .filter { it.isNotBlank() && it != "NONE" }
            .map { url ->
                val name = fileNameFromUrl(url)
                GTIMObservedRepositoryFileV2802(
                    fileName = name.ifBlank { url.takeLast(40) },
                    sourceUrl = url,
                    sizeBytes = 0L,
                    checksumOrEtag = "soft_metadata_reference",
                    downloadTimestamp = "soft_metadata_probe",
                    parserHint = GTIMSupplementaryFileDiscoveryV2802.classifyFileType(name, "")
                )
            }
            .distinctBy { it.fileName.lowercase(Locale.US) + "|" + it.sourceUrl.lowercase(Locale.US) }
            .toList()
    }

    private fun fileNameFromUrl(url: String): String = url.substringAfterLast('/').substringBefore('?').trim()

    private fun extractAccessions(text: String, regex: Regex): List<String> = regex.findAll(text).map { it.value.uppercase(Locale.US) }.toList()
    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""
}
