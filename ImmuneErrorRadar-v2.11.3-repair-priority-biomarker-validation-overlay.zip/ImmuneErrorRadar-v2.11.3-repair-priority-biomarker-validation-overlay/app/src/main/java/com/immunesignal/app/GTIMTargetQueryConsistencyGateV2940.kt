package com.immunesignal.app

/**
 * v2.9.4 — Target/query consistency gate.
 *
 * Prevents sticky or background accession handles from becoming the active ETL target
 * when their known/topic context does not match the current run. Near matches may be
 * displayed as review-only leads, but they must not pass into ETL/DGE as a selected
 * target unless they are compatible with the active run contract.
 */
data class GTIMTargetQueryConsistencyReportV2940(
    val targetId: String,
    val state: String,
    val etlTargetAllowed: Boolean,
    val surfaceState: String,
    val reason: String,
    val claimLimit: String = GTIMTargetQueryConsistencyGateV2940.CLAIM_LIMIT
)

object GTIMTargetQueryConsistencyGateV2940 {
    const val VERSION: String = "2.9.8-target-query-consistency-near-match-lock"
    const val CLAIM_LIMIT: String = "target_consistency_gate_not_evidence_not_dge_ready"
    const val NEAR_MATCH_STATE: String = "NEAR_MATCH_TOPIC_COMPATIBLE_REVIEW"

    private val knownTargetRoutes: Map<String, String> = mapOf(
        "GSE117882" to "gut_microbiome_to_neuroinflammation",
        "GSE250594" to "allergy_type2_ige_mast_eosinophil",
        "GSE152202" to "covid_interferon_cytokine_bridge",
        "GSE166552" to "covid_interferon_cytokine_bridge",
        "GSE152418" to "covid_interferon_cytokine_bridge",
        "GSE157103" to "covid_interferon_cytokine_bridge",
        "GSE93798" to "ebola_hemorrhagic_viral_host_response",
        "GSE72056" to "ebola_hemorrhagic_viral_host_response",
        "GSE131907" to "ebola_hemorrhagic_viral_host_response",
        "GSE25628" to "ebola_hemorrhagic_viral_host_response"
    )

    fun routeHintFor(targetId: String): String? = knownTargetRoutes[canonical(targetId)]

    fun evaluate(candidate: GTIMMatrixAuditTargetCandidateV2748?, contract: GTIMRunDecisionContractV2740): GTIMTargetQueryConsistencyReportV2940 {
        if (candidate == null) {
            return GTIMTargetQueryConsistencyReportV2940(
                targetId = "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED",
                state = "NO_TARGET_CANDIDATE",
                etlTargetAllowed = false,
                surfaceState = "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED",
                reason = "No accession target candidate survived extraction."
            )
        }
        val target = canonical(candidate.id)
        val hintedRoute = knownTargetRoutes[target]
        if (hintedRoute != null && !GTIMDiseaseSpecificSeedPoolGuardV2750.isTopicRouteCompatible(hintedRoute, contract)) {
            return GTIMTargetQueryConsistencyReportV2940(
                targetId = target,
                state = "TARGET_BLOCKED_ROUTE_MISMATCH",
                etlTargetAllowed = false,
                surfaceState = NEAR_MATCH_STATE,
                reason = "Known target route $hintedRoute does not match active contract ${contract.primaryAnchor.routeId}; keep as review-only near match, not ETL/DGE target."
            )
        }
        val context = listOf(candidate.context, candidate.reason, contract.rawQuery, contract.primaryAnchor.routeId).joinToString(" ")
        val anchorCompatible = GTIMCanonicalRouteIdentityV2748.isAnchorCompatibleText(context, contract)
        val keywordState = keywordCompatibilityState(context, contract)
        val weighted = GTIMWeightedAnchorCompatibilityV2960.evaluateText(context, contract)
        val recallAllowed = contract.primaryAnchor == GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL ||
            contract.primaryAnchor == GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION
        val likelyStickyOrBackground = listOf(candidate.source, candidate.reason).joinToString(" ").let { raw ->
            raw.contains("fallback", ignoreCase = true) ||
                raw.contains("previous", ignoreCase = true) ||
                raw.contains("prior", ignoreCase = true) ||
                raw.contains("background", ignoreCase = true) ||
                raw.contains("template", ignoreCase = true)
        }
        val explicitNearMatch = candidate.reason.contains(NEAR_MATCH_STATE, ignoreCase = true) || weighted.nearMatch || keywordState == NEAR_MATCH_STATE
        if (explicitNearMatch && !anchorCompatible && !weighted.topicCompatible) {
            return GTIMTargetQueryConsistencyReportV2940(
                targetId = target,
                state = "TARGET_HELD_FOR_NEAR_MATCH_REVIEW",
                etlTargetAllowed = false,
                surfaceState = NEAR_MATCH_STATE,
                reason = "Near-match target requires human/data review before any SOFT probe, external lookup, ETL, or DGE; weighted=${weighted.state}/score=${weighted.score}; keyword=$keywordState."
            )
        }
        if (!anchorCompatible && !weighted.topicCompatible && !recallAllowed && (likelyStickyOrBackground || candidate.score < 80)) {
            return GTIMTargetQueryConsistencyReportV2940(
                targetId = target,
                state = "TARGET_BLOCKED_LOW_CONTEXT_FIT",
                etlTargetAllowed = false,
                surfaceState = NEAR_MATCH_STATE,
                reason = "Candidate score/context are insufficient for ${contract.primaryAnchor.routeId}; weighted=${weighted.state}/score=${weighted.score}; keyword=$keywordState; prevent sticky target promotion."
            )
        }
        if (weighted.state == GTIMWeightedAnchorCompatibilityV2960.NO_MATCH_STATE && !anchorCompatible && (likelyStickyOrBackground || candidate.score < 120)) {
            return GTIMTargetQueryConsistencyReportV2940(
                targetId = target,
                state = "TARGET_BLOCKED_WEIGHTED_ANCHOR_MISMATCH",
                etlTargetAllowed = false,
                surfaceState = "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED",
                reason = "Weighted anchor mismatch blocks target promotion; weighted=${weighted.state}/score=${weighted.score}; keyword=$keywordState."
            )
        }
        return GTIMTargetQueryConsistencyReportV2940(
            targetId = target,
            state = "TARGET_QUERY_CONSISTENCY_PASS",
            etlTargetAllowed = true,
            surfaceState = "TARGET_QUERY_CONSISTENCY_PASS",
            reason = "Target $target is compatible with active contract ${contract.primaryAnchor.routeId}; weighted=${weighted.state}/score=${weighted.score}; keyword=$keywordState; ETL/DGE gates remain blocked until observed files, metadata, comparator evidence, and sample-ID linkage pass."
        )
    }


    /** v2.9.8: deterministic keyword floor plus weighted-anchor review before network/file probes; near-match never promotes to ETL. */
    fun keywordCompatibilityScore(text: String, contract: GTIMRunDecisionContractV2740): Int {
        val normalized = GTIMCanonicalRouteIdentityV2748.normalize(text)
        return anchorKeywords(contract.primaryAnchor).count { term -> containsTerm(normalized, term) }
    }

    fun keywordCompatibilityState(text: String, contract: GTIMRunDecisionContractV2740): String {
        val score = keywordCompatibilityScore(text, contract)
        return when {
            score >= 2 -> "TOPIC_COMPATIBLE_KEYWORD_FLOOR_PASS"
            score == 1 -> NEAR_MATCH_STATE
            else -> "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED"
        }
    }

    fun anchorKeywordsFor(anchor: GTIMPrimaryAnchorV2740): List<String> = anchorKeywords(anchor)

    private fun anchorKeywords(anchor: GTIMPrimaryAnchorV2740): List<String> = when (anchor) {
        GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL -> listOf("covid", "sars cov 2", "pasc", "long covid", "interferon", "il 6", "tnf")
        GTIMPrimaryAnchorV2740.EBOLA_HEMORRHAGIC_VIRAL -> listOf("ebola", "evd", "filovirus", "hemorrhagic", "viral hemorrhagic", "fatal", "survivor")
        GTIMPrimaryAnchorV2740.HANTAVIRUS_ZOONOTIC_VIRAL -> listOf("hanta", "hantavirus", "hfrs", "hcps", "rodent", "renal", "pulmonary")
        GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL -> listOf("allergy", "allergic", "ige", "mast", "eosinophil", "type 2")
        GTIMPrimaryAnchorV2740.GUT_MICROBIOME_DEPRESSION -> listOf("microbiome", "gut", "depression", "tryptophan", "kynurenine", "il 6", "tnf")
        GTIMPrimaryAnchorV2740.DEPRESSION_NEUROIMMUNE -> listOf("depression", "mood", "neuroimmune", "inflammation", "il 6", "tnf")
        GTIMPrimaryAnchorV2740.DIABETES_METABOLIC_INFLAMMATION,
        GTIMPrimaryAnchorV2740.T2D_INSULIN_RESISTANCE_INFLAMMATION -> listOf("diabetes", "diabetic", "t2d", "type 2 diabetes", "insulin", "glucose", "hba1c", "metabolic")
        GTIMPrimaryAnchorV2740.HIV_RETROVIRAL_CD4_IMMUNE_DEPLETION -> listOf("hiv", "aids", "cd4", "retroviral", "viral load")
        GTIMPrimaryAnchorV2740.RA_SYNOVIAL_AUTOIMMUNE -> listOf("rheumatoid", "arthritis", "synovial", "tnf", "il 6", "autoimmune")
        GTIMPrimaryAnchorV2740.ASTHMA_TYPE2_AIRWAY -> listOf("asthma", "airway", "eosinophil", "type 2", "ige")
        GTIMPrimaryAnchorV2740.CANCER_IMMUNE -> listOf("cancer", "tumor", "tumour", "immune", "checkpoint", "t cell")
        GTIMPrimaryAnchorV2740.UNKNOWN_AUTONOMOUS_DISCOVERY -> emptyList()
        else -> anchor.routeId.replace('_', ' ').split(' ').filter { it.length >= 4 }
    }

    private fun containsTerm(text: String, raw: String): Boolean {
        val term = GTIMCanonicalRouteIdentityV2748.normalize(raw)
        if (term.isBlank()) return false
        return Regex("(?<![a-z0-9])${Regex.escape(term)}(?![a-z0-9])").containsMatchIn(text)
    }

    fun surfaceLine(report: GTIMTargetQueryConsistencyReportV2940): String =
        "Target consistency gate: version=$VERSION | target=${report.targetId} | state=${report.state} | etl_target_allowed=${report.etlTargetAllowed} | surface=${report.surfaceState} | claim_limit=${report.claimLimit}"

    private fun canonical(value: String): String = GTIMAccessionIdValidityGuardV2753.canonical(value)
}
