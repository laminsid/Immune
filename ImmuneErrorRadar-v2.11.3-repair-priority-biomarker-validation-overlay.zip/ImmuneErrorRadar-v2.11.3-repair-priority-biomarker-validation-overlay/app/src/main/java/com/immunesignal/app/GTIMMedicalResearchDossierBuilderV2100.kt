package com.immunesignal.app

// legacy_v2100_audit_marker: 2.10.0-medical-research-dossier
// legacy_v2104_audit_marker: 2.10.4-relaxed-exploration-dossier-extension | weak, partial, or novel routes
// legacy_v2106_audit_marker: 2.10.6-hypothesis-learning-ledger-dossier-extension
// legacy_v2108_audit_marker: 2.10.8-root-cause-eco-immune-engine
// legacy_v2108_audit_marker: 2.10.8-root-cause-eco-immune-dossier-internal-extension
// legacy_v2109_audit_marker: 2.10.9-ci-hardening-root-cause-dossier-internal-extension

/**
 * v2.10.1 — Medical Research Dossier builder.
 *
 * Final report contract:
 * - include what established science can say at a high level,
 * - include what GTIM explored or discovered,
 * - clearly mark novel/app-generated ideas as untested/unvalidated,
 * - expose mechanism and therapeutic-route maps as research hypotheses only.
 */
object GTIMMedicalResearchDossierBuilderV2100 {
    // legacy_v2101_audit_marker: 2.10.1-medical-study-structure-dossier
    // legacy_v2107_audit_marker: 2.10.7-latent-axis-filter-dossier-internal-extension
    const val VERSION: String = "2.11.0-data-harmonization-soft-guard-dossier-internal-extension+2.11.2-restoration-symptom-overlap+2.11.3-repair-priority-validation"
    const val BOUNDARY: String = "free_immune_genetic_research_synthesis_not_clinical_trial_not_medical_advice_not_authority_validated_no_patient_specific_treatment"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        targetId: String,
        metadataBridge: GTIMMetadataFirstObservedEvidenceBridgeReportV2950?,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802
    ): GTIMMedicalResearchDossierReportV2100 {
        val established = GTIMEstablishedScienceEvidenceLayerV2100.build(contract)
        val discovery = GTIMDiscoveryVsEstablishedSeparatorV2100.build(targetId, metadataBridge, dgeVerdict)
        val mechanism = GTIMMedicalMechanismMapBuilderV2100.build(contract)
        val routes = GTIMTherapeuticRouteMapBuilderV2100.build(contract, mechanism)
        val protocol = GTIMResearchProtocolBuilderV2101.build(contract, established, routes)
        val searchStrategy = GTIMSearchStrategyBuilderV2101.build(contract, protocol, metadataBridge)
        val evidenceTable = GTIMEvidenceTableBuilderV2101.build(protocol, established, discovery, routes)
        val authorityValidation = GTIMAuthorityValidationStatementGuardV2101.build(discovery, routes)
        val (immunotherapyCards, clinicalTrialPlans) = GTIMTherapeuticHypothesisCardRendererV2102.build(
            contract = contract,
            routes = routes,
            discovery = discovery,
            dgeVerdict = dgeVerdict
        )
        val knowledgeAssetContract = GTIMKnowledgeBaseAssetContractV2103.validate()
        val authorityEvidencePlans = GTIMAuthorityEvidenceRequestPlannerV2103.build(contract, immunotherapyCards)
        val explorationPosture = GTIMExplorationPosturePolicyV2104.build(immunotherapyCards, clinicalTrialPlans, authorityEvidencePlans)
        val latentAxisFilter = GTIMLatentAxisFilterV2107.build(
            contract = contract,
            establishedEvidence = established,
            discoveryFindings = discovery,
            mechanismMap = mechanism,
            therapeuticRoutes = routes,
            immunotherapyCards = immunotherapyCards,
            dgeVerdict = dgeVerdict
        )
        val ecoImmuneRootCause = GTIMEcoImmuneRootCauseEngineV2108.build(
            contract = contract,
            latentAxisFilter = latentAxisFilter,
            establishedEvidence = established,
            discoveryFindings = discovery,
            mechanismMap = mechanism,
            therapeuticRoutes = routes,
            immunotherapyCards = immunotherapyCards,
            dgeVerdict = dgeVerdict
        )
        val dataHarmonization = GTIMDataHarmonizationGuardV2110.build(
            contract = contract,
            metadataBridge = metadataBridge,
            dgeVerdict = dgeVerdict,
            establishedEvidence = established,
            discoveryFindings = discovery,
            mechanismMap = mechanism,
            ecoImmuneRootCause = ecoImmuneRootCause
        )
        val freeHypothesisSynthesis = GTIMFreeHypothesisSynthesisEngineV2105.build(
            contract = contract,
            establishedEvidence = established,
            discoveryFindings = discovery,
            mechanismMap = mechanism,
            therapeuticRoutes = routes,
            immunotherapyCards = immunotherapyCards,
            explorationPosture = explorationPosture,
            dgeVerdict = dgeVerdict,
            latentAxisFilterOverride = latentAxisFilter,
            ecoImmuneRootCause = ecoImmuneRootCause
        )
        val hypothesisLearningLedger = GTIMHypothesisLearningLedgerV2106.build(
            contract = contract,
            metadataBridge = metadataBridge,
            freeHypothesisSynthesis = freeHypothesisSynthesis,
            clinicalTrialPlans = clinicalTrialPlans,
            authorityEvidencePlans = authorityEvidencePlans,
            discoveryFindings = discovery,
            dgeVerdict = dgeVerdict
        )
        val ciHardeningGuard = GTIMCiHardeningGuardV2109.build(
            dossierVersion = VERSION,
            rootCause = ecoImmuneRootCause,
            freeHypothesis = freeHypothesisSynthesis,
            learningLedger = hypothesisLearningLedger,
            dataHarmonization = dataHarmonization
        )
        val immunotherapyKnowledgeLine = "Immunotherapy knowledge base: version=${GTIMImmunotherapyKnowledgeBaseV2102.VERSION} | asset=${GTIMImmunotherapyKnowledgeBaseV2102.ASSET_NAME} | cards=${immunotherapyCards.size} | clinical_trial_plans=${clinicalTrialPlans.size} | authority_plans=${authorityEvidencePlans.size} | hypothesis_ledger=${hypothesisLearningLedger.state} | root_cause=${ecoImmuneRootCause.state} | data_harmonization=${dataHarmonization.state} | ci_guard=${ciHardeningGuard.state} | asset_contract=${knowledgeAssetContract.state} | design=non-restrictive mechanism ontology, not disease whitelist | claim_limit=${GTIMImmunotherapyKnowledgeBaseV2102.CLAIM_LIMIT}"
        val limits = defaultValidationLimits() + validationLimitsForDiscovery(discovery) + validationLimitsForImmunotherapy(immunotherapyCards)
        val researchQuestion = "What established immune/genetic science applies to ${contract.primaryAnchor.routeId}, what did GTIM explore for target=$targetId, and which therapeutic route hypotheses remain untested or unvalidated?"
        val grade = GTIMValidationStatusClassifierV2100.grade(established, discovery, routes, dgeVerdict)
        val state = GTIMValidationStatusClassifierV2100.state(discovery, routes)
        val lines = conciseLines(
            state = state,
            researchQuestion = researchQuestion,
            established = established,
            discovery = discovery,
            mechanism = mechanism,
            routes = routes,
            limits = limits,
            protocol = protocol,
            searchStrategy = searchStrategy,
            evidenceTable = evidenceTable,
            authorityValidation = authorityValidation,
            immunotherapyCards = immunotherapyCards,
            clinicalTrialPlans = clinicalTrialPlans,
            authorityEvidencePlans = authorityEvidencePlans,
            explorationPosture = explorationPosture,
            freeHypothesisSynthesis = freeHypothesisSynthesis,
            hypothesisLearningLedger = hypothesisLearningLedger,
            ecoImmuneRootCause = ecoImmuneRootCause,
            dataHarmonization = dataHarmonization,
            ciHardeningGuard = ciHardeningGuard,
            knowledgeAssetContract = knowledgeAssetContract,
            immunotherapyKnowledgeLine = immunotherapyKnowledgeLine,
            grade = grade
        )
        return GTIMMedicalResearchDossierReportV2100(
            active = true,
            version = VERSION,
            state = state,
            targetId = targetId,
            researchQuestion = researchQuestion,
            establishedEvidence = established,
            discoveryFindings = discovery,
            mechanismMap = mechanism,
            therapeuticRoutes = routes,
            validationLimits = limits.distinctBy { it.limitId }.take(10),
            researchProtocol = protocol,
            searchStrategy = searchStrategy,
            evidenceTable = evidenceTable,
            authorityValidationStatements = authorityValidation,
            immunotherapyHypothesisCards = immunotherapyCards,
            clinicalTrialsRequestPlans = clinicalTrialPlans,
            authorityEvidenceRequestPlans = authorityEvidencePlans,
            knowledgeAssetContract = knowledgeAssetContract,
            immunotherapyKnowledgeLine = immunotherapyKnowledgeLine,
            evidenceDossierGrade = grade,
            conciseLines = lines,
            boundaryLine = "Medical research dossier boundary: $BOUNDARY; GTIM may synthesize novel immune/genetic hypotheses from established foundations, analogies, metadata, capsules, and request plans; only clinical action claims remain locked.",
            explorationPosture = explorationPosture,
            freeHypothesisSynthesis = freeHypothesisSynthesis,
            hypothesisLearningLedger = hypothesisLearningLedger,
            ecoImmuneRootCause = ecoImmuneRootCause,
            dataHarmonization = dataHarmonization,
            ciHardeningGuard = ciHardeningGuard
        )
    }

    fun defaultValidationLimits(): List<GTIMValidationLimitCardV2100> = listOf(
        limit("LIMIT_NO_CLINICAL_TRIAL", "GTIM did not run a clinical trial or controlled human intervention study.", "HIGH"),
        limit("LIMIT_NO_MEDICAL_ADVICE", "No output is a diagnosis, treatment recommendation, dosing instruction, medication-stopping advice, or clinical-management plan.", "HIGH"),
        limit("LIMIT_AUTHORITY_NOT_VALIDATED", "App-generated hypotheses may be explored before authority validation, but they must be labeled unverified and never converted into clinical action.", "MEDIUM"),
        limit("LIMIT_DGE_BOUNDARY", "Gene/pathway signals require validated DGE or external evidence capsule; metadata/request plans alone are not biological proof.", "HIGH"),
        limit("LIMIT_IMMUNOTHERAPY_DATA_FIRST", "Immunotherapy routes guide broad exploration from mechanism knowledge, capsules, partial evidence, and request plans; they must not restrict discovery to a closed disease list.", "MEDIUM"),
        limit("LIMIT_FREE_SYNTHESIS_DISCIPLINE", "Established science is the foundation, not the ceiling: GTIM may synthesize novel hypotheses only when mechanism basis, missing evidence, and falsification tests are explicit.", "MEDIUM"),
        limit("LIMIT_HYPOTHESIS_LEDGER_BOUNDARY", "Learned hypothesis routes are operational research memory only; they can strengthen search direction over time but never become medical truth or treatment guidance by repetition.", "MEDIUM"),
        limit("LIMIT_ROOT_CAUSE_RESEARCH_BOUNDARY", "Root-cause and ecosystem-restoration routes search upstream dysfunction and missing functions; they are research hypotheses only and never diagnosis, treatment, or clinical advice.", "HIGH"),
        limit("LIMIT_RESTORATION_ANALOGY_NOT_PROOF", "Ecological restoration analogies can generate hypotheses and recovery markers, but they never prove human causality or treatment.", "HIGH"),
        limit("LIMIT_SYMPTOMS_ARE_NOT_DISEASE_IDENTITY", "Shared symptoms must be mapped to competing dysfunction hypotheses and discriminating evidence before naming disease or repair route.", "HIGH")
    )

    private fun validationLimitsForDiscovery(discovery: List<GTIMDiscoveryFindingCardV2100>): List<GTIMValidationLimitCardV2100> = discovery.map { finding ->
        limit(
            id = "LIMIT_${finding.findingId}",
            statement = "${finding.findingId}: ${finding.validationStatus}; ${finding.requiredNextEvidence}",
            severity = if (finding.validationStatus.contains("NOT_VALIDATED", true) || finding.validationStatus.contains("REQUEST_PLAN", true)) "MEDIUM_HIGH" else "MEDIUM"
        )
    }

    private fun validationLimitsForImmunotherapy(cards: List<GTIMTherapeuticHypothesisCardV2102>): List<GTIMValidationLimitCardV2100> = cards.map { card ->
        limit(
            id = "LIMIT_${card.cardId}",
            statement = "${card.cardId}: ${card.validationStatus}; rank=${card.evidenceRank}; keep as explorable research hypothesis unless converted into clinical action.",
            severity = if (card.evidenceRank.contains("X", true) || card.escapeRisk.contains("HIGH", true)) "HIGH" else "MEDIUM"
        )
    }

    private fun conciseLines(
        state: String,
        researchQuestion: String,
        established: List<GTIMEstablishedEvidenceCardV2100>,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        mechanism: List<GTIMMechanismAxisCardV2100>,
        routes: List<GTIMTherapeuticRouteCardV2100>,
        limits: List<GTIMValidationLimitCardV2100>,
        protocol: GTIMResearchProtocolCardV2101,
        searchStrategy: GTIMSearchStrategyCardV2101,
        evidenceTable: List<GTIMEvidenceTableRowV2101>,
        authorityValidation: List<GTIMAuthorityValidationStatementV2101>,
        immunotherapyCards: List<GTIMTherapeuticHypothesisCardV2102>,
        clinicalTrialPlans: List<GTIMClinicalTrialsRequestPlanV2102>,
        authorityEvidencePlans: List<GTIMAuthorityEvidenceRequestPlanV2103>,
        explorationPosture: GTIMExplorationPostureReportV2104,
        freeHypothesisSynthesis: GTIMFreeHypothesisSynthesisReportV2105,
        hypothesisLearningLedger: GTIMHypothesisLearningLedgerReportV2106,
        ecoImmuneRootCause: GTIMEcoImmuneRootCauseReportV2108,
        dataHarmonization: GTIMDataHarmonizationReportV2110,
        ciHardeningGuard: GTIMCiHardeningGuardReportV2109,
        knowledgeAssetContract: GTIMKnowledgeAssetContractReportV2103,
        immunotherapyKnowledgeLine: String,
        grade: String
    ): List<String> {
        val lines = mutableListOf<String>()
        lines += "Medical Research Dossier: version=$VERSION | state=$state | grade=$grade"
        lines += "Research question: ${researchQuestion.oneLine()}"
        lines += protocol.line.clip(420)
        lines += searchStrategy.line.clip(420)
        established.take(3).forEach { lines += it.line.clip(360) }
        discovery.take(4).forEach { lines += it.line.clip(360) }
        mechanism.take(3).forEach { lines += it.line.clip(360) }
        routes.take(4).forEach { lines += it.line.clip(360) }
        lines += immunotherapyKnowledgeLine.clip(420)
        lines += knowledgeAssetContract.line.clip(500)
        lines += explorationPosture.line.clip(620)
        lines += freeHypothesisSynthesis.line.clip(720)
        freeHypothesisSynthesis.cards.take(5).forEach { lines += it.line.clip(650) }
        lines += ecoImmuneRootCause.line.clip(760)
        ecoImmuneRootCause.ecologicalRestoration?.let { restoration ->
            lines += restoration.line.clip(760)
            restoration.collapseSignals.take(4).forEach { lines += it.line.clip(640) }
            restoration.restorationSequences.take(4).forEach { lines += it.line.clip(720) }
        }
        ecoImmuneRootCause.symptomOverlap?.let { overlap ->
            lines += overlap.line.clip(760)
            overlap.symptomSignals.take(1).forEach { lines += it.line.clip(620) }
            overlap.dysfunctionHypotheses.take(5).forEach { lines += it.line.clip(720) }
            overlap.evidencePlans.take(4).forEach { lines += it.line.clip(680) }
            overlap.sharedRootMechanisms.take(4).forEach { lines += it.line.clip(680) }
            overlap.restorativeRoutes.take(4).forEach { lines += it.line.clip(700) }
        }
        ecoImmuneRootCause.repairPriorityValidation?.let { priority ->
            lines += priority.line.clip(760)
            priority.rankedRepairFunctions.take(6).forEach { lines += it.line.clip(720) }
            priority.biomarkerPlans.take(5).forEach { lines += it.line.clip(720) }
            if (priority.executionOrder.isNotEmpty()) {
                lines += "Repair execution order: ${priority.executionOrder.joinToString("; ").oneLine()}".clip(760)
            }
        }
        ecoImmuneRootCause.candidates.take(4).forEach { lines += it.line.clip(720) }
        ecoImmuneRootCause.microbialReversal?.let { reversal ->
            lines += reversal.line.clip(760)
            reversal.damageMechanisms.take(4).forEach { lines += it.line.clip(620) }
            reversal.counterFunctions.take(5).forEach { lines += it.line.clip(680) }
            reversal.candidateRoutes.take(5).forEach { lines += it.line.clip(700) }
            reversal.studyPlans.take(4).forEach { lines += it.line.clip(720) }
        }
        ecoImmuneRootCause.restorationRoutes.take(5).forEach { lines += it.line.clip(680) }
        ecoImmuneRootCause.falsificationPlans.take(4).forEach { lines += it.line.clip(680) }
        lines += dataHarmonization.line.clip(760)
        dataHarmonization.evidenceAlignment?.let { lines += it.line.clip(620) }
        dataHarmonization.spuriousCorrelationAssessment?.let { lines += it.line.clip(680) }
        dataHarmonization.solutionRoutes.take(4).forEach { lines += it.line.clip(680) }
        lines += ciHardeningGuard.line.clip(520)
        lines += hypothesisLearningLedger.line.clip(720)
        hypothesisLearningLedger.entries.take(5).forEach { lines += it.line.clip(680) }
        immunotherapyCards.take(5).forEach { lines += it.line.clip(520) }
        clinicalTrialPlans.take(4).forEach { lines += it.line.clip(500) }
        authorityEvidencePlans.take(6).forEach { lines += it.line.clip(520) }
        evidenceTable.take(5).forEach { lines += it.line.clip(420) }
        authorityValidation.take(4).forEach { lines += it.line.clip(420) }
        lines += "Exploration status: GTIM searches upstream root dysfunction before symptom suppression; microbiome/metabolism/immune/context axes are internal research filters; microbial reversal routes search counter-functions that may reverse, restore, neutralize, or buffer damage mechanisms; Restoration Lens maps collapse -> missing function -> recovery marker while blocking analogy-as-proof; Symptom Overlap Resolver treats symptoms as non-specific overlap signals and demands dysfunction mapping plus discriminating evidence before disease naming; Repair Priority Validation ranks repair functions by impact, feasibility, risk, and biomarker/falsification readiness before any route upgrade; authority evidence is a validation target, not a discovery blocker; heterogeneous public data is harmonized with a soft spurious-correlation guard so weak links still produce research routes; traditional evidence is the foundation, not the ceiling; learned routes are reusable research memory, not medical truth."
        limits.take(4).forEach { lines += it.line.clip(330) }
        lines += "Dossier boundary: $BOUNDARY"
        return lines
    }

    private fun limit(id: String, statement: String, severity: String): GTIMValidationLimitCardV2100 {
        val line = "Validation limit: id=$id | severity=$severity | statement=${statement.oneLine()}"
        return GTIMValidationLimitCardV2100(id, statement, severity, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
    private fun String.clip(max: Int): String = if (length <= max) this else take(max - 1).trimEnd() + "…"
}
