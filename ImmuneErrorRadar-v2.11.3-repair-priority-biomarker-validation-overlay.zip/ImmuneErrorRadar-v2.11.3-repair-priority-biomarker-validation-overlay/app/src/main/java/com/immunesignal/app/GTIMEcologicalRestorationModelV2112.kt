package com.immunesignal.app

// v2.11.2 — Ecological Restoration Model.
// The pond-to-host principle is used as a disciplined research analogy: find the
// collapse condition, then the missing stabilizing function, then the recovery marker.
object GTIMEcologicalRestorationModelV2112 {
    const val VERSION: String = "2.11.2-ecological-restoration-model"
    const val PRINCIPLE: String = "symptoms_or_visible_damage_are_ecosystem_collapse_signals_not_disease_identity"
    const val ANALOGY_GUARD: String = "pond_restoration_analogy_can_generate_hypotheses_but_never_proves_human_causality_or_treatment"
    const val BOUNDARY: String = "ecological_restoration_lens_is_research_only_not_diagnosis_not_treatment_not_biosystem_intervention_protocol"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        corpus: String,
        rootCandidates: List<GTIMEcoImmuneRootCauseCandidateV2108>,
        microbialReversal: GTIMMicrobialReversalReportV2111?
    ): GTIMEcologicalRestorationReportV2112 {
        val collapseSignals = GTIMEcologicalCollapseClassifierV2112.classify(contract, corpus, rootCandidates, microbialReversal)
        val sequences = GTIMRestorationSequencePlannerV2112.plan(collapseSignals, microbialReversal)
        val markers = sequences.flatMap { it.recoveryIndicators }.distinct().take(12)
        val state = when {
            collapseSignals.any { it.collapseType == GTIMEcologicalCollapseTypeV2112.UNKNOWN } && collapseSignals.size == 1 -> "ECOLOGICAL_RESTORATION_OPEN_LENS_NO_DOMINANT_COLLAPSE"
            collapseSignals.any { it.collapseType == GTIMEcologicalCollapseTypeV2112.BARRIER_FAILURE || it.collapseType == GTIMEcologicalCollapseTypeV2112.IMMUNE_OVERACTIVATION } -> "ECOLOGICAL_RESTORATION_ROUTE_FOUND_BARRIER_IMMUNE_SYSTEM"
            collapseSignals.any { it.collapseType == GTIMEcologicalCollapseTypeV2112.TOXIN_ACCUMULATION || it.collapseType == GTIMEcologicalCollapseTypeV2112.EXPOSOME_PRESSURE } -> "ECOLOGICAL_RESTORATION_ROUTE_FOUND_EXPOSOME_PRESSURE"
            else -> "ECOLOGICAL_RESTORATION_ROUTE_FOUND_SYSTEM_REBALANCE_HYPOTHESIS"
        }
        val integration = "CONNECTED_TO_ROOT_CAUSE_MRE_SYMPTOM_OVERLAP_DATA_HARMONIZATION|collapse=${collapseSignals.size}|sequences=${sequences.size}|markers=${markers.size}"
        val line = "Restoration Lens: version=$VERSION | state=$state | principle=$PRINCIPLE | collapse_types=${collapseSignals.map { it.collapseType.name }.distinct().joinToString(",").oneLine()} | recovery_markers=${markers.joinToString(";").oneLine()} | analogy_guard=$ANALOGY_GUARD | integration=$integration | boundary=$BOUNDARY"
        return GTIMEcologicalRestorationReportV2112(
            active = true,
            version = VERSION,
            state = state,
            principle = PRINCIPLE,
            collapseSignals = collapseSignals,
            restorationSequences = sequences,
            recoveryMarkers = markers,
            analogyGuard = ANALOGY_GUARD,
            integrationState = integration,
            line = line,
            boundaryLine = BOUNDARY
        )
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
