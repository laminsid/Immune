package com.immunesignal.app

// v2.11.2 — Plans discriminating evidence so shared symptoms do not become disease claims.
object GTIMDiscriminatingEvidencePlannerV2112 {
    const val VERSION: String = "2.11.2-discriminating-evidence-planner"

    fun plan(hypotheses: List<GTIMDysfunctionHypothesisV2112>): List<GTIMDiscriminatingEvidencePlanV2112> = hypotheses.take(6).mapIndexed { index, h ->
        val separates = when (h.dysfunctionClass) {
            "immune_overactivation" -> listOf("infection-driven inflammation", "autoimmune-like pattern", "allergy/tolerance loss", "metabolic inflammatory mimic")
            "barrier_failure" -> listOf("primary pathogen disease", "food/exposure pressure", "immune overactivation secondary to leak", "local tissue damage")
            "microbial_ecosystem_imbalance" -> listOf("pathogen dominance", "low functional diversity", "metabolite deficit", "antibiotic/post-infectious ecology")
            "metabolic_energy_stress" -> listOf("mitochondrial/energy constraint", "inflammatory fatigue", "sleep/stress mimic", "endocrine/metabolic mimic")
            "exposome_pressure" -> listOf("true exposure burden", "barrier-only dysfunction", "microbial byproduct effect", "coincidental geography/source signal")
            "neuroimmune_tissue_stress" -> listOf("structural neurologic injury", "peripheral inflammatory bridge", "toxin/vascular signal", "infection or autoimmune mimic")
            else -> listOf("overlapping disease families", "context-only analogy", "non-specific symptom cluster")
        }
        val missing = "missing_discriminating_evidence_prevents_disease_naming_and_causal_upgrade"
        val id = "DISCRIMINATOR_${index + 1}_${h.dysfunctionClass}".take(96)
        val evidence = h.discriminatingEvidence.distinct().take(6)
        val line = "Discriminating evidence plan: version=$VERSION | id=$id | dysfunction=${h.dysfunctionClass} | evidence=${evidence.joinToString(";").oneLine()} | separates_from=${separates.joinToString(";").oneLine()} | missing_proof=$missing"
        GTIMDiscriminatingEvidencePlanV2112(id, h.dysfunctionClass, evidence, separates, missing, line)
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
