package com.immunesignal.app

// v2.11.2 — Plans repair sequences: collapse -> first function -> recovery marker.
object GTIMRestorationSequencePlannerV2112 {
    const val VERSION: String = "2.11.2-restoration-sequence-planner"
    const val BOUNDARY: String = "restoration_sequence_is_a_research_route_not_an_intervention_protocol"

    fun plan(
        collapseSignals: List<GTIMEcologicalCollapseSignalV2112>,
        microbialReversal: GTIMMicrobialReversalReportV2111?
    ): List<GTIMRestorationSequenceV2112> {
        val microbialSummary = microbialReversal?.candidateRoutes?.firstOrNull()?.candidateClass ?: "function_first_microbiome_or_metabolite_candidate"
        return collapseSignals.take(6).mapIndexed { index, signal ->
            val (first, second, markers, failures, role) = planFor(signal.collapseType, microbialSummary)
            val confidence = when (signal.collapseType) {
                GTIMEcologicalCollapseTypeV2112.UNKNOWN -> "LOW_OPEN_RESTORATION_LENS"
                GTIMEcologicalCollapseTypeV2112.NEUROIMMUNE_STRESS -> "LONG_HORIZON_REQUIRES_STRONG_FALSIFICATION"
                GTIMEcologicalCollapseTypeV2112.TOXIN_ACCUMULATION -> "PLAUSIBLE_IF_EXPOSURE_MEASURED"
                else -> "PLAUSIBLE_RESEARCH_ONLY_NEEDS_CAUSAL_MARKERS"
            }
            val id = "RESTORATION_SEQUENCE_${index + 1}_${signal.collapseType.name}"
            val line = "Restoration sequence: version=$VERSION | id=$id | collapse=${signal.collapseType.name} | first_repair=${first.oneLine()} | second_order=${second.oneLine()} | recovery_markers=${markers.joinToString(";").oneLine()} | failure_signals=${failures.joinToString(";").oneLine()} | microbial_role=${role.oneLine()} | confidence=$confidence | boundary=$BOUNDARY"
            GTIMRestorationSequenceV2112(id, signal.collapseType, first, second, markers, failures, role, confidence, line)
        }
    }

    private fun planFor(type: GTIMEcologicalCollapseTypeV2112, microbialSummary: String): Quintet {
        return when (type) {
            GTIMEcologicalCollapseTypeV2112.ORGANIC_OVERLOAD -> Quintet(
                "reduce overload and restore cleanup/decomposition balance",
                "oxygen/redox and ecological stability can return before higher-order life indicators recover",
                listOf("burden reduction", "redox/oxygen proxy", "microbial balance shift", "return-of-life proxy"),
                listOf("black-water/overload signal persists", "cleanup function worsens inflammation", "no recovery marker moves"),
                "microbial cleanup or biotransformation function, never direct human treatment inference"
            )
            GTIMEcologicalCollapseTypeV2112.LOW_DIVERSITY -> Quintet(
                "restore missing microbial or metabolite function",
                "barrier tone and immune thresholds may stabilize if missing functions return",
                listOf("functional microbiome profile", "SCFA/metabolite shift", "barrier marker", "inflammatory tone"),
                listOf("diversity/function remains low", "pathogen niche expands", "metabolite direction contradicts repair"),
                microbialSummary
            )
            GTIMEcologicalCollapseTypeV2112.PATHOGEN_DOMINANCE, GTIMEcologicalCollapseTypeV2112.BIOFILM_OR_NICHE_LOCK -> Quintet(
                "weaken harmful niche dominance before rebuilding stable commensal occupancy",
                "pathogen pressure may drop only if biofilm/toxin/niche-lock conditions change",
                listOf("pathogen load", "biofilm/toxin marker", "commensal occupancy", "local inflammation"),
                listOf("target organism not present", "polymicrobial ecology explains damage", "resistance escape dominates"),
                "competitive displacement, phage-like weakening, or anti-biofilm counter-function as research route"
            )
            GTIMEcologicalCollapseTypeV2112.TOXIN_ACCUMULATION, GTIMEcologicalCollapseTypeV2112.EXPOSOME_PRESSURE -> Quintet(
                "measure and reduce burden or bioavailability of the pressure source",
                "barrier and immune noise may decline only after exposure pressure is separated from repair failure",
                listOf("measured exposure", "binding/biotransformation marker", "safe byproduct profile", "burden/excretion marker"),
                listOf("no exposure present", "toxic byproduct appears", "burden does not change despite candidate function"),
                "microbial sink, biotransformation, or resilience-support route under strict safety review"
            )
            GTIMEcologicalCollapseTypeV2112.BARRIER_FAILURE -> Quintet(
                "restore boundary integrity before interpreting downstream immune symptoms",
                "reduced antigen/toxin leakage may lower chronic immune activation and allow microbial recovery",
                listOf("barrier integrity marker", "mucus/tight-junction context", "local immune readout", "microbial metabolite profile"),
                listOf("barrier marker stays damaged", "local inflammation increases", "no local context match"),
                "barrier-supporting microbial/metabolite function"
            )
            GTIMEcologicalCollapseTypeV2112.IMMUNE_OVERACTIVATION -> Quintet(
                "recalibrate immune decision thresholds rather than suppressing all response",
                "tolerance and inflammatory durability may improve if the misclassification loop is broken",
                listOf("cytokine pattern", "Treg/Th or mast-cell threshold", "tolerance marker", "subgroup response"),
                listOf("suppression replaces recalibration", "tolerance marker worsens", "infection signal remains unresolved"),
                "immune-training or metabolite-mediated recalibration route"
            )
            GTIMEcologicalCollapseTypeV2112.METABOLIC_STAGNATION -> Quintet(
                "restore conversion, energy, or metabolite flow needed for repair",
                "immune and tissue resilience may depend on host-microbial metabolic state",
                listOf("metabolite panel", "lactate/mitochondrial proxy", "bile/SCFA context", "repair-capacity marker"),
                listOf("metabolic marker contradicts hypothesis", "candidate produces wrong metabolite", "fatigue remains unexplained by pathway"),
                "microbial or postbiotic metabolic-conversion route"
            )
            GTIMEcologicalCollapseTypeV2112.NEUROIMMUNE_STRESS -> Quintet(
                "separate tissue injury from upstream immune/barrier/toxin/metabolite loops",
                "neuroimmune stress may improve only if peripheral driver and tissue-specific damage are both tracked",
                listOf("neuroinflammatory marker", "peripheral inflammation bridge", "barrier/toxin/metabolite context", "tissue-specific outcome"),
                listOf("no peripheral bridge", "primary structural cause dominates", "candidate worsens neuroinflammation"),
                "long-horizon microbial-metabolite or immune-tone research route, not clinical repair claim"
            )
            GTIMEcologicalCollapseTypeV2112.UNKNOWN -> Quintet(
                "identify the missing stabilizing function before ranking repair candidates",
                "open scan can still produce useful hypotheses if it names the discriminator and kill test",
                listOf("symptom cluster", "context timeline", "minimum mechanism marker", "negative comparator"),
                listOf("no shared mechanism emerges", "all candidate routes remain analogy-only", "alternative cause explains cluster"),
                "open function-first microbial/metabolic/ecological scan"
            )
        }
    }

    private data class Quintet(
        val first: String,
        val second: String,
        val markers: List<String>,
        val failures: List<String>,
        val role: String
    )
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
