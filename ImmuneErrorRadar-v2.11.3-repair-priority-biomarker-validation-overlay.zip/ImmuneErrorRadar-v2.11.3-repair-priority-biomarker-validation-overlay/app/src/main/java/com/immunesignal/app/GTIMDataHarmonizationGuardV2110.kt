package com.immunesignal.app

// v2.11.0 — Soft data-harmonization and spurious-correlation guard.
// This is deliberately not a hard gate. Weak heterogeneous links remain visible as
// research routes, but they carry alignment level, spurious-correlation risk, and
// upgrade evidence requirements. It must not block root-cause exploration.
object GTIMDataHarmonizationGuardV2110 {
    const val VERSION: String = "2.11.0-data-harmonization-soft-spurious-correlation-guard"
    const val POLICY: String = "soft_guard_allows_exploratory_routes_downgrades_causal_claims_not_solution_generation"
    const val BOUNDARY: String = "heterogeneous_public_data_can_generate_research_routes_not_causal_or_clinical_claims"

    fun build(
        contract: GTIMRunDecisionContractV2740,
        metadataBridge: GTIMMetadataFirstObservedEvidenceBridgeReportV2950?,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802,
        establishedEvidence: List<GTIMEstablishedEvidenceCardV2100>,
        discoveryFindings: List<GTIMDiscoveryFindingCardV2100>,
        mechanismMap: List<GTIMMechanismAxisCardV2100>,
        ecoImmuneRootCause: GTIMEcoImmuneRootCauseReportV2108
    ): GTIMDataHarmonizationReportV2110 {
        val corpus = corpus(contract, metadataBridge, dgeVerdict, establishedEvidence, discoveryFindings, mechanismMap, ecoImmuneRootCause)
        val capsules = buildSourceCapsules(corpus, metadataBridge, dgeVerdict, ecoImmuneRootCause)
        val researchObject = buildResearchObject(contract, corpus, capsules)
        val alignment = scoreAlignment(corpus, capsules, researchObject, mechanismMap, ecoImmuneRootCause)
        val spurious = assessSpuriousRisk(alignment, capsules)
        val routes = buildSolutionRoutes(researchObject, alignment, spurious, capsules, ecoImmuneRootCause)
        val state = when {
            routes.any { it.outputState.contains("USABLE", true) } -> "DATA_HARMONIZATION_SOFT_GUARD_USABLE_RESEARCH_ROUTES"
            capsules.isNotEmpty() -> "DATA_HARMONIZATION_SOFT_GUARD_EXPLORATORY_ROUTES_ALLOWED"
            else -> "DATA_HARMONIZATION_OPEN_SCAN_NO_SOURCE_CAPSULES"
        }
        val line = "Data harmonization: version=$VERSION | state=$state | policy=$POLICY | sources=${capsules.map { it.sourceFamily }.distinct().joinToString(";").oneLine()} | alignment=${alignment.alignmentLevel}:${alignment.score} | spurious=${spurious.riskLevel} | routes=${routes.size} | boundary=$BOUNDARY"
        return GTIMDataHarmonizationReportV2110(
            active = true,
            version = VERSION,
            state = state,
            policy = POLICY,
            sourceCapsules = capsules,
            researchObject = researchObject,
            evidenceAlignment = alignment,
            spuriousCorrelationAssessment = spurious,
            solutionRoutes = routes,
            line = line,
            boundaryLine = BOUNDARY
        )
    }

    private fun buildSourceCapsules(
        corpus: String,
        metadataBridge: GTIMMetadataFirstObservedEvidenceBridgeReportV2950?,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802,
        rootCause: GTIMEcoImmuneRootCauseReportV2108
    ): List<GTIMSourceCapsuleV2110> {
        val capsules = mutableListOf<GTIMSourceCapsuleV2110>()
        if (metadataBridge != null && metadataBridge.active) {
            capsules += capsule(
                id = "CAPSULE_METADATA_${metadataBridge.targetId}",
                family = "omics_metadata",
                kind = "GEO_SOFT_OR_ACCESSION_METADATA",
                fields = listOf("target=${metadataBridge.targetId}", "soft=${metadataBridge.softProbe.state}", "srp=${metadataBridge.gseToSrpMapping.state}", "external=${metadataBridge.externalAvailability.state}"),
                use = "sample/context anchoring, not biological proof",
                quality = if (metadataBridge.state.contains("BLOCK", true)) "PARTIAL_METADATA" else "METADATA_ROUTE_AVAILABLE"
            )
        }
        if (dgeVerdict.blockers.isNotEmpty()) {
            capsules += capsule(
                id = "CAPSULE_DGE_BOUNDARY_${dgeVerdict.targetId}",
                family = "dge_boundary",
                kind = "READINESS_LOCK",
                fields = dgeVerdict.blockers.take(5),
                use = "prevents metadata-only gene/pathway causal upgrading",
                quality = dgeVerdict.verdict
            )
        }
        if (containsAny(corpus, listOf("air", "pm2", "pm2.5", "pm10", "no2", "ozone", "pollution", "factory", "car", "openaq"))) {
            capsules += capsule("CAPSULE_AIR_EXPOSURE_CONTEXT", "air_exposome", "PUBLIC_EXPOSURE_CONTEXT", listOf("PM2.5/PM10/NO2/O3 context", "location/time alignment required"), "exposure pressure candidate", "EXPOSURE_CONTEXT_ONLY")
        }
        if (containsAny(corpus, listOf("food", "ultra", "processed", "additive", "fraud", "honey", "olive", "open food", "ingredient", "label"))) {
            capsules += capsule("CAPSULE_FOOD_INTEGRITY_CONTEXT", "food_integrity", "FOOD_LABEL_INGREDIENT_CONTEXT", listOf("ingredient/provenance reliability", "processing/adulteration context"), "dietary ecology and exposure candidate", "LABEL_CONTEXT_ONLY")
        }
        if (containsAny(corpus, listOf("plastic", "microplastic", "nanoplastic", "petroleum", "phthalate", "bpa"))) {
            capsules += capsule("CAPSULE_PLASTIC_EXPOSOME_CONTEXT", "plastic_exposome", "PARTICLE_OR_CHEMICAL_CONTEXT", listOf("particle burden hypothesis", "barrier/oxidative stress bridge required"), "external exposome route candidate", "HYPOTHESIS_CONTEXT_ONLY")
        }
        if (containsAny(corpus, listOf("water", "chlorine", "chlorinated", "hard water", "calcium", "magnesium", "tds", "nitrate", "algeria"))) {
            capsules += capsule("CAPSULE_WATER_EXPOSURE_CONTEXT", "water_exposome", "LONG_TERM_WATER_CONTEXT", listOf("hard/chlorinated water exposure", "skin/barrier and microbiome bridge required"), "lifetime exposome modifier", "CONTEXT_REQUIRES_MEASUREMENT")
        }
        if (containsAny(corpus, listOf("microbiome", "bacteria", "butyrate", "scfa", "dysbiosis", "microbial")) || rootCause.candidates.any { it.candidateId.contains("ecological", true) }) {
            capsules += capsule("CAPSULE_MICROBIAL_FUNCTION_CONTEXT", "microbial_function", "FUNCTION_FIRST_MICROBIOME_CONTEXT", listOf("lost function, metabolite, barrier or tolerance route", "strain name is secondary to function"), "root-cause restoration candidate", "FUNCTIONAL_HYPOTHESIS")
        }
        rootCause.ecologicalRestoration?.takeIf { it.active }?.let { restoration ->
            capsules += capsule(
                "CAPSULE_ECOLOGICAL_RESTORATION_CONTEXT",
                "ecological_restoration_analogy",
                "RESTORATION_LENS_RESEARCH_CONTEXT",
                listOf("collapse=${restoration.collapseSignals.size}", "sequences=${restoration.restorationSequences.size}", restoration.state, restoration.analogyGuard),
                "collapse-to-repair-function route candidate; analogy does not prove causality",
                "RESTORATION_ANALOGY_NOT_PROOF"
            )
        }
        rootCause.symptomOverlap?.takeIf { it.active }?.let { overlap ->
            capsules += capsule(
                "CAPSULE_SYMPTOM_OVERLAP_CONTEXT",
                "symptom_overlap_dysfunction_map",
                "SYMPTOM_TO_DYSFUNCTION_RESEARCH_CONTEXT",
                listOf("symptoms=${overlap.symptomSignals.firstOrNull()?.symptomCluster?.size ?: 0}", "hypotheses=${overlap.dysfunctionHypotheses.size}", overlap.state, overlap.principle),
                "symptoms are non-specific; build dysfunction and discriminator map before disease naming",
                "SYMPTOMS_ARE_NOT_DISEASE_IDENTITY"
            )
        }
        rootCause.repairPriorityValidation?.takeIf { it.active }?.let { priority ->
            capsules += capsule(
                "CAPSULE_REPAIR_PRIORITY_VALIDATION_CONTEXT",
                "repair_priority_validation",
                "REPAIR_FUNCTION_RANKING_AND_BIOMARKER_CONTEXT",
                listOf("ranked=${priority.rankedRepairFunctions.size}", "biomarker_plans=${priority.biomarkerPlans.size}", priority.state, priority.principle),
                "rank repair-function routes by impact, feasibility, risk, and validation markers before upgrade",
                "PRIORITY_RESEARCH_CONTEXT_NOT_PROOF"
            )
        }
        rootCause.microbialReversal?.takeIf { it.active }?.let { reversal ->
            capsules += capsule(
                "CAPSULE_MICROBIAL_REVERSAL_CONTEXT",
                "microbial_reversal_function",
                "COUNTER_FUNCTION_RESEARCH_CONTEXT",
                listOf("damage=${reversal.damageMechanisms.size}", "counter=${reversal.counterFunctions.size}", "candidates=${reversal.candidateRoutes.size}", reversal.state),
                "microbial counter-function route candidate integrated with root-cause graph",
                "HYPOTHETICAL_COUNTER_FUNCTION_CONTEXT"
            )
        }
        return capsules.distinctBy { it.capsuleId }.take(12)
    }

    private fun buildResearchObject(contract: GTIMRunDecisionContractV2740, corpus: String, capsules: List<GTIMSourceCapsuleV2110>): GTIMResearchObjectV2110 {
        val mechanismBridge = when {
            containsAny(corpus, listOf("barrier", "mucosal", "permeability")) -> "barrier_mucosal_immune_bridge"
            containsAny(corpus, listOf("metabolic", "glucose", "insulin", "mitochondria")) -> "immunometabolic_bridge"
            containsAny(corpus, listOf("microbiome", "bacteria", "butyrate", "scfa")) -> "microbiome_metabolite_immune_bridge"
            containsAny(corpus, listOf("pollution", "plastic", "chlorine", "food", "water")) -> "exposome_barrier_immune_bridge"
            containsAny(corpus, listOf("symptom overlap", "dysfunction", "fatigue", "fever", "brain fog")) -> "symptom_to_dysfunction_bridge"
            else -> "open_mechanism_bridge_required"
        }
        val exposure = capsules.filter { it.sourceFamily.contains("exposome") || it.sourceFamily.contains("food") || it.sourceFamily.contains("water") }.map { it.sourceFamily }.distinct().ifEmpty { listOf("not_specified") }.joinToString("+")
        val line = "Research object: topic=${contract.primaryAnchor.routeId} | phenotype=${contract.diseaseFamily.name} | mechanism_bridge=$mechanismBridge | exposure_context=$exposure | claim_limit=research_route_not_causal_claim"
        return GTIMResearchObjectV2110(
            objectId = "RO_${contract.primaryAnchor.routeId.take(32).ifBlank { "OPEN" }}".replace(Regex("[^A-Za-z0-9_]+"), "_"),
            topic = contract.primaryAnchor.routeId,
            phenotypeOrDisease = contract.diseaseFamily.name,
            mechanismBridge = mechanismBridge,
            tissueOrContext = contract.secondaryDomains.joinToString(",") { it.name }.ifBlank { "context_not_specified" },
            exposureOrSourceContext = exposure,
            claimLimit = "research_route_not_causal_or_clinical_claim",
            line = line
        )
    }

    private fun scoreAlignment(
        corpus: String,
        capsules: List<GTIMSourceCapsuleV2110>,
        researchObject: GTIMResearchObjectV2110,
        mechanisms: List<GTIMMechanismAxisCardV2100>,
        rootCause: GTIMEcoImmuneRootCauseReportV2108
    ): GTIMEvidenceAlignmentV2110 {
        val families = capsules.map { it.sourceFamily }.distinct()
        val mechanismBridgeFound = researchObject.mechanismBridge != "open_mechanism_bridge_required" || rootCause.candidates.any { it.causalChain.isNotBlank() } || mechanisms.isNotEmpty()
        var score = 10
        if (mechanismBridgeFound) score += 25
        if (families.size >= 2) score += 15
        if (families.any { it.contains("omics") }) score += 10
        if (families.any { it.contains("microbial") }) score += 10
        if (families.any { it.contains("exposome") || it.contains("food") || it.contains("water") }) score += 10
        if (families.any { it.contains("symptom_overlap") }) score += 5
        if (families.any { it.contains("ecological_restoration") }) score += 5
        if (families.any { it.contains("repair_priority") }) score += 5
        if (containsAny(corpus, listOf("human", "cohort", "clinical", "case", "trial", "metadata", "sample"))) score += 10
        val analogyOnly = families.any { it.contains("ecological_restoration") || it.contains("symptom_overlap") } && families.none { it.contains("omics") || it.contains("dge") || it.contains("food") || it.contains("water") || it.contains("microbial_function") || it.contains("exposome") }
        val clamped = if (analogyOnly) score.coerceIn(10, 54) else score.coerceIn(10, 95)
        val level = when {
            clamped >= 75 -> "L4_CONTEXTUAL_MECHANISTIC_ALIGNMENT"
            clamped >= 55 -> "L3_MECHANISTIC_MULTI_SOURCE_ALIGNMENT"
            clamped >= 35 -> "L2_MECHANISM_SUPPORTED_HETEROGENEOUS_ALIGNMENT"
            else -> "L1_TEXTUAL_OR_CONTEXTUAL_ALIGNMENT"
        }
        val confidenceUse = when {
            level.startsWith("L4") -> "strong_exploratory_route_no_causal_claim"
            level.startsWith("L3") -> "usable_research_route_with_context_warning"
            level.startsWith("L2") -> "weak_to_moderate_research_route_allowed"
            else -> "weak_signal_keep_as_open_question"
        }
        val line = "Evidence alignment: level=$level | score=$clamped | mechanism_bridge=$mechanismBridgeFound | sources=${families.joinToString(";")} | confidence_use=$confidenceUse"
        return GTIMEvidenceAlignmentV2110(level, clamped, mechanismBridgeFound, families, confidenceUse, line)
    }

    private fun assessSpuriousRisk(
        alignment: GTIMEvidenceAlignmentV2110,
        capsules: List<GTIMSourceCapsuleV2110>
    ): GTIMSpuriousCorrelationAssessmentV2110 {
        val heterogeneous = capsules.map { it.sourceFamily }.distinct().size >= 2
        val risk = when {
            !alignment.mechanismBridgeFound -> "HIGH"
            alignment.score < 35 -> "HIGH"
            heterogeneous && alignment.score < 55 -> "MEDIUM_HIGH"
            alignment.score < 75 -> "MEDIUM"
            else -> "LOW_MEDIUM"
        }
        val output = when (risk) {
            "HIGH" -> "ALLOW_WEAK_EXPLORATORY_ROUTE_DO_NOT_HIDE"
            "MEDIUM_HIGH" -> "ALLOW_EXPLORATORY_ROUTE_WITH_SPURIOUS_WARNING"
            else -> "ALLOW_USABLE_RESEARCH_ROUTE_NO_CAUSAL_UPGRADE"
        }
        val required = listOf(
            "same-topic or same-population/context evidence",
            "exposure measurement or credible source capsule",
            "mechanism biomarker bridge",
            "independent replication or alternative-explanation review",
            "time-direction or intervention/capsule evidence before causal claim"
        )
        val reason = if (risk == "HIGH") "mechanism/context alignment insufficient" else "heterogeneous sources require careful weighting"
        val line = "Spurious-correlation soft guard: risk=$risk | policy=$POLICY | output=$output | downgrade_reason=$reason | upgrade=${required.joinToString(";").oneLine()}"
        return GTIMSpuriousCorrelationAssessmentV2110(risk, POLICY, reason, output, required, line)
    }

    private fun buildSolutionRoutes(
        researchObject: GTIMResearchObjectV2110,
        alignment: GTIMEvidenceAlignmentV2110,
        spurious: GTIMSpuriousCorrelationAssessmentV2110,
        capsules: List<GTIMSourceCapsuleV2110>,
        rootCause: GTIMEcoImmuneRootCauseReportV2108
    ): List<GTIMHeterogeneousSolutionRouteV2110> {
        val routes = mutableListOf<GTIMHeterogeneousSolutionRouteV2110>()
        val families = capsules.map { it.sourceFamily }.distinct()
        if (families.any { it.contains("microbial") } || researchObject.mechanismBridge.contains("microbiome")) {
            routes += solutionRoute(
                id = "HET_MICROBIAL_FUNCTION_RESTORATION",
                routeClass = "microbial_function_restoration_route",
                logic = "Search for missing microbial/metabolite function that could restore barrier, tolerance, or exposome handling.",
                supportedBy = families,
                alignment = alignment,
                spurious = spurious
            )
        }
        if (families.any { it.contains("exposome") || it.contains("food") || it.contains("water") }) {
            routes += solutionRoute(
                id = "HET_EXPOSOME_PRESSURE_REDUCTION_OR_RESILIENCE",
                routeClass = "external_pressure_context_route",
                logic = "Treat exposure as a pressure modifier and look for barrier/metabolic/immune resilience routes rather than direct causal proof.",
                supportedBy = families,
                alignment = alignment,
                spurious = spurious
            )
        }
        rootCause.restorationRoutes.take(2).forEachIndexed { idx, route ->
            routes += solutionRoute(
                id = "HET_ROOT_CAUSE_${idx + 1}_${route.routeId}",
                routeClass = "root_cause_restoration_bridge",
                logic = route.restorationLogic,
                supportedBy = families + route.researchLevers.take(3),
                alignment = alignment,
                spurious = spurious
            )
        }
        rootCause.ecologicalRestoration?.restorationSequences?.take(2)?.forEachIndexed { idx, sequence ->
            routes += solutionRoute(
                id = "HET_ECO_RESTORATION_${idx + 1}_${sequence.collapseType.name}",
                routeClass = "ecological_restoration_lens_bridge",
                logic = "Treat observed symptoms/damage as a collapse pattern; map ${sequence.collapseType.name} to ${sequence.firstRepairFunction} and require recovery markers before upgrade.",
                supportedBy = families + listOf(sequence.collapseType.name, sequence.firstRepairFunction, "RECOVERY_PROXY_NOT_PROOF"),
                alignment = alignment,
                spurious = spurious
            )
        }
        rootCause.symptomOverlap?.restorativeRoutes?.take(2)?.forEachIndexed { idx, route ->
            routes += solutionRoute(
                id = "HET_SYMPTOM_OVERLAP_${idx + 1}_${route.dysfunctionClass}".take(110),
                routeClass = "symptom_overlap_repair_function_bridge",
                logic = "Symptoms are overlap signals; map ${route.dysfunctionClass} to repair-function search instead of naming one disease.",
                supportedBy = families + route.candidateRouteClasses.take(3) + "DISCRIMINATING_EVIDENCE_REQUIRED",
                alignment = alignment,
                spurious = spurious
            )
        }
        rootCause.microbialReversal?.candidateRoutes?.take(2)?.forEachIndexed { idx, candidate ->
            routes += solutionRoute(
                id = "HET_MICROBIAL_REVERSAL_${idx + 1}_${candidate.candidateId}".take(110),
                routeClass = "microbial_reversal_counter_function_bridge",
                logic = "Bridge heterogeneous evidence to microbial counter-function research: ${candidate.hypotheticalRole}",
                supportedBy = families + listOf(candidate.candidateClass, candidate.sourceFunctionId, candidate.evidenceRank),
                alignment = alignment,
                spurious = spurious
            )
        }
        rootCause.repairPriorityValidation?.rankedRepairFunctions?.take(2)?.forEachIndexed { idx, rank ->
            routes += solutionRoute(
                id = "HET_REPAIR_PRIORITY_${idx + 1}_${rank.rankId}".take(110),
                routeClass = "repair_priority_validation_bridge",
                logic = "Ranked repair-function route: ${rank.repairFunction}; biomarker/falsification plan required before any upgrade.",
                supportedBy = families + listOf(rank.priorityBand, "score=${rank.score}", rank.sourceLayer) + rank.candidateRouteClasses.take(2),
                alignment = alignment,
                spurious = spurious
            )
        }
        if (routes.isEmpty()) {
            routes += solutionRoute(
                id = "HET_OPEN_RESEARCH_ROUTE",
                routeClass = "open_heterogeneous_research_route",
                logic = "Keep the heterogeneous data link as an open research question and ask for mechanism/context evidence rather than blocking exploration.",
                supportedBy = families.ifEmpty { listOf("open_source_context_needed") },
                alignment = alignment,
                spurious = spurious
            )
        }
        return routes.distinctBy { it.routeId }.take(12)
    }

    private fun solutionRoute(
        id: String,
        routeClass: String,
        logic: String,
        supportedBy: List<String>,
        alignment: GTIMEvidenceAlignmentV2110,
        spurious: GTIMSpuriousCorrelationAssessmentV2110
    ): GTIMHeterogeneousSolutionRouteV2110 {
        val missing = spurious.requiredUpgradeEvidence.take(4)
        val output = when {
            spurious.riskLevel == "HIGH" -> "WEAK_SOLUTION_ROUTE_ALLOWED_RESEARCH_ONLY"
            alignment.score >= 55 -> "USABLE_SOLUTION_ROUTE_RESEARCH_ONLY"
            else -> "EXPLORATORY_SOLUTION_ROUTE_RESEARCH_ONLY"
        }
        val line = "Heterogeneous solution route: id=$id | class=$routeClass | output=$output | logic=${logic.oneLine()} | supported_by=${supportedBy.distinct().joinToString(";").oneLine()} | alignment=${alignment.alignmentLevel}:${alignment.score} | spurious=${spurious.riskLevel} | missing=${missing.joinToString(";").oneLine()}"
        return GTIMHeterogeneousSolutionRouteV2110(id, routeClass, logic, supportedBy.distinct().take(8), missing, output, line)
    }

    private fun capsule(id: String, family: String, kind: String, fields: List<String>, use: String, quality: String): GTIMSourceCapsuleV2110 {
        val line = "Source capsule: id=$id | family=$family | kind=$kind | quality=$quality | use=${use.oneLine()} | fields=${fields.joinToString(";").oneLine()}"
        return GTIMSourceCapsuleV2110(id, family, kind, fields, use, quality, line)
    }

    private fun corpus(
        contract: GTIMRunDecisionContractV2740,
        metadataBridge: GTIMMetadataFirstObservedEvidenceBridgeReportV2950?,
        dgeVerdict: GTIMDgeReadinessVerdictReportV2802,
        established: List<GTIMEstablishedEvidenceCardV2100>,
        discovery: List<GTIMDiscoveryFindingCardV2100>,
        mechanisms: List<GTIMMechanismAxisCardV2100>,
        rootCause: GTIMEcoImmuneRootCauseReportV2108
    ): String = listOf(
        contract.rawQuery,
        contract.normalizedQuery,
        contract.primaryAnchor.routeId,
        contract.diseaseFamily.name,
        contract.secondaryDomains.joinToString(" ") { it.name },
        contract.discoveryBridges.joinToString(" ") { it.routeId },
        contract.exploratoryRoutes.joinToString(" "),
        metadataBridge?.line.orEmpty(),
        metadataBridge?.softProbe?.line.orEmpty(),
        dgeVerdict.verdict,
        dgeVerdict.blockers.joinToString(" "),
        established.joinToString(" ") { it.statement + " " + it.topicArea },
        discovery.joinToString(" ") { it.finding + " " + it.requiredNextEvidence },
        mechanisms.joinToString(" ") { it.axisId + " " + it.mechanismChain },
        rootCause.line,
        rootCause.ecologicalRestoration?.line.orEmpty(),
        rootCause.ecologicalRestoration?.collapseSignals?.joinToString(" ") { it.collapseInterpretation + " " + it.requiredDiscriminators.joinToString(" ") }.orEmpty(),
        rootCause.symptomOverlap?.line.orEmpty(),
        rootCause.symptomOverlap?.dysfunctionHypotheses?.joinToString(" ") { it.dysfunctionClass + " " + it.mechanismLogic + " " + it.repairFunctions.joinToString(" ") }.orEmpty(),
        rootCause.repairPriorityValidation?.line.orEmpty(),
        rootCause.repairPriorityValidation?.rankedRepairFunctions?.joinToString(" ") { it.repairFunction + " " + it.priorityBand + " " + it.evidenceNeed.joinToString(" ") }.orEmpty(),
        rootCause.candidates.joinToString(" ") { it.causalChain + " " + it.restorationNeed + " " + it.contextModifiers.joinToString(" ") }
    ).joinToString(" ").lowercase()

    private fun containsAny(text: String, tokens: List<String>): Boolean = tokens.any { text.contains(it.lowercase()) }
    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
