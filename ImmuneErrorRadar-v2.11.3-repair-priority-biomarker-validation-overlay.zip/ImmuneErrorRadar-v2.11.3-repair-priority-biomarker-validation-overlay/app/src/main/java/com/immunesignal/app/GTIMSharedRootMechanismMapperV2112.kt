package com.immunesignal.app

// v2.11.2 — Finds shared mechanisms across disease families that speak the same symptom language.
object GTIMSharedRootMechanismMapperV2112 {
    const val VERSION: String = "2.11.2-shared-root-mechanism-mapper"

    fun map(hypotheses: List<GTIMDysfunctionHypothesisV2112>, families: List<String>): List<GTIMSharedRootMechanismV2112> {
        val allFamilies = families.ifEmpty { listOf("immune", "infectious", "metabolic", "microbiome", "environmental") }.distinct().take(6)
        return hypotheses.take(5).mapIndexed { index, h ->
            val target = when (h.dysfunctionClass) {
                "immune_overactivation" -> "immune decision threshold and tolerance restoration"
                "barrier_failure" -> "entry-surface boundary restoration"
                "microbial_ecosystem_imbalance" -> "lost microbial/metabolite function restoration"
                "metabolic_energy_stress" -> "host-microbial energy and repair-capacity restoration"
                "exposome_pressure" -> "pressure-source separation and resilience restoration"
                "neuroimmune_tissue_stress" -> "peripheral-to-tissue inflammatory bridge falsification"
                else -> "open shared dysfunction discriminator"
            }
            val shared = "${h.dysfunctionClass} can appear under multiple disease labels; treat it as a shared root-mechanism candidate until discriminators split it."
            val falsify = "falsify_if_discriminating_evidence_maps_symptoms_to_a_single_unrelated_structural_or_external_cause"
            val id = "SHARED_ROOT_${index + 1}_${h.dysfunctionClass}".take(96)
            val line = "Shared root mechanism: version=$VERSION | id=$id | families=${allFamilies.joinToString(";").oneLine()} | mechanism=${shared.oneLine()} | repair_target=${target.oneLine()} | falsification_need=$falsify"
            GTIMSharedRootMechanismV2112(id, allFamilies, shared, target, falsify, line)
        }
    }

    private fun String.oneLine(): String = replace(Regex("\\s+"), " ").trim()
}
