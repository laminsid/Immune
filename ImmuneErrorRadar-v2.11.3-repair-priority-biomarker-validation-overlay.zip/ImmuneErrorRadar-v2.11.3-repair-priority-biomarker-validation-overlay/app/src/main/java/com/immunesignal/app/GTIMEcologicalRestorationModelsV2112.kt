package com.immunesignal.app

// v2.11.2 — Ecological Restoration Model models.
// Converts the pond-restoration analogy into a bounded research lens: symptoms or
// visible damage are not proof. They are treated as system-collapse signals that
// require discriminating biomarkers, recovery markers, and causal tests.

enum class GTIMEcologicalCollapseTypeV2112 {
    ORGANIC_OVERLOAD,
    LOW_DIVERSITY,
    PATHOGEN_DOMINANCE,
    TOXIN_ACCUMULATION,
    BARRIER_FAILURE,
    IMMUNE_OVERACTIVATION,
    METABOLIC_STAGNATION,
    BIOFILM_OR_NICHE_LOCK,
    EXPOSOME_PRESSURE,
    NEUROIMMUNE_STRESS,
    UNKNOWN
}

data class GTIMEcologicalCollapseSignalV2112(
    val signalId: String,
    val collapseType: GTIMEcologicalCollapseTypeV2112,
    val triggerPattern: String,
    val collapseInterpretation: String,
    val requiredDiscriminators: List<String>,
    val claimLimit: String,
    val line: String
)

data class GTIMRestorationSequenceV2112(
    val sequenceId: String,
    val collapseType: GTIMEcologicalCollapseTypeV2112,
    val firstRepairFunction: String,
    val secondOrderEffect: String,
    val recoveryIndicators: List<String>,
    val failureSignals: List<String>,
    val microbialRole: String,
    val confidenceState: String,
    val line: String
)

data class GTIMEcologicalRestorationReportV2112(
    val active: Boolean,
    val version: String,
    val state: String,
    val principle: String,
    val collapseSignals: List<GTIMEcologicalCollapseSignalV2112>,
    val restorationSequences: List<GTIMRestorationSequenceV2112>,
    val recoveryMarkers: List<String>,
    val analogyGuard: String,
    val integrationState: String,
    val line: String,
    val boundaryLine: String
) {
    companion object {
        fun empty(): GTIMEcologicalRestorationReportV2112 = GTIMEcologicalRestorationReportV2112(
            active = false,
            version = GTIMEcologicalRestorationModelV2112.VERSION,
            state = "ECOLOGICAL_RESTORATION_NOT_EVALUATED",
            principle = GTIMEcologicalRestorationModelV2112.PRINCIPLE,
            collapseSignals = emptyList(),
            restorationSequences = emptyList(),
            recoveryMarkers = emptyList(),
            analogyGuard = GTIMEcologicalRestorationModelV2112.ANALOGY_GUARD,
            integrationState = "NOT_EVALUATED",
            line = "Ecological restoration model: not evaluated.",
            boundaryLine = GTIMEcologicalRestorationModelV2112.BOUNDARY
        )
    }
}
