#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(path, token, label):
    text = (ROOT / path).read_text(encoding='utf-8')
    if token not in text:
        errors.append(f"{label}: missing {token!r} in {path}")

for f in [
    'app/src/main/java/com/immunesignal/app/ResearchCyclePlanStage.kt',
    'app/src/test/java/com/immunesignal/app/ResearchCyclePlanStageTest.kt',
]:
    if not (ROOT / f).exists():
        errors.append(f'required file missing: {f}')

require('app/src/main/java/com/immunesignal/app/ResearchCyclePlanStage.kt', 'enforceSearchBudget', 'plan stage budget enforcement')
require('app/src/main/java/com/immunesignal/app/ResearchCyclePlanStage.kt', 'OFFLINE_DIRECTIVE_HAS_SELECTED_QUERIES', 'offline query violation warning')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'selectedSearchQueriesV206', 'autopilot uses selected bounded queries')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'cyclePlanStageReportV206', 'autopilot plan stage report')
require('app/src/main/java/com/immunesignal/app/ResearchModels.kt', 'cyclePlanStageReport', 'report field')
require('app/src/main/java/com/immunesignal/app/ResearchModels.kt', 'ResearchCyclePlanStage.toJson', 'json export')
require('app/src/main/java/com/immunesignal/app/ResearchModels.kt', '.put("schemaVersion", 206)', 'schema v206')
require('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt', 'Cycle plan stage v1.10.6', 'pdf export')
require('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt', 'ResearchCyclePlanStage', 'registry entry')
require('app/src/test/java/com/immunesignal/app/ResearchCyclePlanStageTest.kt', 'activeDirectiveKeepsOnlyAllowedQueryAfterRewrites', 'directive regression test')
require('app/build.gradle.kts', 'versionName = "1.10.6-alpha-plan-stage-extraction"', 'version name')
require('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt', 'v1.10.6-alpha-plan-stage-extraction', 'engine version')

# The network handoff must use the bounded list, not the raw query-feedback batch.
autopilot = (ROOT / 'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text(encoding='utf-8')
if 'runQueryBatch(queryFeedbackPlanV145.improvedQueries' in autopilot:
    errors.append('raw queryFeedbackPlanV145.improvedQueries still leaves PLAN into SEARCH')

if errors:
    print('Plan stage extraction v1.10.6 audit: FAIL')
    for e in errors:
        print(' -', e)
    sys.exit(1)
print('Plan stage extraction v1.10.6 audit: PASS')
