#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors = []

def require(path, token, label):
    text = (ROOT / path).read_text()
    if token not in text:
        errors.append(f"{label}: missing {token!r} in {path}")

require('app/src/main/java/com/immunesignal/app/ResearchCyclePhaseAudit.kt', 'ResearchCyclePhaseAuditEngine', 'phase audit engine')
require('app/src/main/java/com/immunesignal/app/ResearchCyclePhaseAudit.kt', 'RUNTIME_FAILOVER_RAN_DESPITE_ACTIVE_SEARCH_LOCK', 'failover violation token')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'unifiedSearchLockAfterForagerV204', 'same-cycle lock after forager')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', '!unifiedSearchLockAfterForagerV204', 'failover blocked by post-forager lock')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'cyclePhaseAuditReportV204', 'autopilot phase audit wiring')
require('app/src/main/java/com/immunesignal/app/ResearchModels.kt', 'cyclePhaseAuditReport', 'report field')
require('app/src/main/java/com/immunesignal/app/ResearchModels.kt', 'ResearchCyclePhaseAuditEngine.toJson', 'json export')
require('app/src/main/java/com/immunesignal/app/ResearchModels.kt', '.put("schemaVersion", 206)', 'schema version')
require('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt', 'ResearchCyclePhaseAuditEngine', 'runtime module registry')
require('app/src/test/java/com/immunesignal/app/ResearchCyclePhaseAuditTest.kt', 'blocksRuntimeFailoverUnderSameCycleClosureLock', 'regression test')
require('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt', 'Cycle phase audit v1.10.4', 'pdf export section')
require('app/build.gradle.kts', 'versionName = "1.10.6-alpha-plan-stage-extraction"', 'version name')
require('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt', 'v1.10.6-alpha-plan-stage-extraction', 'engine version')

if errors:
    print('Cycle phase audit v1.10.4 audit: FAIL')
    for e in errors:
        print('-', e)
    raise SystemExit(1)
print('Cycle phase audit v1.10.4 audit: PASS')
