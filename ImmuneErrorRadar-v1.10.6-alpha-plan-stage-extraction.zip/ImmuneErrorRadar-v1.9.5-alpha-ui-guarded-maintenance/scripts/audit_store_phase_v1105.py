#!/usr/bin/env python3
from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
checks = []

def require(path, needle, label):
    text = (root / path).read_text(encoding='utf-8')
    if needle not in text:
        checks.append(f"FAIL {label}: missing {needle!r} in {path}")

for file in [
    'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStoreFileOps.kt',
    'app/src/test/java/com/immunesignal/app/ResearchKnowledgeStoreFileOpsTest.kt',
    'app/src/main/java/com/immunesignal/app/ResearchCyclePhaseSpine.kt',
    'app/src/test/java/com/immunesignal/app/ResearchCyclePhaseSpineTest.kt',
]:
    if not (root / file).exists():
        checks.append(f"FAIL required file missing: {file}")

require('app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt', 'ResearchKnowledgeStoreFileOps.appendOnly', 'store delegates append')
require('app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt', 'ResearchKnowledgeStoreFileOps.trimFile', 'store delegates trim')
require('app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt', 'ResearchKnowledgeStoreFileOps.readLastValidJsonLines', 'store delegates readLast')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'phaseSpineReportV205', 'phase spine wired')
require('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt', 'v1.10.6-alpha-plan-stage-extraction', 'engine version')
require('app/build.gradle.kts', 'versionName = "1.10.6-alpha-plan-stage-extraction"', 'app version')
require('app/src/main/java/com/immunesignal/app/ResearchModels.kt', '.put("schemaVersion", 206)', 'schema')
require('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt', 'ResearchKnowledgeStoreFileOps', 'module registry file ops')
require('app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt', 'ResearchCyclePhaseSpine', 'module registry phase spine')

if checks:
    print('\n'.join(checks))
    sys.exit(1)
print('Store/phase hardening v1.10.5 audit: PASS')
