package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DatasetFirstForagerV140Test {
    @Test
    fun decomposesBroadMissionIntoTestableShards() {
        val shards = HypothesisDecomposer.decompose("Which public datasets can map trigger-response-outcome immune patterns?")
        assertTrue(shards.size >= 3)
        assertTrue(shards.any { it.shardId.contains("ALLERGY") })
        assertTrue(shards.all { it.evidenceQuestion.contains("Mission context") })
    }

    @Test
    fun datasetFirstRouterActivatesAfterNoDatasetFailure() {
        val recent = listOf("NO_DATASET_ACCESSION NO_EVIDENCE_OBJECT_NO_UPGRADE dataset candidates: 0")
        val active = DirectDatasetSourceRouter.shouldRunDatasetFirst(
            recentReports = recent,
            researchState = "RESEARCH_NORMAL",
            appliedPivot = PivotDecision.none(),
            memory = PersistentFailureMemorySnapshot.empty()
        )
        assertTrue(active)
    }


    @Test
    fun datasetFirstRouterNormalizesStateAndEvidenceFirstIntent() {
        val byState = DirectDatasetSourceRouter.shouldRunDatasetFirst(
            recentReports = emptyList(),
            researchState = " dataset_hunt ",
            appliedPivot = PivotDecision.none(),
            memory = PersistentFailureMemorySnapshot.empty()
        )
        val byEvidenceFirstIntent = DirectDatasetSourceRouter.shouldRunDatasetFirst(
            recentReports = listOf("EVIDENCE_FIRST_ACCESSION_SEARCH selected by dataset-hunt unlock"),
            researchState = "research_normal",
            appliedPivot = PivotDecision.none(),
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertTrue(byState)
        assertTrue(byEvidenceFirstIntent)
    }

    @Test
    fun routerKeepsCooldownEscapeWhenAllDirectFamiliesAreCoolingDown() {
        val memory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord("h1", "GEO_GDS", "NO_DATASET_ACCESSION", 2, 1L, 3, "SRA_PRJNA"),
                PersistentFailureRecord("h2", "SRA_PRJNA", "WRONG_VOCABULARY", 2, 1L, 3, "IMM_PORT_SDY"),
                PersistentFailureRecord("h3", "IMM_PORT_SDY", "NO_DATASET_ACCESSION", 2, 1L, 3, "PUBMED_ACCESSION_MINING"),
                PersistentFailureRecord("h4", "PUBMED_ACCESSION_MINING", "NO_DATASET_ACCESSION", 2, 1L, 3, "PUBMED_CONTRADICTION"),
                PersistentFailureRecord("h5", "PUBMED_CONTRADICTION", "NO_CONTRADICTION_SEARCH", 2, 1L, 3, "PUBMED_CONTROL"),
                PersistentFailureRecord("h6", "PUBMED_CONTROL", "NO_CONTROL_SIGNAL", 2, 1L, 3, "GEO_GDS")
            ),
            summary = "all direct routes are cooling down"
        )

        val routes = DirectDatasetSourceRouter.routes(memory)

        assertEquals(listOf("PUBMED_ACCESSION_MINING_COOLDOWN_ESCAPE"), routes.map { it.sourceFamily })
    }

    @Test
    fun compilerCreatesNarrowDatasetQueries() {
        val queries = DatasetQueryCompiler.compile(
            HypothesisDecomposer.decompose("baseline mission"),
            PersistentFailureMemorySnapshot.empty()
        )
        assertTrue(queries.isNotEmpty())
        assertTrue(queries.any { it.query.contains("GSE") || it.query.contains("RNA-seq") || it.query.contains("single-cell") })
        assertTrue(queries.none { it.label.contains("daily", ignoreCase = true) })
    }



    @Test
    fun compilerFallsBackToAccessionQueriesWhenNoShardSeedsSurvive() {
        val memory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord(
                    failedQueryHash = "h0",
                    sourceFamily = "broad_pubmed_mapping",
                    rootCause = "NO_DATASET_ACCESSION",
                    cooldownCyclesRemaining = 2,
                    lastAttemptedAtMillis = 1L,
                    timesFailed = 3,
                    forcedNextSource = "GEO_GDS"
                )
            ),
            summary = "force dataset fallback"
        )
        val queries = DatasetQueryCompiler.compile(
            shards = emptyList(),
            memory = memory
        )

        assertTrue(queries.isNotEmpty())
        assertTrue(queries.all { it.id.startsWith("q_v142_fallback_dataset_accession_") })
        assertTrue(queries.any { it.query.contains("GSE") || it.query.contains("PRJNA") || it.query.contains("SRA") })
        assertTrue(queries.all { it.query.contains("outcome", ignoreCase = true) || it.query.contains("severity", ignoreCase = true) })
    }



    @Test
    fun compilerBuildsSourceAwareQueriesForGeoAndSraRoutes() {
        val shards = HypothesisDecomposer.decompose("trigger response outcome immune mapping")
        val geoQueries = DatasetQueryCompiler.compileForRoute(
            route = DirectDatasetSourceRouter.SourceRoute(
                sourceFamily = "GEO_GDS",
                ncbiDb = "gds",
                priority = 100,
                reason = "test GEO"
            ),
            shards = shards,
            memory = PersistentFailureMemorySnapshot.empty()
        )
        val sraQueries = DatasetQueryCompiler.compileForRoute(
            route = DirectDatasetSourceRouter.SourceRoute(
                sourceFamily = "SRA_PRJNA",
                ncbiDb = "sra",
                priority = 90,
                reason = "test SRA"
            ),
            shards = shards,
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertTrue(geoQueries.isNotEmpty())
        assertTrue(sraQueries.isNotEmpty())
        assertTrue(geoQueries.any { it.query.contains("GSE") || it.query.contains("GDS") || it.query.contains("GEO") })
        assertTrue(sraQueries.any { it.query.contains("PRJNA") || it.query.contains("SRP") || it.query.contains("SRA") })
        assertTrue(geoQueries.all { it.id.startsWith("q_v142_geo_gds_") })
        assertTrue(sraQueries.all { it.id.startsWith("q_v142_sra_prjna_") })
    }

    @Test
    fun compilerBuildsContradictionAndControlQueriesForPubMedRoutes() {
        val shards = HypothesisDecomposer.decompose("trigger response outcome immune mapping")
        val contradictionQueries = DatasetQueryCompiler.compileForRoute(
            route = DirectDatasetSourceRouter.SourceRoute(
                sourceFamily = "PUBMED_CONTRADICTION",
                ncbiDb = "pubmed",
                priority = 60,
                reason = "test contradiction"
            ),
            shards = shards,
            memory = PersistentFailureMemorySnapshot.empty()
        )
        val controlQueries = DatasetQueryCompiler.compileForRoute(
            route = DirectDatasetSourceRouter.SourceRoute(
                sourceFamily = "PUBMED_CONTROL",
                ncbiDb = "pubmed",
                priority = 55,
                reason = "test control"
            ),
            shards = shards,
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertTrue(contradictionQueries.any { it.query.contains("nonresponse", ignoreCase = true) || it.query.contains("failed replication", ignoreCase = true) })
        assertTrue(controlQueries.any { it.query.contains("control", ignoreCase = true) || it.query.contains("comparator", ignoreCase = true) })
    }

    @Test
    fun foragingReportDefaultsAreSafe() {
        val report = DatasetForagingReport.empty()
        assertEquals("NOT_RUN", report.state)
        assertEquals(false, report.active)
    }

    @Test
    fun routerRotatesFromGeoNoCandidateToSraPrjna() {
        val memory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord(
                    failedQueryHash = "geo-no-candidate",
                    sourceFamily = "GEO_GDS",
                    rootCause = "NO_DATASET_ACCESSION+BROAD_QUERY",
                    cooldownCyclesRemaining = 3,
                    lastAttemptedAtMillis = 10L,
                    timesFailed = 1,
                    forcedNextSource = "SRA_PRJNA"
                )
            ),
            summary = "GEO returned no candidate; rotate to SRA_PRJNA"
        )

        val routes = DirectDatasetSourceRouter.routes(memory)

        assertEquals("SRA_PRJNA", routes.first().sourceFamily)
        assertTrue(routes.none { it.sourceFamily == "GEO_GDS" })
    }

    @Test
    fun noCandidateLearningRecordSerializesNextPreferredSource() {
        val report = DatasetForagingReport.empty().copy(
            active = true,
            state = "DATASET_FORAGING_NO_CANDIDATE",
            sourceFamiliesAttempted = listOf("GEO_GDS"),
            noCandidateLearningRecords = listOf(
                NoCandidateLearningRecord(
                    sourceFamily = "GEO_GDS",
                    queryId = "q_v142_geo_gds_source_0",
                    status = "SOURCE_SEARCH_NO_IDS",
                    missing = "accession_like_id",
                    nextPreferredSource = "SRA_PRJNA",
                    reason = "GEO_GDS returned no usable dataset candidate."
                )
            )
        )

        val json = DatasetForagingJson.reportToJson(report)
        val rec = json.optJSONArray("noCandidateLearningRecords")!!.optJSONObject(0)

        assertEquals("GEO_GDS", rec.optString("sourceFamily"))
        assertEquals("SRA_PRJNA", rec.optString("nextPreferredSource"))
    }

    @Test
    fun compilerBuildsImmPortAndAccessionMiningQueries() {
        val shards = HypothesisDecomposer.decompose("trigger response outcome immune mapping")
        val immPortQueries = DatasetQueryCompiler.compileForRoute(
            route = DirectDatasetSourceRouter.SourceRoute(
                sourceFamily = "IMM_PORT_SDY",
                ncbiDb = "pubmed",
                priority = 86,
                reason = "test ImmPort"
            ),
            shards = shards,
            memory = PersistentFailureMemorySnapshot.empty()
        )
        val accessionMiningQueries = DatasetQueryCompiler.compileForRoute(
            route = DirectDatasetSourceRouter.SourceRoute(
                sourceFamily = "PUBMED_ACCESSION_MINING",
                ncbiDb = "pubmed",
                priority = 74,
                reason = "test accession mining"
            ),
            shards = shards,
            memory = PersistentFailureMemorySnapshot.empty()
        )

        assertTrue(immPortQueries.any { it.query.contains("ImmPort", ignoreCase = true) || it.query.contains("SDY", ignoreCase = true) })
        assertTrue(accessionMiningQueries.any { it.query.contains("GSE", ignoreCase = true) || it.query.contains("PRJNA", ignoreCase = true) })
    }


    @Test
    fun queryFeedbackUsesNoCandidateLearningWhenNormalBatchIsEmpty() {
        val plan = QueryFeedbackPlanner.applyNoCandidateLearning(
            base = QueryFeedbackPlan.passthrough(emptyList(), "No query batch available for feedback."),
            records = listOf(
                NoCandidateLearningRecord(
                    sourceFamily = "GEO_GDS",
                    queryId = "q_v142_geo_gds_source_0",
                    status = "SOURCE_SEARCH_NO_IDS",
                    missing = "accession_like_id",
                    nextPreferredSource = "SRA_PRJNA",
                    reason = "GEO_GDS returned no usable dataset candidate."
                )
            )
        )

        assertTrue(plan.active)
        assertTrue(plan.summary.contains("SRA_PRJNA"))
        assertTrue(plan.improvements.any { it.original == "GEO_GDS" && it.improved == "SRA_PRJNA" })
    }

    @Test
    fun sourceRotationChainIsDeterministic() {
        assertEquals("SRA_PRJNA", DirectDatasetSourceRouter.nextSourceAfterNoCandidate("GEO_GDS"))
        assertEquals("IMM_PORT_SDY", DirectDatasetSourceRouter.nextSourceAfterNoCandidate("SRA_PRJNA"))
        assertEquals("PUBMED_ACCESSION_MINING", DirectDatasetSourceRouter.nextSourceAfterNoCandidate("IMM_PORT_SDY"))
        assertEquals("PUBMED_CONTRADICTION", DirectDatasetSourceRouter.nextSourceAfterNoCandidate("PUBMED_ACCESSION_MINING"))
    }


    @Test
    fun noCandidateSequenceAdvancesPastSourcesAlreadyTriedInSameCycle() {
        assertEquals(
            "IMM_PORT_SDY",
            DirectDatasetSourceRouter.nextSourceAfterNoCandidateSequence(listOf("GEO_GDS", "SRA_PRJNA"))
        )
        assertEquals(
            "PUBMED_CONTRADICTION",
            DirectDatasetSourceRouter.nextSourceAfterNoCandidateSequence(
                listOf("GEO_GDS", "SRA_PRJNA", "IMM_PORT_SDY", "PUBMED_ACCESSION_MINING")
            )
        )
        assertEquals(
            "GEO_GDS",
            DirectDatasetSourceRouter.nextSourceAfterNoCandidateSequence(
                listOf("GEO_GDS", "SRA_PRJNA", "IMM_PORT_SDY", "PUBMED_ACCESSION_MINING", "PUBMED_CONTRADICTION", "PUBMED_CONTROL")
            )
        )
    }


    @Test
    fun routerSkipsAllNoCandidateFamiliesPersistedFromSameCycle() {
        val memory = PersistentFailureMemorySnapshot(
            records = listOf(
                PersistentFailureRecord(
                    failedQueryHash = "geo-cycle-fail",
                    sourceFamily = "GEO_GDS",
                    rootCause = "NO_DATASET_ACCESSION+BROAD_QUERY",
                    cooldownCyclesRemaining = 5,
                    lastAttemptedAtMillis = 20L,
                    timesFailed = 1,
                    forcedNextSource = "IMM_PORT_SDY"
                ),
                PersistentFailureRecord(
                    failedQueryHash = "sra-cycle-fail",
                    sourceFamily = "SRA_PRJNA",
                    rootCause = "NO_DATASET_ACCESSION+BROAD_QUERY",
                    cooldownCyclesRemaining = 5,
                    lastAttemptedAtMillis = 21L,
                    timesFailed = 1,
                    forcedNextSource = "IMM_PORT_SDY"
                )
            ),
            summary = "GEO_GDS and SRA_PRJNA returned no candidate; rotate to IMM_PORT_SDY"
        )

        val routes = DirectDatasetSourceRouter.routes(memory)

        assertEquals("IMM_PORT_SDY", routes.first().sourceFamily)
        assertTrue(routes.none { it.sourceFamily == "GEO_GDS" })
        assertTrue(routes.none { it.sourceFamily == "SRA_PRJNA" })
    }

    @Test
    fun queryFeedbackSummarizesLastSequenceNextSource() {
        val plan = QueryFeedbackPlanner.applyNoCandidateLearning(
            base = QueryFeedbackPlan.passthrough(emptyList(), "No query batch available for feedback."),
            records = listOf(
                NoCandidateLearningRecord(
                    sourceFamily = "GEO_GDS",
                    queryId = "q_geo",
                    status = "SOURCE_SEARCH_NO_IDS",
                    missing = "accession_like_id",
                    nextPreferredSource = "SRA_PRJNA",
                    reason = "GEO_GDS returned no candidate."
                ),
                NoCandidateLearningRecord(
                    sourceFamily = "SRA_PRJNA",
                    queryId = "q_sra",
                    status = "SOURCE_SEARCH_NO_IDS",
                    missing = "accession_like_id",
                    nextPreferredSource = "IMM_PORT_SDY",
                    reason = "SRA_PRJNA returned no candidate."
                )
            )
        )

        assertTrue(plan.summary.contains("IMM_PORT_SDY"))
        assertTrue(plan.improvements.any { it.original == "SRA_PRJNA" && it.improved == "IMM_PORT_SDY" })
    }

}
