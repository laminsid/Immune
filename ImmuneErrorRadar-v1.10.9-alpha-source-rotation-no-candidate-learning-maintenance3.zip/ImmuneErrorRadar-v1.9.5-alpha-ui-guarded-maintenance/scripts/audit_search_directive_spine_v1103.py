#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
errors = []

def require(path, needle, label):
    text = (root / path).read_text(encoding='utf-8')
    if needle not in text:
        errors.append(f"{label}: missing {needle!r} in {path}")

require('app/src/main/java/com/immunesignal/app/ResearchSearchDirectiveResolver.kt', 'object ResearchSearchDirectiveResolver', 'resolver object')
require('app/src/main/java/com/immunesignal/app/ResearchSearchDirectiveResolver.kt', 'linked_cognition_spine', 'linked priority')
require('app/src/main/java/com/immunesignal/app/ResearchSearchDirectiveResolver.kt', 'evidence_closure', 'closure priority')
require('app/src/main/java/com/immunesignal/app/ResearchSearchDirectiveResolver.kt', 'cognitive_momentum', 'momentum priority')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'priorSearchDirectiveV203', 'autopilot prior resolver wiring')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'postForagerDirectiveV203', 'autopilot post-forager resolver wiring')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'datasetHuntUnlockDecisionV108.allowDatasetAccessionSearch', 'dataset-first unlock-aware lock wiring')
require('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt', 'v1.10.3 search directive resolver', 'learning note trace')
require('app/src/test/java/com/immunesignal/app/ResearchSearchDirectiveResolverTest.kt', 'linkedSpineOverridesClosureAndMomentum', 'resolver priority test')
require('app/build.gradle.kts', 'versionName = "1.10.8-alpha-dataset-hunt-unlock"', 'version name')
require('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt', 'v1.10.9-alpha-source-rotation-no-candidate-learning', 'engine version')
require('app/src/main/java/com/immunesignal/app/ResearchModels.kt', '.put("schemaVersion", 207)', 'schema version')

# Regression guard: the old split-lock conditions should not still control dataset-first or failover directly.
autopilot = (root / 'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text(encoding='utf-8')
for forbidden in [
    'val accessionClosureModeBeforePubMed',
    'priorLinkedSpineLockV200 || priorClosureLockV197 || priorMomentumLockV199',
    '!priorLinkedSpineLockV200 && !priorClosureLockV197 && !priorMomentumLockV199 && DirectDatasetSourceRouter.shouldRunDatasetFirst'
]:
    if forbidden in autopilot:
        errors.append(f'old split-lock logic remains: {forbidden}')

if errors:
    print('Search directive spine v1.10.3 audit: FAIL')
    for e in errors:
        print(' -', e)
    sys.exit(1)
print('Search directive spine v1.10.3/v1.10.8 audit: PASS')
