package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.12.10.1 — Final research value booster.
 *
 * Non-blocking replacement for the former quality-gate surface. The layer improves the
 * first-page research value and points to the best available next evidence route, but it
 * must never stop output generation, downgrade a useful lead, or upgrade evidence into
 * proof. Missing evidence becomes an upgrade checklist, not a failure state.
 */
object GTIMFinalResearchValueBoosterV212101 {
    const val VERSION: String = "2.12.10.1-final-research-value-booster"
    const val CLAIM_LIMIT: String = "value_booster_only_no_evidence_upgrade_no_blocking"

    data class ValueBooster(
        val status: String,
        val researchValue: String,
        val domainFit: String,
        val matrixCapsulePlan: String,
        val nextBestAction: String,
        val missingEvidenceToUpgrade: String,
        val firstSurfaceRule: String,
        val exportDecision: String,
        val claimLimit: String = CLAIM_LIMIT
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): ValueBooster {
        val selector = report.optJSONObject("domainSpecificHypothesisSelectorV2129")
            ?: GTIMDomainSpecificHypothesisSelectorV2129.toJson(report, technicalLines)
        val card = report.optJSONObject("studyResultCardV2126")
            ?: GTIMStudyResultCardV2126.toJson(report, technicalLines)
        val matrixStatus = report.optJSONObject("matrixShortcutStatusLayerV2129")
            ?: GTIMMatrixShortcutStatusLayerV2129.toJson(report, technicalLines)
        val consistency = GTIMReportConsistencyGateV2121.build(report, technicalLines)

        val domainKey = selector.optString("domainKey", "open_research_route")
        val toolClass = selector.optString("biologicalToolClass", "open_function_first_microbiome_or_postbiotic_route")
        val hypothesis = card.optString("topResearchHypothesis", "best available research hypothesis remains open and testable")
        val evidenceGrade = card.optString("evidenceGrade", card.optString("evidenceLevel", "D — useful study route; needs validation"))
        val matrixState = matrixStatus.optString("state", "MATRIX_SHORTCUT_REVIEW_ONLY_ROUTE_QUEUED")
        val routes = matrixStatus.optJSONArray("reviewTasks") ?: matrixStatus.optJSONArray("routes") ?: JSONArray()
        val hasMatrixCapsuleRoute = matrixState.isNotBlank() || routes.length() > 0

        val handleOrTopic = when {
            consistency.acceptedTarget.isNotBlank() -> consistency.acceptedTarget
            consistency.candidateLookupHandle.isNotBlank() -> consistency.candidateLookupHandle
            else -> GTIMStudyFocusNormalizerV21282.build(
                report.optString("topic", report.optString("researchTopic", report.optString("query", "current topic")))
            ).title
        }
        val action = card.optString("nextBestAction").ifBlank {
            matrixStatus.optString("nextAction").ifBlank {
                "Use Matrix Shortcut Resolver and External Router for $handleOrTopic; capture comparator labels, matrix/capsule status, and source-to-sample provenance."
            }
        }
        val domainFit = "domain_specific_route=$domainKey; repair_tool_class=$toolClass; hypothesis=${hypothesis.take(220)}"
        val matrixPlan = if (hasMatrixCapsuleRoute) {
            "matrix_shortcut_status=$matrixState; review_only_capsule_route=true; source_count=${routes.length()}"
        } else {
            "matrix_shortcut_status=queued; use GREIN/refine.bio/recount3/Expression Atlas/GEO2R before declaring matrix dead-end"
        }
        val readiness = when {
            consistency.topicCompatibleTargetSelected && consistency.verifiedMatrixFiles > 0 -> "research value status: review-only capsule candidate; validation still required"
            consistency.topicCompatibleTargetSelected || consistency.candidateLookupHandle.isNotBlank() -> "research value status: usable lead; needs validation"
            else -> "research value status: useful study route; needs dataset anchor"
        }
        val missing = listOf(
            "topic-fit confirmation",
            "matrix or processed-expression capsule",
            "comparator labels",
            "sample-to-source provenance",
            "reviewed expression/gene-list evidence if any",
            "independent contradiction check"
        ).joinToString("; ")
        return ValueBooster(
            status = readiness,
            researchValue = "Best available output preserved: $evidenceGrade + domain-specific hypothesis + repair function + matrix/capsule task + falsification plan.",
            domainFit = domainFit,
            matrixCapsulePlan = matrixPlan,
            nextBestAction = action,
            missingEvidenceToUpgrade = missing,
            firstSurfaceRule = "value_booster_first_surface; no_pass_fail_gate; technical_rails_appendix_only",
            exportDecision = "always_export_research_value_with_safety_boundary_not_blocking",
            claimLimit = CLAIM_LIMIT
        )
    }

    fun publicLines(report: JSONObject, technicalLines: List<String> = emptyList()): List<String> {
        val b = build(report, technicalLines)
        return listOf(
            "Final Research Value Booster",
            b.status,
            "Research value preserved: ${b.researchValue}",
            "Domain-specific fit: ${b.domainFit}",
            "Matrix/capsule plan: ${b.matrixCapsulePlan}",
            "Next best action: ${b.nextBestAction}",
            "Missing evidence to upgrade: ${b.missingEvidenceToUpgrade}",
            "Output rule: ${b.firstSurfaceRule}",
            "Export decision: ${b.exportDecision}",
            "Claim limit: ${b.claimLimit}"
        )
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val b = build(report, technicalLines)
        return JSONObject()
            .put("version", VERSION)
            .put("status", b.status)
            .put("researchValue", b.researchValue)
            .put("domainFit", b.domainFit)
            .put("matrixCapsulePlan", b.matrixCapsulePlan)
            .put("nextBestAction", b.nextBestAction)
            .put("missingEvidenceToUpgrade", b.missingEvidenceToUpgrade)
            .put("firstSurfaceRule", b.firstSurfaceRule)
            .put("exportDecision", b.exportDecision)
            .put("claimLimit", b.claimLimit)
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "Final Research Value Booster",
        "research value status: usable lead; needs validation",
        "research value status: useful study route; needs dataset anchor",
        "missing evidence to upgrade",
        "value_booster_first_surface; no_pass_fail_gate",
        CLAIM_LIMIT
    ))
}
