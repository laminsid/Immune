package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.12.8.2 — Study-focus normalizer.
 * Keeps the first page concise and prevents raw prompt truncation from looking like a broken paper title.
 */
object GTIMStudyFocusNormalizerV21282 {
    const val VERSION: String = "2.12.8.2-study-focus-normalizer"
    const val CLAIM_LIMIT: String = "display_title_only_no_evidence_upgrade"

    data class Focus(
        val title: String,
        val domain: String,
        val routeHint: String,
        val originalQueryPolicy: String
    )

    fun build(topic: String, route: String = "", reportText: String = ""): Focus {
        val raw = firstNonBlank(topic, route, reportText, "immune research question")
        val text = listOf(topic, route, reportText).joinToString(" ").lowercase(Locale.US)
        val domain = when {
            has(text, "pfas", "bpa", "phthalate", "microplastic", "plastic", "pollution", "particle", "toxin") -> "environmental-exposure immune/barrier study"
            has(text, "depress", "kynuren", "tryptophan", "neuroimmune") -> "depression microbiome-kynurenine inflammatory-tone study"
            has(text, "allerg", "ige", "mast", "eosinophil", "type-2", "type 2", "asthma", "eczema") -> "allergy/type-2 microbiome-barrier study"
            has(text, "covid", "sars", "corona", "hanta", "ebola", "filovirus", "viral", "virus", "interferon") -> "viral interferon-cytokine host-response study"
            has(text, "diabet", "insulin", "glucose", "metabolic") -> "metabolic inflammation immune-energy study"
            else -> "immune root-dysfunction study"
        }
        val routeHint = when (domain) {
            "environmental-exposure immune/barrier study" -> "exposure pressure → barrier stress → immune/endocrine inflammation → biosafety-bounded binding/resilience route"
            "depression microbiome-kynurenine inflammatory-tone study" -> "microbiome dysbiosis → tryptophan/kynurenine shift → IL-6/TNF tone → neuroimmune stress"
            "allergy/type-2 microbiome-barrier study" -> "barrier/tolerance dysfunction → IgE/mast/eosinophil type-2 threshold instability"
            "viral interferon-cytokine host-response study" -> "viral trigger → interferon timing → IL-6/TNF cytokine amplification → tissue stress"
            "metabolic inflammation immune-energy study" -> "metabolic stress → immune-energy mismatch → low-grade inflammatory amplification"
            else -> "mechanism-first route → dataset anchor → repair-function hypothesis"
        }
        return Focus(
            title = domain,
            domain = domain,
            routeHint = routeHint,
            originalQueryPolicy = "original_query_moved_to_appendix; first_page_uses_compact_study_focus"
        )
    }

    fun toJson(topic: String, route: String = "", reportText: String = ""): JSONObject {
        val f = build(topic, route, reportText)
        return JSONObject()
            .put("version", VERSION)
            .put("title", f.title)
            .put("domain", f.domain)
            .put("routeHint", f.routeHint)
            .put("originalQueryPolicy", f.originalQueryPolicy)
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "first_page_uses_compact_study_focus",
        "original_query_moved_to_appendix",
        CLAIM_LIMIT
    ))

    private fun has(text: String, vararg needles: String): Boolean = needles.any { text.contains(it, true) }
    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""
}
