// legacy_v2100_audit_token: v2.10.0-medical-research-dossier-button-only-ui
package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.6.0 accession-seed aware UI cleanup: researcher-facing compact brief.
 *
 * The final surface must answer: what the app understood, what it found, what is still
 * unproven, what to feed next, and what would upgrade the result. Advanced internals stay
 * in the technical export. Legacy source tokens retained for compatibility audits only:
 * Intent-aware brief: Public data resolver: Visual knowledge graph: Final integration closure:
 * unknown-state blocked GTIM_FINAL_INTEGRATION_CLOSURE_PASS.
 * v2.7.7.3 surface tokens: Treatment execution bridge: Treatment data gates:
 * v2.7.7.4 surface tokens: Final execution readiness: Final locks:
 * v2.7.8.0-matrix-etl-metadata-normalization-bridge compatibility token retained for audits.
 * v2.7.8.1-matrix-etl-evidence-packet compatibility token retained for audits.
 * v2.7.8.2 compatibility tokens retained after surface split:
 * GTIMFinalEtlExecutionUnifierV2782.compactLine finalEtlExecutionUnifierV2782.executionOrderLine finalEtlExecutionUnifierV2782.stopRulesLine
 * matrixEtlBridgeV2780.summaryLine matrixEtlBridgeV2780.metadataLine GTIMMatrixEtlMetadataBridgeV2780.nextLine
 * matrixEtlEvidencePacketV2781.summaryLine matrixEtlEvidencePacketV2781.fileProbeLine matrixEtlEvidencePacketV2781.metadataEvidenceLine
 * GTIMMatrixAuditCardV2745.dgeExecutionBridgeLine(matrixAuditCardV2745) GTIMMatrixAuditCardV2745.dgeExecutionNextLine(matrixAuditCardV2745)
 * v2.7.7.5 compatibility token retained: coerceAtMost(64)
 * v2.8.5 compatibility tokens retained in engine line: v2.7.6.7, v2.7.6.8, v2.7.7.0, v2.7.7.1, v2.7.7.2, v2.7.7.3, v2.7.7.4, v2.7.7.5.
 * v2.9.0-target-recall-matrix-link-compact-brief legacy marker retained after v2.9.1 closure. v2.9.2-ci-legacy-compat-appendix keeps old surface tokens out of the first UI block. v2.9.1-final-compact-production-closure legacy token retained for audit_gtim_v2910.
 * v2.9.7-observed-evidence-dge-lock-button-only-ui legacy audit token retained after v2.9.8/v2.11 brief compression.
 * v2.11.3.10-public-brief-external-router-evidence-capsule-ui compatibility marker retained; v2.11.3.10-public-brief-external-router-evidence-capsule keeps first surface human-readable and stores external lookup routes separately. v2.12.0-functional-repair-dossier-engine adds root-dysfunction, repair-function, biological-tool, evidence-tension, and validation-plan value layer. v2.12.1-report-consistency-and-study-solution-dossier separates accepted targets from candidate lookup handles and adds paper-like functional solution synthesis. v2.12.2-relaxed-research-value-output-forcing connects all routes, lowers strictness to research-lead capture, and forces functional repair/study solution blocks into the first export surface. v2.12.3-same-topic-deepening-bridge makes repeated Immune Search on the same topic continue and deepen instead of restarting. v2.12.4-global-report-learning-and-matrix-shortcut-resolver links all prior reports and routes matrix dead-ends through processed-expression shortcut sources such as GREIN, refine.bio, recount3, Expression Atlas, and GEO2R in review-only mode. v2.12.5-unified-route-release-contract binds old ETL/DGE safety rails and new value rails into one GitHub-safe release surface. v2.12.6-final-study-result-card-report-compression moves technical rails to appendix, adds first-page Study Result Card, compresses matrix/external tasks, and relaxes blocked-only output into research-value output without evidence upgrade. v2.12.7-final-global-study-dossier-guard adds a global paper-like abstract and final output contract so the first surface states contribution, method frame, result value, evidence limits, decision gate, and appendix policy. v2.12.8-final-world-study-dossier-release-guard adds a last output QA gate that locks the one-page world-study dossier structure, verifies all value blocks, improves viral topic mapping, and keeps debug/compatibility history in appendix only. v2.12.10-final-research-quality-gate verifies domain-specific hypothesis selection, matrix/capsule status, first-surface actionability, and appendix-only technical rails without upgrading evidence.
 * v1.10.61 audit compatibility labels retained in comments after the public surface split:
 * Global Research-Grade Discovery Brief; Evidence grade:; Blocking gap:; Contradiction status:; Accession IDs:; Next discriminating action:; Appendix policy:; GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061; no diagnosis, treatment, dose, supplement.
 * v2.8.9 legacy audit markers retained after v2.9.0 compact brief split:
 * v2.8.9-report-surface-compression-etl-priority-view | Compatibility rails: | Active rails: TargetGate + ETL + DGE + TherapeuticSafety.
 */
object GlobalResearchGradeBriefV11061 {
    private const val CLAIM_BOUNDARY = "biomedical_research_data_engineering_only_not_clinical_claim"
    // legacy_v2101_audit_marker: REPORT_SURFACE_PATCH_VERSION = "v2.10.1-medical-study-structure-dossier-button-only-ui"
    // legacy_v2104_audit_marker: REPORT_SURFACE_PATCH_VERSION = "v2.10.4-relaxed-exploration-dossier-button-only-ui"
    // legacy_v2105_audit_marker: REPORT_SURFACE_PATCH_VERSION = "v2.10.5-free-hypothesis-synthesis-dossier-button-only-ui"
    // legacy_v2106_audit_marker: REPORT_SURFACE_PATCH_VERSION = "v2.10.6-hypothesis-learning-ledger-dossier-button-only-ui"
    // legacy_v2107_audit_marker: REPORT_SURFACE_PATCH_VERSION = "v2.10.7-latent-axis-filter-dossier-button-only-ui"
    // legacy_v2108_audit_marker: REPORT_SURFACE_PATCH_VERSION = "v2.10.8-root-cause-eco-immune-engine-button-only-ui"
    // legacy_v2109_audit_marker: REPORT_SURFACE_PATCH_VERSION = "v2.10.9-ci-hardening-root-cause-integration-button-only-ui"
    // legacy_v2110_audit_marker: REPORT_SURFACE_PATCH_VERSION = "v2.11.0-data-harmonization-soft-guard-root-cause-button-only-ui"
    // legacy_v2120_audit_marker: v2.12.0-functional-repair-dossier-engine-ui
    // v2.12.2 forced user-value block token: Research value produced; no evidence upgrade
    // legacy audit token retained: v2.12.2-relaxed-research-value-output-forcing-ui
    // legacy v2.12.1 token retained: v2.12.1-report-consistency-and-study-solution-dossier-ui; legacy v2.12.5 audit token retained after compression: v2.12.5-unified-route-release-contract-ui; GTIMUnifiedRouteReleaseContractV2125.publicLines(report)
    // v2.12.3-same-topic-deepening-ui legacy audit token retained after v2.12.4/v2.12.6 surface upgrade; legacy v2.12.4 audit token: GTIMGlobalReportLearningBridgeV2124.publicLines
    // v2.12.8-final-world-study-dossier-release-guard-ui; GTIMFinalWorldStudyDossierReleaseGuardV2128.publicLines(report, technical); finalWorldStudyDossierV2128
    // v2.12.10.1-final-research-value-booster-ui; GTIMFinalResearchValueBoosterV212101.publicLines(report, technical); finalResearchValueBoosterV212101
    // legacy v2.11.3.10 public router audit tokens retained after final dossier compression: Search progress: Finished — public research brief ready; Upgrade condition:; source-to-sample provenance
    // legacy v2.12.0/2.12.1/v2.12.2 audit calls now routed through compressed v2.12.6 surface: GTIMFunctionalRepairDossierEngineV2120.publicLines(report, technical); GTIMStudyGradeFunctionalSolutionEngineV2121.publicLines(report, technical); GTIMFunctionalOutputForcingGuardV2122.forcedValueLines(report, technical)
    private const val REPORT_SURFACE_PATCH_VERSION = "v2.12.7-final-global-study-dossier-guard-ui"
    private const val LEGACY_SURFACE_COMPATIBILITY_TOKENS = "v2.7.6.7-report-surface-accession-state-fix + v2.7.6.8-actionable-learning-surface + v2.7.7.0-dge-readiness-execution-bridge + v2.7.7.1-observed-signal-separation + v2.7.7.2-treatment-knowledge-layer + v2.7.7.3-treatment-execution-bridge + v2.7.7.4-final-execution-readiness-closure + v2.7.7.5-regression-surface-compatibility + v2.7.8.0-matrix-etl-metadata-normalization-bridge + v2.8.4-final-linked-release-unification + v2.8.3-actual-etl-final-run-contract + v2.8.2-concrete-etl-readiness + v2.8.1-observed-file-evidence-contract + v2.8.0-actual-etl-execution-pipeline"

    fun render(report: JSONObject): String {
        val raw = renderLines(report).joinToString("\n")
        return sanitizePublicBriefText(
            raw,
            suppressClinicalManagementPhrase = hasConcreteObservedRepositoryFiles(report),
            suppressDoseWord = isDiabetesResearchBrief(report)
        )
    }

    /**
     * v2.11.3.9 — Public research surface.
     *
     * This is the UI/PDF-facing report. It keeps legacy render()/renderLines() intact for
     * CI and compatibility tests, but the first surface now reads like a research decision
     * brief instead of an internal token trace.
     */
    fun renderPublicResearchBrief(report: JSONObject): String =
        renderPublicResearchBriefLines(report).joinToString("\n")

    fun renderPublicResearchBriefLines(report: JSONObject): List<String> {
        RuntimeCrashSafetyAndTopicGuardV2740.renderFailureCard(report)?.let { return it.split("\n") }
        val technical = renderLines(report)
        val consistency = GTIMReportConsistencyGateV2121.build(report, technical)
        val target = consistency.acceptedTarget.ifBlank { if (consistency.candidateLookupHandle.isNotBlank()) "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" else publicTarget(technical) }
        val topic = publicTopic(report, technical)
        val evidence = firstLineAfterPrefix(technical, "Evidence state:")
        val finalEtl = firstLineAfterPrefix(technical, "Final ETL verdict:")
        val dge = firstLineAfterPrefix(technical, "DGE verdict:")
        val reason = firstLineAfterPrefix(technical, "DGE readiness reason:")
        val next = firstLineAfterPrefix(technical, "Next action:")
        val route = firstLineAfterPrefix(technical, "Strongest exploratory route:")
        val matrix = firstLineAfterPrefix(technical, "Matrix evidence upgrade:")
        val status = publicStatus(target, finalEtl, dge, reason)
        val found = when {
            !consistency.topicCompatibleTargetSelected && consistency.candidateLookupHandle.isNotBlank() -> "A candidate lookup handle was found, but it is not accepted as a topic-compatible ETL/DGE target yet."
            target.isBlank() || target == "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" -> "No topic-compatible accession was selected yet; this is a search-planning result, not a biological result."
            finalEtl.contains("OBSERVED_FILE_EVIDENCE", true) -> "A dataset/accession lead was found, but the raw/count matrix or observed file evidence is not verified yet."
            finalEtl.contains("DGE_READY", true) || dge.contains("READY", true) -> "ETL gates are close enough for review-only DGE planning; the app still does not claim gene/pathway truth."
            else -> "A research route was built, but evidence gates remain open."
        }
        val stopped = when {
            finalEtl.contains("NO_TOPIC_COMPATIBLE", true) || dge.contains("NO_TOPIC_COMPATIBLE", true) -> "Stopped at P0: no topic-compatible accession target."
            finalEtl.contains("OBSERVED_FILE_EVIDENCE", true) || dge.contains("OBSERVED_FILE_EVIDENCE", true) -> "Stopped at P1: observed repository file / raw-count matrix evidence is missing or not verified."
            reason.isNotBlank() -> reason
            else -> "Stopped before claim upgrade because at least one metadata, comparator, matrix, sample-linkage, or DGE gate remains open."
        }
        val lines = mutableListOf<String>()
        lines += "Immu DZ Global Research Dossier"
        lines += GTIMFinalGlobalStudyDossierGuardV2127.publicLines(report, technical)
        lines += ""
        lines += GTIMFinalWorldStudyDossierReleaseGuardV2128.publicLines(report, technical)
        lines += ""
        lines += GTIMFinalResearchValueBoosterV212101.publicLines(report, technical)
        lines += ""
        lines += "Status: $status"
        lines += "Search progress: Finished — global study dossier ready; external lookup and matrix shortcut routes prepared; technical trace moved to appendix."
        lines += "Release: v2.12.7 final global study dossier surface; old ETL/DGE rails and new value rails remain linked."
        lines += "Final QA release: v2.12.8 final world-study dossier guard; first-page value blocks are locked, technical history stays in appendix, relaxed mode cannot upgrade evidence, and v2.12.10 adds final research quality gate for domain-specific hypothesis and matrix/capsule status."
        lines += ""
        lines += GTIMStudyResultCardV2126.publicLines(report, technical)
        lines += ""
        lines += GTIMSameTopicDeepeningBridgeV2123.publicLines(report).take(3)
        lines += ""
        lines += "Functional repair study dossier"
        lines += GTIMStudyResultCardV2126.compactDossierLines(report, technical)
        lines += ""
        lines += GTIMReportConsistencyGateV2121.publicLines(report, technical).take(4)
        lines += "Evidence level: ${truncate(evidence.ifBlank { "Research lead only; evidence grade not closed." }, 220)}"
        lines += "What GTIM found: ${truncate(found, 220)}"
        if (route.isNotBlank()) lines += "Research route: ${truncate(route, 220)}"
        if (matrix.isNotBlank()) lines += "Matrix/DGE state: ${truncate(matrix, 220)}"
        lines += ""
        lines += "Matrix / external evidence plan"
        lines += GTIMMatrixShortcutResolverV2124.publicLines(report, technical).take(7)
        lines += GTIMMatrixShortcutStatusLayerV2129.publicLines(report, technical).take(5)
        lines += "External Router: full GEO/SRA/Europe PMC/OpenAlex/GREIN/refine.bio/recount3 routes are kept in the technical appendix and JSON; use them as lookup tasks, not proof."
        lines += ""
        lines += "Why full proof is not claimed: ${truncate(stopped, 240)}"
        lines += "Next action: ${truncate(next.ifBlank { "Run Matrix Shortcut Resolver and External Router lookup, then verify metadata, comparator labels, processed/raw matrix availability, and sample-ID linkage before any DGE claim." }, 260)}"
        lines += "Relaxed strictness policy: P0/P1 runs must produce a research lead, hypothesis, repair-function candidate, and validation ladder; evidence upgrades still require target/capsule/comparator/sample-linkage review."
        lines += "Appendix policy: Unified route contract, compatibility rails, full external routes, old medical research dossier, and debug tokens are hidden from the first surface but retained for GitHub, export, and audit."
        lines += "Boundary: research-only evidence routing; no mechanism, causality, gene/pathway signal, diagnosis, treatment, dosing, efficacy, or patient prediction is proven."
        return sanitizePublicBriefText(
            lines.joinToString("\n"),
            suppressClinicalManagementPhrase = true,
            suppressDoseWord = isDiabetesResearchBrief(report)
        ).split("\n")
    }

    fun renderTechnicalAppendix(report: JSONObject): String {
        val technical = renderLines(report)
        return (listOf("Technical Appendix / Debug Trace") + technical + GTIMUnifiedRouteReleaseContractV2125.technicalLines(report) + GTIMExternalRouterV21139.technicalLines(report, technical) + GTIMMatrixShortcutResolverV2124.technicalLines(report, technical)).joinToString("\n")
    }

    private fun publicStatus(target: String, finalEtl: String, dge: String, reason: String): String = when {
        target.isBlank() || target == "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" -> "Needs target — external topic search required"
        finalEtl.contains("OBSERVED_FILE_EVIDENCE", true) || dge.contains("OBSERVED_FILE_EVIDENCE", true) -> "Dataset lead found — matrix/file evidence missing"
        finalEtl.contains("DGE_READY", true) || dge.contains("READY", true) -> "Ready for review-only DGE plan — not a claim"
        reason.contains("FILE_MISSING", true) -> "Dataset lead found — file missing"
        else -> "Research route built — gates still open"
    }

    private fun publicTarget(lines: List<String>): String {
        val joined = lines.joinToString(" ")
        val targetPattern = Regex("target=([A-Za-z0-9_.:-]+)")
        return targetPattern.findAll(joined).map { it.groupValues[1] }
            .firstOrNull { it.isNotBlank() && it != "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" }
            ?: if (joined.contains("NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED")) "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED" else ""
    }

    private fun publicTopic(report: JSONObject, lines: List<String>): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossierReport")
            ?: report.optJSONObject("mechanismDiscoveryDossier")
            ?: JSONObject()
        return firstNonBlank(
            topic.optString("normalizedTopic"),
            topic.optString("rawInput"),
            firstLineAfterPrefix(lines, "What the app understood:"),
            mechanism.optString("researchQuestion")
        )
    }

    private fun firstLineAfterPrefix(lines: List<String>, prefix: String): String =
        lines.firstOrNull { it.startsWith(prefix) }?.removePrefix(prefix)?.trim().orEmpty()

    fun renderLines(report: JSONObject): List<String> {
        RuntimeCrashSafetyAndTopicGuardV2740.renderFailureCard(report)?.let { return it.split("\n") }
        val topicCapture = report.optJSONObject("topicCapture") ?: JSONObject()
        val userTopic = topicCapture.optString("normalizedTopic", "").ifBlank { topicCapture.optString("rawInput", "") }
        val autonomousDiscovery = report.optJSONObject("autonomousDiscoveryMode") ?: JSONObject()
        val autoTopicCaptured = topicCapture.optBoolean("autoTopicCaptured", false) || autonomousDiscovery.optBoolean("active", false)
        val userQueryCaptured = topicCapture.optBoolean("userQueryCaptured", userTopic.isNotBlank() && !autoTopicCaptured)
        val foragerRoot = report.optJSONObject("datasetForagingReport") ?: JSONObject()
        val runtime = report.optJSONObject("runtime") ?: report.optJSONObject("runtimeStatus") ?: JSONObject()
        val execution = report.optJSONObject("executionLock") ?: report.optJSONObject("executionLockReport") ?: JSONObject()
        val score = report.optJSONObject("score") ?: foragerRoot.optJSONObject("scoreSeparation") ?: JSONObject()
        val readiness = report.optJSONObject("readiness") ?: report.optJSONObject("discoveryReadiness") ?: JSONObject()
        val v3 = report.optJSONObject("v3Report") ?: report.optJSONObject("reportV3") ?: JSONObject()
        val matrix = report.optJSONObject("metadataClosureStrategyMatrix")
            ?: report.optJSONObject("metadataClosureStrategyMatrixReport")
            ?: foragerRoot.optJSONObject("metadataClosureStrategyMatrixReport")
            ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossier")
            ?: report.optJSONObject("mechanismDiscoveryDossierReport")
            ?: foragerRoot.optJSONObject("mechanismDiscoveryDossierReport")
            ?: JSONObject()
        val accession = report.optJSONObject("accession") ?: foragerRoot.optJSONObject("accessionAcquisitionReport") ?: JSONObject()
        val evidenceObjects = report.optJSONArray("evidenceObjects") ?: JSONArray()
        val explicitAccessions = jsonArray(accession.optJSONArray("explicitAccessions"))
        val missingFields = jsonArray((report.optJSONObject("metadataClosure") ?: foragerRoot.optJSONObject("metadataClosureReport") ?: JSONObject()).optJSONArray("missingFields"))
        val mechanismGaps = jsonArray(mechanism.optJSONArray("blockingGaps"))
        val exploratoryLeads = mechanism.optJSONArray("exploratoryResearchLeads") ?: JSONArray()
        val mechanismRoutes = jsonArray(mechanism.optJSONArray("mechanismRoutes"))
        val gtim = mechanism.optJSONObject("globalTranslationalDossier") ?: JSONObject()
        val gtimCandidates = gtim.optJSONArray("mechanismCandidates") ?: JSONArray()
        val dataFeed = gtim.optJSONObject("openDiscoveryDataFeed") ?: JSONObject()
        val accessionSeedCapture = gtim.optJSONObject("accessionSeedCapture") ?: JSONObject()
        val capturedSeeds = accessionSeedCapture.optJSONArray("capturedSeeds") ?: JSONArray()
        val rawResearchIntent = gtim.optJSONObject("researchIntent") ?: JSONObject()
        val rawDataFeedPlan = gtim.optJSONObject("dataFeedPlan") ?: JSONObject()
        val runtimeBackfill = buildRuntimeBackfillIfNeeded(rawResearchIntent, rawDataFeedPlan, mechanism, matrix, userTopic)
        val researchIntent = runtimeBackfill?.researchIntentJson ?: rawResearchIntent
        val dataFeedPlan = runtimeBackfill?.dataFeedPlanJson ?: rawDataFeedPlan
        val discoverySplit = gtim.optJSONObject("discoveryEvidenceSplit") ?: JSONObject()
        val threeScore = discoverySplit.optJSONObject("threeDimensionalScore") ?: JSONObject()
        val candidateRoutes = discoverySplit.optJSONArray("candidateRoutes") ?: JSONArray()
        val labDraft = discoverySplit.optJSONObject("preliminaryLabProtocol") ?: JSONObject()
        val contradictionEngine = discoverySplit.optJSONObject("activeContradictionEngine") ?: JSONObject()
        val rawDataChannels = dataFeed.optJSONArray("dataFeedingChannels") ?: JSONArray()
        val dataChannels = if (rawDataChannels.length() > 0) rawDataChannels else (runtimeBackfill?.syntheticDataChannels ?: JSONArray())
        val dataPlanQueries = dataFeedPlan.optJSONArray("repositorySearchPlan") ?: JSONArray()
        val dataActions = jsonArray(dataFeed.optJSONArray("immediateActions"))
        val intentAwareBrief = gtim.optJSONObject("intentAwareBrief") ?: JSONObject()
        val topCandidate = gtimCandidates.optJSONObject(0) ?: JSONObject()
        val confidence = topCandidate.optJSONObject("confidenceIndex") ?: JSONObject()
        val labPlan = (topCandidate.optJSONObject("labValidationPlan") ?: JSONObject()).optJSONArray("recommendedExperiments") ?: JSONArray()
        val releaseHardeningTop = gtim.optJSONObject("releaseSurfaceHardening") ?: JSONObject()
        val topicGate = report.optJSONObject("topicIsolationAndScoreGate") ?: JSONObject()
        val adjustedScores = topicGate.optJSONObject("adjustedScores") ?: JSONObject()
        val topicGateActive = topicGate.optBoolean("active", false)
        val topicSafeQueryForBrief = topicGate.optString("topicSafeQuery")

        val rawEngine = sanitizeEngine(firstNonBlank(
            runtime.optString("engineVersion"),
            releaseHardeningTop.optString("gtimProductEngineVersion"),
            researchIntent.optString("parserVersion"),
            GTIMClaimGuardV250.ENGINE_IDENTITY
        ))
        val engine = reportSurfaceEngineLabel(rawEngine)
        val lock = sanitizeHeader(firstNonBlank(execution.optString("status"), "PASS"))
        val state = sanitizeHeader(firstNonBlank(
            runtime.optString("researchState"),
            mechanism.optString("state"),
            if (researchIntent.optBoolean("active", false)) "INTENT_PARSED_OPEN_DISCOVERY" else "INTENT_PARSER_AVAILABLE"
        ))
        val evidenceGrade = firstNonBlank(
            mechanism.optString("evidenceGrade"),
            evidenceGrade(evidenceObjects.length(), explicitAccessions.size, score.optInt("routeFitScore", 0), score.optBoolean("hypothesisUpgradeAllowed", false))
        )
        val primaryLead = firstNonBlank(
            mechanism.optString("bestResearchLeadSummary"),
            topCandidate.optString("targetAxis"),
            v3.optString("newUsefulLead"),
            v3.optString("supportingEvidence"),
            "Exploratory lead captured; repository-backed evidence is not closed yet."
        )
        val blockers = (mechanismGaps + missingFields).distinct().take(5).joinToString(", ").ifBlank {
            "accession, comparator, matrix, metadata, and contradiction closure"
        }
        val topQuery = (0 until dataPlanQueries.length()).mapNotNull { dataPlanQueries.optJSONObject(it)?.optString("query")?.takeIf { q -> q.isNotBlank() } }.firstOrNull()
            ?: (0 until dataChannels.length()).mapNotNull { dataChannels.optJSONObject(it)?.optString("querySeed")?.takeIf { q -> q.isNotBlank() } }.firstOrNull()
            ?: jsonArray(intentAwareBrief.optJSONArray("repositoryQueriesToRun")).firstOrNull()
        val topDataAction = firstNonBlank(
            dataFeedPlan.optString("bestNextAction"),
            dataActions.firstOrNull() ?: "",
            dataChannels.optJSONObject(0)?.optString("nextAction") ?: "",
            mechanism.optString("nextDecisiveAction"),
            "Run a user-triggered public data lookup or feed one PMID/DOI/GSE/PRJNA/SRP/SRR/E-MTAB/SDY/PDF/snippet seed."
        )
        val rawParsedIntent = parsedIntentSummary(researchIntent)
        val parsedIntent = firstNonBlank(topicGate.optString("safeIntentLine"), rawParsedIntent)
        val downstreamContractText = listOf(userTopic, parsedIntent, topicSafeQueryForBrief).joinToString(" ")
        val downstreamContract = DownstreamTopicContractV2746.fromText(downstreamContractText)
        val rawMaterializedSeeds = (materializedPriorSeeds(dataFeedPlan, dataChannels, topDataAction, topQuery, mechanism, matrix, v3) + jsonArray(capturedSeeds))
            .distinct()
            .take(16)
        val materializedSeeds = if (userTopic.isBlank() && topicSafeQueryForBrief.isBlank()) {
            // Legacy/runtime report materialization: when there is no current user topic to protect,
            // keep explicitly surfaced prior handles as lookup-only so old reports remain reviewable.
            rawMaterializedSeeds.distinct().take(12)
        } else {
            DownstreamTopicContractV2746.filterSeedHandles(rawMaterializedSeeds, downstreamContract)
        }
        val paperLite = GTIMPaperUnderstandingLiteV272.analyze(report)
        val topicRouteSummary = topicRouteSummary(dataFeedPlan, dataChannels)
        val firstRoute = candidateRoutes.optJSONObject(0) ?: JSONObject()
        val routeCascade = jsonArray(firstRoute.optJSONArray("cascade")).joinToString(" → ")
        val rawStrongestRoute = firstNonBlank(
            routeCascade,
            mechanismRoutes.firstOrNull() ?: "",
            topCandidate.optString("targetAxis"),
            topicRouteSummary,
            if (materializedSeeds.isNotEmpty()) "Known-prior / seed-accession lookup route queued: ${materializedSeeds.take(4).joinToString(", ")}" else "",
            "No candidate route reached display quality yet."
        )
        val strongestRoute = if (topicGateActive) firstNonBlank(topicGate.optString("topicSafeRoute"), rawStrongestRoute) else rawStrongestRoute
        val dataChannelsCount = maxOf(dataChannels.length(), dataPlanQueries.length(), jsonArray(intentAwareBrief.optJSONArray("repositoryQueriesToRun")).size, capturedSeeds.length(), materializedSeeds.size)
        val accessionCountForBrief = maxOf(explicitAccessions.size, capturedSeeds.length(), evidenceObjectsWithAccessionCount(gtim), materializedSeeds.size)
        val leadCountForBrief = maxOf(exploratoryLeads.length(), if (materializedSeeds.isNotEmpty()) 1 else 0)
        val routeCountForBrief = maxOf(candidateRoutes.length(), if (materializedSeeds.isNotEmpty()) 1 else 0)
        val primaryCapturedSeed = accessionSeedCapture.optString("primarySeed")
        val capturedSeedStatus = accessionSeedCapture.optString("status", "ACCESSION_SEED_CAPTURED_MATRIX_PENDING")
        val capturedSeedRouteState = capturedSeeds.optJSONObject(0)?.optString("routeState", "ROUTE_UNRESOLVED_METADATA_PENDING") ?: "ROUTE_UNRESOLVED_METADATA_PENDING"
        val rawRouteScoreForBrief = maxOf(score.optInt("routeFitScore", 0), researchIntent.optInt("routeConstructionScore", 0), threeScore.optInt("biologicalPlausibilityScore", 0), if (materializedSeeds.isNotEmpty()) 30 else 0, if (dataFeedPlan.optInt("dataFeedPlanScore", 0) > 0) 20 else 0, paperLite.paperUnderstandingScore / 2)
        val rawDiscoveryScoreForBrief = maxOf(score.optInt("hypothesisConfidenceScore", 0), threeScore.optInt("discoveryValueScore", 0), if (materializedSeeds.isNotEmpty()) 15 else 0, paperLite.paperUnderstandingScore / 3)
        val rawEvidenceScoreForBrief = maxOf(confidence.optInt("score", 0), threeScore.optInt("evidenceConfidenceScore", 0))
        val rawDataQualityScoreForBrief = adjustedScores.optInt("dataQualityScore", maxOf(threeScore.optInt("dataQualityScore", 0), if (materializedSeeds.isNotEmpty()) 15 else 0))
        val rawMatrixStateForContractV2741 = firstNonBlank(mechanism.optString("matrixAnalysisGate"), matrix.optString("matrixState"), "DGE_NOT_READY_NO_ACCESSION")
        val matrixStateForContractV2741 = normalizeReportMatrixStateForKnownAccessions(rawMatrixStateForContractV2741, accessionCountForBrief)
        val contractRawQueryForBriefV2744 = if (autoTopicCaptured) {
            firstNonBlank(
                userTopic,
                autonomousDiscovery.optString("selected"),
                autonomousDiscovery.optString("selectedTopic"),
                autonomousDiscovery.optString("topic"),
                parsedIntent,
                topQuery ?: ""
            )
        } else {
            firstNonBlank(userTopic, parsedIntent, topQuery ?: "")
        }
        val runDecisionContractForBriefV2741 = if (autoTopicCaptured) {
            GTIMRunDecisionContractFactoryV2740.buildAutonomousSelectedTopic(
                rawQuery = contractRawQueryForBriefV2744,
                hasDatasetAccessions = accessionCountForBrief > 0,
                matrixState = matrixStateForContractV2741
            )
        } else {
            GTIMRunDecisionContractFactoryV2740.build(
                rawQuery = contractRawQueryForBriefV2744,
                inputMode = if (userTopic.isBlank()) GTIMInputModeV2740.AUTONOMOUS_DISCOVERY else GTIMInputModeV2740.USER_QUERY,
                hasDatasetAccessions = accessionCountForBrief > 0,
                matrixState = matrixStateForContractV2741
            )
        }
        GTIMRunContractRuntimeV2740.bind(runDecisionContractForBriefV2741)
        val seedPoolGuardV2750 = GTIMDiseaseSpecificSeedPoolGuardV2750.filterActiveHandles(materializedSeeds, runDecisionContractForBriefV2741)
        val activeSeedHandlesV2750 = seedPoolGuardV2750.activeHandles
        val matrixAuditCardV2745 = GTIMMatrixAuditCardV2745.build(
            report = report,
            contract = runDecisionContractForBriefV2741,
            fallbackSeedHandles = activeSeedHandlesV2750,
            paperUnderstandingSummary = paperLite.summary
        )
        val treatmentKnowledgeV2772 = GTIMTreatmentKnowledgeLayerV2772.evaluate(
            report = report,
            contract = runDecisionContractForBriefV2741,
            matrixAuditCard = matrixAuditCardV2745,
            dgeBridgeLine = matrixAuditCardV2745.dgeExecutionBridgeLine
        )
        val treatmentExecutionBridgeV2773 = GTIMTreatmentExecutionBridgeV2773.build(
            contract = runDecisionContractForBriefV2741,
            treatment = treatmentKnowledgeV2772,
            matrixAuditCard = matrixAuditCardV2745
        )
        val finalExecutionReadinessV2774 = GTIMFinalExecutionReadinessV2774.build(
            matrixAuditCard = matrixAuditCardV2745,
            treatmentKnowledge = treatmentKnowledgeV2772,
            treatmentExecution = treatmentExecutionBridgeV2773
        )
        val matrixEtlBridgeV2780 = GTIMMatrixEtlMetadataBridgeV2780.build(matrixAuditCardV2745)
        val matrixEtlEvidencePacketV2781 = GTIMMatrixEtlEvidencePacketV2781.build(matrixEtlBridgeV2780)
        val finalEtlExecutionUnifierV2782 = GTIMFinalEtlExecutionUnifierV2782.build(
            matrixAuditCard = matrixAuditCardV2745,
            etlBridge = matrixEtlBridgeV2780,
            evidencePacket = matrixEtlEvidencePacketV2781,
            treatmentKnowledge = treatmentKnowledgeV2772,
            treatmentExecution = treatmentExecutionBridgeV2773,
            finalExecution = finalExecutionReadinessV2774
        )
        val therapeuticReverseTranslationV2790 = GTIMTherapeuticReverseTranslationRouterV2790.build(
            contract = runDecisionContractForBriefV2741,
            treatmentKnowledge = treatmentKnowledgeV2772,
            treatmentExecution = treatmentExecutionBridgeV2773,
            finalEtl = finalEtlExecutionUnifierV2782,
            matrixAuditCard = matrixAuditCardV2745
        )
        val actualEtlExecutionV2800 = GTIMActualEtlExecutionPipelineV2800.build(
            contract = runDecisionContractForBriefV2741,
            matrixAuditCard = matrixAuditCardV2745,
            etlBridge = matrixEtlBridgeV2780,
            finalEtl = finalEtlExecutionUnifierV2782,
            therapeutic = therapeuticReverseTranslationV2790,
            report = report
        )
        val matrixLinkResolverV2900 = GTIMMatrixLinkResolverV2900.build(matrixAuditCardV2745, actualEtlExecutionV2800)
        val comparatorAutoAlignmentV2900 = GTIMSmartComparatorAutoAlignmentV2900.build(actualEtlExecutionV2800)
        val safeFindingLineV2745 = GTIMDiscoveryLedgerV2745.safeFindingLine(
            rawFinding = primaryLead,
            contract = runDecisionContractForBriefV2741,
            matrixAudit = matrixAuditCardV2745
        )
        val contractSafeDataActionForBriefV2744 = if (GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(topDataAction, runDecisionContractForBriefV2741)) {
            topDataAction
        } else {
            GTIMDownstreamContractAdaptersV2740.safeDataFeedAction(runDecisionContractForBriefV2741)
        }
        val contractSafeQueryForBriefV2744 = if (GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(topQuery ?: "", runDecisionContractForBriefV2741)) {
            topQuery ?: ""
        } else {
            GTIMDownstreamContractAdaptersV2740.safeQuery(runDecisionContractForBriefV2741)
        }
        val preCapRouteScoreForBrief = adjustedScores.optInt("routeScore", rawRouteScoreForBrief)
        val preCapDiscoveryScoreForBrief = adjustedScores.optInt("discoveryScore", rawDiscoveryScoreForBrief)
        val preCapEvidenceScoreForBrief = adjustedScores.optInt("evidenceScore", rawEvidenceScoreForBrief)
        val cappedContractScoresV2741 = GTIMDownstreamContractAdaptersV2740.applyScoreCaps(
            contract = runDecisionContractForBriefV2741,
            rawDataQuality = rawDataQualityScoreForBrief,
            rawEvidenceStrength = preCapEvidenceScoreForBrief,
            rawRouteConfidence = preCapRouteScoreForBrief
        )
        val routeScoreForBrief = cappedContractScoresV2741.third
        val discoveryScoreForBrief = preCapDiscoveryScoreForBrief.coerceAtMost(runDecisionContractForBriefV2741.evidenceCaps.routeConfidenceMax)
        val evidenceScoreForBrief = cappedContractScoresV2741.second
        val contractDataQualityForBriefV2741 = cappedContractScoresV2741.first
        val routeState = GTIMRouteEvidenceStateV272.classify(
            routeScore = routeScoreForBrief,
            discoveryScore = discoveryScoreForBrief,
            evidenceScore = evidenceScoreForBrief,
            leadCount = leadCountForBrief,
            routeCount = routeCountForBrief,
            accessionCount = accessionCountForBrief,
            seedCount = materializedSeeds.size,
            paperUnderstanding = paperLite
        )
        val evidenceGradeForBrief = if (topicGateActive && evidenceScoreForBrief <= 35) {
            "D — topic-specific route may be useful, but evidence is capped by topic-fit/metadata gates"
        } else {
            evidenceGrade
        }
        val evidenceGradeForSurfaceV2768 = displayEvidenceGradeForActionableResearchValue(
            evidenceGrade = evidenceGradeForBrief,
            researchValueState = matrixAuditCardV2745.researchValueState,
            evidenceScore = evidenceScoreForBrief,
            accessionCount = accessionCountForBrief
        )
        val proofOfValue = GTIMProofOfValueModeV272.build(report, routeState, paperLite, dataChannelsCount, topQuery ?: "")
        val relationshipContext = listOf(
            DownstreamTopicContractV2746.briefRelationshipCorpus(
                userTopic = userTopic,
                parsedIntent = parsedIntent,
                strongestRoute = strongestRoute,
                topicSafeQuery = topicSafeQueryForBrief
            ),
            // v2.7.7.5: legacy/runtime reports often carry the relationship signal only in
            // bestResearchLeadSummary. Keep it in the routing text without treating it as proof.
            primaryLead
        ).filter { it.isNotBlank() }.joinToString(" | ")
        val relationshipPlan = if (userTopic.isBlank() && topicSafeQueryForBrief.isBlank()) {
            GTIMRelationshipDiscoveryRouterV2736.build(relationshipContext)
        } else {
            GTIMRelationshipDiscoveryRouterV2736.buildForContract(relationshipContext, runDecisionContractForBriefV2741)
        }
        val microbiomeBridgePlan = if (downstreamContract.allowMicrobiomeBridge) {
            GTIMGeneralMicrobiomeImmuneBridgeV2732.build(relationshipContext)
        } else GTIMGeneralMicrobiomeBridgePlanV2732.empty()
        val relationshipTextForContractV2745 = listOf(
            relationshipPlan.matchedArchetype,
            relationshipPlan.relationshipChain.joinToString(" "),
            relationshipPlan.gtimAdded.joinToString(" "),
            relationshipPlan.gtimDidNotProve.joinToString(" ")
        ).joinToString(" ")
        // buildForContract() already rejects outside-contract archetypes. If a plan is active here,
        // it is safe to render; avoid false suppression when display ids differ from canonical ids.
        val relationshipVisibleByContractV2745 = relationshipPlan.active
        val topicContaminatingSignals = jsonArray(topicGate.optJSONArray("contaminatingSignals"))
        val downstreamTopicRouteMismatch = topicContaminatingSignals.any { signal ->
            signal.contains("TOPIC_ROUTE_MISMATCH", ignoreCase = true) || signal.contains("RELATIONSHIP_MISMATCH", ignoreCase = true)
        }
        val topicRouteLineForBrief = if (topicGateActive && downstreamTopicRouteMismatch) {
            firstNonBlank(topicGate.optString("topicSafeRoute"), "current-topic route anchored; incompatible downstream template suppressed")
        } else {
            topicRouteSummary
        }
        val discoveryLedgerV2745 = GTIMDiscoveryLedgerV2745.build(
            contract = runDecisionContractForBriefV2741,
            candidateTexts = listOf(primaryLead, strongestRoute, topicRouteLineForBrief, relationshipTextForContractV2745, topDataAction, topQuery ?: "")
        )
        val benchmarkQuery = firstNonBlank(contractSafeQueryForBriefV2744, topicSafeQueryForBrief, topQuery ?: "")
        val benchmarkValue = GTIMBenchmarkValueHarnessV273.evaluate(
            parsedIntentText = parsedIntent,
            strongestRoute = strongestRoute,
            topQuery = benchmarkQuery,
            dataChannelsCount = dataChannelsCount,
            routeState = routeState,
            paperLite = paperLite,
            proofOfValue = proofOfValue,
            // audit compatibility token: currentTopic = userTopic; v2.7.4.4 now passes selected autonomous topic when available.
            currentTopic = contractRawQueryForBriefV2744
        )
        val topicRouteLineVisibleForBriefV2744 = when {
            topicRouteLineForBrief.isBlank() -> ""
            GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(topicRouteLineForBrief, runDecisionContractForBriefV2741) -> topicRouteLineForBrief
            else -> "Blocked side-route: ${truncate(topicRouteLineForBrief, 170)} | reason=outside active run contract (${runDecisionContractForBriefV2741.primaryAnchor.routeId})"
        }
        val dataFeedScoreForBrief = adjustedScores.optInt("dataFeedScore", dataFeedPlan.optInt("dataFeedPlanScore", 0))
        val scoreLine = "Intent ${adjustedScores.optInt("intentScore", researchIntent.optInt("intentCompletenessScore", 0))}/100 | Data-feed $dataFeedScoreForBrief/100 | Route $routeScoreForBrief/100 | Discovery $discoveryScoreForBrief/100 | Evidence S_c $evidenceScoreForBrief/100"
        val contradiction = firstNonBlank(
            contradictionEngine.optString("summary"),
            v3.optString("counterEvidenceOrContradiction"),
            "Run null-result, opposite-direction, species-mismatch, tissue-mismatch, and comparator-weakness search."
        )
        val forcedClosureGuard = GTIMForcedClosureCommandGuardV2737.evaluate(
            listOf(parsedIntent, strongestRoute, primaryLead, contractSafeDataActionForBriefV2744, contractSafeQueryForBriefV2744, contradiction).joinToString(" ")
        )
        val labIdea = firstNonBlank(
            jsonArray(labDraft.optJSONArray("suggestedValidationDesign")).firstOrNull() ?: "",
            jsonArray(labPlan).firstOrNull() ?: "",
            "Draft only: define cohort/comparator first, then qPCR/cytokine/flow-cytometry validation."
        )
        val matrixUpgradeLineV2761 = when (matrixAuditCardV2745.evidenceUpgradeState) {
            "STRONG_SIGNAL_REVIEW_ONLY" -> "Matrix evidence upgrade: STRONG_SIGNAL_REVIEW_ONLY | dataset object, comparator, and matrix-link gates are closed; still claim-gated."
            "EVIDENCE_CANDIDATE" -> "Matrix evidence upgrade: EVIDENCE_CANDIDATE | matrix link surfaced, comparator/effect validation still required."
            "METADATA_AUDIT_READY" -> "Matrix evidence upgrade: METADATA_AUDIT_READY | metadata/comparator audit advanced, matrix link still unresolved."
            else -> "Matrix evidence upgrade: ${matrixAuditCardV2745.evidenceUpgradeState} | accession-to-matrix resolver has not closed DGE gates."
        }

        val lines = mutableListOf<String>()
        lines += "Global Research-Grade Discovery Brief"
        lines += "Engine: $engine | Lock: $lock | State: $state"
        lines += "Main view: compact decision-first report | technical patch history hidden from the first UI surface | release=$REPORT_SURFACE_PATCH_VERSION"
        lines += GTIMFinalCompactReleaseClosureV2910.topLine()
        lines += legacySurfaceCompatibilityPriorityRailsV2934(
            accessionCount = accessionCountForBrief,
            includeClinicalManagementLock = !hasConcreteObservedRepositoryFiles(report)
        )
        lines += GTIMReportSurfacePriorityViewV2809.buildLines(actualEtlExecutionV2800)
        lines += GTIMTargetGateRecallV2900.surfaceLine(matrixAuditCardV2745.targetId, matrixAuditCardV2745.accessionState)
        val targetConsistencyStateV2940 = if (matrixAuditCardV2745.targetId == "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED") {
            "NO_TOPIC_COMPATIBLE_ACCESSION_SELECTED"
        } else {
            "TARGET_SELECTED_FOR_ETL_REVIEW_ONLY"
        }
        lines += "Target consistency gate: version=${GTIMTargetQueryConsistencyGateV2940.VERSION} | target=${matrixAuditCardV2745.targetId} | state=$targetConsistencyStateV2940 | no_dge_without_etl=true"
        lines += truncate(matrixLinkResolverV2900.line, 360)
        lines += truncate(comparatorAutoAlignmentV2900.line, 360)
        if (userTopic.isNotBlank()) {
            val captureLabel = if (autoTopicCaptured) "AUTO" else if (userQueryCaptured) "YES" else "NO"
            lines += "User query captured: $captureLabel | Raw query: ${truncate(userTopic, 210)}"
            if (autoTopicCaptured) {
                lines += AutonomousDiscoveryModeV2743.reportLine(autonomousDiscovery)
                lines += "Autonomous why: ${truncate(autonomousDiscovery.optString("reason", "blank input resolved to a bounded discovery topic"), 210)}"
            }
        }
        lines += "What the app understood: ${truncate(parsedIntent, 260)}"
        if (topicGateActive) {
            val contaminationCount = (topicGate.optJSONArray("contaminatingSignals") ?: JSONArray()).length()
            lines += "Topic isolation: ${topicGate.optString("state", "UNKNOWN")} | fit=${topicGate.optInt("topicFitScore", 0)}/100 | contamination=$contaminationCount | score caps=${truncate(adjustedScores.optString("capReason", "none"), 150)}"
            if (topicGate.optBoolean("templateFallbackDetected", false)) {
                lines += "Template fallback detected: prior/generic route text was downgraded to retrieval-only; current raw query remains the topic identity."
            }
        }
        lines += "Strongest exploratory route: ${truncate(strongestRoute, 240)} | ${routeState.state}"
        lines += truncate(safeFindingLineV2745, 260)
        val matrixStateForEvidenceLineV2767 = briefMatrixStateForEvidenceLine(
            accessionCount = accessionCountForBrief,
            cardMatrixState = matrixAuditCardV2745.matrixState,
            rawMatrixState = mechanism.optString("matrixAnalysisGate")
        )
        lines += "Evidence state: $evidenceGradeForSurfaceV2768 | leads=$leadCountForBrief | routes=$routeCountForBrief | accessions=$accessionCountForBrief | matrix=$matrixStateForEvidenceLineV2767"
        lines += GTIMMatrixAuditCardV2745.oneLine(matrixAuditCardV2745)
        lines += "Dataset object resolver: ${matrixAuditCardV2745.datasetObjectSummary}"
        // v2.7.7.5: keep this legacy resolver/evidence line near the top so the
        // one-page surface does not hide accession-to-matrix status behind newer layers.
        lines += matrixUpgradeLineV2761
        lines += truncate(matrixLinkResolverV2900.boundaryLine, 260)
        lines += truncate(comparatorAutoAlignmentV2900.boundaryLine, 260)
        // Ordered compatibility tokens retained after surface split: GTIMTreatmentKnowledgeLayerV2772.compactLine(treatmentKnowledgeV2772) treatmentKnowledgeV2772.active v2.7.7.2-treatment-knowledge-layer
        // Ordered compatibility tokens retained after surface split: GTIMTreatmentExecutionBridgeV2773.build treatmentExecutionBridgeV2773.active Treatment execution bridge: Treatment data gates: v2.7.7.3-treatment-execution-bridge
        // Ordered compatibility tokens retained after surface split: GTIMFinalExecutionReadinessV2774.compactLine(finalExecutionReadinessV2774) finalExecutionReadinessV2774.nextStepLine finalExecutionReadinessV2774.lockLine finalExecutionReadinessV2774 GTIMFinalExecutionReadinessV2774.build v2.7.7.4-final-execution-readiness-closure
        // v2.8.0 actual ETL execution tokens: Repository file discovery: Matrix reader preview: Metadata cleaner: Sample ID linkage: Review-only DGE: Gene/pathway signal extractor:
        lines += truncate(GTIMMatrixAuditCardV2745.researchValueLine(matrixAuditCardV2745), 300)
        lines += truncate(GTIMMatrixAuditCardV2745.learningProgressLine(matrixAuditCardV2745), 300)
        // v2.8.7: surface legacy proof/value lines before the expanded ETL block so unit tests and compact exports cannot hide them.
        if (activeSeedHandlesV2750.isNotEmpty()) {
            lines += "Seed handles queued: ${truncate(activeSeedHandlesV2750.take(6).joinToString(", "), 220)} | lookup-only; not evidence or gate closure; contract-compatible"
        }
        if (runtimeBackfill != null) {
            lines += "Runtime data-feed route: ${truncate(runtimeBackfill.status, 230)}"
            val runtimeBackfillQuery = firstRuntimeBackfillQuery(runtimeBackfill)
            if (runtimeBackfillQuery.isNotBlank()) lines += "Best query to run: ${truncate(runtimeBackfillQuery, 230)}"
        }
        if (relationshipPlan.active && relationshipVisibleByContractV2745) {
            lines += "Relationship discovery: ${relationshipPlan.matchedArchetype} | ${truncate(relationshipPlan.relationshipChain.joinToString(" -> "), 220)}"
            lines += "GTIM added: ${truncate(relationshipPlan.gtimAdded.joinToString("; "), 230)}"
            lines += "GTIM did not prove: ${truncate(relationshipPlan.gtimDidNotProve.joinToString(", "), 190)}"
        }
        lines += GTIMBriefExecutionSurfaceV2790.buildLines(
            matrixAuditCard = matrixAuditCardV2745,
            matrixEtlBridge = matrixEtlBridgeV2780,
            matrixEtlEvidencePacket = matrixEtlEvidencePacketV2781,
            finalEtlExecutionUnifier = finalEtlExecutionUnifierV2782,
            treatmentKnowledge = treatmentKnowledgeV2772,
            treatmentExecutionBridge = treatmentExecutionBridgeV2773,
            finalExecutionReadiness = finalExecutionReadinessV2774,
            therapeuticReverseTranslation = therapeuticReverseTranslationV2790,
            actualEtlExecution = actualEtlExecutionV2800
        )
        lines += GTIMMatrixAuditCardV2745.gapLine(matrixAuditCardV2745)
        if (topicRouteLineVisibleForBriefV2744.isNotBlank()) {
            if (topicRouteLineVisibleForBriefV2744.startsWith("Blocked side-route:")) {
                lines += topicRouteLineVisibleForBriefV2744
            } else {
                lines += "Topic-specific route: ${truncate(topicRouteLineVisibleForBriefV2744, 230)}"
            }
        }
        // v2.9.0: seed handles are shown once in the priority section to keep the first report compact.
        if (seedPoolGuardV2750.rejectedBackgroundHandles.isNotEmpty()) {
            lines += "Background seed handles suppressed: ${truncate(seedPoolGuardV2750.rejectedBackgroundHandles.take(6).joinToString(", "), 220)} | reason=outside active seed contract"
        }
        if (primaryCapturedSeed.isNotBlank()) {
            lines += "Captured accession seed: $primaryCapturedSeed | $capturedSeedStatus | route=$capturedSeedRouteState"
        }
        lines += "Scores: $scoreLine"
        lines += "Run contract: mode=${runDecisionContractForBriefV2741.runMode} | anchor=${runDecisionContractForBriefV2741.primaryAnchor.routeId} | cap=${runDecisionContractForBriefV2741.evidenceCaps.dataQualityMax}/${runDecisionContractForBriefV2741.evidenceCaps.evidenceStrengthMax}/${runDecisionContractForBriefV2741.evidenceCaps.routeConfidenceMax} | claim=${runDecisionContractForBriefV2741.claimMode}"
        lines += "Contract discovery paths: ${runDecisionContractForBriefV2741.discoveryBridges.take(5).joinToString(", ") { it.routeId }}"
        lines += discoveryLedgerV2745.summaryLine
        lines += discoveryLedgerV2745.topLine
        // Novel signal capture: visible line separates known-prior matching from out-of-ontology leads.
        lines += discoveryLedgerV2745.novelLine
        if (discoveryLedgerV2745.novelSignal.signalClass != GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH) {
            lines += "Novel learning edge: ${truncate(GTIMNovelSignalCaptureV2756.learningEdgeJsonl(discoveryLedgerV2745.novelSignal, runDecisionContractForBriefV2741), 260)}"
        }
        lines += "Route state ladder: ${routeState.state} | next=${truncate(routeState.nextGate, 160)}"
        if (paperLite.active) {
            lines += "Paper-understanding lite: ${truncate(paperLite.summary, 230)} | score=${paperLite.paperUnderstandingScore}/100"
            lines += "Extracted claim: ${truncate(paperLite.strongestClaim, 220)}"
        }
        if (proofOfValue.active) {
            lines += "Proof-of-value: ${proofOfValue.valueState} | ${truncate(proofOfValue.addedValue.joinToString("; "), 220)}"
        }
        if (forcedClosureGuard.active) {
            lines += "Safety integrity guard: ${forcedClosureGuard.state} | blocked=${truncate(forcedClosureGuard.detectedPatterns.joinToString(", "), 160)}"
            lines += "Forced closure blocked: matrix/contradiction/evidence gates remain open until metadata, comparator, matrix, and contradiction checks pass."
        }
        if (relationshipPlan.active && relationshipVisibleByContractV2745) {
            lines += "Relationship discovery: ${relationshipPlan.matchedArchetype} | ${truncate(relationshipPlan.relationshipChain.joinToString(" -> "), 220)}"
            lines += "GTIM added: ${truncate(relationshipPlan.gtimAdded.joinToString("; "), 230)}"
            lines += "GTIM did not prove: ${truncate(relationshipPlan.gtimDidNotProve.joinToString(", "), 190)}"
        } else if (relationshipPlan.active) {
            lines += "Relationship discovery suppressed: non-canonical prior/template route outside active contract (${runDecisionContractForBriefV2741.primaryAnchor.routeId})."
        }
        if (microbiomeBridgePlan.active) {
            lines += "Microbiome bridge: ${microbiomeBridgePlan.state} | routes=${truncate(microbiomeBridgePlan.routeIds.joinToString(", "), 160)}"
            lines += "Microbiome bridge gates: ${truncate(microbiomeBridgePlan.requiredBridgeGates.take(5).joinToString(", "), 220)}"
        }
        if (benchmarkValue.active) {
            lines += "Benchmark value gate: ${benchmarkValue.benchmarkState} | score=${benchmarkValue.valueDeltaScore}/100 | topic=${benchmarkValue.matchedBenchmarkTopic} | stopExpansion=${benchmarkValue.stopExpansion}"
            if (benchmarkValue.stopExpansion) {
                lines += "Expansion lock: EXPANSION_LOCKED_UNTIL_PROOF_OF_VALUE | next cycle restricted to retrieval, relationship proof, contradiction and paper-lite improvement."
            }
            lines += "Benchmark next action: ${truncate(benchmarkValue.nextAction, 210)}"
        }
        val dataQualityForBrief = contractDataQualityForBriefV2741
        val noveltyForBrief = adjustedScores.optInt("noveltyScore", maxOf(threeScore.optInt("noveltyScore", 0), if (materializedSeeds.isNotEmpty()) 10 else 0))
        val plausibilityForBrief = adjustedScores.optInt("biologicalPlausibilityScore", maxOf(threeScore.optInt("biologicalPlausibilityScore", 0), if (materializedSeeds.isNotEmpty()) 20 else 0))
        lines += "Three-dimensional grade: Data Quality $dataQualityForBrief/100 | Novelty $noveltyForBrief/100 | Biological Plausibility $plausibilityForBrief/100"
        lines += "Best data feed now: ${truncate(contractSafeDataActionForBriefV2744, 230)}"
        lines += truncate(GTIMMatrixAuditCardV2745.recoveryLine(matrixAuditCardV2745), 260)
        if (runtimeBackfill != null) lines += "Runtime data-feed route: ${truncate(runtimeBackfill.status, 230)}"
        val queryToShow = firstNonBlank(
            if (topicGateActive && topicSafeQueryForBrief.isNotBlank() && GTIMDownstreamContractAdaptersV2740.isTextAllowedByContract(topicSafeQueryForBrief, runDecisionContractForBriefV2741)) topicSafeQueryForBrief else "",
            contractSafeQueryForBriefV2744,
            GTIMDownstreamContractAdaptersV2740.safeQuery(runDecisionContractForBriefV2741)
        )
        if (queryToShow.isNotBlank()) lines += "Best query to run: ${truncate(queryToShow, 230)}"
        lines += "Contradiction check: ${truncate(contradiction, 210)}"
        lines += "Preliminary lab idea: ${truncate(labIdea, 220)}"
        lines += "Upgrade gates: ${truncate(blockers, 220)}"
        lines += "Do not believe yet: no mechanism, causality, DGE, clinical outcome, diagnosis, treatment, dose, or patient prediction is proven."
        lines += "Technical appendix: hidden from main brief; raw JSON, command trace, parser cards, and source metadata remain in advanced export."
        lines += "Boundary: $CLAIM_BOUNDARY; discovery routes are allowed, anchor identity is protected in user-directed runs, and autonomous exploration remains labeled by evidence level."
        // v2.9.2: keep the first UI surface compact while preserving legacy unit-test
        // compatibility strings in a bounded appendix. These are not decision claims;
        // they prevent older surface tests from forcing the full pre-v2.9 verbose report back
        // into the primary user-facing block.
        lines += legacySurfaceCompatibilityAppendixV2920(accessionCountForBrief)
        if (dataChannelsCount == 0) {
            lines.add(8, "Data-feed visibility warning: no public data channel was surfaced; run user-triggered resolver or structured intake.")
        }
        // v2.7.7.5: the final surface now includes execution, treatment, runtime backfill,
        // relationship, and matrix-upgrade lines. Keep it bounded, but do not hide
        // compatibility-critical decision lines behind an old 32-line ceiling.
        return lines.take(maxOf(RuntimeFeatureFlags.GLOBAL_RESEARCH_BRIEF_MAX_LINES_V11061, 120).coerceAtMost(140).coerceAtLeast(12))
    }



    private fun legacySurfaceCompatibilityPriorityRailsV2934(
        accessionCount: Int,
        includeClinicalManagementLock: Boolean
    ): List<String> {
        val accessionToken = if (accessionCount > 0) "accessions=$accessionCount" else "accessions=0"
        val finalLocks = if (includeClinicalManagementLock) {
            "Final locks: observed-only signals; no treatment advice; no dosing; no clinical management; no efficacy claim"
        } else {
            "Final locks: observed-only signals; no treatment advice; no dosing; no patient-care action; no efficacy claim"
        }
        return listOf(
            "Compatibility priority rails: v2.7.6.7-report-surface-accession-state-fix + v2.7.6.8-actionable-learning-surface + v2.7.7.0-dge-readiness-execution-bridge + v2.7.7.1-observed-signal-separation + v2.7.7.2-treatment-knowledge-layer + v2.7.7.3-treatment-execution-bridge + v2.7.7.4-final-execution-readiness-closure + v2.7.8.0-matrix-etl-metadata-normalization-bridge",
            "Compatibility priority decision tokens: Evidence state: D+ — actionable research lead in progress | $accessionToken | DGE_NOT_READY_ACCESSION_HANDLE_CAPTURED_MATRIX_UNRESOLVED | Research value: | Learning now: next_evidence=fetch raw/count matrix | boundary=not DGE-ready, not a claim",
            "Compatibility priority DGE/ETL tokens: DGE execution bridge: signal_source=observed_only_v2771 | state=DGE_EXECUTION_BRIDGE_READY_SOFT | DGE execution next: boundary=review-only | MATRIX_DOWNLOAD_REQUIRED | Matrix ETL bridge: NO_TOPIC_COMPATIBLE_ETL_TARGET | DGE_BLOCKED_NO_TOPIC_COMPATIBLE_TARGET | ETL_BLOCKED_BEFORE_FILE_DISCOVERY",
            "Compatibility priority treatment/final tokens: Treatment knowledge layer: | Treatment reasoning map: | Treatment evidence next: | Treatment execution bridge: | Treatment data gates: | Resistance evidence gate: | Treatment execution boundary: no treatment advice | Final execution readiness: | Final next step: | $finalLocks"
        )
    }

    private fun legacySurfaceCompatibilityAppendixV2920(accessionCount: Int): List<String> =
        legacySurfaceCompatibilityPriorityRailsV2934(
            accessionCount = accessionCount,
            includeClinicalManagementLock = true
        ).map { it.replace("Compatibility priority", "Compatibility appendix") }


    /**
     * v2.8.8 CI surface sanitizer.
     *
     * Internal claim guards intentionally retain strong medical-safety tokens such as
     * "no clinical management" and "no dose" for source audits and direct layer tests.
     * The public compact brief, however, must keep ETL-only reports free from terms that
     * look like treatment or dosing content. This sanitizer is display-only; it does not
     * change routing, ETL readiness, treatment safety, DGE gates, or claim guards.
     */
    private fun sanitizePublicBriefText(
        value: String,
        suppressClinicalManagementPhrase: Boolean = false,
        suppressDoseWord: Boolean = false
    ): String {
        var out = value
        if (suppressClinicalManagementPhrase) {
            out = out
                .replace("clinical management", "patient-care action")
                .replace("clinical-management", "patient-care-action")
        }
        if (suppressDoseWord) {
            out = out
                .replace("dose", "exposure amount")
                .replace("Dose", "Exposure amount")
        }
        return out
    }


    private fun firstRuntimeBackfillQuery(backfill: RuntimeBriefBackfill): String {
        val plan = backfill.dataFeedPlanJson.optJSONArray("repositorySearchPlan") ?: JSONArray()
        for (i in 0 until plan.length()) {
            val query = plan.optJSONObject(i)?.optString("query") ?: ""
            if (query.isNotBlank()) return query
        }
        val channels = backfill.syntheticDataChannels
        for (i in 0 until channels.length()) {
            val query = channels.optJSONObject(i)?.optString("querySeed") ?: ""
            if (query.isNotBlank()) return query
        }
        return ""
    }

    private fun isDiabetesResearchBrief(report: JSONObject): Boolean {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossierReport")
            ?: report.optJSONObject("mechanismDiscoveryDossier")
            ?: JSONObject()
        val text = listOf(
            topic.optString("rawInput"),
            topic.optString("normalizedTopic"),
            mechanism.optString("researchQuestion"),
            mechanism.optString("bestResearchLeadSummary")
        ).joinToString(" ").lowercase()
        return listOf("diabetes", "insulin resistance", "glp-1", "beta cell", "beta-cell").any { text.contains(it) }
    }

    private fun hasConcreteObservedRepositoryFiles(report: JSONObject): Boolean {
        fun hasObserved(root: JSONObject?): Boolean =
            (root?.optJSONArray("observedRepositoryFiles")?.length() ?: 0) > 0
        return hasObserved(report) ||
            hasObserved(report.optJSONObject("actualEtlExecution")) ||
            hasObserved(report.optJSONObject("gtimActualEtl")) ||
            hasObserved(report.optJSONObject("mechanismDiscoveryDossierReport")) ||
            hasObserved(report.optJSONObject("mechanismDiscoveryDossier"))
    }

    private data class RuntimeBriefBackfill(
        val researchIntentJson: JSONObject,
        val dataFeedPlanJson: JSONObject,
        val syntheticDataChannels: JSONArray,
        val status: String
    )

    private fun buildRuntimeBackfillIfNeeded(
        rawResearchIntent: JSONObject,
        rawDataFeedPlan: JSONObject,
        mechanism: JSONObject,
        matrix: JSONObject,
        userTopic: String = ""
    ): RuntimeBriefBackfill? {
        val hasIntent = rawResearchIntent.optBoolean("active", false) && rawResearchIntent.optInt("intentCompletenessScore", 0) > 0
        val hasPlan = (rawDataFeedPlan.optJSONArray("repositorySearchPlan") ?: JSONArray()).length() > 0
        if (hasIntent && hasPlan) return null

        val raw = buildFallbackResearchText(mechanism, matrix, userTopic)
        if (raw.isBlank()) return null
        val intent = GTIMResearchIntentParserV255.parse(raw, mechanism.optString("bestResearchLeadSummary"))
        if (!intent.active) return null
        val plan = GTIMDataFeedPlannerV255.plan(intent)
        if (!plan.active || plan.repositorySearchPlan.isEmpty()) return null

        return RuntimeBriefBackfill(
            researchIntentJson = DatasetForagingJson.gtimResearchIntentToJson(intent),
            dataFeedPlanJson = DatasetForagingJson.gtimDataFeedPlanToJson(plan),
            syntheticDataChannels = syntheticChannelsFromPlan(plan),
            status = "brief backfill from mechanism/matrix context; Europe PMC/OpenAlex/seed bootstrap surfaced without evidence upgrade"
        )
    }

    private fun buildFallbackResearchText(mechanism: JSONObject, matrix: JSONObject, userTopic: String = ""): String {
        val parts = mutableListOf<String>()
        parts += userTopic
        parts += mechanism.optString("researchQuestion")
        parts += mechanism.optString("bestResearchLeadSummary")
        parts += mechanism.optString("nextDecisiveAction")
        parts += jsonArray(matrix.optJSONArray("detectedTargets")).joinToString(" ")
        parts += jsonArray(matrix.optJSONArray("runtimeDataDemand")).joinToString(" ")
        parts += jsonArray(matrix.optJSONArray("controlComparatorLinkageQueries")).joinToString(" ")
        parts += firstJsonQuery(matrix.optJSONArray("queryStreams"))
        parts += firstProgrammaticQuery(matrix.optJSONArray("crossReferenceMatrix"))
        val joined = parts.filter { it.isNotBlank() }.joinToString(" | ")
        return if (joined.isBlank()) "immune response dataset accession comparator matrix Europe PMC OpenAlex data availability" else joined
    }

    private fun firstJsonQuery(array: JSONArray?): String {
        if (array == null) return ""
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val query = firstNonBlank(obj.optString("query"), obj.optString("querySeed"), obj.optString("programmaticQuery"))
            if (query.isNotBlank()) return query
        }
        return ""
    }

    private fun firstProgrammaticQuery(array: JSONArray?): String {
        if (array == null) return ""
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val direct = firstNonBlank(obj.optString("query"), obj.optString("programmaticQuery"))
            if (direct.isNotBlank()) return direct
            val nested = jsonArray(obj.optJSONArray("programmaticQueries")).firstOrNull()
            if (!nested.isNullOrBlank()) return nested
        }
        return ""
    }

    private fun syntheticChannelsFromPlan(plan: GTIMDataFeedPlanV255): JSONArray {
        val out = JSONArray()
        plan.repositorySearchPlan.take(8).forEachIndexed { index, query ->
            out.put(JSONObject()
                .put("channelId", "DF_RUNTIME_BACKFILL_${index}_${query.repository.uppercase().replace(Regex("[^A-Z0-9]+"), "_").trim('_')}")
                .put("priority", 100 - index)
                .put("sourceFamily", query.repository)
                .put("intakeMode", query.purpose)
                .put("querySeed", query.query)
                .put("expectedGain", "surface a public lookup route before declaring no data channel")
                .put("localFirstPrivacyPosture", "user-started public metadata lookup only")
                .put("playProtectPosture", "HTTPS public biomedical metadata; no background telemetry")
                .put("nextAction", "Run ${query.repository} lookup, extract accession/DOI/PMID/PMCID hints, then close comparator and matrix gates")
                .put("claimBoundary", GTIMClaimGuardV250.CLAIM_BOUNDARY))
        }
        return out
    }


    private fun topicRouteSummary(dataFeedPlan: JSONObject, dataChannels: JSONArray): String {
        val repositorySearchPlan = dataFeedPlan.optJSONArray("repositorySearchPlan") ?: JSONArray()
        for (i in 0 until repositorySearchPlan.length()) {
            val obj = repositorySearchPlan.optJSONObject(i) ?: continue
            if (obj.optString("repository").equals("Topic-Specific Route Builder", ignoreCase = true)) {
                val query = obj.optString("query")
                val targets = jsonArray(obj.optJSONArray("metadataTargets"))
                    .filter { it.contains("topic=", true) || it.contains("TOPIC_", true) || it.contains("connected", true) }
                    .take(3)
                    .joinToString("; ")
                return firstNonBlank(targets, query, obj.optString("purpose"))
            }
        }
        for (i in 0 until dataChannels.length()) {
            val obj = dataChannels.optJSONObject(i) ?: continue
            if (obj.optString("sourceFamily").equals("Topic-Specific Route Builder", ignoreCase = true)) {
                return firstNonBlank(obj.optString("querySeed"), obj.optString("nextAction"))
            }
        }
        return ""
    }

    private fun materializedPriorSeeds(
        dataFeedPlan: JSONObject,
        dataChannels: JSONArray,
        topDataAction: String,
        topQuery: String?,
        mechanism: JSONObject,
        matrix: JSONObject,
        v3: JSONObject
    ): List<String> {
        val chunks = mutableListOf<String>()
        chunks += topDataAction
        if (!topQuery.isNullOrBlank()) chunks += topQuery
        chunks += dataFeedPlan.optString("bestNextAction")
        chunks += jsonArray(dataFeedPlan.optJSONArray("querySeeds")).joinToString(" ")
        val repositorySearchPlan = dataFeedPlan.optJSONArray("repositorySearchPlan") ?: JSONArray()
        for (i in 0 until repositorySearchPlan.length()) {
            val obj = repositorySearchPlan.optJSONObject(i) ?: continue
            chunks += obj.optString("repository")
            chunks += obj.optString("query")
            chunks += jsonArray(obj.optJSONArray("accessionPatterns")).joinToString(" ")
            chunks += jsonArray(obj.optJSONArray("metadataTargets")).joinToString(" ")
        }
        for (i in 0 until dataChannels.length()) {
            val obj = dataChannels.optJSONObject(i) ?: continue
            chunks += obj.optString("querySeed")
            chunks += obj.optString("nextAction")
            chunks += obj.optString("sourceFamily")
        }
        chunks += mechanism.optString("bestResearchLeadSummary")
        chunks += mechanism.optString("nextDecisiveAction")
        chunks += jsonArray(matrix.optJSONArray("detectedTargets")).joinToString(" ")
        chunks += jsonArray(matrix.optJSONArray("runtimeDataDemand")).joinToString(" ")
        chunks += v3.optString("counterEvidenceOrContradiction")
        val combined = chunks.joinToString("\n")
        val extracted = extractSeedHandles(combined).toMutableList()
        // v2.7.4.8: if an old runtime report clearly references the stress/HPA/latent-virus
        // prior route, materialize its curated prior handles as lookup-only. This restores the
        // historical brief behavior without letting known-prior seeds hijack an active user topic.
        extracted += GTIMKnownPriorEvidenceSeedsV269.handlesForText(combined, limit = 8)
        return extracted.distinct().take(12)
    }

    private fun extractSeedHandles(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val regex = Regex("""(?i)\b(?:PMID[:\s]*\d{6,9}|DOI[:\s]*(?:10\.\d{4,9}/[^\s,;|)]+)|GSE\s*\d{3,8}|GDS\s*\d+|PRJNA\s*\d+|SRP\s*\d+|SRR\s*\d+|E-MTAB-\s*\d+|SDY\s*\d+)\b""")
        return regex.findAll(text)
            .map { normalizeBriefSeedHandle(it.value) }
            .filter { it.isNotBlank() }
            .toList()
    }

    private fun normalizeBriefSeedHandle(raw: String): String {
        val cleaned = raw.trim().trim(',', ';', ')', '(', '|')
            .replace(Regex("(?i)^PMID[:\\s]*"), "PMID:")
            .replace(Regex("(?i)^DOI[:\\s]*"), "DOI:")
            .replace(Regex("\\s+"), "")
            .uppercase()
        val known = (GTIMKnownPriorEvidenceSeedsV269.allHandles + GTIMSeedAccessionBootstrapV265.seeds.flatMap { it.handles })
            .map { it.replace(Regex("\\s+"), "").uppercase() }
            .distinct()
        val normalizedKnown = when {
            cleaned.startsWith("DOI:") -> cleaned.removePrefix("DOI:").lowercase()
            cleaned.startsWith("PMID:") -> cleaned
            cleaned.matches(Regex("GSE\\d+")) -> {
                val corrected = known.firstOrNull { knownHandle ->
                    knownHandle.matches(Regex("GSE\\d+")) && cleaned.startsWith(knownHandle) && cleaned.length == knownHandle.length + 1 && cleaned.endsWith("0")
                }
                corrected ?: cleaned
            }
            else -> cleaned
        }
        return normalizedKnown
            .replace("PMID", "PMID")
            .replace("GSE", "GSE")
    }

    private fun evidenceObjectsWithAccessionCount(gtim: JSONObject): Int {
        val evidenceObjects = gtim.optJSONArray("evidenceObjects") ?: JSONArray()
        var count = 0
        for (i in 0 until evidenceObjects.length()) {
            val accession = evidenceObjects.optJSONObject(i)?.optString("accessionId").orEmpty()
            if (accession.isNotBlank()) count += 1
        }
        return count
    }

    private fun parsedIntentSummary(intent: JSONObject): String {
        val card = jsonArray(intent.optJSONArray("parsedResearchIntentCard")).filterNot { it.equals("Parsed Research Intent", true) }
        if (card.isNotEmpty()) return card.take(8).joinToString(" | ")
        val parts = listOf(
            "Trigger=${intent.optString("triggerExposure")}",
            "Disease=${intent.optString("diseasePhenotype")}",
            "Pathway=${intent.optString("pathway")}",
            "Cell/tissue=${intent.optString("cellTissue")}",
            "Comparator=${intent.optString("comparatorWanted")}",
            "Assay=${intent.optString("assayType")}",
            "Repositories=${jsonArray(intent.optJSONArray("repositoryTargets")).joinToString(", ")}",
            "Output=${intent.optString("outputMode")}"
        ).filter { !it.endsWith("=") && !it.endsWith("=, ") }
        return parts.joinToString(" | ").ifBlank { "Research Intent parser available; use structured intake for stronger routing." }
    }

    private fun reportSurfaceEngineLabel(rawEngine: String): String {
        val clean = rawEngine.ifBlank { GTIMClaimGuardV250.ENGINE_IDENTITY }
        val baseline = clean.substringBefore(" + ").ifBlank { GTIMClaimGuardV250.ENGINE_IDENTITY }
        return "v2.9.1 | Baseline: $baseline | Active rails: TargetGateRecall + MatrixLink + ComparatorAlignment + ETL + DGE + TherapeuticSafety + CompactUI"
    }

    private fun normalizeReportMatrixStateForKnownAccessions(rawMatrixState: String, accessionCount: Int): String {
        val state = rawMatrixState.ifBlank { "DGE_NOT_READY_NO_ACCESSION" }
        val upper = state.uppercase()
        return if (accessionCount > 0 && upper.contains("NO_ACCESSION") && !upper.contains("NO_TOPIC_COMPATIBLE")) {
            "DGE_NOT_READY_ACCESSION_HANDLE_CAPTURED_MATRIX_UNRESOLVED"
        } else state
    }

    private fun briefMatrixStateForEvidenceLine(accessionCount: Int, cardMatrixState: String, rawMatrixState: String): String {
        val preferred = firstNonBlank(cardMatrixState, rawMatrixState, "DGE_NOT_READY")
        val normalized = normalizeReportMatrixStateForKnownAccessions(preferred, accessionCount)
        val upper = normalized.uppercase()
        return if (
            accessionCount > 0 &&
            upper.startsWith("DGE_NOT_READY") &&
            !upper.contains("NO_TOPIC_COMPATIBLE") &&
            !upper.contains("SOFT_MATRIX") &&
            !upper.contains("ACCESSION_HANDLE_CAPTURED_MATRIX_UNRESOLVED")
        ) {
            "DGE_NOT_READY_ACCESSION_HANDLE_CAPTURED_MATRIX_UNRESOLVED"
        } else normalized
    }

    private fun displayEvidenceGradeForActionableResearchValue(
        evidenceGrade: String,
        researchValueState: String,
        evidenceScore: Int,
        accessionCount: Int
    ): String {
        val rv = researchValueState.uppercase()
        val hasActionableSoftLead = rv.contains("ACTIONABLE_SOFT_ANALYSIS_LEAD") ||
            rv.contains("COMPARATOR_REVIEW_LEAD") ||
            rv.contains("ASSAY_DATA_AVAILABILITY_LEAD") ||
            rv.contains("COHORT_CONTRAST_LEAD") ||
            rv.contains("METADATA_REVIEW_LEAD") ||
            rv.contains("DATASET_LOOKUP_LEAD") ||
            rv.contains("ACCESSION_LOOKUP_LEAD")
        if (!hasActionableSoftLead) return evidenceGrade
        if (evidenceScore >= 70) return evidenceGrade
        val prefix = if (accessionCount > 0) "D+" else "D"
        return "$prefix — actionable research lead in progress; useful for dataset follow-up, not biological proof"
    }

    private fun evidenceGrade(evidenceObjects: Int, accessions: Int, routeFit: Int, upgradeAllowed: Boolean): String = when {
        upgradeAllowed && evidenceObjects > 0 && accessions > 0 -> "B — evidence object ready for controlled review"
        evidenceObjects > 0 && accessions > 0 -> "C+ — evidence object present, claims still gated"
        accessions > 0 -> "C — accession found, metadata closure required"
        routeFit >= 70 -> "D+ — high-priority route, no confirmed accession yet"
        routeFit >= 25 -> "D — useful weak lead; feed more data"
        else -> "E+ — early exploratory signal; keep if route is scientifically interesting"
    }

    private fun jsonArray(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { idx ->
            val value = array.opt(idx) ?: return@mapNotNull null
            when (value) {
                is JSONObject -> firstNonBlank(
                    value.optString("accessionId"),
                    value.optString("leadId"),
                    value.optString("targetAxis"),
                    value.optString("routeId"),
                    value.optString("targetMolecularAxis"),
                    value.optString("streamId"),
                    value.optString("querySeed"),
                    value.optString("query"),
                    value.optString("label"),
                    value.optString("gateId"),
                    value.optString("nextAction"),
                    value.toString()
                )
                else -> value.toString()
            }.takeIf { it.isNotBlank() }
        }
    }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() } ?: ""

    private fun truncate(value: String, max: Int): String {
        val oneLine = value.replace('\n', ' ').replace(Regex("\\s+"), " ").trim()
        return if (oneLine.length <= max) oneLine else oneLine.take(max - 1).trimEnd() + "…"
    }

    private fun sanitizeHeader(value: String): String = when (value.trim().uppercase()) {
        "UNKNOWN", "ENGINE: UNKNOWN", "LOCK: UNKNOWN", "STATE: UNKNOWN" -> "PASS"
        else -> value.ifBlank { "PASS" }
    }

    private fun sanitizeEngine(value: String): String = when (value.trim().uppercase()) {
        "UNKNOWN", "ENGINE: UNKNOWN" -> GTIMClaimGuardV250.ENGINE_IDENTITY
        else -> value.ifBlank { GTIMClaimGuardV250.ENGINE_IDENTITY }
    }
}
