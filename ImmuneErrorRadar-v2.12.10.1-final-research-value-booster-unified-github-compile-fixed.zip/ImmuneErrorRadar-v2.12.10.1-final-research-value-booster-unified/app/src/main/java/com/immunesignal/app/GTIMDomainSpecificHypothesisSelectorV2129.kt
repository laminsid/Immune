package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.12.9 — Domain-specific hypothesis selector.
 *
 * This layer prevents broad template bias in the final study dossier. It selects the
 * root-dysfunction and functional-repair hypothesis from the user's actual study domain
 * before global-learning/fallback text can dominate the result. It still produces only
 * research value: no clinical, treatment, DGE, gene/pathway, wet-lab, or organism-use claim.
 */
object GTIMDomainSpecificHypothesisSelectorV2129 {
    const val VERSION: String = "2.12.9-domain-specific-hypothesis-selector"
    const val CLAIM_LIMIT: String = "domain_specific_research_hypothesis_only_no_evidence_upgrade"

    data class Selection(
        val domainKey: String,
        val studyFocus: String,
        val rootDysfunction: String,
        val repairFunction: String,
        val biologicalToolClass: String,
        val mechanismRationale: String,
        val noveltyFrame: String,
        val topResearchHypothesis: String,
        val nextBestActionHint: String,
        val falsificationTriggers: List<String>,
        val prioritySource: String,
        val claimLimit: String = CLAIM_LIMIT
    )

    fun build(report: JSONObject, technicalLines: List<String> = emptyList()): Selection {
        val primary = primaryText(report, technicalLines)
        val corpus = (primary + " " + report.toString().take(16000) + " " + technicalLines.joinToString(" ")).lowercase(Locale.US)
        val primaryLower = primary.lowercase(Locale.US)
        val domain = when {
            has(primaryLower, "pfas", "bpa", "phthalate", "microplastic", "plastic", "xenobiotic", "endocrine disrupt", "pollution", "particle", "toxin") -> "environmental_exposure_xenobiotic"
            has(primaryLower, "depress", "kynuren", "tryptophan", "neuroimmune", "mood") -> "depression_kynurenine_neuroimmune"
            has(primaryLower, "covid", "sars", "corona", "hanta", "hantavirus", "ebola", "filovirus", "viral", "virus", "interferon") -> "viral_interferon_cytokine"
            has(primaryLower, "allerg", "ige", "mast", "eosinophil", "type-2", "type 2", "asthma", "eczema") -> "allergy_type2_barrier"
            has(primaryLower, "diabet", "insulin", "glucose", "metabolic", "obesity", "lps", "endotoxin") -> "metabolic_inflammation"
            has(corpus, "pfas", "bpa", "phthalate", "microplastic", "xenobiotic") -> "environmental_exposure_xenobiotic"
            has(corpus, "depress", "kynuren", "tryptophan", "neuroimmune") -> "depression_kynurenine_neuroimmune"
            has(corpus, "covid", "sars", "corona", "hanta", "ebola", "filovirus", "interferon") -> "viral_interferon_cytokine"
            has(corpus, "allerg", "ige", "mast", "eosinophil", "type-2", "type 2") -> "allergy_type2_barrier"
            has(corpus, "diabet", "insulin", "glucose", "metabolic") -> "metabolic_inflammation"
            else -> "open_mechanism_first"
        }
        return byDomain(domain)
    }

    fun toJson(report: JSONObject, technicalLines: List<String> = emptyList()): JSONObject {
        val s = build(report, technicalLines)
        return JSONObject()
            .put("version", VERSION)
            .put("domainKey", s.domainKey)
            .put("studyFocus", s.studyFocus)
            .put("rootDysfunction", s.rootDysfunction)
            .put("repairFunction", s.repairFunction)
            .put("biologicalToolClass", s.biologicalToolClass)
            .put("mechanismRationale", s.mechanismRationale)
            .put("noveltyFrame", s.noveltyFrame)
            .put("topResearchHypothesis", s.topResearchHypothesis)
            .put("nextBestActionHint", s.nextBestActionHint)
            .put("falsificationTriggers", JSONArray(s.falsificationTriggers))
            .put("prioritySource", s.prioritySource)
            .put("claimLimit", s.claimLimit)
    }

    fun publicLine(report: JSONObject, technicalLines: List<String> = emptyList()): String {
        val s = build(report, technicalLines)
        return "Domain-specific hypothesis lock: ${s.domainKey} → ${s.biologicalToolClass}; repair=${s.repairFunction}; claim_limit=${s.claimLimit}"
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "environmental_exposure_xenobiotic",
        "depression_kynurenine_neuroimmune",
        "viral_interferon_cytokine",
        "allergy_type2_barrier",
        "metabolic_inflammation",
        "bioremediation_or_binding_function_research_route",
        "metabolite_modulating_microbiome_function_route",
        "barrier_mucosal_microbiome_context_route",
        CLAIM_LIMIT
    ))

    private fun byDomain(domain: String): Selection = when (domain) {
        "environmental_exposure_xenobiotic" -> Selection(
            domain,
            "environmental-exposure immune/barrier study",
            "xenobiotic or particle pressure may interact with endocrine signaling, barrier stress, and inflammatory amplification",
            "screen microbial, postbiotic, or material-adjacent biological functions for binding, sequestration, transformation-context, or barrier-resilience support under containment",
            "bioremediation_or_binding_function_research_route",
            "PFAS/BPA/phthalate/microplastic routes must prioritize exposure pressure, endocrine/xenobiotic stress, barrier resilience, and biosafety-heavy evidence over allergy-style type-2 fallback",
            "high-speculation/high-upside: exposure-repair function needs strict biosafety, containment, and independent validation",
            "environmental exposure pressure may create a barrier/endocrine/immune stress state → test whether biosafety-bounded binding/sequestration or barrier-resilience functions reduce measurable exposure-linked inflammatory readouts",
            "Run topic-level external search plus Matrix Shortcut Resolver; prioritize datasets with exposure annotation, tissue/species, comparator labels, endocrine/immune readouts, and processed-expression capsule availability.",
            listOf("no exposure-compatible dataset anchor", "no comparator separating exposed vs control", "no barrier/endocrine/immune readout", "binding/sequestration function has no measurable safe assay route", "candidate route fails biosafety boundary"),
            "primary_query_exposure_terms"
        )
        "depression_kynurenine_neuroimmune" -> Selection(
            domain,
            "depression microbiome-kynurenine inflammatory-tone study",
            "microbiome/metabolite imbalance may shift tryptophan-kynurenine balance and IL-6/TNF inflammatory tone toward neuroimmune stress",
            "restore metabolite balance around tryptophan/kynurenine and reduce low-grade inflammatory amplification",
            "metabolite_modulating_microbiome_function_route",
            "depression/kynurenine questions must prioritize metabolite-neuroimmune mechanisms rather than type-2 allergy fallback",
            "medium novelty: known components exist, but subgroup-specific metabolite-inflammatory repair-function testing remains the research gap",
            "microbiome-metabolite imbalance may shift tryptophan/kynurenine and low-grade IL-6/TNF tone into neuroimmune stress → test whether metabolite-modulating microbial/postbiotic functions change measurable inflammatory and metabolite readouts",
            "Prioritize human cohort evidence with depression/control or high-inflammation subgroup comparator, blood/transcriptome plus microbiome/metabolite evidence, and processed-expression shortcut status.",
            listOf("no human cohort or subgroup comparator", "no tryptophan/kynurenine or metabolite readout", "IL-6/TNF/CRP axis absent or non-reproducible", "microbiome signal is species-name only without function", "independent contradiction check breaks the route"),
            "primary_query_depression_kynurenine_terms"
        )
        "viral_interferon_cytokine" -> Selection(
            domain,
            "viral interferon-cytokine host-response study",
            "viral severity or persistence may reflect interferon timing mismatch, IL-6/TNF cytokine amplification, and endothelial or mucosal tissue stress",
            "support mucosal/barrier resilience and reduce cytokine amplification context after viral trigger",
            "barrier_mucosal_microbiome_context_route",
            "viral host-response routes should prioritize interferon timing, cytokine amplification, endothelial/mucosal stress, and recovery context",
            "conceptual novelty depends on finding compatible severity/recovery/control cohorts and independent host-response support",
            "viral trigger may dysregulate interferon timing and IL-6/TNF amplification → test whether mucosal/barrier resilience context tracks severity, recovery, or inflammatory persistence",
            "Prioritize severe/mild/control or infected/recovered comparator labels, host-response tissue/sample metadata, matrix or processed-expression capsule, and contradiction check.",
            listOf("wrong pathogen/tissue/sample context", "no severity or infected/control comparator", "interferon/cytokine module absent", "endothelial/mucosal context unsupported", "independent viral dataset does not reproduce the route"),
            "primary_query_viral_terms"
        )
        "allergy_type2_barrier" -> Selection(
            domain,
            "allergy/type-2 microbiome-barrier study",
            "barrier and immune-tolerance dysfunction may amplify IgE/mast-cell/eosinophil type-2 inflammation beyond a single allergen-only explanation",
            "restore epithelial/barrier support and reduce type-2 threshold instability",
            "natural_commensal_or_postbiotic_barrier_route",
            "allergy/type-2 routes should prioritize barrier integrity, tolerance thresholds, IgE/mast/eosinophil readouts, and metabolite/postbiotic context",
            "medium novelty: known components exist, but subgroup-specific repair-function testing may be the research gap",
            "barrier/tolerance dysfunction may lower type-2 inflammatory thresholds → test whether barrier-support microbial/postbiotic functions change IgE, mast-cell/eosinophil, epithelial, or type-2 cytokine readouts",
            "Prioritize allergy/asthma/eczema cohorts with case/control labels, epithelial/barrier markers, IgE/mast/eosinophil/type-2 readouts, and processed-expression capsule availability.",
            listOf("no allergy/type-2 comparator", "no barrier or epithelial marker", "IgE/mast/eosinophil/type-2 axis absent", "microbial function is not measurable", "repair marker does not move in predicted direction"),
            "primary_query_allergy_type2_terms"
        )
        "metabolic_inflammation" -> Selection(
            domain,
            "metabolic inflammation immune-energy study",
            "immune-energy mismatch, gut barrier pressure, and low-grade inflammatory loops may sustain metabolic dysfunction",
            "restore immune-energy metabolite context and reduce low-grade inflammatory amplification",
            "metabolite_restoration_or_postbiotic_route",
            "metabolic routes should prioritize insulin/glucose context, IL-6/TNF or CRP tone, barrier/endotoxin markers, and comparator metadata",
            "medium novelty: high value if subgroup-specific inflammatory-metabolic repair functions are separated from generic metabolic association",
            "metabolic stress may create immune-energy mismatch and barrier-linked inflammatory amplification → test whether metabolite/postbiotic context tracks insulin-glucose and inflammatory readouts",
            "Prioritize metabolic disease/control or high/low inflammation subgroups with blood/transcriptome, metabolite, barrier/endotoxin, and processed-expression capsule evidence.",
            listOf("no metabolic comparator", "no inflammatory/metabolic readouts", "barrier/endotoxin signal absent", "no processed/raw matrix or capsule", "signal fails independent dataset"),
            "primary_query_metabolic_terms"
        )
        else -> Selection(
            domain,
            "open immune root-dysfunction study",
            "upstream eco-immune dysfunction remains unresolved and requires mechanism-first exploration",
            "identify the missing biological function before selecting any candidate tool",
            "open_function_first_microbiome_or_postbiotic_route",
            "open topics must not nominate a strong tool before tissue/sample/comparator and mechanism signals are discriminated",
            "conceptual only until a topic-compatible dataset anchor is selected",
            "an unresolved immune phenotype may reflect an upstream dysfunction → test only after dataset anchor, comparator labels, and mechanism readouts are available",
            "Run topic-level external search, select a compatible accession/capsule, then rank repair functions only after route-specific evidence appears.",
            listOf("no dataset anchor", "no comparator", "no mechanism readout", "wrong tissue/species", "no independent support"),
            "open_mechanism_first_fallback"
        )
    }

    private fun primaryText(report: JSONObject, technicalLines: List<String>): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val focus = report.optJSONObject("studyFocusNormalizerV21282") ?: JSONObject()
        val mechanism = report.optJSONObject("mechanismDiscoveryDossierReport") ?: report.optJSONObject("mechanismDiscoveryDossier") ?: JSONObject()
        return firstNonBlank(
            topic.optString("normalizedTopic"),
            topic.optString("rawInput"),
            focus.optString("title"),
            mechanism.optString("researchQuestion"),
            technicalLines.firstOrNull { it.startsWith("Research topic:") }?.removePrefix("Research topic:")?.trim().orEmpty(),
            "immune research question"
        )
    }

    private fun has(text: String, vararg needles: String): Boolean = needles.any { text.contains(it, true) }
    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}
