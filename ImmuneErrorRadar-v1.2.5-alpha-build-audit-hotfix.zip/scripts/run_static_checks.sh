#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
python3 scripts/validate_json.py
python3 scripts/audit_kotlin_delimiters.py
python3 - <<'PY'
import pathlib, xml.etree.ElementTree as ET, re, sys
for p in pathlib.Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('XML parse: PASS')
manifest=pathlib.Path('app/src/main/AndroidManifest.xml').read_text()
for forbidden in ['QUERY_ALL_PACKAGES','WRITE_EXTERNAL_STORAGE','MANAGE_EXTERNAL_STORAGE','ACCESS_FINE_LOCATION']:
    if forbidden in manifest:
        raise SystemExit(f'Forbidden permission found: {forbidden}')
if 'android.permission.INTERNET' not in manifest:
    raise SystemExit('INTERNET permission expected for private Research Autopilot')
xml_ids=set()
for p in pathlib.Path('app/src/main/res/layout').glob('*.xml'):
    xml_ids.update(re.findall(r'@\+id/([A-Za-z0-9_]+)', p.read_text()))
refs=set()
for p in pathlib.Path('app/src/main/java').rglob('*.kt'):
    refs.update(re.findall(r'R\.id\.([A-Za-z0-9_]+)', p.read_text()))
missing=refs-xml_ids
if missing:
    raise SystemExit(f'Missing layout ids: {sorted(missing)}')
print('Layout ID check: PASS')
PY
python3 -B -m py_compile research/*.py
find research -type d -name __pycache__ -prune -exec rm -rf {} +
find research -name '*.pyc' -delete

python3 - <<'PY'
import pathlib
bad=[]
for p in pathlib.Path('.').rglob('__pycache__'):
    bad.append(str(p))
for p in pathlib.Path('.').rglob('*.pyc'):
    bad.append(str(p))
if bad:
    raise SystemExit('Python cache artifacts found in release tree: ' + ', '.join(bad[:20]))
print('Python cache artifact check: PASS')
PY

if [[ "${RUN_SAMPLE_PIPELINE:-0}" == "1" ]]; then
  timeout 20 python3 research/omics_bridge.py research/examples/sample_cases.csv >/tmp/immune_omics_bridge.json
  timeout 20 python3 research/baseline_classifier.py research/examples/sample_matrix.csv >/tmp/immune_baseline.json || true
  timeout 20 python3 research/evidence_quality.py >/tmp/immune_evidence_quality.json
  timeout 20 python3 research/causality_scorer.py 'stress before allergy histamine blood pressure mast cell mechanism' >/tmp/immune_causality.json
  timeout 20 python3 research/personal_time_series.py research/examples/sample_personal_series.csv stress allergy_intensity >/tmp/immune_personal_series.json
  timeout 20 python3 research/negative_controls.py research/examples/sample_personal_series.csv stress dizziness >/tmp/immune_negative_controls.json
  timeout 20 python3 research/hypothesis_ranker.py research/examples/sample_hypotheses.csv >/tmp/immune_hypothesis_ranker.json
  echo 'Research Python sample pipeline: PASS'
else
  echo 'Research Python compile checks: PASS'
  echo 'Sample pipeline skipped by default; run RUN_SAMPLE_PIPELINE=1 scripts/run_static_checks.sh to execute examples.'
fi
