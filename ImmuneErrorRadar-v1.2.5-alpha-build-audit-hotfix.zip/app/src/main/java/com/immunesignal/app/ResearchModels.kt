package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ResearchQuery(
    val id: String,
    val label: String,
    val query: String,
    val reason: String
)

data class EvidenceAssessment(
    val sourceClass: String,
    val speciesClass: String,
    val studyDesign: String,
    val humanEvidence: Boolean,
    val evidenceQualityScore: Int,
    val limitations: List<String>
)

data class CausalityAssessment(
    val causalityScore: Int,
    val temporalityScore: Int,
    val biologicalPlausibilityScore: Int,
    val measurableMarkerScore: Int,
    val repeatabilityScore: Int,
    val contradictionPenalty: Int,
    val rationale: List<String>
)

data class NegativeControlAssessment(
    val status: String,
    val reverseTimeRisk: String,
    val shuffledTimelineRisk: String,
    val unrelatedMarkerRisk: String,
    val notes: List<String>
)

data class PersonalPatternAssessment(
    val repeatedObservationCount: Int,
    val temporalSupport: String,
    val strongestLocalAxes: List<String>,
    val nextBestMeasurement: String
)

data class HypothesisRankCard(
    val hypothesisId: String,
    val label: String,
    val status: String,
    val overallScore: Int,
    val evidenceQualityScore: Int,
    val causalityScore: Int,
    val personalRepeatability: Int,
    val negativeControlStatus: String,
    val nextBestMeasurement: String,
    val whyRanked: List<String>
)

/**
 * v1.2: DTOS-inspired research lock output.
 *
 * A hypothesis object is the single source of truth for one research lead.
 * It prevents the engine from repeating narrative and forces every new source
 * to change a rank, state, gate, next measurement, or bias warning.
 */
data class HypothesisObject(
    val hypothesisId: String,
    val label: String,
    val status: String,
    val discoveryState: String,
    val biasRiskState: String,
    val dataTrustScore: Int,
    val evidenceScore10: Double,
    val causalityScore: Int,
    val minimumDataPackStatus: String,
    val missingData: List<String>,
    val nextBestMeasurement: String,
    val signalFlip: String,
    val decisionImpact: String,
    val falsification: List<String>
)

data class LearningDeltaCard(
    val hypothesisId: String,
    val deltaType: String,
    val previousStatus: String,
    val currentStatus: String,
    val signalFlip: String,
    val decisionImpact: String,
    val nextAction: String
)

data class MistakeRiskCard(
    val risk: String,
    val preventionGate: String,
    val affectedHypotheses: List<String>
)

data class ResearchStateSummary(
    val discoveryState: String,
    val biasRiskState: String,
    val nextEvidence: String,
    val discoveryAction: String,
    val biasAlarm: String
) {
    companion object {
        fun empty() = ResearchStateSummary(
            discoveryState = "Off",
            biasRiskState = "Normal",
            nextEvidence = "Run a research cycle or import a report.",
            discoveryAction = "No active discovery action yet.",
            biasAlarm = "Normal: no ranked hypothesis yet."
        )
    }
}

data class ResearchFinding(
    val source: String,
    val sourceId: String,
    val title: String,
    val published: String,
    val url: String,
    val matchedAxes: List<String>,
    val noveltyScore: Int,
    val bridgeSignal: String,
    val whyItMatters: String,
    val evidence: EvidenceAssessment,
    val causality: CausalityAssessment,
    val negativeControl: NegativeControlAssessment,
    val personalPattern: PersonalPatternAssessment,
    // v1.1: statistical sanity flags promised in CANONICAL_SCORING_FORMULA_v0.9.1.md.
    // Default empty for backward compatibility with old saved findings.
    // Possible values: "METADATA_ONLY", "INSUFFICIENT_DATA", "WEAK_PERMUTATION_TEST",
    // "LOW_POWER", "ABSTRACT_FETCH_FAILED".
    val sanityFlags: List<String> = emptyList()
)

data class ImportedReportSignal(
    val reportId: String,
    val createdAtMillis: Long,
    val title: String,
    val matchedAxes: List<String>,
    val extractedKeywords: List<String>,
    val preview: String
)

data class ResearchSteeringProfile(
    val profileId: String,
    val createdAtMillis: Long,
    val variables: List<String>,
    val focusQuestion: String,
    val requiredTerms: List<String>,
    val excludedTerms: List<String>,
    val inferredAxes: List<String>
)

data class KnowledgeDelta(
    val newSourcesSaved: Int,
    val repeatedSourcesSkipped: Int,
    val newAxisPairs: List<String>,
    val manualReportSignalsUsed: Int,
    val dnaRnaSignals: Int,
    val steeredQueriesGenerated: Int,
    val learningNotes: List<String>
)

data class ResearchRunLimits(
    val maxSearchMillis: Long = 10L * 60L * 1000L,
    val maxLearningMillis: Long = 15L * 60L * 1000L,
    val maxQueries: Int = 12,
    val maxResultsPerQuery: Int = 12
)

data class ResearchCycleReport(
    val id: String,
    val createdAtMillis: Long,
    val completedAtMillis: Long,
    val stoppedByUser: Boolean,
    val stopReason: String,
    val searchDurationMillis: Long,
    val learningDurationMillis: Long,
    val queries: List<ResearchQuery>,
    val findings: List<ResearchFinding>,
    val activeSteeringProfile: ResearchSteeringProfile?,
    val importedReportSignals: List<ImportedReportSignal>,
    val hypothesisRankCards: List<HypothesisRankCard>,
    val emergentLinks: List<String>,
    val nextQuestions: List<String>,
    val knowledgeDelta: KnowledgeDelta,
    val limitations: List<String>,
    val hypothesisObjects: List<HypothesisObject> = emptyList(),
    val learningDeltaCards: List<LearningDeltaCard> = emptyList(),
    val mistakeRiskCards: List<MistakeRiskCard> = emptyList(),
    val researchStateSummary: ResearchStateSummary = ResearchStateSummary.empty()
)

object ResearchJsonCodec {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    fun reportToJson(report: ResearchCycleReport): JSONObject {
        return JSONObject()
            .put("schemaVersion", 12)
            .put("productMode", "Immune Error Radar Private Research Autopilot")
            .put("id", report.id)
            .put("createdAtMillis", report.createdAtMillis)
            .put("completedAtMillis", report.completedAtMillis)
            .put("createdAtText", dateFormat.format(Date(report.createdAtMillis)))
            .put("completedAtText", dateFormat.format(Date(report.completedAtMillis)))
            .put("stoppedByUser", report.stoppedByUser)
            .put("stopReason", report.stopReason)
            .put("searchDurationMillis", report.searchDurationMillis)
            .put("learningDurationMillis", report.learningDurationMillis)
            .put("queries", JSONArray(report.queries.map { queryToJson(it) }))
            .put("findings", JSONArray(report.findings.map { findingToJson(it) }))
            .put("activeSteeringProfile", report.activeSteeringProfile?.let { steeringProfileToJson(it) } ?: JSONObject.NULL)
            .put("importedReportSignals", JSONArray(report.importedReportSignals.map { importedSignalToJson(it) }))
            .put("hypothesisRankCards", JSONArray(report.hypothesisRankCards.map { hypothesisCardToJson(it) }))
            .put("hypothesisObjects", JSONArray(report.hypothesisObjects.map { hypothesisObjectToJson(it) }))
            .put("learningDeltaCards", JSONArray(report.learningDeltaCards.map { learningDeltaCardToJson(it) }))
            .put("mistakeRiskCards", JSONArray(report.mistakeRiskCards.map { mistakeRiskCardToJson(it) }))
            .put("researchStateSummary", researchStateSummaryToJson(report.researchStateSummary))
            .put("emergentLinks", JSONArray(report.emergentLinks))
            .put("nextQuestions", JSONArray(report.nextQuestions))
            .put("knowledgeDelta", knowledgeDeltaToJson(report.knowledgeDelta))
            .put("limitations", JSONArray(report.limitations))
    }

    fun findingToJson(finding: ResearchFinding): JSONObject {
        return JSONObject()
            .put("source", finding.source)
            .put("sourceId", finding.sourceId)
            .put("title", finding.title)
            .put("published", finding.published)
            .put("url", finding.url)
            .put("matchedAxes", JSONArray(finding.matchedAxes))
            .put("noveltyScore", finding.noveltyScore)
            .put("bridgeSignal", finding.bridgeSignal)
            .put("whyItMatters", finding.whyItMatters)
            .put("evidence", evidenceToJson(finding.evidence))
            .put("causality", causalityToJson(finding.causality))
            .put("negativeControl", negativeControlToJson(finding.negativeControl))
            .put("personalPattern", personalPatternToJson(finding.personalPattern))
            // v1.1: emit statistical sanity flags so report exports show them.
            .put("sanityFlags", JSONArray(finding.sanityFlags))
    }

    fun evidenceToJson(evidence: EvidenceAssessment): JSONObject {
        return JSONObject()
            .put("sourceClass", evidence.sourceClass)
            .put("speciesClass", evidence.speciesClass)
            .put("studyDesign", evidence.studyDesign)
            .put("humanEvidence", evidence.humanEvidence)
            .put("evidenceQualityScore", evidence.evidenceQualityScore)
            .put("limitations", JSONArray(evidence.limitations))
    }

    fun causalityToJson(causality: CausalityAssessment): JSONObject {
        return JSONObject()
            .put("causalityScore", causality.causalityScore)
            .put("temporalityScore", causality.temporalityScore)
            .put("biologicalPlausibilityScore", causality.biologicalPlausibilityScore)
            .put("measurableMarkerScore", causality.measurableMarkerScore)
            .put("repeatabilityScore", causality.repeatabilityScore)
            .put("contradictionPenalty", causality.contradictionPenalty)
            .put("rationale", JSONArray(causality.rationale))
    }

    fun negativeControlToJson(negative: NegativeControlAssessment): JSONObject {
        return JSONObject()
            .put("status", negative.status)
            .put("reverseTimeRisk", negative.reverseTimeRisk)
            .put("shuffledTimelineRisk", negative.shuffledTimelineRisk)
            .put("unrelatedMarkerRisk", negative.unrelatedMarkerRisk)
            .put("notes", JSONArray(negative.notes))
    }

    fun personalPatternToJson(pattern: PersonalPatternAssessment): JSONObject {
        return JSONObject()
            .put("repeatedObservationCount", pattern.repeatedObservationCount)
            .put("temporalSupport", pattern.temporalSupport)
            .put("strongestLocalAxes", JSONArray(pattern.strongestLocalAxes))
            .put("nextBestMeasurement", pattern.nextBestMeasurement)
    }

    fun hypothesisCardToJson(card: HypothesisRankCard): JSONObject {
        return JSONObject()
            .put("hypothesisId", card.hypothesisId)
            .put("label", card.label)
            .put("status", card.status)
            .put("overallScore", card.overallScore)
            .put("evidenceQualityScore", card.evidenceQualityScore)
            .put("causalityScore", card.causalityScore)
            .put("personalRepeatability", card.personalRepeatability)
            .put("negativeControlStatus", card.negativeControlStatus)
            .put("nextBestMeasurement", card.nextBestMeasurement)
            .put("whyRanked", JSONArray(card.whyRanked))
    }

    fun hypothesisObjectToJson(obj: HypothesisObject): JSONObject {
        return JSONObject()
            .put("hypothesisId", obj.hypothesisId)
            .put("label", obj.label)
            .put("status", obj.status)
            .put("discoveryState", obj.discoveryState)
            .put("biasRiskState", obj.biasRiskState)
            .put("dataTrustScore", obj.dataTrustScore)
            .put("evidenceScore10", obj.evidenceScore10)
            .put("causalityScore", obj.causalityScore)
            .put("minimumDataPackStatus", obj.minimumDataPackStatus)
            .put("missingData", JSONArray(obj.missingData))
            .put("nextBestMeasurement", obj.nextBestMeasurement)
            .put("signalFlip", obj.signalFlip)
            .put("decisionImpact", obj.decisionImpact)
            .put("falsification", JSONArray(obj.falsification))
    }

    fun learningDeltaCardToJson(card: LearningDeltaCard): JSONObject {
        return JSONObject()
            .put("hypothesisId", card.hypothesisId)
            .put("deltaType", card.deltaType)
            .put("previousStatus", card.previousStatus)
            .put("currentStatus", card.currentStatus)
            .put("signalFlip", card.signalFlip)
            .put("decisionImpact", card.decisionImpact)
            .put("nextAction", card.nextAction)
    }

    fun mistakeRiskCardToJson(card: MistakeRiskCard): JSONObject {
        return JSONObject()
            .put("risk", card.risk)
            .put("preventionGate", card.preventionGate)
            .put("affectedHypotheses", JSONArray(card.affectedHypotheses))
    }

    fun researchStateSummaryToJson(summary: ResearchStateSummary): JSONObject {
        return JSONObject()
            .put("discoveryState", summary.discoveryState)
            .put("biasRiskState", summary.biasRiskState)
            .put("nextEvidence", summary.nextEvidence)
            .put("discoveryAction", summary.discoveryAction)
            .put("biasAlarm", summary.biasAlarm)
    }

    fun steeringProfileToJson(profile: ResearchSteeringProfile): JSONObject {
        return JSONObject()
            .put("profileId", profile.profileId)
            .put("createdAtMillis", profile.createdAtMillis)
            .put("variables", JSONArray(profile.variables))
            .put("focusQuestion", profile.focusQuestion)
            .put("requiredTerms", JSONArray(profile.requiredTerms))
            .put("excludedTerms", JSONArray(profile.excludedTerms))
            .put("inferredAxes", JSONArray(profile.inferredAxes))
    }

    fun steeringProfileFromJson(obj: JSONObject): ResearchSteeringProfile {
        val variables = obj.optJSONArray("variables") ?: JSONArray()
        val required = obj.optJSONArray("requiredTerms") ?: JSONArray()
        val excluded = obj.optJSONArray("excludedTerms") ?: JSONArray()
        val axes = obj.optJSONArray("inferredAxes") ?: JSONArray()
        return ResearchSteeringProfile(
            profileId = obj.optString("profileId"),
            createdAtMillis = obj.optLong("createdAtMillis"),
            variables = (0 until variables.length()).map { variables.optString(it) }.filter { it.isNotBlank() },
            focusQuestion = obj.optString("focusQuestion"),
            requiredTerms = (0 until required.length()).map { required.optString(it) }.filter { it.isNotBlank() },
            excludedTerms = (0 until excluded.length()).map { excluded.optString(it) }.filter { it.isNotBlank() },
            inferredAxes = (0 until axes.length()).map { axes.optString(it) }.filter { it.isNotBlank() }
        )
    }

    fun importedSignalToJson(signal: ImportedReportSignal): JSONObject {
        return JSONObject()
            .put("reportId", signal.reportId)
            .put("createdAtMillis", signal.createdAtMillis)
            .put("title", signal.title)
            .put("matchedAxes", JSONArray(signal.matchedAxes))
            .put("extractedKeywords", JSONArray(signal.extractedKeywords))
            .put("preview", signal.preview)
    }

    fun importedSignalFromJson(obj: JSONObject): ImportedReportSignal {
        val axes = obj.optJSONArray("matchedAxes") ?: JSONArray()
        val keys = obj.optJSONArray("extractedKeywords") ?: JSONArray()
        return ImportedReportSignal(
            reportId = obj.optString("reportId"),
            createdAtMillis = obj.optLong("createdAtMillis"),
            title = obj.optString("title"),
            matchedAxes = (0 until axes.length()).map { axes.optString(it) }.filter { it.isNotBlank() },
            extractedKeywords = (0 until keys.length()).map { keys.optString(it) }.filter { it.isNotBlank() },
            preview = obj.optString("preview")
        )
    }

    private fun queryToJson(query: ResearchQuery): JSONObject {
        return JSONObject()
            .put("id", query.id)
            .put("label", query.label)
            .put("query", query.query)
            .put("reason", query.reason)
    }

    private fun knowledgeDeltaToJson(delta: KnowledgeDelta): JSONObject {
        return JSONObject()
            .put("newSourcesSaved", delta.newSourcesSaved)
            .put("repeatedSourcesSkipped", delta.repeatedSourcesSkipped)
            .put("newAxisPairs", JSONArray(delta.newAxisPairs))
            .put("manualReportSignalsUsed", delta.manualReportSignalsUsed)
            .put("dnaRnaSignals", delta.dnaRnaSignals)
            .put("steeredQueriesGenerated", delta.steeredQueriesGenerated)
            .put("learningNotes", JSONArray(delta.learningNotes))
    }
}
