package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Unit tests for AxisMatcher (v1.1).
 *
 * AxisMatcher consolidates two previously-divergent dictionaries
 * (matchAxes in ResearchAutopilot, inferAxes in ResearchKnowledgeStore).
 * These tests document the canonical keyword set so future edits don't
 * silently change classification.
 */
class AxisMatcherTest {

    @Test
    fun `empty input returns empty list`() {
        assertTrue(AxisMatcher.match("").isEmpty())
        assertTrue(AxisMatcher.match("   ").isEmpty())
    }

    @Test
    fun `allergy keywords detect type2 axis`() {
        for (kw in listOf("ige levels", "asthma diagnosis", "mast cell activation",
                          "histamine receptor", "type-2 inflammation", "type 2 immunity",
                          "eosinophil count")) {
            assertTrue("'$kw' must trigger type2_allergy_axis",
                AxisMatcher.match(kw).contains("type2_allergy_axis"))
        }
    }

    @Test
    fun `mast keyword alone triggers type2 axis`() {
        // Important: previously-divergent dicts handled "mast" vs "mast cell" inconsistently.
        // Canonical: both work.
        assertTrue(AxisMatcher.match("mast cells produce histamine")
            .contains("type2_allergy_axis"))
        assertTrue(AxisMatcher.match("mast")
            .contains("type2_allergy_axis"))
    }

    @Test
    fun `frailty triggers aging axis - was missed by inferAxes`() {
        // Regression: v0.9.0 inferAxes lacked "frailty"; matchAxes had it.
        // Canonical AxisMatcher must include both.
        assertTrue(AxisMatcher.match("frailty in elderly")
            .contains("aging_immune_axis"))
    }

    @Test
    fun `vascular triggers autonomic_vascular_axis - was missed by inferAxes`() {
        assertTrue(AxisMatcher.match("vascular tone study")
            .contains("autonomic_vascular_axis"))
        assertTrue(AxisMatcher.match("heart rate variability")
            .contains("autonomic_vascular_axis"))
    }

    @Test
    fun `chromatin triggers dna_genomic_axis - was missed by inferAxes`() {
        assertTrue(AxisMatcher.match("chromatin remodeling")
            .contains("dna_genomic_axis"))
    }

    @Test
    fun `male hormone triggers testosterone axis - was missed by inferAxes`() {
        assertTrue(AxisMatcher.match("male hormone deficiency")
            .contains("testosterone_immune_axis"))
    }

    @Test
    fun `multiple axes detected from a single text`() {
        val result = AxisMatcher.match(
            "RNA-seq study of stress-induced histamine and IL-6 in patients with chronic back pain"
        )
        assertTrue(result.contains("rna_transcriptomic_axis"))
        assertTrue(result.contains("psychoneuroimmune_axis"))
        assertTrue(result.contains("type2_allergy_axis"))
        assertTrue(result.contains("tnf_il6_autoimmune_axis"))
        assertTrue(result.contains("psychomusculoskeletal_axis"))
    }

    @Test
    fun `unrelated text returns empty list`() {
        val result = AxisMatcher.match("the weather is sunny today")
        assertTrue("got $result", result.isEmpty())
    }

    @Test
    fun `match is case-insensitive`() {
        val a = AxisMatcher.match("EOSINOPHIL")
        val b = AxisMatcher.match("eosinophil")
        assertEquals(a, b)
    }

    @Test
    fun `result is deduplicated even with overlapping keywords`() {
        // "ige" + "asthma" + "histamine" all map to type2_allergy_axis
        val r = AxisMatcher.match("ige asthma histamine eosinophil")
        assertEquals(1, r.count { it == "type2_allergy_axis" })
    }

    @Test
    fun `all 15 axes are reachable via the matcher`() {
        // Smoke test: AxisMatcher.knownAxes() defines 15 axes in v1.1.
        // If you add or remove an axis, update this number deliberately.
        assertEquals(15, AxisMatcher.knownAxes().size)
        assertEquals(15, AxisMatcher.knownAxes().distinct().size)
    }
}
