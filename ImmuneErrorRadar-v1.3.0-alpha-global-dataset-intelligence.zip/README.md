# Immune Error Radar v1.3.0-alpha — Global Dataset Intelligence

Immune Error Radar is a private Android research engine for studying immune over-response, immune trigger logic, antiviral response, recovery, regulatory failure, and cross-condition immune mechanisms.

It is **not** a personal symptom diary as its main purpose. The Android app is a control panel for global immune research: search public literature/dataset metadata, map immune axes, rank hypotheses, and produce discovery reports.

## Core objective

Study how the immune system decides:

```text
Trigger → Immune response axis → Tissue effect → Outcome
```

Examples:

- Allergen → Type-2 / IgE / mast-cell axis → airway or skin irritation
- Virus → interferon / T-cell / antibody response → recovery or deterioration
- Self-antigen → TNF / IL-6 inflammatory axis → chronic autoimmune-like burden
- Regulatory failure → weak IL-10/Treg brake → runaway amplification

The long-term research aim is to understand how immune responses can become more precise against new viral variants without becoming destructive.

## v1.3 additions

- GlobalImmuneIntelligenceEngine
- DatasetDiscoveryEngine
- DatasetQualityScorer
- ImmuneAxisMapper
- TriggerResponseGraphBuilder
- GlobalHypothesisLedgerBuilder
- PathogenResponseComparator
- Global report section in JSON/PDF/brief output
- Extended AxisMatcher for antiviral/adaptive/tissue-damage/recovery axes
- Python research helpers for global dataset curation and trigger-response graphing

## What v1.3 does not do

- No PyTorch / PyTorch Geometric inside APK
- No Random Forest or SimCLR inside Android
- No clinical prediction
- No diagnosis
- No treatment or drug recommendation
- No claim of protection against future viral variants

## Android privacy model

- Private imported reports remain on device.
- Research Autopilot uses the internet only for public literature metadata search.
- Research steering terms are sanitized before outbound search.
- No account, telemetry, tracking, or server sync.

## Safety boundary

This project is a hypothesis and dataset-discovery engine only. Every lead remains research-grade until source quality, species, dataset access, trigger-response-outcome labels, contradiction checks, and falsification paths are reviewed.

## Build

Open in Android Studio or use GitHub Actions. This alpha ZIP does not bundle a Gradle Wrapper. See `BUILD.md`.

```bash
gradle :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Static checks

```bash
bash scripts/run_static_checks.sh
RUN_SAMPLE_PIPELINE=1 bash scripts/run_static_checks.sh
```

## Research pipeline examples

```bash
python3 research/global_dataset_registry.py research/examples/global_dataset_candidates.csv
python3 research/immune_axis_mapper.py "interferon IL10 CD8 antibody tissue damage recovery"
python3 research/trigger_response_graph.py "virus interferon IL10 tissue damage recovery"
python3 research/pathogen_response_comparator.py "virus interferon IL10 tissue damage recovery"
```

## Project rule

Do not add heavy ML until public datasets are curated. Current priority:

```text
Dataset discovery → axis mapping → trigger-response-outcome graph → global hypothesis ledger → falsification
```

See:

- `docs/GLOBAL_IMMUNE_DATASET_INTELLIGENCE_v1.3.md`
- `docs/PROJECT_INTERNAL_SHEET_v1.3.md`
- `docs/BACKLOG_v2_ML_IDEAS.md`
