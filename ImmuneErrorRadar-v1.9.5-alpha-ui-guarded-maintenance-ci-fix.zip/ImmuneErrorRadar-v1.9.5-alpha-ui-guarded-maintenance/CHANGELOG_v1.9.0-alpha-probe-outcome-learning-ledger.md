# Immune Error Radar v1.9.0-alpha-probe-outcome-learning-ledger

## Purpose
Closes the v1.8.9 executable probe loop by verifying whether the previous probe actually closed its evidence pack in the next cycle.

## Added
- `ScientificDiscoveryProbeOutcomeLedgerV190.kt`
- `ScientificDiscoveryProbeOutcomeLedgerEngineV190`
- `ProbeOutcomeClosureSignal`
- `ScientificDiscoveryProbeOutcomeLedgerReport`
- JSON export via `scientificDiscoveryProbeOutcomeLedgerReport`
- report/UI/PDF rendering
- next-cycle routing integration through `CognitiveNextCycleBridge`
- knowledge ledger persistence
- scientific term index upgrade to `scientific_term_index_v1.9.0.json`

## Decision behavior
The engine compares the previous probe plan's evidence pack/pass/fail/kill criteria against the current cycle's actual evidence keys, then emits closed/unresolved keys, pass/fail/kill signals, replay penalties, route/belief disposition, and next probe decision.

## Claim boundary
This layer guides routing and memory only. It does not prove biology, causality, diagnosis, treatment, or immune outcome.
