package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v1.6.3: epistemic belief model.
 *
 * The cumulative map remembers objects and links. This layer remembers what the
 * researcher currently believes about those links, how credible each belief is,
 * what would falsify it, and when it must be weakened, revised, or retired.
 *
 * Boundary: beliefs are research priors only. They guide search and review. They
 * do not prove biology, diagnosis, treatment, protection, or causality.
 */
data class EpistemicBelief(
    val beliefId: String,
    val statement: String,
    val beliefType: String,
    val status: String,
    val confidence: Int,
    val credibility: Int,
    val supportCount: Int,
    val contradictionCount: Int,
    val linkedNodes: List<String>,
    val requiredEvidenceToKeep: List<String>,
    val falsifiers: List<String>,
    val abandonmentQuestion: String = "",
    val lastChangedReason: String
)

data class EpistemicBeliefUpdate(
    val beliefId: String,
    val updateType: String,
    val previousStatus: String,
    val newStatus: String,
    val reason: String,
    val nextAction: String
)

data class EpistemicBeliefTransitionSummary(
    val strengthenedBelief: String,
    val weakenedBelief: String,
    val droppedBelief: String,
    val pruningRule: String,
    val unusedWeakBeliefsPruned: Int,
    val abandonmentQuestion: String
) {
    companion object {
        fun empty() = EpistemicBeliefTransitionSummary(
            strengthenedBelief = "None yet.",
            weakenedBelief = "None yet.",
            droppedBelief = "None yet.",
            pruningRule = "Weak unused beliefs are not carried forward unless they are supported, linked to the current cycle, or foundation-level priors.",
            unusedWeakBeliefsPruned = 0,
            abandonmentQuestion = "What evidence would make me abandon this belief?"
        )
    }
}

data class EpistemicBeliefReport(
    val active: Boolean,
    val state: String,
    val beliefScore: Int,
    val carriedForwardBeliefs: Int,
    val newBeliefsThisCycle: Int,
    val weakenedBeliefs: Int,
    val revisedBeliefs: Int,
    val retiredBeliefs: Int,
    val beliefs: List<EpistemicBelief>,
    val updates: List<EpistemicBeliefUpdate>,
    val foundationBeliefs: List<String>,
    val mutableBeliefWarnings: List<String>,
    val nextBeliefAction: String,
    val visibleBrief: String,
    val transitionSummary: EpistemicBeliefTransitionSummary = EpistemicBeliefTransitionSummary.empty(),
    val claimLimit: String = "epistemic_beliefs_not_biological_proof"
) {
    companion object {
        fun empty() = EpistemicBeliefReport(
            active = false,
            state = "NOT_BUILT",
            beliefScore = 0,
            carriedForwardBeliefs = 0,
            newBeliefsThisCycle = 0,
            weakenedBeliefs = 0,
            revisedBeliefs = 0,
            retiredBeliefs = 0,
            beliefs = emptyList(),
            updates = emptyList(),
            foundationBeliefs = emptyList(),
            mutableBeliefWarnings = listOf("No epistemic belief model has run yet."),
            nextBeliefAction = "Run a research cycle to initialize provisional beliefs.",
            visibleBrief = "No belief model yet.",
            transitionSummary = EpistemicBeliefTransitionSummary.empty(),
            claimLimit = "epistemic_beliefs_not_biological_proof"
        )
    }
}

object EpistemicBeliefEngine {
    private const val DEFAULT_ABANDONMENT_QUESTION = "What evidence would make me abandon this belief?"
    private const val PRUNING_RULE = "Weak unused beliefs are not carried forward unless they are supported, linked to the current cycle, or foundation-level priors."

    fun build(
        currentFindings: List<ResearchFinding>,
        hypothesisObjects: List<HypothesisObject>,
        evidenceObjects: List<EvidenceObject>,
        datasetForagingReport: DatasetForagingReport,
        specializedReasoningReport: SpecializedReasoningReport,
        knowledgeMapReport: KnowledgeMapReport,
        recentReportLines: List<String>
    ): EpistemicBeliefReport {
        val prior = readPriorBeliefReport(recentReportLines)
        val activeNodeHints = cycleNodeHints(
            currentFindings = currentFindings,
            hypothesisObjects = hypothesisObjects,
            evidenceObjects = evidenceObjects,
            datasetForagingReport = datasetForagingReport,
            knowledgeMapReport = knowledgeMapReport
        )
        val beliefs = linkedMapOf<String, EpistemicBelief>()
        val updates = mutableListOf<EpistemicBeliefUpdate>()
        val prunedPriorUpdates = mutableListOf<EpistemicBeliefUpdate>()

        fun putBelief(candidate: EpistemicBelief) {
            val normalizedCandidate = candidate.withAbandonmentQuestion()
            val previous = beliefs[normalizedCandidate.beliefId]
            if (previous == null) {
                beliefs[normalizedCandidate.beliefId] = normalizedCandidate
                if (normalizedCandidate.status != "CARRIED_FORWARD") {
                    updates += EpistemicBeliefUpdate(
                        beliefId = normalizedCandidate.beliefId,
                        updateType = "NEW_BELIEF",
                        previousStatus = "NONE",
                        newStatus = normalizedCandidate.status,
                        reason = normalizedCandidate.lastChangedReason,
                        nextAction = nextActionFor(normalizedCandidate)
                    )
                }
            } else {
                val mergedSupport = previous.supportCount + normalizedCandidate.supportCount
                val mergedContradictions = previous.contradictionCount + normalizedCandidate.contradictionCount
                val status = resolveStatus(normalizedCandidate.status, normalizedCandidate.confidence, normalizedCandidate.credibility, mergedSupport, mergedContradictions)
                val merged = previous.copy(
                    status = status,
                    confidence = maxOf(previous.confidence, normalizedCandidate.confidence).coerceIn(0, 100),
                    credibility = minOf(maxOf(previous.credibility, normalizedCandidate.credibility), 100).coerceIn(0, 100),
                    supportCount = mergedSupport,
                    contradictionCount = mergedContradictions,
                    linkedNodes = (previous.linkedNodes + normalizedCandidate.linkedNodes).distinct().take(16),
                    requiredEvidenceToKeep = (previous.requiredEvidenceToKeep + normalizedCandidate.requiredEvidenceToKeep).distinct().take(12),
                    falsifiers = (previous.falsifiers + normalizedCandidate.falsifiers).distinct().take(12),
                    abandonmentQuestion = abandonmentQuestionFor(normalizedCandidate),
                    lastChangedReason = normalizedCandidate.lastChangedReason.ifBlank { previous.lastChangedReason }
                ).withAbandonmentQuestion()
                beliefs[candidate.beliefId] = merged
                if (status != previous.status || merged.credibility < previous.credibility) {
                    updates += EpistemicBeliefUpdate(
                        beliefId = merged.beliefId,
                        updateType = if (status == "REVISE_REQUIRED") "BELIEF_REQUIRES_REVISION" else "BELIEF_CHANGED",
                        previousStatus = previous.status,
                        newStatus = status,
                        reason = merged.lastChangedReason,
                        nextAction = nextActionFor(merged)
                    )
                }
            }
        }

        prior.beliefs.take(40).forEach { priorBelief ->
            val normalizedPrior = priorBelief.withAbandonmentQuestion()
            if (shouldCarryPriorBelief(normalizedPrior, activeNodeHints)) {
                putBelief(
                    normalizedPrior.copy(
                        status = if (normalizedPrior.status == "RETIRED") "RETIRED" else "CARRIED_FORWARD",
                        lastChangedReason = "Carried forward from previous belief report."
                    )
                )
            } else {
                val dropped = normalizedPrior.copy(
                    status = "RETIRED",
                    credibility = minOf(normalizedPrior.credibility, 20),
                    lastChangedReason = "Dropped because it was weak, unused, and not linked to this cycle's evidence path."
                ).withAbandonmentQuestion()
                prunedPriorUpdates += EpistemicBeliefUpdate(
                    beliefId = dropped.beliefId,
                    updateType = "DROPPED_UNUSED_WEAK_BELIEF",
                    previousStatus = normalizedPrior.status,
                    newStatus = "RETIRED",
                    reason = dropped.lastChangedReason,
                    nextAction = nextActionFor(dropped)
                )
            }
        }

        foundationBeliefs().forEach { putBelief(it) }

        hypothesisObjects.take(12).forEach { hyp ->
            val confidence = ((hyp.evidenceScore10 * 10.0).toInt() + hyp.dataTrustScore) / 2
            val missingCritical = hyp.missingData.any { it.contains("outcome", true) || it.contains("time", true) || it.contains("control", true) }
            val contradictionHits = evidenceObjects.count { it.linkedHypothesisId == hyp.hypothesisId && it.contradictsHypothesis }
            val supportHits = evidenceObjects.count { it.linkedHypothesisId == hyp.hypothesisId && !it.contradictsHypothesis }
            val credibility = (hyp.dataTrustScore + hyp.causalityScore) / 2 - contradictionHits * 15 - if (missingCritical) 12 else 0
            putBelief(
                EpistemicBelief(
                    beliefId = id("hypothesis", hyp.hypothesisId),
                    statement = "${hyp.label.take(160)} remains a provisional research belief, not a conclusion.",
                    beliefType = "HYPOTHESIS_BELIEF",
                    status = resolveStatus(hyp.status, confidence, credibility, supportHits, contradictionHits),
                    confidence = confidence.coerceIn(0, 100),
                    credibility = credibility.coerceIn(0, 100),
                    supportCount = supportHits,
                    contradictionCount = contradictionHits,
                    linkedNodes = listOf("hypothesis:${sanitize(hyp.hypothesisId)}"),
                    requiredEvidenceToKeep = (hyp.missingData + listOf("independent_replication", "negative_control", "time_order")).distinct().take(10),
                    falsifiers = hyp.falsification.ifEmpty { listOf("better_competing_explanation", "failed_minimum_data_pack", "reverse_time_explanation") },
                    lastChangedReason = if (missingCritical) "Critical evidence is still missing; belief remains mutable." else "Hypothesis converted into mutable belief state."
                )
            )
        }

        currentFindings.take(20).forEach { finding ->
            finding.matchedAxes.distinct().take(6).forEach { axis ->
                val contradictionPenalty = finding.causality.contradictionPenalty.coerceIn(0, 40)
                val confidence = (finding.evidence.evidenceQualityScore + finding.causality.causalityScore) / 2
                putBelief(
                    EpistemicBelief(
                        beliefId = id("axis", axis),
                        statement = "Axis '$axis' is relevant enough to guide future search, but remains hypothesis-grade.",
                        beliefType = "AXIS_PRIOR",
                        status = if (contradictionPenalty >= 20) "WEAKENED" else "ACTIVE_PRIOR",
                        confidence = confidence.coerceIn(0, 100),
                        credibility = (confidence - contradictionPenalty).coerceIn(0, 100),
                        supportCount = 1,
                        contradictionCount = if (contradictionPenalty >= 20) 1 else 0,
                        linkedNodes = listOf("axis:${sanitize(axis)}", "source:${sanitize(finding.source + ":" + finding.sourceId)}"),
                        requiredEvidenceToKeep = listOf("direct_dataset_metadata", "outcome_labels", "controls_or_comparator"),
                        falsifiers = listOf("axis_only_title_match", "off_route_dataset", "no_outcome_labels", "contradictory_control"),
                        lastChangedReason = "Observed in current cycle and attached to map as a mutable prior."
                    )
                )
            }
        }

        datasetForagingReport.routeFitAssessments.take(16).forEach { fit ->
            val contradiction = fit.blocksHypothesisUpgrade || fit.status.contains("OFF", true)
            val credibility = fit.routeFitScore - if (contradiction) 35 else 0 - if (datasetForagingReport.parsedMetadata.isEmpty()) 12 else 0
            putBelief(
                EpistemicBelief(
                    beliefId = id("route", fit.accession + "_" + fit.targetRoute),
                    statement = "Dataset ${fit.accession} may fit route ${fit.targetRoute}, but the belief must survive metadata parsing and contrastive checks.",
                    beliefType = "ROUTE_BELIEF",
                    status = resolveStatus(fit.status, fit.routeFitScore, credibility, if (contradiction) 0 else 1, if (contradiction) 1 else 0),
                    confidence = fit.routeFitScore.coerceIn(0, 100),
                    credibility = credibility.coerceIn(0, 100),
                    supportCount = if (contradiction) 0 else 1,
                    contradictionCount = if (contradiction) 1 else 0,
                    linkedNodes = listOf("dataset:${sanitize(fit.accession)}", "route:${sanitize(fit.targetRoute)}"),
                    requiredEvidenceToKeep = listOf("minimum_metadata_parse", "condition_labels", "outcome_labels", "contrastive_gate"),
                    falsifiers = listOf("metadata_not_parsed", "route_fit_title_only", "no_controls", "wrong_species"),
                    lastChangedReason = if (datasetForagingReport.parsedMetadata.isEmpty()) "High route fit is not enough; metadata parsing is still required." else "Route belief created from route-fit assessment."
                )
            )
        }

        knowledgeMapReport.gaps.filter { it.blocksUpgrade }.take(12).forEach { gap ->
            val affected = gap.affectedNodes.ifEmpty { listOf("knowledge_map") }
            putBelief(
                EpistemicBelief(
                    beliefId = id("gap", gap.gapId),
                    statement = "Open gap '${gap.gapId}' weakens any belief depending on ${affected.joinToString(", ").take(140)}.",
                    beliefType = "CREDIBILITY_GAP",
                    status = if (gap.severity >= 85) "REVISE_REQUIRED" else "WEAKENED",
                    confidence = gap.severity.coerceIn(0, 100),
                    credibility = (100 - gap.severity).coerceIn(0, 100),
                    supportCount = 0,
                    contradictionCount = 1,
                    linkedNodes = affected.take(10),
                    requiredEvidenceToKeep = listOf(gap.nextAction),
                    falsifiers = listOf("gap_remains_unresolved", "same_gap_repeats", "better_route_explains_data"),
                    lastChangedReason = "Blocking knowledge-map gap reduced belief credibility."
                )
            )
        }

        if (specializedReasoningReport.active) {
            val severeGaps = specializedReasoningReport.evidenceGaps.count { it.severity >= 70 }
            val credibility = (specializedReasoningReport.specialistScore - severeGaps * 8).coerceIn(0, 100)
            putBelief(
                EpistemicBelief(
                    beliefId = "belief:specialist_protocol",
                    statement = "The specialist protocol is the active standard for deciding what must be tested next.",
                    beliefType = "METHOD_BELIEF",
                    status = if (severeGaps >= 2) "ACTIVE_WITH_WARNINGS" else "ACTIVE_PRIOR",
                    confidence = specializedReasoningReport.specialistScore.coerceIn(0, 100),
                    credibility = credibility,
                    supportCount = maxOf(1, specializedReasoningReport.nextCycleProtocol.size),
                    contradictionCount = severeGaps,
                    linkedNodes = listOf("specialized_reasoning"),
                    requiredEvidenceToKeep = listOf("decisive_next_test", "falsification_lane", "discriminator_evidence"),
                    falsifiers = listOf("generic_narrative_only", "no_discriminator", "no_falsification_demand"),
                    lastChangedReason = "Specialized reasoning protocol converted into a method belief."
                )
            )
        }

        val finalBeliefs = beliefs.values.map { b ->
            val finalStatus = resolveStatus(b.status, b.confidence, b.credibility, b.supportCount, b.contradictionCount)
            val updated = if (finalStatus == b.status) b else b.copy(status = finalStatus, lastChangedReason = "Credibility recalculated from support/contradiction balance.")
            updated.withAbandonmentQuestion()
        }.sortedWith(compareBy<EpistemicBelief> { statusRank(it.status) }.thenByDescending { it.credibility }.thenByDescending { it.confidence })

        val priorIds = prior.beliefs.map { it.beliefId }.toSet()
        val carried = finalBeliefs.count { it.beliefId in priorIds }
        val newCount = finalBeliefs.count { it.beliefId !in priorIds }
        val weakened = finalBeliefs.count { it.status == "WEAKENED" || it.status == "ACTIVE_WITH_WARNINGS" }
        val revised = finalBeliefs.count { it.status == "REVISE_REQUIRED" }
        val retired = finalBeliefs.count { it.status == "RETIRED" }
        val score = if (finalBeliefs.isEmpty()) 0 else finalBeliefs.map { it.credibility }.average().toInt().coerceIn(0, 100)
        val state = when {
            finalBeliefs.isEmpty() -> "NO_BELIEFS"
            revised > 0 -> "BELIEFS_NEED_REVISION"
            weakened > 0 -> "BELIEFS_MUTABLE_WITH_WARNINGS"
            newCount > 0 -> "BELIEF_MODEL_EXPANDING"
            carried > 0 -> "BELIEF_MODEL_CARRIED_FORWARD"
            else -> "BELIEF_MODEL_ACTIVE"
        }
        val mostUrgent = finalBeliefs.firstOrNull { it.status == "REVISE_REQUIRED" || it.status == "WEAKENED" || it.status == "ACTIVE_WITH_WARNINGS" }
        val nextAction = mostUrgent?.let { nextActionFor(it) }
            ?: specializedReasoningReport.decisiveNextTest.takeIf { it.isNotBlank() }
            ?: "Use the belief model to choose the next falsification-oriented search."
        val warnings = buildList {
            add("Beliefs are mutable research priors, not biological proof.")
            add("A belief loses credibility when evidence gaps or contradictions repeat.")
            add("Foundation beliefs are patch-suggested only; JSON knowledge packs are never auto-updated.")
            add(PRUNING_RULE)
            add("Every active belief must answer: $DEFAULT_ABANDONMENT_QUESTION")
            if (revised > 0) add("$revised belief(s) require revision before they can guide hypothesis upgrade.")
            if (retired > 0) add("$retired belief(s) were retired by credibility loss.")
        }
        val transitionSummary = buildTransitionSummary(
            prior = prior,
            current = finalBeliefs,
            prunedPriorUpdates = prunedPriorUpdates
        )
        val brief = "Belief model: $state; score $score/100; new=$newCount, weakened=$weakened, revise=$revised, dropped=${transitionSummary.unusedWeakBeliefsPruned + retired}. Next: ${nextAction.take(130)}"

        return EpistemicBeliefReport(
            active = true,
            state = state,
            beliefScore = score,
            carriedForwardBeliefs = carried,
            newBeliefsThisCycle = newCount,
            weakenedBeliefs = weakened,
            revisedBeliefs = revised,
            retiredBeliefs = retired,
            beliefs = finalBeliefs.take(80),
            updates = (prunedPriorUpdates + updates + buildStatusUpdates(prior, finalBeliefs)).distinctBy { it.beliefId + it.updateType + it.newStatus }.take(80),
            foundationBeliefs = finalBeliefs.filter { it.beliefType == "FOUNDATION_PRIOR" }.map { it.statement }.take(8),
            mutableBeliefWarnings = warnings,
            nextBeliefAction = nextAction,
            visibleBrief = brief,
            transitionSummary = transitionSummary,
            claimLimit = "epistemic_beliefs_not_biological_proof"
        )
    }

    private fun buildStatusUpdates(prior: EpistemicBeliefReport, current: List<EpistemicBelief>): List<EpistemicBeliefUpdate> {
        val priorById = prior.beliefs.associateBy { it.beliefId }
        return current.mapNotNull { belief ->
            val old = priorById[belief.beliefId] ?: return@mapNotNull null
            if (old.status == belief.status && old.credibility == belief.credibility) return@mapNotNull null
            EpistemicBeliefUpdate(
                beliefId = belief.beliefId,
                updateType = transitionType(old, belief),
                previousStatus = old.status,
                newStatus = belief.status,
                reason = belief.lastChangedReason,
                nextAction = nextActionFor(belief)
            )
        }
    }


    private fun buildTransitionSummary(
        prior: EpistemicBeliefReport,
        current: List<EpistemicBelief>,
        prunedPriorUpdates: List<EpistemicBeliefUpdate>
    ): EpistemicBeliefTransitionSummary {
        val priorById = prior.beliefs.associateBy { it.beliefId }
        val strengthened = current
            .filter { belief ->
                val old = priorById[belief.beliefId]
                old != null && (belief.credibility >= old.credibility + 10 || strengthRank(belief.status) > strengthRank(old.status))
            }
            .maxWithOrNull(compareBy<EpistemicBelief> { it.credibility }.thenBy { it.contradictionCount })
            ?: current.firstOrNull { it.beliefId !in priorById && it.status == "ACTIVE_PRIOR" }
        val weakened = current
            .filter { belief ->
                val old = priorById[belief.beliefId]
                old != null && (belief.credibility + 10 <= old.credibility || strengthRank(belief.status) < strengthRank(old.status))
            }
            .minWithOrNull(compareBy<EpistemicBelief> { it.credibility }.thenByDescending { it.contradictionCount })
            ?: current.firstOrNull { it.status == "WEAKENED" || it.status == "ACTIVE_WITH_WARNINGS" || it.status == "REVISE_REQUIRED" }
        val droppedFromFinal = current.firstOrNull { it.status == "RETIRED" }
        val droppedFromPrune = prunedPriorUpdates.firstOrNull()
        val droppedLine = when {
            droppedFromPrune != null -> "${droppedFromPrune.beliefId}: ${droppedFromPrune.reason}"
            droppedFromFinal != null -> summarizeBelief(droppedFromFinal)
            else -> "None this cycle."
        }
        return EpistemicBeliefTransitionSummary(
            strengthenedBelief = strengthened?.let { summarizeBelief(it) } ?: "None this cycle.",
            weakenedBelief = weakened?.let { summarizeBelief(it) } ?: "None this cycle.",
            droppedBelief = droppedLine,
            pruningRule = PRUNING_RULE,
            unusedWeakBeliefsPruned = prunedPriorUpdates.size,
            abandonmentQuestion = DEFAULT_ABANDONMENT_QUESTION
        )
    }

    private fun summarizeBelief(belief: EpistemicBelief): String {
        return "${belief.status} c=${belief.credibility}/100 — ${belief.statement.take(170)}"
    }

    private fun transitionType(old: EpistemicBelief, belief: EpistemicBelief): String {
        return when {
            belief.status == "RETIRED" -> "BELIEF_DROPPED"
            belief.credibility >= old.credibility + 10 || strengthRank(belief.status) > strengthRank(old.status) -> "BELIEF_STRENGTHENED"
            belief.credibility + 10 <= old.credibility || strengthRank(belief.status) < strengthRank(old.status) -> "BELIEF_WEAKENED"
            else -> "BELIEF_UPDATE"
        }
    }

    private fun strengthRank(status: String): Int = when (status) {
        "RETIRED" -> 0
        "REVISE_REQUIRED" -> 1
        "WEAKENED" -> 2
        "PROVISIONAL" -> 3
        "CARRIED_FORWARD" -> 3
        "ACTIVE_WITH_WARNINGS" -> 4
        "ACTIVE_PRIOR" -> 5
        else -> 3
    }

    private fun shouldCarryPriorBelief(belief: EpistemicBelief, activeNodeHints: Set<String>): Boolean {
        if (belief.status == "RETIRED") return false
        if (belief.beliefType == "FOUNDATION_PRIOR") return true
        if (belief.status == "ACTIVE_PRIOR" && belief.credibility >= 60) return true
        if (belief.supportCount >= 2 && belief.contradictionCount == 0 && belief.credibility >= 55) return true
        if (belief.linkedNodes.any { node -> nodeTokens(node).any { it in activeNodeHints } }) return true
        return false
    }

    private fun EpistemicBelief.withAbandonmentQuestion(): EpistemicBelief {
        val question = abandonmentQuestion.ifBlank { abandonmentQuestionFor(this) }
        return if (question == abandonmentQuestion) this else copy(abandonmentQuestion = question)
    }

    private fun abandonmentQuestionFor(belief: EpistemicBelief): String {
        val triggers = (belief.falsifiers + belief.requiredEvidenceToKeep.map { "missing_or_failed_$it" })
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(4)
        val suffix = triggers.joinToString("; ").ifBlank { "independent contradiction, failed controls, missing outcome labels, or reverse time-order explanation" }
        return "$DEFAULT_ABANDONMENT_QUESTION Evidence: $suffix."
    }

    private fun cycleNodeHints(
        currentFindings: List<ResearchFinding>,
        hypothesisObjects: List<HypothesisObject>,
        evidenceObjects: List<EvidenceObject>,
        datasetForagingReport: DatasetForagingReport,
        knowledgeMapReport: KnowledgeMapReport
    ): Set<String> {
        val hints = linkedSetOf<String>()
        fun add(raw: String) {
            nodeTokens(raw).forEach { if (it.isNotBlank()) hints += it }
        }
        currentFindings.forEach { finding ->
            add("source:${finding.source}:${finding.sourceId}")
            finding.matchedAxes.forEach { add("axis:$it") }
        }
        hypothesisObjects.forEach { add("hypothesis:${it.hypothesisId}") }
        evidenceObjects.forEach {
            add("evidence:${it.evidenceId}")
            add("hypothesis:${it.linkedHypothesisId}")
        }
        datasetForagingReport.routeFitAssessments.forEach {
            add("dataset:${it.accession}")
            add("route:${it.targetRoute}")
        }
        knowledgeMapReport.gaps.forEach { gap ->
            add("gap:${gap.gapId}")
            gap.affectedNodes.forEach(::add)
        }
        return hints
    }

    private fun nodeTokens(raw: String): Set<String> {
        val sanitized = sanitize(raw)
        val tail = sanitize(raw.substringAfter(':', raw))
        val last = sanitize(raw.substringAfterLast(':', raw))
        return setOf(sanitized, tail, last).filter { it.isNotBlank() }.toSet()
    }

    private fun foundationBeliefs(): List<EpistemicBelief> = listOf(
        EpistemicBelief(
            beliefId = "belief:foundation_generic_inflammation_not_specific",
            statement = "Generic inflammation is not sufficient evidence for antiviral, allergy, autoimmune, or stress axes without route-specific evidence.",
            beliefType = "FOUNDATION_PRIOR",
            status = "ACTIVE_PRIOR",
            confidence = 92,
            credibility = 90,
            supportCount = 1,
            contradictionCount = 0,
            linkedNodes = listOf("foundation:axis_discipline"),
            requiredEvidenceToKeep = listOf("route_specific_marker", "trigger_context", "outcome_or_time_order"),
            falsifiers = listOf("repeated_verified_exception_with_controls"),
            lastChangedReason = "Seeded as a mutable foundation prior."
        ),
        EpistemicBelief(
            beliefId = "belief:foundation_metadata_before_upgrade",
            statement = "No dataset can upgrade a hypothesis until minimum metadata, outcome/control labels, and route fit are inspected.",
            beliefType = "FOUNDATION_PRIOR",
            status = "ACTIVE_PRIOR",
            confidence = 95,
            credibility = 94,
            supportCount = 1,
            contradictionCount = 0,
            linkedNodes = listOf("foundation:evidence_gate"),
            requiredEvidenceToKeep = listOf("accession", "species", "condition_labels", "outcome_labels", "control_or_comparator"),
            falsifiers = listOf("repeated_high_quality_valid_upgrade_without_metadata"),
            lastChangedReason = "Seeded as a mutable foundation prior."
        ),
        EpistemicBelief(
            beliefId = "belief:foundation_ml_routes_not_proof",
            statement = "ML, freshness, query feedback, and belief maps rank the hunt; evidence gates belief.",
            beliefType = "FOUNDATION_PRIOR",
            status = "ACTIVE_PRIOR",
            confidence = 96,
            credibility = 96,
            supportCount = 1,
            contradictionCount = 0,
            linkedNodes = listOf("foundation:claim_guard"),
            requiredEvidenceToKeep = listOf("claim_limit_visible", "evidence_gate_visible"),
            falsifiers = listOf("report_claims_discovery_from_ml_only"),
            lastChangedReason = "Seeded as a mutable foundation prior."
        )
    )

    private fun resolveStatus(baseStatus: String, confidence: Int, credibility: Int, support: Int, contradictions: Int): String {
        val normalized = baseStatus.uppercase(Locale.US)
        return when {
            credibility <= 20 && contradictions >= 3 && support <= 1 -> "RETIRED"
            credibility <= 35 || contradictions >= support + 2 -> "REVISE_REQUIRED"
            credibility <= 55 || contradictions > support -> "WEAKENED"
            normalized.contains("BLOCK") || normalized.contains("OFF") -> "WEAKENED"
            normalized.contains("WARNING") || normalized.contains("CAUTION") -> "ACTIVE_WITH_WARNINGS"
            confidence >= 70 && credibility >= 70 -> "ACTIVE_PRIOR"
            else -> "PROVISIONAL"
        }
    }

    private fun nextActionFor(belief: EpistemicBelief): String = when (belief.status) {
        "RETIRED" -> "Do not use this belief for routing; keep it only as a historical mistake pattern."
        "REVISE_REQUIRED" -> "Run a falsification search and propose a patch before using this belief again."
        "WEAKENED" -> "Collect the required evidence before this belief can guide ranking strongly: ${belief.requiredEvidenceToKeep.take(3).joinToString(", ")}."
        "ACTIVE_WITH_WARNINGS" -> "Use cautiously and keep the listed falsifiers visible: ${belief.falsifiers.take(2).joinToString(", ")}."
        else -> "Use as a search prior only; keep evidence gates active."
    }

    private fun statusRank(status: String): Int = when (status) {
        "REVISE_REQUIRED" -> 0
        "WEAKENED" -> 1
        "ACTIVE_WITH_WARNINGS" -> 2
        "PROVISIONAL" -> 3
        "ACTIVE_PRIOR" -> 4
        "CARRIED_FORWARD" -> 5
        "RETIRED" -> 6
        else -> 7
    }

    private fun readPriorBeliefReport(lines: List<String>): EpistemicBeliefReport {
        for (line in lines) {
            val obj = runCatching { JSONObject(line) }.getOrNull() ?: continue
            val belief = obj.optJSONObject("epistemicBeliefReport") ?: continue
            return EpistemicBeliefReport(
                active = belief.optBoolean("active", false),
                state = belief.optString("state", "PRIOR"),
                beliefScore = belief.optInt("beliefScore", 0),
                carriedForwardBeliefs = belief.optInt("carriedForwardBeliefs", 0),
                newBeliefsThisCycle = belief.optInt("newBeliefsThisCycle", 0),
                weakenedBeliefs = belief.optInt("weakenedBeliefs", 0),
                revisedBeliefs = belief.optInt("revisedBeliefs", 0),
                retiredBeliefs = belief.optInt("retiredBeliefs", 0),
                beliefs = parseBeliefs(belief.optJSONArray("beliefs")),
                updates = parseUpdates(belief.optJSONArray("updates")),
                foundationBeliefs = strings(belief.optJSONArray("foundationBeliefs")),
                mutableBeliefWarnings = strings(belief.optJSONArray("mutableBeliefWarnings")),
                nextBeliefAction = belief.optString("nextBeliefAction", "Continue from prior beliefs."),
                visibleBrief = belief.optString("visibleBrief", "Prior belief model loaded."),
                transitionSummary = parseTransitionSummary(belief.optJSONObject("transitionSummary")),
                claimLimit = belief.optString("claimLimit", "epistemic_beliefs_not_biological_proof")
            )
        }
        return EpistemicBeliefReport.empty()
    }

    private fun parseBeliefs(arr: JSONArray?): List<EpistemicBelief> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            EpistemicBelief(
                beliefId = o.optString("beliefId"),
                statement = o.optString("statement"),
                beliefType = o.optString("beliefType"),
                status = o.optString("status"),
                confidence = o.optInt("confidence"),
                credibility = o.optInt("credibility"),
                supportCount = o.optInt("supportCount"),
                contradictionCount = o.optInt("contradictionCount"),
                linkedNodes = strings(o.optJSONArray("linkedNodes")),
                requiredEvidenceToKeep = strings(o.optJSONArray("requiredEvidenceToKeep")),
                falsifiers = strings(o.optJSONArray("falsifiers")),
                abandonmentQuestion = o.optString("abandonmentQuestion"),
                lastChangedReason = o.optString("lastChangedReason")
            ).withAbandonmentQuestion()
        }.filter { it.beliefId.isNotBlank() }
    }

    private fun parseUpdates(arr: JSONArray?): List<EpistemicBeliefUpdate> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            EpistemicBeliefUpdate(
                beliefId = o.optString("beliefId"),
                updateType = o.optString("updateType"),
                previousStatus = o.optString("previousStatus"),
                newStatus = o.optString("newStatus"),
                reason = o.optString("reason"),
                nextAction = o.optString("nextAction")
            )
        }.filter { it.beliefId.isNotBlank() }
    }

    private fun parseTransitionSummary(obj: JSONObject?): EpistemicBeliefTransitionSummary {
        if (obj == null) return EpistemicBeliefTransitionSummary.empty()
        return EpistemicBeliefTransitionSummary(
            strengthenedBelief = obj.optString("strengthenedBelief", "None yet."),
            weakenedBelief = obj.optString("weakenedBelief", "None yet."),
            droppedBelief = obj.optString("droppedBelief", "None yet."),
            pruningRule = obj.optString("pruningRule", PRUNING_RULE),
            unusedWeakBeliefsPruned = obj.optInt("unusedWeakBeliefsPruned", 0),
            abandonmentQuestion = obj.optString("abandonmentQuestion", DEFAULT_ABANDONMENT_QUESTION)
        )
    }

    private fun strings(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }
    }

    private fun id(type: String, value: String): String = "belief:${type}:${sanitize(value)}"

    private fun sanitize(value: String): String = value
        .lowercase(Locale.US)
        .replace(Regex("[^a-z0-9_:-]+"), "_")
        .trim('_')
        .take(90)
        .ifBlank { "unknown" }
}
