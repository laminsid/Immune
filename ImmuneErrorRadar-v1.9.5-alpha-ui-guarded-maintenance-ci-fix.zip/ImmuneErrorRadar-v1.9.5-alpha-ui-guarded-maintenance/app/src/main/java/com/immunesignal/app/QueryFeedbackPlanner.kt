package com.immunesignal.app

/** v1.4.5: converts repeated failure into better next queries. */
data class ImprovedQuery(
    val original: String,
    val improved: String,
    val addedTerms: List<String>,
    val reasoning: String,
    val expectedImprovement: String
)

data class QueryFeedbackPlan(
    val active: Boolean,
    val improvedQueries: List<ResearchQuery>,
    val improvements: List<ImprovedQuery>,
    val summary: String,
    val claimLimit: String = "query_ranking_only_not_biological_proof"
) {
    companion object {
        fun passthrough(queries: List<ResearchQuery>, reason: String = "No repeated failure pattern required query changes.") = QueryFeedbackPlan(
            active = false,
            improvedQueries = queries,
            improvements = emptyList(),
            summary = reason
        )
    }
}

object QueryFeedbackPlanner {
    fun improveBatch(queries: List<ResearchQuery>, recentFailures: List<FailurePattern>): QueryFeedbackPlan {
        if (queries.isEmpty()) return QueryFeedbackPlan.passthrough(emptyList(), "No query batch available for feedback.")
        if (recentFailures.isEmpty()) return QueryFeedbackPlan.passthrough(queries)
        val improvements = queries.map { query ->
            val route = inferRoute(query.query + " " + query.label)
            improveQuery(query.query, recentFailures, route)
        }
        val rewritten = queries.zip(improvements).map { (query, improved) ->
            if (improved.improved == query.query) query else query.copy(
                query = improved.improved,
                reason = (query.reason + " v1.4.5 query feedback: " + improved.reasoning).take(500)
            )
        }
        val changed = improvements.filter { it.original != it.improved }
        return QueryFeedbackPlan(
            active = changed.isNotEmpty(),
            improvedQueries = rewritten,
            improvements = changed,
            summary = if (changed.isEmpty()) {
                "Failure patterns were checked; no query needed rewriting."
            } else {
                "Improved ${changed.size}/${queries.size} query/queries using recent failure-pattern memory."
            }
        )
    }

    fun improveQuery(previousQuery: String, recentFailures: List<FailurePattern>, targetRoute: String): ImprovedQuery {
        val relevant = recentFailures.filter { it.route == targetRoute || it.route == "unknown_route" || targetRoute == "general_immune_mapping" }
        val mandatoryTerms = linkedSetOf<String>()
        val blacklistedTerms = linkedSetOf<String>()
        for (failure in relevant) {
            when (failure.rootCause) {
                "NO_OUTCOME_LABELS" -> mandatoryTerms.addAll(listOf("outcome", "recovery", "severity", "prognosis", "endpoint"))
                "ANIMAL_ONLY", "WRONG_SPECIES" -> mandatoryTerms.addAll(listOf("human", "patient", "clinical", "cohort"))
                "NO_TIMECOURSE" -> mandatoryTerms.addAll(listOf("longitudinal", "time-course", "serial", "temporal", "follow-up"))
                "METADATA_ONLY" -> mandatoryTerms.addAll(listOf("sample metadata", "expression matrix", "phenotype labels"))
                "OFF_ROUTE", "LOW_PRIORITY", "SKIP_SIMILAR" -> mandatoryTerms.addAll(refineRouteKeywords(targetRoute))
            }
        }
        mandatoryTerms.addAll(refineRouteKeywords(targetRoute).take(3))
        val originalTokens = previousQuery.split(Regex("\\s+")).filter { it.isNotBlank() && it !in blacklistedTerms }
        val improved = (originalTokens + mandatoryTerms).distinctBy { it.lowercase() }.joinToString(" ")
        return ImprovedQuery(
            original = previousQuery,
            improved = improved,
            addedTerms = mandatoryTerms.filterNot { previousQuery.contains(it, ignoreCase = true) },
            reasoning = "Learned from ${relevant.size} recent failure pattern(s) for route $targetRoute.",
            expectedImprovement = "Higher likelihood of human/outcome/longitudinal/in-route datasets; ML/feedback ranks the hunt only."
        )
    }

    fun inferRoute(text: String): String {
        val lower = text.lowercase()
        return when {
            listOf("viral", "virus", "interferon", "ifn", "viral load", "infection", "antiviral").any { lower.contains(it) } -> "antiviral_interferon_timing"
            listOf("allergy", "allergen", "asthma", "nickel", "skin", "dermatitis", "ige", "type-2").any { lower.contains(it) } -> "allergy_contact_dermatitis_il1_skin"
            listOf("autoimmune", "rheumatoid", "lupus", "treg", "regulatory").any { lower.contains(it) } -> "autoimmune_activity_regulatory"
            listOf("sepsis", "ards", "cytokine storm", "hyperinflammation").any { lower.contains(it) } -> "hyperinflammation_tissue_damage"
            else -> "general_immune_mapping"
        }
    }

    private fun refineRouteKeywords(route: String): List<String> = when (route) {
        "antiviral_interferon_timing" -> listOf("viral load", "infection", "recovery", "severity", "human", "longitudinal")
        "allergy_contact_dermatitis_il1_skin" -> listOf("patch test", "skin", "allergen", "outcome", "human")
        "autoimmune_activity_regulatory" -> listOf("disease activity", "clinical", "cohort", "outcome", "human")
        "hyperinflammation_tissue_damage" -> listOf("severity", "organ damage", "clinical", "outcome", "human")
        else -> emptyList()
    }
}
