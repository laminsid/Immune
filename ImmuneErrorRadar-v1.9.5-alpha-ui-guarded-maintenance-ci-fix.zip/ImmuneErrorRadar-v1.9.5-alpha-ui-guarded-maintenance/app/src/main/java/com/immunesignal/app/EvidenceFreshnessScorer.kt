package com.immunesignal.app

import java.time.Year
import kotlin.math.roundToInt

/**
 * v1.4.5: Evidence freshness scoring.
 *
 * Freshness changes ranking priority only. It is not biological proof and it
 * deliberately protects old foundational evidence from harsh decay.
 */
data class FreshnessScore(
    val sourceId: String,
    val publishYear: Int?,
    val score: Double,
    val reason: String,
    val boostInRanking: Int,
    val claimLimit: String = "ranking_weight_only_not_biological_proof"
)

data class FreshnessReport(
    val active: Boolean,
    val averageFreshness: Int,
    val topScores: List<FreshnessScore>,
    val summary: String
) {
    companion object {
        fun empty() = FreshnessReport(
            active = false,
            averageFreshness = 0,
            topScores = emptyList(),
            summary = "Evidence freshness was not evaluated in this cycle."
        )
    }
}

object EvidenceFreshnessScorer {
    fun score(finding: ResearchFinding): FreshnessScore {
        val year = extractYear(finding.published)
        val currentYear = Year.now().value
        val yearDelta = year?.let { (currentYear - it).coerceAtLeast(0) }
        val foundational = isFoundationalStudy(finding, yearDelta)
        val freshness = if (yearDelta == null) {
            0.60
        } else when {
            yearDelta <= 2 -> 0.95
            yearDelta <= 5 -> 0.85
            yearDelta > 10 && foundational -> 0.70
            yearDelta > 10 -> 0.50
            else -> 0.70
        }.coerceIn(0.0, 1.0)
        val boost = ((freshness - 0.50) * 10.0).roundToInt().coerceIn(0, 5)
        val reason = if (yearDelta == null) {
            "Publish year unavailable; freshness boost capped."
        } else when {
            yearDelta <= 2 -> "Recent source, published within 2 years."
            yearDelta <= 5 -> "Moderately recent source, published within 5 years."
            foundational -> "Older but protected as foundational/high-quality evidence."
            yearDelta > 10 -> "Older source; ranking boost reduced unless independently replicated."
            else -> "Moderate recency."
        }
        return FreshnessScore(
            sourceId = finding.source + ":" + finding.sourceId,
            publishYear = year,
            score = freshness,
            reason = reason,
            boostInRanking = boost
        )
    }

    fun report(findings: List<ResearchFinding>): FreshnessReport {
        if (findings.isEmpty()) return FreshnessReport.empty()
        val scores = findings.map { score(it) }
        val average = (scores.map { it.score }.average() * 100.0).roundToInt().coerceIn(0, 100)
        return FreshnessReport(
            active = true,
            averageFreshness = average,
            topScores = scores.sortedWith(compareByDescending<FreshnessScore> { it.boostInRanking }.thenByDescending { it.score }).take(8),
            summary = "Freshness affects ranking only; it does not prove mechanism, diagnosis, treatment value, or causality."
        )
    }

    private fun extractYear(text: String): Int? {
        val match = Regex("(19|20)\\d{2}").find(text) ?: return null
        return match.value.toIntOrNull()
    }

    private fun isFoundationalStudy(finding: ResearchFinding, yearDelta: Int?): Boolean {
        if (yearDelta == null || yearDelta <= 5) return false
        val text = listOf(finding.title, finding.bridgeSignal, finding.whyItMatters, finding.evidence.studyDesign).joinToString(" ").lowercase()
        val foundationalKeywords = listOf("landmark", "seminal", "foundational", "consensus", "guideline", "review", "meta-analysis", "systematic review")
        return foundationalKeywords.any { text.contains(it) } || finding.evidence.evidenceQualityScore >= 90
    }
}
