package com.immunesignal.app

import android.content.Context
import kotlinx.coroutines.*

/**
 * v1.5.0: Integration Module
 *
 * Non-breaking integration between v1.4.5 ResearchAutopilot and v1.5.0 learning features.
 * All v1.4.5 code remains untouched. New code is additive only.
 */

data class LearningConfig(
    val enableAdvancedLearning: Boolean = false,
    val sessionTimeLimit: Long = 15 * 60 * 1000,     // 15 minutes
    val enablePhase1_FailureAnalysis: Boolean = true,
    val enablePhase2_Interactions: Boolean = true,
    val enablePhase3_Routes: Boolean = true,
    val enablePhase4_BlindSpots: Boolean = true,
    val autoStartSession: Boolean = false,
    val sessionScope: CoroutineScope? = null
)

/**
 * Learning Session Launcher
 *
 * Called by ResearchAutopilot.runCycle() after report generation.
 * Completely optional - if not called, system runs as v1.4.5.
 */
class LearningSessionLauncher(
    private val context: Context,
    private val config: LearningConfig
) {
    
    /**
     * Launch a new learning session.
     * Non-blocking - runs in background.
     */
    fun launchSession(
        sessionType: SessionType = SessionType.INCREMENTAL,
        reportHistory: List<ResearchReportV3>,
        onProgressUpdate: (ProgressUpdate) -> Unit = { _ -> },
        onComplete: (LearningSessionReport) -> Unit = { _ -> }
    ) {
        if (!config.enableAdvancedLearning) {
            // Legacy mode - skip learning
            return
        }
        
        // Launch in background using provided scope or create new one
        val scope = config.sessionScope ?: CoroutineScope(Dispatchers.Default)
        
        scope.launch {
            runSession(
                sessionType = sessionType,
                reportHistory = reportHistory,
                onProgressUpdate = onProgressUpdate,
                onComplete = onComplete
            )
        }
    }
    
    private suspend fun runSession(
        sessionType: SessionType,
        reportHistory: List<ResearchReportV3>,
        onProgressUpdate: (ProgressUpdate) -> Unit,
        onComplete: (LearningSessionReport) -> Unit
    ) {
        try {
            // Initialize managers
            val sessionManager = LearningSessionManager(context)
            val progressBroadcaster = ProgressBroadcaster()
            val phaseExecutor = PhaseExecutor(context, sessionManager, progressBroadcaster)
            
            // Subscribe to progress updates
            progressBroadcaster.addListener(object : ProgressListener {
                override fun onProgressUpdate(progress: ProgressUpdate) {
                    onProgressUpdate(progress)
                }
                
                override fun onPhaseComplete(phaseName: String, findings: String) {
                    // Can log or notify UI
                }
                
                override fun onSessionComplete(insights: LearningInsights) {
                    // Can log final results
                }
            })
            
            // Start session
            val session = sessionManager.startSession(sessionType, config.sessionTimeLimit)
            
            // Execute phases (with enabled/disabled filtering)
            val enabledPhases = filterEnabledPhases(session.phases)
            val filteredSession = session.copy(phases = enabledPhases)
            
            // Run all phases
            phaseExecutor.executeAllPhases(
                session = filteredSession,
                reportHistory = reportHistory,
                onComplete = { insights ->
                    // Report completion
                    sessionManager.getSessionReport()?.let { report ->
                        onComplete(report)
                    }
                }
            )
            
        } catch (e: Exception) {
            // Log error but don't crash - v1.4.5 cycle already completed
            android.util.Log.e("LearningSession", "Error in learning session", e)
        }
    }
    
    private fun filterEnabledPhases(phases: List<PhaseState>): List<PhaseState> {
        return phases.filter { phase ->
            when (phase.phaseName) {
                "FAILURE_ANALYSIS" -> config.enablePhase1_FailureAnalysis
                "INTERACTION_DETECTION" -> config.enablePhase2_Interactions
                "ROUTE_DISCOVERY" -> config.enablePhase3_Routes
                "BLIND_SPOT_FINDING" -> config.enablePhase4_BlindSpots
                else -> true
            }
        }
    }
}

// ========== INTEGRATION WITH ResearchAutopilot ==========

/**
 * Extension function for ResearchAutopilot
 *
 * Call this at the end of runCycle() to start learning session.
 * Zero impact on existing runCycle() logic.
 */
fun ResearchAutopilot.launchLearningSession(
    context: Context,
    config: LearningConfig,
    reportHistory: List<ResearchReportV3>,
    onProgress: (ProgressUpdate) -> Unit = { _ -> },
    onComplete: (LearningSessionReport) -> Unit = { _ -> }
) {
    val launcher = LearningSessionLauncher(context, config)
    launcher.launchSession(
        sessionType = SessionType.INCREMENTAL,
        reportHistory = reportHistory,
        onProgressUpdate = onProgress,
        onComplete = onComplete
    )
}

// ========== USAGE EXAMPLE IN ResearchAutopilot ==========

/**
 * BEFORE (v1.4.5):
 *
 * fun runCycle(...): ResearchCycleReport {
 *     val findings = searchAndParse()
 *     val hypotheses = rankHypotheses()
 *     val report = buildReport()
 *     return report
 * }
 *
 * ========================================
 *
 * AFTER (v1.5.0):
 *
 * fun runCycle(...): ResearchCycleReport {
 *     val findings = searchAndParse()
 *     val hypotheses = rankHypotheses()
 *     val report = buildReport()
 *
 *     // NEW: Optional learning session (non-breaking)
 *     if (learningConfig.enableAdvancedLearning) {
 *         launchLearningSession(
 *             context = context,
 *             config = learningConfig,
 *             reportHistory = store.readLatestReports(50),
 *             onProgress = { progress ->
 *                 // Update UI with progress
 *                 // OR just ignore if not interested
 *             },
 *             onComplete = { report ->
 *                 // Optionally integrate insights into next cycle
 *                 // OR just ignore
 *             }
 *         )
 *     }
 *
 *     return report  // Unchanged
 * }
 */

// ========== CONFIGURATION HELPER ==========

object LearningConfigBuilder {
    fun createDefault(): LearningConfig {
        return LearningConfig(
            enableAdvancedLearning = false,
            sessionTimeLimit = 15 * 60 * 1000,
            enablePhase1_FailureAnalysis = true,
            enablePhase2_Interactions = true,
            enablePhase3_Routes = true,
            enablePhase4_BlindSpots = true,
            autoStartSession = false
        )
    }
    
    fun createBeta(): LearningConfig {
        return createDefault().copy(
            enableAdvancedLearning = true,
            autoStartSession = false  // Users control when to learn
        )
    }
    
    fun createProduction(): LearningConfig {
        return createDefault().copy(
            enableAdvancedLearning = true,
            sessionTimeLimit = 20 * 60 * 1000  // 20 minutes for deeper analysis
        )
    }
}

// ========== UI INTEGRATION HELPERS ==========

/**
 * Helper for UI to show session progress
 */
class LearningSessionUIBridge(
    private val context: Context,
    private val sessionManager: LearningSessionManager
) {
    
    fun getCurrentProgress(): ProgressUpdate? {
        return sessionManager.getCurrentSession()?.let { session ->
            ProgressTracker.generateProgressUpdate(session)
        }
    }
    
    fun getUIReport(): String? {
        return sessionManager.getCurrentSession()?.let { session ->
            ProgressTracker.generateUIReport(session)
        }
    }
    
    fun pauseSession() {
        sessionManager.pauseSession()
    }
    
    fun resumeSession() {
        sessionManager.resumeSession()
    }
    
    fun stopSession() {
        sessionManager.clearCheckpoint()
    }
    
    fun skipToNextPhase() {
        sessionManager.skipCurrentOrNextPhase("ui_bridge_skip_to_next_phase")
    }
}

// ========== REPORT INTEGRATION ==========

/**
 * Extension to merge learning insights into existing report
 */
fun ResearchReportV3.withLearningInsights(
    insights: LearningInsights
): ResearchReportV3 {
    return this.copy(
        learningSessionReport = LearningSessionReport(
            sessionId = "auto_generated",
            sessionType = SessionType.INCREMENTAL,
            status = SessionStatus.COMPLETED,
            progress = 100,
            timeUsed = 0L,
            timeLimit = 0L,
            phases = emptyList(),
            insights = insights,
            claimLimits = mapOf(
                "failures" to "memory_only_not_biological_proof",
                "interactions" to "pattern_hypothesis_not_discovery",
                "routes" to "proposed_not_validated",
                "blindSpots" to "research_guidance_not_proof"
            ),
            nextAction = "Review insights and guide next research cycle"
        )
    )
}

// ========== DATA MIGRATION HELPERS ==========

/**
 * Check compatibility with existing data
 */
object CompatibilityChecker {
    
    fun isCompatible(reportVersion: String): Boolean {
        return reportVersion.startsWith("v1.4") || reportVersion.startsWith("v1.5")
    }
    
    fun canUpgrade(): Boolean {
        // Check if all required v1.4.5 engines are present
        return try {
            // These checks ensure no breaking changes occurred
            FailurePatternLedger::class
            QueryFeedbackPlanner::class
            DatasetTriageEngine::class
            EvidenceFreshnessScorer::class
            true
        } catch (e: Exception) {
            false
        }
    }
}

// ========== SAFE LAUNCH FUNCTION ==========

/**
 * Wrapper that ensures no breaking changes
 */
fun safelyLaunchLearningSession(
    context: Context,
    config: LearningConfig,
    reportHistory: List<ResearchReportV3>,
    onError: (Exception) -> Unit = { e -> android.util.Log.e("Learning", e.toString()) }
) {
    try {
        if (!config.enableAdvancedLearning) {
            // Feature disabled - don't even try
            return
        }
        
        if (!CompatibilityChecker.canUpgrade()) {
            onError(Exception("v1.4.5 components not fully available"))
            return
        }
        
        val launcher = LearningSessionLauncher(context, config)
        launcher.launchSession(
            sessionType = SessionType.INCREMENTAL,
            reportHistory = reportHistory
        )
    } catch (e: Exception) {
        // Never crash the main cycle - just report error
        onError(e)
    }
}
