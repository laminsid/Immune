package com.immunesignal.app

/**
 * v1.6.1: single rollback/activation point for optional research-intelligence layers.
 *
 * These flags keep the production research cycle backward-compatible. Foundation
 * knowledge remains disabled by default. Learning Sessions are user-initiated UI
 * tools, not background workers, and never run unless the user presses Think.
 */
object RuntimeFeatureFlags {
    const val ENABLE_FOUNDATION_KNOWLEDGE_OS: Boolean = false
    const val ENABLE_LEARNING_SESSION_UI: Boolean = true
    const val DEFAULT_LEARNING_SESSION_TIME_LIMIT_MILLIS: Long = 15L * 60L * 1000L
    const val MAX_LEARNING_SESSION_HISTORY: Int = 20
    const val LEARNING_SESSION_SCHEMA_VERSION: String = "1.9.5"

    const val FOUNDATION_CLAIM_LIMIT: String = "foundation_knowledge_not_evidence"
    const val LEARNING_SESSION_CLAIM_LIMIT: String = "learning_session_not_biological_proof"
    const val CHECKPOINT_CLAIM_LIMIT: String = "learning_session_checkpoint_not_evidence"
    const val SPECIALIZED_REASONING_CLAIM_LIMIT: String = "specialized_reasoning_not_biological_proof"
    const val EPISTEMIC_BELIEF_CLAIM_LIMIT: String = "epistemic_beliefs_not_biological_proof"
    const val COGNITIVE_PATH_CLAIM_LIMIT: String = "cognitive_path_integration_not_biological_proof"
}
