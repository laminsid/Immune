package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LearningSessionV151Test {
    @Test
    fun progressBarIsBounded() {
        val bar = ProgressTracker.generateProgressBar(48, width = 10)
        assertTrue(bar.contains("48%"))
        assertEquals(10, bar.substringBefore(" ").length)
    }

    @Test
    fun learningConfigDefaultsDisabled() {
        val config = LearningConfigBuilder.createDefault()
        assertEquals(false, config.enableAdvancedLearning)
        assertEquals(15 * 60 * 1000L, config.sessionTimeLimit)
    }
}
