# Immune Error Radar v1.8.2-alpha-weighted-discovery-intelligence

## Purpose
Turn the v1.8 scientific term index and deep discovery reasoner into explicit routing weights, not just report sections.

## Added
- `ScientificDiscoveryWeightsV182.kt`
- `ScientificDiscoveryWeightEngine`
- `ScientificDecisionWeightCard`
- `ScientificDiscoveryWeightReport`
- weighted scientific routing surface:
  - routing weight
  - evidence gap score
  - false-friend risk
  - action classification
  - decisive evidence delta
  - search priority vector
  - risk guards
  - learning receipt

## Knowledge index expansion
- `scientific_term_index_v1.8.2.json`
- Expanded from 32 to 40 scientific terms.
- New decision-weight terms include:
  - mechanism_chain
  - confounder_control
  - cell_type_resolution
  - perturbation_intervention
  - replication_external_validation
  - effect_direction
  - phenotype_granularity
  - assay_platform_quality

## Integrated paths
- `ResearchAutopilot.kt` computes v1.8.2 weighted discovery after deep discovery.
- `ResearchModels.kt` serializes `scientificDiscoveryWeightReport` with schemaVersion 182.
- `CognitiveNextCycleBridge.kt` feeds weighted search vectors and decisive evidence deltas into next-cycle directives.
- `ResearchKnowledgeStore.kt` stores weighted discovery learning receipts.
- `ResearchAutopilotActivity.kt` shows weighted discovery in the user learning brief.
- `DiscoveryReportExporter.kt` exports weighted terms, decisive evidence deltas, and risk guards.

## Claim boundary
This layer guides routing only. It does not prove biology, diagnosis, treatment value, causality, or immune outcomes.
