# ImmuneErrorRadar v1.8.0-alpha-deep-discovery-reasoner

## Purpose

This release upgrades the project from cognitive-loop control toward deeper discovery reasoning. It keeps all existing v1.6/v1.7 pathways intact and adds a claim-safe v1.8 layer above them.

## Added

- `ScientificKnowledgeIndexEngine`
  - Loads `scientific_term_index_v1.8.0.json`.
  - Provides local prior knowledge for immunology, biology, DNA/genomics, RNA/transcriptomics, allergy, antiviral response, inflammation, regulatory brake, tissue context, controls, and outcome labels.
  - Guides search only; it is not biological proof.

- `DeepDiscoveryReasonerV180`
  - Builds mechanism hypotheses from terms, axes, datasets, and current hypotheses.
  - Runs a mechanism tournament across competing explanations.
  - Designs a decisive experiment/query plan.
  - Scores novelty/non-obviousness.
  - Generates a deep contradiction plan.
  - Builds cross-axis bridge questions.
  - Triggers a bounded Deep Think session only when the evidence path is blocked or the route is promising but under-verified.

## Integrated

- `ResearchAutopilot`
  - Executes the scientific index and deep discovery reasoner after v1.7 cognitive control reports.
  - Adds v1.8 learning notes.
  - Carries v1.8 reports into the saved report object.

- `ResearchModels`
  - `schemaVersion = 180`.
  - Adds JSON serialization for `scientificKnowledgeIndexReport` and `deepDiscoveryReasoningReport`.

- `ResearchAutopilotActivity`
  - Shows scientific prior terms and deep discovery summary in the learning status.

- `DiscoveryReportExporter`
  - Adds PDF sections for the scientific term index and deep discovery reasoner.

- `EngineRuntimeStatus`
  - Active engine: `v1.8.0-alpha-deep-discovery-reasoner`.
  - Active modules include the new v1.8 reasoning engines.

## Boundaries

- v1.8 does not diagnose, treat, recommend drugs, prove immune mechanisms, or prove causality.
- The scientific index is a local routing/foundation layer.
- Deep Think produces mechanism questions and decisive tests, not medical conclusions.
