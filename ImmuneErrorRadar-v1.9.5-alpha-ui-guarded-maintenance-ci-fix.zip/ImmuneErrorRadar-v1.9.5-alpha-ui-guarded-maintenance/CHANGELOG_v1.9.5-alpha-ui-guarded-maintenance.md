# v1.9.5-alpha-ui-guarded-maintenance

## Goal
Continue the v1.9.4 maintenance pass by preventing UI complexity from returning and by slimming the legacy result screen without removing underlying evidence/report logic.

## Changes
- Bumped version to `1.9.5-alpha-ui-guarded-maintenance`.
- Bumped report schema to `195` and learning session schema to `1.9.5`.
- Reduced `activity_result.xml` from 178 lines to 121 lines.
- Kept legacy technical result IDs for Kotlin compatibility but moved them into `legacyTechnicalResultContainer` with `android:visibility="gone"`.
- Visible result screen now shows only: result card, safe next actions, proof limits, export, and back.
- Added compact result action limits: visible safe actions capped to 4; proof-limit items capped to 3; overflow points user to Export details.
- Added `scripts/audit_project_health_v195.py`.
- Added v1.9.5 UI guard checks to `scripts/run_static_checks.sh`.
- Kept regression guards for unresolved fields `.edgeType` and `.speciesClass`.

## Boundary
No new scientific discovery engines were added. This is maintenance, UI reduction, and regression prevention only.
