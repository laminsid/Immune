# Immune Error Radar v1.8.1-alpha-knowledge-routed-discovery

## Goal
Make the v1.8 deep-discovery and scientific-term index layers operationally influence the next research cycle rather than only appearing in the report.

## Changes
- Expanded the local scientific term index from 14 to 32 terms in `scientific_term_index_v1.8.1.json`.
- Added immune and biology foundation terms covering T cells, B cells/antibodies, mast cells, eosinophils, cytokines, IL-1/inflammasome, viral-load kinetics, PRR signaling, epithelial barrier, cell composition, batch effects, statistical power, clinical phenotypes, negative controls, metadata/license, autoimmunity, and tissue damage/repair.
- Updated `ScientificKnowledgeIndexEngine` to load v1.8.1 index data.
- Routed scientific-index hints, evidence requirements, decisive experiment plans, contradiction queries, cross-axis bridge evidence, and Deep Think next query into `CognitiveNextCycleBridge`.
- Added v1.8.1 knowledge-routed discovery reason into saved cognitive directives so the next cycle can execute the strongest missing-evidence path.
- Expanded directive evidence mapping for tissue/cell context, assay/batch control, Type-2 markers, interferon/ISG markers, viral load, and falsification lane.
- Stored deep-discovery and scientific-index summaries in the cognitive control ledger.

## Boundary
This layer improves search routing, mechanism reasoning, and evidence discipline only. It does not prove biology, diagnosis, treatment, causality, immune protection, or clinical utility.
