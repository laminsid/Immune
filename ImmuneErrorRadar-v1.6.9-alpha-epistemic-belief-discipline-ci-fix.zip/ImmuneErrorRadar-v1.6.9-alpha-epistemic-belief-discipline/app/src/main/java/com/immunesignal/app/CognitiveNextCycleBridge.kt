package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs

/**
 * v1.6.6: closes the cognitive loop with single-use continuity guards.
 *
 * Earlier versions produced a linked cognitive path, but the next cycle still
 * mostly relied on the normal query planner. This bridge turns the integrated
 * path decision into a bounded next-cycle directive. v1.6.6 adds single-use
 * consumption and query-inflation protection so the same directive cannot be
 * replayed across cycles. It is intentionally narrow:
 * it can add one follow-up query and annotate existing queries; it cannot prove
 * biology, upgrade hypotheses, or edit foundation knowledge packs.
 */
data class CognitiveNextCycleDirective(
    val directiveId: String,
    val createdAtMillis: Long,
    val sourceCycleId: String,
    val state: String,
    val decisionType: String,
    val routeIntegrity: String,
    val action: String,
    val reason: String,
    val nextSearchTerms: List<String>,
    val requiredEvidence: List<String>,
    val blockedClaims: List<String>,
    val priority: Int,
    val expiresAtMillis: Long,
    val consumedCount: Int,
    val useLimit: Int = 1,
    val claimLimit: String = "next_cycle_routing_only_not_biological_proof"
) {
    fun isExpired(nowMillis: Long = System.currentTimeMillis()): Boolean = nowMillis > expiresAtMillis
    fun isConsumed(): Boolean = consumedCount >= useLimit.coerceAtLeast(1)
    fun isActive(nowMillis: Long = System.currentTimeMillis()): Boolean = !isExpired(nowMillis) && !isConsumed()
}

data class CognitiveNextCyclePlan(
    val active: Boolean,
    val directiveId: String?,
    val appliedQueryCount: Int,
    val addedFollowUpQuery: Boolean,
    val appliedTerms: List<String>,
    val blockedClaims: List<String>,
    val summary: String,
    val suppressedReason: String? = null,
    val directiveConsumed: Boolean = false,
    val consumptionReason: String? = null,
    val routingFingerprint: String? = null,
    val useLimit: Int = 1,
    val claimLimit: String = "next_cycle_routing_only_not_biological_proof"
) {
    companion object {
        fun none(reason: String) = CognitiveNextCyclePlan(
            active = false,
            directiveId = null,
            appliedQueryCount = 0,
            addedFollowUpQuery = false,
            appliedTerms = emptyList(),
            blockedClaims = defaultBlockedClaims(),
            summary = reason,
            suppressedReason = reason,
            directiveConsumed = false,
            consumptionReason = null,
            routingFingerprint = null,
            useLimit = 0
        )
    }
}

object CognitiveNextCycleBridge {
    private const val DEFAULT_TTL_MILLIS = 7L * 24L * 60L * 60L * 1000L
    private const val MAX_DIRECTIVE_USES = 1
    private const val MAX_TERMS_APPLIED_TO_BASE_QUERY = 8
    private const val MAX_FOLLOW_UP_TERMS = 12

    fun directiveFromReportJson(reportJson: JSONObject): CognitiveNextCycleDirective? {
        val path = reportJson.optJSONObject("cognitivePathIntegrationReport") ?: return null
        if (!path.optBoolean("active", false)) return null
        val decision = path.optJSONObject("decision") ?: return null
        val terms = jsonArrayToList(decision.optJSONArray("nextSearchTerms"))
        val evidence = jsonArrayToList(decision.optJSONArray("requiredEvidence"))
        if (terms.isEmpty() && evidence.isEmpty()) return null
        val now = System.currentTimeMillis()
        val cycleId = reportJson.optString("id", "cycle_unknown")
        val decisionType = decision.optString("decisionType", "FOLLOW_UP_REQUIRED")
        val routeIntegrity = path.optString("routeIntegrity", "UNKNOWN_ROUTE_INTEGRITY")
        val priority = priorityFor(decisionType, routeIntegrity, evidence, path.optJSONArray("linkedWarnings"))
        return CognitiveNextCycleDirective(
            directiveId = stableDirectiveId(cycleId, decisionType, terms, evidence),
            createdAtMillis = now,
            sourceCycleId = cycleId,
            state = path.optString("state", "ACTIVE"),
            decisionType = decisionType,
            routeIntegrity = routeIntegrity,
            action = decision.optString("action", "Run a bounded follow-up query from the integrated cognitive path."),
            reason = decision.optString("reason", "Integrated cognitive path produced a next-cycle routing directive."),
            nextSearchTerms = terms,
            requiredEvidence = evidence,
            blockedClaims = defaultBlockedClaims(),
            priority = priority,
            expiresAtMillis = now + DEFAULT_TTL_MILLIS,
            consumedCount = 0,
            useLimit = MAX_DIRECTIVE_USES
        )
    }

    fun toJson(directive: CognitiveNextCycleDirective): JSONObject = JSONObject()
        .put("directiveId", directive.directiveId)
        .put("createdAtMillis", directive.createdAtMillis)
        .put("sourceCycleId", directive.sourceCycleId)
        .put("state", directive.state)
        .put("decisionType", directive.decisionType)
        .put("routeIntegrity", directive.routeIntegrity)
        .put("action", directive.action)
        .put("reason", directive.reason)
        .put("nextSearchTerms", JSONArray(directive.nextSearchTerms))
        .put("requiredEvidence", JSONArray(directive.requiredEvidence))
        .put("blockedClaims", JSONArray(directive.blockedClaims))
        .put("priority", directive.priority)
        .put("expiresAtMillis", directive.expiresAtMillis)
        .put("consumedCount", directive.consumedCount)
        .put("useLimit", directive.useLimit)
        .put("routingFingerprint", routingFingerprint(directive))
        .put("claimLimit", directive.claimLimit)

    fun fromJson(obj: JSONObject): CognitiveNextCycleDirective? {
        val id = obj.optString("directiveId")
        if (id.isBlank()) return null
        return runCatching {
            CognitiveNextCycleDirective(
                directiveId = id,
                createdAtMillis = obj.optLong("createdAtMillis", 0L),
                sourceCycleId = obj.optString("sourceCycleId", "cycle_unknown"),
                state = obj.optString("state", "UNKNOWN"),
                decisionType = obj.optString("decisionType", "FOLLOW_UP_REQUIRED"),
                routeIntegrity = obj.optString("routeIntegrity", "UNKNOWN_ROUTE_INTEGRITY"),
                action = obj.optString("action", "Run bounded follow-up."),
                reason = obj.optString("reason", "No reason saved."),
                nextSearchTerms = jsonArrayToList(obj.optJSONArray("nextSearchTerms")),
                requiredEvidence = jsonArrayToList(obj.optJSONArray("requiredEvidence")),
                blockedClaims = jsonArrayToList(obj.optJSONArray("blockedClaims")).ifEmpty { defaultBlockedClaims() },
                priority = obj.optInt("priority", 50).coerceIn(0, 100),
                expiresAtMillis = obj.optLong("expiresAtMillis", System.currentTimeMillis()),
                consumedCount = obj.optInt("consumedCount", 0).coerceAtLeast(0),
                useLimit = obj.optInt("useLimit", MAX_DIRECTIVE_USES).coerceAtLeast(1),
                claimLimit = obj.optString("claimLimit", "next_cycle_routing_only_not_biological_proof")
            )
        }.getOrNull()
    }

    fun markConsumed(directive: CognitiveNextCycleDirective): CognitiveNextCycleDirective = directive.copy(
        state = "CONSUMED",
        consumedCount = directive.consumedCount + 1
    )

    fun sameRoutingFingerprint(a: CognitiveNextCycleDirective, b: CognitiveNextCycleDirective): Boolean =
        routingFingerprint(a) == routingFingerprint(b)

    fun routingFingerprint(directive: CognitiveNextCycleDirective): String {
        val raw = listOf(
            directive.decisionType,
            directive.routeIntegrity,
            normalizedTerms(directive.nextSearchTerms).joinToString("|"),
            normalizedTerms(directive.requiredEvidence).joinToString("|")
        ).joinToString("::")
        return "route_${abs(raw.lowercase(Locale.US).hashCode())}"
    }

    fun applyToQueries(
        baseQueries: List<ResearchQuery>,
        directive: CognitiveNextCycleDirective?,
        maxQueries: Int
    ): Pair<List<ResearchQuery>, CognitiveNextCyclePlan> {
        if (directive == null) return baseQueries to CognitiveNextCyclePlan.none("No integrated cognitive next-cycle directive was available.")
        if (directive.isExpired()) return baseQueries to CognitiveNextCyclePlan.none("Integrated cognitive directive expired; normal planner kept control.")
        if (directive.isConsumed()) return baseQueries to CognitiveNextCyclePlan.none("Integrated cognitive directive already consumed once; replay blocked to prevent query inflation.")
        if (baseQueries.isEmpty()) return baseQueries to CognitiveNextCyclePlan.none("No base query batch available for cognitive follow-up.")

        val candidateTerms = normalizedTerms(directive.nextSearchTerms + evidenceToSearchTerms(directive.requiredEvidence))
        if (candidateTerms.isEmpty()) {
            return baseQueries to consumedNoopPlan(
                directive = directive,
                reason = "Directive did not contain usable search terms; retiring it to avoid repeated no-op cycles."
            )
        }

        val existingQueryText = baseQueries.joinToString(" ") { it.query }
        val missingTerms = candidateTerms.filterNot { term -> containsNormalized(existingQueryText, term) }.take(16)
        if (missingTerms.isEmpty()) {
            return baseQueries to consumedNoopPlan(
                directive = directive,
                reason = "Directive terms were already covered by the current query batch; retiring satisfied directive to prevent replay."
            )
        }

        val followUpQuery = buildFollowUpQuery(directive, missingTerms)
        val annotated = baseQueries.mapIndexed { index, query ->
            if (index == 0) {
                val merged = mergeTerms(query.query, missingTerms.take(MAX_TERMS_APPLIED_TO_BASE_QUERY))
                query.copy(
                    query = merged,
                    reason = (query.reason + " v1.6.6 single-use cognitive next-cycle bridge: ${directive.decisionType}; ${directive.action}").take(650)
                )
            } else query
        }
        val withFollowUp = (listOf(followUpQuery) + annotated)
            .distinctBy { it.id }
            .take(maxQueries.coerceAtLeast(1))
        return withFollowUp to CognitiveNextCyclePlan(
            active = true,
            directiveId = directive.directiveId,
            appliedQueryCount = withFollowUp.size,
            addedFollowUpQuery = true,
            appliedTerms = missingTerms.take(16),
            blockedClaims = directive.blockedClaims,
            summary = "Applied single-use integrated cognitive path from ${directive.sourceCycleId}: ${directive.decisionType}; required=${directive.requiredEvidence.joinToString(", ").ifBlank { "none" }}.",
            suppressedReason = null,
            directiveConsumed = true,
            consumptionReason = "applied_follow_up_once",
            routingFingerprint = routingFingerprint(directive),
            useLimit = directive.useLimit
        )
    }

    private fun consumedNoopPlan(directive: CognitiveNextCycleDirective, reason: String): CognitiveNextCyclePlan = CognitiveNextCyclePlan(
        active = false,
        directiveId = directive.directiveId,
        appliedQueryCount = 0,
        addedFollowUpQuery = false,
        appliedTerms = emptyList(),
        blockedClaims = directive.blockedClaims,
        summary = reason,
        suppressedReason = reason,
        directiveConsumed = true,
        consumptionReason = "retired_noop_or_already_satisfied",
        routingFingerprint = routingFingerprint(directive),
        useLimit = directive.useLimit
    )

    private fun buildFollowUpQuery(directive: CognitiveNextCycleDirective, appliedTerms: List<String>): ResearchQuery {
        val query = appliedTerms
            .take(MAX_FOLLOW_UP_TERMS)
            .joinToString(" ")
            .ifBlank { "human immune dataset outcome labels longitudinal RNA-seq" }
        return ResearchQuery(
            id = "q_cognitive_path_followup_${directive.directiveId.takeLast(10)}",
            label = "COGNITIVE PATH FOLLOW-UP",
            query = query,
            reason = "Follow-up query from integrated map/belief/specialist path. ${directive.reason.take(260)}"
        )
    }

    private fun mergeTerms(query: String, terms: List<String>): String {
        val tokens = query.split(Regex("\\s+")).filter { it.isNotBlank() }
        val merged = (tokens + terms).distinctBy { it.lowercase(Locale.US) }
        return merged.joinToString(" ").take(900)
    }

    private fun containsNormalized(text: String, term: String): Boolean {
        val haystack = text.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), " ").trim()
        val needle = term.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), " ").trim()
        if (needle.isBlank()) return true
        return haystack.contains(needle)
    }

    private fun normalizedTerms(terms: List<String>): List<String> = terms
        .flatMap { term -> term.replace("_", " ").split(";") }
        .map { it.trim().lowercase(Locale.US) }
        .filter { it.length >= 3 }
        .filterNot { it in setOf("none", "unknown", "not evaluated") }
        .distinct()
        .take(24)

    private fun evidenceToSearchTerms(requiredEvidence: List<String>): List<String> = requiredEvidence.flatMap { evidence ->
        when (evidence.lowercase(Locale.US).replace("-", "_")) {
            "minimum_metadata" -> listOf("sample metadata", "phenotype labels", "GSE", "GEO")
            // Keep this as concrete outcome-label evidence, not broad immune-response language.
            // v1.6.6/v1.6.7 replay guards treat a directive as satisfied when the current
            // batch already contains the outcome/severity/recovery/endpoint lane. Including
            // "response" here made an already-covered directive look missing and inflated the
            // next query batch, because "response" is often a generic pathway word rather than
            // an outcome-label marker.
            "outcome_labels" -> listOf("outcome", "recovery", "severity", "endpoint")
            "time_order", "time_course" -> listOf("longitudinal", "time-course", "serial", "temporal", "follow-up")
            "comparator_control", "controls_or_comparator" -> listOf("control", "comparator", "placebo", "healthy control")
            "falsification_lane" -> listOf("negative control", "validation cohort", "replication")
            "human_or_patient_data" -> listOf("human", "patient", "clinical cohort")
            "viral_load" -> listOf("viral load", "infection", "viral kinetics")
            "interferon_markers" -> listOf("interferon", "IFN", "interferon stimulated genes")
            else -> listOf(evidence.replace("_", " "))
        }
    }

    private fun priorityFor(decisionType: String, routeIntegrity: String, evidence: List<String>, warnings: JSONArray?): Int {
        var score = 50
        val text = "$decisionType $routeIntegrity ${evidence.joinToString(" ")}".lowercase(Locale.US)
        if ("block" in text || "requires" in text) score += 15
        if ("minimum_metadata" in text || "outcome_labels" in text) score += 15
        if ("retired" in text || "revise" in text) score += 10
        if ((warnings?.length() ?: 0) > 0) score += 5
        return score.coerceIn(0, 100)
    }

    private fun stableDirectiveId(cycleId: String, decisionType: String, terms: List<String>, evidence: List<String>): String {
        val raw = listOf(cycleId, decisionType, terms.joinToString("|"), evidence.joinToString("|"))
            .joinToString("|")
            .lowercase(Locale.US)
        return "cognitive_${abs(raw.hashCode())}"
    }

    private fun jsonArrayToList(array: JSONArray?): List<String> {
        if (array == null) return emptyList()
        return (0 until array.length()).mapNotNull { idx -> array.optString(idx).trim().takeIf { it.isNotBlank() } }
    }
}

fun defaultBlockedClaims(): List<String> = listOf(
    "no_biological_proof",
    "no_hypothesis_upgrade_without_evidence_gates",
    "no_medical_or_diagnostic_claim",
    "no_foundation_json_auto_update"
)
