#!/usr/bin/env bash
set -euo pipefail

# Full release gate v1.10.33.
# Bounded, GitHub-safe, and intentionally not a recursive wrapper around fast mode.
export PYTHONDONTWRITEBYTECODE=1
find . -type d -name __pycache__ -prune -exec rm -rf {} +
find . -name "*.pyc" -delete

run_py() {
  local script="$1"
  timeout 45 python3 "$script"
}

python3 scripts/validate_json.py
python3 scripts/audit_kotlin_delimiters.py
python3 scripts/audit_discovery_exporter_local_names_v11033.py
python3 scripts/audit_v11033_unit_regression_contracts.py
python3 scripts/audit_release_version_linkage_v11030.py
python3 scripts/audit_release_version_linkage_v11031.py
python3 scripts/audit_release_version_linkage_v11032.py
python3 scripts/audit_release_version_linkage_v11033.py

python3 - <<'PY_AUDIT_STRINGS'
import pathlib
bad=[]
for path in pathlib.Path('app/src/main/java').rglob('*.kt'):
    for i,line in enumerate(path.read_text(errors='replace').splitlines(),1):
        if '"""' in line:
            continue
        cnt=0
        esc=False
        for ch in line:
            if esc:
                esc=False
                continue
            if ch == '\\':
                esc=True
                continue
            if ch == '"':
                cnt += 1
        if cnt % 2 == 1:
            bad.append(f'{path}:{i}: {line[:140]}')
if bad:
    raise SystemExit('Kotlin raw/newline string literal audit failed:\n' + '\n'.join(bad[:20]))
print('Kotlin string literal audit: PASS')
PY_AUDIT_STRINGS

python3 - <<'PY_XML'
import pathlib, xml.etree.ElementTree as ET
for p in pathlib.Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('XML parse: PASS')
PY_XML

run_py scripts/audit_learning_rules_domain_query_activation_v11021.py
run_py scripts/audit_accession_exhaustion_domain_activation_v11022.py
run_py scripts/audit_accession_mining_intensity_v11023.py
run_py scripts/audit_abstract_accession_harvest_v11024.py
run_py scripts/audit_data_availability_query_priority_v11025.py
run_py scripts/audit_mature_domain_evidence_probe_v11026.py
run_py scripts/audit_dataset_path_linkage_guard_v11027.py
run_py scripts/audit_dataset_pass_coverage_linkage_v11028.py
run_py scripts/audit_learning_domain_path_linkage_v11029.py
run_py scripts/audit_release_hygiene_v1108.py

python3 - <<'PY_LAYOUT'
from pathlib import Path
layout = Path('app/src/main/res/layout/activity_research_autopilot.xml')
activity = Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt')
missing = [str(p) for p in [layout, activity] if not p.exists()]
if missing:
    raise SystemExit('Layout/UI anchor missing: ' + ', '.join(missing))
text = layout.read_text(errors='replace') + '\n' + activity.read_text(errors='replace')
for token in ['Decision card', 'Learning receipt', 'technical layers']:
    if token not in text:
        raise SystemExit(f'Layout/UI token missing: {token}')
print('Layout/UI anchor check: PASS')
PY_LAYOUT

python3 - <<'PY_WIRING'
from pathlib import Path
root = Path('app/src/main/java/com/immunesignal/app')
required = {
    'EvidenceLeadAndManualSeedPolicy': 'EvidenceLeadAndManualSeed.kt',
    'MatureDomainFocusModePolicy': 'MatureDomainFocusAndLeanRuntime.kt',
    'LeanAgentRuntimePolicy': 'MatureDomainFocusAndLeanRuntime.kt',
    'ReleaseVersionLinkageGuard': 'ReleaseVersionLinkageGuard.kt',
}
for token, file_name in required.items():
    path = root / file_name
    if not path.exists() or token not in path.read_text(errors='replace'):
        raise SystemExit(f'Execution wiring token missing: {token} in {file_name}')
report = (root / 'DatasetForagingModels.kt').read_text(errors='replace')
for field in ['leadObjects', 'matureDomainFocusReport', 'knowledgeGapQueueReport', 'leanAgentRuntimeReport']:
    if field not in report:
        raise SystemExit(f'DatasetForagingReport linkage field missing: {field}')
print('Execution wiring/version check: PASS')
PY_WIRING

python3 - <<'PY_CACHE'
from pathlib import Path
bad = [str(p) for p in Path('.').rglob('__pycache__')]
bad += [str(p) for p in Path('.').rglob('*.pyc')]
if bad:
    raise SystemExit('Python cache artifacts found before compile: ' + ', '.join(bad[:20]))
print('Python cache artifact check: PASS')
PY_CACHE

timeout 45 python3 - <<'PY_COMPILE'
from pathlib import Path
import py_compile
scripts = sorted(Path('scripts').rglob('*.py'))
for script in scripts:
    py_compile.compile(str(script), doraise=True)
print(f'py_compile scripts: PASS ({len(scripts)} files)')
PY_COMPILE
find . -type d -name __pycache__ -prune -exec rm -rf {} +
find . -name "*.pyc" -delete

echo "Full static checks v1.10.33: PASS"
