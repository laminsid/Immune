#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1
python3 scripts/validate_json.py
python3 scripts/audit_kotlin_delimiters.py
python3 scripts/audit_stage_linkage_v1107.py
python3 - <<'PY_AUDIT_STRINGS'
import pathlib
bad=[]
for path in pathlib.Path('app/src/main/java').rglob('*.kt'):
    for i,line in enumerate(path.read_text(errors='replace').splitlines(),1):
        if '"""' in line:
            continue
        cnt=0
        esc=False
        for ch in line:
            if esc:
                esc=False
                continue
            if ch == '\\':
                esc=True
                continue
            if ch == '"':
                cnt += 1
        if cnt % 2 == 1:
            bad.append(f'{path}:{i}: {line[:140]}')
if bad:
    raise SystemExit('Kotlin raw/newline string literal audit failed:\n' + '\n'.join(bad[:20]))
print('Kotlin string literal audit: PASS')
PY_AUDIT_STRINGS
python3 - <<'PY'
import pathlib, xml.etree.ElementTree as ET, re, sys
for p in pathlib.Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
print('XML parse: PASS')
manifest=pathlib.Path('app/src/main/AndroidManifest.xml').read_text()
for forbidden in ['QUERY_ALL_PACKAGES','WRITE_EXTERNAL_STORAGE','MANAGE_EXTERNAL_STORAGE','ACCESS_FINE_LOCATION']:
    if forbidden in manifest:
        raise SystemExit(f'Forbidden permission found: {forbidden}')
if 'android.permission.INTERNET' not in manifest:
    raise SystemExit('INTERNET permission expected for private Research Autopilot')
if '.ResultActivity' in manifest:
    raise SystemExit('Legacy ResultActivity must not be registered in runtime manifest')
main_layout = pathlib.Path('app/src/main/res/layout/activity_main.xml').read_text().lower()
for forbidden_ui in ['old daily scan', 'symptom input page', 'daily health score']:
    if forbidden_ui in main_layout:
        raise SystemExit(f'Legacy first-page wording remains: {forbidden_ui}')
xml_ids=set()
for p in pathlib.Path('app/src/main/res/layout').glob('*.xml'):
    xml_ids.update(re.findall(r'@\+id/([A-Za-z0-9_]+)', p.read_text()))
refs=set()
for p in pathlib.Path('app/src/main/java').rglob('*.kt'):
    refs.update(re.findall(r'R\.id\.([A-Za-z0-9_]+)', p.read_text()))
missing=refs-xml_ids
if missing:
    raise SystemExit(f'Missing layout ids: {sorted(missing)}')
print('Layout ID check: PASS')
PY

python3 - <<'PY'
import pathlib, re
accepted_versions = {'1.9.5-alpha-ui-guarded-maintenance', '1.9.7-alpha-autonomous-thought-pulse', '1.9.8-alpha-hypothesis-graph-cognition', '1.9.9-alpha-cognitive-momentum', '1.10.1-alpha-runtime-hardening', '1.10.2-alpha-network-io-test-hardening', '1.10.3-alpha-search-directive-spine', '1.10.4-alpha-cycle-phase-audit', '1.10.5-alpha-store-phase-hardening', '1.10.6-alpha-plan-stage-extraction', '1.10.7-alpha-stage-linkage-maintenance'}
build = pathlib.Path('app/build.gradle.kts').read_text()
if not any(version in build for version in accepted_versions):
    raise SystemExit(f'Version mismatch: none of {sorted(accepted_versions)} found in app/build.gradle.kts')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['runtimeStatus', 'executionLockReport', 'datasetForagingReport', 'persistentFailureMemory']:
    if required not in models:
        raise SystemExit(f'Missing report field: {required}')
for required in ['triageReport', 'failurePatternReport', 'queryFeedbackPlan', 'freshnessReport']:
    if required not in pathlib.Path('app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt').read_text():
        raise SystemExit(f'Missing v1.4.5 report field: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
search_stage = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').read_text() if pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').exists() else ''
wiring_text = autopilot + '\n' + search_stage
for required in ['runtimeFailoverApplied', 'hardStagnationTriggered', 'runtime_dataset_accession', 'runDatasetFirstForaging', 'searchNcbiIds', 'DatasetParser.parse', 'ResearchStateEngine.actionableSummary', 'FailurePatternLedger', 'QueryFeedbackPlanner.improveBatch', 'MLDatasetTriageEngine.triage', 'EvidenceFreshnessScorer.report', 'FoundationKnowledgeIntegrationBridge', 'foundationAnalysisV151', 'enableFoundationKnowledgeOs']:
    if required not in wiring_text:
        raise SystemExit(f'Missing execution wiring token: {required}')
router = pathlib.Path('app/src/main/java/com/immunesignal/app/DirectDatasetSourceRouter.kt').read_text()
if 'GEO_GDS_COOLDOWN_ESCAPE' not in router:
    raise SystemExit('Missing route hardening token: GEO_GDS_COOLDOWN_ESCAPE')
engine = pathlib.Path('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt').read_text()
if 'q_v142_' not in engine:
    raise SystemExit('Execution lock does not accept q_v142_ dataset-parser forced queries')
for required in ['FailurePatternLedger', 'QueryFeedbackPlanner', 'DatasetTriageEngine', 'MLDatasetTriageEngine', 'FailurePredictionModel', 'RouteEmbeddingScorer', 'EvidenceFreshnessScorer', 'FoundationKnowledgeLayer', 'AxisRankingEngine', 'FoundationConflictResolver', 'FoundationKnowledgeAccuracyLedger', 'FoundationPatchSuggestionLedger', 'LearningSessionManager', 'PhaseExecutor', 'ProgressTracker', 'QuestionEvolver', 'SessionMetrics', 'RuntimeFeatureFlags', 'LearningSessionIntegrityGuard', 'SessionHistoryPersistence', 'LearningSessionOutcomeBridge', 'SessionHandoff', 'CandidateActionResolver', 'MinimumMetadataParser', 'AutoContinuationTrigger', 'ReportConsistencyGuard', 'SpecializedReasoningEngine', 'HypothesisFalsificationPressure', 'NextDecisiveTestSelector', 'GeneralModelFailureGuard', 'CumulativeKnowledgeMapEngine', 'KnowledgeMapReport', 'EpistemicBeliefEngine', 'EpistemicBeliefReport', 'CognitivePathIntegrationEngine', 'CognitivePathIntegrationReport']:
    if required not in engine:
        raise SystemExit(f'Missing v1.5.7 active module: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
search_stage = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').read_text() if pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').exists() else ''
wiring_text = autopilot + '\n' + search_stage
for required in ['CandidateActionResolver.resolve', 'MinimumMetadataParser.parse', 'AutoContinuationTrigger.evaluate', 'ReportConsistencyGuard.evaluate', 'candidateActionReport', 'autoContinuationReport', 'reportConsistencyGuard']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.5.8 auto-light learning wiring token: {required}')
models_foraging = pathlib.Path('app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt').read_text()
for required in ['CandidateActionReport', 'AutoContinuationReport', 'ReportConsistencyGuardReport']:
    if required not in models_foraging:
        raise SystemExit(f'Missing v1.5.8 foraging model field: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['candidateActionReport', 'autoContinuationReport', 'reportConsistencyGuard']:
    if required not in activity:
        raise SystemExit(f'Missing v1.5.8 UI visibility token: {required}')
for required in ['renderSimpleUserReport', 'renderMiniLearningReport', 'toggleAdvancedControls', 'learningMiniReportText', 'advancedControlsContainer']:
    if required not in activity:
        raise SystemExit(f'Missing v1.5.9 simple UI learning-brief token: {required}')
layout_research = pathlib.Path('app/src/main/res/layout/activity_research_autopilot.xml').read_text()
for required in ['learningMiniReportText', 'toggleAdvancedButton', 'advancedControlsContainer', 'Small learning report']:
    if required not in layout_research:
        raise SystemExit(f'Missing v1.5.9 simple UI layout token: {required}')
report_builder = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchReportV3Builder.kt').read_text()
for required in ['Auto-light learning: ACTIVE during SEARCH', 'CandidateActionResolver', 'Auto-light continuation queued', 'Report consistency']:
    if required not in report_builder:
        raise SystemExit(f'Missing v1.5.8 report consistency language: {required}')

models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
if 'Run a research cycle or import a report' in models:
    raise SystemExit('Generic non-actionable Next Evidence text remains')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['skipThinkingButton.setOnClickListener', 'private fun skipThinkingPhase()', 'skipCurrentOrNextPhase', 'startThinkingSession(SessionType.RESUMED)']:
    if required not in activity:
        raise SystemExit(f'Missing learning-session UI handler token: {required}')
manifest = pathlib.Path('app/src/main/AndroidManifest.xml').read_text()
if '.ResultActivity' in manifest:
    raise SystemExit('Legacy manual result route is still registered')

phase_executor = pathlib.Path('app/src/main/java/com/immunesignal/app/PhaseExecutor.kt').read_text()
for required in ['attachEvolvedQuestions', 'QuestionEvolver.generateQuestions', 'question_evolution_not_biological_proof', 'questionObjects']:
    if required not in phase_executor:
        raise SystemExit(f'Missing v1.5.7 question-evolution token: {required}')
progress_tracker = pathlib.Path('app/src/main/java/com/immunesignal/app/ProgressTracker.kt').read_text()
for required in ['JSONObject().apply', 'JSONArray()', 'generateJSONReport', 'RuntimeFeatureFlags.LEARNING_SESSION_CLAIM_LIMIT']:
    if required not in progress_tracker:
        raise SystemExit(f'Missing v1.5.7 safe progress JSON token: {required}')
manager = pathlib.Path('app/src/main/java/com/immunesignal/app/LearningSessionManager.kt').read_text()

outcome_bridge = pathlib.Path('app/src/main/java/com/immunesignal/app/LearningSessionOutcomeBridge.kt').read_text()
for required in ['session_handoff_not_biological_proof', 'buildHandoffFromInsights', 'NO_OUTCOME_LABELS', 'toJson()', 'compactSummary']:
    if required not in outcome_bridge:
        raise SystemExit(f'Missing v1.5.7 session-handoff token: {required}')
manager = pathlib.Path('app/src/main/java/com/immunesignal/app/LearningSessionManager.kt').read_text()
for required in ['LearningSessionHandoff', 'sessionHandoff', 'LearningSessionOutcomeBridge.buildHandoff']:
    if required not in manager:
        raise SystemExit(f'Missing v1.5.7 manager handoff token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
if 'handoff.compactSummary()' not in activity:
    raise SystemExit('Missing v1.5.7 UI handoff summary token')
integration = pathlib.Path('app/src/main/java/com/immunesignal/app/LearningSessionIntegration.kt').read_text()
if 'skipCurrentOrNextPhase("ui_bridge_skip_to_next_phase")' not in integration:
    raise SystemExit('LearningSessionUIBridge skip must use integrity-protected manager skip')

manager = pathlib.Path('app/src/main/java/com/immunesignal/app/LearningSessionManager.kt').read_text()
for required in ['buildSessionMetrics(normalized)', 'deltaFromPrevious', 'pendingPhases = emptyList()', 'buildSessionMetrics(session)']:
    if required not in manager:
        raise SystemExit(f'Missing v1.5.7 session-metrics token: {required}')

specialist = pathlib.Path('app/src/main/java/com/immunesignal/app/SpecializedReasoningEngine.kt').read_text()
for required in ['specialized_reasoning_not_biological_proof', 'Generic-AI risk', 'decisiveNextTest', 'falsificationDemand', 'axisDiscipline', 'EvidenceGapCard', 'HypothesisTournamentCard', 'ReasoningAuditQuestion', 'specialistVerdict', 'nextCycleProtocol']:
    if required not in specialist:
        raise SystemExit(f'Missing v1.6.1 specialist protocol token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['specializedReasoningReport', 'specializedReasoningToJson', 'specialistMoveToJson', 'evidenceGapToJson', 'hypothesisTournamentToJson', 'reasoningAuditToJson']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.1 specialist protocol JSON token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
search_stage = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').read_text() if pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').exists() else ''
wiring_text = autopilot + '\n' + search_stage
for required in ['SpecializedReasoningEngine.evaluate', 'specializedReasoningReport', 'v1.6.1 specialist evidence protocol', 'v1.6.1 decisive next test']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.1 specialist protocol wiring token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['specializedReasoningReport', 'Specialized reasoning:', 'Specialist check:', 'specialistVerdict', 'evidenceGaps']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.1 specialist protocol UI token: {required}')

knowledge_map = pathlib.Path('app/src/main/java/com/immunesignal/app/CumulativeKnowledgeMapEngine.kt').read_text()
for required in ['knowledge_map_not_biological_proof', 'KnowledgeMapNode', 'KnowledgeMapEdge', 'KnowledgeMapGap', 'readPriorMap', 'changedSincePrevious']:
    if required not in knowledge_map:
        raise SystemExit(f'Missing v1.6.2 knowledge-map token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['knowledgeMapReport', 'knowledgeMapToJson', 'knowledgeMapNodeToJson', 'knowledgeMapEdgeToJson', 'knowledgeMapGapToJson']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.2 knowledge-map JSON token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
search_stage = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').read_text() if pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').exists() else ''
wiring_text = autopilot + '\n' + search_stage
for required in ['CumulativeKnowledgeMapEngine.build', 'knowledgeMapReport', 'v1.6.2 cumulative knowledge map', 'v1.6.2 map next action']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.2 knowledge-map wiring token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['knowledgeMapReport', 'Knowledge map:', 'Map next:', 'Map state:']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.2 knowledge-map UI token: {required}')
exporter = pathlib.Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for required in ['Cumulative knowledge map', 'knowledgeMapReport', 'Top map links', 'knowledge_map_not_biological_proof']:
    if required not in exporter:
        raise SystemExit(f'Missing v1.6.2 knowledge-map PDF token: {required}')

belief = pathlib.Path('app/src/main/java/com/immunesignal/app/EpistemicBeliefEngine.kt').read_text()
for required in ['epistemic_beliefs_not_biological_proof', 'EpistemicBelief', 'EpistemicBeliefReport', 'credibility', 'REVISE_REQUIRED', 'RETIRED', 'foundationBeliefs']:
    if required not in belief:
        raise SystemExit(f'Missing v1.6.3 epistemic-belief token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['epistemicBeliefReport', 'epistemicBeliefToJson', 'epistemicBeliefItemToJson', 'epistemicBeliefUpdateToJson']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.3 epistemic-belief JSON token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
search_stage = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').read_text() if pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').exists() else ''
wiring_text = autopilot + '\n' + search_stage
for required in ['EpistemicBeliefEngine.build', 'epistemicBeliefReport', 'v1.6.3 epistemic belief model', 'v1.6.3 belief next action']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.3 epistemic-belief wiring token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['epistemicBeliefReport', 'Belief model:', 'Belief next:', 'Next belief action']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.3 epistemic-belief UI token: {required}')
exporter = pathlib.Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for required in ['Epistemic belief model', 'epistemicBeliefReport', 'Top mutable beliefs', 'epistemic_beliefs_not_biological_proof']:
    if required not in exporter:
        raise SystemExit(f'Missing v1.6.3 epistemic-belief PDF token: {required}')

belief = pathlib.Path('app/src/main/java/com/immunesignal/app/EpistemicBeliefEngine.kt').read_text()
for required in ['EpistemicBeliefTransitionSummary', 'abandonmentQuestion', 'DROPPED_UNUSED_WEAK_BELIEF', 'buildTransitionSummary', 'shouldCarryPriorBelief', 'What evidence would make me abandon this belief?']:
    if required not in belief:
        raise SystemExit(f'Missing v1.6.9 epistemic-belief discipline token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['transitionSummary', 'epistemicBeliefTransitionSummaryToJson', 'abandonmentQuestion']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.9 epistemic-belief discipline JSON token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['Strengthened belief:', 'Weakened belief:', 'Dropped belief:', 'Belief abandonment test:', 'Belief changed: strengthened=']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.9 epistemic-belief discipline UI token: {required}')
exporter = pathlib.Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for required in ['Strengthened belief:', 'Weakened belief:', 'Dropped belief:', 'Belief abandonment test:', 'Pruning rule:']:
    if required not in exporter:
        raise SystemExit(f'Missing v1.6.9 epistemic-belief discipline PDF token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
search_stage = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').read_text() if pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').exists() else ''
wiring_text = autopilot + '\n' + search_stage
for required in ['v1.6.9 epistemic belief discipline', 'v1.6.9 belief abandonment question']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.9 epistemic-belief discipline wiring token: {required}')
engine = pathlib.Path('app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt').read_text()
for required in ['BeliefTransitionSummary', 'BeliefAbandonmentQuestion', 'UnusedWeakBeliefPruner']:
    if required not in engine:
        raise SystemExit(f'Missing v1.6.9 active module: {required}')


cognitive = pathlib.Path('app/src/main/java/com/immunesignal/app/CognitivePathIntegrationEngine.kt').read_text()
for required in ['cognitive_path_integration_not_biological_proof', 'CognitivePathIntegrationReport', 'CognitivePathDecision', 'map_updates_mutable_belief', 'belief_requires_specialist_test', 'specialist_test_controls_next_search']:
    if required not in cognitive:
        raise SystemExit(f'Missing v1.6.4 cognitive-path token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['cognitivePathIntegrationReport', 'cognitivePathIntegrationToJson', 'cognitivePathNodeToJson', 'cognitivePathLinkToJson', 'cognitivePathDecisionToJson']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.4 cognitive-path JSON token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
search_stage = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').read_text() if pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').exists() else ''
wiring_text = autopilot + '\n' + search_stage
for required in ['CognitivePathIntegrationEngine.integrate', 'cognitivePathIntegrationReport', 'v1.6.4 cognitive path integration', 'v1.6.4 linked next action']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.4 cognitive-path wiring token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['cognitivePathIntegrationReport', 'Linked thinking path:', 'Linked path:', 'Linked next:']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.4 cognitive-path UI token: {required}')
exporter = pathlib.Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for required in ['Cognitive path integration', 'cognitivePathIntegrationReport', 'Integrated links', 'cognitive_path_integration_not_biological_proof']:
    if required not in exporter:
        raise SystemExit(f'Missing v1.6.4 cognitive-path PDF token: {required}')

calibration = pathlib.Path('app/src/main/java/com/immunesignal/app/CognitiveLoopCalibrationEngine.kt').read_text()
for required in ['cognitive_loop_calibration_not_biological_proof', 'CognitiveLoopCalibrationReport', 'dampenSimilarDirective', 'rewardSimilarDirective', 'METADATA_PROGRESS', 'CONTRASTIVE_GATE_STALLED']:
    if required not in calibration:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration token: {required}')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['cognitiveLoopCalibrationReport', 'cognitiveLoopCalibrationToJson', 'cognitiveLoopCalibrationSignalToJson']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration JSON token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
search_stage = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').read_text() if pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchCycleSearchStage.kt').exists() else ''
wiring_text = autopilot + '\n' + search_stage
for required in ['CognitiveLoopCalibrationEngine.calibrate', 'cognitiveLoopCalibrationReport', 'v1.6.8 cognitive loop calibration']:
    if required not in autopilot:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration wiring token: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
for required in ['cognitiveLoopCalibrationReport', 'Loop calibration:', 'calibrationScore']:
    if required not in activity:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration UI token: {required}')
exporter = pathlib.Path('app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt').read_text()
for required in ['Cognitive loop calibration', 'cognitiveLoopCalibrationReport', 'Improved signals', 'Stalled signals']:
    if required not in exporter:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration PDF token: {required}')
store = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt').read_text()
for required in ['saveCognitiveLoopCalibrationFromReport', 'cognitive_loop_calibration', 'rewardSimilarDirective']:
    if required not in store:
        raise SystemExit(f'Missing v1.6.8 cognitive-loop calibration ledger token: {required}')

print('Execution wiring/version check: PASS')
PY

python3 -B -m py_compile research/*.py
find research -type d -name __pycache__ -prune -exec rm -rf {} +
find research -name '*.pyc' -delete

python3 - <<'PY'
import pathlib
bad=[]
for p in pathlib.Path('.').rglob('__pycache__'):
    bad.append(str(p))
for p in pathlib.Path('.').rglob('*.pyc'):
    bad.append(str(p))
if bad:
    raise SystemExit('Python cache artifacts found in release tree: ' + ', '.join(bad[:20]))
print('Python cache artifact check: PASS')
PY

if [[ "${RUN_SAMPLE_PIPELINE:-0}" == "1" ]]; then
  timeout 20 python3 research/omics_bridge.py research/examples/sample_cases.csv >/tmp/immune_omics_bridge.json
  timeout 20 python3 research/baseline_classifier.py research/examples/sample_matrix.csv >/tmp/immune_baseline.json || true
  timeout 20 python3 research/evidence_quality.py >/tmp/immune_evidence_quality.json
  timeout 20 python3 research/causality_scorer.py 'stress before allergy histamine blood pressure mast cell mechanism' >/tmp/immune_causality.json
  timeout 20 python3 research/personal_time_series.py research/examples/sample_personal_series.csv stress allergy_intensity >/tmp/immune_personal_series.json
  timeout 20 python3 research/negative_controls.py research/examples/sample_personal_series.csv stress dizziness >/tmp/immune_negative_controls.json
  timeout 20 python3 research/hypothesis_ranker.py research/examples/sample_hypotheses.csv >/tmp/immune_hypothesis_ranker.json
  timeout 20 python3 research/global_dataset_registry.py research/examples/global_dataset_candidates.csv >/tmp/immune_global_dataset_registry.json
  timeout 20 python3 research/immune_axis_mapper.py 'interferon IL10 CD8 antibody tissue damage recovery' >/tmp/immune_axis_mapper.json
  timeout 20 python3 research/trigger_response_graph.py 'virus interferon IL10 tissue damage recovery' >/tmp/immune_trigger_response_graph.json
  timeout 20 python3 research/pathogen_response_comparator.py 'virus interferon IL10 tissue damage recovery' >/tmp/immune_pathogen_response.json
  echo 'Research Python sample pipeline: PASS'
else
  echo 'Research Python compile checks: PASS'
  echo 'Sample pipeline skipped by default; run RUN_SAMPLE_PIPELINE=1 scripts/run_static_checks.sh to execute examples.'
fi


python3 - <<'PY'
from pathlib import Path
root = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': ['CognitiveNextCycleDirective', 'CognitiveNextCyclePlan', 'next_cycle_routing_only_not_biological_proof', 'isConsumed', 'sameRoutingFingerprint', 'already consumed once', 'Directive terms were already covered'],
    'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt': ['readActiveCognitiveNextCycleDirective', 'saveCognitiveNextCycleDirectiveFromReport', 'markCognitiveNextCycleDirectiveConsumed', 'cognitive_next_cycle_directive_suppressed', 'routingFingerprint'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['CognitiveNextCycleBridge.applyToQueries', 'cognitiveNextCyclePlanV165', 'v1.6.7 cognitive directive retirement'],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': ['cognitiveNextCyclePlan', 'cognitiveNextCyclePlanToJson', 'suppressedReason', 'directiveConsumed']
}
for rel, tokens in checks.items():
    text = (root / rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.6.7 directive-retirement token: {rel} -> {token}')
print('v1.6.7 cognitive loop continuity audit: PASS')
PY


python3 - <<'PY_AUDIT_V167'
import pathlib
bridge = pathlib.Path('app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt').read_text()
for required in ['consumedNoopPlan', 'retired_noop_or_already_satisfied', 'consumptionReason', 'routingFingerprint', 'Directive terms were already covered']:
    if required not in bridge:
        raise SystemExit(f'Missing v1.6.7 directive-retirement token: {required}')
autopilot = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text()
if 'cognitiveNextCyclePlanV165.directiveConsumed' not in autopilot:
    raise SystemExit('ResearchAutopilot must consume directives for active and no-op retired plans')
models = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchModels.kt').read_text()
for required in ['consumptionReason', 'routingFingerprint', 'useLimit']:
    if required not in models:
        raise SystemExit(f'Missing v1.6.7 cognitive plan JSON field: {required}')
activity = pathlib.Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
if 'Closed loop retired' not in activity:
    raise SystemExit('UI must expose retired/satisfied cognitive directives')
print('v1.6.7 cognitive directive retirement audit: PASS')
PY_AUDIT_V167

python3 - <<'PY_AUDIT_V170'
from pathlib import Path
root = Path('.')
checks = {
    'app/src/main/java/com/immunesignal/app/CognitiveLearningControlV170.kt': [
        'DirectiveLifecycleEngine', 'EvidenceGainQueryRanker', 'BeliefFalsificationContractEngine',
        'MemoryConsolidationEngine', 'CausalReadinessGate', 'ReflectionLessonEngine',
        'MiniPeerReviewGate', 'ReportSimplificationLayer', 'directive_lifecycle_not_biological_proof'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'EvidenceGainQueryRanker.rank', 'DirectiveLifecycleEngine.evaluate', 'BeliefFalsificationContractEngine.build',
        'MemoryConsolidationEngine.consolidate', 'CausalReadinessGate.evaluate', 'ReflectionLessonEngine.build',
        'MiniPeerReviewGate.review', 'ReportSimplificationLayer.build', 'v1.7.0 directive lifecycle'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'directiveLifecycleReport', 'evidenceGainQueryRankerReport', 'beliefFalsificationContractReport',
        'memoryConsolidationReport', 'causalReadinessReport', 'reflectionLessonReport',
        'miniPeerReviewReport', 'reportSimplificationReport', 'schemaVersion",'
    ],
    'app/src/main/java/com/immunesignal/app/CumulativeKnowledgeMapEngine.kt': [
        'mapStructureScore', 'evidenceReadinessScore', 'causalReadinessScore', 'upgradeStatus', 'mainBlocker'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt': [
        'saveCognitiveLearningControlFromReport', 'cognitive_learning_control_v170', 'directiveLifecycleState'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Directive lifecycle', 'Evidence-gain query', 'Belief contracts', 'Causal readiness', 'Mini peer review'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Directive lifecycle v1.7', 'Evidence-gain query ranking', 'Causal readiness gate', 'Mini peer review gate', 'Reflection lesson'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'DirectiveLifecycleEngine', 'EvidenceGainQueryRanker', 'CausalReadinessGate'
    ],
}
for rel, tokens in checks.items():
    text = (root / rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.7.0 cognitive-learning control token: {rel} -> {token}')
print('v1.7.0 cognitive-learning control audit: PASS')
PY_AUDIT_V170

python3 - <<'PY_AUDIT_V171'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV17ControlTerms',
        'extractV17RequiredEvidence',
        'buildV17ControlReason',
        'appendControlSuffix',
        'evidenceKeyFromGap',
        'v1.8.3 control'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance',
        'ActionableCognitiveControlV171',
        'DirectiveControlContextEnricher'
    ]
}
for rel, tokens in checks.items():
    text = Path(rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.7.1 actionable-control token: {rel} -> {token}')
print('v1.7.1 actionable cognitive-control audit: PASS')
PY_AUDIT_V171


python3 - <<'PY_AUDIT_V180'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/DeepDiscoveryReasonerV180.kt': [
        'ScientificKnowledgeIndexEngine', 'MechanismHypothesisEngine', 'MechanismTournamentEngine',
        'DecisiveExperimentPlanner', 'NoveltyAndNonObviousnessScorer', 'DeepContradictionMiner',
        'CrossAxisBridgeReasoner', 'DeepThinkSessionEngine', 'deep_discovery_reasoning_not_biological_proof'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ScientificKnowledgeIndexEngine(context).build', 'DeepDiscoveryReasonerV180.reason',
        'v1.8.2 scientific term index', 'v1.8.2 deep discovery reasoner', 'v1.8.2 decisive experiment'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'scientificKnowledgeIndexReport', 'deepDiscoveryReasoningReport', 'scientificDiscoveryWeightReport', 'schemaVersion",',
        'scientificKnowledgeIndexToJson', 'deepDiscoveryReasoningToJson', 'scientificDiscoveryWeightToJson'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Scientific term index', 'Deep discovery', 'Decisive test', 'Deep Think'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Scientific term index v1.8', 'Deep discovery reasoner v1.8', 'Mechanism hypotheses', 'Strongest objection'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificKnowledgeIndexEngine', 'DeepDiscoveryReasonerV180'
    ],
    'app/src/main/assets/scientific_term_index_v1.8.2.json': [
        'innate_immunity', 'adaptive_immunity', 'type2_allergy', 'interferon_antiviral',
        'rna_transcriptomics', 'dna_genomics', 'outcome_labels', 'controls_comparators'
    ]
}
for rel, tokens in checks.items():
    text = Path(rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.8.2 weighted discovery intelligence token: {rel} -> {token}')
print('v1.8.2 weighted discovery intelligence audit: PASS')
PY_AUDIT_V180


python3 - <<'PY_AUDIT_V181'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV18DiscoveryTerms', 'extractV18RequiredEvidence', 'buildV18DiscoveryReason',
        'v1.8.2 weighted discovery intelligence', 'deep-discovery path', 'tissue_cell_context', 'assay_batch_control'
    ],
    'app/src/main/assets/scientific_term_index_v1.8.2.json': [
        'viral_load_kinetics', 'cell_composition', 'batch_effect', 'longitudinal_time_order',
        'negative_control', 'clinical_phenotype', 'metadata_license', 'sample_size_power'
    ],
    'app/src/main/java/com/immunesignal/app/DeepDiscoveryReasonerV180.kt': [
        'scientific_term_index_v1.9.3.json', 'v1.9.3-scientific-term-index', 'Deep discovery v1.9.3'
    ]
}
for rel, tokens in checks.items():
    text = Path(rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.8.2 weighted discovery intelligence token: {rel} -> {token}')
print('v1.8.2 knowledge-routed next-cycle audit: PASS')
PY_AUDIT_V181


python3 - <<'PY_AUDIT_V182'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryWeightsV182.kt': [
        'ScientificDiscoveryWeightEngine', 'ScientificDecisionWeightCard', 'scientific_weighting_guides_routing_not_proof',
        'DOWNGRADE_FALSE_FRIEND', 'CLOSE_DECISIVE_EVIDENCE_GAP', 'searchPriorityVector'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ScientificDiscoveryWeightEngine.weigh', 'scientificDiscoveryWeightReportV182', 'v1.8.2 weighted discovery intelligence'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'scientificDiscoveryWeightReport', 'scientificDiscoveryWeightToJson', 'scientificDecisionWeightToJson', 'schemaVersion",'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV182WeightedDiscoveryTerms', 'extractV182WeightedDiscoveryEvidence', 'buildV182WeightedReason',
        'v1.8.2 weighted discovery intelligence', 'decision-memory cognitive next-cycle bridge'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Weighted discovery intelligence v1.8.2', 'Top weighted terms', 'Decisive evidence delta'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Weighted discovery:', 'Decisive evidence delta'
    ],
    'app/src/main/assets/scientific_term_index_v1.8.2.json': [
        'mechanism_chain', 'confounder_control', 'cell_type_resolution', 'perturbation_intervention',
        'replication_external_validation', 'effect_direction', 'phenotype_granularity', 'assay_platform_quality'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificDiscoveryWeightEngine', 'WeightedDiscoveryIntelligenceV182'
    ],
}
for rel, tokens in checks.items():
    text = Path(rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.8.2 weighted-discovery token: {rel} -> {token}')
print('v1.8.2 weighted discovery intelligence audit: PASS')
PY_AUDIT_V182


python3 - <<'PY_AUDIT_V183'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryDecisionLedgerV183.kt': [
        'ScientificDiscoveryDecisionEngineV183', 'ScientificDiscoveryDecisionReport',
        'scientific_decision_memory_guides_routing_not_proof', 'successCriteria', 'failureCriteria',
        'nextCycleContract', 'changeIfFails'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ScientificDiscoveryDecisionEngineV183.decide', 'scientificDiscoveryDecisionReportV183',
        'v1.8.3 discovery decision memory', 'v1.8.3 next-cycle contract'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'scientificDiscoveryDecisionReport', 'scientificDiscoveryDecisionToJson', 'schemaVersion",'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV183DecisionMemoryTerms', 'extractV183DecisionMemoryEvidence', 'buildV183DecisionMemoryReason',
        'v1.8.3 discovery decision memory', 'decision-memory cognitive next-cycle bridge'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Discovery decision memory v1.8.3', 'Selected move', 'Next-cycle contract', 'If it fails'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Discovery decision memory:', 'Blocked move:', 'Next-cycle contract:', 'If it fails:'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt': [
        'kindV183', 'scientific_discovery_decision_memory_v183', 'scientificDiscoveryDecisionContract'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificDiscoveryDecisionEngineV183', 'ScientificDiscoveryDecisionMemoryV183'
    ],
}
for rel, tokens in checks.items():
    text = Path(rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.8.3 decision-memory token: {rel} -> {token}')
print('v1.8.3 scientific discovery decision-memory audit: PASS')
PY_AUDIT_V183


python3 - <<'PY_AUDIT_V184'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryStressTestV184.kt': [
        'ScientificDiscoveryStressTestEngineV184', 'ScientificDiscoveryStressTestReport',
        'counterfactual_stress_test_guides_routing_not_proof', 'PASS_DECISIVE_EVIDENCE',
        'HIGH_ROUTE_FIT_LOW_USABILITY_TRAP', 'FALSE_FRIEND_GENERALIZATION', 'CONTRADICTION_FIRST_BRANCH'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ScientificDiscoveryStressTestEngineV184.stressTest', 'scientificDiscoveryStressTestReportV184',
        'v1.8.4 counterfactual discovery stress test', 'v1.8.4 stress branch actions'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'scientificDiscoveryStressTestReport', 'scientificDiscoveryStressTestToJson', 'discoveryStressScenarioToJson', 'schemaVersion",'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV184StressTestTerms', 'extractV184StressTestEvidence', 'buildV184StressTestReason',
        'v1.8.4 counterfactual discovery stress test', 'stress-test='
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Counterfactual discovery stress test v1.8.4', 'Stress scenarios:', 'Branch actions:', 'Null-result policy:'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Discovery stress test:', 'Stress branch:', 'scientificDiscoveryStressTestReport'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt': [
        'kindV184', 'counterfactual_discovery_stress_test_v184', 'scientificDiscoveryStressForcedEvidence'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificDiscoveryStressTestEngineV184', 'CounterfactualDiscoveryStressTestV184'
    ],
    'app/src/main/assets/scientific_term_index_v1.9.3.json': [
        'counterfactual_branching', 'null_result_policy', 'effect_reversal', 'heterogeneity_subgroups',
        'tissue_specificity_guard', 'failed_replication'
    ],
}
for rel, tokens in checks.items():
    text = Path(rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.8.4 counterfactual stress-test token: {rel} -> {token}')
print('v1.8.4 counterfactual discovery stress-test audit: PASS')
PY_AUDIT_V184


python3 - <<'PY_AUDIT_V185'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryExecutionPolicyV185.kt': [
        'ScientificDiscoveryExecutionPolicyEngineV185', 'ScientificDiscoveryExecutionPolicyReport',
        'execution_policy_guides_routing_not_proof', 'routeCooldownPolicy', 'beliefBurialPolicy',
        'queryReplayBlocks', 'policy_enforced_discovery_control'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ScientificDiscoveryExecutionPolicyEngineV185.enforce', 'scientificDiscoveryExecutionPolicyReportV185',
        'v1.8.5 execution policy', 'v1.8.5 policy blocks'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'scientificDiscoveryExecutionPolicyReport', 'scientificDiscoveryExecutionPolicyToJson',
        'scientificExecutionPolicyActionToJson', 'schemaVersion",'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV185ExecutionPolicyTerms', 'extractV185ExecutionPolicyEvidence', 'buildV185ExecutionPolicyReason',
        'v1.8.5 policy-enforced discovery control', 'execution-policy='
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Policy-enforced discovery control v1.8.5', 'Allowed next actions:', 'Blocked actions:', 'Query replay blocks:'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Execution policy:', 'Policy blocks:', 'scientificDiscoveryExecutionPolicyReport'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt': [
        'kindV185', 'policy_enforced_discovery_control_v185', 'scientificDiscoveryExecutionPolicyReplayBlocks'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificDiscoveryExecutionPolicyEngineV185', 'PolicyEnforcedDiscoveryControlV185'
    ],
    'app/src/main/assets/scientific_term_index_v1.9.3.json': [
        'policy_enforced_discovery_control', 'route_cooldown_policy', 'belief_burial_policy',
        'query_replay_block', 'evidence_contract_breach', 'overgeneralization_policy_lock'
    ],
}
for rel, tokens in checks.items():
    text = Path(rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.8.5 policy-enforced discovery-control token: {rel} -> {token}')
print('v1.8.5 policy-enforced discovery-control audit: PASS')
PY_AUDIT_V185


python3 - <<'PY_AUDIT_V186'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryOutcomeVerifierV186.kt': [
        'ScientificDiscoveryOutcomeVerifierEngineV186', 'ScientificDiscoveryOutcomeVerifierReport',
        'outcome_verification_guides_routing_not_proof', 'outcome_verification_discovery_memory',
        'unmetEvidenceKeys', 'resolvedEvidenceKeys', 'blockedReplayKeys'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ScientificDiscoveryOutcomeVerifierEngineV186.verify', 'scientificDiscoveryOutcomeVerifierReportV186',
        'v1.8.6 outcome verifier', 'v1.8.6 verifier adjustment'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'scientificDiscoveryOutcomeVerifierReport', 'scientificDiscoveryOutcomeVerifierToJson',
        'scientificOutcomeVerificationSignalToJson', 'schemaVersion",'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV186OutcomeVerifierTerms', 'extractV186OutcomeVerifierEvidence', 'buildV186OutcomeVerifierReason',
        'v1.8.6 outcome verification discovery memory', 'outcome-verifier='
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Outcome verification discovery memory v1.8.6', 'Resolved evidence:', 'Unmet evidence:', 'Verifier replay blocks:'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Outcome verifier:', 'Verifier adjustment:', 'scientificDiscoveryOutcomeVerifierReport'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt': [
        'kindV186', 'outcome_verification_discovery_memory_v186', 'scientificDiscoveryOutcomeVerifierUnmetEvidence'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificDiscoveryOutcomeVerifierEngineV186', 'OutcomeVerificationDiscoveryMemoryV186'
    ],
    'app/src/main/assets/scientific_term_index_v1.9.3.json': [
        'outcome_verification_discovery_memory', 'evidence_key_closure', 'replay_penalty_memory', 'policy_reward_dampen'
    ],
}
for rel, tokens in checks.items():
    text = Path(rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.8.6 outcome-verification token: {rel} -> {token}')
print('v1.8.6 outcome-verification discovery-memory audit: PASS')
PY_AUDIT_V186


python3 - <<'PY_V187'
import pathlib, json
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryLineageV187.kt': [
        'hypothesis_lineage_discovery_graph', 'ScientificDiscoveryLineageEngineV187',
        'ScientificDiscoveryLineageReport', 'HypothesisLineageCard', 'contradictionCarryForward'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'scientificDiscoveryLineageReportV187', 'v1.8.7 hypothesis lineage', 'v1.8.7 lineage next action'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'schemaVersion",', 'scientificDiscoveryLineageReport', 'scientificDiscoveryLineageToJson'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV187LineageTerms', 'extractV187LineageEvidence', 'buildV187LineageReason', 'lineage graph'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Hypothesis lineage:', 'Lineage next:', 'Lineage carry-forward'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Hypothesis lineage discovery graph v1.8.7', 'Contradiction carry-forward:', 'Lineage forced evidence:'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificDiscoveryLineageEngineV187', 'HypothesisLineageDiscoveryGraphV187'
    ],
    'app/src/main/assets/scientific_term_index_v1.9.3.json': [
        'hypothesis_lineage_graph', 'parent_evidence', 'contradiction_carry_forward', 'route_split_merge', 'lineage_break_policy'
    ]
}
for rel, tokens in checks.items():
    text = pathlib.Path(rel).read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.8.7 lineage token: {rel} -> {token}')
json.load(open('app/src/main/assets/scientific_term_index_v1.9.3.json'))
print('v1.8.7 hypothesis-lineage discovery-graph audit: PASS')
PY_V187


python3 - <<'PY_V188'
import pathlib, json
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryGapMinerV188.kt': [
        'latent_discovery_gap_miner', 'ScientificDiscoveryGapMinerEngineV188',
        'ScientificDiscoveryGapMinerReport', 'LatentDiscoveryOpportunityCard', 'unaskedBridgeQuestions'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'scientificDiscoveryGapMinerReportV188', 'v1.8.8 latent discovery gap miner', 'v1.8.8 next discovery probe'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'schemaVersion",', 'scientificDiscoveryGapMinerReport', 'scientificDiscoveryGapMinerToJson'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV188GapMinerTerms', 'extractV188GapMinerEvidence', 'buildV188GapMinerReason', 'latent gap miner'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Latent discovery gaps:', 'Latent gap miner:', 'Gap-miner next probe'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Latent discovery gap miner v1.8.8', 'Latent opportunities:', 'High-value missing evidence:'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificDiscoveryGapMinerEngineV188', 'LatentDiscoveryGapMinerV188'
    ],
    'app/src/main/assets/scientific_term_index_v1.9.3.json': [
        'latent_discovery_gap_mining', 'dormant_hypothesis_reactivation', 'unasked_bridge_question', 'discovery_probe_contract', 'route_white_space_map'
    ]
}
for rel, tokens in checks.items():
    text = pathlib.Path(rel).read_text(errors='replace')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.8.8 latent gap-miner token: {rel} -> {token}')
json.load(open('app/src/main/assets/scientific_term_index_v1.9.3.json'))
print('v1.8.8 latent discovery gap-miner audit: PASS')
PY_V188


python3 - <<'PY_AUDIT_V189'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryProbePlannerV189.kt': [
        'executable_discovery_probe_plan', 'ScientificDiscoveryProbePlannerEngineV189', 'DiscoveryProbeStep',
        'ScientificDiscoveryProbePlanReport', 'passCriteria', 'failCriteria', 'killCriteria', 'probeBudget',
        'executable_probe_plan_guides_routing_not_proof'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ScientificDiscoveryProbePlannerEngineV189.plan', 'scientificDiscoveryProbePlanReportV189',
        'v1.8.9 executable discovery probe plan', 'v1.8.9 selected probe query'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'scientificDiscoveryProbePlanReport', 'scientificDiscoveryProbePlanToJson', 'discoveryProbeStepToJson',
        'scientificDiscoveryGapMinerToJson', 'schemaVersion",'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV189ProbePlanTerms', 'extractV189ProbePlanEvidence', 'buildV189ProbePlanReason',
        'v1.8.9 executable discovery probe plan'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Executable probe plan:', 'Probe query:'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Executable discovery probe plan v1.8.9', 'Evidence pack:', 'If succeeds:', 'If fails:'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificDiscoveryProbePlannerEngineV189', 'ExecutableDiscoveryProbePlanV189'
    ],
    'app/src/main/assets/scientific_term_index_v1.9.3.json': [
        'executable_discovery_probe_plan', 'probe_pass_fail_kill_gates', 'evidence_pack_closure', 'probe_budget_guard'
    ]
}
for rel, tokens in checks.items():
    text = Path(rel).read_text()
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.8.9 executable probe-plan token: {rel} -> {token}')
print('v1.8.9 executable discovery probe-plan audit: PASS')
PY_AUDIT_V189


python3 - <<'PY'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryProbeOutcomeLedgerV190.kt': ['probe_outcome_learning_ledger', 'ScientificDiscoveryProbeOutcomeLedgerEngineV190', 'ProbeOutcomeClosureSignal', 'evidenceClosureScore', 'replayPenaltyKeys'],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': ['scientificDiscoveryProbeOutcomeLedgerReport', 'scientificDiscoveryProbeOutcomeLedgerToJson', 'schemaVersion",'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['scientificDiscoveryProbeOutcomeLedgerReportV190', 'v1.9.0 probe outcome ledger'],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': ['extractV190ProbeOutcomeLedgerTerms', 'extractV190ProbeOutcomeLedgerEvidence', 'buildV190ProbeOutcomeLedgerReason'],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': ['Probe outcome learning ledger v1.9.0', 'Closure'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.9.5-alpha-ui-guarded-maintenance', 'ProbeOutcomeLearningLedgerV190'],
    'app/src/main/assets/scientific_term_index_v1.9.3.json': ['probe_outcome_learning_ledger', 'evidence_closure_score', 'replay_penalty_key', 'probe_kill_switch'],
}
for rel, tokens in checks.items():
    text = Path(rel).read_text(encoding='utf-8')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.9.0 probe outcome ledger token: {rel} -> {token}')
print('v1.9.0 probe outcome learning-ledger audit: PASS')
PY


python3 - <<'PY_AUDIT_V191'
from pathlib import Path
import json
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryMetaStrategyGovernorV191.kt': [
        'meta_strategy_governor', 'ScientificDiscoveryMetaStrategyGovernorEngineV191', 'ScientificDiscoveryMetaStrategyReport',
        'MetaStrategyMoveCard', 'strategyState', 'deepThinkPermission', 'routeBudget', 'meta_strategy_governor_guides_routing_not_proof'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'scientificDiscoveryMetaStrategyReport', 'scientificDiscoveryMetaStrategyToJson', 'metaStrategyMoveToJson', 'schemaVersion",'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ScientificDiscoveryMetaStrategyGovernorEngineV191.govern', 'scientificDiscoveryMetaStrategyReportV191',
        'v1.9.1 meta-strategy governor', 'v1.9.1 strategy decision'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV191MetaStrategyTerms', 'extractV191MetaStrategyEvidence', 'buildV191MetaStrategyReason',
        'v1.9.1 meta-strategy governor'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt': [
        'scientificDiscoveryMetaStrategyState', 'scientificDiscoveryMetaStrategyForcedEvidence', 'kindV191'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Meta-strategy governor:', 'Strategy decision:'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Meta-strategy governor v1.9.1', 'Selected strategy:', 'Deep Think permission:'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificDiscoveryMetaStrategyGovernorEngineV191', 'MetaStrategyGovernorV191'
    ],
    'app/src/main/assets/scientific_term_index_v1.9.3.json': [
        'meta_strategy_governor', 'strategy_budget_guard', 'reroute_or_archive_policy', 'bounded_deep_think_permission'
    ]
}
for rel, tokens in checks.items():
    text = Path(rel).read_text(encoding='utf-8')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.9.1 meta-strategy governor token: {rel} -> {token}')
json.load(open('app/src/main/assets/scientific_term_index_v1.9.3.json'))
print('v1.9.1 meta-strategy governor audit: PASS')
PY_AUDIT_V191


python3 - <<'PY_AUDIT_V192'
from pathlib import Path
import json
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryQualityGateV192.kt': [
        'discovery_quality_gate', 'ScientificDiscoveryQualityGateEngineV192', 'ScientificDiscoveryQualityGateReport',
        'DiscoveryQualityIssueCard', 'requiredBeforeRun', 'allowExecution', 'discovery_quality_gate_routing_only_not_biological_proof'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'scientificDiscoveryQualityGateReport', 'scientificDiscoveryQualityGateToJson', 'discoveryQualityIssueToJson', 'schemaVersion",'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ScientificDiscoveryQualityGateEngineV192.evaluate', 'scientificDiscoveryQualityGateReportV192',
        'v1.9.2 discovery quality gate', 'v1.9.2 quality decision'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV192QualityGateTerms', 'extractV192QualityGateEvidence', 'buildV192QualityGateReason',
        'v1.9.2 discovery quality gate'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchKnowledgeStore.kt': [
        'scientificDiscoveryQualityGateState', 'scientificDiscoveryQualityGateForcedEvidence', 'kindV192'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt': [
        'Quality gate:', 'Discovery quality gate:'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Discovery quality gate v1.9.2', 'Required before run:', 'Quality issues:'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ScientificDiscoveryQualityGateEngineV192', 'DiscoveryQualityGateV192'
    ],
    'app/src/main/assets/scientific_term_index_v1.9.3.json': [
        'discovery_quality_gate', 'required_before_run_contract', 'execution_worthiness_score', 'quality_issue_card'
    ]
}
for rel, tokens in checks.items():
    text = Path(rel).read_text(encoding='utf-8')
    for token in tokens:
        if token not in text:
            raise SystemExit(f'Missing v1.9.2 discovery quality gate token: {rel} -> {token}')
json.load(open('app/src/main/assets/scientific_term_index_v1.9.3.json'))
print('v1.9.2 discovery quality gate audit: PASS')
PY_AUDIT_V192


# v1.9.3 executable quality runbook audit
python3 - <<'PY193'
from pathlib import Path
checks = {
    'app/src/main/java/com/immunesignal/app/ScientificDiscoveryRunbookV193.kt': [
        'ScientificDiscoveryRunbookEngineV193', 'executable_quality_runbook', 'hardStops', 'evidenceChecklist', 'blockedReplayKeys'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': [
        'ScientificDiscoveryRunbookEngineV193.compile', 'scientificDiscoveryRunbookReportV193', 'v1.9.3 executable quality runbook'
    ],
    'app/src/main/java/com/immunesignal/app/ResearchModels.kt': [
        'scientificDiscoveryRunbookReport', 'scientificDiscoveryRunbookToJson', 'discoveryRunbookStepToJson', 'schemaVersion",'
    ],
    'app/src/main/java/com/immunesignal/app/CognitiveNextCycleBridge.kt': [
        'extractV193RunbookTerms', 'extractV193RunbookEvidence', 'buildV193RunbookReason'
    ],
    'app/src/main/java/com/immunesignal/app/DiscoveryReportExporter.kt': [
        'Executable quality runbook v1.9.3', 'Evidence checklist:', 'Hard stops:'
    ],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': [
        'v1.9.5-alpha-ui-guarded-maintenance', 'ExecutableQualityRunbookV193'
    ],
    'app/src/main/assets/scientific_term_index_v1.9.3.json': [
        'executable_quality_runbook', 'hard_stop_condition', 'evidence_checklist_closure', 'bounded_execution_budget'
    ]
}
missing = []
for path, tokens in checks.items():
    text = Path(path).read_text()
    for token in tokens:
        if token not in text:
            missing.append(f'{path}: {token}')
if missing:
    raise SystemExit('v1.9.3 runbook audit failed:\n' + '\n'.join(missing))
print('v1.9.3 executable quality runbook audit: PASS')
PY193


python3 - <<'PY_AUDIT_V194'
from pathlib import Path
layout = Path('app/src/main/res/layout/activity_research_autopilot.xml').read_text()
activity = Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
required_ids = [
    'autopilotOutputText','learningMiniReportText','advancedControlsContainer','toggleAdvancedButton',
    'thinkingSessionText','thinkSessionButton','continueThinkingButton','pauseThinkingButton','skipThinkingButton','stopThinkingButton',
    'steeringVariablesInput','steeringFocusInput','steeringRequiredInput','steeringExcludeInput',
    'manualReportInput','copyBriefReportButton','exportDiscoveryPdfButton'
]
missing = [rid for rid in required_ids if f'@+id/{rid}' not in layout]
if missing:
    raise SystemExit('v1.9.4 UI-slim required IDs missing: ' + ', '.join(missing))
line_count = len(layout.splitlines())
if line_count > 320:
    raise SystemExit(f'v1.9.4 UI-slim layout too large: {line_count} lines > 320')
if 'Decision card' not in activity or 'Learning receipt' not in activity:
    raise SystemExit('v1.9.4 concise report renderers missing')
if 'uiCompatibilityAuditTokensV194' not in activity:
    raise SystemExit('v1.9.4 compatibility token anchor missing')
for forbidden in ['.edgeType', '.speciesClass']:
    offenders = []
    for path in Path('app/src/main/java/com/immunesignal/app').glob('ScientificDiscovery*.kt'):
        text = path.read_text()
        if forbidden in text:
            offenders.append(str(path))
    if offenders:
        raise SystemExit(f'v1.9.4 unresolved-field regression {forbidden}: ' + ', '.join(offenders))
print('v1.9.4 maintenance UI-slim audit: PASS')
PY_AUDIT_V194


python3 - <<'PY_AUDIT_V195'
from pathlib import Path
import re
research_layout = Path('app/src/main/res/layout/activity_research_autopilot.xml').read_text()
# v1.10.1: legacy ResultActivity/layout removed.
activity = Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text()
if len(research_layout.splitlines()) > 340:
    raise SystemExit('v1.10.1 research UI exceeded slim budget')
for token in ['Decision card', 'Learning receipt', 'Export shows the technical layers', 'v1.9.5 UI guard']:
    if token not in activity:
        raise SystemExit(f'v1.9.5 compact report guard missing: {token}')
for bad in ['.edgeType', '.speciesClass']:
    offenders = [str(p) for p in Path('app/src/main/java/com/immunesignal/app').glob('ScientificDiscovery*.kt') if bad in p.read_text(errors='replace')]
    if offenders:
        raise SystemExit(f'v1.9.5 unresolved-field regression {bad}: ' + ', '.join(offenders))
print('v1.9.5 guarded UI maintenance audit: PASS')
PY_AUDIT_V195

# v1.9.5 CI-fix guard: every build/extract bridge helper called by CognitiveNextCycleBridge must be defined.
python3 scripts/audit_cognitive_bridge_helpers.py
