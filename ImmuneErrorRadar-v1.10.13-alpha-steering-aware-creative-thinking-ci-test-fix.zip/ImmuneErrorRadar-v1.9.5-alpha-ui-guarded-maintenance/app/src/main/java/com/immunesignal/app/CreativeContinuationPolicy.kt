package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.12: turns Creative Hypothesis Forge output into one bounded executable
 * continuation query. It does not weaken evidence gates: generated hypotheses
 * remain routing proposals only, and the continuation is capped to a single
 * query path so a no-candidate cycle cannot reopen broad PubMed search.
 */
data class CreativeContinuationPlan(
    val active: Boolean,
    val mode: String,
    val sourceFamily: String,
    val queries: List<ResearchQuery>,
    val reason: String,
    val maxQueries: Int,
    val maxResultsPerQuery: Int,
    val claimLimit: String = "creative_continuation_not_evidence"
) {
    companion object {
        fun empty(reason: String = "No creative continuation was warranted.") = CreativeContinuationPlan(
            active = false,
            mode = "NO_CREATIVE_CONTINUATION",
            sourceFamily = "",
            queries = emptyList(),
            reason = reason,
            maxQueries = 0,
            maxResultsPerQuery = 0
        )
    }
}

object CreativeContinuationPolicy {
    fun build(
        datasetForagingReport: DatasetForagingReport,
        shards: List<TestableHypothesisShard>,
        memory: PersistentFailureMemorySnapshot
    ): CreativeContinuationPlan {
        if (!datasetForagingReport.active) {
            return CreativeContinuationPlan.empty("Dataset foraging did not run; no creative continuation can be built.")
        }
        if (datasetForagingReport.candidates.isNotEmpty()) {
            return CreativeContinuationPlan.empty("Dataset candidates exist; evidence closure must run before creative continuation.")
        }
        val forge = datasetForagingReport.creativeHypothesisForgeReport
        if (!forge.active || forge.generated.isEmpty()) {
            return CreativeContinuationPlan.empty("Creative Hypothesis Forge did not generate a bounded test route.")
        }
        val nextSource = datasetForagingReport.noCandidateLearningRecords
            .lastOrNull()
            ?.nextPreferredSource
            ?.trim()
            ?.uppercase(Locale.US)
            .orEmpty()
        if (nextSource.isBlank()) {
            return CreativeContinuationPlan.empty("No next source family was recorded from no-candidate learning.")
        }
        if (nextSource == "ARCHIVE_OR_REFRAME_ROUTE") {
            return CreativeContinuationPlan.empty("All bounded sources are exhausted; archive or reframe rather than continue search.")
        }
        val route = DirectDatasetSourceRouter.routeForSourceFamily(nextSource)
            ?: return CreativeContinuationPlan.empty("No direct route is available for next source family: $nextSource.")

        val creativeQuery = forge.selectedQuery.ifBlank { forge.generated.firstOrNull()?.testQuery.orEmpty() }
        val sourceAware = DatasetQueryCompiler.compileForRoute(route, shards, memory)
        val query = buildContinuationQuery(route, creativeQuery, sourceAware.firstOrNull())
            ?: return CreativeContinuationPlan.empty("Creative continuation could not compile an executable query.")

        return CreativeContinuationPlan(
            active = true,
            mode = "CREATIVE_CONTINUATION_TEST",
            sourceFamily = route.sourceFamily,
            queries = listOf(query),
            reason = "Creative Hypothesis Forge generated a bounded test route after repeated no-candidate results; execute one ${route.sourceFamily} query while keeping creative_hypothesis_not_evidence and all upgrade gates locked.",
            maxQueries = 1,
            maxResultsPerQuery = 3
        )
    }

    private fun buildContinuationQuery(
        route: DirectDatasetSourceRouter.SourceRoute,
        creativeQuery: String,
        fallback: ResearchQuery?
    ): ResearchQuery? {
        val normalizedFamily = route.sourceFamily.trim().uppercase(Locale.US)
        val routeTerms = when (normalizedFamily) {
            "PUBMED_CONTRADICTION" -> "nonresponse heterogeneity no association failed replication negative control"
            "PUBMED_CONTROL" -> "healthy control comparator placebo baseline matched control time course"
            "PUBMED_ACCESSION_MINING" -> "GSE SDY PRJNA SRP dataset accession supplementary cohort"
            "IMM_PORT_SDY" -> "ImmPort SDY study accession phenotype labels outcome response"
            "SRA_PRJNA" -> "PRJNA SRP SRA BioProject RNA-seq phenotype outcome"
            "GEO_GDS" -> "GSE GDS GEO DataSets phenotype labels outcome recovery"
            else -> "dataset accession outcome control longitudinal metadata"
        }
        val seed = creativeQuery.ifBlank { fallback?.query.orEmpty() }.trim()
        if (seed.isBlank()) return fallback
        return ResearchQuery(
            id = "q_v11012_creative_continuation_${normalizedFamily.lowercase(Locale.US)}",
            label = "v1.10.12 creative continuation ${route.sourceFamily}",
            query = "$seed $routeTerms",
            reason = "Execute the selected Creative Hypothesis Forge test against ${route.sourceFamily}; this is routing only, not evidence or claim support. ${route.reason}"
        )
    }
}
