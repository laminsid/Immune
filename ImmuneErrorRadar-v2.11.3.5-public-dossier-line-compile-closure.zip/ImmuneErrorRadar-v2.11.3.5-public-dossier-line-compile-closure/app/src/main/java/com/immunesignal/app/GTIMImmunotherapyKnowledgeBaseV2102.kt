package com.immunesignal.app

// v2.10.2 — Data-first immunotherapy knowledge base.
// This is a broad mechanism ontology, not a disease whitelist. It guides exploration
// across cancer, inflammation, allergy, epidemic/viral, autoimmune, metabolic, gut,
// neurologic, transplant, and unknown topics without converting hypotheses into advice.
object GTIMImmunotherapyKnowledgeBaseV2102 {
    const val VERSION: String = "2.10.2-immunotherapy-knowledge-base"
    const val ASSET_NAME: String = "immunotherapy_mechanism_ontology_v1.json"
    const val CLAIM_LIMIT: String = "knowledge_base_guidance_not_clinical_recommendation"

    fun entries(): List<GTIMImmunotherapyMechanismEntryV2102> = listOf(
        entry(
            id = "checkpoint_release",
            cls = "checkpoint release / T-cell brake removal",
            targets = listOf("PD-1", "PD-L1", "CTLA-4", "LAG-3", "TIGIT"),
            biomarkers = listOf("MSI-H", "dMMR", "TMB-H", "PD-L1 expression", "T-cell infiltration"),
            contexts = listOf("cancer", "tumor", "melanoma", "colorectal", "lung", "solid tumor"),
            rank = "A_TO_D_CONTEXT_DEPENDENT",
            sources = listOf("FDA_or_guideline_when_specific_indication_present", "clinical_trial_or_meta_analysis_required"),
            resistance = listOf("MSS/pMMR", "low TMB", "immune-excluded tumor", "antigen presentation loss"),
            conservation = "HOST_IMMUNE_TARGET_STABLE",
            escape = "LOW_FOR_HOST_TARGET_BUT_HIGH_FOR_TUMOR_ESCAPE",
            safety = listOf("immune-related adverse events", "colitis/hepatitis/endocrinopathy review"),
            terms = listOf("checkpoint", "pd-1", "pd-l1", "ctla", "msi", "dmmr", "tmb", "immune escape")
        ),
        entry(
            id = "cellular_redirection",
            cls = "immune cell redirection / engineered-cell route",
            targets = listOf("CD19", "BCMA", "MAGE-A4", "NY-ESO-1", "tumor antigen", "HLA-restricted antigen"),
            biomarkers = listOf("target antigen", "HLA context", "B-cell or tumor-antigen dominance", "T-cell fitness"),
            contexts = listOf("hematologic malignancy", "solid tumor", "autoimmune", "refractory disease"),
            rank = "A_TO_C_CONTEXT_DEPENDENT",
            sources = listOf("FDA_cell_therapy_approval_when_indication_present", "case_series_or_phase_trial_for_emerging_autoimmune_reset"),
            resistance = listOf("antigen loss", "HLA mismatch", "T-cell exhaustion", "immune suppressive microenvironment"),
            conservation = "TARGET_EXPRESSION_CONTEXT_DEPENDENT",
            escape = "MEDIUM_TO_HIGH_IF_ANTIGEN_LOSS_OR_HLA_RESTRICTION",
            safety = listOf("CRS", "ICANS", "infection risk", "long-term monitoring"),
            terms = listOf("car-t", "car t", "tcr", "til", "bispecific", "cd19", "bcma", "mage", "immune cell")
        ),
        entry(
            id = "cytokine_modulation",
            cls = "cytokine blockade / immune-modulator route",
            targets = listOf("TNF", "IL-6", "IL-23", "IL-17", "IL-4", "IL-13", "JAK/STAT"),
            biomarkers = listOf("cytokine axis", "tissue inflammation marker", "responder phenotype", "clinical endpoint"),
            contexts = listOf("IBD", "psoriasis", "asthma", "arthritis", "autoimmune", "inflammation", "allergy"),
            rank = "A_TO_D_CONTEXT_DEPENDENT",
            sources = listOf("approved_cytokine_target_in_specific_disease", "phase_trial_or_guideline_required"),
            resistance = listOf("pathway redundancy", "non-inflammatory phenotype", "infection risk tradeoff"),
            conservation = "HOST_PATHWAY_STABLE_BUT_CONTEXT_DEPENDENT",
            escape = "LOW_ESCAPE_HIGH_CONTEXT_MISMATCH_RISK",
            safety = listOf("infection risk", "immune suppression", "screening requirements"),
            terms = listOf("cytokine", "tnf", "il-6", "il-23", "il-17", "jak", "th17", "inflammation")
        ),
        entry(
            id = "b_cell_reset",
            cls = "B-cell reset / autoantibody route",
            targets = listOf("CD19", "CD20", "BAFF", "plasma-cell axis", "autoantibody axis"),
            biomarkers = listOf("autoantibodies", "B-cell signature", "CD19/CD20 axis", "refractory context"),
            contexts = listOf("autoimmune", "SLE", "myositis", "systemic sclerosis", "neuromyelitis", "refractory disease"),
            rank = "B_TO_C_EMERGING_CONTEXT_DEPENDENT",
            sources = listOf("early_clinical_case_series_or_trials", "authority_approval_required_before_rank_A"),
            resistance = listOf("plasma-cell persistence", "relapse after B-cell return", "infection risk"),
            conservation = "HOST_CELL_TARGET_STABLE",
            escape = "LOW_ESCAPE_BUT_RELAPSE_OR_SAFETY_RISK",
            safety = listOf("CRS/ICANS for CAR-T", "hypogammaglobulinemia", "infection risk"),
            terms = listOf("b cell", "b-cell", "autoantibody", "cd19", "cd20", "lupus", "sle", "immune reset")
        ),
        entry(
            id = "ige_mast_cell_modulation",
            cls = "IgE / mast-cell / basophil modulation route",
            targets = listOf("IgE", "FcεRI", "mast cells", "basophils", "allergen-specific tolerance"),
            biomarkers = listOf("IgE-mediated allergy", "allergen trigger", "basophil activation", "anaphylaxis risk"),
            contexts = listOf("food allergy", "asthma", "urticaria", "allergic disease", "atopy"),
            rank = "A_TO_D_CONTEXT_DEPENDENT",
            sources = listOf("approved_anti_IgE_or_immunotherapy_when_context_present", "controlled_desensitization_study_required"),
            resistance = listOf("non-IgE mechanism", "multi-trigger disease", "loss of desensitization durability"),
            conservation = "HOST_IMMUNE_TARGET_STABLE",
            escape = "LOW_ESCAPE_BUT_TRIGGER_AND_PHENOTYPE_MISMATCH_RISK",
            safety = listOf("anaphylaxis risk", "supervised challenge required", "not permission to consume allergen freely"),
            terms = listOf("allergy", "ige", "mast", "basophil", "anaphylaxis", "desensitization", "omalizumab")
        ),
        entry(
            id = "passive_antiviral_antibody",
            cls = "passive antiviral antibody / neutralization route",
            targets = listOf("viral surface glycoprotein", "RSV-F", "Ebola GP", "spike", "conserved epitope"),
            biomarkers = listOf("pathogen identity", "high-risk group", "early infection or prevention window", "neutralization against current variant"),
            contexts = listOf("epidemic", "viral infection", "RSV", "Ebola", "COVID", "outbreak", "infant risk"),
            rank = "A_TO_X_VARIANT_DEPENDENT",
            sources = listOf("FDA_CDC_or_RCT_when_specific_countermeasure_current", "variant_neutralization_required"),
            resistance = listOf("variant escape", "epitope mutation", "late treatment window", "immune escape"),
            conservation = "CONSERVATION_MUST_BE_CHECKED",
            escape = "LOW_IF_CONSERVED_TARGET_HIGH_IF_RAPIDLY_MUTATING_OR_DOCUMENTED_ESCAPE",
            safety = listOf("variant relevance", "population eligibility", "public-health guidance required"),
            terms = listOf("viral", "virus", "epidemic", "outbreak", "rsv", "ebola", "covid", "monoclonal", "neutralizing", "antibody")
        ),
        entry(
            id = "innate_interferon_sting",
            cls = "innate immune activation / interferon-STING route",
            targets = listOf("type I interferon", "STING", "cGAS", "TLR", "antigen presentation"),
            biomarkers = listOf("IFN signature", "DNA damage signal", "antigen presentation", "timing window"),
            contexts = listOf("viral", "cancer", "DNA damage", "host response", "vaccine adjuvant", "immunogenic cell death"),
            rank = "C_TO_E_CONTEXT_DEPENDENT",
            sources = listOf("mechanistic_or_early_clinical_evidence_required", "timing_and_toxicity_review_required"),
            resistance = listOf("late inflammatory injury", "immune exhaustion", "negative feedback", "toxicity"),
            conservation = "HOST_PATHWAY_STABLE_TIMING_SENSITIVE",
            escape = "LOW_ESCAPE_HIGH_TIMING_AND_TOXICITY_RISK",
            safety = listOf("cytokine toxicity", "timing-dependent harm", "autoimmune activation risk"),
            terms = listOf("interferon", "ifn", "sting", "cgas", "tlr", "innate", "antigen presentation")
        ),
        entry(
            id = "microbiome_barrier_modulation",
            cls = "microbiome-barrier immune modulation route",
            targets = listOf("butyrate", "SCFA", "mucosal barrier", "Treg", "microbiome diversity"),
            biomarkers = listOf("microbiome profile", "barrier marker", "SCFA/butyrate context", "mucosal cytokines"),
            contexts = listOf("gut", "IBD", "allergy", "metabolic", "neuroimmune", "microbiome", "diet"),
            rank = "B_TO_E_CONTEXT_DEPENDENT",
            sources = listOf("human_diet_microbiome_trial_or_capsule_required", "nutritional_risk_review_required"),
            resistance = listOf("over-restriction", "microbiome starvation", "phenotype mismatch"),
            conservation = "ECOLOGICAL_CONTEXT_DEPENDENT",
            escape = "NOT_VARIANT_ESCAPE_BUT_HIGH_GENERALIZATION_RISK",
            safety = listOf("nutrition deficiency risk", "do not stop medication", "diet not universal cure"),
            terms = listOf("microbiome", "barrier", "butyrate", "scfa", "gut", "diet", "fiber", "mucosal")
        ),
        entry(
            id = "dna_repair_cell_cycle_apoptosis",
            cls = "DNA repair / cell-cycle / apoptosis route",
            targets = listOf("MMR", "DNA repair", "PARP-like vulnerability", "cell cycle", "G2/S", "M phase", "apoptosis"),
            biomarkers = listOf("DNA repair defect", "MMR/MSI/TMB context", "cell-cycle marker", "apoptosis marker"),
            contexts = listOf("cancer", "tumor", "colon", "colorectal", "genetic instability", "mitotic stress"),
            rank = "B_TO_E_CONTEXT_DEPENDENT",
            sources = listOf("clinical_indication_or_preclinical_combination_evidence_required", "toxicity_and_selectivity_review_required"),
            resistance = listOf("repair pathway compensation", "toxicity to normal dividing cells", "clonal resistance"),
            conservation = "TUMOR_BIOLOGY_CONTEXT_DEPENDENT",
            escape = "MEDIUM_RESISTANCE_RISK",
            safety = listOf("toxicity/selectivity risk", "not a treatment protocol", "combination requires trial evidence"),
            terms = listOf("dna", "repair", "apoptosis", "cell cycle", "mitotic", "g2", "m phase", "parp", "mmr", "msi")
        ),
        entry(
            id = "open_mechanism_exploration",
            cls = "open immune/genetic therapeutic exploration route",
            targets = listOf("topic-specific target to resolve", "immune axis", "genetic pathway"),
            biomarkers = listOf("mechanism anchor", "comparator", "human evidence source", "safety boundary"),
            contexts = listOf("unknown", "new topic", "rare disease", "emerging mechanism"),
            rank = "D_TO_E_UNTIL_EVIDENCE_FOUND",
            sources = listOf("dataset_capsule_or_literature_review_required"),
            resistance = listOf("unknown biology", "insufficient comparator", "no authority validation"),
            conservation = "UNKNOWN_UNTIL_TARGET_RESOLVED",
            escape = "UNKNOWN",
            safety = listOf("research-only", "no individualized advice", "follow-up validation target"),
            terms = emptyList()
        )
    )

    fun match(contract: GTIMRunDecisionContractV2740, routeLines: List<String>): List<GTIMImmunotherapyKnowledgeMatchV2102> {
        val text = (contract.primaryAnchor.routeId + " " + contract.rawQuery + " " + routeLines.joinToString(" ")).lowercase()
        val scored = entries().map { entry ->
            val terms = (entry.openExplorationTerms + entry.targets + entry.biomarkersRequired + entry.diseaseContextHints)
                .map { it.lowercase() }
                .filter { it.isNotBlank() }
            val matched = terms.filter { term -> text.contains(term) }.distinct().take(10)
            val state = when {
                entry.id == "open_mechanism_exploration" -> "OPEN_EXPLORATION_FALLBACK_NOT_RESTRICTED"
                matched.size >= 2 -> "MECHANISM_PATTERN_MATCHED_REVIEW_ONLY"
                matched.size == 1 -> "NEAR_MATCH_MECHANISM_REVIEW_ONLY"
                else -> "MECHANISM_PATTERN_NOT_MATCHED"
            }
            val missing = requiredMissing(entry, matched)
            val line = "Immunotherapy knowledge match: version=$VERSION | id=${entry.id} | state=$state | rank=${entry.evidenceRank} | matched=${matched.joinToString(", ").ifBlank { "none" }} | required_missing=${missing.joinToString(", ")} | escape=${entry.escapeRisk} | claim_limit=$CLAIM_LIMIT"
            GTIMImmunotherapyKnowledgeMatchV2102(entry, state, matched, missing, line)
        }
        val strong = scored.filter { it.matchState != "MECHANISM_PATTERN_NOT_MATCHED" && it.entry.id != "open_mechanism_exploration" }
        return (strong.ifEmpty { scored.filter { it.entry.id == "open_mechanism_exploration" } }).take(6)
    }

    private fun requiredMissing(entry: GTIMImmunotherapyMechanismEntryV2102, matched: List<String>): List<String> {
        val matchedJoined = matched.joinToString(" ").lowercase()
        return entry.biomarkersRequired.filter { biomarker ->
            val simple = biomarker.lowercase().split(Regex("[^a-z0-9]+" )).filter { it.length >= 2 }
            simple.none { token -> matchedJoined.contains(token) }
        }.take(5).ifEmpty { listOf("external evidence source", "human-or-model validation context") }
    }

    private fun entry(
        id: String,
        cls: String,
        targets: List<String>,
        biomarkers: List<String>,
        contexts: List<String>,
        rank: String,
        sources: List<String>,
        resistance: List<String>,
        conservation: String,
        escape: String,
        safety: List<String>,
        terms: List<String>
    ): GTIMImmunotherapyMechanismEntryV2102 = GTIMImmunotherapyMechanismEntryV2102(
        id = id,
        mechanismClass = cls,
        targets = targets,
        biomarkersRequired = biomarkers,
        diseaseContextHints = contexts,
        evidenceRank = rank,
        authoritySources = sources,
        resistancePatterns = resistance,
        targetConservation = conservation,
        escapeRisk = escape,
        safetyFlags = safety,
        claimLimits = listOf(CLAIM_LIMIT, "research_only", "not_treatment_advice", "not_clinically_validated_by_gtim"),
        openExplorationTerms = terms
    )
}
