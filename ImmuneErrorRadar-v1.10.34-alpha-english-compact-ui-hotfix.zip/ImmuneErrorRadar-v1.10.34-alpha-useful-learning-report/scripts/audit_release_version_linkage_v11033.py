#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.33 file: {rel}')
    return p.read_text(errors='replace')

checks = {
    'app/build.gradle.kts': ['versionCode = 95', 'versionName = "1.10.33-alpha-lean-agent-runtime"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.33-alpha-lean-agent-runtime', 'LeanAgentRuntimePolicy'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.10.33-alpha-lean-agent-runtime"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 95', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.33"',
        'ENABLE_LEAN_AGENT_RUNTIME_ORCHESTRATOR', 'ENABLE_MATURE_DOMAIN_FOCUS_MODE',
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 95', 'VERSION_NAME: String = "1.10.33-alpha-lean-agent-runtime"',
        'ENGINE_VERSION: String = "v1.10.33-alpha-lean-agent-runtime"', 'LEARNING_SCHEMA_VERSION: String = "1.10.33"',
    ],
    'app/src/main/java/com/immunesignal/app/MatureDomainFocusAndLeanRuntime.kt': [
        'LeadObject', 'LeanAgentRuntimePolicy', 'lean_agent_runtime_routing_only_not_biological_proof',
        'microAgentsRun', 'hardGatesApplied', 'compactDecisionCard',
    ],
    'app/src/main/java/com/immunesignal/app/DatasetForagingModels.kt': ['leanAgentRuntimeReport', 'leadObjects'],
    'app/src/main/java/com/immunesignal/app/DatasetForagingJson.kt': ['leanAgentRuntimeReport', 'leadObjectToJson'],
    'app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt': ['LeanAgentRuntimePolicy.emit', 'leanAgentRuntimeReportV11033'],
    'app/src/main/java/com/immunesignal/app/RuntimeModuleRegistry.kt': ['LeanAgentRuntimePolicy', 'LeadObjectLedger', 'KnowledgeGapQueue'],
    'docs/LEAN_AGENT_RUNTIME_v1.10.33.md': ['v1.10.33', 'Lean Agent Runtime', 'Hard gates', 'Claim lock'],
    'docs/CHANGELOG_v1.10.33.md': ['1.10.33-alpha-lean-agent-runtime', 'versionCode=95', 'LeadObject', 'LeanAgentRuntimePolicy'],
}

for rel, tokens in checks.items():
    text = read(rel)
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.33 token: {token}')

for rel in ['scripts/run_static_checks_fast.sh', 'scripts/run_static_checks_full.sh']:
    text = read(rel)
    for token in ['audit_release_version_linkage_v11032.py', 'audit_release_version_linkage_v11033.py']:
        if token not in text:
            raise SystemExit(f'{rel} missing v1.10.33 static-check token: {token}')

print('v1.10.33 lean agent runtime audit: PASS')
