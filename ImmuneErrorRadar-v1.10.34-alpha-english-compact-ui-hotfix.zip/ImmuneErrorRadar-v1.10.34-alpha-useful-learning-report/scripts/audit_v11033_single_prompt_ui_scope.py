from pathlib import Path

activity = Path('app/src/main/java/com/immunesignal/app/ResearchAutopilotActivity.kt').read_text(errors='replace')
layout = Path('app/src/main/res/layout/activity_research_autopilot.xml').read_text(errors='replace')
policy = Path('app/src/main/java/com/immunesignal/app/ImmuneTopicPromptPolicy.kt').read_text(errors='replace')
workflow = Path('.github/workflows/android-debug.yml').read_text(errors='replace')
test = Path('app/src/test/java/com/immunesignal/app/ImmuneTopicPromptPolicyV11033Test.kt').read_text(errors='replace')
learning_policy = Path('app/src/main/java/com/immunesignal/app/ImmuneLearningValueModePolicy.kt').read_text(errors='replace')
learning_test = Path('app/src/test/java/com/immunesignal/app/ImmuneLearningValueModePolicyV11033Test.kt').read_text(errors='replace')
unlock_policy = Path('app/src/main/java/com/immunesignal/app/DatasetHuntSearchUnlockPolicy.kt').read_text(errors='replace')
unlock_test = Path('app/src/test/java/com/immunesignal/app/DatasetHuntSearchUnlockPolicyTest.kt').read_text(errors='replace')
autopilot = Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text(errors='replace')

def require(text, token, label):
    if token not in text:
        raise SystemExit(f'single prompt UI/scope audit missing in {label}: {token}')

for token in [
    'topicPromptInput',
    'Enter one topic or question for immune-focused research',
    'Immune Search',
]:
    require(layout, token, 'activity_research_autopilot.xml')

for token in [
    'private lateinit var topicPromptInput: EditText',
    'applySingleTopicPromptIfPresent()',
    'ImmuneTopicPromptPolicy.variablesText(topic)',
    'ImmuneTopicPromptPolicy.importedLearningNote(topic)',
    'postSearchThinkingText.visibility = if (advancedControlsVisible) View.VISIBLE else View.GONE',
    'Immune Research Summary',
    'Learning Summary',
    'Research value:',
    'Open checks:',
]:
    require(activity, token, 'ResearchAutopilotActivity.kt')

for token in [
    'object ImmuneTopicPromptPolicy',
    'interpret only from an immune-system perspective',
    'Do not produce general-domain advice',
    'If no immune route exists',
    'immune_topic_prompt_routing_only_not_biological_proof',
]:
    require(policy, token, 'ImmuneTopicPromptPolicy.kt')


for token in [
    'object ImmuneLearningValueModePolicy',
    'LEARNING_VALUE_MODE',
    'shouldForceDatasetFirst',
    'no EvidenceObject means no hypothesis upgrade',
    'learning_value_routing_only_not_biological_proof',
]:
    require(learning_policy, token, 'ImmuneLearningValueModePolicy.kt')

for token in [
    'learningValueModeActive: Boolean = false',
    'Existing EvidenceObject is non-zero',
    'dataset_hunt_unlock:learning_value_mode_forces_dataset_first',
    'LEARNING_VALUE_MODE: user topic/imported immune leads require dataset-first/weak-lead hunting',
]:
    require(unlock_policy, token, 'DatasetHuntSearchUnlockPolicy.kt')

for token in [
    'learningValueModeActiveV11033',
    'learningValueDatasetFirstAllowedV11033',
    'ImmuneLearningValueModePolicy.learningNote',
    'learning_value_mode_forager_consumed_same_cycle_budget',
]:
    require(autopilot, token, 'ResearchAutopilot.kt')

for token in [
    'userTopicWithNoEvidenceActivatesLearningValueMode',
    'nonImmuneGeneralTopicWithoutImmuneRouteDoesNotForceDatasetFirst',
]:
    require(learning_test, token, 'ImmuneLearningValueModePolicyV11033Test.kt')

for token in [
    'learningValueModeUnlocksUserTopicEvenWhenCognitionSpineBlocksDatasetFirst',
    'learningValueModeStillBlocksWhenEvidenceObjectAlreadyExists',
]:
    require(unlock_test, token, 'DatasetHuntSearchUnlockPolicyTest.kt')

for token in [
    'airplaneTopicIsProjectedIntoImmuneLensNotGeneralEngineering',
    'assertTrue(focus.contains("immune-system lens"))',
    'normalizesWhitespaceWithoutUnsupportedRegexEscapes',
]:
    require(test, token, 'ImmuneTopicPromptPolicyV11033Test.kt')

forbidden = [
    'find .ci_project -maxdepth 4 -type f | sort | head',
    'find . -maxdepth 6 -type f | sort | head',
]
for token in forbidden:
    if token in workflow:
        raise SystemExit(f'workflow still has pipefail-prone preview pipeline: {token}')
for forbidden_ui in ['append("• المحرك: "', 'Regex("\\s+") not in policy']:
    if forbidden_ui == 'Regex("\\s+") not in policy':
        if 'Regex("\\\\s+")' not in policy:
            raise SystemExit('single prompt policy must use escaped Kotlin regex: Regex("\\\\s+")')
    elif forbidden_ui in activity:
        raise SystemExit(f'basic UI still exposes technical runtime detail: {forbidden_ui}')

for token in ['sort > "$PREVIEW_FILE"', "sed -n '1,150p'", 'sort > /tmp/repository_structure.txt']:
    require(workflow, token, 'android-debug.yml')

print('v1.10.33/v1.10.34 single prompt UI/scope + workflow preview audit: PASS')
