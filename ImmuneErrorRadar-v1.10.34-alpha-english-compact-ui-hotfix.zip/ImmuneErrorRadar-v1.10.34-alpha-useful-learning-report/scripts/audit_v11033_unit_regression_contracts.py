from pathlib import Path

root = Path('app/src/main/java/com/immunesignal/app')
linkage = (root / 'DatasetForagingPathLinkageGuard.kt').read_text(errors='replace')
focus = (root / 'MatureDomainFocusAndLeanRuntime.kt').read_text(errors='replace')
consistency = (root / 'ReportConsistencyGuard.kt').read_text(errors='replace')
autopilot = (root / 'ResearchAutopilot.kt').read_text(errors='replace')
evidence_leads = (root / 'EvidenceLeadAndManualSeed.kt').read_text(errors='replace')
query_feedback = (root / 'QueryFeedbackPlanner.kt').read_text(errors='replace')
exporter = (root / 'DiscoveryReportExporter.kt').read_text(errors='replace')
source_priority = (root / 'SourcePriorityArbitrationPolicy.kt').read_text(errors='replace')
creative_continuation = (root / 'CreativeContinuationPolicy.kt').read_text(errors='replace')
persistent_failure_memory = (root / 'PersistentFailureMemory.kt').read_text(errors='replace')
activity = (root / 'ResearchAutopilotActivity.kt').read_text(errors='replace')

def require(haystack, token, label):
    if token not in haystack:
        raise SystemExit(f'v1.10.33 regression contract missing in {label}: {token}')

for token in [
    'val matureProbeConsumedByLeadPath = matureProbeReport.active && matureAttempted && leadInspectionFinalState && leadInspectionNextAction',
    'val matureProbeExposedInFinalState = foragerState.contains("MATURE_DOMAIN", ignoreCase = true) || matureProbeConsumedByLeadPath',
    'CONNECTED_MATURE_DOMAIN_TO_LEAD_INSPECTION',
    'consumedByLead=$matureProbeConsumedByLeadPath',
    '"WEAK_DATASET_LEAD"',
    'SourcePriorityArbitrationPolicy.LEAD_OBJECT_FOLLOW_UP',
]:
    require(linkage, token, 'DatasetForagingPathLinkageGuard.kt')

intent_block = '''val intent = when {
            focus.active -> "mature_domain_focus_probe"
            gapQueue.items.any { it.gapId == "outcome_labels" } -> "outcome_label_probe"
            else -> "dataset_lead_foraging"
        }'''
require(focus, intent_block, 'MatureDomainFocusAndLeanRuntime.kt')

for token in [
    'fun includePathLinkageWarnings(',
    'Dataset path linkage: $it',
    'pathLinkageReport.state.contains("WARNINGS", ignoreCase = true)',
    'learningDomainPathLinkageReport.state.contains("WARNINGS", ignoreCase = true)',
    'val baseNeedsCaution = base.warnings.isNotEmpty() && base.status.equals("PASS", ignoreCase = true)',
    'active = true,',
    'Report consistency blocked: unresolved path-linkage warnings remain',
]:
    require(consistency, token, 'ReportConsistencyGuard.kt')

for token in [
    'ReportConsistencyGuard.includePathLinkageWarnings(',
    'learningDomainPathLinkageReport = learningDomainPathLinkageReportV11029,',
    'nearMissOrLeadSignalExistsV11033',
    'LEAD_OBJECT_SECONDARY_LOOKUP',
    'inspect the LeadObject ledger, source IDs, and supplementary-data phrases before rotating',
]:
    require(autopilot, token, 'ResearchAutopilot.kt')

for token in [
    'leadObjects: List<LeadObject> = emptyList()',
    'WEAK_OR_NEAR_MISS_LEADS_PRESERVED_NOT_UPGRADED',
    'bestLeadObject',
    'nearMissAttempt',
    'fallbackNearMissLeadLabel',
    'Near-miss source response',
    'if (accessionHandles.isNotEmpty()) accessionHandles else listOf(lead.title)',
    '?: fallbackNearMissLeadLabel',
    '?: fallbackNearMissLeadLabel?.let { "NEAR_MISS_DATASET_NEEDS_MANUAL_INSPECTION" }',
]:
    require(evidence_leads, token, 'EvidenceLeadAndManualSeed.kt')

for token in [
    'val leadObjectFollowUp = records.any { it.nextPreferredSource == "LEAD_OBJECT_SECONDARY_LOOKUP" }',
    'next action: LEAD_OBJECT_SECONDARY_LOOKUP before any broad source rotation',
    'inspect LeadObject/source IDs/supplementary-data phrases before rotating to another broad source family',
    'converting a weak lead into a DatasetCandidate by secondary lookup',
]:
    require(query_feedback, token, 'QueryFeedbackPlanner.kt')


for token in [
    'internal fun noCandidateHeaderLine(record: JSONObject): String',
    'internal fun noCandidateLearningDetailLine(record: JSONObject): String',
    'Next lead follow-up: LEAD_OBJECT_SECONDARY_LOOKUP',
    'follow-up LEAD_OBJECT_SECONDARY_LOOKUP',
    'Next source family: $next',
]:
    require(exporter, token, 'DiscoveryReportExporter.kt')

for token in [
    'const val LEAD_OBJECT_FOLLOW_UP: String = "LEAD_OBJECT_SECONDARY_LOOKUP"',
    'fun isLeadObjectFollowUp(value: String): Boolean',
    'leadFollowUp=$LEAD_OBJECT_FOLLOW_UP',
    'nextSource=not_applicable_until_lead_lookup_finishes',
]:
    require(source_priority, token, 'SourcePriorityArbitrationPolicy.kt')

for token in [
    'SourcePriorityArbitrationPolicy.isLeadObjectFollowUp(nextSource)',
    'LeadObject secondary lookup is pending',
    'before creative continuation or broad source rotation',
]:
    require(creative_continuation, token, 'CreativeContinuationPolicy.kt')

for token in [
    'SourcePriorityArbitrationPolicy.isLeadObjectFollowUp(firstFollowUp)',
    'next lead follow-up: ${SourcePriorityArbitrationPolicy.LEAD_OBJECT_FOLLOW_UP}',
]:
    require(persistent_failure_memory, token, 'PersistentFailureMemory.kt')

for token in [
    'SourcePriorityArbitrationPolicy.isLeadObjectFollowUp(next)',
    'follow-up=LEAD_OBJECT_SECONDARY_LOOKUP',
    'nextSource=$next',
]:
    require(activity, token, 'ResearchAutopilotActivity.kt')


unit_test = Path('app/src/test/java/com/immunesignal/app/EvidenceLeadManualSeedV11031Test.kt').read_text(errors='replace')
for forbidden in [
    'assertEquals("none", report.bestLead)',
    'Near-miss dataset lead — manual inspection required" + " with bestLead=none"',
]:
    if forbidden in unit_test:
        raise SystemExit(f'v1.10.33 stale near-miss regression assertion remains: {forbidden}')
for token in [
    'fun breakthroughKeepsNearMissSeparateFromEvidence()',
    'report.bestLead.contains("Near-miss source response")',
    'report.nextAction.contains("manual", ignoreCase = true) || report.nextAction.contains("LeadObject", ignoreCase = true)',
    'nearMissLeadIsRelaxedAndShownAsBestLeadWithoutEvidenceUpgrade',
    'relaxationDisplaysNearMissLeadReferenceEvenWithoutAccession',
]:
    require(unit_test, token, 'EvidenceLeadManualSeedV11031Test.kt')

linkage_test = Path('app/src/test/java/com/immunesignal/app/DatasetPathLinkageGuardV11027Test.kt').read_text(errors='replace')
for token in [
    'matureDomainProbeCanBeConsumedByWeakDatasetLeadFollowUpPath',
    'DATASET_FORAGING_WEAK_DATASET_LEAD_FOUND',
    'Preserve the weak/near-miss lead',
    'CONNECTED_MATURE_DOMAIN_TO_LEAD_INSPECTION',
]:
    require(linkage_test, token, 'DatasetPathLinkageGuardV11027Test.kt')

query_feedback_test = Path('app/src/test/java/com/immunesignal/app/LearningMemoryMlTriageV145Test.kt').read_text(errors='replace')
for token in [
    'queryFeedbackTreatsLeadObjectLookupAsFollowUpNotBroadRotation',
    'plan.summary.contains("next action: LEAD_OBJECT_SECONDARY_LOOKUP")',
    'assertFalse(plan.summary.contains("next source family"))',
]:
    require(query_feedback_test, token, 'LearningMemoryMlTriageV145Test.kt')


exporter_test = Path('app/src/test/java/com/immunesignal/app/DiscoveryReportExporterV11033Test.kt').read_text(errors='replace')
for token in [
    'exporterHeaderTreatsLeadObjectLookupAsFollowUpNotSourceFamily',
    'exporterDetailTreatsLeadObjectLookupAsFollowUpNotNextSource',
    'Next lead follow-up: LEAD_OBJECT_SECONDARY_LOOKUP',
    'follow-up LEAD_OBJECT_SECONDARY_LOOKUP',
    'assertFalse(line.contains("Next source family:"))',
    'assertFalse(line.contains("next source LEAD_OBJECT_SECONDARY_LOOKUP"))',
    'exporterHeaderKeepsSourceFamilyWordingForTrueSourceRotation',
]:
    require(exporter_test, token, 'DiscoveryReportExporterV11033Test.kt')

source_priority_test = Path('app/src/test/java/com/immunesignal/app/SourcePriorityDomainExpertiseV11019Test.kt').read_text(errors='replace')
for token in [
    'sourcePriorityTreatsLeadObjectLookupAsFollowUpNotSourceRotation',
    'leadFollowUp=LEAD_OBJECT_SECONDARY_LOOKUP',
    'nextSource=not_applicable_until_lead_lookup_finishes',
]:
    require(source_priority_test, token, 'SourcePriorityDomainExpertiseV11019Test.kt')

creative_test = Path('app/src/test/java/com/immunesignal/app/CreativeContinuationPolicyV11012Test.kt').read_text(errors='replace')
for token in [
    'blocksCreativeContinuationWhenLeadObjectLookupIsPending',
    'LeadObject secondary lookup',
    'before creative continuation',
]:
    require(creative_test, token, 'CreativeContinuationPolicyV11012Test.kt')


final_invariant_test = Path('app/src/test/java/com/immunesignal/app/FinalReportInvariantV11033Test.kt').read_text(errors='replace')
for token in [
    'latestReportWeakLeadMatureProbeScenarioHasNoLinkageWarning',
    'DATASET_FORAGING_WEAK_DATASET_LEAD_FOUND',
    'CONNECTED_MATURE_DOMAIN_TO_LEAD_INSPECTION',
    'consumedByLead=true',
    'assertEquals("PASS", consistency.status)',
    'latestReportLeadRelaxationMustExposeLeadReferenceWhenRelaxedCountIsPositive',
    'Near-miss source response from PUBMED_ACCESSION_MINING',
]:
    require(final_invariant_test, token, 'FinalReportInvariantV11033Test.kt')

print('v1.10.33 unit/report linkage regression contract audit: PASS')
