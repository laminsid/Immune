#!/usr/bin/env python3
from pathlib import Path
missing=[]
checks={
 'app/build.gradle.kts':['versionCode = 86','versionName = "1.10.24-alpha-abstract-accession-harvest"'],
 'app/src/main/java/com/immunesignal/app/AutonomousStagnationEngine.kt':['realPivot','pivotType != "NO_PIVOT"'],
 'app/src/main/java/com/immunesignal/app/QueryPlanner.kt':['stagnationPivot','ANTI_STAGNATION'],
 'app/src/main/java/com/immunesignal/app/HypothesisRankingEngine.kt':['ResearchPolicyLock.STRONG_SIGNAL_CAUSALITY_THRESHOLD','avgMechanisticDecayPenalty'],
 'app/src/main/java/com/immunesignal/app/SourcePriorityArbitrationPolicy.kt':['return (repairedCore + secondary + archive)','source-priority arbitration'],
 'app/src/main/java/com/immunesignal/app/AdaptiveQueryEvolution.kt':['if (current == "BROAD") "MECHANISM" else "CONTRADICTION"'],
 'app/src/main/java/com/immunesignal/app/LearningDeltaEngine.kt':['stable_no_change'],
 'app/src/main/java/com/immunesignal/app/EpistemicBeliefEngine.kt':['capBeliefs','MAX_EPISTEMIC_BELIEFS_PER_REPORT'],
 'app/src/main/java/com/immunesignal/app/LearningRuleEngine.kt':['learning_rules_route_only_not_biological_proof','MIN_LEARNING_RULE_COVERAGE'],
 'app/src/main/java/com/immunesignal/app/DomainExpertiseMemoryPolicy.kt':['reusableQueryVocabularyFromRecentReports'],
 'app/src/main/java/com/immunesignal/app/DatasetQueryCompiler.kt':['domainVocabulary','domainBoost'],
 'app/src/main/java/com/immunesignal/app/RouteFingerprintGuard.kt':['ROUTE_FINGERPRINT_LOOKBACK','route_fingerprint_not_biological_proof'],
 'app/src/main/java/com/immunesignal/app/KnowledgeGapTaskScheduler.kt':['KnowledgeGapTask','knowledge_gap_task_routing_only_not_biological_proof'],
 'app/src/main/java/com/immunesignal/app/DynamicPlausibilityGraphLearner.kt':['PROPOSED_EDGE_NEEDS_VALIDATION'],
 'app/src/main/java/com/immunesignal/app/HypothesisSplitMergeAdvisor.kt':['SPLIT_SUGGESTED','MERGE_CANDIDATE_REQUIRES_PARENT_EVIDENCE'],
 'app/src/main/java/com/immunesignal/app/ContradictionFinder.kt':['ContradictionTemplate','diabetes_metabolic_inflammation'],
 'app/src/main/assets/biological_plausibility_graph_v0.2.json':['interferon_antiviral_axis','tcell_activation_axis'],
 'app/src/main/assets/contradiction_templates_v1.10.21.json':['contradiction_templates_v1.10.21'],
 'docs/LEARNING_RULES_DOMAIN_QUERY_ACTIVATION_v1.10.21.md':['Learning Rules + Domain Query Activation v1.10.21']
}
for file,tokens in checks.items():
    path=Path(file)
    if not path.exists():
        missing.append(f'{file}: missing file')
        continue
    text=path.read_text(errors='replace')
    for token in tokens:
        if token not in text:
            missing.append(f'{file}: missing token {token}')
if missing:
    raise SystemExit('v1.10.21 learning/domain activation audit failed:\n' + '\n'.join(missing))
print('v1.10.21 learning/domain activation audit: PASS')
