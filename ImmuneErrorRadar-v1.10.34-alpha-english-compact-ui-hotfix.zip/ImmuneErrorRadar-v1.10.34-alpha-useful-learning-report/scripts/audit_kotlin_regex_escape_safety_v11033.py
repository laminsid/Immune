from pathlib import Path

# Kotlin normal strings do not support regex shorthand escapes such as \s, \d, or \w
# unless the backslash itself is escaped ("\\\\s") or the regex uses a raw triple string.
# This audit catches the exact class of GitHub compile failure that can slip through
# delimiter/string-balance checks.

BAD_ESCAPES = set('sdwSDBW')
violations = []

for path in list(Path('app/src/main/java').rglob('*.kt')) + list(Path('app/src/test/java').rglob('*.kt')):
    text = path.read_text(errors='replace')
    lines = text.splitlines()
    for lineno, line in enumerate(lines, 1):
        if '"""' in line:
            continue
        # Lightweight normal-string scan per line. Good enough for this codebase because
        # regex literals here are single-line. It intentionally catches all unsupported
        # shorthand escapes, not only Regex(...), because Kotlin would reject them anywhere.
        in_str = False
        i = 0
        while i < len(line):
            ch = line[i]
            if ch == '"':
                # Count preceding backslashes. An odd count means escaped quote.
                bs = 0
                j = i - 1
                while j >= 0 and line[j] == '\\':
                    bs += 1
                    j -= 1
                if bs % 2 == 0:
                    in_str = not in_str
            elif in_str and ch == '\\':
                nxt = line[i + 1] if i + 1 < len(line) else ''
                # If this is a double backslash, it is a valid escaped backslash.
                if nxt == '\\':
                    i += 2
                    continue
                if nxt in BAD_ESCAPES:
                    violations.append(f'{path}:{lineno}: unsupported Kotlin string escape \\{nxt}: {line.strip()[:180]}')
            i += 1

if violations:
    raise SystemExit('Kotlin regex/string escape safety audit failed:\n' + '\n'.join(violations[:40]))

print('Kotlin regex/string escape safety audit v1.10.33: PASS')
