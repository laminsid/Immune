#!/usr/bin/env bash
set -euo pipefail
# Compatibility wrapper. current release: 1.10.34-alpha-useful-learning-report; audit_release_version_linkage_v11031.py + v11032 + v11034
# Compatibility wrapper. Use run_static_checks_fast.sh for PRs and run_static_checks_full.sh for release gates.
exec bash scripts/run_static_checks_full.sh "$@"
