#!/usr/bin/env python3
from pathlib import Path
ROOT = Path('.')

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f'missing v1.10.34 release file: {rel}')
    return p.read_text(errors='replace')

checks = {
    'app/build.gradle.kts': ['versionCode = 96', 'versionName = "1.10.34-alpha-useful-learning-report"'],
    'app/src/main/java/com/immunesignal/app/EngineRuntimeStatus.kt': ['v1.10.34-alpha-useful-learning-report', 'UsefulLearningReportPolicy'],
    'app/src/main/java/com/immunesignal/app/RuntimeFeatureFlags.kt': [
        'RELEASE_TRAIN_VERSION_NAME: String = "1.10.34-alpha-useful-learning-report"',
        'RELEASE_TRAIN_VERSION_CODE: Int = 96', 'LEARNING_SESSION_SCHEMA_VERSION: String = "1.10.34"',
    ],
    'app/src/main/java/com/immunesignal/app/ReleaseVersionLinkageGuard.kt': [
        'VERSION_CODE: Int = 96', 'VERSION_NAME: String = "1.10.34-alpha-useful-learning-report"',
        'ENGINE_VERSION: String = "v1.10.34-alpha-useful-learning-report"', 'LEARNING_SCHEMA_VERSION: String = "1.10.34"',
    ],
    'scripts/run_static_checks_fast.sh': ['audit_v11034_useful_learning_report.py', 'audit_release_version_linkage_v11034.py'],
    'scripts/run_static_checks_full.sh': ['audit_v11034_useful_learning_report.py', 'audit_release_version_linkage_v11034.py'],
}
for rel, tokens in checks.items():
    text = read(rel)
    for token in tokens:
        if token not in text:
            raise SystemExit(f'{rel} missing release linkage token: {token}')
print('v1.10.34 release version linkage audit: PASS')
