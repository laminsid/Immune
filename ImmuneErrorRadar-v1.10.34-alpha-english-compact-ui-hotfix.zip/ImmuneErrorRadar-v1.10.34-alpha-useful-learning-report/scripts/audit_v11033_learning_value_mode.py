from pathlib import Path

files = {
    'ResearchAutopilot.kt': Path('app/src/main/java/com/immunesignal/app/ResearchAutopilot.kt').read_text(errors='replace'),
    'DatasetHuntSearchUnlockPolicy.kt': Path('app/src/main/java/com/immunesignal/app/DatasetHuntSearchUnlockPolicy.kt').read_text(errors='replace'),
    'ImmuneLearningValueModePolicy.kt': Path('app/src/main/java/com/immunesignal/app/ImmuneLearningValueModePolicy.kt').read_text(errors='replace'),
    'DatasetHuntSearchUnlockPolicyTest.kt': Path('app/src/test/java/com/immunesignal/app/DatasetHuntSearchUnlockPolicyTest.kt').read_text(errors='replace'),
    'ImmuneLearningValueModePolicyV11033Test.kt': Path('app/src/test/java/com/immunesignal/app/ImmuneLearningValueModePolicyV11033Test.kt').read_text(errors='replace'),
}

def require(name, token):
    if token not in files[name]:
        raise SystemExit(f'learning-value mode audit missing in {name}: {token}')

for token in [
    'LEARNING_VALUE_MODE',
    'CLAIM_LIMIT',
    'shouldForceDatasetFirst',
    'no EvidenceObject means no hypothesis upgrade',
]:
    require('ImmuneLearningValueModePolicy.kt', token)

for token in [
    'learningValueModeActive: Boolean = false',
    'Existing EvidenceObject is non-zero',
    'dataset_hunt_unlock:learning_value_mode_forces_dataset_first',
]:
    require('DatasetHuntSearchUnlockPolicy.kt', token)

for token in [
    'learningValueModeActiveV11033',
    'learningValueDatasetFirstAllowedV11033',
    'ImmuneLearningValueModePolicy.learningNote',
]:
    require('ResearchAutopilot.kt', token)

for token in [
    'learningValueModeUnlocksUserTopicEvenWhenCognitionSpineBlocksDatasetFirst',
    'learningValueModeStillBlocksWhenEvidenceObjectAlreadyExists',
]:
    require('DatasetHuntSearchUnlockPolicyTest.kt', token)

for token in [
    'userTopicWithNoEvidenceActivatesLearningValueMode',
    'nonImmuneGeneralTopicWithoutImmuneRouteDoesNotForceDatasetFirst',
]:
    require('ImmuneLearningValueModePolicyV11033Test.kt', token)

print('v1.10.33 learning value mode audit: PASS')
