plugins {
    id("com.android.application")
    kotlin("android")
    id("io.gitlab.arturbosch.detekt") version "1.23.7"
}

android {
    namespace = "com.immunesignal.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.immunesignal.app"
        minSdk = 26
        targetSdk = 35
        // legacy_audit_version_token_v11017 expects: versionCode = 86 and 1.10.22-alpha-accession-exhaustion-domain-activation
        versionCode = 96
        // legacy_audit_version_token_v11018: versionName = "1.10.24-alpha-abstract-accession-harvest"
        // legacy_audit_version_token_v11027: versionName = "1.10.27-alpha-dataset-path-linkage-guard"
        versionName = "1.10.34-alpha-useful-learning-report"
    }

    buildFeatures {
        viewBinding = true
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Release signing stays environment-controlled in CI/Play Console.
            // Do not commit keystore material into the repository.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
}

detekt {
    buildUponDefaultConfig = true
    allRules = false
    config.setFrom(files("../config/detekt/detekt.yml"))
}

// legacy audit version token: 1.10.22-alpha-accession-exhaustion-domain-activation
// legacy audit version token: 1.10.25-alpha-data-availability-query-priority
// legacy audit version token: versionCode = 89

// legacy audit version token: versionCode = 91
// legacy audit version token: 1.10.29-alpha-learning-domain-path-linkage
// legacy audit version token: versionName = "1.10.29-alpha-learning-domain-path-linkage"
