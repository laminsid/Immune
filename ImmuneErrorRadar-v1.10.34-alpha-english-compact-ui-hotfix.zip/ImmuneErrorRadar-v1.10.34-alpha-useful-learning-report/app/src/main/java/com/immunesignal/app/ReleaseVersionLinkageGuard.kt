package com.immunesignal.app

/**
 * v1.10.34: Release version linkage guard kept mandatory for useful learning report release.
 *
 * This guard is intentionally small: it keeps release identity auditable across
 * Gradle, runtime status, learning-session schema, report labels, documentation,
 * and static checks. It does not affect scientific interpretation.
 */
object ReleaseVersionLinkageGuard {
    const val VERSION_CODE: Int = 96
    const val VERSION_NAME: String = "1.10.34-alpha-useful-learning-report"
    const val ENGINE_VERSION: String = "v1.10.34-alpha-useful-learning-report"
    const val LEARNING_SCHEMA_VERSION: String = "1.10.34"
    const val CLAIM_LIMIT: String = "release_version_linkage_not_biological_proof"

    fun summary(): String =
        "v1.10.34 release version linkage: build, engine, learning schema, useful learning report, topic memory, lead inspection queue, report layers, docs, and static checks are aligned; legacy tokens remain audit-only."

    fun isRuntimeAligned(): Boolean =
        EngineRuntimeStatus.ACTIVE_ENGINE_VERSION == ENGINE_VERSION &&
            RuntimeFeatureFlags.LEARNING_SESSION_SCHEMA_VERSION == LEARNING_SCHEMA_VERSION &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_NAME == VERSION_NAME &&
            RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == VERSION_CODE
}
