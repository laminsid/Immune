package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.34: useful learning report layer.
 *
 * This layer deliberately separates research usefulness from scientific belief.
 * No EvidenceObject still means no biological proof, no causal language, no diagnosis,
 * no treatment recommendation, and no hypothesis upgrade. The user still receives a
 * compact, useful immune-lens report: what was learned, what lead was preserved, which
 * topic thread was updated, and what concrete evidence task is next.
 */
data class LearningValueScoreReport(
    val active: Boolean,
    val score: Int,
    val state: String,
    val evidenceStatus: String,
    val learnedSummary: String,
    val usefulOutcomes: List<String>,
    val nextAction: String,
    val claimLimit: String = UsefulLearningReportPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = LearningValueScoreReport(
            active = false,
            score = 0,
            state = "NOT_EVALUATED",
            evidenceStatus = "none",
            learnedSummary = "No useful learning report was evaluated.",
            usefulOutcomes = emptyList(),
            nextAction = "Run an immune-lens topic search.",
            claimLimit = UsefulLearningReportPolicy.CLAIM_LIMIT
        )
    }
}

data class TopicMemoryThread(
    val topicId: String,
    val topic: String,
    val immuneAxis: String,
    val status: String,
    val leadState: String,
    val lastBlocker: String,
    val nextQuery: String,
    val claimLimit: String = UsefulLearningReportPolicy.CLAIM_LIMIT
)

data class TopicMemoryLedgerReport(
    val active: Boolean,
    val threadCount: Int,
    val activeThread: TopicMemoryThread?,
    val recentThreads: List<TopicMemoryThread>,
    val nextAction: String,
    val claimLimit: String = UsefulLearningReportPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = TopicMemoryLedgerReport(
            active = false,
            threadCount = 0,
            activeThread = null,
            recentThreads = emptyList(),
            nextAction = "No topic thread available yet.",
            claimLimit = UsefulLearningReportPolicy.CLAIM_LIMIT
        )
    }
}

data class LeadInspectionQueueItem(
    val leadId: String,
    val label: String,
    val sourceFamily: String,
    val status: String,
    val missing: List<String>,
    val nextLookup: String,
    val priority: Int,
    val claimLimit: String = UsefulLearningReportPolicy.CLAIM_LIMIT
)

data class LeadInspectionQueueReport(
    val active: Boolean,
    val queueState: String,
    val openItems: Int,
    val items: List<LeadInspectionQueueItem>,
    val nextAction: String,
    val claimLimit: String = UsefulLearningReportPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = LeadInspectionQueueReport(
            active = false,
            queueState = "NOT_EVALUATED",
            openItems = 0,
            items = emptyList(),
            nextAction = "No lead inspection queue was evaluated.",
            claimLimit = UsefulLearningReportPolicy.CLAIM_LIMIT
        )
    }
}

data class UsefulReportLayersReport(
    val active: Boolean,
    val state: String,
    val uiSummaryLines: List<String>,
    val onePageResearchLines: List<String>,
    val appendixPolicy: String,
    val claimLimit: String = UsefulLearningReportPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = UsefulReportLayersReport(
            active = false,
            state = "NOT_EVALUATED",
            uiSummaryLines = emptyList(),
            onePageResearchLines = emptyList(),
            appendixPolicy = "Technical appendix remains available only through Export/Advanced.",
            claimLimit = UsefulLearningReportPolicy.CLAIM_LIMIT
        )
    }
}

data class ResearchProgressWithoutEvidenceReport(
    val active: Boolean,
    val progressState: String,
    val successCategories: List<String>,
    val blockedClaims: List<String>,
    val nextAction: String,
    val claimLimit: String = UsefulLearningReportPolicy.CLAIM_LIMIT
) {
    companion object {
        fun empty() = ResearchProgressWithoutEvidenceReport(
            active = false,
            progressState = "NOT_EVALUATED",
            successCategories = emptyList(),
            blockedClaims = listOf("biological proof", "causal claim", "diagnosis", "treatment recommendation"),
            nextAction = "Run a useful-learning cycle.",
            claimLimit = UsefulLearningReportPolicy.CLAIM_LIMIT
        )
    }
}

object UsefulLearningReportPolicy {
    const val CLAIM_LIMIT = "useful_learning_report_not_biological_proof"

    fun learningValueScore(
        steering: ResearchSteeringProfile?,
        importedSignals: List<ImportedReportSignal>,
        importedRawTexts: List<String>,
        forager: DatasetForagingReport,
        learningOs: LearningOsReport,
        discoveryReadiness: DiscoveryReadinessReport
    ): LearningValueScoreReport {
        val useful = usefulOutcomes(steering, importedSignals, importedRawTexts, forager, learningOs)
        val base = 10
        val score = (base + useful.size * 12 +
            (if (forager.leadObjects.isNotEmpty()) 12 else 0) +
            (if (forager.knowledgeGapQueueReport.items.isNotEmpty()) 8 else 0) +
            (if (forager.queryFeedbackPlan.active) 7 else 0) +
            (if (forager.active) 8 else 0)).coerceIn(0, 100)
        val state = when {
            forager.evidenceActivitySeparationReport.evidenceObjects > 0 -> "EVIDENCE_OBJECT_REQUIRES_REVIEW"
            score >= 60 -> "USEFUL_LEARNING_STRONG_NO_EVIDENCE"
            score >= 35 -> "USEFUL_LEARNING_PROGRESS_NO_EVIDENCE"
            score > 0 -> "LOW_VALUE_LEARNING_NO_EVIDENCE"
            else -> "NO_USEFUL_LEARNING_YET"
        }
        val learned = buildLearnedSummary(steering, forager, learningOs, useful)
        return LearningValueScoreReport(
            active = true,
            score = score,
            state = state,
            evidenceStatus = if (forager.evidenceActivitySeparationReport.evidenceObjects > 0) "evidence_object_present_requires_review" else "no_evidence_object_no_upgrade",
            learnedSummary = learned,
            usefulOutcomes = useful,
            nextAction = nextUsefulAction(forager, learningOs, discoveryReadiness)
        )
    }

    fun topicMemoryLedger(
        steering: ResearchSteeringProfile?,
        importedSignals: List<ImportedReportSignal>,
        importedRawTexts: List<String>,
        forager: DatasetForagingReport
    ): TopicMemoryLedgerReport {
        val topics = extractTopics(steering, importedSignals, importedRawTexts).take(8)
        if (topics.isEmpty()) return TopicMemoryLedgerReport.empty()
        val threads = topics.mapIndexed { index, topic ->
            val axis = inferAxis(topic)
            TopicMemoryThread(
                topicId = "topic_${stableId(topic)}_$index",
                topic = topic.take(120),
                immuneAxis = axis,
                status = if (forager.active) "learning_active" else "stored_waiting_for_dataset_hunt",
                leadState = when {
                    forager.leadObjects.isNotEmpty() -> "weak_or_near_miss_lead_available"
                    forager.candidates.isNotEmpty() -> "candidate_available_needs_metadata"
                    else -> "no_lead_yet"
                },
                lastBlocker = firstBlocker(forager),
                nextQuery = topicQuery(topic, axis)
            )
        }
        return TopicMemoryLedgerReport(
            active = true,
            threadCount = threads.size,
            activeThread = threads.firstOrNull(),
            recentThreads = threads,
            nextAction = "Continue the active topic thread from its nextQuery; do not start from zero on repeated or related topics."
        )
    }

    fun leadInspectionQueue(forager: DatasetForagingReport): LeadInspectionQueueReport {
        val leadItems = forager.leadObjects.mapIndexed { index, lead ->
            LeadInspectionQueueItem(
                leadId = lead.leadId,
                label = lead.title.ifBlank { lead.sourceFamily }.take(140),
                sourceFamily = lead.sourceFamily,
                status = if (lead.detectedAccessions.isNotEmpty()) "ACCESSION_NEEDS_METADATA" else "LEAD_OBJECT_SECONDARY_LOOKUP",
                missing = missingForLead(lead),
                nextLookup = nextLookupForLead(lead),
                priority = (lead.confidence + missingForLead(lead).size * 5).coerceIn(10, 95)
            )
        }
        val fallback = if (leadItems.isEmpty() && forager.evidenceDiscoveryBreakthroughReport.bestLead != "none") {
            listOf(
                LeadInspectionQueueItem(
                    leadId = "breakthrough_${stableId(forager.evidenceDiscoveryBreakthroughReport.bestLead)}",
                    label = forager.evidenceDiscoveryBreakthroughReport.bestLead.take(140),
                    sourceFamily = "BREAKTHROUGH_REPORT",
                    status = forager.evidenceDiscoveryBreakthroughReport.bestLeadStatus,
                    missing = listOf("accession", "minimum_metadata", "outcome_labels", "control_or_comparator"),
                    nextLookup = forager.evidenceDiscoveryBreakthroughReport.nextAction,
                    priority = 55
                )
            )
        } else emptyList()
        val items = (leadItems + fallback).sortedByDescending { it.priority }.take(12)
        return LeadInspectionQueueReport(
            active = true,
            queueState = if (items.isEmpty()) "NO_OPEN_LEAD_INSPECTION_ITEMS" else "OPEN_LEADS_REQUIRE_SECONDARY_LOOKUP",
            openItems = items.size,
            items = items,
            nextAction = items.firstOrNull()?.nextLookup ?: "Create a weak lead through dataset-first search or manual seed."
        )
    }

    fun progressWithoutEvidence(
        forager: DatasetForagingReport,
        learningValue: LearningValueScoreReport,
        topicLedger: TopicMemoryLedgerReport,
        leadQueue: LeadInspectionQueueReport
    ): ResearchProgressWithoutEvidenceReport {
        val categories = linkedSetOf<String>()
        if (topicLedger.active) categories += "topic_stored"
        if (learningValue.usefulOutcomes.contains("query_strategy_changed")) categories += "query_strategy_changed"
        if (forager.leadObjects.isNotEmpty() || leadQueue.openItems > 0) categories += "weak_lead_preserved"
        if (forager.knowledgeGapQueueReport.items.isNotEmpty()) categories += "gap_queue_created"
        if (forager.active || forager.sourceFamiliesAttempted.isNotEmpty()) categories += "dataset_first_attempted"
        if (forager.evidenceDiscoveryBreakthroughReport.postPubMedSearchStrategies.isNotEmpty()) categories += "post_pubmed_strategy_prepared"
        if (forager.noCandidateLearningRecords.isNotEmpty()) categories += "failure_pattern_learned"
        return ResearchProgressWithoutEvidenceReport(
            active = true,
            progressState = if (categories.isEmpty()) "NO_PROGRESS_RECORDED" else "RESEARCH_PROGRESS_NOT_EVIDENCE",
            successCategories = categories.toList(),
            blockedClaims = listOf("biological proof", "causal claim", "diagnosis", "treatment recommendation", "hypothesis upgrade"),
            nextAction = leadQueue.nextAction.ifBlank { learningValue.nextAction }
        )
    }

    fun reportLayers(
        topicLedger: TopicMemoryLedgerReport,
        learningValue: LearningValueScoreReport,
        leadQueue: LeadInspectionQueueReport,
        progress: ResearchProgressWithoutEvidenceReport
    ): UsefulReportLayersReport {
        val topic = topicLedger.activeThread?.topic ?: "immune topic"
        val leadLabel = leadQueue.items.firstOrNull()?.label ?: "no lead yet"
        val ui = listOf(
            "Value: ${learningValue.score}/100 ${learningValue.state}",
            "Topic: $topic",
            "Learned: ${learningValue.learnedSummary}",
            "Best lead: $leadLabel",
            "Next: ${learningValue.nextAction}"
        )
        val onePage = listOf(
            "Research value: ${learningValue.score}/100 — ${learningValue.state}",
            "Evidence status: ${learningValue.evidenceStatus}; claims stay locked.",
            "Topic memory: ${topicLedger.threadCount} thread(s); active=${topicLedger.activeThread?.immuneAxis ?: "none"}.",
            "Lead queue: ${leadQueue.openItems} open item(s); first=${leadLabel}.",
            "Progress without EvidenceObject: ${progress.successCategories.joinToString(", ").ifBlank { "none" }}.",
            "Next action: ${learningValue.nextAction}"
        )
        return UsefulReportLayersReport(
            active = true,
            state = "THREE_LAYER_REPORT_READY",
            uiSummaryLines = ui,
            onePageResearchLines = onePage,
            appendixPolicy = "Show only the five-line useful summary in the main UI; keep runtime, version, gates, audits, and full technical traces in Export/Advanced."
        )
    }

    fun learningNote(report: LearningValueScoreReport): String =
        "v1.10.34 useful learning: score=${report.score}/100 state=${report.state}; outcomes=${report.usefulOutcomes.joinToString(", ").ifBlank { "none" }}; claim-limit=$CLAIM_LIMIT"

    private fun usefulOutcomes(
        steering: ResearchSteeringProfile?,
        importedSignals: List<ImportedReportSignal>,
        importedRawTexts: List<String>,
        forager: DatasetForagingReport,
        learningOs: LearningOsReport
    ): List<String> {
        val out = linkedSetOf<String>()
        if (steering != null || importedSignals.any { it.title.contains("Single topic prompt", true) } || importedRawTexts.isNotEmpty()) out += "topic_stored"
        if (forager.active || forager.sourceFamiliesAttempted.isNotEmpty()) out += "dataset_first_attempted"
        if (forager.leadObjects.isNotEmpty() || forager.candidates.any { it.status.contains("LEAD", true) }) out += "weak_lead_preserved"
        if (forager.knowledgeGapQueueReport.items.isNotEmpty()) out += "gap_queue_created"
        if (forager.queryFeedbackPlan.active || learningOs.preventiveGates.isNotEmpty()) out += "query_strategy_changed"
        if (forager.evidenceDiscoveryBreakthroughReport.postPubMedSearchStrategies.isNotEmpty()) out += "dataset_catalog_strategy_prepared"
        if (learningOs.incident.rootCauses.isNotEmpty()) out += "failure_pattern_learned"
        return out.toList()
    }

    private fun buildLearnedSummary(
        steering: ResearchSteeringProfile?,
        forager: DatasetForagingReport,
        learningOs: LearningOsReport,
        useful: List<String>
    ): String {
        val axis = steering?.inferredAxes?.firstOrNull() ?: forager.matureDomainFocusReport.selectedDomain.takeIf { it != "none" } ?: "immune evidence route"
        val blocker = learningOs.incident.rootCauses.firstOrNull() ?: firstBlocker(forager)
        return "Mapped topic to $axis; blocker=$blocker; useful=${useful.take(3).joinToString("+").ifBlank { "routing memory" }}."
    }

    private fun nextUsefulAction(forager: DatasetForagingReport, learningOs: LearningOsReport, discoveryReadiness: DiscoveryReadinessReport): String {
        return firstNonBlank(
            forager.leadObjects.firstOrNull()?.let { nextLookupForLead(it) },
            forager.evidenceDiscoveryBreakthroughReport.nextAction.takeIf { forager.evidenceDiscoveryBreakthroughReport.active },
            forager.knowledgeGapQueueReport.items.firstOrNull()?.nextQuery,
            learningOs.nextLearningAction,
            discoveryReadiness.blockers.firstOrNull(),
            "Run dataset-first search with outcome/control metadata terms."
        ).take(280)
    }

    private fun extractTopics(steering: ResearchSteeringProfile?, importedSignals: List<ImportedReportSignal>, importedRawTexts: List<String>): List<String> {
        val out = mutableListOf<String>()
        steering?.variables?.firstOrNull()?.let { out += it }
        importedSignals.filter { it.title.contains("Single topic prompt", true) }.forEach { signal ->
            val clean = signal.preview
                .substringAfter("Immune Error Radar:", signal.preview)
                .substringBefore("Scope rule:")
                .trim()
            if (clean.isNotBlank()) out += clean
        }
        importedRawTexts.forEach { raw ->
            val clean = raw.substringAfter("Immune Error Radar:", raw).substringBefore("Scope rule:").trim()
            if (clean.isNotBlank()) out += clean
        }
        return out.map { ImmuneTopicPromptPolicy.normalizeTopic(it) }.filter { it.isNotBlank() }.distinct()
    }

    private fun inferAxis(topic: String): String {
        val t = topic.lowercase(Locale.US)
        return when {
            t.contains("arthritis") || t.contains("rheumatoid") || t.contains("autoimmune") -> "tnf_il6_autoimmune_axis"
            t.contains("corona") || t.contains("covid") || t.contains("hanta") || t.contains("virus") || t.contains("viral") -> "interferon_antiviral_axis"
            t.contains("allerg") || t.contains("mast") || t.contains("histamine") -> "type2_allergy_axis"
            t.contains("stress") || t.contains("sleep") || t.contains("fatigue") -> "psychoneuroimmune_axis"
            t.contains("gut") || t.contains("barrier") || t.contains("microbiome") -> "barrier_tissue_axis"
            else -> "immune_lens_general_axis"
        }
    }

    private fun topicQuery(topic: String, axis: String): String = when (axis) {
        "tnf_il6_autoimmune_axis" -> "$topic human cohort RNA-seq cytokine TNF IL6 outcome severity control comparator GSE PRJNA"
        "interferon_antiviral_axis" -> "$topic interferon viral load immune response longitudinal outcome severity control cohort GSE PRJNA SRP"
        "type2_allergy_axis" -> "$topic mast cell histamine allergy cytokine RNA-seq cohort outcome control GSE"
        else -> "$topic immune response inflammation human cohort dataset outcome control comparator GSE PRJNA"
    }.take(260)

    private fun missingForLead(lead: LeadObject): List<String> {
        val missing = mutableListOf<String>()
        if (lead.detectedAccessions.isEmpty()) missing += "accession"
        if (!lead.humanLikely) missing += "human_or_patient_data"
        if (!lead.outcomeLikely) missing += "outcome_labels"
        if (!lead.controlLikely) missing += "control_or_comparator"
        if (!lead.timeLikely) missing += "time_order"
        if (!lead.sampleSizeLikely) missing += "sample_size"
        if (!lead.licenseAccessLikely) missing += "license_access"
        return missing.distinct().ifEmpty { listOf("minimum_metadata") }
    }

    private fun nextLookupForLead(lead: LeadObject): String {
        return if (lead.detectedAccessions.isNotEmpty()) {
            "Parse minimum metadata for ${lead.detectedAccessions.first()} and verify outcome/control/time labels."
        } else {
            "Run LEAD_OBJECT_SECONDARY_LOOKUP for ${lead.sourceFamily}: inspect source IDs, supplementary-data phrases, GSE/PRJNA/SRP/E-MTAB/SDY handles, then parse metadata."
        }
    }

    private fun firstBlocker(forager: DatasetForagingReport): String = firstNonBlank(
        forager.knowledgeGapQueueReport.items.firstOrNull()?.gapId,
        forager.noCandidateLearningRecords.firstOrNull()?.missing,
        forager.blockedLearningReason,
        "no_dataset_accession"
    )

    private fun firstNonBlank(vararg values: String?): String = values.firstOrNull { !it.isNullOrBlank() } ?: ""

    private fun stableId(value: String): String = value.lowercase(Locale.US)
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
        .take(40)
        .ifBlank { "topic" }
}
