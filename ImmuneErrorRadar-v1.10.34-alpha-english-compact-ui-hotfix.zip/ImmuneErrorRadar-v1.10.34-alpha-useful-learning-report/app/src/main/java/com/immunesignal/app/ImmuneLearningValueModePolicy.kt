package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.33 learning-value mode.
 *
 * Scientific claim gates remain strict: no EvidenceObject means no hypothesis upgrade,
 * no causal language, and no biological proof. This policy prevents the UI/topic prompt
 * path from becoming useless when the old cognition spine locks the cycle to one narrow
 * query. A user topic, imported note, or manual candidate is allowed to create routing
 * value: dataset-first foraging, weak-lead preservation, gap closure, and a useful
 * immune-lens research report.
 */
object ImmuneLearningValueModePolicy {
    const val MODE: String = "LEARNING_VALUE_MODE"
    const val CLAIM_LIMIT: String = "learning_value_routing_only_not_biological_proof"

    private val topicMarkers = listOf(
        "single topic prompt",
        "user research topic for immune error radar",
        "scope rule: interpret only from an immune-system perspective",
        ImmuneTopicPromptPolicy.CLAIM_LIMIT.lowercase(Locale.US)
    )

    private val usefulTopicTerms = listOf(
        "immune", "immunity", "inflammation", "cytokine", "arthritis", "rheumatoid",
        "autoimmune", "autoimmunity", "viral", "virus", "corona", "covid", "hanta",
        "allergy", "mast", "barrier", "cohort", "dataset", "outcome", "control",
        "transcript", "rna", "single-cell", "single cell", "gse", "geo", "sra", "prjna",
        "sdy", "immport"
    )

    fun isActive(
        steering: ResearchSteeringProfile?,
        importedSignals: List<ImportedReportSignal>,
        importedRawTexts: List<String>,
        recentReports: List<String>
    ): Boolean {
        val text = buildString {
            steering?.let {
                append(it.variables.joinToString(" ")).append(' ')
                append(it.focusQuestion).append(' ')
                append(it.requiredTerms.joinToString(" ")).append(' ')
                append(it.inferredAxes.joinToString(" ")).append(' ')
            }
            importedSignals.take(12).forEach { signal ->
                append(signal.title).append(' ')
                append(signal.preview).append(' ')
                append(signal.extractedKeywords.joinToString(" ")).append(' ')
                append(signal.matchedAxes.joinToString(" ")).append(' ')
            }
            importedRawTexts.take(12).forEach { append(it).append(' ') }
            recentReports.take(3).forEach { append(it.take(1200)).append(' ') }
        }.lowercase(Locale.US)

        val topicPromptSeen = topicMarkers.any { marker -> text.contains(marker) }
        val immuneTopicSeen = usefulTopicTerms.any { term -> text.contains(term) }
        val repeatedManualInputs = importedSignals.count { it.title.equals("Single topic prompt", ignoreCase = true) } >= 1 || importedRawTexts.size >= 2
        val noEvidenceStillOpen = text.contains("no_evidence_object_no_upgrade") ||
            text.contains("no dataset accession") ||
            text.contains("no_dataset_accession") ||
            text.contains("dataset candidates: 0") ||
            text.contains("evidence objects: 0") ||
            text.contains("no evidence object")

        return (topicPromptSeen || repeatedManualInputs) && immuneTopicSeen && noEvidenceStillOpen
    }

    fun shouldForceDatasetFirst(
        steering: ResearchSteeringProfile?,
        importedSignals: List<ImportedReportSignal>,
        importedRawTexts: List<String>,
        recentReports: List<String>
    ): Boolean = isActive(steering, importedSignals, importedRawTexts, recentReports)

    fun learningNote(active: Boolean): String? {
        if (!active) return null
        return "$MODE active: user topic/imported leads create routing value even when no EvidenceObject exists; run dataset-first/weak-lead hunt, preserve useful leads, and keep claim upgrades locked. Claim limit: $CLAIM_LIMIT."
    }
}
