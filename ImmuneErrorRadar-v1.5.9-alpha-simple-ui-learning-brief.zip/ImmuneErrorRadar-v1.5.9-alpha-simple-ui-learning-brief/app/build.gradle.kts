plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.immunesignal.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.immunesignal.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 41
        versionName = "1.5.9-alpha-simple-ui-learning-brief"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    // v1.1: required for ComponentActivity (lifecycleScope, registerForActivityResult)
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // v1.0: local JVM unit tests for scoring engines, sanitizer, and parsers.
    // org.json is provided in the Android runtime but stubbed in the test
    // classpath, so we add a real implementation for tests only.
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")
}
