package com.immunesignal.app

/**
 * General microbiome bridge metadata for v2.7.3 patch-line.
 *
 * This is deliberately broad: it supports routes where microbiome signals connect to molecules,
 * immune mediators and phenotypes without asserting that one bacterium, one toxin or one disease
 * is causal. v2.7.3.8 makes the bridge executable by exposing query seeds and planner targets,
 * while keeping all outputs lookup-only and claim-gated.
 */
data class GTIMGeneralMicrobiomeBridgePlanV2732(
    val active: Boolean,
    val version: String,
    val state: String,
    val routeIds: List<String>,
    val querySeeds: List<String>,
    val requiredBridgeGates: List<String>,
    val comparatorTargets: List<String>,
    val contradictionTargets: List<String>,
    val safetyLine: String,
    val claimLimit: String = GTIMGeneralMicrobiomeImmuneBridgeV2732.CLAIM_LIMIT
) {
    companion object {
        fun empty() = GTIMGeneralMicrobiomeBridgePlanV2732(
            active = false,
            version = GTIMGeneralMicrobiomeImmuneBridgeV2732.VERSION,
            state = "MICROBIOME_BRIDGE_NOT_OPENED",
            routeIds = emptyList(),
            querySeeds = emptyList(),
            requiredBridgeGates = GTIMGeneralMicrobiomeImmuneBridgeV2732.requiredBridgeGates,
            comparatorTargets = emptyList(),
            contradictionTargets = emptyList(),
            safetyLine = GTIMGeneralMicrobiomeImmuneBridgeV2732.safetyLine()
        )
    }
}

object GTIMGeneralMicrobiomeImmuneBridgeV2732 {
    const val VERSION: String = "2.7.3.8-general-microbiome-bridge-executable"
    const val RELEASE_COMPAT_VERSION: String = "2.7.3-final-proof-benchmark-learning-locked"
    const val CLAIM_LIMIT: String = "route_learning_only_not_evidence_not_diagnosis_not_treatment_not_exposure_attribution"

    val routeIds: List<String> = listOf(
        "microbiome_molecule_immune_phenotype_bridge_route",
        "microbiome_environment_drug_food_immune_modulation_route"
    )

    val requiredBridgeGates: List<String> = listOf(
        "microbe_or_community_feature",
        "molecule_metabolite_barrier_hormone_or_cytokine_mediator",
        "immune_mediator_or_host_response",
        "phenotype_or_outcome_label",
        "case_control_or_exposure_comparator",
        "microbiome_metabolomics_or_host_response_accession",
        "contradiction_or_negative_control_search"
    )

    private val microbiomeTerms = listOf(
        "microbiome", "microbiota", "gut bacteria", "gut-brain", "gut brain", "dysbiosis", "resistome"
    )
    private val bridgeTerms = listOf(
        "metabolite", "tryptophan", "kynurenine", "scfa", "short-chain fatty acid", "butyrate",
        "bile acid", "lps", "endotoxin", "intestinal permeability", "gut barrier", "barrier"
    )
    private val exposureTerms = listOf(
        "pesticide", "glyphosate", "heavy metal", "lead exposure", "blood lead", "lead poisoning", "arsenic", "cadmium", "mercury",
        "microplastic", "microplastics", "plastic", "bpa", "pfas", "phthalate", "livestock antibiotic",
        "poultry antibiotic", "antibiotic residue"
    )
    private val immuneTerms = listOf("il-6", "il6", "tnf", "crp", "interferon", "ifn", "th17", "inflammasome")
    private val phenotypeTerms = listOf(
        "depression", "anxiety", "neuroinflammation", "inflammation", "autoimmune", "immune dysregulation",
        "gut inflammation", "endocrine immune", "phenotype"
    )

    fun isMicrobiomeBridgeTopic(text: String): Boolean {
        val normalized = text.lowercase()
        return (microbiomeTerms + bridgeTerms + exposureTerms).any { normalized.contains(it) }
    }

    fun build(text: String): GTIMGeneralMicrobiomeBridgePlanV2732 {
        if (!isMicrobiomeBridgeTopic(text)) return GTIMGeneralMicrobiomeBridgePlanV2732.empty()
        return GTIMGeneralMicrobiomeBridgePlanV2732(
            active = true,
            version = VERSION,
            state = "GENERAL_MICROBIOME_IMMUNE_BRIDGE_OPENED_LOOKUP_ONLY",
            routeIds = routeIds,
            querySeeds = querySeedsForText(text),
            requiredBridgeGates = requiredBridgeGates,
            comparatorTargets = listOf(
                "case-control or exposed/unexposed comparator",
                "microbiome/metabolomics comparator",
                "cytokine/immune mediator comparator",
                "phenotype or outcome label"
            ),
            contradictionTargets = listOf(
                "no association",
                "null result",
                "failed replication",
                "confounding by diet/medication/geography",
                "species or model mismatch"
            ),
            safetyLine = safetyLine()
        )
    }

    fun querySeedsForText(text: String): List<String> {
        if (!isMicrobiomeBridgeTopic(text)) return emptyList()
        val normalized = text.lowercase()
        val topicAnchor = when {
            normalized.contains("depression") -> "depression IL-6 gut-brain axis"
            normalized.contains("anxiety") -> "anxiety tryptophan kynurenine gut-brain axis"
            normalized.contains("pesticide") || normalized.contains("glyphosate") -> "pesticide gut barrier inflammation"
            normalized.contains("livestock") || normalized.contains("resistome") || normalized.contains("antibiotic") -> "livestock antibiotics resistome immune dysregulation"
            normalized.contains("microplastic") || normalized.contains("pfas") || normalized.contains("bpa") || normalized.contains("phthalate") -> "microplastics PFAS BPA endocrine immune inflammation"
            normalized.contains("heavy metal") || normalized.contains("lead exposure") || normalized.contains("blood lead") || normalized.contains("lead poisoning") || normalized.contains("arsenic") || normalized.contains("cadmium") || normalized.contains("mercury") -> "heavy metals water inflammation microbiome"
            else -> "microbiome metabolite immune mediator phenotype"
        }
        return listOf(
            "$topicAnchor microbiome metabolomics cytokine IL-6 TNF CRP comparator data availability PMID DOI GSE PRJNA",
            "$topicAnchor microbial metabolite immune mediator phenotype human cohort OpenAlex Europe PMC",
            "$topicAnchor no association null result failed replication contradiction comparator",
            "$topicAnchor microbiome metagenomics metabolomics RNA-seq PBMC tissue case control dataset"
        ).distinct()
    }

    fun safetyLine(): String =
        "Microbiome bridge routes are lookup/learning routes only: require mediator + comparator + accession + contradiction gates; no causality, diagnosis, treatment or exposure attribution."
}
