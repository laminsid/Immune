package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.7.4.1 Topic Isolation + Score Cap Gate.
 *
 * Purpose: each user-triggered search must stay anchored to the raw topic the user typed.
 * Prior reports, generic route names, known-prior seed packs, and words such as "research lead"
 * must not silently dominate the next brief. This is a routing/reporting safety layer only;
 * it does not make biological claims or upgrade evidence.
 */
object TopicIsolationAndScoreGateV2741 {
    const val VERSION: String = "2.7.4.1-topic-isolation-score-gate"
    const val CLAIM_LIMIT: String = "topic_isolation_and_score_capping_not_biological_proof"

    fun searchRouteContext(snapshot: ResearchTopicCaptureSnapshotV2740?, fallbackContext: String): String {
        if (snapshot == null || snapshot.normalizedTopic.isBlank()) return fallbackContext
        val intent = correctedIntent(snapshot)
        return listOf(
            "USER_TOPIC=${snapshot.normalizedTopic}",
            "RAW_QUERY=${snapshot.rawInput}",
            "DISEASE_PHENOTYPE=${intent.diseasePhenotype.joinToString(";")}",
            "TRIGGER_EXPOSURE=${intent.triggerExposure.joinToString(";")}",
            "PATHWAY_MEDIATOR=${intent.pathway.joinToString(";")}",
            "COMPARATOR=${intent.comparatorWanted.joinToString(";")}",
            "ASSAY=${intent.assayType.joinToString(";")}",
            "BOUNDARY=ignore previous-topic templates unless explicitly supported by the current raw query"
        ).joinToString(" | ")
    }

    fun annotate(report: JSONObject, snapshot: ResearchTopicCaptureSnapshotV2740?): JSONObject {
        val gate = evaluate(report, snapshot)
        report.put("topicIsolationAndScoreGate", gate)
        val topicCapture = report.optJSONObject("topicCapture") ?: JSONObject()
        if (snapshot != null) {
            topicCapture.put("correctedIntent", intentToJson(correctedIntent(snapshot)))
            topicCapture.put("topicIsolationState", gate.optString("state"))
            topicCapture.put("topicFitScore", gate.optInt("topicFitScore"))
            topicCapture.put("claimLimit", CLAIM_LIMIT)
            report.put("topicCapture", topicCapture)
        }
        return report
    }

    fun evaluate(report: JSONObject, snapshot: ResearchTopicCaptureSnapshotV2740?): JSONObject {
        if (snapshot == null || snapshot.normalizedTopic.isBlank()) {
            return JSONObject()
                .put("active", false)
                .put("version", VERSION)
                .put("state", "NO_USER_TOPIC")
                .put("claimLimit", CLAIM_LIMIT)
        }
        val intent = correctedIntent(snapshot)
        val rawLower = snapshot.normalizedTopic.lowercase(Locale.US)
        val reportText = flattenReportText(report).lowercase(Locale.US)
        val expectedTerms = expectedTermsFor(snapshot, intent)
        val matchedTerms = expectedTerms.filter { termMatches(reportText, it) }
        val topicFit = if (expectedTerms.isEmpty()) 35 else ((matchedTerms.size.toDouble() / expectedTerms.size.toDouble()) * 100.0).toInt().coerceIn(0, 100)
        val contaminating = contaminatingSignals(rawLower, reportText)
        val templateFallback = detectsTemplateFallback(rawLower, reportText, contaminating)
        val evidenceWeaknesses = evidenceWeaknesses(reportText)
        val state = when {
            templateFallback || contaminating.size >= 3 -> "WARN_TOPIC_CONTAMINATION_OR_TEMPLATE_FALLBACK"
            topicFit < 45 -> "WARN_WEAK_TOPIC_FIT"
            evidenceWeaknesses.isNotEmpty() -> "PASS_TOPIC_ANCHORED_EVIDENCE_CAPPED"
            else -> "PASS_TOPIC_ANCHORED"
        }
        val adjusted = adjustedScores(report, topicFit, contaminating, templateFallback, evidenceWeaknesses)
        return JSONObject()
            .put("active", true)
            .put("version", VERSION)
            .put("state", state)
            .put("rawQuery", snapshot.normalizedTopic)
            .put("safeIntentLine", safeIntentLine(intent))
            .put("topicSafeRoute", topicSafeRoute(snapshot, intent))
            .put("topicSafeQuery", topicSafeQuery(snapshot, intent))
            .put("topicFitScore", topicFit)
            .put("expectedTerms", JSONArray(expectedTerms))
            .put("matchedTerms", JSONArray(matchedTerms))
            .put("contaminatingSignals", JSONArray(contaminating))
            .put("templateFallbackDetected", templateFallback)
            .put("evidenceWeaknesses", JSONArray(evidenceWeaknesses))
            .put("adjustedScores", adjusted)
            .put("routingInstruction", "current raw query dominates; prior templates and generic seeds may support retrieval only, not topic identity or evidence upgrade")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun safeIntentLineFromGate(report: JSONObject): String {
        return report.optJSONObject("topicIsolationAndScoreGate")?.optString("safeIntentLine").orEmpty()
    }

    fun shouldSuppressFallbackRelationship(report: JSONObject): Boolean {
        val gate = report.optJSONObject("topicIsolationAndScoreGate") ?: return false
        return gate.optBoolean("templateFallbackDetected", false) || gate.optInt("topicFitScore", 100) < 45
    }

    private fun correctedIntent(snapshot: ResearchTopicCaptureSnapshotV2740): GTIMResearchIntentObjectV255 {
        return GTIMResearchIntentParserV255.parse(snapshot.normalizedTopic)
    }

    private fun intentToJson(intent: GTIMResearchIntentObjectV255): JSONObject = JSONObject()
        .put("parserVersion", intent.parserVersion)
        .put("sourceText", intent.sourceText)
        .put("diseasePhenotype", JSONArray(intent.diseasePhenotype))
        .put("triggerExposure", JSONArray(intent.triggerExposure))
        .put("pathway", JSONArray(intent.pathway))
        .put("cellTissue", JSONArray(intent.cellTissue))
        .put("assayType", JSONArray(intent.assayType))
        .put("comparatorWanted", JSONArray(intent.comparatorWanted))
        .put("intentCompletenessScore", intent.intentCompletenessScore)
        .put("routeConstructionScore", intent.routeConstructionScore)
        .put("queryReadinessScore", intent.queryReadinessScore)
        .put("missingIntentFields", JSONArray(intent.missingIntentFields))
        .put("claimBoundary", intent.claimBoundary)

    private fun safeIntentLine(intent: GTIMResearchIntentObjectV255): String = listOf(
        "Trigger: ${intent.triggerExposure.joinToString(", ").ifBlank { "not specified" }}",
        "Disease / phenotype: ${intent.diseasePhenotype.joinToString(", ").ifBlank { "not specified" }}",
        "Pathway: ${intent.pathway.joinToString(", ").ifBlank { "not specified" }}",
        "Cell / tissue: ${intent.cellTissue.joinToString(", ").ifBlank { "not specified" }}",
        "Comparator: ${intent.comparatorWanted.joinToString(", ").ifBlank { "not specified" }}",
        "Assay: ${intent.assayType.joinToString(", ").ifBlank { "not specified" }}",
        "Repositories: ${intent.repositoryTargets.take(6).joinToString(", ")}",
        "Output mode: ${intent.outputMode}"
    ).joinToString(" | ")

    private fun topicSafeRoute(snapshot: ResearchTopicCaptureSnapshotV2740, intent: GTIMResearchIntentObjectV255): String {
        val disease = intent.diseasePhenotype.firstOrNull().orEmpty().ifBlank { snapshot.normalizedTopic }
        val trigger = intent.triggerExposure.firstOrNull().orEmpty().ifBlank { "current user topic" }
        val pathway = intent.pathway.take(3).joinToString("/").ifBlank { "immune mediator to resolve" }
        return "current-topic route: $trigger -> $pathway -> $disease; prior templates retrieval-only"
    }

    private fun topicSafeQuery(snapshot: ResearchTopicCaptureSnapshotV2740, intent: GTIMResearchIntentObjectV255): String {
        val parts = mutableListOf(snapshot.normalizedTopic)
        parts += intent.diseasePhenotype.take(3)
        parts += intent.triggerExposure.take(3)
        parts += intent.pathway.take(4)
        if (parts.none { it.contains("dataset", ignoreCase = true) }) parts += listOf("GSE", "PRJNA", "PMID", "data availability", "comparator")
        return parts.filter { it.isNotBlank() }.distinctBy { it.lowercase(Locale.US) }.joinToString(" ")
    }

    private fun expectedTermsFor(snapshot: ResearchTopicCaptureSnapshotV2740, intent: GTIMResearchIntentObjectV255): List<String> {
        val raw = snapshot.normalizedTopic.lowercase(Locale.US)
        val terms = mutableListOf<String>()
        terms += raw.split(Regex("[^a-z0-9+/-]+"))
            .map { it.trim('+', '/', '-') }
            .filter { it.length >= 4 && it !in setOf("with", "from", "immune", "system") }
        terms += intent.diseasePhenotype.flatMap { simpleTerms(it) }
        terms += intent.triggerExposure.flatMap { simpleTerms(it) }
        terms += intent.pathway.flatMap { simpleTerms(it) }
        if (raw.contains("depression")) terms += listOf("depression", "mood", "neuroimmune", "il-6", "tnf", "kynurenine", "tryptophan", "microbiome", "bacteria")
        if (raw.contains("bacteria")) terms += listOf("bacteria", "microbiome", "metabolite", "gut")
        if (raw.contains("longevity") || raw.contains("aging") || raw.contains("ageing")) terms += listOf("longevity", "aging", "immunosenescence", "inflammaging", "senescence")
        if (raw.contains("covid") || raw.contains("sars")) terms += listOf("covid", "sars-cov-2", "interferon", "pasc", "long covid")
        if (raw.contains("allergy")) terms += listOf("allergy", "ige", "mast", "eosinophil", "type 2")
        return terms.map { normalizeToken(it) }
            .filter { it.length >= 3 }
            .distinct()
            .take(32)
    }

    private fun simpleTerms(text: String): List<String> = text.lowercase(Locale.US)
        .split(Regex("[^a-z0-9+/-]+"))
        .map { normalizeToken(it) }
        .filter { it.length >= 3 }

    private fun normalizeToken(value: String): String = value.trim().lowercase(Locale.US)
        .replace("sars cov 2", "sars-cov-2")
        .replace("long covid / pasc", "long covid")
        .trim('/', '-', '+')

    private fun termMatches(text: String, term: String): Boolean {
        val escaped = Regex.escape(term)
        return if (term.contains(' ') || term.contains('-')) text.contains(term) else Regex("(?<![a-z0-9])$escaped(?![a-z0-9])").containsMatchIn(text)
    }

    private fun contaminatingSignals(rawLower: String, reportText: String): List<String> {
        val signals = mutableListOf<String>()
        fun rawLacks(vararg needles: String): Boolean = needles.none { rawLower.contains(it) }
        if (reportText.contains("water heavy-metal immune axis") && rawLacks("heavy metal", "lead exposure", "mercury", "arsenic", "cadmium", "water")) {
            signals += "HEAVY_METAL_FALSE_FRIEND_OR_PRIOR_TEMPLATE"
        }
        if (reportText.contains("disease / phenotype: allergy") && rawLacks("allergy", "allergic", "ige", "mast")) {
            signals += "ALLERGY_PRIOR_TEMPLATE_IN_NON_ALLERGY_TOPIC"
        }
        if ((reportText.contains("pesticide_gut_barrier") || reportText.contains("pesticides_gut_immunity")) && rawLacks("pesticide", "glyphosate", "organophosphate")) {
            signals += "PESTICIDE_ROUTE_DOMINATES_UNREQUESTED_TOPIC"
        }
        if ((reportText.contains("plastic_pfas") || reportText.contains("pfas/bpa") || reportText.contains("phthalate")) && rawLacks("plastic", "pfas", "bpa", "phthalate", "microplastic")) {
            signals += "PLASTIC_PFAS_ROUTE_DOMINATES_UNREQUESTED_TOPIC"
        }
        if (reportText.contains("topic=long_covid_interferon") && rawLacks("covid", "sars", "pasc", "interferon")) {
            signals += "BENCHMARK_TOPIC_MISMATCH_LONG_COVID"
        }
        return signals.distinct()
    }

    private fun detectsTemplateFallback(rawLower: String, reportText: String, contaminating: List<String>): Boolean {
        val sameSeedPack = reportText.contains("pmid:22114171") && reportText.contains("10.1126/science.1211719") && reportText.contains("gse117882")
        val rawSpecific = rawLower.contains("depression") || rawLower.contains("longevity") || rawLower.contains("covid") || rawLower.contains("bacteria")
        return contaminating.size >= 2 || (rawSpecific && sameSeedPack && contaminating.isNotEmpty())
    }

    private fun evidenceWeaknesses(reportText: String): List<String> {
        val out = mutableListOf<String>()
        if (reportText.contains("dge_not_ready") || reportText.contains("metadata_gap")) out += "MATRIX_OR_METADATA_NOT_READY"
        if (reportText.contains("lookup-only") || reportText.contains("not evidence")) out += "LOOKUP_ONLY_NOT_EVIDENCE"
        if (reportText.contains("route_unresolved_metadata_pending")) out += "ROUTE_METADATA_PENDING"
        if (reportText.contains("comparator: not specified")) out += "COMPARATOR_MISSING"
        if (reportText.contains("assay: not specified")) out += "ASSAY_MISSING"
        if (reportText.contains("cell / tissue: not specified")) out += "CELL_TISSUE_MISSING"
        return out.distinct()
    }

    private fun adjustedScores(
        report: JSONObject,
        topicFit: Int,
        contaminating: List<String>,
        templateFallback: Boolean,
        evidenceWeaknesses: List<String>
    ): JSONObject {
        val score = report.optJSONObject("datasetForagingReport")?.optJSONObject("scoreSeparation") ?: report.optJSONObject("score") ?: JSONObject()
        val mechanism = report.optJSONObject("datasetForagingReport")?.optJSONObject("mechanismDiscoveryDossierReport") ?: JSONObject()
        val gtim = mechanism.optJSONObject("globalTranslationalDossier") ?: JSONObject()
        val intent = gtim.optJSONObject("researchIntent") ?: JSONObject()
        val split = gtim.optJSONObject("discoveryEvidenceSplit") ?: JSONObject()
        val three = split.optJSONObject("threeDimensionalScore") ?: JSONObject()
        val confidence = gtim.optJSONArray("mechanismCandidates")?.optJSONObject(0)?.optJSONObject("confidenceIndex") ?: JSONObject()
        val rawIntent = intent.optInt("intentCompletenessScore", 0)
        val rawRoute = maxOf(score.optInt("routeFitScore", 0), intent.optInt("routeConstructionScore", 0), three.optInt("biologicalPlausibilityScore", 0))
        val rawDiscovery = maxOf(score.optInt("hypothesisConfidenceScore", 0), three.optInt("discoveryValueScore", 0))
        val rawEvidence = maxOf(confidence.optInt("score", 0), three.optInt("evidenceConfidenceScore", 0))
        var routeCap = 100
        var discoveryCap = 100
        var evidenceCap = 100
        var dataQualityCap = 100
        var noveltyCap = 100
        var plausibilityCap = 100
        if (topicFit < 45 || templateFallback || contaminating.isNotEmpty()) {
            routeCap = minOf(routeCap, 45)
            discoveryCap = minOf(discoveryCap, 35)
            evidenceCap = minOf(evidenceCap, 25)
            dataQualityCap = minOf(dataQualityCap, 40)
            noveltyCap = minOf(noveltyCap, 35)
            plausibilityCap = minOf(plausibilityCap, 45)
        }
        if (evidenceWeaknesses.contains("MATRIX_OR_METADATA_NOT_READY")) {
            evidenceCap = minOf(evidenceCap, 40)
            dataQualityCap = minOf(dataQualityCap, 50)
        }
        if (evidenceWeaknesses.contains("LOOKUP_ONLY_NOT_EVIDENCE")) evidenceCap = minOf(evidenceCap, 35)
        if (evidenceWeaknesses.contains("COMPARATOR_MISSING")) evidenceCap = minOf(evidenceCap, 45)
        if (evidenceWeaknesses.contains("ASSAY_MISSING") || evidenceWeaknesses.contains("CELL_TISSUE_MISSING")) dataQualityCap = minOf(dataQualityCap, 55)
        return JSONObject()
            .put("intentScore", rawIntent.coerceIn(0, 100))
            .put("routeScore", rawRoute.coerceAtMost(routeCap).coerceIn(0, 100))
            .put("discoveryScore", rawDiscovery.coerceAtMost(discoveryCap).coerceIn(0, 100))
            .put("evidenceScore", rawEvidence.coerceAtMost(evidenceCap).coerceIn(0, 100))
            .put("dataQualityScore", three.optInt("dataQualityScore", 0).coerceAtMost(dataQualityCap).coerceIn(0, 100))
            .put("noveltyScore", three.optInt("noveltyScore", 0).coerceAtMost(noveltyCap).coerceIn(0, 100))
            .put("biologicalPlausibilityScore", three.optInt("biologicalPlausibilityScore", 0).coerceAtMost(plausibilityCap).coerceIn(0, 100))
            .put("routeCap", routeCap)
            .put("discoveryCap", discoveryCap)
            .put("evidenceCap", evidenceCap)
            .put("dataQualityCap", dataQualityCap)
            .put("capReason", listOf(contaminating.joinToString(";"), evidenceWeaknesses.joinToString(";"))
                .filter { it.isNotBlank() }.joinToString(" | ").ifBlank { "no cap beyond raw evidence gates" })
    }

    private fun flattenReportText(value: Any?, limit: Int = 24000): String {
        val out = StringBuilder()
        fun walk(v: Any?, depth: Int) {
            if (out.length >= limit || depth > 6 || v == null || v == JSONObject.NULL) return
            when (v) {
                is JSONObject -> {
                    val keys = v.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        out.append(' ').append(key)
                        walk(v.opt(key), depth + 1)
                        if (out.length >= limit) return
                    }
                }
                is JSONArray -> {
                    for (i in 0 until v.length()) {
                        walk(v.opt(i), depth + 1)
                        if (out.length >= limit) return
                    }
                }
                else -> out.append(' ').append(v.toString())
            }
        }
        walk(value, 0)
        return out.toString().take(limit)
    }
}
