package com.immunesignal.app

import java.util.Locale

/**
 * v2.7.4.2 Topic Run Isolation Policy.
 *
 * This layer prevents cross-run memory/template contamination. It is deliberately
 * conservative: previous reports may support learning only when they visibly
 * overlap the current raw query. Otherwise, the current user topic owns the
 * steering profile and the first executed queries.
 */
object TopicRunIsolationPolicyV2742 {
    const val VERSION: String = "2.7.4.2-topic-run-isolation-policy"
    const val CLAIM_LIMIT: String = "topic_run_isolation_not_biological_proof"

    fun chooseSteering(
        snapshot: ResearchTopicCaptureSnapshotV2740?,
        stored: ResearchSteeringProfile?
    ): ResearchSteeringProfile? {
        val snapshotSteering = RuntimeCrashSafetyAndTopicGuardV2740.fallbackSteering(snapshot)
        return snapshotSteering ?: stored
    }

    fun scopedRecentReports(
        reports: List<String>,
        snapshot: ResearchTopicCaptureSnapshotV2740?,
        maxReports: Int = 8
    ): List<String> {
        val topic = snapshot?.normalizedTopic.orEmpty()
        if (topic.isBlank()) return reports
        val terms = topicTerms(snapshot)
        if (terms.isEmpty()) return emptyList()
        return reports
            .filter { report ->
                val lower = report.lowercase(Locale.US)
                val overlap = terms.count { term -> lower.contains(term) }
                val contaminated = hasUnrequestedContamination(lower, topic.lowercase(Locale.US))
                overlap >= minOf(2, terms.size) && !contaminated
            }
            .take(maxReports)
    }

    fun scopedImportedRawTexts(
        texts: List<String>,
        snapshot: ResearchTopicCaptureSnapshotV2740?,
        maxTexts: Int = 6
    ): List<String> {
        val topic = snapshot?.normalizedTopic.orEmpty()
        if (topic.isBlank()) return texts
        val terms = topicTerms(snapshot)
        if (terms.isEmpty()) return emptyList()
        return texts
            .filter { text ->
                val lower = text.lowercase(Locale.US)
                terms.any { lower.contains(it) } && !hasUnrequestedContamination(lower, topic.lowercase(Locale.US))
            }
            .take(maxTexts)
    }

    fun scopedImportedSignals(
        signals: List<ImportedReportSignal>,
        snapshot: ResearchTopicCaptureSnapshotV2740?,
        maxSignals: Int = 8
    ): List<ImportedReportSignal> {
        val topic = snapshot?.normalizedTopic.orEmpty()
        if (topic.isBlank()) return signals
        val terms = topicTerms(snapshot)
        if (terms.isEmpty()) return emptyList()
        return signals
            .filter { signal ->
                val lower = listOf(signal.title, signal.preview, signal.extractedKeywords.joinToString(" "))
                    .joinToString(" ")
                    .lowercase(Locale.US)
                terms.any { lower.contains(it) } && !hasUnrequestedContamination(lower, topic.lowercase(Locale.US))
            }
            .take(maxSignals)
    }

    fun topicFirstQueries(snapshot: ResearchTopicCaptureSnapshotV2740?, maxQueries: Int = 3): List<ResearchQuery> {
        val topic = snapshot?.normalizedTopic.orEmpty().trim()
        if (topic.isBlank()) return emptyList()
        val intent = GTIMResearchIntentParserV255.parse(topic)
        val base = mutableListOf<String>()
        base += buildList {
            add(topic)
            addAll(intent.diseasePhenotype.take(2))
            addAll(intent.triggerExposure.take(2))
            addAll(intent.pathway.take(3))
            add("human")
            add("immune")
            add("comparator")
            add("GSE OR PRJNA OR PMID")
        }.joinToString(" ")
        base += buildList {
            add(topic)
            addAll(intent.diseasePhenotype.take(2))
            add("transcriptome OR cytokine OR biomarker")
            add("healthy controls OR case control")
            add("data availability")
        }.joinToString(" ")
        if (topic.contains("bacteria", true) || topic.contains("microbiome", true) || topic.contains("depression", true)) {
            base += "$topic microbiome tryptophan kynurenine IL-6 TNF depression human cohort dataset"
        }
        if (topic.contains("longevity", true) || topic.contains("aging", true) || topic.contains("ageing", true)) {
            base += "$topic immunosenescence inflammaging senescence IL-6 CRP human cohort dataset"
        }
        if (topic.contains("covid", true) || topic.contains("sars", true)) {
            base += "$topic SARS-CoV-2 interferon Long COVID PBMC RNA-seq comparator GSE"
        }
        return base
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotBlank() }
            .distinctBy { it.lowercase(Locale.US) }
            .take(maxQueries)
            .mapIndexed { index, query ->
                ResearchQuery(
                    id = "q_v2742_topic_first_$index",
                    label = "v2.7.4.2 current-topic first query",
                    query = query,
                    reason = "Current user topic is executed before prior-memory, template, microbiome, or relationship expansion. Claim limit: $CLAIM_LIMIT."
                )
            }
    }

    fun filterQueriesForCurrentTopic(
        queries: List<ResearchQuery>,
        snapshot: ResearchTopicCaptureSnapshotV2740?,
        maxQueries: Int = queries.size.coerceAtLeast(1)
    ): List<ResearchQuery> {
        val topic = snapshot?.normalizedTopic.orEmpty()
        if (topic.isBlank()) return queries.take(maxQueries)
        val topicLower = topic.lowercase(Locale.US)
        val terms = topicTerms(snapshot)
        val topicFirst = topicFirstQueries(snapshot, maxQueries = 3)
        val kept = queries.filter { query ->
            val text = listOf(query.query, query.label, query.reason).joinToString(" ").lowercase(Locale.US)
            val overlapsTopic = terms.any { text.contains(it) }
            val contaminated = hasUnrequestedContamination(text, topicLower)
            overlapsTopic && !contaminated
        }
        return (topicFirst + kept)
            .distinctBy { it.query.lowercase(Locale.US) }
            .take(maxQueries.coerceAtLeast(topicFirst.size.coerceAtLeast(1)))
    }

    fun isolationTrace(
        snapshot: ResearchTopicCaptureSnapshotV2740?,
        storedReports: Int,
        scopedReports: Int,
        originalQueries: Int,
        filteredQueries: Int
    ): String {
        val topic = snapshot?.normalizedTopic.orEmpty().ifBlank { "none" }
        return "TopicRunIsolationPolicyV2742: topic=$topic; reports=$scopedReports/$storedReports; queries=$filteredQueries/$originalQueries; claim-limit=$CLAIM_LIMIT"
    }

    private fun topicTerms(snapshot: ResearchTopicCaptureSnapshotV2740?): List<String> {
        val normalized = snapshot?.normalizedTopic.orEmpty().trim()
        if (normalized.isBlank()) return emptyList()
        val raw = normalized.lowercase(Locale.US)
        val parsed = GTIMResearchIntentParserV255.parse(normalized)
        return (raw.split(Regex("[^a-z0-9+-]+")) +
            parsed.diseasePhenotype.flatMap { it.lowercase(Locale.US).split(Regex("[^a-z0-9+-]+")) } +
            parsed.triggerExposure.flatMap { it.lowercase(Locale.US).split(Regex("[^a-z0-9+-]+")) } +
            parsed.pathway.flatMap { it.lowercase(Locale.US).split(Regex("[^a-z0-9+-]+")) })
            .map { it.trim('+', '-') }
            .filter { it.length >= 4 && it !in genericStopTerms }
            .distinct()
            .take(24)
    }

    private fun hasUnrequestedContamination(textLower: String, topicLower: String): Boolean {
        fun lacks(vararg needles: String): Boolean = needles.none { topicLower.contains(it) }
        if ((textLower.contains("water heavy-metal") || textLower.contains("heavy metal") || textLower.contains("lead poisoning") || textLower.contains("blood lead")) && lacks("heavy metal", "lead exposure", "lead poisoning", "mercury", "arsenic", "cadmium", "water")) return true
        if ((textLower.contains("pesticide") || textLower.contains("glyphosate") || textLower.contains("organophosphate")) && lacks("pesticide", "glyphosate", "organophosphate")) return true
        if ((textLower.contains("pfas") || textLower.contains("bpa") || textLower.contains("phthalate") || textLower.contains("microplastic")) && lacks("pfas", "bpa", "phthalate", "microplastic", "plastic")) return true
        if (textLower.contains("disease / phenotype: allergy") && lacks("allergy", "allergic", "ige", "mast")) return true
        if (textLower.contains("topic=long_covid_interferon") && lacks("covid", "sars", "pasc", "interferon")) return true
        return false
    }

    private val genericStopTerms = setOf(
        "immune", "immunity", "system", "human", "cohort", "dataset", "data", "availability", "response", "route", "research", "lead", "leads", "with", "from", "axis", "case", "control", "controls", "comparator"
    )
}
