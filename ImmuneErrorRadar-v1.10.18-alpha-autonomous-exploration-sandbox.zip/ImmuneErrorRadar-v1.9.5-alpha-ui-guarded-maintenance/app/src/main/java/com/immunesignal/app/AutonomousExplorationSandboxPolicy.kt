package com.immunesignal.app

import java.util.Locale

/**
 * v1.10.18: Autonomous Exploration Sandbox.
 *
 * The previous dataset hunt was safe but too narrow: it could demand an almost
 * perfect dataset (neuroimmune + time + multiple axes + outcome/control) before
 * it had even found a usable accession. This sandbox deliberately broadens the
 * evidence hunt into nearby biomedical domains and drug/perturbation contexts,
 * while keeping all interpretation gates locked.
 *
 * Freedom is allowed in exploration: vocabulary mutation, adjacent-domain
 * search, drug-exposure/perturbation search, and near-miss lead capture. Freedom
 * is not allowed in claims: no diagnosis, treatment, dose, drug ranking,
 * clinical recommendation, causal upgrade, or hypothesis strengthening without
 * accession + metadata + outcome/control/time gates.
 */
object AutonomousExplorationSandboxPolicy {
    const val CLAIM_LIMIT: String = "exploration_sandbox_not_biological_proof"
    const val MODE: String = "AUTONOMOUS_EXPLORATION_SANDBOX"

    val adjacentDomains: List<String> = listOf(
        "drug_perturbation_research",
        "aging_immunosenescence_inflammaging",
        "diabetes_metabolic_inflammation",
        "gastric_acid_reflux_gut_barrier"
    )

    fun summary(): String =
        "Autonomous exploration sandbox: broaden search into drug perturbation, aging, diabetes/metabolic inflammation, and gastric-acid/reflux/gut-barrier domains; keep claims locked to research leads only."

    fun routeForSourceFamily(sourceFamily: String): DirectDatasetSourceRouter.SourceRoute? {
        val normalized = normalize(sourceFamily)
        if (normalized != "PUBMED_ADJACENT_DOMAIN_MINING") return null
        return DirectDatasetSourceRouter.SourceRoute(
            sourceFamily = "PUBMED_ADJACENT_DOMAIN_MINING",
            ncbiDb = "pubmed",
            priority = 68,
            reason = "v1.10.18 autonomous exploration sandbox: mine adjacent biomedical domains and drug/perturbation contexts for public dataset leads; research-only, no treatment or drug-ranking claim."
        )
    }

    fun queriesForRoute(
        route: DirectDatasetSourceRouter.SourceRoute,
        memory: PersistentFailureMemorySnapshot
    ): List<ResearchQuery> {
        val family = normalize(route.sourceFamily)
        val baseQueries = when {
            family == "PUBMED_ADJACENT_DOMAIN_MINING" -> adjacentPubMedQueries()
            route.ncbiDb == "gds" -> adjacentDatasetQueries("GSE GEO GDS")
            route.ncbiDb == "sra" -> adjacentDatasetQueries("PRJNA PRJEB SRP SRA BioProject BioSample")
            family.contains("ACCESSION", ignoreCase = true) -> adjacentPubMedQueries().take(4)
            else -> adjacentNearMissQueries().take(2)
        }
        val memoryHint = memory.records
            .asSequence()
            .map { it.rootCause + " " + it.forcedNextSource }
            .firstOrNull { it.isNotBlank() }
            .orEmpty()
        return baseQueries.mapIndexed { idx, query ->
            ResearchQuery(
                id = "q_v11018_${family.lowercase(Locale.US)}_sandbox_$idx",
                label = "v1.10.18 exploration sandbox ${route.sourceFamily} ${idx + 1}",
                query = query,
                reason = "Exploration sandbox broadens retrieval only: adjacent domains=${adjacentDomains.joinToString(",")}; drug terms mean perturbation/exposure metadata, not treatment advice. Memory hint: ${memoryHint.ifBlank { "none" }}. Claim limit: $CLAIM_LIMIT."
            )
        }
    }

    fun nearMissStatus(hasAccession: Boolean, usabilityScore: Int): String = when {
        hasAccession && usabilityScore >= 45 -> "ACCESSION_FOUND_METADATA_WEAK"
        hasAccession -> "NEAR_MISS_DATASET_CANDIDATE"
        usabilityScore >= 35 -> "PARTIAL_AXIS_MATCH_NEEDS_ACCESSION"
        else -> "EXPLORATORY_LEAD_NEEDS_ACCESSION"
    }

    fun safetyGuards(): List<String> = listOf(
        "drug terms are research perturbation/exposure context only",
        "no treatment, dose, drug ranking, or clinical recommendation",
        "adjacent-domain leads cannot upgrade hypotheses without accession and metadata closure",
        "near-miss candidates are retained for inspection but remain non-evidence"
    )

    private fun adjacentDatasetQueries(prefix: String): List<String> = listOf(
        "$prefix human immune transcriptome severity recovery outcome aging diabetes drug perturbation reflux gut barrier accession metadata",
        "$prefix human RNA-seq single-cell immune response medication exposure inflammaging metabolic inflammation gastric acid phenotype labels",
        "$prefix patient cohort immune response responder nonresponder longitudinal control diabetes aging gut reflux pharmacologic challenge"
    )

    private fun adjacentPubMedQueries(): List<String> = listOf(
        "GSE OR PRJNA OR SRP OR E-MTAB human immune transcriptome drug perturbation medication exposure outcome severity recovery dataset accession",
        "GSE OR GEO human aging immunosenescence inflammaging immune response transcriptomic outcome severity recovery longitudinal dataset",
        "PRJNA OR SRP human diabetes metabolic inflammation immune transcriptome responder nonresponder severity recovery control dataset",
        "GSE OR E-MTAB human gastric acid reflux GERD gut barrier microbiome immune inflammation transcriptome outcome dataset",
        "public dataset human pharmacologic challenge immune response RNA-seq single-cell control comparator phenotype metadata accession"
    )

    private fun adjacentNearMissQueries(): List<String> = listOf(
        "human immune response transcriptome aging diabetes reflux medication exposure outcome severity recovery control dataset",
        "human pharmacologic perturbation immune gene expression cohort phenotype recovery responder nonresponder public data"
    )

    private fun normalize(value: String): String = value.trim().uppercase(Locale.US)
}
