# GTIM Research Intent Parser v2.5.5

## Purpose
Turn structured or free-text biomedical research questions into a ResearchIntentObject.

## Parsed fields
- diseasePhenotype
- triggerExposure
- pathway
- cellTissue
- assayType
- repositoryTargets
- comparatorWanted
- speciesPriority
- outputMode
- claimStrictness
- contradictionRequirement
- labValidationRequirement

## Output requirement
Final reports must show Parsed Research Intent and must not show Engine: unknown / Lock: UNKNOWN / State: UNKNOWN.
