# GTIM Final Integration Closure v2.6.0

GTIM v2.6.0 closes the accession-seed loop: if a user supplies a real repository handle such as GSE152202, the system must capture it as an accession seed and keep discovery alive while evidence upgrade remains gated.

## Required behavior

- No `Engine: unknown`, `Lock: UNKNOWN`, or `State: UNKNOWN` in the main brief.
- No `GTIM_OPEN_DISCOVERY_DATAFEED_NOT_VISIBLE` fallback when an accession seed is present.
- `GSE/PRJNA/SRP/SDY/E-MTAB` seeds become visible in `accessionSeedCapture`.
- Captured seeds use `ACCESSION_SEED_CAPTURED_MATRIX_PENDING` and `ROUTE_UNRESOLVED_METADATA_PENDING`.
- Captured seeds are not biological proof and do not create DGE, fold-change, p-value, diagnosis, treatment, or patient prediction.

## unknown runtime fallbacks

Unknown runtime fallbacks are sanitized to the current GTIM engine identity and PASS lock where appropriate, while the technical appendix keeps raw debug details.
