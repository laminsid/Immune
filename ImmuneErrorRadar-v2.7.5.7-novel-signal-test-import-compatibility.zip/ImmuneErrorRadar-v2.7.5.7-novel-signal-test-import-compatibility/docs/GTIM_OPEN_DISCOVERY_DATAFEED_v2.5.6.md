# GTIM Open Discovery DataFeed v2.5.6

## What was relaxed
Weak research leads, source metadata, repository handles, candidate routes, data-feed query plans, and lab-protocol drafts remain visible.

## Data-feed channels
GEO, SRA, ArrayExpress, BioProject, ImmPort, PubMed Data Availability, and Manual PMID/DOI/PDF/snippet seed.

## What remains locked
DGE/fold-change/p-value, matrix claims, confirmed human mechanism claims, clinical advice, hidden background scraping, and patient-data upload.
