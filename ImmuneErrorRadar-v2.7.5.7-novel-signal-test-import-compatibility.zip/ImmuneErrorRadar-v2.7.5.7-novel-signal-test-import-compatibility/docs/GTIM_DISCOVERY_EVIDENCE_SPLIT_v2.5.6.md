# GTIM Discovery / Evidence Split v2.5.6

## Principle
Discovery is flexible; evidence upgrade is strict; clinical claims are forbidden.

## New layers
- Three-dimensional grading: Data Quality, Novelty, Biological Plausibility
- Semantic Mechanism Prior: SEMANTIC_PRIOR_NOT_MATRIX
- Active Contradiction Engine
- Preliminary Lab Protocol Draft: LAB_PROTOCOL_DRAFT_NOT_VALIDATION
- Candidate Routes: EXPLORATORY_ROUTE_NOT_EVIDENCE

## Locked claims
No diagnosis, treatment, patient prediction, DGE, fold-change, p-value, causal claim, or confirmed discovery from weak leads.
