# GTIM Unified Relaxed Exploration v2.5.6

## What was relaxed
The report no longer collapses rich research questions to absolute zero when accession/matrix evidence is absent.

## What remains locked
Candidate route ≠ evidence object. Semantic prior ≠ matrix. Lab draft ≠ validation. Discovery ≠ clinical claim.
