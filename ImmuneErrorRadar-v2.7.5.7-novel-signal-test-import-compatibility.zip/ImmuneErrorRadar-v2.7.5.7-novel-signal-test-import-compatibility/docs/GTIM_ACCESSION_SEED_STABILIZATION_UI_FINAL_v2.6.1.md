# GTIM Accession Seed Stabilization + UI Final v2.6.1

This patch closes the post-v2.6.0 compile/regression surface.

## Fixed
- Removed a duplicated Kotlin function return signature in `GTIMDiscoveryDossierV250.kt` that static delimiter checks did not catch.
- Added a dedicated audit to prevent duplicate Kotlin return signatures and unescaped contradiction-query string regressions.
- Unified active release labels to `2.6.1-alpha-gtim-accession-seed-stabilization-ui-final`.
- Preserved the v2.6 accession-seed loop breaker: GSE/PRJNA/SRP/SRR/E-MTAB/SDY inputs must become captured accession seeds, not manual snippets.

## Product surface
- Main brief stays compact and researcher-facing.
- Technical trace, raw JSON, parser cards, and module internals remain in advanced export.
- Captured accession seeds are visible in the main brief without turning into evidence claims.

## Guardrails
- No diagnosis, treatment, dose, patient prediction, DGE/fold-change/p-value, or confirmed mechanism claim without accession/comparator/matrix/metadata/contradiction closure.
- No hidden background scraping, patient upload, tracking, or broad sensitive permissions.
