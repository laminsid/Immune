# GTIM Safe Launch UI Stability v2.6.3

Purpose: guarantee that the launcher opens even if XML layout/drawable polish regresses.

Changes:
- MainActivity no longer inflates the large launcher XML surface.
- The launcher is built programmatically with stable Android framework widgets.
- The first screen exposes only two safe actions: Start GTIM Research and Open Saved Reports.
- Research and history screens remain unchanged.
- No new permissions, no background scraping, no clinical claim surface.

Acceptance:
- MainActivity must not call setContentView(R.layout.activity_main).
- MainActivity must expose buildStableLauncher().
- Launcher must not depend on decorative drawables for startup.
