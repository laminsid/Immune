# GTIM v2.5.7 — Professor Dashboard Final Hardening

Version: `2.5.9-alpha-gtim-final-integration-closure`

This release completes the remaining product-surface hardening on top of v2.5.6.

## Added
- Professor-facing Discovery Dashboard
- User-triggered Public Data Resolver action plan
- Graph-ready nodes/edges for later interactive visualization
- JSON/brief/registry/audit linkage for the dashboard surface

## Non-negotiable locks
- Discovery can be flexible.
- Evidence upgrade remains strict.
- Clinical claims remain forbidden.
- Semantic priors are not expression matrices.
- Candidate routes are not evidence objects.
- Public data lookup remains user-triggered; no hidden background scraping or patient data upload.
