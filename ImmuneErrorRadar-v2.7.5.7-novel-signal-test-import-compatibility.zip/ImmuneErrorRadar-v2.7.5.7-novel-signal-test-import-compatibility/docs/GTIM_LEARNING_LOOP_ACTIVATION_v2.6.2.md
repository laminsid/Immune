# GTIM Learning Loop Activation v2.6.2

Version: `2.6.2-alpha-learning-loop-activation`

## Purpose

This release closes the learning loop described by the architecture audit: rules, domain memory, gap mining, plausibility graph edges, route fingerprints, and belief updates now feed the next-cycle research posture instead of staying as isolated reports.

## Decision rule

- Discovery = flexible.
- Evidence upgrade = strict.
- Clinical claim = forbidden.

## Implemented fixes and activations

- Prevents `NO_PIVOT` from being treated as real stagnation.
- Anti-stagnation queries run only for explicit stagnation pivots.
- STRONG_SIGNAL thresholds are unified through `ResearchPolicyLock` / `RuntimeFeatureFlags`.
- Evidence-lane rotation goes BROAD → MECHANISM before CONTRADICTION.
- Stable cycles emit `stable_no_change` rather than fake delta wording.
- Source priority no longer duplicates repaired core routes.
- Epistemic beliefs are capped with active/non-retired/high-credibility priority.
- `LearningRuleEngine` activates learning-rules as routing priors only.
- `DomainExpertiseMemoryPolicy` feeds reusable vocabulary into `DatasetQueryCompiler`.
- `RouteFingerprintGuard` blocks semantic replay from pretending to be progress.
- `KnowledgeGapTaskScheduler` converts gap-miner opportunities into query tasks.
- `DynamicPlausibilityGraphLearner` proposes new edges as `PROPOSED_EDGE_NEEDS_VALIDATION` only.
- `AxisPerformanceLearningV262` tracks axis search productivity.
- `BayesianBeliefRevisionV262` computes posterior-style belief updates as research priors only.
- `EpistemicDistanceMeterV262` measures progress beyond accession count.
- `LearningLoopActivationV262` aggregates the loop into a single next-cycle action.

## Guardrails

No diagnosis, treatment advice, dosing, patient prediction, DGE/fold-change/p-value claim, or confirmed mechanism can be produced from these learning signals.
