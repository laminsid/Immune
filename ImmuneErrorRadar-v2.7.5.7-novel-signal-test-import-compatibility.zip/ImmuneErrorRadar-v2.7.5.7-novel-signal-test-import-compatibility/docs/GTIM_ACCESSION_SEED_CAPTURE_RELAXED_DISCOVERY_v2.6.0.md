# GTIM Accession Seed Capture + Relaxed Discovery v2.6.0

## Purpose

This release breaks the repeated loop where the application asks for a seed even after the user provides a concrete repository handle such as `GSE152202`.

## Behavior

- Any real repository handle matching `GSE`, `GSM`, `GDS`, `GPL`, `PRJNA`, `SRP`, `SRR`, `E-MTAB`, `SDY`, and related patterns is captured as an accession seed.
- The main brief must show `Captured accession seed` and must not report `accessions=0` when a real seed is present.
- The route state stays `ROUTE_UNRESOLVED_METADATA_PENDING` until repository metadata is parsed.
- The evidence state stays `ACCESSION_SEED_NOT_EVIDENCE_OBJECT`.
- The next step becomes metadata/comparator/matrix closure, not another generic seed request.

## Safety boundary

Captured accession seeds are not biological proof. The system still blocks diagnosis, treatment, dose, patient prediction, causal claims, DGE, fold-change, and p-value claims until real matrix/comparator/metadata gates close.

## Google Play / GitHub posture

- User-triggered public repository lookup only.
- No hidden background scraping.
- No patient data upload.
- No tracking.
- Static audit: `audit_gtim_v260_accession_seed_capture_relaxed_discovery.py`.
