# GTIM v2.5.8 — Modular Completion

This release completes the remaining modular split above v2.5.7 without changing the claim policy.

## Completed modules
- `GTIMIntentAwareBriefRendererV255.kt`
- `GTIMThreeDimensionalScoringV256.kt`
- `GTIMSemanticMechanismPriorV256.kt`
- `GTIMActiveContradictionEngineV256.kt`
- `GTIMPreliminaryLabProtocolGeneratorV256.kt`
- `GTIMOpenDataResolverV256.kt`
- `GTIMVisualKnowledgeGraphV257.kt`

## Linked surfaces
- `GTIMDiscoveryDossierV250`
- `GTIMEvidenceModelsV250`
- `DatasetForagingJson`
- `GlobalResearchGradeBriefV11061`
- `RuntimeModuleRegistry`
- `run_static_checks_fast.sh`
- `run_static_checks_full.sh`

## Integrity locks
Discovery remains flexible. Evidence upgrade remains strict. Clinical claims remain forbidden.
Semantic priors are not expression matrices. Candidate routes are not evidence objects.
Public data lookup remains user-triggered only.
