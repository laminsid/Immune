package com.immunesignal.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GTIMNovelSignalCaptureV2756Test {
    @Test
    fun microbiomeKynurenineSignalBecomesKnownPriorExtensionNotForcedTemplate() {
        val contract = GTIMRunDecisionContractFactoryV2740.buildAutonomousSelectedTopic(
            "gut bacteria depression tryptophan kynurenine IL-6 TNF human cohort dataset",
            hasDatasetAccessions = false,
            matrixState = "DGE_NOT_READY_NO_ACCESSION"
        )
        val lead = GTIMNovelSignalCaptureV2756.capture(
            rawText = "gut microbiome depression tryptophan kynurenine IL-6 TNF microglia cohort",
            contract = contract
        )
        assertEquals(GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION, lead.signalClass)
        assertTrue(lead.novelTerms.any { it.contains("kynurenine") || it.contains("microglia") })
        assertFalse(lead.promoteToCore)
    }

    @Test
    fun priorTemplateOutsideContractIsRejectedNotPromoted() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Covid", GTIMInputModeV2740.USER_QUERY)
        val lead = GTIMNovelSignalCaptureV2756.capture(
            rawText = "EBV HHV-6 SLE MS ME-CFS transcriptomic bridge",
            contract = contract
        )
        assertEquals(GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE, lead.signalClass)
        assertFalse(lead.promoteToCore)
    }

    @Test
    fun discoveryLedgerSurfacesNovelSignalLine() {
        val contract = GTIMRunDecisionContractFactoryV2740.build("Diabetes", GTIMInputModeV2740.USER_QUERY)
        val ledger = GTIMDiscoveryLedgerV2745.build(
            contract,
            candidateTexts = listOf("diabetes insulin resistance adipokine leptin adiponectin cohort")
        )
        assertTrue(ledger.novelLine.contains("Novel signal capture"))
        assertTrue(ledger.novelLine.contains("NOVEL_SIGNAL_CAPTURE_NOT_EVIDENCE_NOT_DIAGNOSIS"))
    }

    @Test
    fun novelSignalLayerDoesNotBreakKnownOntologyRouting() {
        val covid = GTIMRunDecisionContractFactoryV2740.build("Covid", GTIMInputModeV2740.USER_QUERY)
        val allergy = GTIMRunDecisionContractFactoryV2740.build("Immune vs allergy vs inflammation", GTIMInputModeV2740.USER_QUERY)
        assertEquals(GTIMPrimaryAnchorV2740.COVID_RESPIRATORY_VIRAL, covid.primaryAnchor)
        assertEquals(GTIMPrimaryAnchorV2740.ALLERGY_TYPE2_IGE_MAST_EOSINOPHIL, allergy.primaryAnchor)
        assertTrue(covid.canUseRoute("covid_interferon_cytokine_bridge"))
        assertTrue(allergy.canUseRoute("allergy_type2_to_barrier_immunity"))
    }
}
