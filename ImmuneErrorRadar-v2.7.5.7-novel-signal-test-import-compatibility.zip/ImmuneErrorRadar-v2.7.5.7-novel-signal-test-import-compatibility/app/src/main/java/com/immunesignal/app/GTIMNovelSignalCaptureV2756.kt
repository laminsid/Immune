package com.immunesignal.app

/**
 * v2.7.5.6 — Novel Signal Capture Layer
 *
 * The ontology is a routing guard, not a closed-world ceiling. This layer detects
 * whether a candidate finding merely repeats known ontology, extends it, or carries
 * an out-of-ontology signal that should be tracked without being forced into an old
 * template. It never upgrades evidence; it only labels novelty and produces safe
 * lookup queries/learning-edge candidates.
 */
enum class GTIMNovelSignalClassV2756 {
    KNOWN_PRIOR_MATCH,
    KNOWN_PRIOR_EXTENSION,
    OUT_OF_ONTOLOGY_LEAD,
    REJECTED_PRIOR_TEMPLATE
}

data class GTIMOutOfOntologyLeadV2756(
    val signalClass: GTIMNovelSignalClassV2756,
    val leadId: String,
    val summary: String,
    val matchedKnownTerms: List<String>,
    val novelTerms: List<String>,
    val safeQuery: String,
    val promoteToCore: Boolean,
    val reason: String
)

object GTIMNovelSignalCaptureV2756 {
    const val VERSION: String = "2.7.5.6-novel-signal-capture-layer"
    const val CLAIM_BOUNDARY: String = "NOVEL_SIGNAL_CAPTURE_NOT_EVIDENCE_NOT_DIAGNOSIS"

    fun capture(
        rawText: String,
        contract: GTIMRunDecisionContractV2740,
        matrixAudit: GTIMMatrixAuditCardReportV2745? = null,
        extraContext: List<String> = emptyList()
    ): GTIMOutOfOntologyLeadV2756 {
        val corpus = normalize((listOf(rawText) + extraContext + listOf(contract.rawQuery, contract.primaryAnchor.routeId)).joinToString(" "))
        val known = knownTermsFor(contract).filter { token -> token.isNotBlank() && corpus.contains(normalize(token)) }.distinct().take(12)
        val novel = novelTerms(corpus, contract).take(12)
        val priorTemplate = looksLikeRejectedPriorTemplate(corpus, contract)
        val hasValidAccession = matrixAudit?.targetId?.let { GTIMAccessionIdValidityGuardV2753.isFullAccession(it) } ?: false
        val matrixReady = matrixAudit?.let { it.matrixState == "DGE_READY" && it.accessionState == "DGE_READY" } ?: false
        val signalClass = when {
            priorTemplate -> GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE
            novel.size >= 2 && known.isNotEmpty() -> GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION
            novel.isNotEmpty() && known.isEmpty() -> GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD
            else -> GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH
        }
        val leadId = when (signalClass) {
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH -> "known_prior_${contract.primaryAnchor.routeId}"
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION -> "known_prior_extension_${contract.primaryAnchor.routeId}"
            GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD -> "out_of_ontology_${contract.primaryAnchor.routeId}"
            GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE -> "rejected_prior_template_${contract.primaryAnchor.routeId}"
        }
        val promote = signalClass != GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE && hasValidAccession && matrixReady
        val safeQuery = safeNovelQuery(contract, novel, known)
        val summary = when (signalClass) {
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH -> "Novel signal: known-prior match only; ontology route protected and no new edge promoted."
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION -> "Novel signal: known-prior extension candidate; track as learning edge, not evidence."
            GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD -> "Novel signal: out-of-ontology lead captured; keep separate from known templates until accession/matrix support exists."
            GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE -> "Novel signal: rejected prior-template; not allowed to overwrite active contract."
        }
        val reason = when (signalClass) {
            GTIMNovelSignalClassV2756.REJECTED_PRIOR_TEMPLATE -> "Old template terms conflict with active contract ${contract.primaryAnchor.routeId}."
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_EXTENSION -> "Known route terms plus novel tokens were both present; preserve as extension candidate."
            GTIMNovelSignalClassV2756.OUT_OF_ONTOLOGY_LEAD -> "Candidate terms are not covered by the current ontology route; preserve for review."
            GTIMNovelSignalClassV2756.KNOWN_PRIOR_MATCH -> "Candidate remained inside current ontology/contract boundaries."
        }
        return GTIMOutOfOntologyLeadV2756(signalClass, leadId, summary, known, novel, safeQuery, promote, reason)
    }

    fun reportLine(lead: GTIMOutOfOntologyLeadV2756): String {
        val novel = if (lead.novelTerms.isEmpty()) "none" else lead.novelTerms.take(6).joinToString(", ")
        return "Novel signal capture: class=${lead.signalClass} | lead=${lead.leadId} | novel=$novel | promote_to_core=${lead.promoteToCore} | $CLAIM_BOUNDARY"
    }

    fun learningEdgeJsonl(lead: GTIMOutOfOntologyLeadV2756, contract: GTIMRunDecisionContractV2740): String {
        val novel = lead.novelTerms.take(8).joinToString(";")
        return "{\"anchor\":\"${contract.primaryAnchor.routeId}\",\"lead_id\":\"${lead.leadId}\",\"signal_class\":\"${lead.signalClass}\",\"novel_terms\":\"$novel\",\"promote_to_core\":${lead.promoteToCore},\"claim_boundary\":\"$CLAIM_BOUNDARY\"}"
    }

    private fun knownTermsFor(contract: GTIMRunDecisionContractV2740): List<String> {
        val ontology = GTIMDiseaseSymptomOntologyBootstrapV2755.searchKeywordsFor(contract.primaryAnchor)
        val bridges = contract.discoveryBridges.map { it.routeId.replace('_', ' ') }
        val anchor = listOf(contract.primaryAnchor.routeId.replace('_', ' '), contract.benchmarkTopic ?: "")
        return (ontology + bridges + anchor).flatMap { splitUsefulTerms(it) }.distinct()
    }

    private fun novelTerms(text: String, contract: GTIMRunDecisionContractV2740): List<String> {
        val candidateTerms = listOf(
            "kynurenine", "tryptophan", "serotonin", "indole", "short chain fatty acid", "scfa", "butyrate",
            "bile acid", "lipopolysaccharide", "lps", "microglia", "vagus", "hpa", "cortisol", "sleep",
            "mitochondrial", "lactate", "oxidative stress", "barrier permeability", "zonulin", "th17", "il-17",
            "neutrophil", "endothelial", "vascular leakage", "adipokine", "leptin", "adiponectin", "androgen",
            "thyroid peroxidase", "tpo", "molecular mimicry", "candida", "fungal", "yeast", "metabolite"
        )
        val knownNorm = knownTermsFor(contract).map { normalize(it) }.toSet()
        return candidateTerms.filter { term ->
            val norm = normalize(term)
            text.contains(norm) && knownNorm.none { known -> known.contains(norm) || norm.contains(known) }
        }.distinct()
    }

    private fun safeNovelQuery(contract: GTIMRunDecisionContractV2740, novel: List<String>, known: List<String>): String {
        val base = GTIMDownstreamContractAdaptersV2740.safeQuery(contract)
        val additions = (novel.take(5) + known.take(4)).filter { it.isNotBlank() }.distinct().joinToString(" ")
        return listOf(base, additions, "human cohort comparator accession GSE PRJNA PMID").joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }

    private fun looksLikeRejectedPriorTemplate(text: String, contract: GTIMRunDecisionContractV2740): Boolean {
        val latentVirus = (text.contains("ebv") || text.contains("hhv 6") || text.contains("hhv6")) &&
            (text.contains("sle") || text.contains("ms") || text.contains("me cfs") || text.contains("mecfs"))
        if (latentVirus && contract.primaryAnchor !in setOf(
                GTIMPrimaryAnchorV2740.SLE_SYSTEMIC_AUTOIMMUNE,
                GTIMPrimaryAnchorV2740.MS_NEUROIMMUNE_DEMYELINATION,
                GTIMPrimaryAnchorV2740.FATIGUE_SYNDROME_NEUROIMMUNE_METABOLIC
            )) return true
        if (text.contains("allergy") && contract.forbiddenConflations.any { it.contains("allergy") }) return true
        return false
    }

    private fun splitUsefulTerms(text: String): List<String> = normalize(text)
        .split(" ")
        .map { it.trim() }
        .filter { it.length >= 4 && it !in setOf("dataset", "human", "cohort", "comparator", "route", "axis", "with", "and") }

    private fun normalize(value: String): String = value.lowercase()
        .replace('_', ' ')
        .replace('-', ' ')
        .replace('/', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()
}
