#!/usr/bin/env bash
set -euo pipefail
# Default CI gate is bounded and fast. Full historical/release verification is opt-in.
# Use CI_RESEARCH_FULL_CHECKS=1 bash scripts/run_static_checks.sh for the full gate.
if [ "${CI_RESEARCH_FULL_CHECKS:-0}" = "1" ]; then
  exec bash scripts/run_static_checks_full.sh "$@"
fi
exec bash scripts/run_static_checks_fast.sh "$@"
