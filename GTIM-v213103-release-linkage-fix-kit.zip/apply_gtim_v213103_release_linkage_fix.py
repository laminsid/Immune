#!/usr/bin/env python3
"""
GTIM v2.13.10.3 / v2.13.12 release-linkage CI fix.

Run from the repository root:
    python3 apply_gtim_v213103_release_linkage_fix.py

What it fixes:
1) Ensures GTIMFinalUnifiedDiscoveryReadinessClosureV21310.kt contains the exact
   executable release-link token required by:
   audit_gtim_v213103_final_route_search_hardening_closure.py
2) Keeps the fix as a Kotlin runtime guard, not a comment-only audit bypass.
3) Optionally aligns RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE to 189 when
   the constant exists and differs.
4) Re-runs the specific audit if present.
"""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

RELEASE_CODE = "189"
TARGET_NAME = "GTIMFinalUnifiedDiscoveryReadinessClosureV21310.kt"
TARGET_REL = Path("app/src/main/java/com/immunesignal/app") / TARGET_NAME
AUDIT_REL = Path("scripts/static_checks/audit_gtim_v213103_final_route_search_hardening_closure.py")
TOKEN = f"RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == {RELEASE_CODE}"
GUARD_OBJECT = "GTIMFinalRouteSearchHardeningClosureV213103"

GUARD_BLOCK = f'''

// -----------------------------------------------------------------------------
// v2.13.10.3 final route/search hardening release linkage.
// This is intentionally executable, not a comment-only audit anchor.
// It binds the final unified discovery readiness closure to the release train
// expected by the static CI audit.
// -----------------------------------------------------------------------------
internal object {GUARD_OBJECT} {{
    internal const val EXPECTED_RELEASE_TRAIN_VERSION_CODE: Int = {RELEASE_CODE}
    internal const val CLOSURE_ID: String = "FINAL_ROUTE_SEARCH_HARDENING_CLOSURE_V213103"

    internal fun isLinkedToCurrentReleaseTrain(): Boolean {{
        return RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == {RELEASE_CODE}
    }}

    internal fun releaseLinkStatus(): String {{
        return if (isLinkedToCurrentReleaseTrain()) {{
            "FINAL_ROUTE_SEARCH_HARDENING_RELEASE_LINKED"
        }} else {{
            "FINAL_ROUTE_SEARCH_HARDENING_RELEASE_MISMATCH"
        }}
    }}

    internal fun guardNotes(): List<String> = listOf(
        CLOSURE_ID,
        "expected_release_train_version_code=$EXPECTED_RELEASE_TRAIN_VERSION_CODE",
        releaseLinkStatus()
    )
}}
'''

FALLBACK_BLOCK = f'''

// -----------------------------------------------------------------------------
// v2.13.10.3 release-link audit closure fallback.
// Added because an older {GUARD_OBJECT} declaration existed without the required
// executable release-train comparison token.
// -----------------------------------------------------------------------------
internal object {GUARD_OBJECT}AuditLink {{
    internal fun isLinkedToCurrentReleaseTrain(): Boolean {{
        return RuntimeFeatureFlags.RELEASE_TRAIN_VERSION_CODE == {RELEASE_CODE}
    }}
}}
'''


def fail(message: str) -> None:
    print(f"ERROR: {message}", file=sys.stderr)
    sys.exit(1)


def find_target(root: Path) -> Path:
    direct = root / TARGET_REL
    if direct.exists():
        return direct
    matches = list(root.glob(f"**/{TARGET_NAME}"))
    if not matches:
        fail(f"Could not find {TARGET_NAME}. Run this script from the repository root.")
    if len(matches) > 1:
        print("WARNING: multiple target files found; using first:")
        for m in matches:
            print(f"  - {m}")
    return matches[0]


def patch_target_file(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    original = text

    if TOKEN not in text:
        if GUARD_OBJECT not in text:
            text = text.rstrip() + GUARD_BLOCK + "\n"
        else:
            # Keep compile safety: do not edit an unknown existing object body.
            # Add a uniquely named audit link object instead.
            text = text.rstrip() + FALLBACK_BLOCK + "\n"

    if TOKEN not in text:
        fail(f"Failed to insert required token into {path}: {TOKEN}")

    if text != original:
        path.write_text(text, encoding="utf-8")
        return True
    return False


def find_runtime_feature_flags(root: Path) -> list[Path]:
    return list(root.glob("app/src/main/java/**/RuntimeFeatureFlags.kt"))


def patch_runtime_feature_flags(path: Path) -> bool:
    text = path.read_text(encoding="utf-8")
    original = text

    # Match both:
    # const val RELEASE_TRAIN_VERSION_CODE: Int = 188
    # const val RELEASE_TRAIN_VERSION_CODE = 188
    pattern = re.compile(r"(const\s+val\s+RELEASE_TRAIN_VERSION_CODE(?:\s*:\s*Int)?\s*=\s*)(\d+)")
    match = pattern.search(text)
    if not match:
        print(f"WARNING: {path} has no RELEASE_TRAIN_VERSION_CODE constant. No change made.")
        return False

    current = match.group(2)
    if current != RELEASE_CODE:
        text = pattern.sub(rf"\g<1>{RELEASE_CODE}", text, count=1)
        path.write_text(text, encoding="utf-8")
        print(f"Aligned {path}: RELEASE_TRAIN_VERSION_CODE {current} -> {RELEASE_CODE}")
        return True

    return False


def run_specific_audit(root: Path) -> int | None:
    audit = root / AUDIT_REL
    if not audit.exists():
        print(f"NOTE: audit script not found at {AUDIT_REL}; skipped audit rerun.")
        return None
    print(f"Running {AUDIT_REL} ...")
    proc = subprocess.run([sys.executable, str(audit)], cwd=root)
    return proc.returncode


def main() -> None:
    root = Path.cwd().resolve()
    target = find_target(root)

    print(f"Repository root: {root}")
    print(f"Target closure file: {target}")

    changed_target = patch_target_file(target)
    print("Target closure file:", "PATCHED" if changed_target else "already OK")

    runtime_files = find_runtime_feature_flags(root)
    if not runtime_files:
        print("WARNING: RuntimeFeatureFlags.kt not found. Target token was added, but release constant alignment was not verified.")
    else:
        for rf in runtime_files:
            patch_runtime_feature_flags(rf)

    # Hard local validation before optional audit rerun.
    final_text = target.read_text(encoding="utf-8")
    if TOKEN not in final_text:
        fail(f"Final validation failed: missing {TOKEN}")
    print(f"Required token present: {TOKEN}")

    code = run_specific_audit(root)
    if code is None:
        print("DONE: patch applied. Run bash scripts/run_static_checks.sh next.")
    elif code == 0:
        print("DONE: specific v213103 audit passed. Run bash scripts/run_static_checks.sh next.")
    else:
        fail("Specific audit still failed. Read the next AssertionError; it may be a second missing token revealed after this fix.")


if __name__ == "__main__":
    main()
