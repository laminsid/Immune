package com.immunesignal.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * v2.12.15 — Candidate handle ledger.
 *
 * Single source of truth for candidate handles. It separates local curated handles,
 * externally discovered handles, selected review target, demoted cross-domain seeds, and
 * verified capsule counts. This prevents contradictory counters between the first surface,
 * study card, terminal continuation, and technical appendix. It never upgrades evidence.
 */
object GTIMCandidateHandleLedgerV21215 {
    const val VERSION: String = "2.12.15-candidate-handle-ledger"
    const val CLAIM_LIMIT: String = "candidate_handle_ledger_only_no_evidence_upgrade"

    fun toJson(report: JSONObject): JSONObject {
        val domainKey = domainKey(report)
        val topicSubtype = topicSubtype(report)
        val curated = report.optJSONObject("curatedMetadataSeedLibraryV21211") ?: JSONObject()
        val consistency = GTIMReportConsistencyGateV2121.build(report, GlobalResearchGradeBriefV11061.renderLines(report))
        val localSeedHandles = domainCompatibleLocalSeedHandles(curated, domainKey, topicSubtype)
        val demotedSeeds = demotedLocalSeeds(curated, domainKey, topicSubtype)
        val rawHandles = extractHandles(report.toString())
        val externalHandles = rawHandles
            .filterNot { it in localSeedHandles }
            .filter { isCompatibleOrUnknown(domainKey, it, topicSubtype) }
            .distinct()
            .take(12)
        val selected = selectReviewTarget(consistency.candidateLookupHandle, localSeedHandles, externalHandles, domainKey, topicSubtype)
        val allCandidateHandles = (localSeedHandles + externalHandles).distinct().take(12)
        val verifiedCapsules = verifiedCapsuleSourceCount(report, consistency.verifiedMatrixFiles)
        return JSONObject()
            .put("version", VERSION)
            .put("domainKey", domainKey)
            .put("topicSubtype", topicSubtype)
            .put("state", if (allCandidateHandles.isNotEmpty()) "CANDIDATE_HANDLE_LEDGER_READY" else "NO_CANDIDATE_HANDLE_YET")
            .put("localSeedHandles", JSONArray(localSeedHandles))
            .put("externalCandidateHandles", JSONArray(externalHandles))
            .put("allCandidateHandles", JSONArray(allCandidateHandles))
            .put("candidateHandleCount", allCandidateHandles.size)
            .put("selectedReviewTarget", selected)
            .put("demotedCrossDomainSeeds", demotedSeeds)
            .put("verifiedCapsuleSourceCount", verifiedCapsules)
            .put("topicCompatibleTargetSelected", consistency.topicCompatibleTargetSelected)
            .put("counterContract", "local_seed_handles + external_candidate_handles = all_candidate_handles; verified_capsule_source_count is separate")
            .put("claimLimit", CLAIM_LIMIT)
    }

    fun publicLines(obj: JSONObject): List<String> {
        val selected = obj.optString("selectedReviewTarget").ifBlank { "none yet" }
        val all = jsonStrings(obj.optJSONArray("allCandidateHandles")).take(5).joinToString(", ").ifBlank { "none" }
        val demotedCount = obj.optJSONArray("demotedCrossDomainSeeds")?.length() ?: 0
        return listOf(
            "Candidate handle ledger",
            "State: ${obj.optString("state", "UNKNOWN")}; domain=${obj.optString("domainKey", "unknown")}; selected_review_target=$selected.",
            "Counters: candidate_handles=${obj.optInt("candidateHandleCount", 0)} [$all]; verified_capsule_source_count=${obj.optInt("verifiedCapsuleSourceCount", 0)}; demoted_cross_domain_seeds=$demotedCount.",
            "Contract: candidate handles are lookup/review targets only; verified capsules are counted separately and control evidence upgrades."
        )
    }

    fun auditTokens(): JSONArray = JSONArray(listOf(
        VERSION,
        "CANDIDATE_HANDLE_LEDGER_READY",
        "selectedReviewTarget",
        "topicSubtype",
        "viral_subtype_gate_covid_not_filovirus",
        "localSeedHandles",
        "externalCandidateHandles",
        "demotedCrossDomainSeeds",
        "verifiedCapsuleSourceCount",
        "candidate_handle_ledger_only_no_evidence_upgrade"
    ))

    private fun domainKey(report: JSONObject): String = report.optJSONObject("domainSpecificHypothesisSelectorV2129")?.optString("domainKey").orEmpty()
        .ifBlank { GTIMDomainSpecificHypothesisSelectorV2129.build(report).domainKey }

    private fun domainCompatibleLocalSeedHandles(curated: JSONObject, domainKey: String, topicSubtype: String): List<String> {
        val matches = curated.optJSONArray("localSeedMatches") ?: JSONArray()
        return (0 until matches.length()).mapNotNull { idx ->
            val seed = matches.optJSONObject(idx) ?: return@mapNotNull null
            val handle = seed.optString("handle").uppercase(Locale.US)
            val family = seed.optString("topic_family")
            if (isDatasetHandle(handle) && familyMatches(domainKey, family, topicSubtype) && isCompatibleOrUnknown(domainKey, handle, topicSubtype)) handle else null
        }.distinct().take(8)
    }

    private fun demotedLocalSeeds(curated: JSONObject, domainKey: String, topicSubtype: String): JSONArray {
        val out = JSONArray()
        val matches = curated.optJSONArray("localSeedMatches") ?: JSONArray()
        for (idx in 0 until matches.length()) {
            val seed = matches.optJSONObject(idx) ?: continue
            val family = seed.optString("topic_family")
            val handle = seed.optString("handle").uppercase(Locale.US)
            if (!familyMatches(domainKey, family, topicSubtype) || (isDatasetHandle(handle) && !isCompatibleOrUnknown(domainKey, handle, topicSubtype))) {
                out.put(JSONObject()
                    .put("handle", seed.optString("handle"))
                    .put("topicFamily", family)
                    .put("topicSubtype", topicSubtype)
                    .put("demotionReason", "selectedSeed.topicFamily_or_viralSubtype_does_not_match_domainSpecificRoute")
                    .put("newRole", "cross_domain_or_cross_subtype_background_or_contradiction_seed_only"))
            }
        }
        return out
    }

    private fun selectReviewTarget(raw: String, local: List<String>, external: List<String>, domainKey: String, topicSubtype: String): String {
        val candidate = raw.uppercase(Locale.US).takeIf { it.isNotBlank() && isCompatibleOrUnknown(domainKey, it, topicSubtype) }
        return candidate ?: local.firstOrNull() ?: external.firstOrNull().orEmpty()
    }

    private fun verifiedCapsuleSourceCount(report: JSONObject, fallback: Int): Int {
        val terminal = report.optJSONObject("terminalDiscoveryContinuationV21212")
        val metadata = report.optJSONObject("metadataProbeBackgroundWorkersV21215")
        val capsuleReady = metadata?.optJSONArray("probeResults")?.let { arr ->
            (0 until arr.length()).count { idx ->
                val item = arr.optJSONObject(idx) ?: JSONObject()
                item.optString("matrixOrCapsuleHint").contains("possible", true) &&
                    item.optString("sampleProvenanceStatus").contains("found", true)
            }
        } ?: 0
        return listOf(fallback, terminal?.optInt("verifiedCapsuleSourceCount", 0) ?: 0, capsuleReady).maxOrNull() ?: 0
    }

    private fun extractHandles(text: String): List<String> = Regex("\\b(GSE\\d+|GDS\\d+|SRP\\d+|SRR\\d+|PRJNA\\d+|PRJEB\\d+|SDY\\d+|E-MTAB-[A-Za-z0-9_.-]+)\\b", RegexOption.IGNORE_CASE)
        .findAll(text)
        .map { it.value.uppercase(Locale.US) }
        .distinct()
        .toList()

    private fun isDatasetHandle(handle: String): Boolean = Regex("^(GSE|GDS|SRP|SRR|PRJNA|PRJEB|SDY|E-MTAB-).+", RegexOption.IGNORE_CASE).containsMatchIn(handle)

    private fun isCompatibleOrUnknown(domainKey: String, handle: String, topicSubtype: String): Boolean {
        val family = knownHandleFamily(handle) ?: return true
        if (!familyMatches(domainKey, family, topicSubtype)) return false
        val subtype = knownHandleSubtype(handle) ?: return true
        return when (topicSubtype) {
            "viral_covid_postviral" -> subtype == "viral_covid_postviral" || subtype == "viral_generic"
            "viral_filovirus" -> subtype == "viral_filovirus" || subtype == "viral_generic"
            "viral_hantavirus" -> subtype == "viral_hantavirus" || subtype == "viral_generic"
            else -> true
        }
    }

    private fun knownHandleFamily(handle: String): String? = when (handle.uppercase(Locale.US)) {
        "GSE102556" -> "depression_kynurenine_neuroimmune"
        "GSE152202", "GSE166552", "GSE152418", "GSE157103" -> "viral_post_inflammatory"
        "GSE45291" -> "filovirus_viral_host_response"
        "GSE250594", "GSE146170", "GSE146352" -> "allergy_type2_barrier"
        "GSE72056", "GSE131907" -> "oncology_tumor_microenvironment"
        "GSE49454" -> "rheumatoid_autoimmune_synovial_inflammation"
        else -> null
    }

    private fun knownHandleSubtype(handle: String): String? = when (handle.uppercase(Locale.US)) {
        "GSE152202", "GSE166552", "GSE152418", "GSE157103" -> "viral_covid_postviral"
        "GSE45291" -> "viral_filovirus"
        else -> null
    }

    private fun topicSubtype(report: JSONObject): String {
        val topic = report.optJSONObject("topicCapture") ?: JSONObject()
        val normalizer = report.optJSONObject("studyFocusNormalizerV21282") ?: JSONObject()
        val selector = report.optJSONObject("domainSpecificHypothesisSelectorV2129") ?: JSONObject()
        val priorityText = listOf(
            topic.optString("normalizedTopic"),
            topic.optString("rawInput"),
            report.optString("normalizedTopic"),
            report.optString("researchTopic"),
            normalizer.optString("title"),
            normalizer.optString("studyFocus"),
            selector.optString("studyFocus"),
            selector.optString("domainKey"),
            selector.optString("topResearchHypothesis")
        ).joinToString(" ").lowercase(Locale.US)
        val fallbackText = if (priorityText.isBlank()) report.toString().take(2500).lowercase(Locale.US) else priorityText
        return when {
            fallbackText.contains("ebola") || fallbackText.contains("filovirus") || fallbackText.contains("hemorrhagic fever") -> "viral_filovirus"
            fallbackText.contains("covid") || fallbackText.contains("sars-cov-2") || fallbackText.contains("post-covid") || fallbackText.contains("post viral") || fallbackText.contains("post-viral") -> "viral_covid_postviral"
            fallbackText.contains("hanta") || fallbackText.contains("hantavirus") -> "viral_hantavirus"
            fallbackText.contains("viral") || fallbackText.contains("interferon") -> "viral_generic"
            else -> "nonviral_or_unspecified"
        }
    }

    private fun familyMatches(domainKey: String, family: String, topicSubtype: String): Boolean {
        val d = domainKey.lowercase(Locale.US)
        val f = family.lowercase(Locale.US)
        return when {
            d.contains("depression_kynurenine") -> f.contains("depression_kynurenine")
            d.contains("viral_interferon") -> when (topicSubtype) {
                "viral_covid_postviral" -> f.contains("viral_post") || f.contains("covid")
                "viral_filovirus" -> f.contains("filovirus")
                "viral_hantavirus" -> f.contains("hanta")
                else -> f.contains("viral") || f.contains("filovirus") || f.contains("hantavirus")
            }
            d.contains("allergy_type2") -> f.contains("allergy_type2")
            d.contains("metabolic") -> f.contains("metabolic")
            d.contains("environmental") -> f.contains("environmental") || f.contains("xenobiotic")
            else -> true
        }
    }

    private fun jsonStrings(array: JSONArray?): List<String> = if (array == null) emptyList() else (0 until array.length()).mapNotNull { idx ->
        array.optString(idx).takeIf { it.isNotBlank() }
    }
}
