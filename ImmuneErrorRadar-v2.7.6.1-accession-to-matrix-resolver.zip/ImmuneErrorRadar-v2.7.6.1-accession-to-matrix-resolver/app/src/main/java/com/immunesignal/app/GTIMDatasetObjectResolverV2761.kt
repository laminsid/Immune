package com.immunesignal.app

import org.json.JSONObject

/**
 * v2.7.6.1 — accession-to-matrix resolver.
 *
 * Converts a retrieval handle (GSE/PMID/PRJNA/SRP/SDY) into an internal
 * dataset-object readiness ladder. This is deliberately conservative: a full
 * accession can become a resolved/partial dataset object from local report
 * context or known seed profiles, but DGE_READY requires explicit comparator +
 * matrix readiness signals. No clinical or biological claim is upgraded here.
 */
enum class GTIMDatasetObjectStageV2761(val code: String) {
    ACCESSION_HANDLE_ONLY("ACCESSION_HANDLE_ONLY"),
    DATASET_OBJECT_RESOLVED("DATASET_OBJECT_RESOLVED"),
    METADATA_TABLE_FOUND("METADATA_TABLE_FOUND"),
    COMPARATOR_MAPPED("COMPARATOR_MAPPED"),
    MATRIX_LINK_FOUND("MATRIX_LINK_FOUND"),
    DGE_READY("DGE_READY")
}

enum class GTIMEvidenceUpgradeStateV2761(val code: String) {
    LOOKUP_HANDLE_ONLY("LOOKUP_HANDLE_ONLY"),
    DATASET_OBJECT_PARTIAL("DATASET_OBJECT_PARTIAL"),
    METADATA_AUDIT_READY("METADATA_AUDIT_READY"),
    EVIDENCE_CANDIDATE("EVIDENCE_CANDIDATE"),
    STRONG_SIGNAL_REVIEW_ONLY("STRONG_SIGNAL_REVIEW_ONLY")
}

data class GTIMResolvedDatasetObjectV2761(
    val accessionId: String,
    val repository: String,
    val title: String,
    val organism: String,
    val assayType: String,
    val tissueContext: String,
    val conditionContext: String,
    val sampleCountHint: Int?,
    val sourceState: GTIMDatasetObjectStageV2761,
    val sourceReason: String
)

data class GTIMMetadataTraitAuditV2761(
    val metadataState: GTIMDatasetObjectStageV2761,
    val verifiedSlots: List<String>,
    val blockingGaps: List<String>,
    val comparatorStatus: String,
    val timepointStatus: String,
    val matrixLinkStatus: String
)

data class GTIMMatrixReadinessDecisionV2761(
    val state: GTIMDatasetObjectStageV2761,
    val matrixState: String,
    val readinessScore: Int,
    val nextDecisiveAction: String,
    val evidenceUpgradeState: GTIMEvidenceUpgradeStateV2761
)

data class GTIMDatasetObjectResolutionReportV2761(
    val datasetObject: GTIMResolvedDatasetObjectV2761,
    val metadataAudit: GTIMMetadataTraitAuditV2761,
    val matrixDecision: GTIMMatrixReadinessDecisionV2761,
    val summaryLine: String
)

object GTIMDatasetObjectResolverV2761 {
    const val VERSION: String = "2.7.6.1-accession-to-matrix-resolver"

    private data class SeedProfile(
        val title: String,
        val organism: String,
        val assayType: String,
        val tissueContext: String,
        val conditionContext: String,
        val comparatorHint: String = "COMPARATOR_UNVERIFIED",
        val timepointHint: String = "TIMEPOINT_UNVERIFIED",
        val matrixHint: String = "MATRIX_LINK_NOT_VERIFIED"
    )

    private val knownProfiles: Map<String, SeedProfile> = mapOf(
        "GSE152202" to SeedProfile("COVID / SARS-CoV-2 host-response dataset handle", "human_or_patient_sample", "Transcriptomics / RNA-seq", "PBMC/blood/airway context", "COVID / Long COVID host response", "COMPARATOR_PARTIAL_FROM_TOPIC"),
        "GSE166552" to SeedProfile("COVID / SARS-CoV-2 immune-response dataset handle", "human_or_patient_sample", "Transcriptomics / RNA-seq", "PBMC/blood context", "COVID / recovered or control comparison possible", "COMPARATOR_PARTIAL_FROM_TOPIC"),
        "GSE152418" to SeedProfile("COVID immune-response dataset handle", "human_or_patient_sample", "Transcriptomics / RNA-seq", "blood/airway context", "COVID host response", "COMPARATOR_PARTIAL_FROM_TOPIC"),
        "GSE157103" to SeedProfile("COVID immune-response dataset handle", "human_or_patient_sample", "Transcriptomics / RNA-seq", "blood/PBMC context", "COVID host response", "COMPARATOR_PARTIAL_FROM_TOPIC"),
        "GSE72056" to SeedProfile("Ebola / EVD host-response dataset handle", "human_or_patient_sample", "Transcriptomics / RNA-seq", "blood/PBMC context", "Ebola virus disease host response", "COMPARATOR_UNVERIFIED"),
        "GSE131907" to SeedProfile("Ebola / hemorrhagic viral host-response dataset handle", "human_or_patient_sample", "Transcriptomics / RNA-seq", "blood/PBMC context", "Ebola virus disease host response", "COMPARATOR_UNVERIFIED"),
        "GSE93798" to SeedProfile("Ebola single-cell / host-response dataset handle", "human_or_patient_sample", "Single-cell RNA-seq", "PBMC/single-cell droplets", "Ebola virus disease host response", "COMPARATOR_UNVERIFIED", "TIMEPOINT_PARTIAL_FROM_TOPIC"),
        "GSE250594" to SeedProfile("Allergy / type-2 immune dataset handle", "human_or_patient_sample", "Single-cell RNA-seq", "mast-cell/eosinophil/barrier context", "allergic disease / hypersensitivity", "COMPARATOR_UNVERIFIED"),
        "GSE117882" to SeedProfile("Microbiome / depression neuroimmune candidate handle", "human_or_patient_sample", "Transcriptomics / RNA-seq", "gut/microbiome or blood immune context", "depression / microbiome-neuroimmune axis", "COMPARATOR_UNVERIFIED")
    )

    fun resolve(
        report: JSONObject,
        contract: GTIMRunDecisionContractV2740,
        pipeline: GTIMAccessionPipelineStateReportV2749,
        paperUnderstandingSummary: String = ""
    ): GTIMDatasetObjectResolutionReportV2761 {
        val target = pipeline.targetId
        val repository = repositoryFor(target)
        val reportText = report.toString()
        val context = normalize(listOf(
            pipeline.targetContext,
            paperUnderstandingSummary,
            reportText.take(1600),
            contract.rawQuery,
            contract.primaryAnchor.routeId
        ).joinToString(" "))
        val profile = knownProfiles[target]
        val fullAccession = GTIMAccessionIdValidityGuardV2753.isFullAccession(target)

        val hasDatasetObject = fullAccession && (
            profile != null || containsAny(context, "gsm", "sample", "samples", "sample trait", "sample traits", "metadata", "dataset=", "data availability", "supplementary")
        )
        val hasMetadataTable = hasDatasetObject && (
            profile != null || containsAny(context, "trait", "phenotype", "characteristics", "condition", "disease state", "patient", "healthy", "control", "case", "metadata")
        )
        val hasComparator = hasMetadataTable && (
            containsAny(context, "control", "healthy", "matched", "baseline", "case", "recovered", "comparator") || profile?.comparatorHint?.contains("PARTIAL") == true
        )
        val hasMatrix = hasDatasetObject && containsAny(context, "count matrix", "raw count", "raw counts", "counts", "expression matrix", "matrix file", "mtx", "h5", "rds", "supplementary file", "geo supplementary")
        val explicitReady = hasMatrix && hasComparator && containsAny(context, "dge ready", "matrix ready", "accession backed ready", "accession ready", "ready matrix") && !containsAny(context, "dge not ready", "not ready", "matrix not ready")

        val objectStage = when {
            explicitReady -> GTIMDatasetObjectStageV2761.DGE_READY
            hasMatrix -> GTIMDatasetObjectStageV2761.MATRIX_LINK_FOUND
            hasComparator -> GTIMDatasetObjectStageV2761.COMPARATOR_MAPPED
            hasMetadataTable -> GTIMDatasetObjectStageV2761.METADATA_TABLE_FOUND
            hasDatasetObject -> GTIMDatasetObjectStageV2761.DATASET_OBJECT_RESOLVED
            else -> GTIMDatasetObjectStageV2761.ACCESSION_HANDLE_ONLY
        }

        val dataset = GTIMResolvedDatasetObjectV2761(
            accessionId = target,
            repository = repository,
            title = firstNonBlank(profile?.title.orEmpty(), titleFromContext(context), "dataset object not resolved"),
            organism = firstNonBlank(profile?.organism.orEmpty(), if (containsAny(context, "human", "patient", "pbmc", "blood")) "human_or_patient_sample" else "not surfaced"),
            assayType = firstNonBlank(profile?.assayType.orEmpty(), assayFromContext(context)),
            tissueContext = firstNonBlank(profile?.tissueContext.orEmpty(), tissueFromContext(context), "not surfaced"),
            conditionContext = firstNonBlank(profile?.conditionContext.orEmpty(), contract.primaryAnchor.routeId),
            sampleCountHint = Regex("(?i)(?:n=|samples?=|sample count[:= ]+)(\\d{1,5})").find(context)?.groupValues?.getOrNull(1)?.toIntOrNull(),
            sourceState = objectStage,
            sourceReason = if (profile != null) "known seed profile + surfaced context" else "surfaced report context only"
        )

        val verified = mutableListOf<String>()
        if (dataset.organism != "not surfaced") verified += "organism_or_model=${dataset.organism}"
        if (dataset.tissueContext != "not surfaced") verified += "tissue_context=${dataset.tissueContext}"
        if (dataset.assayType != "assay not surfaced") verified += "assay=${dataset.assayType}"
        if (hasMetadataTable) verified += "metadata_table=FOUND_OR_PROFILED"
        if (hasComparator) verified += "comparator_tokens=PARTIAL_OR_FOUND"
        if (hasMatrix) verified += "matrix_link=FOUND_UNVERIFIED"
        verified += "condition_anchor=${contract.primaryAnchor.routeId}"

        val gaps = mutableListOf<String>()
        if (!fullAccession) gaps += "ACCESSION_HANDLE_ONLY:: no full accession-backed target is available."
        if (!hasDatasetObject) gaps += "DATASET_OBJECT_NOT_RESOLVED:: accession handle captured, but title/sample table/matrix links are not resolved."
        if (hasDatasetObject && !hasMetadataTable) gaps += "MISSING_SAMPLE_TRAIT_TABLE:: dataset object exists, but sample trait metadata is not parsed."
        if (hasMetadataTable && !hasComparator) gaps += "MISSING_COMPARATOR_LABELS:: case/control, matched healthy, baseline, or recovered comparator labels are not machine-mapped."
        if (!containsAny(context, "day", "timepoint", "longitudinal", "baseline", "post onset", "post-onset", "follow up", "follow-up")) gaps += "MISSING_TEMPORAL_ORDER:: longitudinal/timepoint ordering is not machine-checkable."
        if (!hasMatrix) gaps += "MATRIX_FILE_LINK_NOT_RESOLVED:: raw/count expression matrix or supplementary matrix link is not verified."
        if (explicitReady) gaps.clear()

        val metadataStage = when {
            explicitReady -> GTIMDatasetObjectStageV2761.DGE_READY
            hasMatrix -> GTIMDatasetObjectStageV2761.MATRIX_LINK_FOUND
            hasComparator -> GTIMDatasetObjectStageV2761.COMPARATOR_MAPPED
            hasMetadataTable -> GTIMDatasetObjectStageV2761.METADATA_TABLE_FOUND
            hasDatasetObject -> GTIMDatasetObjectStageV2761.DATASET_OBJECT_RESOLVED
            else -> GTIMDatasetObjectStageV2761.ACCESSION_HANDLE_ONLY
        }
        val metadata = GTIMMetadataTraitAuditV2761(
            metadataState = metadataStage,
            verifiedSlots = verified.distinct().take(8),
            blockingGaps = gaps.distinct().take(8),
            comparatorStatus = when {
                explicitReady || hasComparator -> "COMPARATOR_MAPPED_OR_PARTIAL"
                hasMetadataTable -> "AMBIGUOUS_COMPARATOR"
                else -> "COMPARATOR_NOT_PARSED"
            },
            timepointStatus = if (containsAny(context, "day", "timepoint", "longitudinal", "baseline", "post onset", "follow up")) "TIMEPOINT_TOKENS_PRESENT" else "TIMEPOINT_ORDER_NOT_MAPPED",
            matrixLinkStatus = when {
                explicitReady -> "MATRIX_LINK_READY"
                hasMatrix -> "MATRIX_LINK_FOUND_UNVERIFIED"
                else -> "MATRIX_LINK_NOT_RESOLVED"
            }
        )
        val readinessScore = when {
            explicitReady -> 88
            hasMatrix -> 82
            hasComparator -> 72
            hasMetadataTable -> 64
            hasDatasetObject -> 56
            fullAccession -> 45
            else -> 25
        }
        val matrixState = when {
            explicitReady -> "DGE_READY"
            hasMatrix -> "DGE_NOT_READY_MATRIX_LINK_UNVERIFIED"
            hasComparator -> "DGE_NOT_READY_COMPARATOR_MAPPED_MATRIX_MISSING"
            hasMetadataTable -> "DGE_NOT_READY_METADATA_TABLE_FOUND_COMPARATOR_MISSING"
            hasDatasetObject -> "DGE_NOT_READY_DATASET_OBJECT_RESOLVED_METADATA_PENDING"
            fullAccession -> "DGE_NOT_READY_ACCESSION_HANDLE_ONLY"
            else -> "DGE_NOT_READY_NO_ACCESSION"
        }
        val upgrade = when {
            explicitReady -> GTIMEvidenceUpgradeStateV2761.STRONG_SIGNAL_REVIEW_ONLY
            hasMatrix -> GTIMEvidenceUpgradeStateV2761.EVIDENCE_CANDIDATE
            hasComparator || hasMetadataTable -> GTIMEvidenceUpgradeStateV2761.METADATA_AUDIT_READY
            hasDatasetObject -> GTIMEvidenceUpgradeStateV2761.DATASET_OBJECT_PARTIAL
            else -> GTIMEvidenceUpgradeStateV2761.LOOKUP_HANDLE_ONLY
        }
        val decisiveAction = when {
            explicitReady -> "Human review: verify comparator mapping, effect direction, batch correction, and contradiction closure before any strong-signal claim."
            !hasDatasetObject -> "$target AND dataset sample metadata table AND ${GTIMDownstreamContractAdaptersV2740.safeQuery(contract).take(120)}"
            !hasMetadataTable -> "$target AND sample traits phenotype characteristics metadata"
            !hasComparator -> "$target AND healthy control matched comparator baseline recovered case control"
            !hasMatrix -> "$target AND supplementary raw counts expression matrix mtx h5 count matrix"
            else -> "$target AND DGE ready comparator raw matrix validation"
        }.replace(Regex("\\s+"), " ").trim()
        val matrixDecision = GTIMMatrixReadinessDecisionV2761(
            state = metadataStage,
            matrixState = matrixState,
            readinessScore = readinessScore,
            nextDecisiveAction = decisiveAction,
            evidenceUpgradeState = upgrade
        )
        val summary = "Dataset resolver: target=$target | object=${dataset.sourceState.code} | metadata=${metadata.metadataState.code} | comparator=${metadata.comparatorStatus} | matrix_link=${metadata.matrixLinkStatus} | evidence_upgrade=${upgrade.code}"
        return GTIMDatasetObjectResolutionReportV2761(dataset, metadata, matrixDecision, summary)
    }

    private fun repositoryFor(target: String): String = when {
        target.startsWith("GSE", true) || target.startsWith("GDS", true) -> "GEO"
        target.startsWith("PRJNA", true) -> "BioProject/SRA"
        target.startsWith("SRP", true) || target.startsWith("SRR", true) -> "SRA"
        target.startsWith("E-MTAB", true) -> "ArrayExpress"
        target.startsWith("SDY", true) -> "ImmPort"
        target.startsWith("PMID", true) -> "PubMed"
        target.startsWith("DOI", true) -> "DOI resolver"
        else -> "repository not surfaced"
    }

    private fun assayFromContext(text: String): String = when {
        containsAny(text, "single cell", "single-cell", "scrna", "scrna seq") -> "Single-cell RNA-seq"
        containsAny(text, "rna seq", "rnaseq", "transcriptomic", "transcriptomics") -> "Transcriptomics / RNA-seq"
        containsAny(text, "microarray", "array") -> "Microarray / expression profiling"
        containsAny(text, "cytokine", "elisa", "il 6", "tnf") -> "Cytokine / immune-marker panel"
        else -> "assay not surfaced"
    }

    private fun tissueFromContext(text: String): String = when {
        containsAny(text, "pbmc") -> "PBMC"
        containsAny(text, "blood") -> "blood"
        containsAny(text, "airway", "epithelial") -> "airway/epithelial"
        containsAny(text, "gut", "intestinal", "mucosal") -> "gut/mucosal"
        containsAny(text, "skin") -> "skin"
        containsAny(text, "synovial") -> "synovial"
        else -> "not surfaced"
    }

    private fun titleFromContext(text: String): String {
        val match = Regex("(?i)(?:title|dataset)[:= ]+([^.;|]{8,120})").find(text)?.groupValues?.getOrNull(1)
        return match?.trim().orEmpty()
    }

    private fun normalize(value: String): String = value.lowercase()
        .replace('_', ' ')
        .replace('-', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun containsAny(text: String, vararg needles: String): Boolean = needles.any { text.contains(it, ignoreCase = true) }

    private fun firstNonBlank(vararg values: String): String = values.firstOrNull { it.isNotBlank() }.orEmpty()
}
