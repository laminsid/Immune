# Immune Error Radar v1.2.1-alpha — Research Lock Hotfix Baseline

Immune Error Radar is a private Android research notebook for exploring immune over-response patterns and possible causal drivers.

It is designed for personal research and hypothesis generation, not for public clinical use.

## Core idea

The project studies how immune signals may shift across:

- Type-2 allergy / asthma-like patterns
- Autoimmune inflammatory patterns
- Hyperinflammatory / storm-like patterns
- Psychoneuroimmune stress/sleep amplification
- Psychomusculoskeletal pain/recovery loops
- Aging / immunosenescence / inflammaging patterns
- Autonomic-vascular dynamics: stress pressure-up vs histamine pressure-down

The goal is not to label disease. The goal is to discover whether a shared immune-axis vector can reveal hidden bridges between biological, psychological, environmental, infection, mechanical, aging, and vascular drivers.

## v0.5 additions

- AgingImmuneAxis: immunosenescence, inflammaging, immune responsiveness, resilience
- AllergyAgingBridge: preserved responsiveness vs chronic inflammaging burden
- AutonomicVascularLayer: sympathetic pressure-up vs histamine/vasodilation pressure-down
- LongevityHypothesisEngine: non-traditional but bounded research hypotheses
- New aging/autonomic UI inputs
- New result and PDF section for Allergy / Aging / Autonomic Bridge
- Research Autopilot queries for aging, immunosenescence, inflammaging, histamine, BP, autonomic dynamics
- Python `research/aging_autonomic_bridge.py`
- Dataset registry v0.4

## Android privacy model

- Private cases stay on device.
- Research Autopilot uses the internet only for public literature metadata search.
- No private case data is uploaded.
- No account, telemetry, tracking, or server sync.

## Safety boundary

This project is not:

- A diagnostic tool
- A treatment recommendation system
- A drug selection system
- A blood-pressure diagnostic tool
- An anti-aging claim engine
- A substitute for medical care
- A proof of psychological, biological, vascular, or aging causality

It is:

- A private research notebook
- A hypothesis engine
- A local evidence ledger
- A public-literature discovery assistant
- A dataset/pipeline seed for immune over-response research

## Build

Open in Android Studio or use GitHub Actions. This alpha ZIP does not bundle a Gradle Wrapper. See `BUILD.md`.

```bash
gradle :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Research pipeline

```bash
python3 research/dataset_registry_loader.py docs/DATASET_REGISTRY_v0.4.csv
python3 research/unit_normalizer.py research/examples/sample_markers.csv
python3 research/immune_matrix_builder.py research/examples/sample_cases.csv > /tmp/sample_matrix.csv
python3 research/baseline_classifier.py /tmp/sample_matrix.csv
python3 research/cross_condition_bridge.py /tmp/sample_matrix.csv
python3 research/aging_autonomic_bridge.py research/examples/sample_cases.csv
```

## Scientific rule

Every discovery remains hypothesis-grade until it passes:

1. Temporal evidence
2. Biological plausibility
3. Repeatability
4. Falsification test
5. Baseline comparison

## v0.5 central research question

Does allergy/reactivity sometimes indicate preserved immune responsiveness when aging-load is low, while chronic allergy plus inflammatory load may indicate inflammaging burden? The app tests both possibilities and does not assume either one is true.

## v0.6 — Omics Autopilot + Knowledge Intake

This private research build adds:

- DNA/RNA/omics research axis.
- PubMed/NCBI search cycle with cumulative source memory.
- Previously saved PubMed IDs are skipped so new cycles prefer new sources.
- Manual report intake via pasted text or uploaded text/csv/json file.
- Stop button: stops after current request/timeout and writes a partial report.
- Hard limits: 10 minutes search, 15 minutes learning.
- Short report renderer with copy-to-clipboard.
- GitHub-style static checks under `scripts/`.

Boundary: research hypotheses only. No diagnosis, no treatment, no drug ranking.

## v0.7.0-alpha — Gut / Nutrition / Muscle / Testosterone Research Layer

This version adds a new private research layer for relationships among stomach-acid context, digestive symptoms, gut barrier/microbiome hypotheses, nutrition/protein intake, muscle reserve, and testosterone/androgen immune modulation.

New input fields include reflux/heartburn, bloating/dyspepsia, low-acid suspicion pattern, PPI/antacid context, gastritis/H. pylori context, diet diversity, protein estimate, body weight, muscle-mass concern, strength training, appetite, testosterone value if measured, low libido/drive, and low morning energy.

New axes:

- gastricAcidDysregulationAxis
- gutBarrierMicrobiomeAxis
- nutritionProteinAxis
- muscleMassReserveAxis
- testosteroneImmuneModulationAxis

Research Autopilot now searches for gut-acid/allergy, microbiome/gut barrier, nutrition/protein/muscle reserve, and testosterone-immune links, while avoiding repeated PubMed IDs already saved in the local knowledge store.

Safety: all outputs are exploratory hypotheses only. The app does not diagnose digestive, endocrine, nutritional, muscular, or immune disorders and does not recommend treatment.


## v0.8.0-alpha — Research Steering

Research steering lets the user enter variables, focus questions, required context terms, and excluded terms. The engine generates directed variable-bridge queries without editing code.

## v0.9.0-alpha — Evidence Quality & Causal Learning Engine

This version stops treating every new source as equally useful. Each finding now carries:

- evidence quality score,
- human / animal / cell / unknown species bucket,
- study-design classification,
- causality score,
- biological plausibility rationale,
- measurable-marker support,
- personal repeatability proxy,
- negative-control status,
- hypothesis ranking card.

New Kotlin modules:

```text
SourceClassifier.kt
BiologicalPlausibilityGraph.kt
CausalityScorer.kt
NegativeControlEngine.kt
PersonalPatternLedger.kt
ContradictionFinder.kt
HypothesisRankingEngine.kt
```

New Python research tools:

```bash
python3 research/evidence_quality.py
python3 research/causality_scorer.py "stress before allergy histamine blood pressure"
python3 research/personal_time_series.py research/examples/sample_personal_series.csv stress allergy_intensity
python3 research/negative_controls.py research/examples/sample_personal_series.csv stress dizziness
python3 research/hypothesis_ranker.py research/examples/sample_hypotheses.csv
```

Internal continuation document:

```text
docs/PROJECT_INTERNAL_SHEET_v1.1.1.md
```

## v1.1.1 scientific law

Do not learn a relationship because it is interesting. Upgrade it only if it has:

1. plausible biology,
2. measurable markers,
3. time order,
4. repetition,
5. negative-control resistance,
6. no stronger contradiction.


## v1.1.0-alpha — Research Discipline Hardening

This version added engineering discipline around the research loop:

- `AxisMatcher.kt` as the single axis-classification source.
- Coroutine-based Research Autopilot activity lifecycle.
- ActivityResultContracts for imported files.
- Sanity flags such as `ABSTRACT_FETCH_FAILED`, `METADATA_ONLY`, and `LOW_POWER`.
- Expanded JVM unit tests for scoring and parsing modules.

## v1.2.0-alpha — Stable Research Baseline Patch

This patch stabilizes the v1.1 line:

- README version corrected to v1.1.1.
- Python `__pycache__` artifacts removed from release ZIP.
- `.gitignore` added for Android/Python/generated files.
- `omics_bridge.py` fixed so `no`, `unknown`, blank, and equivalent values do not count as DNA/RNA signals.
- Build path documented explicitly in `BUILD.md` because no Gradle Wrapper is bundled in this alpha ZIP.

Internal continuation document:

```text
docs/PROJECT_INTERNAL_SHEET_v1.1.1.md
```


## v1.2 Research Lock System

This release adds a DTOS-inspired research discipline layer. The engine now treats every lead as a living Hypothesis Object with:

- Discovery State: Off / Early / Active / Strong Candidate
- Bias Risk State: Normal / Watch / Alert / Severe Bias
- Minimum Data Pack gate
- Hypothesis-impact test
- Learning Delta cards
- Mistake Library risks
- Falsification points

A finding should not enter the main report unless it changes rank, state, gate, next measurement, or bias warning.


## v1.2.1-alpha — Research Lock Hotfix

This patch stabilizes the v1.2 Research Lock System without adding new biology scope.

Fixed:

- Negative-control scoring now uses actual statuses from `NegativeControlEngine`.
- Empty finding sets no longer trigger false metadata-heavy bias alerts.
- Learning delta comparison preserves newest prior status instead of accidentally using the oldest duplicate.
- Minimum data pack matching is stricter and no longer lets a generic token like `meal` satisfy `meal_timing`.
- Evidence scores are formatted to one decimal in UI/PDF/brief reports.
- Data Trust no longer double-credits human evidence already reflected in source quality.
- CI now runs unit tests before APK assembly.
- Duplicate `biological_plausibility_graph_v0.1.json` removed.

Added v1.2 regression tests for the lock-system modules.
