package com.immunesignal.app

object ResearchReportV3Builder {
    fun build(
        findings: List<ResearchFinding>,
        hypothesisObjects: List<HypothesisObject>,
        learningDeltas: List<LearningDeltaCard>,
        datasetCandidates: List<DatasetCandidateV133>,
        pivot: PivotDecision,
        repeatedSkipped: Int,
        global: GlobalImmuneIntelligenceReport,
        evidenceObjects: List<EvidenceObject> = emptyList(),
        learningOs: LearningOsReport = LearningOsReport.empty(),
        discoveryReadiness: DiscoveryReadinessReport = DiscoveryReadinessReport.empty(),
        datasetForagingReport: DatasetForagingReport = DatasetForagingReport.empty()
    ): ResearchReportV3 {
        val safePivot = ScopeDisciplineLock.sanitizePivot(pivot)
        val topFinding = findings.maxByOrNull { it.noveltyScore }
        val topDataset = datasetCandidates.maxByOrNull { it.priorityScore }
        val topRouteFit = datasetForagingReport.routeFitAssessments.maxByOrNull { it.routeFitScore }
        val firstRouteBlock = datasetForagingReport.routeFitAssessments.firstOrNull { it.blocksHypothesisUpgrade }
        val scoreSeparation = datasetForagingReport.scoreSeparation
        val triageReport = datasetForagingReport.triageReport
        val candidateActionReport = datasetForagingReport.candidateActionReport
        val autoContinuationReport = datasetForagingReport.autoContinuationReport
        val consistencyGuard = datasetForagingReport.reportConsistencyGuard
        val failurePatternReport = datasetForagingReport.failurePatternReport
        val queryFeedbackPlan = datasetForagingReport.queryFeedbackPlan
        val freshnessReport = datasetForagingReport.freshnessReport
        val creativeForge = datasetForagingReport.creativeHypothesisForgeReport
        val accessionAcquisition = datasetForagingReport.accessionAcquisitionReport
        val topCreativeHypothesis = creativeForge.generated.firstOrNull()
        val hasDecisionEvidence = evidenceObjects.any { it.decisionImpact != "no_upgrade" }
        val topDelta = if (hasDecisionEvidence) learningDeltas.firstOrNull { it.deltaType != "no_change" } else null
        val topHypothesis = hypothesisObjects.maxByOrNull { it.evidenceScore10 + it.causalityScore / 20.0 }
        val contradictionFindings = findings.filter { finding ->
            finding.causality.contradictionPenalty > 0 ||
                finding.negativeControl.status.contains("fail", ignoreCase = true) ||
                finding.negativeControl.status.contains("control_required", ignoreCase = true) ||
                finding.sanityFlags.contains("METADATA_ONLY") ||
                finding.sanityFlags.contains("ABSTRACT_FETCH_FAILED")
        }
        val cycleResult = when {
            firstRouteBlock != null && topDataset != null && topDataset.priorityScore >= 60 -> "Off-route dataset lead found"
            topDataset != null && topDataset.priorityScore >= 60 -> "Dataset lead found"
            topDelta != null -> "Hypothesis changed"
            topFinding != null && hasDecisionEvidence -> "Useful evidence object"
            accessionAcquisition.state == "FOUND_ACCESSION" -> "Dataset accession found — metadata closure required"
            accessionAcquisition.state == "FOUND_WEAK_ACCESSION_NEEDS_METADATA" -> "Weak dataset handle found — accession/metadata closure required"
            accessionAcquisition.state == "NO_ACCESSION_ARCHIVE_ROUTE" -> "No accession — archive or reframe route"
            candidateActionReport.minimumMetadataAccessions.isNotEmpty() -> "Dataset candidate selected for minimum metadata parse"
            triageReport.active && triageReport.parsedAccessions.isEmpty() && triageReport.results.isNotEmpty() -> "Dataset candidates triaged — auto-light continuation queued"
            learningOs.incident.rootCauses.isNotEmpty() && evidenceObjects.none { it.decisionImpact != "no_upgrade" } -> "No evidence object — learning gate applied"
            topFinding != null -> "Source found — evidence gate pending"
            safePivot.pivotType != "NO_PIVOT" -> "No useful delta — strategy pivoted"
            repeatedSkipped > 0 -> "Stalled by repeated sources"
            else -> "No useful delta"
        }
        val lead = when {
            topDataset != null && firstRouteBlock != null -> "${topDataset.datasetId}: ${topDataset.dataType}, ${topDataset.species}, ${topDataset.outcomeLabelsHint}. Route gate: ${firstRouteBlock.status} (${firstRouteBlock.datasetRoute} → ${firstRouteBlock.targetRoute})."
            topDataset != null -> "${topDataset.datasetId}: ${topDataset.dataType}, ${topDataset.species}, ${topDataset.outcomeLabelsHint}."
            topFinding != null -> topFinding.title
            accessionAcquisition.state == "FOUND_ACCESSION" -> "Explicit dataset accession(s): ${accessionAcquisition.explicitAccessions.take(3).joinToString(", ")}."
            accessionAcquisition.state == "FOUND_WEAK_ACCESSION_NEEDS_METADATA" -> "Weak dataset handle captured; explicit accession or minimum metadata is still missing."
            accessionAcquisition.state == "NO_ACCESSION_ARCHIVE_ROUTE" -> "No dataset handle after bounded acquisition pressure; route should be archived or reframed."
            topCreativeHypothesis != null -> "Creative hypothesis route: ${topCreativeHypothesis.label} — not evidence; test query prepared."
            else -> "No new useful source saved in this cycle."
        }
        val hypothesisText = buildHypothesisText(topHypothesis, topDelta, topFinding, global, safePivot, firstRouteBlock, topCreativeHypothesis)
        val supporting = buildSupportingEvidence(topDataset, topFinding, topHypothesis, findings, scoreSeparation, topRouteFit)
        val counterEvidence = buildCounterEvidence(contradictionFindings, findings, safePivot, firstRouteBlock)
        val unknowns = buildWhatNotBelieveYet(topFinding, topDataset, topHypothesis, contradictionFindings, safePivot, firstRouteBlock, scoreSeparation)
        val changed = when {
            firstRouteBlock != null -> "No hypothesis upgraded: Route-Fit Gate blocked ${firstRouteBlock.accession} for the current target route. Failure memory and ML-safe triage recorded this as routing feedback, not evidence."
            topDelta != null -> "${topDelta.hypothesisId}: ${topDelta.previousStatus} → ${topDelta.currentStatus} (${topDelta.deltaType})."
            topHypothesis != null -> "${topHypothesis.hypothesisId}: ${topHypothesis.status}, discovery ${topHypothesis.discoveryState}, bias ${topHypothesis.biasRiskState}."
            learningOs.hypothesisUpdateGateStatus == "NO_EVIDENCE_OBJECT_NO_UPGRADE" -> "No hypothesis upgraded: EvidenceObject gate blocked query-only changes."
            else -> "No hypothesis upgraded."
        }
        val why = when {
            candidateActionReport.minimumMetadataAccessions.isNotEmpty() -> "CandidateActionResolver overrode cautious triage for a high route-fit accession and forced minimum metadata inspection; this is search-time learning, not biological proof."
            triageReport.active && triageReport.parsedAccessions.isEmpty() && triageReport.results.isNotEmpty() -> "ML-safe triage did not fully parse candidates; auto-light learning queues a micro-follow-up when metadata remains unresolved."
            firstRouteBlock != null -> "The dataset may be useful, but only as ${firstRouteBlock.datasetRoute}; it cannot support ${firstRouteBlock.targetRoute} without in-route evidence."
            topDataset != null -> topDataset.whyUseful
            topFinding != null -> topFinding.whyItMatters
            global.globalDiscoveryAction.isNotBlank() -> global.globalDiscoveryAction
            else -> "The cycle mainly informed search strategy rather than biology."
        }
        val next = when {
            accessionAcquisition.state in setOf("FOUND_ACCESSION", "FOUND_WEAK_ACCESSION_NEEDS_METADATA", "NO_ACCESSION_ARCHIVE_ROUTE", "NO_ACCESSION_CONTINUE_SOURCE_SWEEP") -> accessionAcquisition.nextAction.take(260)
            autoContinuationReport.triggered -> "Auto-light continuation queued: ${autoContinuationReport.queuedQuery ?: autoContinuationReport.recommendedAction}".take(260)
            creativeForge.active && creativeForge.selectedQuery.isNotBlank() -> "Creative hypothesis test only: ${creativeForge.selectedQuery}".take(260)
            queryFeedbackPlan.active -> "Use the improved query plan next: ${queryFeedbackPlan.improvements.firstOrNull()?.improved ?: queryFeedbackPlan.summary}".take(260)
            failurePatternReport.newlyRecorded.isNotEmpty() -> "Convert recorded failure pattern into next query constraints: ${failurePatternReport.newlyRecorded.first().suggestedAction}".take(260)
            firstRouteBlock != null -> "Re-route ${firstRouteBlock.accession} to ${firstRouteBlock.datasetRoute}, or search for an in-route dataset for ${firstRouteBlock.targetRoute}."
            learningOs.preventiveGates.isNotEmpty() -> learningOs.nextLearningAction.take(260)
            topDataset != null -> topDataset.nextVerificationStep
            safePivot.pivotType != "NO_PIVOT" -> "Pivot to ${safePivot.nextIntent}: ${safePivot.nextQuerySeed}".take(260)
            global.nextGlobalDatasetNeeded.isNotBlank() -> global.nextGlobalDatasetNeeded
            contradictionFindings.isEmpty() && findings.isNotEmpty() -> "Run explicit contradiction search before upgrading this hypothesis."
            else -> "Run the next autonomous Explore/Deepen/Challenge cycle."
        }
        val steeringAxisCaution = if (creativeForge.steeringAxesUsed.isNotEmpty()) " Steering axes used: ${creativeForge.steeringAxesUsed.take(3).joinToString(",") { it.id }}." else ""
        val expandedThinkingCaution = if (creativeForge.expandedThinking.active) " Expanded thinking window: ${creativeForge.expandedThinking.mode}; ${creativeForge.expandedThinking.claimLimit}." else ""
        val creativeCaution = if (creativeForge.active) " Creative Hypothesis Forge: ${creativeForge.summary}$steeringAxisCaution$expandedThinkingCaution Claim limit: ${creativeForge.claimLimit}." else ""
        val accessionCaution = if (accessionAcquisition.active) " Accession acquisition: ${accessionAcquisition.state}; ${accessionAcquisition.nextAction} Claim limit: ${accessionAcquisition.claimLimit}." else ""
        val caution = (unknowns + creativeCaution + accessionCaution + " Auto-light learning: ACTIVE during SEARCH; Deep Think session is not required for failure memory, query feedback, freshness, route-fit, or minimum metadata decisions. Score separation: dataset usability ${scoreSeparation.datasetUsabilityScore}/100, route fit ${scoreSeparation.routeFitScore}/100, hypothesis confidence ${scoreSeparation.hypothesisConfidenceScore}/100 (${scoreSeparation.scoreState}). Candidate action: ${candidateActionReport.summary} Claim limit: ${candidateActionReport.claimLimit}. ML/Triage: ${triageReport.summary} Claim limit: ${triageReport.claimLimit}. Auto-continuation: ${autoContinuationReport.recommendedAction} Report consistency: ${consistencyGuard.status}; ${consistencyGuard.requiredReportLanguage}. Failure memory: ${failurePatternReport.summary}. Query feedback: ${queryFeedbackPlan.summary}. Freshness: average ${freshnessReport.averageFreshness}/100; ${freshnessReport.summary}. Discovery readiness: ${discoveryReadiness.score}/100 ${discoveryReadiness.state}. Learning gate: ${learningOs.hypothesisUpdateGateStatus}.").trim()
        val report = ResearchReportV3(
            cycleResult = cycleResult,
            newUsefulLead = lead,
            hypothesisChanged = changed,
            whyItMatters = why,
            nextAutonomousMove = next,
            doNotBelieveYet = caution,
            technicalPointer = "Open Full Technical Report for locks, evidence, bias, and raw findings.",
            hypothesis = hypothesisText,
            supportingEvidence = supporting,
            counterEvidenceOrContradiction = counterEvidence,
            whatWeDoNotBelieveYet = caution
        )
        return SmartReportIntegrityLock.enforce(report)
    }

    private fun buildHypothesisText(
        topHypothesis: HypothesisObject?,
        topDelta: LearningDeltaCard?,
        topFinding: ResearchFinding?,
        global: GlobalImmuneIntelligenceReport,
        pivot: PivotDecision,
        routeBlock: DatasetRouteFitAssessment?,
        topCreativeHypothesis: CreativeHypothesisCard?
    ): String {
        return when {
            routeBlock != null -> "OFF_ROUTE_USEFUL_DATASET: ${routeBlock.accession} fits ${routeBlock.datasetRoute}, not ${routeBlock.targetRoute}; no hypothesis upgrade."
            topHypothesis != null -> "${topHypothesis.hypothesisId}: ${topHypothesis.label} — state ${topHypothesis.discoveryState}/${topHypothesis.biasRiskState}."
            topDelta != null -> "${topDelta.hypothesisId}: hypothesis state changed from ${topDelta.previousStatus} to ${topDelta.currentStatus}."
            topFinding != null -> "Candidate lead from source ${topFinding.sourceId}: ${topFinding.bridgeSignal.ifBlank { topFinding.title }}."
            global.globalHypotheses.isNotEmpty() -> global.globalHypotheses.first().question
            pivot.pivotType != "NO_PIVOT" -> "Current autonomous search hypothesis is under-specified; the cycle produced a strategy pivot rather than biological confirmation."
            topCreativeHypothesis != null -> "CREATIVE_HYPOTHESIS: ${topCreativeHypothesis.label}; hypothesis invention is not evidence and cannot upgrade biology."
            else -> "No active hypothesis passed the minimum evidence gates in this cycle."
        }
    }

    private fun buildSupportingEvidence(
        topDataset: DatasetCandidateV133?,
        topFinding: ResearchFinding?,
        topHypothesis: HypothesisObject?,
        findings: List<ResearchFinding>,
        scoreSeparation: DatasetScoreSeparation,
        routeFit: DatasetRouteFitAssessment?
    ): String {
        return when {
            topDataset != null && routeFit != null -> "Dataset candidate ${topDataset.datasetId} (${topDataset.dataType}, ${topDataset.species}) with priority ${topDataset.priorityScore}. Score separation: usability ${scoreSeparation.datasetUsabilityScore}/100, route fit ${scoreSeparation.routeFitScore}/100, hypothesis confidence ${scoreSeparation.hypothesisConfidenceScore}/100. Allowed use: ${routeFit.allowedUse}"
            topDataset != null -> "Dataset candidate ${topDataset.datasetId} (${topDataset.dataType}, ${topDataset.species}) with priority ${topDataset.priorityScore}; still requires accession/sample/outcome verification."
            topFinding != null -> "Top source: ${topFinding.title}; evidence quality ${topFinding.evidence.evidenceQualityScore}/100; causality ${topFinding.causality.causalityScore}/100; species ${topFinding.evidence.speciesClass}."
            topHypothesis != null -> "Hypothesis score: evidence ${topHypothesis.evidenceScore10}/10, data trust ${topHypothesis.dataTrustScore}/100, causality ${topHypothesis.causalityScore}/100."
            findings.isNotEmpty() -> "${findings.size} finding(s) survived ranking, but none reached dataset/hypothesis lead priority."
            else -> "No supporting evidence survived this cycle; creative hypotheses, if present, are routing proposals only."
        }
    }

    private fun buildCounterEvidence(
        contradictionFindings: List<ResearchFinding>,
        findings: List<ResearchFinding>,
        pivot: PivotDecision,
        routeBlock: DatasetRouteFitAssessment?
    ): String {
        val direct = contradictionFindings.firstOrNull()
        return when {
            routeBlock != null -> "Route counter-signal: ${routeBlock.accession} is ${routeBlock.status}; dataset route ${routeBlock.datasetRoute}; target route ${routeBlock.targetRoute}; hypothesis upgrade blocked."
            direct != null -> "Counter-signal: ${direct.title}; contradiction penalty ${direct.causality.contradictionPenalty}; negative-control status ${direct.negativeControl.status}; flags ${direct.sanityFlags.joinToString(", ").ifBlank { "none" }}."
            pivot.nextIntent == "contradiction_search" -> "No direct contradiction survived yet; the next move is contradiction search, so confirmation is forbidden."
            findings.isNotEmpty() -> "No explicit contradiction found in surviving findings; absence of contradiction is not confirmation. Run failed-replication/no-association search next."
            else -> "No counter-evidence found because no useful evidence survived; this blocks any upgrade."
        }
    }

    private fun buildWhatNotBelieveYet(
        topFinding: ResearchFinding?,
        topDataset: DatasetCandidateV133?,
        topHypothesis: HypothesisObject?,
        contradictionFindings: List<ResearchFinding>,
        pivot: PivotDecision,
        routeBlock: DatasetRouteFitAssessment?,
        scoreSeparation: DatasetScoreSeparation
    ): String {
        val warnings = mutableListOf<String>()
        warnings += "Do not treat correlation as causation."
        if (topDataset != null) warnings += "Do not believe dataset usefulness until accession, sample size, labels, and license are verified."
        if (routeBlock != null) warnings += "Do not use an off-route dataset to upgrade an unrelated hypothesis; allowed use is contrast/re-route only."
        if (!scoreSeparation.hypothesisUpgradeAllowed) warnings += "Do not upgrade while hypothesis-confidence score remains below the route-fit gate."
        if (topFinding == null && topDataset == null) warnings += "Do not believe any discovery claim from this cycle; it mainly changed search strategy."
        if (topFinding != null && topFinding.evidence.speciesClass != "human") warnings += "Do not generalize animal/cell-only evidence to humans."
        if (topFinding != null && topFinding.sanityFlags.contains("METADATA_ONLY")) warnings += "Do not believe mechanism strength from metadata-only evidence."
        if (topHypothesis != null && topHypothesis.minimumDataPackStatus != "PASS") warnings += "Do not upgrade hypothesis before the minimum data pack passes."
        if (contradictionFindings.isEmpty()) warnings += "Do not assume there is no contradiction; explicit contradiction search is still required."
        if (pivot.pivotType != "NO_PIVOT") warnings += "Do not treat the pivot as evidence; it is only a better next search direction."
        if (scoreSeparation.scoreState != "NOT_EVALUATED") warnings += "Do not treat ML triage, query feedback, failure memory, or freshness weighting as biological proof; they only rank the evidence hunt."
        return warnings.distinct().joinToString(" ")
    }
}
